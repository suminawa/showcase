/** 文面・ファイル名・明細の差し込みデータ（純粋）。メールの本文には金額を入れない（差し込みに金額の字が無い）。 */
import { formatAmount, parseAmount } from "./amount.js";
import { METHOD_ATTACH } from "./employees.js";
import { MONEY_CATEGORIES, TABLE_CATEGORIES } from "./items.js";
import { cellText, plainText } from "./text.js";

/** 本文の {リンク} に入る字 */
export function linkBlock(method, url) {
  if (method === METHOD_ATTACH) return "明細を PDF で添付しています。";
  return "次のリンクから開いてください（このメールが届いたアドレスの Google アカウントで、ログインが要ります）。\n" + url;
}

/** {名前} を置き換える。知らない {…} はそのまま残す */
export function renderTemplate(template, vars) {
  return String(template).replace(/\{([^{}]+)\}/g, (whole, name) => (Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : whole));
}

/**
 * 社員 1 人へのメール。差し込めるのは 氏名・対象月・題・リンク・会社名 だけで、金額は渡さない。
 * 返り値 { subject, body }
 */
export function buildMail(config, name, method, url) {
  const vars = {
    氏名: name,
    対象月: config.month ? config.month.label : "",
    題: config.title,
    リンク: linkBlock(method, url),
    会社名: config.company,
  };
  return { subject: renderTemplate(config.subject, vars).replace(/\s*\n\s*/g, " ").trim(), body: renderTemplate(config.body, vars) };
}

/** ファイル名に使えない字（/ \ : * ? " < > | と改行・タブ）を _ に */
export function safeFileName(text) {
  return cellText(text).replace(/[\\/:*?"<>|\r\n\t]/g, "_").replace(/\s+/g, " ").slice(0, 150);
}

/** 明細 PDF のファイル名: {対象月}_{題}_{社員番号}_{氏名}.pdf。送り直しは _2回目 を付ける */
export function pdfFileName(monthKey, title, id, name, version) {
  const base = [monthKey, title, id, name].map(safeFileName).join("_");
  return base + (version && version > 1 ? "_" + version + "回目" : "") + ".pdf";
}

/**
 * 雛形に差し込むデータ。fields は {{会社名}} などの差し込み記号の値、tables は 4 つの表の行。
 * 0 の行は showZero が false なら出さない（合計は常に出す）。空の金額は 0 とみなす。勤怠は字のまま
 */
export function payslipData(person, items, config, employeeName) {
  const fields = {
    会社名: config.company,
    題: config.title,
    対象月: config.month ? config.month.label : "",
    支給日: config.payday,
    社員番号: person.id,
    氏名: person.name || employeeName || "",
    備考: config.note,
  };
  const tables = {};
  for (let i = 0; i < TABLE_CATEGORIES.length; i += 1) tables[TABLE_CATEGORIES[i]] = [];
  for (let i = 0; i < items.length; i += 1) {
    const item = items[i];
    if (!tables[item.category]) continue;
    const raw = person.values[item.header];
    if (raw === undefined) continue;
    const always = item.category === "合計";
    if (MONEY_CATEGORIES.indexOf(item.category) >= 0) {
      const amount = parseAmount(raw);
      const value = amount === null ? 0 : amount;
      if (!always && !config.showZero && value === 0) continue;
      tables[item.category].push({ label: item.label, value: Number.isNaN(value) ? cellText(raw) : formatAmount(value) });
    } else {
      const text = plainText(raw);
      if (!always && !config.showZero && (text === "" || /^0+([.:]0+)?$/.test(text))) continue;
      tables[item.category].push({ label: item.label, value: text });
    }
  }
  return { fields: fields, tables: tables };
}

/**
 * 試し送り（実行した方あての 1 通）。entries は明細の全員 [{ id, name, method, to, link }]。
 * PDF は添付せず、ドライブに置いた PDF のリンクを並べる（作った方のドライブなので、作った方は開ける。人数が多くても 25 MB の上限に当たらない）
 */
export function buildTrialMail(config, entries) {
  const month = config.month ? config.month.label : "";
  const lines = [
    "【試し送り】" + month + "分の" + config.title + "です。社員の方には送っていません。",
    "",
    "下のリンクから PDF（" + entries.length + " 人分）の体裁と金額を、一覧から宛先と渡し方をご確認ください。",
    "",
  ];
  for (let i = 0; i < entries.length; i += 1) {
    const entry = entries[i];
    lines.push(entry.id + " " + entry.name + " → " + (entry.to ? entry.to + "（" + entry.method + "）" : entry.method));
    if (entry.link) lines.push("  " + entry.link);
  }
  lines.push("", "よければ、メニュー「給与明細」→「配る」を押してください。");
  lines.push("明細や社員シート・設定を直したときは、もう一度「試し送り」を押してから配ります。");
  return { subject: "【試し送り】" + month + "分 " + config.title + "（" + entries.length + " 人分）", body: lines.join("\n") };
}
