/** 字のそろえ方（純粋）。取り込み・社員・記録が同じ形で比べられるように、ここに 1 つだけ置く。 */

/** セルの値を字に。NFKC で全角英数・半角カナをそろえ、前後の空白を落とす。null / undefined は "" */
export function cellText(value) {
  if (value === null || value === undefined) return "";
  return String(value).normalize("NFKC").trim();
}

/** 見出しのゆれをそろえる: 改行・全角スペース・続く空白は 1 つの半角空白 */
export function normalizeHeader(value) {
  return cellText(value).replace(/\s+/g, " ");
}

/** 社員番号を比べる鍵。数字だけなら先頭の 0 を落とす（シートが 001001 を 1001 に読み替えることがあるため） */
export function idKey(value) {
  const text = cellText(value);
  if (/^\d+$/.test(text)) return text.replace(/^0+(?=\d)/, "");
  return text;
}

/** 中身の指紋（djb2 の 32 bit を 16 進 8 桁）。試し送りのあとに明細や宛先が変わったかを見分けるだけに使う */
export function fingerprint(value) {
  const text = typeof value === "string" ? value : JSON.stringify(value);
  let hash = 5381;
  for (let i = 0; i < text.length; i += 1) hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  return ("0000000" + hash.toString(16)).slice(-8);
}

/**
 * 勤怠などの字の欄。シートが「12:30」「25:00」を時刻（1899-12-30 起点の Date）に読み替えたものは「12:30」に戻す。
 * ほかの Date は「2026/10/25」、それ以外は cellText
 */
export function plainText(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    if (value.getFullYear() < 1900) {
      const minutes = Math.round((value.getTime() - new Date(1899, 11, 30).getTime()) / 60000); // 秒は分に丸める
      return Math.floor(minutes / 60) + ":" + ("0" + (minutes % 60)).slice(-2);
    }
    return value.getFullYear() + "/" + (value.getMonth() + 1) + "/" + value.getDate();
  }
  const text = cellText(value);
  // 「25:00:00」「12:00:00」のように秒まで付いた時刻も [h]:mm にそろえる
  const time = text.match(/^(\d+):(\d{2}):(\d{2})$/);
  if (time) {
    const minutes = Number(time[1]) * 60 + Number(time[2]) + Math.round(Number(time[3]) / 60);
    return Math.floor(minutes / 60) + ":" + ("0" + (minutes % 60)).slice(-2);
  }
  return text;
}
