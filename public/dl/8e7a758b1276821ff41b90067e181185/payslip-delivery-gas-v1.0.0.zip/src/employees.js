/** 「社員」シート（純粋）: 社員番号・氏名・メール・渡し方・電子交付の同意日・在籍。 */
import { isFree } from "./edition.js";
import { cellText, idKey, normalizeHeader } from "./text.js";

export const EMPLOYEES_TAB = "社員";
export const METHOD_SHARE = "共有";
export const METHOD_ATTACH = "添付";
export const ACTIVE = "在籍";
export const RETIRED = "退職";
export const CONSENT_HEADER = "電子交付の同意日";

/** 社員シートの見出し。無料版は同意の列が無い */
export function employeeHeaders(edition) {
  const all = ["社員番号", "氏名", "メール", "渡し方", CONSENT_HEADER, "在籍"];
  return isFree(edition) ? all.filter((name) => name !== CONSENT_HEADER) : all;
}

/** メールの形（@ の前後に字があり、ドメインに点がある。空白・カンマ・山括弧は不可） */
export function isEmail(value) {
  const text = cellText(value);
  return !ZERO_WIDTH.test(text) && /^[^\s@,;<>()]+@[^\s@,;<>()]+\.[^\s@,;<>()]+$/.test(text);
}

/** 見えない字（ゼロ幅の空白など）。NFKC でも \s でも落ちない */
const ZERO_WIDTH = /[\u200B-\u200D\u2060\uFEFF]/;

/**
 * 同じ受信箱かを比べる鍵（宛先そのものは変えない）。小文字・見えない字を落とす・「+」から @ の前までを落とす。
 * Gmail（gmail.com / googlemail.com）は点を落として gmail.com にそろえる
 */
export function mailKey(value) {
  const text = cellText(value).toLowerCase().replace(new RegExp(ZERO_WIDTH.source, "g"), "");
  const at = text.lastIndexOf("@");
  if (at < 0) return text;
  let local = text.slice(0, at).replace(/\+.*$/, "");
  let domain = text.slice(at + 1);
  if (domain === "gmail.com" || domain === "googlemail.com") {
    local = local.replace(/\./g, "");
    domain = "gmail.com";
  }
  return local + "@" + domain;
}

/**
 * 社員シートを読む。見出しの名前で列を探す（列の順は自由）。社員番号が空の行は飛ばす。
 * method は「共有」「添付」（空は共有）。それ以外の字は methodRaw に残し、確かめるが知らせる。
 */
export function parseEmployees(rows, edition) {
  const list = Array.isArray(rows) ? rows : [];
  const header = (list[0] || []).map((cell) => normalizeHeader(cell));
  const col = (name) => header.indexOf(name);
  const at = (row, name) => (col(name) >= 0 ? row[col(name)] : "");
  const employees = [];
  for (let r = 1; r < list.length; r += 1) {
    const row = Array.isArray(list[r]) ? list[r] : [];
    const id = cellText(at(row, "社員番号"));
    if (id === "") continue;
    const methodRaw = cellText(at(row, "渡し方"));
    const status = cellText(at(row, "在籍"));
    const consent = at(row, CONSENT_HEADER);
    employees.push({
      id: id,
      key: idKey(id),
      name: cellText(at(row, "氏名")).replace(/\s+/g, " "),
      email: cellText(at(row, "メール")).toLowerCase(),
      method: methodRaw === METHOD_ATTACH ? METHOD_ATTACH : METHOD_SHARE,
      methodRaw: methodRaw,
      consent: isFree(edition) ? true : consent instanceof Date || cellText(consent) !== "",
      active: status !== RETIRED,
      row: r + 1,
    });
  }
  return employees;
}

/** 社員番号の鍵 → 社員 */
export function employeesByKey(employees) {
  const map = {};
  for (let i = 0; i < employees.length; i += 1) if (map[employees[i].key] === undefined) map[employees[i].key] = employees[i];
  return map;
}
