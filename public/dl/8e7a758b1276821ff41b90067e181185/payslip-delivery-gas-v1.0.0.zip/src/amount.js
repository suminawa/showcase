/** 金額の読み取りと書式（純粋）。 */
import { cellText } from "./text.js";

/**
 * 社労士や給与ソフトの字を数に。全角・「円」「¥」・カンマ・空白・△▲（マイナス）を読む。
 * 空は null、読めない字は NaN（取り込みの結果でお知らせする）。
 */
export function parseAmount(value) {
  if (typeof value === "number") return value;
  let text = cellText(value).replace(/[\s,円¥￥]/g, "");
  if (text === "") return null;
  let sign = 1;
  if (/^[△▲\-−‐ー]/.test(text)) {
    sign = -1;
    text = text.slice(1);
  }
  if (!/^\d+(\.\d+)?$/.test(text)) return NaN;
  return sign * Number(text);
}

/** 3 桁区切り。マイナスは「-1,234」。null は "" */
export function formatAmount(value) {
  if (value === null || value === undefined || value === "") return "";
  const number = Number(value);
  if (!Number.isFinite(number)) return String(value);
  const parts = String(Math.abs(number)).split(".");
  const whole = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (number < 0 ? "-" : "") + whole + (parts.length > 1 ? "." + parts[1] : "");
}
