/** スプレッドシートの読み書き（GAS）。どのシートも名前で探す。 */
import { CHECK_TAB, checkSheetRows } from "./check.js";
import { SETTINGS_TAB } from "./config.js";
import { EMPLOYEES_TAB } from "./employees.js";
import { DETAIL_TAB, PASTE_TAB } from "./importer.js";
import { ITEMS_TAB, MONEY_CATEGORIES } from "./items.js";
import { LEDGER_HEADERS, LEDGER_TAB, ledgerRow, parseLedger } from "./ledger.js";
import { sheetSpecs } from "./setup.js";

/** 字の先頭が = + @ だと Sheets が式として読むので、' を付けて字のまま置く */
function safeCell_(value) {
  return typeof value === "string" && /^[=+@]/.test(value) ? "'" + value : value;
}

function safeRows_(rows) {
  return rows.map((row) => row.map(safeCell_));
}

function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

/** シートの値。シートが無ければ null、空なら [] */
export function sheetValues_(name) {
  const sheet = book_().getSheetByName(name);
  if (!sheet) return null;
  return sheet.getLastRow() === 0 ? [] : sheet.getDataRange().getValues();
}

/** シートの値。無ければ、初期化を促して止める */
export function requiredValues_(name) {
  const values = sheetValues_(name);
  if (values === null) throw new Error("「" + name + "」シートがありません。メニュー「給与明細」→「初期化」を押してください。");
  return values;
}

/** 初期化で読むもの: 7 枚のシートのうち、あるものの値 */
export function readInitSnapshot_(edition) {
  const sheets = {};
  const specs = sheetSpecs(edition);
  for (let i = 0; i < specs.length; i += 1) {
    const values = sheetValues_(specs[i][0]);
    if (values !== null) sheets[specs[i][0]] = values;
  }
  return sheets;
}

/** 初期化の計画を書く。あるセルには書かない */
export function applyInit_(plan) {
  const book = book_();
  for (let i = 0; i < plan.create.length; i += 1) {
    const entry = plan.create[i];
    const sheet = entry.exists ? book.getSheetByName(entry.name) : book.insertSheet(entry.name);
    if (entry.rows.length > 0) {
      const width = entry.rows.reduce((max, row) => Math.max(max, row.length), 0);
      const rows = entry.rows.map((row) => row.concat(new Array(width - row.length).fill("")));
      sheet.getRange(1, 1, rows.length, width).setValues(rows);
      sheet.setFrozenRows(1);
      sheet.getRange(1, 1, 1, width).setFontWeight("bold");
    }
    if (entry.name === SETTINGS_TAB) sheet.setColumnWidth(2, 420);
    if (entry.name === EMPLOYEES_TAB) sheet.getRange("A:A").setNumberFormat("@");
    if (entry.name === LEDGER_TAB) sheet.getRange("A:D").setNumberFormat("@"); // 対象月の 2026-10 を日付に読み替えさせない
  }
  for (let i = 0; i < plan.appendHeaders.length; i += 1) {
    const entry = plan.appendHeaders[i];
    const sheet = book.getSheetByName(entry.sheet);
    const start = sheet.getLastColumn() + 1;
    const last = start + entry.names.length - 1;
    if (last > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), last - sheet.getMaxColumns());
    sheet.getRange(1, start, 1, entry.names.length).setValues([entry.names]).setFontWeight("bold");
  }
  if (plan.appendSettings.length > 0) {
    const sheet = book.getSheetByName(SETTINGS_TAB);
    sheet.getRange(sheet.getLastRow() + 1, 1, plan.appendSettings.length, 2).setValues(plan.appendSettings);
  }
}

/** 貼り付けシートの値 */
export function readPasteValues_() {
  return requiredValues_(PASTE_TAB);
}

/** 項目シートの末尾に足す */
export function appendItems_(rows) {
  if (rows.length === 0) return;
  const sheet = book_().getSheetByName(ITEMS_TAB);
  sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, rows[0].length).setValues(safeRows_(rows));
}

/** 明細シートを書き直す（取り込みのたびに作り直す）。社員番号は字のまま、金額の列は 3 桁区切りで見せる */
export function writeDetail_(rows, items) {
  const sheet = book_().getSheetByName(DETAIL_TAB);
  sheet.clear();
  const width = rows[0].length;
  sheet.getRange(1, 1, Math.max(rows.length, 1), 1).setNumberFormat("@");
  // 勤怠などの字の列は、書いてから時刻に読み替えられない（25:00 が 25:00:00 にならない）よう、先に書式「@」にする
  for (let i = 0; i < items.length; i += 1) {
    if (MONEY_CATEGORIES.indexOf(items[i].category) < 0) sheet.getRange(1, 3 + i, rows.length, 1).setNumberFormat("@");
  }
  sheet.getRange(1, 1, rows.length, width).setValues(safeRows_(rows));
  sheet.getRange(1, 1, 1, width).setFontWeight("bold");
  sheet.setFrozenRows(1);
  for (let i = 0; i < items.length; i += 1) {
    if (MONEY_CATEGORIES.indexOf(items[i].category) >= 0 && rows.length > 1) {
      sheet.getRange(2, 3 + i, rows.length - 1, 1).setNumberFormat("#,##0");
    }
  }
}

/** 確かめるシートを書き直し、要確認の行を色で目立たせる */
export function writeChecks_(results) {
  const book = book_();
  const sheet = book.getSheetByName(CHECK_TAB) || book.insertSheet(CHECK_TAB);
  const rows = checkSheetRows(results);
  sheet.clear();
  sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
  sheet.getRange(1, 1, 1, rows[0].length).setFontWeight("bold");
  sheet.setFrozenRows(1);
  sheet.setColumnWidth(1, 360);
  sheet.setColumnWidth(4, 640);
  sheet.getRange(2, 4, rows.length - 1, 1).setWrap(true);
  for (let i = 0; i < results.length; i += 1) {
    const color = results[i].status === "要確認" ? "#fde2e1" : results[i].status === "お知らせ" ? "#fff4d6" : null;
    sheet.getRange(i + 2, 1, 1, rows[0].length).setBackground(color);
  }
}

/** 送信記録に 1 行足し、すぐに書き込む（送る前の「送信中」が落ちても残るように） */
export function appendLedger_(entry) {
  const sheet = book_().getSheetByName(LEDGER_TAB);
  // 1.0.0 の初期化より前に作ったシートでも、対象月の 2026-10 を日付に読み替えさせない
  sheet.getRange(sheet.getLastRow() + 1, 1, 1, 4).setNumberFormat("@");
  sheet.appendRow(ledgerRow(entry).map(safeCell_));
  SpreadsheetApp.flush();
}

/**
 * 送信記録の行を書き換える。鍵と版と状態（「送信中」）で探す（途中で人が行を足し引きしても、行を取り違えない）。
 * row を渡したときは、その行の鍵が合うかだけを確かめて書く
 */
export function updateLedger_(match, changes) {
  const sheet = book_().getSheetByName(LEDGER_TAB);
  const records = parseLedger(sheet.getDataRange().getValues());
  const found = records.filter((record) =>
    record.key === match.key && record.version === match.version && (match.row ? record.row === match.row : record.status === match.status),
  );
  if (found.length === 0) throw new Error("「" + LEDGER_TAB + "」に " + match.key + " の行が見つかりません。行を消さずに、もう一度お試しください。");
  const record = Object.assign({}, found[found.length - 1], changes);
  sheet.getRange(record.row, 1, 1, 4).setNumberFormat("@");
  sheet.getRange(record.row, 1, 1, LEDGER_HEADERS.length).setValues([ledgerRow(record).map(safeCell_)]);
  SpreadsheetApp.flush();
}
