/**
 * 「貼り付け」シートの取り込み（純粋）。社労士や給与ソフトの一覧を、1 人 1 行の明細に整える。
 * - 見出しの行は「社員番号」の列名がある行から決める（上の段・下の段を含めて最大 3 行）
 * - 結合されて空いている上の段は、左の値で埋めて「支給 基本給」のように 1 つの見出しにする
 * - 合計・小計・計の行と、社員番号が空の行は捨てる（件数を返す）
 */
import { parseAmount } from "./amount.js";
import { MONEY_CATEGORIES } from "./items.js";
import { cellText, idKey, normalizeHeader, plainText } from "./text.js";

export const PASTE_TAB = "貼り付け";
export const DETAIL_TAB = "明細";
export const ID_HEADER = "社員番号";
export const NAME_HEADER = "氏名";

/** 社員番号の列とみなす見出し（空白を落としてから比べる） */
export const ID_ALIASES = ["社員番号", "社員No", "社員NO", "社員no", "社員№", "社員コード", "社員CD", "社員ID", "従業員番号", "従業員コード", "従業員No", "従業員ID", "個人コード", "社員No."];
/** 氏名の列とみなす見出し */
export const NAME_ALIASES = ["氏名", "名前", "社員名", "従業員名", "氏名(漢字)", "社員氏名"];
/** 自動判定で見出しを探す行の数 */
const SEARCH_ROWS = 15;
const MAX_HEADER_ROWS = 3;

function compact(value) {
  return normalizeHeader(value).replace(/\s/g, "");
}

function isIdHeader(value) {
  return ID_ALIASES.indexOf(compact(value)) >= 0;
}

function isNameHeader(value) {
  return NAME_ALIASES.indexOf(compact(value)) >= 0;
}

function filled(row) {
  return (Array.isArray(row) ? row : []).filter((cell) => cellText(cell) !== "").length;
}

/** 合計・小計・計の行の印（社員番号か氏名の欄にこの字がある） */
function isTotalWord(value) {
  return /^(総?合計|小計|総計|計|.{1,6}計)$/.test(compact(value).replace(/[()[\]【】「」〔〕<>＜＞]/g, ""));
}

/**
 * 見出しの行の範囲を決める。返り値 { start, end, idCol } か、見つからなければ null。
 * headerRows が数なら、社員番号の列名がある段から下へ数えて、そこまでを見出しにする（上の段の題は読まない）。
 */
export function findHeaderRows(rows, headerRows) {
  const limit = Math.min(rows.length, SEARCH_ROWS);
  for (let r = 0; r < limit; r += 1) {
    const row = Array.isArray(rows[r]) ? rows[r] : [];
    for (let c = 0; c < row.length; c += 1) {
      if (!isIdHeader(row[c])) continue;
      let start = r;
      let end = r;
      if (typeof headerRows === "number") {
        end = Math.min(rows.length - 1, r + headerRows - 1);
        return { start: start, end: end, idCol: c };
      }
      // 下の段: 社員番号の欄が空で、字の見出しが 2 つ以上ある行（1 段目が縦に結合された 2 段の見出し）
      while (end + 1 < rows.length && end - start + 1 < MAX_HEADER_ROWS) {
        const below = Array.isArray(rows[end + 1]) ? rows[end + 1] : [];
        const texts = below.filter((cell) => cellText(cell) !== "" && Number.isNaN(Number(cellText(cell))));
        if (cellText(below[c]) !== "" || texts.length < 2) break;
        end += 1;
      }
      // 上の段: すぐ上の行に字があり、社員番号の列の上が空なら、まとまりの見出し（「支給」「控除」）とみなす。
      // 社員番号の列の上に字がある行は、表の題（「給与一覧表」）として読まない
      while (start - 1 >= 0 && end - start + 1 < MAX_HEADER_ROWS && filled(rows[start - 1]) >= 1 && cellText((rows[start - 1] || [])[c]) === "") start -= 1;
      return { start: start, end: end, idCol: c };
    }
  }
  return null;
}

/**
 * 段になった見出しを 1 つに。上の段の空きは、下の段に字がある列だけ、左の値で埋める（結合セルの空き）。
 * 下の段が空の列（縦の結合）は、上の段の字だけになる。同じ字が続けば 1 つにする。
 */
export function combineHeaders(headerRows) {
  const width = headerRows.reduce((max, row) => Math.max(max, Array.isArray(row) ? row.length : 0), 0);
  const grid = headerRows.map((row) => {
    const line = [];
    for (let c = 0; c < width; c += 1) line.push(normalizeHeader(Array.isArray(row) ? row[c] : ""));
    return line;
  });
  for (let r = 0; r < grid.length - 1; r += 1) {
    let carry = "";
    for (let c = 0; c < width; c += 1) {
      let below = false;
      for (let k = r + 1; k < grid.length; k += 1) if (grid[k][c] !== "") below = true;
      if (grid[r][c] !== "") carry = below ? grid[r][c] : "";
      else if (below) grid[r][c] = carry;
      else carry = "";
    }
  }
  const names = [];
  for (let c = 0; c < width; c += 1) {
    const parts = [];
    for (let r = 0; r < grid.length; r += 1) {
      if (grid[r][c] !== "" && parts[parts.length - 1] !== grid[r][c]) parts.push(grid[r][c]);
    }
    names.push(parts.join(" "));
  }
  return names;
}

/**
 * 貼り付けた一覧を読む。
 * 返り値: { ok, problem, headers: [{ col, name }]（社員番号・氏名を除く項目）, idCol, nameCol,
 *          people: [{ id, key, name, values: { 見出し: 元の値 }, row }], dropped: { totals, noId } }
 */
export function readPaste(rows, headerRows) {
  const list = Array.isArray(rows) ? rows : [];
  const found = findHeaderRows(list, headerRows === undefined ? "auto" : headerRows);
  if (!found) {
    return {
      ok: false,
      problem: "「" + PASTE_TAB + "」シートの上から " + SEARCH_ROWS + " 行に「社員番号」の列が見つかりません。A1 に一覧をそのまま貼るか、社員番号の列の見出しを「社員番号」にしてください。",
      headers: [], people: [], dropped: { totals: 0, noId: 0 },
    };
  }
  const names = combineHeaders(list.slice(found.start, found.end + 1));
  let nameCol = -1;
  const headers = [];
  for (let c = 0; c < names.length; c += 1) {
    if (c === found.idCol || names[c] === "") continue;
    if (nameCol < 0 && isNameHeader(names[c].split(" ").pop())) {
      nameCol = c;
      continue;
    }
    // 同じ見出しが 2 つあれば、右の列に「(2)」と番号を付けて両方残す（1 段の見出しの「その他」など）
    let name = names[c];
    for (let n = 2; headers.some((h) => h.name === name); n += 1) name = names[c] + " (" + n + ")";
    headers.push({ col: c, name: name });
  }
  const people = [];
  const dropped = { totals: 0, noId: 0 };
  for (let r = found.end + 1; r < list.length; r += 1) {
    const row = Array.isArray(list[r]) ? list[r] : [];
    if (filled(row) === 0) continue;
    const id = cellText(row[found.idCol]);
    const name = nameCol >= 0 ? cellText(row[nameCol]).replace(/\s+/g, " ") : "";
    if (isTotalWord(id) || (id === "" && isTotalWord(name))) {
      dropped.totals += 1;
      continue;
    }
    if (id === "") {
      dropped.noId += 1;
      continue;
    }
    const values = {};
    for (let i = 0; i < headers.length; i += 1) values[headers[i].name] = row[headers[i].col];
    people.push({ id: id, key: idKey(id), name: name, values: values, row: r + 1 });
  }
  return { ok: true, problem: "", headers: headers, idCol: found.idCol, nameCol: nameCol, people: people, dropped: dropped };
}

/**
 * 明細シートの行を作る。1 行目は「社員番号」「氏名」と項目の見出し。金額の区分は数に直し、勤怠などは字のまま。
 * 返り値: { rows, badCells: [{ row, header, value }] }（金額として読めなかったセル。字のまま残す）
 */
export function buildDetailRows(people, items, namesById) {
  const headers = items.map((item) => item.header);
  const rows = [[ID_HEADER, NAME_HEADER].concat(headers)];
  const badCells = [];
  for (let p = 0; p < people.length; p += 1) {
    const person = people[p];
    const name = person.name || (namesById && namesById[person.key]) || "";
    const line = [person.id, name];
    for (let i = 0; i < items.length; i += 1) {
      const item = items[i];
      const raw = person.values[item.header];
      if (MONEY_CATEGORIES.indexOf(item.category) >= 0) {
        const amount = parseAmount(raw);
        if (Number.isNaN(amount)) {
          badCells.push({ row: person.row, header: item.header, value: cellText(raw) });
          line.push(cellText(raw));
        } else {
          line.push(amount === null ? "" : amount);
        }
      } else {
        line.push(typeof raw === "number" ? raw : plainText(raw));
      }
    }
    rows.push(line);
  }
  return { rows: rows, badCells: badCells };
}

/** 取り込みの結果の 1 通 */
export function importReport(result) {
  const lines = ["明細に " + result.people + " 人を取り込みました。"];
  if (result.totals > 0) lines.push("・合計・小計の行を " + result.totals + " 行、読み飛ばしました");
  if (result.noId > 0) lines.push("・社員番号が空の行を " + result.noId + " 行、読み飛ばしました");
  if (result.added.length > 0) {
    lines.push("・「項目」シートに見出しを " + result.added.length + " 個足しました。区分は推定です。違っていれば直して、もう一度「取り込む」を押してください");
    const unknown = result.added.filter((row) => row[1] === "").map((row) => row[0]);
    if (unknown.length > 0) lines.push("・区分を推定できなかった見出し（「項目」シートで選んでください）: " + unknown.join("、"));
  }
  for (let i = 0; i < result.badCells.length && i < 10; i += 1) {
    const bad = result.badCells[i];
    lines.push("・金額として読めませんでした: 「" + PASTE_TAB + "」の " + bad.row + " 行目「" + bad.header + "」の「" + bad.value + "」");
  }
  if (result.badCells.length > 10) lines.push("・ほか " + (result.badCells.length - 10) + " か所、金額として読めませんでした");
  if (result.cut > 0) lines.push("・無料版は 3 人まで取り込みます。残りの " + result.cut + " 人は取り込んでいません");
  lines.push("", "次は、メニュー「給与明細」→「確かめる」を押してください。");
  return lines.join("\n");
}

/** 明細シートを読む。1 行目が見出し（社員番号・氏名・項目）。社員番号が空の行は飛ばす */
export function parseDetail(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const header = (list[0] || []).map(normalizeHeader);
  const idCol = header.indexOf(ID_HEADER);
  const nameCol = header.indexOf(NAME_HEADER);
  const people = [];
  if (idCol < 0) return { headers: [], people: people };
  const headers = header.filter((name, c) => c !== idCol && c !== nameCol && name !== "");
  for (let r = 1; r < list.length; r += 1) {
    const row = Array.isArray(list[r]) ? list[r] : [];
    const id = cellText(row[idCol]);
    if (id === "") continue;
    const values = {};
    for (let c = 0; c < header.length; c += 1) {
      if (c !== idCol && c !== nameCol && header[c] !== "") values[header[c]] = row[c];
    }
    people.push({ id: id, key: idKey(id), name: nameCol >= 0 ? cellText(row[nameCol]) : "", values: values, row: r + 1 });
  }
  return { headers: headers, people: people };
}
