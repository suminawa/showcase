/** 「項目」シート（純粋）: 見出しごとの区分・並び順・表示名。区分は語の辞書で推定し、人が直した値は残す。 */
import { cellText, normalizeHeader } from "./text.js";

export const ITEMS_TAB = "項目";
export const ITEM_HEADERS = ["見出し", "区分", "並び順", "表示名"];
export const CATEGORIES = ["勤怠", "支給", "控除", "合計", "表示しない"];
/** PDF に表として並べる区分（この順で 4 つの表になる） */
export const TABLE_CATEGORIES = ["勤怠", "支給", "控除", "合計"];
/** 金額として読む区分 */
export const MONEY_CATEGORIES = ["支給", "控除", "合計"];

/**
 * 区分の辞書。上から順に、見出しにその語が含まれるかを見る。
 * 合計を先に見るのは「支給合計」「控除合計」「差引支給額」を支給・控除と取り違えないため。
 * 支給を勤怠より先に見るのは「残業手当」「時間外手当」を勤怠と取り違えないため。
 */
export const CATEGORY_WORDS = [
  ["合計", ["差引", "合計", "総支給", "総額", "手取", "振込額", "支給額", "控除額計"]],
  [
    "控除",
    [
      "控除", "健康保険", "健保", "介護保険", "厚生年金", "年金", "雇用保険", "社会保険", "社保", "所得税", "住民税", "市民税",
      "源泉", "組合費", "財形", "社宅", "寮費", "貸付", "返済", "積立", "互助会", "親睦会", "前払",
    ],
  ],
  ["支給", ["支給", "手当", "基本給", "給与", "給料", "賞与", "報酬", "割増", "通勤", "交通費", "精算", "調整", "日給", "時給"]],
  ["表示しない", ["部署", "所属", "部門", "役職", "等級", "銀行", "口座", "振込先", "入社", "年齢", "生年月日", "性別", "フリガナ", "カナ"]],
  ["勤怠", ["勤怠", "日数", "時間", "回数", "出勤", "欠勤", "有給", "有休", "休暇", "遅刻", "早退", "休日", "深夜", "残業", "労働"]],
];

/** 1 語の区分を辞書で引く。無ければ "" */
function lookup(word) {
  const text = normalizeHeader(word).replace(/\s/g, "");
  if (text === "") return "";
  for (let i = 0; i < CATEGORY_WORDS.length; i += 1) {
    const words = CATEGORY_WORDS[i][1];
    for (let j = 0; j < words.length; j += 1) if (text.indexOf(words[j]) >= 0) return CATEGORY_WORDS[i][0];
  }
  return "";
}

/**
 * 見出しの区分を推定する。2 段の見出し「支給 その他」は、下の段（その他）で引けなければ上の段（支給）で引く。
 * 引けなければ ""（「確かめる」が区分の空きとしてお知らせする）。
 */
export function guessCategory(header) {
  const parts = normalizeHeader(header).split(" ").filter((part) => part !== "");
  for (let i = parts.length - 1; i >= 0; i -= 1) {
    const found = lookup(parts[i]);
    if (found !== "") return found;
  }
  return "";
}

/** 表示名の既定: 2 段の見出しの下の段（「支給 基本給」→「基本給」） */
export function defaultLabel(header) {
  const parts = normalizeHeader(header).split(" ").filter((part) => part !== "");
  return parts.length === 0 ? "" : parts[parts.length - 1];
}

/** 項目シートを読む。見出しが空の行は飛ばす。並び順が数でなければ、シートの上からの順 */
export function parseItems(rows) {
  const list = Array.isArray(rows) ? rows.slice(1) : [];
  const items = [];
  for (let i = 0; i < list.length; i += 1) {
    const row = Array.isArray(list[i]) ? list[i] : [];
    const header = normalizeHeader(row[0]);
    if (header === "") continue;
    const order = Number(cellText(row[2]));
    items.push({
      header: header,
      category: cellText(row[1]),
      order: cellText(row[2]) !== "" && Number.isFinite(order) ? order : 1000 + i,
      label: cellText(row[3]) || defaultLabel(header),
    });
  }
  return items;
}

/**
 * 取り込んだ見出しを項目シートに足す。すでにある見出しの区分・並び順・表示名は変えない（人が直した値を残す）。
 * 返り値: { items（並び順に並べた全部）, added（新しく足した行。シートの末尾に書く [見出し, 区分, 並び順, 表示名]） }
 */
export function mergeItems(existing, headers) {
  const items = existing.slice();
  const have = {};
  let next = 0;
  for (let i = 0; i < items.length; i += 1) {
    have[items[i].header] = true;
    if (items[i].order < 1000) next = Math.max(next, items[i].order);
  }
  const added = [];
  for (let i = 0; i < headers.length; i += 1) {
    const header = normalizeHeader(headers[i]);
    if (header === "" || have[header] === true) continue;
    have[header] = true;
    next += 1;
    const item = { header: header, category: guessCategory(header), order: next, label: defaultLabel(header) };
    items.push(item);
    added.push([item.header, item.category, item.order, item.label]);
  }
  return { items: sortItems(items), added: added };
}

/** 並び順で並べる（同じ数ならもとの順） */
export function sortItems(items) {
  return items
    .map((item, index) => ({ item: item, index: index }))
    .sort((a, b) => a.item.order - b.item.order || a.index - b.index)
    .map((entry) => entry.item);
}
