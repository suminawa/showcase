/**
 * 「送信記録」シート（純粋）: 二重送信の防止・送り直しの版・落ちたときの「送信中」・続きの計画。
 * 鍵 = 対象月 + 社員番号 + 題。記録に「送信済み」か「送信中」の鍵があれば送らない。
 */
import { cellText, idKey } from "./text.js";

export const LEDGER_TAB = "送信記録";
export const LEDGER_HEADERS = ["鍵", "対象月", "題", "社員番号", "氏名", "宛先", "渡し方", "状態", "版", "ファイルID", "共有ID", "日時", "メモ"];
export const SENDING = "送信中";
export const SENT = "送信済み";
export const FAILED = "失敗";
/** 1 回の実行で使ってよい時間（Apps Script の 6 分の上限より手前で止める） */
export const TIME_LIMIT_MS = 270000;

export function keyOf(monthKey, id, title) {
  return cellText(monthKey) + "|" + idKey(id) + "|" + cellText(title);
}

/** 記録を読む。row はシートの行番号（1 始まり） */
export function parseLedger(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const records = [];
  for (let r = 1; r < list.length; r += 1) {
    const row = Array.isArray(list[r]) ? list[r] : [];
    const key = cellText(row[0]);
    if (key === "") continue;
    records.push({
      key: key,
      month: cellText(row[1]),
      title: cellText(row[2]),
      id: cellText(row[3]),
      name: cellText(row[4]),
      to: cellText(row[5]),
      method: cellText(row[6]),
      status: cellText(row[7]),
      version: Number(cellText(row[8])) || 1,
      fileId: cellText(row[9]),
      permissionId: cellText(row[10]),
      at: row[11],
      memo: cellText(row[12]),
      row: r + 1,
    });
  }
  return records;
}

/** 記録の 1 行（シートに書く形） */
export function ledgerRow(entry) {
  return [
    entry.key, entry.month, entry.title, entry.id, entry.name, entry.to, entry.method, entry.status,
    entry.version, entry.fileId || "", entry.permissionId || "", entry.at || "", entry.memo || "",
  ];
}

/** 送った（送っている途中を含む）記録があるか。失敗の行は、次の「配る」でもう一度送る */
export function isDone(records, key) {
  return records.some((record) => record.key === key && (record.status === SENT || record.status === SENDING));
}

/** その月・題で「送信中」のまま残った行（実行が途中で落ちた印）。人が直すまで送らない */
export function stuckRecords(records, monthKey, title) {
  return records.filter((record) => record.month === monthKey && record.title === title && record.status === SENDING);
}

/** その月・題で送った記録 */
export function sentRecords(records, monthKey, title) {
  return records.filter((record) => record.month === monthKey && record.title === title && record.status === SENT);
}

/**
 * 送り直しの版。送った記録が無ければ null（送り直しではなく、ふつうの「配る」で送る）。
 * 返り値 { version, previous }（previous は差し替える前の送信済みの記録。共有を外すのに使う）
 */
export function resendPlan(records, key) {
  const sent = records.filter((record) => record.key === key && record.status === SENT);
  if (sent.length === 0) return null;
  const max = records.filter((record) => record.key === key).reduce((top, record) => Math.max(top, record.version), 1);
  return { version: max + 1, previous: sent };
}

/** 今回送る人と残り。quota は 1 日の残りの宛先数（GAS の層がメールの残り枠を読んで渡す）、reserve は取っておく数 */
export function planBatch(targets, quota, reserve) {
  const room = Math.max(0, Math.floor(Number(quota) || 0) - (reserve || 0));
  return { now: targets.slice(0, room), rest: targets.slice(room) };
}

/** 時間切れか */
export function timeUp(startedMs, nowMs, limitMs) {
  return nowMs - startedMs >= (limitMs === undefined ? TIME_LIMIT_MS : limitMs);
}

/** 打ち切ったときの 1 文 */
export function continueText(restCount, reason) {
  const why = reason === "quota" ? "今日送れるメールの数の上限に近づいたため" : "1 回の実行の時間の上限に近づいたため";
  return why + "、ここで止めました。続きは もう一度「配る」を押してください（残り " + restCount + " 人）。";
}

/** 試し送りで作ったファイルのうち、記録に載っていない（社員に渡していない）もの。作り直すときにゴミ箱へ移す */
export function staleFiles(fileMap, records) {
  const used = {};
  for (let i = 0; i < records.length; i += 1) if (records[i].fileId !== "") used[records[i].fileId] = true;
  const files = fileMap && fileMap.files ? fileMap.files : {};
  return Object.keys(files)
    .map((key) => files[key])
    .filter((id) => id && used[id] !== true);
}

/** 退職者の共有を外す対象: 退職の社員の、共有 ID がある送信済みの記録で、まだ外していないもの */
export function unshareTargets(records, retiredKeys) {
  return records.filter(
    (record) => retiredKeys.indexOf(idKey(record.id)) >= 0 && record.status === SENT && record.permissionId !== "" && record.memo.indexOf("共有を外しました") < 0,
  );
}
