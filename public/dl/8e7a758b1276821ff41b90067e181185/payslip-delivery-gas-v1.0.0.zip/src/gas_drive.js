/**
 * ドライブとドキュメント（GAS）。DriveApp は使わない（ドライブ全体の権限を求めるため）。
 * Advanced Drive（v3）の Drive.* は drive.file（このキットが作ったファイルとフォルダだけ）で動く。
 * 明細は「雛形の複製 → 差し込み → PDF」。複製は PDF にしたらゴミ箱へ移す。
 */
import { TABLE_CATEGORIES } from "./items.js";

export const KIT_FOLDER_NAME = "給与明細 配布キット";
const FOLDER_MIME = "application/vnd.google-apps.folder";
const DOC_MIME = "application/vnd.google-apps.document";
const COMMON = { supportsAllDrives: true };
/** A4（ポイント） */
const A4_WIDTH = 595.28;
const A4_HEIGHT = 841.89;

function props_() {
  return PropertiesService.getDocumentProperties();
}

/** プロパティの JSON。読めなければ fallback */
export function readJson_(name, fallback) {
  const text = props_().getProperty(name);
  if (!text) return fallback;
  try {
    return JSON.parse(text);
  } catch (error) {
    return fallback;
  }
}

export function writeJson_(name, value) {
  props_().setProperty(name, JSON.stringify(value));
}

/** 一時的な失敗の文（Drive・Docs の Internal Error・Backend Error・時間切れ・回数の上限など） */
const TRANSIENT = /internal error|backend error|service error|timed out|time-?out|temporar|try again|rate limit|user rate|too many|unavailable|failed while accessing|\b(429|500|502|503|504)\b/i;

/** 見つからない（消えた・ゴミ箱を空にした）ときの文 */
function notFound_(error) {
  return /not ?found|\b404\b/i.test(String(error && error.message ? error.message : error));
}

/**
 * 一時的な失敗なら、間を空けて 3 回まで繰り返す（1 秒・2 秒）。ほかの失敗はそのまま投げる。
 * 呼び出す側（試し送り・配る）は、止まっても作り終えた分を控えているので、押し直せば続きから動く
 */
// ponytail: 3 回・合わせて 3 秒まで。Drive の障害が長引くときは、押し直してもらう（自動で待ち続けない）
export function retry_(run) {
  for (let attempt = 1; ; attempt += 1) {
    try {
      return run();
    } catch (error) {
      if (attempt >= 3 || !TRANSIENT.test(String(error && error.message ? error.message : error))) throw error;
      Utilities.sleep(1000 * attempt);
    }
  }
}

/**
 * そのファイルがまだ使えるか。見つからない（404）・ゴミ箱のときだけ false。
 * ほかの失敗（権限・一時的な失敗が続いた）は投げる（「無い」とみなして雛形やフォルダを作り直さないように）
 */
function alive_(id) {
  if (!id) return false;
  try {
    const file = retry_(() => Drive.Files.get(id, Object.assign({ fields: "id,trashed" }, COMMON)));
    return Boolean(file) && file.trashed !== true;
  } catch (error) {
    if (notFound_(error)) return false;
    throw error;
  }
}

/** キットのフォルダ。無ければ作る（マイドライブの直下） */
export function kitFolderId_() {
  const saved = props_().getProperty("kitFolderId");
  if (alive_(saved)) return saved;
  const folder = retry_(() => Drive.Files.create({ name: KIT_FOLDER_NAME, mimeType: FOLDER_MIME }));
  props_().setProperty("kitFolderId", folder.id);
  return folder.id;
}

/** 対象月のフォルダ（キットのフォルダ / 2026-10）。無ければ作る */
export function monthFolderId_(monthKey) {
  const map = readJson_("monthFolders", {});
  if (alive_(map[monthKey])) return map[monthKey];
  const parent = kitFolderId_();
  const folder = retry_(() => Drive.Files.create({ name: monthKey, mimeType: FOLDER_MIME, parents: [parent] }));
  map[monthKey] = folder.id;
  writeJson_("monthFolders", map);
  return folder.id;
}

export const TEMPLATE_NAME = "給与明細の雛形";

/**
 * 雛形のドキュメント。無ければ作る。返り値 { id, url, created, folderName, name }。
 * 呼ぶ側はロックの中で呼ぶ（重なって走ると雛形が 2 つできる）。ここでプロパティを読み直してから作る
 */
export function ensureTemplate_() {
  const saved = props_().getProperty("templateId");
  if (alive_(saved)) return { id: saved, url: docUrl_(saved), created: false, folderName: KIT_FOLDER_NAME, name: TEMPLATE_NAME };
  const parent = kitFolderId_();
  const file = retry_(() => Drive.Files.create({ name: TEMPLATE_NAME, mimeType: DOC_MIME, parents: [parent] }));
  writeTemplate_(file.id);
  props_().setProperty("templateId", file.id);
  return { id: file.id, url: docUrl_(file.id), created: true, folderName: KIT_FOLDER_NAME, name: TEMPLATE_NAME };
}

function docUrl_(id) {
  return "https://docs.google.com/document/d/" + id + "/edit";
}

export function fileUrl_(id) {
  return "https://drive.google.com/file/d/" + id + "/view";
}

/** 小さくした空の段落の属性（表と表の間の空き・消せない最後の段落）。1 ページに収めるため */
function smallGap_() {
  const attrs = {};
  attrs[DocumentApp.Attribute.FONT_SIZE] = 4;
  attrs[DocumentApp.Attribute.SPACING_BEFORE] = 0;
  attrs[DocumentApp.Attribute.SPACING_AFTER] = 0;
  attrs[DocumentApp.Attribute.LINE_SPACING] = 1;
  return attrs;
}

/** 段落の前後の間隔を 0 に（見出しの既定の間隔で溢れないように） */
function tight_(paragraph) {
  paragraph.setSpacingBefore(0);
  paragraph.setSpacingAfter(0);
  return paragraph;
}

/**
 * 雛形の中身: 差し込み記号と、勤怠・支給・控除・合計の 4 つの表（各 2 列。2 行目が {{項目}} {{金額}} の行）。
 * 1 ページに収める作り: 余白 40pt、表の字は 10pt・セルの上下の余白 2pt、段落の前後の間隔 0、表と表の間は 4pt の空の段落。
 * 見本の 8 人で項目が一番多い方（4 つの表で 20 行ほど）が 1 ページに収まる。項目がもっと多いと 2 ページ目に続く
 */
function writeTemplate_(id) {
  const doc = retry_(() => DocumentApp.openById(id));
  const body = doc.getBody();
  body.setPageWidth(A4_WIDTH).setPageHeight(A4_HEIGHT).setMarginTop(40).setMarginBottom(40).setMarginLeft(50).setMarginRight(50);
  body.clear();
  // Paragraph.setText は何も返さない（つなげて呼べない）
  const first = body.getParagraphs()[0];
  first.setText("{{会社名}}");
  first.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  tight_(first);
  tight_(body.appendParagraph("{{題}}").setHeading(DocumentApp.ParagraphHeading.HEADING1).setAlignment(DocumentApp.HorizontalAlignment.CENTER));
  tight_(body.appendParagraph("{{対象月}}分　支給日 {{支給日}}").setAlignment(DocumentApp.HorizontalAlignment.CENTER));
  tight_(body.appendParagraph("社員番号 {{社員番号}}　　{{氏名}} 様").setHeading(DocumentApp.ParagraphHeading.HEADING3));
  for (let i = 0; i < TABLE_CATEGORIES.length; i += 1) {
    body.appendParagraph("").setAttributes(smallGap_());
    const category = TABLE_CATEGORIES[i];
    const table = body.appendTable([
      [category, category === "勤怠" ? "日数・時間" : "金額（円）"],
      ["{{項目}}", "{{金額}}"],
    ]);
    table.setBorderWidth(1).setBorderColor("#555555");
    table.editAsText().setFontSize(10);
    table.getRow(0).editAsText().setBold(true);
    for (let r = 0; r < 2; r += 1) {
      for (let c = 0; c < 2; c += 1) {
        const cell = table.getRow(r).getCell(c);
        cell.setPaddingTop(2);
        cell.setPaddingBottom(2);
        if (r === 0) cell.setBackgroundColor("#eeeeee");
      }
      table.getRow(r).getCell(1).getChild(0).asParagraph().setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
    }
  }
  body.appendParagraph("").setAttributes(smallGap_());
  tight_(body.appendParagraph("{{備考}}"));
  doc.saveAndClose();
}

/**
 * 差し込んだあとの片づけ: {{備考}} が空なら、その段落を消す。文書の末尾の空の段落も消す。
 * 最後の段落は消せない（Docs の決まり）ので、小さくして残す
 */
function trimTail_(body) {
  for (let i = body.getNumChildren() - 1; i >= 0; i -= 1) {
    const child = body.getChild(i);
    if (child.getType() !== DocumentApp.ElementType.PARAGRAPH) break;
    const paragraph = child.asParagraph();
    if (paragraph.getText().trim() !== "") break;
    if (i === body.getNumChildren() - 1) {
      try {
        paragraph.removeFromParent();
      } catch (error) {
        paragraph.setAttributes(smallGap_());
        continue;
      }
    } else {
      paragraph.removeFromParent();
    }
  }
}

/** 正規表現で使う字を逃がす */
function pattern_(name) {
  return "\\{\\{" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\}\\}";
}

/**
 * 表がどの区分か: 1 行目の左のセルの字。まず完全に一致する字、無ければ含む字を 合計 → 控除 → 支給 → 勤怠 の順で
 * （「合計（差引支給額）」を支給の表と取り違えないように）。見分けられなければ並び順
 */
function tableCategory_(table, index) {
  const head = table.getNumRows() > 0 ? table.getRow(0).getCell(0).getText().trim() : "";
  if (TABLE_CATEGORIES.indexOf(head) >= 0) return head;
  const order = ["合計", "控除", "支給", "勤怠"];
  for (let i = 0; i < order.length; i += 1) if (head.indexOf(order[i]) >= 0) return order[i];
  return TABLE_CATEGORIES[index] || "";
}

/** 複製したドキュメントに差し込む。表は {{項目}} の行を項目の数だけ複製する */
function fillDocument_(id, data) {
  const doc = retry_(() => DocumentApp.openById(id));
  const body = doc.getBody();
  const tables = body.getTables();
  for (let t = 0; t < tables.length; t += 1) {
    const table = tables[t];
    let at = -1;
    for (let r = 0; r < table.getNumRows(); r += 1) if (table.getRow(r).getText().indexOf("{{項目}}") >= 0) at = r;
    if (at < 0) continue;
    const rows = data.tables[tableCategory_(table, t)] || [];
    const template = table.getRow(at);
    if (rows.length === 0) {
      template.replaceText(pattern_("項目"), "なし");
      template.replaceText(pattern_("金額"), "");
      continue;
    }
    for (let k = 0; k < rows.length; k += 1) {
      const row = table.insertTableRow(at + 1 + k, template.copy());
      row.replaceText(pattern_("項目"), rows[k].label);
      row.replaceText(pattern_("金額"), rows[k].value);
    }
    table.removeRow(at);
  }
  const sections = [body, doc.getHeader(), doc.getFooter()].filter((section) => section);
  const names = Object.keys(data.fields);
  for (let s = 0; s < sections.length; s += 1) {
    for (let i = 0; i < names.length; i += 1) sections[s].replaceText(pattern_(names[i]), String(data.fields[names[i]]));
  }
  trimTail_(body);
  doc.saveAndClose();
}

/** 明細 1 人分の PDF（Blob）。雛形を対象月のフォルダに複製 → 差し込み → PDF → 複製をゴミ箱へ */
export function makePdf_(templateId, folderId, data, fileName) {
  const copy = retry_(() => Drive.Files.copy({ name: "作業中_" + fileName, parents: [folderId] }, templateId, Object.assign({ fields: "id" }, COMMON)));
  try {
    fillDocument_(copy.id, data);
    return retry_(() => DocumentApp.openById(copy.id).getAs("application/pdf")).setName(fileName);
  } finally {
    trash_(copy.id);
  }
}

/** PDF をフォルダに置く。返り値はファイル ID */
export function savePdf_(blob, folderId) {
  const file = retry_(() => Drive.Files.create({ name: blob.getName(), mimeType: "application/pdf", parents: [folderId] }, blob, Object.assign({ fields: "id" }, COMMON)));
  return file.id;
}

/** ゴミ箱へ（消しはしない。30 日はドライブのゴミ箱から戻せる） */
export function trash_(id) {
  try {
    retry_(() => Drive.Files.update({ trashed: true }, id, null, COMMON));
  } catch (error) {
    Logger.log("ゴミ箱へ移せませんでした: " + id + " " + error);
  }
}

/** ファイル単位で閲覧者に足す。Google の通知メールは止める（知らせはキットが送る）。返り値は共有 ID */
export function share_(fileId, email) {
  const permission = retry_(() =>
    Drive.Permissions.create({ role: "reader", type: "user", emailAddress: email }, fileId, Object.assign({ sendNotificationEmail: false, fields: "id" }, COMMON)),
  );
  return permission.id;
}

/** 共有を外す。すでに無い（404）ときは外れたものとみなす */
export function unshare_(fileId, permissionId) {
  try {
    retry_(() => Drive.Permissions.remove(fileId, permissionId, COMMON));
  } catch (error) {
    if (!notFound_(error)) throw error;
  }
}

/**
 * このスプレッドシートの一般的なアクセス。"anyone"（リンクを知っている全員・組織内の全員）/ "restricted" / "unknown"。
 * drive.file の権限では読めないことがあり、そのときは "unknown"（確かめるが目での確認をお願いする）
 */
export function sharingStatus_(spreadsheetId) {
  try {
    const list = retry_(() => Drive.Permissions.list(spreadsheetId, Object.assign({ fields: "permissions(type)" }, COMMON)));
    const permissions = (list && list.permissions) || [];
    return permissions.some((p) => p.type === "anyone" || p.type === "domain") ? "anyone" : "restricted";
  } catch (error) {
    return "unknown";
  }
}
