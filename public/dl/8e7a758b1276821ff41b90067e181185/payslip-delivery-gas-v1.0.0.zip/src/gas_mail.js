/** メール（GAS）。送るのは MailApp だけ（Gmail の受信箱は読まない）。 */

/** 1 通送る。attachments は Blob の配列（空なら付けない） */
export function sendMail_(to, mail, senderName, attachments) {
  const message = { to: to, subject: mail.subject, body: mail.body, name: senderName };
  if (attachments && attachments.length > 0) message.attachments = attachments;
  MailApp.sendEmail(message);
}

/** 今日あと何人に送れるか（無料の Google アカウントは 1 日 100、Workspace は 1,500 ほど） */
export function remainingQuota_() {
  return MailApp.getRemainingDailyQuota();
}

/** 実行している方のアドレス（試し送りの宛先）。読めなければ止める */
export function myAddress_() {
  const email = Session.getEffectiveUser().getEmail();
  if (!email) throw new Error("実行しているアカウントのアドレスを読めませんでした。スプレッドシートの持ち主のアカウントで開き直してください。");
  return email;
}
