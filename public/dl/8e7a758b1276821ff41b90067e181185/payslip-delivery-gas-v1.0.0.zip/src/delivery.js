/** 渡し方の決定（純粋）: 同意・在籍・社員シートの「渡し方」から、共有／添付／紙／送らない を決める。 */
import { employeesByKey, METHOD_ATTACH, METHOD_SHARE } from "./employees.js";
import { isDone, keyOf } from "./ledger.js";
import { fingerprint } from "./text.js";

export const METHOD_PAPER = "紙";
export const METHOD_NONE = "送らない";
export const SWITCHED_MEMO = "添付に切替";

/**
 * 1 人の渡し方。employee が無い・退職は「送らない」、同意が無ければ「紙」（紙で渡す人）、ほかは社員シートの渡し方。
 * 返り値 { method, reason }
 */
export function decideDelivery(employee) {
  if (!employee) return { method: METHOD_NONE, reason: "社員シートにありません" };
  if (!employee.active) return { method: METHOD_NONE, reason: "退職" };
  if (!employee.consent) return { method: METHOD_PAPER, reason: "電子交付の同意日が空です" };
  return { method: employee.method === METHOD_ATTACH ? METHOD_ATTACH : METHOD_SHARE, reason: "" };
}

/** 共有に失敗したとき（Google アカウントの無いアドレスなど）は添付に切り替える。記録のメモに残す字 */
export function afterShareFailure(error) {
  const message = String(error && error.message ? error.message : error).slice(0, 120);
  return { method: METHOD_ATTACH, memo: SWITCHED_MEMO + "（共有できませんでした: " + message + "）" };
}

/**
 * 明細の全員を、送る人・紙で渡す人・送らない人・送った人に分ける。
 * targets: [{ person, employee, method, key }]（明細の上からの順）
 */
export function planDelivery(people, employees, records, config) {
  const byKey = employeesByKey(employees);
  const plan = { targets: [], paper: [], skipped: [], alreadySent: [] };
  const monthKey = config.month ? config.month.key : "";
  for (let i = 0; i < people.length; i += 1) {
    const person = people[i];
    const employee = byKey[person.key];
    const key = keyOf(monthKey, person.id, config.title);
    const decision = decideDelivery(employee);
    const name = person.name || (employee ? employee.name : "");
    if (decision.method === METHOD_NONE) plan.skipped.push({ person: person, name: name, reason: decision.reason });
    else if (decision.method === METHOD_PAPER) plan.paper.push({ person: person, name: name });
    else if (isDone(records, key)) plan.alreadySent.push({ person: person, name: name });
    else plan.targets.push({ person: person, employee: employee, method: decision.method, key: key, name: name });
  }
  return plan;
}

/** 試し送りが要るときの 1 文 */
export const TRIAL_REQUIRED_TEXT =
  "この月の試し送りが済んでいません（試し送りのあとで、明細・項目・社員・設定のどれかが変わったときも同じです）。先に「試し送り」を押して、届いた PDF と宛先をご確認ください。";

/**
 * 試し送りのあとで変わったかを見分ける指紋。PDF と宛先・文面に効くものだけを入れる
 * （明細の値、項目の区分・表示名・並び順、社員の宛先・渡し方・同意・在籍、設定の差し込みと文面）
 */
export function deliveryFingerprint(detailRows, items, employees, config) {
  return fingerprint([
    detailRows,
    items.map((item) => [item.header, item.category, item.order, item.label]),
    employees.map((e) => [e.key, e.name, e.email, e.method, e.consent, e.active]),
    [config.company, config.title, config.month ? config.month.key : "", config.payday, config.note, config.showZero, config.senderName, config.subject, config.body],
  ]);
}
