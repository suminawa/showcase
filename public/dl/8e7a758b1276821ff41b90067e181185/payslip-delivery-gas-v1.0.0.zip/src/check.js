/**
 * 「確かめる」の 11 項目（純粋）。1 つでも「要確認」があれば、試し送りも配るもできない。
 * 「お知らせ」は止めない（紙で渡す人・送った人など、知っておいてほしいこと）。
 */
import { parseAmount } from "./amount.js";
import { isFree } from "./edition.js";
import { CONSENT_HEADER, employeesByKey, EMPLOYEES_TAB, isEmail, mailKey, METHOD_ATTACH, METHOD_SHARE } from "./employees.js";
import { DETAIL_TAB } from "./importer.js";
import { CATEGORIES, ITEMS_TAB } from "./items.js";
import { LEDGER_TAB, SENT, sentRecords, stuckRecords } from "./ledger.js";
import { SETTINGS_TAB } from "./config.js";
import { cellText } from "./text.js";

export const CHECK_TAB = "確かめる";
export const CHECK_HEADERS = ["項目", "件数", "状態", "直し方・名前"];
export const OK = "OK";
export const NEEDS = "要確認";
export const INFO = "お知らせ";

/** セル 1 つに収まるよう、10 件を超えたら「ほか N 件」にする */
export function delimit(names, max) {
  const limit = max === undefined ? 10 : max;
  return names.slice(0, limit).join("、") + (names.length > limit ? " ほか " + (names.length - limit) + " 件" : "");
}

/** 氏名を比べる形: NFKC でそろえ、空白を落とす */
function nameKey(name) {
  return cellText(name).replace(/\s/g, "");
}

/** 社員番号の鍵が 2 回以上出てくるものの、最初の書き方の一覧 */
function duplicatedIds(list) {
  const seen = {};
  const dup = [];
  for (let i = 0; i < list.length; i += 1) {
    if (seen[list[i].key] && dup.indexOf(seen[list[i].key]) < 0) dup.push(seen[list[i].key]);
    if (!seen[list[i].key]) seen[list[i].key] = list[i].id;
  }
  return dup;
}

function result(no, label, count, status, fix) {
  return { no: no, label: label, count: count, status: status, fix: fix || "" };
}

function nameOf(person, byKey) {
  const employee = byKey[person.key];
  return person.id + " " + (person.name || (employee ? employee.name : ""));
}

/** 11 項目を順に確かめる。返り値は [{ no, label, count, status, fix }] */
export function runChecks(snapshot) {
  const config = snapshot.config;
  const people = snapshot.detail.people;
  const employees = snapshot.employees;
  const byKey = employeesByKey(employees);
  const inDetail = {};
  for (let i = 0; i < people.length; i += 1) inDetail[people[i].key] = true;
  const results = [];

  // 1. 明細の社員番号が社員シートにあり、氏名が合う（番号の打ち違いで別の人のアドレスに送らないように）
  const label1 = "明細の社員番号が社員シートにあり、氏名が合う";
  const missing = people.filter((person) => byKey[person.key] === undefined);
  const mismatch = people.filter((person) => {
    const employee = byKey[person.key];
    if (!employee) return false;
    const a = nameKey(person.name);
    const b = nameKey(employee.name);
    return a !== "" && b !== "" && a !== b;
  });
  if (people.length === 0) {
    results.push(result(1, label1, 0, NEEDS, "「" + DETAIL_TAB + "」が空です。「貼り付け」シートの A1 に一覧を貼り、「取り込む」を押してください"));
  } else {
    const fixes1 = [];
    if (missing.length > 0) fixes1.push("「" + EMPLOYEES_TAB + "」シートに足してください: " + delimit(missing.map((p) => nameOf(p, byKey))));
    if (mismatch.length > 0) {
      fixes1.push("氏名が違います。社員番号の打ち違いでないかを確かめ、「" + EMPLOYEES_TAB + "」シートを直してください: " +
        delimit(mismatch.map((p) => p.id + ": 明細は" + p.name + "、社員シートは" + byKey[p.key].name)));
    }
    results.push(result(1, label1, missing.length + mismatch.length, fixes1.length === 0 ? OK : NEEDS, fixes1.join(" / ")));
  }

  // 2. 明細にいる人のメールが空でない・形が正しい（渡し方の字も）
  const badMail = employees.filter((e) => inDetail[e.key] && e.active && e.consent && !isEmail(e.email));
  const badMethod = employees.filter((e) => inDetail[e.key] && e.methodRaw !== "" && e.methodRaw !== METHOD_SHARE && e.methodRaw !== METHOD_ATTACH);
  const fixes2 = [];
  if (badMail.length > 0) fixes2.push("メールが空か、形が違います（" + EMPLOYEES_TAB + "シート）: " + delimit(badMail.map((e) => e.row + " 行目 " + e.name)));
  if (badMethod.length > 0) fixes2.push("「渡し方」は「共有」か「添付」で書いてください: " + delimit(badMethod.map((e) => e.row + " 行目 " + e.name)));
  results.push(result(2, "社員シートのメールが空でない・形が正しい", badMail.length + badMethod.length, fixes2.length === 0 ? OK : NEEDS, fixes2.join(" / ")));

  // 3. 同じメールが 2 人以上にない（漏えいに直結）。taro+pay@ と taro@、Gmail の点の違いも同じ受信箱とみなす
  const byMail = {};
  for (let i = 0; i < employees.length; i += 1) {
    const mail = mailKey(employees[i].email);
    if (mail === "") continue;
    (byMail[mail] = byMail[mail] || []).push(employees[i]);
  }
  const shared = Object.keys(byMail).filter((mail) => byMail[mail].length > 1);
  results.push(result(3, "同じメールが 2 人以上にない", shared.length, shared.length === 0 ? OK : NEEDS,
    shared.length === 0 ? "" : "1 人 1 つのアドレスにしてください。ほかの人の明細が届きます: " +
      delimit(shared.map((mail) => byMail[mail].map((e) => e.name + " " + e.email).join("・")))));

  // 4. 同じ社員番号が明細にも社員シートにも 2 行ない（0123 と 123 も同じ番号とみなす）
  const dup = duplicatedIds(people);
  const dupEmployees = duplicatedIds(employees);
  const fixes4 = [];
  if (dup.length > 0) fixes4.push("貼り付けた一覧で、同じ社員番号の行を 1 つにしてください: " + delimit(dup));
  if (dupEmployees.length > 0) fixes4.push("「" + EMPLOYEES_TAB + "」シートに同じ社員番号が 2 行以上あります。打ち違いを直してください: " + delimit(dupEmployees));
  results.push(result(4, "同じ社員番号が明細・社員シートに 2 行ない", dup.length + dupEmployees.length, fixes4.length === 0 ? OK : NEEDS, fixes4.join(" / ")));

  // 5. 合計の区分の列が 1 つ以上ある・空・負の人がいない
  const used = snapshot.items.filter((item) => snapshot.detail.headers.indexOf(item.header) >= 0);
  const totals = used.filter((item) => item.category === "合計");
  if (totals.length === 0) {
    results.push(result(5, "合計（差引支給額）が空・マイナスの人がいない", 0, NEEDS, "「" + ITEMS_TAB + "」シートで、差引支給額の見出しの区分を「合計」にしてください"));
  } else {
    const bad = people.filter((person) => totals.some((item) => {
      const amount = parseAmount(person.values[item.header]);
      return amount === null || Number.isNaN(amount) || amount < 0;
    }));
    results.push(result(5, "合計（差引支給額）が空・マイナスの人がいない", bad.length, bad.length === 0 ? OK : NEEDS,
      bad.length === 0 ? "" : "合計の列（" + totals.map((t) => t.header).join("・") + "）が空かマイナスです。貼り付けた一覧をご確認ください: " + delimit(bad.map((p) => nameOf(p, byKey)))));
  }

  // 6. 項目シートで区分が空・書き間違いの見出しがない
  const noCategory = used.filter((item) => CATEGORIES.indexOf(item.category) < 0);
  results.push(result(6, "項目シートで区分が空の見出しがない", noCategory.length, noCategory.length === 0 ? OK : NEEDS,
    noCategory.length === 0 ? "" : "「" + ITEMS_TAB + "」シートで区分（" + CATEGORIES.join("／") + "）を選び、もう一度「取り込む」を押してください: " + delimit(noCategory.map((i) => i.header))));

  // 7. 対象月・題・支給日が設定にあり、明細を取り込んだときの対象月と合う（取り込み忘れで先月の金額を送らないように）
  const lacks = [];
  if (!config.month) lacks.push(config.monthRaw ? "対象月（「" + config.monthRaw + "」は読めません。2026-10 の形で）" : "対象月");
  if (config.title === "") lacks.push("題");
  if (config.payday === "") lacks.push("支給日");
  const fixes7 = lacks.length === 0 ? [] : ["「" + SETTINGS_TAB + "」シートに書いてください: " + lacks.join("、")];
  if (config.month && people.length > 0 && snapshot.importedMonth !== config.month.key) {
    fixes7.push(snapshot.importedMonth
      ? "明細は対象月が " + snapshot.importedMonth + " のときに取り込んだものです。" + config.month.label + "分の一覧を「貼り付け」に貼って「取り込む」を押してください"
      : "明細がいつの月のものか分かりません。" + config.month.label + "分の一覧を「貼り付け」に貼って「取り込む」を押してください");
  }
  const problems = fixes7.concat(config.problems || []);
  results.push(result(7, "対象月・題・支給日が設定にあり、明細の対象月と合う", problems.length, problems.length === 0 ? OK : NEEDS, problems.join(" / ")));

  // 8. 同意日が空の人（エラーではなく「紙で渡す人」）
  if (isFree(snapshot.edition)) {
    results.push(result(8, "電子交付の同意日が空の人（紙で渡す人）", 0, OK, "無料版には同意の管理がありません（有料版の機能です）"));
  } else {
    const paper = employees.filter((e) => inDetail[e.key] && e.active && !e.consent);
    results.push(result(8, "電子交付の同意日が空の人（紙で渡す人）", paper.length, paper.length === 0 ? OK : INFO,
      paper.length === 0 ? "" : "この方には送りません。PDF を印刷してお渡しください。同意をいただいたら「" + CONSENT_HEADER + "」に日付を書きます: " + delimit(paper.map((e) => e.name))));
  }

  // 9. 退職の人が明細にいる（要確認）
  const retired = employees.filter((e) => inDetail[e.key] && !e.active);
  results.push(result(9, "退職の人が明細にいない", retired.length, retired.length === 0 ? OK : NEEDS,
    retired.length === 0 ? "" : "退職の方には送りません。最後の給与を渡すときは、配り終えてから「在籍」を「退職」に直してください。渡さないときは明細から行を消してください: " + delimit(retired.map((e) => e.name))));

  // 10. すでに送った人（送らない人）、送信中のまま残った行、同じ月に別の題で送った記録
  const monthKey = config.month ? config.month.key : "";
  const stuck = stuckRecords(snapshot.records, monthKey, config.title);
  const sent = sentRecords(snapshot.records, monthKey, config.title);
  const otherTitles = [];
  for (let i = 0; i < snapshot.records.length; i += 1) {
    const record = snapshot.records[i];
    if (record.month === monthKey && record.title !== config.title && record.status === SENT && otherTitles.indexOf(record.title) < 0) otherTitles.push(record.title);
  }
  const fixes10 = [];
  if (stuck.length > 0) {
    fixes10.push("「" + LEDGER_TAB + "」に「送信中」のまま残った行があります（途中で止まった印）。Gmail の「送信済み」にその方あてのメールがあれば届いています。届いていれば状態を「送信済み」に、届いていなければその行を消してください: " +
      delimit(stuck.map((r) => r.row + " 行目 " + r.name)));
  }
  if (otherTitles.length > 0 && !config.allowOtherTitle) {
    fixes10.push(monthKey + " は「" + otherTitles.join("」「") + "」の題で送っています。題を書き換えると、同じ方にもう一度送ります。同じ明細なら設定の題を元に戻してください。賞与など別の明細を送るときは、「" + SETTINGS_TAB + "」の「同じ月の別の題を送る」を「する」にしてください");
  }
  const names = [];
  for (let i = 0; i < sent.length; i += 1) if (names.indexOf(sent[i].name) < 0) names.push(sent[i].name);
  if (fixes10.length > 0) {
    results.push(result(10, "すでに送った人（今回は送らない人）", stuck.length + otherTitles.length, NEEDS, fixes10.join(" / ")));
  } else {
    results.push(result(10, "すでに送った人（今回は送らない人）", names.length, names.length === 0 ? OK : INFO,
      names.length === 0 ? "" : "この方には送りません。送り直すときはメニューの「送り直す」を使います: " + delimit(names)));
  }

  // 11. スプレッドシートが「リンクを知っている全員」に共有されていない。自動で読めないときは、目で確かめた日が設定に要る
  const label11 = "このスプレッドシートが「リンクを知っている全員」に共有されていない";
  if (snapshot.sharing === "anyone") {
    results.push(result(11, label11, 1, NEEDS, "このシートには全員の給与が入っています。右上の「共有」で一般的なアクセスを「制限付き」にしてください"));
  } else if (snapshot.sharing === "restricted") {
    results.push(result(11, label11, 0, OK, ""));
  } else if (config.sharingCheckedOn !== "") {
    results.push(result(11, label11, 0, OK, "自動では確かめられないため、目で確かめた日（" + config.sharingCheckedOn + "）で通しています。共有を変えたら、もう一度確かめてください"));
  } else {
    results.push(result(11, label11, 1, NEEDS,
      "自動では確かめられませんでした。右上の「共有」で、一般的なアクセスが「制限付き」になっているかを確かめ、「" + SETTINGS_TAB + "」の「共有範囲を確かめた日」に今日の日付を書いてください"));
  }
  return results;
}

/** 要確認が 1 つでもあるか */
export function isBlocked(results) {
  return results.some((entry) => entry.status === NEEDS);
}

/** 確かめるシートに書く行 */
export function checkSheetRows(results) {
  return [CHECK_HEADERS].concat(results.map((entry) => [entry.no + ". " + entry.label, entry.count, entry.status, entry.fix]));
}

/** 確かめた結果の短い 1 通（画面に出す） */
export function checkSummary(results) {
  const needs = results.filter((entry) => entry.status === NEEDS);
  const infos = results.filter((entry) => entry.status === INFO);
  if (needs.length === 0) {
    const lines = ["11 項目を確かめました。要確認はありません。"];
    if (infos.length > 0) lines.push("", "お知らせ:", ...infos.map((entry) => "・" + entry.label + "（" + entry.count + " 件）"));
    lines.push("", "次は「試し送り」で、自分あてに PDF を受け取って確かめてください。");
    return lines.join("\n");
  }
  return ["要確認が " + needs.length + " 項目あります。直すまで、試し送りと配るはできません。", ""]
    .concat(needs.map((entry) => "・" + entry.no + ". " + entry.label))
    .concat(["", "「" + CHECK_TAB + "」シートに直し方を書きました。直したら、もう一度「確かめる」を押してください。"])
    .join("\n");
}
