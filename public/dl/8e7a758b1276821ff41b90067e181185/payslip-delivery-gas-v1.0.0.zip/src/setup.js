/** 初期化（純粋）: 足りないシート・見出し・設定の行だけを足す。すでにあるデータには触らない。 */
import { CHECK_TAB } from "./check.js";
import { DEFAULT_ROWS, SETTINGS_TAB, settingKey } from "./config.js";
import { employeeHeaders, EMPLOYEES_TAB } from "./employees.js";
import { DETAIL_TAB, PASTE_TAB } from "./importer.js";
import { ITEM_HEADERS, ITEMS_TAB } from "./items.js";
import { LEDGER_HEADERS, LEDGER_TAB } from "./ledger.js";
import { normalizeHeader } from "./text.js";

export const MENU_NAME = "給与明細";
export const INIT_MENU_LABEL = "初期化（足りないシート・見出し・雛形を足す。データは消しません）";

/** 初期化で作るシートと、その 1 行目。null は見出しを持たないシート */
export function sheetSpecs(edition) {
  return [
    [SETTINGS_TAB, ["項目", "値"]],
    [EMPLOYEES_TAB, employeeHeaders(edition)],
    [ITEMS_TAB, ITEM_HEADERS],
    [PASTE_TAB, null],
    [DETAIL_TAB, null],
    [CHECK_TAB, null],
    [LEDGER_TAB, LEDGER_HEADERS],
  ];
}

/**
 * sheets: { シート名: 値の 2 次元配列 }（無いシートは載せない）。
 * 返り値 { create: [{ name, rows }], appendHeaders: [{ sheet, names }], appendSettings: [[項目, 値]] }
 */
export function planInit(sheets, edition) {
  const plan = { create: [], appendHeaders: [], appendSettings: [] };
  const specs = sheetSpecs(edition);
  for (let i = 0; i < specs.length; i += 1) {
    const name = specs[i][0];
    const header = specs[i][1];
    const values = sheets[name];
    const empty = !values || values.length === 0 || values.every((row) => row.every((cell) => String(cell) === ""));
    if (values && !header) continue; // 見出しを持たないシート（貼り付け・明細・確かめる）は、あれば足すものは無い
    if (!values || empty) {
      let rows = header ? [header] : [];
      if (name === SETTINGS_TAB) rows = rows.concat(DEFAULT_ROWS);
      plan.create.push({ name: name, rows: rows, exists: Boolean(values) });
      continue;
    }
    if (header && name !== SETTINGS_TAB) {
      const have = values[0].map(normalizeHeader);
      const missing = header.filter((h) => have.indexOf(h) < 0);
      if (missing.length > 0) plan.appendHeaders.push({ sheet: name, names: missing });
    }
    if (name === SETTINGS_TAB) {
      const keys = values.map((row) => settingKey(row[0]));
      plan.appendSettings = DEFAULT_ROWS.filter((row) => keys.indexOf(settingKey(row[0])) < 0);
    }
  }
  return plan;
}

/** 初期化の結果の 1 通。雛形は URL ではなく、フォルダと名前で案内する（画面の横にはみ出さないように） */
export function initReport(plan, template) {
  const lines = [];
  const made = plan.create.filter((entry) => !entry.exists).map((entry) => entry.name);
  const filled = plan.create.filter((entry) => entry.exists).map((entry) => entry.name);
  if (made.length > 0) lines.push("・シートを作りました: " + made.join("、"));
  if (filled.length > 0) lines.push("・空だったシートに見出しを書きました: " + filled.join("、"));
  for (let i = 0; i < plan.appendHeaders.length; i += 1) {
    lines.push("・「" + plan.appendHeaders[i].sheet + "」シートの見出しに足しました: " + plan.appendHeaders[i].names.join("、"));
  }
  if (plan.appendSettings.length > 0) lines.push("・「" + SETTINGS_TAB + "」シートに足しました: " + plan.appendSettings.map((row) => row[0]).join("、"));
  if (template && template.created) lines.push("・明細の雛形（ドキュメント）を、ドライブの「" + template.folderName + "」フォルダに作りました");
  const head = lines.length === 0 ? "変更はありません。シート・見出し・設定・雛形はそろっています。" : "初期化しました（すでにあったデータは変えていません）。\n\n" + lines.join("\n");
  const tail = [
    "",
    "雛形: " + (template ? "ドライブの「" + template.folderName + "」フォルダの「" + (template.name || "給与明細の雛形") + "」" : "（作れませんでした）"),
    "",
    "次は「" + SETTINGS_TAB + "」に会社名・対象月・支給日を、「" + EMPLOYEES_TAB + "」に社員を書き、「" + PASTE_TAB + "」の A1 に一覧を貼って「取り込む」を押してください。",
  ];
  return head + "\n" + tail.join("\n");
}
