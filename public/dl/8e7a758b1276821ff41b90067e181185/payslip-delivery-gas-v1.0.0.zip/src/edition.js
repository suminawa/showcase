/**
 * 有料版と無料版の違い（純粋）。scripts/build.mjs が dist-free/ を作るときに、この 1 行を "free" に書き換える。
 * 無料版: 社員 3 人まで・試し送りまで（配る・送り直す・退職者の共有を外すは止める）・電子交付の同意の列なし。
 */
export const EDITION = "paid";

/** 無料版で取り込める人数 */
export const FREE_EMPLOYEE_LIMIT = 3;

/** 無料版で止める操作に出す 1 文 */
export const PAID_ONLY_TEXT = "この操作は有料版で使えます。無料版は、社員 3 人までの取り込み・確かめる・試し送り（自分あて）までです。";

export function isFree(edition) {
  return edition === "free";
}

/** 社員本人に渡す操作（配る・送り直す・退職者の共有を外す）が使えるか */
export function canDeliver(edition) {
  return !isFree(edition);
}

/** 無料版は明細を先頭の 3 人に切る。返り値は { rows, cut }（cut は切った人数） */
export function limitPeople(rows, edition) {
  const list = Array.isArray(rows) ? rows : [];
  if (!isFree(edition) || list.length <= FREE_EMPLOYEE_LIMIT) return { rows: list, cut: 0 };
  return { rows: list.slice(0, FREE_EMPLOYEE_LIMIT), cut: list.length - FREE_EMPLOYEE_LIMIT };
}
