/**
 * 入口（GAS）。メニュー「給与明細」の各項目と、続きを送る 1 回きりのトリガーが呼ぶ。
 * 送る操作（試し送り・配る・送り直す・退職者の共有を外す）は LockService で 1 本ずつ走らせる。
 */
import { checkSummary, isBlocked, runChecks } from "./check.js";
import { parseConfig, SETTINGS_TAB } from "./config.js";
import { afterShareFailure, decideDelivery, deliveryFingerprint, METHOD_NONE, planDelivery, TRIAL_REQUIRED_TEXT } from "./delivery.js";
import { canDeliver, EDITION, isFree, limitPeople, PAID_ONLY_TEXT } from "./edition.js";
import { employeesByKey, EMPLOYEES_TAB, METHOD_ATTACH, METHOD_SHARE, parseEmployees } from "./employees.js";
import { buildDetailRows, DETAIL_TAB, importReport, parseDetail, readPaste } from "./importer.js";
import { ITEMS_TAB, mergeItems, parseItems, sortItems } from "./items.js";
import { continueText, FAILED, keyOf, LEDGER_TAB, parseLedger, planBatch, resendPlan, SENDING, SENT, staleFiles, timeUp, unshareTargets } from "./ledger.js";
import { buildMail, buildTrialMail, payslipData, pdfFileName } from "./message.js";
import { idKey } from "./text.js";
import { initReport, INIT_MENU_LABEL, MENU_NAME, planInit } from "./setup.js";
import { ensureTemplate_, fileUrl_, makePdf_, monthFolderId_, readJson_, savePdf_, share_, sharingStatus_, trash_, unshare_, writeJson_ } from "./gas_drive.js";
import { myAddress_, remainingQuota_, sendMail_ } from "./gas_mail.js";
import { appendItems_, appendLedger_, applyInit_, readInitSnapshot_, readPasteValues_, requiredValues_, updateLedger_, writeChecks_, writeDetail_ } from "./gas_sheets.js";

/** キットの版。package.json と同じ値にする（docs.test.mjs が照合） */
const KIT_VERSION = "1.0.0";
/** 続きを送るトリガーの関数名 */
const CONTINUE_HANDLER = "continueDelivery";

/** シートを開いたときにメニューを足す。dist/Code.gs の最初の関数（エディタで実行するとメニューが出る） */
export function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu(MENU_NAME)
    .addItem(INIT_MENU_LABEL, "initializeKit")
    .addSeparator()
    .addItem("取り込む（貼り付け → 明細）", "importPayroll")
    .addItem("確かめる", "checkBeforeSend")
    .addItem("試し送り（自分あてに 1 通）", "sendTrial")
    .addItem("配る", "deliverPayslips")
    .addSeparator()
    .addItem("送り直す（社員番号を指定）", "resendPayslip")
    .addItem("退職者の共有を外す", "unshareRetired")
    .addToUi();
}

function ui_() {
  return SpreadsheetApp.getUi();
}

function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

/** ロックを取って走らせる。取れなければ、ほかの操作が終わるのを待ってもらう */
function withLock_(run) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return "ほかの操作（配る・試し送りなど）が動いています。終わってから、もう一度押してください。";
  try {
    return run();
  } finally {
    lock.releaseLock();
  }
}

/** メニューから呼ぶ操作の共通の形: 返ってきた文を画面に出す。失敗も画面に出す */
function runFromMenu_(run) {
  try {
    const text = run();
    if (text) ui_().alert(text);
  } catch (error) {
    ui_().alert(failureText_(error));
  }
}

/** 足りないシート・見出し・設定の行・雛形だけを足す。何度押してもデータは消さない */
export function initializeKit() {
  // 許可の画面の前後で重なって走ると、雛形が 2 つできる。ロックの中で、プロパティを読み直してから作る
  runFromMenu_(() => withLock_(() => {
    const plan = planInit(readInitSnapshot_(EDITION), EDITION);
    applyInit_(plan);
    const template = ensureTemplate_();
    return "給与明細 配布キット v" + KIT_VERSION + (isFree(EDITION) ? "（無料版）" : "") + "\n\n" + initReport(plan, template);
  }));
}

/** 貼り付けシートの一覧を、1 人 1 行の明細に整える。項目シートに新しい見出しを足す */
export function importPayroll() {
  runFromMenu_(() => {
    const config = parseConfig(requiredValues_(SETTINGS_TAB));
    const paste = readPaste(readPasteValues_(), config.headerRows);
    if (!paste.ok) return paste.problem;
    const limited = limitPeople(paste.people, EDITION);
    const names = paste.headers.map((header) => header.name);
    const merged = mergeItems(parseItems(requiredValues_(ITEMS_TAB)), names);
    appendItems_(merged.added);
    const items = merged.items.filter((item) => names.indexOf(item.header) >= 0);
    const namesById = {};
    const employees = parseEmployees(requiredValues_(EMPLOYEES_TAB), EDITION);
    for (let i = 0; i < employees.length; i += 1) namesById[employees[i].key] = employees[i].name;
    const built = buildDetailRows(limited.rows, items, namesById);
    writeDetail_(built.rows, items);
    // 取り込んだときの対象月を残す（確かめるが、設定の対象月と違えば止める）
    writeJson_("importedMonth", config.month ? config.month.key : "");
    return importReport({
      people: limited.rows.length, totals: paste.dropped.totals, noId: paste.dropped.noId, added: merged.added, badCells: built.badCells, cut: limited.cut,
    });
  });
}

/** 送る前に読むもの一式と、確かめるの結果 */
function loadContext_() {
  const config = parseConfig(requiredValues_(SETTINGS_TAB));
  const detailRows = requiredValues_(DETAIL_TAB);
  const detail = parseDetail(detailRows);
  // 無料版は、明細シートに直接足した行も 3 人で切る
  detail.people = limitPeople(detail.people, EDITION).rows;
  const items = sortItems(parseItems(requiredValues_(ITEMS_TAB)));
  const employees = parseEmployees(requiredValues_(EMPLOYEES_TAB), EDITION);
  const records = parseLedger(requiredValues_(LEDGER_TAB));
  const sharing = sharingStatus_(SpreadsheetApp.getActiveSpreadsheet().getId());
  const importedMonth = readJson_("importedMonth", null);
  const results = runChecks({ config, detail, items, employees, records, sharing, importedMonth, edition: EDITION });
  const ctx = { config, detail, items, employees, records, results, byKey: employeesByKey(employees) };
  ctx.fingerprint = deliveryFingerprint(detailRows, items, employees, config);
  ctx.scope = config.month ? config.month.key + "|" + config.title : "";
  return ctx;
}

/** 11 項目を確かめて「確かめる」シートに書く */
export function checkBeforeSend() {
  runFromMenu_(() => {
    const ctx = loadContext_();
    writeChecks_(ctx.results);
    return checkSummary(ctx.results);
  });
}

/** 要確認があれば確かめるシートに書いて、その文を返す。無ければ null */
function blockedText_(ctx) {
  if (!isBlocked(ctx.results)) return null;
  writeChecks_(ctx.results);
  return checkSummary(ctx.results);
}

/** 試し送りで作った PDF の控え { fingerprint, files: { 社員番号の鍵: ファイル ID } }。明細が変わっていれば、渡していない分をゴミ箱へ移して空から */
// ponytail: ドキュメント プロパティは 1 つ 9 KB まで。150 人ほどで上限に近づく。超えるなら隠しシートに移す
function fileMap_(ctx) {
  const name = "files:" + ctx.scope;
  const map = readJson_(name, null);
  if (map && map.fingerprint === ctx.fingerprint) return map;
  if (map) staleFiles(map, ctx.records).forEach(trash_);
  const fresh = { fingerprint: ctx.fingerprint, files: {} };
  writeJson_(name, fresh);
  return fresh;
}

function saveFileMap_(ctx, map) {
  writeJson_("files:" + ctx.scope, map);
}

function personName_(ctx, person) {
  const employee = ctx.byKey[person.key];
  return person.name || (employee ? employee.name : "");
}

/** 1 人分の PDF を作る（Blob）。version が 2 以上ならファイル名に回目を付ける */
function buildPdf_(ctx, person, version) {
  const name = personName_(ctx, person);
  const data = payslipData(person, ctx.items, ctx.config, name);
  const fileName = pdfFileName(ctx.config.month.key, ctx.config.title, person.id, name, version);
  // 雛形とフォルダは 1 回の実行で 1 度だけ確かめる（1 人ごとに Drive を引かない）
  if (!ctx.templateId) ctx.templateId = ensureTemplate_().id;
  if (!ctx.folderId) ctx.folderId = monthFolderId_(ctx.config.month.key);
  return makePdf_(ctx.templateId, ctx.folderId, data, fileName);
}

/**
 * 全員分の PDF を作り、そろったら自分あてに 1 通で送る（社員には送らない）。済むまで「配る」は押せない。
 * 1 人 10 秒ほどかかるので、時間の上限の手前で止め、作った PDF の ID を控えて、次に押したときは続きから作る。
 * 「済み」は、全員分の PDF がそろい、自分あてのメールが送れたあとにだけ書く。作った PDF は「配る」でそのまま使う
 */
export function sendTrial() {
  runFromMenu_(() => withLock_(() => {
    const ctx = loadContext_();
    const blocked = blockedText_(ctx);
    if (blocked) return blocked;
    const me = myAddress_();
    const map = fileMap_(ctx);
    const started = Date.now();
    const people = ctx.detail.people;
    let made = 0;
    for (let i = 0; i < people.length; i += 1) {
      const key = people[i].key;
      if (map.files[key]) continue;
      if (timeUp(started, Date.now())) break;
      map.files[key] = savePdf_(buildPdf_(ctx, people[i], 1), ctx.folderId);
      saveFileMap_(ctx, map);
      made += 1;
    }
    const left = people.filter((person) => !map.files[person.key]).length;
    if (left > 0) {
      return made + " 人分の PDF を作りました。時間の上限に近づいたため、残りの " + left + " 人分はまだです。もう一度「試し送り」を押すと続きを作ります（作った分は作り直しません）。全員分がそろったら、自分あてに 1 通お届けします。";
    }
    if (made === 0 && readJson_("trial:" + ctx.scope, null) === ctx.fingerprint) {
      return "この内容の試し送りは済んでいます（明細・社員・設定は前の試し送りから変わっていません）。PDF はドライブの「給与明細 配布キット」/「" + ctx.config.month.key + "」フォルダにあります。\n\n次は「配る」を押してください。";
    }
    const entries = people.map((person) => {
      const employee = ctx.byKey[person.key];
      const decision = decideDelivery(employee);
      const sendsMail = decision.method === METHOD_SHARE || decision.method === METHOD_ATTACH;
      return {
        id: person.id, name: personName_(ctx, person), link: fileUrl_(map.files[person.key]),
        method: decision.method === METHOD_NONE ? "送らない（" + decision.reason + "）" : decision.method, to: sendsMail ? employee.email : "",
      };
    });
    sendMail_(me, buildTrialMail(ctx.config, entries), ctx.config.senderName, []);
    writeJson_("trial:" + ctx.scope, ctx.fingerprint);
    return me + " に試し送りを送りました（" + people.length + " 人分の PDF）。社員の方には送っていません。\n\n届いたメールのリンクから PDF の体裁・金額を、本文の一覧から宛先と渡し方をご確認ください。よければ「配る」を押します。";
  }));
}

/** 例外の文を短く */
function errorText_(error, max) {
  return String(error && error.message ? error.message : error).slice(0, max);
}

/**
 * 1 人に送る。送る前に記録へ「送信中」を書き、送れたら「送信済み」にする。
 * 「失敗」にするのは、メールの送信を呼ぶより前に落ちたと分かるときだけ（次の「配る」でもう一度送る）。
 * 送信を呼んだあと（送信の例外・記録の書き換えの失敗）は、届いたか分からないので「送信中」のまま止める（確かめるが要確認にする）。
 * 共有に失敗したら添付に切り替える。返り値 { ok, switched, uncertain, error }
 */
function sendOne_(ctx, target, version, map) {
  const config = ctx.config;
  const employee = target.employee;
  const entry = {
    key: target.key, month: config.month.key, title: config.title, id: target.person.id, name: target.name,
    to: employee.email, method: target.method, status: SENDING, version: version, at: new Date(),
  };
  appendLedger_(entry);
  const match = { key: entry.key, version: version, status: SENDING };
  const known = { fileId: "", permissionId: "" };
  let calledSend = false;
  try {
    known.fileId = version === 1 && map ? map.files[target.person.key] || "" : "";
    let blob = null;
    if (!known.fileId) {
      blob = buildPdf_(ctx, target.person, version);
      known.fileId = savePdf_(blob, ctx.folderId);
    }
    let method = target.method;
    let memo = "";
    if (method === METHOD_SHARE) {
      try {
        known.permissionId = share_(known.fileId, employee.email);
      } catch (error) {
        const next = afterShareFailure(error);
        method = next.method;
        memo = next.memo;
      }
    }
    if (method === METHOD_ATTACH && !blob) blob = buildPdf_(ctx, target.person, version);
    calledSend = true;
    sendMail_(employee.email, buildMail(config, target.name, method, fileUrl_(known.fileId)), config.senderName, method === METHOD_ATTACH ? [blob] : []);
    updateLedger_(match, { status: SENT, method: method, fileId: known.fileId, permissionId: known.permissionId, memo: memo, at: new Date() });
    return { ok: true, switched: memo !== "" };
  } catch (error) {
    const changes = calledSend
      ? { memo: "届いたか分かりません（送信のあとで止まりました: " + errorText_(error, 150) + "）", fileId: known.fileId, permissionId: known.permissionId }
      : { status: FAILED, memo: "送れませんでした: " + errorText_(error, 200), fileId: known.fileId, permissionId: known.permissionId, at: new Date() };
    try {
      updateLedger_(match, changes);
    } catch (ledgerError) {
      // 書けなければ「送信中」のまま残る（確かめるが止める側に倒れる）
    }
    return { ok: false, uncertain: calledSend, error: error };
  }
}

/** 続きの 1 回きりのトリガーを消す */
function clearContinueTriggers_() {
  const triggers = ScriptApp.getProjectTriggers();
  for (let i = 0; i < triggers.length; i += 1) if (triggers[i].getHandlerFunction() === CONTINUE_HANDLER) ScriptApp.deleteTrigger(triggers[i]);
}

/** 1 回きりの続きを minutes 分後に作る（前の続きは消す） */
function scheduleContinue_(minutes) {
  clearContinueTriggers_();
  ScriptApp.newTrigger(CONTINUE_HANDLER).timeBased().after(minutes * 60 * 1000).create();
}

/**
 * 配る本体。画面の無いトリガーからも呼ぶので、結果は文で返す。
 * confirm は送る前の確認（画面から押したときだけ）。時間は確認の画面を含めて、この関数の始まりから数える。
 * 返り値 { text, rest, scheduled }
 */
function deliverCore_(confirm) {
  const started = Date.now();
  if (!canDeliver(EDITION)) return { text: PAID_ONLY_TEXT, rest: 0, scheduled: false };
  const ctx = loadContext_();
  const blocked = blockedText_(ctx);
  if (blocked) return { text: blocked, rest: 0, scheduled: false };
  if (readJson_("trial:" + ctx.scope, null) !== ctx.fingerprint) return { text: TRIAL_REQUIRED_TEXT, rest: 0, scheduled: false };
  const plan = planDelivery(ctx.detail.people, ctx.employees, ctx.records, ctx.config);
  const paperLine = plan.paper.length > 0 ? "紙で渡す人（送りません。PDF を印刷してお渡しください）: " + plan.paper.map((p) => p.name).join("、") : "";
  if (plan.targets.length === 0) {
    return { text: ["送る人はいません（" + ctx.config.month.label + "分の" + ctx.config.title + "は、送れる方には送り済みです）。", paperLine].filter((t) => t).join("\n\n"), rest: 0, scheduled: false };
  }
  if (confirm && !confirm(plan)) return { text: "送るのをやめました。", rest: 0, scheduled: false };
  const map = fileMap_(ctx);
  // 「続きを自動で送る」のときは、結果を知らせる 1 通の分を残す
  const batch = planBatch(plan.targets, remainingQuota_(), ctx.config.autoContinue ? 1 : 0);
  let done = 0;
  let stopped = batch.rest.length > 0 ? "quota" : "";
  const failed = [];
  const uncertain = [];
  const switched = [];
  for (let i = 0; i < batch.now.length; i += 1) {
    if (timeUp(started, Date.now())) {
      stopped = "time";
      break;
    }
    const target = batch.now[i];
    const sent = sendOne_(ctx, target, 1, map);
    done += 1;
    if (sent.uncertain) uncertain.push(target.name);
    else if (!sent.ok) failed.push(target.name + "（" + errorText_(sent.error, 80) + "）");
    else if (sent.switched) switched.push(target.name);
  }
  const rest = plan.targets.length - done;
  const lines = [ctx.config.month.label + "分の" + ctx.config.title + "を " + (done - failed.length - uncertain.length) + " 人に送りました。"];
  if (switched.length > 0) lines.push("共有できなかったため添付で送った人: " + switched.join("、"));
  if (failed.length > 0) lines.push("送れなかった人（「送信記録」に「失敗」と書きました。直してもう一度「配る」を押すと送ります）: " + failed.join("、"));
  if (uncertain.length > 0) {
    lines.push("届いたか分からない人（「送信記録」は「送信中」のままです。Gmail の「送信済み」にその方あてのメールがあれば届いています。確かめて記録を直すまで、次の「配る」は止まります）: " + uncertain.join("、"));
  }
  if (paperLine) lines.push(paperLine);
  if (rest > 0) lines.push(continueText(rest, stopped || "time"));
  clearContinueTriggers_();
  let scheduled = false;
  // 続きを自動で回すのは、時間で止まって、送れた人がいたときだけ（送信数の上限なら、翌日まで回り続けないよう作らない）
  if (rest > 0 && ctx.config.autoContinue && stopped === "time" && done > 0 && uncertain.length === 0) {
    scheduleContinue_(1);
    scheduled = true;
    lines.push("「続きを自動で送る」が「する」なので、1 分ほどあとに続きを送ります。");
  }
  return { text: lines.join("\n\n"), rest: rest, scheduled: scheduled };
}

/** 同意あり・在籍の社員に、渡し方どおりに送る */
export function deliverPayslips() {
  runFromMenu_(() => withLock_(() => deliverCore_((plan) => {
    const share = plan.targets.filter((t) => t.method === METHOD_SHARE).length;
    const answer = ui_().alert(
      "配る前の確認",
      plan.targets.length + " 人に送ります（共有 " + share + " 人・添付 " + (plan.targets.length - share) + " 人）。" +
        (plan.paper.length > 0 ? "\n紙で渡す人 " + plan.paper.length + " 人には送りません。" : "") + "\n\nよろしいですか。",
      ui_().ButtonSet.YES_NO,
    );
    return answer === ui_().Button.YES;
  }).text));
}

/**
 * 1 回きりのトリガーから呼ぶ続き。画面が無いので、続きを作らずに終わったら自分あてに結果を 1 通送る。
 * ほかの操作がロックを持っていたら、5 分後にもう一度回す
 */
export function continueDelivery() {
  clearContinueTriggers_();
  let locked = false;
  const text = withLock_(() => {
    locked = true;
    const result = deliverCore_(null);
    if (!result.scheduled) sendMail_(myAddress_(), { subject: "【給与明細】続きの送信の結果", body: result.text }, "給与明細 配布キット", []);
    return result.text;
  });
  if (!locked) scheduleContinue_(5);
  Logger.log(text);
}

/** 社員番号を指定して送り直す（記録に 2 回目・3 回目と版を残す）。前の版の共有は外す */
export function resendPayslip() {
  runFromMenu_(() => {
    if (!canDeliver(EDITION)) return PAID_ONLY_TEXT;
    const ui = ui_();
    const asked = ui.prompt("送り直す", "送り直す方の社員番号を入れてください。", ui.ButtonSet.OK_CANCEL);
    if (asked.getSelectedButton() !== ui.Button.OK) return null;
    const wanted = idKey(asked.getResponseText());
    return withLock_(() => {
      const ctx = loadContext_();
      const blocked = blockedText_(ctx);
      if (blocked) return blocked;
      if (readJson_("trial:" + ctx.scope, null) !== ctx.fingerprint) return TRIAL_REQUIRED_TEXT;
      const person = ctx.detail.people.find((p) => p.key === wanted);
      if (!person) return "「" + DETAIL_TAB + "」に社員番号 " + wanted + " の方がいません。";
      const employee = ctx.byKey[person.key];
      const decision = decideDelivery(employee);
      if (decision.method !== METHOD_SHARE && decision.method !== METHOD_ATTACH) return personName_(ctx, person) + " 様には送れません（" + (decision.reason || decision.method) + "）。";
      const key = keyOf(ctx.config.month.key, person.id, ctx.config.title);
      const plan = resendPlan(ctx.records, key);
      if (!plan) return "この方にはまだ送っていません。「配る」で送ります。";
      const name = personName_(ctx, person);
      const yes = ui.alert("送り直しの確認", name + " 様（" + employee.email + "）に " + plan.version + " 回目として送り直します。前の版の共有は外します。よろしいですか。", ui.ButtonSet.YES_NO);
      if (yes !== ui.Button.YES) return "送り直しをやめました。";
      const sent = sendOne_(ctx, { person: person, employee: employee, method: decision.method, key: key, name: name }, plan.version, null);
      if (sent.uncertain) return name + " 様あてのメールを送りましたが、届いたかを確かめられませんでした（" + errorText_(sent.error, 120) + "）。「送信記録」は「送信中」のままです。Gmail の「送信済み」を確かめてください。";
      if (!sent.ok) return "送れませんでした: " + errorText_(sent.error, 200);
      // 送れたことを先に確かにしてから、前の版の共有を 1 件ずつ外す（外せなくても、送れたことは伝える）
      const notRemoved = [];
      for (let i = 0; i < plan.previous.length; i += 1) {
        const previous = plan.previous[i];
        if (previous.permissionId === "") continue;
        try {
          unshare_(previous.fileId, previous.permissionId);
          updateLedger_({ key: previous.key, version: previous.version, row: previous.row }, { memo: (previous.memo ? previous.memo + " / " : "") + "共有を外しました（差し替え）" });
        } catch (error) {
          notRemoved.push(previous.version + " 回目（" + errorText_(error, 80) + "）");
        }
      }
      if (notRemoved.length > 0) {
        return name + " 様に " + plan.version + " 回目を送りました。前の版のうち " + notRemoved.length + " 件の共有を外せませんでした: " + notRemoved.join("、") + "\nもう一度「送り直す」は押さず、ドライブでそのファイルの共有を外してください。";
      }
      return name + " 様に " + plan.version + " 回目を送りました。前の版の共有は外しました。";
    });
  });
}

/** 社員シートで「退職」にした方の、キットが作ったファイルの共有を外す */
export function unshareRetired() {
  runFromMenu_(() => {
    if (!canDeliver(EDITION)) return PAID_ONLY_TEXT;
    return withLock_(() => {
      const employees = parseEmployees(requiredValues_(EMPLOYEES_TAB), EDITION);
      const retired = employees.filter((e) => !e.active).map((e) => e.key);
      const targets = unshareTargets(parseLedger(requiredValues_(LEDGER_TAB)), retired);
      if (targets.length === 0) return "共有を外すファイルはありません（「" + EMPLOYEES_TAB + "」で「在籍」を「退職」にした方の、共有したままのファイルが対象です）。";
      const ui = ui_();
      const names = [];
      for (let i = 0; i < targets.length; i += 1) if (names.indexOf(targets[i].name) < 0) names.push(targets[i].name);
      const yes = ui.alert("共有を外す", names.join("、") + " 様の " + targets.length + " ファイルの共有を外します。よろしいですか。", ui.ButtonSet.YES_NO);
      if (yes !== ui.Button.YES) return "やめました。";
      const failed = [];
      for (let i = 0; i < targets.length; i += 1) {
        const record = targets[i];
        try {
          unshare_(record.fileId, record.permissionId);
          updateLedger_({ key: record.key, version: record.version, row: record.row }, { memo: (record.memo ? record.memo + " / " : "") + "共有を外しました（退職）" });
        } catch (error) {
          failed.push(record.name + " " + record.month);
        }
      }
      return (targets.length - failed.length) + " ファイルの共有を外しました。" + (failed.length > 0 ? "\n外せなかったもの: " + failed.join("、") : "");
    });
  });
}
