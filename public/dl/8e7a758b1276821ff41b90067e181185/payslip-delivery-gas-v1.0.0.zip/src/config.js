/** 「設定」シートの読み取り（純粋）。シートは「項目」「値」の 2 列。知らない項目は無視する。 */
import { cellText } from "./text.js";

export const SETTINGS_TAB = "設定";

export const DEFAULT_SUBJECT = "{対象月}分 {題}のお知らせ";
export const DEFAULT_BODY = [
  "{氏名} 様",
  "",
  "{対象月}分の{題}をお届けします。",
  "",
  "{リンク}",
  "",
  "このメールには金額を書いていません。",
  "お心当たりのない場合は、お手数ですがこのメールを削除してください。",
  "",
  "{会社名}",
].join("\n");

/** 初期化で入れる行（項目・既定値）。README の表と同じ順 */
export const DEFAULT_ROWS = [
  ["会社名", ""],
  ["題", "給与明細"],
  ["対象月", ""],
  ["支給日", ""],
  ["備考", ""],
  ["見出しの行数", "自動"],
  ["0 の行", "出さない"],
  ["送信元の表示名", ""],
  ["件名", DEFAULT_SUBJECT],
  ["本文", DEFAULT_BODY],
  ["続きを自動で送る", "しない"],
  ["同じ月の別の題を送る", "しない"],
  ["共有範囲を確かめた日", ""],
];

export const CONFIG_KEYS = DEFAULT_ROWS.map((row) => row[0]);

/** 項目名のゆれ（前後・中の空白、全角）をそろえる */
export function settingKey(name) {
  return cellText(name).replace(/\s+/g, "");
}

function two(n) {
  return n < 10 ? "0" + n : String(n);
}

/** 対象月を { key: "2026-10", label: "2026年10月" } に。読めなければ null。Date はその年月 */
export function parseMonth(value) {
  let year;
  let month;
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    year = value.getFullYear();
    month = value.getMonth() + 1;
  } else {
    const match = cellText(value).match(/^(\d{4})\s*[-/.年]?\s*(\d{1,2})\s*月?(分)?$/);
    if (!match) return null;
    year = Number(match[1]);
    month = Number(match[2]);
  }
  if (month < 1 || month > 12) return null;
  return { key: year + "-" + two(month), label: year + "年" + month + "月" };
}

/** 支給日の表示。Date は「2026年10月25日」、字はそのまま */
export function formatPayday(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.getFullYear() + "年" + (value.getMonth() + 1) + "月" + value.getDate() + "日";
  }
  return cellText(value);
}

/** 設定シートの値を、項目名 → 値 の表に。最初の行が「項目」なら見出しとして飛ばす */
function settingMap(rows) {
  const map = {};
  const list = Array.isArray(rows) ? rows : [];
  for (let i = 0; i < list.length; i += 1) {
    const row = Array.isArray(list[i]) ? list[i] : [];
    const key = settingKey(row[0]);
    if (key === "" || key === "項目") continue;
    const value = row[1];
    if (value === null || value === undefined || (typeof value === "string" && value.trim() === "")) continue;
    map[key] = value;
  }
  return map;
}

/** 設定を読む。値が空の項目は既定値。読めない値は既定値に戻して problems に直し方を残す */
export function parseConfig(rows) {
  const map = settingMap(rows);
  const problems = [];
  const text = (name, fallback) => (map[settingKey(name)] === undefined ? fallback : String(map[settingKey(name)]));
  const company = cellText(text("会社名", ""));

  let headerRows = "auto";
  const rawHeader = cellText(text("見出しの行数", "自動"));
  if (rawHeader !== "自動" && rawHeader !== "") {
    if (/^[1-3]$/.test(rawHeader)) headerRows = Number(rawHeader);
    else problems.push("「設定」の「見出しの行数」は「自動」か 1〜3 の数で書いてください（いまは「" + rawHeader + "」）");
  }

  const rawMonth = map[settingKey("対象月")];
  return {
    company: company,
    title: cellText(text("題", "給与明細")) || "給与明細",
    month: rawMonth === undefined ? null : parseMonth(rawMonth),
    monthRaw: rawMonth === undefined ? "" : cellText(rawMonth instanceof Date ? "" : rawMonth),
    payday: map[settingKey("支給日")] === undefined ? "" : formatPayday(map[settingKey("支給日")]),
    note: cellText(text("備考", "")),
    headerRows: headerRows,
    showZero: cellText(text("0 の行", "出さない")) === "出す",
    senderName: cellText(text("送信元の表示名", "")) || company || "給与明細",
    subject: text("件名", DEFAULT_SUBJECT),
    body: text("本文", DEFAULT_BODY),
    autoContinue: cellText(text("続きを自動で送る", "しない")) === "する",
    allowOtherTitle: cellText(text("同じ月の別の題を送る", "しない")) === "する",
    sharingCheckedOn: map[settingKey("共有範囲を確かめた日")] === undefined ? "" : formatPayday(map[settingKey("共有範囲を確かめた日")]),
    problems: problems,
  };
}
