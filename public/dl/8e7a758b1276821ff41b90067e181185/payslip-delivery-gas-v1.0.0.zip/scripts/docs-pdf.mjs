#!/usr/bin/env node
// docs/staff-guide.md から、印刷用の docs/staff-guide.pdf（A4 1 枚）を作る。Google Chrome の headless の印刷を使う。
// 見出し・段落・箇条書き・番号つき・太字・コードだけを読む小さな変換（この 1 枚に要る分だけ）。
import { execFileSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const CHROME = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";

function inline(text) {
  return text
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/`([^`]+)`/g, "<code>$1</code>");
}

export function toHtml(markdown) {
  const out = [];
  let list = null;
  const close = () => {
    if (list) out.push("</" + list + ">");
    list = null;
  };
  for (const line of markdown.split("\n")) {
    const heading = line.match(/^(#{1,3}) (.*)$/);
    const bullet = line.match(/^- (.*)$/);
    const number = line.match(/^\d+\. (.*)$/);
    if (heading) {
      close();
      out.push("<h" + heading[1].length + ">" + inline(heading[2]) + "</h" + heading[1].length + ">");
    } else if (bullet || number) {
      const kind = bullet ? "ul" : "ol";
      if (list !== kind) {
        close();
        out.push("<" + kind + ">");
        list = kind;
      }
      out.push("<li>" + inline((bullet || number)[1]) + "</li>");
    } else if (line.trim() === "") close();
    else {
      close();
      out.push("<p>" + inline(line) + "</p>");
    }
  }
  close();
  return [
    '<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>給与明細の受け取り方</title><style>',
    "@page { size: A4; margin: 14mm 16mm; }",
    'body { font-family: "Hiragino Sans", "Noto Sans JP", sans-serif; font-size: 9.6pt; line-height: 1.55; color: #222; }',
    "h1 { font-size: 15pt; margin: 0 0 4pt; } h2 { font-size: 11pt; margin: 9pt 0 2pt; border-bottom: 0.6pt solid #999; }",
    "p { margin: 2pt 0; } ul, ol { margin: 2pt 0; padding-left: 16pt; } li { margin: 1pt 0; }",
    "code { font-family: inherit; background: #f1f1f1; padding: 0 2pt; }",
    "</style></head><body>",
    out.join("\n"),
    "</body></html>",
  ].join("\n");
}

if (!existsSync(CHROME)) {
  console.error("Google Chrome が見つかりません。CHROME= で場所を指定してください");
  process.exit(1);
}
const dir = mkdtempSync(join(tmpdir(), "staff-guide-"));
const html = join(dir, "staff-guide.html");
writeFileSync(html, toHtml(readFileSync("docs/staff-guide.md", "utf8")));
execFileSync(CHROME, ["--headless", "--disable-gpu", "--no-pdf-header-footer", "--print-to-pdf=" + join(process.cwd(), "docs/staff-guide.pdf"), "file://" + html], { stdio: "inherit" });
console.log("wrote docs/staff-guide.pdf");
