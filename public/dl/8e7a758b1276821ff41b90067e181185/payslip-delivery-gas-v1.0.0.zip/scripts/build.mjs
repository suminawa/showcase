#!/usr/bin/env node
// src/*.js を 1 本の Code.gs にまとめる。有料版は dist/、無料版は dist-free/。買い手は Apps Script のエディタにこの 1 ファイルを貼る。
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/**
 * つなぐ順。先頭は gas_main.js（最初の関数が onOpen なので、エディタの実行ボタンを押すとメニューが出る）。
 * 関数宣言は巻き上がり、どのファイルも先頭で走るのは定数の初期化だけなので、前に置いても壊れない。
 * 以降は 純粋な処理（使われる側から） → GAS に触る部分。
 */
export const SOURCE_ORDER = [
  "gas_main.js",
  "edition.js",
  "text.js",
  "amount.js",
  "config.js",
  "items.js",
  "importer.js",
  "employees.js",
  "ledger.js",
  "delivery.js",
  "message.js",
  "check.js",
  "setup.js",
  "gas_sheets.js",
  "gas_drive.js",
  "gas_mail.js",
];

const SCOPES = {
  // このスプレッドシートだけの読み書き（承認の画面も「このスプレッドシート」になる）
  sheet: "https://www.googleapis.com/auth/spreadsheets.currentonly",
  // 雛形の複製を開いて差し込む
  documents: "https://www.googleapis.com/auth/documents",
  // Advanced Drive。このキットが作ったファイルとフォルダだけ（ドライブ全体は見ない）
  driveFile: "https://www.googleapis.com/auth/drive.file",
  // 知らせと試し送りのメール
  mail: "https://www.googleapis.com/auth/script.send_mail",
  // 続きを自動で送る 1 回きりのトリガー（有料版だけ）
  trigger: "https://www.googleapis.com/auth/script.scriptapp",
  // 試し送りの宛先（実行している方のアドレス）
  email: "https://www.googleapis.com/auth/userinfo.email",
  // メニューと画面の文
  ui: "https://www.googleapis.com/auth/script.container.ui",
};

export function manifestFor(edition) {
  const scopes = Object.keys(SCOPES)
    .filter((name) => !(edition === "free" && name === "trigger"))
    .map((name) => SCOPES[name]);
  return {
    timeZone: "Asia/Tokyo",
    dependencies: { enabledAdvancedServices: [{ userSymbol: "Drive", version: "v3", serviceId: "drive" }] },
    exceptionLogging: "STACKDRIVER",
    runtimeVersion: "V8",
    oauthScopes: scopes,
  };
}

export const MANIFEST = manifestFor("paid");

/** import 行は落とし、行頭の export だけを剥がす（Apps Script は import / export を解さない） */
export function toGasSource(source) {
  const lines = String(source).split("\n");
  const kept = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (/^import\s[^;]*from\s+["'][^"']+["'];?\s*$/.test(line)) continue;
    kept.push(line.replace(/^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\s)/, ""));
  }
  return kept.join("\n").trim();
}

const EDITION_LINE = 'const EDITION = "paid";';

export function buildSource(root, edition) {
  const base = root === undefined ? ROOT : root;
  const parts = [];
  for (let i = 0; i < SOURCE_ORDER.length; i += 1) {
    const name = SOURCE_ORDER[i];
    parts.push("// ===== " + name + " =====\n" + toGasSource(readFileSync(join(base, "src", name), "utf8")));
  }
  let code = parts.join("\n\n");
  const leftover = code.match(/^\s*(import|export)\s/m);
  if (leftover) throw new Error("import / export が残っている: " + leftover[0].trim());
  if (edition === "free") {
    if (code.split(EDITION_LINE).length !== 2) throw new Error(EDITION_LINE + " が 1 つだけ無い");
    code = code.replace(EDITION_LINE, 'const EDITION = "free";');
  }
  return code;
}

/** Code.gs の頭。1 行目に版。@OnlyCurrentDoc は、承認を「このスプレッドシート」に絞る印 */
export function headerOf(version, edition) {
  return (
    "// 給与明細 配布キット v" + version + (edition === "free" ? "（無料版）" : "") +
    " — scripts/build.mjs が src/ から作る。ここを直接編集しない\n/** @OnlyCurrentDoc */\n\n"
  );
}

export function build(root) {
  const base = root === undefined ? ROOT : root;
  const version = JSON.parse(readFileSync(join(base, "package.json"), "utf8")).version;
  for (const [dir, edition] of [["dist", "paid"], ["dist-free", "free"]]) {
    mkdirSync(join(base, dir), { recursive: true });
    writeFileSync(join(base, dir, "Code.gs"), headerOf(version, edition) + buildSource(base, edition) + "\n");
    writeFileSync(join(base, dir, "appsscript.json"), JSON.stringify(manifestFor(edition), null, 2) + "\n");
  }
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  build();
  console.log("wrote dist/ and dist-free/ (Code.gs, appsscript.json)");
}
