#!/usr/bin/env node
// 配布 zip を release/ に 2 つ作る。有料版（dist）と、買う前に試す無料版（dist-free）。
// 有料版には src / test / scripts も入れる（「手元で動かす」と改造ができるように）。
// ファイル名は英数字だけにしてある（macOS の zip は UTF-8 の印を付けられず、Windows の標準の展開で日本語名が化けるため）。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const COMMON = ["samples", "docs", "README.ja.md", "LICENSE.md", "CHANGELOG.md"];
const zips = [
  { out: `release/payslip-delivery-gas-v${pkg.version}.zip`, files: ["dist"].concat(COMMON, ["src", "test", "scripts", "package.json"]) },
  { out: `release/payslip-delivery-gas-free-v${pkg.version}.zip`, files: ["dist-free"].concat(COMMON) },
];

for (const required of ["dist/Code.gs", "dist/appsscript.json", "dist-free/Code.gs", "dist-free/appsscript.json", "docs/staff-guide.pdf"]) {
  if (!existsSync(required)) {
    console.error(required + " がありません。先に npm run build（staff-guide.pdf は npm run docs:pdf）を実行してください");
    process.exit(1);
  }
}
mkdirSync("release", { recursive: true });
for (const zip of zips) {
  if (existsSync(zip.out)) rmSync(zip.out);
  execFileSync("zip", ["-r", zip.out].concat(zip.files, ["-x", "*.DS_Store"]), { stdio: "inherit" });
  console.log(`${zip.out} を作りました`);
}
