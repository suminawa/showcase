import { test } from "node:test";
import assert from "node:assert/strict";
import { CONFIG_KEYS, DEFAULT_ROWS, formatPayday, parseConfig, parseMonth } from "../src/config.js";

test("対象月: いろいろな書き方を 2026-10 に。Date も読む", () => {
  assert.deepEqual(parseMonth("2026-10"), { key: "2026-10", label: "2026年10月" });
  assert.deepEqual(parseMonth("２０２６年１０月"), { key: "2026-10", label: "2026年10月" });
  assert.deepEqual(parseMonth("2026/8"), { key: "2026-08", label: "2026年8月" });
  assert.deepEqual(parseMonth(new Date(2026, 9, 1)), { key: "2026-10", label: "2026年10月" });
  assert.equal(parseMonth("2026-13"), null);
  assert.equal(parseMonth("来月"), null);
  assert.equal(parseMonth(""), null);
});

test("支給日: Date は 2026年10月25日、字はそのまま", () => {
  assert.equal(formatPayday(new Date(2026, 9, 25)), "2026年10月25日");
  assert.equal(formatPayday(" 10月25日 "), "10月25日");
  assert.equal(formatPayday(""), "");
});

test("初期化で入る行は CONFIG_KEYS と同じ順・同じ数", () => {
  assert.deepEqual(DEFAULT_ROWS.map((row) => row[0]), CONFIG_KEYS);
});

test("空のシートでも既定値で読める。対象月と支給日は空のまま", () => {
  const config = parseConfig([]);
  assert.equal(config.title, "給与明細");
  assert.equal(config.month, null);
  assert.equal(config.payday, "");
  assert.equal(config.showZero, false);
  assert.equal(config.headerRows, "auto");
  assert.equal(config.autoContinue, false);
  assert.ok(config.subject.includes("{対象月}"));
  assert.ok(config.body.includes("{リンク}"));
});

test("書いた値を読む。項目の前後の空白とゆれは気にしない", () => {
  const config = parseConfig([
    ["項目", "値"],
    [" 会社名 ", "見本商事株式会社"],
    ["題", "賞与明細"],
    ["対象月", "2026年10月"],
    ["支給日", new Date(2026, 9, 25)],
    ["0 の行", "出す"],
    ["見出しの行数", "2"],
    ["続きを自動で送る", "する"],
    ["送信元の表示名", ""],
    ["メモ", "知らない行は無視"],
  ]);
  assert.equal(config.company, "見本商事株式会社");
  assert.equal(config.title, "賞与明細");
  assert.deepEqual(config.month, { key: "2026-10", label: "2026年10月" });
  assert.equal(config.payday, "2026年10月25日");
  assert.equal(config.showZero, true);
  assert.equal(config.headerRows, 2);
  assert.equal(config.autoContinue, true);
  assert.equal(config.senderName, "見本商事株式会社", "表示名が空なら会社名");
});

test("見出しの行数の書き間違いは自動判定に戻し、problems に残す", () => {
  const config = parseConfig([["見出しの行数", "たくさん"]]);
  assert.equal(config.headerRows, "auto");
  assert.equal(config.problems.length, 1);
});
