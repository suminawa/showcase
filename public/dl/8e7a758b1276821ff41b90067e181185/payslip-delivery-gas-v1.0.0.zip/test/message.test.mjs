import { test } from "node:test";
import assert from "node:assert/strict";
import { parseConfig } from "../src/config.js";
import { buildMail, buildTrialMail, payslipData, pdfFileName, renderTemplate, safeFileName } from "../src/message.js";

const config = parseConfig([
  ["会社名", "見本商事株式会社"],
  ["対象月", "2026-10"],
  ["支給日", "2026年10月25日"],
]);

const items = [
  { header: "勤怠 出勤日数", category: "勤怠", label: "出勤日数" },
  { header: "勤怠 欠勤日数", category: "勤怠", label: "欠勤日数" },
  { header: "支給 基本給", category: "支給", label: "基本給" },
  { header: "支給 役職手当", category: "支給", label: "役職手当" },
  { header: "支給 過不足調整", category: "支給", label: "過不足調整" },
  { header: "控除 介護保険", category: "控除", label: "介護保険" },
  { header: "控除合計", category: "合計", label: "控除合計" },
  { header: "差引支給額", category: "合計", label: "差引支給額" },
  { header: "所属", category: "表示しない", label: "所属" },
];
const person = {
  id: "1001", key: "1001", name: "見本 一郎",
  values: {
    "勤怠 出勤日数": "20", "勤怠 欠勤日数": "0", "支給 基本給": 250000, "支給 役職手当": "", "支給 過不足調整": -3000,
    "控除 介護保険": 0, 控除合計: 0, 差引支給額: 247000, 所属: "営業",
  },
};

test("差し込み: 知っている名前だけ置き換え、知らない {…} は残す", () => {
  assert.equal(renderTemplate("{氏名} 様 {金額}", { 氏名: "見本" }), "見本 様 {金額}");
});

test("共有のメール: 既定の件名・本文に氏名・対象月・題・リンク。金額は入らない", () => {
  const mail = buildMail(config, "見本 一郎", "共有", "https://drive.google.com/file/d/F1/view");
  assert.equal(mail.subject, "2026年10月分 給与明細のお知らせ");
  assert.ok(mail.body.startsWith("見本 一郎 様\n"));
  assert.ok(mail.body.includes("https://drive.google.com/file/d/F1/view"));
  assert.ok(mail.body.includes("見本商事株式会社"));
  for (const amount of ["250,000", "250000", "247,000", "247000", "3,000"]) assert.equal(mail.body.includes(amount), false, amount);
});

test("本文に金額の差し込みを書いても、金額は入らない（差し込めるのは 5 つだけ）", () => {
  const custom = Object.assign({}, config, { body: "{氏名} 様 {差引支給額} {金額}" });
  assert.equal(buildMail(custom, "見本 一郎", "共有", "u").body, "見本 一郎 様 {差引支給額} {金額}");
});

test("添付のメール: リンクの代わりに添付の案内", () => {
  const mail = buildMail(config, "見本 花子", "添付", "");
  assert.ok(mail.body.includes("PDF で添付しています"));
  assert.equal(mail.body.includes("drive.google.com"), false);
});

test("ファイル名: {対象月}_{題}_{社員番号}_{氏名}.pdf。使えない字は _、送り直しは回目", () => {
  assert.equal(pdfFileName("2026-10", "給与明細", "1001", "見本 一郎"), "2026-10_給与明細_1001_見本 一郎.pdf");
  assert.equal(pdfFileName("2026-10", "給与/賞与", "A:1", "見本*一郎?", 2), "2026-10_給与_賞与_A_1_見本_一郎__2回目.pdf");
  assert.equal(safeFileName('a\\b"c<d>e|f\ng'), "a_b_c_d_e_f_g");
});

test("明細のデータ: 4 つの表。0 の行は既定で出さない（合計は常に出す）。マイナスは -3,000。表示しないは出ない", () => {
  const data = payslipData(person, items, config);
  assert.deepEqual(data.fields, { 会社名: "見本商事株式会社", 題: "給与明細", 対象月: "2026年10月", 支給日: "2026年10月25日", 社員番号: "1001", 氏名: "見本 一郎", 備考: "" });
  assert.deepEqual(data.tables.勤怠, [{ label: "出勤日数", value: "20" }]);
  assert.deepEqual(data.tables.支給, [{ label: "基本給", value: "250,000" }, { label: "過不足調整", value: "-3,000" }]);
  assert.deepEqual(data.tables.控除, []);
  assert.deepEqual(data.tables.合計, [{ label: "控除合計", value: "0" }, { label: "差引支給額", value: "247,000" }]);
});

test("明細のデータ: 0 の行を「出す」にすると、0 と空の行も出る", () => {
  const data = payslipData(person, items, Object.assign({}, config, { showZero: true }));
  assert.equal(data.tables.勤怠.length, 2);
  assert.deepEqual(data.tables.支給[1], { label: "役職手当", value: "0" });
  assert.deepEqual(data.tables.控除, [{ label: "介護保険", value: "0" }]);
});

test("試し送り: 自分あての 1 通に、宛先と渡し方と PDF のリンクの一覧", () => {
  const mail = buildTrialMail(config, [
    { id: "1001", name: "見本 一郎", method: "共有", to: "ichiro@example.com", link: "https://drive.google.com/file/d/F1/view" },
    { id: "1003", name: "見本 健太", method: "紙", to: "", link: "https://drive.google.com/file/d/F3/view" },
  ]);
  assert.equal(mail.subject, "【試し送り】2026年10月分 給与明細（2 人分）");
  assert.ok(mail.body.includes("1001 見本 一郎 → ichiro@example.com（共有）\n  https://drive.google.com/file/d/F1/view"));
  assert.ok(mail.body.includes("1003 見本 健太 → 紙"));
  assert.ok(mail.body.includes("社員の方には送っていません"));
});
