import { test } from "node:test";
import assert from "node:assert/strict";
import { readdirSync } from "node:fs";
import { read, root } from "./helpers.mjs";
import { join } from "node:path";

const PURE = ["edition.js", "text.js", "amount.js", "config.js", "items.js", "importer.js", "employees.js", "ledger.js", "delivery.js", "message.js", "check.js", "setup.js"];
const GLUE = ["gas_main.js", "gas_sheets.js", "gas_drive.js", "gas_mail.js"];
const GAS_GLOBALS = ["SpreadsheetApp", "DocumentApp", "DriveApp", "Drive.", "MailApp", "GmailApp", "UrlFetchApp", "PropertiesService", "ScriptApp", "Logger", "Utilities", "Session", "LockService"];

test("純粋な処理は GAS のグローバルに触らない", () => {
  for (const name of PURE) {
    const source = read("src/" + name);
    for (const global of GAS_GLOBALS) assert.equal(source.includes(global), false, name + " が " + global + " に触っている");
  }
});

test("純粋な処理は GAS 側のファイルを読み込まない", () => {
  for (const name of PURE) assert.equal(/from\s+["']\.\/gas_/.test(read("src/" + name)), false, name);
});

test("src にあるのは純粋な処理と GAS 側の 2 種類だけ", () => {
  const files = readdirSync(join(root, "src")).filter((name) => name.endsWith(".js")).sort();
  assert.deepEqual(files, PURE.concat(GLUE).sort());
});

test("メニューの入口が gas_main.js にあり、onOpen が先頭", () => {
  const source = read("src/gas_main.js");
  const names = ["onOpen", "initializeKit", "importPayroll", "checkBeforeSend", "sendTrial", "deliverPayslips", "continueDelivery", "resendPayslip", "unshareRetired"];
  for (const name of names) assert.ok(source.includes("export function " + name + "("), name);
  assert.equal(source.match(/^export function ([A-Za-z_]+)\(/m)[1], "onOpen");
  for (const name of names.slice(1).filter((n) => n !== "continueDelivery")) assert.ok(source.includes('"' + name + '")'), name + " がメニューに無い");
});
