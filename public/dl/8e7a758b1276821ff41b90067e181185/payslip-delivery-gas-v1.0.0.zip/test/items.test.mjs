import { test } from "node:test";
import assert from "node:assert/strict";
import { CATEGORY_WORDS, defaultLabel, guessCategory, mergeItems, parseItems } from "../src/items.js";

test("辞書は 30 語以上", () => {
  const count = CATEGORY_WORDS.reduce((sum, entry) => sum + entry[1].length, 0);
  assert.ok(count >= 30, String(count));
});

test("区分の推定: よく出る見出し", () => {
  const cases = {
    基本給: "支給", 役職手当: "支給", 通勤手当: "支給", 残業手当: "支給", 時間外手当: "支給", 家族手当: "支給",
    健康保険: "控除", 介護保険: "控除", 厚生年金: "控除", 雇用保険: "控除", 所得税: "控除", 住民税: "控除",
    差引支給額: "合計", 支給合計: "合計", 控除合計: "合計", 総支給額: "合計",
    出勤日数: "勤怠", 欠勤日数: "勤怠", 残業時間: "勤怠", 有給休暇: "勤怠", 遅刻回数: "勤怠",
    所属: "表示しない", 振込先: "表示しない",
    なぞの列: "",
  };
  for (const header of Object.keys(cases)) assert.equal(guessCategory(header), cases[header], header);
});

test("2 段の見出しは下の段で引き、引けなければ上の段で引く", () => {
  assert.equal(guessCategory("支給 基本給"), "支給");
  assert.equal(guessCategory("控除 その他"), "控除");
  assert.equal(guessCategory("支給 過不足"), "支給");
  assert.equal(guessCategory("勤怠 出勤"), "勤怠");
  assert.equal(guessCategory("支給 支給合計"), "合計");
  assert.equal(defaultLabel("支給 基本給"), "基本給");
  assert.equal(defaultLabel("差引支給額"), "差引支給額");
});

test("足すのは新しい見出しだけ。人が直した区分・並び順・表示名は残る", () => {
  const existing = parseItems([
    ["見出し", "区分", "並び順", "表示名"],
    ["支給 基本給", "支給", 1, "基本給"],
    ["支給 精勤手当", "表示しない", 2, "精勤"],
  ]);
  const merged = mergeItems(existing, ["支給 基本給", "支給 精勤手当", "控除 所得税"]);
  assert.deepEqual(merged.added, [["控除 所得税", "控除", 3, "所得税"]]);
  assert.equal(merged.items[1].category, "表示しない");
  assert.equal(merged.items[1].label, "精勤");
  assert.deepEqual(merged.items.map((item) => item.header), ["支給 基本給", "支給 精勤手当", "控除 所得税"]);
});

test("並び順の列で並ぶ。空の並び順はシートの順で後ろへ", () => {
  const items = parseItems([
    ["見出し", "区分", "並び順", "表示名"],
    ["B", "支給", 2, ""],
    ["A", "支給", 1, ""],
    ["C", "支給", "", ""],
  ]);
  assert.deepEqual(mergeItems(items, []).items.map((item) => item.header), ["A", "B", "C"]);
});

test("見出しのゆれ（全角スペース・改行）は同じ見出しとみなす", () => {
  const existing = parseItems([["見出し"], ["支給 基本給", "支給", 1, ""]]);
  assert.deepEqual(mergeItems(existing, ["支給　基本給", "支給\n基本給"]).added, []);
});
