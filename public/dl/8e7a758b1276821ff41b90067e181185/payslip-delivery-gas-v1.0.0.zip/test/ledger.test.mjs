import { test } from "node:test";
import assert from "node:assert/strict";
import {
  continueText, isDone, keyOf, LEDGER_HEADERS, ledgerRow, parseLedger, planBatch, resendPlan, staleFiles, stuckRecords, timeUp, unshareTargets,
} from "../src/ledger.js";

function sheet(entries) {
  return [LEDGER_HEADERS].concat(entries.map(ledgerRow));
}

const base = { month: "2026-10", title: "給与明細", name: "見本 一郎", to: "a@example.com", method: "共有", version: 1 };

test("鍵 = 対象月 + 社員番号 + 題。社員番号の全角・先頭の 0 はそろえる", () => {
  assert.equal(keyOf("2026-10", "００１００１", "給与明細"), "2026-10|1001|給与明細");
  assert.notEqual(keyOf("2026-10", "1001", "給与明細"), keyOf("2026-10", "1001", "賞与明細"));
});

test("送信済み・送信中の鍵は送らない。失敗の鍵はもう一度送る", () => {
  const records = parseLedger(sheet([
    Object.assign({}, base, { key: "k1", id: "1", status: "送信済み" }),
    Object.assign({}, base, { key: "k2", id: "2", status: "送信中" }),
    Object.assign({}, base, { key: "k3", id: "3", status: "失敗" }),
  ]));
  assert.equal(records[0].row, 2);
  assert.equal(isDone(records, "k1"), true);
  assert.equal(isDone(records, "k2"), true);
  assert.equal(isDone(records, "k3"), false);
  assert.equal(isDone(records, "k4"), false);
});

test("送信中のまま残った行を、その月・題で拾う", () => {
  const records = parseLedger(sheet([
    Object.assign({}, base, { key: "k1", id: "1", status: "送信中" }),
    Object.assign({}, base, { key: "k2", id: "2", status: "送信中", month: "2026-09" }),
  ]));
  assert.deepEqual(stuckRecords(records, "2026-10", "給与明細").map((r) => r.key), ["k1"]);
});

test("送り直しの版: 送った記録があれば次の版、無ければ null", () => {
  const records = parseLedger(sheet([
    Object.assign({}, base, { key: "k1", id: "1", status: "送信済み", version: 1 }),
    Object.assign({}, base, { key: "k1", id: "1", status: "失敗", version: 2 }),
  ]));
  const plan = resendPlan(records, "k1");
  assert.equal(plan.version, 3);
  assert.equal(plan.previous.length, 1);
  assert.equal(resendPlan(records, "k9"), null);
});

test("バッチ計画: 残り枠のぶんだけ今回、あとは残り。取っておく数を引く", () => {
  const targets = ["a", "b", "c", "d", "e"];
  assert.deepEqual(planBatch(targets, 3, 0), { now: ["a", "b", "c"], rest: ["d", "e"] });
  assert.deepEqual(planBatch(targets, 3, 1), { now: ["a", "b"], rest: ["c", "d", "e"] });
  assert.deepEqual(planBatch(targets, 100, 1), { now: targets, rest: [] });
  assert.deepEqual(planBatch(targets, 0, 1), { now: [], rest: targets });
});

test("時間: 4.5 分で打ち切る", () => {
  assert.equal(timeUp(0, 269999), false);
  assert.equal(timeUp(0, 270000), true);
  assert.ok(continueText(4, "time").includes("もう一度「配る」を押してください（残り 4 人）"));
  assert.ok(continueText(4, "quota").includes("今日送れるメールの数"));
});

test("試し送りのファイルのうち、記録に載っていないものだけをゴミ箱へ", () => {
  const records = parseLedger(sheet([Object.assign({}, base, { key: "k1", id: "1", status: "送信済み", fileId: "F1" })]));
  assert.deepEqual(staleFiles({ files: { 1: "F1", 2: "F2" } }, records), ["F2"]);
  assert.deepEqual(staleFiles(null, records), []);
});

test("退職者の共有を外す対象: 共有 ID のある送信済みで、まだ外していないもの", () => {
  const records = parseLedger(sheet([
    Object.assign({}, base, { key: "k1", id: "0007", status: "送信済み", permissionId: "P1" }),
    Object.assign({}, base, { key: "k2", id: "7", status: "送信済み", permissionId: "" }),
    Object.assign({}, base, { key: "k3", id: "7", status: "送信済み", permissionId: "P3", memo: "共有を外しました（2026-10-30）" }),
    Object.assign({}, base, { key: "k4", id: "8", status: "送信済み", permissionId: "P4" }),
  ]));
  assert.deepEqual(unshareTargets(records, ["7"]).map((r) => r.permissionId), ["P1"]);
});
