import { test } from "node:test";
import assert from "node:assert/strict";
import { checkSheetRows, checkSummary, delimit, isBlocked, runChecks } from "../src/check.js";
import { parseConfig } from "../src/config.js";
import { parseEmployees } from "../src/employees.js";
import { parseDetail } from "../src/importer.js";
import { keyOf, LEDGER_HEADERS, ledgerRow, parseLedger } from "../src/ledger.js";

const EMPLOYEES = [
  ["社員番号", "氏名", "メール", "渡し方", "電子交付の同意日", "在籍"],
  ["1001", "見本 一郎", "ichiro@example.com", "共有", "2026/09/01", "在籍"],
  ["1002", "見本 花子", "hanako@example.com", "添付", "2026/09/01", "在籍"],
];
const DETAIL = [
  ["社員番号", "氏名", "支給 基本給", "差引支給額"],
  ["1001", "見本 一郎", 250000, 240000],
  ["1002", "見本 花子", 220000, 210000],
];
const ITEMS = [
  { header: "支給 基本給", category: "支給", order: 1, label: "基本給" },
  { header: "差引支給額", category: "合計", order: 2, label: "差引支給額" },
];
const CONFIG = [["対象月", "2026-10"], ["支給日", "2026年10月25日"]];

/** すべて OK になる snapshot。over で一部だけ差し替える */
function snapshot(over) {
  const o = over || {};
  return {
    config: parseConfig(o.config || CONFIG),
    detail: parseDetail(o.detail || DETAIL),
    items: o.items || ITEMS,
    employees: parseEmployees(o.employees || EMPLOYEES, o.edition || "paid"),
    records: parseLedger([LEDGER_HEADERS].concat((o.records || []).map(ledgerRow))),
    sharing: o.sharing || "restricted",
    importedMonth: "importedMonth" in o ? o.importedMonth : "2026-10",
    edition: o.edition || "paid",
  };
}

function statusOf(results, no) {
  return results.find((entry) => entry.no === no);
}

test("すべてそろっていれば 11 項目とも OK で、止めない", () => {
  const results = runChecks(snapshot());
  assert.equal(results.length, 11);
  assert.deepEqual(results.map((r) => r.no), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);
  assert.deepEqual(results.filter((r) => r.status !== "OK"), []);
  assert.equal(isBlocked(results), false);
  assert.ok(checkSummary(results).includes("要確認はありません"));
});

test("1. 社員シートに無い社員番号 → 要確認。明細が空も要確認", () => {
  const detail = DETAIL.concat([["1009", "見本 九郎", 1, 1]]);
  const entry = statusOf(runChecks(snapshot({ detail })), 1);
  assert.equal(entry.status, "要確認");
  assert.ok(entry.fix.includes("1009 見本 九郎"));
  assert.equal(statusOf(runChecks(snapshot({ detail: [DETAIL[0]] })), 1).status, "要確認");
});

test("2. メールが空・形が違う、渡し方の書き間違い → 要確認", () => {
  const employees = [EMPLOYEES[0], ["1001", "見本 一郎", "ichiro@", "共有", "2026/09/01", ""], ["1002", "見本 花子", "hanako@example.com", "手渡し", "2026/09/01", ""]];
  const entry = statusOf(runChecks(snapshot({ employees })), 2);
  assert.equal(entry.status, "要確認");
  assert.equal(entry.count, 2);
  assert.ok(entry.fix.includes("「渡し方」は「共有」か「添付」"));
});

test("3. 同じメールが 2 人 → 要確認（大文字小文字は同じとみなす）", () => {
  const employees = [EMPLOYEES[0], EMPLOYEES[1], ["1002", "見本 花子", "ICHIRO@example.com", "", "2026/09/01", ""]];
  const entry = statusOf(runChecks(snapshot({ employees })), 3);
  assert.equal(entry.status, "要確認");
  assert.ok(entry.fix.includes("見本 一郎 ichiro@example.com・見本 花子 ichiro@example.com"));
});

test("4. 同じ社員番号が明細に 2 行 → 要確認", () => {
  const detail = DETAIL.concat([["01001", "見本 一郎", 1, 1]]);
  assert.equal(statusOf(runChecks(snapshot({ detail })), 4).status, "要確認");
});

test("5. 合計の列が無い・空・マイナス → 要確認", () => {
  const noTotal = runChecks(snapshot({ items: [ITEMS[0], Object.assign({}, ITEMS[1], { category: "支給" })] }));
  assert.equal(statusOf(noTotal, 5).status, "要確認");
  const detail = [DETAIL[0], ["1001", "見本 一郎", 1, ""], ["1002", "見本 花子", 1, -5]];
  const entry = statusOf(runChecks(snapshot({ detail })), 5);
  assert.equal(entry.status, "要確認");
  assert.equal(entry.count, 2);
});

test("6. 区分が空・書き間違い → 要確認。明細に無い見出しは見ない", () => {
  const items = ITEMS.concat([{ header: "なぞ", category: "", order: 3, label: "なぞ" }]);
  assert.equal(statusOf(runChecks(snapshot({ items })), 6).status, "OK", "明細に無い見出し");
  const detail = [DETAIL[0].concat(["なぞ"]), DETAIL[1].concat([1]), DETAIL[2].concat([1])];
  assert.equal(statusOf(runChecks(snapshot({ items, detail })), 6).status, "要確認");
  const typo = [ITEMS[0], Object.assign({}, ITEMS[1], { category: "ごうけい" })];
  assert.equal(statusOf(runChecks(snapshot({ items: typo })), 6).status, "要確認");
});

test("7. 対象月・支給日が無い、読めない → 要確認", () => {
  const entry = statusOf(runChecks(snapshot({ config: [["対象月", "来月"]] })), 7);
  assert.equal(entry.status, "要確認");
  assert.ok(entry.fix.includes("「来月」は読めません"));
  assert.ok(entry.fix.includes("支給日"));
});

test("8. 同意日が空の人は「お知らせ」（紙で渡す人）。止めない。無料版は OK", () => {
  const employees = [EMPLOYEES[0], EMPLOYEES[1], ["1002", "見本 花子", "hanako@example.com", "", "", ""]];
  const results = runChecks(snapshot({ employees }));
  const entry = statusOf(results, 8);
  assert.equal(entry.status, "お知らせ");
  assert.ok(entry.fix.includes("見本 花子"));
  assert.equal(isBlocked(results), false);
  const free = [["社員番号", "氏名", "メール", "渡し方", "在籍"], ["1001", "見本 一郎", "ichiro@example.com", "", ""], ["1002", "見本 花子", "hanako@example.com", "", ""]];
  assert.equal(statusOf(runChecks(snapshot({ employees: free, edition: "free" })), 8).status, "OK");
});

test("9. 退職の人が明細にいる → 要確認", () => {
  const employees = [EMPLOYEES[0], EMPLOYEES[1], ["1002", "見本 花子", "hanako@example.com", "", "2026/09/01", "退職"]];
  assert.equal(statusOf(runChecks(snapshot({ employees })), 9).status, "要確認");
});

test("10. 送った人は「お知らせ」、送信中のまま残った行は要確認。ほかの月の記録は見ない", () => {
  const sent = { key: keyOf("2026-10", "1001", "給与明細"), month: "2026-10", title: "給与明細", id: "1001", name: "見本 一郎", status: "送信済み", version: 1 };
  const results = runChecks(snapshot({ records: [sent] }));
  assert.equal(statusOf(results, 10).status, "お知らせ");
  assert.ok(statusOf(results, 10).fix.includes("見本 一郎"));
  const stuck = Object.assign({}, sent, { status: "送信中" });
  assert.equal(statusOf(runChecks(snapshot({ records: [stuck] })), 10).status, "要確認");
  const other = Object.assign({}, stuck, { month: "2026-09" });
  assert.equal(statusOf(runChecks(snapshot({ records: [other] })), 10).status, "OK");
});

test("11. リンクを知っている全員に共有 → 要確認。自動で確かめられなければ、目で確かめた日が要る", () => {
  assert.equal(statusOf(runChecks(snapshot({ sharing: "anyone" })), 11).status, "要確認");
  assert.equal(statusOf(runChecks(snapshot({ sharing: "unknown" })), 11).status, "要確認", "I6: 読めず、目で確かめた日も無ければ止める");
  assert.equal(statusOf(runChecks(snapshot({ sharing: "unknown", config: CONFIG.concat([["共有範囲を確かめた日", "2026/10/23"]]) })), 11).status, "OK");
});

test("確かめるシートの行と、止めるときの 1 通", () => {
  const results = runChecks(snapshot({ sharing: "anyone" }));
  const rows = checkSheetRows(results);
  assert.deepEqual(rows[0], ["項目", "件数", "状態", "直し方・名前"]);
  assert.equal(rows.length, 12);
  assert.ok(checkSummary(results).startsWith("要確認が 1 項目あります"));
  assert.equal(delimit(["a", "b", "c"], 2), "a、b ほか 1 件");
});

test("C2: 1. 明細の氏名と社員シートの氏名が違えば要確認（空白・全角半角はそろえる。どちらかが空なら比べない）", () => {
  assert.equal(statusOf(runChecks(snapshot({ detail: [DETAIL[0], ["1001", "見本　一郎", 1, 1], ["1002", "ﾐﾎﾝ ﾊﾅｺ", 1, 1]], employees: [EMPLOYEES[0], EMPLOYEES[1], ["1002", "ミホンハナコ", "hanako@example.com", "", "2026/09/01", ""]] })), 1).status, "OK");
  assert.equal(statusOf(runChecks(snapshot({ detail: [DETAIL[0], ["1001", "", 1, 1], DETAIL[2]] })), 1).status, "OK");
  const entry = statusOf(runChecks(snapshot({ detail: [DETAIL[0], ["1001", "見本 佐藤", 1, 1], DETAIL[2]] })), 1);
  assert.equal(entry.status, "要確認");
  assert.ok(entry.fix.includes("1001: 明細は見本 佐藤、社員シートは見本 一郎"));
});

test("C2: 4. 社員シートに同じ社員番号（0123 と 123 も同じ）が 2 行あれば要確認", () => {
  const employees = EMPLOYEES.concat([["01001", "見本 佐藤", "sato@example.com", "", "2026/09/01", ""]]);
  const entry = statusOf(runChecks(snapshot({ employees })), 4);
  assert.equal(entry.status, "要確認");
  assert.ok(entry.fix.includes("「社員」シートに同じ社員番号"));
});

test("I2: 3. +付き・Gmail の点・googlemail.com・見えない字も同じ受信箱とみなす", async () => {
  const { isEmail, mailKey } = await import("../src/employees.js");
  assert.equal(mailKey("Taro+pay@Gmail.com"), "taro@gmail.com");
  assert.equal(mailKey("t.a.ro@googlemail.com"), "taro@gmail.com");
  assert.equal(mailKey("t.aro@example.com"), "t.aro@example.com", "Gmail 以外の点は落とさない");
  assert.equal(mailKey("taro\u200B@example.com"), "taro@example.com");
  assert.equal(isEmail("taro\u200B@example.com"), false);
  const employees = [EMPLOYEES[0], EMPLOYEES[1].slice(0, 2).concat(["ichiro@gmail.com", "", "2026/09/01", ""]), ["1002", "見本 花子", "i.chiro+kyuyo@gmail.com", "", "2026/09/01", ""]];
  assert.equal(statusOf(runChecks(snapshot({ employees })), 3).status, "要確認");
});

test("I3: 10. 同じ月に別の題で送った記録があれば止める。「同じ月の別の題を送る」が「する」なら通す", () => {
  const other = { key: keyOf("2026-10", "1001", "給与明細書"), month: "2026-10", title: "給与明細書", id: "1001", name: "見本 一郎", status: "送信済み", version: 1 };
  const entry = statusOf(runChecks(snapshot({ records: [other] })), 10);
  assert.equal(entry.status, "要確認");
  assert.ok(entry.fix.includes("「給与明細書」の題で送っています"));
  assert.equal(statusOf(runChecks(snapshot({ records: [other], config: CONFIG.concat([["同じ月の別の題を送る", "する"]]) })), 10).status, "OK");
});

test("I8: 7. 明細を取り込んだときの対象月が設定と違う・分からなければ止める", () => {
  assert.equal(statusOf(runChecks(snapshot({ importedMonth: "2026-09" })), 7).status, "要確認");
  assert.ok(statusOf(runChecks(snapshot({ importedMonth: "2026-09" })), 7).fix.includes("明細は対象月が 2026-09 のときに取り込んだもの"));
  assert.equal(statusOf(runChecks(snapshot({ importedMonth: null })), 7).status, "要確認");
});
