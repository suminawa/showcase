import { test } from "node:test";
import assert from "node:assert/strict";
import { afterShareFailure, decideDelivery, planDelivery } from "../src/delivery.js";
import { employeeHeaders, isEmail, parseEmployees } from "../src/employees.js";
import { canDeliver, limitPeople } from "../src/edition.js";
import { keyOf, LEDGER_HEADERS, ledgerRow, parseLedger } from "../src/ledger.js";

const SHEET = [
  ["社員番号", "氏名", "メール", "渡し方", "電子交付の同意日", "在籍"],
  ["1001", "見本 一郎", "Ichiro@Example.com", "共有", new Date(2026, 8, 1), "在籍"],
  ["1002", "見本 花子", "hanako@example.com", "添付", "2026/09/01", ""],
  ["1003", "見本 健太", "kenta@example.com", "", "", "在籍"],
  ["1004", "見本 美咲", "misaki@example.com", "共有", "2026/09/01", "退職"],
  ["", "（空行）", "", "", "", ""],
];

test("社員シート: 見出しで列を探す。メールは小文字、渡し方の空は共有、在籍の空は在籍", () => {
  const employees = parseEmployees(SHEET, "paid");
  assert.equal(employees.length, 4);
  assert.equal(employees[0].email, "ichiro@example.com");
  assert.equal(employees[1].method, "添付");
  assert.equal(employees[2].method, "共有");
  assert.equal(employees[1].active, true);
  assert.equal(employees[3].active, false);
  assert.equal(employees[0].consent, true);
  assert.equal(employees[2].consent, false);
});

test("メールの形", () => {
  assert.equal(isEmail("a@example.com"), true);
  for (const bad of ["", "a@", "a@example", "a b@example.com", "a@example.com,b@example.com", "見本"]) assert.equal(isEmail(bad), false, bad);
});

test("渡し方の決定: 退職・社員シートに無い → 送らない、同意なし → 紙、ほかは社員シートどおり", () => {
  const employees = parseEmployees(SHEET, "paid");
  assert.deepEqual(decideDelivery(employees[0]), { method: "共有", reason: "" });
  assert.equal(decideDelivery(employees[1]).method, "添付");
  assert.equal(decideDelivery(employees[2]).method, "紙");
  assert.deepEqual(decideDelivery(employees[3]), { method: "送らない", reason: "退職" });
  assert.equal(decideDelivery(undefined).method, "送らない");
});

test("共有に失敗したら添付に切り替え、記録に「添付に切替」と残す", () => {
  const next = afterShareFailure(new Error("Invalid sharing request"));
  assert.equal(next.method, "添付");
  assert.ok(next.memo.startsWith("添付に切替"));
});

test("配る計画: 送る人・紙・送らない・送った人に分ける", () => {
  const employees = parseEmployees(SHEET, "paid");
  const config = { month: { key: "2026-10" }, title: "給与明細" };
  const people = ["1001", "1002", "1003", "1004", "1005"].map((id) => ({ id: id, key: id, name: "", values: {} }));
  const records = parseLedger([LEDGER_HEADERS, ledgerRow({ key: keyOf("2026-10", "1002", "給与明細"), status: "送信済み", version: 1 })]);
  const plan = planDelivery(people, employees, records, config);
  assert.deepEqual(plan.targets.map((t) => [t.person.id, t.method, t.name]), [["1001", "共有", "見本 一郎"]]);
  assert.deepEqual(plan.alreadySent.map((t) => t.person.id), ["1002"]);
  assert.deepEqual(plan.paper.map((t) => t.name), ["見本 健太"]);
  assert.deepEqual(plan.skipped.map((t) => [t.person.id, t.reason]), [["1004", "退職"], ["1005", "社員シートにありません"]]);
});

test("無料版: 同意の列は無く、同意ありとみなす。3 人で切り、配るは止める", () => {
  assert.deepEqual(employeeHeaders("free"), ["社員番号", "氏名", "メール", "渡し方", "在籍"]);
  assert.equal(employeeHeaders("paid").length, 6);
  const free = parseEmployees([employeeHeaders("free"), ["1", "見本 一郎", "a@example.com", "", ""]], "free");
  assert.equal(free[0].consent, true);
  assert.deepEqual(limitPeople([1, 2, 3, 4, 5], "free"), { rows: [1, 2, 3], cut: 2 });
  assert.deepEqual(limitPeople([1, 2, 3, 4, 5], "paid"), { rows: [1, 2, 3, 4, 5], cut: 0 });
  assert.equal(canDeliver("free"), false);
  assert.equal(canDeliver("paid"), true);
});

test("試し送りの指紋: 宛先や金額が変われば変わり、同じなら同じ", async () => {
  const { deliveryFingerprint } = await import("../src/delivery.js");
  const employees = parseEmployees(SHEET, "paid");
  const config = { company: "c", title: "給与明細", month: { key: "2026-10" }, payday: "x", note: "", showZero: false, senderName: "c", subject: "s", body: "b" };
  const rows = [["社員番号", "氏名", "差引支給額"], ["1001", "見本 一郎", 1]];
  const items = [{ header: "差引支給額", category: "合計", order: 1, label: "差引支給額" }];
  const base = deliveryFingerprint(rows, items, employees, config);
  assert.equal(deliveryFingerprint(rows, items, employees, Object.assign({}, config)), base);
  assert.notEqual(deliveryFingerprint([rows[0], ["1001", "見本 一郎", 2]], items, employees, config), base);
  const moved = employees.map((e, i) => (i === 0 ? Object.assign({}, e, { email: "other@example.com" }) : e));
  assert.notEqual(deliveryFingerprint(rows, items, moved, config), base);
});
