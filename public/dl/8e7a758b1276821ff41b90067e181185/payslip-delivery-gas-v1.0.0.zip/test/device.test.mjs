// 本物の GAS（実機）で分かったことの検査。2026-10-23 の実機の通しで見つかった 6 点
import { test } from "node:test";
import assert from "node:assert/strict";
import { initReport, planInit } from "../src/setup.js";
import { plainText } from "../src/text.js";
import { put, runKit, sample } from "./helpers.mjs";

function ready(options) {
  const kit = runKit(options);
  kit.g.initializeKit();
  put(kit, "社員", sample("employees-sample.csv"));
  put(kit, "貼り付け", sample("payroll-2026-10.csv"));
  for (const row of kit.sheets["設定"].rows) {
    if (row[0] === "会社名") row[1] = "見本商事株式会社";
    if (row[0] === "対象月") row[1] = "2026-10";
    if (row[0] === "支給日") row[1] = "2026年10月23日";
  }
  return kit;
}

/** 作業用に複製して差し込んだドキュメント（PDF の元）の中身 */
function workingDocs(kit) {
  return Object.keys(kit.files).filter((id) => String(kit.files[id].name).startsWith("作業中_")).map((id) => kit.docs.models[id]);
}

/**
 * 1 ページの高さのおおよその見積もり（pt）。字のある段落 24、小さくした空の段落 6、ふつうの空の段落 16、
 * 表の 1 行は 字の大きさ × 1.3 + 上下の余白 + 罫線 1（字の大きさの既定は 11、余白の既定は 5）
 */
function estimateHeight(model) {
  let height = 0;
  for (const block of model.blocks) {
    if (block.type === "t") {
      const size = block.fontSize || 11;
      const padding = block.padding === undefined ? 5 : block.padding;
      height += block.rows.length * (size * 1.3 + padding * 2 + 1);
    } else if (block.text !== "") height += 24;
    else height += block.attrs && block.attrs.FONT_SIZE <= 4 ? 6 : 16;
  }
  return height;
}

test("実機 1: 明細は 1 ページに収まる。表は 10pt・余白は小さく、空の段落は小さく、空の {{備考}} の段落は消す", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  const docs = workingDocs(kit);
  assert.equal(docs.length, 8);
  const tallest = Math.max(...docs.map(estimateHeight));
  // A4 の高さ 841.89 から上下の余白を引いた残り（余白 40 + 40）より、ゆとりを持って低い
  assert.ok(tallest <= 700, "見積もりの高さ " + tallest);
  for (const model of docs) {
    assert.equal(model.blocks.some((b) => b.type === "p" && b.text.includes("{{備考}}")), false);
    for (const block of model.blocks) {
      if (block.type === "t") assert.equal(block.fontSize, 10);
      if (block.type === "p" && block.text === "") assert.ok(block.attrs && block.attrs.FONT_SIZE <= 4, "ふつうの大きさの空の段落が残っている");
    }
  }
});

test("実機 1: {{備考}} に字があれば、その段落は残す", () => {
  const kit = ready();
  kit.sheets["設定"].rows.find((r) => r[0] === "備考")[1] = "年末調整の書類は 11 月 10 日までにお出しください。";
  kit.g.importPayroll();
  kit.g.sendTrial();
  assert.ok(workingDocs(kit)[0].blocks.some((b) => b.type === "p" && b.text.startsWith("年末調整の書類")));
});

test("実機 2: Drive の一時的な失敗（Internal Error）は、間を空けて 3 回まで繰り返す", () => {
  const kit = ready({ failCopy: 2 });
  kit.g.importPayroll();
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("試し送りを送りました"));
  assert.ok(kit.options.slept > 0, "間を空けている");
});

test("実機 2: 一時的でない失敗（見つからない）は繰り返さない", () => {
  const kit = ready({ failCopy: 1, copyError: "API call to drive.files.copy failed with error: File not found: T" });
  kit.g.importPayroll();
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("File not found"));
  assert.equal(kit.options.slept || 0, 0);
});

test("実機 2: 試し送りの途中で止まっても、作り終えた PDF は捨てずに続きから作る", () => {
  const kit = ready();
  kit.g.importPayroll();
  const real = kit.g.Drive.Files.copy;
  let calls = 0;
  kit.g.Drive.Files.copy = (...args) => {
    calls += 1;
    if (calls >= 4 && calls <= 6) throw new Error("API call to drive.files.copy failed with error: Internal Error");
    return real(...args);
  };
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("Internal Error"));
  kit.g.Drive.Files.copy = real;
  const before = kit.options.copies || 0;
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("試し送りを送りました"));
  assert.equal((kit.options.copies || 0) - before, 5, "3 人分は作り直さない");
});

test("実機 3: 試し送りは時間で打ち切って続きから作り、全員分がそろってから自分あてに 1 通。配るは試し送りの PDF をそのまま使う", () => {
  const kit = ready();
  kit.g.importPayroll();
  const RealDate = Date;
  let clock = RealDate.now();
  kit.g.Date = class extends RealDate {
    static now() {
      clock += 100000;
      return clock;
    }
  };
  kit.g.sendTrial();
  kit.g.Date = RealDate;
  const first = kit.alerts.pop();
  assert.ok(first.includes("もう一度「試し送り」を押すと続きを作ります"), first);
  assert.equal(kit.mails.length, 0, "そろうまでは送らない");
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("試し送りを送りました（8 人分の PDF）"));
  assert.equal(kit.mails.length, 1);
  const pdfLinks = kit.mails[0].body.match(/https:\/\/drive\.google\.com\/file\/d\/[^/\s]+\/view/g) || [];
  assert.equal(pdfLinks.length, 8, kit.mails[0].body);
  const before = kit.options.copies;
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("を 7 人に送りました"));
  assert.equal(kit.options.copies - before, 1, "作り直すのは添付の 1 人だけ（共有は試し送りの PDF）");
});

test("実機 4: 雛形の有無を確かめる呼び出しが一時的でない形で落ちても、雛形を作り直さない", () => {
  const kit = runKit();
  kit.g.initializeKit();
  const templates = () => Object.values(kit.files).filter((f) => f.name === "給与明細の雛形").length;
  assert.equal(templates(), 1);
  kit.g.Drive.Files.get = () => {
    throw new Error("API call to drive.files.get failed with error: Insufficient Permission");
  };
  kit.g.initializeKit();
  assert.ok(kit.alerts.pop().includes("Insufficient Permission"));
  assert.equal(templates(), 1);
});

test("実機 4: 初期化はロックの中で動く。ほかの初期化が動いていれば、雛形を作らない", () => {
  const kit = runKit();
  kit.g.LockService = { getScriptLock: () => ({ tryLock: () => false, releaseLock: () => {} }) };
  kit.g.initializeKit();
  assert.ok(kit.alerts.pop().includes("ほかの操作"));
  assert.equal(Object.values(kit.files).filter((f) => f.name === "給与明細の雛形").length, 0);
});

test("実機 5: 24 時間を越える時刻も [h]:mm にそろえる（25:00:00 → 25:00）", () => {
  assert.equal(plainText("25:00:00"), "25:00");
  assert.equal(plainText("12:00:00"), "12:00");
  assert.equal(plainText("0:00"), "0:00");
  assert.equal(plainText(new Date(1899, 11, 31, 1, 0, 0)), "25:00");
  assert.equal(plainText("2026/10/23"), "2026/10/23", "時刻でない字はそのまま");
});

test("実機 6: 初期化の完了の画面に URL を出さず、雛形の場所を名前で案内する", () => {
  const text = initReport(planInit({}, "paid"), { created: true, folderName: "給与明細 配布キット", url: "https://docs.google.com/document/d/T/edit" });
  assert.equal(text.includes("https://"), false);
  assert.ok(text.includes("ドライブの「給与明細 配布キット」フォルダの「給与明細の雛形」"));
});
