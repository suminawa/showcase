import { test } from "node:test";
import assert from "node:assert/strict";
import { cellText, fingerprint, idKey, normalizeHeader } from "../src/text.js";
import { formatAmount, parseAmount } from "../src/amount.js";

test("セルの字: 全角英数を半角に、前後の空白と全角スペースを落とす。null は空", () => {
  assert.equal(cellText("　ＡＢＣ１２３ "), "ABC123");
  assert.equal(cellText(null), "");
  assert.equal(cellText(1001), "1001");
});

test("見出しのゆれ: 改行・全角スペース・続く空白を 1 つの半角空白に", () => {
  assert.equal(normalizeHeader(" 基本\n給 "), "基本 給");
  assert.equal(normalizeHeader("支給　　基本給"), "支給 基本給");
  assert.equal(normalizeHeader("ｻﾝﾌﾟﾙ"), "サンプル");
});

test("社員番号の鍵: 数字だけなら先頭の 0 を落とす（1001 と ００１００１ を同じ人に）", () => {
  assert.equal(idKey("００１００１"), "1001");
  assert.equal(idKey(1001), "1001");
  assert.equal(idKey(" A-01 "), "A-01");
  assert.equal(idKey("0"), "0");
  assert.equal(idKey(""), "");
});

test("指紋: 同じ中身なら同じ、1 字でも違えば違う", () => {
  assert.equal(fingerprint([["a", 1]]), fingerprint([["a", 1]]));
  assert.notEqual(fingerprint([["a", 1]]), fingerprint([["a", 2]]));
  assert.match(fingerprint("x"), /^[0-9a-f]{8}$/);
});

test("金額: 全角・円・カンマ・全角カンマ・空白・△▲・マイナスを数に", () => {
  assert.equal(parseAmount("１２，３４５円"), 12345);
  assert.equal(parseAmount(" 250,000 "), 250000);
  assert.equal(parseAmount("△3,000"), -3000);
  assert.equal(parseAmount("▲ 500円"), -500);
  assert.equal(parseAmount("-1,234"), -1234);
  assert.equal(parseAmount("−1,234"), -1234);
  assert.equal(parseAmount("¥8,000"), 8000);
  assert.equal(parseAmount(4200), 4200);
  assert.equal(parseAmount("0"), 0);
});

test("金額: 空は null、読めない字は NaN", () => {
  assert.equal(parseAmount(""), null);
  assert.equal(parseAmount(null), null);
  assert.equal(parseAmount("　"), null);
  assert.ok(Number.isNaN(parseAmount("未定")));
  assert.ok(Number.isNaN(parseAmount("1,2,3x")));
});

test("金額の書式: 3 桁区切り、マイナスは -1,234", () => {
  assert.equal(formatAmount(1234567), "1,234,567");
  assert.equal(formatAmount(-1234), "-1,234");
  assert.equal(formatAmount(0), "0");
  assert.equal(formatAmount(999), "999");
  assert.equal(formatAmount(1234.5), "1,234.5");
  assert.equal(formatAmount(null), "");
});

test("時刻に読み替えられた勤怠（12:30・25:00）を字に戻す", async () => {
  const { plainText } = await import("../src/text.js");
  assert.equal(plainText(new Date(1899, 11, 30, 12, 30)), "12:30");
  assert.equal(plainText(new Date(1899, 11, 31, 1, 0)), "25:00");
  assert.equal(plainText(new Date(2026, 9, 25)), "2026/10/25");
  assert.equal(plainText("２０"), "20");
});
