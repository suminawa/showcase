// 検査の共通の部品: 見本 CSV の読み取りと、GAS の偽物を並べた入れ物（つないだ Code.gs をそのまま動かす）。
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";
import { buildSource } from "../scripts/build.mjs";

export const root = join(dirname(fileURLToPath(import.meta.url)), "..");

export function read(name) {
  return readFileSync(join(root, name), "utf8");
}

/** CSV を行と列に割る（"..." の中のカンマ・改行は区切りにしない） */
export function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

export function sample(name) {
  return rowsOf(read("samples/" + name));
}

function chain(target) {
  return new Proxy(target, { get: (t, key) => (key in t ? t[key] : () => chain(t)) });
}

function fakeSheet(name, o) {
  const rows = [];
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const range = (r, c, h, w) =>
    chain({
      setValues(values) {
        // 送信記録の書き換え（行 2 から下）を、決めた回数だけ失敗させる（Sheets の一時的なエラーの代わり）
        if (name === "送信記録" && r > 1 && o.failLedgerWrites > 0) {
          o.failLedgerWrites -= 1;
          throw new Error("Service Spreadsheets timed out");
        }
        for (let i = 0; i < h; i += 1) {
          while (rows.length < r + i) rows.push([]);
          for (let j = 0; j < w; j += 1) rows[r - 1 + i][c - 1 + j] = values[i][j];
        }
        return range(r, c, h, w);
      },
    });
  return chain({
    rows: rows,
    getLastRow: () => rows.length,
    getLastColumn: width,
    getMaxColumns: () => Math.max(26, width()),
    clear: () => {
      rows.length = 0;
    },
    getDataRange: () => ({ getValues: () => rows.map((row) => Array.from({ length: width() }, (_, c) => (row[c] === undefined ? "" : row[c]))) }),
    getRange: (a, b, h, w) => (typeof a === "string" ? chain({}) : range(a, b, h || 1, w || 1)),
    appendRow: (values) => {
      rows.push(values.slice());
    },
  });
}

/**
 * ドキュメントの偽物。段落（字と属性）と表（行 = セルの字の配列、字の大きさ、セルの余白）だけを持つ。
 * getAs は中身の字を Blob にする。本物と同じく、文書の最後の段落は消せない
 */
function fakeDocs() {
  const models = {};
  const blob = (content, type) => ({ content: content, type: type, name: "", setName(n) { this.name = n; return this; }, getName() { return this.name; } });
  const rowApi = (block, cells) => chain({
    __cells: cells,
    getText: () => cells.join(""),
    getCell: (j) => chain({
      getText: () => cells[j],
      setPaddingTop: (n) => { block.padding = n; },
      setPaddingBottom: (n) => { block.padding = n; },
    }),
    copy: () => rowApi(block, cells.slice()),
    replaceText: (pattern, value) => {
      for (let j = 0; j < cells.length; j += 1) cells[j] = cells[j].replace(new RegExp(pattern, "g"), () => value);
    },
  });
  const tableApi = (block) => chain({
    getType: () => "TABLE",
    getNumRows: () => block.rows.length,
    getRow: (i) => rowApi(block, block.rows[i]),
    insertTableRow: (i, row) => {
      block.rows.splice(i, 0, row.__cells);
      return rowApi(block, row.__cells);
    },
    removeRow: (i) => {
      block.rows.splice(i, 1);
    },
    editAsText: () => chain({ setFontSize: (n) => { block.fontSize = n; } }),
  });
  const paraApi = (model, block) => {
    const api = chain({
      getType: () => "PARAGRAPH",
      asParagraph: () => api,
      getText: () => block.text,
      setText: (t) => { block.text = t; return undefined; } /* 本物の Paragraph.setText は void */,
      setAttributes: (attrs) => { block.attrs = Object.assign({}, block.attrs, attrs); return api; },
      setSpacingBefore: (n) => { block.before = n; return api; },
      setSpacingAfter: (n) => { block.after = n; return api; },
      removeFromParent: () => {
        const at = model.blocks.indexOf(block);
        if (at === model.blocks.length - 1) throw new Error("Can't remove the last paragraph in a document section.");
        model.blocks.splice(at, 1);
        return api;
      },
    });
    return api;
  };
  const api = (id) => {
    const model = models[id];
    if (!model) throw new Error("No document " + id);
    const wrap = (b) => (b.type === "p" ? paraApi(model, b) : tableApi(b));
    const body = chain({
      setPageWidth: (w) => { model.width = w; return body; },
      setPageHeight: (h) => { model.height = h; return body; },
      clear: () => { model.blocks = [{ type: "p", text: "" }]; },
      getParagraphs: () => model.blocks.filter((b) => b.type === "p").map((b) => paraApi(model, b)),
      getNumChildren: () => model.blocks.length,
      getChild: (i) => wrap(model.blocks[i]),
      appendParagraph: (t) => { const b = { type: "p", text: t }; model.blocks.push(b); return paraApi(model, b); },
      appendTable: (cells) => { const b = { type: "t", rows: cells.map((r) => r.slice()) }; model.blocks.push(b); return tableApi(b); },
      getTables: () => model.blocks.filter((b) => b.type === "t").map(tableApi),
      replaceText: (pattern, value) => {
        const re = new RegExp(pattern, "g");
        for (const b of model.blocks) {
          if (b.type === "p") b.text = b.text.replace(re, () => value);
          else for (const r of b.rows) for (let j = 0; j < r.length; j += 1) r[j] = r[j].replace(re, () => value);
        }
      },
    });
    return {
      getBody: () => body,
      getHeader: () => null,
      getFooter: () => null,
      saveAndClose: () => {},
      getAs: (type) => {
        if (o_.failGetAs > 0) {
          o_.failGetAs -= 1;
          throw new Error("Service Documents failed while accessing document");
        }
        return blob(model.blocks.map((b) => (b.type === "p" ? b.text : b.rows.map((r) => r.join(" | ")).join("\n"))).join("\n") + "\n[A4 " + model.width + "x" + model.height + "]", type);
      },
    };
  };
  let o_ = {};
  return { models: models, api: api, bind: (o) => { o_ = o; } };
}

/**
 * つないだ Code.gs を偽物の GAS で動かす。返り値の g から入口の関数を呼ぶ。
 * options: { edition, quota, noGoogle: [アドレス], sharing: "anyone" | "restricted" | "throw", prompts: [字], answers: ["YES" | "NO"],
 *            failMail: [1 回だけ送信に失敗する宛先], failLedgerWrites: 送信記録の書き換えを失敗させる回数,
 *            failCopy / failGetAs: Drive の複製・PDF への書き出しを失敗させる回数（copyError がその文） }
 */
export function runKit(options) {
  const o = Object.assign({ edition: "paid", quota: 100, noGoogle: [], sharing: "restricted", prompts: [], answers: [], failMail: [], failLedgerWrites: 0, failCopy: 0, failGetAs: 0, copyError: "API call to drive.files.copy failed with error: Internal Error" }, options);
  const sheets = {};
  const book = chain({
    getSheetByName: (name) => sheets[name] || null,
    insertSheet: (name) => (sheets[name] = fakeSheet(name, o)),
    getId: () => "SS1",
  });
  const alerts = [];
  const mails = [];
  const triggers = [];
  const files = {};
  let counter = 0;
  const docs = fakeDocs();
  docs.bind(o);
  const props = {};
  const ui = {
    alert: (a, b) => {
      alerts.push(b === undefined ? a : a + "\n" + b);
      return b === undefined ? "OK" : o.answers.shift() || "YES";
    },
    prompt: () => {
      const text = o.prompts.shift();
      return { getSelectedButton: () => "OK", getResponseText: () => text };
    },
    ButtonSet: { YES_NO: "YES_NO", OK_CANCEL: "OK_CANCEL" },
    Button: { YES: "YES", NO: "NO", OK: "OK" },
    createMenu: () => chain({}),
  };
  const newId = (prefix) => prefix + (counter += 1);
  const Drive = {
    Files: {
      create: (resource, media) => {
        const id = newId("F");
        files[id] = Object.assign({ trashed: false, permissions: [], blob: media || null }, resource);
        if (resource.mimeType === "application/vnd.google-apps.document") docs.models[id] = { blocks: [{ type: "p", text: "" }] };
        return { id: id };
      },
      copy: (resource, source) => {
        o.copies = (o.copies || 0) + 1;
        if (o.failCopy > 0) {
          o.failCopy -= 1;
          throw new Error(o.copyError);
        }
        const id = newId("F");
        files[id] = Object.assign({ trashed: false, permissions: [] }, resource);
        docs.models[id] = JSON.parse(JSON.stringify(docs.models[source]));
        return { id: id };
      },
      get: (id) => {
        if (!files[id]) throw new Error("File not found: " + id);
        return { id: id, trashed: files[id].trashed };
      },
      update: (resource, id) => Object.assign(files[id], resource),
    },
    Permissions: {
      create: (resource, fileId, optional) => {
        if (!optional || optional.sendNotificationEmail !== false) throw new Error("通知メールを止めていない");
        if (o.noGoogle.indexOf(resource.emailAddress) >= 0) throw new Error("Bad Request: the user does not have a Google account");
        const id = newId("P");
        files[fileId].permissions.push(Object.assign({ id: id }, resource));
        return { id: id };
      },
      remove: (fileId, permissionId) => {
        const list = files[fileId].permissions;
        const at = list.findIndex((p) => p.id === permissionId);
        if (at < 0) throw new Error("Permission not found: " + permissionId);
        list.splice(at, 1);
      },
      list: () => {
        if (o.sharing === "throw") throw new Error("Insufficient permissions");
        return { permissions: [{ type: "user" }].concat(o.sharing === "anyone" ? [{ type: "anyone" }] : []) };
      },
    },
  };
  const context = createContext({
    SpreadsheetApp: { getActiveSpreadsheet: () => book, getUi: () => ui, flush: () => {} },
    DocumentApp: {
      openById: docs.api,
      HorizontalAlignment: {},
      ParagraphHeading: {},
      ElementType: { PARAGRAPH: "PARAGRAPH", TABLE: "TABLE" },
      Attribute: { FONT_SIZE: "FONT_SIZE", SPACING_BEFORE: "SPACING_BEFORE", SPACING_AFTER: "SPACING_AFTER", LINE_SPACING: "LINE_SPACING" },
    },
    Utilities: { sleep: (ms) => { o.slept = (o.slept || 0) + ms; } },
    Drive: Drive,
    MailApp: {
      sendEmail: (message) => {
        // failMail に載せた宛先は 1 回だけ失敗させる
        const at = o.failMail.indexOf(message.to);
        if (at >= 0) {
          o.failMail.splice(at, 1);
          throw new Error("Service invoked too many times for one day: email.");
        }
        mails.push(message);
        o.quota -= 1;
      },
      getRemainingDailyQuota: () => o.quota,
    },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {} }) },
    PropertiesService: { getDocumentProperties: () => ({ getProperty: (k) => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = String(v); } }) },
    ScriptApp: {
      getProjectTriggers: () => triggers.slice(),
      deleteTrigger: (t) => triggers.splice(triggers.indexOf(t), 1),
      newTrigger: (name) => chain({ create: () => triggers.push({ getHandlerFunction: () => name }) }),
    },
    Session: { getEffectiveUser: () => ({ getEmail: () => "owner@example.com" }) },
    Logger: { log: () => {} },
    Date: Date,
    JSON: JSON,
  });
  runInContext(buildSource(root, o.edition), context);
  return { g: context, sheets, alerts, mails, triggers, files, docs, props, options: o };
}

/** シートに値を書く（見本の読み込みの代わり） */
export function put(kit, name, rows) {
  const sheet = kit.sheets[name];
  sheet.clear();
  for (const row of rows) sheet.appendRow(row);
}
