import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_ROWS } from "../src/config.js";
import { initReport, planInit, sheetSpecs } from "../src/setup.js";

test("空のブックには 7 枚を作る。設定は既定の行入り", () => {
  const plan = planInit({}, "paid");
  assert.deepEqual(plan.create.map((entry) => entry.name), ["設定", "社員", "項目", "貼り付け", "明細", "確かめる", "送信記録"]);
  assert.equal(plan.create[0].rows.length, 1 + DEFAULT_ROWS.length);
  assert.ok(initReport(plan, { created: true, folderName: "給与明細 配布キット", url: "https://docs.google.com/document/d/T/edit" }).includes("シートを作りました"));
});

test("何度押してもデータは消さない: あるシートには、足りない見出しと設定の行だけを足す", () => {
  const sheets = {
    設定: [["項目", "値"], ["会社名", "見本商事株式会社"], ["題", "給与明細"]],
    社員: [["社員番号", "氏名", "メール"], ["1001", "見本 一郎", "a@example.com"]],
    項目: [["見出し", "区分", "並び順", "表示名"]],
    貼り付け: [["何か"]],
    明細: [[""]],
    確かめる: [["項目"]],
    送信記録: [sheetSpecs("paid")[6][1]],
  };
  const plan = planInit(sheets, "paid");
  assert.deepEqual(plan.create, [], "空の明細シートは見出しを持たないので、そのまま");
  assert.deepEqual(plan.appendHeaders, [{ sheet: "社員", names: ["渡し方", "電子交付の同意日", "在籍"] }]);
  assert.equal(plan.appendSettings.some((row) => row[0] === "会社名"), false);
  assert.equal(plan.appendSettings.length, DEFAULT_ROWS.length - 2);
});

test("そろっていれば「変更はありません」", () => {
  const sheets = {};
  for (const [name, header] of sheetSpecs("paid")) sheets[name] = [header || ["x"]];
  sheets.設定 = [["項目", "値"]].concat(DEFAULT_ROWS);
  const plan = planInit(sheets, "paid");
  assert.deepEqual(plan, { create: [], appendHeaders: [], appendSettings: [] });
  assert.ok(initReport(plan, { created: false, url: "u" }).startsWith("変更はありません"));
});

test("無料版の社員シートには同意の列が無い", () => {
  assert.equal(planInit({}, "free").create[1].rows[0].includes("電子交付の同意日"), false);
});
