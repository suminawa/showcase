import { test } from "node:test";
import assert from "node:assert/strict";
import { put, runKit, sample } from "./helpers.mjs";

/** 初期化 → 見本の社員と 10 月分を入れる → 設定に 3 つ書く */
function ready(options) {
  const kit = runKit(options);
  kit.g.initializeKit();
  put(kit, "社員", sample("employees-sample.csv").map((row) => (kit.options.edition === "free" ? row.filter((_, i) => i !== 4) : row)));
  put(kit, "貼り付け", sample("payroll-2026-10.csv"));
  const settings = kit.sheets["設定"].rows;
  for (const row of settings) {
    if (row[0] === "会社名") row[1] = "見本商事株式会社";
    if (row[0] === "対象月") row[1] = "2026-10";
    if (row[0] === "支給日") row[1] = "2026年10月23日";
  }
  return kit;
}

/** 試し送りのメールに並んだ PDF のリンクの数 */
function links(mail) {
  return (mail.body.match(/https:\/\/drive\.google\.com\/file\/d\//g) || []).length;
}

function ledger(kit) {
  return kit.sheets["送信記録"].rows.slice(1);
}

test("初期化: 7 枚のシートと雛形（A4・4 つの表）。2 回押してもデータは消えない", () => {
  const kit = runKit();
  kit.g.initializeKit();
  assert.deepEqual(Object.keys(kit.sheets), ["設定", "社員", "項目", "貼り付け", "明細", "確かめる", "送信記録"]);
  assert.ok(kit.alerts[0].startsWith("給与明細 配布キット v1.0.0\n\n初期化しました"));
  const template = Object.values(kit.docs.models)[0];
  assert.equal(Math.round(template.width), 595);
  assert.equal(Math.round(template.height), 842);
  assert.deepEqual(template.blocks.filter((b) => b.type === "t").map((b) => b.rows[0][0]), ["勤怠", "支給", "控除", "合計"]);
  kit.sheets["社員"].appendRow(["1001", "見本 一郎"]);
  kit.g.initializeKit();
  assert.ok(kit.alerts[1].includes("変更はありません"));
  assert.equal(kit.sheets["社員"].rows.length, 2);
  assert.equal(Object.keys(kit.docs.models).length, 1, "雛形は 1 つのまま");
});

test("取り込み: 見本の 10 月分から 8 人。合計行と空行を捨て、項目に区分を推定して足す", () => {
  const kit = ready();
  kit.g.importPayroll();
  const text = kit.alerts.pop();
  assert.ok(text.includes("明細に 8 人を取り込みました"), text);
  assert.ok(text.includes("合計・小計の行を 1 行"));
  const detail = kit.sheets["明細"].rows;
  assert.equal(detail.length, 9);
  assert.equal(detail[3][0], "1003", "全角の社員番号もそろう");
  const items = kit.sheets["項目"].rows.slice(1);
  const category = Object.fromEntries(items.map((row) => [row[0], row[1]]));
  assert.equal(category["所属"], "表示しない");
  assert.equal(category["勤怠 残業時間"], "勤怠");
  assert.equal(category["支給 過不足調整"], "支給");
  assert.equal(category["支給 支給合計"], "合計");
  assert.equal(category["控除 介護保険"], "控除");
  assert.equal(category["差引支給額"], "合計");
  const header = detail[0];
  assert.equal(detail[1][header.indexOf("支給 基本給")], 280000);
  assert.equal(detail[6][header.indexOf("支給 過不足調整")], -9000);
});

test("取り込み: 項目の区分を人が直したら、次の取り込みでも残る", () => {
  const kit = ready();
  kit.g.importPayroll();
  const row = kit.sheets["項目"].rows.find((r) => r[0] === "支給 家族手当");
  row[1] = "表示しない";
  kit.g.importPayroll();
  assert.equal(kit.sheets["項目"].rows.filter((r) => r[0] === "支給 家族手当").length, 1);
  assert.equal(kit.sheets["項目"].rows.find((r) => r[0] === "支給 家族手当")[1], "表示しない");
});

test("配る流れ: 確かめる → 試し送りの前は配れない → 試し送りは自分あてに 1 通 → 配る → 二重には送らない", () => {
  const kit = ready({ noGoogle: ["kenta@example.com"] });
  kit.g.importPayroll();
  kit.g.checkBeforeSend();
  assert.ok(kit.alerts.pop().includes("要確認はありません"));
  assert.equal(kit.sheets["確かめる"].rows.length, 12);
  assert.equal(kit.sheets["確かめる"].rows[8][2], "お知らせ", "8. 紙で渡す人（見本 翔）");

  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("試し送りが済んでいません"));
  assert.equal(kit.mails.length, 0);

  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("owner@example.com に試し送りを送りました（8 人分の PDF）"));
  assert.equal(kit.mails.length, 1);
  const trial = kit.mails[0];
  assert.equal(trial.to, "owner@example.com");
  assert.equal(trial.attachments, undefined, "PDF は添付せず、ドライブのリンクを並べる");
  assert.equal(links(trial), 8);
  assert.ok(trial.body.includes("1007 見本 翔 → 紙"));
  assert.ok(trial.body.includes("1002 見本 花子 → hanako@example.com（添付）"));
  const pdfFile = Object.values(kit.files).find((f) => f.name === "2026-10_給与明細_1001_見本 一郎.pdf");
  assert.ok(trial.body.includes("https://drive.google.com/file/d/" + Object.keys(kit.files).find((id) => kit.files[id] === pdfFile) + "/view"));
  const pdf = pdfFile.blob.content;
  for (const text of ["見本商事株式会社", "2026年10月分", "支給日 2026年10月23日", "1001", "見本 一郎 様", "基本給 | 280,000", "差引支給額 | 277,641", "残業時間 | 12:00", "[A4 595.28x841.89]"]) {
    assert.ok(pdf.includes(text), text + "\n" + pdf);
  }
  assert.equal(pdf.includes("{{"), false, "差し込み記号が残っていない");
  assert.equal(pdf.includes("所属"), false, "表示しないは出ない");
  const working = Object.values(kit.files).filter((f) => String(f.name).startsWith("作業中_"));
  assert.ok(working.length >= 8 && working.every((f) => f.trashed === true), "作業用の複製はゴミ箱へ");

  kit.g.deliverPayslips();
  const result = kit.alerts.pop();
  assert.ok(kit.alerts.pop().includes("7 人に送ります（共有 6 人・添付 1 人）"), "送る前の確認");
  assert.ok(result.includes("を 7 人に送りました"), result);
  assert.ok(result.includes("共有できなかったため添付で送った人: 見本 健太"));
  assert.ok(result.includes("紙で渡す人"));
  const sent = kit.mails.slice(1);
  assert.equal(sent.length, 7);
  assert.deepEqual(sent.map((m) => m.to).sort(), ["daisuke@example.com", "hanako@example.com", "ichiro@example.com", "kenta@example.com", "megumi@example.com", "misaki@example.com", "yumi@example.com"]);
  assert.equal(sent.some((m) => m.to === "sho@example.com"), false, "同意の無い人には送らない");
  for (const mail of sent) {
    assert.equal(/\d{1,3},\d{3}/.test(mail.body), false, "本文に金額が無い: " + mail.body);
    assert.equal(mail.name, "見本商事株式会社");
  }
  const ichiro = sent.find((m) => m.to === "ichiro@example.com");
  assert.equal(ichiro.attachments, undefined, "共有は添付しない");
  assert.ok(ichiro.body.includes("https://drive.google.com/file/d/"));
  assert.equal(sent.find((m) => m.to === "hanako@example.com").attachments.length, 1);
  assert.equal(sent.find((m) => m.to === "kenta@example.com").attachments.length, 1);

  const rows = ledger(kit);
  assert.equal(rows.length, 7);
  assert.ok(rows.every((r) => r[7] === "送信済み" && r[8] === 1));
  const kenta = rows.find((r) => r[3] === "1003");
  assert.equal(kenta[6], "添付");
  assert.ok(kenta[12].startsWith("添付に切替"));
  const shared = rows.find((r) => r[3] === "1001");
  assert.equal(kit.files[shared[9]].permissions[0].emailAddress, "ichiro@example.com");
  assert.equal(kit.files[shared[9]].permissions[0].role, "reader");

  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("送る人はいません"));
  assert.equal(kit.mails.length, 8);
});

test("明細を直したら、試し送りからやり直す。送り直すは版を残し、前の版の共有を外す", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.g.deliverPayslips();
  const detail = kit.sheets["明細"].rows;
  detail[1][detail[0].indexOf("差引支給額")] = 277000;

  kit.options.prompts.push("1001");
  kit.g.resendPayslip();
  assert.ok(kit.alerts.pop().includes("試し送りが済んでいません"));

  kit.g.sendTrial();
  kit.options.prompts.push("１００１");
  kit.g.resendPayslip();
  assert.ok(kit.alerts.pop().includes("見本 一郎 様に 2 回目を送りました"));
  const rows = ledger(kit).filter((r) => r[3] === "1001");
  assert.deepEqual(rows.map((r) => [r[7], r[8]]), [["送信済み", 1], ["送信済み", 2]]);
  assert.ok(rows[0][12].includes("共有を外しました（差し替え）"));
  assert.equal(kit.files[rows[0][9]].permissions.length, 0);
  assert.equal(kit.files[rows[1][9]].permissions.length, 1);
  assert.ok(kit.files[rows[1][9]].name.endsWith("_2回目.pdf"));
  const last = kit.mails[kit.mails.length - 1];
  assert.equal(last.to, "ichiro@example.com");
});

test("退職者の共有を外す: 退職にした人の共有だけを外し、記録に残す", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.g.deliverPayslips();
  kit.sheets["社員"].rows.find((r) => r[0] === "1005")[5] = "退職";
  kit.g.unshareRetired();
  assert.ok(kit.alerts.pop().includes("1 ファイルの共有を外しました"));
  const row = ledger(kit).find((r) => r[3] === "1005");
  assert.ok(row[12].includes("共有を外しました（退職）"));
  assert.equal(kit.files[row[9]].permissions.length, 0);
  assert.equal(kit.files[ledger(kit).find((r) => r[3] === "1001")[9]].permissions.length, 1);
  kit.g.unshareRetired();
  assert.ok(kit.alerts.pop().includes("共有を外すファイルはありません"));
});

test("1 日の残り枠で打ち切り、続きは次の「配る」で。送った人には二度送らない", () => {
  const kit = ready({ quota: 4 });
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.g.deliverPayslips();
  const first = kit.alerts.pop();
  assert.ok(first.includes("を 3 人に送りました"), first);
  assert.ok(first.includes("もう一度「配る」を押してください（残り 4 人）"));
  kit.options.quota = 100;
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("を 4 人に送りました"));
  assert.equal(new Set(ledger(kit).map((r) => r[0])).size, 7);
});

test("続きを自動で送る: 時間で止まったら 1 回きりのトリガーを作り、続きが終わったら自分あてに結果を 1 通", () => {
  const kit = ready();
  kit.sheets["設定"].rows.find((r) => r[0] === "続きを自動で送る")[1] = "する";
  kit.g.importPayroll();
  kit.g.sendTrial();
  // Date.now() を呼ぶたびに 100 秒進む時計（4 分 30 秒で止まる）
  const RealDate = Date;
  let clock = RealDate.now();
  kit.g.Date = class extends RealDate {
    static now() {
      clock += 100000;
      return clock;
    }
  };
  kit.g.deliverPayslips();
  kit.g.Date = RealDate;
  const text = kit.alerts.pop();
  assert.ok(text.includes("を 2 人に送りました"), text);
  assert.ok(text.includes("1 分ほどあとに続きを送ります"));
  assert.equal(kit.triggers.length, 1);
  kit.g.continueDelivery();
  assert.equal(kit.triggers.length, 0);
  const summary = kit.mails[kit.mails.length - 1];
  assert.equal(summary.to, "owner@example.com");
  assert.ok(summary.body.includes("を 5 人に送りました"));
  assert.equal(ledger(kit).length, 7);
});

test("I5: 送信数の上限で止まったときは、続きを自動にしていても 1 分ごとのトリガーを作らない", () => {
  const kit = ready({ quota: 4 });
  kit.sheets["設定"].rows.find((r) => r[0] === "続きを自動で送る")[1] = "する";
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.g.deliverPayslips();
  const text = kit.alerts.pop();
  assert.ok(text.includes("今日送れるメールの数"), text);
  assert.equal(kit.triggers.length, 0);
});

test("M3: 続きのトリガーがロックを取れなかったら、5 分後にもう一度回す", () => {
  const kit = ready();
  kit.g.LockService = { getScriptLock: () => ({ tryLock: () => false, releaseLock: () => {} }) };
  kit.g.continueDelivery();
  assert.equal(kit.triggers.length, 1);
});

test("送信中のまま残った行があると、確かめるが止める", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.g.deliverPayslips();
  ledger(kit)[0][7] = "送信中";
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().startsWith("要確認が 1 項目あります"));
  assert.ok(kit.sheets["確かめる"].rows[10][3].includes("「送信中」のまま残った行"));
});

test("同じメールが 2 人・リンクを知っている全員に共有 → 試し送りもできない", () => {
  const kit = ready({ sharing: "anyone" });
  kit.sheets["社員"].rows.find((r) => r[0] === "1002")[2] = "ichiro@example.com";
  kit.g.importPayroll();
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().startsWith("要確認が 2 項目あります"));
  assert.equal(kit.mails.length, 0);
});

test("無料版: 3 人まで取り込み、試し送りまで。配る・送り直す・退職者の共有を外すは止める", () => {
  const kit = ready({ edition: "free" });
  assert.equal(kit.sheets["社員"].rows[0].includes("電子交付の同意日"), false);
  assert.ok(kit.alerts[0].includes("（無料版）"));
  kit.g.importPayroll();
  assert.ok(kit.alerts.pop().includes("残りの 5 人は取り込んでいません"));
  assert.equal(kit.sheets["明細"].rows.length, 4);
  kit.g.sendTrial();
  assert.equal(links(kit.mails[0]), 3);
  for (const name of ["deliverPayslips", "resendPayslip", "unshareRetired"]) {
    kit.g[name]();
    assert.ok(kit.alerts.pop().includes("有料版で使えます"), name);
  }
  assert.equal(kit.mails.length, 1);
});

// ===== 審査 C1〜C3: 先に赤になる検査 =====

test("C1: メールを送ったあとで記録の書き換えが落ちたら「送信中」のまま止め、次の「配る」で送り直さない", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.options.failLedgerWrites = 1; // 送信済みへの書き換えだけが落ちる（そのあとの書き換えは通る）
  kit.g.deliverPayslips();
  const first = ledger(kit)[0];
  assert.equal(first[7], "送信中", "送れたか分からない行は送信中のまま");
  const before = kit.mails.filter((m) => m.to === "ichiro@example.com").length;
  assert.equal(before, 1);
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().startsWith("要確認"), "送信中が残っているので止まる");
  assert.equal(kit.mails.filter((m) => m.to === "ichiro@example.com").length, 1, "同じ人に 2 通目が行かない");
});

test("C1: メールの送信の呼び出しで例外が出たときも、届いたか分からないので「送信中」のまま止める", () => {
  const kit = ready({ failMail: [] });
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.options.failMail.push("ichiro@example.com");
  kit.g.deliverPayslips();
  const row = ledger(kit).find((r) => r[3] === "1001");
  assert.equal(row[7], "送信中");
  assert.ok(row[12].includes("届いたか分かりません"), row[12]);
});

test("C1: 送信の呼び出しより前に落ちたと分かるとき（PDF を作れない）だけ「失敗」にし、次の「配る」で送る", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  const realCopy = kit.g.Drive.Files.copy;
  kit.g.Drive.Files.copy = () => {
    throw new Error("Drive の一時的なエラー");
  };
  kit.g.deliverPayslips(); // 花子さん（添付）は PDF を作り直すので、ここで落ちる
  kit.g.Drive.Files.copy = realCopy;
  const hanako = ledger(kit).find((r) => r[3] === "1002");
  assert.equal(hanako[7], "失敗");
  assert.ok(kit.alerts.pop().includes("送れなかった人"));
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("を 1 人に送りました"));
  assert.equal(kit.mails.filter((m) => m.to === "hanako@example.com").length, 1);
});

test("C2: 社員シートに同じ社員番号が 2 行あれば止める（別の人のアドレスに明細が行かないように）", () => {
  const kit = ready();
  const rows = kit.sheets["社員"].rows;
  rows.splice(1, 0, ["01001", "見本 佐藤", "sato@example.com", "共有", "2026/10/01", "在籍"]);
  kit.g.importPayroll();
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().startsWith("要確認"));
  assert.equal(kit.mails.length, 0);
});

test("C2: 明細の氏名と社員シートの氏名が違えば止める。空白・全角半角の違いは同じとみなす", () => {
  const kit = ready();
  kit.sheets["社員"].rows.find((r) => r[0] === "1002")[1] = "見本　花子";
  kit.sheets["社員"].rows.find((r) => r[0] === "1003")[1] = "見本健太";
  kit.g.importPayroll();
  kit.g.checkBeforeSend();
  assert.ok(kit.alerts.pop().includes("要確認はありません"));
  kit.sheets["社員"].rows.find((r) => r[0] === "1001")[1] = "見本 佐藤";
  kit.g.checkBeforeSend();
  assert.ok(kit.alerts.pop().startsWith("要確認"));
  assert.ok(kit.sheets["確かめる"].rows[1][3].includes("1001: 明細は見本 一郎、社員シートは見本 佐藤"));
});

test("C3: 試し送りのメールが落ちたら済みにしない。もう一度押すと送り直し、送れてから配れる", () => {
  const kit = ready({ failMail: ["owner@example.com"] });
  kit.g.importPayroll();
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("うまくいきませんでした"));
  assert.equal(kit.mails.length, 0);
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("試し送りが済んでいません"));
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().includes("試し送りを送りました（8 人分の PDF）"));
  assert.equal(links(kit.mails[0]), 8);
  kit.g.deliverPayslips();
  assert.ok(kit.alerts.pop().includes("を 7 人に送りました"));
});

// ===== 審査 Important =====

test("I4: 無料版は、明細シートに直接足した行も 3 人で切る", () => {
  const kit = ready({ edition: "free" });
  kit.g.importPayroll();
  const detail = kit.sheets["明細"].rows;
  for (const id of ["1004", "1005"]) detail.push([id, "", 1, 1].concat(new Array(detail[0].length - 4).fill("")));
  kit.g.sendTrial();
  assert.equal(links(kit.mails[0]), 3);
});

test("I7: 送り直しで前の版の共有を外せなくても、送れたことを伝え、外せなかったものを出す", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.g.sendTrial();
  kit.g.deliverPayslips();
  kit.g.Drive.Permissions.remove = () => {
    throw new Error("Insufficient permissions");
  };
  kit.options.prompts.push("1001");
  kit.g.resendPayslip();
  const text = kit.alerts.pop();
  assert.ok(text.startsWith("見本 一郎 様に 2 回目を送りました。前の版のうち 1 件の共有を外せませんでした"), text);
});

test("I8: 対象月を変えて取り込み忘れたら、先月の明細を今月分として送らない", () => {
  const kit = ready();
  kit.g.importPayroll();
  kit.sheets["設定"].rows.find((r) => r[0] === "対象月")[1] = "2026-11";
  kit.g.sendTrial();
  assert.ok(kit.alerts.pop().startsWith("要確認"));
  assert.ok(kit.sheets["確かめる"].rows[7][3].includes("明細は対象月が 2026-10 のときに取り込んだもの"));
  assert.equal(kit.mails.length, 0);
});

test("M7: = で始まる字は、送信記録と明細に ' を付けて字のまま置く", () => {
  const kit = ready();
  kit.sheets["貼り付け"].rows[4][2] = "=IMPORTXML(\"x\")";
  kit.g.importPayroll();
  const detail = kit.sheets["明細"].rows;
  assert.equal(detail[1][detail[0].indexOf("所属")], "'=IMPORTXML(\"x\")");
});
