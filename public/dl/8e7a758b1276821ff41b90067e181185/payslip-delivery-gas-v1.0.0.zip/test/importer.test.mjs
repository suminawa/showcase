import { test } from "node:test";
import assert from "node:assert/strict";
import { buildDetailRows, combineHeaders, findHeaderRows, importReport, readPaste } from "../src/importer.js";
import { mergeItems } from "../src/items.js";

/** 社労士の一覧によくある形: 題の行・空行・2 段の見出し（上の段は結合で空き）・合計行・全角と「円」・△ */
const PASTE = [
  ["給与一覧表　２０２６年１０月分"],
  [],
  ["社員番号", "氏名", "勤怠", "", "支給", "", "", "控除", "", "差引支給額"],
  ["", "", "出勤日数", "残業時間", "基本給", "通勤手当", "過不足調整", "健康保険", "所得税", ""],
  ["１００１", "見本　一郎", "２０", "12:30", "２５０，０００円", "12,000", "△3,000", "12,450", "6,530", "240,020"],
  ["", "", "", "", "", "", "", "", "", ""],
  ["1002", "見本 花子", "19", "0:00", "220000", "8000", "", "10958", "4770", "212272"],
  ["", "（部署計）", "", "", "470000", "", "", "", "", ""],
  ["合計", "", "", "", "470,000", "20,000", "△3,000", "23,408", "11,300", "452,292"],
];

test("見出しの行: 社員番号の段と、その下の段（2 段）。上の題の行は読まない", () => {
  assert.deepEqual(findHeaderRows(PASTE, "auto"), { start: 2, end: 3, idCol: 0 });
});

test("見出しの行: 数を書いたら、社員番号の段から下へその数だけ", () => {
  assert.deepEqual(findHeaderRows(PASTE, 1), { start: 2, end: 2, idCol: 0 });
});

test("見出しの行: 社員番号が下の段にあり、上の段がまとまりの見出し", () => {
  const rows = [
    ["", "", "支給", ""],
    ["社員No", "氏名", "基本給", "手当"],
    ["1", "見本 一郎", "1", "2"],
  ];
  assert.deepEqual(findHeaderRows(rows, "auto"), { start: 0, end: 1, idCol: 0 });
  assert.deepEqual(combineHeaders(rows.slice(0, 2)), ["社員No", "氏名", "支給 基本給", "支給 手当"]);
});

test("見出しが無ければ、直し方つきで止める", () => {
  const result = readPaste([["名前", "金額"], ["見本", "1"]]);
  assert.equal(result.ok, false);
  assert.ok(result.problem.includes("社員番号"));
});

test("2 段の見出しの結合: 空いた上の段を左の値で埋める。縦の結合はそのまま 1 つ", () => {
  assert.deepEqual(combineHeaders(PASTE.slice(2, 4)), [
    "社員番号", "氏名", "勤怠 出勤日数", "勤怠 残業時間", "支給 基本給", "支給 通勤手当", "支給 過不足調整", "控除 健康保険", "控除 所得税", "差引支給額",
  ]);
});

test("縦に結合した列の右の空き列は、左の見出しを引き継がない", () => {
  assert.deepEqual(combineHeaders([["氏名", "", "支給"], ["", "", "基本給"]]), ["氏名", "", "支給 基本給"]);
});

test("見出しのゆれ: 全角スペース・改行を 1 つに", () => {
  assert.deepEqual(combineHeaders([["支給　", ""], ["基本\n給", "通勤　手当"]]), ["支給 基本 給", "支給 通勤 手当"]);
});

test("合計・小計・計の行と、社員番号が空の行を捨て、件数を返す", () => {
  const result = readPaste(PASTE);
  assert.equal(result.ok, true);
  assert.deepEqual(result.people.map((p) => p.id), ["1001", "1002"]);
  assert.deepEqual(result.dropped, { totals: 2, noId: 0 });
  assert.equal(result.nameCol, 1);
  assert.equal(result.people[0].name, "見本 一郎");
  assert.equal(result.people[0].key, "1001");
  assert.equal(result.headers.length, 8, "社員番号と氏名は項目に入らない");
});

test("社員番号が空で合計の字も無い行は「社員番号が空」として数える", () => {
  const result = readPaste([["社員番号", "氏名", "基本給"], ["", "見本 三郎", "1"], ["1", "見本 一郎", "2"]]);
  assert.deepEqual(result.dropped, { totals: 0, noId: 1 });
});

test("明細の行: 金額の区分は数に（全角・円・カンマ・△）、勤怠は字のまま。読めない金額は字のまま残して知らせる", () => {
  const paste = readPaste(PASTE);
  const items = mergeItems([], paste.headers.map((h) => h.name)).items;
  const built = buildDetailRows(paste.people, items, {});
  assert.deepEqual(built.rows[0].slice(0, 4), ["社員番号", "氏名", "勤怠 出勤日数", "勤怠 残業時間"]);
  assert.deepEqual(built.rows[1], ["1001", "見本 一郎", "20", "12:30", 250000, 12000, -3000, 12450, 6530, 240020]);
  assert.equal(built.rows[2][6], "", "空の金額は空のまま");
  assert.deepEqual(built.badCells, []);

  const bad = buildDetailRows([{ id: "1", key: "1", name: "", values: { "支給 基本給": "未定" }, row: 5 }], [{ header: "支給 基本給", category: "支給" }], { 1: "見本 一郎" });
  assert.deepEqual(bad.rows[1], ["1", "見本 一郎", "未定"], "氏名の列が無ければ社員シートの氏名");
  assert.deepEqual(bad.badCells, [{ row: 5, header: "支給 基本給", value: "未定" }]);
});

test("取り込みの結果の文: 人数・捨てた行・足した見出し・推定できなかった見出し・無料版の切り捨て", () => {
  const text = importReport({ people: 3, totals: 1, noId: 2, added: [["支給 基本給", "支給", 1, "基本給"], ["なぞ", "", 2, "なぞ"]], badCells: [], cut: 5 });
  assert.ok(text.includes("3 人を取り込みました"));
  assert.ok(text.includes("合計・小計の行を 1 行"));
  assert.ok(text.includes("社員番号が空の行を 2 行"));
  assert.ok(text.includes("見出しを 2 個足しました"));
  assert.ok(text.includes("推定できなかった見出し（「項目」シートで選んでください）: なぞ"));
  assert.ok(text.includes("残りの 5 人"));
});

test("M4: 同じ見出しが 2 列あれば、右に番号を付けて両方残す", () => {
  const result = readPaste([["社員番号", "その他", "その他"], ["1", "10", "20"]]);
  assert.deepEqual(result.headers.map((h) => h.name), ["その他", "その他 (2)"]);
  assert.deepEqual(result.people[0].values, { その他: "10", "その他 (2)": "20" });
});
