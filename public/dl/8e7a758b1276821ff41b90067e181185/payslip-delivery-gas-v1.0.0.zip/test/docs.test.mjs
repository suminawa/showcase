import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { runChecks } from "../src/check.js";
import { CONFIG_KEYS, DEFAULT_ROWS, parseConfig } from "../src/config.js";
import { parseEmployees } from "../src/employees.js";
import { buildDetailRows, readPaste } from "../src/importer.js";
import { mergeItems } from "../src/items.js";
import { buildMail } from "../src/message.js";
import { INIT_MENU_LABEL } from "../src/setup.js";
import { read, root, sample } from "./helpers.mjs";

const PUBLIC = () =>
  ["README.ja.md", "CHANGELOG.md", "LICENSE.md"]
    .concat(readdirSync(join(root, "docs")).filter((n) => n.endsWith(".md")).map((n) => "docs/" + n))
    .concat(readdirSync(join(root, "samples")).map((n) => "samples/" + n))
    .concat(readdirSync(join(root, "src")).map((n) => "src/" + n));

test("公開する文に、使わない言い回しと内向きの呼び方が無い", () => {
  for (const file of PUBLIC()) {
    const text = read(file);
    for (const word of ["承ります", "必ず", "確実に", "最短", "今だけ", "鉋", "棟梁"]) assert.equal(text.includes(word), false, file + " に「" + word + "」");
  }
});

test("版がそろっている（package.json・README の題・CHANGELOG の先頭・KIT_VERSION）", () => {
  const version = JSON.parse(read("package.json")).version;
  assert.ok(read("README.ja.md").startsWith("# 給与明細 配布キット v" + version + "\n"));
  assert.equal(read("CHANGELOG.md").match(/^## (\d+\.\d+\.\d+)/m)[1], version);
  assert.equal(read("src/gas_main.js").match(/^const KIT_VERSION = "([^"]+)";$/m)[1], version);
});

test("README の 1 行目の約束と、計算をしないこと・添付の注意", () => {
  const readme = read("README.ja.md");
  assert.ok(readme.includes("社労士や給与ソフトから届いた給与の一覧を貼ると、社員ごとの明細 PDF を作り、本人のアドレスだけに渡します。"));
  assert.ok(readme.includes("**税と社会保険の計算はしません**"));
  assert.ok(readme.includes("**添付はメールが転送されると誰でも開けます。できるだけ共有をお勧めします。**"));
  assert.ok(readme.includes("**メールに金額を差し込む書き方はありません。**"));
});

test("README に設定の全項目・メニューの字・確かめるの 11 項目・許可の説明が載っている", () => {
  const readme = read("README.ja.md");
  for (const key of CONFIG_KEYS) assert.ok(readme.includes("| " + key + " |"), key);
  assert.ok(readme.includes(INIT_MENU_LABEL));
  const main = read("src/gas_main.js");
  for (const label of main.match(/\.addItem\("([^"]+)"/g).map((s) => s.slice(10, -1))) assert.ok(readme.includes(label), label);
  const empty = runChecks({ config: parseConfig([]), detail: { headers: [], people: [] }, items: [], employees: [], records: [], sharing: "x", edition: "paid" });
  for (const entry of empty) assert.ok(readme.includes(entry.no + ". " + entry.label), entry.label);
  const permissions = readme.slice(readme.indexOf("### 承認の画面に出る許可"), readme.indexOf("## 手順 2"));
  assert.equal((permissions.match(/^\| [^|-]/gm) || []).length - 1, 7, "許可 7 つを 1 行ずつ");
});

test("README の「届くメール」は、見本の設定で実際に作る 1 通と同じ", () => {
  const config = parseConfig(sample("settings-sample.csv"));
  const mail = buildMail(config, "見本 一郎", "共有", "https://drive.google.com/file/d/（ファイルごとの ID）/view");
  assert.ok(read("README.ja.md").includes("件名: " + mail.subject + "\n\n" + mail.body + "\n```"));
});

test("見本の設定シートは、初期化で入る行に会社名・対象月・支給日・表示名を書いたもの", () => {
  const rows = sample("settings-sample.csv");
  assert.deepEqual(rows[0], ["項目", "値"]);
  assert.deepEqual(rows.slice(1).map((r) => r[0]), DEFAULT_ROWS.map((r) => r[0]));
  const filled = ["会社名", "対象月", "支給日", "送信元の表示名"];
  rows.slice(1).forEach((row, i) => {
    if (filled.indexOf(row[0]) < 0) assert.equal(row[1], DEFAULT_ROWS[i][1], row[0]);
  });
});

test("見本の 3 か月はどれも 8 人に整い、合計行を 1 行捨て、支給合計・控除合計・差引支給額の計算が合う", () => {
  for (const month of ["2026-08", "2026-09", "2026-10"]) {
    const paste = readPaste(sample("payroll-" + month + ".csv"));
    assert.equal(paste.ok, true, month);
    assert.equal(paste.people.length, 8, month);
    assert.deepEqual(paste.dropped, { totals: 1, noId: 0 }, month);
    const items = mergeItems([], paste.headers.map((h) => h.name)).items;
    assert.deepEqual(items.filter((i) => i.category === "").map((i) => i.header), [], "区分を推定できない見出しが無い");
    const built = buildDetailRows(paste.people, items, {});
    assert.deepEqual(built.badCells, []);
    const header = built.rows[0];
    const col = (name) => header.indexOf(name);
    for (const row of built.rows.slice(1)) {
      const value = (i) => (row[i] === "" ? 0 : row[i]);
      const pay = items.filter((i) => i.category === "支給").reduce((sum, i) => sum + value(col(i.header)), 0);
      const ded = items.filter((i) => i.category === "控除").reduce((sum, i) => sum + value(col(i.header)), 0);
      assert.equal(row[col("支給 支給合計")], pay, month + " " + row[0]);
      assert.equal(row[col("控除 控除合計")], ded, month + " " + row[0]);
      assert.equal(row[col("差引支給額")], pay - ded, month + " " + row[0]);
    }
  }
});

test("見本の社員シート: 添付 1 人・同意なし 1 人・退職 1 人。名前は架空（見本）、アドレスは example.com", () => {
  const employees = parseEmployees(sample("employees-sample.csv"), "paid");
  assert.equal(employees.filter((e) => e.method === "添付").length, 1);
  assert.equal(employees.filter((e) => !e.consent).length, 1);
  assert.equal(employees.filter((e) => !e.active).length, 1);
  assert.ok(employees.every((e) => e.name.startsWith("見本 ") && e.email.endsWith("@example.com")));
});

test("同意の文例: 法の扱いを断定せず、顧問に確かめるよう書いている", () => {
  const consent = read("docs/consent.md");
  assert.ok(consent.includes("所得税法第 231 条第 2 項"));
  assert.ok(consent.includes("**使う前に顧問の税理士・社労士にご確認ください。**"));
  assert.ok(consent.includes("https://www.nta.go.jp/publication/pamph/hotei/denshikouhu.pdf"));
  assert.equal(consent.includes("承諾とみなせます"), false);
});

test("受け取る方への案内は、印刷用の PDF もある。同梱のファイル名は英数字だけ", () => {
  assert.ok(existsSync(join(root, "docs/staff-guide.pdf")));
  for (const dir of ["samples", "docs", "src", "scripts", "test"]) {
    for (const name of readdirSync(join(root, dir))) assert.match(name, /^[A-Za-z0-9._-]+$/, dir + "/" + name);
  }
});
