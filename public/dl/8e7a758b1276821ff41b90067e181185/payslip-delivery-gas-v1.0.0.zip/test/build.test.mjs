import { test } from "node:test";
import assert from "node:assert/strict";
import { readdirSync } from "node:fs";
import { join } from "node:path";
import { buildSource, headerOf, manifestFor, MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";
import { root } from "./helpers.mjs";

test("import 行は落ち、export だけが剥がれる", () => {
  assert.equal(toGasSource('import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\n'), "function f() {\n  return 1;\n}");
  assert.equal(toGasSource("export const A = 1;\nconst exported = 2;"), "const A = 1;\nconst exported = 2;");
});

test("つないだ結果に import / export も、node 専用の書き方も残らない", () => {
  for (const edition of ["paid", "free"]) {
    const code = buildSource(root, edition);
    assert.equal(/^\s*(import|export)\s/m.test(code), false);
    for (const node of ["require(", "process.", "module.exports", "import.meta", "Buffer.", "__dirname"]) assert.equal(code.includes(node), false, node);
  }
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = buildSource(root, "paid");
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("SOURCE_ORDER に src の取りこぼしが無い。最初の関数は onOpen", () => {
  const files = readdirSync(join(root, "src")).filter((name) => name.endsWith(".js")).sort();
  assert.deepEqual(SOURCE_ORDER.slice().sort(), files);
  assert.equal(buildSource(root, "paid").match(/^function\s+([A-Za-z0-9_$]+)/m)[1], "onOpen");
});

test("無料版は EDITION の 1 行だけが違う", () => {
  const paid = buildSource(root, "paid");
  const free = buildSource(root, "free");
  assert.ok(paid.includes('const EDITION = "paid";'));
  assert.ok(free.includes('const EDITION = "free";'));
  assert.equal(free.replace('const EDITION = "free";', 'const EDITION = "paid";'), paid);
  assert.ok(headerOf("1.0.0", "free").startsWith("// 給与明細 配布キット v1.0.0（無料版）"));
  assert.equal(headerOf("1.0.0", "paid").split("\n")[1], "/** @OnlyCurrentDoc */");
});

test("マニフェスト: Asia/Tokyo の V8、Advanced Drive の v3、許可は最小（ドライブ全体・全シートは求めない）", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
  assert.deepEqual(MANIFEST.dependencies.enabledAdvancedServices, [{ userSymbol: "Drive", version: "v3", serviceId: "drive" }]);
  const scopes = MANIFEST.oauthScopes.map((s) => s.replace("https://www.googleapis.com/auth/", "")).sort();
  assert.deepEqual(scopes, ["documents", "drive.file", "script.container.ui", "script.scriptapp", "script.send_mail", "spreadsheets.currentonly", "userinfo.email"]);
  assert.equal(manifestFor("free").oauthScopes.some((s) => s.endsWith("script.scriptapp")), false, "無料版はトリガーを使わない");
});

test("許可と使うサービスがそろっている。DriveApp と、ほかのシートを開く呼び出しは使わない", () => {
  const code = buildSource(root, "paid");
  const needs = {
    "spreadsheets.currentonly": "SpreadsheetApp.getActiveSpreadsheet",
    documents: "DocumentApp.openById",
    "drive.file": "Drive.Permissions.create",
    "script.send_mail": "MailApp.sendEmail",
    "script.scriptapp": "ScriptApp.newTrigger",
    "userinfo.email": "Session.getEffectiveUser",
    "script.container.ui": "SpreadsheetApp.getUi",
  };
  for (const scope of Object.keys(needs)) assert.ok(code.includes(needs[scope]), needs[scope]);
  for (const call of ["DriveApp.", "GmailApp.", "UrlFetchApp.", "SpreadsheetApp.openById", "SpreadsheetApp.openByUrl", "SpreadsheetApp.create", "DocumentApp.create"]) {
    assert.equal(code.includes(call), false, call);
  }
});

test("共有は通知メールを止め、閲覧者・ファイル単位。フォルダは共有しない", () => {
  const code = buildSource(root, "paid");
  assert.ok(code.includes('{ role: "reader", type: "user", emailAddress: email }'));
  assert.ok(code.includes("sendNotificationEmail: false"));
  assert.equal((code.match(/Drive\.Permissions\.create\(/g) || []).length, 1);
});
