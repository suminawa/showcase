#!/usr/bin/env node
// 業務アプリ（sheet-app-gas）の純粋な処理 8 本を src/vendor/sheet-app/ に写す・照らす。
//   node scripts/vendor-check.mjs          元と 1 字も違わないかを照らす（違えば終了コード 1）
//   node scripts/vendor-check.mjs --write  元から写し直す
// 写しの 1 行目は出どころの注記。2 行目から先が元と同じ中身。
// zip の中では元（../sheet-app-gas）が無いので、照らさずに終わる。
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const VENDOR_FILES = ["text.js", "dates.js", "definition.js", "validate.js", "format.js", "ids.js", "query.js", "line.js"];
export const VENDOR_VERSION = "1.1.0";
export const VENDOR_HEADER = `// sheet-app-gas v${VENDOR_VERSION} の src から写した。直すときは元を直して写し直す（npm run vendor）\n`;

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");
export const SOURCE_DIR = resolve(ROOT, "../sheet-app-gas/src");
export const VENDOR_DIR = join(ROOT, "src/vendor/sheet-app");

/** 元のフォルダがあるか（モノレポの中だけ true） */
export function hasSource(sourceDir = SOURCE_DIR) {
  return existsSync(join(sourceDir, "definition.js"));
}

/** 元と違う写しの名前の一覧（すべて同じなら空） */
export function vendorDiff(sourceDir = SOURCE_DIR, vendorDir = VENDOR_DIR) {
  const differ = [];
  for (const name of VENDOR_FILES) {
    const source = readFileSync(join(sourceDir, name), "utf8");
    const copy = existsSync(join(vendorDir, name)) ? readFileSync(join(vendorDir, name), "utf8") : null;
    if (copy !== VENDOR_HEADER + source) differ.push(name);
  }
  return differ;
}

export function vendorWrite(sourceDir = SOURCE_DIR, vendorDir = VENDOR_DIR) {
  mkdirSync(vendorDir, { recursive: true });
  for (const name of VENDOR_FILES) {
    writeFileSync(join(vendorDir, name), VENDOR_HEADER + readFileSync(join(sourceDir, name), "utf8"));
  }
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  if (!hasSource()) {
    console.log("sheet-app-gas の src が見つからないため、照らさずに終わります（zip の中ではこれで正常です）");
  } else if (process.argv.includes("--write")) {
    vendorWrite();
    console.log(`sheet-app-gas から ${VENDOR_FILES.length} 本を写しました`);
  } else {
    const differ = vendorDiff();
    if (differ.length > 0) {
      console.error(`元と違う写しがあります: ${differ.join(", ")}。npm run vendor で写し直してください`);
      process.exit(1);
    }
    console.log("写しは元と同じです");
  }
}
