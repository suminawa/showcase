/**
 * 入口 (b): Streamable HTTP（ChatGPT のコネクタ・claude.ai のカスタムコネクタ・遠隔利用）。
 * 状態を持たない（要求ごとに Server とトランスポートを作って捨てる）。Bearer 必須、CORS 無し、既定は 127.0.0.1:8787。
 */
import { realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";
import express, { type Express, type NextFunction, type Request, type Response } from "express";
import { rateLimit } from "express-rate-limit";
import { createMcpExpressApp } from "@modelcontextprotocol/sdk/server/express.js";
import { InvalidTokenError } from "@modelcontextprotocol/sdk/server/auth/errors.js";
import { requireBearerAuth } from "@modelcontextprotocol/sdk/server/auth/middleware/bearerAuth.js";
import { getOAuthProtectedResourceMetadataUrl, mcpAuthRouter } from "@modelcontextprotocol/sdk/server/auth/router.js";
import type { AuthInfo } from "@modelcontextprotocol/sdk/server/auth/types.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import type { Config } from "../core/env.ts";
import { stderrSink, type Logger } from "../core/log.ts";
import { boot, kitDirOf } from "./boot.ts";
import { createServer } from "./create.ts";
import { PasswordOAuthProvider, SCOPE, sameSecret } from "./oauth.ts";
import type { Registry } from "./registry.ts";

export const REQUESTS_PER_MINUTE = 120;

export interface HttpAppOptions {
  registry: Registry;
  config: Config;
  logger: Logger;
  clock: () => Date;
}

function methodNotAllowed(_req: Request, res: Response): void {
  res.status(405).set("Allow", "POST").json({ jsonrpc: "2.0", error: { code: -32000, message: "Method not allowed." }, id: null });
}

/**
 * 最後の誤りの受け手。Express の既定（スタックと絶対パス入りの HTML を返し、stderr にも書く）の代わりに、
 * 短い英字の JSON-RPC の誤りだけを返す。ログは MCP_LOG=debug のときだけ、誤りの種類だけを書く（本文のかけらは書かない）
 */
function errorHandler(logger: Logger) {
  return (error: unknown, _req: Request, res: Response, next: NextFunction): void => {
    const info = (typeof error === "object" && error !== null ? error : {}) as { type?: unknown; status?: unknown; statusCode?: unknown; name?: unknown };
    const type = typeof info.type === "string" ? info.type : "";
    const given = typeof info.status === "number" ? info.status : typeof info.statusCode === "number" ? info.statusCode : 500;
    let status = 500;
    let code = -32603;
    let message = "Internal server error.";
    if (type === "entity.parse.failed") {
      status = 400;
      code = -32700;
      message = "Parse error.";
    } else if (type === "entity.too.large" || given === 413) {
      status = 413;
      code = -32600;
      message = "Request body too large.";
    } else if (given >= 400 && given < 500) {
      status = given;
      code = -32600;
      message = "Invalid request.";
    }
    logger.debug(`http error status=${status} type=${type !== "" ? type : typeof info.name === "string" ? info.name : "unknown"}`);
    if (res.headersSent) {
      next(error);
      return;
    }
    res.status(status).json({ jsonrpc: "2.0", error: { code, message }, id: null });
  };
}

export function createHttpApp(options: HttpAppOptions): { app: Express; oauth: PasswordOAuthProvider | null } {
  const { config, registry, logger } = options;
  const allowedHosts = ["localhost", "127.0.0.1", "[::1]"];
  if (config.publicUrl !== "") allowedHosts.push(new URL(config.publicUrl).hostname);
  // Host ヘッダーの検査（DNS リバインディングの守り）は SDK が入れる。本文の JSON もここで読む（上限は express の既定の 100 KB）
  const app = createMcpExpressApp({ host: config.httpHost, allowedHosts });
  app.disable("x-powered-by");
  // Cloudflare Tunnel などが同じ機器から中継するときだけ、X-Forwarded-For の接続元を信じる
  app.set("trust proxy", "loopback");

  // CORS は返さない（ブラウザのページから呼ばせない）。OPTIONS は 405
  app.use((req, res, next) => {
    if (req.method === "OPTIONS") methodNotAllowed(req, res);
    else next();
  });
  app.use(rateLimit({ windowMs: 60000, limit: REQUESTS_PER_MINUTE, standardHeaders: "draft-7", legacyHeaders: false }));

  app.get("/healthz", (_req, res) => {
    res.type("text/plain").send("ok");
  });

  let oauth: PasswordOAuthProvider | null = null;
  let resourceMetadataUrl: string | undefined;
  if (config.publicUrl !== "") {
    const provider = new PasswordOAuthProvider({ secret: config.httpToken, clock: () => options.clock().getTime() });
    oauth = provider;
    const resource = new URL(`${config.publicUrl}/mcp`);
    resourceMetadataUrl = getOAuthProtectedResourceMetadataUrl(resource);
    app.use(mcpAuthRouter({ provider, issuerUrl: new URL(config.publicUrl), resourceServerUrl: resource, scopesSupported: [SCOPE], resourceName: "mcp-server-kit" }));
    app.post("/login", express.urlencoded({ extended: false, limit: "10kb" }), (req, res) => provider.handleLogin(req, res));
  }

  const verifier = {
    async verifyAccessToken(token: string): Promise<AuthInfo> {
      if (sameSecret(token, config.httpToken)) {
        return { token, clientId: "static-token", scopes: [SCOPE], expiresAt: Math.floor(options.clock().getTime() / 1000) + 3600 };
      }
      if (oauth !== null) return oauth.verifyAccessToken(token);
      // この文は WWW-Authenticate の見出しに入るので、英字で書く（見出しに日本語は入れられない）
      throw new InvalidTokenError("Invalid token");
    },
  };

  app.post("/mcp", requireBearerAuth({ verifier, resourceMetadataUrl }), async (req, res) => {
    const server = createServer(registry, { listChanged: false });
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    res.on("close", () => {
      void transport.close();
      void server.close();
    });
    try {
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (error) {
      logger.debug(error instanceof Error ? (error.stack ?? error.message) : String(error));
      if (!res.headersSent) res.status(500).json({ jsonrpc: "2.0", error: { code: -32603, message: "Internal server error." }, id: null });
    }
  });
  app.get("/mcp", methodNotAllowed);
  app.delete("/mcp", methodNotAllowed);
  // 経路のあとに置く（本文の読み取りの誤りもここへ来る）
  app.use(errorHandler(logger));

  return { app, oauth };
}

/** 待ち受けに失敗したときの文（敬体）。ポートが使われているときは、変え方まで伝える */
export function listenFailure(error: Error & { code?: string }, config: Pick<Config, "httpHost" | "httpPort">): string {
  if (error.code === "EADDRINUSE") {
    return `ポート ${config.httpPort} は、ほかのプログラムが使っています。前に起動した HTTP 版が残っていれば止めるか、.env の MCP_HTTP_PORT を別の数（例: ${config.httpPort === 8788 ? 8789 : 8788}）に変えてください。変えたときは cloudflared の --url のポートも同じにしてください（README の 15 章）。`;
  }
  if (error.code === "EADDRNOTAVAIL") {
    return `${config.httpHost} では待ち受けられません。.env の MCP_HTTP_HOST をご確認ください（既定は 127.0.0.1）。`;
  }
  return `HTTP で待ち受けられませんでした（${error.code ?? error.message}）。.env の MCP_HTTP_HOST と MCP_HTTP_PORT をご確認ください。`;
}

async function main(): Promise<void> {
  const clock = () => new Date();
  const booted = await boot({ mode: "http", processEnv: process.env, kitDir: kitDirOf(import.meta.url), stderr: stderrSink, fetch: (url, init) => fetch(url, init), clock });
  if (booted === null) {
    process.exitCode = 1;
    return;
  }
  const { config, logger, registry } = booted;
  const { app } = createHttpApp({ registry, config, logger, clock });
  // Express 5 は待ち受けに失敗したときも、このコールバックを誤りを添えて呼ぶ
  app.listen(config.httpPort, config.httpHost, (error?: Error) => {
    if (error) {
      stderrSink(listenFailure(error, config));
      process.exitCode = 1;
      return;
    }
    logger.info(`HTTP で待ち受けています: http://${config.httpHost}:${config.httpPort}/mcp`);
    if (config.publicUrl !== "") logger.info(`外からの URL: ${config.publicUrl}/mcp（ChatGPT・claude.ai のログインが使えます）`);
  });
}

// 検査から import したときは起動しない（node dist/http.js・node src/server/http.ts のときだけ起動する）
function isEntry(): boolean {
  const entry = process.argv[1];
  if (entry === undefined) return false;
  try {
    return realpathSync(entry) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}
if (isEntry()) {
  main().catch((error: unknown) => {
    stderrSink(`起動できませんでした: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  });
}
