/**
 * ChatGPT・claude.ai のための、合い言葉でログインする 1 人用の OAuth（MCP_PUBLIC_URL があるときだけ）。
 * メタデータ・/register・/authorize・/token・/revoke と PKCE（S256）の照合は SDK の mcpAuthRouter が持つ。
 * 状態はディスクに持たない。すべての札は base64url(JSON).base64url(HMAC) で、署名の鍵は HKDF-SHA256(MCP_HTTP_TOKEN)。
 * 合い言葉を変えると、出した鍵はすべて使えなくなる。
 * OAuth の誤り（InvalidTokenError など）の文は英字にする。相手はクライアントのソフトで、WWW-Authenticate の見出しにも入るため。
 */
import { createHash, createHmac, hkdfSync, randomUUID, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { ipKeyGenerator } from "express-rate-limit";
import type { OAuthRegisteredClientsStore } from "@modelcontextprotocol/sdk/server/auth/clients.js";
import { InvalidClientMetadataError, InvalidGrantError, InvalidTokenError } from "@modelcontextprotocol/sdk/server/auth/errors.js";
import type { AuthorizationParams, OAuthServerProvider } from "@modelcontextprotocol/sdk/server/auth/provider.js";
import type { AuthInfo } from "@modelcontextprotocol/sdk/server/auth/types.js";
import type { OAuthClientInformationFull, OAuthTokenRevocationRequest, OAuthTokens } from "@modelcontextprotocol/sdk/shared/auth.js";

export const OAUTH_INFO = "suminawa-mcp-oauth-v1";
export const SCOPE = "sheets";
export const ACCESS_TTL_SEC = 3600;
export const REFRESH_TTL_SEC = 30 * 86400;
export const CODE_TTL_SEC = 300;
export const REQUEST_TTL_SEC = 600;
/** ログインの失敗は、接続元ごとに 10 分で 5 回まで */
export const LOGIN_LIMIT = 5;
export const LOGIN_WINDOW_MS = 600000;
/**
 * 接続元を問わない失敗の上限（10 分で 20 回）。これを超えると、正しい合い言葉でも 10 分たつまで誰もログインできない。
 * 使う人が 1 人のサーバーなので、持ち主が締め出される不便より、合い言葉を総当たりされないことを取る
 * （IPv6 は接続元を多く持てるので、接続元ごとの上限だけでは止まらない）。すでに出した鍵とリフレッシュはそのまま使える。
 */
export const LOGIN_GLOBAL_LIMIT = 20;
/**
 * ログインの画面の CSP。form-action には戻り先の origin も足す（Chrome はフォームの送信のあとの 302 の行き先にも
 * form-action を当てるため、'self' だけだと ChatGPT への戻りが止まる）
 */
export function loginCsp(redirectUri: string): string {
  return `default-src 'none'; style-src 'unsafe-inline'; form-action 'self' ${new URL(redirectUri).origin}; frame-ancestors 'none'`;
}

type Payload =
  | { t: "client"; ru: string[]; n: string; m: string }
  | { t: "req"; c: string; ru: string; cc: string; st?: string; exp: number }
  | { t: "code" | "access" | "refresh"; c: string; ru?: string; cc?: string; jti: string; exp: number };

export function deriveKey(secret: string): Buffer {
  return Buffer.from(hkdfSync("sha256", secret, "", OAUTH_INFO, 32));
}

function mac(key: Buffer, body: string): string {
  return createHmac("sha256", key).update(body).digest("base64url");
}

export function seal(key: Buffer, payload: object): string {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${mac(key, body)}`;
}

export function unseal<T>(key: Buffer, token: string): T | null {
  const [body, signature, extra] = String(token).split(".");
  if (body === undefined || signature === undefined || extra !== undefined) return null;
  const want = Buffer.from(mac(key, body));
  const got = Buffer.from(signature);
  if (want.length !== got.length || !timingSafeEqual(want, got)) return null;
  try {
    return JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as T;
  } catch {
    return null;
  }
}

/** 2 つの文字が同じか。長さが違っても同じ時間で比べる（SHA-256 にしてから timingSafeEqual） */
export function sameSecret(a: string, b: string): boolean {
  const x = createHash("sha256").update(String(a)).digest();
  const y = createHash("sha256").update(String(b)).digest();
  return timingSafeEqual(x, y);
}

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch] as string);
}

/** ログインの画面（HTML 1 枚、敬体） */
export function loginPage(options: { clientName: string; host: string; request: string; message?: string }): string {
  const message = options.message ? `<p class="error" role="alert">${escapeHtml(options.message)}</p>` : "";
  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>接続の許可</title>
<style>
body { font-family: system-ui, sans-serif; background: #f6f5f2; color: #1f1f1f; margin: 0; padding: 32px 16px; }
main { max-width: 440px; margin: 0 auto; background: #fff; border: 1px solid #dddbd5; border-radius: 12px; padding: 24px; }
h1 { font-size: 20px; margin: 0 0 12px; }
p { line-height: 1.7; }
label { display: block; font-weight: 600; margin: 16px 0 6px; }
input { width: 100%; box-sizing: border-box; font-size: 16px; padding: 10px; border: 1px solid #b9b6ad; border-radius: 8px; }
button { margin-top: 16px; width: 100%; font-size: 16px; padding: 12px; border: 0; border-radius: 8px; background: #1f4e79; color: #fff; }
.error { color: #a4262c; font-weight: 600; }
</style>
</head>
<body>
<main>
<h1>接続の許可</h1>
<p>戻り先: <strong>${escapeHtml(options.host)}</strong>（名乗り: ${escapeHtml(options.clientName)}）</p>
<p>この戻り先のアプリが、このサーバーのツールを使えるようにしようとしています。名乗りはアプリが自分で付けた名前ですので、戻り先のホストをお確かめください。心当たりがある場合だけ、.env の MCP_HTTP_TOKEN と同じ合い言葉を入れて「許可する」を押してください。</p>
${message}
<form method="post" action="login">
<input type="hidden" name="request" value="${escapeHtml(options.request)}">
<label for="password">合い言葉</label>
<input id="password" name="password" type="password" autocomplete="current-password" required>
<button type="submit">許可する</button>
</form>
</main>
</body>
</html>`;
}

function allowedRedirect(uri: string): boolean {
  try {
    const url = new URL(uri);
    return url.protocol === "https:" || (url.protocol === "http:" && url.hostname === "localhost");
  } catch {
    return false;
  }
}

export class PasswordOAuthProvider implements OAuthServerProvider {
  private readonly secret: string;
  private readonly key: Buffer;
  private readonly clock: () => number;
  /** 使った認可コードと、取り消した鍵（期限まで覚えておく） */
  private readonly spent = new Map<string, number>();
  /** 合い言葉を間違えた時刻。接続元（IPv6 は /56 にまとめる）ごとと、全体 */
  private readonly failures = new Map<string, number[]>();
  private allFailures: number[] = [];

  constructor(options: { secret: string; clock: () => number }) {
    this.secret = options.secret;
    this.key = deriveKey(options.secret);
    this.clock = options.clock;
  }

  private nowSec(): number {
    return Math.floor(this.clock() / 1000);
  }

  private prune(): void {
    const now = this.nowSec();
    for (const [jti, exp] of this.spent) if (exp < now) this.spent.delete(jti);
    const nowMs = this.clock();
    const fresh = (at: number) => nowMs - at < LOGIN_WINDOW_MS;
    for (const [source, times] of this.failures) {
      const recent = times.filter(fresh);
      if (recent.length === 0) this.failures.delete(source);
      else this.failures.set(source, recent);
    }
    this.allFailures = this.allFailures.filter(fresh);
  }

  /** 失敗を覚えている接続元の数（検査用） */
  get trackedLoginSources(): number {
    return this.failures.size;
  }

  private secretFor(clientId: string): string {
    return mac(this.key, `secret.${clientId}`);
  }

  get clientsStore(): OAuthRegisteredClientsStore {
    return {
      getClient: (clientId: string) => {
        const p = unseal<Payload>(this.key, clientId);
        if (p === null || p.t !== "client") return undefined;
        const confidential = p.m !== "none";
        return {
          client_id: clientId,
          client_name: p.n,
          redirect_uris: p.ru,
          token_endpoint_auth_method: p.m,
          client_secret: confidential ? this.secretFor(clientId) : undefined,
          client_secret_expires_at: confidential ? 0 : undefined,
        } as OAuthClientInformationFull;
      },
      registerClient: (client: Omit<OAuthClientInformationFull, "client_id" | "client_id_issued_at">) => {
        const uris = client.redirect_uris.map(String);
        if (uris.length === 0 || !uris.every(allowedRedirect)) {
          throw new InvalidClientMetadataError("redirect_uris must be https:// or http://localhost URLs");
        }
        const method = client.token_endpoint_auth_method ?? "client_secret_post";
        const clientId = seal(this.key, { t: "client", ru: uris, n: String(client.client_name ?? "").slice(0, 100), m: method });
        const confidential = method !== "none";
        return {
          ...client,
          client_id: clientId,
          client_id_issued_at: this.nowSec(),
          client_secret: confidential ? this.secretFor(clientId) : undefined,
          client_secret_expires_at: confidential ? 0 : undefined,
        } as OAuthClientInformationFull;
      },
    };
  }

  async authorize(client: OAuthClientInformationFull, params: AuthorizationParams, res: Response): Promise<void> {
    const request = seal(this.key, { t: "req", c: client.client_id, ru: params.redirectUri, cc: params.codeChallenge, st: params.state, exp: this.nowSec() + REQUEST_TTL_SEC });
    this.sendPage(res, 200, params.redirectUri, { clientName: client.client_name || "名前の無いアプリ", host: new URL(params.redirectUri).host, request });
  }

  private sendPage(res: Response, status: number, redirectUri: string, options: Parameters<typeof loginPage>[0]): void {
    res.status(status);
    res.setHeader("Content-Security-Policy", loginCsp(redirectUri));
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("Cache-Control", "no-store");
    res.type("html").send(loginPage(options));
  }

  /** POST /login（本文は express.urlencoded で読んだあと） */
  handleLogin(req: Request, res: Response): void {
    const body = (req.body ?? {}) as Record<string, unknown>;
    const token = String(body.request ?? "");
    const p = unseal<Payload>(this.key, token);
    if (p === null || p.t !== "req" || p.exp < this.nowSec()) {
      res.status(400).type("text/plain").send("ログインの期限が切れました。接続の手続きを、はじめからやり直してください。");
      return;
    }
    const client = this.clientsStore.getClient(p.c) as OAuthClientInformationFull | undefined;
    const page = { clientName: client?.client_name || "名前の無いアプリ", host: new URL(p.ru).host, request: token };
    this.prune();
    const source = req.ip ? ipKeyGenerator(req.ip) : "unknown";
    const recent = this.failures.get(source) ?? [];
    if (recent.length >= LOGIN_LIMIT || this.allFailures.length >= LOGIN_GLOBAL_LIMIT) {
      this.sendPage(res, 429, p.ru, { ...page, message: "しばらく置いてからお試しください。" });
      return;
    }
    if (!sameSecret(String(body.password ?? ""), this.secret)) {
      const now = this.clock();
      this.failures.set(source, [...recent, now]);
      this.allFailures.push(now);
      this.sendPage(res, 401, p.ru, { ...page, message: "合い言葉が違います。" });
      return;
    }
    const code = seal(this.key, { t: "code", c: p.c, ru: p.ru, cc: p.cc, jti: randomUUID(), exp: this.nowSec() + CODE_TTL_SEC });
    const target = new URL(p.ru);
    target.searchParams.set("code", code);
    if (p.st !== undefined) target.searchParams.set("state", p.st);
    res.redirect(302, target.href);
  }

  private readCode(client: OAuthClientInformationFull, code: string) {
    const p = unseal<Payload>(this.key, code);
    if (p === null || p.t !== "code" || p.c !== client.client_id || p.exp < this.nowSec()) {
      throw new InvalidGrantError("Invalid or expired authorization code");
    }
    return p;
  }

  async challengeForAuthorizationCode(client: OAuthClientInformationFull, code: string): Promise<string> {
    return this.readCode(client, code).cc as string;
  }

  private issue(clientId: string): OAuthTokens {
    const now = this.nowSec();
    return {
      access_token: seal(this.key, { t: "access", c: clientId, jti: randomUUID(), exp: now + ACCESS_TTL_SEC }),
      token_type: "Bearer",
      expires_in: ACCESS_TTL_SEC,
      refresh_token: seal(this.key, { t: "refresh", c: clientId, jti: randomUUID(), exp: now + REFRESH_TTL_SEC }),
      scope: SCOPE,
    };
  }

  async exchangeAuthorizationCode(client: OAuthClientInformationFull, code: string, _verifier?: string, redirectUri?: string): Promise<OAuthTokens> {
    this.prune();
    const p = this.readCode(client, code);
    if (redirectUri !== undefined && redirectUri !== p.ru) throw new InvalidGrantError("redirect_uri does not match the authorization request");
    if (this.spent.has(p.jti)) throw new InvalidGrantError("Authorization code already used");
    this.spent.set(p.jti, p.exp);
    return this.issue(client.client_id);
  }

  async exchangeRefreshToken(client: OAuthClientInformationFull, refreshToken: string): Promise<OAuthTokens> {
    this.prune();
    const p = unseal<Payload>(this.key, refreshToken);
    if (p === null || p.t !== "refresh" || p.c !== client.client_id || p.exp < this.nowSec() || this.spent.has(p.jti)) {
      throw new InvalidGrantError("Invalid or expired refresh token");
    }
    this.spent.set(p.jti, p.exp);
    return this.issue(client.client_id);
  }

  async verifyAccessToken(token: string): Promise<AuthInfo> {
    const p = unseal<Payload>(this.key, token);
    if (p === null || p.t !== "access" || p.exp < this.nowSec() || this.spent.has(p.jti)) {
      throw new InvalidTokenError("Invalid or expired token");
    }
    return { token, clientId: p.c, scopes: [SCOPE], expiresAt: p.exp };
  }

  async revokeToken(client: OAuthClientInformationFull, request: OAuthTokenRevocationRequest): Promise<void> {
    const p = unseal<Payload>(this.key, request.token);
    if (p !== null && (p.t === "access" || p.t === "refresh") && p.c === client.client_id) this.spent.set(p.jti, p.exp);
  }
}
