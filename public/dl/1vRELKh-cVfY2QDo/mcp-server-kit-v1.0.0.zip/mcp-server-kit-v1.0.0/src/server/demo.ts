/**
 * MCP_DEMO=1 の見本データ（架空）を、記憶の中のスプレッドシートにする。書き込みも記憶の中だけ（再起動で戻る）。
 * 業務アプリは samples/sheet-app の CSV（sheet-app-gas の「顧客管理」の見本の写し）、予約と書類読み取りは samples/booking・samples/doc-reader の JSON。
 * ファイル名は英字にする（zip の中の日本語のファイル名は、Windows で展開すると文字化けするため）。
 */
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { addDays, writeCell } from "../core/values.ts";
import { userEntered, type FakeBook } from "../google/fake.ts";
import { compactDate, fromSheetValue, parseDefinition, pad2, type Column } from "../vendor/sheet-app/index.js";

export const DEMO_IDS = {
  sheetApp: "demo-sheet-app-spreadsheet",
  booking: "demo-booking-spreadsheet",
  docReader: "demo-doc-reader-spreadsheet",
};

/** RFC 4180 の CSV（引用符・引用符の中のカンマと改行・"" のエスケープ）。先頭の BOM は落とす */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const source = text.replace(/^﻿/, "");
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (quoted) {
      if (ch === '"' && source[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(cell);
      cell = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && source[i + 1] === "\n") i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else cell += ch;
  }
  if (cell !== "" || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

/** 業務アプリの見本: シート名 → ファイル名 */
export const SHEET_APP_SAMPLE_FILES: Record<string, string> = { 定義: "definition.csv", 顧客: "customers.csv", 対応履歴: "contacts.csv" };

function sheetAppBook(dir: string): FakeBook {
  const read = (name: string) => parseCsv(readFileSync(join(dir, "sheet-app", SHEET_APP_SAMPLE_FILES[name]), "utf8"));
  const definition = read("定義");
  const { tables } = parseDefinition(definition);
  const sheets: Record<string, unknown[][]> = { 定義: definition, _ごみ箱: [["元テーブル", "ID", "削除日時", "削除者", "行の内容（JSON）"]] };
  for (const table of tables) {
    const [header, ...body] = read(table.name);
    const columns = header.map((name) => table.columns.find((c) => c.name === name));
    // GAS が書いた形にそろえる（文字は文字、日付はシリアル値、金額は数、チェックは真偽）
    sheets[table.name] = [header, ...body.map((row) => row.map((text, i) => (columns[i] === undefined ? text : userEntered(writeCell(columns[i] as Column, fromSheetValue(columns[i] as Column, text))))))];
  }
  return { sheets };
}

interface DemoBooking {
  received: number;
  day: number;
  start: string;
  end: string;
  service: string;
  name: string;
  email: string;
  wish: string;
  status: string;
}

function bookingBook(dir: string, today: string): FakeBook {
  const { bookings } = JSON.parse(readFileSync(join(dir, "booking", "bookings.json"), "utf8")) as { bookings: DemoBooking[] };
  const header = ["ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話", "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用"];
  const perDay = new Map<string, number>();
  const rows = bookings.map((b, i) => {
    const receivedOn = addDays(today, b.received);
    const sequence = (perDay.get(receivedOn) ?? 0) + 1;
    perDay.set(receivedOn, sequence);
    const cancelled = b.status === "キャンセル";
    return [
      `${compactDate(receivedOn)}-${String(sequence).padStart(3, "0")}`,
      b.status,
      addDays(today, b.day),
      b.start,
      b.end,
      b.service,
      b.name,
      b.email,
      `045-000-00${pad2(i + 1)}`,
      b.wish,
      `${receivedOn} 09:${pad2(i * 5)}:00`,
      cancelled ? `${addDays(receivedOn, 1)} 11:00:00` : "",
      cancelled ? "" : `demo-event-${i + 1}@google.com`,
      "",
      `demo-cancel-token-${String(i + 1).padStart(6, "0")}`,
    ];
  });
  return { sheets: { 予約: [header, ...rows], 枠: [["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"]], 設定: [["項目", "値"]] } };
}

function docReaderBook(dir: string, sheetName: string): FakeBook {
  const { header, rows } = JSON.parse(readFileSync(join(dir, "doc-reader", "documents.json"), "utf8")) as { header: string[]; rows: (string | number)[][] };
  return { sheets: { [sheetName]: [header, ...rows.map((row) => row.map((cell) => userEntered(cell)))] } };
}

export function demoBooks(samplesDir: string, today: string, docReaderSheet: string): Record<string, FakeBook> {
  return {
    [DEMO_IDS.sheetApp]: sheetAppBook(samplesDir),
    [DEMO_IDS.booking]: bookingBook(samplesDir, today),
    [DEMO_IDS.docReader]: docReaderBook(samplesDir, docReaderSheet),
  };
}
