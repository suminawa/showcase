/**
 * 起動の組み立て: .env → 設定の検査 → 鍵 → 各スプレッドシートを 1 回読む → 元とツールの一覧。
 * 誤りは敬体で stderr に並べ、読めた元だけで立ち上がる。全部読めなければ null（呼ぶ側が終了コード 1 で終える）。
 */
import { existsSync, readFileSync, statSync } from "node:fs";
import { dirname, isAbsolute, join } from "node:path";
import { fileURLToPath } from "node:url";
import { SOURCES, mergeEnv, parseEnvText, readConfig, type Config, type Mode, type SourceKind } from "../core/env.ts";
import { ToolError } from "../core/errors.ts";
import { createHider } from "../core/hide.ts";
import { WriteLimiter } from "../core/limits.ts";
import { createLogger, type Logger } from "../core/log.ts";
import type { Source } from "../core/tool.ts";
import { todayKey } from "../core/values.ts";
import { FakeSheets } from "../google/fake.ts";
import { TokenSource, parseServiceAccount, scopeFor, type FetchLike, type ServiceAccount } from "../google/jwt.ts";
import { MetaCache, createHttpSheets, type SheetsClient } from "../google/sheets.ts";
import { bookingSource } from "../sources/booking.ts";
import { docReaderSource } from "../sources/doc-reader.ts";
import { sheetAppSource } from "../sources/sheet-app/source.ts";
import { DEMO_IDS, demoBooks } from "./demo.ts";
import { Registry } from "./registry.ts";

export interface BootDeps {
  mode: Mode;
  processEnv: Record<string, string | undefined>;
  /** キットのフォルダ（.env と samples/ を探す場所） */
  kitDir: string;
  stderr: (line: string) => void;
  fetch: FetchLike;
  clock: () => Date;
  /** 検査用: true なら .env を一切読まない（既定の <kitDir>/.env も MCP_ENV_FILE も無視する）。買い手向けの起動では常に未指定 */
  skipEnvFile?: boolean;
}

export interface Booted {
  config: Config;
  logger: Logger;
  sheets: SheetsClient;
  spreadsheets: Partial<Record<SourceKind, string>>;
  registry: Registry;
}

/** dist/*.js（か src/server/*.ts）の場所から上へたどり、このキットの package.json があるフォルダを返す */
export function kitDirOf(moduleUrl: string): string {
  let dir = dirname(fileURLToPath(moduleUrl));
  for (let i = 0; i < 5; i += 1) {
    const pkg = join(dir, "package.json");
    if (existsSync(pkg) && readFileSync(pkg, "utf8").includes('"@suminawa/mcp-server-kit"')) return dir;
    dir = dirname(dir);
  }
  return dirname(dirname(fileURLToPath(moduleUrl)));
}

/** .env を読み、プロセスの環境変数を重ねる。skipEnvFile が true なら .env は読まず、プロセスの環境変数だけを使う */
export function loadVars(deps: Pick<BootDeps, "processEnv" | "kitDir" | "skipEnvFile">): { vars: ReturnType<typeof mergeEnv>; error: string | null } {
  if (deps.skipEnvFile === true) {
    return { vars: mergeEnv({}, deps.processEnv), error: null };
  }
  const explicit = deps.processEnv.MCP_ENV_FILE;
  const file = explicit !== undefined && explicit !== "" ? explicit : join(deps.kitDir, ".env");
  if (!existsSync(file)) {
    const vars = mergeEnv({}, deps.processEnv);
    return { vars, error: explicit ? "MCP_ENV_FILE のファイルが見つかりません。場所をご確認ください。" : null };
  }
  return { vars: mergeEnv(parseEnvText(readFileSync(file, "utf8")), deps.processEnv), error: null };
}

/** サービス アカウントの鍵を読む。読めなければ敬体の文を stderr に書いて null */
export function loadAccount(config: Config, kitDir: string, stderr: (line: string) => void): ServiceAccount | null {
  let text = config.serviceAccountJson;
  if (config.serviceAccountFile !== "") {
    const path = isAbsolute(config.serviceAccountFile) ? config.serviceAccountFile : join(kitDir, config.serviceAccountFile);
    if (!existsSync(path)) {
      stderr("GOOGLE_SERVICE_ACCOUNT_FILE のファイルが見つかりません。Google Cloud でダウンロードした JSON の置き場所と名前をご確認ください（README の 4 章の 5）。");
      return null;
    }
    if (process.platform !== "win32" && (statSync(path).mode & 0o077) !== 0) {
      stderr("鍵のファイルがほかの利用者からも読める状態です。chmod 600 で持ち主だけにすることをおすすめします。");
    }
    text = readFileSync(path, "utf8");
  }
  const account = parseServiceAccount(text);
  if (account === null) {
    stderr("サービス アカウントの鍵を読めませんでした。ダウンロードした JSON をそのまま指しているかご確認ください（client_email と private_key が必要です）。");
  }
  return account;
}

export async function boot(deps: BootDeps): Promise<Booted | null> {
  const loaded = loadVars(deps);
  const { config, errors, warnings } = readConfig(loaded.vars, deps.mode);
  if (loaded.error !== null) errors.unshift(loaded.error);
  for (const line of warnings) deps.stderr(line);
  if (errors.length > 0) {
    for (const line of errors) deps.stderr(line);
    return null;
  }
  const logger = createLogger(config.log, deps.stderr, deps.clock);

  let sheets: SheetsClient;
  const wanted: Partial<Record<SourceKind, string>> = {};
  if (config.demo) {
    sheets = new FakeSheets(demoBooks(join(deps.kitDir, "samples"), todayKey(deps.clock()), config.docReaderSheet));
    Object.assign(wanted, DEMO_IDS);
  } else {
    const account = loadAccount(config, deps.kitDir, deps.stderr);
    if (account === null) return null;
    const tokens = new TokenSource(account, scopeFor(config.write), deps.fetch, () => deps.clock().getTime());
    const envNames: Record<string, string> = {};
    for (const kind of Object.keys(SOURCES) as SourceKind[]) {
      const id = config.spreadsheets[kind];
      if (id === null) continue;
      wanted[kind] = id;
      envNames[id] = SOURCES[kind].env;
    }
    sheets = createHttpSheets({
      token: () => tokens.token(),
      fetch: deps.fetch,
      sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
      clientEmail: account.client_email,
      envNames,
      logger,
    });
  }

  const meta = new MetaCache(sheets);
  const opened: Partial<Record<SourceKind, string>> = {};
  for (const kind of Object.keys(wanted) as SourceKind[]) {
    const id = wanted[kind] as string;
    try {
      const info = await meta.get(id, deps.clock().getTime());
      opened[kind] = id;
      if (info.timeZone !== "Asia/Tokyo") {
        deps.stderr(`${SOURCES[kind].label}: スプレッドシートのタイムゾーンが Asia/Tokyo ではありません（ファイル → 設定）。日付が 1 日ずれることがあります。`);
      }
    } catch (error) {
      if (!(error instanceof ToolError)) throw error;
      deps.stderr(`${SOURCES[kind].label}（${SOURCES[kind].env}）: ${error.message}`);
    }
  }
  if (Object.keys(opened).length === 0) {
    deps.stderr("開けたスプレッドシートがありません。上の案内をご確認ください。");
    return null;
  }

  const hider = createHider(config);
  const sources: Source[] = [];
  if (opened.sheetApp) sources.push(sheetAppSource({ sheets, meta, spreadsheetId: opened.sheetApp, config, hider }));
  if (opened.booking) sources.push(bookingSource({ sheets, meta, spreadsheetId: opened.booking, config, hider }));
  if (opened.docReader) sources.push(docReaderSource({ sheets, meta, spreadsheetId: opened.docReader, sheetName: config.docReaderSheet, hider }));
  const registry = new Registry({ sources, limiter: new WriteLimiter(), logger, clock: deps.clock });

  const labels = (Object.keys(opened) as SourceKind[]).map((kind) => SOURCES[kind].label).join("・");
  logger.info(`起動しました（${deps.mode}${config.demo ? "・見本データ" : ""}。元: ${labels}。書き込み: ${config.write ? "あり" : "なし"}）`);
  return { config, logger, sheets, spreadsheets: opened, registry };
}
