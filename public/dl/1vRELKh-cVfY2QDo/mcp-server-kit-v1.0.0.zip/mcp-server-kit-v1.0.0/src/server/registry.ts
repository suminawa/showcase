/**
 * 有効な元 → ツールの一覧、名前 → 処理の振り分け。引数の検査・書き込みの 1 分の上限・1 行ログ・失敗の文をここでまとめる。
 */
import type { CallToolResult, Tool } from "@modelcontextprotocol/sdk/types.js";
import { checkArgs } from "../core/args.ts";
import { E, ToolError, errorText } from "../core/errors.ts";
import type { WriteLimiter } from "../core/limits.ts";
import type { Logger } from "../core/log.ts";
import type { Source, ToolDef } from "../core/tool.ts";

export interface RegistryOptions {
  sources: Source[];
  limiter: WriteLimiter;
  logger: Logger;
  clock: () => Date;
}

function rowsOf(out: Record<string, unknown>): number | undefined {
  if (typeof out.count === "number") return out.count;
  if (out.row !== undefined || out.booking !== undefined || out.document !== undefined) return 1;
  if (Array.isArray(out.tables)) return out.tables.length;
  return undefined;
}

export class Registry {
  private readonly options: RegistryOptions;
  constructor(options: RegistryOptions) {
    this.options = options;
  }

  async tools(): Promise<ToolDef[]> {
    const now = this.options.clock();
    const all: ToolDef[] = [];
    for (const source of this.options.sources) {
      try {
        all.push(...(await source.tools(now)));
      } catch (error) {
        this.options.logger.info("ツールの一覧を作れない元がありました（MCP_LOG=debug で詳しく出ます）");
        this.options.logger.debug(error instanceof Error ? (error.stack ?? error.message) : String(error));
      }
    }
    return all;
  }

  /** tools/list に出す形 */
  async list(): Promise<Tool[]> {
    return (await this.tools()).map((tool) => ({
      name: tool.name,
      title: tool.title,
      description: tool.description,
      inputSchema: tool.inputSchema as Tool["inputSchema"],
      outputSchema: tool.outputSchema as Tool["outputSchema"],
      annotations: { title: tool.title, ...tool.annotations },
    }));
  }

  /** ツールの形の目印（定義が変わってツールが変わったかを比べる） */
  static signature(tools: Tool[]): string {
    return JSON.stringify(tools.map((tool) => [tool.name, tool.inputSchema]));
  }

  async call(name: string, rawArgs: Record<string, unknown> | undefined): Promise<CallToolResult> {
    const started = this.options.clock();
    const args = rawArgs ?? {};
    const argNames = Object.keys(args);
    const finish = (result: string, rows?: number) =>
      this.options.logger.call({ tool: name, ms: this.options.clock().getTime() - started.getTime(), result, rows, argNames });
    try {
      const tool = (await this.tools()).find((t) => t.name === name);
      if (tool === undefined) throw E.unknownTool(name);
      tool.beforeCheck?.(args);
      const problems = checkArgs(tool.inputSchema, args);
      if (problems.length > 0) throw E.invalidArguments(problems);
      if (tool.write && !this.options.limiter.take(started.getTime())) throw E.writeRate();
      const out = await tool.run(args, started);
      finish("ok", rowsOf(out));
      return { content: [{ type: "text", text: JSON.stringify(out) }], structuredContent: out };
    } catch (error) {
      const failure = error instanceof ToolError ? error : E.internal();
      if (!(error instanceof ToolError)) this.options.logger.debug(error instanceof Error ? (error.stack ?? error.message) : String(error));
      finish(failure.code);
      return { isError: true, content: [{ type: "text", text: errorText(failure) }] };
    }
  }
}
