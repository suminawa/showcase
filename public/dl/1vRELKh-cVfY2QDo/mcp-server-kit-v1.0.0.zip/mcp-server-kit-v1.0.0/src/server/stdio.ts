/**
 * 入口 (a): stdio（Claude Desktop・Claude Code・Cursor）。stdout はプロトコル専用で、ログは stderr だけに書く。
 */
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { ToolError } from "../core/errors.ts";
import { stderrSink } from "../core/log.ts";
import { boot, kitDirOf } from "./boot.ts";
import { createServer } from "./create.ts";

async function main(): Promise<void> {
  const booted = await boot({
    mode: "stdio",
    processEnv: process.env,
    kitDir: kitDirOf(import.meta.url),
    stderr: stderrSink,
    fetch: (url, init) => fetch(url, init),
    clock: () => new Date(),
    // 検査（煙の検査の子プロセス）専用。買い手の起動では立てない: 実物の .env をこの検査だけ読ませないため
    skipEnvFile: process.env.MCP_ENV_FILE_SKIP === "1",
  });
  if (booted === null) {
    process.exitCode = 1;
    return;
  }
  const server = createServer(booted.registry, { listChanged: true });
  await server.connect(new StdioServerTransport());
}

main().catch((error: unknown) => {
  if (error instanceof ToolError) {
    stderrSink(`起動できませんでした: ${error.message}`);
  } else {
    stderrSink("起動の途中で失敗しました。MCP_LOG=debug で詳しい記録を出せます。");
    if (process.env.MCP_LOG === "debug") {
      stderrSink(`[debug] ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  process.exitCode = 1;
});
