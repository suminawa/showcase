/**
 * サービス アカウントの JWT → アクセストークン。node:crypto だけで署名し、トークンは記憶の中で使い回す（ディスクに書かない）。
 */
import { createPrivateKey, createSign } from "node:crypto";
import { E } from "../core/errors.ts";

export const SCOPE_READ = "https://www.googleapis.com/auth/spreadsheets.readonly";
export const SCOPE_WRITE = "https://www.googleapis.com/auth/spreadsheets";
export const DEFAULT_TOKEN_URI = "https://oauth2.googleapis.com/token";
/** 期限の 5 分前になったら取り直す */
const REFRESH_MARGIN_SEC = 300;
const TIMEOUT_MS = 20000;

export interface ServiceAccount {
  client_email: string;
  private_key: string;
  token_uri: string;
}

export type FetchLike = (url: string, init?: RequestInit) => Promise<Response>;

/** 書かない設定では readonly の scope（鍵が漏れても書けない） */
export function scopeFor(write: boolean): string {
  return write ? SCOPE_WRITE : SCOPE_READ;
}

/** 鍵の JSON（そのままか base64）を読む。client_email と private_key が無いか、秘密鍵として読めなければ null */
export function parseServiceAccount(text: string): ServiceAccount | null {
  const candidates = [text.trim()];
  if (!text.trim().startsWith("{")) candidates.push(Buffer.from(text.trim(), "base64").toString("utf8"));
  for (const candidate of candidates) {
    try {
      const json = JSON.parse(candidate) as Record<string, unknown>;
      if (typeof json.client_email === "string" && typeof json.private_key === "string" && json.private_key.includes("PRIVATE KEY")) {
        // 中身の崩れた鍵は、ここで読めないものとして扱う（署名のときに初めて落ちると、接続の誤りに見えるため）
        createPrivateKey(json.private_key);
        const tokenUri = typeof json.token_uri === "string" && json.token_uri !== "" ? json.token_uri : DEFAULT_TOKEN_URI;
        return { client_email: json.client_email, private_key: json.private_key, token_uri: tokenUri };
      }
    } catch {
      // 次の候補へ
    }
  }
  return null;
}

function base64url(input: string | Buffer): string {
  return Buffer.from(input).toString("base64url");
}

/** RS256 の JWT（iss・scope・aud・iat・exp = iat + 3600） */
export function signJwt(account: ServiceAccount, scope: string, nowSec: number): string {
  const header = base64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claims = base64url(JSON.stringify({ iss: account.client_email, scope, aud: account.token_uri, iat: nowSec, exp: nowSec + 3600 }));
  const signer = createSign("RSA-SHA256");
  signer.update(`${header}.${claims}`);
  return `${header}.${claims}.${signer.sign(account.private_key).toString("base64url")}`;
}

export class TokenSource {
  private readonly account: ServiceAccount;
  private readonly scope: string;
  private readonly fetchFn: FetchLike;
  private readonly clock: () => number;
  private cached: { token: string; expiresAtSec: number } | null = null;

  constructor(account: ServiceAccount, scope: string, fetchFn: FetchLike, clock: () => number = () => Date.now()) {
    this.account = account;
    this.scope = scope;
    this.fetchFn = fetchFn;
    this.clock = clock;
  }

  async token(): Promise<string> {
    const nowSec = Math.floor(this.clock() / 1000);
    if (this.cached !== null && this.cached.expiresAtSec - REFRESH_MARGIN_SEC > nowSec) return this.cached.token;
    const body = new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: signJwt(this.account, this.scope, nowSec),
    });
    let response: Response;
    try {
      response = await this.fetchFn(this.account.token_uri, {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: body.toString(),
        signal: AbortSignal.timeout(TIMEOUT_MS),
      });
    } catch (error) {
      throw E.unavailable(error instanceof Error && error.name === "TimeoutError" ? "時間切れ" : "接続できませんでした");
    }
    if (response.status === 400 || response.status === 401) throw E.authFailed();
    if (!response.ok) throw E.unavailable(String(response.status));
    const json = (await response.json()) as { access_token?: string; expires_in?: number };
    if (typeof json.access_token !== "string") throw E.authFailed();
    this.cached = { token: json.access_token, expiresAtSec: nowSec + (json.expires_in ?? 3600) };
    return json.access_token;
  }
}
