/**
 * 記憶の中のスプレッドシート（MCP_DEMO=1 と検査で使う）。
 * USER_ENTERED の読み替え（' を落として文字、"2026-09-16" を日付のシリアル値、TRUE/FALSE を真偽、数の文字を数）と、
 * UNFORMATTED_VALUE・SERIAL_NUMBER での返し方（行末の空のセルと、末尾の空の行を返さない）を真似る。
 */
import type { ToolError } from "../core/errors.ts";
import { dateKeyToSerial } from "../core/values.ts";
import type { Cell, SheetsClient, SpreadsheetMeta } from "./sheets.ts";

export interface FakeBook {
  timeZone?: string;
  sheets: Record<string, unknown[][]>;
}

export type FakeMethod = "meta" | "get" | "batchGet" | "append" | "update";

/** USER_ENTERED で書いた値が、シートの中でどう持たれるか */
export function userEntered(value: Cell): unknown {
  if (typeof value !== "string") return value;
  if (value.startsWith("'")) return value.slice(1);
  if (value === "") return "";
  const date = value.match(/^(\d{4}-\d{2}-\d{2})(?: (\d{2}):(\d{2})(?::(\d{2}))?)?$/);
  if (date) {
    const serial = dateKeyToSerial(date[1]);
    if (date[2] === undefined) return serial;
    return serial + (Number(date[2]) * 3600 + Number(date[3]) * 60 + Number(date[4] ?? 0)) / 86400;
  }
  if (/^(true|false)$/i.test(value)) return value.toLowerCase() === "true";
  if (/^-?\d+(\.\d+)?$/.test(value)) return Number(value);
  return value;
}

function columnNumber(letters: string): number {
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n;
}

/** '顧客'!A1:ZZ・'顧客'!A5:P5・'顧客'!C5・'顧客'!A1:A を読む（行・列は 1 始まり。終わりが無ければ null） */
export function parseRange(range: string): { sheet: string; col1: number; row1: number; col2: number | null; row2: number | null } {
  const matched = range.match(/^'((?:[^']|'')*)'(?:!([A-Z]+)(\d*)(?::([A-Z]+)(\d*))?)?$/);
  if (!matched) throw new Error(`偽のシート: 範囲を読めません: ${range}`);
  const sheet = matched[1].replace(/''/g, "'");
  const col1 = matched[2] ? columnNumber(matched[2]) : 1;
  const row1 = matched[3] ? Number(matched[3]) : 1;
  if (matched[4] === undefined) {
    const single = matched[2] !== undefined && matched[3] !== "";
    return { sheet, col1, row1, col2: single ? col1 : null, row2: single ? row1 : null };
  }
  return { sheet, col1, row1, col2: columnNumber(matched[4]), row2: matched[5] ? Number(matched[5]) : null };
}

function isEmptyCell(value: unknown): boolean {
  return value === "" || value === null || value === undefined;
}

function trimmed(rows: unknown[][]): unknown[][] {
  const out = rows.map((row) => {
    const copy = row.map((cell) => (cell === undefined || cell === null ? "" : cell));
    while (copy.length > 0 && isEmptyCell(copy[copy.length - 1])) copy.pop();
    return copy;
  });
  while (out.length > 0 && out[out.length - 1].length === 0) out.pop();
  return out;
}

export class FakeSheets implements SheetsClient {
  readonly clientEmail: string;
  readonly books = new Map<string, { timeZone: string; sheets: Map<string, unknown[][]> }>();
  /** 呼ばれた順の記録（検査で「書いたのはセル単位か」などを見る） */
  readonly calls: { method: FakeMethod; ranges: string[] }[] = [];
  /** 呼ばれるたびに、呼び出しの前に動く（同じ時刻にほかの人が書いた、を真似る） */
  onCall: ((method: FakeMethod, ranges: string[], index: number) => void) | null = null;
  private readonly failures: { method: FakeMethod; error: ToolError }[] = [];

  constructor(books: Record<string, FakeBook>, clientEmail = "mcp-demo@example.iam.gserviceaccount.com") {
    this.clientEmail = clientEmail;
    for (const [id, book] of Object.entries(books)) {
      const sheets = new Map<string, unknown[][]>();
      for (const [name, rows] of Object.entries(book.sheets)) sheets.set(name, rows.map((row) => [...row]));
      this.books.set(id, { timeZone: book.timeZone ?? "Asia/Tokyo", sheets });
    }
  }

  /** 次にその呼び方をしたとき、error で失敗させる */
  failNext(method: FakeMethod, error: ToolError): void {
    this.failures.push({ method, error });
  }

  /** シートの中身（検査で直接見る・書き換える） */
  sheet(id: string, name: string): unknown[][] {
    const rows = this.book(id).sheets.get(name);
    if (rows === undefined) throw new Error(`偽のシート: ${name} がありません`);
    return rows;
  }

  private book(id: string) {
    const book = this.books.get(id);
    if (book === undefined) throw new Error(`偽のシート: スプレッドシート ${id} がありません`);
    return book;
  }

  private before(method: FakeMethod, ranges: string[]): void {
    const at = this.failures.findIndex((failure) => failure.method === method);
    if (at >= 0) {
      const [failure] = this.failures.splice(at, 1);
      throw failure.error;
    }
    this.onCall?.(method, ranges, this.calls.length);
    this.calls.push({ method, ranges });
  }

  private read(id: string, range: string): unknown[][] {
    const r = parseRange(range);
    const rows = this.book(id).sheets.get(r.sheet);
    if (rows === undefined) throw new Error(`偽のシート: ${r.sheet} がありません（本物は 400 を返します）`);
    const lastRow = r.row2 ?? rows.length;
    const picked = rows.slice(r.row1 - 1, lastRow).map((row) => {
      const out: unknown[] = [];
      const end = r.col2 ?? Math.max(row.length, r.col1);
      for (let c = r.col1; c <= end; c += 1) out.push(row[c - 1] ?? "");
      return out;
    });
    return trimmed(picked);
  }

  async meta(id: string): Promise<SpreadsheetMeta> {
    this.before("meta", []);
    const book = this.book(id);
    return {
      timeZone: book.timeZone,
      sheets: [...book.sheets.entries()].map(([title, rows], index) => ({
        title,
        sheetId: index,
        rows: Math.max(1000, rows.length),
        columns: Math.max(26, ...rows.map((row) => row.length)),
      })),
    };
  }

  async get(id: string, range: string): Promise<unknown[][]> {
    this.before("get", [range]);
    return this.read(id, range);
  }

  async batchGet(id: string, ranges: string[]): Promise<unknown[][][]> {
    this.before("batchGet", ranges);
    return ranges.map((range) => this.read(id, range));
  }

  async append(id: string, range: string, row: Cell[]): Promise<number> {
    this.before("append", [range]);
    const r = parseRange(range);
    const rows = this.sheet(id, r.sheet);
    let last = rows.length;
    while (last > 0 && rows[last - 1].every(isEmptyCell)) last -= 1;
    rows.splice(last, rows.length - last, row.map(userEntered));
    return last + 1;
  }

  async update(id: string, cells: { range: string; value: Cell }[]): Promise<void> {
    this.before("update", cells.map((cell) => cell.range));
    for (const cell of cells) {
      const r = parseRange(cell.range);
      const rows = this.sheet(id, r.sheet);
      while (rows.length < r.row1) rows.push([]);
      const row = rows[r.row1 - 1];
      while (row.length < r.col1) row.push("");
      row[r.col1 - 1] = userEntered(cell.value);
    }
  }
}
