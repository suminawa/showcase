/**
 * Sheets API v4 を fetch で呼ぶ小さな面。本物（createHttpSheets）と偽物（fake.ts の FakeSheets）を差し替える。
 * 読みは UNFORMATTED_VALUE + SERIAL_NUMBER、書きは USER_ENTERED。
 */
import { rowOfRange } from "../core/a1.ts";
import { E, fromGoogleStatus } from "../core/errors.ts";
import type { Logger } from "../core/log.ts";
import type { FetchLike } from "./jwt.ts";

export type Cell = string | number | boolean;

export interface SheetInfo {
  title: string;
  sheetId: number;
  rows: number;
  columns: number;
}

export interface SpreadsheetMeta {
  timeZone: string;
  sheets: SheetInfo[];
}

export interface SheetsClient {
  /** サービス アカウントのメール（共有の案内に使う。秘密ではない） */
  readonly clientEmail: string;
  meta(spreadsheetId: string): Promise<SpreadsheetMeta>;
  get(spreadsheetId: string, range: string): Promise<unknown[][]>;
  batchGet(spreadsheetId: string, ranges: string[]): Promise<unknown[][][]>;
  /** 1 行を末尾に足し、足した行の番号（1 始まり）を返す */
  append(spreadsheetId: string, range: string, row: Cell[]): Promise<number>;
  /** 1 セル 1 範囲で書き換える */
  update(spreadsheetId: string, cells: { range: string; value: Cell }[]): Promise<void>;
}

const BASE = "https://sheets.googleapis.com/v4/spreadsheets/";
const READ_OPTIONS = "valueRenderOption=UNFORMATTED_VALUE&dateTimeRenderOption=SERIAL_NUMBER";
/** 再試行の待ち（1 秒・3 秒の 2 回まで） */
export const RETRY_WAITS = [1000, 3000];
const READ_RETRY = [429, 500, 502, 503, 504];
/** 書き込みは 429 だけ再試行する（5xx は書けたかどうか分からないので、二重に足さない） */
const WRITE_RETRY = [429];

export interface HttpSheetsOptions {
  token: () => Promise<string>;
  fetch: FetchLike;
  sleep: (ms: number) => Promise<void>;
  clientEmail: string;
  /** スプレッドシートの ID → .env の名前（「見つかりませんでした」の案内に使う） */
  envNames: Record<string, string>;
  logger?: Logger;
  timeoutMs?: number;
}

export function createHttpSheets(options: HttpSheetsOptions): SheetsClient {
  const timeoutMs = options.timeoutMs ?? 20000;

  async function call(id: string, method: "GET" | "POST", path: string, write: boolean, body?: unknown, label = path): Promise<unknown> {
    const context = { write, clientEmail: options.clientEmail, envName: options.envNames[id] ?? "スプレッドシート" };
    const retry = write ? WRITE_RETRY : READ_RETRY;
    for (let attempt = 0; ; attempt += 1) {
      let status: number;
      let response: Response | null = null;
      let token: string;
      try {
        token = await options.token();
      } catch (error) {
        // 鍵で署名できない・トークンを受け取れないなどの思わぬ例外は、接続の誤りではなく認証の誤りとして返す
        if (error instanceof Error && error.name === "ToolError") throw error;
        options.logger?.debug(`sheets token ${error instanceof Error ? error.name : "error"}`);
        throw E.authFailed();
      }
      try {
        response = await options.fetch(BASE + id + path, {
          method,
          headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
          body: body === undefined ? undefined : JSON.stringify(body),
          signal: AbortSignal.timeout(timeoutMs),
        });
        status = response.status;
      } catch (error) {
        if (error instanceof Error && error.name === "ToolError") throw error;
        status = error instanceof Error && error.name === "TimeoutError" ? -1 : 0;
      }
      options.logger?.debug(`sheets ${method} ${label} ${status}`);
      if (response !== null && response.ok) return response.json();
      if (retry.includes(status) && attempt < RETRY_WAITS.length) {
        await options.sleep(RETRY_WAITS[attempt]);
        continue;
      }
      // 403 は本文で「API が無効」と「共有が無い」を見分ける（本文は誤りの文には入れない）
      const detail = status === 403 && response !== null ? await response.text().catch(() => "") : "";
      throw fromGoogleStatus(status, context, detail);
    }
  }

  return {
    clientEmail: options.clientEmail,
    async meta(id) {
      const json = (await call(id, "GET", "?fields=properties.timeZone,sheets.properties(title,sheetId,gridProperties)", false, undefined, "meta")) as {
        properties?: { timeZone?: string };
        sheets?: { properties: { title: string; sheetId: number; gridProperties?: { rowCount?: number; columnCount?: number } } }[];
      };
      return {
        timeZone: json.properties?.timeZone ?? "",
        sheets: (json.sheets ?? []).map(({ properties }) => ({
          title: properties.title,
          sheetId: properties.sheetId,
          rows: properties.gridProperties?.rowCount ?? 0,
          columns: properties.gridProperties?.columnCount ?? 0,
        })),
      };
    },
    async get(id, range) {
      const json = (await call(id, "GET", `/values/${encodeURIComponent(range)}?${READ_OPTIONS}`, false, undefined, range)) as { values?: unknown[][] };
      return json.values ?? [];
    },
    async batchGet(id, ranges) {
      const query = ranges.map((range) => `ranges=${encodeURIComponent(range)}`).join("&");
      const json = (await call(id, "GET", `/values:batchGet?${query}&${READ_OPTIONS}`, false, undefined, ranges.join(" "))) as {
        valueRanges?: { values?: unknown[][] }[];
      };
      return ranges.map((_, index) => json.valueRanges?.[index]?.values ?? []);
    },
    async append(id, range, row) {
      const path = `/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS&includeValuesInResponse=false`;
      const json = (await call(id, "POST", path, true, { values: [row] }, range)) as { updates?: { updatedRange?: string } };
      const added = rowOfRange(json.updates?.updatedRange ?? "");
      if (added === null) throw fromGoogleStatus(0, { write: true, clientEmail: options.clientEmail, envName: options.envNames[id] ?? "" });
      return added;
    },
    async update(id, cells) {
      const body = { valueInputOption: "USER_ENTERED", data: cells.map((cell) => ({ range: cell.range, values: [[cell.value]] })) };
      await call(id, "POST", "/values:batchUpdate", true, body, cells.map((cell) => cell.range).join(" "));
    },
  };
}

/** シートの一覧とタイムゾーンを 5 分だけ覚えておく */
export class MetaCache {
  private readonly sheets: SheetsClient;
  private readonly ttlMs: number;
  private readonly cache = new Map<string, { at: number; meta: SpreadsheetMeta }>();
  constructor(sheets: SheetsClient, ttlMs = 300000) {
    this.sheets = sheets;
    this.ttlMs = ttlMs;
  }
  async get(id: string, nowMs: number): Promise<SpreadsheetMeta> {
    const hit = this.cache.get(id);
    if (hit !== undefined && nowMs - hit.at < this.ttlMs) return hit.meta;
    const meta = await this.sheets.meta(id);
    this.cache.set(id, { at: nowMs, meta });
    return meta;
  }
  async titles(id: string, nowMs: number): Promise<string[]> {
    return (await this.get(id, nowMs)).sheets.map((sheet) => sheet.title);
  }
}
