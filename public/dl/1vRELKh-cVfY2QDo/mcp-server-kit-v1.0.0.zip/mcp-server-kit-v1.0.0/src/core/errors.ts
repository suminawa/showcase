/**
 * ツールの失敗。AI が読んで利用者に伝えられる敬体の文と、英字の code を持つ。
 * 内部の例外文・スタック・Google の生の応答は、この文に入れない。
 */

export class ToolError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = "ToolError";
    this.code = code;
  }
}

/** ツールの返りに入れる文（「…。（code: xxx）」） */
export function errorText(error: ToolError): string {
  return `${error.message}（code: ${error.code}）`;
}

export const E = {
  invalidArguments: (details: string[]) => new ToolError("invalid_arguments", `引数に誤りがあります: ${details.join("／")}。`),
  unknownTool: (name: string) => new ToolError("unknown_tool", `ツール「${name}」はありません。ツールの一覧を読み直してから、もう一度お試しください。`),
  unknownTable: (name: string) => new ToolError("unknown_table", `テーブル「${name}」はありません。list_tables でテーブルの名前をご確認ください。`),
  unknownColumn: (column: string, table: string, usable: string[]) =>
    new ToolError("unknown_column", `列「${column}」は「${table}」にありません。使える列: ${usable.join("、")}。`),
  hiddenColumn: (column: string) => new ToolError("hidden_column", `列「${column}」は、このサーバーからは読み書きできない設定です。`),
  rowNotFound: (id: string, table: string) => new ToolError("row_not_found", `ID「${id}」の行は「${table}」にありません。search_rows で ID をご確認ください。`),
  validation: (errors: Record<string, string>) =>
    new ToolError("validation", `入力に誤りがあります。${Object.entries(errors).map(([column, text]) => `${column}: ${text}`).join("／")}。`),
  conflict: (updatedAt: string) =>
    new ToolError("conflict", `この行は、読み込んだあとにほかの方が更新しています${updatedAt === "" ? "" : `（更新日時 ${updatedAt}）`}。get_row で読み直してから、もう一度お試しください。`),
  rowMoved: () => new ToolError("row_moved", "書き込む直前に行の位置が変わったため、書き込みを止めました。もう一度お試しください。"),
  idConflict: (sheet: string, row: number, id: string) =>
    new ToolError(
      "id_conflict",
      `同じ時刻にほかの登録が重なり、重ならない ID を決められませんでした。行は「${sheet}」シートの ${row} 行目に、ID「${id}」（ほかの行と同じ ID）で追加されています。同じ行が 2 つにならないよう、もう一度登録する前に search_rows でこの行をご確認ください。`,
    ),
  addedRowMoved: (sheet: string, row: number, id: string) =>
    new ToolError(
      "added_row_moved",
      `行は「${sheet}」シートに ID「${id}」で追加しましたが（追加したときは ${row} 行目）、ID の重なりを確かめる前に行の位置が変わったため、確かめを止めました。ほかの操作をする前に、search_rows でこの行と、同じ ID の行が無いかをご確認ください。`,
    ),
  addedUnconfirmed: (sheet: string, row: number, ids: string[]) =>
    new ToolError(
      "added_unconfirmed",
      `行を追加したあとの確かめの途中で、Google とのやり取りに失敗しました。行は「${sheet}」シートの ${row} 行目に、ID「${ids[0]}」${ids.slice(1).map((id) => `（または「${id}」）`).join("")}で追加されている可能性があります。同じ行が 2 つにならないよう、もう一度登録する前に search_rows でこの行をご確認ください。`,
    ),
  missingHeader: (sheet: string, header: string, kit = "業務アプリ") =>
    new ToolError("missing_header", `「${sheet}」シートに「${header}」の見出しがありません。${kit}のメニュー「初期化」を実行してから、もう一度お試しください。`),
  sheetMissing: (sheet: string, kit: string) =>
    new ToolError("sheet_missing", `スプレッドシートに「${sheet}」シートがありません。${kit}のメニュー「初期化」を実行したスプレッドシートかご確認ください。`),
  docSheetMissing: (sheet: string) =>
    new ToolError("sheet_missing", `スプレッドシートに「${sheet}」シートがありません。書類読み取りから 1 度送ると作られます。DOC_READER_SHEET のシート名もご確認ください。`),
  definitionEmpty: () => new ToolError("definition_empty", "「定義」シートにテーブルがありません。業務アプリの README「定義シートの書き方」をご覧ください。"),
  bookingNotFound: (id: string) => new ToolError("booking_not_found", `受付番号「${id}」のご予約は見つかりませんでした。`),
  alreadyCancelled: (id: string) => new ToolError("already_cancelled", `受付番号「${id}」のご予約は、すでにキャンセルになっています。`),
  pastBooking: (id: string) => new ToolError("past_booking", `受付番号「${id}」は過ぎたご予約のため、キャンセルにできません。`),
  invalidRange: () => new ToolError("invalid_range", "期間の指定に誤りがあります。from は to より前の日にし、期間は 366 日以内にしてください。"),
  documentNotFound: (id: string, sheet: string) => new ToolError("document_not_found", `書類ID「${id}」の書類は「${sheet}」シートにありません。`),
  writeRate: () => new ToolError("write_rate", "書き込みが 1 分に 20 回を超えました。1 分ほど置いてから、もう一度お試しください。"),
  apiDisabled: () =>
    new ToolError("api_disabled", "Google Sheets API が有効になっていません。README の 4 章の 2 で「有効にする」を押し、数分置いてからもう一度お試しください。"),
  noAccess: (clientEmail: string) =>
    new ToolError(
      "no_access",
      `スプレッドシートを開けませんでした。スプレッドシートの「共有」に、サービス アカウントのメール（${clientEmail}）を追加してください。書き込みも使う場合は「編集者」にしてください。`,
    ),
  readOnlyShare: () =>
    new ToolError("read_only_share", "スプレッドシートに書き込めませんでした。共有でサービス アカウントが「閲覧者」になっています。書き込みを使う場合は「編集者」にしてください。"),
  spreadsheetNotFound: (envName: string) =>
    new ToolError("spreadsheet_not_found", `スプレッドシートが見つかりませんでした。.env の ${envName} の URL か ID をご確認ください。`),
  authFailed: () =>
    new ToolError("auth_failed", "Google の認証に失敗しました。サービス アカウントの鍵が削除されていないか、パソコンの時計が合っているかをご確認ください。"),
  rateLimited: () => new ToolError("rate_limited", "Google の読み書きの上限（1 分あたり）に達しました。1 分ほど置いてから、もう一度お試しください。"),
  writeUnknown: (status: string) =>
    new ToolError(
      "write_unknown",
      `書き込みの応答を受け取れませんでした（Google の応答: ${status}）。書けているかもしれないので、シートをご確認のうえ、必要なら get_row で確かめてからやり直してください。`,
    ),
  unavailable: (status: string) => new ToolError("unavailable", `Google につながりませんでした（${status}）。少し置いてから、もう一度お試しください。`),
  internal: () => new ToolError("internal", "処理の途中で思わぬ誤りが起きました。少し置いてから、もう一度お試しください。続く場合は、サーバーのログをご確認ください。"),
};

export interface GoogleErrorContext {
  write: boolean;
  clientEmail: string;
  envName: string;
}

/** 403 の本文がこれに当たれば、共有ではなく API の無効（Google Cloud で Sheets API を有効にしていない） */
const API_DISABLED = /SERVICE_DISABLED|accessNotConfigured|has not been used/;

/** Google の応答の状態番号（0 は届かなかった、-1 は時間切れ）→ ToolError。body は 403 の見分けにだけ使い、文には入れない */
export function fromGoogleStatus(status: number, context: GoogleErrorContext, body = ""): ToolError {
  const label = status === -1 ? "時間切れ" : status === 0 ? "接続できませんでした" : String(status);
  if (status === 401) return E.authFailed();
  if (status === 403 && API_DISABLED.test(body)) return E.apiDisabled();
  if (status === 403) return context.write ? E.readOnlyShare() : E.noAccess(context.clientEmail);
  if (status === 404) return E.spreadsheetNotFound(context.envName);
  if (status === 429) return E.rateLimited();
  if (context.write && (status >= 500 || status <= 0)) return E.writeUnknown(label);
  return E.unavailable(label);
}
