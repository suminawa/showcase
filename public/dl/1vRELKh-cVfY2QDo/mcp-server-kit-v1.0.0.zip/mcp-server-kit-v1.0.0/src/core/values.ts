/**
 * シートの値 ⇄ ツールの値。読むときは UNFORMATTED_VALUE + SERIAL_NUMBER の値を、書くときは USER_ENTERED の値を扱う。
 * 時刻の基準は Asia/Tokyo 固定。シリアル値はシートのタイムゾーンの暦日なので、時差を足さない。
 */
import { fromSheetValue, pad2, safeCell, textOf, toDateKey, type Column } from "../vendor/sheet-app/index.js";

const DAY_MS = 86400000;
/** シリアル値 0 の日（1899-12-30） */
const EPOCH_MS = Date.UTC(1899, 11, 30);
const JST_OFFSET_MS = 9 * 3600000;

function serialParts(serial: number): { date: Date; seconds: number } {
  const totalSeconds = Math.round(serial * 86400);
  const days = Math.floor(totalSeconds / 86400);
  return { date: new Date(EPOCH_MS + days * DAY_MS), seconds: totalSeconds - days * 86400 };
}

function dateKeyOf(date: Date): string {
  return `${date.getUTCFullYear()}-${pad2(date.getUTCMonth() + 1)}-${pad2(date.getUTCDate())}`;
}

function timeOf(seconds: number, withSeconds: boolean): string {
  const hh = pad2(Math.floor(seconds / 3600));
  const mm = pad2(Math.floor((seconds % 3600) / 60));
  return withSeconds ? `${hh}:${mm}:${pad2(seconds % 60)}` : `${hh}:${mm}`;
}

/** シリアル値 → "YYYY-MM-DD" */
export function serialToDateKey(serial: number): string {
  return dateKeyOf(serialParts(serial).date);
}

/** シリアル値 → "YYYY-MM-DD HH:mm" */
export function serialToDateTimeKey(serial: number): string {
  const parts = serialParts(serial);
  return `${dateKeyOf(parts.date)} ${timeOf(parts.seconds, false)}`;
}

/** シリアル値 → "YYYY-MM-DD HH:mm:ss" */
export function serialToStamp(serial: number): string {
  const parts = serialParts(serial);
  return `${dateKeyOf(parts.date)} ${timeOf(parts.seconds, true)}`;
}

/** "YYYY-MM-DD" → シリアル値（検査と偽物のシートで使う） */
export function dateKeyToSerial(key: string): number {
  const [y, m, d] = key.split("-").map(Number);
  return (Date.UTC(y, m - 1, d) - EPOCH_MS) / DAY_MS;
}

/** セル → ツールの値（業務アプリの定義の列） */
export function readCell(column: Column, raw: unknown): unknown {
  if (typeof raw === "number") {
    if (column.type === "日付") return serialToDateKey(raw);
    if (column.type === "日時") return serialToDateTimeKey(raw);
    if (column.type !== "数値" && column.type !== "金額" && column.type !== "チェック") return String(raw);
  }
  return fromSheetValue(column, raw);
}

/** ID・作成日時・更新日時・更新者のセル → 文字（シリアル値なら "YYYY-MM-DD HH:mm:ss"） */
export function readSystemCell(raw: unknown): string {
  if (typeof raw === "number") return serialToStamp(raw);
  return textOf(raw);
}

/** ツールの値 → USER_ENTERED で書く値（業務アプリの GAS と同じ書き方。文字は ' を付ける） */
export function writeCell(column: Column, value: unknown): string | number | boolean {
  if (value === null || value === undefined || value === "") return "";
  switch (column.type) {
    case "数値":
    case "金額":
      return Number(value);
    case "チェック":
      return value === true;
    case "日付":
    case "日時":
      return String(value);
    case "複数選択":
      return safeCell((Array.isArray(value) ? value : [value]).join(", "));
    default:
      return safeCell(value);
  }
}

/** 日付の列ではない時刻（予約の 開始・終了）。シリアル値の小数・"10:00"・"10時"・"10時30分" を "HH:mm" に */
export function readTime(raw: unknown): string {
  if (typeof raw === "number") return timeOf(serialParts(raw - Math.floor(raw)).seconds % 86400, false);
  const text = textOf(raw);
  const matched = text.match(/^(\d{1,2})(?::|時)(\d{2})?分?$/);
  if (!matched) return text;
  const hour = Number(matched[1]);
  const minute = matched[2] === undefined ? 0 : Number(matched[2]);
  if (hour > 23 || minute > 59) return text;
  return `${pad2(hour)}:${pad2(minute)}`;
}

/** 人が手で入れたかもしれない日付のセル。読めなければ文字のまま */
export function readLooseDate(raw: unknown): string {
  if (typeof raw === "number") return serialToDateKey(raw);
  return toDateKey(raw) ?? textOf(raw);
}

/** Date → Asia/Tokyo の "YYYY-MM-DD" */
export function todayKey(now: Date): string {
  return dateKeyOf(new Date(now.getTime() + JST_OFFSET_MS));
}

/** Date → Asia/Tokyo の "YYYY-MM-DD HH:mm" */
export function nowKey(now: Date): string {
  const shifted = new Date(now.getTime() + JST_OFFSET_MS);
  return `${dateKeyOf(shifted)} ${pad2(shifted.getUTCHours())}:${pad2(shifted.getUTCMinutes())}`;
}

/** "YYYY-MM-DD" に days 日足す */
export function addDays(key: string, days: number): string {
  const [y, m, d] = key.split("-").map(Number);
  return dateKeyOf(new Date(Date.UTC(y, m - 1, d) + days * DAY_MS));
}

/** 2 つの "YYYY-MM-DD" の差（to − from の日数） */
export function daysBetween(from: string, to: string): number {
  return Math.round((dateKeyToSerial(to) - dateKeyToSerial(from)));
}
