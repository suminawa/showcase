/** シート名の引用、列の字、範囲（A1 の書き方） */

/** シート名は常に '…' で囲み、名前の中の ' は '' にする */
export function quoteSheet(name: string): string {
  return `'${name.replace(/'/g, "''")}'`;
}

/** 列番号（1 始まり）→ 列の字。1 → A、26 → Z、27 → AA */
export function columnLetter(index: number): string {
  let n = index;
  let out = "";
  while (n > 0) {
    const rest = (n - 1) % 26;
    out = String.fromCharCode(65 + rest) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

/** シート全体（A 列から ZZ 列まで） */
export function sheetRange(sheet: string): string {
  return `${quoteSheet(sheet)}!A1:ZZ`;
}

/** 1 行（A 列から width 列まで） */
export function rowRange(sheet: string, row: number, width: number): string {
  return `${quoteSheet(sheet)}!A${row}:${columnLetter(Math.max(1, width))}${row}`;
}

/** 1 列（column は 1 始まり） */
export function columnRange(sheet: string, column: number): string {
  const letter = columnLetter(column);
  return `${quoteSheet(sheet)}!${letter}1:${letter}`;
}

/** 1 セル（column・row は 1 始まり） */
export function cellRange(sheet: string, column: number, row: number): string {
  return `${quoteSheet(sheet)}!${columnLetter(column)}${row}`;
}

/** append の応答の updatedRange（'顧客'!A22:P22）から行番号を取る。読めなければ null */
export function rowOfRange(range: string): number | null {
  const matched = range.match(/![A-Z]+(\d+)/);
  return matched ? Number(matched[1]) : null;
}
