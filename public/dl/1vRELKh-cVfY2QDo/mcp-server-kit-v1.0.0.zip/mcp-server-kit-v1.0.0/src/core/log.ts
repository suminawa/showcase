/**
 * 1 行ログ（stderr）。引数と値は書かない（引数は名前だけ）。stdout には 1 字も書かない（stdio はプロトコル専用）。
 * 時刻は呼ぶ側が clock で渡す（core では時計を読まない）
 */

export interface CallEntry {
  tool: string;
  ms: number;
  result: string;
  rows?: number;
  argNames: string[];
}

export interface Logger {
  readonly level: "info" | "debug";
  info(message: string): void;
  debug(message: string): void;
  call(entry: CallEntry): void;
}

export function createLogger(level: "info" | "debug", sink: (line: string) => void, clock: () => Date): Logger {
  const write = (text: string) => sink(`${clock().toISOString()} ${text}`);
  return {
    level,
    info: (message) => write(message),
    debug: (message) => {
      if (level === "debug") write(message);
    },
    call: (entry) => {
      const rows = entry.rows === undefined ? "" : ` rows=${entry.rows}`;
      write(`tool=${entry.tool} ms=${entry.ms} result=${entry.result}${rows} args=${entry.argNames.join(",")}`);
    },
  };
}

/** process.stderr に 1 行ずつ書く */
export function stderrSink(line: string): void {
  process.stderr.write(`${line}\n`);
}
