/** ツールの形（tools/list に出すもの）と、呼ばれたときの処理 */
import type { JsonSchema } from "./args.ts";

export interface ToolAnnotations {
  readOnlyHint: boolean;
  destructiveHint?: boolean;
  idempotentHint?: boolean;
  openWorldHint: boolean;
}

export interface ToolShape {
  name: string;
  title: string;
  description: string;
  inputSchema: JsonSchema;
  annotations: ToolAnnotations;
}

export interface ToolDef extends ToolShape {
  outputSchema: JsonSchema;
  /** 書くツールか（MCP_WRITE と 1 分の上限の対象） */
  write: boolean;
  /** 引数の検査の前に呼ぶ（見せない列を名前で指したときに hidden_column を返すため） */
  beforeCheck?: (args: Record<string, unknown>) => void;
  run: (args: Record<string, unknown>, now: Date) => Promise<Record<string, unknown>>;
}

/** 元（業務アプリ・予約・書類読み取り）ごとのツールの組 */
export interface Source {
  tools(now: Date): Promise<ToolDef[]>;
}

export const READ_ANNOTATIONS: ToolAnnotations = { readOnlyHint: true, openWorldHint: false };

/** 返りの形。最上位の項目の名前だけを決め、中身は問わない */
export function outputObject(keys: string[]): JsonSchema {
  const properties: Record<string, JsonSchema> = {};
  for (const key of keys) properties[key] = {};
  return { type: "object", properties, required: keys };
}
