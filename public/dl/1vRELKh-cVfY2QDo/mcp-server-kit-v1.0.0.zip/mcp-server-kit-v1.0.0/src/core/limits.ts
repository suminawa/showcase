/** 読みの上限（500 行・80,000 字）と、書き込みの 1 分の上限 */

export const MAX_ROWS = 500;
export const MAX_JSON_CHARS = 80000;
export const WRITES_PER_MINUTE = 20;

export interface Page<T> {
  rows: T[];
  total: number;
  offset: number;
  limit: number;
  count: number;
  next_offset: number | null;
  truncated: boolean;
}

/**
 * offset から limit 行を取り、build(rows) の JSON が 80,000 字に収まるまで後ろの行を落とす。
 * 落としたら truncated: true と、続きの next_offset を付ける
 */
export function pageOf<T>(all: T[], offset: number, limit: number, build: (rows: T[]) => unknown, maxChars = MAX_JSON_CHARS): Page<T> {
  const size = Math.min(Math.max(1, limit), MAX_ROWS);
  const slice = all.slice(offset, offset + size);
  const base = JSON.stringify(build([])).length;
  let used = base;
  let keep = 0;
  for (const row of slice) {
    const add = JSON.stringify(row).length + 1;
    if (used + add > maxChars) break;
    used += add;
    keep += 1;
  }
  // 行に応じて増える添え物（search_rows の labels など）も含めて、全体で上限に収める
  while (keep > 0 && JSON.stringify(build(slice.slice(0, keep))).length > maxChars) keep -= 1;
  const rows = slice.slice(0, keep);
  const truncated = keep < slice.length;
  const end = offset + rows.length;
  return { rows, total: all.length, offset, limit: size, count: rows.length, next_offset: end < all.length ? end : null, truncated };
}

/** 書き込みの回数の上限（直近 windowMs に max 回まで）。プロセスの中だけで数える */
export class WriteLimiter {
  readonly max: number;
  readonly windowMs: number;
  private stamps: number[] = [];
  constructor(max = WRITES_PER_MINUTE, windowMs = 60000) {
    this.max = max;
    this.windowMs = windowMs;
  }
  /** 使えれば true（1 回ぶん数える）。上限なら false */
  take(nowMs: number): boolean {
    this.stamps = this.stamps.filter((at) => nowMs - at < this.windowMs);
    if (this.stamps.length >= this.max) return false;
    this.stamps.push(nowMs);
    return true;
  }
}
