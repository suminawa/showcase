/**
 * .env の読み手と、設定の検査。誤りは敬体の文の配列で返す（投げない）。
 * 誤りの文に値そのもの（鍵・合い言葉・URL）は入れない。
 */

/** 買い手が書ける名前（README の表・.env.example と同じ並び） */
export const ENV_NAMES = [
  "GOOGLE_SERVICE_ACCOUNT_FILE",
  "GOOGLE_SERVICE_ACCOUNT_JSON",
  "SHEET_APP_SPREADSHEET",
  "BOOKING_SPREADSHEET",
  "DOC_READER_SPREADSHEET",
  "DOC_READER_SHEET",
  "MCP_WRITE",
  "MCP_TABLES",
  "MCP_TABLE_ALIASES",
  "MCP_HIDE_COLUMNS",
  "MCP_SHOW_UPDATER",
  "MCP_ACTOR",
  "MCP_HTTP_TOKEN",
  "MCP_HTTP_HOST",
  "MCP_HTTP_PORT",
  "MCP_PUBLIC_URL",
  "MCP_DEMO",
  "MCP_LOG",
] as const;

export type EnvName = (typeof ENV_NAMES)[number];
export type Vars = Partial<Record<EnvName | "MCP_ENV_FILE", string>>;
export type Mode = "stdio" | "http" | "cli";
export type SourceKind = "sheetApp" | "booking" | "docReader";

/** 元ごとの .env の名前と、画面に出す名前 */
export const SOURCES: Record<SourceKind, { env: EnvName; label: string }> = {
  sheetApp: { env: "SHEET_APP_SPREADSHEET", label: "業務アプリ" },
  booking: { env: "BOOKING_SPREADSHEET", label: "予約ページ" },
  docReader: { env: "DOC_READER_SPREADSHEET", label: "書類読み取り" },
};

export interface Config {
  demo: boolean;
  write: boolean;
  serviceAccountFile: string;
  serviceAccountJson: string;
  spreadsheets: Record<SourceKind, string | null>;
  docReaderSheet: string;
  tables: string[];
  aliases: Record<string, string>;
  hideColumns: string[];
  showUpdater: boolean;
  actor: string;
  httpToken: string;
  httpHost: string;
  httpPort: number;
  publicUrl: string;
  log: "info" | "debug";
}

export const MIN_TOKEN_LENGTH = 32;

/** KEY=VALUE の行を読む。引用符（" と '）・# の注記・空行・先頭の export を扱う。= を含む値もそのまま */
export function parseEnvText(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const rawLine of text.replace(/^﻿/, "").split(/\r?\n/)) {
    const line = rawLine.trim();
    if (line === "" || line.startsWith("#")) continue;
    const body = line.startsWith("export ") ? line.slice(7).trim() : line;
    const at = body.indexOf("=");
    if (at <= 0) continue;
    const key = body.slice(0, at).trim();
    let value = body.slice(at + 1).trim();
    const quote = value.charAt(0);
    if ((quote === '"' || quote === "'") && value.indexOf(quote, 1) > 0) {
      value = value.slice(1, value.indexOf(quote, 1));
      if (quote === '"') value = value.replace(/\\n/g, "\n");
    } else {
      const comment = value.search(/\s#/);
      if (comment >= 0) value = value.slice(0, comment).trim();
    }
    out[key] = value;
  }
  return out;
}

/** .env の値に、プロセスの環境変数を重ねる（同じ名前ならプロセスの側が勝つ）。知らない名前は捨てる */
export function mergeEnv(fileVars: Record<string, string>, processEnv: Record<string, string | undefined>): Vars {
  const out: Vars = {};
  for (const name of [...ENV_NAMES, "MCP_ENV_FILE"] as const) {
    const fromProcess = processEnv[name];
    if (fromProcess !== undefined && fromProcess !== "") out[name] = fromProcess;
    else if (fileVars[name] !== undefined) out[name] = fileVars[name];
  }
  return out;
}

/** スプレッドシートの URL か ID から ID を取り出す。形が違えば null */
export function spreadsheetIdOf(value: string): string | null {
  const text = value.trim();
  const fromUrl = text.match(/\/spreadsheets\/d\/([A-Za-z0-9_-]+)/);
  const id = fromUrl ? fromUrl[1] : text;
  return /^[A-Za-z0-9_-]{20,}$/.test(id) ? id : null;
}

function splitItems(text: string): string[] {
  return text
    .split(/[,、]/)
    .map((item) => item.trim())
    .filter((item) => item !== "");
}

export function readConfig(vars: Vars, mode: Mode): { config: Config; errors: string[]; warnings: string[] } {
  const errors: string[] = [];
  const warnings: string[] = [];
  const get = (name: EnvName) => (vars[name] ?? "").trim();
  const demo = get("MCP_DEMO") === "1";

  const writeText = get("MCP_WRITE").toLowerCase();
  if (writeText !== "" && writeText !== "true" && writeText !== "false") {
    warnings.push("MCP_WRITE は true か false で書いてください。いまは書き込みを使わない設定で動きます。");
  }

  const spreadsheets: Record<SourceKind, string | null> = { sheetApp: null, booking: null, docReader: null };
  for (const kind of Object.keys(SOURCES) as SourceKind[]) {
    const text = get(SOURCES[kind].env);
    if (text === "") continue;
    const id = spreadsheetIdOf(text);
    if (id === null) {
      errors.push(`${SOURCES[kind].env} の URL か ID の形が違います。スプレッドシートを開いたときのアドレスを、そのまま貼ってください。`);
    } else {
      spreadsheets[kind] = id;
    }
  }

  if (!demo) {
    if (get("GOOGLE_SERVICE_ACCOUNT_FILE") === "" && get("GOOGLE_SERVICE_ACCOUNT_JSON") === "") {
      errors.push("サービス アカウントの鍵が設定されていません。GOOGLE_SERVICE_ACCOUNT_FILE に、Google Cloud でダウンロードした JSON の場所を書いてください（README の 4 章）。");
    }
    const anyGiven = (Object.keys(SOURCES) as SourceKind[]).some((kind) => get(SOURCES[kind].env) !== "");
    if (!anyGiven) {
      errors.push("スプレッドシートの URL か ID が設定されていません。SHEET_APP_SPREADSHEET・BOOKING_SPREADSHEET・DOC_READER_SPREADSHEET のどれかを書いてください（README の 5 章）。");
    }
  }

  const aliases: Record<string, string> = {};
  for (const pair of splitItems(get("MCP_TABLE_ALIASES"))) {
    const parts = pair.split(/[:：]/);
    if (parts.length !== 2 || parts[0].trim() === "" || parts[1].trim() === "") {
      warnings.push("MCP_TABLE_ALIASES は「テーブル名:英字の別名」をカンマで区切って書いてください（例: 顧客:customers, 対応履歴:contacts）。形の違う項目は使わずに動きます。");
      continue;
    }
    aliases[parts[0].trim()] = parts[1].trim();
  }

  const hideColumns: string[] = [];
  for (const item of splitItems(get("MCP_HIDE_COLUMNS"))) {
    const at = item.indexOf(".");
    if (at <= 0 || at === item.length - 1) {
      warnings.push("MCP_HIDE_COLUMNS は「テーブル.列」の形で書いてください（例: 顧客.電話）。形の違う項目は使わずに動きます。");
      continue;
    }
    hideColumns.push(item);
  }

  const httpToken = get("MCP_HTTP_TOKEN");
  const httpHost = get("MCP_HTTP_HOST") || "127.0.0.1";
  const portText = get("MCP_HTTP_PORT") || "8787";
  const httpPort = /^\d+$/.test(portText) ? Number(portText) : NaN;
  const publicUrl = get("MCP_PUBLIC_URL").replace(/\/+$/, "");
  // check（cli）は、HTTP の設定を書いたときだけ HTTP 版と同じ決まりで確かめる（stdio だけ使う方には要らないため）
  if (mode === "http" || (mode === "cli" && (httpToken !== "" || publicUrl !== ""))) {
    if (httpToken.length < MIN_TOKEN_LENGTH) {
      errors.push("MCP_HTTP_TOKEN が空か、32 字より短いです。npm run token で作った文字を貼ってください（README の 8 章の 1）。");
    }
    if (!(httpPort >= 1 && httpPort <= 65535)) {
      errors.push("MCP_HTTP_PORT は 1 から 65535 までの数にしてください。");
    }
    if (publicUrl !== "" && !publicUrl.startsWith("https://")) {
      errors.push("MCP_PUBLIC_URL は https:// から書いてください。");
    }
    if (mode === "http" && httpHost !== "127.0.0.1" && httpHost !== "localhost" && httpHost !== "::1") {
      warnings.push("127.0.0.1 以外で待ち受けています。同じネットワークのほかの機器からも届きます。合い言葉が長く、推測できないものかをご確認ください。");
    }
  }

  const logText = get("MCP_LOG") || "info";
  if (logText !== "info" && logText !== "debug") warnings.push("MCP_LOG は info か debug で書いてください。いまは info で動きます。");

  const config: Config = {
    demo,
    write: writeText === "true",
    serviceAccountFile: get("GOOGLE_SERVICE_ACCOUNT_FILE"),
    serviceAccountJson: get("GOOGLE_SERVICE_ACCOUNT_JSON"),
    spreadsheets,
    docReaderSheet: get("DOC_READER_SHEET") || "読み取り",
    tables: splitItems(get("MCP_TABLES")),
    aliases,
    hideColumns,
    showUpdater: get("MCP_SHOW_UPDATER").toLowerCase() === "true",
    actor: get("MCP_ACTOR"),
    httpToken,
    httpHost,
    httpPort,
    publicUrl,
    log: logText === "debug" ? "debug" : "info",
  };
  return { config, errors, warnings };
}
