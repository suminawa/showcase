/** AI に見せない列（返さない・受け取らない）の判定 */

export type SourceName = "sheet-app" | "booking" | "doc-reader";

/** 設定に関係なく常に落とす、予約の列（キャンセル用の合い言葉と、カレンダーの予定 ID） */
export const BOOKING_ALWAYS_HIDDEN = ["キャンセル用", "カレンダー"];

export interface Hider {
  isHidden(source: SourceName, table: string, column: string, type?: string): boolean;
}

export function createHider(options: { hideColumns: string[]; showUpdater: boolean }): Hider {
  const listed = new Set(options.hideColumns);
  return {
    isHidden(source, table, column, type) {
      if (listed.has(`${table}.${column}`)) return true;
      if (source === "sheet-app") return type === "LINE" || (column === "更新者" && !options.showUpdater);
      if (source === "booking") return BOOKING_ALWAYS_HIDDEN.includes(column);
      return false;
    },
  };
}
