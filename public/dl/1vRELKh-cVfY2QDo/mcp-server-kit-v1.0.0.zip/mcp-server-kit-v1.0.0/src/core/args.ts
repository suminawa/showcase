/**
 * ツールの引数を、JSON Schema の部分集合で確かめる。誤りは日本語の断片の配列で返す（「引数に誤りがあります: 」の後ろに並べる）。
 * 使う語: type enum required minimum maximum minLength maxLength pattern items maxItems uniqueItems
 *         properties additionalProperties minProperties anyOf（null を許すときだけ）
 */

export type JsonType = "string" | "number" | "integer" | "boolean" | "object" | "array" | "null";

export interface JsonSchema {
  type?: JsonType | JsonType[];
  title?: string;
  description?: string;
  enum?: unknown[];
  default?: unknown;
  required?: string[];
  properties?: Record<string, JsonSchema>;
  additionalProperties?: boolean;
  minProperties?: number;
  items?: JsonSchema;
  maxItems?: number;
  uniqueItems?: boolean;
  minimum?: number;
  maximum?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  anyOf?: JsonSchema[];
}

const TYPE_NAMES: Record<JsonType, string> = {
  string: "文字",
  number: "数",
  integer: "整数",
  boolean: "true か false",
  object: "オブジェクト（{ }）",
  array: "配列（[ ]）",
  null: "null",
};

function typeOf(value: unknown): JsonType {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (typeof value === "number") return Number.isInteger(value) ? "integer" : "number";
  if (typeof value === "string") return "string";
  if (typeof value === "boolean") return "boolean";
  return "object";
}

function typeMatches(value: unknown, type: JsonType): boolean {
  const actual = typeOf(value);
  if (type === "number") return actual === "number" || actual === "integer";
  return actual === type;
}

function rangeText(schema: JsonSchema, noun: string): string {
  if (schema.minimum !== undefined && schema.maximum !== undefined) return `${schema.minimum} から ${schema.maximum} までの${noun}`;
  if (schema.minimum !== undefined) return `${schema.minimum} 以上の${noun}`;
  if (schema.maximum !== undefined) return `${schema.maximum} 以下の${noun}`;
  return noun;
}

/** 英数で始まる・終わる語の前後に空白を入れる（「limit は 1 から 500 までの整数にしてください」） */
function spaced(text: string): string {
  const head = /^[A-Za-z0-9]/.test(text) ? " " : "";
  const tail = /[A-Za-z0-9]$/.test(text) ? " " : "";
  return head + text + tail;
}

function childPath(path: string, key: string): string {
  return path === "" ? key : `${path}.${key}`;
}

/** 誤りの断片（「limit は 1 から 500 までの整数にしてください」など）を返す。誤りが無ければ空 */
export function checkArgs(schema: JsonSchema, value: unknown, path = ""): string[] {
  const name = path === "" ? "引数" : path;

  if (schema.anyOf !== undefined) {
    for (const branch of schema.anyOf) {
      if (checkArgs(branch, value, path).length === 0) return [];
    }
    const main = schema.anyOf.find((branch) => branch.type !== "null") ?? schema.anyOf[0];
    return checkArgs(main, value, path);
  }

  if (schema.type !== undefined) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((type) => typeMatches(value, type))) {
      const noun = types.map((type) => TYPE_NAMES[type]).join(" か ");
      const numeric = types.includes("integer") || types.includes("number");
      return [`${name} は${spaced(numeric ? rangeText(schema, noun) : noun)}にしてください`];
    }
  }

  if (schema.enum !== undefined && !schema.enum.some((item) => item === value)) {
    return [`${name} は次のどれかにしてください: ${schema.enum.map(String).join("、")}`];
  }

  if (typeof value === "number") {
    if ((schema.minimum !== undefined && value < schema.minimum) || (schema.maximum !== undefined && value > schema.maximum)) {
      return [`${name} は${spaced(rangeText(schema, schema.type === "integer" ? "整数" : "数"))}にしてください`];
    }
  }

  if (typeof value === "string") {
    if (schema.maxLength !== undefined && value.length > schema.maxLength) return [`${name} は ${schema.maxLength} 字以内にしてください`];
    if (schema.minLength !== undefined && value.length < schema.minLength) return [`${name} は ${schema.minLength} 字以上にしてください`];
    if (schema.pattern !== undefined && !new RegExp(schema.pattern, "u").test(value)) {
      return [`${name} の形が違います（形: ${schema.pattern}）`];
    }
  }

  if (Array.isArray(value)) {
    if (schema.maxItems !== undefined && value.length > schema.maxItems) return [`${name} は ${schema.maxItems} 個までにしてください`];
    if (schema.uniqueItems === true && new Set(value.map((item) => JSON.stringify(item))).size !== value.length) {
      return [`${name} に同じ値が 2 回あります`];
    }
    if (schema.items !== undefined) {
      const errors: string[] = [];
      value.forEach((item, index) => errors.push(...checkArgs(schema.items as JsonSchema, item, `${name}[${index}]`)));
      return errors;
    }
  }

  if (typeOf(value) === "object" && (schema.properties !== undefined || schema.required !== undefined)) {
    const record = value as Record<string, unknown>;
    const properties = schema.properties ?? {};
    const known = Object.keys(properties);
    const noun = path === "values" ? "列" : "項目";
    const errors: string[] = [];
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(record)) {
        if (!known.includes(key)) errors.push(`${name} に、知らない${noun}「${key}」があります（使える${noun}: ${known.join("、")}）`);
      }
    }
    for (const key of schema.required ?? []) {
      if (record[key] === undefined) errors.push(`${childPath(path, key)} がありません`);
    }
    if (schema.minProperties !== undefined && Object.keys(record).length < schema.minProperties) {
      errors.push(`${name} に、${noun}を ${schema.minProperties} つ以上入れてください`);
    }
    for (const key of known) {
      if (record[key] !== undefined) errors.push(...checkArgs(properties[key], record[key], childPath(path, key)));
    }
    return errors;
  }

  return [];
}
