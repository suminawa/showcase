#!/usr/bin/env node
/**
 * npx mcp-server-kit check … 鍵・共有・見出しを確かめ、足りない設定を具体的な文で指す（npm run check）
 * npx mcp-server-kit token … HTTP の合い言葉を作る（npm run token）
 * ここは MCP のサーバーではないので、結果は stdout に書く。
 */
import { randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { sheetRange } from "./core/a1.ts";
import { SOURCES, readConfig, type SourceKind } from "./core/env.ts";
import { ToolError } from "./core/errors.ts";
import { createHider } from "./core/hide.ts";
import { todayKey } from "./core/values.ts";
import { FakeSheets } from "./google/fake.ts";
import { TokenSource, scopeFor, type FetchLike } from "./google/jwt.ts";
import { MetaCache, createHttpSheets, type SheetsClient } from "./google/sheets.ts";
import { BOOKING_COLUMNS, BOOKING_SHEET } from "./sources/booking.ts";
import { SheetAppData } from "./sources/sheet-app/read.ts";
import { headerFor, textOf } from "./vendor/sheet-app/index.js";
import { kitDirOf, loadAccount, loadVars } from "./server/boot.ts";
import { DEMO_IDS, demoBooks } from "./server/demo.ts";

export interface CheckDeps {
  processEnv: Record<string, string | undefined>;
  kitDir: string;
  fetch: FetchLike;
  clock: () => Date;
  /** 検査用: 本物の Google の代わりに使うシート */
  sheets?: SheetsClient;
}

const OK = "[OK]";
const NG = "[要対応]";
const NOTE = "[注意]";

export async function runCheck(deps: CheckDeps): Promise<{ lines: string[]; ok: boolean }> {
  const lines: string[] = [];
  let ok = true;
  const fail = (text: string) => {
    ok = false;
    lines.push(`${NG} ${text}`);
  };

  const loaded = loadVars(deps);
  const { config, errors, warnings } = readConfig(loaded.vars, "cli");
  if (loaded.error !== null) fail(loaded.error);
  for (const text of errors) fail(text);
  for (const text of warnings) lines.push(`${NOTE} ${text}`);
  if (!ok) {
    // .env を写し忘れたまま check した方には、何より先にそれを伝える（「.env で直して」だけでは、どの .env か分からないため）。
    // 環境変数で鍵や見本を渡している方（ホスティングなど）には言わない
    const explicit = deps.processEnv.MCP_ENV_FILE;
    const byEnv = ["GOOGLE_SERVICE_ACCOUNT_FILE", "GOOGLE_SERVICE_ACCOUNT_JSON", "SHEET_APP_SPREADSHEET", "BOOKING_SPREADSHEET", "DOC_READER_SPREADSHEET", "MCP_DEMO"].some(
      (name) => (deps.processEnv[name] ?? "") !== "",
    );
    if ((explicit === undefined || explicit === "") && !byEnv && !existsSync(join(deps.kitDir, ".env"))) {
      lines.unshift(`${NG} キットのフォルダに .env がありません。.env.example を .env という名前で写し（cp .env.example .env）、鍵の場所とスプレッドシートの URL を書いてください（README の 5 章）。`);
    }
    return { lines: [...lines, "上の項目を .env で直してから、もう一度 npm run check を実行してください。"], ok };
  }

  let sheets: SheetsClient;
  const ids: Partial<Record<SourceKind, string>> = {};
  if (config.demo) {
    lines.push(`${OK} 見本データ（MCP_DEMO=1）で確かめます。Google には接続しません。`);
    sheets = new FakeSheets(demoBooks(join(deps.kitDir, "samples"), todayKey(deps.clock()), config.docReaderSheet));
    Object.assign(ids, DEMO_IDS);
  } else {
    const account = loadAccount(config, deps.kitDir, (text) => lines.push(text.startsWith("鍵のファイルがほかの") ? `${NOTE} ${text}` : `${NG} ${text}`));
    if (account === null) return { lines: [...lines, "鍵の場所を .env で直してから、もう一度 npm run check を実行してください。"], ok: false };
    lines.push(`${OK} 鍵を読めました（サービス アカウント: ${account.client_email}）`);
    const envNames: Record<string, string> = {};
    for (const kind of Object.keys(SOURCES) as SourceKind[]) {
      const id = config.spreadsheets[kind];
      if (id === null) continue;
      ids[kind] = id;
      envNames[id] = SOURCES[kind].env;
    }
    const tokens = new TokenSource(account, scopeFor(config.write), deps.fetch, () => deps.clock().getTime());
    sheets =
      deps.sheets ??
      createHttpSheets({ token: () => tokens.token(), fetch: deps.fetch, sleep: (ms) => new Promise((r) => setTimeout(r, ms)), clientEmail: account.client_email, envNames });
  }

  const meta = new MetaCache(sheets);
  const now = deps.clock().getTime();
  const hider = createHider(config);
  for (const kind of Object.keys(ids) as SourceKind[]) {
    const id = ids[kind] as string;
    const label = SOURCES[kind].label;
    try {
      const info = await meta.get(id, now);
      lines.push(`${OK} ${label}: スプレッドシートを開けました（シート ${info.sheets.length} 枚）`);
      if (info.timeZone !== "Asia/Tokyo") lines.push(`${NOTE} ${label}: スプレッドシートのタイムゾーンが Asia/Tokyo ではありません（ファイル → 設定）。日付が 1 日ずれることがあります。`);
      const titles = info.sheets.map((s) => s.title);

      if (kind === "sheetApp") {
        const data = new SheetAppData({ sheets, meta, spreadsheetId: id, config, hider });
        const definition = await data.definition(now);
        for (const text of definition.errors) lines.push(`${NOTE} 定義: ${text}`);
        if (definition.specs.length === 0) fail("業務アプリ: 「定義」シートにテーブルがありません。業務アプリの README「定義シートの書き方」をご覧ください。");
        for (const spec of definition.specs) {
          const name = spec.table.name;
          if (!titles.includes(name)) {
            fail(`業務アプリ: スプレッドシートに「${name}」シートがありません。業務アプリのメニュー「初期化」を実行してください。`);
            continue;
          }
          const values = await sheets.get(id, sheetRange(name));
          const header = (values[0] ?? []).map(textOf);
          const missing = headerFor(spec.table).filter((h) => !header.includes(h));
          if (missing.length > 0) fail(`業務アプリ: 「${name}」シートに「${missing.join("」「")}」の見出しがありません。業務アプリのメニュー「初期化」を実行してください。`);
          else lines.push(`${OK} 業務アプリ: 「${name}」の見出しがそろっています（${values.length - 1} 行。ツール名 add_row_${spec.suffix}・update_row_${spec.suffix}）`);
        }
      }
      if (kind === "booking") {
        if (!titles.includes(BOOKING_SHEET)) fail("予約ページ: スプレッドシートに「予約」シートがありません。予約ページのメニュー「初期化」を実行してください。");
        else {
          const values = await sheets.get(id, sheetRange(BOOKING_SHEET));
          const header = (values[0] ?? []).map(textOf);
          const missing = BOOKING_COLUMNS.filter((h) => !header.includes(h));
          if (missing.length > 0) fail(`予約ページ: 「予約」シートに「${missing.join("」「")}」の見出しがありません。予約ページのメニュー「初期化」を実行してください。`);
          else lines.push(`${OK} 予約ページ: 「予約」の見出しがそろっています（${values.length - 1} 件）`);
        }
      }
      if (kind === "docReader") {
        if (!titles.includes(config.docReaderSheet)) {
          fail(`書類読み取り: スプレッドシートに「${config.docReaderSheet}」シートがありません。書類読み取りから 1 度送ると作られます。DOC_READER_SHEET のシート名もご確認ください。`);
        } else {
          const values = await sheets.get(id, sheetRange(config.docReaderSheet));
          lines.push(`${OK} 書類読み取り: 「${config.docReaderSheet}」を読めました（${values.length > 0 ? values.length - 1 : 0} 行、列 ${(values[0] ?? []).length}）`);
        }
      }
    } catch (error) {
      if (!(error instanceof ToolError)) throw error;
      fail(`${label}（${SOURCES[kind].env}）: ${error.message}`);
    }
  }

  lines.push(config.write ? `${NOTE} 書き込み: あり。共有が「編集者」になっているかは、最初の書き込みのときに分かります。` : `${OK} 書き込み: なし（読むだけ）`);
  lines.push(ok ? "すべて確かめました。Claude Desktop などの設定に進んでください。" : `${NG} の項目を直してから、もう一度 npm run check を実行してください。`);
  return { lines, ok };
}

/** HTTP の合い言葉（43 字の英数と - _） */
export function newToken(): string {
  return randomBytes(32).toString("base64url");
}

async function main(): Promise<void> {
  const command = process.argv[2];
  if (command === "token") {
    process.stdout.write(`${newToken()}\n`);
    process.stderr.write("この文字を .env の MCP_HTTP_TOKEN に貼ってください。ほかの人には見せないでください。\n");
    return;
  }
  if (command === "check") {
    const result = await runCheck({ processEnv: process.env, kitDir: kitDirOf(import.meta.url), fetch: (url, init) => fetch(url, init), clock: () => new Date() });
    process.stdout.write(`${result.lines.join("\n")}\n`);
    process.exitCode = result.ok ? 0 : 1;
    return;
  }
  process.stderr.write("使い方: npx mcp-server-kit check（設定を確かめる） / npx mcp-server-kit token（HTTP の合い言葉を作る）\n");
  process.exitCode = 1;
}

const entry = process.argv[1] ?? "";
if (/[\\/](cli\.(js|ts)|mcp-server-kit)$/.test(entry)) {
  main().catch((error: unknown) => {
    process.stderr.write(`確かめられませんでした: ${error instanceof Error ? error.message : String(error)}\n`);
    process.exitCode = 1;
  });
}
