/**
 * 業務アプリ: 書く 2 種（add_row_<suffix>・update_row_<suffix>）。MCP_WRITE=true のときだけ出す。
 * 1 回 1 行・セル単位で書き、手で足した列や数式を潰さない。行は消さない。
 */
import { cellRange, columnRange, quoteSheet, rowRange } from "../../core/a1.ts";
import { E } from "../../core/errors.ts";
import { outputObject, type ToolDef } from "../../core/tool.ts";
import { readSystemCell, todayKey, writeCell } from "../../core/values.ts";
import type { Cell } from "../../google/sheets.ts";
import { formatStamp, headerFor, laterId, nextId, parseId, safeCell, textOf, validate, type Column } from "../../vendor/sheet-app/index.js";
import { TRASH_SHEET, headerIndex, type Definition, type SheetAppData } from "./read.ts";
import { addRowTool, updateRowTool, type TableSpec } from "./schema.ts";

/** 同じ ID が重なったときに振り直す回数 */
export const ID_RETRIES = 3;

function latestOf(ids: string[]): string {
  return ids.reduce((latest, id) => laterId(latest, id), "");
}

function checkHeader(name: string, header: string[], required: string[]): void {
  for (const want of required) if (!header.includes(want)) throw E.missingHeader(name, want);
}

/** values に見せない列・更新者があれば hidden_column（引数の検査より先に） */
function rejectHidden(spec: TableSpec, values: unknown): void {
  if (values === null || typeof values !== "object") return;
  for (const key of Object.keys(values)) {
    const hiddenColumn = spec.table.columns.some((c) => c.name === key) && !spec.visible.some((c) => c.name === key);
    if (hiddenColumn || key === "更新者") throw E.hiddenColumn(key);
  }
}

export function writeTools(data: SheetAppData, definition: Definition): ToolDef[] {
  const ctx = data.ctx;
  const sid = ctx.spreadsheetId;
  const actor = ctx.config.actor !== "" ? ctx.config.actor : ctx.sheets.clientEmail;
  const tools: ToolDef[] = [];

  for (const spec of definition.specs.filter((s) => s.writable)) {
    const name = spec.table.name;
    const columnOf = (header: string): Column | undefined => spec.table.columns.find((c) => c.name === header);

    tools.push({
      ...addRowTool(spec),
      outputSchema: outputObject(["table", "id", "row", "created_at"]),
      write: true,
      beforeCheck: (args) => rejectHidden(spec, args.values),
      run: async (args, now) => {
        const today = todayKey(now);
        const stamp = formatStamp(now);
        const checked = validate(spec.table, args.values as Record<string, unknown>, { isNew: true, today });
        if (!checked.ok) throw E.validation(checked.errors);

        const hasTrash = await data.hasSheet(TRASH_SHEET, now.getTime());
        const values = await data.read(hasTrash ? [name, TRASH_SHEET] : [name], now.getTime());
        const header = (values[0][0] ?? []).map(textOf);
        checkHeader(name, header, headerFor(spec.table));
        const index = headerIndex(header);
        const idAt = index.get("ID") as number;

        // 削除済みの ID（_ごみ箱）も含めて、今日のいちばん後ろの ID の次を振る（GAS の lastId は読めないため）
        const trash = hasTrash ? values[1] : [];
        const trashHeader = (trash[0] ?? []).map(textOf);
        if (trash.length > 0) checkHeader(TRASH_SHEET, trashHeader, ["元テーブル", "ID"]);
        const trashIds = trash
          .slice(1)
          .filter((row) => textOf(row[trashHeader.indexOf("元テーブル")]) === name)
          .map((row) => readSystemCell(row[trashHeader.indexOf("ID")]));
        const todays = (ids: string[]) => ids.filter((id) => parseId(id)?.dateKey === today);
        const tableIds = values[0].slice(1).map((row) => readSystemCell(row[idAt]));
        let id = nextId(latestOf(todays([...tableIds, ...trashIds])), today);

        const row: Cell[] = header.map((column) => {
          if (column === "ID") return safeCell(id);
          if (column === "作成日時" || column === "更新日時") return safeCell(stamp);
          if (column === "更新者") return safeCell(actor);
          const def = columnOf(column);
          return def === undefined ? "" : writeCell(def, checked.values[column]);
        });
        const rowNumber = await ctx.sheets.append(sid, `${quoteSheet(name)}!A1`, row);
        const byAt = index.get("更新者") as number;

        // ここから先は行がもう足されている。失敗しても行は消さず（削除は作らない）、場所と ID を添えて返す
        let written = [id];
        const afterAppend = async <T>(step: () => Promise<T>): Promise<T> => {
          try {
            return await step();
          } catch {
            throw E.addedUnconfirmed(name, rowNumber, written);
          }
        };

        // 同じ瞬間に画面やほかの MCP から登録されて ID が重なったら、自分の行の ID を振り直す
        for (let attempt = 0; ; attempt += 1) {
          const [idCells, byCells] = await afterAppend(() => ctx.sheets.batchGet(sid, [columnRange(name, idAt + 1), columnRange(name, byAt + 1)]));
          const ids = idCells.map((cells) => readSystemCell(cells[0]));
          const by = byCells.map((cells) => textOf(cells[0]));
          // 並べ替え・行の挿入や削除で自分の行が動いていたら、よその行に書かないよう止める
          if (ids[rowNumber - 1] !== id) throw E.addedRowMoved(name, rowNumber, id);
          // 重なった相手が自分より後ろの行で、同じサーバーの書き込みなら、振り直すのは相手（両方が振り直し続けないため）
          const clash = ids.some((other, i) => other === id && i + 1 !== rowNumber && (i + 1 < rowNumber || by[i] !== actor));
          if (!clash) break;
          if (attempt >= ID_RETRIES) throw E.idConflict(name, rowNumber, id);
          const next = nextId(latestOf(todays([...ids, ...trashIds])), today);
          written = [id, next];
          await afterAppend(() => ctx.sheets.update(sid, [{ range: cellRange(name, idAt + 1, rowNumber), value: safeCell(next) }]));
          id = next;
          written = [id];
        }

        const saved: Record<string, unknown> = { ID: id };
        for (const column of spec.visible) saved[column.name] = checked.values[column.name];
        saved.作成日時 = stamp;
        saved.更新日時 = stamp;
        return { table: name, id, row: saved, created_at: stamp };
      },
    });

    tools.push({
      ...updateRowTool(spec),
      outputSchema: outputObject(["table", "id", "changed", "updated_at"]),
      write: true,
      beforeCheck: (args) => rejectHidden(spec, args.values),
      run: async (args, now) => {
        const id = String(args.id);
        const stamp = formatStamp(now);
        const checked = validate(spec.table, args.values as Record<string, unknown>, { isNew: false });
        if (!checked.ok) throw E.validation(checked.errors);

        const [values] = await data.read([name], now.getTime());
        const loaded = data.load(spec, values);
        const found = loaded.rows.find((r) => r.record.ID === id);
        if (found === undefined) throw E.rowNotFound(id, name);
        // 照らし合わせは、見せない設定でもシートの更新日時そのもので行う（見せない設定は返す値と文にだけ効く）
        const updatedAtAt = headerIndex(loaded.header).get("更新日時");
        const current = updatedAtAt === undefined ? "" : readSystemCell(found.raw[updatedAtAt]);
        const shown = (value: string) => ("更新日時" in found.record ? value : "");
        if (args.expected_updated_at !== undefined && args.expected_updated_at !== current) throw E.conflict(shown(current));

        const changed = Object.keys(checked.values).filter((column) => JSON.stringify(found.record[column]) !== JSON.stringify(checked.values[column]));
        if (changed.length === 0) return { table: name, id, changed: [], updated_at: shown(current) };
        checkHeader(name, loaded.header, [...changed, "更新日時", "更新者"]);
        const index = headerIndex(loaded.header);

        // 書く直前に、その行だけを読み直す（その間に消された・並べ替えられたら止める）
        const [again] = await ctx.sheets.get(sid, rowRange(name, found.rowNumber, loaded.header.length));
        if (readSystemCell((again ?? [])[index.get("ID") as number]) !== id) throw E.rowMoved();
        // 最初に読んでから書く直前までに、ほかの方が更新していたら止める（changed の before が古くなるため）
        const updatedAt = index.get("更新日時") as number;
        const latest = readSystemCell((again ?? [])[updatedAt]);
        if (latest !== readSystemCell(found.raw[updatedAt])) throw E.conflict(shown(latest));

        const cells = changed.map((column) => ({
          range: cellRange(name, (index.get(column) as number) + 1, found.rowNumber),
          value: writeCell(columnOf(column) as Column, checked.values[column]),
        }));
        cells.push({ range: cellRange(name, (index.get("更新日時") as number) + 1, found.rowNumber), value: safeCell(stamp) });
        cells.push({ range: cellRange(name, (index.get("更新者") as number) + 1, found.rowNumber), value: safeCell(actor) });
        await ctx.sheets.update(sid, cells);
        return {
          table: name,
          id,
          changed: changed.map((column) => ({ column, before: found.record[column], after: checked.values[column] })),
          updated_at: stamp,
        };
      },
    });
  }
  return tools;
}
