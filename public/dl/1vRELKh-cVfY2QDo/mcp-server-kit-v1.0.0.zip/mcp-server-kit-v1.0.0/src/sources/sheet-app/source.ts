/** 業務アプリの元: 定義を読んで、読む 4 本と、テーブルごとの書くツールを組む */
import { ToolError } from "../../core/errors.ts";
import type { Source, ToolDef } from "../../core/tool.ts";
import { SheetAppData, readTools, type SheetAppContext } from "./read.ts";
import { writeTools } from "./write.ts";

export function sheetAppSource(ctx: SheetAppContext): Source {
  const data = new SheetAppData(ctx);
  return {
    async tools(now) {
      try {
        const definition = await data.definition(now.getTime());
        return [...readTools(data, definition), ...writeTools(data, definition)];
      } catch (error) {
        if (!(error instanceof ToolError)) throw error;
        // 定義を読めないときも list_tables だけは出し、呼ばれたら読めない理由（敬体の文）を返す
        const [listTables] = readTools(data, { specs: [], errors: [] });
        const failing: ToolDef = { ...listTables, run: async () => Promise.reject(error) };
        return [failing];
      }
    },
  };
}
