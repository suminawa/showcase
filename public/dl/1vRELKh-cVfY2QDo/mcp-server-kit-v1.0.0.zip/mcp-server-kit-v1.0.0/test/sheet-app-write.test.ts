import { test } from "node:test";
import assert from "node:assert/strict";
import { E, type ToolError } from "../src/core/errors.ts";
import { dateKeyToSerial } from "../src/core/values.ts";
import type { Vars } from "../src/core/env.ts";
import type { ToolDef } from "../src/core/tool.ts";
import type { FakeSheets } from "../src/google/fake.ts";
import { SheetAppData } from "../src/sources/sheet-app/read.ts";
import { writeTools } from "../src/sources/sheet-app/write.ts";
import { NOW, SHEET_APP_ID, callTool, codeOf, sheetAppFake } from "./fixtures.ts";
import { sheetAppContext } from "./sheet-app-helpers.ts";

async function sheetAppWriteTools(fake: FakeSheets, vars: Vars = {}): Promise<ToolDef[]> {
  const data = new SheetAppData(sheetAppContext(fake, { MCP_TABLE_ALIASES: "顧客:customers, 対応履歴:contacts", MCP_ACTOR: "AI（MCP）", ...vars }));
  return writeTools(data, await data.definition(NOW.getTime()));
}

/** 足したあとに読み直す ID の列（対応履歴） */
const ID_COLUMN = "'対応履歴'!A1:A";

const CONTACT = { 顧客: "20260901-001", 種別: "電話", 内容: "来月見積もりを出す" };

function lastRow(fake: ReturnType<typeof sheetAppFake>, sheet: string): unknown[] {
  const rows = fake.sheet(SHEET_APP_ID, sheet);
  return rows[rows.length - 1];
}

test("MCP_WRITE=false なら書くツールを作らない", async () => {
  assert.deepEqual(await sheetAppWriteTools(sheetAppFake(), { MCP_WRITE: "false" }), []);
  const names = (await sheetAppWriteTools(sheetAppFake())).map((tool) => tool.name);
  assert.deepEqual(names, ["add_row_customers", "update_row_customers", "add_row_contacts", "update_row_contacts"]);
});

test("add_row: 今日の続きの ID を振り、既定値（今日・選択肢）を入れ、GAS と同じ形で 1 行足す", async () => {
  const fake = sheetAppFake();
  const out = await callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: { ...CONTACT, 担当: "=HYPERLINK()" } });
  assert.equal(out.id, "20260925-001");
  assert.equal(out.created_at, "2026-09-25 14:03:12");
  assert.deepEqual(out.row, {
    ID: "20260925-001", 顧客: "20260901-001", 日付: "2026-09-25", 種別: "電話", 担当: "=HYPERLINK()", 内容: "来月見積もりを出す", 次回対応日: "",
    作成日時: "2026-09-25 14:03:12", 更新日時: "2026-09-25 14:03:12",
  });
  assert.deepEqual(lastRow(fake, "対応履歴"), [
    "20260925-001", "20260901-001", dateKeyToSerial("2026-09-25"), "電話", "=HYPERLINK()", "来月見積もりを出す", "", "2026-09-25 14:03:12", "2026-09-25 14:03:12", "AI（MCP）",
  ]);
});

test("add_row: 今日の ID がシートにあればその次、_ごみ箱 の削除済みの ID も避ける", async () => {
  const fake = sheetAppFake();
  const out = await callTool(await sheetAppWriteTools(fake), "add_row_customers", { values: { 会社名: "そよかぜ美容室" } });
  assert.equal(out.id, "20260925-003");
  const row = lastRow(fake, "顧客");
  assert.equal(row[7], "");
  assert.equal(row[4], "見込み");
});

test("add_row: 同じ ID が同時に入ったら振り直す", async () => {
  const fake = sheetAppFake();
  fake.onCall = (method) => {
    if (method === "append") fake.sheet(SHEET_APP_ID, "対応履歴").push(["20260925-001", "20260901-002", "", "訪問", "", "画面から", "", "", "", ""]);
  };
  const out = await callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: CONTACT });
  assert.equal(out.id, "20260925-002");
  assert.equal(lastRow(fake, "対応履歴")[0], "20260925-002");
});

test("add_row: 3 回振り直しても重なるなら id_conflict", async () => {
  const fake = sheetAppFake();
  let ours = -1;
  fake.onCall = (method, ranges) => {
    if (method !== "batchGet" || ranges[0] !== ID_COLUMN) return;
    const rows = fake.sheet(SHEET_APP_ID, "対応履歴");
    if (ours < 0) ours = rows.length - 1;
    rows.push([rows[ours][0], "20260901-002", "", "訪問", "", "画面から", "", "", "", ""]);
  };
  await assert.rejects(callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: CONTACT }), (error: ToolError) => {
    assert.equal(error.code, "id_conflict");
    assert.match(error.message, /「対応履歴」シートの 4 行目に、ID「20260925-004」/);
    assert.match(error.message, /search_rows/);
    return true;
  });
  // 自分の行は消さずに残る（削除は作らない）。最後に振った ID のまま、中身は渡した値
  const rows = fake.sheet(SHEET_APP_ID, "対応履歴");
  assert.equal(ours, 3);
  assert.deepEqual(rows[3].slice(0, 6), ["20260925-004", "20260901-001", dateKeyToSerial("2026-09-25"), "電話", "", "来月見積もりを出す"]);
  assert.equal(rows[3][9], "AI（MCP）");
  assert.equal(rows.length, 3 + 1 + 4);
});

test("add_row: 足したあとに行の位置が変わったら、ほかの行の ID を書き換えずに added_row_moved", async () => {
  const fake = sheetAppFake();
  fake.onCall = (method, ranges) => {
    if (method === "batchGet" && ranges[0] === ID_COLUMN) fake.sheet(SHEET_APP_ID, "対応履歴").splice(1, 0, ["20260925-001", "20260901-002", "", "訪問", "", "画面から", "", "", "", ""]);
  };
  await assert.rejects(callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: CONTACT }), (error: ToolError) => {
    assert.equal(error.code, "added_row_moved");
    assert.match(error.message, /ID「20260925-001」/);
    assert.match(error.message, /search_rows/);
    return true;
  });
  assert.equal(fake.calls.some((call) => call.method === "update"), false);
  assert.deepEqual(fake.sheet(SHEET_APP_ID, "対応履歴").map((row) => row[0]), ["ID", "20260925-001", "20260901-001", "20260901-002", "20260925-001"]);
});

test("add_row: 足したあとの読み直しが失敗したら、足した行の場所と ID を添えて added_unconfirmed", async () => {
  const fake = sheetAppFake();
  fake.onCall = (method) => {
    if (method === "append") fake.failNext("batchGet", E.unavailable("503"));
  };
  await assert.rejects(callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: CONTACT }), (error: ToolError) => {
    assert.equal(error.code, "added_unconfirmed");
    assert.match(error.message, /「対応履歴」シートの 4 行目に、ID「20260925-001」/);
    assert.match(error.message, /search_rows/);
    return true;
  });
  assert.equal(lastRow(fake, "対応履歴")[0], "20260925-001");
});

test("add_row: 振り直しの書き込みが失敗したら、書いたかもしれない 2 つの ID を添えて added_unconfirmed", async () => {
  const fake = sheetAppFake();
  fake.onCall = (method) => {
    if (method !== "append") return;
    fake.sheet(SHEET_APP_ID, "対応履歴").push(["20260925-001", "20260901-002", "", "訪問", "", "画面から", "", "", "", ""]);
    fake.failNext("update", E.writeUnknown("503"));
  };
  await assert.rejects(callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: CONTACT }), (error: ToolError) => {
    assert.equal(error.code, "added_unconfirmed");
    assert.match(error.message, /5 行目に、ID「20260925-001」（または「20260925-002」）/);
    return true;
  });
});

test("add_row: このサーバーどうしが同じ ID を書いたら、後ろの行だけが振り直す（前の行はそのまま）", async () => {
  const fake = sheetAppFake();
  const [first, second] = await Promise.all([sheetAppWriteTools(fake), sheetAppWriteTools(fake)]);
  const [a, b] = await Promise.all([
    callTool(first, "add_row_contacts", { values: CONTACT }),
    callTool(second, "add_row_contacts", { values: { ...CONTACT, 内容: "もう一方" } }),
  ]);
  // 両方とも足す前に同じ ID を決めていた（重なりの場面を通った）こと
  const methods = fake.calls.map((call) => call.method);
  assert.ok(methods.lastIndexOf("append") < fake.calls.findIndex((call) => call.ranges[0] === ID_COLUMN));
  assert.equal(a.id, "20260925-001");
  assert.equal(b.id, "20260925-002");
  const rows = fake.sheet(SHEET_APP_ID, "対応履歴");
  assert.deepEqual(rows.slice(3).map((row) => [row[0], row[5]]), [["20260925-001", "来月見積もりを出す"], ["20260925-002", "もう一方"]]);
  assert.equal(fake.calls.filter((call) => call.method === "update").length, 1);
});

test("add_row: _ごみ箱 に「元テーブル」か「ID」の見出しが無ければ missing_header（足さない）", async () => {
  for (const at of [0, 1]) {
    const fake = sheetAppFake();
    fake.sheet(SHEET_APP_ID, "_ごみ箱")[0][at] = "別の見出し";
    await assert.rejects(callTool(await sheetAppWriteTools(fake), "add_row_customers", { values: { 会社名: "そよかぜ美容室" } }), {
      code: "missing_header",
      message: at === 0 ? /「_ごみ箱」シートに「元テーブル」/ : /「_ごみ箱」シートに「ID」/,
    });
    assert.equal(fake.calls.some((call) => call.method === "append"), false);
  }
});

test("add_row: 検証の誤りは列ごとの文を並べ、シートに触れない", async () => {
  const fake = sheetAppFake();
  const tools = await sheetAppWriteTools(fake);
  const before = fake.calls.length;
  await assert.rejects(callTool(tools, "add_row_contacts", { values: { 顧客: "20260901-001", 種別: "来店", 内容: "", 日付: "2026-02-30" } }), {
    code: "validation",
    message: "入力に誤りがあります。日付: 日付は 2026-09-16 の形で入力してください／種別: 候補から選んでください／内容: 内容 を入力してください。",
  });
  assert.equal(fake.calls.length, before);
});

test("add_row: 見出しが足りなければ missing_header（シートの形は変えない）", async () => {
  const fake = sheetAppFake();
  fake.sheet(SHEET_APP_ID, "対応履歴")[0][6] = "次の対応";
  assert.equal(await codeOf(callTool(await sheetAppWriteTools(fake), "add_row_contacts", { values: CONTACT })), "missing_header");
  assert.equal(fake.calls.some((call) => call.method === "append"), false);
});

test("見せない列（LINE・更新者）を書こうとすると hidden_column", async () => {
  const tools = await sheetAppWriteTools(sheetAppFake());
  assert.equal(await codeOf(callTool(tools, "add_row_customers", { values: { 会社名: "x", LINE: "U0123456789abcdef0123456789abcdef" } })), "hidden_column");
  assert.equal(await codeOf(callTool(tools, "update_row_customers", { id: "20260901-001", values: { 更新者: "x" } })), "hidden_column");
});

test("update_row: 渡した列だけをセル単位で書き、更新日時と更新者を入れる（ほかの列と数式に触れない）", async () => {
  const fake = sheetAppFake();
  const rows = fake.sheet(SHEET_APP_ID, "顧客");
  rows[0].push("手で足した列");
  rows[1].push("=A2&B2");
  const out = await callTool(await sheetAppWriteTools(fake), "update_row_customers", { id: "20260901-001", values: { 状況: "取引中", 年間取引額: 120000 } });
  assert.deepEqual(out.changed, [
    { column: "状況", before: "見込み", after: "取引中" },
    { column: "年間取引額", before: null, after: 120000 },
  ]);
  assert.equal(out.updated_at, "2026-09-25 14:03:12");
  const update = fake.calls.find((call) => call.method === "update");
  assert.deepEqual(update?.ranges, ["'顧客'!E2", "'顧客'!K2", "'顧客'!O2", "'顧客'!P2"]);
  assert.deepEqual(rows[1].slice(13), ["2026-09-01 10:00:00", "2026-09-25 14:03:12", "AI（MCP）", "=A2&B2"]);
});

test("update_row: 変わる列が無ければ書かない", async () => {
  const fake = sheetAppFake();
  const out = await callTool(await sheetAppWriteTools(fake), "update_row_customers", { id: "20260901-001", values: { 状況: "見込み" } });
  assert.deepEqual(out.changed, []);
  assert.equal(fake.calls.some((call) => call.method === "update"), false);
});

test("update_row: 必須の列を空にすると validation、無い ID は row_not_found", async () => {
  const tools = await sheetAppWriteTools(sheetAppFake());
  await assert.rejects(callTool(tools, "update_row_customers", { id: "20260901-001", values: { 会社名: null } }), {
    code: "validation",
    message: "入力に誤りがあります。会社名: 会社名 を入力してください。",
  });
  assert.equal(await codeOf(callTool(tools, "update_row_customers", { id: "20990101-001", values: { 状況: "休眠" } })), "row_not_found");
});

test("update_row: 読んだあとにほかの方が更新していたら conflict", async () => {
  const tools = await sheetAppWriteTools(sheetAppFake());
  await assert.rejects(
    callTool(tools, "update_row_customers", { id: "20260901-002", values: { 状況: "休眠" }, expected_updated_at: "2026-09-01 10:01:00" }),
    { code: "conflict", message: /更新日時 2026-09-02 09:00:00/ },
  );
  const ok = await callTool(tools, "update_row_customers", { id: "20260901-002", values: { 状況: "休眠" }, expected_updated_at: "2026-09-02 09:00:00" });
  assert.equal((ok.changed as unknown[]).length, 1);
});

test("update_row: 書く直前に行がずれていたら row_moved で止める", async () => {
  const fake = sheetAppFake();
  fake.onCall = (method, ranges) => {
    if (method === "get" && ranges[0] === "'顧客'!A2:P2") fake.sheet(SHEET_APP_ID, "顧客").splice(1, 1);
  };
  assert.equal(await codeOf(callTool(await sheetAppWriteTools(fake), "update_row_customers", { id: "20260901-001", values: { 状況: "休眠" } })), "row_moved");
  assert.equal(fake.calls.some((call) => call.method === "update"), false);
});

test("update_row: 書く直前の読み直しで更新日時が変わっていたら conflict で止める", async () => {
  const fake = sheetAppFake();
  fake.onCall = (method, ranges) => {
    if (method === "get" && ranges[0] === "'顧客'!A2:P2") fake.sheet(SHEET_APP_ID, "顧客")[1][14] = "2026-09-25 14:00:00";
  };
  await assert.rejects(
    callTool(await sheetAppWriteTools(fake), "update_row_customers", { id: "20260901-001", values: { 状況: "休眠" }, expected_updated_at: "2026-09-01 10:00:00" }),
    { code: "conflict", message: /更新日時 2026-09-25 14:00:00/ },
  );
  assert.equal(fake.calls.some((call) => call.method === "update"), false);
});

test("update_row: 更新日時を見せない設定でも、expected_updated_at はシートの更新日時と照らす（文には値を出さない）", async () => {
  const tools = await sheetAppWriteTools(sheetAppFake(), { MCP_HIDE_COLUMNS: "顧客.更新日時" });
  const stale = await callTool(tools, "update_row_customers", { id: "20260901-002", values: { 状況: "休眠" }, expected_updated_at: "2026-09-01 10:01:00" }).then(
    () => assert.fail("止まるはず"),
    (error: ToolError) => error,
  );
  assert.equal(stale.code, "conflict");
  assert.equal(stale.message.includes("2026-09-02 09:00:00"), false);
  const ok = await callTool(tools, "update_row_customers", { id: "20260901-002", values: { 状況: "休眠" }, expected_updated_at: "2026-09-02 09:00:00" });
  assert.equal((ok.changed as unknown[]).length, 1);
});
