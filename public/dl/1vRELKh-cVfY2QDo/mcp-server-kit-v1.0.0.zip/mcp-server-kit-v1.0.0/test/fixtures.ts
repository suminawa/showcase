/**
 * 検査で使う見本（業務アプリの「顧客管理」の定義・予約・書類読み取りの行）と、小さな道具。
 * このファイルは *.test.ts ではないので、検査としては走らない（読み込まれるだけ）
 */
import { readConfig, type Config, type Vars } from "../src/core/env.ts";
import { ToolError } from "../src/core/errors.ts";
import { createHider } from "../src/core/hide.ts";
import type { ToolDef } from "../src/core/tool.ts";
import { dateKeyToSerial } from "../src/core/values.ts";
import { FakeSheets } from "../src/google/fake.ts";
import { parseDefinition, type Table } from "../src/vendor/sheet-app/index.js";

export const SHEET_APP_ID = "1SheetAppAbCdEfGhIjKlMnOpQrStUvWxYz012345";
export const BOOKING_ID = "1BookingAbCdEfGhIjKlMnOpQrStUvWxYz0123456";
export const DOC_READER_ID = "1DocReaderAbCdEfGhIjKlMnOpQrStUvWxYz01234";

/** 業務アプリ キットの見本（顧客管理の定義）と同じ中身 */
export const DEFINITION_ROWS: string[][] = [
  ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"],
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", "法人名。個人は氏名"],
  ["顧客", "担当者", "文字", "", "", "", "", "", "先方のご担当者の姓"],
  ["顧客", "業種", "選択", "", "建設, 不動産, 飲食, 小売, 士業, 医療, 製造, その他", "", "", "その他", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "メール", "メール", "", "", "FALSE", "", "", ""],
  ["顧客", "電話", "電話", "", "", "", "", "", ""],
  ["顧客", "LINE", "LINE", "", "", "FALSE", "FALSE", "", "LINE 公式アカウントの友だち。表示名から選びます"],
  ["顧客", "住所", "文字", "", "", "FALSE", "", "", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "今日", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", "円。見込みは空のまま"],
  ["顧客", "要注意", "チェック", "", "", "", "", "", "支払いの遅れなど"],
  ["顧客", "メモ", "長文", "", "", "FALSE", "", "", ""],
  ["対応履歴", "顧客", "参照:顧客", "TRUE", "", "", "", "", ""],
  ["対応履歴", "日付", "日付", "TRUE", "", "", "", "今日", ""],
  ["対応履歴", "種別", "選択", "TRUE", "電話, 訪問, メール, 打ち合わせ, その他", "", "", "電話", ""],
  ["対応履歴", "担当", "文字", "", "", "", "", "", "こちらの担当"],
  ["対応履歴", "内容", "長文", "TRUE", "", "", "", "", ""],
  ["対応履歴", "次回対応日", "日付", "", "", "", "", "", ""],
];

export function definitionTables(): Table[] {
  return parseDefinition(DEFINITION_ROWS).tables;
}

export const HIDER = createHider({ hideColumns: [], showUpdater: false });

const CUSTOMER_HEADER = ["ID", "会社名", "担当者", "業種", "状況", "メール", "電話", "LINE", "住所", "最終連絡日", "年間取引額", "要注意", "メモ", "作成日時", "更新日時", "更新者"];
const LINE_ID = "U0123456789abcdef0123456789abcdef";

/** 顧客 5 行（GAS が書いた形: 文字は文字、日付はシリアル値、金額は数、チェックは真偽） */
export function customerRows(): unknown[][] {
  const d = dateKeyToSerial;
  return [
    CUSTOMER_HEADER,
    ["20260901-001", "うみかぜ商店", "山川", "小売", "見込み", "info1@example.com", "045-000-0001", LINE_ID, "みなと市 1-2-3", d("2026-06-01"), "", false, "年度末に予算の相談", "2026-09-01 10:00:00", "2026-09-01 10:00:00", "staff@example.com"],
    ["20260901-002", "みなと工務店", "田中", "建設", "取引中", "info2@example.com", "045-000-0002", "", "みなと市 2-2-3", d("2026-08-20"), 240000, false, "", "2026-09-01 10:01:00", "2026-09-02 09:00:00", "staff@example.com"],
    ["20260901-003", "さくら不動産", "佐藤", "不動産", "休眠", "info3@example.com", "045-000-0003", "", "みなと市 3-2-3", d("2026-06-11"), 360000, true, "", "2026-09-01 10:02:00", "2026-09-01 10:02:00", "staff@example.com"],
    ["", "（ID の無い行は無いものとして扱う）", "", "", "", "", "", "", "", "", "", false, "", "", "", ""],
    ["20260901-004", "ひだまり整体院", "鈴木", "医療", "見込み", "info4@example.com", "045-000-0004", "", "みなと市 4-2-3", d("2026-07-16"), "", false, "", "2026-09-01 10:03:00", "2026-09-03 18:00:00", "staff@example.com"],
    ["20260925-001", "なぎさ食堂", "中村", "飲食", "取引中", "info8@example.com", "045-000-0008", "", "みなと市 8-2-3", d("2026-09-25"), 960000, false, "", "2026-09-25 09:00:00", "2026-09-25 09:00:00", "staff@example.com"],
  ];
}

export function contactRows(): unknown[][] {
  const d = dateKeyToSerial;
  return [
    ["ID", "顧客", "日付", "種別", "担当", "内容", "次回対応日", "作成日時", "更新日時", "更新者"],
    ["20260901-001", "20260901-001", d("2026-07-01"), "電話", "鈴木", "見積もりの内容についてご説明しました。", d("2026-07-31"), "2026-09-01 10:20:00", "2026-09-01 10:20:00", "staff@example.com"],
    ["20260901-002", "20260901-002", d("2026-07-04"), "訪問", "高橋", "納期のご相談を受けました。", "", "2026-09-01 10:21:00", "2026-09-01 10:21:00", "staff@example.com"],
  ];
}

export function sheetAppFake(extra: Record<string, unknown[][]> = {}): FakeSheets {
  return new FakeSheets({
    [SHEET_APP_ID]: {
      sheets: {
        定義: DEFINITION_ROWS,
        顧客: customerRows(),
        対応履歴: contactRows(),
        _ごみ箱: [["元テーブル", "ID", "削除日時", "削除者", "行の内容（JSON）"], ["顧客", "20260925-002", "2026-09-25 09:30:00", "staff@example.com", "{}"]],
        設定: [["項目", "値"], ["LINE チャネルアクセストークン", "line-token-should-never-be-read"]],
        ...extra,
      },
    },
  });
}

/** 2026-09-25 14:03:12（日本時間） */
export const NOW = new Date(Date.UTC(2026, 8, 25, 5, 3, 12));

/** 設定（.env の名前で上書きできる）。既定は見本の動き + 書き込みあり */
/** 設定（.env の名前で上書きできる）。既定は見本の動き + 書き込みあり */
export function configOf(vars: Vars = {}): Config {
  return readConfig({ MCP_DEMO: "1", MCP_WRITE: "true", ...vars }, "stdio").config;
}

/** ツールを名前で呼ぶ（引数の検査は通さない。検査は registry の受け持ち） */
export async function callTool(tools: ToolDef[], name: string, args: Record<string, unknown> = {}, now = NOW): Promise<Record<string, unknown>> {
  const tool = tools.find((t) => t.name === name);
  if (tool === undefined) throw new Error(`ツール ${name} がありません: ${tools.map((t) => t.name).join(", ")}`);
  tool.beforeCheck?.(args);
  return tool.run(args, now);
}

/** 失敗の code を取る（成功なら "ok"） */
export async function codeOf(promise: Promise<unknown>): Promise<string> {
  try {
    await promise;
    return "ok";
  } catch (error) {
    if (error instanceof ToolError) return error.code;
    throw error;
  }
}

const BOOKING_HEADER = ["ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話", "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用"];

/** 予約 5 行（GAS は全部 ' 付きの文字で書く。1 行だけ人が手で日付と時刻をセルに入れた形） */
export function bookingRows(): unknown[][] {
  return [
    BOOKING_HEADER,
    ["20260918-001", "確定", "2026-09-26", "10:00", "11:00", "初回カウンセリング（60 分）", "山川", "yamakawa@example.com", "045-000-0001", "", "2026-09-18 21:04:11", "", "event-id-1", "", "token-000000000000000001"],
    ["20260918-002", "確定", "2026-09-24", "14:00", "14:45", "通常の施術", "田中", "tanaka@example.com", "045-000-0002", "初めての利用です。", "2026-09-18 21:10:00", "", "event-id-2", "", "token-000000000000000002"],
    ["20260920-001", "キャンセル", "2026-09-30", "15:30", "16:15", "通常の施術", "佐藤", "sato@example.com", "", "", "2026-09-20 09:00:00", "2026-09-21 10:00:00", "", "", "token-000000000000000003"],
    ["20260922-001", "確定", dateKeyToSerial("2026-10-03"), 0.4166666667, "11:00", "", "鈴木", "suzuki@example.com", "", "肩こりが気になります。", "2026-09-22 12:00:00", "", "", "", "token-000000000000000004"],
    ["20260923-001", "確定", "2026-09-25", "15:00", "15:45", "通常の施術", "高橋", "takahashi@example.com", "", "", "2026-09-23 08:00:00", "", "", "", "token-000000000000000005"],
  ];
}

export function bookingFake(): FakeSheets {
  return new FakeSheets({ [BOOKING_ID]: { sheets: { 予約: bookingRows(), 枠: [["曜日"]], 設定: [["項目", "値"]] } } });
}

const DOC_HEADER = ["書類ID", "ファイル名", "請求元", "請求先", "請求書番号", "発行日", "支払期限", "税抜金額", "消費税", "合計金額", "登録番号", "振込先"];

/** 書類読み取りの結果（請求書 3 通。1 通は 2 度送られて 2 行） */
export function docRows(): unknown[][] {
  const d = dateKeyToSerial;
  return [
    DOC_HEADER,
    ["a1b2c3d4e5f60001", "請求書_さくら設備.pdf", "さくら設備株式会社", "みなと商会", "INV-2026-0901", d("2026-09-01"), d("2026-09-30"), 152500, 15250, 167750, "T0000000000001", "うみかぜ銀行 中央支店 普通 0000001"],
    ["a1b2c3d4e5f60002", "請求書_ひかり工務店.jpg", "ひかり工務店", "みなと商会 総務部", "H-0905", "2026-09-05", "2026-10-31", 252000, 25200, 277200, "T0000000000002", "しおかぜ信用金庫 本店 普通 0000002"],
    ["a1b2c3d4e5f60003", "請求書_あおば印刷.pdf", "あおば印刷", "みなと商会", "AP-260910-07", d("2026-09-10"), d("2026-10-10"), 61400, 6140, 67540, "T0000000000003", "うみかぜ銀行 さくら支店 当座 0000003"],
    ["a1b2c3d4e5f60001", "請求書_さくら設備.pdf", "さくら設備株式会社", "みなと商会", "INV-2026-0901", d("2026-09-01"), d("2026-09-30"), 152500, 15250, 167750, "T0000000000001", "うみかぜ銀行 中央支店 普通 0000001"],
  ];
}

export function docFake(sheetName = "読み取り"): FakeSheets {
  return new FakeSheets({ [DOC_READER_ID]: { sheets: { [sheetName]: docRows() } } });
}
