import { test } from "node:test";
import assert from "node:assert/strict";
import { createLogger, stderrSink } from "../src/core/log.ts";

const clock = () => new Date(Date.UTC(2026, 8, 25, 5, 3, 12));

test("呼び出しのログは 1 行で、引数は名前だけ", () => {
  const lines: string[] = [];
  const logger = createLogger("info", (line) => lines.push(line), clock);
  logger.call({ tool: "search_rows", ms: 12, result: "ok", rows: 7, argNames: ["table", "keyword"] });
  assert.deepEqual(lines, ["2026-09-25T05:03:12.000Z tool=search_rows ms=12 result=ok rows=7 args=table,keyword"]);
});

test("debug は MCP_LOG=debug のときだけ書く", () => {
  const lines: string[] = [];
  createLogger("info", (line) => lines.push(line), clock).debug("GET 200");
  createLogger("debug", (line) => lines.push(line), clock).debug("GET 200");
  assert.equal(lines.length, 1);
});

test("stderrSink は stderr にだけ書き、stdout には書かない", (t) => {
  const out = t.mock.method(process.stdout, "write", () => true);
  const err = t.mock.method(process.stderr, "write", () => true);
  stderrSink("hello");
  assert.equal(out.mock.callCount(), 0);
  assert.equal(err.mock.callCount(), 1);
  assert.equal(err.mock.calls[0].arguments[0], "hello\n");
});
