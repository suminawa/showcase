import { test } from "node:test";
import assert from "node:assert/strict";
import type { CallToolResult } from "@modelcontextprotocol/sdk/types.js";
import { WriteLimiter } from "../src/core/limits.ts";
import { createLogger } from "../src/core/log.ts";
import type { Source, ToolDef } from "../src/core/tool.ts";
import { Registry } from "../src/server/registry.ts";
import { sheetAppSource } from "../src/sources/sheet-app/source.ts";
import { NOW, sheetAppFake } from "./fixtures.ts";
import { sheetAppContext } from "./sheet-app-helpers.ts";

function textOf(result: CallToolResult): string {
  return (result.content[0] as { text: string }).text;
}

function registryOf(sources: Source[], lines: string[] = [], limiter = new WriteLimiter()) {
  return new Registry({ sources, limiter, logger: createLogger("debug", (line) => lines.push(line), () => NOW), clock: () => NOW });
}

function sheetApp(vars = {}) {
  return sheetAppSource(sheetAppContext(sheetAppFake(), { MCP_TABLE_ALIASES: "顧客:customers, 対応履歴:contacts", ...vars }));
}

test("tools/list: 読む 4 本と書く 4 本。形・注記・outputSchema がそろう", async () => {
  const tools = await registryOf([sheetApp()]).list();
  assert.deepEqual(tools.map((t) => t.name), ["list_tables", "describe_table", "search_rows", "get_row", "add_row_customers", "update_row_customers", "add_row_contacts", "update_row_contacts"]);
  for (const tool of tools) {
    assert.match(tool.name, /^[a-z0-9_]{1,64}$/);
    assert.equal(tool.inputSchema.type, "object");
    assert.equal(tool.outputSchema?.type, "object");
  }
  assert.deepEqual(tools[0].annotations, { title: "業務アプリのテーブル一覧", readOnlyHint: true, openWorldHint: false });
});

test("tools/call: structuredContent と、同じ JSON を content[0].text に", async () => {
  const result = await registryOf([sheetApp()]).call("get_row", { table: "顧客", id: "20260901-002" });
  assert.equal(result.isError, undefined);
  assert.deepEqual(JSON.parse((result.content[0] as { text: string }).text), result.structuredContent);
});

test("引数の誤りは invalid_arguments の敬体の文（code を添える）", async () => {
  const result = await registryOf([sheetApp()]).call("search_rows", { table: "顧客", limit: 0 });
  assert.equal(result.isError, true);
  assert.equal((result.content[0] as { text: string }).text, "引数に誤りがあります: limit は 1 から 500 までの整数にしてください。（code: invalid_arguments）");
});

test("知らないツールは unknown_tool、見せない列は引数の検査より先に hidden_column", async () => {
  const registry = registryOf([sheetApp()]);
  assert.match(textOf(await registry.call("delete_row", {})), /code: unknown_tool/);
  assert.match(textOf(await registry.call("add_row_customers", { values: { 会社名: "x", LINE: "U1" } })), /code: hidden_column/);
});

test("書くツールは 1 分に 20 回まで（21 回目は write_rate）", async () => {
  const registry = registryOf([sheetApp()], [], new WriteLimiter(2, 60000));
  for (let i = 0; i < 2; i += 1) assert.equal((await registry.call("update_row_customers", { id: "20260901-001", values: { 状況: "休眠" } })).isError, undefined);
  assert.match(textOf(await registry.call("update_row_customers", { id: "20260901-001", values: { 状況: "休眠" } })), /code: write_rate/);
  assert.equal((await registry.call("search_rows", { table: "顧客" })).isError, undefined);
});

test("思わぬ例外は中身を返さず internal。生の文は debug のログにだけ", async () => {
  const lines: string[] = [];
  const broken: ToolDef = {
    name: "broken", title: "壊れた", description: "", inputSchema: { type: "object" }, outputSchema: { type: "object" }, annotations: { readOnlyHint: true, openWorldHint: false }, write: false,
    run: async () => {
      throw new Error("secret stack detail");
    },
  };
  const result = await registryOf([{ tools: async () => [broken] }], lines).call("broken", {});
  assert.equal(JSON.stringify(result).includes("secret stack detail"), false);
  assert.match(textOf(result), /code: internal/);
  assert.ok(lines.some((line) => line.includes("secret stack detail")));
});

test("呼び出しのログは 1 行で、引数の値・見本の会社名・メールを書かない", async () => {
  const lines: string[] = [];
  const registry = registryOf([sheetApp()], lines);
  await registry.call("search_rows", { table: "顧客", keyword: "うみかぜ" });
  await registry.call("add_row_contacts", { values: { 顧客: "20260901-001", 種別: "電話", 内容: "info1@example.com に電話" } });
  const calls = lines.filter((line) => line.includes("tool="));
  assert.deepEqual(calls, [
    `${NOW.toISOString()} tool=search_rows ms=0 result=ok rows=1 args=table,keyword`,
    `${NOW.toISOString()} tool=add_row_contacts ms=0 result=ok rows=1 args=values`,
  ]);
  for (const word of ["うみかぜ", "info1@example.com", "顧客"]) assert.equal(lines.join("\n").includes(word), false, word);
});

test("定義を読めない元も list_tables だけは出し、呼ぶと読めない理由を返す", async () => {
  const fake = sheetAppFake();
  fake.books.get([...fake.books.keys()][0])?.sheets.delete("定義");
  const registry = registryOf([sheetAppSource(sheetAppContext(fake))]);
  assert.deepEqual((await registry.list()).map((t) => t.name), ["list_tables"]);
  assert.match(textOf(await registry.call("list_tables", {})), /「定義」シートがありません。.*（code: sheet_missing）/);
});
