import { test } from "node:test";
import assert from "node:assert/strict";
import { hashSuffix } from "../src/sources/sheet-app/schema.ts";
import { SHEET_APP_ID, callTool, codeOf, sheetAppFake } from "./fixtures.ts";
import { sheetAppReadTools } from "./sheet-app-helpers.ts";

type Rows = { rows: Record<string, unknown>[]; total: number; count: number; next_offset: number | null; truncated: boolean; labels: Record<string, string> };

test("list_tables: テーブル・別名・書き込めるか・定義の誤り", async () => {
  const tools = await sheetAppReadTools(sheetAppFake(), { MCP_TABLE_ALIASES: "顧客:customers, 対応履歴:Contacts" });
  const out = await callTool(tools, "list_tables");
  assert.deepEqual(out.tables, [
    { name: "顧客", tool_suffix: "customers", display_column: "会社名", columns: 11, writable: true },
    { name: "対応履歴", tool_suffix: hashSuffix("対応履歴"), display_column: "担当", columns: 6, writable: true },
  ]);
  assert.equal(out.write_enabled, true);
  assert.equal((out.definition_errors as string[]).length, 1);
});

test("describe_table: 列の決まり・行の数・見せない列は出さない・書くツール名", async () => {
  const tools = await sheetAppReadTools(sheetAppFake(), { MCP_TABLE_ALIASES: "顧客:customers" });
  const out = await callTool(tools, "describe_table", { table: "顧客" });
  assert.equal(out.row_count, 5);
  const columns = out.columns as { name: string; type: string; max_length: number | null; default: string }[];
  assert.equal(columns.some((c) => c.name === "LINE"), false);
  assert.deepEqual(columns[0], { name: "会社名", type: "文字", required: true, options: [], default: "", note: "法人名。個人は氏名", searchable: true, ref_table: null, max_length: 200 });
  assert.deepEqual(out.system_columns, ["ID", "作成日時", "更新日時"]);
  assert.deepEqual(out.tools, { add: "add_row_customers", update: "update_row_customers" });
  const readOnly = await sheetAppReadTools(sheetAppFake(), { MCP_WRITE: "false" });
  assert.equal((await callTool(readOnly, "describe_table", { table: "顧客" })).tools, null);
});

test("search_rows: 全部の列（見せない列を除く）を返し、ID の無い行と LINE・更新者は出さない", async () => {
  const out = (await callTool(await sheetAppReadTools(sheetAppFake()), "search_rows", { table: "顧客" })) as unknown as Rows;
  assert.equal(out.total, 5);
  const first = out.rows.find((row) => row.ID === "20260901-001");
  assert.deepEqual(first, {
    ID: "20260901-001", 会社名: "うみかぜ商店", 担当者: "山川", 業種: "小売", 状況: "見込み", メール: "info1@example.com", 電話: "045-000-0001",
    住所: "みなと市 1-2-3", 最終連絡日: "2026-06-01", 年間取引額: null, 要注意: false, メモ: "年度末に予算の相談", 作成日時: "2026-09-01 10:00:00", 更新日時: "2026-09-01 10:00:00",
  });
  assert.deepEqual(out.rows.map((row) => row.ID), ["20260925-001", "20260901-004", "20260901-002", "20260901-003", "20260901-001"]);
});

test("search_rows: keyword は検索の列を部分一致（全角半角・大文字小文字を同一視）", async () => {
  const tools = await sheetAppReadTools(sheetAppFake());
  const out = (await callTool(tools, "search_rows", { table: "顧客", keyword: "ＩＮＦＯ2" })) as unknown as Rows;
  assert.deepEqual(out.rows.map((row) => row.会社名), ["みなと工務店"]);
});

test("search_rows: filters と sort（見込みのまま、最終連絡日が 7/1 より前、古い順）", async () => {
  const out = (await callTool(await sheetAppReadTools(sheetAppFake()), "search_rows", {
    table: "顧客",
    filters: [{ column: "状況", op: "eq", value: "見込み" }, { column: "最終連絡日", op: "lt", value: "2026-07-20" }],
    sort: { column: "最終連絡日", dir: "asc" },
  })) as unknown as Rows;
  assert.deepEqual(out.rows.map((row) => row.会社名), ["うみかぜ商店", "ひだまり整体院"]);
});

test("search_rows: limit と offset、next_offset", async () => {
  const out = (await callTool(await sheetAppReadTools(sheetAppFake()), "search_rows", { table: "顧客", limit: 2, offset: 2 })) as unknown as Rows;
  assert.equal(out.count, 2);
  assert.equal(out.next_offset, 4);
  assert.equal(out.truncated, false);
});

test("search_rows: 80,000 字を超えるなら後ろを落として truncated", async () => {
  const fake = sheetAppFake();
  const rows = fake.sheet(SHEET_APP_ID, "顧客");
  for (let i = 0; i < 40; i += 1) rows.push(["20260910-" + String(i + 1).padStart(3, "0"), `会社${i}`, "", "", "見込み", "", "", "", "", "", "", false, "あ".repeat(4000), "2026-09-10 10:00:00", "2026-09-10 10:00:00", ""]);
  const out = (await callTool(await sheetAppReadTools(fake), "search_rows", { table: "顧客", limit: 100 })) as unknown as Rows;
  assert.equal(out.truncated, true);
  assert.ok(out.count < 45);
  assert.equal(out.next_offset, out.count);
});

test("search_rows: 参照の列の表示名を labels に入れる（参照先も同じ batchGet で読む）", async () => {
  const fake = sheetAppFake();
  const out = (await callTool(await sheetAppReadTools(fake), "search_rows", { table: "対応履歴" })) as unknown as Rows;
  assert.deepEqual(out.labels, { "20260901-001": "うみかぜ商店", "20260901-002": "みなと工務店" });
  assert.deepEqual(fake.calls.filter((call) => call.method === "batchGet").at(-1)?.ranges, ["'対応履歴'!A1:ZZ", "'顧客'!A1:ZZ"]);
});

test("知らないテーブル・知らない列・見せない列は、それぞれの code で返す", async () => {
  const tools = await sheetAppReadTools(sheetAppFake());
  assert.equal(await codeOf(callTool(tools, "search_rows", { table: "案件" })), "unknown_table");
  assert.equal(await codeOf(callTool(tools, "search_rows", { table: "顧客", filters: [{ column: "会社", op: "eq", value: "x" }] })), "unknown_column");
  assert.equal(await codeOf(callTool(tools, "search_rows", { table: "顧客", filters: [{ column: "LINE", op: "notEmpty" }] })), "hidden_column");
  assert.equal(await codeOf(callTool(tools, "search_rows", { table: "顧客", sort: { column: "更新者" } })), "hidden_column");
  assert.equal(await codeOf(callTool(tools, "search_rows", { table: "顧客", filters: [{ column: "最終連絡日", op: "between", value: "2026-07-01" }] })), "invalid_arguments");
});

test("get_row: ID で読む。無い ID は row_not_found", async () => {
  const tools = await sheetAppReadTools(sheetAppFake());
  const out = await callTool(tools, "get_row", { table: "対応履歴", id: "20260901-002" });
  assert.equal((out.row as Record<string, unknown>).内容, "納期のご相談を受けました。");
  assert.deepEqual(out.labels, { "20260901-002": "みなと工務店" });
  assert.equal(await codeOf(callTool(tools, "get_row", { table: "顧客", id: "20990101-001" })), "row_not_found");
});

test("シートが無ければ sheet_missing、定義が空なら definition_empty", async () => {
  const fake = sheetAppFake();
  fake.books.get(SHEET_APP_ID)?.sheets.delete("対応履歴");
  assert.equal(await codeOf(callTool(await sheetAppReadTools(fake), "get_row", { table: "対応履歴", id: "20260901-001" })), "sheet_missing");
  const empty = sheetAppFake({ 定義: [["テーブル", "列", "型"]] });
  const tools = await sheetAppReadTools(empty);
  assert.equal(await codeOf(callTool(tools, "search_rows", { table: "顧客" })), "definition_empty");
  assert.deepEqual((await callTool(tools, "list_tables")).definition_errors, ["「定義」シートにテーブルがありません。2 行目から、テーブル・列・型を書いてください"]);
});

test("「設定」シートは読まない（LINE のトークンに触れない）", async () => {
  const fake = sheetAppFake();
  const tools = await sheetAppReadTools(fake);
  await callTool(tools, "search_rows", { table: "顧客" });
  await callTool(tools, "describe_table", { table: "対応履歴" });
  assert.equal(fake.calls.some((call) => call.ranges.some((range) => range.startsWith("'設定'"))), false);
});
