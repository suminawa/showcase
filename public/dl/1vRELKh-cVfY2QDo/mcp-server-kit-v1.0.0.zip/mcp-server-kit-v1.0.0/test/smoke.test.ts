import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const KIT = fileURLToPath(new URL("..", import.meta.url));

async function smoke(entry: string): Promise<void> {
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [entry],
    cwd: KIT,
    env: { PATH: process.env.PATH ?? "", MCP_DEMO: "1", MCP_ENV_FILE_SKIP: "1" },
    stderr: "pipe",
  });
  const client = new Client({ name: "smoke", version: "1.0.0" });
  await client.connect(transport);
  try {
    const { tools } = await client.listTools();
    for (const name of ["list_tables", "describe_table", "search_rows", "get_row", "list_bookings", "get_booking", "list_documents", "get_document"]) {
      assert.ok(tools.some((t) => t.name === name), name);
    }
    const result = await client.callTool({ name: "search_rows", arguments: { table: "顧客" } });
    assert.equal((result.structuredContent as { total: number }).total, 20);
  } finally {
    await client.close();
  }
}

test("MCP_DEMO=1 の stdio を子プロセスで起こし、initialize → tools/list → search_rows（src）", async () => {
  await smoke(`${KIT}src/server/stdio.ts`);
});

test("同じことを build 済みの dist/stdio.js でも（build 前は飛ばす。release は build のあとに検査を回す）", { skip: !existsSync(`${KIT}dist/stdio.js`) }, async () => {
  await smoke(`${KIT}dist/stdio.js`);
});
