import { test } from "node:test";
import assert from "node:assert/strict";
import type { Vars } from "../src/core/env.ts";
import { createHider } from "../src/core/hide.ts";
import type { ToolDef } from "../src/core/tool.ts";
import type { FakeSheets } from "../src/google/fake.ts";
import { MetaCache } from "../src/google/sheets.ts";
import { docReaderSource } from "../src/sources/doc-reader.ts";
import { DOC_READER_ID, NOW, callTool, codeOf, configOf, docFake } from "./fixtures.ts";

async function docTools(fake: FakeSheets, vars: Vars = {}): Promise<ToolDef[]> {
  const config = configOf(vars);
  return docReaderSource({ sheets: fake, meta: new MetaCache(fake), spreadsheetId: DOC_READER_ID, sheetName: config.docReaderSheet, hider: createHider(config) }).tools(NOW);
}

type Listed = { sheet: string; columns: string[]; total: number; documents: Record<string, unknown>[] };

test("見出しの名前で読み、日付の見出しの列だけシリアル値を日付に直す", async () => {
  const out = (await callTool(await docTools(docFake()), "list_documents")) as unknown as Listed;
  assert.equal(out.sheet, "読み取り");
  assert.equal(out.columns.length, 12);
  const doc = out.documents.find((d) => d.請求元 === "あおば印刷");
  assert.equal(doc?.発行日, "2026-09-10");
  assert.equal(doc?.合計金額, 67540);
});

test("新しい順（シートの下から）に返す", async () => {
  const out = (await callTool(await docTools(docFake()), "list_documents")) as unknown as Listed;
  assert.deepEqual(out.documents.map((d) => d.請求元), ["さくら設備株式会社", "あおば印刷", "ひかり工務店", "さくら設備株式会社"]);
});

test("filters: 数どうしは数で、YYYY-MM-DD は日付の文字で比べる", async () => {
  const tools = await docTools(docFake());
  const big = (await callTool(tools, "list_documents", { filters: [{ column: "合計金額", op: "gte", value: 200000 }] })) as unknown as Listed;
  assert.deepEqual(big.documents.map((d) => d.請求元), ["ひかり工務店"]);
  const due = (await callTool(tools, "list_documents", {
    keyword: "みなと",
    filters: [{ column: "支払期限", op: "gte", value: "2026-09-01" }, { column: "支払期限", op: "lte", value: "2026-09-30" }],
  })) as unknown as Listed;
  assert.equal(due.total, 2);
  assert.equal(await codeOf(callTool(tools, "list_documents", { filters: [{ column: "金額", op: "eq", value: 1 }] })), "unknown_column");
});

test("get_document: 同じ書類ID の行が 2 つなら最後の行と、その数", async () => {
  const tools = await docTools(docFake());
  const out = await callTool(tools, "get_document", { document_id: "a1b2c3d4e5f60001" });
  assert.equal(out.duplicates, 2);
  assert.equal((out.document as Record<string, unknown>).請求書番号, "INV-2026-0901");
  assert.equal(await codeOf(callTool(tools, "get_document", { document_id: "ffffffffffffffff" })), "document_not_found");
});

test("シート名は DOC_READER_SHEET で変えられ、MCP_HIDE_COLUMNS の列は返さない", async () => {
  const tools = await docTools(docFake("請求書"), { DOC_READER_SHEET: "請求書", MCP_HIDE_COLUMNS: "請求書.振込先" });
  const out = (await callTool(tools, "list_documents")) as unknown as Listed;
  assert.equal(out.sheet, "請求書");
  assert.equal(out.columns.includes("振込先"), false);
  assert.equal(JSON.stringify(out.documents).includes("うみかぜ銀行"), false);
  assert.equal(await codeOf(callTool(tools, "list_documents", { filters: [{ column: "振込先", op: "contains", value: "銀行" }] })), "hidden_column");
});

test("シートが無いときは、書類読み取りから送ると作られることを伝える", async () => {
  await assert.rejects(callTool(await docTools(docFake("別の名前")), "list_documents"), {
    code: "sheet_missing",
    message: "スプレッドシートに「読み取り」シートがありません。書類読み取りから 1 度送ると作られます。DOC_READER_SHEET のシート名もご確認ください。",
  });
});
