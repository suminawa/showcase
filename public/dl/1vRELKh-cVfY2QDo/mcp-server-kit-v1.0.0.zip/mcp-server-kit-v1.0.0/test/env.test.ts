import { test } from "node:test";
import assert from "node:assert/strict";
import { ENV_NAMES, mergeEnv, parseEnvText, readConfig, spreadsheetIdOf, type Vars } from "../src/core/env.ts";

const ID = "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-ab";
const BASE: Vars = { GOOGLE_SERVICE_ACCOUNT_FILE: "./key.json", SHEET_APP_SPREADSHEET: ID };

test("読み手: 引用符・# の注記・空行・export・= を含む値", () => {
  const vars = parseEnvText(
    ["# 注記", "", "A=1", 'B="two words # not comment"', "C='x=y'", "export D=plain # 注記", "E=a=b=c", "BROKEN"].join("\n"),
  );
  assert.deepEqual(vars, { A: "1", B: "two words # not comment", C: "x=y", D: "plain", E: "a=b=c" });
});

test("読み手: 先頭の BOM と CRLF を落とす", () => {
  assert.deepEqual(parseEnvText("﻿MCP_WRITE=true\r\nMCP_LOG=debug\r\n"), { MCP_WRITE: "true", MCP_LOG: "debug" });
});

test("プロセスの環境変数が .env より勝ち、知らない名前は捨てる", () => {
  const merged = mergeEnv({ MCP_WRITE: "false", MCP_LOG: "debug", OTHER: "x" }, { MCP_WRITE: "true", PATH: "/bin" });
  assert.deepEqual(merged, { MCP_WRITE: "true", MCP_LOG: "debug" });
});

test("スプレッドシートの URL から ID を取り出す。形の違うものは null", () => {
  assert.equal(spreadsheetIdOf(`https://docs.google.com/spreadsheets/d/${ID}/edit#gid=0`), ID);
  assert.equal(spreadsheetIdOf(ID), ID);
  assert.equal(spreadsheetIdOf("short"), null);
  assert.equal(spreadsheetIdOf("https://example.com/not-a-sheet"), null);
});

test("ID の形が違うと、名前を挙げた誤りになる", () => {
  const { errors } = readConfig({ ...BASE, BOOKING_SPREADSHEET: "abc" }, "stdio");
  assert.deepEqual(errors, ["BOOKING_SPREADSHEET の URL か ID の形が違います。スプレッドシートを開いたときのアドレスを、そのまま貼ってください。"]);
});

test("3 つとも空・鍵が無いと誤り。MCP_DEMO=1 ならどちらも要らない", () => {
  const { errors } = readConfig({}, "stdio");
  assert.equal(errors.length, 2);
  assert.match(errors[0], /GOOGLE_SERVICE_ACCOUNT_FILE/);
  assert.equal(errors[1], "スプレッドシートの URL か ID が設定されていません。SHEET_APP_SPREADSHEET・BOOKING_SPREADSHEET・DOC_READER_SPREADSHEET のどれかを書いてください（README の 5 章）。");
  assert.deepEqual(readConfig({ MCP_DEMO: "1" }, "stdio").errors, []);
});

test("HTTP では MCP_HTTP_TOKEN が 32 字以上要る（stdio では要らない）", () => {
  assert.deepEqual(readConfig({ ...BASE, MCP_HTTP_TOKEN: "short" }, "stdio").errors, []);
  assert.deepEqual(readConfig({ ...BASE, MCP_HTTP_TOKEN: "short" }, "http").errors, [
    "MCP_HTTP_TOKEN が空か、32 字より短いです。npm run token で作った文字を貼ってください（README の 8 章の 1）。",
  ]);
  assert.deepEqual(readConfig({ ...BASE, MCP_HTTP_TOKEN: "x".repeat(32) }, "http").errors, []);
  // check（cli）は書いたときだけ確かめ、待ち受け先の注意は HTTP 版の起動のときだけ出す
  assert.deepEqual(readConfig({ ...BASE }, "cli").errors, []);
  assert.equal(readConfig({ ...BASE, MCP_HTTP_TOKEN: "short" }, "cli").errors.length, 1);
  assert.deepEqual(readConfig({ ...BASE, MCP_HTTP_TOKEN: "x".repeat(32), MCP_HTTP_HOST: "0.0.0.0" }, "cli").warnings, []);
});

test("MCP_PUBLIC_URL が http:// なら誤り。末尾の / は落とす", () => {
  const token = { MCP_HTTP_TOKEN: "x".repeat(40) };
  assert.deepEqual(readConfig({ ...BASE, ...token, MCP_PUBLIC_URL: "http://example.com" }, "http").errors, ["MCP_PUBLIC_URL は https:// から書いてください。"]);
  assert.equal(readConfig({ ...BASE, ...token, MCP_PUBLIC_URL: "https://mcp.example.com/" }, "http").config.publicUrl, "https://mcp.example.com");
});

test("MCP_TABLES・MCP_TABLE_ALIASES・MCP_HIDE_COLUMNS を読む（読点と全角のコロンも可）", () => {
  const { config, warnings } = readConfig(
    { ...BASE, MCP_TABLES: "顧客、対応履歴", MCP_TABLE_ALIASES: "顧客:customers, 対応履歴：contacts", MCP_HIDE_COLUMNS: "顧客.電話, 予約.メール" },
    "stdio",
  );
  assert.deepEqual(config.tables, ["顧客", "対応履歴"]);
  assert.deepEqual(config.aliases, { 顧客: "customers", 対応履歴: "contacts" });
  assert.deepEqual(config.hideColumns, ["顧客.電話", "予約.メール"]);
  assert.deepEqual(warnings, []);
});

test("形の違う別名・見せない列は警告にとどめて使わない", () => {
  const { config, warnings } = readConfig({ ...BASE, MCP_TABLE_ALIASES: "顧客", MCP_HIDE_COLUMNS: "電話" }, "stdio");
  assert.deepEqual(config.aliases, {});
  assert.deepEqual(config.hideColumns, []);
  assert.equal(warnings.length, 2);
});

test("既定値: 書き込みなし・127.0.0.1:8787・読み取りシート・info", () => {
  const { config } = readConfig(BASE, "stdio");
  assert.equal(config.write, false);
  assert.equal(config.httpHost, "127.0.0.1");
  assert.equal(config.httpPort, 8787);
  assert.equal(config.docReaderSheet, "読み取り");
  assert.equal(config.log, "info");
  assert.equal(readConfig({ ...BASE, MCP_WRITE: "TRUE" }, "stdio").config.write, true);
  assert.equal(ENV_NAMES.length, 18);
});

test("誤りと警告の文に、値そのもの（合い言葉・ID・URL）が入らない", () => {
  const secret = "secret-value-123";
  const { errors, warnings } = readConfig(
    { SHEET_APP_SPREADSHEET: "bad-id-value", MCP_HTTP_TOKEN: secret, MCP_PUBLIC_URL: "http://leak.example.com", MCP_HTTP_HOST: "0.0.0.0" },
    "http",
  );
  const all = [...errors, ...warnings].join("\n");
  for (const value of [secret, "bad-id-value", "leak.example.com"]) assert.equal(all.includes(value), false, value);
  assert.ok(warnings.some((w) => w.startsWith("127.0.0.1 以外で待ち受けています。")));
});
