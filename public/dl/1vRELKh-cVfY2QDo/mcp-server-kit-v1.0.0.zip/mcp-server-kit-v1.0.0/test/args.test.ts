import { test } from "node:test";
import assert from "node:assert/strict";
import { checkArgs, type JsonSchema } from "../src/core/args.ts";

const LIMIT: JsonSchema = { type: "integer", minimum: 1, maximum: 500 };

test("type: 整数・文字・真偽・配列", () => {
  assert.deepEqual(checkArgs({ type: "string" }, 3, "keyword"), ["keyword は文字にしてください"]);
  assert.deepEqual(checkArgs({ type: "boolean" }, "yes", "flag"), ["flag は true か false にしてください"]);
  assert.deepEqual(checkArgs({ type: "array" }, {}, "filters"), ["filters は配列（[ ]）にしてください"]);
  assert.deepEqual(checkArgs({ type: "number" }, 1.5, "n"), []);
  assert.deepEqual(checkArgs({ type: ["string", "number"] }, true, "value"), ["value は文字 か 数にしてください"]);
});

test("minimum・maximum は範囲を添えて言う", () => {
  assert.deepEqual(checkArgs(LIMIT, 0, "limit"), ["limit は 1 から 500 までの整数にしてください"]);
  assert.deepEqual(checkArgs(LIMIT, 501, "limit"), ["limit は 1 から 500 までの整数にしてください"]);
  assert.deepEqual(checkArgs(LIMIT, 2.5, "limit"), ["limit は 1 から 500 までの整数にしてください"]);
  assert.deepEqual(checkArgs({ type: "integer", minimum: 0 }, -1, "offset"), ["offset は 0 以上の整数にしてください"]);
});

test("enum", () => {
  assert.deepEqual(checkArgs({ type: "string", enum: ["asc", "desc"] }, "up", "sort.dir"), ["sort.dir は次のどれかにしてください: asc、desc"]);
});

test("required と additionalProperties", () => {
  const schema: JsonSchema = { type: "object", additionalProperties: false, required: ["table"], properties: { table: { type: "string" } } };
  assert.deepEqual(checkArgs(schema, {}), ["table がありません"]);
  assert.deepEqual(checkArgs(schema, { table: "顧客", extra: 1 }), ["引数 に、知らない項目「extra」があります（使える項目: table）"]);
});

test("values の知らない列は「列」と言い、使える列を並べる", () => {
  const schema: JsonSchema = {
    type: "object",
    required: ["values"],
    properties: { values: { type: "object", additionalProperties: false, properties: { 会社名: { type: "string" }, 担当者: { type: "string" } } } },
  };
  assert.deepEqual(checkArgs(schema, { values: { 会社: "x" } }), ["values に、知らない列「会社」があります（使える列: 会社名、担当者）"]);
});

test("minLength・maxLength", () => {
  assert.deepEqual(checkArgs({ type: "string", maxLength: 3 }, "abcd", "keyword"), ["keyword は 3 字以内にしてください"]);
  assert.deepEqual(checkArgs({ type: "string", minLength: 8 }, "abc", "document_id"), ["document_id は 8 字以上にしてください"]);
});

test("pattern", () => {
  const id: JsonSchema = { type: "string", pattern: "^\\d{8}-\\d{3,}$" };
  assert.deepEqual(checkArgs(id, "20260916-003", "id"), []);
  assert.deepEqual(checkArgs(id, "2026-09-16", "id"), ["id の形が違います（形: ^\\d{8}-\\d{3,}$）"]);
});

test("items・maxItems・uniqueItems と、配列の中の位置", () => {
  const tags: JsonSchema = { type: "array", maxItems: 2, uniqueItems: true, items: { type: "string", enum: ["a", "b", "c"] } };
  assert.deepEqual(checkArgs(tags, ["a", "a"], "tags"), ["tags に同じ値が 2 回あります"]);
  assert.deepEqual(checkArgs(tags, ["a", "b", "c"], "tags"), ["tags は 2 個までにしてください"]);
  assert.deepEqual(checkArgs(tags, ["a", "z"], "tags"), ["tags[1] は次のどれかにしてください: a、b、c"]);
});

test("anyOf は null を許すときに使い、外れたら本体の誤りを言う", () => {
  const nullable: JsonSchema = { anyOf: [{ type: "integer" }, { type: "null" }] };
  assert.deepEqual(checkArgs(nullable, null, "年間取引額"), []);
  assert.deepEqual(checkArgs(nullable, 10, "年間取引額"), []);
  assert.deepEqual(checkArgs(nullable, "高い", "年間取引額"), ["年間取引額 は整数にしてください"]);
});

test("minProperties と、入れ子の誤りをまとめて返す", () => {
  const schema: JsonSchema = {
    type: "object",
    properties: { values: { type: "object", minProperties: 1, properties: {} }, limit: LIMIT },
  };
  assert.deepEqual(checkArgs(schema, { values: {}, limit: 0 }), ["values に、列を 1 つ以上入れてください", "limit は 1 から 500 までの整数にしてください"]);
});
