import { test } from "node:test";
import assert from "node:assert/strict";
import { createHider } from "../src/core/hide.ts";

test("既定で落とす列: LINE 型・更新者・予約のキャンセル用とカレンダー", () => {
  const hider = createHider({ hideColumns: [], showUpdater: false });
  assert.equal(hider.isHidden("sheet-app", "顧客", "LINE", "LINE"), true);
  assert.equal(hider.isHidden("sheet-app", "顧客", "更新者"), true);
  assert.equal(hider.isHidden("sheet-app", "顧客", "会社名", "文字"), false);
  assert.equal(hider.isHidden("booking", "予約", "キャンセル用"), true);
  assert.equal(hider.isHidden("booking", "予約", "カレンダー"), true);
  assert.equal(hider.isHidden("booking", "予約", "お名前"), false);
  assert.equal(hider.isHidden("doc-reader", "読み取り", "振込先"), false);
});

test("MCP_SHOW_UPDATER で更新者を出し、MCP_HIDE_COLUMNS の「テーブル.列」を落とす", () => {
  const hider = createHider({ hideColumns: ["顧客.電話", "予約.メール", "読み取り.振込先"], showUpdater: true });
  assert.equal(hider.isHidden("sheet-app", "顧客", "更新者"), false);
  assert.equal(hider.isHidden("sheet-app", "顧客", "電話", "電話"), true);
  assert.equal(hider.isHidden("sheet-app", "対応履歴", "電話", "電話"), false);
  assert.equal(hider.isHidden("booking", "予約", "メール"), true);
  assert.equal(hider.isHidden("doc-reader", "読み取り", "振込先"), true);
});
