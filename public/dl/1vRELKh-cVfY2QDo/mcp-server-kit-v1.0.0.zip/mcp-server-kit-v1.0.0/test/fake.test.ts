import { test } from "node:test";
import assert from "node:assert/strict";
import { FakeSheets, parseRange, userEntered } from "../src/google/fake.ts";
import { dateKeyToSerial } from "../src/core/values.ts";

test("USER_ENTERED の読み替え: ' を落とす・日付と日時はシリアル値・TRUE は真偽・数の文字は数", () => {
  assert.equal(userEntered("'045-000-0001"), "045-000-0001");
  assert.equal(userEntered("'=SUM(A1)"), "=SUM(A1)");
  assert.equal(userEntered("2026-09-16"), dateKeyToSerial("2026-09-16"));
  assert.equal(userEntered("2026-09-16 12:00"), dateKeyToSerial("2026-09-16") + 0.5);
  assert.equal(userEntered("TRUE"), true);
  assert.equal(userEntered("1200"), 1200);
  assert.equal(userEntered(false), false);
});

test("範囲の読み: シート全体・1 行・1 列・1 セル（' の入った名前も）", () => {
  assert.deepEqual(parseRange("'顧客'!A1:ZZ"), { sheet: "顧客", col1: 1, row1: 1, col2: 702, row2: null });
  assert.deepEqual(parseRange("'顧客'!A5:P5"), { sheet: "顧客", col1: 1, row1: 5, col2: 16, row2: 5 });
  assert.deepEqual(parseRange("'顧客'!A1:A"), { sheet: "顧客", col1: 1, row1: 1, col2: 1, row2: null });
  assert.deepEqual(parseRange("'Tom''s'!C7"), { sheet: "Tom's", col1: 3, row1: 7, col2: 3, row2: 7 });
});

test("読みは行末の空と末尾の空行を返さず、append は最後の行の次、update はセルだけ書く", async () => {
  const fake = new FakeSheets({ id1: { sheets: { 顧客: [["ID", "会社名", "メモ"], ["20260901-001", "うみかぜ商店", ""], ["", "", ""]] } } });
  assert.deepEqual(await fake.get("id1", "'顧客'!A1:ZZ"), [["ID", "会社名", "メモ"], ["20260901-001", "うみかぜ商店"]]);
  assert.equal(await fake.append("id1", "'顧客'!A1", ["'20260925-001", "'なぎさ食堂", ""]), 3);
  await fake.update("id1", [{ range: "'顧客'!C3", value: "'電話で連絡" }]);
  assert.deepEqual(fake.sheet("id1", "顧客")[2], ["20260925-001", "なぎさ食堂", "電話で連絡"]);
  assert.deepEqual(fake.calls.map((call) => call.method), ["get", "append", "update"]);
});
