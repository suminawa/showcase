import { test } from "node:test";
import assert from "node:assert/strict";
import {
  addDays,
  dateKeyToSerial,
  daysBetween,
  nowKey,
  readCell,
  readLooseDate,
  readSystemCell,
  readTime,
  serialToDateKey,
  serialToDateTimeKey,
  serialToStamp,
  todayKey,
  writeCell,
} from "../src/core/values.ts";
import { fromSheetValue, type Column } from "../src/vendor/sheet-app/index.js";

function column(type: Column["type"], extra: Partial<Column> = {}): Column {
  return { name: "列", type, required: false, options: [], inList: true, searchable: false, defaultValue: "", note: "", refTable: null, ...extra };
}

test("シリアル値 → 日付（1899-12-30 起点。1900 年の境とうるう年）", () => {
  assert.equal(serialToDateKey(0), "1899-12-30");
  assert.equal(serialToDateKey(61), "1900-03-01");
  assert.equal(serialToDateKey(dateKeyToSerial("2024-02-29")), "2024-02-29");
  assert.equal(serialToDateKey(dateKeyToSerial("2026-09-16")), "2026-09-16");
});

test("シリアル値 → 日時・時刻（0 時・23:59・秒の丸めで日をまたぐ）", () => {
  const day = dateKeyToSerial("2026-09-16");
  assert.equal(serialToDateTimeKey(day), "2026-09-16 00:00");
  assert.equal(serialToDateTimeKey(day + (23 * 60 + 59) / 1440), "2026-09-16 23:59");
  assert.equal(serialToStamp(day + (10 * 3600 + 32 * 60 + 5) / 86400), "2026-09-16 10:32:05");
  assert.equal(serialToStamp(day + 0.9999999), "2026-09-17 00:00:00");
});

test("日付の列: シリアル値も文字も YYYY-MM-DD に", () => {
  const date = column("日付");
  assert.equal(readCell(date, dateKeyToSerial("2026-06-01")), "2026-06-01");
  assert.equal(readCell(date, "2026/6/1"), "2026-06-01");
  assert.equal(readCell(date, ""), "");
});

test("日時の列: シリアル値の小数部を時分に", () => {
  assert.equal(readCell(column("日時"), dateKeyToSerial("2026-09-16") + 0.4375), "2026-09-16 10:30");
});

test("文字の列に数で来たら文字にする", () => {
  assert.equal(readCell(column("文字"), 12345), "12345");
  assert.equal(readCell(column("電話"), 450000001), "450000001");
});

test("数値・金額・チェック・複数選択", () => {
  assert.equal(readCell(column("金額"), 240000), 240000);
  assert.equal(readCell(column("数値"), ""), null);
  assert.equal(readCell(column("チェック"), true), true);
  assert.equal(readCell(column("チェック"), "FALSE"), false);
  assert.deepEqual(readCell(column("複数選択", { options: ["a", "b"] }), "a, b"), ["a", "b"]);
});

test("ツールの値の形が、業務アプリの fromSheetValue と同じ（シリアル値以外）", () => {
  for (const [type, raw] of [["文字", "うみかぜ商店"], ["金額", 1200], ["チェック", true], ["複数選択", "a, b"], ["日付", "2026-09-16"], ["選択", "見込み"]] as const) {
    const col = column(type, { options: ["a", "b", "見込み"] });
    assert.deepEqual(readCell(col, raw), fromSheetValue(col, raw), type);
  }
});

test("システム列: 文字はそのまま、シリアル値は秒まで", () => {
  assert.equal(readSystemCell("2026-09-01 10:00:00"), "2026-09-01 10:00:00");
  assert.equal(readSystemCell(dateKeyToSerial("2026-09-01") + 0.5), "2026-09-01 12:00:00");
  assert.equal(readSystemCell(null), "");
});

test("セルへの書き方: 文字は ' を付け、= で始まっても数式にならない。空と null は空", () => {
  assert.equal(writeCell(column("文字"), "うみかぜ商店"), "'うみかぜ商店");
  assert.equal(writeCell(column("長文"), "=SUM(A1)"), "'=SUM(A1)");
  assert.equal(writeCell(column("電話"), "045-000-0001"), "'045-000-0001");
  assert.equal(writeCell(column("文字"), ""), "");
  assert.equal(writeCell(column("金額"), null), "");
});

test("セルへの書き方: 日付・日時は文字のまま（Sheets が日付として読む）、数・真偽、複数選択は 'a, b", () => {
  assert.equal(writeCell(column("日付"), "2026-09-16"), "2026-09-16");
  assert.equal(writeCell(column("日時"), "2026-09-16 10:30"), "2026-09-16 10:30");
  assert.equal(writeCell(column("金額"), 1200), 1200);
  assert.equal(writeCell(column("チェック"), false), false);
  assert.equal(writeCell(column("複数選択"), ["a", "b"]), "'a, b");
});

test("予約の時刻: シリアル値の小数・10:00・10時・10時30分", () => {
  assert.equal(readTime(0.4166666667), "10:00");
  assert.equal(readTime("10:00"), "10:00");
  assert.equal(readTime("9時"), "09:00");
  assert.equal(readTime("10時30分"), "10:30");
  assert.equal(readTime("あとで"), "あとで");
});

test("人が手で入れた日付: シリアル値・2026/10/3・読めない文字", () => {
  assert.equal(readLooseDate(dateKeyToSerial("2026-10-03")), "2026-10-03");
  assert.equal(readLooseDate("2026/10/3"), "2026-10-03");
  assert.equal(readLooseDate("未定"), "未定");
});

test("今日・いまは Asia/Tokyo（UTC 15 時は翌日）", () => {
  const at = new Date(Date.UTC(2026, 8, 24, 15, 5));
  assert.equal(todayKey(at), "2026-09-25");
  assert.equal(nowKey(at), "2026-09-25 00:05");
});

test("日付の足し算と差", () => {
  assert.equal(addDays("2026-09-25", 30), "2026-10-25");
  assert.equal(addDays("2026-02-28", 1), "2026-03-01");
  assert.equal(daysBetween("2026-01-01", "2027-01-01"), 365);
});
