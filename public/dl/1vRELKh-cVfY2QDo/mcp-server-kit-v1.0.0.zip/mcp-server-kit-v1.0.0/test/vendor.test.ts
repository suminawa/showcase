import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";
// @ts-expect-error 型の無い .mjs（scripts は検査と release の道具）
import { VENDOR_FILES, VENDOR_DIR, hasSource, vendorDiff } from "../scripts/vendor-check.mjs";
import * as vendor from "../src/vendor/sheet-app/index.js";

const ROOT = fileURLToPath(new URL("..", import.meta.url));

/** src の下の .ts と .js（vendor の型の d.ts は除く） */
function sourceFiles(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir).sort()) {
    const path = join(dir, name);
    if (statSync(path).isDirectory()) out.push(...sourceFiles(path));
    else if (/\.(ts|js)$/.test(name) && !name.endsWith(".d.ts")) out.push(path);
  }
  return out;
}

test("写した 8 本が sheet-app-gas の src と 1 字も違わない（元が無い zip の中では飛ばす）", { skip: !hasSource() }, () => {
  assert.deepEqual(vendorDiff(), []);
});

test("このキットが使う関数がそろっている", () => {
  for (const name of ["parseDefinition", "validate", "fromSheetValue", "safeCell", "nextId", "laterId", "normalizeQuery", "filterRows", "sortRows", "toDateKey", "formatStamp", "isLineUserId"]) {
    assert.equal(typeof (vendor as Record<string, unknown>)[name], "function", name);
  }
  assert.equal(VENDOR_FILES.length, 8);
  assert.ok(VENDOR_DIR.endsWith("src/vendor/sheet-app"));
});

test("写しは GAS の大域に触れず、src は決まった場所でだけ時刻を読み、console.log を使わない", () => {
  for (const name of VENDOR_FILES) {
    const text = readFileSync(join(ROOT, "src/vendor/sheet-app", name), "utf8");
    assert.doesNotMatch(text, /\b(SpreadsheetApp|PropertiesService|LockService|UrlFetchApp|HtmlService|Session|Utilities|Logger|CacheService)\./, name);
  }
  for (const path of sourceFiles(join(ROOT, "src"))) {
    const rel = relative(ROOT, path);
    const text = readFileSync(path, "utf8");
    assert.doesNotMatch(text, /console\.log/, rel);
    const clockAllowed = rel.startsWith("src/server/") || rel.startsWith("src/google/") || rel === "src/cli.ts";
    if (!clockAllowed) assert.doesNotMatch(text, /new Date\(\)|Date\.now\(\)/, rel);
  }
});
