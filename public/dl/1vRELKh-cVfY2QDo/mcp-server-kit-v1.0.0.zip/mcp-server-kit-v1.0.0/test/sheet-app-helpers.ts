/** 業務アプリの元を、偽のシートの上で組む道具（*.test.ts ではない） */
import type { Vars } from "../src/core/env.ts";
import { createHider } from "../src/core/hide.ts";
import type { ToolDef } from "../src/core/tool.ts";
import type { FakeSheets } from "../src/google/fake.ts";
import { MetaCache } from "../src/google/sheets.ts";
import { SheetAppData, readTools, type SheetAppContext } from "../src/sources/sheet-app/read.ts";
import { NOW, SHEET_APP_ID, configOf } from "./fixtures.ts";

export function sheetAppContext(fake: FakeSheets, vars: Vars = {}): SheetAppContext {
  const config = configOf(vars);
  return { sheets: fake, meta: new MetaCache(fake), spreadsheetId: SHEET_APP_ID, config, hider: createHider(config) };
}

export async function sheetAppReadTools(fake: FakeSheets, vars: Vars = {}): Promise<ToolDef[]> {
  const data = new SheetAppData(sheetAppContext(fake, vars));
  return readTools(data, await data.definition(NOW.getTime()));
}
