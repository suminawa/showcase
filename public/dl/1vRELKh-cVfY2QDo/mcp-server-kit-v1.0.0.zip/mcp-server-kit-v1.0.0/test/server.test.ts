import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import { ToolListChangedNotificationSchema } from "@modelcontextprotocol/sdk/types.js";
import { boot, loadVars } from "../src/server/boot.ts";
import { INSTRUCTIONS, createServer } from "../src/server/create.ts";
import { DEMO_IDS } from "../src/server/demo.ts";
import type { FakeSheets } from "../src/google/fake.ts";

const KIT = fileURLToPath(new URL("..", import.meta.url));

async function bootDemo(vars: Record<string, string> = {}, clock = () => new Date(Date.UTC(2026, 8, 25, 5, 0))) {
  const lines: string[] = [];
  const booted = await boot({
    mode: "stdio",
    processEnv: { MCP_DEMO: "1", ...vars },
    kitDir: KIT,
    skipEnvFile: true,
    stderr: (line) => lines.push(line),
    fetch: async () => {
      throw new Error("見本では Google に出ない");
    },
    clock,
  });
  return { booted, lines };
}

async function connect(booted: NonNullable<Awaited<ReturnType<typeof bootDemo>>["booted"]>) {
  const [clientSide, serverSide] = InMemoryTransport.createLinkedPair();
  const server = createServer(booted.registry, { listChanged: true });
  await server.connect(serverSide);
  const client = new Client({ name: "test", version: "1.0.0" });
  await client.connect(clientSide);
  return client;
}

test("MCP_DEMO=1 で 3 つの見本が立ち上がり、鍵を読まない", async () => {
  const { booted, lines } = await bootDemo();
  assert.ok(booted);
  assert.deepEqual(booted.spreadsheets, DEMO_IDS);
  assert.deepEqual(lines, ["2026-09-25T05:00:00.000Z 起動しました（stdio・見本データ。元: 業務アプリ・予約ページ・書類読み取り。書き込み: なし）"]);
});

test("設定の誤りは stderr に並べて null（終了コード 1 にする）", async () => {
  const lines: string[] = [];
  const booted = await boot({ mode: "stdio", processEnv: {}, kitDir: KIT, skipEnvFile: true, stderr: (l) => lines.push(l), fetch: fetch, clock: () => new Date() });
  assert.equal(booted, null);
  assert.equal(lines.length, 2);
});

test("loadVars: skipEnvFile は kitDir の .env を読まない", () => {
  const tmp = mkdtempSync(join(tmpdir(), "mcp-envfile-"));
  try {
    writeFileSync(join(tmp, ".env"), "MCP_WRITE=true\n");
    const withoutSkip = loadVars({ processEnv: {}, kitDir: tmp });
    assert.equal(withoutSkip.vars.MCP_WRITE, "true");
    const withSkip = loadVars({ processEnv: {}, kitDir: tmp, skipEnvFile: true });
    assert.equal(withSkip.vars.MCP_WRITE, undefined);
    assert.equal(withSkip.error, null);
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test("kit フォルダの .env に MCP_WRITE=true があっても、skipEnvFile を付ければ demo に漏れない", async () => {
  const tmp = mkdtempSync(join(tmpdir(), "mcp-kitdir-"));
  try {
    symlinkSync(join(KIT, "samples"), join(tmp, "samples"), "junction");
    writeFileSync(join(tmp, ".env"), "MCP_WRITE=true\n");
    const booted = await boot({
      mode: "stdio",
      processEnv: { MCP_DEMO: "1" },
      kitDir: tmp,
      skipEnvFile: true,
      stderr: () => {},
      fetch: async () => {
        throw new Error("見本では Google に出ない");
      },
      clock: () => new Date(Date.UTC(2026, 8, 25, 5, 0)),
    });
    assert.ok(booted);
    assert.equal(booted!.config.write, false);
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});

test("initialize で instructions を返し、見本の顧客 20 件を search_rows で読める", async () => {
  const { booted } = await bootDemo();
  const client = await connect(booted!);
  assert.equal(client.getInstructions(), INSTRUCTIONS);
  const { tools } = await client.listTools();
  assert.deepEqual(tools.map((t) => t.name), ["list_tables", "describe_table", "search_rows", "get_row", "list_bookings", "get_booking", "list_documents", "get_document"]);
  const result = await client.callTool({ name: "search_rows", arguments: { table: "顧客", filters: [{ column: "状況", op: "eq", value: "見込み" }] } });
  assert.equal((result.structuredContent as { total: number }).total, 7);
  const all = await client.callTool({ name: "search_rows", arguments: { table: "顧客" } });
  assert.equal((all.structuredContent as { total: number }).total, 20);
  await client.close();
});

test("見本の予約は起動した日を基準に並び、書類読み取りは請求書 5 行", async () => {
  const { booted } = await bootDemo();
  const client = await connect(booted!);
  const bookings = await client.callTool({ name: "list_bookings", arguments: {} });
  assert.equal((bookings.structuredContent as { total: number }).total, 6);
  const docs = await client.callTool({ name: "list_documents", arguments: {} });
  assert.equal((docs.structuredContent as { total: number }).total, 5);
  await client.close();
});

test("定義が変わってツールの形が変わったら notifications/tools/list_changed を送る", async () => {
  let now = Date.UTC(2026, 8, 25, 5, 0);
  const { booted } = await bootDemo({ MCP_WRITE: "true" }, () => new Date(now));
  const client = await connect(booted!);
  let changed = 0;
  client.setNotificationHandler(ToolListChangedNotificationSchema, async () => {
    changed += 1;
  });
  await client.listTools();
  (booted!.sheets as FakeSheets).sheet(DEMO_IDS.sheetApp, "定義").push(["顧客", "紹介者", "文字", "", "", "", "", "", ""]);
  await client.callTool({ name: "list_tables", arguments: {} });
  assert.equal(changed, 0);
  now += 31000;
  await client.callTool({ name: "list_tables", arguments: {} });
  await new Promise((resolve) => setTimeout(resolve, 10));
  assert.equal(changed, 1);
  await client.close();
});
