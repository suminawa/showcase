import { test } from "node:test";
import assert from "node:assert/strict";
import { MAX_ROWS, WriteLimiter, pageOf } from "../src/core/limits.ts";

test("書き込みは 1 分に 20 回まで。21 回目は断り、1 分たつと戻る", () => {
  const limiter = new WriteLimiter();
  for (let i = 0; i < 20; i += 1) assert.equal(limiter.take(1000 + i), true);
  assert.equal(limiter.take(1030), false);
  assert.equal(limiter.take(1000 + 60000), true);
});

test("読みは 500 行まで。80,000 字を超えるなら後ろを落として truncated と next_offset", () => {
  const rows = Array.from({ length: 800 }, (_, i) => ({ i }));
  const page = pageOf(rows, 0, 9999, (r) => ({ rows: r }));
  assert.equal(page.count, MAX_ROWS);
  assert.equal(page.next_offset, 500);
  assert.equal(page.truncated, false);

  const long = Array.from({ length: 100 }, (_, i) => ({ i, text: "あ".repeat(3000) }));
  const cut = pageOf(long, 10, 50, (r) => ({ rows: r }));
  assert.equal(cut.truncated, true);
  assert.ok(cut.count < 50 && cut.count > 0);
  assert.equal(cut.next_offset, 10 + cut.count);
  assert.ok(JSON.stringify({ rows: cut.rows }).length <= 80000);
});

test("pageOf: 行ごとに増える添え物（labels など）も字数に数え、全体が上限を超えないところで切る", () => {
  const all = Array.from({ length: 10 }, (_, i) => ({ id: i }));
  const build = (rows: { id: number }[]) => ({ rows, labels: Object.fromEntries(rows.map((r) => [`k${r.id}`, "x".repeat(1000)])) });
  const page = pageOf(all, 0, 10, build, 5000);
  assert.ok(page.count > 0 && page.count < 10, String(page.count));
  assert.ok(JSON.stringify(build(page.rows)).length <= 5000);
  assert.equal(page.truncated, true);
  assert.equal(page.next_offset, page.count);
});
