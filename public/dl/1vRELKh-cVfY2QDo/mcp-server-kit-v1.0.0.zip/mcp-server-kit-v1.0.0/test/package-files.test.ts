import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
// @ts-expect-error 型の無い .mjs（scripts は release の道具）
import { RELEASE_GENERATED, createRelease, releaseFileList, releaseFolderName, releaseKeepName, releaseZipPath } from "../scripts/release.mjs";

const ROOT = fileURLToPath(new URL("..", import.meta.url));

/** OS の zip と unzip があるか（Windows には無いことが多い。zip を展開した買い手のフォルダでも dist があるので、この検査は動きうる） */
function hasCommand(name: string): boolean {
  try {
    execFileSync(name, ["-v"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}
const NO_ZIP_TOOLS = !hasCommand("zip") || !hasCommand("unzip");

test("zip の一覧: dist・src・samples・examples・README・LICENSE・NOTICES・.env.example・lock が入り、.env・鍵の JSON・node_modules は入らない", () => {
  const root = mkdtempSync(join(tmpdir(), "mcp-kit-release-"));
  try {
    const files = [
      ...RELEASE_GENERATED,
      "src/core/env.ts",
      "src/vendor/sheet-app/index.js",
      "samples/sheet-app/definition.csv",
      "examples/claude_desktop_config.json",
      "test/env.test.ts",
      "scripts/release.mjs",
      "README.ja.md",
      "LICENSE.md",
      "THIRD-PARTY-NOTICES.md",
      "CHANGELOG.md",
      "package.json",
      "package-lock.json",
      ".env.example",
      ".env",
      "src/.env.local",
      "service-account.json",
      "samples/my-project-key.json",
      "node_modules/zod/index.js",
      "src/.DS_Store",
    ];
    for (const file of files) {
      mkdirSync(dirname(join(root, file)), { recursive: true });
      writeFileSync(join(root, file), file === "package.json" ? JSON.stringify({ version: "1.0.0" }) : "x");
    }
    const listed: string[] = releaseFileList(root);
    for (const want of ["dist/stdio.js", "dist/http.js", "dist/cli.js", "src/core/env.ts", "samples/sheet-app/definition.csv", "examples/claude_desktop_config.json", "README.ja.md", "LICENSE.md", "THIRD-PARTY-NOTICES.md", ".env.example", "package-lock.json"]) {
      assert.ok(listed.includes(want), want);
    }
    for (const never of [".env", "src/.env.local", "service-account.json", "samples/my-project-key.json", "node_modules/zod/index.js", "src/.DS_Store"]) {
      assert.equal(listed.includes(never), false, never);
    }
    assert.equal(releaseFolderName(root), "mcp-server-kit-v1.0.0");
    // 日本語のファイル名は zip の中で文字化けする（Windows の展開）ので、実物の一覧はすべて英数の名前
    for (const file of releaseFileList(ROOT)) assert.match(file, /^[\x20-\x7e]+$/, file);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

/** release/ の zip が、いまの dist より後に作られたものか（npm run release は build → test → zip の順なので、test の時点の zip は 1 つ前の版の古いもの） */
function freshReleaseZip(): boolean {
  const zipPath = releaseZipPath(ROOT);
  if (!existsSync(zipPath)) return false;
  const zipTime = statSync(zipPath).mtimeMs;
  return RELEASE_GENERATED.every((relPath: string) => existsSync(join(ROOT, relPath)) && statSync(join(ROOT, relPath)).mtimeMs <= zipTime);
}

test("release 済みなら、zip の中身は一覧と同じで、すべて mcp-server-kit-v<版>/ の下（dist を作り直したあとの古い zip は飛ばす）", { skip: NO_ZIP_TOOLS || !freshReleaseZip() }, () => {
  const listed = execFileSync("unzip", ["-Z1", releaseZipPath(ROOT)], { encoding: "utf8" }).split("\n").filter((line) => line !== "");
  const folder = releaseFolderName(ROOT);
  assert.deepEqual(listed.sort(), releaseFileList(ROOT).map((file: string) => `${folder}/${file}`).sort());
  for (const entry of listed) {
    const name = entry.split("/").pop() as string;
    assert.ok(!name.startsWith(".env") || name === ".env.example", `zip に .env が入っています: ${entry}`);
    assert.match(entry, /^[\x20-\x7e]+$/, entry);
  }
});

test(
  "build をやり直さず、同じ dist から 2 回 zip を作ると、1 バイトも違わない（再現性）",
  { skip: NO_ZIP_TOOLS || RELEASE_GENERATED.some((relPath: string) => !existsSync(join(ROOT, relPath))) },
  () => {
    const outDir = mkdtempSync(join(tmpdir(), "mcp-kit-release-repro-"));
    try {
      const zipA = join(outDir, "a.zip");
      const zipB = join(outDir, "b.zip");
      const madeA = createRelease(ROOT, zipA);
      const madeB = createRelease(ROOT, zipB);
      assert.equal(madeB.bytes, madeA.bytes, "2 回目の zip の大きさが違います");
      assert.ok(readFileSync(zipB).equals(readFileSync(zipA)), "2 回目の zip の中身が 1 バイト以上違います");
    } finally {
      rmSync(outDir, { recursive: true, force: true });
    }
  },
);

test("releaseKeepName: Google の鍵の既定のファイル名（-<12桁の16進数>.json）を除く", () => {
  for (const name of ["my-project-1a2b3c4d5e6f.json", "sample-project-000000000000.json"]) {
    assert.equal(releaseKeepName(name), false, name);
  }
  for (const name of ["definition.csv", "customers.csv", "package.json"]) {
    assert.equal(releaseKeepName(name), true, name);
  }
});

test("Google の鍵の既定のファイル名がキット直下や samples に置かれても zip の一覧に入らない", () => {
  // 実物のキットのフォルダには書かない（ほかの検査が samples/ を同時に読むため）。一時のフォルダに同じ形を作る
  const root = mkdtempSync(join(tmpdir(), "mcp-kit-release-key-"));
  const keyName = "my-project-1a2b3c4d5e6f.json";
  try {
    for (const file of ["package.json", "samples/sheet-app/definition.csv", keyName, `samples/${keyName}`, `samples/sheet-app/${keyName}`]) {
      mkdirSync(dirname(join(root, file)), { recursive: true });
      writeFileSync(join(root, file), file === "package.json" ? JSON.stringify({ version: "1.0.0" }) : "x");
    }
    const listed: string[] = releaseFileList(root);
    assert.ok(listed.includes("samples/sheet-app/definition.csv"));
    for (const never of [keyName, `samples/${keyName}`, `samples/sheet-app/${keyName}`]) assert.equal(listed.includes(never), false, never);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
