import { test } from "node:test";
import assert from "node:assert/strict";
import { cellRange, columnLetter, columnRange, quoteSheet, rowOfRange, rowRange, sheetRange } from "../src/core/a1.ts";

test("シート名は ' で囲み、中の ' は '' にする", () => {
  assert.equal(quoteSheet("顧客"), "'顧客'");
  assert.equal(quoteSheet("Tom's list"), "'Tom''s list'");
  assert.equal(quoteSheet("対応 履歴"), "'対応 履歴'");
});

test("列の字（1・26・27・702・703）", () => {
  assert.deepEqual([1, 26, 27, 702, 703].map(columnLetter), ["A", "Z", "AA", "ZZ", "AAA"]);
});

test("シート全体・1 行・1 列・1 セルの範囲", () => {
  assert.equal(sheetRange("顧客"), "'顧客'!A1:ZZ");
  assert.equal(rowRange("顧客", 5, 16), "'顧客'!A5:P5");
  assert.equal(columnRange("顧客", 1), "'顧客'!A1:A");
  assert.equal(cellRange("顧客", 28, 3), "'顧客'!AB3");
});

test("append の updatedRange から行番号を取る", () => {
  assert.equal(rowOfRange("'顧客'!A22:P22"), 22);
  assert.equal(rowOfRange("'Tom''s'!C7"), 7);
  assert.equal(rowOfRange("broken"), null);
});

test("範囲の中の日本語のシート名はそのまま（URL の符号化は呼ぶ側）", () => {
  assert.equal(sheetRange("_ごみ箱"), "'_ごみ箱'!A1:ZZ");
});
