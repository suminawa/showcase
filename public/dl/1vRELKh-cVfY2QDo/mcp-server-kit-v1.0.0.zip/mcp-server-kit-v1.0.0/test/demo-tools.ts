/** 見本（MCP_DEMO=1・書き込みあり）で組んだツールの名前の一覧（docs.test が README と照らす）。*.test.ts ではない */
import { fileURLToPath } from "node:url";
import { boot } from "../src/server/boot.ts";

export async function bootDemoTools(): Promise<string[]> {
  const booted = await boot({
    mode: "stdio",
    processEnv: { MCP_DEMO: "1", MCP_WRITE: "true" },
    // 手元に .env があっても読まない（見本だけで組む）
    skipEnvFile: true,
    kitDir: fileURLToPath(new URL("..", import.meta.url)),
    stderr: () => {},
    fetch: async () => {
      throw new Error("見本では Google に出ない");
    },
    clock: () => new Date(Date.UTC(2026, 8, 25, 5, 0)),
  });
  if (booted === null) throw new Error("見本で起動できません");
  return (await booted.registry.list()).map((tool) => tool.name);
}
