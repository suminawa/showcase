import { test } from "node:test";
import assert from "node:assert/strict";
import { createVerify, generateKeyPairSync } from "node:crypto";
import { SCOPE_READ, SCOPE_WRITE, TokenSource, parseServiceAccount, scopeFor, signJwt, type FetchLike } from "../src/google/jwt.ts";
import { createHttpSheets, RETRY_WAITS } from "../src/google/sheets.ts";
import { ToolError } from "../src/core/errors.ts";

const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
const PEM = privateKey.export({ type: "pkcs8", format: "pem" }).toString();
const ACCOUNT = { client_email: "mcp@kit-test.iam.gserviceaccount.com", private_key: PEM, token_uri: "https://oauth2.googleapis.com/token" };
const ID = "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-ab";

function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

/** 応答を順に返す偽の fetch。呼ばれた URL と本文を控える */
function scriptedFetch(responses: (Response | Error)[]) {
  const calls: { url: string; init?: RequestInit }[] = [];
  const fetchFn: FetchLike = async (url, init) => {
    calls.push({ url, init });
    const next = responses.shift();
    if (next === undefined) throw new Error("応答の用意が足りません");
    if (next instanceof Error) throw next;
    return next;
  };
  return { fetchFn, calls };
}

function sheetsWith(responses: (Response | Error)[]) {
  const { fetchFn, calls } = scriptedFetch(responses);
  const waits: number[] = [];
  const sheets = createHttpSheets({
    token: async () => "access-token-value",
    fetch: fetchFn,
    sleep: async (ms) => {
      waits.push(ms);
    },
    clientEmail: ACCOUNT.client_email,
    envNames: { [ID]: "SHEET_APP_SPREADSHEET" },
  });
  return { sheets, calls, waits };
}

async function codeOf(promise: Promise<unknown>): Promise<string> {
  try {
    await promise;
  } catch (error) {
    assert.ok(error instanceof ToolError);
    return error.code;
  }
  return "ok";
}

test("JWT の見出し・中身・期限と、署名が検査用の鍵で確かめられる", () => {
  const jwt = signJwt(ACCOUNT, SCOPE_READ, 1_790_000_000);
  const [header, claims, signature] = jwt.split(".");
  assert.deepEqual(JSON.parse(Buffer.from(header, "base64url").toString()), { alg: "RS256", typ: "JWT" });
  assert.deepEqual(JSON.parse(Buffer.from(claims, "base64url").toString()), {
    iss: ACCOUNT.client_email,
    scope: SCOPE_READ,
    aud: ACCOUNT.token_uri,
    iat: 1_790_000_000,
    exp: 1_790_003_600,
  });
  const verifier = createVerify("RSA-SHA256");
  verifier.update(`${header}.${claims}`);
  assert.equal(verifier.verify(publicKey, Buffer.from(signature, "base64url")), true);
});

test("鍵の JSON はそのままでも base64 でも読み、欠けていれば null", () => {
  const json = JSON.stringify({ ...ACCOUNT, token_uri: undefined });
  assert.equal(parseServiceAccount(json)?.token_uri, "https://oauth2.googleapis.com/token");
  assert.equal(parseServiceAccount(Buffer.from(json).toString("base64"))?.client_email, ACCOUNT.client_email);
  assert.equal(parseServiceAccount(JSON.stringify({ client_email: "x" })), null);
  assert.equal(parseServiceAccount("not json"), null);
});

test("トークンは使い回し、期限の 5 分前を過ぎたら取り直す。書かない設定では readonly の scope", async () => {
  assert.equal(scopeFor(false), SCOPE_READ);
  assert.equal(scopeFor(true), SCOPE_WRITE);
  let now = 1_790_000_000_000;
  const { fetchFn, calls } = scriptedFetch([jsonResponse(200, { access_token: "t1", expires_in: 3600 }), jsonResponse(200, { access_token: "t2", expires_in: 3600 })]);
  const source = new TokenSource(ACCOUNT, scopeFor(false), fetchFn, () => now);
  assert.equal(await source.token(), "t1");
  now += 3000 * 1000;
  assert.equal(await source.token(), "t1");
  now += 301 * 1000;
  assert.equal(await source.token(), "t2");
  assert.equal(calls.length, 2);
  const assertion = new URLSearchParams(String(calls[0].init?.body)).get("assertion") ?? "";
  assert.equal(JSON.parse(Buffer.from(assertion.split(".")[1], "base64url").toString()).scope, SCOPE_READ);
});

test("トークンの取得で 400 なら auth_failed（鍵の削除・時計のずれ）", async () => {
  const { fetchFn } = scriptedFetch([jsonResponse(400, { error: "invalid_grant" })]);
  assert.equal(await codeOf(new TokenSource(ACCOUNT, SCOPE_READ, fetchFn).token()), "auth_failed");
});

test("403・404・429・5xx を敬体の code に言い換える", async () => {
  assert.equal(await codeOf(sheetsWith([jsonResponse(403, {})]).sheets.get(ID, "'顧客'!A1:ZZ")), "no_access");
  assert.equal(await codeOf(sheetsWith([jsonResponse(404, {})]).sheets.meta(ID)), "spreadsheet_not_found");
  assert.equal(await codeOf(sheetsWith([jsonResponse(403, {})]).sheets.update(ID, [{ range: "'顧客'!B2", value: "'x" }])), "read_only_share");
  const busy = sheetsWith([jsonResponse(429, {}), jsonResponse(429, {}), jsonResponse(429, {})]);
  assert.equal(await codeOf(busy.sheets.get(ID, "'顧客'!A1:ZZ")), "rate_limited");
  assert.deepEqual(busy.waits, RETRY_WAITS);
  const down = sheetsWith([jsonResponse(503, {}), jsonResponse(503, {}), jsonResponse(503, {})]);
  assert.equal(await codeOf(down.sheets.get(ID, "'顧客'!A1:ZZ")), "unavailable");
});

test("読みは 5xx を 2 回まで再試行して、3 回目で読めれば値を返す", async () => {
  const { sheets, calls, waits } = sheetsWith([jsonResponse(502, {}), jsonResponse(500, {}), jsonResponse(200, { values: [["ID"]] })]);
  assert.deepEqual(await sheets.get(ID, "'顧客'!A1:ZZ"), [["ID"]]);
  assert.equal(calls.length, 3);
  assert.deepEqual(waits, [1000, 3000]);
  assert.ok(calls[0].url.includes("valueRenderOption=UNFORMATTED_VALUE&dateTimeRenderOption=SERIAL_NUMBER"));
  assert.ok(calls[0].url.includes(encodeURIComponent("'顧客'!A1:ZZ")));
});

test("書き込みは 429 だけ再試行し、5xx は再試行せずに write_unknown", async () => {
  const limited = sheetsWith([jsonResponse(429, {}), jsonResponse(200, { updates: { updatedRange: "'顧客'!A22:P22" } })]);
  assert.equal(await limited.sheets.append(ID, "'顧客'!A1", ["'x"]), 22);
  assert.equal(limited.calls.length, 2);
  assert.ok(limited.calls[1].url.includes("valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS"));
  const broken = sheetsWith([jsonResponse(503, {})]);
  assert.equal(await codeOf(broken.sheets.append(ID, "'顧客'!A1", ["'x"])), "write_unknown");
  assert.equal(broken.calls.length, 1);
  const timeout = Object.assign(new Error("timeout"), { name: "TimeoutError" });
  assert.equal(await codeOf(sheetsWith([timeout]).sheets.update(ID, [{ range: "'顧客'!B2", value: 1 }])), "write_unknown");
});

test("誤りの文に鍵・トークン・範囲の中身が入らない", async () => {
  const { sheets } = sheetsWith([jsonResponse(403, { error: { message: "raw google message" } })]);
  try {
    await sheets.get(ID, "'顧客'!A1:ZZ");
    assert.fail("投げるはず");
  } catch (error) {
    const text = (error as Error).message;
    for (const secret of ["access-token-value", "PRIVATE KEY", "raw google message", ID]) assert.equal(text.includes(secret), false, secret);
    assert.ok(text.includes(ACCOUNT.client_email));
  }
});

test("403 の本文が API の無効を示すなら api_disabled、ふつうの 403 は no_access", async () => {
  const disabled = {
    error: {
      code: 403,
      message: "Google Sheets API has not been used in project 123 before or it is disabled.",
      status: "PERMISSION_DENIED",
      details: [{ reason: "SERVICE_DISABLED" }],
    },
  };
  assert.equal(await codeOf(sheetsWith([jsonResponse(403, disabled)]).sheets.meta(ID)), "api_disabled");
  assert.equal(await codeOf(sheetsWith([jsonResponse(403, { error: { errors: [{ reason: "accessNotConfigured" }] } })]).sheets.get(ID, "'顧客'!A1:ZZ")), "api_disabled");
  assert.equal(await codeOf(sheetsWith([jsonResponse(403, disabled)]).sheets.update(ID, [{ range: "'顧客'!B2", value: "'x" }])), "api_disabled");
  assert.equal(await codeOf(sheetsWith([jsonResponse(403, { error: { status: "PERMISSION_DENIED" } })]).sheets.meta(ID)), "no_access");
  try {
    await sheetsWith([jsonResponse(403, disabled)]).sheets.meta(ID);
    assert.fail("投げるはず");
  } catch (error) {
    const text = (error as Error).message;
    assert.ok(text.includes("Google Sheets API が有効になっていません"));
    assert.equal(text.includes("project 123"), false);
  }
});

test("壊れた秘密鍵（PEM の中身が崩れている）は parseServiceAccount が null を返す", () => {
  const broken = PEM.replace(/\n[A-Za-z0-9+/]{20}/, "\n!!!!broken!!!!");
  assert.equal(parseServiceAccount(JSON.stringify({ ...ACCOUNT, private_key: broken })), null);
  assert.equal(parseServiceAccount(JSON.stringify({ ...ACCOUNT, private_key: "-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----\n" })), null);
  assert.equal(parseServiceAccount(JSON.stringify(ACCOUNT))?.client_email, ACCOUNT.client_email);
});

test("トークンの取得がふつうの例外で落ちたら auth_failed（unavailable にしない）", async () => {
  const { fetchFn, calls } = scriptedFetch([]);
  const sheets = createHttpSheets({
    token: async () => {
      throw new Error("error:1E08010C:DECODER routines::unsupported");
    },
    fetch: fetchFn,
    sleep: async () => {},
    clientEmail: ACCOUNT.client_email,
    envNames: { [ID]: "SHEET_APP_SPREADSHEET" },
  });
  assert.equal(await codeOf(sheets.meta(ID)), "auth_failed");
  assert.equal(calls.length, 0);
  const passthrough = createHttpSheets({
    token: async () => {
      throw new ToolError("unavailable", "x");
    },
    fetch: fetchFn,
    sleep: async () => {},
    clientEmail: ACCOUNT.client_email,
    envNames: {},
  });
  assert.equal(await codeOf(passthrough.meta(ID)), "unavailable");
});
