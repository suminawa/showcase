import { test } from "node:test";
import assert from "node:assert/strict";
import { checkArgs } from "../src/core/args.ts";
import { createHider } from "../src/core/hide.ts";
import { MAX_WRITABLE_TABLES, addRowTool, buildSpecs, columnSchema, hashSuffix, updateRowTool } from "../src/sources/sheet-app/schema.ts";
import { checkValue, parseDefinition, type Column } from "../src/vendor/sheet-app/index.js";
import { DEFINITION_ROWS, HIDER, definitionTables } from "./fixtures.ts";

function col(type: Column["type"], extra: Partial<Column> = {}): Column {
  return { name: "列", type, required: true, options: ["見込み", "取引中"], inList: true, searchable: false, defaultValue: "", note: "", refTable: "顧客", ...extra };
}

const specsOf = (options: Partial<Parameters<typeof buildSpecs>[1]> = {}) =>
  buildSpecs(definitionTables(), { only: [], aliases: {}, hider: HIDER, write: true, ...options });

test("文字・長文・数値・金額の schema", () => {
  assert.deepEqual(columnSchema(col("文字")), { type: "string", maxLength: 200, title: "列" });
  assert.deepEqual(columnSchema(col("長文")), { type: "string", maxLength: 5000, title: "列" });
  assert.deepEqual(columnSchema(col("数値")), { type: "number", title: "列" });
  assert.deepEqual(columnSchema(col("金額", { note: "見込みは空" })), { type: "integer", title: "列", description: "見込みは空。円。整数" });
});

test("日付・日時の schema と説明", () => {
  assert.deepEqual(columnSchema(col("日付")), { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$", title: "列", description: "YYYY-MM-DD" });
  assert.equal(columnSchema(col("日時")).description, "YYYY-MM-DD HH:mm（日本時間）");
  assert.equal(columnSchema(col("日付", { defaultValue: "今日" })).description, "YYYY-MM-DD。空なら登録した日");
  assert.equal(columnSchema(col("日付", { defaultValue: "今日" })).default, undefined);
});

test("選択 → enum、複数選択 → 配列の enum と uniqueItems、チェック → boolean", () => {
  assert.deepEqual(columnSchema(col("選択")), { type: "string", enum: ["見込み", "取引中"], title: "列" });
  assert.deepEqual(columnSchema(col("複数選択")), { type: "array", items: { type: "string", enum: ["見込み", "取引中"] }, uniqueItems: true, title: "列" });
  assert.deepEqual(columnSchema(col("チェック")), { type: "boolean", title: "列" });
});

test("メール・電話・URL・参照の schema と説明", () => {
  assert.equal(columnSchema(col("メール")).description, "メールアドレス");
  assert.equal(columnSchema(col("電話")).pattern, "^[0-9+\\-() ０-９－]+$");
  assert.equal(columnSchema(col("URL")).pattern, "^https?://");
  const ref = columnSchema(col("参照"));
  assert.equal(ref.pattern, "^\\d{8}-\\d{3,}$");
  assert.equal(ref.description, "「顧客」テーブルの ID。search_rows(table: \"顧客\") で探してください");
});

test("必須でない列は null も受け、既定値は型に合わせて default に入れる", () => {
  const optional = columnSchema(col("選択", { required: false, defaultValue: "見込み" }));
  assert.deepEqual(optional.anyOf, [{ type: "string", enum: ["見込み", "取引中"] }, { type: "null" }]);
  assert.equal(optional.default, "見込み");
  assert.equal(columnSchema(col("チェック", { defaultValue: "TRUE" })).default, true);
  assert.equal(columnSchema(col("金額", { defaultValue: "1000" })).default, 1000);
});

test("add_row: 必須の列（チェックと既定値のある列を除く）が required、LINE 型の列は出さない", () => {
  const { specs } = specsOf();
  const add = addRowTool(specs[0]);
  assert.equal(add.name, `add_row_${hashSuffix("顧客")}`);
  assert.equal(add.title, "顧客を登録");
  const values = add.inputSchema.properties?.values;
  assert.deepEqual(values?.required, ["会社名"]);
  assert.equal(Object.keys(values?.properties ?? {}).includes("LINE"), false);
  assert.equal(Object.keys(values?.properties ?? {}).length, 11);
  assert.deepEqual(add.annotations, { readOnlyHint: false, destructiveHint: false, openWorldHint: false });
  assert.match(add.description, /登録の前に、登録する内容を利用者に確かめてください。/);
  assert.deepEqual(addRowTool(specs[1]).inputSchema.properties?.values?.required, ["顧客", "内容"]);
});

test("update_row: 全部の列が任意で minProperties 1、expected_updated_at を受ける", () => {
  const { specs } = specsOf();
  const update = updateRowTool(specs[1]);
  assert.equal(update.title, "対応履歴を更新");
  assert.deepEqual(update.inputSchema.required, ["id", "values"]);
  assert.equal(update.inputSchema.properties?.values?.minProperties, 1);
  assert.equal(update.inputSchema.properties?.values?.required, undefined);
  assert.ok(update.inputSchema.properties?.expected_updated_at);
  assert.equal(update.annotations.destructiveHint, true);
});

test("見せない列（MCP_HIDE_COLUMNS）は schema に出さない", () => {
  const hider = createHider({ hideColumns: ["顧客.電話"], showUpdater: false });
  const { specs } = specsOf({ hider });
  assert.equal(Object.keys(addRowTool(specs[0]).inputSchema.properties?.values?.properties ?? {}).includes("電話"), false);
});

test("suffix: 別名があれば別名、英字の名前はそのまま、日本語は t + ハッシュ 6 桁（安定）", () => {
  const { specs } = specsOf({ aliases: { 顧客: "customers" } });
  assert.deepEqual(specs.map((s) => s.suffix), ["customers", hashSuffix("対応履歴")]);
  assert.match(hashSuffix("対応履歴"), /^t[0-9a-f]{6}$/);
  assert.equal(hashSuffix("対応履歴"), hashSuffix("対応履歴"));
  const english = parseDefinition([DEFINITION_ROWS[0], ["orders", "name", "文字"]]).tables;
  assert.equal(buildSpecs(english, { only: [], aliases: {}, hider: HIDER, write: true }).specs[0].suffix, "orders");
});

test("ツール名は 64 字以内で ^[a-z0-9_]+$", () => {
  const { specs } = specsOf({ aliases: { 顧客: "c".repeat(40) } });
  for (const spec of specs) {
    for (const tool of [addRowTool(spec), updateRowTool(spec)]) assert.match(tool.name, /^[a-z0-9_]{1,64}$/);
  }
});

test("形の違う別名・重なった別名は捨ててハッシュに戻し、誤りに書く", () => {
  const bad = specsOf({ aliases: { 顧客: "Customers!" } });
  assert.equal(bad.specs[0].suffix, hashSuffix("顧客"));
  assert.match(bad.errors[0], /^MCP_TABLE_ALIASES の「顧客」の別名は、英小文字・数字・_ の 40 字以内にしてください。/);
  const dup = specsOf({ aliases: { 顧客: "same", 対応履歴: "same" } });
  assert.deepEqual(dup.specs.map((s) => s.suffix), [hashSuffix("顧客"), hashSuffix("対応履歴")]);
  assert.equal(dup.errors.length, 1);
});

test("MCP_TABLES で絞る。定義に無い名前は誤りに書く", () => {
  const { specs, errors } = specsOf({ only: ["対応履歴", "案件"] });
  assert.deepEqual(specs.map((s) => s.table.name), ["対応履歴"]);
  assert.deepEqual(errors, ["MCP_TABLES のテーブル「案件」は定義にありません。"]);
});

test("MCP_WRITE=false なら書けるテーブルは無い", () => {
  assert.deepEqual(specsOf({ write: false }).specs.map((s) => s.writable), [false, false]);
});

test("21 個目のテーブルからは書くツールを作らない", () => {
  const rows = [DEFINITION_ROWS[0], ...Array.from({ length: 22 }, (_, i) => [`表${i + 1}`, "名前", "文字"])];
  const { specs, errors } = buildSpecs(parseDefinition(rows).tables, { only: [], aliases: {}, hider: HIDER, write: true });
  assert.equal(specs.filter((s) => s.writable).length, MAX_WRITABLE_TABLES);
  assert.equal(specs[20].writable, false);
  assert.deepEqual(errors, ["テーブルが 20 を超えたため、21 個目から書くツールを作っていません。MCP_TABLES で絞ってください。"]);
});

test("schema の pattern と validate() が、同じ値の表で同じ判定をする", () => {
  const table: [Column["type"], unknown, boolean][] = [
    ["日付", "2026-09-16", true],
    ["日付", "来週", false],
    ["日時", "2026-09-16 10:30", true],
    ["日時", "2026-09-16", false],
    ["電話", "045-000-0001", true],
    ["電話", "０４５－０００－０００１", true],
    ["電話", "お電話ください", false],
    ["URL", "https://example.com/a", true],
    ["URL", "ftp://example.com", false],
    ["金額", 1200, true],
    ["金額", 12.5, false],
    ["数値", "たくさん", false],
    ["選択", "見込み", true],
    ["選択", "不明", false],
  ];
  for (const [type, value, ok] of table) {
    const column = col(type);
    assert.equal(checkArgs(columnSchema(column), value).length === 0, ok, `schema ${type} ${String(value)}`);
    assert.equal(checkValue(column, value).error === "", ok, `validate ${type} ${String(value)}`);
  }
});

test("参照の列は ID の形だけを通す（validate より狭い。AI には ID を渡してもらう）", () => {
  const ref = columnSchema(col("参照"));
  assert.equal(checkArgs(ref, "20260901-001").length, 0);
  assert.equal(checkArgs(ref, "うみかぜ商店").length, 1);
});
