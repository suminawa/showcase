import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { createMcpExpressApp } from "@modelcontextprotocol/sdk/server/express.js";
import { getOAuthProtectedResourceMetadataUrl, mcpAuthRouter } from "@modelcontextprotocol/sdk/server/auth/router.js";
import { requireBearerAuth } from "@modelcontextprotocol/sdk/server/auth/middleware/bearerAuth.js";
import { InvalidGrantError, InvalidTokenError } from "@modelcontextprotocol/sdk/server/auth/errors.js";
import type { OAuthServerProvider } from "@modelcontextprotocol/sdk/server/auth/provider.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

test("SDK 1.30.1 の import 先と名前がそろっている", () => {
  const sdk = JSON.parse(readFileSync(new URL("../node_modules/@modelcontextprotocol/sdk/package.json", import.meta.url), "utf8")) as { version: string };
  assert.equal(sdk.version, "1.30.1");
  for (const value of [Server, StdioServerTransport, StreamableHTTPServerTransport, createMcpExpressApp, mcpAuthRouter, requireBearerAuth, getOAuthProtectedResourceMetadataUrl, InvalidGrantError, InvalidTokenError]) {
    assert.equal(typeof value, "function");
  }
  assert.ok(CallToolRequestSchema && ListToolsRequestSchema);
  const methods: (keyof OAuthServerProvider)[] = ["authorize", "challengeForAuthorizationCode", "exchangeAuthorizationCode", "exchangeRefreshToken", "verifyAccessToken", "revokeToken"];
  assert.equal(methods.length, 6);
  assert.equal(getOAuthProtectedResourceMetadataUrl(new URL("https://mcp.example.com/mcp")), "https://mcp.example.com/.well-known/oauth-protected-resource/mcp");
});
