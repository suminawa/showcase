import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { request as httpRequest, type Server as HttpServer } from "node:http";
import type { AddressInfo } from "node:net";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { readConfig } from "../src/core/env.ts";
import { WriteLimiter } from "../src/core/limits.ts";
import { createLogger } from "../src/core/log.ts";
import { createHttpApp, listenFailure } from "../src/server/http.ts";
import { Registry } from "../src/server/registry.ts";
import { sheetAppSource } from "../src/sources/sheet-app/source.ts";
import { sheetAppFake } from "./fixtures.ts";
import { sheetAppContext } from "./sheet-app-helpers.ts";

const TOKEN = "t".repeat(20) + "-fixed-secret-for-tests-0123";
const PUBLIC = "https://mcp.example.com";
const REDIRECT = "https://chat.example.com/connector/oauth/callback";

async function start(vars: Record<string, string> = {}, clock = () => new Date()) {
  const { config } = readConfig({ MCP_DEMO: "1", MCP_HTTP_TOKEN: TOKEN, ...vars }, "http");
  const lines: string[] = [];
  const logger = createLogger("info", (line) => lines.push(line), clock);
  const registry = new Registry({ sources: [sheetAppSource(sheetAppContext(sheetAppFake()))], limiter: new WriteLimiter(), logger, clock });
  const { app, oauth } = createHttpApp({ registry, config, logger, clock });
  const server: HttpServer = await new Promise((resolve) => {
    const s = app.listen(0, "127.0.0.1", () => resolve(s));
  });
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return { base, lines, oauth, close: () => new Promise<void>((resolve) => server.close(() => resolve())) };
}

async function listTools(base: string, bearer: string): Promise<string[]> {
  const client = new Client({ name: "http-test", version: "1.0.0" });
  await client.connect(new StreamableHTTPClientTransport(new URL(`${base}/mcp`), { requestInit: { headers: { Authorization: `Bearer ${bearer}` } } }));
  try {
    return (await client.listTools()).tools.map((t) => t.name);
  } finally {
    await client.close();
  }
}

function rpc(base: string, headers: Record<string, string> = {}): Promise<Response> {
  return fetch(`${base}/mcp`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json, text/event-stream", ...headers },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/list", params: {} }),
  });
}

/** node:http で Host を書き換えて送る（fetch は Host を変えられない） */
function withHost(base: string, host: string): Promise<number> {
  const url = new URL(`${base}/healthz`);
  return new Promise((resolve, reject) => {
    const req = httpRequest({ hostname: url.hostname, port: url.port, path: url.pathname, headers: { host } }, (res) => {
      res.resume();
      resolve(res.statusCode ?? 0);
    });
    req.on("error", reject);
    req.end();
  });
}

/** 登録 → 認可の画面 → ログイン → code を受け取るまで */
async function authorize(base: string, password = TOKEN) {
  const registered = await fetch(`${base}/register`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ redirect_uris: [REDIRECT], client_name: "ChatGPT", token_endpoint_auth_method: "none" }),
  });
  assert.equal(registered.status, 201);
  const clientId = ((await registered.json()) as { client_id: string }).client_id;
  const verifier = randomBytes(32).toString("base64url");
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  const query = new URLSearchParams({ response_type: "code", client_id: clientId, redirect_uri: REDIRECT, code_challenge: challenge, code_challenge_method: "S256", state: "st-1" });
  const page = await fetch(`${base}/authorize?${query}`);
  const html = await page.text();
  const request = /name="request" value="([^"]+)"/.exec(html)?.[1] ?? "";
  const login = await fetch(`${base}/login`, { method: "POST", redirect: "manual", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ request, password }) });
  return { clientId, verifier, page, html, login };
}

async function exchange(base: string, clientId: string, code: string, verifier: string): Promise<Response> {
  return fetch(`${base}/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "authorization_code", code, code_verifier: verifier, client_id: clientId, redirect_uri: REDIRECT }),
  });
}

test("鍵なし・違う鍵は 401（WWW-Authenticate: Bearer）、固定の合い言葉なら tools/list", async () => {
  const app = await start();
  try {
    const none = await rpc(app.base);
    assert.equal(none.status, 401);
    assert.match(none.headers.get("www-authenticate") ?? "", /^Bearer /);
    assert.equal((await rpc(app.base, { authorization: "Bearer wrong" })).status, 401);
    assert.ok((await listTools(app.base, TOKEN)).includes("search_rows"));
  } finally {
    await app.close();
  }
});

test("Host ヘッダーが localhost・127.0.0.1・MCP_PUBLIC_URL のホスト以外なら 403", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    assert.equal(await withHost(app.base, "evil.example.net"), 403);
    assert.equal(await withHost(app.base, "mcp.example.com"), 200);
    assert.equal(await withHost(app.base, "localhost:8787"), 200);
  } finally {
    await app.close();
  }
});

test("CORS の見出しを返さず、OPTIONS・GET /mcp は 405。/healthz は ok だけ", async () => {
  const app = await start();
  try {
    const res = await rpc(app.base, { authorization: `Bearer ${TOKEN}`, origin: "https://evil.example.net" });
    assert.equal(res.status, 200);
    assert.equal([...res.headers.keys()].some((name) => name.startsWith("access-control-")), false);
    assert.equal((await fetch(`${app.base}/mcp`, { method: "OPTIONS" })).status, 405);
    assert.equal((await fetch(`${app.base}/mcp`, { headers: { authorization: `Bearer ${TOKEN}` } })).status, 405);
    assert.equal(await (await fetch(`${app.base}/healthz`)).text(), "ok");
  } finally {
    await app.close();
  }
});

test("MCP_PUBLIC_URL が無ければ OAuth の道は無い", async () => {
  const app = await start();
  try {
    assert.equal((await fetch(`${app.base}/.well-known/oauth-authorization-server`)).status, 404);
    assert.equal((await fetch(`${app.base}/register`, { method: "POST" })).status, 404);
  } finally {
    await app.close();
  }
});

test("MCP_PUBLIC_URL があれば、401 に resource_metadata を添え、メタデータを出す。戻り先は https か localhost だけ", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    assert.match((await rpc(app.base)).headers.get("www-authenticate") ?? "", /resource_metadata="https:\/\/mcp\.example\.com\/\.well-known\/oauth-protected-resource\/mcp"/);
    const meta = (await (await fetch(`${app.base}/.well-known/oauth-authorization-server`)).json()) as Record<string, unknown>;
    assert.equal(meta.issuer, `${PUBLIC}/`);
    assert.deepEqual(meta.code_challenge_methods_supported, ["S256"]);
    const resource = (await (await fetch(`${app.base}/.well-known/oauth-protected-resource/mcp`)).json()) as Record<string, unknown>;
    assert.equal(resource.resource, `${PUBLIC}/mcp`);
    const plainHttp = await fetch(`${app.base}/register`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ redirect_uris: ["http://evil.example.net/cb"], client_name: "x", token_endpoint_auth_method: "none" }),
    });
    assert.equal(plainHttp.status, 400);
  } finally {
    await app.close();
  }
});

test("ログインの画面は敬体で、CSP を付け、合い言葉が合えば code を付けて戻り先へ 302", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const { page, html, login } = await authorize(app.base);
    assert.equal(page.status, 200);
    assert.match(page.headers.get("content-security-policy") ?? "", /default-src 'none'; style-src 'unsafe-inline'; form-action 'self' https:\/\/chat\.example\.com; frame-ancestors 'none'/);
    assert.ok(html.includes("この戻り先のアプリが、このサーバーのツールを使えるようにしようとしています。"));
    assert.ok(html.includes('type="password"'));
    assert.equal(login.status, 302);
    const location = new URL(login.headers.get("location") ?? "");
    assert.equal(location.origin + location.pathname, REDIRECT);
    assert.equal(location.searchParams.get("state"), "st-1");
    assert.ok((location.searchParams.get("code") ?? "").length > 20);
  } finally {
    await app.close();
  }
});

test("code は PKCE を照らして 1 回だけ鍵に換えられ、その鍵で tools/list を呼べる", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const { clientId, verifier, login } = await authorize(app.base);
    const code = new URL(login.headers.get("location") ?? "").searchParams.get("code") ?? "";
    assert.equal((await exchange(app.base, clientId, code, "wrong-verifier-wrong-verifier-wrong-verifier")).status, 400);
    const ok = await exchange(app.base, clientId, code, verifier);
    assert.equal(ok.status, 200);
    const tokens = (await ok.json()) as { access_token: string; refresh_token: string; expires_in: number };
    assert.equal(tokens.expires_in, 3600);
    assert.ok((await listTools(app.base, tokens.access_token)).includes("list_tables"));
    assert.equal((await exchange(app.base, clientId, code, verifier)).status, 400);
  } finally {
    await app.close();
  }
});

test("合い言葉が違えば同じ画面で知らせ、10 分に 5 回を超えたら正しくても断る", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    for (let i = 0; i < 5; i += 1) {
      const { login } = await authorize(app.base, "wrong");
      assert.equal(login.status, 401);
      assert.ok((await login.text()).includes("合い言葉が違います。"));
    }
    const { login } = await authorize(app.base);
    assert.equal(login.status, 429);
    assert.ok((await login.text()).includes("しばらく置いてからお試しください。"));
  } finally {
    await app.close();
  }
});

test("アクセス鍵は 1 時間で切れる", async () => {
  // SDK の requireBearerAuth は本物の時計でも期限を見るので、いまの時刻から始める
  let now = Date.now();
  const app = await start({ MCP_PUBLIC_URL: PUBLIC }, () => new Date(now));
  try {
    const { clientId, verifier, login } = await authorize(app.base);
    const code = new URL(login.headers.get("location") ?? "").searchParams.get("code") ?? "";
    const { access_token } = (await (await exchange(app.base, clientId, code, verifier)).json()) as { access_token: string };
    assert.equal((await rpc(app.base, { authorization: `Bearer ${access_token}` })).status, 200);
    now += 3601 * 1000;
    assert.equal((await rpc(app.base, { authorization: `Bearer ${access_token}` })).status, 401);
  } finally {
    await app.close();
  }
});

test("合い言葉を変えると、前に出した鍵はすべて 401", async () => {
  const first = await start({ MCP_PUBLIC_URL: PUBLIC });
  let access = "";
  try {
    const { clientId, verifier, login } = await authorize(first.base);
    const code = new URL(login.headers.get("location") ?? "").searchParams.get("code") ?? "";
    access = ((await (await exchange(first.base, clientId, code, verifier)).json()) as { access_token: string }).access_token;
  } finally {
    await first.close();
  }
  const second = await start({ MCP_PUBLIC_URL: PUBLIC, MCP_HTTP_TOKEN: "n".repeat(40) });
  try {
    assert.equal((await rpc(second.base, { authorization: `Bearer ${access}` })).status, 401);
    assert.equal((await rpc(second.base, { authorization: `Bearer ${TOKEN}` })).status, 401);
  } finally {
    await second.close();
  }
});

test("HTTP のログに Authorization・code・合い言葉を書かない", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    await authorize(app.base);
    await rpc(app.base, { authorization: `Bearer ${TOKEN}` });
    const text = app.lines.join("\n");
    assert.equal(text.includes(TOKEN), false);
    assert.equal(text.includes("code="), false);
  } finally {
    await app.close();
  }
});

/** 登録して認可の画面を開き、ログインの画面に埋まった request の札を返す */
async function loginRequest(base: string, redirect = REDIRECT): Promise<string> {
  const registered = await fetch(`${base}/register`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ redirect_uris: [redirect], client_name: "ChatGPT", token_endpoint_auth_method: "none" }),
  });
  const clientId = ((await registered.json()) as { client_id: string }).client_id;
  const challenge = createHash("sha256").update(randomBytes(32).toString("base64url")).digest("base64url");
  const query = new URLSearchParams({ response_type: "code", client_id: clientId, redirect_uri: redirect, code_challenge: challenge, code_challenge_method: "S256" });
  const html = await (await fetch(`${base}/authorize?${query}`)).text();
  return /name="request" value="([^"]+)"/.exec(html)?.[1] ?? "";
}

/** POST /login。from を渡すと X-Forwarded-For で接続元を変える（trust proxy は loopback なので、検査の接続から信じられる） */
function postLogin(base: string, request: string, password: string, from?: string): Promise<Response> {
  const headers: Record<string, string> = { "content-type": "application/x-www-form-urlencoded" };
  if (from !== undefined) headers["x-forwarded-for"] = from;
  return fetch(`${base}/login`, { method: "POST", redirect: "manual", headers, body: new URLSearchParams({ request, password }) });
}

async function issueTokens(base: string) {
  const { clientId, verifier, login } = await authorize(base);
  const code = new URL(login.headers.get("location") ?? "").searchParams.get("code") ?? "";
  const tokens = (await (await exchange(base, clientId, code, verifier)).json()) as { access_token: string; refresh_token: string };
  return { clientId, code, ...tokens };
}

function refresh(base: string, clientId: string, refreshToken: string): Promise<Response> {
  return fetch(`${base}/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: refreshToken, client_id: clientId }),
  });
}

test("入れ替えたリフレッシュ鍵は、2 度目に出すと断る", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const { clientId, refresh_token } = await issueTokens(app.base);
    const first = await refresh(app.base, clientId, refresh_token);
    assert.equal(first.status, 200);
    const next = (await first.json()) as { access_token: string; refresh_token: string };
    assert.notEqual(next.refresh_token, refresh_token);
    assert.equal((await refresh(app.base, clientId, refresh_token)).status, 400);
    assert.equal((await refresh(app.base, clientId, next.refresh_token)).status, 200);
  } finally {
    await app.close();
  }
});

test("リフレッシュ鍵・認可コードを Bearer に出しても /mcp は 401", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const { code, refresh_token, access_token } = await issueTokens(app.base);
    assert.equal((await rpc(app.base, { authorization: `Bearer ${refresh_token}` })).status, 401);
    assert.equal((await rpc(app.base, { authorization: `Bearer ${code}` })).status, 401);
    const { login } = await authorize(app.base);
    const fresh = new URL(login.headers.get("location") ?? "").searchParams.get("code") ?? "";
    assert.equal((await rpc(app.base, { authorization: `Bearer ${fresh}` })).status, 401);
    assert.equal((await rpc(app.base, { authorization: `Bearer ${access_token}` })).status, 200);
  } finally {
    await app.close();
  }
});

test("/register は http://localhost の戻り先を受け、ほかの http は断る", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const register = (uri: string) =>
      fetch(`${app.base}/register`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ redirect_uris: [uri], client_name: "local", token_endpoint_auth_method: "none" }),
      });
    assert.equal((await register("http://localhost:33418/cb")).status, 201);
    assert.equal((await register("http://example.com/cb")).status, 400);
  } finally {
    await app.close();
  }
});

test("OPTIONS は /healthz・/authorize でも 405", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const healthz = await fetch(`${app.base}/healthz`, { method: "OPTIONS" });
    assert.equal(healthz.status, 405);
    assert.equal([...healthz.headers.keys()].some((name) => name.startsWith("access-control-")), false);
    assert.equal((await fetch(`${app.base}/authorize`, { method: "OPTIONS" })).status, 405);
  } finally {
    await app.close();
  }
});

test("ログインの画面は戻り先のホストを先に太字で出し、名前は名乗りとして添える", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const { html } = await authorize(app.base);
    assert.ok(html.includes("戻り先: <strong>chat.example.com</strong>（名乗り: ChatGPT）"));
    assert.equal(html.includes("ChatGPT（chat.example.com）"), false);
  } finally {
    await app.close();
  }
});

test("ログインの失敗は IPv6 の /56 をひとつの接続元として数え、5 回で止める（ほかの接続元は通る）", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  try {
    const request = await loginRequest(app.base);
    for (let i = 1; i <= 5; i += 1) {
      assert.equal((await postLogin(app.base, request, "wrong", `2001:db8:0:${i}::${i}`)).status, 401);
    }
    const blocked = await postLogin(app.base, request, TOKEN, "2001:db8:0:ff::abcd");
    assert.equal(blocked.status, 429);
    assert.ok((await blocked.text()).includes("しばらく置いてからお試しください。"));
    assert.equal((await postLogin(app.base, request, TOKEN, "203.0.113.9")).status, 302);
  } finally {
    await app.close();
  }
});

test("ログインの失敗は、接続元を問わず 10 分で 20 回を超えたら、どこからでも断る（10 分たてば戻る）", async () => {
  let now = Date.now();
  const app = await start({ MCP_PUBLIC_URL: PUBLIC }, () => new Date(now));
  try {
    const request = await loginRequest(app.base);
    for (let i = 1; i <= 20; i += 1) {
      assert.equal((await postLogin(app.base, request, "wrong", `198.51.100.${i}`)).status, 401);
    }
    assert.equal((await postLogin(app.base, request, "wrong", "198.51.100.99")).status, 429);
    const blocked = await postLogin(app.base, request, TOKEN, "203.0.113.9");
    assert.equal(blocked.status, 429);
    assert.ok((await blocked.text()).includes("しばらく置いてからお試しください。"));
    now += 601 * 1000;
    const again = await loginRequest(app.base);
    assert.equal((await postLogin(app.base, again, TOKEN, "203.0.113.9")).status, 302);
  } finally {
    await app.close();
  }
});

test("ログインの失敗の記録は、合い言葉を試したときだけ作り、古いものは消す", async () => {
  let now = Date.now();
  const app = await start({ MCP_PUBLIC_URL: PUBLIC }, () => new Date(now));
  try {
    assert.ok(app.oauth !== null);
    for (let i = 1; i <= 10; i += 1) {
      assert.equal((await postLogin(app.base, "not-a-request", "wrong", `192.0.2.${i}`)).status, 400);
    }
    assert.equal(app.oauth.trackedLoginSources, 0);
    const request = await loginRequest(app.base);
    assert.equal((await postLogin(app.base, request, "wrong", "192.0.2.50")).status, 401);
    assert.equal((await postLogin(app.base, request, TOKEN, "192.0.2.51")).status, 302);
    assert.equal(app.oauth.trackedLoginSources, 1);
    now += 601 * 1000;
    const again = await loginRequest(app.base);
    assert.equal((await postLogin(app.base, again, "wrong", "192.0.2.60")).status, 401);
    assert.equal(app.oauth.trackedLoginSources, 1);
  } finally {
    await app.close();
  }
});

test("ポートが使われていれば、待ち受けたふりをせず、変え方まで敬体で伝える（Express 5 は listen の誤りをコールバックに渡す）", async () => {
  const { config } = readConfig({ MCP_DEMO: "1", MCP_HTTP_TOKEN: TOKEN }, "http");
  const logger = createLogger("info", () => {}, () => new Date());
  const registry = new Registry({ sources: [sheetAppSource(sheetAppContext(sheetAppFake()))], limiter: new WriteLimiter(), logger, clock: () => new Date() });
  const first: HttpServer = await new Promise((resolve) => {
    const s = createHttpApp({ registry, config, logger, clock: () => new Date() }).app.listen(0, "127.0.0.1", () => resolve(s));
  });
  try {
    const port = (first.address() as AddressInfo).port;
    const error: Error & { code?: string } = await new Promise((resolve) => {
      const s = createHttpApp({ registry, config, logger, clock: () => new Date() }).app.listen(port, "127.0.0.1", (e?: Error) => {
        s.close();
        resolve(e as Error);
      });
    });
    assert.equal(error.code, "EADDRINUSE");
    assert.equal(
      listenFailure(error, { httpHost: "127.0.0.1", httpPort: 8787 }),
      "ポート 8787 は、ほかのプログラムが使っています。前に起動した HTTP 版が残っていれば止めるか、.env の MCP_HTTP_PORT を別の数（例: 8788）に変えてください。変えたときは cloudflared の --url のポートも同じにしてください（README の 15 章）。",
    );
    assert.match(listenFailure(Object.assign(new Error("x"), { code: "EACCES" }), { httpHost: "127.0.0.1", httpPort: 80 }), /^HTTP で待ち受けられませんでした（EACCES）。/);
  } finally {
    first.close();
  }
});

/** 誤りの応答が JSON-RPC の形で、スタック・絶対パス・HTML・本文のかけらを含まないことを確かめる */
async function assertCleanError(res: Response, status: number, code: number, fragment: string): Promise<void> {
  assert.equal(res.status, status);
  assert.match(res.headers.get("content-type") ?? "", /^application\/json/);
  const text = await res.text();
  assert.equal(/\bat /.test(text), false, text);
  assert.equal(text.includes("/"), false, text);
  assert.equal(/<[a-z!]/i.test(text), false, text);
  assert.equal(text.includes(fragment), false, text);
  const json = JSON.parse(text) as { jsonrpc: string; error: { code: number; message: string }; id: null };
  assert.equal(json.jsonrpc, "2.0");
  assert.equal(json.error.code, code);
  assert.equal(json.id, null);
}

test("壊れた JSON・大きすぎる本文には、ログインの前でもスタックやパスを見せず JSON-RPC の誤りを返す", async () => {
  const app = await start({ MCP_PUBLIC_URL: PUBLIC });
  const writes: string[] = [];
  const original = process.stderr.write.bind(process.stderr);
  process.stderr.write = ((chunk: string | Uint8Array) => {
    writes.push(String(chunk));
    return true;
  }) as typeof process.stderr.write;
  try {
    const broken = await fetch(`${app.base}/mcp`, { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream" }, body: '{"jsonrpc":"2.0", secret-fragment' });
    await assertCleanError(broken, 400, -32700, "secret-fragment");
    const big = await fetch(`${app.base}/login`, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ request: "x", password: "big-fragment-" + "a".repeat(20000) }),
    });
    await assertCleanError(big, 413, -32600, "big-fragment");
    const bigJson = await fetch(`${app.base}/mcp`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ pad: "b".repeat(200000) }) });
    await assertCleanError(bigJson, 413, -32600, "bbbb");
  } finally {
    process.stderr.write = original;
    await app.close();
  }
  assert.equal(writes.join("").includes("SyntaxError"), false);
  assert.equal(writes.join("").includes("secret-fragment"), false);
  assert.equal(app.lines.some((line) => line.includes("secret-fragment") || line.includes("big-fragment")), false);
});
