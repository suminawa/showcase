import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { ENV_NAMES } from "../src/core/env.ts";
import { INTERNAL_PATHS, INTERNAL_WORDS, WORK_IN_PROGRESS_MARKS } from "./forbidden.ts";
import { bootDemoTools } from "./demo-tools.ts";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const read = (path: string) => readFileSync(join(ROOT, path), "utf8");
const README = read("README.ja.md");

function filesUnder(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(join(ROOT, dir)).sort()) {
    const path = join(dir, name);
    if (statSync(join(ROOT, path)).isDirectory()) out.push(...filesUnder(path));
    else out.push(path);
  }
  return out;
}

test("README の設定の表の名前が、env.ts の ENV_NAMES と同じ並びでそろう", () => {
  const section = README.slice(README.indexOf("| 名前 | 既定 | 意味 |"));
  const names = [...section.matchAll(/^\| `([A-Z_]+)` \|/gm)].map((m) => m[1]);
  assert.deepEqual(names, [...ENV_NAMES]);
});

test(".env.example に全部の名前があり、値は既定のもの以外は空", () => {
  const example = read(".env.example");
  const entries = [...example.matchAll(/^([A-Z_]+)=(.*)$/gm)].map((m) => [m[1], m[2]]);
  assert.deepEqual(entries.map(([name]) => name), [...ENV_NAMES]);
  const filled = Object.fromEntries(entries.filter(([, value]) => value !== ""));
  assert.deepEqual(filled, { DOC_READER_SHEET: "読み取り", MCP_WRITE: "false", MCP_SHOW_UPDATER: "false", MCP_HTTP_HOST: "127.0.0.1", MCP_HTTP_PORT: "8787", MCP_DEMO: "0", MCP_LOG: "info" });
});

test("README のツール名が実物とそろう（書き込みありの見本で組んだ一覧）", async () => {
  const tools = await bootDemoTools();
  const fixed = tools.filter((name) => !/^(add|update)_row_/.test(name));
  for (const name of fixed) assert.ok(README.includes(`\`${name}\``), name);
  for (const pattern of ["`add_row_<テーブル>`", "`update_row_<テーブル>`"]) assert.ok(README.includes(pattern), pattern);
  const mentioned = [...README.matchAll(/`((?:list|get|search|describe|cancel)_[a-z_]+)`/g)].map((m) => m[1]);
  for (const name of mentioned) assert.ok(tools.includes(name), `README に実物に無いツール名: ${name}`);
});

test("README の誤りの code の表が、errors.ts の code とそろう（同じ並び・過不足なし）", () => {
  const source = read("src/core/errors.ts");
  const codes = [...new Set([...source.matchAll(/new ToolError\(\s*"([a-z_]+)"/g)].map((m) => m[1]))];
  const section = README.slice(README.indexOf("| code | 意味 | どうするか |"));
  const listed = [...section.matchAll(/^\| `([a-z_]+)` \|/gm)].map((m) => m[1]);
  assert.ok(codes.length >= 29, `errors.ts の code が少なすぎます: ${codes.length}`);
  assert.deepEqual(listed, codes);
});

test("THIRD-PARTY-NOTICES の版とライセンスの全文が、入っている依存と 1 字も違わない", () => {
  const notices = read("THIRD-PARTY-NOTICES.md");
  const sections = [...notices.matchAll(/^## (\S+) (\S+)（[^）]+）\n\n```\n([\s\S]*?)```$/gm)];
  assert.deepEqual(sections.map((m) => m[1]), ["@modelcontextprotocol/sdk", "zod", "express", "express-rate-limit"]);
  for (const [, name, version, text] of sections) {
    const dir = join(ROOT, "node_modules", name);
    assert.equal(JSON.parse(readFileSync(join(dir, "package.json"), "utf8")).version, version, name);
    const file = readdirSync(dir).find((entry) => /^licen[cs]e(\.md|\.txt)?$/i.test(entry));
    assert.ok(file, `${name} のライセンスのファイル`);
    assert.equal(text, readFileSync(join(dir, file), "utf8"), name);
  }
});

test("公開物と、zip に入る src・samples・examples・test・scripts に、内部の語・内部の場所・書きかけの印が無い", () => {
  const files = ["README.ja.md", "LICENSE.md", "CHANGELOG.md", "THIRD-PARTY-NOTICES.md", ".env.example", ...filesUnder("src"), ...filesUnder("samples"), ...filesUnder("examples"), ...filesUnder("test"), ...filesUnder("scripts")];
  for (const file of files) {
    const text = read(file);
    for (const word of [...INTERNAL_WORDS, ...INTERNAL_PATHS, ...WORK_IN_PROGRESS_MARKS]) {
      assert.equal(text.includes(word), false, `${relative(ROOT, join(ROOT, file))} に内部の語があります`);
    }
  }
});
