import { test } from "node:test";
import assert from "node:assert/strict";
import { CANCEL_NOTE } from "../src/sources/booking.ts";
import type { Vars } from "../src/core/env.ts";
import { createHider } from "../src/core/hide.ts";
import type { ToolDef } from "../src/core/tool.ts";
import type { FakeSheets } from "../src/google/fake.ts";
import { MetaCache } from "../src/google/sheets.ts";
import { bookingSource } from "../src/sources/booking.ts";
import { BOOKING_ID, NOW, bookingFake, callTool, codeOf, configOf } from "./fixtures.ts";

async function bookingTools(fake: FakeSheets, vars: Vars = {}): Promise<ToolDef[]> {
  const config = configOf(vars);
  return bookingSource({ sheets: fake, meta: new MetaCache(fake), spreadsheetId: BOOKING_ID, config, hider: createHider(config) }).tools(NOW);
}

type Listed = { from: string; to: string; total: number; bookings: Record<string, string>[] };

test("list_bookings: 期間の既定は今日から 30 日。確定だけを日付と開始の順に", async () => {
  const out = (await callTool(await bookingTools(bookingFake()), "list_bookings")) as unknown as Listed;
  assert.equal(out.from, "2026-09-25");
  assert.equal(out.to, "2026-10-25");
  assert.deepEqual(out.bookings.map((b) => b.ID), ["20260923-001", "20260918-001", "20260922-001"]);
});

test("list_bookings: 手で入れた日付と時刻のセルも YYYY-MM-DD と HH:mm で返す", async () => {
  const out = (await callTool(await bookingTools(bookingFake()), "list_bookings", { keyword: "肩こり" })) as unknown as Listed;
  assert.equal(out.bookings[0].日付, "2026-10-03");
  assert.equal(out.bookings[0].開始, "10:00");
});

test("list_bookings: 期間の誤り（from が to より後・366 日を超える）", async () => {
  const tools = await bookingTools(bookingFake());
  assert.equal(await codeOf(callTool(tools, "list_bookings", { from: "2026-10-01", to: "2026-09-01" })), "invalid_range");
  assert.equal(await codeOf(callTool(tools, "list_bookings", { from: "2026-01-01", to: "2027-01-03" })), "invalid_range");
  assert.equal(await codeOf(callTool(tools, "list_bookings", { from: "2026-02-30" })), "invalid_range");
});

test("list_bookings: 状態「すべて」と keyword（お名前・サービス・ご要望・受付番号）", async () => {
  const tools = await bookingTools(bookingFake());
  const all = (await callTool(tools, "list_bookings", { from: "2026-09-01", to: "2026-10-31", status: "すべて" })) as unknown as Listed;
  assert.equal(all.total, 5);
  const cancelled = (await callTool(tools, "list_bookings", { from: "2026-09-01", status: "キャンセル", keyword: "施術" })) as unknown as Listed;
  assert.deepEqual(cancelled.bookings.map((b) => b.お名前), ["佐藤"]);
});

test("キャンセル用・カレンダーは設定に関係なく返さない。MCP_HIDE_COLUMNS の列も落とす", async () => {
  const tools = await bookingTools(bookingFake(), { MCP_HIDE_COLUMNS: "予約.電話" });
  const { booking } = (await callTool(tools, "get_booking", { id: "20260918-001" })) as { booking: Record<string, string> };
  assert.deepEqual(Object.keys(booking), ["ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "ご要望", "受付日時", "キャンセル日時", "リマインド"]);
  assert.equal(JSON.stringify(booking).includes("token-"), false);
  assert.equal(await codeOf(callTool(tools, "get_booking", { id: "20990101-001" })), "booking_not_found");
});

test("cancel_booking: 状態とキャンセル日時を GAS と同じ書き方（' 付きの文字）で書き、注意を添える", async () => {
  const fake = bookingFake();
  const out = await callTool(await bookingTools(fake), "cancel_booking", { id: "20260918-001" });
  assert.equal(out.状態, "キャンセル");
  assert.equal(out.キャンセル日時, "2026-09-25 14:03:12");
  assert.equal(out.note, CANCEL_NOTE);
  const update = fake.calls.find((call) => call.method === "update");
  assert.deepEqual(update?.ranges, ["'予約'!B2", "'予約'!L2"]);
  const row = fake.sheet(BOOKING_ID, "予約")[1];
  assert.equal(row[1], "キャンセル");
  assert.equal(row[11], "2026-09-25 14:03:12");
  assert.equal(row[14], "token-000000000000000001");
});

test("cancel_booking: 済み・過去・無い受付番号・書かない設定", async () => {
  const tools = await bookingTools(bookingFake());
  assert.equal(await codeOf(callTool(tools, "cancel_booking", { id: "20260920-001" })), "already_cancelled");
  assert.equal(await codeOf(callTool(tools, "cancel_booking", { id: "20260918-002" })), "past_booking");
  assert.equal(await codeOf(callTool(tools, "cancel_booking", { id: "20990101-001" })), "booking_not_found");
  assert.deepEqual((await bookingTools(bookingFake(), { MCP_WRITE: "false" })).map((t) => t.name), ["list_bookings", "get_booking"]);
});

test("cancel_booking: 今日の、まだ始まっていない予約はキャンセルできる。書く直前に行がずれていたら row_moved", async () => {
  const fake = bookingFake();
  assert.equal((await callTool(await bookingTools(fake), "cancel_booking", { id: "20260923-001" })).状態, "キャンセル");
  const moved = bookingFake();
  moved.onCall = (method, ranges) => {
    if (method === "get" && ranges[0] === "'予約'!A2:O2") moved.sheet(BOOKING_ID, "予約").splice(1, 1);
  };
  assert.equal(await codeOf(callTool(await bookingTools(moved), "cancel_booking", { id: "20260918-001" })), "row_moved");
});

test("cancel_booking: 書く直前の読み直しで、ほかの方がキャンセルにしていたら already_cancelled で止める", async () => {
  const fake = bookingFake();
  fake.onCall = (method, ranges) => {
    if (method === "get" && ranges[0] === "'予約'!A2:O2") fake.sheet(BOOKING_ID, "予約")[1][1] = "キャンセル";
  };
  assert.equal(await codeOf(callTool(await bookingTools(fake), "cancel_booking", { id: "20260918-001" })), "already_cancelled");
  assert.equal(fake.calls.some((call) => call.method === "update"), false);
});

test("cancel_booking: 開始が空の今日の予約は、過ぎた予約として断らない（昨日の予約は past_booking）", async () => {
  const fake = bookingFake();
  const rows = fake.sheet(BOOKING_ID, "予約");
  rows[1][2] = "2026-09-25";
  rows[1][3] = "";
  assert.equal((await callTool(await bookingTools(fake), "cancel_booking", { id: "20260918-001" })).状態, "キャンセル");
  const yesterday = bookingFake();
  const old = yesterday.sheet(BOOKING_ID, "予約");
  old[1][2] = "2026-09-24";
  old[1][3] = "";
  assert.equal(await codeOf(callTool(await bookingTools(yesterday), "cancel_booking", { id: "20260918-001" })), "past_booking");
});
