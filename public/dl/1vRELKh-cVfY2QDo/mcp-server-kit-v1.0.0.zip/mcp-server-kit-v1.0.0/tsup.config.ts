import { defineConfig } from "tsup";

// 入口 3 本を dist/ に。依存（SDK・express・zod）は束ねず、npm ci で入れたものを読む。
// express-rate-limit は SDK の依存として入るものを使う（package.json に足さないので、ここで外に出すと明示する）
export default defineConfig({
  entry: { stdio: "src/server/stdio.ts", http: "src/server/http.ts", cli: "src/cli.ts" },
  format: ["esm"],
  platform: "node",
  target: "node20",
  outDir: "dist",
  clean: true,
  splitting: true,
  sourcemap: false,
  dts: false,
  external: ["express-rate-limit"],
});
