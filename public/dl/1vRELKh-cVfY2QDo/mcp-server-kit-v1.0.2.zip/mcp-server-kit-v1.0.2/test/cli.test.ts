import { test } from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import { copyFileSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { DOWNLOAD_URL, aliasesLine, newToken, runCheck, versionLine } from "../src/cli.ts";
import { SERVER_INFO } from "../src/server/create.ts";
import { FakeSheets } from "../src/google/fake.ts";
import { buildSpecs, hashSuffix } from "../src/sources/sheet-app/schema.ts";
import { BOOKING_ID, DEFINITION_ROWS, DOC_READER_ID, HIDER, SHEET_APP_ID, bookingRows, contactRows, customerRows, definitionTables } from "./fixtures.ts";

const KIT = fileURLToPath(new URL("..", import.meta.url));
const clock = () => new Date(Date.UTC(2026, 8, 25, 5, 0));
const noFetch = async () => {
  throw new Error("検査では Google に出ない");
};
const PEM = generateKeyPairSync("rsa", { modulusLength: 2048 }).privateKey.export({ type: "pkcs8", format: "pem" }).toString();
const KEY_JSON = JSON.stringify({ client_email: "mcp@kit-test.iam.gserviceaccount.com", private_key: PEM });

test("MCP_DEMO=1 なら見本で全部そろい、ok", async () => {
  const { lines, ok } = await runCheck({ processEnv: { MCP_DEMO: "1", MCP_ENV_FILE: "" }, kitDir: KIT, fetch: noFetch, clock });
  assert.equal(ok, true);
  assert.equal(lines[0], "[OK] 見本データ（MCP_DEMO=1）で確かめます。Google には接続しません。");
  const suffix = hashSuffix("顧客");
  assert.ok(lines.includes(`[OK] 業務アプリ: 「顧客」の見出しがそろっています（20 行。ツール名 add_row_${suffix}・update_row_${suffix}）`));
  assert.ok(lines.includes("[OK] 予約ページ: 「予約」の見出しがそろっています（8 件）"));
  assert.ok(lines.includes("[OK] 書類読み取り: 「読み取り」を読めました（5 行、列 12）"));
  assert.equal(lines.at(-1), "すべて確かめました。Claude Desktop などの設定に進んでください。");
});

test(".env を写していなければ、まずそれを伝え、続けて足りない設定を README の章つきで指す", async () => {
  const { lines, ok } = await runCheck({ processEnv: { MCP_ENV_FILE: "" }, kitDir: "/nonexistent-kit-dir", fetch: noFetch, clock });
  assert.equal(ok, false);
  assert.equal(lines[0], "[要対応] キットのフォルダに .env がありません。.env.example を .env という名前で写し（cp .env.example .env）、鍵の場所とスプレッドシートの URL を書いてください（README の 5 章）。");
  assert.equal(lines[1], "[要対応] サービス アカウントの鍵が設定されていません。GOOGLE_SERVICE_ACCOUNT_FILE に、Google Cloud でダウンロードした JSON の場所を書いてください（README の 4 章）。");
  assert.equal(lines[2], "[要対応] スプレッドシートの URL か ID が設定されていません。SHEET_APP_SPREADSHEET・BOOKING_SPREADSHEET・DOC_READER_SPREADSHEET のどれかを書いてください（README の 5 章）。");
  assert.equal(lines.at(-1), "上の項目を .env で直してから、もう一度 npm run check を実行してください。");
});

test(".env を写しただけ（値が空）なら、.env が無いとは言わずに足りない設定だけを指す", async () => {
  const dir = mkdtempSync(join(tmpdir(), "mcp-kit-check-"));
  try {
    copyFileSync(join(KIT, ".env.example"), join(dir, ".env"));
    const { lines, ok } = await runCheck({ processEnv: {}, kitDir: dir, fetch: noFetch, clock });
    assert.equal(ok, false);
    assert.equal(lines.length, 3);
    assert.match(lines[0], /^\[要対応\] サービス アカウントの鍵が設定されていません。/);
    assert.match(lines[1], /^\[要対応\] スプレッドシートの URL か ID が設定されていません。/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("MCP_HTTP_TOKEN を書いたのに短ければ、check でも HTTP 版と同じ文で指す（空なら stdio だけの方なので何も言わない）", async () => {
  const short = await runCheck({ processEnv: { MCP_ENV_FILE: "", MCP_DEMO: "1", MCP_HTTP_TOKEN: "short123" }, kitDir: KIT, fetch: noFetch, clock });
  assert.equal(short.ok, false);
  assert.deepEqual(short.lines, [
    "[要対応] MCP_HTTP_TOKEN が空か、32 字より短いです。npm run token で作った文字を貼ってください（README の 8 章の 1）。",
    "上の項目を .env で直してから、もう一度 npm run check を実行してください。",
  ]);
  const noToken = await runCheck({ processEnv: { MCP_ENV_FILE: "", MCP_DEMO: "1", MCP_PUBLIC_URL: "https://x.trycloudflare.com" }, kitDir: KIT, fetch: noFetch, clock });
  assert.equal(noToken.ok, false);
  assert.match(noToken.lines[0], /^\[要対応\] MCP_HTTP_TOKEN が空か/);
  const empty = await runCheck({ processEnv: { MCP_ENV_FILE: "", MCP_DEMO: "1" }, kitDir: KIT, fetch: noFetch, clock });
  assert.equal(empty.ok, true);
});

test("鍵のファイルが無ければ、その場所を確かめるよう伝える", async () => {
  const { lines, ok } = await runCheck({
    processEnv: { MCP_ENV_FILE: "", GOOGLE_SERVICE_ACCOUNT_FILE: "missing-key.json", SHEET_APP_SPREADSHEET: SHEET_APP_ID },
    kitDir: KIT,
    fetch: noFetch,
    clock,
  });
  assert.equal(ok, false);
  assert.equal(lines[0], "[要対応] GOOGLE_SERVICE_ACCOUNT_FILE のファイルが見つかりません。Google Cloud でダウンロードした JSON の置き場所と名前をご確認ください（README の 4 章の 5）。");
});

test("秘密鍵の中身が崩れていれば [OK] にせず、鍵を読めないと伝える（Google につながらない、とは言わない）", async () => {
  const broken = PEM.replace(/\n[A-Za-z0-9+/]{20}/, "\n!!!!broken!!!!");
  const { lines, ok } = await runCheck({
    processEnv: { MCP_ENV_FILE: "", GOOGLE_SERVICE_ACCOUNT_JSON: JSON.stringify({ client_email: "mcp@kit-test.iam.gserviceaccount.com", private_key: broken }), SHEET_APP_SPREADSHEET: SHEET_APP_ID },
    kitDir: KIT,
    fetch: noFetch,
    clock,
  });
  assert.equal(ok, false);
  assert.match(lines[0], /^\[要対応\] サービス アカウントの鍵を読めませんでした。/);
  assert.equal(lines.some((l) => l.includes("Google につながりませんでした")), false);
});

test("見出しの不足・シートの不足・開けないスプレッドシートを、どれも名前を挙げて指す", async () => {
  const customers = customerRows();
  customers[0] = customers[0].filter((h) => h !== "最終連絡日");
  const sheets = new FakeSheets(
    {
      [SHEET_APP_ID]: { sheets: { 定義: DEFINITION_ROWS, 顧客: customers, 対応履歴: contactRows() } },
      [BOOKING_ID]: { timeZone: "America/New_York", sheets: { 予約: bookingRows() } },
      [DOC_READER_ID]: { sheets: { シート1: [] } },
    },
    "mcp@kit-test.iam.gserviceaccount.com",
  );
  const { lines, ok } = await runCheck({
    processEnv: { MCP_ENV_FILE: "", GOOGLE_SERVICE_ACCOUNT_JSON: KEY_JSON, SHEET_APP_SPREADSHEET: SHEET_APP_ID, BOOKING_SPREADSHEET: BOOKING_ID, DOC_READER_SPREADSHEET: DOC_READER_ID },
    kitDir: KIT,
    fetch: noFetch,
    clock,
    sheets,
  });
  assert.equal(ok, false);
  assert.equal(lines[0], "[OK] 鍵を読めました（サービス アカウント: mcp@kit-test.iam.gserviceaccount.com）");
  assert.ok(lines.includes("[要対応] 業務アプリ: 「顧客」シートに「最終連絡日」の見出しがありません。見出しの名前が変わっていないかを確かめ、業務アプリのメニュー「初期化」を実行してください。"));
  assert.ok(lines.some((l) => l.startsWith("[注意] 予約ページ: スプレッドシートのタイムゾーンが Asia/Tokyo ではありません")));
  assert.ok(lines.includes("[要対応] 書類読み取り: スプレッドシートに「読み取り」シートがありません。書類読み取りから 1 度送ると作られます。DOC_READER_SHEET のシート名もご確認ください。"));
  assert.equal(lines.at(-1), "[要対応] の項目を直してから、もう一度 npm run check を実行してください。");
});

test("token は 43 字の英数と - _ で、毎回ちがう（32 字以上の決まりを満たす）", () => {
  const a = newToken();
  assert.match(a, /^[A-Za-z0-9_-]{43}$/);
  assert.notEqual(a, newToken());
});

test("check の 1 行目に、いまの版と配布ページの URL を出す", () => {
  assert.equal(versionLine(), `MCP サーバー キット ${SERVER_INFO.version}（新しい版はこちらで確かめられます: ${DOWNLOAD_URL}）`);
  assert.match(DOWNLOAD_URL, /^https:\/\/suminawa\.booth\.pm\/items\/\d+$/);
});

test("ツール名が英数の並びなら、.env に貼れる MCP_TABLE_ALIASES の 1 行を出す（付いている別名は残す）", async () => {
  const { lines } = await runCheck({ processEnv: { MCP_DEMO: "1", MCP_ENV_FILE: "" }, kitDir: KIT, fetch: noFetch, clock });
  const at = lines.indexOf("MCP_TABLE_ALIASES=顧客:customers, 対応履歴:contacts");
  assert.ok(at > 0, lines.join("\n"));
  assert.match(lines[at - 1], new RegExp(`^\\[注意\\] 業務アプリ: ツール名が add_row_${hashSuffix("顧客")} のような英数の並びです。`));
  const options = { only: [], hider: HIDER, write: true };
  const named = buildSpecs(definitionTables(), { ...options, aliases: { 顧客: "clients" } }).specs;
  assert.equal(aliasesLine(named), "MCP_TABLE_ALIASES=顧客:clients, 対応履歴:contacts");
  const tables = definitionTables().map((table) => ({ ...table, name: table.name === "顧客" ? "取引先" : table.name }));
  assert.equal(aliasesLine(buildSpecs(tables, { ...options, aliases: {} }).specs), "MCP_TABLE_ALIASES=取引先:table1, 対応履歴:contacts");
  const all = await runCheck({ processEnv: { MCP_DEMO: "1", MCP_ENV_FILE: "", MCP_TABLE_ALIASES: "顧客:customers, 対応履歴:contacts" }, kitDir: KIT, fetch: noFetch, clock });
  assert.equal(all.lines.some((l) => l.startsWith("MCP_TABLE_ALIASES=")), false);
});

test("見出しの空白や全角はそろっているものとして扱い、5,000 行を超えるシートには注意を出す", async () => {
  const customers = customerRows();
  customers[0] = customers[0].map((h) => (h === "ID" ? "ＩＤ" : h === "会社名" ? "会社名 " : h));
  const contacts = contactRows();
  for (let i = 0; i < 5001; i += 1) contacts.push([`20260801-${String(i + 1).padStart(4, "0")}`, "20260901-001", "", "電話", "", "", "", "", "", ""]);
  const sheets = new FakeSheets({ [SHEET_APP_ID]: { sheets: { 定義: DEFINITION_ROWS, 顧客: customers, 対応履歴: contacts } } }, "mcp@kit-test.iam.gserviceaccount.com");
  const { lines, ok } = await runCheck({
    processEnv: { MCP_ENV_FILE: "", GOOGLE_SERVICE_ACCOUNT_JSON: KEY_JSON, SHEET_APP_SPREADSHEET: SHEET_APP_ID },
    kitDir: KIT,
    fetch: noFetch,
    clock,
    sheets,
  });
  assert.equal(ok, true, lines.join("\n"));
  assert.ok(lines.some((l) => l.startsWith("[OK] 業務アプリ: 「顧客」の見出しがそろっています（6 行。")));
  assert.ok(lines.includes("[注意] 業務アプリ: 「対応履歴」は 5,003 行あります。ツールは呼ぶたびにシートを全部読むため、5,000 行を超えると返事が遅くなります。古い行を別のスプレッドシートに移すと速くなります。"));
  assert.equal(lines.some((l) => l.includes("「顧客」は")), false);
});
