import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { findHashed, findInternal, INTERNAL_PATHS, INTERNAL_WORDS, STYLE_WORDS, WORK_IN_PROGRESS_MARKS } from "./forbidden.ts";
import type { HashedWord } from "./forbidden.ts";

/** 照合の仕組みを確かめるための見本の語。本物の語は、検査のコードにも書きません */
const FIXTURE_WORD = "forbidden-word-fixture";
const FIXTURE: HashedWord = { sha256: "c0a62e3dcf4e43332289226b6ee97d2dfd1f4a4fc7810cfa73040b123ef91efa", length: 22 };

test("見本の語のハッシュと長さは、見本の語そのものから計算した値と合う", () => {
  assert.equal(createHash("sha256").update(FIXTURE_WORD, "utf8").digest("hex"), FIXTURE.sha256);
  assert.equal(Array.from(FIXTURE_WORD).length, FIXTURE.length);
});

test("ハッシュの照合で、文の中の語を見つけ、語の無い文は通す", () => {
  assert.equal(findHashed(`前置きの文 ${FIXTURE_WORD} 後ろの文`, [FIXTURE]), FIXTURE_WORD);
  assert.equal(findHashed(FIXTURE_WORD, [FIXTURE]), FIXTURE_WORD);
  // 前にサロゲートペアの字があっても、コードポイントの窓で見つける
  assert.equal(findHashed(`𠮷${FIXTURE_WORD}`, [FIXTURE]), FIXTURE_WORD);
  // 大文字と小文字は、ignoreCase のときだけ区別しない
  assert.equal(findHashed("Forbidden-Word-Fixture で始まる文", [FIXTURE]), null);
  assert.equal(findHashed("Forbidden-Word-Fixture で始まる文", [FIXTURE], { ignoreCase: true }), FIXTURE_WORD);
  // 1 字足りない・1 字違う・空の文は通す
  assert.equal(findHashed(FIXTURE_WORD.slice(0, -1), [FIXTURE]), null);
  assert.equal(findHashed(FIXTURE_WORD.replace("word", "ward"), [FIXTURE]), null);
  assert.equal(findHashed("", [FIXTURE]), null);
});

test("同梱物の検査の語は、ハッシュと長さだけで持ち、語の無い文は通す", () => {
  const lists = [INTERNAL_WORDS, STYLE_WORDS, INTERNAL_PATHS, WORK_IN_PROGRESS_MARKS];
  for (const list of lists) {
    assert.ok(list.length > 0);
    for (const item of list) {
      assert.deepEqual(Object.keys(item).sort(), ["length", "sha256"]);
      assert.match(item.sha256, /^[0-9a-f]{64}$/);
      assert.ok(Number.isInteger(item.length) && item.length > 0);
    }
  }
  const clean = "お見積もりは無料です。現地調査のうえ、3〜5 営業日でお出しします。Settings → Secrets and variables → Actions";
  assert.equal(findInternal(clean), null);
  assert.equal(findInternal(clean, { style: false }), null);
  assert.equal(findInternal(`${clean} ${FIXTURE_WORD}`), null, "見本の語は、同梱物の検査の語には入っていません");
});
