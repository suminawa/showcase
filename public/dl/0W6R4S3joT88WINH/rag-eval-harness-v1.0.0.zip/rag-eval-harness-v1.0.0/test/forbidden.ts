/**
 * 同梱物に出してはいけない語をハッシュで照合します。
 * 語そのものは持たず、語の SHA-256（UTF-8 の 16 進）と長さ（コードポイントの数）だけを持ちます。
 * 文のコードポイントに、その長さの窓を 1 字ずつずらして当て、窓の SHA-256 を比べます。
 * このファイルは *.test.ts ではないので、検査としては走りません（読み込まれるだけです）。
 */
import { createHash } from "node:crypto";

export interface HashedWord {
  /** 語の SHA-256（UTF-8 の 16 進） */
  sha256: string;
  /** 語の長さ（コードポイントの数） */
  length: number;
}

/** 内部でだけ使う呼び名。大文字と小文字を区別しません（小文字にした語のハッシュです） */
export const INTERNAL_WORDS: readonly HashedWord[] = [
  { sha256: "64f267fcb11f79a7015e95fb568fe2a2647c7058bcbc5ab22f6ce352cfa4663f", length: 1 },
  { sha256: "8862996ab14f5b6963e73ad3a19db6584d2a8ddb2d377bdee0fd52ff36a119f5", length: 2 },
  { sha256: "a814855073fe357c3de182bdf03f3563c96fefc2e6feaf548e838c5fdeaa6de0", length: 5 },
  { sha256: "5f5e1c9a0ceb6b921608ef39fb385bcaa26d0dc20a63a43089a213e4b7441a84", length: 2 },
  { sha256: "a1a330a6d8469acc206bfe88bb6dc4330fd68f77178ee259faa4a5289d848fa4", length: 2 },
  { sha256: "a625159d18da57180b7215e56c4ca20cabf8bcd9b7030c8c460aeed7b5588c6c", length: 11 },
];

/** 公開する文で使わない言い回し。キットの答えを記録した samples/recorded/ は、見本の文書の言い回しを写すことがあるので見ません */
export const STYLE_WORDS: readonly HashedWord[] = [{ sha256: "4717078262be209bc6b139cd4399cb39c18aef45d051254c9a196ddd86f991dc", length: 4 }];

/** 手元の場所が分かってしまう手がかり。字のまま（大文字と小文字を区別して）照合します */
export const INTERNAL_PATHS: readonly HashedWord[] = [
  { sha256: "97eec8935ba3d3bd8f32e570e56fdc321b249bd44e99b272202e39e92fcccc9c", length: 12 },
  { sha256: "ac7148ee4d01e3aed55f1fe8177f2ac48494689fa83a15a74dfa03243799921c", length: 12 },
  { sha256: "a9e628bc2480d11a7fa8c1caf4729cd51068bd05ba41ea91a15261dea685b331", length: 18 },
  { sha256: "46dc943e3424a2254a109373bb5e9e7d016a71c4ad9f38d63991107e091bee56", length: 7 },
];

/** 書きかけの印。字のまま（大文字と小文字を区別して）照合します */
export const WORK_IN_PROGRESS_MARKS: readonly HashedWord[] = [
  { sha256: "337e547a950fc8a98592f10d964c1e79a304961790a8da0ce449a1f000cefabb", length: 4 },
  { sha256: "8f2adf96b87e9da120f700d292f446ffe20062d9f57eaa2449ae67a09af970c3", length: 5 },
  { sha256: "03626549a59abf648ee59163b3b8acbf66c36513cb1e76d6e277bc044c926e30", length: 3 },
];

function sha256(text: string): string {
  return createHash("sha256").update(text, "utf8").digest("hex");
}

/**
 * words のどれかに当たる部分を文から探して返します（無ければ null）。
 * 語の長さごとに、文のコードポイントの上で窓を 1 字ずつずらし、窓の SHA-256 を語のハッシュと比べます。
 * ignoreCase なら、文を小文字にしてから照合します（語のハッシュも小文字にした語のものにします）
 */
export function findHashed(text: string, words: readonly HashedWord[], options: { ignoreCase?: boolean } = {}): string | null {
  const target = options.ignoreCase === true ? text.toLowerCase() : text;
  // コードポイントごとの、文字列の中の位置（窓の切り出しに使います）
  const offsets: number[] = [];
  let offset = 0;
  for (const char of target) {
    offsets.push(offset);
    offset += char.length;
  }
  offsets.push(offset);
  const count = offsets.length - 1;

  const byLength = new Map<number, Set<string>>();
  for (const word of words) byLength.set(word.length, (byLength.get(word.length) ?? new Set<string>()).add(word.sha256));
  for (const [length, digests] of byLength) {
    for (let start = 0; start + length <= count; start += 1) {
      const window = target.slice(offsets[start], offsets[start + length]);
      if (digests.has(sha256(window))) return window;
    }
  }
  return null;
}

/**
 * 見つけた語を返します（無ければ null）。呼び名は大文字と小文字を区別せず（文頭で大文字になっても見つけます）、
 * 場所と書きかけの印は字のまま探します。style: false なら言い回し（STYLE_WORDS）は見ません
 */
export function findInternal(text: string, options: { style?: boolean } = {}): string | null {
  const words = options.style === false ? INTERNAL_WORDS : [...INTERNAL_WORDS, ...STYLE_WORDS];
  return findHashed(text, words, { ignoreCase: true }) ?? findHashed(text, [...INTERNAL_PATHS, ...WORK_IN_PROGRESS_MARKS]);
}
