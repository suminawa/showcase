import { test } from "node:test";
import assert from "node:assert/strict";
import { parseCases } from "../src/cases/cases.ts";
import { parseCsv } from "../src/cases/csv.ts";
import { ADMIN_HEADERS, casesFromAdmin } from "../src/cases/from-admin.ts";

test("未回答の行だけを質問にし、タグに 未回答。語の揃え方で同じ質問は 1 行にまとめる", () => {
  const exported = [
    ADMIN_HEADERS.join(","),
    "2026-10-01T01:00:00.000Z,太陽光パネルは付けられますか,資料に載っていません,,いいえ,900,claude-opus-5,10,5,0,いいえ,いいえ",
    "2026-10-01T01:01:00.000Z,見積もりは無料ですか,無料です,[1],はい,800,claude-opus-5,10,5,0,いいえ,いいえ",
    "2026-10-01T01:02:00.000Z,太陽光パネルは 付けられますか,資料に載っていません,,いいえ,900,claude-opus-5,10,5,0,いいえ,いいえ",
    "2026-10-01T01:03:00.000Z,駐車場はありますか,資料に載っていません,,いいえ,900,claude-opus-5,10,5,0,いいえ,いいえ",
  ].join("\n");
  const { csv, count } = casesFromAdmin(exported);
  assert.equal(count, 2);
  assert.ok(csv.startsWith("﻿id,質問,期待する答えの要点,"));
  const parsed = parseCases(parseCsv(csv.slice(1)), { baseDir: "/", exists: () => true });
  assert.deepEqual(parsed.cases.map((c) => [c.question, c.tags]), [
    ["太陽光パネルは付けられますか", ["未回答"]],
    ["駐車場はありますか", ["未回答"]],
  ]);
  assert.equal(parsed.problems.length, 2, "要点は空のまま（書き足してから使う）");
});

test("「質問」の列が無い CSV は、敬体で止める", () => {
  assert.throws(() => casesFromAdmin("a,b\n1,2\n"), /案内窓口の \/admin\/export の CSV ではないようです（「質問」の列がありません）。/);
});

test("先頭の空白で隠れた = も、書き出す CSV では ' を付けて守る（Excel 対策）", () => {
  const exported = [
    ADMIN_HEADERS.join(","),
    "2026-10-01T01:00:00.000Z, =SUM(1),資料に載っていません,,いいえ,900,claude-opus-5,10,5,0,いいえ,いいえ",
  ].join("\n");
  const { csv } = casesFromAdmin(exported);
  const rows = parseCsv(csv.slice(1));
  assert.equal(rows[1][1], "'=SUM(1)");
});
