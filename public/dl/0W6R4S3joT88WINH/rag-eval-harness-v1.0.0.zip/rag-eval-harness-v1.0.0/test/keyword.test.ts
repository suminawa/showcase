import { test } from "node:test";
import assert from "node:assert/strict";
import { KEYWORD_NOTE, createKeywordJudge, keywordJudgment } from "../src/judge/keyword.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

test("要点は語の揃え方で答えに探す（部分一致）", () => {
  const c = caseOf({ id: "q1", points: ["80 万円", "150 万円", "4 日"] });
  const judgment = keywordJudgment(c, answerOf({ answer: "キッチンは８０万円～１５０万円ほどです。", refused: false }));
  assert.deepEqual(judgment.points, ["covered", "covered", "missing"]);
  assert.equal(judgment.reason, "語の一致: 要点 2/3 が答えに含まれます。");
});

test("禁止事項は答えに含まれたら違反。quote は禁止事項の字", () => {
  const c = caseOf({ id: "q1", points: ["銀行振込"], forbidden: ["クレジットカードで払える", "無料"] });
  const judgment = keywordJudgment(c, answerOf({ answer: "銀行振込のほか、クレジットカードで払えるようになりました。", refused: false }));
  assert.deepEqual(judgment.forbidden, [
    { violated: true, quote: "クレジットカードで払える", review: false },
    { violated: false, quote: "", review: false },
  ]);
});

test("断ったかは、キットの印が「断った」でなければ決まり文句で見る", () => {
  const c = caseOf({ id: "q1", special: "refuse" });
  assert.equal(keywordJudgment(c, answerOf({ answer: "申し訳ありませんが、資料に載っていません。", refused: null })).declined, true);
  assert.equal(keywordJudgment(c, answerOf({ answer: "お答えできかねます。", refused: null })).declined, true);
  assert.equal(keywordJudgment(c, answerOf({ answer: "資料に載っていません。", refused: false })).declined, true, "印が false でも断りの言い方があれば断った");
  assert.equal(keywordJudgment(c, answerOf({ answer: "駐車場は 3 台分あります。", refused: false })).declined, false);
  assert.equal(keywordJudgment(c, answerOf({ answer: "駐車場は 3 台分あります。", refused: true })).declined, true);
  assert.equal(keywordJudgment(c, answerOf({ answer: "駐車場は 3 台分あります。", refused: null })).declined, false);
});

test("contradicted は出さない。API を呼ばず、費用は 0", async () => {
  const judge = createKeywordJudge();
  assert.deepEqual(judge.info, { mode: "keyword", model: null, effort: null, rubricVersion: null });
  const outcome = await judge.judge(caseOf({ id: "q1", points: ["2 年"] }), answerOf({ answer: "保証は 3 年です。", refused: false }), 0);
  assert.ok(outcome.ok);
  assert.deepEqual(outcome.judgment.points, ["missing"]);
  assert.deepEqual(outcome.usage, []);
  assert.equal(KEYWORD_NOTE, "語の一致での採点です。言い換えは誤りに数えます。目安としてご覧ください。");
});
