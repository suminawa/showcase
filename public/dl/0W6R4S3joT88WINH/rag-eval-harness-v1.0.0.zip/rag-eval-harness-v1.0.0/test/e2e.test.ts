import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { main, type CliIo } from "../src/cli.ts";
import { OUTPUT_FILES } from "../src/report/write.ts";
import type { ResultJson } from "../src/types.ts";
import { fakeAnthropic, type FakeScript } from "./fixtures/fake-anthropic.ts";
import { FAKE_KITS } from "./fixtures/helpers.ts";

/**
 * 偽のキット（案内窓口）と偽の Anthropic（キットの答えと採点の両方）で、CLI を端から端まで通す。
 * 採点の偽物は、<answer> に要点の字が入っていれば covered、無ければ missing を返す
 */
const CASES = [
  "id,質問,期待する答えの要点,出典に含まれるべき文書,答えてはいけないこと,タグ",
  "price,キッチンの料金は,80 万円|150 万円,料金,見積もりに費用がかかる,料金",
  "warranty,保証は何年ですか,2 年,保証,,保証",
  "solar,太陽光パネルは付けられますか,（答えない）,,,断るべき",
].join("\n");

function script(answers: Record<string, string>): FakeScript {
  return (params) => {
    if (params.output_config?.format !== undefined) {
      const user: string = params.messages[0].content;
      const answer = user.slice(user.indexOf("<answer>\n") + 9, user.indexOf("\n</answer>"));
      const points = user.slice(user.indexOf("<expected_points>\n") + 18, user.indexOf("\n</expected_points>")).split("\n").filter((line) => /^\d+\. /.test(line));
      return {
        text: JSON.stringify({
          declined: /資料に載っていません|お答えできません/.test(answer),
          points: points.map((line, i) => ({ index: i + 1, status: answer.includes(line.replace(/^\d+\. /, "")) ? "covered" : "missing" })),
          forbidden: [],
          reason: "偽の採点です。",
        }),
        usage: { input_tokens: 400, output_tokens: 60 },
      };
    }
    const question: string = params.messages.at(-1).content;
    const text = Object.entries(answers).find(([key]) => question.includes(key))?.[1] ?? "資料に載っていません。";
    // 偽の索引は 0 = 料金、1 = 保証とアフターサービス
    return { text, citations: text.startsWith("資料") ? [] : [question.includes("保証") ? 1 : 0], usage: { input_tokens: 2000, output_tokens: 120 } };
  };
}

function run(dir: string, answers: Record<string, string>, at: string) {
  const out: string[] = [];
  const io: CliIo = { stdout: (line) => out.push(line), stderr: () => {}, env: {}, cwd: dir, now: () => new Date(at), anthropic: fakeAnthropic(script(answers)).client, sleep: async () => {} };
  const kitDir = join(FAKE_KITS, "ai-concierge");
  return main(["run", "--kit", "ai-concierge", "--kit-dir", kitDir, "--index", join(kitDir, "data", "index.json"), "--cases", "cases.csv"], io).then((code) => ({ code, out }));
}

test("1 回目: 偽のキットと偽の採点で、出力 6 つを書く", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-e2e-"));
  try {
    writeFileSync(join(dir, "cases.csv"), CASES);
    const { code, out } = await run(dir, { キッチン: "キッチンは 80 万円〜150 万円です。", 保証: "保証は 2 年です。" }, "2026-10-05T12:30:00.000Z");
    assert.equal(code, 0);
    assert.equal(out[0], "正答率 100%（正解 3・部分 0・誤り 0・無回答 0 ／ 採点できた 3 問）");
    const folder = join(dir, "runs", "20261005-213000-ai-concierge");
    assert.deepEqual(readdirSync(folder).sort(), [...OUTPUT_FILES].sort());
    const result = JSON.parse(readFileSync(join(folder, "result.json"), "utf8")) as ResultJson;
    assert.equal(result.schema, "rag-eval/1");
    assert.deepEqual(result.results.map((entry) => [entry.id, entry.verdict]), [["price", "correct"], ["warranty", "correct"], ["solar", "correct"]]);
    assert.equal(result.summary.citationHit, 1);
    assert.ok(result.summary.costJpy.kit > 0 && result.summary.costJpy.judge > 0);
    assert.deepEqual(result.judge, { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" });
    assert.ok(readFileSync(join(folder, "report.html"), "utf8").includes("見本の会社の案内窓口の答え合わせ 3 問"));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("キットの印が false でも、丁寧に断った答えは採点者の declined で「正解」になる", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-e2e-"));
  try {
    writeFileSync(join(dir, "cases.csv"), CASES);
    const { code } = await run(dir, { キッチン: "キッチンは 80 万円〜150 万円です。", 保証: "保証は 2 年です。", 太陽光: "申し訳ありません。その内容はお答えできません。" }, "2026-10-05T12:30:00.000Z");
    assert.equal(code, 0);
    const result = JSON.parse(readFileSync(join(dir, "runs", "20261005-213000-ai-concierge", "result.json"), "utf8")) as ResultJson;
    const solar = result.results.find((entry) => entry.id === "solar");
    assert.deepEqual([solar?.verdict, solar?.refused], ["correct", true]);
    assert.equal(result.summary.refusal.refusedWhenShould, 1);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("2 回目: 前回の result.json と id で突き合わせ、悪くなった問いを出す", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-e2e-"));
  try {
    writeFileSync(join(dir, "cases.csv"), CASES);
    await run(dir, { キッチン: "キッチンは 80 万円〜150 万円です。", 保証: "保証は 2 年です。" }, "2026-10-05T12:30:00.000Z");
    const second = await run(dir, { キッチン: "キッチンは 80 万円〜150 万円です。", 保証: "保証は 3 年です。", 太陽光: "太陽光パネルも付けられます。" }, "2026-10-06T12:30:00.000Z");
    assert.equal(second.code, 0);
    assert.equal(second.out[1], "前回との差: −67 ポイント（良くなった 0 問・悪くなった 2 問）");
    const result = JSON.parse(readFileSync(join(dir, "runs", "20261006-213000-ai-concierge", "result.json"), "utf8")) as ResultJson;
    assert.deepEqual(result.baseline?.regressed, ["warranty", "solar"]);
    assert.equal(result.baseline?.dir, "runs/20261005-213000-ai-concierge");
    const html = readFileSync(join(dir, "runs", "20261006-213000-ai-concierge", "report.html"), "utf8");
    assert.ok(html.indexOf("前回から悪くなった問い（2）") < html.indexOf("問いごとの結果"));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("鍵の値は、出力 6 つにも画面にも出ない", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-e2e-"));
  try {
    writeFileSync(join(dir, "cases.csv"), CASES);
    const secret = "sk-ant-test-SECRET123";
    const lines: string[] = [];
    const push = (line: string) => void lines.push(line);
    const io: CliIo = { stdout: push, stderr: push, env: { ANTHROPIC_API_KEY: secret }, cwd: dir, now: () => new Date("2026-10-05T12:30:00.000Z"), anthropic: fakeAnthropic(script({ キッチン: "キッチンは 80 万円〜150 万円です。", 保証: "保証は 2 年です。" })).client, sleep: async () => {} };
    const kitDir = join(FAKE_KITS, "ai-concierge");
    assert.equal(await main(["run", "--kit", "ai-concierge", "--kit-dir", kitDir, "--index", join(kitDir, "data", "index.json"), "--cases", "cases.csv"], io), 0);
    const folder = join(dir, "runs", "20261005-213000-ai-concierge");
    assert.deepEqual(readdirSync(folder).sort(), [...OUTPUT_FILES].sort());
    for (const file of OUTPUT_FILES) assert.equal(readFileSync(join(folder, file), "utf8").includes("SECRET123"), false, file);
    assert.equal(lines.join("\n").includes("SECRET123"), false);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
