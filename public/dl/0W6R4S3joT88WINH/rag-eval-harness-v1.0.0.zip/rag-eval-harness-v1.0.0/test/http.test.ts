import { test } from "node:test";
import assert from "node:assert/strict";
import { createHttpAdapter, getPointer, parseHttpMap } from "../src/adapters/http.ts";
import { HarnessError } from "../src/errors.ts";
import { caseOf, neverAbort } from "./fixtures/helpers.ts";

function fakeFetch(respond: (url: string, init: RequestInit) => Response | Promise<Response>) {
  const seen: Array<{ url: string; init: RequestInit }> = [];
  const impl = (async (url: string, init: RequestInit) => {
    seen.push({ url, init });
    return respond(url, init);
  }) as unknown as typeof fetch;
  return { impl, seen };
}

test("既定の形: POST {url} に question と history、応答の answer・sources・refused・retrieved・usage を読む", async () => {
  const { impl, seen } = fakeFetch(() =>
    Response.json({
      answer: "銀行振込のみです。",
      sources: [{ title: "料金", url: "https://example.com/price" }],
      refused: false,
      retrieved: [{ title: "料金", url: "https://example.com/price" }],
      model: "claude-sonnet-5",
      usage: { input_tokens: 1200, output_tokens: 80 },
    }),
  );
  const adapter = createHttpAdapter({ url: "http://127.0.0.1:8787/ask", env: {}, fetchImpl: impl });
  const answer = await adapter.ask(caseOf({ id: "q1", question: "カードは使えますか" }), 0, neverAbort());
  assert.equal(seen[0].url, "http://127.0.0.1:8787/ask");
  assert.equal(seen[0].init.method, "POST");
  assert.deepEqual(JSON.parse(String(seen[0].init.body)), { question: "カードは使えますか", history: [] });
  assert.deepEqual([answer.status, answer.answer, answer.refused, answer.model], ["ok", "銀行振込のみです。", false, "claude-sonnet-5"]);
  assert.deepEqual(answer.sources, [{ title: "料金", url: "https://example.com/price" }]);
  assert.deepEqual(answer.retrieved, [{ title: "料金", url: "https://example.com/price" }]);
  assert.deepEqual(answer.usage, [{ model: "claude-sonnet-5", input: 1200, output: 80, cacheRead: 0, cacheWrite5m: 0, cacheWrite1h: 0, lowerBound: false }]);
});

test("--map: 本文の {{question}}・{{history}} と、応答の場所を JSON Pointer で読む", async () => {
  const map = parseHttpMap({ method: "post", body: { q: "質問: {{question}}", turns: "{{history}}" }, answer: "/data/text", sources: "/data/refs", sourceTitle: "/name", sourceUrl: "/link", refused: "/data/declined" });
  const { impl, seen } = fakeFetch((_url, init) => {
    const body = JSON.parse(String(init.body));
    return Response.json({ data: { text: body.turns.length === 0 ? "80 万円です。" : "4 日です。", refs: [{ name: "料金", link: "/price" }, "会社概要"], declined: false } });
  });
  const adapter = createHttpAdapter({ url: "https://bot.example.com/v1", map, env: {}, fetchImpl: impl });
  const answer = await adapter.ask(caseOf({ id: "q1", question: "工期は", previous: "料金は" }), 0, neverAbort());
  assert.deepEqual(JSON.parse(String(seen[1].init.body)), { q: "質問: 工期は", turns: [{ role: "user", content: "料金は" }, { role: "assistant", content: "80 万円です。" }] });
  assert.deepEqual([answer.answer, answer.refused, answer.retrieved], ["4 日です。", false, null]);
  assert.deepEqual(answer.sources, [{ title: "料金", url: "/price" }, { title: "会社概要", url: null }]);
  assert.equal(getPointer({ "a/b": { "~c": 1 } }, "/a~1b/~0c"), 1);
  assert.throws(() => parseHttpMap({ answer: "data.text" }), /--map の answer は \/ で始まる JSON Pointer で書いてください/);
});

test("${ENV} は環境変数から埋め、値は答えにもエラーの文にも出さない", async () => {
  const token = "secret-token-1234567890";
  const map = parseHttpMap({ headers: { authorization: "Bearer ${EVAL_HTTP_TOKEN}" } });
  const { impl, seen } = fakeFetch(() => new Response("oops", { status: 500 }));
  const adapter = createHttpAdapter({ url: "https://bot.example.com", map, env: { EVAL_HTTP_TOKEN: token }, fetchImpl: impl });
  const answer = await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort());
  assert.equal((seen[0].init.headers as Record<string, string>).authorization, `Bearer ${token}`);
  assert.equal(JSON.stringify(answer).includes(token), false);
  assert.throws(
    () => createHttpAdapter({ url: "https://bot.example.com", map, env: {} }),
    (error: unknown) => error instanceof HarnessError && error.message === "--map の ${EVAL_HTTP_TOKEN} を環境変数 EVAL_HTTP_TOKEN で渡してください（値はどこにも書き出しません）。",
  );
});

test("2xx 以外・JSON でない・答えが無いは実行エラー（誤りとは数えない）。429 と 5xx と接続の切れはやり直せる", async () => {
  const cases: Array<[() => Response | never, string, boolean]> = [
    [() => new Response("", { status: 503 }), "窓口が 503 を返しました。", true],
    [() => new Response("", { status: 429 }), "窓口が 429 を返しました。", true],
    [() => new Response("", { status: 404 }), "窓口が 404 を返しました。", false],
    [() => new Response("<html>", { status: 200 }), "窓口の応答が JSON ではありません。", false],
    [() => Response.json({ text: "x" }), "窓口の応答に答え（/answer）がありません。", false],
    [() => { throw Object.assign(new TypeError("fetch failed"), { cause: { code: "ECONNRESET" } }); }, "窓口につながりませんでした（TypeError）。", true],
  ];
  for (const [respond, error, retryable] of cases) {
    const adapter = createHttpAdapter({ url: "https://bot.example.com", env: {}, fetchImpl: fakeFetch(respond).impl });
    const answer = await adapter.ask(caseOf({ id: "q1" }), 0, neverAbort());
    assert.deepEqual([answer.status, answer.error, answer.retryable], ["error", error, retryable]);
  }
});

test("時間切れ（signal が止まった）は、やり直さない実行エラー", async () => {
  const controller = new AbortController();
  const impl = ((_url: string, init: RequestInit) =>
    new Promise((_resolve, reject) => {
      init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")));
    })) as unknown as typeof fetch;
  const adapter = createHttpAdapter({ url: "https://bot.example.com", env: {}, fetchImpl: impl });
  const pending = adapter.ask(caseOf({ id: "q1" }), 0, controller.signal);
  controller.abort();
  const answer = await pending;
  assert.deepEqual([answer.status, answer.error, answer.retryable], ["error", "打ち切りました。", false]);
});

test("質問の $$・$&・$`・$' は、置き換えの記号として読まずにそのまま送る", async () => {
  const { impl, seen } = fakeFetch(() => Response.json({ answer: "はい。" }));
  const question = "$$5 と $& と $` と $'";
  const map = parseHttpMap({ body: { q: "質問: {{question}}", raw: "{{question}}" } });
  await createHttpAdapter({ url: "https://bot.example.com", env: {}, fetchImpl: impl }).ask(caseOf({ id: "q1", question }), 0, neverAbort());
  await createHttpAdapter({ url: "https://bot.example.com", map, env: {}, fetchImpl: impl }).ask(caseOf({ id: "q1", question }), 0, neverAbort());
  assert.deepEqual(JSON.parse(String(seen[0].init.body)), { question, history: [] });
  assert.deepEqual(JSON.parse(String(seen[1].init.body)), { q: `質問: ${question}`, raw: question });
});

test("--map の method に GET・HEAD は使えない（本文を送れず、質問が窓口に届かないため）", () => {
  for (const method of ["GET", "get", "HEAD"]) {
    assert.throws(
      () => parseHttpMap({ method }),
      (error: unknown) =>
        error instanceof HarnessError &&
        error.exitCode === 2 &&
        error.message === `--map の method に ${method.toUpperCase()} は使えません（本文を送れないため、質問が窓口に届きません）。POST など、本文を送れる方法を指定してください。`,
    );
  }
  assert.equal(parseHttpMap({ method: "put" }).method, "PUT");
});
