import { test } from "node:test";
import assert from "node:assert/strict";
import { casesOfRecords, createReplayAdapter, parseCasesJsonl, toCasesJsonl } from "../src/adapters/replay.ts";
import type { CaseRecord, RunMeta } from "../src/types.ts";
import { answerOf, caseOf, neverAbort } from "./fixtures/helpers.ts";

const META: RunMeta = {
  tool: { name: "rag-eval-harness", version: "1.0.0" },
  startedAt: "2026-10-05T12:00:00.000Z",
  finishedAt: "2026-10-05T12:03:00.000Z",
  kit: { name: "ai-concierge", label: "みなと工務店の案内窓口", mode: "in-process", version: "1.0.1", model: "claude-opus-5" },
  judge: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" },
  cases: { file: "cases/ai-concierge.csv", sha256: "0".repeat(64), count: 1 },
  rounds: 2,
  notes: ["全文モード"],
  yenPerUsd: 150,
  redact: true,
};

function recordOf(id: string, round: number, text: string): CaseRecord {
  return {
    case: caseOf({ id, question: `${id} の質問` }),
    answer: answerOf({ answer: text }),
    judge: null,
    result: { id, round, tags: [], verdict: "correct", points: [], forbidden: [], citationHit: null, retrievalHit: null, refused: false, handoff: null, latencyMs: 1000, attempts: 1, reason: "", judgedBy: "rule", incomplete: false },
  };
}

test("記録の答えを、同じ id・同じ回で再生する（無い回は 1 回目）", async () => {
  const text = toCasesJsonl(META, [recordOf("q1", 0, "一回目"), recordOf("q1", 1, "二回目"), recordOf("q2", 0, "別の問い")]);
  const jsonl = parseCasesJsonl(text);
  assert.deepEqual(jsonl.meta, META);
  const adapter = createReplayAdapter(jsonl);
  assert.deepEqual(adapter.info, { name: "ai-concierge", label: "みなと工務店の案内窓口", mode: "replay", version: "1.0.1", model: "claude-opus-5" });
  assert.deepEqual(adapter.notes, ["全文モード"]);
  assert.equal((await adapter.ask(caseOf({ id: "q1" }), 1, neverAbort())).answer, "二回目");
  assert.equal((await adapter.ask(caseOf({ id: "q2" }), 2, neverAbort())).answer, "別の問い");
});

test("記録に無い問いは実行エラー。--cases が無いときは記録の問い（1 回目）を使う", async () => {
  const jsonl = parseCasesJsonl(toCasesJsonl(META, [recordOf("q1", 0, "a"), recordOf("q1", 1, "b")]));
  const answer = await createReplayAdapter(jsonl).ask(caseOf({ id: "q9" }), 0, neverAbort());
  assert.deepEqual([answer.status, answer.error], ["error", "記録に無い問いです（q9）。"]);
  assert.deepEqual(casesOfRecords(jsonl.records).map((c) => c.id), ["q1"]);
  assert.throws(() => parseCasesJsonl('{"type":"run"}\n{broken\n'), /cases\.jsonl の 2 行目を JSON として読めません。/);
});
