import { test } from "node:test";
import assert from "node:assert/strict";
import { createSseParser, readSse, summarizeChat } from "../src/adapters/sse.ts";

function streamOf(text: string, size: number): ReadableStream<Uint8Array> {
  const bytes = new TextEncoder().encode(text);
  return new ReadableStream({
    start(controller) {
      for (let i = 0; i < bytes.length; i += size) controller.enqueue(bytes.slice(i, i + size));
      controller.close();
    },
  });
}

test("行と文字が塊の境目で切れても、つないで組み直す", async () => {
  const sse = 'data: {"type":"text","text":"料金は 80 万円からです"}\n\ndata: {"type":"done","answered":true}\n\n';
  for (const size of [1, 3, 5, 64]) {
    const events = await readSse(streamOf(sse, size));
    assert.deepEqual(events, [{ type: "text", text: "料金は 80 万円からです" }, { type: "done", answered: true }], `size ${size}`);
  }
  const parser = createSseParser();
  assert.deepEqual(parser.push('data: {"type":"te'), []);
  assert.deepEqual(parser.push('xt","text":"a"}\r\n\r\ndata: x\n\n'), [{ type: "text", text: "a" }]);
});

test("text をつなぎ、citation を出典に、not_in_documents は断ったとする", () => {
  const answered = summarizeChat([
    { type: "text", text: "80 万円" },
    { type: "text", text: "からです。" },
    { type: "citation", index: 1, title: "料金 › 費用の目安", url: "https://example.com/price" },
    { type: "done", answered: true },
  ]);
  assert.deepEqual(answered, { text: "80 万円からです。", sources: [{ title: "料金 › 費用の目安", url: "https://example.com/price" }], refused: false, error: null });
  const refused = summarizeChat([{ type: "text", text: "資料に載っていません。" }, { type: "done", answered: false, reason: "not_in_documents" }]);
  assert.equal(refused.refused, true);
  assert.equal(refused.error, null);
  const noCitation = summarizeChat([{ type: "text", text: "はい。" }, { type: "done", answered: false, reason: "no_citations" }]);
  assert.equal(noCitation.refused, false);
});

test("error の出来事と reason: error は実行エラー", () => {
  assert.equal(summarizeChat([{ type: "error", code: "unavailable", message: "いまはお答えできません。" }, { type: "done", answered: false, reason: "error" }]).error, "いまはお答えできません。");
  assert.equal(summarizeChat([{ type: "done", answered: false, reason: "error" }]).error, "キットが答えを出せませんでした。");
});

test("同じ出典は 1 度だけ。done が届かなければ実行エラー", () => {
  const summary = summarizeChat([
    { type: "citation", index: 1, title: "料金", url: "https://example.com/price" },
    { type: "citation", index: 2, title: "料金", url: "https://example.com/price" },
  ]);
  assert.equal(summary.sources.length, 1);
  assert.equal(summary.error, "答えが最後まで届きませんでした。");
});
