import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { buildResultsCsv, RESULTS_CSV_HEADERS } from "../src/report/csv.ts";
import { buildReportHtml } from "../src/report/html.ts";
import { buildResultJson, type ReportInput } from "../src/report/json.ts";
import { buildSummaryEnMd, buildSummaryMd } from "../src/report/markdown.ts";
import { aggregate } from "../src/score/aggregate.ts";
import type { CaseRecord, RunMeta } from "../src/types.ts";
import { recordOf, usageOf } from "./fixtures/helpers.ts";

const META: RunMeta = {
  tool: { name: "rag-eval-harness", version: "1.0.0" },
  startedAt: "2026-10-05T12:30:00.000Z",
  finishedAt: "2026-10-05T12:33:00.000Z",
  kit: { name: "ai-concierge", label: "みなと工務店の案内窓口", mode: "in-process", version: "1.0.1", model: "claude-opus-5" },
  judge: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" },
  cases: { file: "cases/ai-concierge.csv", sha256: "a".repeat(64), count: 3 },
  rounds: 1,
  notes: ["全文モード（検索なし）"],
  yenPerUsd: 150,
  redact: true,
};

function inputOf(records: CaseRecord[], extra: Partial<ReportInput> = {}): ReportInput {
  return { meta: META, summary: aggregate(records, { yenPerUsd: 150, kit: "ai-concierge" }), baseline: null, previous: null, records, ...extra };
}

const RECORDS = [
  recordOf("q01", { verdict: "correct", tags: ["料金"], answer: { answer: "<script>alert(1)</script> 連絡は info@example.com へ", usage: [usageOf("claude-opus-5", 5000, 300)] } }),
  recordOf("q02", { verdict: "wrong", tags: ["保証"], answer: { answer: "=HYPERLINK(\"https://evil.example\")" }, result: { reason: "構造の 10 年が抜けています。" } }),
  recordOf("q03", { verdict: "partial", tags: ["料金"] }),
];

test("答えの中の <script> はエスケープし、伏せ字をかける（--no-redact なら外す）", () => {
  const html = buildReportHtml(inputOf(RECORDS));
  assert.ok(html.includes("&lt;script&gt;alert(1)&lt;/script&gt;"));
  assert.equal(html.split("<script>").length, 2, "中の script は 1 つだけ");
  assert.ok(html.includes("連絡は ***@*** へ"));
  assert.equal(html.includes("info@example.com"), false);
  const plain = buildReportHtml(inputOf(RECORDS, { meta: { ...META, redact: false } }));
  assert.ok(plain.includes("info@example.com"));
});

test("cases.jsonl・--from・前回の result.json からの偽の status・verdict は、決まった値に無ければ「不明」にする（HTML の属性から抜け出せない）", () => {
  const malicious = 'x"><a href="https://evil.example/">INJECTED</a><span class="';
  const records = [
    recordOf("q01", {
      // 形の検査をしない読み込み元（cases.jsonl・--from・前回の result.json）を装い、決まりに無い値を渡す
      verdict: malicious as any,
      result: {
        verdict: malicious as any,
        points: [{ text: "要点", status: malicious as any }],
      },
    }),
  ];
  const html = buildReportHtml(inputOf(records));
  assert.equal(html.includes("evil.example"), false);
  assert.equal(html.includes("INJECTED"), false);
  assert.equal(/<a\s/i.test(html), false);
  assert.equal(html.includes(malicious), false);
  assert.ok(html.includes('data-verdict="unknown"'));
  assert.ok(html.includes('<span class="chip unknown">不明</span>'));
  assert.ok(html.includes('<span class="m-unknown"'));
  assert.ok(html.includes("問いごとの結果"), "壊れずに最後まで描けている");
});

test("CSP の script-src のハッシュが、中の script と一致する", () => {
  const html = buildReportHtml(inputOf(RECORDS));
  const script = html.slice(html.indexOf("<script>") + "<script>".length, html.indexOf("</script>"));
  const csp = html.match(/content="default-src 'none'; style-src 'unsafe-inline'; script-src '(sha256-[^']+)'"/);
  assert.ok(csp);
  assert.equal(csp[1], `sha256-${createHash("sha256").update(script).digest("base64")}`);
});

test("外の資源（フォント・画像・スクリプト・スタイル）を読まない。出典の URL も字として出すだけ", () => {
  const html = buildReportHtml(inputOf([recordOf("q01", { answer: { sources: [{ title: "料金", url: "https://example.com/price" }] } })]));
  for (const pattern of [/\ssrc=/i, /<link\b/i, /@import/i, /url\(/i, /href="?https?:/i]) assert.equal(pattern.test(html), false, String(pattern));
  assert.ok(html.includes("<code>https://example.com/price</code>"));
});

test("ID とタグの列は 1 字ずつ折り返さない（td.nw）", () => {
  const html = buildReportHtml(inputOf(RECORDS));
  assert.match(html, /td\.nw \{ white-space: nowrap; \}/);
  assert.match(html, /<td data-label="ID" class="nw">/);
});

test("前回から悪くなった問いは、問いの表より先に出す", () => {
  const previous = buildResultJson(inputOf([recordOf("q01"), recordOf("q02", { verdict: "correct" }), recordOf("q03")]));
  const html = buildReportHtml(inputOf(RECORDS, { previous, baseline: { dir: "runs/20261004-090000-ai-concierge", score: 1, delta: -0.5, improved: [], regressed: ["q02"], common: 3, notes: [] } }));
  const regressed = html.indexOf("前回から悪くなった問い（1）");
  assert.ok(regressed > 0);
  assert.ok(regressed < html.indexOf("問いごとの結果"));
  assert.ok(html.includes("前回 正解 → 今回 誤り: 構造の 10 年が抜けています。"));
  assert.ok(html.includes('<span class="delta bad">▼50</span>'));
});

test("summary.md に答えの本文を入れない（質問と採点の理由だけ）", () => {
  const md = buildSummaryMd(inputOf(RECORDS));
  assert.ok(md.startsWith("# みなと工務店の案内窓口 3 問: 正答率 50%\n"));
  assert.ok(md.includes("「q02 の質問」— 誤り: 構造の 10 年が抜けています。"));
  assert.ok(md.includes("答え: claude-opus-5 ／ 採点: claude-sonnet-5（effort low）／ 3 問で"));
  for (const text of ["alert(1)", "HYPERLINK", "q03 の答え"]) assert.equal(md.includes(text), false, text);
});

test("測り方の一文は採点の方法（claude・keyword・replay）で変わる。keyword は Claude が印を付けたとは言わない", () => {
  const claudeMd = buildSummaryMd(inputOf(RECORDS));
  assert.ok(claudeMd.includes("測り方: 質問表の問いをそのまま窓口に答えさせ、答えに入っているべき要点ごとに Claude が印を付けました。"));

  const keywordMeta: RunMeta = { ...META, judge: { mode: "keyword", model: null, effort: null, rubricVersion: null } };
  const keywordMd = buildSummaryMd(inputOf(RECORDS, { meta: keywordMeta }));
  assert.ok(keywordMd.includes("測り方: 質問表の問いをそのまま窓口に答えさせ、答えに入っているべき要点ごとに語の一致で照合しました（Claude による採点ではありません）。"));
  assert.equal(keywordMd.includes("Claude が印を付けました"), false);
  const keywordEn = buildSummaryEnMd(inputOf(RECORDS, { meta: keywordMeta }));
  assert.ok(keywordEn.includes("Method: each question in the CSV was sent to the assistant as written. Each expected key point was matched against the answer by keyword (not graded by Claude)"));

  const replayMeta: RunMeta = { ...META, judge: { mode: "replay", model: "claude-sonnet-5", effort: null, rubricVersion: "2026-10-06" } };
  const replayMd = buildSummaryMd(inputOf(RECORDS, { meta: replayMeta }));
  assert.ok(replayMd.includes("測り方: 質問表の問いをそのまま窓口に答えさせ、正解・部分・誤り・無回答の判定は、前回の実行で記録した採点をそのまま再生したものです（今回はあらためて採点していません）。"));
  const replayEn = buildSummaryEnMd(inputOf(RECORDS, { meta: replayMeta }));
  assert.ok(replayEn.includes("Method: each question in the CSV was sent to the assistant as written. The verdict (correct / partial / wrong / no answer) is replayed from grading recorded in a previous run"));
});

test("summary.en.md は同じ形の英語", () => {
  const md = buildSummaryEnMd(inputOf(RECORDS, { baseline: { dir: "runs/x", score: 0.44, delta: 0.06, improved: [], regressed: [], common: 3, notes: [] } }));
  assert.ok(md.startsWith("# みなと工務店の案内窓口 — 3 questions: score 50% (+6 vs. previous run)\n"));
  for (const text of ["| Metric | Value |", "| Score | 50%", "## Weakest questions", "Answered by claude-opus-5 / graded by claude-sonnet-5 (effort low)", "Method: "]) assert.ok(md.includes(text), text);
  assert.equal(md.includes("alert(1)"), false);
});

test("results.csv は BOM つき、= + - @ で始まる値に ' を付けて式として動かないようにする", () => {
  const csv = buildResultsCsv(inputOf(RECORDS));
  assert.ok(csv.startsWith(`﻿${RESULTS_CSV_HEADERS.join(",")}\r\n`));
  assert.ok(csv.includes(`"'=HYPERLINK(""https://evil.example"")"`));
  assert.equal(/,=HYPERLINK/.test(csv), false);
  const json = buildResultJson(inputOf(RECORDS));
  assert.equal(json.schema, "rag-eval/1");
  assert.equal(json.results[0].answerHead.includes("***@***"), true, "result.json の答えも伏せ字の後");
  assert.deepEqual(json.notes, ["全文モード（検索なし）"]);
});

function caseRows(html: string): string[] {
  const start = html.indexOf('<tbody id="case-rows">');
  return html.slice(start, html.indexOf("</tbody>", start)).split("<tr ").slice(1);
}

test("採点が不完全な問いと、違反の印の字が答えに見つからない問いは、行に「要確認」を出す（CSV の要確認の列にも）", () => {
  const records = [
    recordOf("q01", { verdict: "partial", result: { incomplete: true, reason: "要点の番号が欠けていました。" } }),
    recordOf("q02", { verdict: "correct", result: { forbidden: [{ text: "無料", violated: false, review: true, quote: "無料" }] } }),
    recordOf("q03", { verdict: "correct" }),
  ];
  const html = buildReportHtml(inputOf(records));
  const rows = caseRows(html);
  assert.equal(rows.length, 3);
  assert.deepEqual(rows.map((row) => row.includes('<span class="chip review"')), [true, true, false]);
  assert.ok(rows[0].includes("要点の番号が欠けていました。（採点が不完全です）"));
  assert.ok(html.includes("要確認の問い: 2。"));
  assert.equal(buildReportHtml(inputOf([recordOf("q03")])).includes("要確認の問い"), false);
  const csv = buildResultsCsv(inputOf(records)).split("\r\n");
  const at = RESULTS_CSV_HEADERS.indexOf("要確認");
  assert.deepEqual(csv.slice(1, 4).map((line) => line.split(",")[at]), ["採点が不完全", "無料", ""]);
});

test("キャッシュの書き込みの数が分からない費用には「以上」を付ける（行の円・1 問あたり・要約）", () => {
  const input = inputOf([recordOf("q01", { answer: { usage: [usageOf("claude-opus-5", 5000, 300, { lowerBound: true })] } })]);
  assert.equal(input.summary.costLowerBound, true);
  const html = buildReportHtml(input);
  assert.ok(caseRows(html)[0].includes('<td data-label="円" class="num">4.9 円以上</td>'));
  assert.ok(html.includes("4.9 円以上・95%"));
  assert.ok(buildSummaryMd(input).includes("1 問で 4.9 円以上"));
  assert.ok(buildSummaryEnMd(input).includes("1 questions for ¥4.9+"));
  const exact = inputOf([recordOf("q01", { answer: { usage: [usageOf("claude-opus-5", 5000, 300)] } })]);
  assert.equal(buildReportHtml(exact).includes("以上"), false);
});

test("書類の読んだ値・根拠の字・採点の理由の電話番号も、答えと同じに伏せる（--no-redact なら外す）", () => {
  const records = [
    recordOf("q01", {
      verdict: "wrong",
      answer: { field: { label: "電話", value: "03-0000-1234", expected: "x", evidence: "TEL 03-0000-1234 まで", warnings: [], needsReview: false } as any },
      result: { reason: "電話 03-0000-1234 が違います。" },
    }),
  ];
  const checks = (redact: boolean) => {
    const input = inputOf(records, { meta: { ...META, redact } });
    return [buildReportHtml(input), buildSummaryMd(input), buildResultsCsv(input), JSON.stringify(buildResultJson(input))];
  };
  for (const text of checks(true)) assert.equal(text.includes("03-0000-1234"), false);
  assert.ok(checks(false)[0].includes("TEL 03-0000-1234 まで") && checks(false)[1].includes("03-0000-1234"));
});

test("手で書き換えた前回の差（数の欄に HTML）でも、レポートに差し込まれない", () => {
  const hostile = { dir: "runs/x", score: 1, delta: -0.5, improved: { length: '<img src=x onerror=alert(1)>' }, regressed: ["q02"], common: 3, notes: [] } as any;
  const html = buildReportHtml(inputOf(RECORDS, { baseline: hostile }));
  assert.equal(html.includes("<img"), false);
});
