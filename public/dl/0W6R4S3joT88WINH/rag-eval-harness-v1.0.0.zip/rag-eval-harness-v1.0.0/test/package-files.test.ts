import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
// @ts-expect-error 型の無い .mjs（scripts は release の道具）
import { RELEASE_GENERATED, releaseFileList, releaseFolderName, releaseZipPath } from "../scripts/release.mjs";
import { PACKAGE_ROOT } from "./fixtures/helpers.ts";

test("zip の一覧: dist・src・cases・samples・examples・test と README・LICENSE・NOTICES・lock が入り、runs/・.env・node_modules は入らない", () => {
  const root = mkdtempSync(join(tmpdir(), "rag-eval-release-"));
  try {
    const files = [
      ...RELEASE_GENERATED,
      "src/cli.ts",
      "cases/template.csv",
      "samples/calibration.jsonl",
      "examples/http-server.mjs",
      "test/fixtures/fake-kits/ai-concierge/dist/index.js",
      "scripts/release.mjs",
      "README.ja.md",
      "README.md",
      "LICENSE.md",
      "THIRD-PARTY-NOTICES.md",
      "CHANGELOG.md",
      "package.json",
      "package-lock.json",
      ".env",
      "examples/.env.local",
      "cases/from-admin-20261005.csv",
      "runs/20261005-213000-ai-concierge/report.html",
      "samples/runs/x.json",
      "node_modules/@anthropic-ai/sdk/index.js",
      "src/.DS_Store",
    ];
    for (const file of files) {
      mkdirSync(dirname(join(root, file)), { recursive: true });
      writeFileSync(join(root, file), file === "package.json" ? JSON.stringify({ version: "1.0.0" }) : "x");
    }
    const listed: string[] = releaseFileList(root);
    for (const want of ["dist/cli.js", "src/cli.ts", "cases/template.csv", "samples/calibration.jsonl", "examples/http-server.mjs", "test/fixtures/fake-kits/ai-concierge/dist/index.js", "README.ja.md", "README.md", "LICENSE.md", "THIRD-PARTY-NOTICES.md", "package-lock.json"]) {
      assert.ok(listed.includes(want), want);
    }
    for (const never of [".env", "examples/.env.local", "runs/20261005-213000-ai-concierge/report.html", "samples/runs/x.json", "node_modules/@anthropic-ai/sdk/index.js", "src/.DS_Store", "cases/from-admin-20261005.csv"]) {
      assert.equal(listed.includes(never), false, never);
    }
    assert.equal(releaseFolderName(root), "rag-eval-harness-v1.0.0");
    for (const file of releaseFileList(PACKAGE_ROOT)) assert.match(file, /^[\x20-\x7e]+$/, file);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

/** release/ の zip が、いまの dist より後に作られたものか（npm run release は build → test → zip の順なので、test の時点の zip は 1 つ前のもの） */
function freshZip(): boolean {
  const zipPath = releaseZipPath(PACKAGE_ROOT);
  if (!existsSync(zipPath)) return false;
  return RELEASE_GENERATED.every((relPath: string) => existsSync(join(PACKAGE_ROOT, relPath)) && statSync(join(PACKAGE_ROOT, relPath)).mtimeMs <= statSync(zipPath).mtimeMs);
}

test("release 済みなら、zip の中身は一覧と同じで、すべて rag-eval-harness-v<版>/ の下", { skip: !freshZip() }, () => {
  const listed = execFileSync("unzip", ["-Z1", releaseZipPath(PACKAGE_ROOT)], { encoding: "utf8" }).split("\n").filter((line) => line !== "");
  const folder = releaseFolderName(PACKAGE_ROOT);
  assert.deepEqual(listed.sort(), releaseFileList(PACKAGE_ROOT).map((file: string) => `${folder}/${file}`).sort());
  for (const entry of listed) assert.equal(/(^|\/)(\.env[^/]*|runs|node_modules)(\/|$)/.test(entry), false, entry);
});
