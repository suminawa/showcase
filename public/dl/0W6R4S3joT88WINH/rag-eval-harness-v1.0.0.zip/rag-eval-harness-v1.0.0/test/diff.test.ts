import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { HarnessError } from "../src/errors.ts";
import { checkThresholds, diffResults, findBaseline, readResultJson } from "../src/score/diff.ts";
import type { ResultEntry, ResultJson, Verdict } from "../src/types.ts";

function entry(id: string, verdict: Verdict, violated = false): ResultEntry {
  return { id, round: 0, tags: [], status: "ok", verdict, points: [], forbidden: violated ? [{ text: "無料", violated: true, quote: "無料", review: false }] : [], citationHit: null, retrievalHit: null, refused: false, handoff: null, latencyMs: 1, attempts: 1, usage: { kit: [], judge: [] }, answerHead: "", sources: [], reason: "" };
}

function resultOf(entries: ResultEntry[], extra: { kit?: string; sha?: string; score?: number | null; rubric?: string; range?: { min: number; max: number } } = {}): ResultJson {
  return {
    schema: "rag-eval/1",
    tool: { name: "rag-eval-harness", version: "1.0.0" },
    startedAt: "2026-10-05T00:00:00.000Z",
    finishedAt: "2026-10-05T00:01:00.000Z",
    kit: { name: (extra.kit ?? "ai-concierge") as ResultJson["kit"]["name"], label: "見本", mode: "in-process", version: "1.0.1", model: "claude-opus-5" },
    judge: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: extra.rubric ?? "2026-10-06" },
    cases: { file: "cases.csv", sha256: extra.sha ?? "a".repeat(64), count: entries.length },
    summary: { score: extra.score === undefined ? 0.8 : extra.score, scoreRange: extra.range ?? null } as ResultJson["summary"],
    baseline: null,
    notes: [],
    results: entries,
  };
}

test("--baseline auto は、runs/ の中で同じ kit の一番新しい result.json（今回と demo は除く）", () => {
  const root = mkdtempSync(join(tmpdir(), "rag-eval-runs-"));
  try {
    const put = (name: string, kit: string) => {
      mkdirSync(join(root, name), { recursive: true });
      writeFileSync(join(root, name, "result.json"), JSON.stringify(resultOf([], { kit })));
    };
    put("20261001-090000-ai-concierge", "ai-concierge");
    put("20261003-090000-ai-concierge", "ai-concierge");
    put("20261004-090000-doc-reader", "doc-reader");
    put("demo", "ai-concierge");
    put("20261005-090000-ai-concierge", "ai-concierge");
    mkdirSync(join(root, "20261006-090000-ai-concierge"));
    assert.equal(findBaseline(root, "ai-concierge", join(root, "20261005-090000-ai-concierge")), join(root, "20261003-090000-ai-concierge"));
    assert.equal(findBaseline(root, "doc-reader", null), join(root, "20261004-090000-doc-reader"));
    assert.equal(findBaseline(root, "line-concierge", null), null);
    assert.equal(findBaseline(join(root, "none"), "ai-concierge", null), null);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("findBaseline: 実行フォルダの名前のパターン（YYYYMMDD-HHmmss-…）だけを見る。壊れた symlink は無視する", () => {
  const root = mkdtempSync(join(tmpdir(), "rag-eval-baseline-"));
  try {
    mkdirSync(join(root, "20261001-090000-ai-concierge"));
    writeFileSync(join(root, "20261001-090000-ai-concierge", "result.json"), JSON.stringify(resultOf([], { kit: "ai-concierge" })));
    // 名前のパターンに合わないフォルダ（result.json はあっても見ない）
    mkdirSync(join(root, "notes"));
    writeFileSync(join(root, "notes", "result.json"), JSON.stringify(resultOf([], { kit: "ai-concierge" })));
    // 名前のパターンには合うが、壊れた symlink（例外を投げずに無視する）
    symlinkSync(join(root, "does-not-exist"), join(root, "20261002-090000-ai-concierge"));
    assert.equal(findBaseline(root, "ai-concierge", null), join(root, "20261001-090000-ai-concierge"));
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("readResultJson: schema が rag-eval/1 で必要な項目があれば読める", () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-good-"));
  try {
    const file = join(dir, "result.json");
    const json = resultOf([entry("a", "correct")]);
    writeFileSync(file, JSON.stringify(json));
    assert.deepEqual(readResultJson(file), json);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("readResultJson: 読めても rag-eval の result.json でなければ、TypeError より先に HarnessError にする", () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-foreign-"));
  try {
    const file = join(dir, "foreign.json");
    writeFileSync(file, JSON.stringify({ schema: "other-tool/1", hello: "world" }));
    assert.throws(
      () => readResultJson(file),
      (error: unknown) => error instanceof HarnessError && error.message.includes(file) && error.message.includes("rag-eval"),
    );
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("悪化: 正解・部分 → 誤り・無回答と新しい禁止の違反。良化はその逆。差は今回 − 前回", () => {
  const before = resultOf([entry("a", "correct"), entry("b", "partial"), entry("c", "wrong"), entry("d", "correct"), entry("e", "noAnswer", true)], { score: 0.5 });
  const after = resultOf([entry("a", "wrong"), entry("b", "noAnswer"), entry("c", "correct"), entry("d", "correct", true), entry("e", "noAnswer")], { score: 0.56 });
  const diff = diffResults(after, before, "runs/x");
  assert.deepEqual(diff.regressed, ["a", "b", "d"]);
  assert.deepEqual(diff.improved, ["c", "e"]);
  assert.ok(Math.abs((diff.delta ?? 0) - (0.4 - 0.5)) < 1e-9);
  assert.deepEqual([diff.dir, diff.score, diff.common, diff.notes], ["runs/x", 0.5, 5, []]);
});

test("質問表が違えば共通の問いで比べ、採点のしかたが違えば差は参考。幅より小さい差は幅の内側", () => {
  const before = resultOf([entry("a", "correct"), entry("b", "wrong"), entry("old", "correct")], { sha: "b".repeat(64), rubric: "2026-09-01" });
  const after = resultOf([entry("a", "correct"), entry("b", "correct"), entry("new", "wrong")], { range: { min: 0.5, max: 0.9 } });
  const diff = diffResults(after, before, "runs/y");
  assert.equal(diff.common, 2);
  assert.deepEqual([diff.score, diff.delta], [0.5, 0.5]);
  assert.deepEqual(diff.notes, ["質問表が前回と違います（共通の 2 問で比べました）。", "採点のしかたが違うため、差は参考です。"]);
  const narrow = diffResults(resultOf([entry("a", "correct")], { score: 0.82, range: { min: 0.7, max: 0.9 } }), resultOf([entry("a", "correct")], { score: 0.8 }), "runs/z");
  assert.deepEqual(narrow.notes, ["差は幅の内側です。"]);
});

test("--limit の run と全件の run は、ハッシュが同じでも共通の問いだけで比べる（偽の悪化にしない）", () => {
  const full = resultOf([entry("a", "correct"), entry("b", "correct"), entry("c", "wrong"), entry("d", "wrong")], { score: 0.5 });
  const limited = resultOf([entry("a", "correct"), entry("b", "correct")], { score: 1 });
  const diff = diffResults(limited, full, "runs/l");
  assert.equal(diff.common, 2);
  assert.deepEqual([diff.score, diff.delta], [1, 0]);
  assert.deepEqual(diff.notes, ["質問表が前回と違います（共通の 2 問で比べました）。"]);
  assert.equal(diffResults(full, limited, "runs/l").delta, 0);
});

test("id の組が同じでも質問表の中身が変わっていれば知らせる", () => {
  const before = resultOf([entry("a", "correct"), entry("b", "wrong")], { sha: "b".repeat(64) });
  const after = resultOf([entry("a", "correct"), entry("b", "wrong")]);
  assert.deepEqual(diffResults(after, before, "runs/s").notes, ["質問表の中身が前回と違います（同じ id の問いどうしで比べました）。"]);
});

test("--repeat の見出しの差は 1 回目どうし（回ごとの平均ではない）", () => {
  const round = (id: string, verdict: Verdict, n: number): ResultEntry => ({ ...entry(id, verdict), round: n });
  const before = resultOf([round("a", "wrong", 0), round("a", "correct", 1)], { score: 0.5 });
  const after = resultOf([round("a", "correct", 0), round("a", "correct", 1)], { score: 1 });
  const diff = diffResults(after, before, "runs/r");
  assert.deepEqual([diff.score, diff.delta], [0, 1]);
});

test("CI: 正答率が --min-score 未満、または --max-drop より下がったら終了コード 1（--min-score・--max-drop は 0〜100 の点数）", () => {
  assert.deepEqual(checkThresholds(0.85, 0.02, 80, 5), { exitCode: 0, messages: [] });
  assert.deepEqual(checkThresholds(0.75, null, 80, null), { exitCode: 1, messages: ["正答率 75% が --min-score 80% に届きません。"] });
  assert.deepEqual(checkThresholds(0.9, -0.1, null, 5), { exitCode: 1, messages: ["前回から 10 ポイント下がりました（--max-drop 5 ポイント）。"] });
  assert.deepEqual(checkThresholds(null, null, 50, null).exitCode, 1);
});

test("--max-drop は点数（0〜100）として扱う。1（1 ポイント）を 100 ポイントと取り違えない", () => {
  assert.equal(checkThresholds(0.9, -0.05, null, 1).exitCode, 1);
  assert.equal(checkThresholds(0.9, -0.005, null, 1).exitCode, 0);
});

test("--max-drop・--min-score の境界は小数の誤差に関わらずぴったりで判定する", () => {
  // ちょうど 5.0 ポイントの下がり（浮動小数の丸め誤差の出方が違う 2 通り）は、どちらも --max-drop 5 に収まる
  assert.equal(checkThresholds(0.75, 0.75 - 0.8, null, 5).exitCode, 0);
  assert.equal(checkThresholds(0.65, 0.65 - 0.7, null, 5).exitCode, 0);
  // 5.1 ポイントの下がりは超える
  assert.equal(checkThresholds(0.749, 0.749 - 0.8, null, 5).exitCode, 1);
  // ちょうど 80.0 点は --min-score 80 に届いている
  assert.equal(checkThresholds(0.8, null, 80, null).exitCode, 0);
});
