import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdtempSync, readFileSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { CHAT_URL, createAiConciergeAdapter, createAiConciergeHttpAdapter } from "../src/adapters/ai-concierge.ts";
import { RELAXED_LIMITS, WHOLE_MODE_NOTE, buildSampleIndex, noNetworkFetch } from "../src/adapters/common.ts";
import { HarnessError } from "../src/errors.ts";
import { fakeAnthropic, type FakeScript } from "./fixtures/fake-anthropic.ts";
import { FAKE_KITS, caseOf, fakeKit, neverAbort } from "./fixtures/helpers.ts";

const KIT = join(FAKE_KITS, "ai-concierge");

async function setup(script: FakeScript, index = "index.json") {
  const fake = await fakeKit("ai-concierge");
  fake.received.length = 0;
  const anthropic = fakeAnthropic(script);
  const adapter = await createAiConciergeAdapter({ kitDir: KIT, configPath: join(KIT, "concierge.config.json"), indexPath: join(KIT, "data", index), apiKey: "sk-test", baseClient: anthropic.client });
  return { adapter, anthropic, received: fake.received as any[] };
}

test("要求の形: 手元の /chat に POST、Origin は付けず、本文は question と history", async () => {
  const { adapter, received } = await setup(() => ({ text: "はい。", citations: [0] }));
  await adapter.ask(caseOf({ id: "q1", question: "見積もりは無料ですか" }), 0, neverAbort());
  const request = received.find((item) => item.url !== undefined);
  assert.equal(request.url, CHAT_URL);
  assert.equal(request.origin, null);
  assert.deepEqual(request.body, { question: "見積もりは無料ですか", history: [] });
});

test("答え・出典・model・usage を返す（出典は citation の題と URL）", async () => {
  const { adapter } = await setup(() => ({ text: "キッチンは 80 万円〜150 万円です。", citations: [0, 0] }));
  const answer = await adapter.ask(caseOf({ id: "q1", question: "キッチンの料金は" }), 0, neverAbort());
  assert.equal(answer.status, "ok");
  assert.equal(answer.answer, "キッチンは 80 万円〜150 万円です。");
  assert.deepEqual(answer.sources, [{ title: "料金", url: "https://example.com/price" }]);
  assert.equal(answer.refused, false);
  assert.equal(answer.model, "claude-opus-5");
  assert.equal(answer.usage.length, 1);
  assert.equal(answer.usage[0].lowerBound, false);
  assert.deepEqual([adapter.info.version, adapter.info.label], ["1.0.1", "見本の会社の案内窓口"]);
});

test("not_in_documents で終わった答えは「断った」", async () => {
  const { adapter } = await setup(() => ({ text: "資料に載っていません。" }));
  const answer = await adapter.ask(caseOf({ id: "q1", question: "太陽光パネルは" }), 0, neverAbort());
  assert.equal(answer.status, "ok");
  assert.equal(answer.refused, true);
});

test("回数の上限は、読み込んだ設定を記憶の中でだけゆるめる", async () => {
  const { adapter, received } = await setup(() => ({ text: "はい。", citations: [0] }));
  await adapter.ask(caseOf({ id: "q1" }), 0, neverAbort());
  assert.deepEqual(received[0].config.limits, { maxInputChars: 400, ...RELAXED_LIMITS });
  assert.equal(JSON.parse(readFileSync(join(KIT, "concierge.config.json"), "utf8")).limits, undefined, "設定ファイルは書き換えない");
});

test("キットに渡す環境変数は ANTHROPIC_API_KEY だけ（記録の Webhook を渡さない）", async () => {
  process.env.LOG_WEBHOOK_URL = "https://hooks.example.com/should-not-be-used";
  try {
    const { adapter, received } = await setup(() => ({ text: "はい。", citations: [0] }));
    await adapter.ask(caseOf({ id: "q1" }), 0, neverAbort());
    assert.deepEqual(received[0].config.envNames, ["ANTHROPIC_API_KEY"]);
    assert.equal(received[0].config.logWebhookUrl, null);
    assert.equal(received[0].deps.fetch, noNetworkFetch, "外へ出ない fetch も渡す");
  } finally {
    delete process.env.LOG_WEBHOOK_URL;
  }
});

test("前の質問は先に聞き、その答えを history に入れて本題を聞く", async () => {
  const { adapter, anthropic, received } = await setup((params) => ({ text: params.messages.length === 1 ? "80 万円〜150 万円です。" : "4 日〜6 日です。", citations: [0] }));
  const answer = await adapter.ask(caseOf({ id: "q1", question: "工期はどれくらいですか", previous: "キッチンの入れ替えはいくらですか" }), 0, neverAbort());
  const bodies = received.filter((item) => item.body !== undefined).map((item) => item.body);
  assert.deepEqual(bodies[1].history, [
    { role: "user", content: "キッチンの入れ替えはいくらですか" },
    { role: "assistant", content: "80 万円〜150 万円です。" },
  ]);
  assert.equal(answer.answer, "4 日〜6 日です。");
  assert.equal(anthropic.requests.length, 2);
  assert.equal(answer.usage.length, 2, "前の質問の費用も数える");
});

test("全文モードでは retrieved は null で注意を出し、BM25 の形では検索で拾った文書を返す", async () => {
  const whole = await setup(() => ({ text: "はい。", citations: [0] }));
  assert.deepEqual(whole.adapter.notes, [WHOLE_MODE_NOTE]);
  assert.equal((await whole.adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort())).retrieved, null);
  const bm25 = await setup(() => ({ text: "はい。", citations: [0] }), "index-bm25.json");
  assert.deepEqual(bm25.adapter.notes, []);
  assert.deepEqual((await bm25.adapter.ask(caseOf({ id: "q1", question: "料金と保証は" }), 0, neverAbort())).retrieved, [
    { title: "料金", url: "https://example.com/price" },
    { title: "保証とアフターサービス", url: "https://example.com/warranty" },
  ]);
});

test("Anthropic の 529 はやり直せる実行エラー、別の model で答えたらやり直さない実行エラー", async () => {
  const overloaded = await setup(() => ({ error: { status: 529 } }));
  const failed = await overloaded.adapter.ask(caseOf({ id: "q1" }), 0, neverAbort());
  assert.deepEqual([failed.status, failed.retryable, failed.error], ["error", true, "Anthropic の呼び出しが失敗しました（HTTP 529）。"]);
  const other = await setup(() => ({ text: "はい。", citations: [0], model: "claude-haiku-4-5" }));
  const mismatch = await other.adapter.ask(caseOf({ id: "q1" }), 0, neverAbort());
  assert.deepEqual([mismatch.status, mismatch.retryable], ["error", false]);
  assert.match(mismatch.error ?? "", /応答のモデル（claude-haiku-4-5）が、キットが頼んだモデル（claude-opus-5）と違います。/);
});

test("置いた先（--url）: POST {url}/chat・Origin なし。429 と 5xx はやり直せる実行エラー", async () => {
  const seen: Request[] = [];
  let status = 429;
  const fetchImpl = (async (input: Request) => {
    seen.push(input);
    if (status !== 200) return new Response(JSON.stringify({ ok: false, message: "少し時間をおいてからお試しください。" }), { status });
    return new Response('data: {"type":"text","text":"はい。"}\n\ndata: {"type":"citation","index":1,"title":"料金","url":"https://example.com/price"}\n\ndata: {"type":"done","answered":true}\n\n', { status: 200 });
  }) as unknown as typeof fetch;
  const adapter = createAiConciergeHttpAdapter({ url: "https://preview.example.com/api/concierge/", fetchImpl });
  const limited = await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort());
  assert.deepEqual([limited.status, limited.retryable, limited.error], ["error", true, "窓口が 429 を返しました（少し時間をおいてからお試しください。）。"]);
  status = 200;
  const answer = await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort());
  assert.equal(answer.answer, "はい。");
  assert.equal(seen[0].url, "https://preview.example.com/api/concierge/chat");
  assert.equal(seen[0].headers.get("origin"), null);
  assert.deepEqual(adapter.info, { name: "ai-concierge", label: "案内窓口（preview.example.com）", mode: "http", version: null, model: null });
});

test("--sample の索引は、キットの CLI で作る（作業フォルダはキットのフォルダ）", () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-index-"));
  try {
    const out = join(dir, ".cache", "ai-concierge-index.json");
    buildSampleIndex(join(KIT, "dist", "cli.js"), KIT, "samples/concierge.config.json", out);
    assert.ok(existsSync(out));
    assert.deepEqual(JSON.parse(readFileSync(out, "utf8")).builtFrom, { cwd: realpathSync(KIT), config: "samples/concierge.config.json" });
    assert.throws(() => buildSampleIndex(join(KIT, "dist", "missing.js"), KIT, "x.json", out), /見本の索引を作れませんでした（/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("置いた先（--url）: 読んでいる途中で切れたら、やり直せる実行エラー（ask は reject しない）", async () => {
  const first = new TextEncoder().encode('data: {"type":"text","text":"はい、"}\n\n');
  const fetchImpl = (async () => {
    let pulls = 0;
    const body = new ReadableStream<Uint8Array>({
      pull(stream) {
        pulls += 1;
        // 1 つ目の出来事を流したあと、本物の fetch と同じ TypeError("terminated") で切れる
        if (pulls === 1) stream.enqueue(first);
        else stream.error(new TypeError("terminated"));
      },
    });
    return new Response(body, { status: 200 });
  }) as unknown as typeof fetch;
  const adapter = createAiConciergeHttpAdapter({ url: "https://preview.example.com/api/concierge", fetchImpl });
  const answer = await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort());
  assert.deepEqual([answer.status, answer.error, answer.retryable, answer.answer], ["error", "窓口との接続が途中で切れました。もう一度お試しください。", true, ""]);
});

test("置いた先（--url）: 読んでいる途中で打ち切ったら「打ち切りました。」（やり直さない）", async () => {
  const first = new TextEncoder().encode('data: {"type":"text","text":"はい、"}\n\n');
  // 本文が AbortError で切れるのが先でも、こちらが読むのをやめるのが先でも、同じ答えにする
  for (const order of ["body-first", "abort-first"] as const) {
    const controller = new AbortController();
    const fetchImpl = (async () => {
      let pulls = 0;
      const body = new ReadableStream<Uint8Array>({
        pull(stream) {
          pulls += 1;
          if (pulls === 1) {
            stream.enqueue(first);
            return;
          }
          // 1 つ目の出来事を読み終えたところで時間切れにする
          if (order === "body-first") stream.error(new DOMException("This operation was aborted", "AbortError"));
          controller.abort();
        },
      });
      return new Response(body, { status: 200 });
    }) as unknown as typeof fetch;
    const adapter = createAiConciergeHttpAdapter({ url: "https://preview.example.com/api/concierge", fetchImpl });
    const answer = await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, controller.signal);
    assert.deepEqual([answer.status, answer.error, answer.retryable, answer.answer], ["error", "打ち切りました。", false, ""], order);
  }
});

test("見本の索引づくりに渡す環境変数は PATH だけ（記録の Webhook は届かない）。時間切れは敬体の文で止める", () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-index-"));
  process.env.LOG_WEBHOOK_URL = "https://hooks.example.com/should-not-be-used";
  try {
    // キットの CLI の代わりに、受け取った環境変数の名前を --out に書く台本
    const cli = join(dir, "env-cli.mjs");
    writeFileSync(cli, 'import { writeFileSync } from "node:fs";\nconst args = process.argv.slice(2);\nwriteFileSync(args[args.indexOf("--out") + 1], JSON.stringify(Object.keys(process.env)));\n');
    const out = join(dir, "env.json");
    buildSampleIndex(cli, dir, "x.json", out);
    const names = JSON.parse(readFileSync(out, "utf8")) as string[];
    assert.ok(names.includes("PATH"));
    assert.equal(names.includes("LOG_WEBHOOK_URL"), false);
    const slow = join(dir, "slow-cli.mjs");
    writeFileSync(slow, "setTimeout(() => {}, 10000);\n");
    assert.throws(
      () => buildSampleIndex(slow, dir, "x.json", out, 200),
      (error: unknown) => error instanceof HarnessError && error.exitCode === 2 && error.message === "見本の索引を作れませんでした（0.2 秒を過ぎても終わらなかったため、止めました）。キットのフォルダの場所をご確認のうえ、もう一度お試しください。",
    );
  } finally {
    delete process.env.LOG_WEBHOOK_URL;
    rmSync(dir, { recursive: true, force: true });
  }
});
