import { test } from "node:test";
import assert from "node:assert/strict";
import { gradeCase, ruleDecision, verdictOf } from "../src/score/grade.ts";
import type { DocField, JudgeOutcome, Judgment } from "../src/types.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

const context = { round: 0, attempts: 1, judgeMode: "claude" as const };
const judged = (judgment: Partial<Judgment>): JudgeOutcome => ({ ok: true, judgment: { declined: false, points: [], forbidden: [], reason: "理由", incomplete: false, ...judgment }, usage: [], raw: "{}" });
const field = (partial: Partial<DocField>): DocField => ({ key: "total", label: "合計金額", type: "money", value: 167750, expected: 167750, evidence: "合計 ¥167,750", needsReview: false, warnings: [], ...partial });

test("実行エラーは採点者を呼ばずに「実行エラー」（正答率の分母に入れない）", () => {
  const c = caseOf({ id: "q1", points: ["80 万円"] });
  const answer = answerOf({ status: "error", error: "Anthropic の呼び出しが失敗しました（HTTP 529）。" });
  assert.deepEqual(ruleDecision(c, answer), { verdict: "error", reason: "Anthropic の呼び出しが失敗しました（HTTP 529）。" });
  const result = gradeCase(c, answer, null, { ...context, attempts: 4 });
  assert.deepEqual([result.verdict, result.judgedBy, result.attempts, result.citationHit], ["error", "rule", 4, null]);
});

test("（答えない）: 断った → 正解、答えた → 誤り、引き継いだ → 誤り。印が無ければ採点者の declined で決める", () => {
  const c = caseOf({ id: "q1", special: "refuse" });
  assert.deepEqual(ruleDecision(c, answerOf({ refused: true })), { verdict: "correct", reason: "資料に無い問いを断りました。" });
  assert.equal(ruleDecision(c, answerOf({ refused: false })), null, "印が false でも丁寧な断りがありうるので採点者へ");
  assert.deepEqual(ruleDecision(c, answerOf({ refused: false, handoff: true })), { verdict: "wrong", reason: "資料に無い問いで、担当者に引き継いでいます。" });
  assert.equal(ruleDecision(c, answerOf({ refused: null })), null);
  assert.equal(gradeCase(c, answerOf({ refused: null }), judged({ declined: true }), context).verdict, "correct");
  const answered = gradeCase(c, answerOf({ refused: null }), judged({ declined: false }), context);
  assert.deepEqual([answered.verdict, answered.refused], ["wrong", false]);
  const polite = gradeCase(c, answerOf({ refused: false, answer: "お答えできません。" }), judged({ declined: true }), context);
  assert.deepEqual([polite.verdict, polite.refused, polite.judgedBy], ["correct", true, "claude"]);
  const stillAnswered = gradeCase(c, answerOf({ refused: false }), judged({ declined: false }), context);
  assert.deepEqual([stillAnswered.verdict, stillAnswered.refused], ["wrong", false]);
});

test("（引き継ぐ）: 引き継いだ → 正解、それ以外 → 誤り", () => {
  const c = caseOf({ id: "q1", special: "handoff" });
  assert.equal(ruleDecision(c, answerOf({ handoff: true }))?.verdict, "correct");
  assert.deepEqual(ruleDecision(c, answerOf({ handoff: false, refused: false })), { verdict: "wrong", reason: "担当者に引き継いでいません。" });
});

test("要点が普通なのに断った・引き継いだ → 無回答（答えるべき問いで断った）", () => {
  const c = caseOf({ id: "q1", points: ["80 万円"] });
  assert.deepEqual(ruleDecision(c, answerOf({ refused: true })), { verdict: "noAnswer", reason: "答えるべき問いで断りました。" });
  assert.deepEqual(ruleDecision(c, answerOf({ handoff: true, refused: false })), { verdict: "noAnswer", reason: "答えるべき問いで、担当者に引き継ぎました。" });
  assert.equal(ruleDecision(c, answerOf({ refused: false })), null, "答えたなら採点者へ");
});

test("書類読み取り: 型つきの値は比べて決め、（空）は値が null なら正解。文字は揃えて同じなら正解、違えば採点者へ", () => {
  const c = caseOf({ id: "d1", points: ["¥167,750"] });
  assert.deepEqual(ruleDecision(c, answerOf({ field: field({}) })), { verdict: "correct", reason: "値が一致しました（167750）。" });
  assert.deepEqual(ruleDecision(c, answerOf({ field: field({ type: "date", value: "2026-09-02", expected: "2026-09-01" }) })), { verdict: "wrong", reason: "値が違います（読み取り: 2026-09-02、期待: 2026-09-01）。" });
  assert.deepEqual(ruleDecision(c, answerOf({ field: field({ expected: null }) })), { verdict: "wrong", reason: "要点「¥167,750」を金額として読めません。質問表の要点を直してください。" });
  const empty = caseOf({ id: "d2", special: "empty" });
  assert.equal(ruleDecision(empty, answerOf({ field: field({ type: "string", value: null, expected: null }) }))?.verdict, "correct");
  assert.deepEqual(ruleDecision(empty, answerOf({ field: field({ type: "string", value: "会議費", expected: null }) })), { verdict: "wrong", reason: "空のはずの項目に「会議費」が入っています。" });
  assert.equal(ruleDecision(c, answerOf({ field: field({ type: "string", value: "さくら設備　株式会社", expected: "さくら設備株式会社" }) }))?.verdict, "correct");
  assert.equal(ruleDecision(c, answerOf({ field: field({ type: "string", value: "(株)さくら設備", expected: "さくら設備株式会社" }) })), null);
  assert.equal(gradeCase(c, answerOf({ field: field({ type: "string", value: "(株)さくら設備", expected: "さくら設備株式会社" }) }), judged({ points: ["covered"] }), context).verdict, "correct");
});

test("判定の決め方: 全部 covered → 正解、covered があり contradicted が無い → 部分、それ以外 → 誤り、断った → 無回答", () => {
  const of = (points: Judgment["points"], declined = false) => verdictOf({ declined, points, forbidden: [], reason: "", incomplete: false });
  assert.equal(of(["covered", "covered"]), "correct");
  assert.equal(of(["covered", "missing"]), "partial");
  assert.equal(of(["covered", "contradicted"]), "wrong");
  assert.equal(of(["missing", "missing"]), "wrong");
  assert.equal(of([]), "wrong");
  assert.equal(of(["covered"], true), "noAnswer");
});

test("採点者の結果から要点の印・禁止の違反・理由・不完全の印を写す。採点者の失敗は採点エラー", () => {
  const c = caseOf({ id: "q1", points: ["80 万円", "150 万円"], forbidden: ["無料"], tags: ["料金"] });
  const result = gradeCase(c, answerOf({ answer: "80 万円からで、見積もりは無料です。", refused: false }), judged({ points: ["covered", "missing"], forbidden: [{ violated: true, quote: "無料", review: false }], reason: "上限が抜けています。", incomplete: true }), { ...context, round: 2 });
  assert.deepEqual(result.points, [{ text: "80 万円", status: "covered" }, { text: "150 万円", status: "missing" }]);
  assert.deepEqual(result.forbidden, [{ text: "無料", violated: true, review: false, quote: "無料" }]);
  assert.deepEqual([result.verdict, result.reason, result.incomplete, result.round, result.tags, result.judgedBy], ["partial", "上限が抜けています。", true, 2, ["料金"], "claude"]);
  const failed = gradeCase(c, answerOf({ refused: false }), { ok: false, error: "採点の答えが JSON として読めませんでした。", usage: [], raw: null }, context);
  assert.deepEqual([failed.verdict, failed.reason], ["judgeError", "採点の答えが JSON として読めませんでした。"]);
});

test("根拠の一致: 出典の題か URL の一部。書類読み取りは evidence（出典の列が空なら要点）、明細のセルと断った問いは数えない。検索の当たりも見る", () => {
  const c = caseOf({ id: "q1", points: ["銀行振込"], sources: ["料金", "/faq"] });
  const answer = answerOf({ refused: false, sources: [{ title: "よくあるご質問", url: "https://example.com/faq" }], retrieved: [{ title: "会社概要", url: null }] });
  const hit = gradeCase(c, answer, judged({ points: ["covered"] }), context);
  assert.deepEqual([hit.citationHit, hit.retrievalHit], [true, false]);
  assert.equal(gradeCase(c, answerOf({ refused: true, sources: [] }), null, context).citationHit, null);
  assert.equal(gradeCase(caseOf({ id: "q2", points: ["x"] }), answerOf({ refused: false }), judged({ points: ["covered"] }), context).citationHit, null);
  const doc = caseOf({ id: "d1", points: ["¥167,750"] });
  assert.equal(gradeCase(doc, answerOf({ field: field({}) }), null, context).citationHit, true);
  assert.equal(gradeCase(doc, answerOf({ field: field({ evidence: "小計 ¥152,500" }) }), null, context).citationHit, false);
  assert.equal(gradeCase(doc, answerOf({ field: field({ evidence: null }) }), null, context).citationHit, null);
});
