import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { noNetworkFetch } from "../src/adapters/common.ts";
import { checkDocCases, createDocReaderAdapter, resolveTarget } from "../src/adapters/doc-reader.ts";
import { fakeAnthropic } from "./fixtures/fake-anthropic.ts";
import { FAKE_KITS, FIXTURES, caseOf, fakeKit, neverAbort } from "./fixtures/helpers.ts";

const KIT = join(FAKE_KITS, "doc-reader");
const INVOICE = join(FIXTURES, "docs", "invoice-a.pdf");
const RECEIPT = join(FIXTURES, "docs", "receipt-a.jpg");
const READ = {
  "invoice-a.pdf": {
    fields: { issuer: { value: "さくら設備株式会社", evidence: "さくら設備株式会社" }, issueDate: { value: "2026年9月1日", evidence: "発行日 2026年9月1日" }, total: { value: "¥167,750", evidence: "ご請求金額 ¥167,750" } },
    tables: { lineItems: [{ description: "給湯器交換工事", amount: "¥128,000" }, { description: "出張費", amount: "¥6,000" }] },
    warnings: [{ key: "issueDate", code: "confidence", message: "x" }, { key: "total", code: "check", message: "y" }],
    needsReview: true,
  },
  "receipt-a.jpg": { fields: { total: { value: "¥1,296", evidence: "合計 ¥1,296" }, purpose: { value: null, evidence: "" } } },
};

async function setup() {
  const fake = await fakeKit("doc-reader");
  fake.received.length = 0;
  fake.faults.length = 0;
  const anthropic = fakeAnthropic((params) => ({ text: JSON.stringify(READ[params.messages[0].content as keyof typeof READ]) }));
  const adapter = await createDocReaderAdapter({ kitDir: KIT, configPath: join(KIT, "reader.config.json"), formsDir: join(KIT, "forms"), apiKey: "sk-test", baseClient: anthropic.client });
  return { adapter, anthropic, received: fake.received as any[] };
}

const invoiceCase = (id: string, question: string, point: string) => caseOf({ id, question, points: [point], document: INVOICE, documentLabel: "docs/invoice-a.pdf", form: "invoice" });

test("同じ書類の行は 1 回の読み取りで採点し、費用は最初の問いにだけ数える", async () => {
  const { adapter, anthropic, received } = await setup();
  const answers = await Promise.all([invoiceCase("d1", "total", "167750"), invoiceCase("d2", "issuer", "さくら設備"), invoiceCase("d3", "発行日", "2026/9/1")].map((c) => adapter.ask(c, 0, neverAbort())));
  assert.equal(anthropic.requests.length, 1);
  assert.deepEqual(received.filter((item) => item.fileName !== undefined).map((item) => [item.fileName, item.form]), [["invoice-a.pdf", "invoice"]]);
  assert.deepEqual(answers.map((answer) => answer.usage.length), [1, 0, 0]);
  assert.deepEqual(answers.map((answer) => answer.latencyMs), [1500, 1500, 1500]);
  await adapter.ask(invoiceCase("d1", "total", "167750"), 1, neverAbort());
  assert.equal(anthropic.requests.length, 2, "2 回目（--repeat）は読み直す");
});

test("明細のセルは 表.列#行（キーでも名前でも）。行は 1 から", async () => {
  const { adapter } = await setup();
  const form = adapter.forms.get("invoice")!;
  assert.deepEqual(resolveTarget(form, "lineItems.amount#2"), resolveTarget(form, "明細.金額#2"));
  assert.equal(resolveTarget(form, "lineItems.amount#0"), null);
  const answer = await adapter.ask(invoiceCase("d4", "明細.金額#2", "6000"), 0, neverAbort());
  assert.deepEqual([answer.answer, answer.field?.key, answer.field?.label, answer.field?.evidence, answer.field?.value], ["6000", "lineItems.amount#2", "明細.金額#2", null, 6000]);
});

test("金額と日付は、要点をキットの normalizeValue で直した値を expected に入れる", async () => {
  const { adapter } = await setup();
  const money = await adapter.ask(invoiceCase("d1", "total", "¥167,750"), 0, neverAbort());
  assert.deepEqual([money.field?.type, money.field?.value, money.field?.expected], ["money", 167750, 167750]);
  const date = await adapter.ask(invoiceCase("d3", "issueDate", "2026年9月1日"), 0, neverAbort());
  assert.deepEqual([date.field?.type, date.field?.value, date.field?.expected], ["date", "2026-09-01", "2026-09-01"]);
});

test("（空）は expected が null。値が空なら answer も空", async () => {
  const { adapter } = await setup();
  const answer = await adapter.ask(caseOf({ id: "r1", question: "purpose", special: "empty", document: RECEIPT, documentLabel: "docs/receipt-a.jpg", form: "receipt" }), 0, neverAbort());
  assert.deepEqual([answer.status, answer.answer, answer.field?.value, answer.field?.expected], ["ok", "", null, null]);
});

test("文字の項目は要点をそのまま expected に（比べ方は採点の側）。警告はその項目と書類全体のものだけ", async () => {
  const { adapter } = await setup();
  const answer = await adapter.ask(invoiceCase("d2", "請求元", "さくら設備株式会社"), 0, neverAbort());
  assert.deepEqual([answer.field?.type, answer.field?.expected, answer.field?.needsReview], ["string", "さくら設備株式会社", true]);
  assert.deepEqual(answer.field?.warnings, []);
  const date = await adapter.ask(invoiceCase("d3", "issueDate", "2026-09-01"), 0, neverAbort());
  assert.deepEqual(date.field?.warnings, ["confidence"]);
});

test("根拠の字（evidence）を返す。帳票の型と項目の名前は API の前に確かめる", async () => {
  const { adapter } = await setup();
  const answer = await adapter.ask(invoiceCase("d1", "total", "167750"), 0, neverAbort());
  assert.equal(answer.field?.evidence, "ご請求金額 ¥167,750");
  assert.deepEqual(
    checkDocCases([invoiceCase("d1", "total", "1"), { ...invoiceCase("d2", "送料", "1"), line: 3 }, { ...invoiceCase("d3", "total", "1"), line: 4, form: "memo" }], adapter.forms),
    [
      "3 行目: 「送料」は帳票の型 invoice の項目にありません。項目のキーか名前（明細のセルは 表.列#行）で書いてください。",
      "4 行目: 帳票の型「memo」がキットの forms にありません（あるのは invoice・receipt）。",
    ],
  );
});

test("読み取りが途中で投げても ask は reject しない。接続の切れはやり直せる実行エラーで、覚えを消して次は読み直す", async () => {
  const { adapter, anthropic } = await setup();
  const fake = await fakeKit("doc-reader");
  fake.faults.push(Object.assign(new TypeError("fetch failed"), { cause: { code: "ECONNRESET" } }));
  const failed = await adapter.ask(invoiceCase("d1", "total", "167750"), 0, neverAbort());
  assert.deepEqual([failed.status, failed.retryable, failed.error], ["error", true, "キットが書類を読み取れませんでした（TypeError: fetch failed）。"]);
  assert.equal(anthropic.requests.length, 0);
  const again = await adapter.ask(invoiceCase("d1", "total", "167750"), 0, neverAbort());
  assert.deepEqual([again.status, again.answer], ["ok", "167750"]);
  assert.equal(anthropic.requests.length, 1, "同じ書類・同じ回でも読み直す");
  // 書類が無いのは、やり直しても直らない実行エラー
  const missing = await adapter.ask(caseOf({ id: "d9", question: "total", points: ["1"], document: join(FIXTURES, "docs", "missing.pdf"), documentLabel: "docs/missing.pdf", form: "invoice" }), 0, neverAbort());
  assert.deepEqual([missing.status, missing.retryable, missing.error], ["error", false, "書類 docs/missing.pdf を読めませんでした（ENOENT）。質問表の書類の場所をご確認ください。"]);
});

test("同じ書類を待つ 2 つの問いが、やり直せる失敗に当たっても、費用は 1 回だけ数える", async () => {
  const { adapter } = await setup();
  const fake = await fakeKit("doc-reader");
  fake.lateFaults.push(Object.assign(new TypeError("fetch failed"), { cause: { code: "ECONNRESET" } }));
  const answers = await Promise.all([invoiceCase("d1", "total", "167750"), invoiceCase("d2", "issuer", "さくら設備")].map((c) => adapter.ask(c, 0, neverAbort())));
  assert.deepEqual(answers.map((answer) => [answer.status, answer.retryable]), [["error", true], ["error", true]]);
  assert.deepEqual(answers.map((answer) => answer.usage.length), [1, 0]);
  const again = await adapter.ask(invoiceCase("d1", "total", "167750"), 0, neverAbort());
  assert.equal(again.status, "ok");
  assert.equal(again.usage.length, 1, "やり直しの読み取りの費用は数える");
});

test("キットには外へ出ない fetch を渡す（送り先の Webhook は渡していないが、念のため）", async () => {
  const { adapter, received } = await setup();
  await adapter.ask(invoiceCase("d1", "total", "167750"), 0, neverAbort());
  assert.equal(received[0].deps.fetch, noNetworkFetch);
});
