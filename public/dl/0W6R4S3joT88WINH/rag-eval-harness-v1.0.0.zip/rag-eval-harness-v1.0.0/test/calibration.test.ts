import { test } from "node:test";
import assert from "node:assert/strict";
import { createKeywordJudge } from "../src/judge/keyword.ts";
import { AGREEMENT_FLOOR, parseCalibration, runCalibration, runWiringCheck, type CalibrationItem } from "../src/judge/calibration.ts";
import { caseOf } from "./fixtures/helpers.ts";

const item = (partial: Partial<CalibrationItem> & { id: string }): CalibrationItem => ({ kind: "sample", note: "", question: "保証は何年ですか", points: ["2 年"], special: null, forbidden: [], answer: "", sources: [], label: "correct", ...partial });

test("較正: 採点者の判定と人の判定の一致率を出す（90% が発売の条件）", async () => {
  const items = parseCalibration(
    [
      item({ id: "c1", answer: "保証は 2 年です。", label: "correct" }),
      item({ id: "c2", answer: "保証は二年間です。", label: "correct" }),
      item({ id: "c3", answer: "分かりません。", label: "noAnswer", kind: "planted" }),
      item({ id: "c4", question: "太陽光は", points: [], special: "refuse", answer: "資料に載っていません。", label: "correct" }),
    ].map((row) => JSON.stringify(row)).join("\n"),
  );
  const result = await runCalibration(createKeywordJudge(), items);
  assert.deepEqual(result.rows.map((row) => [row.id, row.got, row.agree]), [["c1", "correct", true], ["c2", "wrong", false], ["c3", "noAnswer", true], ["c4", "correct", true]]);
  assert.deepEqual([result.agreed, result.total, result.agreement], [3, 4, 0.75]);
  assert.equal(AGREEMENT_FLOOR, 0.9);
  assert.throws(() => parseCalibration('{"id":"x"}'), /calibration\.jsonl の 1 行目の形が違います/);
});

test("正しい見本と空の見本: 要点をつないだ答えは正解、空の答えは正解以外。ずれたら問いを挙げる", async () => {
  const cases = [caseOf({ id: "q1", points: ["80 万円", "150 万円"] }), caseOf({ id: "q2", points: ["無料"] })];
  assert.deepEqual(await runWiringCheck(createKeywordJudge(), cases), { failures: [], checked: 4, usage: [] });
  const broken = createKeywordJudge();
  const alwaysCorrect = { info: broken.info, judge: async () => ({ ok: true as const, judgment: { declined: false, points: ["covered" as const, "covered" as const], forbidden: [], reason: "", incomplete: false }, usage: [], raw: null }) };
  const result = await runWiringCheck(alwaysCorrect, [cases[0]]);
  assert.deepEqual(result.failures, ["q1: 空の答えが「正解」になりました。"]);
});
