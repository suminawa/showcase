import { test } from "node:test";
import assert from "node:assert/strict";
import { costUsd, costYen, priceOf } from "../src/pricing.ts";
import { usageOf } from "./fixtures/helpers.ts";

test("usage の実数 × 値段の表。キャッシュ読みは 0.1 倍、書き込みは 5 分 1.25 倍・1 時間 2 倍", () => {
  assert.deepEqual(priceOf("claude-sonnet-5"), { input: 2, output: 10 });
  assert.equal(costUsd(usageOf("claude-opus-5", 1_000_000, 0)), 5);
  assert.equal(costUsd(usageOf("claude-opus-5", 0, 1_000_000)), 25);
  assert.equal(costUsd(usageOf("claude-sonnet-5", 0, 0, { cacheRead: 1_000_000 })), 0.2);
  assert.equal(costUsd(usageOf("claude-sonnet-5", 0, 0, { cacheWrite5m: 1_000_000 })), 2.5);
  assert.equal(costUsd(usageOf("claude-haiku-4-5", 0, 0, { cacheWrite1h: 1_000_000 })), 2);
  assert.equal(costYen([usageOf("claude-opus-5", 10_000, 1_000)], 150).yen, (10_000 * 5 + 1_000 * 25) / 1_000_000 * 150);
});

test("表に無いモデルは費用に入れず名前を返す。書き込みの数が分からない記録があれば「以上」", () => {
  const cost = costYen([usageOf("my-own-model", 1000, 100), usageOf("claude-sonnet-5", 1000, 100, { lowerBound: true })]);
  assert.deepEqual(cost.unknownModels, ["my-own-model"]);
  assert.equal(cost.lowerBound, true);
  assert.ok(cost.yen > 0);
  assert.equal(priceOf("gpt-x"), null);
});

test("モデル名は完全一致か、名前 + 8 桁の日付だけに当てる（claude-opus-5-1 のような偽の一致は避ける）", () => {
  assert.deepEqual(priceOf("claude-sonnet-5-20260101"), { input: 2, output: 10 });
  assert.equal(priceOf("claude-opus-5-1"), null);
});
