import { test } from "node:test";
import assert from "node:assert/strict";
import { redact } from "../src/redact.ts";

test("メールアドレスと電話番号を伏せる", () => {
  assert.equal(redact("連絡は info@example.com か 03-0000-1111 へ"), "連絡は ***@*** か *** へ");
  assert.equal(redact("携帯 090 0000 0001"), "携帯 ***");
  assert.equal(redact("03-0000-1234 まで"), "*** まで");
});

test("9 桁以上の数字を伏せ、8 桁までと金額は残す", () => {
  assert.equal(redact("口座 1234567890"), "口座 ***");
  assert.equal(redact("12345678 と 80 万円"), "12345678 と 80 万円");
  // 0 を含む 8 桁の金額。電話番号のパターンに数字の境目が無いと、内側の 0 から始まる部分だけ誤って伏せられる
  assert.equal(redact("10000000 円"), "10000000 円");
  assert.equal(redact("合計 30500000"), "合計 30500000");
});
