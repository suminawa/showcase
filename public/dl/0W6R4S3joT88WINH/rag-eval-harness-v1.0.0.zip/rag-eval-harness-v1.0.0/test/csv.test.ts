import { test } from "node:test";
import assert from "node:assert/strict";
import { CsvError, NOT_UTF8_MESSAGE, csvCell, decodeUtf8, parseCsv } from "../src/cases/csv.ts";

const bytes = (text: string) => new TextEncoder().encode(text);

test("BOM つきの UTF-8 は BOM を落として読む", () => {
  assert.equal(decodeUtf8(bytes("﻿id,質問\n")), "id,質問\n");
  assert.equal(decodeUtf8(bytes("id,質問\n")), "id,質問\n");
});

test("CRLF と LF のどちらでも行に分ける", () => {
  assert.deepEqual(parseCsv("a,b\r\n1,2\r\n"), [["a", "b"], ["1", "2"]]);
  assert.deepEqual(parseCsv("a,b\n1,2\n"), [["a", "b"], ["1", "2"]]);
});

test("引用の中の , と改行と \"\" を 1 つのセルとして読む", () => {
  const rows = parseCsv('質問,要点\n"料金は、いくら?","80 万円\n150 万円"\n"""見積もり""は無料",x\n');
  assert.deepEqual(rows[1], ["料金は、いくら?", "80 万円\n150 万円"]);
  assert.deepEqual(rows[2], ['"見積もり"は無料', "x"]);
});

test("末尾の空行は捨てる（途中の空行は残し、cases が飛ばす）", () => {
  assert.deepEqual(parseCsv("a\n1\n\n2\n\n\n"), [["a"], ["1"], [""], ["2"]]);
  assert.deepEqual(parseCsv("a,b\n1,2\n,\n"), [["a", "b"], ["1", "2"]]);
});

test("UTF-8 として読めなければ、保存のしかたを敬体で伝える", () => {
  const shiftJis = new Uint8Array([0x8e, 0xbf, 0x96, 0xe2]);
  assert.throws(() => decodeUtf8(shiftJis), (error: unknown) => error instanceof CsvError && error.message === NOT_UTF8_MESSAGE);
  assert.equal(NOT_UTF8_MESSAGE, "質問表を UTF-8 で保存してください（Excel は「CSV UTF-8（コンマ区切り）」）。");
});

test("閉じていない引用符は、始まった行を添えて止める", () => {
  assert.throws(() => parseCsv('a,b\n1,"2\n3\n'), /2 行目で、引用符（"）が閉じていません/);
});

test("最後の行に改行が無くても読む", () => {
  assert.deepEqual(parseCsv("a,b\n1,2"), [["a", "b"], ["1", "2"]]);
});

test("書き出し: 引用が要る値だけ囲み、式よけは = + - @ で始まる値に ' を付ける", () => {
  assert.equal(csvCell("ふつう"), "ふつう");
  assert.equal(csvCell('a,"b"'), '"a,""b"""');
  assert.equal(csvCell("=1+1", true), "'=1+1");
  assert.equal(csvCell("-5", true), "'-5");
  assert.equal(csvCell("@x", true), "'@x");
  assert.equal(csvCell("=1+1"), "=1+1");
});
