import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { FLAG_ROWS } from "../src/cli.ts";
import { HEADERS } from "../src/cases/cases.ts";
import { findInternal } from "./forbidden.ts";
import { PACKAGE_ROOT } from "./fixtures/helpers.ts";

const read = (path: string) => readFileSync(join(PACKAGE_ROOT, path), "utf8");
const README = read("README.ja.md");

/** 見出しの行から始まる表の 1 列目（次の空行まで） */
function firstColumn(markdown: string, headerRow: string): string[] {
  const start = markdown.indexOf(headerRow);
  assert.ok(start >= 0, `表が見つかりません: ${headerRow}`);
  const rows = markdown.slice(start).split("\n\n")[0].split("\n").slice(2);
  return rows.map((row) => row.split("|")[1].trim());
}

function filesUnder(dir: string): string[] {
  return readdirSync(join(PACKAGE_ROOT, dir)).sort().flatMap((name) => (statSync(join(PACKAGE_ROOT, dir, name)).isDirectory() ? filesUnder(join(dir, name)) : [join(dir, name)]));
}

test("README の旗の一覧と質問表の見出しの表が、cli.ts と cases.ts の実物と同じ並び", () => {
  const flags = firstColumn(README, "| 旗 | 既定 | 意味 |").flatMap((cell) => [...cell.matchAll(/`(--[a-z-]+)`/g)].map((m) => m[1]));
  assert.deepEqual(flags, FLAG_ROWS.flatMap((row) => row.names));
  const headers = firstColumn(README, "| 見出し | 必須 | 中身 |").map((cell) => cell.replace(/`/g, ""));
  assert.deepEqual(headers, [...HEADERS]);
  const english = firstColumn(read("README.md"), "| Header | Meaning |").flatMap((cell) => [...cell.matchAll(/`([^`]+)`/g)].map((m) => m[1]));
  assert.deepEqual(english, [...HEADERS]);
});

test("README に発売時の一致率（27/30 以上）が書いてあり、日英でそろう", () => {
  const ja = README.match(/人の判定との一致は (\d+)\/30 でした/);
  const en = read("README.md").match(/agreed with the human labels on (\d+)\/30/);
  assert.ok(ja !== null && en !== null, "Task 7 の judge:check の一致数を README に書いてください");
  assert.equal(ja[1], en[1]);
  assert.ok(Number(ja[1]) >= 27, `一致が 90% 未満です（${ja[1]}/30）`);
});

test("THIRD-PARTY-NOTICES の版とライセンスの全文が、入っている @anthropic-ai/sdk と 1 字も違わない", () => {
  const sections = [...read("THIRD-PARTY-NOTICES.md").matchAll(/^## (\S+) (\S+)（[^）]+）\n\n```\n([\s\S]*?)```$/gm)];
  assert.deepEqual(sections.map((m) => m[1]), ["@anthropic-ai/sdk"]);
  const [, name, version, text] = sections[0];
  const dir = join(PACKAGE_ROOT, "node_modules", name);
  assert.equal(JSON.parse(readFileSync(join(dir, "package.json"), "utf8")).version, version);
  assert.equal(JSON.parse(read("package.json")).dependencies[name], version, "package.json の版と同じ");
  assert.equal(text, readFileSync(join(dir, "LICENSE"), "utf8"));
});

test("公開物と、zip に入る src・cases・samples・examples・test・scripts に、内部の語・内部の場所・書きかけの印が無い", () => {
  const files = ["README.ja.md", "README.md", "LICENSE.md", "CHANGELOG.md", "THIRD-PARTY-NOTICES.md", ...["src", "cases", "samples", "examples", "test", "scripts"].flatMap(filesUnder)];
  for (const file of files) {
    if (file === join("test", "forbidden.ts")) continue;
    assert.equal(findInternal(read(file), { style: !file.startsWith(join("samples", "recorded")) }), null, `${file} に内部の語があります`);
  }
});
