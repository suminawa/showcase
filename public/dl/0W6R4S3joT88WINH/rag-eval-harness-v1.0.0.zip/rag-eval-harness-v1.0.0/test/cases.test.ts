import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { autoId, loadCasesFile, parseCases } from "../src/cases/cases.ts";
import { parseCsv } from "../src/cases/csv.ts";

const HEAD = "id,質問,期待する答えの要点,出典に含まれるべき文書,答えてはいけないこと,タグ,前の質問,書類,帳票の型,メモ";
const parse = (text: string, kit: Parameters<typeof parseCases>[1]["kit"] = null, exists: (path: string) => boolean = () => true) =>
  parseCases(parseCsv(text), { baseDir: "/cases", kit, exists });

test("必須の列が無い・必須のセルが空は、止めずに全部集めて行番号つきで返す", () => {
  assert.deepEqual(parse("id,質問\nq1,a\n").problems, [
    "見出しに「期待する答えの要点」の列がありません。1 行目に「期待する答えの要点」と書いてください（見出しは README の「質問表の書き方」の表のとおりです）。",
  ]);
  const { problems } = parse(`${HEAD}\nq1,,80 万円\nq2,料金は,\nq3,,\n`);
  assert.deepEqual(problems, [
    "2 行目: 「質問」が空です。",
    "3 行目: 「期待する答えの要点」が空です。資料に無い質問なら （答えない） と書いてください。",
    "4 行目: 「質問」が空です。",
    "4 行目: 「期待する答えの要点」が空です。資料に無い質問なら （答えない） と書いてください。",
  ]);
});

test("id が空なら q- と FNV-1a の 8 桁。行を並べ替えても同じ id になる", () => {
  const a = parse("質問,期待する答えの要点\n見積もりは無料ですか,無料\n保証は何年,2 年\n").cases;
  const b = parse("期待する答えの要点,質問\n2 年,保証は何年\n無料,見積もりは無料ですか\n").cases;
  assert.match(a[0].id, /^q-[0-9a-f]{8}$/);
  assert.equal(a[0].id, autoId("見積もりは無料ですか", null, null));
  assert.equal(a[0].id, b[1].id);
  assert.equal(a[1].id, b[0].id);
  assert.notEqual(autoId("合計", "a.pdf", "invoice"), autoId("合計", "b.pdf", "invoice"));
});

test("id の重なりと形の誤りを知らせる", () => {
  const { problems } = parse(`${HEAD}\nq1,a,x\nq1,b,y\nあ,c,z\n`);
  assert.deepEqual(problems, [
    "3 行目: id「q1」が 2 行目と重なっています。",
    "4 行目: id は英数・-・_ の 40 字までにしてください（いまの値: あ）。",
  ]);
  assert.deepEqual(parse("質問,期待する答えの要点\n同じ,x\n同じ,y\n").problems, ["3 行目: 2 行目と同じ質問です（id が重なります）。id の列に別の名前を書いてください。"]);
});

test("特別な値: （答えない）と半角の (答えない) を受け、括弧の無い綴りは直し方を伝える", () => {
  const { cases, problems } = parse(`${HEAD}\nq1,太陽光パネルは,（答えない）\nq2,駐車場は,(答えない)\nq3,評判は,答えない\nq4,担当者と,（引き継ぐ）\nq5,x,（答えない）｜80 万円\n`, "line-concierge");
  assert.equal(cases[0].special, "refuse");
  assert.deepEqual(cases[0].points, []);
  assert.equal(cases[1].special, "refuse");
  assert.equal(cases[3].special, "handoff");
  assert.deepEqual(problems, [
    "4 行目: 「答えない」は （答えない） と書いてください。",
    "6 行目: 特別な値（答えない・引き継ぐ・空）は、ほかの要点と並べずに 1 つだけ書いてください。",
  ]);
  assert.deepEqual(parse(`${HEAD}\nq1,担当者と,（引き継ぐ）\nq2,x,（空）\n`, "ai-concierge").problems, [
    "2 行目: （引き継ぐ）は LINE 窓口（--kit line-concierge）でだけ使えます。",
    "3 行目: （空）は書類読み取り（--kit doc-reader）でだけ使えます。",
  ]);
});

test("区切りは ｜ と | とセルの中の改行の 3 種。要点は 5 つまで", () => {
  const { cases, problems } = parse(`${HEAD}\nq1,料金,"80 万円｜150 万円|4 日\n6 日",料金|/price,カード払い\nq2,多い,a|b|c|d|e|f\n`);
  assert.deepEqual(cases[0].points, ["80 万円", "150 万円", "4 日", "6 日"]);
  assert.deepEqual(cases[0].sources, ["料金", "/price"]);
  assert.deepEqual(cases[0].forbidden, ["カード払い"]);
  assert.deepEqual(problems, ["3 行目: 要点は 5 つまでにしてください（いまは 6 つ）。"]);
});

test("要点のセルが区切りだけなら、空と同じく直すところにする", () => {
  const { problems } = parse(`${HEAD}\nq1,料金,｜|\n`);
  assert.deepEqual(problems, ["2 行目: 「期待する答えの要点」に区切り（| や ｜）しかありません。要点を書くか、資料に無い質問なら （答えない） と書いてください。"]);
});

test("タグは , と 、 の区切り。メモは読まず、知らない列は extras に入れる", () => {
  const { cases, unknownColumns } = parse("質問,期待する答えの要点,タグ,メモ,担当\n料金は,80 万円,\"料金, 断るべき\",人のための注記,営業\n保証は,2 年,保証、会社,,\n");
  assert.deepEqual(cases[0].tags, ["料金", "断るべき"]);
  assert.deepEqual(cases[1].tags, ["保証", "会社"]);
  assert.deepEqual(unknownColumns, ["担当"]);
  assert.deepEqual(cases[0].extras, { 担当: "営業" });
  assert.deepEqual(cases[1].extras, {});
});

test("前の質問は 1 つ。空なら null", () => {
  const { cases } = parse(`${HEAD}\nq1,工期は,4 日〜6 日,,,,キッチンの入れ替えはいくらですか\nq2,料金は,80 万円,,,,\n`);
  assert.equal(cases[0].previous, "キッチンの入れ替えはいくらですか");
  assert.equal(cases[1].previous, null);
});

test("doc-reader: 書類と帳票の型が要り、要点は 1 つ。書類が無ければ場所を添えて知らせる", () => {
  const exists = (path: string) => path === "/cases/docs/invoice-01.pdf";
  const { problems } = parse(`${HEAD}\nd1,total,167750,,,,,docs/invoice-01.pdf,invoice\nd2,total,1,,,,,docs/nothing.pdf,invoice\nd3,total,1|2,,,,,,\nd4,purpose,（空）,,,,,docs/invoice-01.pdf,receipt\n`, "doc-reader", exists);
  assert.deepEqual(problems, [
    "3 行目: 書類 docs/nothing.pdf が見つかりません（質問表のある場所からの相対で書いてください）。",
    "4 行目: 書類読み取りでは「書類」が要ります。",
    "4 行目: 書類読み取りでは「帳票の型」が要ります（invoice など、キットの forms/ の id）。",
    "4 行目: 書類読み取りでは、要点を 1 つ（期待する値）にしてください。",
  ]);
  assert.deepEqual(parse("質問,期待する答えの要点\ntotal,1\n", "doc-reader").problems, ["書類読み取りでは、見出しに「書類」の列が要ります。", "書類読み取りでは、見出しに「帳票の型」の列が要ります。"]);
});

test("書類の場所は質問表のあるフォルダからの相対（baseDir で変えられる）。sha256 も返す", () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-cases-"));
  try {
    mkdirSync(join(dir, "docs"));
    writeFileSync(join(dir, "docs", "a.pdf"), "x");
    writeFileSync(join(dir, "cases.csv"), `﻿${HEAD}\r\nd1,total,1,,,,,docs/a.pdf,invoice,\r\n`);
    const loaded = loadCasesFile(join(dir, "cases.csv"), { kit: "doc-reader" });
    assert.deepEqual(loaded.problems, []);
    assert.equal(loaded.cases[0].document, join(dir, "docs", "a.pdf"));
    assert.equal(loaded.cases[0].documentLabel, "docs/a.pdf");
    assert.match(loaded.sha256, /^[0-9a-f]{64}$/);
    const other = loadCasesFile(join(dir, "cases.csv"), { kit: "doc-reader", baseDir: "/elsewhere", exists: () => true });
    assert.equal(other.cases[0].document, "/elsewhere/docs/a.pdf");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
