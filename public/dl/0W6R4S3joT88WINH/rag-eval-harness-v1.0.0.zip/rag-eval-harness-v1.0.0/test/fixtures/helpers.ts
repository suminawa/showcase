import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import type { AdapterAnswer, CaseRecord, CaseResult, EvalCase, UsageRecord } from "../../src/types.ts";

/** 検査の置き場所 */
export const FIXTURES = fileURLToPath(new URL("./", import.meta.url));
export const FAKE_KITS = join(FIXTURES, "fake-kits");
export const PACKAGE_ROOT = fileURLToPath(new URL("../../", import.meta.url));

/** 偽のキットの dist/index.js（アダプタが import するのと同じ URL なので、同じものを見る） */
export async function fakeKit(name: "ai-concierge" | "line-concierge" | "doc-reader"): Promise<any> {
  return import(pathToFileURL(join(FAKE_KITS, name, "dist", "index.js")).href);
}

/** 質問表の 1 行を、足りない項目を既定で埋めて作る */
export function caseOf(partial: Partial<EvalCase> & { id: string }): EvalCase {
  return {
    line: 2,
    question: "質問",
    points: [],
    special: null,
    sources: [],
    forbidden: [],
    tags: [],
    previous: null,
    document: null,
    documentLabel: null,
    form: null,
    extras: {},
    ...partial,
  };
}

/** キットの答えを、足りない項目を既定で埋めて作る */
export function answerOf(partial: Partial<AdapterAnswer> = {}): AdapterAnswer {
  return { status: "ok", answer: "", sources: [], refused: null, handoff: null, retrieved: null, latencyMs: 1000, usage: [], model: "claude-opus-5", ...partial };
}

export const neverAbort = (): AbortSignal => new AbortController().signal;

/** 集計・差・出力の検査に使う 1 問の記録。判定と答えだけを指定して、残りを既定で埋める */
export function recordOf(id: string, partial: { verdict?: CaseResult["verdict"]; round?: number; special?: EvalCase["special"]; tags?: string[]; answer?: Partial<AdapterAnswer>; result?: Partial<CaseResult>; judgeUsage?: UsageRecord[]; points?: string[] } = {}): CaseRecord {
  const c = caseOf({ id, question: `${id} の質問`, points: partial.points ?? (partial.special ? [] : ["要点"]), special: partial.special ?? null, tags: partial.tags ?? [] });
  const answer = answerOf({ answer: `${id} の答え`, refused: false, ...partial.answer });
  return {
    case: c,
    answer,
    judge: partial.judgeUsage === undefined ? null : { ok: true, judgment: { declined: false, points: ["covered"], forbidden: [], reason: "", incomplete: false }, usage: partial.judgeUsage, raw: "{}" },
    result: {
      id,
      round: partial.round ?? 0,
      tags: partial.tags ?? [],
      verdict: partial.verdict ?? "correct",
      points: c.points.map((text) => ({ text, status: partial.verdict === "correct" ? "covered" : "missing" })),
      forbidden: [],
      citationHit: null,
      retrievalHit: null,
      refused: answer.refused,
      handoff: answer.handoff,
      latencyMs: answer.latencyMs,
      attempts: 1,
      reason: "",
      judgedBy: "claude",
      incomplete: false,
      ...partial.result,
    },
  };
}

export const usageOf = (model: string, input: number, output: number, extra: Partial<UsageRecord> = {}): UsageRecord => ({ model, input, output, cacheRead: 0, cacheWrite5m: 0, cacheWrite1h: 0, lowerBound: false, ...extra });
