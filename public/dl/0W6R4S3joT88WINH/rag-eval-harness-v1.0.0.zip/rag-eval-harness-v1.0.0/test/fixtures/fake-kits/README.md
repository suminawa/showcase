# 偽のキット（検査用）

3 キットの公開の入口（`dist/index.js` と `package.json`）の名前と形だけを真似た偽物です。アダプタの検査が、本物のキットや Anthropic を呼ばずに走るように使います。本物との食い違いは `test/contract.test.ts`（モノレポの中だけ）が見張ります。
