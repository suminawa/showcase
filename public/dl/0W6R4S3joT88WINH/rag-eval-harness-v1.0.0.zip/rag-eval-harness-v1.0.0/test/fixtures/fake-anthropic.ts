/**
 * 偽の Anthropic client。決めた答え（文・出典・stop_reason・model・usage・失敗）を返し、受け取った要求を requests に残す。
 * messages.stream（案内窓口・LINE 窓口）、messages.create（書類読み取り・採点）、beta.messages.create（opus 5 の採点）の 3 つを持つ
 */
export interface FakeReply {
  text?: string;
  /** citations_delta で流す document_index（0 から） */
  citations?: number[];
  stopReason?: string;
  model?: string;
  usage?: Record<string, unknown>;
  error?: { status?: number; name?: string; message?: string };
  /** usage.iterations に入れる（fallback の印） */
  iterations?: Array<{ type: string }>;
}

export type FakeScript = (params: any, call: number) => FakeReply;

function failure(reply: FakeReply): Error {
  const error = new Error(reply.error?.message ?? "fake failure");
  error.name = reply.error?.name ?? "APIError";
  return Object.assign(error, { status: reply.error?.status });
}

export function messageOf(params: any, reply: FakeReply): any {
  return {
    id: "msg_fake",
    type: "message",
    role: "assistant",
    model: reply.model ?? params.model,
    stop_reason: reply.stopReason ?? "end_turn",
    stop_details: null,
    content: [{ type: "text", text: reply.text ?? "", citations: null }],
    usage: {
      input_tokens: 1000,
      output_tokens: 100,
      cache_read_input_tokens: 0,
      cache_creation_input_tokens: 0,
      cache_creation: { ephemeral_5m_input_tokens: 0, ephemeral_1h_input_tokens: 0 },
      ...(reply.iterations === undefined ? {} : { iterations: reply.iterations }),
      ...reply.usage,
    },
  };
}

export function fakeAnthropic(script: FakeScript) {
  const requests: any[] = [];
  const create = async (params: any) => {
    requests.push(params);
    const reply = script(params, requests.length);
    if (reply.error !== undefined) throw failure(reply);
    return messageOf(params, reply);
  };
  const client = {
    messages: {
      stream(params: any) {
        requests.push(params);
        const reply = script(params, requests.length);
        return {
          async *[Symbol.asyncIterator]() {
            if (reply.error !== undefined) throw failure(reply);
            const text = reply.text ?? "";
            // 2 字ずつ流す（本物のストリームと同じく、答えは細切れで届く）
            for (let i = 0; i < text.length; i += 2) yield { type: "content_block_delta", index: 0, delta: { type: "text_delta", text: text.slice(i, i + 2) } };
            for (const index of reply.citations ?? []) {
              yield { type: "content_block_delta", index: 0, delta: { type: "citations_delta", citation: { type: "char_location", document_index: index, cited_text: "x" } } };
            }
          },
          async finalMessage() {
            if (reply.error !== undefined) throw failure(reply);
            return messageOf(params, reply);
          },
          abort() {},
        };
      },
      create,
    },
    beta: { messages: { create } },
  };
  return { client, requests };
}
