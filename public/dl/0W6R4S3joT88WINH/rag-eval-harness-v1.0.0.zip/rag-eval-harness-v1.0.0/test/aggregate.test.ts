import { test } from "node:test";
import assert from "node:assert/strict";
import { aggregate, percentile } from "../src/score/aggregate.ts";
import { recordOf, usageOf } from "./fixtures/helpers.ts";

const options = { yenPerUsd: 150, kit: "ai-concierge" as const };

test("正答率 = (正解 + 部分 × 0.5) ÷ 採点できた問い。実行エラーと採点エラーは分母に入れない", () => {
  const summary = aggregate([
    recordOf("a", { verdict: "correct" }),
    recordOf("b", { verdict: "partial" }),
    recordOf("c", { verdict: "wrong" }),
    recordOf("d", { verdict: "noAnswer" }),
    recordOf("e", { verdict: "error", result: { reason: "529" } }),
    recordOf("f", { verdict: "judgeError", result: { reason: "壊れた JSON" } }),
  ], options);
  assert.equal(summary.score, 1.5 / 4);
  assert.equal(summary.correctRate, 1 / 4);
  assert.deepEqual(summary.counts, { correct: 1, partial: 1, wrong: 1, noAnswer: 1, error: 1, judgeError: 1 });
  assert.deepEqual([summary.graded, summary.total], [4, 6]);
  assert.deepEqual(summary.errors, [{ id: "e", round: 0, reason: "529" }]);
  assert.deepEqual(summary.judgeErrors, [{ id: "f", round: 0, reason: "壊れた JSON" }]);
});

test("時間はキットの ms の中央値と 95 パーセンタイル（実行エラーは除く）", () => {
  assert.equal(percentile([5, 1, 3, 2, 4], 50), 3);
  assert.equal(percentile(Array.from({ length: 20 }, (_, i) => i + 1), 95), 19);
  const summary = aggregate([1000, 2000, 3000, 4000].map((ms, i) => recordOf(`q${i}`, { answer: { latencyMs: ms } })).concat(recordOf("x", { verdict: "error", answer: { status: "error", latencyMs: 90000 } })), options);
  assert.deepEqual(summary.latencyMs, { p50: 2000, p95: 4000 });
});

test("打ち切りの印の usage.model（unknown）は、値段の表に無いモデルとして summary.unknownModels に出さない", () => {
  const summary = aggregate(
    [
      recordOf("a", { answer: { usage: [usageOf("unknown", 0, 0, { lowerBound: true })] } }),
      recordOf("b", { answer: { usage: [usageOf("mystery-model", 100, 10)] } }),
    ],
    options,
  );
  assert.deepEqual(summary.unknownModels, ["mystery-model"]);
});

test("タグ別の正答率と件数", () => {
  const summary = aggregate([recordOf("a", { tags: ["料金", "断るべき"] }), recordOf("b", { tags: ["料金"], verdict: "wrong" }), recordOf("c", { tags: ["保証"], verdict: "partial" })], options);
  assert.deepEqual(summary.tags, [
    { tag: "料金", score: 0.5, count: 2 },
    { tag: "断るべき", score: 1, count: 1 },
    { tag: "保証", score: 0.5, count: 1 },
  ]);
});

test("分母が 0 の率は null（根拠・検索・断り・時間・正答率）", () => {
  const summary = aggregate([recordOf("e", { verdict: "error", answer: { status: "error" } })], options);
  assert.equal(summary.score, null);
  assert.equal(summary.correctRate, null);
  assert.equal(summary.citationHit, null);
  assert.equal(summary.retrievalHit, null);
  assert.deepEqual(summary.refusal, { shouldRefuse: 0, refusedWhenShould: null, overRefused: null });
  assert.deepEqual(summary.latencyMs, { p50: null, p95: null });
  assert.equal(summary.handoff, null);
});

test("費用はキットと採点を分けて円で。1 問あたりはキットの分 ÷ 問いの数", () => {
  const summary = aggregate([
    recordOf("a", { answer: { usage: [usageOf("claude-opus-5", 10_000, 1_000)] }, judgeUsage: [usageOf("claude-sonnet-5", 2_000, 100)] }),
    recordOf("b", { answer: { usage: [usageOf("claude-opus-5", 10_000, 1_000)] } }),
  ], options);
  const kit = 2 * ((10_000 * 5 + 1_000 * 25) / 1_000_000) * 150;
  const judge = ((2_000 * 2 + 100 * 10) / 1_000_000) * 150;
  assert.ok(Math.abs(summary.costJpy.kit - kit) < 1e-9);
  assert.ok(Math.abs(summary.costJpy.judge - judge) < 1e-9);
  assert.ok(Math.abs((summary.costJpy.perQuestion ?? 0) - kit / 2) < 1e-9);
  assert.equal(summary.costLowerBound, false);
});

test("断りの正しさ・引き継ぎ・禁止の違反・根拠と検索の当たり、--repeat は回ごとの平均と幅", () => {
  const summary = aggregate([
    recordOf("r1", { special: "refuse", verdict: "correct" }),
    recordOf("r2", { special: "refuse", verdict: "wrong" }),
    recordOf("n1", { verdict: "noAnswer", result: { citationHit: null } }),
    recordOf("n2", { verdict: "correct", result: { citationHit: true, retrievalHit: true, forbidden: [{ text: "無料", violated: true, review: false, quote: "無料" }] } }),
    recordOf("n3", { verdict: "correct", result: { citationHit: false, retrievalHit: true, forbidden: [{ text: "x", violated: false, review: true, quote: "" }] } }),
    recordOf("h1", { special: "handoff", verdict: "correct", answer: { handoff: true } }),
    recordOf("n4", { verdict: "wrong", answer: { handoff: true } }),
  ], { yenPerUsd: 150, kit: "line-concierge" });
  assert.deepEqual(summary.refusal, { shouldRefuse: 2, refusedWhenShould: 0.5, overRefused: 1 / 4 });
  assert.deepEqual(summary.handoff, { shouldHandoff: 1, handedOffWhenShould: 1, unexpected: 1 });
  assert.deepEqual(summary.forbidden, { violated: 1, review: 1 });
  assert.deepEqual([summary.citationHit, summary.retrievalHit], [0.5, 1]);
  const repeated = aggregate([recordOf("a", { round: 0 }), recordOf("b", { round: 0, verdict: "wrong" }), recordOf("a", { round: 1 }), recordOf("b", { round: 1 })], options);
  assert.deepEqual([repeated.score, repeated.scoreRange, repeated.rounds], [0.75, { min: 0.5, max: 1 }, 2]);
});
