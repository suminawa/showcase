import { test } from "node:test";
import assert from "node:assert/strict";
import { callFailure, modelMismatch, recordCreate, recordStream, usageOfCalls, type CallRecord } from "../src/adapters/recording-client.ts";
import { fakeAnthropic } from "./fixtures/fake-anthropic.ts";

test("stream: 答えはそのまま流し、最後のメッセージの usage（書き込みの 5 分と 1 時間）と model を記録する", async () => {
  const { client } = fakeAnthropic(() => ({ text: "こんにちは", usage: { input_tokens: 50, output_tokens: 7, cache_read_input_tokens: 900, cache_creation: { ephemeral_5m_input_tokens: 300, ephemeral_1h_input_tokens: 20 } } }));
  const calls: CallRecord[] = [];
  const stream = recordStream(client, calls).messages.stream({ model: "claude-opus-5" });
  let text = "";
  for await (const event of stream) text += event.delta.text;
  const final = await stream.finalMessage();
  assert.equal(text, "こんにちは");
  assert.equal(final.model, "claude-opus-5");
  assert.deepEqual(usageOfCalls(calls), [{ model: "claude-opus-5", input: 50, output: 7, cacheRead: 900, cacheWrite5m: 300, cacheWrite1h: 20, lowerBound: false }]);
  assert.equal(modelMismatch(calls), null);
  assert.equal(callFailure(calls), null);
});

test("create: 失敗は状態を記録してそのまま投げる。529 はやり直せる、別の model は食い違いとして返す", async () => {
  const { client } = fakeAnthropic((params) => (params.max_tokens === 1 ? { error: { status: 529, message: "overloaded" } } : { text: "{}", model: "claude-sonnet-5" }));
  const calls: CallRecord[] = [];
  const recorded = recordCreate(client, calls);
  await assert.rejects(recorded.messages.create({ model: "claude-opus-5", max_tokens: 1 }), /overloaded/);
  assert.deepEqual(callFailure(calls), { error: "Anthropic の呼び出しが失敗しました（HTTP 529）。", retryable: true });
  await recorded.messages.create({ model: "claude-opus-5", max_tokens: 10 });
  assert.equal(modelMismatch(calls), "応答のモデル（claude-sonnet-5）が、キットが頼んだモデル（claude-opus-5）と違います。");
  const bad: CallRecord[] = [];
  await assert.rejects(recordCreate(fakeAnthropic(() => ({ error: { status: 400 } })).client, bad).messages.create({ model: "m" }));
  assert.equal(callFailure(bad)?.retryable, false);
});

test("model は、そのままの一致か日付（-YYYYMMDD）付きだけを同じとみなす（claude-opus-5 に claude-opus-5-5 は別）", async () => {
  const mismatchOf = async (answered: string) => {
    const calls: CallRecord[] = [];
    await recordCreate(fakeAnthropic(() => ({ text: "{}", model: answered })).client, calls).messages.create({ model: "claude-opus-5" });
    return modelMismatch(calls);
  };
  assert.equal(await mismatchOf("claude-opus-5"), null);
  assert.equal(await mismatchOf("claude-opus-5-20260101"), null);
  assert.equal(await mismatchOf("claude-opus-5-5"), "応答のモデル（claude-opus-5-5）が、キットが頼んだモデル（claude-opus-5）と違います。");
  assert.notEqual(await mismatchOf("claude-opus-5-2026"), null);
});
