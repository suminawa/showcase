import { test } from "node:test";
import assert from "node:assert/strict";
import { errorAnswer } from "../src/adapters/common.ts";
import { createKeywordJudge } from "../src/judge/keyword.ts";
import { costYen } from "../src/pricing.ts";
import { runCases } from "../src/run.ts";
import { aggregate } from "../src/score/aggregate.ts";
import type { Adapter, AdapterAnswer, EvalCase, Judge } from "../src/types.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

function adapterOf(ask: (c: EvalCase, round: number, signal: AbortSignal) => Promise<AdapterAnswer>): Adapter {
  return { info: { name: "http", label: "窓口（127.0.0.1）", mode: "http", version: null, model: null }, notes: [], ask };
}
const cases = ["a", "b", "c", "d"].map((id) => caseOf({ id, question: `${id}?`, points: ["はい"] }));

test("同時は concurrency 個まで。送り始めは intervalMs ずつ空ける", async () => {
  let running = 0;
  let most = 0;
  const adapter = adapterOf(async () => {
    running += 1;
    most = Math.max(most, running);
    await new Promise((resolve) => setTimeout(resolve, 5));
    running -= 1;
    return answerOf({ answer: "はい", refused: false });
  });
  await runCases({ cases, adapter, judge: createKeywordJudge(), concurrency: 2, intervalMs: 0, repeat: 1 });
  assert.equal(most, 2);
  const waits: number[] = [];
  let clock = 0;
  await runCases({ cases, adapter, judge: createKeywordJudge(), concurrency: 1, intervalMs: 7000, repeat: 1, now: () => clock, sleep: async (ms) => { waits.push(ms); clock += ms; } });
  assert.deepEqual(waits, [7000, 7000, 7000]);
});

test("1 問 90 秒（timeoutMs）で打ち切り、signal を止めて実行エラーにする", async () => {
  let aborted = false;
  const adapter = adapterOf((_c, _round, signal) => new Promise(() => signal.addEventListener("abort", () => (aborted = true))));
  const [record] = await runCases({ cases: [cases[0]], adapter, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, timeoutMs: 20 });
  assert.equal(aborted, true);
  assert.deepEqual([record.result.verdict, record.answer.error], ["error", "0 秒で打ち切りました。"]);
});

test("やり直せる失敗は 1・3・9 秒（ゆらぎつき）で 3 回まで。試行回数を残す", async () => {
  let calls = 0;
  const flaky = adapterOf(async () => (++calls < 3 ? errorAnswer("窓口が 503 を返しました。", { retryable: true }) : answerOf({ answer: "はい", refused: false })));
  const waits: number[] = [];
  const [ok] = await runCases({ cases: [cases[0]], adapter: flaky, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, random: () => 0, sleep: async (ms) => void waits.push(ms) });
  assert.deepEqual([ok.result.verdict, ok.result.attempts, waits], ["correct", 3, [800, 2400]]);
  const always = adapterOf(async () => errorAnswer("窓口が 429 を返しました。", { retryable: true }));
  const [failed] = await runCases({ cases: [cases[0]], adapter: always, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, sleep: async () => {} });
  assert.deepEqual([failed.result.verdict, failed.result.attempts], ["error", 4]);
  const fatal = adapterOf(async () => errorAnswer("窓口が 404 を返しました。"));
  const [once] = await runCases({ cases: [cases[0]], adapter: fatal, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, sleep: async () => {} });
  assert.equal(once.result.attempts, 1);
});

test("--repeat は問いごとに回を並べ、採点者は決まりで決まらない問いだけを呼ぶ", async () => {
  const judged: string[] = [];
  const keyword = createKeywordJudge();
  const judge: Judge = { info: keyword.info, judge: async (c, a, round) => (judged.push(`${c.id}#${round}`), keyword.judge(c, a, round)) };
  const refuse = caseOf({ id: "r", question: "太陽光は", special: "refuse" });
  const adapter = adapterOf(async (c) => answerOf({ answer: c.special === "refuse" ? "資料に載っていません。" : "はい", refused: c.special === "refuse" }));
  const records = await runCases({ cases: [cases[0], refuse], adapter, judge, concurrency: 2, intervalMs: 0, repeat: 2 });
  assert.deepEqual(records.map((record) => `${record.case.id}#${record.result.round}`), ["a#0", "a#1", "r#0", "r#1"]);
  assert.deepEqual(judged.sort(), ["a#0", "a#1"]);
  assert.deepEqual(records.map((record) => record.result.judgedBy), ["keyword", "keyword", "rule", "rule"]);
});

test("窓口が reject しても実行エラーの答えにして、回し終える", async () => {
  const adapter = adapterOf(async () => {
    throw new Error("接続が切れました。");
  });
  const records = await runCases({ cases: [cases[0]], adapter, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, sleep: async () => {} });
  assert.equal(records.length, 1);
  assert.equal(records[0].result.verdict, "error");
  assert.match(records[0].answer.error ?? "", /接続が切れました/);
});

test("同期の throw をする ask（async でない）も実行エラーにする（そのまま投げて回し全体を止めない）", async () => {
  const adapter: Adapter = {
    info: { name: "http", label: "窓口（127.0.0.1）", mode: "http", version: null, model: null },
    notes: [],
    ask: () => {
      throw new Error("設定を読む前に落ちました。");
    },
  };
  const records = await runCases({ cases: [cases[0]], adapter, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, sleep: async () => {} });
  assert.equal(records.length, 1);
  assert.equal(records[0].result.verdict, "error");
  assert.match(records[0].answer.error ?? "", /設定を読む前に落ちました/);
});

test("打ち切ったあとにキットの答えが遅れて届いても、記録は 1 つだけ・onAnswer は 1 回だけ", async () => {
  const adapter = adapterOf((_c, _round) => new Promise((resolve) => setTimeout(() => resolve(answerOf({ answer: "遅い", refused: false })), 40)));
  let onAnswerCalls = 0;
  const records = await runCases({
    cases: [cases[0]],
    adapter,
    judge: createKeywordJudge(),
    concurrency: 1,
    intervalMs: 0,
    repeat: 1,
    timeoutMs: 10,
    onAnswer: () => {
      onAnswerCalls += 1;
    },
  });
  assert.equal(records.length, 1);
  assert.equal(records[0].result.verdict, "error");
  assert.equal(onAnswerCalls, 1);
  await new Promise((resolve) => setTimeout(resolve, 60)); // 遅れて届く答えが済むのを待つ
  assert.equal(onAnswerCalls, 1);
});

test("打ち切ったときの usage は「以上」の印がつく（signal を見ないキットは裏で呼び出しが続くかもしれないため）", async () => {
  const adapter = adapterOf(() => new Promise(() => {}));
  const [record] = await runCases({ cases: [cases[0]], adapter, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1, timeoutMs: 10 });
  assert.equal(record.answer.status, "error");
  assert.equal(costYen(record.answer.usage).lowerBound, true);
});

test("採点者が投げても採点エラーとして記録し、回し終える", async () => {
  const throwingJudge: Judge = {
    info: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" },
    judge: async () => {
      throw new Error("採点サーバが落ちました。");
    },
  };
  const adapter = adapterOf(async () => answerOf({ answer: "はい", refused: false }));
  const records = await runCases({ cases: [cases[0]], adapter, judge: throwingJudge, concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(records.length, 1);
  assert.equal(records[0].result.verdict, "judgeError");
  assert.match(records[0].result.reason, /採点サーバが落ちました/);
});

test("cases が空なら何も回さず空の配列を返す", async () => {
  const adapter = adapterOf(async () => answerOf({ answer: "はい", refused: false }));
  const records = await runCases({ cases: [], adapter, judge: createKeywordJudge(), concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.deepEqual(records, []);
});

test("aggregate: records が空なら率は null、件数は 0 の Summary を返す", () => {
  const summary = aggregate([], { yenPerUsd: 150, kit: "ai-concierge" });
  assert.deepEqual(summary, {
    score: null,
    scoreRange: null,
    correctRate: null,
    counts: { correct: 0, partial: 0, wrong: 0, noAnswer: 0, error: 0, judgeError: 0 },
    graded: 0,
    total: 0,
    citationHit: null,
    retrievalHit: null,
    refusal: { shouldRefuse: 0, refusedWhenShould: null, overRefused: null },
    handoff: null,
    forbidden: { violated: 0, review: 0 },
    latencyMs: { p50: null, p95: null },
    costJpy: { kit: 0, judge: 0, perQuestion: null },
    costLowerBound: false,
    unknownModels: [],
    tags: [],
    errors: [],
    judgeErrors: [],
    rounds: 1,
  });
});
