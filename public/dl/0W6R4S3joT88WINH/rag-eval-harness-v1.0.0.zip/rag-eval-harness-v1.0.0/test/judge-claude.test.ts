import { test } from "node:test";
import assert from "node:assert/strict";
import { runFirstThenPool } from "../src/concurrency.ts";
import { FALLBACK_BETA, JUDGE_CONCURRENCY, buildJudgeRequest, createClaudeJudge } from "../src/judge/claude.ts";
import { RUBRIC } from "../src/judge/prompt.ts";
import { JUDGE_SCHEMA } from "../src/judge/schema.ts";
import { fakeAnthropic, type FakeScript } from "./fixtures/fake-anthropic.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

const c = caseOf({ id: "q1", question: "保証は何年ですか", points: ["施工 2 年", "構造 10 年"] });
const a = answerOf({ answer: "施工は 2 年、構造は 10 年です。", refused: false });
const GOOD = JSON.stringify({ declined: false, points: [{ index: 1, status: "covered" }, { index: 2, status: "covered" }], forbidden: [], reason: "両方を述べています。" });

function judgeWith(script: FakeScript, model = "claude-sonnet-5") {
  const anthropic = fakeAnthropic(script);
  const waits: number[] = [];
  const judge = createClaudeJudge({ client: anthropic.client, model, effort: "low", sleep: async (ms) => void waits.push(ms), random: () => 0.5 });
  return { judge, anthropic, waits };
}

test("要求の形: model・max_tokens 2048・effort low・output_config.format（json_schema）・system の cache_control", async () => {
  const { judge, anthropic } = judgeWith(() => ({ text: GOOD }));
  const outcome = await judge.judge(c, a, 0);
  assert.ok(outcome.ok);
  const params = anthropic.requests[0];
  assert.equal(params.model, "claude-sonnet-5");
  assert.equal(params.max_tokens, 2048);
  assert.deepEqual(params.output_config, { effort: "low", format: { type: "json_schema", schema: JUDGE_SCHEMA } });
  assert.deepEqual(params.system, [{ type: "text", text: RUBRIC, cache_control: { type: "ephemeral" } }]);
  assert.equal(params.thinking, undefined);
  assert.equal(params.betas, undefined);
  assert.equal(outcome.usage.length, 1);
  assert.deepEqual(judge.info, { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" });
});

test("haiku 4.5 には effort を送らない。opus 5 は beta で fallbacks: default を付け、予備のモデルの答えも受ける", async () => {
  assert.deepEqual(buildJudgeRequest("claude-haiku-4-5", "low", c, a).params.output_config, { format: { type: "json_schema", schema: JUDGE_SCHEMA } });
  const opus = buildJudgeRequest("claude-opus-5", "low", c, a);
  assert.equal(opus.beta, true);
  assert.deepEqual([opus.params.betas, opus.params.fallbacks], [[FALLBACK_BETA], "default"]);
  const { judge } = judgeWith(() => ({ text: GOOD, model: "claude-opus-4-8", iterations: [{ type: "fallback_message" }] }), "claude-opus-5");
  const outcome = await judge.judge(c, a, 0);
  assert.equal(outcome.ok, true);
});

test("最初の 1 件の応答を受けてから、残りを同時 4 で送る", async () => {
  let running = 0;
  let most = 0;
  const started: number[] = [];
  let firstDone = false;
  const order: string[] = [];
  await runFirstThenPool([0, 1, 2, 3, 4, 5, 6, 7], JUDGE_CONCURRENCY, async (item) => {
    started.push(item);
    if (item !== 0) assert.ok(firstDone, "2 件目以降は、最初の 1 件の応答の後");
    running += 1;
    most = Math.max(most, running);
    await new Promise((resolve) => setTimeout(resolve, 5));
    running -= 1;
    if (item === 0) firstDone = true;
    order.push(String(item));
    return item;
  });
  assert.equal(most, 4);
  assert.equal(order[0], "0");
});

test("max_tokens か refusal で止まったら、max_tokens 4096 で 1 回だけやり直す。だめなら採点エラー", async () => {
  const { judge, anthropic } = judgeWith((_params, call) => (call === 1 ? { text: '{"declined":', stopReason: "max_tokens" } : { text: GOOD }));
  const outcome = await judge.judge(c, a, 0);
  assert.ok(outcome.ok);
  assert.deepEqual(anthropic.requests.map((params) => params.max_tokens), [2048, 4096]);
  assert.equal(outcome.usage.length, 2, "やり直しの費用も数える");
  const broken = judgeWith(() => ({ text: "", stopReason: "refusal" }));
  const failed = await broken.judge.judge(c, a, 0);
  assert.deepEqual([failed.ok, broken.anthropic.requests.length], [false, 2]);
  assert.ok(!failed.ok && failed.error === "採点が途中で止まりました（stop_reason: refusal）。");
});

test("529 は 1・3・9 秒（ゆらぎつき）で 3 回までやり直す。別の model が答えたら採点エラー", async () => {
  const busy = judgeWith((_params, call) => (call <= 3 ? { error: { status: 529 } } : { text: GOOD }));
  assert.equal((await busy.judge.judge(c, a, 0)).ok, true);
  assert.deepEqual(busy.waits, [1000, 3000, 9000]);
  const down = judgeWith(() => ({ error: { status: 500 } }));
  const failed = await down.judge.judge(c, a, 0);
  assert.ok(!failed.ok && failed.error === "採点の呼び出しが失敗しました（HTTP 500）。");
  assert.equal(down.anthropic.requests.length, 4);
  const other = judgeWith(() => ({ text: GOOD, model: "claude-haiku-4-5" }));
  const mismatch = await other.judge.judge(c, a, 0);
  assert.ok(!mismatch.ok && mismatch.error === "採点のモデル（claude-haiku-4-5）が、頼んだモデル（claude-sonnet-5）と違います。");
  const longer = judgeWith(() => ({ text: GOOD, model: "claude-sonnet-5-5" }));
  const notSame = await longer.judge.judge(c, a, 0);
  assert.ok(!notSame.ok && notSame.error === "採点のモデル（claude-sonnet-5-5）が、頼んだモデル（claude-sonnet-5）と違います。");
  const dated = judgeWith(() => ({ text: GOOD, model: "claude-sonnet-5-20261001" }));
  assert.equal((await dated.judge.judge(c, a, 0)).ok, true, "日付つきの名前は受ける");
  const denied = judgeWith(() => ({ error: { status: 401 } }));
  await denied.judge.judge(c, a, 0);
  assert.equal(denied.anthropic.requests.length, 1, "401 はやり直さない");
});
