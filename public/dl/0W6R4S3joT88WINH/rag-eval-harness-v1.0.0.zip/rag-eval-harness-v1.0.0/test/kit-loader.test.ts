import { test } from "node:test";
import assert from "node:assert/strict";
import { cpSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { loadKit } from "../src/adapters/kit-loader.ts";
import { HarnessError } from "../src/errors.ts";

const FAKE = fileURLToPath(new URL("./fixtures/fake-kits/", import.meta.url));

test("dist が無い・別のキットのフォルダは、終了コード 2 の敬体の文で止める", async () => {
  await assert.rejects(loadKit("ai-concierge", join(FAKE, "nothing")), (error: unknown) => {
    assert.ok(error instanceof HarnessError);
    assert.equal(error.exitCode, 2);
    assert.match(error.message, /^キットのフォルダに package\.json か dist\/index\.js が見つかりません（.+）。--kit-dir に、キットの zip を展開したフォルダを指定してください。$/);
    return true;
  });
  await assert.rejects(loadKit("doc-reader", join(FAKE, "ai-concierge")), /--kit-dir のフォルダは @suminawa\/doc-reader ではありません（package.json の name: @suminawa\/ai-concierge）。/);
});

test("1.0.x 以外の版は警告して続ける", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-kit-"));
  try {
    cpSync(join(FAKE, "ai-concierge"), dir, { recursive: true });
    writeFileSync(join(dir, "package.json"), JSON.stringify({ name: "@suminawa/ai-concierge", version: "1.1.0", type: "module" }));
    const kit = await loadKit("ai-concierge", dir);
    assert.equal(kit.version, "1.1.0");
    assert.deepEqual(kit.warnings, ["キットの版 1.1.0 は、動作を確かめた版（1.0.x）と違います。続けますが、結果が想定と違うときはキットの版をご確認ください。"]);
    assert.deepEqual((await loadKit("ai-concierge", join(FAKE, "ai-concierge"))).warnings, []);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("使う名前が無ければ、どの名前かを添えて止める", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-kit-"));
  try {
    cpSync(join(FAKE, "ai-concierge"), dir, { recursive: true });
    writeFileSync(join(dir, "dist", "index.js"), "export const loadConfigFile = () => undefined;\n");
    await assert.rejects(loadKit("ai-concierge", dir), (error: unknown) => {
      assert.ok(error instanceof HarnessError);
      assert.equal(error.message, "キットの版が想定と違います（createConcierge が見つかりません）。キットのフォルダの場所と版をご確認ください。");
      return true;
    });
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("package.json が JSON として読めなければ、終了コード 2 の敬体の文で止める", async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-kit-"));
  try {
    cpSync(join(FAKE, "ai-concierge"), dir, { recursive: true });
    writeFileSync(join(dir, "package.json"), '{ "name": "@suminawa/ai-concierge", ');
    await assert.rejects(loadKit("ai-concierge", dir), (error: unknown) => {
      assert.ok(error instanceof HarnessError);
      assert.equal(error.exitCode, 2);
      assert.match(error.message, /^キットのフォルダの package\.json を読めませんでした（.+）。--kit-dir に、キットの zip を展開したフォルダを指定してください。$/);
      return true;
    });
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
