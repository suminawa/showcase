import { test } from "node:test";
import assert from "node:assert/strict";
import { JUDGE_SCHEMA, parseJudge } from "../src/judge/schema.ts";

const answer = "キッチンは 80 万円からです。クレジットカードで払えます。";

test("正しい答えはそのまま読む。形は設計書の JSON Schema", () => {
  assert.deepEqual(JUDGE_SCHEMA.required, ["declined", "points", "forbidden", "reason"]);
  assert.deepEqual(JUDGE_SCHEMA.properties.points.items.properties.status.enum, ["covered", "missing", "contradicted"]);
  const parsed = parseJudge(JSON.stringify({ declined: false, points: [{ index: 1, status: "covered" }, { index: 2, status: "missing" }], forbidden: [{ index: 1, violated: true, quote: "クレジットカードで払えます" }], reason: "上限が抜けています。" }), 2, 1, answer);
  assert.deepEqual(parsed, { ok: true, judgment: { declined: false, points: ["covered", "missing"], forbidden: [{ violated: true, quote: "クレジットカードで払えます", review: false }], reason: "上限が抜けています。", incomplete: false } });
});

test("index の欠けは missing、重なりと範囲の外は捨てて、どちらも「採点が不完全」の印", () => {
  const missing = parseJudge(JSON.stringify({ declined: false, points: [{ index: 2, status: "covered" }], forbidden: [], reason: "" }), 2, 0, answer);
  assert.ok(missing.ok);
  assert.deepEqual([missing.judgment.points, missing.judgment.incomplete], [["missing", "covered"], true]);
  const doubled = parseJudge(JSON.stringify({ declined: false, points: [{ index: 1, status: "covered" }, { index: 1, status: "contradicted" }, { index: 3, status: "covered" }], forbidden: [], reason: "" }), 1, 0, answer);
  assert.ok(doubled.ok);
  assert.deepEqual([doubled.judgment.points, doubled.judgment.incomplete], [["covered"], true]);
});

test("violated なのに quote が答えに見つからなければ、違反にせず「要確認」。揃え方のゆれは見つかったとする", () => {
  const parsed = parseJudge(JSON.stringify({ declined: false, points: [], forbidden: [{ index: 1, violated: true, quote: "見積もりは有料です" }, { index: 2, violated: true, quote: "クレジットカードで 払えます" }], reason: "" }), 0, 2, answer);
  assert.ok(parsed.ok);
  assert.deepEqual(parsed.judgment.forbidden, [
    { violated: false, quote: "", review: true },
    { violated: true, quote: "クレジットカードで 払えます", review: false },
  ]);
});

test("壊れた JSON は読めなかったことを返す（呼び出し側が 1 回だけやり直す）", () => {
  assert.deepEqual(parseJudge('{"declined": false, "points": [', 1, 0, answer), { ok: false, error: "採点の答えが JSON として読めませんでした。" });
  assert.deepEqual(parseJudge("", 1, 0, answer), { ok: false, error: "採点の答えが JSON として読めませんでした。" });
});

test("enum の外の印と、足りない項目は形の誤り", () => {
  assert.deepEqual(parseJudge(JSON.stringify({ declined: false, points: [{ index: 1, status: "partly" }], forbidden: [], reason: "" }), 1, 0, answer), { ok: false, error: "採点の答えに知らない印があります（partly）。" });
  assert.deepEqual(parseJudge(JSON.stringify({ declined: false, points: [], reason: "" }), 0, 0, answer), { ok: false, error: "採点の答えの形が違います。" });
});

test("理由は 100 字で切る。禁止事項の番号が欠けたら違反なしで不完全の印", () => {
  const parsed = parseJudge(JSON.stringify({ declined: true, points: [], forbidden: [], reason: "あ".repeat(150) }), 0, 1, answer);
  assert.ok(parsed.ok);
  assert.equal(parsed.judgment.reason.length, 100);
  assert.deepEqual(parsed.judgment.forbidden, [{ violated: false, quote: "", review: false }]);
  assert.equal(parsed.judgment.incomplete, true);
  assert.equal(parsed.judgment.declined, true);
});
