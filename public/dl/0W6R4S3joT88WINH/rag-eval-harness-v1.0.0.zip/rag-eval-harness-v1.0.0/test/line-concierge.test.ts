import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { RELAXED_LIMITS, RELAXED_PER_USER_DAILY } from "../src/adapters/common.ts";
import { createLineConciergeAdapter, splitLineText, type CoreModule } from "../src/adapters/line-concierge.ts";
import { fakeAnthropic, type FakeScript } from "./fixtures/fake-anthropic.ts";
import { FAKE_KITS, caseOf, fakeKit, neverAbort } from "./fixtures/helpers.ts";

const KIT = join(FAKE_KITS, "line-concierge");
const INDEX = join(FAKE_KITS, "ai-concierge", "data", "index.json");

async function setup(script: FakeScript) {
  const fake = await fakeKit("line-concierge");
  fake.received.length = 0;
  const core = (await fakeKit("ai-concierge")) as CoreModule;
  const anthropic = fakeAnthropic(script);
  const adapter = await createLineConciergeAdapter({ kitDir: KIT, configPath: join(KIT, "concierge.config.json"), indexPath: INDEX, apiKey: "sk-test", baseClient: anthropic.client, core });
  return { adapter, anthropic, received: fake.received as any[] };
}

test("利用者の名前は問いごと・回ごとに新しくする", async () => {
  const { adapter, received } = await setup(() => ({ text: "はい。", citations: [0] }));
  await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort());
  await adapter.ask(caseOf({ id: "q2", question: "保証は" }), 0, neverAbort());
  await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 1, neverAbort());
  assert.deepEqual(received.filter((item) => item.userId !== undefined).map((item) => item.userId), ["eval-q1-1", "eval-q2-1", "eval-q1-2"]);
});

test("前の質問は同じ利用者で先に送り、本題は会話の続きとして答えさせる", async () => {
  const { adapter, anthropic, received } = await setup((params) => ({ text: params.messages.length === 1 ? "80 万円〜150 万円です。" : "4 日〜6 日です。", citations: [0] }));
  const answer = await adapter.ask(caseOf({ id: "q1", question: "工期は", previous: "キッチンはいくら" }), 0, neverAbort());
  assert.deepEqual(received.filter((item) => item.userId !== undefined).map((item) => [item.userId, item.text]), [
    ["eval-q1-1", "キッチンはいくら"],
    ["eval-q1-1", "工期は"],
  ]);
  assert.equal(anthropic.requests[1].messages.length, 3);
  assert.equal(answer.answer, "4 日〜6 日です。");
});

test("引き継ぎの言葉なら handoff、Claude は呼ばない。資料に無ければ断った", async () => {
  const { adapter, anthropic } = await setup(() => ({ text: "資料に載っていません。" }));
  const handoff = await adapter.ask(caseOf({ id: "q1", question: "担当者と話したいです" }), 0, neverAbort());
  assert.deepEqual([handoff.status, handoff.handoff, handoff.refused, handoff.answer], ["ok", true, false, "担当者におつなぎします。"]);
  assert.equal(anthropic.requests.length, 0);
  const refused = await adapter.ask(caseOf({ id: "q2", question: "太陽光パネルは" }), 0, neverAbort());
  assert.deepEqual([refused.handoff, refused.refused], [false, true]);
});

test("「参考:」の行より後ろを出典として切り分ける（1 行 題 URL）", async () => {
  const { adapter } = await setup(() => ({ text: "2 年間です。", citations: [1, 0] }));
  const answer = await adapter.ask(caseOf({ id: "q1", question: "保証は" }), 0, neverAbort());
  assert.equal(answer.answer, "2 年間です。");
  assert.deepEqual(answer.sources, [
    { title: "保証とアフターサービス", url: "https://example.com/warranty" },
    { title: "料金", url: "https://example.com/price" },
  ]);
  assert.deepEqual(splitLineText("本文\n\n参考:\n会社 概要 https://example.com/about", "参考"), { body: "本文", sources: [{ title: "会社 概要", url: "https://example.com/about" }] });
  assert.deepEqual(splitLineText("出典の無い答え", "参考"), { body: "出典の無い答え", sources: [] });
});

test("LINE には何も送らない: 偽の LINE の API・外へ出ない fetch・鍵は ANTHROPIC_API_KEY だけ・上限をゆるめる", async () => {
  const { adapter, received } = await setup(() => ({ text: "はい。", citations: [0] }));
  await adapter.ask(caseOf({ id: "q1", question: "料金は" }), 0, neverAbort());
  const { config, deps } = received[0];
  assert.deepEqual(config.envNames, ["ANTHROPIC_API_KEY"]);
  assert.deepEqual(config.secrets, { channelSecret: null, channelAccessToken: null, handoffWebhookUrl: null });
  assert.deepEqual(deps.lineApi.calls, ["loading eval-q1-1"]);
  await assert.rejects(deps.fetch("https://api.line.me/v2/bot/message/reply"), /評価の実行では、キットから外へは送りません。/);
  assert.deepEqual(config.concierge.limits, { maxInputChars: 400, ...RELAXED_LIMITS });
  assert.equal(config.line.perUserDaily, RELAXED_PER_USER_DAILY);
});
