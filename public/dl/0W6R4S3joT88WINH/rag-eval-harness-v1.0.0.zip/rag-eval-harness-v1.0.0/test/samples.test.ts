import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { DEMO_RECORDING, main } from "../src/cli.ts";
import { loadCasesFile } from "../src/cases/cases.ts";
import { loadCalibration, runCalibration } from "../src/judge/calibration.ts";
import { createKeywordJudge } from "../src/judge/keyword.ts";
import type { KitName, ResultJson } from "../src/types.ts";
import { findInternal } from "./forbidden.ts";
import { PACKAGE_ROOT } from "./fixtures/helpers.ts";

const SAMPLE_TABLES: Array<[string, KitName | null, number]> = [
  ["cases/ai-concierge.csv", "ai-concierge", 20],
  ["cases/line-concierge.csv", "line-concierge", 20],
  ["cases/doc-reader.csv", "doc-reader", 20],
  ["cases/http-example.csv", "http", 5],
  ["cases/template.csv", null, 3],
];
// 書類読み取りの見本の書類は、キットのフォルダの samples/ にあります（CLI の --sample と同じく、書類はここからの相対です）。
// キットのフォルダが隣に無いとき（配布の zip だけのとき）は、書類の有無は見ません
const DOC_READER_SAMPLES = join(PACKAGE_ROOT, "..", "doc-reader", "samples");
const DOC_READER_PRESENT = existsSync(DOC_READER_SAMPLES);
const load = (file: string, kit: KitName | null) =>
  loadCasesFile(join(PACKAGE_ROOT, file), kit === "doc-reader" ? { kit, baseDir: DOC_READER_SAMPLES, exists: DOC_READER_PRESENT ? existsSync : () => true } : { kit });

function filesUnder(dir: string): string[] {
  return readdirSync(join(PACKAGE_ROOT, dir)).sort().flatMap((name) => (statSync(join(PACKAGE_ROOT, dir, name)).isDirectory() ? filesUnder(join(dir, name)) : [join(dir, name)]));
}

test("同梱の質問表 5 枚が検査を通り、行の数は 20・20・20・5・3", () => {
  for (const [file, kit, count] of SAMPLE_TABLES) {
    const loaded = load(file, kit);
    assert.deepEqual(loaded.problems, [], file);
    assert.equal(loaded.cases.length, count, file);
    assert.equal(new Set(loaded.cases.map((c) => c.id)).size, count, `${file} の id が重なっています`);
  }
  const ai = load("cases/ai-concierge.csv", "ai-concierge").cases;
  assert.equal(ai.filter((c) => c.special === "refuse").length, 4);
  assert.equal(ai.filter((c) => c.previous !== null).length, 1);
  assert.equal(ai.filter((c) => c.forbidden.length > 0).length, 6);
  assert.ok(ai.some((c) => c.id === "q31"));
});

test("LINE の質問表は、案内窓口の上から 16 問（断るべき 2 問を含む）と LINE だけの 4 問", () => {
  const ai = load("cases/ai-concierge.csv", "ai-concierge").cases;
  const line = load("cases/line-concierge.csv", "line-concierge").cases;
  const shared = (c: (typeof ai)[number]) => [c.id, c.question, c.points, c.forbidden];
  assert.deepEqual(line.slice(0, 16).map(shared), ai.slice(0, 16).map(shared));
  assert.equal(line.slice(0, 16).filter((c) => c.special === "refuse").length, 2);
  assert.deepEqual(line.slice(16).map((c) => c.special), ["handoff", "handoff", "refuse", "refuse"]);
  assert.equal(line.find((c) => c.id === "l03")?.question, "電話番号を教えてください");
  // LINE の引き継ぎの言葉（既定）を含む問いは、（引き継ぐ）の 2 問だけ
  const keywords = ["担当者", "人と話", "スタッフ", "電話で話", "お電話ください", "オペレーター"];
  assert.deepEqual(line.filter((c) => keywords.some((keyword) => c.question.includes(keyword))).map((c) => c.id), ["l01", "l02"]);
  const doc = load("cases/doc-reader.csv", "doc-reader").cases;
  assert.equal(new Set(doc.map((c) => c.documentLabel)).size, 12, "見本の書類 12 枚を使う");
  assert.deepEqual(doc.filter((c) => c.special === "empty").map((c) => [c.documentLabel, c.question]), [["docs/receipt-01.jpg", "purpose"]]);
});

test("書類読み取りの質問表の書類 12 枚は、キットの samples/ に全部ある（モノレポの中だけ）", { skip: DOC_READER_PRESENT ? false : "書類読み取りのキットのフォルダ（../doc-reader/samples）が無いため、飛ばします。" }, () => {
  const file = join(PACKAGE_ROOT, "cases", "doc-reader.csv");
  const loaded = loadCasesFile(file, { kit: "doc-reader", baseDir: DOC_READER_SAMPLES, exists: existsSync });
  assert.deepEqual(loaded.problems, []);
  for (const c of loaded.cases) assert.ok(c.document !== null && existsSync(c.document), `${c.id}: ${c.documentLabel}`);
  // 基準の場所を間違えると、20 行とも「見つかりません」になる（検査が実際に書類を見ていることの確かめ）
  const misplaced = loadCasesFile(file, { kit: "doc-reader", baseDir: join(PACKAGE_ROOT, "samples"), exists: existsSync });
  assert.equal(misplaced.problems.filter((problem) => problem.includes("が見つかりません")).length, 20);
});

test("同梱の質問表・記録・較正は架空の値だけ（電話は 03-0000- と 090-0000- の帯、メールは example.com）で、内部の語と手元のパスが無い", () => {
  for (const file of [...filesUnder("cases"), ...filesUnder("samples"), ...filesUnder("examples")]) {
    const text = readFileSync(join(PACKAGE_ROOT, file), "utf8");
    // キットの答えの記録は、見本の文書の言い回しを写すことがあるので、言い回しだけは見ない
    assert.equal(findInternal(text, { style: !file.startsWith(join("samples", "recorded")) }), null, `${file} に内部の語があります`);
    for (const phone of text.match(/0\d{1,3}-\d{2,4}-\d{3,4}/g) ?? []) assert.match(phone, /^(03-0000-|090-0000-)/, `${file}: ${phone}`);
    for (const mail of text.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g) ?? []) assert.match(mail, /@example\.com$/, `${file}: ${mail}`);
    assert.equal(/"document":"\//.test(text), false, `${file} に書類の絶対パスがあります`);
  }
});

test("較正の 30 件は、見本の文書に沿った答え 24 件とわざと作った 6 件（呼びかけつき 1 件を含む）。語の一致の採点では 18/30", async () => {
  const items = loadCalibration(join(PACKAGE_ROOT, "samples", "calibration.jsonl"));
  assert.equal(items.length, 30);
  assert.equal(new Set(items.map((item) => item.id)).size, 30);
  assert.deepEqual([items.filter((item) => item.kind === "sample").length, items.filter((item) => item.kind === "planted").length], [24, 6]);
  assert.equal(items.filter((item) => item.answer.includes("採点者へ")).length, 1);
  assert.ok(items.some((item) => item.kind === "planted" && item.answer === ""));
  const labels = new Set(items.map((item) => item.label));
  for (const label of ["correct", "partial", "wrong", "noAnswer"]) assert.ok(labels.has(label as never), label);
  const keyword = await runCalibration(createKeywordJudge(), items);
  assert.equal(keyword.agreed, 18, "README の「18/30」と合わせる");
});

// 見本の記録は本物のキットと本物の採点で作る（鍵が要る）。まだ無いうちは、この 1 本だけを飛ばす
const DEMO_SKIP = existsSync(join(PACKAGE_ROOT, DEMO_RECORDING)) ? false : `見本の記録 ${DEMO_RECORDING} がまだ無いため、飛ばします（本物のキットで記録してから確かめます）。`;

test("記録から、鍵なしで見本のレポートができる（npm run demo）", { skip: DEMO_SKIP }, async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-demo-"));
  try {
    const out: string[] = [];
    const code = await main(["demo", "--out", join(dir, "runs")], { stdout: (line) => out.push(line), stderr: () => {}, env: {}, cwd: dir, now: () => new Date("2026-10-06T09:00:00.000Z") });
    assert.equal(code, 0);
    assert.equal(out[1], "前回との差: 比べていません（--baseline none）");
    assert.equal(out[3], "レポート: runs/demo/report.html");
    const result = JSON.parse(readFileSync(join(dir, "runs", "demo", "result.json"), "utf8")) as ResultJson;
    assert.deepEqual([result.kit.name, result.kit.mode, result.judge.mode, result.results.length], ["ai-concierge", "replay", "replay", 20]);
    assert.ok(result.notes.includes("記録した答えと採点を再生しています（API は呼んでいません。費用は記録したときの額です）。"));
    assert.ok(existsSync(join(PACKAGE_ROOT, DEMO_RECORDING)));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("npm run demo:diff は、鍵なしで 0 で終わり、悪くなった問い（q05）を summary.md の先頭に出す", { skip: DEMO_SKIP }, async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-demo-diff-"));
  try {
    const out: string[] = [];
    const code = await main(["demo-diff", "--out", join(dir, "runs")], { stdout: (line) => out.push(line), stderr: () => {}, env: {}, cwd: dir, now: () => new Date("2026-10-06T09:00:00.000Z") });
    assert.equal(code, 0);
    assert.match(out[0], /再生のデモです。/);
    assert.match(out[2], /^前回との差: −5 ポイント（良くなった 0 問・悪くなった 1 問）/);
    const summary = readFileSync(join(dir, "runs", "demo-diff", "summary.md"), "utf8");
    assert.match(summary, /## 前回から悪くなった問い\n\n- q05「キッチンの入れ替えはいくらくらいですか」— 正解 → 誤り/);
    assert.ok(summary.indexOf("## 前回から悪くなった問い") < summary.indexOf("## 悪かった問い"));
    assert.ok(summary.includes("わざと書き換えて"));
    const html = readFileSync(join(dir, "runs", "demo-diff", "report.html"), "utf8");
    assert.ok(html.indexOf("前回から悪くなった問い（1）") < html.indexOf("<thead>"));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("（答えない）の話題は、キットの見本の文書に載っていない（モノレポの中だけ）", { skip: !existsSync(join(PACKAGE_ROOT, "..", "ai-concierge", "samples", "content")) }, () => {
  const content = join(PACKAGE_ROOT, "..", "ai-concierge", "samples", "content");
  const text = readdirSync(content).map((name) => readFileSync(join(content, name), "utf8")).join("\n");
  for (const topic of ["太陽光", "駐車場", "評判", "携帯", "エアコン", "電話番号"]) assert.equal(text.includes(topic), false, topic);
  assert.equal(/0\d{1,3}-\d{2,4}-\d{3,4}/.test(text), false, "見本の文書に電話番号は無い");
});
