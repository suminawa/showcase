/**
 * モノレポの中だけで走る検査: 本物の 3 キットの dist を、偽の Anthropic client で呼び、アダプタが読めることを確かめる
 * （偽のキットと本物の食い違いを見張る）。配布 zip の中では、隣にキットが無いので飛ばす。
 * 先に packages/ai-concierge・line-concierge・doc-reader で npm ci と npm run build を済ませておく
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createAiConciergeAdapter } from "../src/adapters/ai-concierge.ts";
import { buildSampleIndex } from "../src/adapters/common.ts";
import { createDocReaderAdapter } from "../src/adapters/doc-reader.ts";
import { createLineConciergeAdapter } from "../src/adapters/line-concierge.ts";
import { fakeAnthropic } from "./fixtures/fake-anthropic.ts";
import { PACKAGE_ROOT, caseOf, neverAbort } from "./fixtures/helpers.ts";

const KITS = join(PACKAGE_ROOT, "..");
const ready = (name: string, extra: string[] = []) => [join(KITS, name, "dist", "index.js"), ...extra.map((path) => join(KITS, name, path))].every((path) => existsSync(path));
const AI = join(KITS, "ai-concierge");
const LINE = join(KITS, "line-concierge");
const DOC = join(KITS, "doc-reader");

test("本物の AI 案内窓口キット: 見本の索引を作り、偽の client で答えと出典を読める", { skip: !ready("ai-concierge", ["dist/cli.js"]) }, async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-contract-"));
  try {
    const index = join(dir, "index.json");
    buildSampleIndex(join(AI, "dist", "cli.js"), AI, "samples/concierge.config.json", index);
    const anthropic = fakeAnthropic(() => ({ text: "お見積もりは無料です。", citations: [0] }));
    const adapter = await createAiConciergeAdapter({ kitDir: AI, configPath: join(AI, "samples", "concierge.config.json"), indexPath: index, apiKey: "sk-test", baseClient: anthropic.client });
    const answer = await adapter.ask(caseOf({ id: "c1", question: "見積もりは無料ですか" }), 0, neverAbort());
    assert.equal(answer.status, "ok", answer.error);
    assert.equal(answer.answer, "お見積もりは無料です。");
    assert.equal(answer.sources.length, 1);
    assert.match(answer.sources[0].url ?? "", /^https:\/\/example\.com\//);
    assert.equal(answer.refused, false);
    assert.equal(answer.usage.length, 1);
    assert.equal(anthropic.requests[0].model, adapter.info.model);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("本物の LINE 案内窓口キット: simulate の答えから本文と「参考」を切り分け、LINE には送らない", { skip: !ready("line-concierge", ["node_modules/@suminawa/ai-concierge/dist/cli.js"]) }, async () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-contract-"));
  try {
    const index = join(dir, "index.json");
    buildSampleIndex(join(LINE, "node_modules", "@suminawa", "ai-concierge", "dist", "cli.js"), LINE, "samples/concierge.config.json", index);
    const anthropic = fakeAnthropic(() => ({ text: "保証は 2 年です。", citations: [0] }));
    const adapter = await createLineConciergeAdapter({ kitDir: LINE, configPath: join(LINE, "samples", "concierge.config.json"), indexPath: index, apiKey: "sk-test", baseClient: anthropic.client });
    const answer = await adapter.ask(caseOf({ id: "c2", question: "保証は何年ですか" }), 0, neverAbort());
    assert.equal(answer.status, "ok", answer.error);
    assert.equal(answer.answer, "保証は 2 年です。");
    assert.equal(answer.sources.length, 1);
    assert.equal(answer.handoff, false);
    const handoff = await adapter.ask(caseOf({ id: "c3", question: "担当者と話したいです" }), 0, neverAbort());
    assert.deepEqual([handoff.status, handoff.handoff], ["ok", true]);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("本物の AI 書類読み取りキット: 見本の請求書を偽の client の答えで読み、金額を数として返す", { skip: !ready("doc-reader", ["samples/docs/invoice-01.pdf"]) }, async () => {
  const raw = { fields: { total: { value: "¥167,750", confidence: 0.95, evidence: "ご請求金額 ¥167,750" } }, tables: {}, notes: "" };
  const anthropic = fakeAnthropic(() => ({ text: JSON.stringify(raw) }));
  const adapter = await createDocReaderAdapter({ kitDir: DOC, configPath: join(DOC, "reader.config.json"), formsDir: join(DOC, "forms"), apiKey: "sk-test", baseClient: anthropic.client });
  const answer = await adapter.ask(caseOf({ id: "c4", question: "total", points: ["¥167,750"], document: join(DOC, "samples", "docs", "invoice-01.pdf"), documentLabel: "invoice-01.pdf", form: "invoice" }), 0, neverAbort());
  assert.equal(answer.status, "ok", answer.error);
  assert.deepEqual([answer.field?.value, answer.field?.expected, answer.field?.evidence], [167750, 167750, "ご請求金額 ¥167,750"]);
});
