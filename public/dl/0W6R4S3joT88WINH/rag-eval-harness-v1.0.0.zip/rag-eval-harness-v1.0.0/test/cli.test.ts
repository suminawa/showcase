import { test } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { FLAG_ROWS, USAGE, cacheLines, main, parseArgs, type CliIo } from "../src/cli.ts";
import { OUTPUT_FILES } from "../src/report/write.ts";
import { ADMIN_HEADERS } from "../src/cases/from-admin.ts";
import { toCasesJsonl } from "../src/adapters/replay.ts";
import { HarnessError } from "../src/errors.ts";
import type { ResultJson, RunMeta } from "../src/types.ts";
import { fakeAnthropic } from "./fixtures/fake-anthropic.ts";
import { FAKE_KITS, FIXTURES, recordOf, usageOf } from "./fixtures/helpers.ts";

// dist/cli.js を直接子プロセスで叩く検査もある。tsup は速いので、古い dist が残って誤魔化さないよう毎回ここでビルドし直す
const pkgDir = join(dirname(fileURLToPath(import.meta.url)), "..");
const cliPath = join(pkgDir, "dist", "cli.js");
const built = spawnSync("npm", ["run", "build"], { cwd: pkgDir, encoding: "utf8" });
assert.equal(built.status, 0, `npm run build に失敗しました:\n${built.stderr}`);

const HEAD = "id,質問,期待する答えの要点,出典に含まれるべき文書,答えてはいけないこと,タグ";

function ioOf(cwd: string, extra: Partial<CliIo> = {}) {
  const out: string[] = [];
  const err: string[] = [];
  const io: CliIo = { stdout: (line) => out.push(line), stderr: (line) => err.push(line), env: {}, cwd, now: () => new Date("2026-10-05T12:30:00.000Z"), sleep: async () => {}, ...extra };
  return { io, out, err };
}

function withDir(run: (dir: string) => Promise<void>) {
  return async () => {
    const dir = mkdtempSync(join(tmpdir(), "rag-eval-cli-"));
    try {
      await run(dir);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  };
}

const answering = (answer: string) =>
  (async () => Response.json({ answer, sources: [{ title: "料金", url: "https://example.com/price" }], refused: false })) as unknown as typeof fetch;

test("旗: 知らない旗・値の無い旗・範囲の外は、使い方の誤り（終了コード 2）", () => {
  assert.throws(() => parseArgs(["run", "--kitt", "http"]), (error: unknown) => error instanceof HarnessError && error.exitCode === 2 && error.message.startsWith("知らない旗です: --kitt。"));
  assert.throws(() => parseArgs(["run", "--kit"]), /--kit には値が要ります。/);
  const parsed = parseArgs(["run", "--kit=http", "--dry-run", "--url", "http://127.0.0.1:8787"]);
  assert.deepEqual([...parsed.flags.entries()], [["--kit", "http"], ["--dry-run", true], ["--url", "http://127.0.0.1:8787"]]);
  assert.equal(FLAG_ROWS.flatMap((row) => row.names).length, 25);
});

test("質問表に誤りがあれば、全部を並べて API を呼ばずに 2 で止める", withDir(async (dir) => {
  writeFileSync(join(dir, "bad.csv"), `${HEAD}\nq1,,80 万円\nq2,料金は,答えない\n`);
  let called = 0;
  const { io, err } = ioOf(dir, { fetch: (async () => (called += 1, Response.json({}))) as unknown as typeof fetch, env: { ANTHROPIC_API_KEY: "sk-test" } });
  const code = await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "bad.csv"], io);
  assert.equal(code, 2);
  assert.deepEqual(err, ["質問表に直すところがあります（2 件）。API は呼んでいません。\n  2 行目: 「質問」が空です。\n  3 行目: 「答えない」は （答えない） と書いてください。"]);
  assert.equal(called, 0);
  assert.equal(existsSync(join(dir, "runs")), false);
}));

test("--dry-run は質問表とキットの読み込みまで。API を呼ばず、鍵も要らない", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円,料金\n`);
  const anthropic = fakeAnthropic(() => ({ text: "x" }));
  const kitDir = join(FAKE_KITS, "ai-concierge");
  const { io, out } = ioOf(dir, { anthropic: anthropic.client });
  const code = await main(["run", "--kit", "ai-concierge", "--kit-dir", kitDir, "--index", join(kitDir, "data", "index.json"), "--cases", "cases.csv", "--dry-run"], io);
  assert.equal(code, 0);
  assert.deepEqual(out, [
    "[確かめ] 質問表: cases.csv（1 問）",
    "[確かめ] キット: AI 案内窓口キット 1.0.1（手元）・答え claude-opus-5",
    "[確かめ] 採点: claude-sonnet-5（effort low）",
    "[注意] 全文モード（検索なし）: 文書が少ないため、キットは毎回すべての文書を読ませています。検索の当たりは出しません。",
    "--dry-run なので、API は呼びませんでした。",
  ]);
  assert.equal(anthropic.requests.length, 0);
  assert.equal(existsSync(join(dir, "runs")), false);
}));

test("鍵が無ければ、手元のキットでも Claude の採点でも API の前に 2 で止める", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const { io, err } = ioOf(dir, { fetch: answering("80 万円です。") });
  assert.equal(await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv"], io), 2);
  assert.match(err[0], /^ANTHROPIC_API_KEY が設定されていません。/);
  assert.equal(await main(["run", "--kit", "ai-concierge", "--kit-dir", join(FAKE_KITS, "ai-concierge"), "--cases", "cases.csv", "--judge", "keyword"], io), 2);
}));

test("--min-score に届かなければ終了コード 1。終わりの 5 行は正答率・前回との差・費用・レポート・終了コード", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円|150 万円,料金\nq2,保証は,2 年\n`);
  const { io, out, err } = ioOf(dir, { fetch: answering("80 万円からです。") });
  const code = await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--judge", "keyword", "--min-score", "80"], io);
  assert.equal(code, 1);
  assert.ok(err.includes("正答率 25% が --min-score 80% に届きません。"));
  assert.deepEqual(out, [
    "正答率 25%（正解 0・部分 1・誤り 1・無回答 0 ／ 採点できた 2 問）",
    "前回との差: 前回の記録がありません（次の実行から出ます）",
    "費用: キット 0.0 円・採点 0.0 円（1 問あたり 0.0 円）",
    "レポート: runs/20261005-213000-http/report.html",
    "終了コード: 1",
  ]);
  assert.deepEqual(readdirSync(join(dir, "runs", "20261005-213000-http")).sort(), [...OUTPUT_FILES].sort());
}));

test("cases check は API を呼ばずに確かめ、from-admin は未回答の CSV から質問表を書く", withDir(async (dir) => {
  writeFileSync(join(dir, "ok.csv"), `${HEAD},担当\nq1,料金は,80 万円,,,,営業\nq2,太陽光は,（答えない）\n`);
  const { io, out } = ioOf(dir);
  assert.equal(await main(["cases", "check", "ok.csv"], io), 0);
  assert.deepEqual(out, ["[OK] ok.csv: 2 問（断るべき 1・引き継ぐ 0・前の質問つき 0）。直すところはありません。", "[注意] 知らない列（担当）は、レポートに「ご参考」として出します。"]);
  writeFileSync(join(dir, "export.csv"), `${ADMIN_HEADERS.join(",")}\n2026-10-01T00:00:00.000Z,駐車場はありますか,資料に載っていません,,いいえ,900,claude-opus-5,1,1,0,いいえ,いいえ\n`);
  out.length = 0;
  assert.equal(await main(["cases", "from-admin", "export.csv"], io), 0);
  assert.deepEqual(out, ["[OK] 未回答の質問 1 問を cases/from-admin-20261005.csv に書きました。「期待する答えの要点」を書き足してから、--cases に指定してください。"]);
  assert.ok(readFileSync(join(dir, "cases", "from-admin-20261005.csv"), "utf8").includes("駐車場はありますか"));
}));

test("dist/cli.js を npm の bin の symlink 越しに叩いても直接実行と認識する（引数なしは使い方で 0、誤りは 2）", () => {
  const dir = mkdtempSync(join(tmpdir(), "rag-eval-symlink-"));
  try {
    const link = join(dir, "rag-eval");
    symlinkSync(cliPath, link);
    const help = spawnSync(process.execPath, [link], { encoding: "utf8" });
    assert.equal(help.status, 0, help.stderr);
    assert.ok(help.stdout.startsWith("RAG 評価ハーネス（rag-eval）"), help.stdout);
    const wrong = spawnSync(process.execPath, [link, "run", "--kit", "nothing"], { encoding: "utf8" });
    assert.equal(wrong.status, 2);
    assert.equal(wrong.stdout, "");
    assert.equal(wrong.stderr, "--kit は ai-concierge・line-concierge・doc-reader・http・replay のどれかにしてください（いまの値: nothing）。\n");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("cases from-admin を同じ出し先に 2 回実行しても、既存のファイルは上書きせず -2 を付ける", withDir(async (dir) => {
  writeFileSync(join(dir, "export.csv"), `${ADMIN_HEADERS.join(",")}\n2026-10-01T01:00:00.000Z,営業時間を教えてください,,,いいえ,900,claude-opus-5,10,5,0,いいえ,いいえ\n`);
  const { io, out } = ioOf(dir);
  assert.equal(await main(["cases", "from-admin", "export.csv", "--out", "made"], io), 0);
  assert.equal(await main(["cases", "from-admin", "--out", "made", "export.csv"], io), 0);
  assert.deepEqual(readdirSync(join(dir, "made")).sort(), ["from-admin-20261005-2.csv", "from-admin-20261005.csv"]);
  assert.match(out[1], /made\/from-admin-20261005-2\.csv に書きました。/);
  const written = readFileSync(join(dir, "made", "from-admin-20261005.csv"), "utf8");
  assert.equal(written, readFileSync(join(dir, "made", "from-admin-20261005-2.csv"), "utf8"), "1 回目のファイルはそのまま");
}));

test("from-admin の質問表は、= + - @ で始まる質問に ' を付けて書く（表計算ソフトで式として動かない）", withDir(async (dir) => {
  writeFileSync(join(dir, "export.csv"), `${ADMIN_HEADERS.join(",")}\n2026-10-01T01:00:00.000Z,"=HYPERLINK(""https://evil.example"")",,,いいえ,900,claude-opus-5,10,5,0,いいえ,いいえ\n`);
  const { io } = ioOf(dir);
  assert.equal(await main(["cases", "from-admin", "export.csv"], io), 0);
  const written = readFileSync(join(dir, "cases", "from-admin-20261005.csv"), "utf8");
  assert.ok(written.includes(`"'=HYPERLINK(""https://evil.example"")"`), written);
}));

test("help・-h・--help は使い方を出して 0。--min-score と --max-drop は 0〜100 のポイントと書いてある", withDir(async (dir) => {
  for (const argv of [[], ["help"], ["-h"], ["--help"], ["run", "--help"]]) {
    const { io, out, err } = ioOf(dir);
    assert.equal(await main(argv, io), 0, argv.join(" "));
    assert.deepEqual([out, err], [[USAGE], []], argv.join(" "));
  }
  assert.ok(USAGE.includes("--min-score と --max-drop は 0〜100 のポイントで指定します"));
  const row = FLAG_ROWS.find((item) => item.names.includes("--max-drop"));
  assert.ok(row?.meaning.includes("0〜100 のポイント"));
}));

test("旗は CSV のパスの前にも後ろにも置ける。最後の旗に値が無ければ誤り", withDir(async (dir) => {
  writeFileSync(join(dir, "a.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const { io, out, err } = ioOf(dir);
  assert.equal(await main(["cases", "check", "--kit", "ai-concierge", "a.csv"], io), 0);
  assert.equal(await main(["cases", "--kit=http", "check", "a.csv"], io), 0);
  assert.deepEqual(err, []);
  assert.deepEqual(out, Array(2).fill("[OK] a.csv: 1 問（断るべき 0・引き継ぐ 0・前の質問つき 0）。直すところはありません。"));
  assert.equal(await main(["cases", "check", "a.csv", "--kit"], io), 2);
  assert.equal(await main(["cases", "check", "a.csv", "--kit="], io), 2);
  assert.equal(await main(["run", "--dry-run=no"], io), 2);
  assert.deepEqual(err, ["--kit には値が要ります。", "--kit には値が要ります。", "--dry-run は値を取りません（--dry-run とだけ書いてください）。"]);
}));

test("質問表にフォルダや無いファイルを渡すと、生の EISDIR・ENOENT ではなく敬体の文で 2", withDir(async (dir) => {
  mkdirSync(join(dir, "folder.csv"));
  const { io, out, err } = ioOf(dir);
  const http = ["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--judge", "keyword"];
  assert.equal(await main(["cases", "check", "folder.csv"], io), 2);
  assert.equal(await main(["cases", "from-admin", "folder.csv"], io), 2);
  assert.equal(await main(["cases", "check", "missing.csv"], io), 2);
  assert.equal(await main([...http, "--cases", "folder.csv"], io), 2);
  assert.equal(await main([...http, "--cases", "missing.csv"], io), 2);
  assert.deepEqual(out, []);
  assert.deepEqual(err, [
    "folder.csv はフォルダです。ファイルを指定してください。",
    "folder.csv はフォルダです。ファイルを指定してください。",
    "missing.csv が見つかりません。",
    "質問表 folder.csv はフォルダです。ファイルを指定してください。",
    "質問表 missing.csv が見つかりません。",
  ]);
}));

test("読めない質問表も敬体の文で 2", { skip: process.getuid?.() === 0 }, withDir(async (dir) => {
  writeFileSync(join(dir, "locked.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  chmodSync(join(dir, "locked.csv"), 0o000);
  const { io, err } = ioOf(dir);
  assert.equal(await main(["cases", "check", "locked.csv"], io), 2);
  assert.deepEqual(err, ["locked.csv を読めません。ファイルの読み取りの権限をご確認ください。"]);
}));

test("--config に無いファイルを指定したら、キットの既定に戻さず 2 で止める", withDir(async (dir) => {
  const invoice = join(FIXTURES, "docs", "invoice-a.pdf");
  writeFileSync(join(dir, "docs.csv"), `id,質問,期待する答えの要点,書類,帳票の型\nd1,total,1000,${invoice},invoice\n`);
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const anthropic = fakeAnthropic(() => ({ text: "x" }));
  const { io, out, err } = ioOf(dir, { anthropic: anthropic.client });
  const doc = ["run", "--kit", "doc-reader", "--kit-dir", join(FAKE_KITS, "doc-reader"), "--cases", "docs.csv", "--dry-run"];
  assert.equal(await main([...doc, "--config", "reader.config.json"], io), 2);
  assert.equal(await main(["run", "--kit", "ai-concierge", "--kit-dir", join(FAKE_KITS, "ai-concierge"), "--cases", "cases.csv", "--config", "nothing", "--dry-run"], io), 2);
  mkdirSync(join(dir, "folder"));
  assert.equal(await main([...doc, "--config", "folder"], io), 2);
  assert.deepEqual(err, ["--config のファイル reader.config.json が見つかりません。", "--config のファイル nothing が見つかりません。", "--config のファイル folder はフォルダです。ファイルを指定してください。"]);
  assert.deepEqual(out, []);
  assert.equal(await main(doc, io), 0, "--config を付けなければ、キットの既定の設定で読み込む");
  assert.equal(anthropic.requests.length, 0);
}));

test("--judge-model は claude-sonnet-・claude-opus-・claude-haiku- で始まる名前だけ", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const http = ["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--dry-run"];
  const { io, out, err } = ioOf(dir);
  for (const model of ["claude-3-opus", "gpt-5", "claude-instant"]) assert.equal(await main([...http, "--judge-model", model], io), 2, model);
  assert.deepEqual(err, ["claude-3-opus", "gpt-5", "claude-instant"].map((model) => `--judge-model は claude-sonnet-・claude-opus-・claude-haiku- のどれかで始まるモデルにしてください（いまの値: ${model}）。`));
  for (const model of ["claude-haiku-4-5", "claude-opus-5", "claude-sonnet-5"]) assert.equal(await main([...http, "--judge-model", model], io), 0, model);
  assert.deepEqual(out.filter((line) => line.startsWith("[確かめ] 採点")), ["[確かめ] 採点: claude-haiku-4-5（effort low）", "[確かめ] 採点: claude-opus-5（effort low）", "[確かめ] 採点: claude-sonnet-5（effort low）"]);
}));

test("いまの答えと記録の採点（--judge replay）は組み合わせられない（replay の採点は記録の答えとだけ）", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  let called = 0;
  const { io, err } = ioOf(dir, { fetch: (async () => (called += 1, Response.json({ answer: "x" }))) as unknown as typeof fetch });
  assert.equal(await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--judge", "replay", "--from", "old/cases.jsonl"], io), 2);
  assert.deepEqual(err, ["--judge replay は --kit replay とだけ組み合わせられます（記録の採点は、記録の答えにだけ合います）。いまの答えを採点するときは --judge claude か --judge keyword にしてください。"]);
  assert.equal(called, 0);
}));

test("--min-score・--max-drop の範囲の外は、答えさせる前に 2 で止める。--max-drop を付けても前回が無ければ、確かめを飛ばしたと知らせる", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  let called = 0;
  const fetchImpl = (async () => (called += 1, Response.json({ answer: "80 万円です。", sources: [], refused: false }))) as unknown as typeof fetch;
  const http = ["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--judge", "keyword"];
  const bad = ioOf(dir, { fetch: fetchImpl });
  assert.equal(await main([...http, "--min-score", "180"], bad.io), 2);
  assert.equal(await main([...http, "--max-drop", "-1"], bad.io), 2);
  assert.deepEqual(bad.err, ["--min-score は 0〜100 の数にしてください（いまの値: 180）。", "--max-drop は 0〜100 の数にしてください（いまの値: -1）。"]);
  assert.equal(called, 0);
  assert.equal(existsSync(join(dir, "runs")), false);

  const first = ioOf(dir, { fetch: fetchImpl });
  assert.equal(await main([...http, "--max-drop", "5"], first.io), 0);
  assert.ok(first.err.includes("前回の記録が無いため、--max-drop の確かめは飛ばしました。"), first.err.join("\n"));
  const none = ioOf(dir, { fetch: fetchImpl, now: () => new Date("2026-10-05T12:31:00.000Z") });
  assert.equal(await main([...http, "--max-drop", "5", "--baseline", "none"], none.io), 0);
  assert.ok(none.err.includes("--baseline none のため、--max-drop の確かめは飛ばしました。"), none.err.join("\n"));
  const second = ioOf(dir, { fetch: fetchImpl, now: () => new Date("2026-10-05T12:32:00.000Z") });
  assert.equal(await main([...http, "--max-drop", "5"], second.io), 0);
  assert.equal(second.err.some((line) => line.includes("--max-drop の確かめは飛ばしました")), false);
  assert.equal(second.out[1], "前回との差: ±0 ポイント（良くなった 0 問・悪くなった 0 問）");
}));

test("値段の表に無いモデルは注意に出すが、打ち切りの印の unknown は出さない", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const run = async (model: string, at: string) => {
    const fetchImpl = (async () => Response.json({ answer: "80 万円です。", sources: [], refused: false, model, usage: { input_tokens: 10, output_tokens: 5 } })) as unknown as typeof fetch;
    const { io } = ioOf(dir, { fetch: fetchImpl, now: () => new Date(at) });
    assert.equal(await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--judge", "keyword", "--baseline", "none"], io), 0);
    const stamp = at === "2026-10-05T12:30:00.000Z" ? "20261005-213000" : "20261005-213100";
    return (JSON.parse(readFileSync(join(dir, "runs", `${stamp}-http`, "result.json"), "utf8")) as ResultJson).notes;
  };
  assert.ok((await run("mystery-model", "2026-10-05T12:30:00.000Z")).includes("値段の表に無いモデル（mystery-model）の費用は入れていません。"));
  assert.equal((await run("unknown", "2026-10-05T12:31:00.000Z")).some((note) => note.startsWith("値段の表に無いモデル")), false);
}));

test("judge-check のキャッシュの行: haiku で 2 件目の読みが 0 でも、失敗扱いにせずご参考として出す", () => {
  const first = usageOf("claude-haiku-4-5", 3000, 80);
  const second = usageOf("claude-haiku-4-5", 3000, 80);
  const lines = cacheLines("claude-haiku-4-5", [first, second]);
  assert.equal(lines[0], "キャッシュ: 1 件目の書き込み 0 トークン・2 件目の読み 0 トークン");
  assert.match(lines[1], /^\[ご参考\] Haiku 4\.5 は 4096 トークン以上の決まりだけをキャッシュに乗せるため/);
  assert.equal(lines.some((line) => line.startsWith("[注意]") || line.startsWith("[要対応]")), false);
  assert.match(cacheLines("claude-sonnet-5", [first, second])[1], /^\[注意\] 採点の決まりがキャッシュに乗っていません/);
  assert.deepEqual(cacheLines("claude-sonnet-5", [usageOf("claude-sonnet-5", 100, 10, { cacheWrite5m: 2000 }), usageOf("claude-sonnet-5", 100, 10, { cacheRead: 2000 })]), ["キャッシュ: 1 件目の書き込み 2000 トークン・2 件目の読み 2000 トークン"]);
  assert.deepEqual(cacheLines("claude-sonnet-5", []), []);
});

test("記録の答えを語の一致で採点し直せる（注意は「答えだけ再生」）。report は cases.jsonl から描き直す", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const first = ioOf(dir, { fetch: answering("80 万円です。") });
  assert.equal(await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--judge", "keyword"], first.io), 0);
  const replayed = ioOf(dir, { now: () => new Date("2026-10-05T12:40:00.000Z") });
  assert.equal(await main(["run", "--kit", "replay", "--from", "runs/20261005-213000-http/cases.jsonl", "--judge", "keyword"], replayed.io), 0);
  const notes = (JSON.parse(readFileSync(join(dir, "runs", "20261005-214000-http", "result.json"), "utf8")) as ResultJson).notes;
  assert.ok(notes.includes("記録した答えを再生し、採点だけをいま行いました（キットは呼んでいません。答えの費用は記録したときの額です）。"), notes.join("\n"));
  assert.equal(notes.some((note) => note.startsWith("記録した答えと採点を再生しています")), false);
  assert.equal(notes.filter((note) => note.startsWith("語の一致での採点です。")).length, 1, "記録の注意と重ねない");

  const { io, out, err } = ioOf(dir);
  rmSync(join(dir, "runs", "20261005-213000-http", "report.html"));
  assert.equal(await main(["report", "runs/20261005-213000-http"], io), 0);
  assert.deepEqual(out, ["描き直しました: runs/20261005-213000-http/report.html"]);
  assert.ok(readFileSync(join(dir, "runs", "20261005-213000-http", "report.html"), "utf8").includes("問いごとの結果"));
  assert.equal(await main(["report", "runs"], io), 2);
  assert.deepEqual(err, ["runs に cases.jsonl がありません。runs の下の、1 回の実行のフォルダを指定してください。"]);
}));

test("旗はコマンドの前にも置ける（rag-eval --kit http run a.csv）", () => {
  const parsed = parseArgs(["--kit", "http", "run", "a.csv"]);
  assert.equal(parsed.command, "run");
  assert.deepEqual(parsed.positionals, ["a.csv"]);
  assert.deepEqual([...parsed.flags.entries()], [["--kit", "http"]]);
});

test("--judge keyword・replay に付けた --judge-model・--judge-effort は、使わない旨を敬体で知らせるだけ（誤りにはしない）", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const keyword = ioOf(dir);
  const httpArgs = ["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--dry-run", "--judge", "keyword", "--judge-model", "claude-sonnet-5", "--judge-effort", "high"];
  assert.equal(await main(httpArgs, keyword.io), 0);
  assert.deepEqual(keyword.err, ["--judge-model・--judge-effort は --judge keyword では使いません（このまま進みます）。"]);

  const meta: RunMeta = {
    tool: { name: "rag-eval-harness", version: "1.0.0" },
    startedAt: "2026-10-05T12:00:00.000Z",
    finishedAt: "2026-10-05T12:01:00.000Z",
    kit: { name: "ai-concierge", label: "偽のキット", mode: "in-process", version: null, model: null },
    judge: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: null },
    cases: { file: "cases/x.csv", sha256: "0".repeat(64), count: 1 },
    rounds: 1,
    notes: [],
    yenPerUsd: 150,
    redact: true,
  };
  writeFileSync(join(dir, "from.jsonl"), toCasesJsonl(meta, [recordOf("q1")]));
  const replay = ioOf(dir);
  const replayArgs = ["run", "--kit", "replay", "--from", "from.jsonl", "--judge", "replay", "--dry-run", "--judge-model", "claude-opus-5", "--judge-effort", "low"];
  assert.equal(await main(replayArgs, replay.io), 0);
  assert.deepEqual(replay.err, ["--judge-model・--judge-effort は --judge replay では使いません（このまま進みます）。"]);
}));

test("記録の cases.jsonl の meta.kit.name（形の検査をしていない）が決まった名前でなければ、runs の外にフォルダを作らず 2 で止める", withDir(async (dir) => {
  const meta: RunMeta = {
    tool: { name: "rag-eval-harness", version: "1.0.0" },
    startedAt: "2026-10-05T12:00:00.000Z",
    finishedAt: "2026-10-05T12:01:00.000Z",
    kit: { name: "/../outside" as unknown as RunMeta["kit"]["name"], label: "偽のキット", mode: "in-process", version: null, model: null },
    judge: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: null },
    cases: { file: "cases/x.csv", sha256: "0".repeat(64), count: 1 },
    rounds: 1,
    notes: [],
    yenPerUsd: 150,
    redact: true,
  };
  writeFileSync(join(dir, "cases.jsonl"), toCasesJsonl(meta, [recordOf("q1")]));
  const { io, err } = ioOf(dir);
  const code = await main(["run", "--kit", "replay", "--from", "cases.jsonl", "--judge", "keyword"], io);
  assert.equal(code, 2);
  assert.equal(err.at(-1), "記録のキットの名前（meta.kit.name）が正しくありません（いまの値: /../outside）。ai-concierge・line-concierge・doc-reader・http・replay のどれかにしてください。");
  assert.equal(existsSync(join(dir, "runs")), false);
}));

test("答えさせた問いが全部実行エラーなら終了コード 3", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円\n`);
  const fetchImpl = (async () => new Response("", { status: 500 })) as unknown as typeof fetch;
  const { io, out, err } = ioOf(dir, { fetch: fetchImpl });
  const code = await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--judge", "keyword"], io);
  assert.equal(code, 3);
  assert.ok(err.includes("すべての問いが実行エラーになりました。report.html の「実行エラー」で理由をご確認ください。"), err.join("\n"));
  assert.ok(out.includes("終了コード: 3"));
}));

test("--tags で絞り込んだ結果が 0 問なら、API を呼ぶ前に 2 で止める", withDir(async (dir) => {
  writeFileSync(join(dir, "cases.csv"), `${HEAD}\nq1,料金は,80 万円,,,料金\n`);
  let called = 0;
  const { io, err } = ioOf(dir, { fetch: (async () => (called += 1, Response.json({}))) as unknown as typeof fetch, env: { ANTHROPIC_API_KEY: "sk-test" } });
  const code = await main(["run", "--kit", "http", "--url", "http://127.0.0.1:8787/ask", "--cases", "cases.csv", "--tags", "存在しない"], io);
  assert.equal(code, 2);
  assert.deepEqual(err, ["絞り込んだ結果、問いが 0 になりました。--tags と --limit をご確認ください。"]);
  assert.equal(called, 0);
}));
