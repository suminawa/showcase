import { test } from "node:test";
import assert from "node:assert/strict";
import { includesNormalized, normalizeText } from "../src/normalize.ts";

test("NFKC で全角の英数と記号を半角にする", () => {
  assert.equal(normalizeText("ＡＢＣ１２３（税込）"), "abc123(税込)");
});

test("空白と、数字の桁区切りの , を除く", () => {
  assert.equal(normalizeText("80 万円 〜 1,500 円"), "80万円~1500円");
  assert.equal(normalizeText("1,200,000 円"), "1200000円");
  assert.equal(normalizeText("A, B"), "a,b");
});

test("英字は小文字、波ダッシュとハイフンのゆれをそろえる", () => {
  assert.equal(normalizeText("Claude ～ API"), "claude~api");
  assert.equal(normalizeText("03−0000‐1111"), "03-0000-1111");
  assert.equal(normalizeText("コーヒー"), "コーヒー");
});

test("includesNormalized: 揃えてから部分一致。空の語は一致としない", () => {
  assert.equal(includesNormalized("キッチンは８０万円～１５０万円です", "80 万円〜150 万円"), true);
  assert.equal(includesNormalized("銀行振込のみです", "クレジットカード"), false);
  assert.equal(includesNormalized("何か", "  "), false);
});
