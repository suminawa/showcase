import { test } from "node:test";
import assert from "node:assert/strict";
import { parseCasesJsonl, toCasesJsonl } from "../src/adapters/replay.ts";
import { createReplayJudge } from "../src/judge/replay.ts";
import type { CaseRecord, JudgeOutcome, RunMeta } from "../src/types.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

test("記録の採点をそのまま返す（費用も記録のまま）。採点の無い問いは採点エラー", async () => {
  const judged: JudgeOutcome = {
    ok: true,
    judgment: { declined: false, points: ["covered"], forbidden: [], reason: "要点を満たしています。", incomplete: false },
    usage: [{ model: "claude-sonnet-5", input: 300, output: 60, cacheRead: 1200, cacheWrite5m: 0, cacheWrite1h: 0, lowerBound: false }],
    raw: "{}",
  };
  const record = (id: string, judge: JudgeOutcome | null): CaseRecord => ({
    case: caseOf({ id, points: ["2 年"] }),
    answer: answerOf({ answer: "2 年です。" }),
    judge,
    result: { id, round: 0, tags: [], verdict: "correct", points: [], forbidden: [], citationHit: null, retrievalHit: null, refused: false, handoff: null, latencyMs: 1, attempts: 1, reason: "", judgedBy: "claude", incomplete: false },
  });
  const meta = { kit: { name: "ai-concierge", label: "みなと工務店の案内窓口", mode: "in-process", version: "1.0.1", model: "claude-opus-5" }, judge: { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" } } as RunMeta;
  const judge = createReplayJudge(parseCasesJsonl(toCasesJsonl(meta, [record("q1", judged), record("q2", null)])));
  assert.deepEqual(judge.info, { mode: "replay", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" });
  assert.deepEqual(await judge.judge(caseOf({ id: "q1" }), answerOf(), 0), judged);
  assert.deepEqual(await judge.judge(caseOf({ id: "q2" }), answerOf(), 0), { ok: false, error: "記録に採点がありません（q2）。", usage: [], raw: null });
});
