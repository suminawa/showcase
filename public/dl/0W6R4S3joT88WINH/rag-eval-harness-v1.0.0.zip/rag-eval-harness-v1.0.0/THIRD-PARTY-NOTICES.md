# サードパーティのお知らせ / Third-Party Notices

このハーネスは、次のオープンソースソフトウェアを使います。zip には依存の本体を入れていません（`npm ci` で入ります）。直接の依存 1 つの名前・版・ライセンスの全文は、下記のとおりです。`npm ci` で入る間接の依存のライセンスは、`npx license-checker --production` などでご確認いただけます。

This harness uses the following open-source software. The zip does not include the dependency itself (it is installed by `npm ci`). The name, version and full license text of the one direct dependency are reproduced below. You can review the licenses of the indirect dependencies installed by `npm ci` with a tool such as `npx license-checker --production`.

## @anthropic-ai/sdk 0.128.0（MIT）

```
Copyright 2023 Anthropic, PBC.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

```
