// 任意の HTTP の窓口の見本（node:http だけ）。決まった答えと出典を、ハーネスの既定の形で返します。
// 動かし方: node examples/http-server.mjs → 別の端末で
//   npm run eval -- --kit http --url http://127.0.0.1:8787/ask --cases cases/http-example.csv --judge keyword
import { createServer } from "node:http";

const PRICE = { title: "料金", url: "https://example.com/price" };
const ANSWERS = [
  { match: "見積もり", answer: "お見積もりは無料です。現地調査のうえでお出しします。", sources: [PRICE] },
  { match: "保証", answer: "施工部分は 2 年間の保証です（引き渡しから数えます）。", sources: [{ title: "保証", url: "https://example.com/warranty" }] },
  { match: "クレジットカード", answer: "お支払いは銀行振込のみです。", sources: [PRICE] },
  { match: "営業時間", answer: "平日 9:00〜18:00 に営業しております。", sources: [{ title: "会社概要", url: "https://example.com/about" }] },
];

const server = createServer((request, response) => {
  if (request.method !== "POST" || request.url !== "/ask") {
    response.writeHead(404, { "content-type": "application/json" }).end(JSON.stringify({ message: "POST /ask で聞いてください。" }));
    return;
  }
  let body = "";
  request.setEncoding("utf8");
  request.on("data", (chunk) => (body += chunk));
  request.on("end", () => {
    let question = "";
    try {
      question = String(JSON.parse(body).question ?? "");
    } catch {
      response.writeHead(400, { "content-type": "application/json" }).end(JSON.stringify({ message: "JSON で送ってください。" }));
      return;
    }
    const found = ANSWERS.find((item) => question.includes(item.match));
    const reply = found === undefined
      ? { answer: "資料に載っていないため、お答えできません。", sources: [], refused: true }
      : { answer: found.answer, sources: found.sources, refused: false };
    response.writeHead(200, { "content-type": "application/json; charset=utf-8" }).end(JSON.stringify(reply));
  });
});

const port = Number(process.env.PORT ?? 8787);
server.listen(port, "127.0.0.1", () => console.log(`見本の窓口: http://127.0.0.1:${port}/ask`));
