import { defineConfig } from "tsup";

// 入口は cli.ts の 1 本。依存（@anthropic-ai/sdk）は束ねず、npm ci で入れたものを読む
export default defineConfig({
  entry: { cli: "src/cli.ts" },
  format: ["esm"],
  platform: "node",
  target: "node20",
  outDir: "dist",
  clean: true,
  splitting: false,
  sourcemap: false,
  dts: false,
  banner: { js: "#!/usr/bin/env node" },
});
