#!/usr/bin/env node
/*
 * 配布 zip を release/ に作る（npm run release が build → test のあとに呼ぶ）。
 * zip の中は rag-eval-harness-v<版>/ の 1 つのフォルダにまとめる。使うのは OS の zip コマンドだけ。
 * 元: MCP サーバー キット 1.0.0 の scripts/release.mjs（入れるフォルダとファイル、zip の名前、runs/ と .env を除く決まりを変えた）
 */
import { execFileSync } from "node:child_process";
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/** 丸ごと入れるフォルダ（この並びの順に、中は名前順で入れる） */
export const RELEASE_DIRS = ["dist", "src", "cases", "samples", "examples", "test", "scripts"];

/** 単体で入れるファイル（package-lock.json は npm ci に要る） */
export const RELEASE_FILES = [
  "README.ja.md",
  "README.md",
  "LICENSE.md",
  "THIRD-PARTY-NOTICES.md",
  "CHANGELOG.md",
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "tsup.config.ts",
  ".gitignore",
];

/** npm run build が作るもの。無ければ zip を作らない */
export const RELEASE_GENERATED = ["dist/cli.js"];

/** 入れない名前（評価の出力 runs/ と、鍵の入りうる .env、来訪者の質問の from-admin-*.csv はどの階層でも） */
const SKIP_NAMES = ["node_modules", ".git", ".DS_Store", "release", "runs"];

export function releaseKeepName(name) {
  if (SKIP_NAMES.includes(name)) return false;
  if (name.startsWith(".env")) return false;
  // .gitignore の /cases/from-admin-*.csv（来訪者の生の質問）と同じ
  if (/^from-admin-.*\.csv$/.test(name)) return false;
  return true;
}

function walk(root, relDir) {
  const found = [];
  for (const name of readdirSync(join(root, relDir)).slice().sort()) {
    if (!releaseKeepName(name)) continue;
    const relPath = `${relDir}/${name}`;
    if (statSync(join(root, relPath)).isDirectory()) found.push(...walk(root, relPath));
    else found.push(relPath);
  }
  return found;
}

/** zip に入るファイルの一覧（root からの相対の道すじ）。読むだけなので検査からそのまま呼べる */
export function releaseFileList(root = ROOT) {
  const found = [];
  for (const dir of RELEASE_DIRS) if (existsSync(join(root, dir))) found.push(...walk(root, dir));
  for (const file of RELEASE_FILES) if (existsSync(join(root, file))) found.push(file);
  return found;
}

export function releaseMissing(root = ROOT) {
  return [...RELEASE_GENERATED, ...RELEASE_FILES].filter((relPath) => !existsSync(join(root, relPath)));
}

export function releaseFolderName(root = ROOT) {
  return `rag-eval-harness-v${JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version}`;
}

export function releaseZipPath(root = ROOT) {
  return join(root, "release", `${releaseFolderName(root)}.zip`);
}

/** zip を作る。そろっていなければ Error を投げる。返すのは { zipPath, bytes, files } */
export function createRelease(root = ROOT, outPath) {
  const missing = releaseMissing(root);
  if (missing.length > 0) {
    throw new Error(`配布 zip を作れません。次のファイルがまだありません。\n  ${missing.join("\n  ")}\n先に npm run build を実行してください（npm run release なら自動で実行されます）。`);
  }
  const zipPath = outPath === undefined ? releaseZipPath(root) : resolve(outPath);
  const folder = releaseFolderName(root);
  const files = releaseFileList(root);
  mkdirSync(dirname(zipPath), { recursive: true });
  if (existsSync(zipPath)) rmSync(zipPath);
  // zip はフォルダ名を付け替えられないので、いちど写してから固める
  const stage = `${zipPath}.stage`;
  rmSync(stage, { recursive: true, force: true });
  for (const relPath of files) {
    const to = join(stage, folder, relPath);
    mkdirSync(dirname(to), { recursive: true });
    // 同じコミットで 2 回作った zip の中身が同じ大きさ・同じ一覧になるよう、コピー元の更新日時をそのまま持ち越す
    cpSync(join(root, relPath), to, { preserveTimestamps: true });
  }
  try {
    execFileSync("zip", ["-q", "-X", zipPath, ...files.map((relPath) => `${folder}/${relPath}`)], { cwd: stage });
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }
  return { zipPath, bytes: statSync(zipPath).size, files: files.length };
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  try {
    const made = createRelease();
    console.log(`${made.zipPath} を作りました`);
    console.log(`大きさ: ${made.bytes.toLocaleString("ja-JP")} バイト / ファイル数: ${made.files}`);
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
}
