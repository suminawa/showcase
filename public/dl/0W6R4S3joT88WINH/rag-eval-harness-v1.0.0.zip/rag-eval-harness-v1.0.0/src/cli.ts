/**
 * rag-eval（npm run eval / demo / cases / report / judge:check）
 * 旗の読み取り・コマンドの振り分け・終わりの 5 行・終了コード。
 * 終了コード: 0 = 終わった／1 = --min-score・--max-drop に届かない（judge-check は一致が 90% 未満）／
 * 2 = 使い方・質問表・キットの読み込みの誤り（API を呼ぶ前）／3 = 全部の問いが実行エラー
 */
import { accessSync, constants, existsSync, mkdirSync, readFileSync, realpathSync, statSync, writeFileSync } from "node:fs";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createAiConciergeAdapter, createAiConciergeHttpAdapter } from "./adapters/ai-concierge.ts";
import { NO_KEY_MESSAGE, buildSampleIndex } from "./adapters/common.ts";
import { checkDocCases, createDocReaderAdapter } from "./adapters/doc-reader.ts";
import { createHttpAdapter, loadHttpMap } from "./adapters/http.ts";
import { createLineConciergeAdapter } from "./adapters/line-concierge.ts";
import type { CreateClientLike, StreamClientLike } from "./adapters/recording-client.ts";
import { casesOfRecords, createReplayAdapter, readCasesJsonl, type CasesJsonl } from "./adapters/replay.ts";
import { loadCasesFile } from "./cases/cases.ts";
import { CsvError, decodeUtf8 } from "./cases/csv.ts";
import { casesFromAdmin } from "./cases/from-admin.ts";
import { HarnessError } from "./errors.ts";
import { DEFAULT_JUDGE_EFFORT, DEFAULT_JUDGE_MODEL, JUDGE_EFFORTS, SAME_MODEL_NOTE, createClaudeJudge, createJudgeClient, type JudgeClientLike, type JudgeEffort } from "./judge/claude.ts";
import { AGREEMENT_FLOOR, loadCalibration, runCalibration, runWiringCheck } from "./judge/calibration.ts";
import { KEYWORD_NOTE, createKeywordJudge } from "./judge/keyword.ts";
import { createReplayJudge } from "./judge/replay.ts";
import { DEFAULT_YEN_PER_USD, costYen } from "./pricing.ts";
import { buildResultJson } from "./report/json.ts";
import { VERDICT_LABELS, formatDelta, formatRate, formatYen, judgeLabel, kitLabel, runStamp } from "./report/format.ts";
import { writeOutputs } from "./report/write.ts";
import { runCases } from "./run.ts";
import { aggregate } from "./score/aggregate.ts";
import { checkThresholds, diffResults, findBaseline, readResultJson } from "./score/diff.ts";
import type { Adapter, BaselineDiff, EvalCase, Judge, KitName, ResultJson, RunMeta, Summary, UsageRecord } from "./types.ts";

/** ハーネスのフォルダ（src/ と dist/ の 1 つ上） */
export const HARNESS_ROOT = fileURLToPath(new URL("..", import.meta.url));

export const KITS: KitName[] = ["ai-concierge", "line-concierge", "doc-reader", "http", "replay"];

/** --sample で使う同梱の質問表 */
export const SAMPLE_CASES: Record<string, string> = {
  "ai-concierge": "cases/ai-concierge.csv",
  "line-concierge": "cases/line-concierge.csv",
  "doc-reader": "cases/doc-reader.csv",
  http: "cases/http-example.csv",
};

export const DEMO_RECORDING = "samples/recorded/ai-concierge.jsonl";
/** npm run demo:diff の「あと」。見本の文書の価格表 1 行をわざと書き換えて取った記録（「前」は DEMO_RECORDING） */
export const DEMO_AFTER_RECORDING = "samples/recorded/ai-concierge-after.jsonl";

/** demo の再生の指定（既定は runs/demo に DEMO_RECORDING。demo:diff は 2 回に分ける） */
interface DemoPlan {
  recording: string;
  dir: string[];
  baseline: string | null;
}
export const CALIBRATION_FILE = "samples/calibration.jsonl";
/** 正しい見本と空の見本で確かめる問いの数（見本の案内窓口の質問表の先頭から） */
export const WIRING_CASES = 5;
export const REPLAY_NOTE = "記録した答えと採点を再生しています（API は呼んでいません。費用は記録したときの額です）。";
const REPLAY_ANSWERS_NOTE = "記録した答えを再生し、採点だけをいま行いました（キットは呼んでいません。答えの費用は記録したときの額です）。";
const LOWER_BOUND_NOTE = "キャッシュの書き込みの数が分からない呼び出しがあるため、費用は「以上」です。";
const UNKNOWN_MODELS_NOTE_HEAD = "値段の表に無いモデル（";

/** 旗の一覧（README の「旗の一覧」の表と同じ並び。docs.test が照合する） */
export const FLAG_ROWS: Array<{ names: string[]; fallback: string; meaning: string }> = [
  { names: ["--kit"], fallback: "（必須）", meaning: "ai-concierge・line-concierge・doc-reader・http・replay" },
  { names: ["--cases"], fallback: "（必須。--sample なら不要）", meaning: "質問表の CSV" },
  { names: ["--sample"], fallback: "", meaning: "キットに合う同梱の質問表と、キットのフォルダの見本（設定・文書・書類）を使う" },
  { names: ["--kit-dir"], fallback: "", meaning: "キットのフォルダ（手元で呼ぶとき必須）" },
  { names: ["--config", "--index", "--forms"], fallback: "キットのフォルダの既定の場所", meaning: "自分の設定・索引・帳票の型" },
  { names: ["--url", "--map"], fallback: "", meaning: "HTTP で呼ぶ窓口と、形の対応表" },
  { names: ["--from"], fallback: "", meaning: "replay で読む cases.jsonl" },
  { names: ["--judge"], fallback: "claude", meaning: "claude・keyword・replay" },
  { names: ["--judge-model", "--judge-effort"], fallback: "claude-sonnet-5 / low", meaning: "採点のモデルと effort（low・medium・high）" },
  { names: ["--concurrency"], fallback: "2（http の ai-concierge は 1）", meaning: "キットへの同時の問い（1〜8）。採点は 4 に固定" },
  { names: ["--interval-ms"], fallback: "0（http の ai-concierge は 7000）", meaning: "問いの間の待ち" },
  { names: ["--repeat"], fallback: "1", meaning: "1〜5" },
  { names: ["--tags", "--limit"], fallback: "", meaning: "タグで絞る（, 区切り）／先頭 n 問だけ" },
  { names: ["--baseline"], fallback: "auto", meaning: "auto・パス・none" },
  { names: ["--min-score", "--max-drop"], fallback: "", meaning: "CI 用。正答率がこれ未満、または前回からこれより下がったら終了コード 1（どちらも 0〜100 のポイント）" },
  { names: ["--out", "--yen-per-usd", "--no-redact"], fallback: "runs / 150", meaning: "出力の親・換算・伏せ字を外す" },
  { names: ["--dry-run"], fallback: "", meaning: "質問表とキットの読み込みまで確かめ、API を呼ばない" },
];

/** 値を取らない旗 */
export const SWITCHES = new Set(["--sample", "--no-redact", "--dry-run"]);
const KNOWN_FLAGS = new Set(FLAG_ROWS.flatMap((row) => row.names));

/** --judge-model に使える名前の頭（effort を送らないのは claude-haiku- だけ。judge/claude.ts の buildJudgeRequest） */
const JUDGE_MODEL_PREFIXES = ["claude-sonnet-", "claude-opus-", "claude-haiku-"];
/** run.ts が打ち切りの問いに添える印の usage の model（キットの model が分からないとき）。値段の表に無いモデルとしては出さない */
const TIMEOUT_USAGE_MODEL = "unknown";

export const USAGE = `RAG 評価ハーネス（rag-eval）— AI 窓口の答え合わせを、表 1 枚で。

使い方:
  npm run eval -- --kit ai-concierge --kit-dir <キットのフォルダ> --sample      見本の質問表で回す
  npm run eval -- --kit ai-concierge --kit-dir <…> --cases my-cases.csv       自分の質問表で回す
  npm run eval -- --kit http --url http://127.0.0.1:8787/ask --cases <…>      任意の HTTP の窓口を回す
  npm run demo                                        鍵なしで見本のレポートを作る（runs/demo/report.html）
  npm run demo:diff                                   鍵なしで「更新の前と後」の比べ方を見る（runs/demo-diff/report.html）
  npm run cases -- check <質問表.csv> [--kit <キット>]   質問表を確かめる（API を呼ばない）
  npm run cases -- from-admin <export.csv>            案内窓口の /admin/export の CSV から質問表を作る
  npm run report -- <runs のフォルダ>                  cases.jsonl から出力を描き直す（API を呼ばない）
  npm run judge:check                                  採点の確かめ（較正 30 件と、正しい見本・空の見本）

CI では --min-score 80 --max-drop 5 のように付けます。--min-score と --max-drop は 0〜100 のポイントで指定します（0.8 ではなく 80）。
旗の一覧は README の「旗の一覧」をご覧ください。鍵は環境変数 ANTHROPIC_API_KEY だけから読みます。`;

export interface CliIo {
  stdout(line: string): void;
  stderr(line: string): void;
  env: Record<string, string | undefined>;
  cwd: string;
  now(): Date;
  /** 検査用: 本物の Anthropic の代わり（キットにも採点にも使う） */
  anthropic?: StreamClientLike & CreateClientLike & JudgeClientLike;
  fetch?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
}

export interface ParsedArgs {
  command: string;
  positionals: string[];
  flags: Map<string, string | true>;
}

export function parseArgs(argv: string[]): ParsedArgs {
  // 旗はコマンドの前にも後ろにも置ける（rag-eval --kit http run a.csv）。最初に出てきた旗でない字がコマンド、残りは positionals
  let command: string | undefined;
  const positionals: string[] = [];
  const flags = new Map<string, string | true>();
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith("--")) {
      if (command === undefined) command = arg;
      else positionals.push(arg);
      continue;
    }
    const [name, inline] = arg.includes("=") ? [arg.slice(0, arg.indexOf("=")), arg.slice(arg.indexOf("=") + 1)] : [arg, undefined];
    if (name === "--help") {
      flags.set(name, true);
      continue;
    }
    if (!KNOWN_FLAGS.has(name)) throw new HarnessError(`知らない旗です: ${name}。npm run eval -- --help で使い方を出せます（旗の一覧は README にあります）。`);
    if (SWITCHES.has(name)) {
      if (inline !== undefined) throw new HarnessError(`${name} は値を取りません（${name} とだけ書いてください）。`);
      flags.set(name, true);
      continue;
    }
    const value = inline ?? argv[i + 1];
    // 最後の旗の値が無い・次が旗・--kit= のように空、はどれも値の無い旗として止める（黙って捨てない）
    if (value === undefined || value === "" || (inline === undefined && value.startsWith("--"))) throw new HarnessError(`${name} には値が要ります。`);
    if (inline === undefined) i += 1;
    flags.set(name, value);
  }
  return { command: command ?? "help", positionals, flags };
}

class Options {
  readonly parsed: ParsedArgs;
  readonly cwd: string;

  constructor(parsed: ParsedArgs, cwd: string) {
    this.parsed = parsed;
    this.cwd = cwd;
  }

  str(name: string): string | null {
    const value = this.parsed.flags.get(name);
    return typeof value === "string" ? value : null;
  }

  has(name: string): boolean {
    return this.parsed.flags.has(name);
  }

  path(name: string): string | null {
    const value = this.str(name);
    return value === null ? null : resolve(this.cwd, value);
  }

  num(name: string, min: number, max: number, fallback: number, integer: boolean = true): number {
    const raw = this.str(name);
    if (raw === null) return fallback;
    const value = Number(raw);
    if (!Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) {
      throw new HarnessError(`${name} は ${min}〜${max} の${integer ? "整数" : "数"}にしてください（いまの値: ${raw}）。`);
    }
    return value;
  }

  choice<T extends string>(name: string, choices: readonly T[], fallback: T): T {
    const raw = this.str(name);
    if (raw === null) return fallback;
    if (!choices.includes(raw as T)) throw new HarnessError(`${name} は ${choices.join("・")} のどれかにしてください（いまの値: ${raw}）。`);
    return raw as T;
  }
}

function shown(cwd: string, path: string): string {
  const rel = relative(cwd, path);
  return rel !== "" && !rel.startsWith("..") && !isAbsolute(rel) ? rel : path;
}

/** 読むファイルを確かめる。無い・フォルダ・読めないは、生の ENOENT・EISDIR・EACCES ではなく敬体の文で止める（終了コード 2） */
function requireFile(path: string, label: string): void {
  let isDirectory: boolean;
  try {
    isDirectory = statSync(path).isDirectory();
  } catch {
    throw new HarnessError(`${label} が見つかりません。`);
  }
  if (isDirectory) throw new HarnessError(`${label} はフォルダです。ファイルを指定してください。`);
  try {
    accessSync(path, constants.R_OK);
  } catch {
    throw new HarnessError(`${label} を読めません。ファイルの読み取りの権限をご確認ください。`);
  }
}

function problemsError(title: string, problems: string[]): HarnessError {
  return new HarnessError([`${title}（${problems.length} 件）。API は呼んでいません。`, ...problems.map((problem) => `  ${problem}`)].join("\n"));
}

function toolVersion(): string {
  try {
    return (JSON.parse(readFileSync(join(HARNESS_ROOT, "package.json"), "utf8")) as { version?: string }).version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

/** 終わりの 5 行（正答率・前回との差・費用・レポートの場所・終了コード） */
export function finalLines(summary: Summary, baseline: BaselineDiff | null, baselineMode: string, reportPath: string, exitCode: number): string[] {
  const c = summary.counts;
  const extra = [c.error > 0 ? `実行エラー ${c.error}` : "", c.judgeError > 0 ? `採点エラー ${c.judgeError}` : ""].filter((text) => text !== "");
  const diffLine =
    baseline === null
      ? baselineMode === "none"
        ? "前回との差: 比べていません（--baseline none）"
        : "前回との差: 前回の記録がありません（次の実行から出ます）"
      : `前回との差: ${formatDelta(baseline.delta)} ポイント（良くなった ${baseline.improved.length} 問・悪くなった ${baseline.regressed.length} 問）${baseline.notes.length === 0 ? "" : ` ${baseline.notes.join(" ")}`}`;
  return [
    `正答率 ${formatRate(summary.score)}（正解 ${c.correct}・部分 ${c.partial}・誤り ${c.wrong}・無回答 ${c.noAnswer} ／ 採点できた ${summary.graded} 問${extra.length === 0 ? "" : `・${extra.join("・")}`}）`,
    diffLine,
    `費用: キット ${formatYen(summary.costJpy.kit, summary.costLowerBound)}・採点 ${formatYen(summary.costJpy.judge)}（1 問あたり ${formatYen(summary.costJpy.perQuestion, summary.costLowerBound)}）`,
    `レポート: ${reportPath}`,
    `終了コード: ${exitCode}`,
  ];
}

interface Prepared {
  adapter: Adapter;
  cases: EvalCase[];
  casesMeta: RunMeta["cases"];
  concurrency: number;
  intervalMs: number;
}

async function prepare(options: Options, io: CliIo, kit: KitName, jsonl: CasesJsonl | null, apiKey: string | null, outRoot: string): Promise<Prepared> {
  const sample = options.has("--sample");
  const kitDir = options.path("--kit-dir");
  const requireKitDir = (): string => {
    if (kitDir === null) throw new HarnessError(`--kit ${kit} では --kit-dir にキットのフォルダ（zip を展開したフォルダ）を指定してください。`);
    return kitDir;
  };
  const url = options.str("--url");
  const inProcess = (kit === "ai-concierge" && url === null) || kit === "line-concierge" || kit === "doc-reader";

  // 質問表（replay で --cases が無ければ記録の問い）
  let cases: EvalCase[];
  let casesMeta: RunMeta["cases"];
  const casesPath = sample && SAMPLE_CASES[kit] !== undefined ? join(HARNESS_ROOT, SAMPLE_CASES[kit]) : options.path("--cases");
  if (kit === "replay" && casesPath === null && jsonl !== null) {
    cases = casesOfRecords(jsonl.records);
    casesMeta = jsonl.meta?.cases ?? { file: "cases.jsonl", sha256: "", count: cases.length };
  } else {
    if (casesPath === null) throw new HarnessError("--cases に質問表の CSV を指定してください（見本で試すときは --sample）。");
    // 見本の書類はキットのフォルダの samples/ にある（質問表の「書類」は docs/invoice-01.pdf の形）
    const baseDir = sample && kit === "doc-reader" ? join(requireKitDir(), "samples") : undefined;
    requireFile(casesPath, `質問表 ${sample ? SAMPLE_CASES[kit] : (options.str("--cases") ?? casesPath)}`);
    const loaded = loadCasesFile(casesPath, { kit, baseDir });
    if (loaded.problems.length > 0) throw problemsError("質問表に直すところがあります", loaded.problems);
    cases = loaded.cases;
    casesMeta = { file: sample ? SAMPLE_CASES[kit] : shown(io.cwd, casesPath), sha256: loaded.sha256, count: loaded.cases.length };
  }
  const tags = (options.str("--tags") ?? "").split(",").map((tag) => tag.trim()).filter((tag) => tag !== "");
  if (tags.length > 0) cases = cases.filter((c) => c.tags.some((tag) => tags.includes(tag)));
  const limit = options.str("--limit") === null ? null : options.num("--limit", 1, 100000, 1);
  if (limit !== null) cases = cases.slice(0, limit);
  if (cases.length === 0) throw new HarnessError("絞り込んだ結果、問いが 0 になりました。--tags と --limit をご確認ください。");

  if (!options.has("--dry-run") && apiKey === null && inProcess && io.anthropic === undefined) throw new HarnessError(NO_KEY_MESSAGE);

  const sampleIndex = (name: string, cliPath: string, configPath: string): string => {
    const out = join(outRoot, ".cache", `${name}-index.json`);
    buildSampleIndex(cliPath, requireKitDir(), configPath, out);
    return out;
  };
  // --config を指定したのに無ければ、キットの既定に戻さずに止める（書類読み取りのキットは、無い設定を黙って既定で埋めるため）
  const explicitConfig = options.path("--config");
  if (explicitConfig !== null) requireFile(explicitConfig, `--config のファイル ${options.str("--config")}`);
  const conciergeConfig = () => explicitConfig ?? join(requireKitDir(), sample ? join("samples", "concierge.config.json") : "concierge.config.json");
  let adapter: Adapter;
  if (kit === "ai-concierge" && url !== null) {
    adapter = createAiConciergeHttpAdapter({ url, fetchImpl: io.fetch });
  } else if (kit === "ai-concierge") {
    const configPath = conciergeConfig();
    const indexPath = options.path("--index") ?? (sample ? sampleIndex("ai-concierge", join(requireKitDir(), "dist", "cli.js"), configPath) : join(requireKitDir(), "data", "index.json"));
    adapter = await createAiConciergeAdapter({ kitDir: requireKitDir(), configPath, indexPath, apiKey, baseClient: io.anthropic });
  } else if (kit === "line-concierge") {
    const configPath = conciergeConfig();
    const cli = join(requireKitDir(), "node_modules", "@suminawa", "ai-concierge", "dist", "cli.js");
    const indexPath = options.path("--index") ?? (sample ? sampleIndex("line-concierge", cli, configPath) : join(requireKitDir(), "data", "index.json"));
    adapter = await createLineConciergeAdapter({ kitDir: requireKitDir(), configPath, indexPath, apiKey, baseClient: io.anthropic });
  } else if (kit === "doc-reader") {
    const reader = await createDocReaderAdapter({
      kitDir: requireKitDir(),
      configPath: explicitConfig ?? join(requireKitDir(), "reader.config.json"),
      formsDir: options.path("--forms") ?? join(requireKitDir(), "forms"),
      apiKey,
      baseClient: io.anthropic,
    });
    const problems = checkDocCases(cases, reader.forms);
    if (problems.length > 0) throw problemsError("質問表の帳票の型か項目の名前が、キットと合いません", problems);
    adapter = reader;
  } else if (kit === "http") {
    if (url === null) throw new HarnessError("--kit http では --url に窓口のアドレスを指定してください。");
    const mapPath = options.path("--map");
    adapter = createHttpAdapter({ url, map: mapPath === null ? undefined : loadHttpMap(mapPath), env: io.env, fetchImpl: io.fetch });
  } else {
    adapter = createReplayAdapter(jsonl as CasesJsonl);
  }
  const slowHttp = kit === "ai-concierge" && url !== null;
  return {
    adapter,
    cases,
    casesMeta,
    concurrency: options.num("--concurrency", 1, 8, slowHttp ? 1 : 2),
    intervalMs: options.num("--interval-ms", 0, 600000, slowHttp ? 7000 : 0),
  };
}

function buildJudge(options: Options, io: CliIo, mode: "claude" | "keyword" | "replay", jsonl: CasesJsonl | null, apiKey: string | null): Judge {
  if (mode !== "claude") {
    // --judge-model・--judge-effort は claude の採点にしか使わない。keyword・replay では黙って捨てず、敬体でお知らせする
    const unused = ["--judge-model", "--judge-effort"].filter((name) => options.has(name));
    if (unused.length > 0) io.stderr(`${unused.join("・")} は --judge ${mode} では使いません（このまま進みます）。`);
  }
  if (mode === "keyword") return createKeywordJudge();
  if (mode === "replay") return createReplayJudge(jsonl as CasesJsonl);
  const model = options.str("--judge-model") ?? DEFAULT_JUDGE_MODEL;
  if (!JUDGE_MODEL_PREFIXES.some((prefix) => model.startsWith(prefix))) {
    throw new HarnessError(`--judge-model は ${JUDGE_MODEL_PREFIXES.join("・")} のどれかで始まるモデルにしてください（いまの値: ${model}）。`);
  }
  const effort = options.choice<JudgeEffort>("--judge-effort", JUDGE_EFFORTS, DEFAULT_JUDGE_EFFORT);
  const client = io.anthropic ?? (apiKey === null ? null : createJudgeClient(apiKey));
  if (client === null) {
    return { info: { mode: "claude", model, effort, rubricVersion: null }, judge: async () => ({ ok: false, error: NO_KEY_MESSAGE, usage: [], raw: null }) };
  }
  return createClaudeJudge({ client, model, effort, sleep: io.sleep });
}

async function runCommand(options: Options, io: CliIo, demo: boolean, plan: DemoPlan = { recording: DEMO_RECORDING, dir: ["demo"], baseline: null }): Promise<number> {
  const kitRaw = demo ? "replay" : options.str("--kit");
  if (kitRaw === null) throw new HarnessError(`--kit を指定してください（${KITS.join("・")}）。`);
  if (!KITS.includes(kitRaw as KitName)) throw new HarnessError(`--kit は ${KITS.join("・")} のどれかにしてください（いまの値: ${kitRaw}）。`);
  const kit = kitRaw as KitName;
  const outRoot = options.path("--out") ?? resolve(io.cwd, "runs");
  const judgeMode = demo ? "replay" : options.choice("--judge", ["claude", "keyword", "replay"] as const, "claude");
  // 記録の採点は記録の答えにだけ合う（いまの答えに前の採点を付けない）
  if (judgeMode === "replay" && kit !== "replay") {
    throw new HarnessError("--judge replay は --kit replay とだけ組み合わせられます（記録の採点は、記録の答えにだけ合います）。いまの答えを採点するときは --judge claude か --judge keyword にしてください。");
  }
  const repeat = options.num("--repeat", 1, 5, 1);
  const yenPerUsd = options.num("--yen-per-usd", 1, 10000, DEFAULT_YEN_PER_USD, false);
  const baselineMode = demo ? (plan.baseline ?? "none") : (options.str("--baseline") ?? "auto");
  const apiKey = (io.env.ANTHROPIC_API_KEY ?? "").trim() || null;
  const dryRun = options.has("--dry-run");
  // CI の決まり（0〜100 のポイント）は、答えさせる前に確かめる
  const minScore = options.str("--min-score") === null ? null : options.num("--min-score", 0, 100, 0, false);
  const maxDrop = options.str("--max-drop") === null ? null : options.num("--max-drop", 0, 100, 0, false);

  let jsonl: CasesJsonl | null = null;
  if (kit === "replay" || judgeMode === "replay") {
    const from = demo ? join(HARNESS_ROOT, plan.recording) : options.path("--from");
    if (from === null) throw new HarnessError("replay では --from に前の実行の cases.jsonl を指定してください。");
    jsonl = readCasesJsonl(from);
  }
  if (judgeMode === "claude" && !dryRun && apiKey === null && io.anthropic === undefined) throw new HarnessError(NO_KEY_MESSAGE);
  let explicitBaseline: string | null = null;
  if (baselineMode !== "auto" && baselineMode !== "none") {
    const path = resolve(io.cwd, baselineMode);
    explicitBaseline = path.endsWith(".json") ? dirname(path) : path;
    if (!existsSync(join(explicitBaseline, "result.json"))) throw new HarnessError(`--baseline のフォルダに result.json がありません（${baselineMode}）。`);
  }

  // 採点の旗（--judge-model・--judge-effort）も、キットを読み込む前に確かめる
  const judge = buildJudge(options, io, judgeMode, jsonl, apiKey);
  const prepared = await prepare(options, io, kit, jsonl, apiKey, outRoot);
  const { adapter } = prepared;
  // replay では adapter.info.name が cases.jsonl の meta.kit.name（形の検査をしていない）から来るため、
  // 採点（API）を呼ぶ前に決まった名前かどうかを確かめる（/ や .. を含む名前で runs/ の外に書かせない）
  if (!KITS.includes(adapter.info.name as KitName)) {
    throw new HarnessError(`記録のキットの名前（meta.kit.name）が正しくありません（いまの値: ${adapter.info.name}）。${KITS.join("・")} のどれかにしてください。`);
  }
  if (dryRun) {
    io.stdout(`[確かめ] 質問表: ${prepared.casesMeta.file}（${prepared.cases.length} 問）`);
    io.stdout(`[確かめ] キット: ${kitLabel(adapter.info)}・答え ${adapter.info.model ?? "—"}`);
    io.stdout(`[確かめ] 採点: ${judgeLabel(judge.info)}`);
    for (const note of adapter.notes) io.stdout(`[注意] ${note}`);
    io.stdout("--dry-run なので、API は呼びませんでした。");
    return 0;
  }

  const started = io.now();
  const total = prepared.cases.length * repeat;
  io.stderr(`${prepared.cases.length} 問${repeat > 1 ? ` × ${repeat} 回` : ""}を答えさせます（${kitLabel(adapter.info)}）。`);
  const records = await runCases({
    cases: prepared.cases,
    adapter,
    judge,
    concurrency: prepared.concurrency,
    intervalMs: prepared.intervalMs,
    repeat,
    sleep: io.sleep,
    onAnswer: (done) => {
      if (done === total || done % 5 === 0) io.stderr(`答え ${done}/${total}`);
    },
  });
  const finished = io.now();
  const summary = aggregate(records, { yenPerUsd, kit: adapter.info.name });

  // 記録の再生では、記録の注意のうち採点と集計から出したものを捨てて出し直す（採点し直したときに古い注意を残さず、重ねない）
  const recomputed = new Set([KEYWORD_NOTE, REPLAY_NOTE, REPLAY_ANSWERS_NOTE, SAME_MODEL_NOTE, LOWER_BOUND_NOTE]);
  const notes = adapter.notes.filter((note) => !recomputed.has(note) && !note.startsWith(UNKNOWN_MODELS_NOTE_HEAD));
  if (judge.info.mode === "keyword") notes.push(KEYWORD_NOTE);
  // --judge replay は --kit replay とだけ組むので、採点の再生は答えの再生でもある
  if (judge.info.mode === "replay") notes.push(REPLAY_NOTE);
  else if (adapter.info.mode === "replay") notes.push(REPLAY_ANSWERS_NOTE);
  if (judge.info.mode === "claude" && adapter.info.model !== null && adapter.info.model === judge.info.model) notes.push(SAME_MODEL_NOTE);
  if (adapter.info.mode === "http" && summary.costJpy.kit === 0) notes.push("キットの費用は、窓口が usage と model を返したときだけ数えます。");
  const unknownModels = summary.unknownModels.filter((model) => model !== TIMEOUT_USAGE_MODEL);
  if (unknownModels.length > 0) notes.push(`${UNKNOWN_MODELS_NOTE_HEAD}${unknownModels.join("・")}）の費用は入れていません。`);
  if (summary.costLowerBound) notes.push(LOWER_BOUND_NOTE);

  const meta: RunMeta = {
    tool: { name: "rag-eval-harness", version: toolVersion() },
    startedAt: started.toISOString(),
    finishedAt: finished.toISOString(),
    kit: adapter.info,
    judge: judge.info,
    cases: prepared.casesMeta,
    rounds: repeat,
    notes,
    yenPerUsd,
    redact: !options.has("--no-redact"),
  };
  let dir = demo ? join(outRoot, ...plan.dir) : join(outRoot, `${runStamp(started)}-${adapter.info.name}`);
  for (let n = 2; !demo && existsSync(dir); n += 1) dir = join(outRoot, `${runStamp(started)}-${adapter.info.name}-${n}`);

  let baseline: BaselineDiff | null = null;
  let previous: ResultJson | null = null;
  const baselineDir = baselineMode === "none" ? null : (explicitBaseline ?? findBaseline(outRoot, adapter.info.name, dir));
  if (baselineDir !== null) {
    previous = readResultJson(join(baselineDir, "result.json"));
    const current = buildResultJson({ meta, summary, baseline: null, previous: null, records });
    baseline = diffResults(current, previous, shown(io.cwd, baselineDir));
  }
  writeOutputs(dir, { meta, summary, baseline, previous, records });

  let exitCode = 0;
  if (records.every((record) => record.result.verdict === "error")) {
    exitCode = 3;
    io.stderr("すべての問いが実行エラーになりました。report.html の「実行エラー」で理由をご確認ください。");
  } else {
    if (maxDrop !== null && (baseline === null || baseline.delta === null)) {
      io.stderr(
        baselineMode === "none"
          ? "--baseline none のため、--max-drop の確かめは飛ばしました。"
          : baseline === null
            ? "前回の記録が無いため、--max-drop の確かめは飛ばしました。"
            : "前回か今回の正答率が出ていないため、--max-drop の確かめは飛ばしました。",
      );
    }
    const checked = checkThresholds(summary.score, baseline?.delta ?? null, minScore, maxDrop);
    for (const message of checked.messages) io.stderr(message);
    exitCode = checked.exitCode;
  }
  for (const line of finalLines(summary, baseline, baselineMode, shown(io.cwd, join(dir, "report.html")), exitCode)) io.stdout(line);
  return exitCode;
}

/** npm run demo:diff: 「前」と「あと」の記録を鍵なしで再生し、あとのレポートの先頭に悪くなった問いを出す */
async function demoDiffCommand(options: Options, io: CliIo): Promise<number> {
  const outRoot = options.path("--out") ?? resolve(io.cwd, "runs");
  const quiet: CliIo = { ...io, stdout: () => {}, stderr: () => {} };
  const beforeDir = join(outRoot, "demo-diff", "before");
  const first = await runCommand(options, quiet, true, { recording: DEMO_RECORDING, dir: ["demo-diff", "before"], baseline: null });
  if (first !== 0) return first;
  io.stdout("再生のデモです。「あと」は、見本の文書の価格表 1 行（キッチンの入れ替え 80 万円〜150 万円）をわざと 100 万円〜190 万円に書き換えて取った記録で、実際の窓口の結果ではありません。");
  return await runCommand(options, io, true, { recording: DEMO_AFTER_RECORDING, dir: ["demo-diff"], baseline: beforeDir });
}

async function casesCommand(options: Options, io: CliIo): Promise<number> {
  const [sub, file] = options.parsed.positionals;
  if (file === undefined || (sub !== "check" && sub !== "from-admin")) throw new HarnessError("npm run cases -- check <質問表.csv> か npm run cases -- from-admin <export.csv> の形で指定してください。");
  const path = resolve(io.cwd, file);
  requireFile(path, file);
  if (sub === "check") {
    const kit = options.str("--kit");
    if (kit !== null && !KITS.includes(kit as KitName)) throw new HarnessError(`--kit は ${KITS.join("・")} のどれかにしてください（いまの値: ${kit}）。`);
    const loaded = loadCasesFile(path, { kit: kit as KitName | null });
    if (loaded.problems.length > 0) throw problemsError("質問表に直すところがあります", loaded.problems);
    const count = (special: string) => loaded.cases.filter((c) => c.special === special).length;
    io.stdout(`[OK] ${file}: ${loaded.cases.length} 問（断るべき ${count("refuse")}・引き継ぐ ${count("handoff")}・前の質問つき ${loaded.cases.filter((c) => c.previous !== null).length}）。直すところはありません。`);
    if (loaded.unknownColumns.length > 0) io.stdout(`[注意] 知らない列（${loaded.unknownColumns.join("・")}）は、レポートに「ご参考」として出します。`);
    return 0;
  }
  const result = casesFromAdmin(decodeUtf8(readFileSync(path)));
  const stamp = runStamp(io.now()).slice(0, 8);
  const outDir = options.path("--out") ?? resolve(io.cwd, "cases");
  mkdirSync(outDir, { recursive: true });
  // 前に書き出したファイル（要点を書き足しているかもしれない）は上書きしない。あれば -2・-3 … を付ける
  let outPath = join(outDir, `from-admin-${stamp}.csv`);
  for (let n = 2; ; n += 1) {
    try {
      writeFileSync(outPath, result.csv, { flag: "wx" });
      break;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      outPath = join(outDir, `from-admin-${stamp}-${n}.csv`);
    }
  }
  io.stdout(`[OK] 未回答の質問 ${result.count} 問を ${shown(io.cwd, outPath)} に書きました。「期待する答えの要点」を書き足してから、--cases に指定してください。`);
  return 0;
}

async function reportCommand(options: Options, io: CliIo): Promise<number> {
  const target = options.parsed.positionals[0];
  if (target === undefined) throw new HarnessError("npm run report -- runs/<フォルダ> のように、描き直すフォルダを指定してください。");
  const dir = resolve(io.cwd, target);
  if (!existsSync(join(dir, "cases.jsonl"))) throw new HarnessError(`${target} に cases.jsonl がありません。runs の下の、1 回の実行のフォルダを指定してください。`);
  const jsonl = readCasesJsonl(join(dir, "cases.jsonl"));
  if (jsonl.meta === null) throw new HarnessError(`${target}/cases.jsonl に実行の情報（1 行目）がありません。`);
  const summary = aggregate(jsonl.records, { yenPerUsd: jsonl.meta.yenPerUsd, kit: jsonl.meta.kit.name });
  const existing = existsSync(join(dir, "result.json")) ? readResultJson(join(dir, "result.json")) : null;
  const baseline = existing?.baseline ?? null;
  const previousPath = baseline === null ? null : resolve(io.cwd, baseline.dir, "result.json");
  const previous = previousPath !== null && existsSync(previousPath) ? readResultJson(previousPath) : null;
  writeOutputs(dir, { meta: jsonl.meta, summary, baseline, previous, records: jsonl.records });
  io.stdout(`描き直しました: ${shown(io.cwd, join(dir, "report.html"))}`);
  return 0;
}

/**
 * judge:check のキャッシュの行。2 件目の読みが 0 なら採点の決まりがキャッシュに乗っていない。
 * ただし Haiku 4.5 は 4096 トークン以上の決まりだけをキャッシュに乗せるので、読みが 0 でも誤りではない（失敗にはしない）
 */
export function cacheLines(model: string, usage: UsageRecord[]): string[] {
  const [first, second] = usage;
  if (first === undefined) return [];
  const lines = [`キャッシュ: 1 件目の書き込み ${first.cacheWrite5m + first.cacheWrite1h} トークン・2 件目の読み ${second?.cacheRead ?? 0} トークン`];
  if (second !== undefined && second.cacheRead === 0) {
    lines.push(
      model.startsWith("claude-haiku-")
        ? "[ご参考] Haiku 4.5 は 4096 トークン以上の決まりだけをキャッシュに乗せるため、2 件目の読みが 0 でも誤りではありません（費用が少し増えるだけです）。"
        : "[注意] 採点の決まりがキャッシュに乗っていません（2 件目の読みが 0）。採点の決まりの長さをご確認ください。",
    );
  }
  return lines;
}

/** npm run judge:check: 較正の一致率（90% 以上で 0）と、正しい見本・空の見本の配線の確かめ */
async function judgeCheckCommand(options: Options, io: CliIo): Promise<number> {
  const apiKey = (io.env.ANTHROPIC_API_KEY ?? "").trim() || null;
  if (apiKey === null && io.anthropic === undefined) throw new HarnessError(NO_KEY_MESSAGE);
  const items = loadCalibration(join(HARNESS_ROOT, CALIBRATION_FILE));
  // 正しい見本・空の見本に使う質問表も、API を呼ぶ前に読む
  const samplePath = join(HARNESS_ROOT, SAMPLE_CASES["ai-concierge"]);
  requireFile(samplePath, `見本の質問表 ${SAMPLE_CASES["ai-concierge"]}`);
  const sample = loadCasesFile(samplePath, { kit: "ai-concierge" });
  if (sample.problems.length > 0) throw problemsError(`見本の質問表 ${SAMPLE_CASES["ai-concierge"]} に直すところがあります`, sample.problems);
  const judge = buildJudge(options, io, "claude", null, apiKey);
  io.stderr(`較正の ${items.length} 件を採点させます（${judgeLabel(judge.info)}）。`);
  const result = await runCalibration(judge, items);
  for (const row of result.rows) {
    io.stdout(`${row.agree ? "一致　" : "不一致"} ${row.id}  人: ${VERDICT_LABELS[row.label]}  採点: ${VERDICT_LABELS[row.got]}${row.agree ? "" : `（${row.reason}）`}`);
  }
  io.stdout(`較正: 人の判定との一致 ${result.agreed}/${result.total}（${formatRate(result.agreement)}）`);
  for (const line of cacheLines(judge.info.model ?? "", result.usage)) io.stdout(line);
  const wiring = await runWiringCheck(judge, sample.cases.filter((c) => c.special === null && c.previous === null).slice(0, WIRING_CASES));
  io.stdout(`正しい見本と空の見本: ${wiring.checked} 件を確かめました（ずれ ${wiring.failures.length} 件）`);
  for (const failure of wiring.failures) io.stdout(`[要対応] ${failure}`);
  io.stdout(`費用: 採点 ${formatYen(costYen([...result.usage, ...wiring.usage]).yen)}`);
  if (result.agreement < AGREEMENT_FLOOR) io.stdout(`[要対応] 一致が ${formatRate(AGREEMENT_FLOOR)} 未満です。採点の決まり（src/judge/prompt.ts）を直してから、もう一度確かめてください。`);
  return result.agreement >= AGREEMENT_FLOOR && wiring.failures.length === 0 ? 0 : 1;
}

export async function main(argv: string[], io: CliIo): Promise<number> {
  try {
    const parsed = parseArgs(argv);
    const options = new Options(parsed, io.cwd);
    if (parsed.flags.has("--help") || ["help", "-h", "--help"].includes(parsed.command)) {
      io.stdout(USAGE);
      return 0;
    }
    switch (parsed.command) {
      case "run":
        return await runCommand(options, io, false);
      case "demo":
        return await runCommand(options, io, true);
      case "demo-diff":
        return await demoDiffCommand(options, io);
      case "cases":
        return await casesCommand(options, io);
      case "report":
        return await reportCommand(options, io);
      case "judge-check":
        return await judgeCheckCommand(options, io);
      default:
        throw new HarnessError(`知らないコマンドです: ${parsed.command}。\n${USAGE}`);
    }
  } catch (error) {
    if (error instanceof HarnessError) {
      io.stderr(error.message);
      return error.exitCode;
    }
    if (error instanceof CsvError) {
      io.stderr(error.message);
      return 2;
    }
    throw error;
  }
}

function argv1RealPath(): string | null {
  if (process.argv[1] === undefined) return null;
  try {
    return realpathSync(process.argv[1]);
  } catch {
    return null;
  }
}

// npm の bin は symlink を張るので、argv[1] はリンクのパスになる。realpath で実体を比べる
const invokedDirectly = argv1RealPath() === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  main(process.argv.slice(2), {
    stdout: (line) => console.log(line),
    stderr: (line) => console.error(line),
    env: process.env,
    cwd: process.cwd(),
    now: () => new Date(),
  }).then(
    (code) => {
      process.exitCode = code;
    },
    (error: unknown) => {
      console.error(`思わぬ失敗がありました: ${error instanceof Error ? (error.stack ?? error.message) : String(error)}`);
      process.exitCode = 1;
    },
  );
}
