/**
 * 使い方・質問表・キットの読み込みの誤り（API を呼ぶ前に分かるもの）。
 * cli はこれを受けたら文をそのまま出し、終了コード 2 で止める。文はすべて敬体
 */
export class HarnessError extends Error {
  readonly exitCode: number;

  constructor(message: string, exitCode: number = 2) {
    super(message);
    this.name = "HarnessError";
    this.exitCode = exitCode;
  }
}
