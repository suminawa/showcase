import { createHash } from "node:crypto";
import { costYen } from "../pricing.ts";
import type { CaseRecord, ResultEntry, Verdict } from "../types.ts";
import { VERDICT_LABELS, VERDICT_ORDER, formatJst, formatRate, formatSeconds, formatYen, judgeLabel, kitLabel } from "./format.ts";
import { shownAnswer, type ReportInput } from "./json.ts";

/**
 * report.html。1 ファイルで完結（CSS と小さな JS を中に書き、外のフォント・画像・スクリプトを読まない）。
 * データの文字はすべてエスケープし、JS は innerHTML を使わない（判定とタグで行を隠すだけ。無くても全部読める）
 */

export function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const e = escapeHtml;

export const STYLE = `
:root { --paper: #f4efe6; --card: #fbf8f2; --ink: #1f1d1a; --muted: #6b655c; --rule: #d9d1c3; --alert: #b3261e; --ok: #2f6b4f; --part: #9a6b12; --none: #8a8378; color-scheme: light dark; }
@media (prefers-color-scheme: dark) { :root { --paper: #1b1a17; --card: #24221e; --ink: #ece6da; --muted: #a79f92; --rule: #3b3832; --alert: #e5736a; --ok: #7cc19c; --part: #d9aa55; --none: #8f887d; } }
* { box-sizing: border-box; }
html { background: var(--paper); color: var(--ink); -webkit-text-size-adjust: 100%; }
body { margin: 0 auto; max-width: 72rem; padding: 2rem 1rem 3rem; font: 15px/1.7 "Hiragino Sans", "Noto Sans JP", system-ui, sans-serif; }
h1 { font-size: 1.5rem; line-height: 1.4; margin: 0 0 .5rem; letter-spacing: .02em; }
h2 { font-size: 1.0625rem; margin: 2.25rem 0 .75rem; padding-bottom: .375rem; border-bottom: 1px solid var(--rule); }
p { margin: 0 0 .5rem; }
.meta { color: var(--muted); font-size: .875rem; }
.num, td.num, .value { font-variant-numeric: tabular-nums; }
.notes { margin: 1rem 0 0; padding: .75rem 1rem; border-left: 3px solid var(--part); background: var(--card); font-size: .875rem; }
.notes li { margin: .125rem 0; }
.notes ul { margin: 0; padding-left: 1.25rem; }
.cards { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: .75rem; margin: 1.5rem 0 1rem; }
.card { background: var(--card); border: 1px solid var(--rule); border-radius: 6px; padding: .875rem 1rem; min-width: 0; }
.card .label { color: var(--muted); font-size: .8125rem; margin: 0; }
.card .value { font-size: 1.75rem; font-weight: 600; line-height: 1.3; margin: .25rem 0; overflow-wrap: anywhere; }
.card .sub { color: var(--muted); font-size: .8125rem; margin: 0; }
.delta { font-size: .875rem; font-weight: 600; margin-left: .375rem; }
.delta.good { color: var(--ok); }
.delta.bad { color: var(--alert); }
.bar { display: flex; height: .875rem; border-radius: 3px; overflow: hidden; background: var(--rule); margin: .5rem 0; }
.bar span { display: block; height: 100%; }
.legend { display: flex; flex-wrap: wrap; gap: .25rem 1rem; font-size: .8125rem; color: var(--muted); margin: 0; padding: 0; list-style: none; }
.legend i { display: inline-block; width: .625rem; height: .625rem; border-radius: 2px; margin-right: .375rem; vertical-align: baseline; }
.v-correct { background: var(--ok); } .v-partial { background: var(--part); } .v-wrong { background: var(--alert); } .v-noAnswer { background: var(--none); } .v-error, .v-judgeError { background: var(--muted); opacity: .45; }
.chip { display: inline-block; padding: 0 .5rem; border-radius: 999px; font-size: .8125rem; font-weight: 600; white-space: nowrap; border: 1px solid currentColor; }
.chip.correct { color: var(--ok); } .chip.partial { color: var(--part); } .chip.wrong { color: var(--alert); } .chip.noAnswer, .chip.error, .chip.judgeError, .chip.unknown { color: var(--muted); }
.chip.review { color: var(--part); border-style: dashed; }
.regressed { border: 1px solid var(--alert); border-radius: 6px; padding: .75rem 1rem; background: var(--card); }
.regressed h2 { color: var(--alert); border: 0; margin-top: 0; }
.regressed ol { margin: 0; padding-left: 1.25rem; }
.regressed li { margin: .375rem 0; }
table { width: 100%; border-collapse: collapse; font-size: .875rem; }
th, td { text-align: left; border-bottom: 1px solid var(--rule); padding: .5rem; vertical-align: top; overflow-wrap: anywhere; }
th { color: var(--muted); font-weight: 600; font-size: .8125rem; }
td.num, th.num { text-align: right; white-space: nowrap; }
td.short, td.nw { white-space: nowrap; }
table.tags { max-width: 32rem; }
.marks { letter-spacing: .125em; white-space: nowrap; }
.m-covered { color: var(--ok); } .m-missing { color: var(--muted); } .m-contradicted { color: var(--alert); font-weight: 700; } .m-unknown { color: var(--muted); }
details { margin-top: .375rem; }
summary { cursor: pointer; color: var(--muted); font-size: .8125rem; }
details dl { margin: .5rem 0 0; display: grid; grid-template-columns: max-content 1fr; gap: .25rem .75rem; }
details dt { color: var(--muted); }
details dd { margin: 0; white-space: pre-wrap; }
code { font-size: .8125rem; overflow-wrap: anywhere; }
.filters { display: flex; flex-wrap: wrap; gap: .5rem 1rem; align-items: center; margin: 0 0 .75rem; font-size: .875rem; }
.filters select { font: inherit; color: inherit; background: var(--card); border: 1px solid var(--rule); border-radius: 4px; padding: .125rem .375rem; }
footer { margin-top: 2.5rem; color: var(--muted); font-size: .8125rem; }
@media (max-width: 960px) { .cards { grid-template-columns: repeat(2, minmax(0, 1fr)); } .card:last-child { grid-column: span 2; } }
@media (max-width: 640px) {
  body { padding: 1.25rem 1rem 2rem; }
  h1 { font-size: 1.25rem; }
  .card .value { font-size: 1.375rem; }
  table.stack thead { display: none; }
  table.stack, table.stack tbody, table.stack tr, table.stack td { display: block; width: 100%; }
  table.stack tr { border: 1px solid var(--rule); border-radius: 6px; margin: 0 0 .75rem; padding: .5rem .75rem; background: var(--card); }
  table.stack td { border: 0; padding: .125rem 0; display: flex; gap: .75rem; text-align: left; }
  table.stack td::before { content: attr(data-label); color: var(--muted); flex: 0 0 4.5em; font-size: .8125rem; }
  table.stack td.num { text-align: left; }
  table.stack td.nw { white-space: normal; }
  table.stack td > * { min-width: 0; }
  table.stack td.wide { display: block; }
  table.stack td.wide::before { display: block; }
  details dl { grid-template-columns: 1fr; gap: 0; }
  details dd { margin-bottom: .375rem; }
}
@media print { body { max-width: none; padding: 0; font-size: 12px; } .filters { display: none; } .card, .regressed, table.stack tr { break-inside: avoid; } }
`;

/** 判定とタグで行を絞る小さな JS。行には data-verdict と data-tags（JSON）がある */
export const SCRIPT = `(function () {
  var filters = document.getElementById("filters");
  var verdict = document.getElementById("filter-verdict");
  var tag = document.getElementById("filter-tag");
  var count = document.getElementById("filter-count");
  var rows = Array.prototype.slice.call(document.querySelectorAll("tbody#case-rows > tr"));
  function apply() {
    var shown = 0;
    rows.forEach(function (row) {
      var tags = JSON.parse(row.getAttribute("data-tags") || "[]");
      var ok = (verdict.value === "" || row.getAttribute("data-verdict") === verdict.value) && (tag.value === "" || tags.indexOf(tag.value) >= 0);
      row.hidden = !ok;
      if (ok) shown += 1;
    });
    count.textContent = shown + " 問を表示";
  }
  verdict.addEventListener("change", apply);
  tag.addEventListener("change", apply);
  filters.hidden = false;
  apply();
})();`;

export function scriptHash(script: string = SCRIPT): string {
  return `sha256-${createHash("sha256").update(script).digest("base64")}`;
}

const MARKS = { covered: "●", missing: "○", contradicted: "×", unknown: "？" } as const;
const MARK_TITLES = { covered: "述べている", missing: "触れていない", contradicted: "食い違う", unknown: "不明" } as const;
const SPECIAL_LABELS = { refuse: "断るべき問い", handoff: "引き継ぐ問い", empty: "空が正しい項目" } as const;

/**
 * cases.jsonl・--from・前回の result.json は形の検査をせずに読むため、point.status と verdict は
 * 決まった値の一覧に無ければ「不明」として扱う（そのまま HTML の属性・クラス名に出さない）
 */
const KNOWN_MARK_KEYS = new Set<string>(Object.keys(MARKS));
type MarkKey = keyof typeof MARKS;

function safeMarkStatus(status: string): MarkKey {
  return (KNOWN_MARK_KEYS.has(status) ? status : "unknown") as MarkKey;
}

const KNOWN_VERDICTS = new Set<string>(VERDICT_ORDER);

function safeVerdict(verdict: string): Verdict | "unknown" {
  return KNOWN_VERDICTS.has(verdict) ? (verdict as Verdict) : "unknown";
}

function verdictLabel(verdict: string): string {
  const safe = safeVerdict(verdict);
  return safe === "unknown" ? "不明" : VERDICT_LABELS[safe];
}

function deltaSpan(delta: number | null, higherIsBetter: boolean): string {
  if (delta === null) return "";
  const points = Math.round(delta * 100);
  if (points === 0) return `<span class="delta">±0</span>`;
  const good = points > 0 === higherIsBetter;
  return `<span class="delta ${good ? "good" : "bad"}">${points > 0 ? "▲" : "▼"}${Math.abs(points)}</span>`;
}

function countDelta(now: number, before: number | null): string {
  if (before === null) return "";
  const diff = now - before;
  if (diff === 0) return `<span class="delta">±0</span>`;
  return `<span class="delta ${diff < 0 ? "good" : "bad"}">${diff > 0 ? "▲" : "▼"}${Math.abs(diff)}</span>`;
}

function card(label: string, value: string, delta: string, sub: string): string {
  return `<div class="card"><p class="label">${e(label)}</p><p class="value">${e(value)}${delta}</p><p class="sub">${e(sub)}</p></div>`;
}

function rateDelta(now: number | null, before: number | null | undefined): number | null {
  return now === null || before === null || before === undefined ? null : now - before;
}

function groupByCase(records: CaseRecord[]): CaseRecord[][] {
  const groups = new Map<string, CaseRecord[]>();
  for (const record of records) {
    const list = groups.get(record.case.id) ?? [];
    list.push(record);
    groups.set(record.case.id, list);
  }
  return [...groups.values()].map((list) => list.sort((a, b) => a.result.round - b.result.round));
}

function chip(verdict: string): string {
  const safe = safeVerdict(verdict);
  return `<span class="chip ${e(safe)}">${e(verdictLabel(safe))}</span>`;
}

/** 要確認: 採点が不完全（要点の番号の欠け・余り）か、採点者の違反の印の字が答えに見つからない（どの回でも） */
function needsReview(group: CaseRecord[]): boolean {
  return group.some((record) => record.result.incomplete || record.result.forbidden.some((item) => item.review));
}

const REVIEW_CHIP = `<span class="chip review" title="${e("採点が不完全か、違反の印の字が答えに見つかりません。答えを読んでお確かめください。")}">要確認</span>`;

function caseRow(input: ReportInput, group: CaseRecord[], previous: Map<string, ResultEntry>): string {
  const first = group[0];
  const c = first.case;
  const result = first.result;
  const marks =
    c.special !== null
      ? `<span class="meta">${e(SPECIAL_LABELS[c.special])}</span>`
      : `<span class="marks">${result.points
          .map((point) => {
            const status = safeMarkStatus(point.status);
            return `<span class="m-${e(status)}" title="${e(`${point.text}: ${MARK_TITLES[status]}`)}">${MARKS[status]}</span>`;
          })
          .join("")}</span>`;
  const citation = result.citationHit === null ? "—" : result.citationHit ? "当たり" : "外れ";
  const violated = result.forbidden.filter((item) => item.violated).length;
  const review = result.forbidden.filter((item) => item.review).length;
  const costs = group.map((record) => costYen(record.answer.usage, input.meta.yenPerUsd));
  const yen = costs.reduce((sum, cost) => sum + cost.yen, 0) / group.length;
  const yenLowerBound = costs.some((cost) => cost.lowerBound);
  const before = previous.get(c.id);
  const details: string[] = [];
  if (c.previous !== null) details.push(`<dt>前の質問</dt><dd>${e(c.previous)}</dd>`);
  if (first.answer.field !== undefined) {
    const field = first.answer.field;
    details.push(`<dt>書類</dt><dd>${e(c.documentLabel ?? "")}（${e(field.label)}）</dd>`);
    details.push(`<dt>読み取った値</dt><dd>${e(field.value === null ? "（空）" : shownAnswer(input, String(field.value)))}</dd>`);
    details.push(`<dt>期待する値</dt><dd>${e(field.expected === null ? "（空）" : String(field.expected))}</dd>`);
    if (field.evidence !== null) details.push(`<dt>根拠の字</dt><dd>${e(shownAnswer(input, field.evidence))}</dd>`);
    if (field.needsReview) details.push(`<dt>要確認</dt><dd>${e(field.warnings.join("・") || "はい")}</dd>`);
  } else {
    details.push(`<dt>答え</dt><dd>${e(shownAnswer(input, first.answer.answer) || "（空）")}</dd>`);
  }
  if (first.answer.sources.length > 0) details.push(`<dt>出典</dt><dd>${first.answer.sources.map((source) => `${e(source.title)}${source.url === null ? "" : ` <code>${e(source.url)}</code>`}`).join("<br>")}</dd>`);
  if (c.sources.length > 0) details.push(`<dt>出典に含まれるべき</dt><dd>${e(c.sources.join("・"))}</dd>`);
  if (result.forbidden.length > 0) {
    details.push(`<dt>答えてはいけないこと</dt><dd>${result.forbidden.map((item) => `${e(item.text)}: ${item.violated ? `違反（${e(shownAnswer(input, item.quote))}）` : item.review ? "要確認（採点者は違反としましたが、答えに同じ字がありません）" : "なし"}`).join("<br>")}</dd>`);
  }
  details.push(`<dt>採点の理由</dt><dd>${e(shownAnswer(input, result.reason))}${result.incomplete ? "（採点が不完全です）" : ""}</dd>`);
  if (group.length > 1) details.push(`<dt>回ごとの判定</dt><dd>${group.map((record) => chip(record.result.verdict)).join(" ")}</dd>`);
  if (before !== undefined) details.push(`<dt>前回の判定</dt><dd>${chip(before.verdict)}</dd>`);
  for (const [key, value] of Object.entries(c.extras)) details.push(`<dt>${e(key)}（ご参考）</dt><dd>${e(value)}</dd>`);
  return `<tr data-verdict="${e(safeVerdict(result.verdict))}" data-tags="${e(JSON.stringify(c.tags))}">
<td data-label="ID" class="nw"><code>${e(c.id)}</code></td>
<td data-label="タグ" class="nw">${e(c.tags.join("、"))}</td>
<td data-label="質問" class="wide"><div><div>${e(c.question)}</div><details><summary>答えと採点</summary><dl>${details.join("")}</dl></details></div></td>
<td data-label="判定" class="short">${group.map((record) => chip(record.result.verdict)).join(" ")}${needsReview(group) ? ` ${REVIEW_CHIP}` : ""}</td>
<td data-label="要点" class="short">${marks}</td>
<td data-label="出典" class="short">${citation}</td>
<td data-label="違反" class="num">${violated}${review > 0 ? `（要確認 ${review}）` : ""}</td>
<td data-label="時間" class="num">${e(formatSeconds(first.answer.status === "ok" ? first.answer.latencyMs : null))}</td>
<td data-label="円" class="num">${e(formatYen(yen, yenLowerBound))}</td>
</tr>`;
}

export function buildReportHtml(input: ReportInput): string {
  const { meta, summary, baseline, previous } = input;
  const prev = previous?.summary ?? null;
  const previousByCase = new Map((previous?.results ?? []).filter((entry) => entry.round === 0).map((entry) => [entry.id, entry]));
  const groups = groupByCase(input.records);
  const n = groups.length;
  const notes = [...meta.notes, ...(baseline?.notes ?? [])];
  const counts = summary.counts;
  const refusalSub = `断るべき ${summary.refusal.shouldRefuse} 問・断りすぎ ${formatRate(summary.refusal.overRefused)}${summary.handoff === null ? "" : `・引き継ぎ ${formatRate(summary.handoff.handedOffWhenShould)}`}`;
  const cards = [
    card(
      "正答率",
      `${formatRate(summary.score)}${summary.scoreRange === null ? "" : `（${formatRate(summary.scoreRange.min)}〜${formatRate(summary.scoreRange.max)}）`}`,
      deltaSpan(baseline?.delta ?? null, true),
      `正解 ${counts.correct}・部分 ${counts.partial}・誤り ${counts.wrong}・無回答 ${counts.noAnswer}`,
    ),
    card("期待した出典との一致", formatRate(summary.citationHit), deltaSpan(rateDelta(summary.citationHit, prev?.citationHit), true), `検索の当たり ${formatRate(summary.retrievalHit)}`),
    card("断りの正しさ", formatRate(summary.refusal.refusedWhenShould), deltaSpan(rateDelta(summary.refusal.refusedWhenShould, prev?.refusal?.refusedWhenShould), true), refusalSub),
    card("禁止事項の違反", `${summary.forbidden.violated} 件`, countDelta(summary.forbidden.violated, prev?.forbidden?.violated ?? null), `要確認 ${summary.forbidden.review} 件`),
    card("1 問あたり", formatSeconds(summary.latencyMs.p50), "", `${formatYen(summary.costJpy.perQuestion, summary.costLowerBound)}・95%: ${formatSeconds(summary.latencyMs.p95)}・採点 ${formatYen(summary.costJpy.judge)}`),
  ].join("\n");
  const total = Math.max(1, summary.total);
  const bar = VERDICT_ORDER.filter((verdict) => counts[verdict] > 0)
    .map((verdict) => `<span class="v-${verdict}" style="width:${((counts[verdict] / total) * 100).toFixed(2)}%" title="${e(`${VERDICT_LABELS[verdict]} ${counts[verdict]}`)}"></span>`)
    .join("");
  const legend = VERDICT_ORDER.map((verdict) => `<li><i class="v-${verdict}"></i>${e(VERDICT_LABELS[verdict])} <span class="num">${counts[verdict]}</span></li>`).join("");
  const reviewCount = groups.filter(needsReview).length;
  const reviewLine =
    reviewCount === 0 ? "" : `<p class="meta">要確認の問い: ${reviewCount}。採点が不完全か、採点者の違反の印の字が答えに見つからなかった問いです。表の「要確認」の印の問いは、答えを読んでお確かめください。</p>`;

  let regressedBlock = "";
  if (baseline !== null) {
    const byId = new Map(groups.map((group) => [group[0].case.id, group[0]]));
    const items = baseline.regressed
      .map((id) => byId.get(id))
      .filter((record): record is CaseRecord => record !== undefined)
      .map((record) => {
        const before = previousByCase.get(record.case.id);
        return `<li><code>${e(record.case.id)}</code> ${e(record.case.question)}<br><span class="meta">前回 ${before === undefined ? "—" : e(verdictLabel(before.verdict))} → 今回 ${e(verdictLabel(record.result.verdict))}: ${e(shownAnswer(input, record.result.reason))}</span></li>`;
      });
    regressedBlock =
      items.length > 0
        ? `<section class="regressed"><h2>前回から悪くなった問い（${items.length}）</h2><ol>${items.join("")}</ol><p class="meta">良くなった問い: ${Number(baseline.improved.length)}。採点は目安です。悪くなった問いは、答えを読んでお確かめください。</p></section>`
        : `<p class="meta">前回から悪くなった問いはありません（良くなった問い: ${Number(baseline.improved.length)}）。</p>`;
  }

  const tagRows = summary.tags.map((tag) => `<tr><td>${e(tag.tag)}</td><td class="num">${formatRate(tag.score)}</td><td class="num">${tag.count}</td></tr>`).join("");
  const tagOptions = summary.tags.map((tag) => `<option value="${e(tag.tag)}">${e(tag.tag)}</option>`).join("");
  const verdictOptions = VERDICT_ORDER.map((verdict) => `<option value="${verdict}">${e(VERDICT_LABELS[verdict])}</option>`).join("");
  const errors = [...summary.errors.map((item) => ({ ...item, kind: "実行エラー" })), ...summary.judgeErrors.map((item) => ({ ...item, kind: "採点エラー" }))];
  const errorBlock =
    errors.length === 0
      ? ""
      : `<h2>実行エラー・採点エラー（${errors.length}）</h2><p class="meta">正答率の分母には入れていません。</p><ul>${errors.map((item) => `<li><code>${e(item.id)}</code>${summary.rounds > 1 ? `（${item.round + 1} 回目）` : ""} ${e(item.kind)}: ${e(item.reason)}</li>`).join("")}</ul>`;
  const metaLine = [
    kitLabel(meta.kit),
    `答え ${meta.kit.model ?? "—"}`,
    `採点 ${judgeLabel(meta.judge)}`,
    `質問表 ${meta.cases.file} ${n} 問${summary.rounds > 1 ? ` × ${summary.rounds} 回` : ""}`,
    formatJst(meta.startedAt),
  ].join("・");

  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src '${scriptHash()}'">
<meta name="referrer" content="no-referrer">
<title>${e(meta.kit.label)}の答え合わせ（${e(formatJst(meta.startedAt))}）</title>
<style>${STYLE}</style>
</head>
<body>
<header>
<h1>${e(meta.kit.label)}の答え合わせ ${n} 問</h1>
<p class="meta">${e(metaLine)}</p>
${notes.length === 0 ? "" : `<div class="notes"><ul>${notes.map((note) => `<li>${e(note)}</li>`).join("")}</ul></div>`}
</header>
<main>
<section class="cards">
${cards}
</section>
<section aria-label="判定の内訳">
<div class="bar">${bar}</div>
<ul class="legend">${legend}</ul>
${reviewLine}
</section>
${regressedBlock}
${tagRows === "" ? "" : `<h2>タグ別</h2><table class="tags"><thead><tr><th>タグ</th><th class="num">正答率</th><th class="num">件数</th></tr></thead><tbody>${tagRows}</tbody></table>`}
<h2>問いごとの結果</h2>
<div class="filters" id="filters" hidden>
<label>判定 <select id="filter-verdict"><option value="">すべて</option>${verdictOptions}</select></label>
<label>タグ <select id="filter-tag"><option value="">すべて</option>${tagOptions}</select></label>
<span id="filter-count" class="meta"></span>
</div>
<table class="stack">
<thead><tr><th>ID</th><th>タグ</th><th>質問</th><th>判定</th><th>要点</th><th>出典</th><th class="num">違反</th><th class="num">時間</th><th class="num">円</th></tr></thead>
<tbody id="case-rows">
${groups.map((group) => caseRow(input, group, previousByCase)).join("\n")}
</tbody>
</table>
<p class="meta">要点の印: ● 述べている・○ 触れていない・× 食い違う。時間はキットの 1 問の所要時間（やり直しの待ちを含めない）、円はキットの費用です。</p>
${errorBlock}
</main>
<footer>
<p>採点は Claude による目安です。悪くなった問いや誤りの問いは、答えを読んでお確かめください。</p>
<p>RAG 評価ハーネス ${e(meta.tool.version)}・採点の決まり ${e(meta.judge.rubricVersion ?? "—")}</p>
</footer>
<script>${SCRIPT}</script>
</body>
</html>
`;
}
