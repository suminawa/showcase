import { formatDelta, formatRate, formatSeconds, formatYen, judgeLabel, VERDICT_LABELS, VERDICT_LABELS_EN } from "./format.ts";
import { shownAnswer, type ReportInput } from "./json.ts";
import type { CaseRecord } from "../types.ts";

/**
 * Zenn・LinkedIn に貼る要約。答えの本文は入れない（質問と採点の理由だけ）。
 * summary.md は日本語、summary.en.md は同じ形の英語
 */

const BAD_ORDER = ["wrong", "noAnswer", "partial"];

/** 悪かった問い 3 つ（誤り → 無回答 → 部分の順、1 回目だけ） */
export function worstRecords(records: CaseRecord[], count: number = 3): CaseRecord[] {
  return BAD_ORDER.flatMap((verdict) => records.filter((record) => record.result.round === 0 && record.result.verdict === verdict)).slice(0, count);
}

function questionCount(input: ReportInput): number {
  return input.records.filter((record) => record.result.round === 0).length;
}


/** 前回から悪くなった問い（id・質問・前回→今回の判定）。無ければ空 */
function regressedLines(input: ReportInput, en: boolean): string[] {
  const { baseline, previous, records } = input;
  if (baseline === null || baseline.regressed.length === 0) return [];
  const labels = en ? VERDICT_LABELS_EN : VERDICT_LABELS;
  const now = new Map(records.filter((record) => record.result.round === 0).map((record) => [record.case.id, record]));
  const before = new Map((previous?.results ?? []).filter((entry) => entry.round === 0).map((entry) => [entry.id, entry]));
  const lines = [en ? "## Worse than the previous run" : "## 前回から悪くなった問い", ""];
  for (const id of baseline.regressed) {
    const record = now.get(id);
    if (record === undefined) continue;
    const was = before.get(id);
    const change = `${was === undefined ? "—" : labels[was.verdict]} → ${labels[record.result.verdict]}`;
    lines.push(en ? `- ${id} "${record.case.question}" — ${change}` : `- ${id}「${record.case.question}」— ${change}`);
  }
  lines.push("");
  return lines;
}

export function buildSummaryMd(input: ReportInput): string {
  const { summary, meta, baseline } = input;
  const n = questionCount(input);
  const title = `${meta.kit.label} ${n} 問: 正答率 ${formatRate(summary.score)}${baseline === null || baseline.delta === null ? "" : `（前回 ${formatDelta(baseline.delta)}）`}`;
  const refusal = `断るべき ${summary.refusal.shouldRefuse} 問で ${formatRate(summary.refusal.refusedWhenShould)}・断りすぎ ${formatRate(summary.refusal.overRefused)}`;
  const lines = [
    `# ${title}`,
    "",
    "| 指標 | 値 |",
    "|---|---|",
    `| 正答率 | ${formatRate(summary.score)}${summary.scoreRange === null ? "" : `（${formatRate(summary.scoreRange.min)}〜${formatRate(summary.scoreRange.max)}）`}・正解だけ ${formatRate(summary.correctRate)} |`,
    `| 期待した出典との一致 | ${formatRate(summary.citationHit)} |`,
    `| 検索の当たり | ${formatRate(summary.retrievalHit)} |`,
    `| 断りの正しさ | ${refusal} |`,
    `| 禁止事項の違反 | ${summary.forbidden.violated} 件（要確認 ${summary.forbidden.review} 件） |`,
    `| 1 問あたり | ${formatSeconds(summary.latencyMs.p50)}（95%: ${formatSeconds(summary.latencyMs.p95)}）・${formatYen(summary.costJpy.perQuestion, summary.costLowerBound)} |`,
    "",
    `判定の内訳: ${(["correct", "partial", "wrong", "noAnswer"] as const).map((verdict) => `${VERDICT_LABELS[verdict]} ${summary.counts[verdict]}`).join("・")}（実行エラー ${summary.counts.error}・採点エラー ${summary.counts.judgeError}）`,
    "",
  ];
  lines.push(...regressedLines(input, false));
  const worst = worstRecords(input.records);
  if (worst.length > 0) {
    lines.push("## 悪かった問い", "");
    for (const record of worst) lines.push(`- 「${record.case.question}」— ${VERDICT_LABELS[record.result.verdict]}: ${shownAnswer(input, record.result.reason)}`);
    lines.push("");
  }
  const method =
    meta.judge.mode === "keyword"
      ? "測り方: 質問表の問いをそのまま窓口に答えさせ、答えに入っているべき要点ごとに語の一致で照合しました（Claude による採点ではありません）。正解・部分・誤り・無回答の判定は、その照合からプログラムが決めています。"
      : meta.judge.mode === "replay"
        ? "測り方: 質問表の問いをそのまま窓口に答えさせ、正解・部分・誤り・無回答の判定は、前回の実行で記録した採点をそのまま再生したものです（今回はあらためて採点していません）。"
        : "測り方: 質問表の問いをそのまま窓口に答えさせ、答えに入っているべき要点ごとに Claude が印を付けました。正解・部分・誤り・無回答の判定は、その印からプログラムが決めています。";
  lines.push(
    `答え: ${meta.kit.model ?? "—"} ／ 採点: ${judgeLabel(meta.judge)}／ ${n} 問で ${formatYen(summary.costJpy.kit + summary.costJpy.judge, summary.costLowerBound)}`,
    "",
    method,
    "資料に無い問い（断るのが正しい問い）と、答えてはいけないことも表に入れて数えています。",
    "",
  );
  if (meta.notes.length > 0) lines.push("注意:", ...meta.notes.map((note) => `- ${note}`), "");
  return lines.join("\n");
}

export function buildSummaryEnMd(input: ReportInput): string {
  const { summary, meta, baseline } = input;
  const n = questionCount(input);
  const rate = (value: number | null) => formatRate(value);
  const seconds = (ms: number | null) => (ms === null ? "—" : `${(ms / 1000).toFixed(1)} s`);
  const yen = (value: number | null) => (value === null ? "—" : `¥${value < 10 ? value.toFixed(1) : Math.round(value).toLocaleString("en-US")}${summary.costLowerBound ? "+" : ""}`);
  const title = `${meta.kit.label} — ${n} questions: score ${rate(summary.score)}${baseline === null || baseline.delta === null ? "" : ` (${formatDelta(baseline.delta).replace("−", "-")} vs. previous run)`}`;
  const lines = [
    `# ${title}`,
    "",
    "| Metric | Value |",
    "|---|---|",
    `| Score | ${rate(summary.score)}${summary.scoreRange === null ? "" : ` (${rate(summary.scoreRange.min)}–${rate(summary.scoreRange.max)})`}, fully correct ${rate(summary.correctRate)} |`,
    `| Expected-source match | ${rate(summary.citationHit)} |`,
    `| Retrieval hit | ${rate(summary.retrievalHit)} |`,
    `| Refusals | ${rate(summary.refusal.refusedWhenShould)} of ${summary.refusal.shouldRefuse} out-of-scope questions refused; over-refusal ${rate(summary.refusal.overRefused)} |`,
    `| Forbidden content | ${summary.forbidden.violated} violation(s), ${summary.forbidden.review} flagged for review |`,
    `| Per question | ${seconds(summary.latencyMs.p50)} median (p95 ${seconds(summary.latencyMs.p95)}), ${yen(summary.costJpy.perQuestion)} |`,
    "",
    `Verdicts: ${(["correct", "partial", "wrong", "noAnswer"] as const).map((verdict) => `${VERDICT_LABELS_EN[verdict]} ${summary.counts[verdict]}`).join(", ")} (run errors ${summary.counts.error}, grading errors ${summary.counts.judgeError})`,
    "",
  ];
  lines.push(...regressedLines(input, true));
  const worst = worstRecords(input.records);
  if (worst.length > 0) {
    lines.push("## Weakest questions", "");
    for (const record of worst) lines.push(`- "${record.case.question}" — ${VERDICT_LABELS_EN[record.result.verdict]}`);
    lines.push("");
  }
  const judge = meta.judge.mode === "keyword" ? "keyword match (no API)" : meta.judge.mode === "replay" ? `${meta.judge.model ?? "—"} (replayed)` : `${meta.judge.model ?? "—"} (effort ${meta.judge.effort ?? "—"})`;
  const method =
    meta.judge.mode === "keyword"
      ? "Method: each question in the CSV was sent to the assistant as written. Each expected key point was matched against the answer by keyword (not graded by Claude), and the verdict (correct / partial / wrong / no answer) was decided in code from that match."
      : meta.judge.mode === "replay"
        ? "Method: each question in the CSV was sent to the assistant as written. The verdict (correct / partial / wrong / no answer) is replayed from grading recorded in a previous run; this run did not grade the answers again."
        : "Method: each question in the CSV was sent to the assistant as written. Claude marked every expected key point as covered, missing or contradicted using structured outputs, and the verdict (correct / partial / wrong / no answer) was decided in code from those marks.";
  lines.push(
    `Answered by ${meta.kit.model ?? "—"} / graded by ${judge} / ${n} questions for ${yen(summary.costJpy.kit + summary.costJpy.judge)}`,
    "",
    method,
    "Out-of-scope questions (where refusing is the right answer) and things the assistant must never say are part of the question set.",
    "",
  );
  // notes are written in Japanese (the run's own wording); they are kept as is
  if (meta.notes.length > 0) lines.push("Notes (as written in the report):", ...meta.notes.map((note) => `- ${note}`), "");
  return lines.join("\n");
}
