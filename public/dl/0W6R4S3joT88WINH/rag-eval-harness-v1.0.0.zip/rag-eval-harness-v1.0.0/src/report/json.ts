import { redact } from "../redact.ts";
import type { BaselineDiff, CaseRecord, ResultEntry, ResultJson, RunMeta, Summary } from "../types.ts";
import { head } from "./format.ts";

/** 出力を描くのに要るもの（html・markdown・csv・json で共通） */
export interface ReportInput {
  meta: RunMeta;
  summary: Summary;
  baseline: BaselineDiff | null;
  /** 前回の result.json（数の札の差と、問いごとの前回の判定に使う） */
  previous: ResultJson | null;
  records: CaseRecord[];
}

/** レポートと要約に出す答え（伏せ字を外していなければ伏せる） */
export function shownAnswer(input: ReportInput, text: string): string {
  return input.meta.redact ? redact(text) : text;
}

export function entryOf(input: ReportInput, record: CaseRecord): ResultEntry {
  const result = record.result;
  return {
    id: result.id,
    round: result.round,
    tags: result.tags,
    status: record.answer.status,
    verdict: result.verdict,
    points: result.points,
    forbidden: result.forbidden.map((item) => ({ text: item.text, violated: item.violated, quote: shownAnswer(input, item.quote), review: item.review })),
    citationHit: result.citationHit,
    retrievalHit: result.retrievalHit,
    refused: result.refused,
    handoff: result.handoff,
    latencyMs: result.latencyMs,
    attempts: result.attempts,
    usage: { kit: record.answer.usage, judge: record.judge === null ? [] : record.judge.usage },
    answerHead: head(shownAnswer(input, record.answer.answer)),
    sources: record.answer.sources,
    reason: shownAnswer(input, result.reason),
  };
}

/** result.json（"schema": "rag-eval/1"）。率は 0〜1、分母が 0 なら null */
export function buildResultJson(input: ReportInput): ResultJson {
  return {
    schema: "rag-eval/1",
    tool: input.meta.tool,
    startedAt: input.meta.startedAt,
    finishedAt: input.meta.finishedAt,
    kit: input.meta.kit,
    judge: input.meta.judge,
    cases: input.meta.cases,
    summary: input.summary,
    baseline: input.baseline,
    notes: [...input.meta.notes, ...(input.baseline?.notes ?? [])],
    results: input.records.map((record) => entryOf(input, record)),
  };
}
