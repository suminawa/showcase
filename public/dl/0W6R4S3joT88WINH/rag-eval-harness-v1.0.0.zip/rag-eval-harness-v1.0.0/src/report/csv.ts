import { toCsv } from "../cases/csv.ts";
import { costYen } from "../pricing.ts";
import { VERDICT_LABELS, head } from "./format.ts";
import { shownAnswer, type ReportInput } from "./json.ts";

export const RESULTS_CSV_HEADERS = ["id", "回", "タグ", "質問", "判定", "要点", "出典", "検索", "断った", "引き継いだ", "違反", "要確認", "所要ms", "試行", "キットの円", "採点の円", "答えの先頭", "理由"];

const flag = (value: boolean | null) => (value === null ? "" : value ? "はい" : "いいえ");
const MARKS = { covered: "●", missing: "○", contradicted: "×" } as const;

/** results.csv（スプレッドシートで見る人向け）。BOM つき、= + - @ で始まる値は ' を付けて式として動かないように */
export function buildResultsCsv(input: ReportInput): string {
  const rows = input.records.map((record) => {
    const result = record.result;
    return [
      result.id,
      String(result.round + 1),
      result.tags.join(", "),
      record.case.question,
      VERDICT_LABELS[result.verdict] ?? "不明",
      result.points.map((point) => `${MARKS[point.status] ?? "?"}${point.text}`).join(" "),
      flag(result.citationHit),
      flag(result.retrievalHit),
      flag(result.refused),
      flag(result.handoff),
      result.forbidden.filter((item) => item.violated).map((item) => item.text).join(" | "),
      [...result.forbidden.filter((item) => item.review).map((item) => item.text), ...(result.incomplete ? ["採点が不完全"] : [])].join(" | "),
      String(result.latencyMs),
      String(result.attempts),
      costYen(record.answer.usage, input.meta.yenPerUsd).yen.toFixed(2),
      costYen(record.judge === null ? [] : record.judge.usage, input.meta.yenPerUsd).yen.toFixed(2),
      head(shownAnswer(input, record.answer.answer)),
      shownAnswer(input, result.reason),
    ];
  });
  return "﻿" + toCsv([RESULTS_CSV_HEADERS, ...rows], true);
}
