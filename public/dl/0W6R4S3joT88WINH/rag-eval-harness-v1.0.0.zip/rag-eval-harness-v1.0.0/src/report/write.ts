import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { toCasesJsonl } from "../adapters/replay.ts";
import { buildResultsCsv } from "./csv.ts";
import { buildReportHtml } from "./html.ts";
import { buildResultJson, type ReportInput } from "./json.ts";
import { buildSummaryEnMd, buildSummaryMd } from "./markdown.ts";

/** runs/<日時>-<kit>/ に書き出すファイル */
export const OUTPUT_FILES = ["report.html", "summary.md", "summary.en.md", "result.json", "results.csv", "cases.jsonl"] as const;

/** 6 つを書き出す。cases.jsonl だけは伏せ字をかけない全文（replay と調べ直し用） */
export function writeOutputs(dir: string, input: ReportInput): void {
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, "report.html"), buildReportHtml(input));
  writeFileSync(join(dir, "summary.md"), buildSummaryMd(input));
  writeFileSync(join(dir, "summary.en.md"), buildSummaryEnMd(input));
  writeFileSync(join(dir, "result.json"), `${JSON.stringify(buildResultJson(input), null, 2)}\n`);
  writeFileSync(join(dir, "results.csv"), buildResultsCsv(input));
  writeFileSync(join(dir, "cases.jsonl"), toCasesJsonl(input.meta, input.records));
}
