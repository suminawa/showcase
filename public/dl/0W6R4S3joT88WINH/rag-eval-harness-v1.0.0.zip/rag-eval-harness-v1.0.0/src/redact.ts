/**
 * レポートと要約に出す前に、メールアドレス・電話番号・9 桁以上の数字を伏せる
 * （キットの記録と同じ線。--no-redact で外せる）
 */
export function redact(text: string): string {
  return text
    .replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, "***@***")
    .replace(/(?<!\d)0\d{1,3}[-\s]?\d{2,4}[-\s]?\d{3,4}(?!\d)/g, "***")
    .replace(/\d{9,}/g, "***");
}
