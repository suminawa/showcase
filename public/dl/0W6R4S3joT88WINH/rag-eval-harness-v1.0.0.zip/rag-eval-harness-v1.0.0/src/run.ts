import { errorAnswer } from "./adapters/common.ts";
import { RETRY_DELAYS_MS, jittered, runFirstThenPool, runPool, sleep as realSleep } from "./concurrency.ts";
import { JUDGE_CONCURRENCY } from "./judge/claude.ts";
import { gradeCase, ruleDecision } from "./score/grade.ts";
import type { Adapter, AdapterAnswer, CaseRecord, EvalCase, Judge, JudgeOutcome } from "./types.ts";

/** 1 問の打ち切り（ストリームが生きていても） */
export const TIMEOUT_MS = 90_000;

export interface RunOptions {
  cases: EvalCase[];
  adapter: Adapter;
  judge: Judge;
  /** キットへの同時の問い（1〜8） */
  concurrency: number;
  /** 問いを送り始める間隔 */
  intervalMs: number;
  /** 1〜5 */
  repeat: number;
  timeoutMs?: number;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  now?: () => number;
  /** 答えが 1 つ届くたびに呼ぶ（進み具合の表示） */
  onAnswer?: (done: number, total: number) => void;
}

interface Asked {
  c: EvalCase;
  round: number;
  answer: AdapterAnswer;
  attempts: number;
}

/**
 * 答えさせる → 決まりで決める → 残りを採点する。
 * 答えさせる: 同時 concurrency 個・間隔 intervalMs・1 問 90 秒で打ち切り・429/529/5xx/接続の切れは 1・3・9 秒で 3 回まで
 * 採点する: 最初の 1 件を先に送り、応答を受けてから同時 4
 */
export async function runCases(options: RunOptions): Promise<CaseRecord[]> {
  const sleep = options.sleep ?? realSleep;
  const random = options.random ?? Math.random;
  const now = options.now ?? (() => Date.now());
  const timeoutMs = options.timeoutMs ?? TIMEOUT_MS;
  const items = options.cases.flatMap((c) => Array.from({ length: options.repeat }, (_, round) => ({ c, round })));
  let nextStart = now();
  let done = 0;

  async function askOnce(c: EvalCase, round: number): Promise<AdapterAnswer> {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const timeout = new Promise<AdapterAnswer>((resolve) => {
      timer = setTimeout(() => {
        controller.abort();
        resolve(
          errorAnswer(`${Math.round(timeoutMs / 1000)} 秒で打ち切りました。`, {
            latencyMs: timeoutMs,
            // signal を見ないキット（line-concierge・doc-reader）は呼び出しが裏で続くことがあり、その分の usage は取れない。
            // 費用が「以上」だと分かるよう、印だけの usage を 1 件添える（costYen が見る）
            usage: [{ model: options.adapter.info.model ?? "unknown", input: 0, output: 0, cacheRead: 0, cacheWrite5m: 0, cacheWrite1h: 0, lowerBound: true }],
          }),
        );
      }, timeoutMs);
    });
    try {
      return await Promise.race([
        Promise.resolve()
          .then(() => options.adapter.ask(c, round, controller.signal))
          .catch((error: unknown) => errorAnswer(`キットの呼び出しで思わぬ失敗がありました（${error instanceof Error ? error.message : String(error)}）。`)),
        timeout,
      ]);
    } finally {
      clearTimeout(timer);
    }
  }

  const asked = await runPool(items, options.concurrency, async ({ c, round }): Promise<Asked> => {
    // 送り始めの間隔をそろえる（置いた先の窓口の 1 分 10 回の内側に収めるため）
    const wait = Math.max(0, nextStart - now());
    nextStart = Math.max(now(), nextStart) + options.intervalMs;
    if (wait > 0) await sleep(wait);
    let attempts = 0;
    let answer: AdapterAnswer;
    for (;;) {
      answer = await askOnce(c, round);
      attempts += 1;
      if (answer.status !== "error" || answer.retryable !== true || attempts > RETRY_DELAYS_MS.length) break;
      await sleep(jittered(RETRY_DELAYS_MS[attempts - 1], random));
    }
    done += 1;
    options.onAnswer?.(done, items.length);
    return { c, round, answer, attempts };
  });

  const pending = asked.filter((item) => ruleDecision(item.c, item.answer) === null);
  const judged = await runFirstThenPool(pending, JUDGE_CONCURRENCY, async (item): Promise<JudgeOutcome> => {
    try {
      return await options.judge.judge(item.c, item.answer, item.round);
    } catch (error) {
      return { ok: false, error: `採点で思わぬ失敗がありました（${error instanceof Error ? error.message : String(error)}）。`, usage: [], raw: null };
    }
  });
  const judgeOf = new Map(pending.map((item, i) => [item, judged[i]]));

  return asked.map((item) => {
    const judge = judgeOf.get(item) ?? null;
    return {
      case: item.c,
      answer: item.answer,
      judge,
      result: gradeCase(item.c, item.answer, judge, { round: item.round, attempts: item.attempts, judgeMode: options.judge.info.mode }),
    };
  });
}
