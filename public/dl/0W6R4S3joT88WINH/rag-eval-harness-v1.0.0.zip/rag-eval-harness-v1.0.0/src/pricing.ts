import type { UsageRecord } from "./types.ts";

/** 100 万トークンあたりのドル（2026-09 時点の公開価格）。キャッシュ読みは 0.1 倍、書き込みは 5 分 1.25 倍・1 時間 2 倍 */
export const PRICES: Record<string, { input: number; output: number }> = {
  "claude-opus-5": { input: 5, output: 25 },
  "claude-opus-4-8": { input: 5, output: 25 },
  "claude-sonnet-5": { input: 2, output: 10 },
  "claude-haiku-4-5": { input: 1, output: 5 },
};
export const CACHE_READ_RATE = 0.1;
export const CACHE_WRITE_5M_RATE = 1.25;
export const CACHE_WRITE_1H_RATE = 2;
export const DEFAULT_YEN_PER_USD = 150;

export function priceOf(model: string): { input: number; output: number } | null {
  const exact = PRICES[model];
  if (exact !== undefined) return exact;
  // 名前そのものか、名前 + "-" + 8 桁の日付（スナップショット名）だけを当てる。claude-opus-5-1 のような偽の一致は避ける
  const dated = Object.keys(PRICES).find((name) => new RegExp(`^${name}-\\d{8}$`).test(model));
  return dated === undefined ? null : PRICES[dated];
}

export function costUsd(usage: UsageRecord): number | null {
  const price = priceOf(usage.model);
  if (price === null) return null;
  const input = usage.input + usage.cacheRead * CACHE_READ_RATE + usage.cacheWrite5m * CACHE_WRITE_5M_RATE + usage.cacheWrite1h * CACHE_WRITE_1H_RATE;
  return (input * price.input + usage.output * price.output) / 1_000_000;
}

export interface Cost {
  yen: number;
  lowerBound: boolean;
  unknownModels: string[];
}

/** usage の実数 × 値段の表 × 1 ドルの円。表に無いモデルは数えずに名前を返す */
export function costYen(records: UsageRecord[], yenPerUsd: number = DEFAULT_YEN_PER_USD): Cost {
  let usd = 0;
  const unknownModels: string[] = [];
  for (const usage of records) {
    const cost = costUsd(usage);
    if (cost === null) {
      if (!unknownModels.includes(usage.model)) unknownModels.push(usage.model);
    } else {
      usd += cost;
    }
  }
  return { yen: usd * yenPerUsd, lowerBound: records.some((usage) => usage.lowerBound), unknownModels };
}
