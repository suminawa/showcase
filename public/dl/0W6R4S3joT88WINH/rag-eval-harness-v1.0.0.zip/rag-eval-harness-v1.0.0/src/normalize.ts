/**
 * 照合のための語の揃え方。要点・出典・禁止の照合と、語の一致の採点で共通に使う。
 * NFKC（全角英数と記号を半角に）→ 波ダッシュとハイフンのゆれをそろえる → 数字の桁区切りの , を除く → 空白を除く → 英字は小文字
 */
export function normalizeText(text: string): string {
  return text
    .normalize("NFKC")
    .replace(/[〜～]/g, "~")
    .replace(/[‐‑‒–—―−]/g, "-")
    .replace(/(\d),(?=\d{3}(?:\D|$))/g, "$1")
    .replace(/\s+/g, "")
    .toLowerCase();
}

/** needle を揃えた字が haystack を揃えた字に含まれるか。needle が空なら false */
export function includesNormalized(haystack: string, needle: string): boolean {
  const target = normalizeText(needle);
  return target !== "" && normalizeText(haystack).includes(target);
}
