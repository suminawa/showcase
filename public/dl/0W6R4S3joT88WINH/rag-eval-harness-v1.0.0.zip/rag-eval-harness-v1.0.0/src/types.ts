/** 型だけを持つファイル。実行するコードは置かない */

export type KitName = "ai-concierge" | "line-concierge" | "doc-reader" | "http" | "replay";
export type JudgeMode = "claude" | "keyword" | "replay";

/** 要点の特別な値。refuse =（答えない）、handoff =（引き継ぐ）、empty =（空） */
export type Special = "refuse" | "handoff" | "empty";

/** 質問表の 1 行 */
export interface EvalCase {
  id: string;
  /** CSV の行番号（見出しが 1 行目） */
  line: number;
  question: string;
  /** 期待する答えの要点。特別な値のときは空 */
  points: string[];
  special: Special | null;
  sources: string[];
  forbidden: string[];
  tags: string[];
  previous: string | null;
  /** 書類の絶対パス（doc-reader だけ） */
  document: string | null;
  /** 質問表に書いたままの書類の場所 */
  documentLabel: string | null;
  form: string | null;
  /** 知らない列（レポートの「ご参考」に出す） */
  extras: Record<string, string>;
}

export interface SourceRef {
  title: string;
  url: string | null;
}

/** 1 回の API 呼び出しの使った量。費用は pricing.ts が円にする */
export interface UsageRecord {
  model: string;
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite5m: number;
  cacheWrite1h: number;
  /** キャッシュの書き込みの数が分からない（費用は「以上」と出す） */
  lowerBound: boolean;
}

/** doc-reader の 1 項目。値と要点の比べ方は score/grade.ts */
export interface DocField {
  key: string;
  label: string;
  type: string;
  value: string | number | boolean | null;
  /** 要点をキットの normalizeValue で直した値（string は要点のまま、（空）は null） */
  expected: string | number | boolean | null;
  /** 書類に書かれていた字。明細のセルは null */
  evidence: string | null;
  needsReview: boolean;
  warnings: string[];
}

export interface AdapterAnswer {
  status: "ok" | "error";
  answer: string;
  sources: SourceRef[];
  /** 断ったか。窓口が印を返さないときは null（採点者が見る） */
  refused: boolean | null;
  /** 担当者に引き継いだか（LINE だけ）。ほかは null */
  handoff: boolean | null;
  /** 検索で拾った片（BM25 の形と、retrieved を返す http だけ）。無いときは null */
  retrieved: SourceRef[] | null;
  field?: DocField;
  latencyMs: number;
  usage: UsageRecord[];
  model: string | null;
  error?: string;
  /** 429・529・5xx・接続の切れ。run.ts がやり直す */
  retryable?: boolean;
}

export interface KitInfo {
  name: KitName;
  /** レポートの見出しに使う名前（「みなと工務店の案内窓口」など） */
  label: string;
  mode: "in-process" | "http" | "replay";
  version: string | null;
  model: string | null;
}

export interface Adapter {
  info: KitInfo;
  /** レポートの頭に出す注意（全文モードなど） */
  notes: string[];
  ask(c: EvalCase, round: number, signal: AbortSignal): Promise<AdapterAnswer>;
}

export type PointStatus = "covered" | "missing" | "contradicted";

export interface ForbiddenCheck {
  violated: boolean;
  quote: string;
  /** 採点者は違反と言ったが、quote が答えに見つからなかった */
  review: boolean;
}

export interface Judgment {
  declined: boolean;
  points: PointStatus[];
  forbidden: ForbiddenCheck[];
  reason: string;
  /** 要点の番号が欠けていた・余計だった（採点が不完全） */
  incomplete: boolean;
}

export type JudgeOutcome =
  | { ok: true; judgment: Judgment; usage: UsageRecord[]; raw: string | null }
  | { ok: false; error: string; usage: UsageRecord[]; raw: string | null };

export interface JudgeInfo {
  mode: JudgeMode;
  model: string | null;
  effort: string | null;
  rubricVersion: string | null;
}

export interface Judge {
  info: JudgeInfo;
  judge(c: EvalCase, answer: AdapterAnswer, round: number): Promise<JudgeOutcome>;
}

export type Verdict = "correct" | "partial" | "wrong" | "noAnswer" | "error" | "judgeError";

export interface CaseResult {
  id: string;
  round: number;
  tags: string[];
  verdict: Verdict;
  points: { text: string; status: PointStatus }[];
  forbidden: { text: string; violated: boolean; review: boolean; quote: string }[];
  citationHit: boolean | null;
  retrievalHit: boolean | null;
  refused: boolean | null;
  handoff: boolean | null;
  latencyMs: number;
  attempts: number;
  reason: string;
  judgedBy: "rule" | JudgeMode;
  incomplete: boolean;
}

/** cases.jsonl の 1 行（type: "case"）。replay と描き直しはこれを読む */
export interface CaseRecord {
  case: EvalCase;
  answer: AdapterAnswer;
  judge: JudgeOutcome | null;
  result: CaseResult;
}

/** 実行の情報。cases.jsonl の 1 行目（type: "run"）と result.json の頭に使う */
export interface RunMeta {
  tool: { name: string; version: string };
  startedAt: string;
  finishedAt: string;
  kit: KitInfo;
  judge: JudgeInfo;
  cases: { file: string; sha256: string; count: number };
  rounds: number;
  notes: string[];
  /** 1 ドルの円（--yen-per-usd） */
  yenPerUsd: number;
  /** レポートと要約で伏せ字にしたか（--no-redact で false） */
  redact: boolean;
}

/** 集計（score/aggregate.ts）。率は 0〜1、分母が 0 なら null。費用は円 */
export interface Summary {
  /** (正解 + 部分 × 0.5) ÷ 採点できた問い。--repeat のときは回ごとの平均 */
  score: number | null;
  /** --repeat のときの回ごとの正答率の最小〜最大 */
  scoreRange: { min: number; max: number } | null;
  correctRate: number | null;
  counts: { correct: number; partial: number; wrong: number; noAnswer: number; error: number; judgeError: number };
  /** 採点できた数（正解・部分・誤り・無回答） */
  graded: number;
  total: number;
  citationHit: number | null;
  retrievalHit: number | null;
  refusal: { shouldRefuse: number; refusedWhenShould: number | null; overRefused: number | null };
  handoff: { shouldHandoff: number; handedOffWhenShould: number | null; unexpected: number } | null;
  forbidden: { violated: number; review: number };
  latencyMs: { p50: number | null; p95: number | null };
  costJpy: { kit: number; judge: number; perQuestion: number | null };
  /** キャッシュの書き込みの数が分からない呼び出しがあった（費用は「以上」） */
  costLowerBound: boolean;
  /** 値段の表に無いモデル（費用に入れていない） */
  unknownModels: string[];
  tags: Array<{ tag: string; score: number | null; count: number }>;
  errors: Array<{ id: string; round: number; reason: string }>;
  judgeErrors: Array<{ id: string; round: number; reason: string }>;
  rounds: number;
}

/** 前回との差（score/diff.ts） */
export interface BaselineDiff {
  dir: string;
  score: number | null;
  /** 今回 − 前回（0〜1 の差）。比べられなければ null */
  delta: number | null;
  improved: string[];
  regressed: string[];
  /** 共通の問いの数 */
  common: number;
  notes: string[];
}

/** result.json の 1 問（答えは先頭 200 字、伏せ字の後） */
export interface ResultEntry {
  id: string;
  round: number;
  tags: string[];
  status: "ok" | "error";
  verdict: Verdict;
  points: Array<{ text: string; status: PointStatus }>;
  forbidden: Array<{ text: string; violated: boolean; quote: string; review: boolean }>;
  citationHit: boolean | null;
  retrievalHit: boolean | null;
  refused: boolean | null;
  handoff: boolean | null;
  latencyMs: number;
  attempts: number;
  usage: { kit: UsageRecord[]; judge: UsageRecord[] };
  answerHead: string;
  sources: SourceRef[];
  reason: string;
}

/** result.json（"schema": "rag-eval/1"）。CI と前回との差が読む */
export interface ResultJson {
  schema: "rag-eval/1";
  tool: { name: string; version: string };
  startedAt: string;
  finishedAt: string;
  kit: KitInfo;
  judge: JudgeInfo;
  cases: { file: string; sha256: string; count: number };
  summary: Summary;
  baseline: BaselineDiff | null;
  notes: string[];
  results: ResultEntry[];
}
