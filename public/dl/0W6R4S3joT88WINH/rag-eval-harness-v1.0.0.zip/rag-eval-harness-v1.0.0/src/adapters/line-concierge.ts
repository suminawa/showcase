import { HarnessError } from "../errors.ts";
import type { Adapter, AdapterAnswer, EvalCase, SourceRef } from "../types.ts";
import type { AiConciergeModule } from "./ai-concierge.ts";
import { NO_KEY_MESSAGE, RELAXED_LIMITS, RELAXED_PER_USER_DAILY, WHOLE_MODE_NOTE, errorAnswer, noNetworkFetch, sourcesOfEntries, usageOfLog } from "./common.ts";
import { loadCoreForLine, loadKit } from "./kit-loader.ts";
import { callFailure, modelMismatch, recordStream, usageOfCalls, type CallRecord, type StreamClientLike } from "./recording-client.ts";

/** キットの値の型（キットの型は取り込まず、使う形だけを下の interface に書く） */
type Any = any;
export interface LineOutcome {
  messages: Array<{ text: string }>;
  answered: boolean;
  handoff: boolean;
  reason: string;
}
export interface LineConciergeModule {
  createLineBot(config: Any, deps: Any): { simulate(userId: string, text: string): Promise<LineOutcome> };
  resolveLineConfig(input: { file?: unknown; env?: Record<string, string | undefined> }): Any;
  createMemoryStore(): Any;
  fakeLineApi(): Any;
}
/** LINE 窓口キットが中で使う案内窓口キットのうち、借りる名前 */
export type CoreModule = Pick<AiConciergeModule, "loadConfigFile" | "loadIndex" | "retrieve" | "retrievalMode" | "createAnthropicClient" | "createLogRing">;

export interface LineConciergeOptions {
  kitDir: string;
  configPath: string;
  indexPath: string;
  apiKey: string | null;
  baseClient?: StreamClientLike;
  /** 検査用: キットの node_modules の案内窓口キットの代わり */
  core?: CoreModule;
  now?: () => number;
}

/**
 * LINE の返信の文を、本文と出典に分ける。出典は「参考:」の行より後ろに 1 行 1 つ（題 URL）
 * （キットの sourcesBlock の形。URL の無い文書は LINE の出典に出ない）
 */
export function splitLineText(text: string, label: string): { body: string; sources: SourceRef[] } {
  const marker = `\n\n${label}:\n`;
  const at = text.lastIndexOf(marker);
  if (at < 0) return { body: text, sources: [] };
  const sources = text
    .slice(at + marker.length)
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line !== "")
    .map((line) => {
      const space = line.lastIndexOf(" ");
      return space < 0 ? { title: line, url: null } : { title: line.slice(0, space), url: line.slice(space + 1) };
    });
  return { body: text.slice(0, at), sources };
}

/** 答えに使えない Outcome（上限・長すぎ・空・失敗）は実行エラーにする */
const ERROR_REASONS: Record<string, string> = {
  unavailable: "キットが答えを出せませんでした（unavailable）。",
  limit: "キットの回数の上限に当たりました（limit）。",
  too_long: "質問がキットの字数の上限を超えています（too_long）。",
  empty: "質問が空です（empty）。",
};

export async function createLineConciergeAdapter(options: LineConciergeOptions): Promise<Adapter> {
  const now = options.now ?? (() => Date.now());
  const kit = await loadKit("line-concierge", options.kitDir);
  const mod = kit.module as unknown as LineConciergeModule;
  const core = options.core ?? (loadCoreForLine(options.kitDir) as unknown as CoreModule);
  const file = await core.loadConfigFile(options.configPath);
  if (file === undefined) throw new HarnessError(`設定ファイル ${options.configPath} が見つかりません。--config で concierge.config.json の場所を指定してください。`);
  let config: Any;
  try {
    // LINE の鍵は渡さない（simulate は使わない）。渡すのは ANTHROPIC_API_KEY だけ
    config = mod.resolveLineConfig({ file, env: options.apiKey === null ? {} : { ANTHROPIC_API_KEY: options.apiKey } });
  } catch (error) {
    throw new HarnessError(`キットの設定を読めませんでした（${error instanceof Error ? error.message : String(error)}）。`);
  }
  config.concierge.limits = { ...config.concierge.limits, ...RELAXED_LIMITS };
  config.line.perUserDaily = RELAXED_PER_USER_DAILY;
  let index: Any;
  try {
    index = await core.loadIndex(options.indexPath);
  } catch (error) {
    throw new HarnessError(`索引を読めませんでした（${error instanceof Error ? error.message : String(error)}）。--index で索引の場所を指定してください。`);
  }
  const whole = core.retrievalMode(index, config.concierge.retrieval.wholeCorpusMaxTokens) === "whole";
  const base = options.baseClient ?? (options.apiKey === null ? null : core.createAnthropicClient(options.apiKey));
  const label: string = config.line.sourcesLabel;
  return {
    info: { name: "line-concierge", label: `${config.concierge.site.name}の LINE 窓口`, mode: "in-process", version: kit.version, model: config.concierge.answer.model },
    notes: [...kit.warnings, ...(whole ? [WHOLE_MODE_NOTE] : [])],
    async ask(c: EvalCase, round: number): Promise<AdapterAnswer> {
      if (base === null) return errorAnswer(NO_KEY_MESSAGE);
      const calls: CallRecord[] = [];
      const log = core.createLogRing();
      // LINE には何も送らない: 偽の LINE の API、記憶の中の保存先、外へ出ない fetch
      const bot = mod.createLineBot(config, {
        index,
        client: recordStream(base, calls),
        lineApi: mod.fakeLineApi(),
        store: mod.createMemoryStore(),
        log,
        fetch: noNetworkFetch,
        logger: () => {},
      });
      // 利用者の名前は問いごとに新しく（会話と回数が混ざらない）。前の質問は同じ名前で先に送る
      const userId = `eval-${c.id}-${round + 1}`;
      const history: Array<{ role: "user" | "assistant"; content: string }> = [];
      if (c.previous !== null) {
        const previous = await bot.simulate(userId, c.previous);
        const failure = callFailure(calls);
        if (failure !== null) return errorAnswer(failure.error, { retryable: failure.retryable, usage: usageOfCalls(calls) });
        if (ERROR_REASONS[previous.reason] !== undefined) return errorAnswer(ERROR_REASONS[previous.reason], { usage: usageOfCalls(calls) });
        history.push({ role: "user", content: c.previous }, { role: "assistant", content: splitLineText(previous.messages[0]?.text ?? "", label).body });
      }
      const started = now();
      const outcome = await bot.simulate(userId, c.question);
      const latencyMs = now() - started;
      const usage = usageOfCalls(calls);
      const failure = callFailure(calls);
      if (failure !== null) return errorAnswer(failure.error, { retryable: failure.retryable, latencyMs, usage });
      if (ERROR_REASONS[outcome.reason] !== undefined) return errorAnswer(ERROR_REASONS[outcome.reason], { latencyMs, usage });
      const mismatch = modelMismatch(calls);
      if (mismatch !== null) return errorAnswer(mismatch, { latencyMs, usage });
      const { body, sources } = splitLineText(outcome.messages[0]?.text ?? "", label);
      return {
        status: "ok",
        answer: body,
        sources,
        refused: outcome.reason === "not_in_documents",
        handoff: outcome.handoff,
        retrieved: whole || outcome.handoff ? null : sourcesOfEntries(core.retrieve({ index, config: config.concierge, question: c.question, history }).entries),
        latencyMs,
        usage: usage.length > 0 ? usage : usageOfLog(log.list()),
        model: calls.at(-1)?.model ?? config.concierge.answer.model,
      };
    },
  };
}
