import type { UsageRecord } from "../types.ts";

/**
 * 記録つきの client。キットに差し込む Anthropic の client を包み、最後のメッセージの usage と応答の model を記録して、
 * そのまま返す。キットのコードは変えない（3 キットとも deps.client で差し替えられる）。
 * 案内窓口・LINE 窓口は messages.stream、書類読み取りは messages.create を使う。
 */

export interface CallRecord {
  requestedModel: string;
  model: string | null;
  usage: UsageRecord | null;
  stopReason: string | null;
  /** 失敗したときの HTTP の状態（接続の切れは null） */
  errorStatus: number | null;
  error: string | null;
  retryable: boolean;
}

/** キットの client の形（キットの型は取り込まず、使う形だけを見る） */
export interface StreamClientLike {
  messages: { stream(params: any): any };
}

export interface CreateClientLike {
  messages: { create(params: any): Promise<any> };
}

export function statusOf(error: unknown): number | null {
  const status = (error as { status?: unknown } | null)?.status;
  return typeof status === "number" ? status : null;
}

/** やり直してよい失敗: 429・529・5xx と接続の切れ */
export function isRetryable(error: unknown): boolean {
  const status = statusOf(error);
  if (status !== null) return status === 429 || status >= 500;
  const name = (error as { name?: unknown } | null)?.name;
  const code = (error as { code?: unknown } | null)?.code;
  return (typeof name === "string" && /Connection/i.test(name)) || code === "ECONNRESET" || code === "ECONNREFUSED" || code === "ETIMEDOUT";
}

/** API の usage を記録の形に。書き込みの 5 分と 1 時間の内訳が無ければ、全部を 5 分として数える */
export function usageRecordOf(model: string, usage: any, lowerBound: boolean = false): UsageRecord {
  const creation = usage?.cache_creation;
  const five = creation?.ephemeral_5m_input_tokens;
  const hour = creation?.ephemeral_1h_input_tokens;
  return {
    model,
    input: usage?.input_tokens ?? 0,
    output: usage?.output_tokens ?? 0,
    cacheRead: usage?.cache_read_input_tokens ?? 0,
    cacheWrite5m: typeof five === "number" ? five : (usage?.cache_creation_input_tokens ?? 0),
    cacheWrite1h: typeof hour === "number" ? hour : 0,
    lowerBound,
  };
}

function recordMessage(calls: CallRecord[], requestedModel: string, message: any): void {
  const model = typeof message?.model === "string" ? message.model : null;
  calls.push({
    requestedModel,
    model,
    usage: usageRecordOf(model ?? requestedModel, message?.usage),
    stopReason: message?.stop_reason ?? null,
    errorStatus: null,
    error: null,
    retryable: false,
  });
}

function recordError(calls: CallRecord[], requestedModel: string, error: unknown): void {
  calls.push({
    requestedModel,
    model: null,
    usage: null,
    stopReason: null,
    errorStatus: statusOf(error),
    error: error instanceof Error ? error.message : String(error),
    retryable: isRetryable(error),
  });
}

export function recordStream(inner: StreamClientLike, calls: CallRecord[]): StreamClientLike {
  return {
    messages: {
      stream(params: any) {
        const requestedModel = String(params?.model ?? "");
        const stream = inner.messages.stream(params);
        let settled = false;
        const fail = (error: unknown): never => {
          if (!settled) recordError(calls, requestedModel, error);
          settled = true;
          throw error;
        };
        return {
          [Symbol.asyncIterator]() {
            const iterator = stream[Symbol.asyncIterator]();
            return {
              next: () => (iterator.next() as Promise<unknown>).catch(fail),
              return: (value?: unknown) => (typeof iterator.return === "function" ? iterator.return(value) : Promise.resolve({ done: true, value })),
            };
          },
          async finalMessage() {
            try {
              const message = await stream.finalMessage();
              if (!settled) recordMessage(calls, requestedModel, message);
              settled = true;
              return message;
            } catch (error) {
              return fail(error);
            }
          },
          abort() {
            if (typeof stream.abort === "function") stream.abort();
          },
        };
      },
    },
  };
}

export function recordCreate(inner: CreateClientLike, calls: CallRecord[]): CreateClientLike {
  return {
    messages: {
      async create(params: any) {
        const requestedModel = String(params?.model ?? "");
        try {
          const message = await inner.messages.create(params);
          recordMessage(calls, requestedModel, message);
          return message;
        } catch (error) {
          recordError(calls, requestedModel, error);
          throw error;
        }
      },
    },
  };
}

/** 同じモデルか: そのままの一致か、頼んだ名前に日付（-YYYYMMDD）が付いただけのもの（claude-opus-5 に claude-opus-5-5 は別） */
export function sameModel(requested: string, answered: string): boolean {
  return answered === requested || (answered.startsWith(requested) && /^-\d{8}$/.test(answered.slice(requested.length)));
}

/** 応答の model が頼んだ model と違う呼び出し（別のモデルで答えた問いは実行エラーにする） */
export function modelMismatch(calls: CallRecord[]): string | null {
  const bad = calls.find((call) => call.model !== null && call.requestedModel !== "" && !sameModel(call.requestedModel, call.model));
  return bad === undefined ? null : `応答のモデル（${bad.model}）が、キットが頼んだモデル（${bad.requestedModel}）と違います。`;
}

/** 失敗した呼び出し。retryable はやり直してよいか */
export function callFailure(calls: CallRecord[]): { error: string; retryable: boolean } | null {
  const failed = calls.find((call) => call.error !== null);
  if (failed !== undefined) {
    const status = failed.errorStatus === null ? "接続の切れ" : `HTTP ${failed.errorStatus}`;
    return { error: `Anthropic の呼び出しが失敗しました（${status}）。`, retryable: failed.retryable };
  }
  const refused = calls.find((call) => call.stopReason === "refusal");
  if (refused !== undefined) return { error: "Anthropic が答えを断りました（stop_reason: refusal）。", retryable: false };
  return null;
}

export function usageOfCalls(calls: CallRecord[]): UsageRecord[] {
  return calls.flatMap((call) => (call.usage === null ? [] : [call.usage]));
}
