import { execFileSync } from "node:child_process";
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { HarnessError } from "../errors.ts";
import type { AdapterAnswer, SourceRef, UsageRecord } from "../types.ts";

/** 評価の間だけ、読み込んだ設定の回数の上限を記憶の中でゆるめる（ファイルは書き換えない） */
export const RELAXED_LIMITS = { perMinute: 10000, perHour: 100000, dailyQuestions: 100000 };
export const RELAXED_READER_LIMITS = { perMinute: 10000, perHour: 100000, daily: 100000 };
export const RELAXED_PER_USER_DAILY = 10000;

export const WHOLE_MODE_NOTE = "全文モード（検索なし）: 文書が少ないため、キットは毎回すべての文書を読ませています。検索の当たりは出しません。";
export const NO_KEY_MESSAGE = "ANTHROPIC_API_KEY が設定されていません。export ANTHROPIC_API_KEY=… で入れてから、もう一度お試しください（--judge keyword・replay・--dry-run では要りません）。";

export function errorAnswer(error: string, options: { retryable?: boolean; latencyMs?: number; usage?: UsageRecord[]; model?: string | null } = {}): AdapterAnswer {
  return {
    status: "error",
    answer: "",
    sources: [],
    refused: null,
    handoff: null,
    retrieved: null,
    latencyMs: options.latencyMs ?? 0,
    usage: options.usage ?? [],
    model: options.model ?? null,
    error,
    retryable: options.retryable ?? false,
  };
}

/** キットに渡す fetch。評価の質問を Slack・LINE・記録の送り先に流さないよう、外への送信は必ず失敗させる */
export const noNetworkFetch = (async () => {
  throw new Error("評価の実行では、キットから外へは送りません。");
}) as unknown as typeof fetch;

/** 片の一覧を出典の形に（同じ文書は 1 度） */
export function sourcesOfEntries(entries: Array<{ doc: { title: string; url: string | null } }>): SourceRef[] {
  const out: SourceRef[] = [];
  for (const entry of entries) {
    const source = { title: entry.doc.title, url: entry.doc.url ?? null };
    if (!out.some((item) => item.title === source.title && item.url === source.url)) out.push(source);
  }
  return out;
}

/** キットの記録（LogEntry）から usage を戻す。書き込みの数が無いので費用は「以上」 */
export function usageOfLog(entries: Array<{ model: string; inputTokens: number; outputTokens: number; cacheReadTokens: number }>): UsageRecord[] {
  return entries
    .filter((entry) => entry.inputTokens + entry.outputTokens > 0)
    .map((entry) => ({ model: entry.model, input: entry.inputTokens, output: entry.outputTokens, cacheRead: entry.cacheReadTokens, cacheWrite5m: 0, cacheWrite1h: 0, lowerBound: true }));
}

/** 見本の索引づくりを待つ長さ */
const SAMPLE_INDEX_TIMEOUT_MS = 120_000;

/**
 * --sample の索引をキットの CLI で作る（node <cli> index --config <設定> --out <出力>、作業フォルダはキットのフォルダ）。
 * LINE 窓口キットは node_modules/@suminawa/ai-concierge/dist/cli.js を使う。
 * 環境変数は PATH だけを渡す（記録の Webhook などをキットに読ませず、エラーの文にも出さない）
 */
export function buildSampleIndex(cliPath: string, kitDir: string, configPath: string, outPath: string, timeoutMs: number = SAMPLE_INDEX_TIMEOUT_MS): void {
  mkdirSync(dirname(resolve(outPath)), { recursive: true });
  try {
    execFileSync(process.execPath, [cliPath, "index", "--config", configPath, "--out", resolve(outPath)], { cwd: kitDir, stdio: "pipe", env: { PATH: process.env.PATH ?? "" }, timeout: timeoutMs });
  } catch (error) {
    if ((error as { code?: unknown }).code === "ETIMEDOUT") {
      throw new HarnessError(`見本の索引を作れませんでした（${timeoutMs / 1000} 秒を過ぎても終わらなかったため、止めました）。キットのフォルダの場所をご確認のうえ、もう一度お試しください。`);
    }
    const detail = (error as { stderr?: Buffer }).stderr?.toString().trim() || (error instanceof Error ? error.message : String(error));
    throw new HarnessError(`見本の索引を作れませんでした（${detail}）。キットのフォルダで npm install を済ませてから、もう一度お試しください。`);
  }
}
