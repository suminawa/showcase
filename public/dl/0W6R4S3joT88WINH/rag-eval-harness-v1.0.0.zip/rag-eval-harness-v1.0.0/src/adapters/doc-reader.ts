import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { HarnessError } from "../errors.ts";
import { normalizeText } from "../normalize.ts";
import type { Adapter, AdapterAnswer, DocField, EvalCase, UsageRecord } from "../types.ts";
import { NO_KEY_MESSAGE, RELAXED_READER_LIMITS, errorAnswer, noNetworkFetch } from "./common.ts";
import { loadKit } from "./kit-loader.ts";
import { callFailure, isRetryable, modelMismatch, recordCreate, usageOfCalls, type CallRecord, type CreateClientLike } from "./recording-client.ts";

export const EXTRACT_URL = "http://127.0.0.1/api/reader/extract";

/** キットの値の型（キットの型は取り込まず、使う形だけを下の interface に書く） */
type Any = any;
type Scalar = string | number | boolean | null;
export interface FormColumnLike {
  key: string;
  label: string;
  type: string;
}
export interface FormFieldLike {
  key: string;
  label: string;
  type: string;
  options: string[] | null;
  columns: FormColumnLike[] | null;
}
export interface FormLike {
  id: string;
  name: string;
  fields: FormFieldLike[];
}
export interface DocReaderModule {
  createReader(config: Any, deps: Any): { fetch(request: Request): Promise<Response> };
  loadConfigFile(path: string): Promise<unknown>;
  resolveConfig(input: { file?: unknown; env?: Record<string, string | undefined> }): Any;
  loadForms(dir: string): Promise<Map<string, FormLike>>;
  normalizeValue(type: string, raw: string | null, options: string[] | null): { value: Scalar; invalid: boolean };
  createAnthropicClient(apiKey: string): CreateClientLike;
}

export interface DocReaderOptions {
  kitDir: string;
  configPath: string;
  formsDir: string;
  apiKey: string | null;
  baseClient?: CreateClientLike;
  now?: () => number;
}

/** 質問の列が指すもの: 項目（キーか名前）か、明細のセル（表.列#行。行は 1 から） */
export type Target = { kind: "field"; field: FormFieldLike } | { kind: "cell"; table: FormFieldLike; column: FormColumnLike; row: number };

const same = (a: string, b: string) => normalizeText(a) === normalizeText(b);

export function resolveTarget(form: FormLike, question: string): Target | null {
  const cell = question.trim().match(/^(.+)\.(.+)#(\d+)$/);
  if (cell !== null) {
    const table = form.fields.find((field) => field.type === "table" && (same(field.key, cell[1]) || same(field.label, cell[1])));
    const column = table?.columns?.find((item) => same(item.key, cell[2]) || same(item.label, cell[2]));
    const row = Number(cell[3]);
    return table === undefined || column === undefined || row < 1 ? null : { kind: "cell", table, column, row };
  }
  const field = form.fields.find((item) => item.type !== "table" && (same(item.key, question) || same(item.label, question)));
  return field === undefined ? null : { kind: "field", field };
}

/** 帳票の型と項目の名前を、キットの forms で確かめる（API を呼ぶ前） */
export function checkDocCases(cases: EvalCase[], forms: Map<string, FormLike>): string[] {
  const problems: string[] = [];
  for (const c of cases) {
    const form = c.form === null ? undefined : forms.get(c.form);
    if (form === undefined) {
      problems.push(`${c.line} 行目: 帳票の型「${c.form ?? ""}」がキットの forms にありません（あるのは ${[...forms.keys()].join("・")}）。`);
      continue;
    }
    if (resolveTarget(form, c.question) === null) {
      problems.push(`${c.line} 行目: 「${c.question}」は帳票の型 ${form.id} の項目にありません。項目のキーか名前（明細のセルは 表.列#行）で書いてください。`);
    }
  }
  return problems;
}

interface Extraction {
  ok: boolean;
  json: Any;
  calls: CallRecord[];
  error: string | null;
  retryable: boolean;
}

/** 接続の切れ（やり直せる）: 429・529・5xx・接続の名前と、fetch の fetch failed・terminated（原因の code も見る） */
function isNetworkFailure(error: unknown): boolean {
  if (isRetryable(error) || isRetryable((error as { cause?: unknown } | null)?.cause)) return true;
  return error instanceof TypeError && /^(fetch failed|terminated)$/.test(error.message);
}

export interface DocReaderAdapter extends Adapter {
  forms: Map<string, FormLike>;
}

export async function createDocReaderAdapter(options: DocReaderOptions): Promise<DocReaderAdapter> {
  const now = options.now ?? (() => Date.now());
  const kit = await loadKit("doc-reader", options.kitDir);
  const mod = kit.module as unknown as DocReaderModule;
  let config: Any;
  let forms: Map<string, FormLike>;
  try {
    const file = await mod.loadConfigFile(options.configPath);
    config = mod.resolveConfig({ file, env: options.apiKey === null ? {} : { ANTHROPIC_API_KEY: options.apiKey } });
    forms = await mod.loadForms(options.formsDir);
  } catch (error) {
    throw new HarnessError(`キットの設定か帳票の型を読めませんでした（${error instanceof Error ? error.message : String(error)}）。--config と --forms の場所をご確認ください。`);
  }
  config.limits = { ...config.limits, ...RELAXED_READER_LIMITS };
  const base = options.baseClient ?? (options.apiKey === null ? null : mod.createAnthropicClient(options.apiKey));
  // 同じ書類の行は 1 回の読み取りで採点する（書類・帳票の型・何回目 で 1 つ）
  const cache = new Map<string, Promise<Extraction>>();
  // 費用を数えた読み取り（同じ読み取りを待っていた問いが、失敗のあとにも二重に数えないよう、キーではなく結果そのもので覚える）
  const charged = new WeakSet<object>();

  async function extract(c: EvalCase): Promise<Extraction> {
    const calls: CallRecord[] = [];
    let bytes: Buffer;
    try {
      bytes = await readFile(c.document as string);
    } catch (error) {
      const reason = (error as { code?: unknown }).code ?? (error instanceof Error ? error.message : String(error));
      return { ok: false, json: null, calls, error: `書類 ${c.documentLabel ?? basename(c.document as string)} を読めませんでした（${String(reason)}）。質問表の書類の場所をご確認ください。`, retryable: false };
    }
    let response: Response;
    let json: Any;
    try {
      // 読み取りごとに組み直す（同じ書類の 2 回目を「重なり」と数えないように）。外へ出ない fetch も渡す（念のため）
      const reader = mod.createReader(config, { forms, client: recordCreate(base as CreateClientLike, calls), fetch: noNetworkFetch });
      response = await reader.fetch(
        new Request(EXTRACT_URL, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ fileName: basename(c.document as string), data: Buffer.from(bytes).toString("base64"), form: c.form }),
        }),
      );
      json = (await response.json()) as Any;
    } catch (error) {
      // reject のままにすると、失敗が覚えに残る。接続の切れはやり直せる失敗として返し、ask が覚えを消す
      const failed = callFailure(calls);
      const detail = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
      return { ok: false, json: null, calls, error: failed?.error ?? `キットが書類を読み取れませんでした（${detail}）。`, retryable: failed?.retryable ?? isNetworkFailure(error) };
    }
    const failure = callFailure(calls);
    if (!response.ok || json?.ok !== true) {
      return { ok: false, json, calls, error: failure?.error ?? `キットが読み取れませんでした（${json?.code ?? response.status}: ${json?.message ?? ""}）。`, retryable: failure?.retryable ?? json?.code === "rate_limited" };
    }
    const mismatch = modelMismatch(calls);
    if (mismatch !== null) return { ok: false, json, calls, error: mismatch, retryable: false };
    return { ok: true, json, calls, error: null, retryable: false };
  }

  return {
    info: { name: "doc-reader", label: String(config.site?.name ?? "書類の読み取り"), mode: "in-process", version: kit.version, model: config.model },
    notes: kit.warnings,
    forms,
    async ask(c: EvalCase, round: number): Promise<AdapterAnswer> {
      if (base === null) return errorAnswer(NO_KEY_MESSAGE);
      const form = forms.get(c.form ?? "");
      const target = form === undefined ? null : resolveTarget(form, c.question);
      if (form === undefined || target === null) return errorAnswer(`「${c.question}」は帳票の型 ${c.form ?? ""} の項目にありません。`);
      const key = `${c.document}\u0000${c.form}\u0000${round}`;
      const started = now();
      let pending = cache.get(key);
      if (pending === undefined) {
        pending = extract(c);
        cache.set(key, pending);
      }
      const result = await pending;
      const latencyMs = typeof result.json?.ms === "number" ? result.json.ms : now() - started;
      // 費用は、その書類を最初に受け取った問いにだけ数える（同じ書類の問いで二重に数えない）
      let usage: UsageRecord[] = [];
      if (!charged.has(result)) {
        charged.add(result);
        usage = usageOfCalls(result.calls);
      }
      if (!result.ok) {
        // やり直せる失敗は、次の試行で読み直せるように覚えを消す
        if (result.retryable) {
          if (cache.get(key) === pending) cache.delete(key);
        }
        return errorAnswer(result.error ?? "", { retryable: result.retryable, latencyMs, usage });
      }
      const json = result.json;
      let value: Scalar = null;
      let evidence: string | null = null;
      let keyName: string;
      let label: string;
      let type: string;
      let fieldOptions: string[] | null = null;
      if (target.kind === "field") {
        const found = json.fields?.[target.field.key];
        value = found?.value ?? null;
        evidence = found?.evidence ?? "";
        keyName = target.field.key;
        label = target.field.label;
        type = target.field.type;
        fieldOptions = target.field.options;
      } else {
        value = json.tables?.[target.table.key]?.rows?.[target.row - 1]?.[target.column.key] ?? null;
        keyName = `${target.table.key}.${target.column.key}#${target.row}`;
        label = `${target.table.label}.${target.column.label}#${target.row}`;
        type = target.column.type;
      }
      const expected: Scalar = c.special === "empty" ? null : type === "string" ? (c.points[0] ?? "") : mod.normalizeValue(type, c.points[0] ?? "", fieldOptions).value;
      const warningKey = target.kind === "field" ? target.field.key : target.table.key;
      const field: DocField = {
        key: keyName,
        label,
        type,
        value,
        expected,
        evidence,
        needsReview: json.needsReview === true,
        warnings: (json.warnings ?? []).filter((warning: Any) => warning.key === warningKey || warning.key === null).map((warning: Any) => String(warning.code)),
      };
      return {
        status: "ok",
        answer: value === null ? "" : String(value),
        sources: [],
        refused: null,
        handoff: null,
        retrieved: null,
        field,
        latencyMs,
        usage,
        model: result.calls.at(-1)?.model ?? config.model,
      };
    },
  };
}
