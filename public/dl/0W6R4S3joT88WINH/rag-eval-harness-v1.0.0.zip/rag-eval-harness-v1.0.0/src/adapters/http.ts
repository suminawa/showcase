import { readFileSync } from "node:fs";
import { HarnessError } from "../errors.ts";
import type { Adapter, AdapterAnswer, EvalCase, SourceRef, UsageRecord } from "../types.ts";
import { errorAnswer } from "./common.ts";
import { usageRecordOf } from "./recording-client.ts";

/**
 * 任意の窓口の呼び方（--map map.json）。場所は JSON Pointer（RFC 6901）。
 * headers と body の文字の中の ${名前} は環境変数からだけ埋め、値はどこにも書き出さない。
 * body の文字の {{question}} は質問に、ちょうど "{{history}}" の値は会話の配列に替える。
 */
export interface HttpMap {
  method: string;
  headers: Record<string, string>;
  body: unknown;
  answer: string;
  sources: string | null;
  sourceTitle: string;
  sourceUrl: string;
  refused: string | null;
  retrieved: string | null;
  usage: string | null;
  model: string | null;
}

/** 既定の形: POST {url}、本文 {"question", "history"}、応答 {"answer", "sources": [{title, url}], "refused"?, "retrieved"?, "usage"?, "model"?} */
export const DEFAULT_MAP: HttpMap = {
  method: "POST",
  headers: {},
  body: { question: "{{question}}", history: "{{history}}" },
  answer: "/answer",
  sources: "/sources",
  sourceTitle: "/title",
  sourceUrl: "/url",
  refused: "/refused",
  retrieved: "/retrieved",
  usage: "/usage",
  model: "/model",
};

type Turn = { role: "user" | "assistant"; content: string };

export function getPointer(value: unknown, pointer: string): unknown {
  if (pointer === "") return value;
  if (!pointer.startsWith("/")) return undefined;
  let current: unknown = value;
  for (const raw of pointer.slice(1).split("/")) {
    const key = raw.replace(/~1/g, "/").replace(/~0/g, "~");
    if (current === null || typeof current !== "object") return undefined;
    current = (current as Record<string, unknown>)[key];
  }
  return current;
}

function pointerOf(raw: Record<string, unknown>, name: keyof HttpMap, fallback: string | null): string | null {
  const value = raw[name];
  if (value === undefined) return fallback;
  if (value === null) return null;
  if (typeof value !== "string" || (value !== "" && !value.startsWith("/"))) throw new HarnessError(`--map の ${name} は / で始まる JSON Pointer で書いてください（いまの値: ${String(value)}）。`);
  return value;
}

export function parseHttpMap(raw: unknown): HttpMap {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) throw new HarnessError("--map のファイルは { … } の JSON にしてください。");
  const map = raw as Record<string, unknown>;
  const headers = map.headers === undefined ? {} : map.headers;
  if (headers === null || typeof headers !== "object" || Array.isArray(headers) || Object.values(headers).some((value) => typeof value !== "string")) {
    throw new HarnessError("--map の headers は、名前と文字の組（{ \"authorization\": \"Bearer ${EVAL_HTTP_TOKEN}\" } など）にしてください。");
  }
  const method = typeof map.method === "string" ? map.method.toUpperCase() : "POST";
  // GET・HEAD は本文を送れないので、質問が窓口に届かない
  if (method === "GET" || method === "HEAD") {
    throw new HarnessError(`--map の method に ${method} は使えません（本文を送れないため、質問が窓口に届きません）。POST など、本文を送れる方法を指定してください。`);
  }
  return {
    method,
    headers: headers as Record<string, string>,
    body: map.body === undefined ? DEFAULT_MAP.body : map.body,
    answer: pointerOf(map, "answer", DEFAULT_MAP.answer) ?? DEFAULT_MAP.answer,
    sources: pointerOf(map, "sources", DEFAULT_MAP.sources),
    sourceTitle: pointerOf(map, "sourceTitle", DEFAULT_MAP.sourceTitle) ?? DEFAULT_MAP.sourceTitle,
    sourceUrl: pointerOf(map, "sourceUrl", DEFAULT_MAP.sourceUrl) ?? DEFAULT_MAP.sourceUrl,
    refused: pointerOf(map, "refused", DEFAULT_MAP.refused),
    retrieved: pointerOf(map, "retrieved", DEFAULT_MAP.retrieved),
    usage: pointerOf(map, "usage", DEFAULT_MAP.usage),
    model: pointerOf(map, "model", DEFAULT_MAP.model),
  };
}

export function loadHttpMap(path: string): HttpMap {
  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(path, "utf8"));
  } catch (error) {
    throw new HarnessError(`--map のファイル ${path} を JSON として読めません（${error instanceof Error ? error.message : String(error)}）。`);
  }
  return parseHttpMap(raw);
}

/** ${名前} を環境変数で埋める。無ければ名前を添えて止める（値そのものは文に入れない） */
function fillEnv(text: string, env: Record<string, string | undefined>): string {
  return text.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_whole, name: string) => {
    const value = env[name];
    if (value === undefined || value === "") throw new HarnessError(`--map の \${${name}} を環境変数 ${name} で渡してください（値はどこにも書き出しません）。`);
    return value;
  });
}

export function fillTemplate(value: unknown, vars: { question: string; history: Turn[] }, env: Record<string, string | undefined>): unknown {
  if (typeof value === "string") {
    if (value === "{{history}}") return vars.history;
    // 置き換えは関数で渡す（質問の $$・$&・$`・$' を置き換えの記号として読ませない）
    return fillEnv(value, env).replace(/\{\{question\}\}/g, () => vars.question);
  }
  if (Array.isArray(value)) return value.map((item) => fillTemplate(item, vars, env));
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, fillTemplate(item, vars, env)]));
  }
  return value;
}

function sourcesAt(json: unknown, pointer: string | null, map: HttpMap): SourceRef[] | null {
  if (pointer === null) return null;
  const list = getPointer(json, pointer);
  if (!Array.isArray(list)) return null;
  return list.map((item) => {
    if (typeof item === "string") return { title: item, url: null };
    const title = getPointer(item, map.sourceTitle);
    const url = getPointer(item, map.sourceUrl);
    return { title: typeof title === "string" ? title : "", url: typeof url === "string" ? url : null };
  });
}

export interface HttpAdapterOptions {
  url: string;
  map?: HttpMap;
  env: Record<string, string | undefined>;
  fetchImpl?: typeof fetch;
  now?: () => number;
}

interface Reply {
  text: string;
  json: unknown;
}

export function createHttpAdapter(options: HttpAdapterOptions): Adapter {
  const map = options.map ?? DEFAULT_MAP;
  const doFetch = options.fetchImpl ?? fetch;
  const now = options.now ?? (() => Date.now());
  // ${…} が足りなければ、最初の問いを送る前に止める
  fillTemplate({ headers: map.headers, body: map.body }, { question: "", history: [] }, options.env);

  async function send(question: string, history: Turn[], signal: AbortSignal): Promise<Reply | AdapterAnswer> {
    const headers = fillTemplate(map.headers, { question, history }, options.env) as Record<string, string>;
    const body = fillTemplate(map.body, { question, history }, options.env);
    let response: Response;
    try {
      response = await doFetch(options.url, {
        method: map.method,
        headers: { "content-type": "application/json", ...headers },
        body: map.method === "GET" ? undefined : JSON.stringify(body),
        signal,
      });
    } catch (error) {
      if (signal.aborted) return errorAnswer("打ち切りました。");
      return errorAnswer(`窓口につながりませんでした（${error instanceof Error ? error.name : "接続の切れ"}）。`, { retryable: true });
    }
    if (!response.ok) return errorAnswer(`窓口が ${response.status} を返しました。`, { retryable: response.status === 429 || response.status >= 500 });
    let json: unknown;
    try {
      json = await response.json();
    } catch {
      return errorAnswer("窓口の応答が JSON ではありません。");
    }
    const text = getPointer(json, map.answer);
    if (typeof text !== "string") return errorAnswer(`窓口の応答に答え（${map.answer}）がありません。`);
    return { text, json };
  }

  return {
    info: { name: "http", label: `窓口（${new URL(options.url).host}）`, mode: "http", version: null, model: null },
    notes: [],
    async ask(c: EvalCase, _round: number, signal: AbortSignal): Promise<AdapterAnswer> {
      const history: Turn[] = [];
      if (c.previous !== null) {
        const previous = await send(c.previous, [], signal);
        if ("status" in previous) return previous;
        history.push({ role: "user", content: c.previous }, { role: "assistant", content: previous.text });
      }
      const started = now();
      const reply = await send(c.question, history, signal);
      const latencyMs = now() - started;
      if ("status" in reply) return { ...reply, latencyMs };
      const refused = map.refused === null ? undefined : getPointer(reply.json, map.refused);
      const model = map.model === null ? undefined : getPointer(reply.json, map.model);
      const rawUsage = map.usage === null ? undefined : getPointer(reply.json, map.usage);
      const usage: UsageRecord[] = typeof model === "string" && rawUsage !== null && typeof rawUsage === "object" ? [usageRecordOf(model, rawUsage)] : [];
      return {
        status: "ok",
        answer: reply.text,
        sources: sourcesAt(reply.json, map.sources, map) ?? [],
        refused: typeof refused === "boolean" ? refused : null,
        handoff: null,
        retrieved: sourcesAt(reply.json, map.retrieved, map),
        latencyMs,
        usage,
        model: typeof model === "string" ? model : null,
      };
    },
  };
}
