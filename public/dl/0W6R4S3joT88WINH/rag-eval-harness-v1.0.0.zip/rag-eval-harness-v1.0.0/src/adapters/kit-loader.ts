import { existsSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { HarnessError } from "../errors.ts";

export type InProcessKit = "ai-concierge" | "line-concierge" | "doc-reader";

export const KIT_PACKAGES: Record<InProcessKit, string> = {
  "ai-concierge": "@suminawa/ai-concierge",
  "line-concierge": "@suminawa/line-concierge",
  "doc-reader": "@suminawa/doc-reader",
};

/** アダプタが使う公開の入口の名前（Task 1 の確かめで、実物にあることを見た） */
export const KIT_EXPORTS: Record<InProcessKit, string[]> = {
  "ai-concierge": ["createConcierge", "loadConfigFile", "resolveConfig", "loadIndex", "retrieve", "retrievalMode", "createAnthropicClient", "createLogRing"],
  "line-concierge": ["createLineBot", "resolveLineConfig", "createMemoryStore", "fakeLineApi"],
  "doc-reader": ["createReader", "loadConfigFile", "resolveConfig", "loadForms", "normalizeValue", "createAnthropicClient"],
};

/** LINE 窓口キットが中で使う案内窓口キットから借りる名前 */
export const CORE_EXPORTS = ["loadConfigFile", "loadIndex", "retrieve", "retrievalMode", "createAnthropicClient", "createLogRing"];

/** 動作を確かめた版（3 キットとも 1.0.x） */
export const SUPPORTED_VERSION = /^1\.0\.\d+$/;

export interface LoadedKit {
  name: string;
  version: string;
  dir: string;
  module: Record<string, unknown>;
  warnings: string[];
}

function missingExport(module: Record<string, unknown>, names: string[]): string | null {
  return names.find((name) => module[name] === undefined) ?? null;
}

/**
 * --kit-dir のキットを読み込む。dist/index.js を import する（@anthropic-ai/sdk はキットの node_modules から解決される）。
 * 読めなければ HarnessError（敬体。終了コード 2）
 */
export async function loadKit(kit: InProcessKit, kitDir: string): Promise<LoadedKit> {
  const dir = resolve(kitDir);
  const packagePath = join(dir, "package.json");
  const entry = join(dir, "dist", "index.js");
  if (!existsSync(packagePath) || !existsSync(entry)) {
    throw new HarnessError(`キットのフォルダに package.json か dist/index.js が見つかりません（${dir}）。--kit-dir に、キットの zip を展開したフォルダを指定してください。`);
  }
  let pkg: { name?: string; version?: string };
  try {
    pkg = JSON.parse(readFileSync(packagePath, "utf8")) as { name?: string; version?: string };
  } catch (error) {
    throw new HarnessError(`キットのフォルダの package.json を読めませんでした（${error instanceof Error ? error.message : String(error)}）。--kit-dir に、キットの zip を展開したフォルダを指定してください。`);
  }
  if (pkg.name !== KIT_PACKAGES[kit]) {
    throw new HarnessError(`--kit-dir のフォルダは ${KIT_PACKAGES[kit]} ではありません（package.json の name: ${pkg.name ?? "なし"}）。キットのフォルダの場所をご確認ください。`);
  }
  const version = pkg.version ?? "";
  const warnings: string[] = [];
  if (!SUPPORTED_VERSION.test(version)) {
    warnings.push(`キットの版 ${version} は、動作を確かめた版（1.0.x）と違います。続けますが、結果が想定と違うときはキットの版をご確認ください。`);
  }
  let module: Record<string, unknown>;
  try {
    module = (await import(pathToFileURL(entry).href)) as Record<string, unknown>;
  } catch (error) {
    throw new HarnessError(`キットを読み込めませんでした（${error instanceof Error ? error.message : String(error)}）。キットのフォルダで npm install を済ませてから、もう一度お試しください。`);
  }
  const missing = missingExport(module, KIT_EXPORTS[kit]);
  if (missing !== null) {
    throw new HarnessError(`キットの版が想定と違います（${missing} が見つかりません）。キットのフォルダの場所と版をご確認ください。`);
  }
  return { name: KIT_PACKAGES[kit], version, dir, module, warnings };
}

/**
 * LINE 窓口キットのフォルダの node_modules から、案内窓口キット（@suminawa/ai-concierge）を読む。
 * LINE 窓口キットは設定・索引の読み込みと検索を案内窓口キットに任せているので、同じものを使う
 */
export function loadCoreForLine(kitDir: string): Record<string, unknown> {
  let module: Record<string, unknown>;
  try {
    module = createRequire(join(resolve(kitDir), "package.json"))("@suminawa/ai-concierge") as Record<string, unknown>;
  } catch {
    throw new HarnessError("LINE 窓口キットのフォルダに @suminawa/ai-concierge が見つかりません。キットのフォルダで npm install を済ませてから、もう一度お試しください。");
  }
  const missing = missingExport(module, CORE_EXPORTS);
  if (missing !== null) {
    throw new HarnessError(`LINE 窓口キットの中の案内窓口キットの版が想定と違います（${missing} が見つかりません）。キットのフォルダで npm install をやり直してください。`);
  }
  return module;
}
