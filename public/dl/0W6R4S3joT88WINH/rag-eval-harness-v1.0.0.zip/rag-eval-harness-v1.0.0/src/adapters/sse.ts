import type { SourceRef } from "../types.ts";

/** 案内窓口キットの /chat が流す出来事（ChatEvent）のうち、読む項目だけ */
export interface ChatEventLike {
  type: string;
  text?: string;
  index?: number;
  title?: string;
  url?: string | null;
  answered?: boolean;
  reason?: string;
  code?: string;
  message?: string;
}

/**
 * SSE の data: 行を出来事として読む。行や文字が塊の境目で切れても、次の塊とつないで組み直す
 * （push に渡すのは文字。バイトの切れ目は readSse の TextDecoder が面倒を見る）
 */
export function createSseParser(): { push(chunk: string): ChatEventLike[]; flush(): ChatEventLike[] } {
  let buffer = "";
  const eventsOf = (block: string): ChatEventLike[] => {
    const data = block
      .split(/\r?\n/)
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).replace(/^ /, ""))
      .join("\n");
    if (data === "") return [];
    try {
      return [JSON.parse(data) as ChatEventLike];
    } catch {
      return [];
    }
  };
  return {
    push(chunk: string): ChatEventLike[] {
      buffer += chunk;
      const events: ChatEventLike[] = [];
      let at = buffer.search(/\r?\n\r?\n/);
      while (at >= 0) {
        const block = buffer.slice(0, at);
        buffer = buffer.slice(at).replace(/^\r?\n\r?\n/, "");
        events.push(...eventsOf(block));
        at = buffer.search(/\r?\n\r?\n/);
      }
      return events;
    },
    flush(): ChatEventLike[] {
      const rest = buffer;
      buffer = "";
      return eventsOf(rest);
    },
  };
}

/** 応答の本文（SSE）を最後まで読む。signal が止まったら読むのをやめる（キットは上流の問い合わせも止める） */
export async function readSse(body: ReadableStream<Uint8Array> | null, signal?: AbortSignal): Promise<ChatEventLike[]> {
  if (body === null) return [];
  const reader = body.getReader();
  const onAbort = () => {
    void reader.cancel().catch(() => {});
  };
  signal?.addEventListener("abort", onAbort, { once: true });
  const decoder = new TextDecoder();
  const parser = createSseParser();
  const events: ChatEventLike[] = [];
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      events.push(...parser.push(decoder.decode(value, { stream: true })));
    }
    events.push(...parser.push(decoder.decode()), ...parser.flush());
  } finally {
    signal?.removeEventListener("abort", onAbort);
  }
  return events;
}

export interface ChatSummary {
  text: string;
  sources: SourceRef[];
  refused: boolean;
  error: string | null;
}

/**
 * 出来事を 1 つの答えにまとめる。text はつなぎ、citation は出典に（重複を除く）、
 * done が answered: false・reason: not_in_documents なら断った、reason: error か error の出来事は実行エラー
 */
export function summarizeChat(events: ChatEventLike[]): ChatSummary {
  let text = "";
  const sources: SourceRef[] = [];
  let refused = false;
  let error: string | null = null;
  let done = false;
  for (const event of events) {
    if (event.type === "text" && typeof event.text === "string") text += event.text;
    else if (event.type === "citation") {
      const source = { title: event.title ?? "", url: event.url ?? null };
      if (!sources.some((item) => item.title === source.title && item.url === source.url)) sources.push(source);
    } else if (event.type === "error") error = event.message ?? event.code ?? "error";
    else if (event.type === "done") {
      done = true;
      if (event.answered === false && event.reason === "not_in_documents") refused = true;
      if (event.reason === "error" && error === null) error = "キットが答えを出せませんでした。";
    }
  }
  if (!done && error === null) error = "答えが最後まで届きませんでした。";
  return { text, sources, refused, error };
}
