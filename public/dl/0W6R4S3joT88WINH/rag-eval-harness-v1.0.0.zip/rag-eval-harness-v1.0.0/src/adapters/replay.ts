import { readFileSync } from "node:fs";
import { HarnessError } from "../errors.ts";
import type { Adapter, AdapterAnswer, CaseRecord, EvalCase, RunMeta } from "../types.ts";
import { errorAnswer } from "./common.ts";

/**
 * cases.jsonl の読み書きの形。1 行目は実行の情報（type: "run"）、2 行目からは 1 問 1 行（type: "case"）。
 * replay（答えの再生・採点の再生）と npm run report（描き直し）がこれを読む
 */
export const RUN_LINE = "run";
export const CASE_LINE = "case";

export interface CasesJsonl {
  meta: RunMeta | null;
  records: CaseRecord[];
}

export function parseCasesJsonl(text: string): CasesJsonl {
  let meta: RunMeta | null = null;
  const records: CaseRecord[] = [];
  text.split("\n").forEach((line, index) => {
    if (line.trim() === "") return;
    let value: { type?: string } & Record<string, unknown>;
    try {
      value = JSON.parse(line) as { type?: string } & Record<string, unknown>;
    } catch {
      throw new HarnessError(`cases.jsonl の ${index + 1} 行目を JSON として読めません。`);
    }
    const { type, ...rest } = value;
    if (type === RUN_LINE) meta = rest as unknown as RunMeta;
    else if (type === CASE_LINE) records.push(rest as unknown as CaseRecord);
  });
  return { meta, records };
}

export function readCasesJsonl(path: string): CasesJsonl {
  let text: string;
  try {
    text = readFileSync(path, "utf8");
  } catch {
    throw new HarnessError(`記録のファイル ${path} が見つかりません。--from に前の実行の cases.jsonl を指定してください。`);
  }
  const parsed = parseCasesJsonl(text);
  if (parsed.records.length === 0) throw new HarnessError(`記録のファイル ${path} に問いが 1 つもありません。`);
  return parsed;
}

/** 書類の場所は、手元の絶対パスを残さないよう null にして書く（質問表に書いたままの documentLabel は残す） */
export function toCasesJsonl(meta: RunMeta, records: CaseRecord[]): string {
  const lines = records.map((record) => JSON.stringify({ type: CASE_LINE, ...record, case: { ...record.case, document: null } }));
  return [JSON.stringify({ type: RUN_LINE, ...meta }), ...lines].join("\n") + "\n";
}

/** 記録の中から、同じ id・同じ回の記録を探す（無ければ 1 回目） */
export function findRecord(records: CaseRecord[], id: string, round: number): CaseRecord | undefined {
  return records.find((record) => record.case.id === id && record.result.round === round) ?? records.find((record) => record.case.id === id && record.result.round === 0);
}

/** 前の実行の答えをそのまま返す（API を呼ばない） */
export function createReplayAdapter(jsonl: CasesJsonl): Adapter {
  const kit = jsonl.meta?.kit;
  return {
    info: { name: kit?.name ?? "replay", label: kit?.label ?? "記録の再生", mode: "replay", version: kit?.version ?? null, model: kit?.model ?? null },
    notes: [...(jsonl.meta?.notes ?? [])],
    async ask(c: EvalCase, round: number): Promise<AdapterAnswer> {
      const record = findRecord(jsonl.records, c.id, round);
      if (record === undefined) return errorAnswer(`記録に無い問いです（${c.id}）。`);
      return record.answer;
    },
  };
}

/** --cases を渡さない replay では、記録の問い（1 回目）をそのまま使う */
export function casesOfRecords(records: CaseRecord[]): EvalCase[] {
  return records.filter((record) => record.result.round === 0).map((record) => record.case);
}
