import { HarnessError } from "../errors.ts";
import type { Adapter, AdapterAnswer, EvalCase, SourceRef } from "../types.ts";
import { NO_KEY_MESSAGE, RELAXED_LIMITS, WHOLE_MODE_NOTE, errorAnswer, noNetworkFetch, sourcesOfEntries, usageOfLog } from "./common.ts";
import { loadKit } from "./kit-loader.ts";
import { callFailure, modelMismatch, recordStream, usageOfCalls, type CallRecord, type StreamClientLike } from "./recording-client.ts";
import { readSse, summarizeChat, type ChatEventLike } from "./sse.ts";

/** 手元で呼ぶときの道。Origin は付けない（キットは Origin の無い要求を通す） */
export const CHAT_URL = "http://127.0.0.1/api/concierge/chat";

/** キットの値の型（キットの型は取り込まず、使う形だけを下の interface に書く） */
type Any = any;
interface Turn {
  role: "user" | "assistant";
  content: string;
}
export interface AiConciergeModule {
  createConcierge(config: Any, deps: Any): { fetch(request: Request): Promise<Response> };
  loadConfigFile(path: string): Promise<unknown>;
  resolveConfig(input: { file?: unknown; env?: Record<string, string | undefined> }): Any;
  loadIndex(path: string): Promise<Any>;
  retrieve(input: { index: Any; config: Any; question: string; history: Turn[] }): { entries: Array<{ doc: { title: string; url: string | null } }> };
  retrievalMode(index: Any, wholeCorpusMaxTokens: number): "whole" | "bm25";
  createAnthropicClient(apiKey: string): StreamClientLike;
  createLogRing(): { list(): Array<{ model: string; inputTokens: number; outputTokens: number; cacheReadTokens: number }> };
}

export interface AiConciergeOptions {
  kitDir: string;
  configPath: string;
  indexPath: string;
  apiKey: string | null;
  /** 検査用: キットの createAnthropicClient の代わりに使う client */
  baseClient?: StreamClientLike;
  now?: () => number;
}

interface ChatOnce {
  text: string;
  sources: SourceRef[];
  refused: boolean;
  error: string | null;
  retryable: boolean;
}

/** /chat に 1 回聞いて SSE を最後まで読む。fetchImpl は手元（concierge.fetch）か置いた先（fetch） */
export async function chatOnce(fetchImpl: (request: Request) => Promise<Response>, url: string, question: string, history: Turn[], signal: AbortSignal): Promise<ChatOnce> {
  let response: Response;
  try {
    response = await fetchImpl(new Request(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ question, history }), signal }));
  } catch (error) {
    if (signal.aborted) return { text: "", sources: [], refused: false, error: "打ち切りました。", retryable: false };
    return { text: "", sources: [], refused: false, error: `窓口につながりませんでした（${error instanceof Error ? error.message : String(error)}）。`, retryable: true };
  }
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    let message = "";
    try {
      message = (JSON.parse(detail) as { message?: string }).message ?? "";
    } catch {
      message = "";
    }
    return {
      text: "",
      sources: [],
      refused: false,
      error: `窓口が ${response.status} を返しました${message === "" ? "" : `（${message}）`}。`,
      retryable: response.status === 429 || response.status >= 500,
    };
  }
  // 読んでいる途中の切れ・打ち切りも、ask を reject させず実行エラーとして返す
  const aborted: ChatOnce = { text: "", sources: [], refused: false, error: "打ち切りました。", retryable: false };
  let events: ChatEventLike[];
  try {
    events = await readSse(response.body, signal);
  } catch {
    if (signal.aborted) return aborted;
    return { text: "", sources: [], refused: false, error: "窓口との接続が途中で切れました。もう一度お試しください。", retryable: true };
  }
  // 打ち切りで読むのをやめたときは、途中までの答えを採点に回さない
  if (signal.aborted) return aborted;
  const summary = summarizeChat(events);
  return { ...summary, retryable: false };
}

export async function createAiConciergeAdapter(options: AiConciergeOptions): Promise<Adapter> {
  const now = options.now ?? (() => Date.now());
  const kit = await loadKit("ai-concierge", options.kitDir);
  const mod = kit.module as unknown as AiConciergeModule;
  const file = await mod.loadConfigFile(options.configPath);
  if (file === undefined) throw new HarnessError(`設定ファイル ${options.configPath} が見つかりません。--config で concierge.config.json の場所を指定してください。`);
  let config: Any;
  try {
    // キットに渡す環境変数は ANTHROPIC_API_KEY だけ（記録の Webhook などは渡さない）
    config = mod.resolveConfig({ file, env: options.apiKey === null ? {} : { ANTHROPIC_API_KEY: options.apiKey } });
  } catch (error) {
    throw new HarnessError(`キットの設定を読めませんでした（${error instanceof Error ? error.message : String(error)}）。`);
  }
  config.limits = { ...config.limits, ...RELAXED_LIMITS };
  let index: Any;
  try {
    index = await mod.loadIndex(options.indexPath);
  } catch (error) {
    throw new HarnessError(`索引を読めませんでした（${error instanceof Error ? error.message : String(error)}）。--index で索引の場所を指定してください。`);
  }
  const whole = mod.retrievalMode(index, config.retrieval.wholeCorpusMaxTokens) === "whole";
  const base = options.baseClient ?? (options.apiKey === null ? null : mod.createAnthropicClient(options.apiKey));
  return {
    info: { name: "ai-concierge", label: `${config.site.name}の案内窓口`, mode: "in-process", version: kit.version, model: config.answer.model },
    notes: [...kit.warnings, ...(whole ? [WHOLE_MODE_NOTE] : [])],
    async ask(c: EvalCase, _round: number, signal: AbortSignal): Promise<AdapterAnswer> {
      if (base === null) return errorAnswer(NO_KEY_MESSAGE);
      // 問いごとに新しく組む（記録つきの client の記録と、回数の数えが問いどうしで混ざらない）
      const calls: CallRecord[] = [];
      const log = mod.createLogRing();
      // 外へ出ない fetch も渡す（記録の Webhook は渡していないが、念のため）
      const concierge = mod.createConcierge(config, { index, client: recordStream(base, calls), log, fetch: noNetworkFetch });
      const ask = (request: Request) => concierge.fetch(request);
      const failed = (error: string, retryable: boolean, latencyMs: number): AdapterAnswer => {
        const failure = callFailure(calls);
        return errorAnswer(failure?.error ?? error, { retryable: failure?.retryable ?? retryable, latencyMs, usage: usageOfCalls(calls) });
      };
      const history: Turn[] = [];
      if (c.previous !== null) {
        const previous = await chatOnce(ask, CHAT_URL, c.previous, [], signal);
        if (previous.error !== null) return failed(previous.error, previous.retryable, 0);
        history.push({ role: "user", content: c.previous }, { role: "assistant", content: previous.text });
      }
      const started = now();
      const main = await chatOnce(ask, CHAT_URL, c.question, history, signal);
      const latencyMs = now() - started;
      const usage = usageOfCalls(calls);
      const measured = usage.length > 0 ? usage : usageOfLog(log.list());
      if (callFailure(calls) !== null || main.error !== null) return failed(main.error ?? "", main.retryable, latencyMs);
      const mismatch = modelMismatch(calls);
      if (mismatch !== null) return errorAnswer(mismatch, { latencyMs, usage: measured });
      return {
        status: "ok",
        answer: main.text,
        sources: main.sources,
        refused: main.refused,
        handoff: null,
        retrieved: whole ? null : sourcesOfEntries(mod.retrieve({ index, config, question: c.question, history }).entries),
        latencyMs,
        usage: measured,
        model: calls.at(-1)?.model ?? config.answer.model,
      };
    },
  };
}

/** 置いた先の窓口（--url https://…/api/concierge）に POST {url}/chat で聞く。検索の当たりと費用は出ない */
export function createAiConciergeHttpAdapter(options: { url: string; fetchImpl?: typeof fetch; now?: () => number }): Adapter {
  const now = options.now ?? (() => Date.now());
  const doFetch = options.fetchImpl ?? fetch;
  const url = `${options.url.replace(/\/+$/, "")}/chat`;
  return {
    info: { name: "ai-concierge", label: `案内窓口（${new URL(options.url).host}）`, mode: "http", version: null, model: null },
    notes: [],
    async ask(c: EvalCase, _round: number, signal: AbortSignal): Promise<AdapterAnswer> {
      const ask = (request: Request) => doFetch(request);
      const history: Turn[] = [];
      if (c.previous !== null) {
        const previous = await chatOnce(ask, url, c.previous, [], signal);
        if (previous.error !== null) return errorAnswer(previous.error, { retryable: previous.retryable });
        history.push({ role: "user", content: c.previous }, { role: "assistant", content: previous.text });
      }
      const started = now();
      const main = await chatOnce(ask, url, c.question, history, signal);
      const latencyMs = now() - started;
      if (main.error !== null) return errorAnswer(main.error, { retryable: main.retryable, latencyMs });
      return { status: "ok", answer: main.text, sources: main.sources, refused: main.refused, handoff: null, retrieved: null, latencyMs, usage: [], model: null };
    },
  };
}
