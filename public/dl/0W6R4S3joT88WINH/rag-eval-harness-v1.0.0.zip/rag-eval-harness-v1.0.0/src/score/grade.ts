import { includesNormalized, normalizeText } from "../normalize.ts";
import type { AdapterAnswer, CaseResult, EvalCase, Judgment, JudgeMode, JudgeOutcome, PointStatus, Verdict } from "../types.ts";

/**
 * 判定を決める。決まりで決まるもの（実行エラー・断るべき問い・引き継ぐ問い・書類読み取りの型つきの値）は先に決め、
 * 残りだけを採点者に回す。採点者には総合点を出させず、要点ごとの印から判定をこちらで決める（設計書 §5）
 */

export interface RuleDecision {
  verdict: Verdict;
  reason: string;
}

const TYPE_LABELS: Record<string, string> = { money: "金額", number: "数", date: "日付", boolean: "真偽", enum: "選択肢" };

function shown(value: string | number | boolean | null): string {
  return value === null ? "空" : String(value);
}

/** 採点者を呼ばずに決まるなら判定を、決まらなければ null を返す */
export function ruleDecision(c: EvalCase, a: AdapterAnswer): RuleDecision | null {
  if (a.status === "error") return { verdict: "error", reason: a.error ?? "実行エラーです。" };
  if (c.special === "refuse") {
    if (a.handoff === true) return { verdict: "wrong", reason: "資料に無い問いで、担当者に引き継いでいます。" };
    if (a.refused === true) return { verdict: "correct", reason: "資料に無い問いを断りました。" };
    // 窓口の印が信じられるのは「断った」のときだけ。false は窓口が決まった断り文でないと立てないので、丁寧な断りを誤りにしないよう採点者に回す
    return null;
  }
  if (c.special === "handoff") {
    return a.handoff === true ? { verdict: "correct", reason: "担当者に引き継ぎました。" } : { verdict: "wrong", reason: "担当者に引き継いでいません。" };
  }
  if (c.special === "empty") {
    const value = a.field === undefined ? (a.answer === "" ? null : a.answer) : a.field.value;
    return value === null
      ? { verdict: "correct", reason: "値を空にして、要確認に回しました。" }
      : { verdict: "wrong", reason: `空のはずの項目に「${shown(value)}」が入っています。` };
  }
  if (a.handoff === true) return { verdict: "noAnswer", reason: "答えるべき問いで、担当者に引き継ぎました。" };
  if (a.refused === true) return { verdict: "noAnswer", reason: "答えるべき問いで断りました。" };
  if (a.field !== undefined) {
    const field = a.field;
    if (field.type !== "string") {
      if (field.expected === null) return { verdict: "wrong", reason: `要点「${c.points[0] ?? ""}」を${TYPE_LABELS[field.type] ?? field.type}として読めません。質問表の要点を直してください。` };
      return field.value === field.expected
        ? { verdict: "correct", reason: `値が一致しました（${shown(field.value)}）。` }
        : { verdict: "wrong", reason: `値が違います（読み取り: ${shown(field.value)}、期待: ${shown(field.expected)}）。` };
    }
    if (field.value === null) return { verdict: "wrong", reason: `値が空です（期待: ${shown(field.expected)}）。` };
    if (normalizeText(String(field.value)) === normalizeText(String(field.expected))) return { verdict: "correct", reason: `値が一致しました（${shown(field.value)}）。` };
    return null;
  }
  return null;
}

/** 採点者の印から判定を決める。全部 covered → 正解／1 つ以上 covered で contradicted が無い → 部分／それ以外 → 誤り／断った → 無回答 */
export function verdictOf(judgment: Judgment): Verdict {
  if (judgment.declined) return "noAnswer";
  const covered = judgment.points.filter((status) => status === "covered").length;
  if (covered > 0 && covered === judgment.points.length) return "correct";
  if (covered > 0 && !judgment.points.includes("contradicted")) return "partial";
  return "wrong";
}

/** 出典の当たり。書類読み取りは根拠の字（evidence）に、出典の列（空なら要点）の字が入っているか */
export function citationHitOf(c: EvalCase, a: AdapterAnswer, verdict: Verdict): boolean | null {
  if (c.special !== null || verdict === "error" || verdict === "judgeError" || verdict === "noAnswer") return null;
  if (a.field !== undefined) {
    if (a.field.evidence === null) return null;
    const wanted = c.sources.length > 0 ? c.sources : c.points;
    return wanted.some((item) => includesNormalized(a.field?.evidence ?? "", item));
  }
  if (c.sources.length === 0) return null;
  return c.sources.some((wanted) => a.sources.some((source) => includesNormalized(source.title, wanted) || includesNormalized(source.url ?? "", wanted)));
}

/** 検索の当たり。拾った片（retrieved）がある窓口だけ */
export function retrievalHitOf(c: EvalCase, a: AdapterAnswer): boolean | null {
  if (c.sources.length === 0 || a.retrieved === null || a.status === "error") return null;
  return c.sources.some((wanted) => (a.retrieved ?? []).some((source) => includesNormalized(source.title, wanted) || includesNormalized(source.url ?? "", wanted)));
}

/** 決まりで決めた問いの禁止事項は、語の一致で見る（断った・引き継いだ・失敗した答えは見ない） */
function forbiddenByWords(c: EvalCase, a: AdapterAnswer): CaseResult["forbidden"] {
  const skip = a.status === "error" || a.refused === true || a.handoff === true;
  return c.forbidden.map((text) => {
    const violated = !skip && includesNormalized(a.answer, text);
    return { text, violated, review: false, quote: violated ? text : "" };
  });
}

export interface GradeContext {
  round: number;
  attempts: number;
  judgeMode: JudgeMode;
}

/**
 * 1 問の結果を組む。ruleDecision で決まらない問いには judge（採点者の結果）が要る。
 * 採点者が失敗したら「採点エラー」（正答率の分母から外す）
 */
export function gradeCase(c: EvalCase, a: AdapterAnswer, judge: JudgeOutcome | null, context: GradeContext): CaseResult {
  const rule = ruleDecision(c, a);
  const base = {
    id: c.id,
    round: context.round,
    tags: c.tags,
    refused: a.refused,
    handoff: a.handoff,
    latencyMs: a.latencyMs,
    attempts: context.attempts,
    retrievalHit: retrievalHitOf(c, a),
  };
  const pointsWith = (status: PointStatus) => c.points.map((text) => ({ text, status }));
  if (rule !== null) {
    return {
      ...base,
      verdict: rule.verdict,
      points: pointsWith(rule.verdict === "correct" ? "covered" : "missing"),
      forbidden: forbiddenByWords(c, a),
      citationHit: citationHitOf(c, a, rule.verdict),
      reason: rule.reason,
      judgedBy: "rule",
      incomplete: false,
    };
  }
  if (judge === null || !judge.ok) {
    return {
      ...base,
      verdict: "judgeError",
      points: pointsWith("missing"),
      forbidden: c.forbidden.map((text) => ({ text, violated: false, review: false, quote: "" })),
      citationHit: null,
      reason: judge === null ? "採点されていません。" : judge.error,
      judgedBy: context.judgeMode,
      incomplete: false,
    };
  }
  const judgment = judge.judgment;
  let verdict: Verdict;
  if (c.special === "refuse") verdict = judgment.declined ? "correct" : "wrong";
  else if (a.field !== undefined) verdict = judgment.points[0] === "covered" ? "correct" : "wrong";
  else verdict = verdictOf(judgment);
  return {
    ...base,
    refused: a.refused === true || judgment.declined,
    verdict,
    points: c.points.map((text, i) => ({ text, status: judgment.points[i] ?? "missing" })),
    forbidden: c.forbidden.map((text, i) => ({ text, violated: judgment.forbidden[i]?.violated ?? false, review: judgment.forbidden[i]?.review ?? false, quote: judgment.forbidden[i]?.quote ?? "" })),
    citationHit: citationHitOf(c, a, verdict),
    reason: judgment.reason,
    judgedBy: context.judgeMode,
    incomplete: judgment.incomplete,
  };
}
