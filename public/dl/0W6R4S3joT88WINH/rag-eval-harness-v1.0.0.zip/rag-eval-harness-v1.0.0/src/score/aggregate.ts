import { costYen } from "../pricing.ts";
import type { CaseRecord, CaseResult, KitName, Summary } from "../types.ts";

const GRADED = new Set(["correct", "partial", "wrong", "noAnswer"]);

/** run.ts が打ち切りの問いに添える印の usage の model（キットの model が分からないとき）。値段の表に無いモデルとしては出さない */
const TIMEOUT_USAGE_MODEL = "unknown";

function rate(numerator: number, denominator: number): number | null {
  return denominator === 0 ? null : numerator / denominator;
}

/** (正解 + 部分 × 0.5) ÷ 採点できた問い */
export function scoreOf(results: Pick<CaseResult, "verdict">[]): number | null {
  const graded = results.filter((result) => GRADED.has(result.verdict));
  const points = graded.reduce((sum, result) => sum + (result.verdict === "correct" ? 1 : result.verdict === "partial" ? 0.5 : 0), 0);
  return rate(points, graded.length);
}

/** 近い順位の百分位（nearest-rank）。値が無ければ null */
export function percentile(values: number[], p: number): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.max(0, Math.ceil((p / 100) * sorted.length) - 1)];
}

export interface AggregateOptions {
  yenPerUsd: number;
  kit: KitName;
}

export function aggregate(records: CaseRecord[], options: AggregateOptions): Summary {
  const results = records.map((record) => record.result);
  const count = (verdict: string) => results.filter((result) => result.verdict === verdict).length;
  const counts = { correct: count("correct"), partial: count("partial"), wrong: count("wrong"), noAnswer: count("noAnswer"), error: count("error"), judgeError: count("judgeError") };
  const graded = counts.correct + counts.partial + counts.wrong + counts.noAnswer;

  const rounds = Math.max(1, ...results.map((result) => result.round + 1));
  const perRound = Array.from({ length: rounds }, (_, round) => scoreOf(results.filter((result) => result.round === round))).filter((score): score is number => score !== null);
  const score = perRound.length === 0 ? null : perRound.reduce((sum, value) => sum + value, 0) / perRound.length;

  const withFlag = (pick: (result: CaseResult) => boolean | null) => {
    const known = results.map(pick).filter((value): value is boolean => value !== null);
    return rate(known.filter(Boolean).length, known.length);
  };

  const gradedRecords = records.filter((record) => GRADED.has(record.result.verdict));
  const shouldRefuse = gradedRecords.filter((record) => record.case.special === "refuse");
  const normal = gradedRecords.filter((record) => record.case.special === null);
  const shouldHandoff = gradedRecords.filter((record) => record.case.special === "handoff");

  const kitCost = costYen(records.flatMap((record) => record.answer.usage), options.yenPerUsd);
  const judgeCost = costYen(records.flatMap((record) => (record.judge === null ? [] : record.judge.usage)), options.yenPerUsd);

  const tags: string[] = [];
  for (const result of results) for (const tag of result.tags) if (!tags.includes(tag)) tags.push(tag);

  return {
    score,
    scoreRange: perRound.length > 1 ? { min: Math.min(...perRound), max: Math.max(...perRound) } : null,
    correctRate: rate(counts.correct, graded),
    counts,
    graded,
    total: results.length,
    citationHit: withFlag((result) => result.citationHit),
    retrievalHit: withFlag((result) => result.retrievalHit),
    refusal: {
      shouldRefuse: shouldRefuse.length,
      refusedWhenShould: rate(shouldRefuse.filter((record) => record.result.verdict === "correct").length, shouldRefuse.length),
      overRefused: rate(normal.filter((record) => record.result.verdict === "noAnswer").length, normal.length),
    },
    handoff:
      options.kit === "line-concierge" || shouldHandoff.length > 0
        ? {
            shouldHandoff: shouldHandoff.length,
            handedOffWhenShould: rate(shouldHandoff.filter((record) => record.result.verdict === "correct").length, shouldHandoff.length),
            unexpected: records.filter((record) => record.case.special !== "handoff" && record.result.handoff === true).length,
          }
        : null,
    forbidden: {
      violated: results.filter((result) => result.forbidden.some((item) => item.violated)).length,
      review: results.filter((result) => result.forbidden.some((item) => item.review)).length,
    },
    latencyMs: (() => {
      const values = records.filter((record) => record.answer.status === "ok").map((record) => record.answer.latencyMs);
      return { p50: percentile(values, 50), p95: percentile(values, 95) };
    })(),
    costJpy: { kit: kitCost.yen, judge: judgeCost.yen, perQuestion: records.length === 0 ? null : kitCost.yen / records.length },
    costLowerBound: kitCost.lowerBound || judgeCost.lowerBound,
    unknownModels: [...new Set([...kitCost.unknownModels, ...judgeCost.unknownModels])].filter((model) => model !== TIMEOUT_USAGE_MODEL),
    tags: tags.map((tag) => {
      const tagged = results.filter((result) => result.tags.includes(tag));
      return { tag, score: scoreOf(tagged), count: tagged.filter((result) => GRADED.has(result.verdict)).length };
    }),
    errors: results.filter((result) => result.verdict === "error").map((result) => ({ id: result.id, round: result.round, reason: result.reason })),
    judgeErrors: results.filter((result) => result.verdict === "judgeError").map((result) => ({ id: result.id, round: result.round, reason: result.reason })),
    rounds,
  };
}
