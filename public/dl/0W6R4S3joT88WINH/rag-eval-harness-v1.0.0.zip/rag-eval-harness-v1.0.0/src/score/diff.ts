import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join, resolve } from "node:path";
import { HarnessError } from "../errors.ts";
import type { BaselineDiff, ResultEntry, ResultJson } from "../types.ts";
import { scoreOf } from "./aggregate.ts";

const GOOD = new Set(["correct", "partial"]);
const BAD = new Set(["wrong", "noAnswer"]);

/** readResultJson が中身を認める最小の形（diffResults が読む項目だけを確かめる） */
function looksLikeResultJson(value: unknown): value is ResultJson {
  if (typeof value !== "object" || value === null) return false;
  const obj = value as Record<string, unknown>;
  if (obj.schema !== "rag-eval/1") return false;
  if (!Array.isArray(obj.results)) return false;
  const cases = obj.cases as Record<string, unknown> | null | undefined;
  if (typeof cases !== "object" || cases === null || typeof cases.sha256 !== "string") return false;
  const judge = obj.judge as Record<string, unknown> | null | undefined;
  if (typeof judge !== "object" || judge === null || !("rubricVersion" in judge) || !("model" in judge) || !("mode" in judge)) return false;
  const summary = obj.summary as Record<string, unknown> | null | undefined;
  if (typeof summary !== "object" || summary === null || !("score" in summary) || !("scoreRange" in summary)) return false;
  return true;
}

export function readResultJson(path: string): ResultJson {
  let parsed: unknown;
  try {
    parsed = JSON.parse(readFileSync(path, "utf8"));
  } catch {
    throw new HarnessError(`前回の result.json（${path}）を読めません。--baseline none で比べずに回せます。`);
  }
  if (!looksLikeResultJson(parsed)) {
    throw new HarnessError(`${path} は rag-eval-harness の result.json（"schema": "rag-eval/1"）として読めません。--baseline none で比べずに回せます。`);
  }
  return parsed;
}

/** 実行フォルダの名前のパターン（YYYYMMDD-HHmmss-kit）。demo やメモ用フォルダなど、これに合わない名前は見ない */
const RUN_FOLDER_NAME = /^\d{8}-\d{6}-/;

/**
 * --baseline auto: 出力の親フォルダ（runs/）の中で、同じ kit の一番新しい result.json のあるフォルダ。
 * フォルダ名（YYYYMMDD-HHmmss-kit）の新しい順に見る。今回のフォルダと demo は除く
 */
export function findBaseline(outRoot: string, kitName: string, exclude: string | null): string | null {
  if (!existsSync(outRoot)) return null;
  const names = readdirSync(outRoot)
    .filter((name) => RUN_FOLDER_NAME.test(name))
    .filter((name) => {
      try {
        return statSync(join(outRoot, name)).isDirectory();
      } catch {
        return false; // 壊れた symlink など、読めない項目は無視する
      }
    })
    .sort()
    .reverse();
  for (const name of names) {
    const dir = join(outRoot, name);
    if (exclude !== null && resolve(dir) === resolve(exclude)) continue;
    const file = join(dir, "result.json");
    if (!existsSync(file)) continue;
    try {
      if ((JSON.parse(readFileSync(file, "utf8")) as ResultJson).kit?.name === kitName) return dir;
    } catch {
      continue;
    }
  }
  return null;
}

const firstRound = (entries: ResultEntry[]) => new Map(entries.filter((entry) => entry.round === 0).map((entry) => [entry.id, entry]));
const violated = (entry: ResultEntry) => entry.forbidden.some((item) => item.violated);

/**
 * 問いは id で突き合わせる（--repeat のときは 1 回目どうし）。
 * 悪化: 正解・部分 → 誤り・無回答、新しい禁止の違反（断るべき問いに答えるようになったのも、正解 → 誤り に入る）。良化はその逆
 */
export function diffResults(current: ResultJson, previous: ResultJson, dir: string): BaselineDiff {
  const now = firstRound(current.results);
  const before = firstRound(previous.results);
  const common = [...now.keys()].filter((id) => before.has(id));
  const regressed: string[] = [];
  const improved: string[] = [];
  for (const id of common) {
    const a = before.get(id) as ResultEntry;
    const b = now.get(id) as ResultEntry;
    if ((GOOD.has(a.verdict) && BAD.has(b.verdict)) || (violated(b) && !violated(a))) regressed.push(id);
    else if ((BAD.has(a.verdict) && GOOD.has(b.verdict)) || (violated(a) && !violated(b))) improved.push(id);
  }
  const notes: string[] = [];
  // 質問表のハッシュは --tags・--limit で絞る前の CSV 全体のものなので、同じでも問いの組が違いうる。id の組で見る
  const sameQuestions = now.size === before.size && common.length === now.size;
  if (!sameQuestions) notes.push(`質問表が前回と違います（共通の ${common.length} 問で比べました）。`);
  // id の組が同じでも、要点の書き換えなどで CSV が変わっていれば知らせる（差は同じ id どうしで出す）
  else if (current.cases.sha256 !== previous.cases.sha256) notes.push("質問表の中身が前回と違います（同じ id の問いどうしで比べました）。");
  // 見出しの差は --repeat のときも 1 回目どうし（改善・悪化の一覧と同じ）
  const score = scoreOf(common.map((id) => before.get(id) as ResultEntry));
  const currentScore = scoreOf(common.map((id) => now.get(id) as ResultEntry));
  if (current.judge.rubricVersion !== previous.judge.rubricVersion || current.judge.model !== previous.judge.model || current.judge.mode !== previous.judge.mode) {
    notes.push("採点のしかたが違うため、差は参考です。");
  }
  const delta = score === null || currentScore === null ? null : currentScore - score;
  const range = current.summary.scoreRange;
  if (delta !== null && range !== null && Math.abs(delta) < range.max - range.min) notes.push("差は幅の内側です。");
  return { dir, score, delta, improved, regressed, common: common.length, notes };
}

/** --min-score・--max-drop は 0〜100 の点数（ポイント）で受け取る決まりなので、率（0〜1）にはいつも 100 で割る */
export function toRate(value: number): number {
  return value / 100;
}

const percent = (value: number) => `${Math.round(value * 100)}%`;
const points = (value: number) => `${Math.round(value * 100)} ポイント`;
/** 率（0〜1）を 0.1 ポイント刻みに丸める。小数の誤差（0.75 − 0.8 など）で境界がぶれないように */
const roundToPoints = (value: number): number => Math.round(value * 1000) / 10;

/** CI 用。正答率が --min-score 未満、または前回から --max-drop より下がったら終了コード 1 */
export function checkThresholds(score: number | null, delta: number | null, minScore: number | null, maxDrop: number | null): { exitCode: 0 | 1; messages: string[] } {
  const messages: string[] = [];
  if (minScore !== null && (score === null || roundToPoints(score) < minScore)) {
    messages.push(`正答率 ${score === null ? "—" : percent(score)} が --min-score ${percent(toRate(minScore))} に届きません。`);
  }
  if (maxDrop !== null && delta !== null && roundToPoints(-delta) > maxDrop) {
    messages.push(`前回から ${points(-delta)}下がりました（--max-drop ${points(toRate(maxDrop))}）。`);
  }
  return { exitCode: messages.length > 0 ? 1 : 0, messages };
}
