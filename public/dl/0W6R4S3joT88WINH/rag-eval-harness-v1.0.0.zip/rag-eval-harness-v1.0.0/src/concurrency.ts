/** やり直しの待ち（1 秒・3 秒・9 秒）。429・529・5xx・接続の切れだけをやり直す */
export const RETRY_DELAYS_MS = [1000, 3000, 9000];

/** 待ちにゆらぎを付ける（0.8〜1.2 倍）。同時の問いが同じ時刻にやり直して、また混まないように */
export function jittered(delayMs: number, random: () => number = Math.random): number {
  return Math.round(delayMs * (0.8 + 0.4 * random()));
}

export const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

/** 同時に concurrency 個まで動かす。結果は items と同じ並び */
export async function runPool<T, R>(items: T[], concurrency: number, work: (item: T, index: number) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let next = 0;
  const lane = async (): Promise<void> => {
    for (;;) {
      const index = next;
      next += 1;
      if (index >= items.length) return;
      results[index] = await work(items[index], index);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(concurrency, items.length)) }, lane));
  return results;
}

/**
 * 最初の 1 件を先に送り、その応答を受けてから残りを同時 concurrency 個で送る。
 * キャッシュは最初の応答が始まるまで読めず、同時に送ると全部が書き込みになるため（採点の system を安く保つ）
 */
export async function runFirstThenPool<T, R>(items: T[], concurrency: number, work: (item: T, index: number) => Promise<R>): Promise<R[]> {
  if (items.length === 0) return [];
  const first = await work(items[0], 0);
  const rest = await runPool(items.slice(1), concurrency, (item, index) => work(item, index + 1));
  return [first, ...rest];
}
