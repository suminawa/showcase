/**
 * RFC 4180 の CSV の読み手と書き手（依存なし）。
 * 読む: UTF-8（BOM あり・なし）、引用の中の , と改行と ""、CRLF と LF、末尾の空行は捨てる。
 */

export const NOT_UTF8_MESSAGE = "質問表を UTF-8 で保存してください（Excel は「CSV UTF-8（コンマ区切り）」）。";

/** 質問表を読めないときの誤り。cli は終了コード 2 で止める */
export class CsvError extends Error {}

/** バイト列を UTF-8 として読む。読めなければ CsvError（敬体の文） */
export function decodeUtf8(bytes: Uint8Array): string {
  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new CsvError(NOT_UTF8_MESSAGE);
  }
  return text.startsWith("﻿") ? text.slice(1) : text;
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  let line = 1;
  let quoteStartLine = 1;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quoted) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        if (char === "\n") line += 1;
        cell += char;
      }
      continue;
    }
    if (char === '"' && cell === "") {
      quoted = true;
      quoteStartLine = line;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n" || char === "\r") {
      if (char === "\r" && text[i + 1] === "\n") i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      line += 1;
    } else {
      cell += char;
    }
  }
  if (quoted) throw new CsvError(`質問表の ${quoteStartLine} 行目で、引用符（"）が閉じていません。`);
  if (cell !== "" || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  while (rows.length > 0 && rows[rows.length - 1].every((value) => value.trim() === "")) rows.pop();
  return rows;
}

/** 書き出す 1 セル。formulaGuard なら = + - @ で始まる値に ' を付ける（表計算ソフトで式として動かない） */
export function csvCell(value: string, formulaGuard: boolean = false): string {
  const safe = formulaGuard && /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
}

/** 行の並びを CSV にする（行の終わりは CRLF。スプレッドシートに読み込みやすい形） */
export function toCsv(rows: string[][], formulaGuard: boolean = false): string {
  return rows.map((row) => row.map((value) => csvCell(value, formulaGuard)).join(",")).join("\r\n") + "\r\n";
}
