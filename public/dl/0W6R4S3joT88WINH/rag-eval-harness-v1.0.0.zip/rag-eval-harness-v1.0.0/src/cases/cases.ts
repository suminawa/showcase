import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { dirname, isAbsolute, resolve } from "node:path";
import type { EvalCase, KitName, Special } from "../types.ts";
import { decodeUtf8, parseCsv } from "./csv.ts";

/** 質問表の見出し（1 行目はこのとおり。順番は自由） */
export const HEADERS = [
  "id",
  "質問",
  "期待する答えの要点",
  "出典に含まれるべき文書",
  "答えてはいけないこと",
  "タグ",
  "前の質問",
  "書類",
  "帳票の型",
  "メモ",
] as const;

export const SPECIAL_VALUES: Record<string, Special> = {
  "（答えない）": "refuse",
  "（引き継ぐ）": "handoff",
  "（空）": "empty",
};

export const MAX_POINTS = 5;
const ID_PATTERN = /^[A-Za-z0-9_-]{1,40}$/;

export interface ParseCasesOptions {
  /** 書類の場所の基準（既定は質問表のあるフォルダ） */
  baseDir: string;
  /** 分かっていれば、キットに合わない書き方を検査する */
  kit?: KitName | null;
  exists?: (path: string) => boolean;
}

export interface ParsedCases {
  cases: EvalCase[];
  /** 問題の全部（敬体、行番号つき）。1 つでもあれば API を呼ばずに止める */
  problems: string[];
  /** 知らない列の見出し */
  unknownColumns: string[];
}

/** FNV-1a（32 ビット）の 8 桁。id の自動の名前に使う */
export function fnv1a(text: string): string {
  let hash = 0x811c9dc5;
  for (const byte of new TextEncoder().encode(text)) {
    hash ^= byte;
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

export function autoId(question: string, document: string | null, form: string | null): string {
  return `q-${fnv1a([question, document ?? "", form ?? ""].join("\u0000"))}`;
}

/** 要点・出典・禁止の区切り: ｜ と | とセルの中の改行 */
export function splitList(cell: string): string[] {
  return cell
    .split(/[｜|\r\n]/)
    .map((item) => item.trim())
    .filter((item) => item !== "");
}

/** タグの区切り: , と 、 */
export function splitTags(cell: string): string[] {
  return cell
    .split(/[,、，]/)
    .map((item) => item.trim())
    .filter((item) => item !== "");
}

/** 「(答えない)」も受ける。括弧の無い「答えない」は綴り違いとして知らせる */
function specialOf(value: string): { special: Special | null; misspelled: string | null } {
  const normalized = value.normalize("NFKC").trim();
  for (const [word, special] of Object.entries(SPECIAL_VALUES)) {
    const bare = word.slice(1, -1);
    if (normalized === word.normalize("NFKC")) return { special, misspelled: null };
    if (normalized === bare) return { special: null, misspelled: word };
  }
  return { special: null, misspelled: null };
}

export function parseCases(rows: string[][], options: ParseCasesOptions): ParsedCases {
  const exists = options.exists ?? existsSync;
  const kit = options.kit ?? null;
  const problems: string[] = [];
  if (rows.length === 0) return { cases: [], problems: ["質問表が空です。1 行目に見出し（id・質問・期待する答えの要点 など）を書いてください。"], unknownColumns: [] };

  const header = rows[0].map((name) => name.trim());
  const column = (name: string): number => header.indexOf(name);
  for (const required of ["質問", "期待する答えの要点"]) {
    if (column(required) < 0) problems.push(`見出しに「${required}」の列がありません。1 行目に「${required}」と書いてください（見出しは README の「質問表の書き方」の表のとおりです）。`);
  }
  if (kit === "doc-reader") {
    for (const required of ["書類", "帳票の型"]) {
      if (column(required) < 0) problems.push(`書類読み取りでは、見出しに「${required}」の列が要ります。`);
    }
  }
  const known = new Set<string>(HEADERS);
  const unknownColumns = header.filter((name) => name !== "" && !known.has(name));
  if (problems.length > 0) return { cases: [], problems, unknownColumns };

  const cell = (row: string[], name: string): string => {
    const index = column(name);
    return index < 0 ? "" : (row[index] ?? "").trim();
  };

  const cases: EvalCase[] = [];
  const seen = new Map<string, number>();
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r];
    const line = r + 1;
    if (row.every((value) => value.trim() === "")) continue;
    const question = cell(row, "質問");
    const pointsCell = cell(row, "期待する答えの要点");
    if (question === "") problems.push(`${line} 行目: 「質問」が空です。`);
    if (pointsCell === "") problems.push(`${line} 行目: 「期待する答えの要点」が空です。資料に無い質問なら （答えない） と書いてください。`);

    let special: Special | null = null;
    const points: string[] = [];
    const items = splitList(pointsCell);
    if (pointsCell !== "" && items.length === 0) problems.push(`${line} 行目: 「期待する答えの要点」に区切り（| や ｜）しかありません。要点を書くか、資料に無い質問なら （答えない） と書いてください。`);
    for (const item of items) {
      const found = specialOf(item);
      if (found.misspelled !== null) problems.push(`${line} 行目: 「${item}」は ${found.misspelled} と書いてください。`);
      else if (found.special !== null) special = found.special;
      else points.push(item);
    }
    if (special !== null && (points.length > 0 || items.length > 1)) {
      problems.push(`${line} 行目: 特別な値（答えない・引き継ぐ・空）は、ほかの要点と並べずに 1 つだけ書いてください。`);
    }
    if (points.length > MAX_POINTS) problems.push(`${line} 行目: 要点は ${MAX_POINTS} つまでにしてください（いまは ${points.length} つ）。`);
    if (special === "handoff" && kit !== null && kit !== "line-concierge" && kit !== "replay") {
      problems.push(`${line} 行目: （引き継ぐ）は LINE 窓口（--kit line-concierge）でだけ使えます。`);
    }
    if (special === "empty" && kit !== null && kit !== "doc-reader" && kit !== "replay") {
      problems.push(`${line} 行目: （空）は書類読み取り（--kit doc-reader）でだけ使えます。`);
    }

    const documentLabel = cell(row, "書類") || null;
    const form = cell(row, "帳票の型") || null;
    let document: string | null = null;
    if (documentLabel !== null) {
      document = isAbsolute(documentLabel) ? documentLabel : resolve(options.baseDir, documentLabel);
      if (!exists(document)) problems.push(`${line} 行目: 書類 ${documentLabel} が見つかりません（質問表のある場所からの相対で書いてください）。`);
    }
    if (kit === "doc-reader") {
      if (documentLabel === null) problems.push(`${line} 行目: 書類読み取りでは「書類」が要ります。`);
      if (form === null) problems.push(`${line} 行目: 書類読み取りでは「帳票の型」が要ります（invoice など、キットの forms/ の id）。`);
      if (special === null && points.length !== 1) problems.push(`${line} 行目: 書類読み取りでは、要点を 1 つ（期待する値）にしてください。`);
    }

    const idCell = cell(row, "id");
    const id = idCell === "" ? autoId(question, documentLabel, form) : idCell;
    if (idCell !== "" && !ID_PATTERN.test(idCell)) problems.push(`${line} 行目: id は英数・-・_ の 40 字までにしてください（いまの値: ${idCell}）。`);
    const before = seen.get(id);
    if (before !== undefined) {
      problems.push(
        idCell === ""
          ? `${line} 行目: ${before} 行目と同じ質問です（id が重なります）。id の列に別の名前を書いてください。`
          : `${line} 行目: id「${id}」が ${before} 行目と重なっています。`,
      );
    } else {
      seen.set(id, line);
    }

    const extras: Record<string, string> = {};
    for (const name of unknownColumns) {
      const value = cell(row, name);
      if (value !== "") extras[name] = value;
    }
    cases.push({
      id,
      line,
      question,
      points,
      special,
      sources: splitList(cell(row, "出典に含まれるべき文書")),
      forbidden: splitList(cell(row, "答えてはいけないこと")),
      tags: splitTags(cell(row, "タグ")),
      previous: cell(row, "前の質問") || null,
      document,
      documentLabel,
      form,
      extras,
    });
  }
  if (cases.length === 0 && problems.length === 0) problems.push("質問表に問いが 1 つもありません。2 行目から 1 行に 1 問ずつ書いてください。");
  return { cases, problems, unknownColumns };
}

export interface LoadedCases extends ParsedCases {
  file: string;
  sha256: string;
}

/** 質問表のファイルを読む。UTF-8 でなければ CsvError */
export function loadCasesFile(path: string, options: Partial<ParseCasesOptions> = {}): LoadedCases {
  const bytes = readFileSync(path);
  const parsed = parseCases(parseCsv(decodeUtf8(bytes)), { baseDir: options.baseDir ?? dirname(resolve(path)), kit: options.kit, exists: options.exists });
  return { ...parsed, file: path, sha256: createHash("sha256").update(bytes).digest("hex") };
}
