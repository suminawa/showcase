import { normalizeText } from "../normalize.ts";
import { HEADERS } from "./cases.ts";
import { CsvError, parseCsv, toCsv } from "./csv.ts";

/** 案内窓口の /admin/export の見出し（キットの toCsv と同じ並び） */
export const ADMIN_HEADERS = [
  "受付日時",
  "質問",
  "答えの先頭",
  "出典",
  "答えられたか",
  "所要ms",
  "モデル",
  "入力トークン",
  "出力トークン",
  "キャッシュ読み",
  "途中で切れた",
  "途中で切断",
] as const;

export const FROM_ADMIN_TAG = "未回答";

export interface FromAdminResult {
  csv: string;
  count: number;
}

/**
 * /admin/export の CSV から質問表を作る。未回答（答えられたか = いいえ）の行だけを取り、
 * 「質問」だけを埋めて「タグ」に「未回答」を入れる。語の揃え方で同じ質問は 1 行にまとめる。
 * 要点は空のまま（書き足してから使う）。
 */
export function casesFromAdmin(text: string): FromAdminResult {
  const rows = parseCsv(text.startsWith("﻿") ? text.slice(1) : text);
  const header = (rows[0] ?? []).map((name) => name.trim());
  const questionAt = header.indexOf("質問");
  if (questionAt < 0) throw new CsvError("案内窓口の /admin/export の CSV ではないようです（「質問」の列がありません）。");
  const answeredAt = header.indexOf("答えられたか");
  const seen = new Set<string>();
  const out: string[][] = [[...HEADERS]];
  for (const row of rows.slice(1)) {
    const question = (row[questionAt] ?? "").trim();
    if (question === "") continue;
    if (answeredAt >= 0 && (row[answeredAt] ?? "").trim() !== "いいえ") continue;
    const key = normalizeText(question);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(HEADERS.map((name) => (name === "質問" ? question : name === "タグ" ? FROM_ADMIN_TAG : "")));
  }
  return { csv: "﻿" + toCsv(out, true), count: out.length - 1 };
}
