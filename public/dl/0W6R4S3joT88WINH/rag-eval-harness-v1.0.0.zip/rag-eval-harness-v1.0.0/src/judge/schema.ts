import { includesNormalized } from "../normalize.ts";
import type { ForbiddenCheck, Judgment, PointStatus } from "../types.ts";

/** 採点者の答えの形（structured outputs の json_schema）。件数の制約はスキーマに書かず、parseJudge で確かめる */
export const JUDGE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["declined", "points", "forbidden", "reason"],
  properties: {
    declined: { type: "boolean" },
    points: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["index", "status"],
        properties: {
          index: { type: "integer" },
          status: { type: "string", enum: ["covered", "missing", "contradicted"] },
        },
      },
    },
    forbidden: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["index", "violated", "quote"],
        properties: {
          index: { type: "integer" },
          violated: { type: "boolean" },
          quote: { type: "string" },
        },
      },
    },
    reason: { type: "string" },
  },
} as const;

export const REASON_MAX = 100;
const STATUSES: PointStatus[] = ["covered", "missing", "contradicted"];

export type ParsedJudge = { ok: true; judgment: Judgment } | { ok: false; error: string };

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);

/**
 * 採点者の答えを確かめる。
 * - index は 1〜n にちょうど 1 回ずつ。欠けた要点は missing、余計なものと重なりは捨てて「採点が不完全」の印
 * - violated なのに quote が答えの中に（語の揃え方で）見つからなければ、違反にせず「要確認」
 * - JSON が壊れた・形が違う → ok: false（呼び出し側が 1 回だけやり直す）
 */
export function parseJudge(text: string, pointCount: number, forbiddenCount: number, answer: string): ParsedJudge {
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch {
    return { ok: false, error: "採点の答えが JSON として読めませんでした。" };
  }
  if (!isRecord(value) || typeof value.declined !== "boolean" || !Array.isArray(value.points) || !Array.isArray(value.forbidden) || typeof value.reason !== "string") {
    return { ok: false, error: "採点の答えの形が違います。" };
  }
  let incomplete = false;
  const points: (PointStatus | null)[] = Array.from({ length: pointCount }, () => null);
  for (const item of value.points) {
    if (!isRecord(item) || typeof item.index !== "number" || typeof item.status !== "string") return { ok: false, error: "採点の答えの形が違います。" };
    if (!STATUSES.includes(item.status as PointStatus)) return { ok: false, error: `採点の答えに知らない印があります（${item.status}）。` };
    const at = item.index - 1;
    if (!Number.isInteger(item.index) || at < 0 || at >= pointCount || points[at] !== null) {
      incomplete = true;
      continue;
    }
    points[at] = item.status as PointStatus;
  }
  if (points.includes(null)) incomplete = true;
  const forbidden: (ForbiddenCheck | null)[] = Array.from({ length: forbiddenCount }, () => null);
  for (const item of value.forbidden) {
    if (!isRecord(item) || typeof item.index !== "number" || typeof item.violated !== "boolean" || typeof item.quote !== "string") return { ok: false, error: "採点の答えの形が違います。" };
    const at = item.index - 1;
    if (!Number.isInteger(item.index) || at < 0 || at >= forbiddenCount || forbidden[at] !== null) {
      incomplete = true;
      continue;
    }
    // 採点者の思い込みで違反を作らない: 写した字が答えに見つからなければ「要確認」
    const found = item.violated && includesNormalized(answer, item.quote);
    forbidden[at] = { violated: found, quote: found ? item.quote : "", review: item.violated && !found };
  }
  if (forbidden.includes(null)) incomplete = true;
  return {
    ok: true,
    judgment: {
      declined: value.declined,
      points: points.map((status) => status ?? "missing"),
      forbidden: forbidden.map((check) => check ?? { violated: false, quote: "", review: false }),
      reason: [...value.reason].slice(0, REASON_MAX).join(""),
      incomplete,
    },
  };
}
