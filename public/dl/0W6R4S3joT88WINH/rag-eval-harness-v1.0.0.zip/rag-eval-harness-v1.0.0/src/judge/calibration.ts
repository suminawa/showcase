import { readFileSync } from "node:fs";
import { HarnessError } from "../errors.ts";
import { runFirstThenPool } from "../concurrency.ts";
import { gradeCase } from "../score/grade.ts";
import type { AdapterAnswer, EvalCase, Judge, JudgeOutcome, SourceRef, UsageRecord, Verdict } from "../types.ts";
import { JUDGE_CONCURRENCY } from "./claude.ts";

/**
 * 採点の確かめ（npm run judge:check）。
 * 1. 較正: 人の判定を持たせた答え（samples/calibration.jsonl）を採点させ、人の判定との一致率を出す。90% 未満なら発売しない
 * 2. 正しい見本と空の見本: 要点をそのままつないだ答えが全部「正解」、空の答えが全部「正解以外」になるか（配線の誤りを見つける）
 */

export const AGREEMENT_FLOOR = 0.9;

export interface CalibrationItem {
  id: string;
  /** sample = 見本の会社の文書に沿って書いた答え、planted = わざと作った悪い答え */
  kind: "sample" | "planted";
  note: string;
  question: string;
  points: string[];
  special: "refuse" | null;
  forbidden: string[];
  answer: string;
  sources: SourceRef[];
  /** 人の判定 */
  label: Exclude<Verdict, "error" | "judgeError">;
}

export interface CalibrationRow {
  id: string;
  kind: CalibrationItem["kind"];
  label: Verdict;
  got: Verdict;
  agree: boolean;
  reason: string;
}

export interface CalibrationResult {
  rows: CalibrationRow[];
  agreed: number;
  total: number;
  agreement: number;
  usage: UsageRecord[];
}

const LABELS = ["correct", "partial", "wrong", "noAnswer"];

export function parseCalibration(text: string): CalibrationItem[] {
  const items: CalibrationItem[] = [];
  text.split("\n").forEach((line, index) => {
    if (line.trim() === "") return;
    let item: CalibrationItem;
    try {
      item = JSON.parse(line) as CalibrationItem;
    } catch {
      throw new HarnessError(`calibration.jsonl の ${index + 1} 行目を JSON として読めません。`);
    }
    if (typeof item.id !== "string" || typeof item.question !== "string" || typeof item.answer !== "string" || !Array.isArray(item.points) || !LABELS.includes(item.label)) {
      throw new HarnessError(`calibration.jsonl の ${index + 1} 行目の形が違います（id・question・points・answer・label が要ります）。`);
    }
    items.push(item);
  });
  return items;
}

export function loadCalibration(path: string): CalibrationItem[] {
  let text: string;
  try {
    text = readFileSync(path, "utf8");
  } catch {
    throw new HarnessError(`較正の答え ${path} が見つかりません。`);
  }
  return parseCalibration(text);
}

/** 較正の 1 件を、質問表の 1 行とキットの答えの形にする。断ったかは採点者に決めさせる（refused: null） */
export function calibrationCase(item: CalibrationItem): { c: EvalCase; a: AdapterAnswer } {
  return {
    c: { id: item.id, line: 0, question: item.question, points: item.points, special: item.special, sources: [], forbidden: item.forbidden, tags: [], previous: null, document: null, documentLabel: null, form: null, extras: {} },
    a: { status: "ok", answer: item.answer, sources: item.sources, refused: null, handoff: null, retrieved: null, latencyMs: 0, usage: [], model: null },
  };
}

export async function runCalibration(judge: Judge, items: CalibrationItem[]): Promise<CalibrationResult> {
  const outcomes: JudgeOutcome[] = await runFirstThenPool(items, JUDGE_CONCURRENCY, async (item) => {
    const { c, a } = calibrationCase(item);
    return judge.judge(c, a, 0);
  });
  const rows = items.map((item, i): CalibrationRow => {
    const { c, a } = calibrationCase(item);
    const result = gradeCase(c, a, outcomes[i], { round: 0, attempts: 1, judgeMode: judge.info.mode });
    return { id: item.id, kind: item.kind, label: item.label, got: result.verdict, agree: result.verdict === item.label, reason: result.reason };
  });
  const agreed = rows.filter((row) => row.agree).length;
  return { rows, agreed, total: rows.length, agreement: rows.length === 0 ? 0 : agreed / rows.length, usage: outcomes.flatMap((outcome) => outcome.usage) };
}

export interface WiringResult {
  failures: string[];
  checked: number;
  usage: UsageRecord[];
}

/** 要点をそのままつないだ答え → 正解、空の答え → 正解以外。ずれた問いを返す */
export async function runWiringCheck(judge: Judge, cases: EvalCase[]): Promise<WiringResult> {
  const failures: string[] = [];
  const pairs = cases.flatMap((c) => [
    { c, a: { status: "ok", answer: `${c.points.join("。")}。`, sources: [], refused: null, handoff: null, retrieved: null, latencyMs: 0, usage: [], model: null } as AdapterAnswer, wantCorrect: true },
    { c, a: { status: "ok", answer: "", sources: [], refused: null, handoff: null, retrieved: null, latencyMs: 0, usage: [], model: null } as AdapterAnswer, wantCorrect: false },
  ]);
  const outcomes = await runFirstThenPool(pairs, JUDGE_CONCURRENCY, (pair) => judge.judge(pair.c, pair.a, 0));
  pairs.forEach((pair, i) => {
    const verdict = gradeCase(pair.c, pair.a, outcomes[i], { round: 0, attempts: 1, judgeMode: judge.info.mode }).verdict;
    if (pair.wantCorrect && verdict !== "correct") failures.push(`${pair.c.id}: 要点をそのままつないだ答えが「${verdict}」になりました。`);
    if (!pair.wantCorrect && verdict === "correct") failures.push(`${pair.c.id}: 空の答えが「正解」になりました。`);
  });
  return { failures, checked: pairs.length, usage: outcomes.flatMap((outcome) => outcome.usage) };
}
