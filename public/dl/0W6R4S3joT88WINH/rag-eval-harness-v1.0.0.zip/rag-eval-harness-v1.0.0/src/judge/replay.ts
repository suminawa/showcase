import { findRecord, type CasesJsonl } from "../adapters/replay.ts";
import type { AdapterAnswer, EvalCase, Judge } from "../types.ts";

/**
 * 記録の採点をそのまま使う（--judge replay。API を呼ばない）。
 * 費用も記録のまま数える（見本のレポートに、実際にかかった額を出すため）
 */
export function createReplayJudge(jsonl: CasesJsonl): Judge {
  const judge = jsonl.meta?.judge;
  return {
    info: { mode: "replay", model: judge?.model ?? null, effort: judge?.effort ?? null, rubricVersion: judge?.rubricVersion ?? null },
    async judge(c: EvalCase, _answer: AdapterAnswer, round: number) {
      const record = findRecord(jsonl.records, c.id, round);
      if (record === undefined || record.judge === null) return { ok: false, error: `記録に採点がありません（${c.id}）。`, usage: [], raw: null };
      return record.judge;
    },
  };
}
