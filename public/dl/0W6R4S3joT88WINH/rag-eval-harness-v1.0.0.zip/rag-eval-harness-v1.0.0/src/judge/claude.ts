import Anthropic from "@anthropic-ai/sdk";
import { isRetryable, sameModel, statusOf, usageRecordOf } from "../adapters/recording-client.ts";
import { RETRY_DELAYS_MS, jittered, sleep as realSleep } from "../concurrency.ts";
import type { AdapterAnswer, EvalCase, Judge, JudgeOutcome, UsageRecord } from "../types.ts";
import { RUBRIC, RUBRIC_VERSION, buildJudgeUser } from "./prompt.ts";
import { JUDGE_SCHEMA, parseJudge } from "./schema.ts";

export const DEFAULT_JUDGE_MODEL = "claude-sonnet-5";
export const DEFAULT_JUDGE_EFFORT = "low";
export const JUDGE_EFFORTS = ["low", "medium", "high"] as const;
export type JudgeEffort = (typeof JUDGE_EFFORTS)[number];
export const JUDGE_MAX_TOKENS = 2048;
export const JUDGE_RETRY_MAX_TOKENS = 4096;
/** 採点は同時 4 に固定（最初の 1 件の後） */
export const JUDGE_CONCURRENCY = 4;
/** claude-opus-5 は断り（refusal）の予備を、サーバー側の fallback に任せる */
export const FALLBACK_BETA = "server-side-fallback-2026-07-01";
export const SAME_MODEL_NOTE = "答えと採点が同じモデルです。自分の答えを甘く採点する傾向があるため、--judge-model で別のモデルを選ぶことをおすすめします。";

/** 採点に使う client の形。本物は createJudgeClient、検査は偽物 */
export interface JudgeClientLike {
  messages: { create(params: any): Promise<any> };
  beta: { messages: { create(params: any): Promise<any> } };
}

/** 本物の SDK に触る唯一の場所。やり直しはこちらで数えるので、SDK のやり直しは切る */
export function createJudgeClient(apiKey: string): JudgeClientLike {
  const client = new Anthropic({ apiKey, maxRetries: 0 });
  return {
    messages: { create: (params: unknown) => client.messages.create(params as never) },
    beta: { messages: { create: (params: unknown) => client.beta.messages.create(params as never) } },
  };
}

export interface JudgeRequest {
  params: Record<string, unknown>;
  /** beta.messages.create で送るか（opus 5 の fallback） */
  beta: boolean;
}

export function buildJudgeRequest(model: string, effort: JudgeEffort, c: EvalCase, a: AdapterAnswer, maxTokens: number = JUDGE_MAX_TOKENS): JudgeRequest {
  const format = { type: "json_schema", schema: JUDGE_SCHEMA };
  const params: Record<string, unknown> = {
    model,
    max_tokens: maxTokens,
    system: [{ type: "text", text: RUBRIC, cache_control: { type: "ephemeral" } }],
    messages: [{ role: "user", content: buildJudgeUser(c, a) }],
    // haiku 4.5 は effort を受けないので送らない。thinking は付けない（sonnet 5 は既定で adaptive）
    output_config: model.startsWith("claude-haiku") ? { format } : { effort, format },
  };
  if (model === "claude-opus-5") return { params: { ...params, betas: [FALLBACK_BETA], fallbacks: "default" }, beta: true };
  return { params, beta: false };
}

function textOf(message: any): string {
  return (message?.content ?? []).filter((block: any) => block?.type === "text").map((block: any) => String(block.text ?? "")).join("");
}

/** fallback が走った（予備のモデルが答えた）か。そのときはモデル違いとしない */
function fellBack(message: any): boolean {
  return (message?.usage?.iterations ?? []).some((entry: any) => entry?.type === "fallback_message");
}

export interface ClaudeJudgeOptions {
  client: JudgeClientLike;
  model: string;
  effort: JudgeEffort;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
}

export function createClaudeJudge(options: ClaudeJudgeOptions): Judge {
  const sleep = options.sleep ?? realSleep;
  const random = options.random ?? Math.random;

  async function send(request: JudgeRequest): Promise<any> {
    for (let attempt = 0; ; attempt += 1) {
      try {
        return request.beta ? await options.client.beta.messages.create(request.params) : await options.client.messages.create(request.params);
      } catch (error) {
        if (!isRetryable(error) || attempt >= RETRY_DELAYS_MS.length) throw error;
        await sleep(jittered(RETRY_DELAYS_MS[attempt], random));
      }
    }
  }

  return {
    info: { mode: "claude", model: options.model, effort: options.effort, rubricVersion: RUBRIC_VERSION },
    async judge(c: EvalCase, a: AdapterAnswer): Promise<JudgeOutcome> {
      const usage: UsageRecord[] = [];
      let raw: string | null = null;
      let problem = "";
      // JSON が壊れた・max_tokens・refusal なら、max_tokens を 4096 にして 1 回だけやり直す
      for (const maxTokens of [JUDGE_MAX_TOKENS, JUDGE_RETRY_MAX_TOKENS]) {
        let message: any;
        try {
          message = await send(buildJudgeRequest(options.model, options.effort, c, a, maxTokens));
        } catch (error) {
          const status = statusOf(error);
          return { ok: false, error: `採点の呼び出しが失敗しました（${status === null ? "接続の切れ" : `HTTP ${status}`}）。`, usage, raw };
        }
        const model = typeof message?.model === "string" ? message.model : options.model;
        usage.push(usageRecordOf(model, message?.usage));
        if (!sameModel(options.model, model) && !fellBack(message)) {
          return { ok: false, error: `採点のモデル（${model}）が、頼んだモデル（${options.model}）と違います。`, usage, raw };
        }
        raw = textOf(message);
        if (message?.stop_reason === "max_tokens" || message?.stop_reason === "refusal") {
          problem = `採点が途中で止まりました（stop_reason: ${message.stop_reason}）。`;
          continue;
        }
        const parsed = parseJudge(raw, c.points.length, c.forbidden.length, a.answer);
        if (parsed.ok) return { ok: true, judgment: parsed.judgment, usage, raw };
        problem = parsed.error;
      }
      return { ok: false, error: problem, usage, raw };
    },
  };
}
