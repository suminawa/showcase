import { includesNormalized } from "../normalize.ts";
import type { AdapterAnswer, EvalCase, Judge, Judgment } from "../types.ts";

/** --judge keyword のときにレポートの頭に出す注意 */
export const KEYWORD_NOTE = "語の一致での採点です。言い換えは誤りに数えます。目安としてご覧ください。";

/** 窓口の印が「断った」でないときに使う、断りの決まり文句（印は false でも丁寧な断りを返すことがある） */
export const REFUSAL_PATTERN = /資料に(は)?(載っていません|見当たりません|記載がございません|ございません|ありません)|お答えできません|お答えできかねます|分かりかねます|わかりかねます|分かりません|わかりません/;

/**
 * 語の一致の採点（API を呼ばない）。要点と禁止を語の揃え方で答えに探す（部分一致）。
 * covered と missing だけで、contradicted は出せない
 */
export function keywordJudgment(c: EvalCase, a: AdapterAnswer): Judgment {
  const points = c.points.map((point) => (includesNormalized(a.answer, point) ? "covered" : "missing") as Judgment["points"][number]);
  const covered = points.filter((status) => status === "covered").length;
  return {
    declined: a.refused === true || REFUSAL_PATTERN.test(a.answer),
    points,
    forbidden: c.forbidden.map((text) => (includesNormalized(a.answer, text) ? { violated: true, quote: text, review: false } : { violated: false, quote: "", review: false })),
    reason: points.length === 0 ? "語の一致: 断りの言い方を見ました。" : `語の一致: 要点 ${covered}/${points.length} が答えに含まれます。`,
    incomplete: false,
  };
}

export function createKeywordJudge(): Judge {
  return {
    info: { mode: "keyword", model: null, effort: null, rubricVersion: null },
    async judge(c: EvalCase, a: AdapterAnswer) {
      return { ok: true, judgment: keywordJudgment(c, a), usage: [], raw: null };
    },
  };
}
