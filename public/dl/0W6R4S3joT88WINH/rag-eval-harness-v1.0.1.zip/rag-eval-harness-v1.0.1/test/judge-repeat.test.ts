import { test } from "node:test";
import assert from "node:assert/strict";
import { createClaudeJudge } from "../src/judge/claude.ts";
import { createRepeatedJudge } from "../src/judge/repeat.ts";
import { runCases } from "../src/run.ts";
import { aggregate } from "../src/score/aggregate.ts";
import type { Adapter } from "../src/types.ts";
import { fakeAnthropic } from "./fixtures/fake-anthropic.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

const reply = (status: string) => ({ text: JSON.stringify({ declined: false, points: [{ index: 1, status }], forbidden: [], reason: status }) });
const adapter: Adapter = { info: { name: "http", label: "窓口", mode: "http", version: null, model: null }, notes: [], ask: async () => answerOf({ answer: "施工は 2 年です。", refused: false }) };

test("--judge-repeat 3: 同じ答えを 3 回採点し、2:1 に割れたら多数決（正解）にする。一致率は 2/3", async () => {
  // 1 回目と 3 回目は「述べている」、2 回目だけ「触れていない」
  const anthropic = fakeAnthropic((_params, call) => reply(call === 2 ? "missing" : "covered"));
  const judge = createRepeatedJudge(createClaudeJudge({ client: anthropic.client, model: "claude-sonnet-5", effort: "low" }), 3);
  assert.equal(judge.info.repeat, 3);
  const records = await runCases({ cases: [caseOf({ id: "q1", points: ["2 年"] })], adapter, judge, concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(anthropic.requests.length, 3);
  assert.equal(records[0].result.verdict, "correct");
  assert.deepEqual(records[0].result.votes, ["correct", "wrong", "correct"]);
  assert.equal(records[0].judge?.usage.length, 3, "3 回分の費用を数える");
  const summary = aggregate(records, { yenPerUsd: 150, kit: "http" });
  assert.ok(summary.judgeAgreement !== null && Math.abs(summary.judgeAgreement - 2 / 3) < 1e-9, String(summary.judgeAgreement));
});

test("--judge-repeat: そろえば一致率 100%。採点エラーは票に数えず、全部が採点エラーなら採点エラー。1 回なら包まない", async () => {
  const same = fakeAnthropic(() => reply("covered"));
  const cases = [caseOf({ id: "q1", points: ["2 年"] }), caseOf({ id: "q2", points: ["2 年"] })];
  const records = await runCases({ cases, adapter, judge: createRepeatedJudge(createClaudeJudge({ client: same.client, model: "claude-sonnet-5", effort: "low" }), 3), concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(aggregate(records, { yenPerUsd: 150, kit: "http" }).judgeAgreement, 1);

  const flaky = fakeAnthropic((_params, call) => (call <= 2 ? { text: "壊れた", stopReason: "end_turn" } : reply("missing")));
  const [one] = await runCases({ cases: [cases[0]], adapter, judge: createRepeatedJudge(createClaudeJudge({ client: flaky.client, model: "claude-sonnet-5", effort: "low" }), 3), concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(one.result.verdict, "wrong", "壊れた 1 票を除いた多数決");
  assert.deepEqual(one.result.votes?.slice(1), ["wrong", "wrong"]);

  const broken = fakeAnthropic(() => ({ error: { status: 500 } }));
  const [bad] = await runCases({ cases: [cases[0]], adapter, judge: createRepeatedJudge(createClaudeJudge({ client: broken.client, model: "claude-sonnet-5", effort: "low", sleep: async () => {} }), 3), concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(bad.result.verdict, "judgeError");

  const inner = createClaudeJudge({ client: same.client, model: "claude-sonnet-5", effort: "low" });
  assert.equal(createRepeatedJudge(inner, 1), inner);
});

test("--judge-repeat: 最初の採点が 404 なら、2 回目以降も残りの問いも送らない", async () => {
  const anthropic = fakeAnthropic(() => ({ error: { status: 404 } }));
  const judge = createRepeatedJudge(createClaudeJudge({ client: anthropic.client, model: "claude-sonnet-9", effort: "low", sleep: async () => {} }), 3);
  const records = await runCases({ cases: ["q1", "q2"].map((id) => caseOf({ id, points: ["2 年"] })), adapter, judge, concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(anthropic.requests.length, 1);
  assert.deepEqual(records.map((record) => record.result.verdict), ["judgeError", "judgeError"]);
});
