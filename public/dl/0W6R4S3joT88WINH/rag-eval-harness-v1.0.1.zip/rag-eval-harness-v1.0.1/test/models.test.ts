import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { DEFAULT_JUDGE_MODEL, JUDGE_MODEL_PREFIXES, PRICES } from "../src/models.ts";
import { PACKAGE_ROOT } from "./fixtures/helpers.ts";

function filesUnder(dir: string): string[] {
  return readdirSync(join(PACKAGE_ROOT, dir)).sort().flatMap((name) => (statSync(join(PACKAGE_ROOT, dir, name)).isDirectory() ? filesUnder(join(dir, name)) : [join(dir, name)]));
}

test("モデル名・値段・名前の頭・beta の字は src/models.ts の 1 か所だけに書く（モデルの廃止のとき、直すのはここだけ）", () => {
  for (const file of filesUnder("src")) {
    if (file === join("src", "models.ts")) continue;
    // コメントは除いて、コードの中の文字だけを見る
    const code = readFileSync(join(PACKAGE_ROOT, file), "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:])\/\/.*$/gm, "$1");
    assert.equal(/["'`]claude-[a-z0-9-]*["'`]/.test(code), false, `${file} にモデル名があります`);
    assert.equal(/server-side-fallback/.test(code), false, `${file} に beta の字があります`);
  }
  assert.ok(JUDGE_MODEL_PREFIXES.some((prefix) => DEFAULT_JUDGE_MODEL.startsWith(prefix)));
  assert.ok(PRICES[DEFAULT_JUDGE_MODEL] !== undefined, "既定の採点モデルは値段の表にある");
});
