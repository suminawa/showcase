import { test } from "node:test";
import assert from "node:assert/strict";
import { runFirstThenPool } from "../src/concurrency.ts";
import { FALLBACK_BETA, JUDGE_CONCURRENCY, buildJudgeRequest, createClaudeJudge } from "../src/judge/claude.ts";
import { RUBRIC } from "../src/judge/prompt.ts";
import { runCases } from "../src/run.ts";
import type { Adapter } from "../src/types.ts";
import { JUDGE_SCHEMA } from "../src/judge/schema.ts";
import { fakeAnthropic, type FakeScript } from "./fixtures/fake-anthropic.ts";
import { answerOf, caseOf } from "./fixtures/helpers.ts";

const c = caseOf({ id: "q1", question: "保証は何年ですか", points: ["施工 2 年", "構造 10 年"] });
const a = answerOf({ answer: "施工は 2 年、構造は 10 年です。", refused: false });
const GOOD = JSON.stringify({ declined: false, points: [{ index: 1, status: "covered" }, { index: 2, status: "covered" }], forbidden: [], reason: "両方を述べています。" });

function judgeWith(script: FakeScript, model = "claude-sonnet-5") {
  const anthropic = fakeAnthropic(script);
  const waits: number[] = [];
  const judge = createClaudeJudge({ client: anthropic.client, model, effort: "low", sleep: async (ms) => void waits.push(ms), random: () => 0.5 });
  return { judge, anthropic, waits };
}

test("要求の形: model・max_tokens 2048・effort low・output_config.format（json_schema）・system の cache_control", async () => {
  const { judge, anthropic } = judgeWith(() => ({ text: GOOD }));
  const outcome = await judge.judge(c, a, 0);
  assert.ok(outcome.ok);
  const params = anthropic.requests[0];
  assert.equal(params.model, "claude-sonnet-5");
  assert.equal(params.max_tokens, 2048);
  assert.deepEqual(params.output_config, { effort: "low", format: { type: "json_schema", schema: JUDGE_SCHEMA } });
  assert.deepEqual(params.system, [{ type: "text", text: RUBRIC, cache_control: { type: "ephemeral" } }]);
  assert.equal(params.thinking, undefined);
  assert.equal(params.betas, undefined);
  assert.equal(outcome.usage.length, 1);
  assert.deepEqual(judge.info, { mode: "claude", model: "claude-sonnet-5", effort: "low", rubricVersion: "2026-10-06" });
});

test("haiku 4.5 には effort を送らない。opus 5 は beta で fallbacks: default を付け、予備のモデルの答えも受ける", async () => {
  assert.deepEqual(buildJudgeRequest("claude-haiku-4-5", "low", c, a).params.output_config, { format: { type: "json_schema", schema: JUDGE_SCHEMA } });
  const opus = buildJudgeRequest("claude-opus-5", "low", c, a);
  assert.equal(opus.beta, true);
  assert.deepEqual([opus.params.betas, opus.params.fallbacks], [[FALLBACK_BETA], "default"]);
  const { judge } = judgeWith(() => ({ text: GOOD, model: "claude-opus-4-8", iterations: [{ type: "fallback_message" }] }), "claude-opus-5");
  const outcome = await judge.judge(c, a, 0);
  assert.equal(outcome.ok, true);
});

test("最初の 1 件の応答を受けてから、残りを同時 4 で送る", async () => {
  let running = 0;
  let most = 0;
  const started: number[] = [];
  let firstDone = false;
  const order: string[] = [];
  await runFirstThenPool([0, 1, 2, 3, 4, 5, 6, 7], JUDGE_CONCURRENCY, async (item) => {
    started.push(item);
    if (item !== 0) assert.ok(firstDone, "2 件目以降は、最初の 1 件の応答の後");
    running += 1;
    most = Math.max(most, running);
    await new Promise((resolve) => setTimeout(resolve, 5));
    running -= 1;
    if (item === 0) firstDone = true;
    order.push(String(item));
    return item;
  });
  assert.equal(most, 4);
  assert.equal(order[0], "0");
});

test("max_tokens か refusal で止まったら、max_tokens 4096 で 1 回だけやり直す。だめなら採点エラー", async () => {
  const { judge, anthropic } = judgeWith((_params, call) => (call === 1 ? { text: '{"declined":', stopReason: "max_tokens" } : { text: GOOD }));
  const outcome = await judge.judge(c, a, 0);
  assert.ok(outcome.ok);
  assert.deepEqual(anthropic.requests.map((params) => params.max_tokens), [2048, 4096]);
  assert.equal(outcome.usage.length, 2, "やり直しの費用も数える");
  const broken = judgeWith(() => ({ text: "", stopReason: "refusal" }));
  const failed = await broken.judge.judge(c, a, 0);
  assert.deepEqual([failed.ok, broken.anthropic.requests.length], [false, 2]);
  assert.ok(!failed.ok && failed.error === "採点が途中で止まりました（stop_reason: refusal）。");
});

test("529 は 1・3・9 秒（ゆらぎつき）で 3 回までやり直す。別の model が答えたら採点エラー", async () => {
  const busy = judgeWith((_params, call) => (call <= 3 ? { error: { status: 529 } } : { text: GOOD }));
  assert.equal((await busy.judge.judge(c, a, 0)).ok, true);
  assert.deepEqual(busy.waits, [1000, 3000, 9000]);
  const down = judgeWith(() => ({ error: { status: 500 } }));
  const failed = await down.judge.judge(c, a, 0);
  assert.ok(!failed.ok && failed.error === "採点の呼び出しが失敗しました（HTTP 500）。");
  assert.equal(down.anthropic.requests.length, 4);
  const other = judgeWith(() => ({ text: GOOD, model: "claude-haiku-4-5" }));
  const mismatch = await other.judge.judge(c, a, 0);
  assert.ok(!mismatch.ok && mismatch.error === "採点のモデル（claude-haiku-4-5）が、頼んだモデル（claude-sonnet-5）と違います。");
  const longer = judgeWith(() => ({ text: GOOD, model: "claude-sonnet-5-5" }));
  const notSame = await longer.judge.judge(c, a, 0);
  assert.ok(!notSame.ok && notSame.error === "採点のモデル（claude-sonnet-5-5）が、頼んだモデル（claude-sonnet-5）と違います。");
  const dated = judgeWith(() => ({ text: GOOD, model: "claude-sonnet-5-20261001" }));
  assert.equal((await dated.judge.judge(c, a, 0)).ok, true, "日付つきの名前は受ける");
  const denied = judgeWith(() => ({ error: { status: 401 } }));
  await denied.judge.judge(c, a, 0);
  assert.equal(denied.anthropic.requests.length, 1, "401 はやり直さない");
});

test("429 の retry-after（秒）と retry-after-ms を読んで待つ。60 秒より長い指定は 60 秒で止める", async () => {
  const later = judgeWith((_params, call) => (call === 1 ? { error: { status: 429, headers: { "retry-after": "20" } } } : { text: GOOD }));
  assert.equal((await later.judge.judge(c, a, 0)).ok, true);
  assert.deepEqual(later.waits, [20000]);
  const ms = judgeWith((_params, call) => (call === 1 ? { error: { status: 529, headers: { "retry-after-ms": "2500" } } } : { text: GOOD }));
  await ms.judge.judge(c, a, 0);
  assert.deepEqual(ms.waits, [2500]);
  const long = judgeWith((_params, call) => (call === 1 ? { error: { status: 429, headers: { "retry-after": "600" } } } : { text: GOOD }));
  await long.judge.judge(c, a, 0);
  assert.deepEqual(long.waits, [60000]);
});

test("採点のモデルが 404（名前の誤り・廃止）なら、最初の 1 件で止めて残りは送らない。全部を採点エラーにする", async () => {
  const anthropic = fakeAnthropic(() => ({ error: { status: 404, message: "model: claude-sonnet-9" } }));
  const judge = createClaudeJudge({ client: anthropic.client, model: "claude-sonnet-9", effort: "low", sleep: async () => {} });
  const adapter: Adapter = { info: { name: "http", label: "窓口", mode: "http", version: null, model: null }, notes: [], ask: async () => answerOf({ answer: "施工は 2 年です。", refused: false }) };
  const cases = ["q1", "q2", "q3", "q4"].map((id) => caseOf({ id, points: ["2 年"] }));
  const records = await runCases({ cases, adapter, judge, concurrency: 2, intervalMs: 0, repeat: 1 });
  assert.equal(anthropic.requests.length, 1, "404 はやり直さず、残りの 3 件も送らない");
  assert.deepEqual(records.map((record) => record.result.verdict), ["judgeError", "judgeError", "judgeError", "judgeError"]);
  assert.match(records[0].result.reason, /HTTP 404.*--judge-model/);
  assert.match(records[1].result.reason, /^最初の採点が HTTP 404 で失敗したため、この問いの採点は送っていません。/);
  const denied = fakeAnthropic(() => ({ error: { status: 401 } }));
  const keyJudge = createClaudeJudge({ client: denied.client, model: "claude-sonnet-5", effort: "low", sleep: async () => {} });
  const keyRecords = await runCases({ cases, adapter, judge: keyJudge, concurrency: 2, intervalMs: 0, repeat: 1 });
  assert.equal(denied.requests.length, 1);
  assert.match(keyRecords[0].result.reason, /HTTP 401.*ANTHROPIC_API_KEY/);
  // 2 件目以降の 404 は、その問いだけの採点エラー（止めない）
  const later = fakeAnthropic((_params, call) => (call === 2 ? { error: { status: 404 } } : { text: JSON.stringify({ declined: false, points: [{ index: 1, status: "covered" }], forbidden: [], reason: "" }) }));
  const laterJudge = createClaudeJudge({ client: later.client, model: "claude-sonnet-5", effort: "low", sleep: async () => {} });
  await runCases({ cases, adapter, judge: laterJudge, concurrency: 1, intervalMs: 0, repeat: 1 });
  assert.equal(later.requests.length, 4);
});
