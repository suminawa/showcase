# 自前の RAG を FastAPI で包み、ハーネスの既定の形（POST /ask）で答える見本です。
# 既定の形なら --map は要りません。
# 動かし方: pip install fastapi uvicorn → uvicorn wrap_fastapi:app --port 8787（examples/ で）→ 別の端末で
#   npm run eval -- --kit http --url http://127.0.0.1:8787/ask --cases my-cases.csv
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Turn(BaseModel):
    role: str  # "user" か "assistant"
    content: str


class Ask(BaseModel):
    question: str
    history: list[Turn] = []  # 「前の質問」があるときの会話


def ask_my_rag(question: str, history: list[Turn]) -> dict:
    """ここを自分の RAG の呼び出しに替えます。

    返すもの: answer（答えの文）・sources（出典の題と URL）・refused（資料に無いので断ったか。分からなければ省く）。
    retrieved（検索で拾った文書）を返すと、レポートに「検索の当たり」が出ます。
    """
    # 例: result = chain.invoke({"question": question, "chat_history": [(t.role, t.content) for t in history]})
    return {
        "answer": f"（ここに答えが入ります）{question}",
        "sources": [{"title": "料金", "url": "https://example.com/price"}],
        "refused": False,
        "retrieved": [{"title": "料金", "url": "https://example.com/price"}],
    }


@app.post("/ask")
def ask(body: Ask) -> dict:
    # 例外は 500 になり、ハーネスが 1・3・9 秒でやり直します（だめなら実行エラーとして数え、誤りには数えません）
    return ask_my_rag(body.question, body.history)
