// 自前の RAG を Express で包み、ハーネスの既定の形（POST /ask）で答える見本です。
// 既定の形なら --map は要りません。
// 動かし方: npm install express → node examples/wrap-express.mjs → 別の端末で
//   npm run eval -- --kit http --url http://127.0.0.1:8787/ask --cases my-cases.csv
import express from "express";

/**
 * ここを自分の RAG の呼び出しに替えます。
 * question は質問、history は「前の質問」があるときの会話（[{ role: "user" | "assistant", content }]）です。
 * 返すもの: answer（答えの文）・sources（出典の題と URL）・refused（資料に無いので断ったか。分からなければ省く）。
 * retrieved（検索で拾った文書）を返すと、レポートに「検索の当たり」が出ます。
 */
async function askMyRag(question, history) {
  // 例: const result = await chain.invoke({ question, chat_history: history });
  return {
    answer: `（ここに答えが入ります）${question}`,
    sources: [{ title: "料金", url: "https://example.com/price" }],
    refused: false,
    retrieved: [{ title: "料金", url: "https://example.com/price" }],
  };
}

const app = express();
app.use(express.json());
app.post("/ask", async (request, response) => {
  const { question, history } = request.body ?? {};
  if (typeof question !== "string") {
    response.status(400).json({ message: "question を文字で送ってください。" });
    return;
  }
  try {
    response.json(await askMyRag(question, Array.isArray(history) ? history : []));
  } catch (error) {
    // 5xx はハーネスが 1・3・9 秒でやり直し、だめなら実行エラーとして数えます（誤りには数えません）
    response.status(500).json({ message: error instanceof Error ? error.message : String(error) });
  }
});
app.listen(8787, "127.0.0.1", () => console.log("http://127.0.0.1:8787/ask で待っています"));
