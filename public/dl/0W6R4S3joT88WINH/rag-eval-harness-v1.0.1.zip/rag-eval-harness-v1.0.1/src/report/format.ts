import type { CaseRecord, JudgeInfo, KitInfo, Summary, Verdict } from "../types.ts";

/** 出力（HTML・Markdown・CSV・終わりの 5 行）で共通に使う書き方 */

export const VERDICT_LABELS: Record<Verdict, string> = {
  correct: "正解",
  partial: "部分",
  wrong: "誤り",
  noAnswer: "無回答",
  error: "実行エラー",
  judgeError: "採点エラー",
};

export const VERDICT_LABELS_EN: Record<Verdict, string> = {
  correct: "correct",
  partial: "partial",
  wrong: "wrong",
  noAnswer: "no answer",
  error: "run error",
  judgeError: "grading error",
};

export const VERDICT_ORDER: Verdict[] = ["correct", "partial", "wrong", "noAnswer", "error", "judgeError"];

export const KIT_LABELS: Record<string, string> = {
  "ai-concierge": "AI 案内窓口キット",
  "line-concierge": "LINE 案内窓口キット",
  "doc-reader": "AI 書類読み取りキット",
  http: "任意の窓口（HTTP）",
  replay: "記録の再生",
};

export const MODE_LABELS: Record<KitInfo["mode"], string> = { "in-process": "手元", http: "置いた先", replay: "記録の再生" };

export function formatRate(value: number | null): string {
  return value === null ? "—" : `${Math.round(value * 100)}%`;
}

/** 差（0〜1）をポイントで。+6・−3・±0 */
export function formatDelta(value: number | null): string {
  if (value === null) return "—";
  const points = Math.round(value * 100);
  if (points === 0) return "±0";
  return points > 0 ? `+${points}` : `−${Math.abs(points)}`;
}

/** 円。10 円未満は小数 1 桁 */
export function formatYen(value: number | null, lowerBound: boolean = false): string {
  if (value === null) return "—";
  const text = value < 10 ? value.toFixed(1) : Math.round(value).toLocaleString("ja-JP");
  return `${text} 円${lowerBound ? "以上" : ""}`;
}

export function formatSeconds(ms: number | null): string {
  return ms === null ? "—" : `${(ms / 1000).toFixed(1)} 秒`;
}

/** ISO の日時を日本時間の「2026-10-05 21:30」に */
export function formatJst(iso: string): string {
  const date = new Date(new Date(iso).getTime() + 9 * 60 * 60 * 1000);
  return date.toISOString().slice(0, 16).replace("T", " ");
}

/** runs の下のフォルダ名に使う日時（日本時間の YYYYMMDD-HHmmss） */
export function runStamp(date: Date): string {
  const jst = new Date(date.getTime() + 9 * 60 * 60 * 1000).toISOString();
  return `${jst.slice(0, 10).replace(/-/g, "")}-${jst.slice(11, 19).replace(/:/g, "")}`;
}

export function judgeLabel(judge: JudgeInfo): string {
  if (judge.mode === "keyword") return "語の一致（API なし）";
  if (judge.mode === "replay") return `${judge.model ?? "—"}（記録の再生）`;
  return `${judge.model ?? "—"}（effort ${judge.effort ?? "—"}${(judge.repeat ?? 1) > 1 ? `・${judge.repeat} 回の多数決` : ""}）`;
}

export function kitLabel(kit: KitInfo): string {
  const product = KIT_LABELS[kit.name] ?? kit.name;
  return `${product}${kit.version === null ? "" : ` ${kit.version}`}（${MODE_LABELS[kit.mode]}）`;
}

export function head(text: string, max: number = 200): string {
  const chars = [...text];
  return chars.length <= max ? text : `${chars.slice(0, max - 1).join("")}…`;
}

/** 1 問の重み（ポイント）。10 未満は小数 1 桁（40 問なら 2.5） */
export function formatPoints(value: number): string {
  return value >= 10 ? String(Math.round(value)) : String(Number(value.toFixed(1)));
}

/** 「95% 区間 58〜92%（1 問 = 5 ポイント）」。出せなければ空 */
export function intervalText(summary: Pick<Summary, "scoreInterval" | "pointsPerQuestion">, en: boolean = false): string {
  const { scoreInterval: ci, pointsPerQuestion: weight } = summary;
  if (ci === null || ci === undefined || weight === null || weight === undefined) return "";
  const low = Math.round(ci.low * 100);
  const high = Math.round(ci.high * 100);
  return en ? `95% CI ${low}–${high}%, 1 question = ${formatPoints(weight)} points` : `95% 区間 ${low}〜${high}%（1 問 = ${formatPoints(weight)} ポイント）`;
}

/** --judge-repeat の回数（票の数の最大）。付けていなければ 1 */
export function votesPerAnswer(records: CaseRecord[]): number {
  return Math.max(1, ...records.map((record) => record.result.votes?.length ?? 0));
}
