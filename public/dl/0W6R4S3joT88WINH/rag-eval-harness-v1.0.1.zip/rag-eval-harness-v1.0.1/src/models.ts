/**
 * モデルに関わる決まりの 1 か所。モデルの名前が変わった・廃止されたときは、ここだけを直します
 * （直したら npm run build で組み立て直し、npm run judge:check で採点を確かめてください）。
 */

/** 採点の既定のモデル（キットの答えの既定 claude-opus-5 とは別のモデルにしてある） */
export const DEFAULT_JUDGE_MODEL = "claude-sonnet-5";

/** --judge-model に使える名前の頭 */
export const JUDGE_MODEL_PREFIXES = ["claude-sonnet-", "claude-opus-", "claude-haiku-"];

/** effort を受けないモデルの名前の頭。このモデルは 4096 トークン以上の決まりだけをキャッシュに乗せる */
export const NO_EFFORT_PREFIX = "claude-haiku-";

/** 断り（refusal）の予備を、サーバー側の fallback に任せるモデルと、そのときに付ける beta の字 */
export const FALLBACK_MODEL = "claude-opus-5";
export const FALLBACK_BETA = "server-side-fallback-2026-07-01";

/** 100 万トークンあたりのドル（2026-09 時点の公開価格）。キャッシュの倍率は pricing.ts */
export const PRICES: Record<string, { input: number; output: number }> = {
  "claude-opus-5": { input: 5, output: 25 },
  "claude-opus-4-8": { input: 5, output: 25 },
  "claude-sonnet-5": { input: 2, output: 10 },
  "claude-haiku-4-5": { input: 1, output: 5 },
};
