import { gradeCase } from "../score/grade.ts";
import type { AdapterAnswer, EvalCase, Judge, JudgeOutcome, Verdict } from "../types.ts";

/**
 * --judge-repeat N: 同じ答えを N 回採点し、判定の多数決を採る（採点のぶれを測る）。
 * 採点エラーは票に数えない。同数なら先に出た判定。費用は N 回分を数える。
 * 票（採点ごとの判定）は outcome.votes に残し、集計が一致率（多数決の票の割合）を出す
 */
export function createRepeatedJudge(inner: Judge, times: number): Judge {
  if (times <= 1) return inner;
  return {
    info: { ...inner.info, repeat: times },
    async judge(c: EvalCase, a: AdapterAnswer, round: number): Promise<JudgeOutcome> {
      const outcomes: JudgeOutcome[] = [];
      for (let i = 0; i < times; i += 1) {
        const outcome = await inner.judge(c, a, round);
        // 404・401 など、何度送っても同じ失敗はそこで止める（run.ts が残りの問いも止める）
        if (!outcome.ok && outcome.fatal === true) return outcome;
        outcomes.push(outcome);
      }
      const votes: Verdict[] = outcomes.map((outcome) => gradeCase(c, a, outcome, { round, attempts: 1, judgeMode: inner.info.mode }).verdict);
      const counts = new Map<Verdict, number>();
      for (const vote of votes) if (vote !== "judgeError") counts.set(vote, (counts.get(vote) ?? 0) + 1);
      let winner: Verdict | null = null;
      for (const [vote, count] of counts) if (winner === null || count > (counts.get(winner) ?? 0)) winner = vote;
      const chosen = winner === null ? outcomes[0] : outcomes[votes.indexOf(winner)];
      return { ...chosen, usage: outcomes.flatMap((outcome) => outcome.usage), votes };
    },
  };
}
