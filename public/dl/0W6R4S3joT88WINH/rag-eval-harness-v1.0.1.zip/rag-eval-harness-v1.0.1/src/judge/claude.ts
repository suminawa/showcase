import Anthropic from "@anthropic-ai/sdk";
import { isRetryable, sameModel, statusOf, usageRecordOf } from "../adapters/recording-client.ts";
import { RETRY_DELAYS_MS, jittered, sleep as realSleep } from "../concurrency.ts";
import { DEFAULT_JUDGE_MODEL, FALLBACK_BETA, FALLBACK_MODEL, NO_EFFORT_PREFIX } from "../models.ts";
import type { AdapterAnswer, EvalCase, Judge, JudgeOutcome, UsageRecord } from "../types.ts";
import { RUBRIC, RUBRIC_VERSION, buildJudgeUser } from "./prompt.ts";
import { JUDGE_SCHEMA, parseJudge } from "./schema.ts";

export { DEFAULT_JUDGE_MODEL, FALLBACK_BETA };
export const DEFAULT_JUDGE_EFFORT = "low";
export const JUDGE_EFFORTS = ["low", "medium", "high"] as const;
export type JudgeEffort = (typeof JUDGE_EFFORTS)[number];
export const JUDGE_MAX_TOKENS = 2048;
export const JUDGE_RETRY_MAX_TOKENS = 4096;
/** 採点は同時 4 に固定（最初の 1 件の後） */
export const JUDGE_CONCURRENCY = 4;
export const SAME_MODEL_NOTE = "答えと採点が同じモデルです。自分の答えを甘く採点する傾向があるため、--judge-model で別のモデルを選ぶことをおすすめします。";

/** 採点に使う client の形。本物は createJudgeClient、検査は偽物 */
export interface JudgeClientLike {
  messages: { create(params: any): Promise<any> };
  beta: { messages: { create(params: any): Promise<any> } };
}

/** 本物の SDK に触る唯一の場所。やり直しはこちらで数えるので、SDK のやり直しは切る */
export function createJudgeClient(apiKey: string): JudgeClientLike {
  const client = new Anthropic({ apiKey, maxRetries: 0 });
  return {
    messages: { create: (params: unknown) => client.messages.create(params as never) },
    beta: { messages: { create: (params: unknown) => client.beta.messages.create(params as never) } },
  };
}

export interface JudgeRequest {
  params: Record<string, unknown>;
  /** beta.messages.create で送るか（opus 5 の fallback） */
  beta: boolean;
}

export function buildJudgeRequest(model: string, effort: JudgeEffort, c: EvalCase, a: AdapterAnswer, maxTokens: number = JUDGE_MAX_TOKENS): JudgeRequest {
  const format = { type: "json_schema", schema: JUDGE_SCHEMA };
  const params: Record<string, unknown> = {
    model,
    max_tokens: maxTokens,
    system: [{ type: "text", text: RUBRIC, cache_control: { type: "ephemeral" } }],
    messages: [{ role: "user", content: buildJudgeUser(c, a) }],
    // haiku 4.5 は effort を受けないので送らない。thinking は付けない（sonnet 5 は既定で adaptive）
    output_config: model.startsWith(NO_EFFORT_PREFIX) ? { format } : { effort, format },
  };
  if (model === FALLBACK_MODEL) return { params: { ...params, betas: [FALLBACK_BETA], fallbacks: "default" }, beta: true };
  return { params, beta: false };
}

/** どの問いでも同じく失敗する状態（名前の誤り・廃止・鍵・権限）。最初の 1 件がこれなら、残りの採点は送らない（run.ts） */
const FATAL_HINTS: Record<number, string> = {
  401: "鍵（ANTHROPIC_API_KEY）をご確認ください。",
  403: "鍵（ANTHROPIC_API_KEY）でこのモデルを使えるか、Console の設定をご確認ください。",
  404: "採点のモデル名（--judge-model）が正しいか、廃止されていないかをご確認ください。",
};

/** やり直すまでの待ちの上限（retry-after がこれより長くても、ここで止める） */
export const RETRY_AFTER_MAX_MS = 60_000;

/** 応答の retry-after-ms（ミリ秒）か retry-after（秒）。無い・読めないときは null（決まった待ちを使う） */
export function retryAfterMs(error: unknown): number | null {
  const headers = (error as { headers?: unknown } | null)?.headers;
  const get = (name: string): string | null => {
    if (headers instanceof Headers) return headers.get(name);
    const value = headers !== null && typeof headers === "object" ? (headers as Record<string, unknown>)[name] : undefined;
    return typeof value === "string" ? value : null;
  };
  const ms = Number(get("retry-after-ms") ?? NaN);
  const seconds = Number(get("retry-after") ?? NaN);
  const wait = Number.isFinite(ms) && ms >= 0 ? ms : Number.isFinite(seconds) && seconds >= 0 ? seconds * 1000 : null;
  return wait === null ? null : Math.min(wait, RETRY_AFTER_MAX_MS);
}

function textOf(message: any): string {
  return (message?.content ?? []).filter((block: any) => block?.type === "text").map((block: any) => String(block.text ?? "")).join("");
}

/** fallback が走った（予備のモデルが答えた）か。そのときはモデル違いとしない */
function fellBack(message: any): boolean {
  return (message?.usage?.iterations ?? []).some((entry: any) => entry?.type === "fallback_message");
}

export interface ClaudeJudgeOptions {
  client: JudgeClientLike;
  model: string;
  effort: JudgeEffort;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
}

export function createClaudeJudge(options: ClaudeJudgeOptions): Judge {
  const sleep = options.sleep ?? realSleep;
  const random = options.random ?? Math.random;

  async function send(request: JudgeRequest): Promise<any> {
    for (let attempt = 0; ; attempt += 1) {
      try {
        return request.beta ? await options.client.beta.messages.create(request.params) : await options.client.messages.create(request.params);
      } catch (error) {
        if (!isRetryable(error) || attempt >= RETRY_DELAYS_MS.length) throw error;
        await sleep(retryAfterMs(error) ?? jittered(RETRY_DELAYS_MS[attempt], random));
      }
    }
  }

  return {
    info: { mode: "claude", model: options.model, effort: options.effort, rubricVersion: RUBRIC_VERSION },
    async judge(c: EvalCase, a: AdapterAnswer): Promise<JudgeOutcome> {
      const usage: UsageRecord[] = [];
      let raw: string | null = null;
      let problem = "";
      // JSON が壊れた・max_tokens・refusal なら、max_tokens を 4096 にして 1 回だけやり直す
      for (const maxTokens of [JUDGE_MAX_TOKENS, JUDGE_RETRY_MAX_TOKENS]) {
        let message: any;
        try {
          message = await send(buildJudgeRequest(options.model, options.effort, c, a, maxTokens));
        } catch (error) {
          const status = statusOf(error);
          const hint = status === null ? undefined : FATAL_HINTS[status];
          const text = `採点の呼び出しが失敗しました（${status === null ? "接続の切れ" : `HTTP ${status}`}）。${hint ?? ""}`;
          return hint === undefined ? { ok: false, error: text, usage, raw } : { ok: false, error: text, usage, raw, fatal: true };
        }
        const model = typeof message?.model === "string" ? message.model : options.model;
        usage.push(usageRecordOf(model, message?.usage));
        if (!sameModel(options.model, model) && !fellBack(message)) {
          return { ok: false, error: `採点のモデル（${model}）が、頼んだモデル（${options.model}）と違います。`, usage, raw };
        }
        raw = textOf(message);
        if (message?.stop_reason === "max_tokens" || message?.stop_reason === "refusal") {
          problem = `採点が途中で止まりました（stop_reason: ${message.stop_reason}）。`;
          continue;
        }
        const parsed = parseJudge(raw, c.points.length, c.forbidden.length, a.answer);
        if (parsed.ok) return { ok: true, judgment: parsed.judgment, usage, raw };
        problem = parsed.error;
      }
      return { ok: false, error: problem, usage, raw };
    },
  };
}
