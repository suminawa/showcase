import { existsSync, readFileSync, realpathSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { parseEnv } from "node:util";

/** 自分が「直接起動されたファイル」かどうか。npx の bin はシンボリックリンクなので実体のパスで比べる */
export function isMainModule(argv1: string | undefined, selfUrl: string): boolean {
  if (argv1 === undefined) return false;
  try {
    return realpathSync(argv1) === realpathSync(fileURLToPath(selfUrl));
  } catch {
    return false;
  }
}

/** 読む順。.env.local があればそれだけ、無ければ .env（Next.js の手元と同じ置き場） */
export const ENV_FILES = [".env.local", ".env"] as const;

/**
 * dir の .env.local（無ければ .env）を env に足す。すでに入っている環境変数が優先（上書きしない）。
 * 読んだファイル名を返し、どちらも無ければ null
 */
export function loadEnvFile(dir: string, env: Record<string, string | undefined>): string | null {
  for (const name of ENV_FILES) {
    const path = join(dir, name);
    if (!existsSync(path)) continue;
    for (const [key, value] of Object.entries(parseEnv(readFileSync(path, "utf8")))) {
      if (env[key] === undefined) env[key] = value;
    }
    return name;
  }
  return null;
}
