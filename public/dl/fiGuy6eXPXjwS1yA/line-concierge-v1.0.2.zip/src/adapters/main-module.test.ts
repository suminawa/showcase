import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { isMainModule, loadEnvFile } from "./main-module";

describe("isMainModule", () => {
  it("同じファイルなら true、違えば false、無ければ false", () => {
    const self = new URL(import.meta.url);
    expect(isMainModule(self.pathname, import.meta.url)).toBe(true);
    expect(isMainModule("/no/such/file.js", import.meta.url)).toBe(false);
    expect(isMainModule(undefined, import.meta.url)).toBe(false);
  });
});

describe("loadEnvFile", () => {
  it(".env.local を読み、すでにある環境変数は上書きしない。.env.local があれば .env は読まない", async () => {
    const dir = await mkdtemp(join(tmpdir(), "line-env-"));
    await writeFile(join(dir, ".env.local"), '# 手元の鍵\nLINE_CHANNEL_SECRET=from-file\nANTHROPIC_API_KEY="quoted"\n');
    await writeFile(join(dir, ".env"), "LINE_CHANNEL_ACCESS_TOKEN=from-dotenv\n");
    const env: Record<string, string | undefined> = { LINE_CHANNEL_SECRET: "from-shell" };
    expect(loadEnvFile(dir, env)).toBe(".env.local");
    expect(env).toEqual({ LINE_CHANNEL_SECRET: "from-shell", ANTHROPIC_API_KEY: "quoted" });
  });

  it(".env.local が無ければ .env、どちらも無ければ null で何もしない", async () => {
    const dir = await mkdtemp(join(tmpdir(), "line-env-"));
    const env: Record<string, string | undefined> = {};
    expect(loadEnvFile(dir, env)).toBeNull();
    expect(env).toEqual({});
    await writeFile(join(dir, ".env"), "LINE_CHANNEL_ACCESS_TOKEN=from-dotenv\n");
    expect(loadEnvFile(dir, env)).toBe(".env");
    expect(env.LINE_CHANNEL_ACCESS_TOKEN).toBe("from-dotenv");
  });
});
