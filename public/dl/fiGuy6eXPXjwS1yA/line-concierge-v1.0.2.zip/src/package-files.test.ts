import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

type TgzRefs = {
  checkTgzRefs: (dir: string, expected: { coreTgz: string; selfTgz?: string; vendorDirs?: boolean }) => string[];
};
async function loadTgzRefs(): Promise<TgzRefs> {
  const url = new URL("../scripts/tgz-refs.mjs", import.meta.url).href;
  return (await import(url)) as TgzRefs;
}

describe("package.json", () => {
  it("名前・bin・files・core への依存が揃っている", async () => {
    const pkg = JSON.parse(await readFile("package.json", "utf8")) as {
      name: string;
      version: string;
      bin: Record<string, string>;
      files: string[];
      peerDependencies: Record<string, string>;
      devDependencies: Record<string, string>;
      dependencies?: Record<string, string>;
    };
    expect(pkg.name).toBe("@suminawa/line-concierge");
    expect(pkg.version).toBe("1.0.2");
    expect(pkg.bin["line-concierge"]).toBe("./dist/cli.js");
    expect(pkg.files).toEqual(["dist", "README.ja.md", "LICENSE.md"]);
    expect(pkg.peerDependencies["@suminawa/ai-concierge"]).toBe("1.0.0");
    expect(pkg.devDependencies["@suminawa/ai-concierge"]).toBe("file:./vendor/suminawa-ai-concierge-1.0.0.tgz");
    expect(pkg.dependencies).toBeUndefined();
  });
  it("キットとテンプレが、同じ版の core の tgz と、キット自身の版の tgz を指している", async () => {
    const pkg = JSON.parse(await readFile("package.json", "utf8")) as {
      version: string;
      peerDependencies: Record<string, string>;
    };
    const { checkTgzRefs } = await loadTgzRefs();
    const coreTgz = `suminawa-ai-concierge-${pkg.peerDependencies["@suminawa/ai-concierge"]}.tgz`;
    const selfTgz = `suminawa-line-concierge-${pkg.version}.tgz`;
    expect(checkTgzRefs(".", { coreTgz, selfTgz })).toEqual([]);
  });
  it("vendor-core.mjs と release.mjs は、指し先と作った tgz の版がずれていたら止まる", async () => {
    for (const name of ["scripts/vendor-core.mjs", "scripts/release.mjs"]) {
      expect(await readFile(name, "utf8")).toContain("assertTgzRefs(");
    }
    const { checkTgzRefs } = await loadTgzRefs();
    const dir = await mkdtemp(join(tmpdir(), "line-tgz-"));
    try {
      await mkdir(join(dir, "templates/nextjs/vendor"), { recursive: true });
      await mkdir(join(dir, "vendor"), { recursive: true });
      await writeFile(
        join(dir, "package.json"),
        JSON.stringify({
          version: "1.0.0",
          peerDependencies: { "@suminawa/ai-concierge": "1.0.0" },
          devDependencies: { "@suminawa/ai-concierge": "file:./vendor/suminawa-ai-concierge-1.0.0.tgz" },
        }),
      );
      await writeFile(
        join(dir, "templates/nextjs/package.json"),
        JSON.stringify({
          dependencies: {
            "@suminawa/ai-concierge": "file:./vendor/suminawa-ai-concierge-1.0.0.tgz",
            "@suminawa/line-concierge": "file:./vendor/suminawa-line-concierge-1.0.0.tgz",
          },
        }),
      );
      const ok = { coreTgz: "suminawa-ai-concierge-1.0.0.tgz", selfTgz: "suminawa-line-concierge-1.0.0.tgz" };
      expect(checkTgzRefs(dir, ok)).toEqual([]);
      // core を 1.0.2 で詰めたのに、キットとテンプレが 1.0.0 を指したまま（1.0.1 の zip で起きたこと）
      const drift = checkTgzRefs(dir, { ...ok, coreTgz: "suminawa-ai-concierge-1.0.2.tgz" });
      expect(drift).toHaveLength(3);
      expect(drift.join("\n")).toContain("devDependencies");
      expect(drift.join("\n")).toContain("templates/nextjs/package.json");
      expect(drift.join("\n")).toContain("peerDependencies");
      // キット自身の tgz の版がずれている
      expect(checkTgzRefs(dir, { ...ok, selfTgz: "suminawa-line-concierge-1.0.1.tgz" })).toHaveLength(1);
      // 古い版の tgz が vendor に残っている（zip に入ってしまう）
      await writeFile(join(dir, "vendor/suminawa-ai-concierge-0.9.0.tgz"), "");
      await writeFile(join(dir, "vendor/suminawa-ai-concierge-1.0.0.tgz"), "");
      expect(checkTgzRefs(dir, ok)).toEqual([]);
      expect(checkTgzRefs(dir, { ...ok, vendorDirs: true })).toEqual([
        "vendor/suminawa-ai-concierge-0.9.0.tgz は古い版の tgz。消してから",
      ]);
      // package-lock.json の integrity が vendor の tgz の中身と合わない（1.0.0 の zip で、まっさらな npm install が止まった）
      await rm(join(dir, "vendor/suminawa-ai-concierge-0.9.0.tgz"));
      const lock = (integrity: string) =>
        writeFile(join(dir, "package-lock.json"), JSON.stringify({ packages: { "node_modules/@suminawa/ai-concierge": { integrity } } }));
      await lock("sha512-old");
      expect(checkTgzRefs(dir, { ...ok, vendorDirs: true })[0]).toContain("integrity が vendor/suminawa-ai-concierge-1.0.0.tgz と合わない");
      // 空のファイルの sha512
      await lock("sha512-z4PhNX7vuL3xVChQ1m2AB9Yg5AULVxXcg/SpIdNs6c5H0NE8XYXysP+DGNKHfuwvY7kxvUdBeoGlODJ6+SfaPg==");
      expect(checkTgzRefs(dir, { ...ok, vendorDirs: true })).toEqual([]);
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  });
  it("release.mjs は 2 つの tgz を入れ、node_modules を入れない", async () => {
    const script = await readFile("scripts/release.mjs", "utf8");
    expect(script).toContain("vendor-core.mjs");
    expect(script).toContain("templates/nextjs/vendor");
    expect(script).toContain("*/node_modules/*");
    expect(script).toContain("line-concierge-v");
  });
});
