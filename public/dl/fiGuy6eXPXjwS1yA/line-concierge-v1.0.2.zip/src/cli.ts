import { indexSummary, loadConfigFile, loadIndex, type LoadedIndex } from "@suminawa/ai-concierge";
import { isMainModule, loadEnvFile } from "./adapters/main-module";
import { createLineBot } from "./core/bot";
import { resolveLineConfig } from "./core/config";
import { createFakeClient } from "./core/fake-client";
import { createLineApi } from "./core/line-api";
import { createMemoryStore } from "./core/store";
import type { LineApi, LineConfig } from "./core/types";

export const USAGE = `使い方:
  line-concierge check                       設定・索引・環境変数・LINE のトークン・モデル名を確かめます（答えは作らせません）
  line-concierge simulate --question "…"     LINE を呼ばずに、返すはずのメッセージを JSON で出します
      [--user U1] [--follow] [--config concierge.config.json]
  LINE_FAKE=1 を付けると Claude も呼ばず、決まった答えで動きを見られます
  起動したフォルダの .env.local（無ければ .env）を読みます。すでに入っている環境変数が優先です`;

export interface CliIo {
  log: (message: string) => void;
  error: (message: string) => void;
  env: Record<string, string | undefined>;
  fetchImpl?: typeof fetch;
  /** 起動時に読んだ環境変数のファイル（.env.local / .env）。null なら無かった。省略時は check で触れない */
  envFile?: string | null;
}

export interface CliOptions {
  command: "check" | "simulate" | "help";
  question: string | null;
  user: string;
  follow: boolean;
  configPath: string;
}

export function parseArgs(argv: string[]): CliOptions {
  const options: CliOptions = { command: "help", question: null, user: "U-simulate", follow: false, configPath: "concierge.config.json" };
  const [first, ...rest] = argv;
  if (first === "check" || first === "simulate") options.command = first;
  else return options;
  for (let i = 0; i < rest.length; i += 1) {
    const arg = rest[i];
    if (arg === "--question") options.question = rest[++i] ?? null;
    else if (arg === "--user") options.user = rest[++i] ?? options.user;
    else if (arg === "--config") options.configPath = rest[++i] ?? options.configPath;
    else if (arg === "--follow") options.follow = true;
  }
  return options;
}

/** LINE を呼ばない偽物。simulate で使う */
export function fakeLineApi(): LineApi & { calls: string[] } {
  const calls: string[] = [];
  return {
    calls,
    async reply(replyToken) {
      calls.push(`reply ${replyToken}`);
    },
    async loading(chatId) {
      calls.push(`loading ${chatId}`);
    },
    async profile() {
      return null;
    },
    async info() {
      return { basicId: "", displayName: "" };
    },
  };
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export const ANTHROPIC_MODELS_URL = "https://api.anthropic.com/v1/models/";

/**
 * answer.model がいまも使えるかを Models API で確かめる（答えは作らないので費用はかからない）。
 * 提供が終わったモデルのままだと、起動後にすべてのご質問が「いまはお答えできません」になるため、起動前に止める
 */
async function checkModel(apiKey: string, model: string, fetchImpl: typeof fetch): Promise<{ ok: boolean; message: string }> {
  let res: Response;
  try {
    res = await fetchImpl(`${ANTHROPIC_MODELS_URL}${encodeURIComponent(model)}`, {
      headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      signal: AbortSignal.timeout(10_000),
    });
  } catch (error) {
    return { ok: true, message: `answer.model: 確かめられませんでした（${messageOf(error)}）。通信できる所でもう一度お試しください` };
  }
  if (res.ok) return { ok: true, message: `answer.model: OK（${model}）` };
  if (res.status === 404) {
    return {
      ok: false,
      message: `answer.model: 「${model}」が見つかりません。提供が終わったか、名前が違います。concierge.config.json の answer.model を、Anthropic のモデルの一覧にある名前に変えてください`,
    };
  }
  if (res.status === 401 || res.status === 403) {
    return { ok: false, message: `ANTHROPIC_API_KEY: 通りません（${res.status}）。Anthropic Console で鍵を確かめてください` };
  }
  return { ok: true, message: `answer.model: 確かめられませんでした（${res.status}）。しばらくしてからもう一度お試しください` };
}

async function check(config: LineConfig, index: LoadedIndex, io: CliIo): Promise<number> {
  let failed = false;
  io.log(`設定ファイル: OK（${config.concierge.site.name}）`);
  io.log(`索引: OK（${indexSummary(index)}）`);
  if (io.envFile !== undefined) {
    io.log(
      io.envFile === null
        ? "環境変数のファイル: なし（.env.local も .env も見つからないので、環境変数だけを見ます）"
        : `環境変数のファイル: ${io.envFile} を読みました（すでに入っている環境変数が優先）`,
    );
  }
  if (config.concierge.apiKey === null) {
    io.log("ANTHROPIC_API_KEY: ありません（必須）");
    failed = true;
  } else {
    io.log("ANTHROPIC_API_KEY: 設定済み");
    const model = await checkModel(config.concierge.apiKey, config.concierge.answer.model, io.fetchImpl ?? fetch);
    io.log(model.message);
    if (!model.ok) failed = true;
  }
  if (config.secrets.channelSecret === null) {
    io.log("LINE_CHANNEL_SECRET: ありません（必須）");
    failed = true;
  } else io.log("LINE_CHANNEL_SECRET: 設定済み");
  if (config.secrets.channelAccessToken === null) {
    io.log("LINE_CHANNEL_ACCESS_TOKEN: ありません（必須）");
    failed = true;
  } else {
    try {
      const info = await createLineApi(config.secrets.channelAccessToken, io.fetchImpl ?? fetch).info();
      io.log(`LINE_CHANNEL_ACCESS_TOKEN: OK（${info.displayName} ${info.basicId}）`);
    } catch (error) {
      io.log(`LINE_CHANNEL_ACCESS_TOKEN: 通りません（${messageOf(error)}）。長期のチャネルアクセストークンを発行し直してください`);
      failed = true;
    }
  }
  io.log(`HANDOFF_WEBHOOK_URL: ${config.secrets.handoffWebhookUrl === null ? "ありません（任意。引き継ぎの通知は送られません）" : "設定済み"}`);
  io.log(`会話の保存先: ${config.secrets.upstashUrl === null ? "メモリ（Upstash の設定なし）" : "Upstash Redis"}`);
  io.log(`引き継ぎの言葉: ${config.line.handoff.keywords.join(" / ")}`);
  io.log(`候補のボタン: ${config.line.suggestions.length} 個`);
  io.log(failed ? "足りないものがあります。上の「必須」を入れてから、もう一度お試しください。" : "すべて揃っています。");
  return failed ? 1 : 0;
}

async function simulate(config: LineConfig, index: LoadedIndex, options: CliOptions, io: CliIo): Promise<number> {
  const fake = io.env.LINE_FAKE === "1";
  if (!fake && config.concierge.apiKey === null) {
    io.error("ANTHROPIC_API_KEY がありません。鍵を入れるか、LINE_FAKE=1 を付けてください。");
    return 1;
  }
  const bot = createLineBot(config, {
    index,
    client: fake ? createFakeClient() : undefined,
    lineApi: fakeLineApi(),
    store: createMemoryStore(),
    fetch: io.fetchImpl,
    logger: (message) => io.error(message),
  });
  if (options.follow) {
    io.log(JSON.stringify({ event: "follow", messages: bot.greet() }, null, 2));
    return 0;
  }
  if (options.question === null) {
    io.error("--question を付けてください。");
    return 1;
  }
  const outcome = await bot.simulate(options.user, options.question);
  io.log(JSON.stringify({ question: options.question, reason: outcome.reason, answered: outcome.answered, messages: outcome.messages }, null, 2));
  return 0;
}

export async function run(argv: string[], io: CliIo): Promise<number> {
  const options = parseArgs(argv);
  if (options.command === "help") {
    io.log(USAGE);
    return 0;
  }
  let config: LineConfig;
  try {
    config = resolveLineConfig({ file: await loadConfigFile(options.configPath), env: io.env });
  } catch (error) {
    io.error(`設定: ${messageOf(error)}`);
    return 1;
  }
  let index: LoadedIndex;
  try {
    index = await loadIndex(config.concierge.indexPath);
  } catch (error) {
    io.error(`索引: ${messageOf(error)}`);
    return 1;
  }
  return options.command === "check" ? check(config, index, io) : simulate(config, index, options, io);
}

if (isMainModule(process.argv[1], import.meta.url)) {
  const envFile = loadEnvFile(process.cwd(), process.env);
  void run(process.argv.slice(2), { log: console.log, error: console.error, env: process.env, envFile }).then((code) => process.exit(code));
}
