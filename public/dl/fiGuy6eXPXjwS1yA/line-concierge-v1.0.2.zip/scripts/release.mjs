#!/usr/bin/env node
// 配布 zip を release/ に作る。買い手が Node サーバーでも Next.js テンプレでも動かせるよう、
// キットの根の vendor/（core の tgz）と templates/nextjs/vendor/（core とキットの tgz）を入れる。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";
import { assertTgzRefs } from "./tgz-refs.mjs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/line-concierge-v${pkg.version}.zip`;

for (const file of ["dist/index.js", "dist/index.cjs", "dist/cli.js", "dist/adapters/node.js"]) {
  if (!existsSync(file)) {
    console.error(`${file} が無い。先に npm run build`);
    process.exit(1);
  }
}
if (!existsSync("samples/content/about.md")) {
  console.error("samples が無い。リポジトリの取り込み漏れ");
  process.exit(1);
}

// core の tgz を vendor/ と templates/nextjs/vendor/ に置き直す（scripts/vendor-core.mjs）
execFileSync("node", ["scripts/vendor-core.mjs"], { stdio: "inherit" });
// キット自身の tgz をテンプレの vendor に置く
execFileSync("npm", ["pack", "--pack-destination", "templates/nextjs/vendor"], { stdio: "inherit" });
const selfTgz = `templates/nextjs/vendor/${pkg.name.replace(/^@/, "").replace(/\//g, "-")}-${pkg.version}.tgz`;
if (!existsSync(selfTgz)) {
  console.error(`${selfTgz} が無い`);
  process.exit(1);
}

// 2 つの tgz を、キットとテンプレの package.json がそのまま指しているか（vendor-core.mjs でも見ている）。
// 古い版の tgz が vendor に残っていても zip に入ってしまうので、それも止める
// 同梱する core の版はキットの peerDependencies で決まる（vendor-core.mjs と同じ）
const coreTgz = `suminawa-ai-concierge-${pkg.peerDependencies["@suminawa/ai-concierge"]}.tgz`;
if (!existsSync(`vendor/${coreTgz}`) || !existsSync(`templates/nextjs/vendor/${coreTgz}`)) {
  console.error(`vendor/${coreTgz} か templates/nextjs/vendor/${coreTgz} が無い`);
  process.exit(1);
}
assertTgzRefs(".", { coreTgz, selfTgz: selfTgz.replace("templates/nextjs/vendor/", ""), vendorDirs: true });

mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

execFileSync(
  "zip",
  [
    "-r",
    out,
    "dist",
    "src",
    "test",
    "templates",
    "samples",
    "scripts",
    "vendor",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "tsup.config.ts",
    "vitest.config.ts",
    ".gitignore",
    "README.ja.md",
    "LICENSE.md",
    "CHANGELOG.md",
    "-x",
    "*.DS_Store",
    "-x",
    "*/node_modules/*",
    "-x",
    "*/.next/*",
    "-x",
    "vendor/.gitignore",
    "-x",
    "templates/nextjs/vendor/.gitignore",
    "-x",
    "*/.vercel/*",
    "-x",
    "templates/nextjs/data/*",
    // 手元の鍵を zip に入れない
    "-x",
    "*.env",
    "-x",
    "*.env.local",
  ],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
