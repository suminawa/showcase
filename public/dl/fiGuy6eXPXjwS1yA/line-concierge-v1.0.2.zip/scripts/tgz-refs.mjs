// キットの package.json とテンプレの package.json が、いま作った（作る）tgz を指しているかを見る。
// 案内窓口キット 1.0.1 の zip で、テンプレが 1.0.0 の tgz を指したまま出して npm install が
// 通らなかったことがある。vendor-core.mjs と release.mjs は、ずれていたら zip を作らずに止まる。
import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const CORE = "@suminawa/ai-concierge";
const SELF = "@suminawa/line-concierge";

/**
 * @param {string} dir キットの根（package.json と templates/nextjs/package.json がある所）
 * @param {{ coreTgz: string, selfTgz?: string, vendorDirs?: boolean }} expected いま置いた tgz のファイル名。
 *   vendorDirs が true なら、vendor/ と templates/nextjs/vendor/ に別の版の tgz が残っていないかと、
 *   package-lock.json の core の integrity が vendor/ の tgz の中身と合っているかも見る
 *   （合わないと、まっさらな手元の npm install が EINTEGRITY で止まる。1.0.0 の zip で起きたこと）
 * @returns {string[]} ずれの説明。空ならずれていない
 */
export function checkTgzRefs(dir, { coreTgz, selfTgz, vendorDirs = false }) {
  const problems = [];
  const pkg = JSON.parse(readFileSync(join(dir, "package.json"), "utf8"));
  const template = JSON.parse(readFileSync(join(dir, "templates/nextjs/package.json"), "utf8"));
  const expect = (where, actual, tgz) => {
    const want = `file:./vendor/${tgz}`;
    if (actual !== want) problems.push(`${where} が ${actual ?? "（なし）"} を指している。${want} に合わせてから`);
  };
  expect(`package.json の devDependencies["${CORE}"]`, pkg.devDependencies?.[CORE], coreTgz);
  expect(`templates/nextjs/package.json の dependencies["${CORE}"]`, template.dependencies?.[CORE], coreTgz);
  const coreVersion = coreTgz.match(/-(\d+\.\d+\.\d+)\.tgz$/)?.[1];
  if (pkg.peerDependencies?.[CORE] !== coreVersion) {
    problems.push(`package.json の peerDependencies["${CORE}"] が ${pkg.peerDependencies?.[CORE] ?? "（なし）"}。${coreVersion} に合わせてから`);
  }
  if (selfTgz) expect(`templates/nextjs/package.json の dependencies["${SELF}"]`, template.dependencies?.[SELF], selfTgz);
  if (vendorDirs) {
    const allowed = { vendor: [coreTgz], "templates/nextjs/vendor": [coreTgz, selfTgz] };
    for (const [sub, names] of Object.entries(allowed)) {
      const path = join(dir, sub);
      if (!existsSync(path)) continue;
      for (const name of readdirSync(path)) {
        if (name.endsWith(".tgz") && !names.includes(name)) problems.push(`${sub}/${name} は古い版の tgz。消してから`);
      }
    }
    const lockPath = join(dir, "package-lock.json");
    const tgzPath = join(dir, "vendor", coreTgz);
    if (existsSync(lockPath) && existsSync(tgzPath)) {
      const locked = JSON.parse(readFileSync(lockPath, "utf8")).packages?.[`node_modules/${CORE}`]?.integrity;
      const actual = `sha512-${createHash("sha512").update(readFileSync(tgzPath)).digest("base64")}`;
      if (locked !== actual) {
        problems.push(`package-lock.json の ${CORE} の integrity が vendor/${coreTgz} と合わない（${locked ?? "なし"}）。${actual} に合わせてから`);
      }
    }
  }
  return problems;
}

/** ずれがあれば理由を出して止める */
export function assertTgzRefs(dir, expected) {
  const problems = checkTgzRefs(dir, expected);
  if (problems.length > 0) {
    for (const p of problems) console.error(p);
    console.error("tgz の版と package.json の指し先がずれているので、作るのを止めました");
    process.exit(1);
  }
}
