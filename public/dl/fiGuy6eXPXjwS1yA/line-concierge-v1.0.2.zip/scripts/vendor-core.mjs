#!/usr/bin/env node
// 案内窓口キット（../ai-concierge）の tgz を vendor/ と templates/nextjs/vendor/ に置く（vendor/ に無ければ npm pack で作る）。
// このキットは core を tgz から取り込む（package.json の devDependencies と、テンプレの dependencies）。
import { execFileSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync } from "node:fs";
import { resolve } from "node:path";
import { assertTgzRefs } from "./tgz-refs.mjs";

const core = resolve("../ai-concierge");
const pkg = JSON.parse(readFileSync(resolve(core, "package.json"), "utf8"));
// 同梱する core の版は、このキットの peerDependencies で決める（隣の ../ai-concierge が先の版に進んでいても、
// 買い手に渡した core の版と中身を変えない）
const kit = JSON.parse(readFileSync("package.json", "utf8"));
const pinned = kit.peerDependencies?.["@suminawa/ai-concierge"];
const tgz = `${pkg.name.replace(/^@/, "").replace(/\//g, "-")}-${pinned}.tgz`;

// このキットとテンプレが指している core の tgz が、同梱する tgz と同じ版か。
// ずれたまま置くと、買い手の npm install が通らない zip ができる
assertTgzRefs(".", { coreTgz: tgz });

mkdirSync("vendor", { recursive: true });
const packed = resolve("vendor", tgz);
// 固定した版の tgz がすでにあれば作り直さない（作り直すと中身のハッシュが変わり、package-lock.json の integrity と合わなくなる）
if (!existsSync(packed)) {
  if (pkg.version !== pinned) {
    console.error(
      `../ai-concierge は ${pkg.version}、このキットは core ${pinned} を同梱する。vendor/${tgz} を置くか、指し先と peerDependencies を ${pkg.version} に合わせてから`,
    );
    process.exit(1);
  }
  if (!existsSync(resolve(core, "node_modules"))) {
    console.error(`${core} に node_modules がありません。先に core で npm install を実行してください`);
    process.exit(1);
  }
  // dist が無ければ core を build する（tgz には dist が入る）
  if (!existsSync(resolve(core, "dist/index.js")) || !existsSync(resolve(core, "dist/cli.js"))) {
    execFileSync("npm", ["run", "build"], { cwd: core, stdio: "inherit" });
  }
  // core のテンプレの vendor に古い tgz が残っていると、tgz の中に tgz が入れ子になる。先に消す
  const coreVendor = resolve(core, "templates/nextjs/vendor");
  if (existsSync(coreVendor)) {
    for (const name of readdirSync(coreVendor)) if (name.endsWith(".tgz")) rmSync(resolve(coreVendor, name));
  }
  execFileSync("npm", ["pack", "--pack-destination", resolve("vendor")], { cwd: core, stdio: "inherit" });
  if (!existsSync(packed)) {
    console.error(`${packed} ができていません`);
    process.exit(1);
  }
}
const listing = execFileSync("tar", ["-tzf", packed], { encoding: "utf8" });
if (listing.split("\n").some((line) => line.endsWith(".tgz"))) {
  console.error("core の tgz の中に tgz が入れ子になっています。core の templates/nextjs/vendor を空にしてやり直してください");
  process.exit(1);
}
mkdirSync("templates/nextjs/vendor", { recursive: true });
copyFileSync(packed, resolve("templates/nextjs/vendor", tgz));
console.log(`vendor/${tgz} と templates/nextjs/vendor/${tgz} を置きました`);
