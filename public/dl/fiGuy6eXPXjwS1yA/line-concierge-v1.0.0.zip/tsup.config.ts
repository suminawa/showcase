import { defineConfig } from "tsup";

const external = ["@suminawa/ai-concierge", "@anthropic-ai/sdk"];

export default defineConfig([
  // 1) npm と Next.js から使う部品と、Node サーバー
  {
    entry: { index: "src/index.ts", "adapters/node": "src/adapters/node.ts" },
    format: ["esm", "cjs"],
    dts: { entry: { index: "src/index.ts" } },
    sourcemap: false,
    clean: true,
    target: "node22",
    platform: "node",
    external,
    // adapters/node.ts の import.meta.url を cjs 出力でも使えるようにする
    shims: true,
    // 分割しない。分割すると dist/adapters/node.js の中身が dist/chunk-*.js に移り、
    // import.meta.url が chunk のパスになって「直接起動されたか」の判定が外れる（main() が動かない）
    splitting: false,
  },
  // 2) check / simulate のコマンド
  {
    entry: { cli: "src/cli.ts" },
    format: ["esm"],
    sourcemap: false,
    target: "node22",
    platform: "node",
    external,
    banner: { js: "#!/usr/bin/env node" },
  },
]);
