# CHANGELOG

## 1.0.0 — 2026-09-29

- 初版。LINE 公式アカウントの Webhook を受け、案内窓口キットの答える部品で敬体で答え、参考の URL と候補のボタンを付けて返信します。
- 担当者への引き継ぎ（言葉で判定、24 時間 AI が黙る、Slack へ通知）。
- 会話の記憶（直近 6 往復・1 時間。メモリ / Upstash Redis）。
- 1 人 1 日・全体 1 日の上限、署名の確認、再送の除外。
- `line-concierge check` と `simulate`、Next.js テンプレ（Vercel）、Node サーバー。
