#!/usr/bin/env node
// 案内窓口キット（../ai-concierge）を npm pack して、vendor/ と templates/nextjs/vendor/ に置く。
// このキットは core を tgz から取り込む（package.json の devDependencies と、テンプレの dependencies）。
import { execFileSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync } from "node:fs";
import { resolve } from "node:path";

const core = resolve("../ai-concierge");
const pkg = JSON.parse(readFileSync(resolve(core, "package.json"), "utf8"));
const tgz = `${pkg.name.replace(/^@/, "").replace(/\//g, "-")}-${pkg.version}.tgz`;

if (!existsSync(resolve(core, "node_modules"))) {
  console.error(`${core} に node_modules がありません。先に core で npm install を実行してください`);
  process.exit(1);
}
// dist が無ければ core を build する（tgz には dist が入る）
if (!existsSync(resolve(core, "dist/index.js")) || !existsSync(resolve(core, "dist/cli.js"))) {
  execFileSync("npm", ["run", "build"], { cwd: core, stdio: "inherit" });
}
// core のテンプレの vendor に古い tgz が残っていると、tgz の中に tgz が入れ子になる。先に消す
const coreVendor = resolve(core, "templates/nextjs/vendor");
if (existsSync(coreVendor)) {
  for (const name of readdirSync(coreVendor)) if (name.endsWith(".tgz")) rmSync(resolve(coreVendor, name));
}

mkdirSync("vendor", { recursive: true });
execFileSync("npm", ["pack", "--pack-destination", resolve("vendor")], { cwd: core, stdio: "inherit" });
const packed = resolve("vendor", tgz);
if (!existsSync(packed)) {
  console.error(`${packed} ができていません`);
  process.exit(1);
}
const listing = execFileSync("tar", ["-tzf", packed], { encoding: "utf8" });
if (listing.split("\n").some((line) => line.endsWith(".tgz"))) {
  console.error("core の tgz の中に tgz が入れ子になっています。core の templates/nextjs/vendor を空にしてやり直してください");
  process.exit(1);
}
mkdirSync("templates/nextjs/vendor", { recursive: true });
copyFileSync(packed, resolve("templates/nextjs/vendor", tgz));
console.log(`vendor/${tgz} と templates/nextjs/vendor/${tgz} を置きました`);
