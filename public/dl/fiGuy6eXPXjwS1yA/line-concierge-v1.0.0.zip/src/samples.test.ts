import { readdir, readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";
import { resolveLineConfig } from "./core/config";

describe("samples と templates の設定", () => {
  it("samples/concierge.config.json は line の節つきで読める", async () => {
    const file = JSON.parse(await readFile("samples/concierge.config.json", "utf8")) as Record<string, unknown>;
    const config = resolveLineConfig({ file, env: {} });
    expect(config.concierge.content).toBe("samples/content");
    expect(config.line.suggestions.length).toBeGreaterThanOrEqual(3);
    expect(config.line.greeting).toContain("みなと工務店");
    // 引き継ぎの言葉は部分一致なので、「電話」だけでは入れない（「電話番号を教えてください」を拾ってしまう）
    expect(config.line.handoff.keywords).not.toContain("電話");
    expect(config.line.handoff.keywords).toContain("電話で話");
  });
  it("samples/content には core と同じ 8 本の文書がある", async () => {
    const files = (await readdir("samples/content")).filter((name) => name.endsWith(".md")).sort();
    expect(files).toEqual(["about.md", "area.md", "contact.md", "faq.md", "flow.md", "price.md", "warranty.md", "works.md"]);
    expect(await readFile("samples/content/about.md", "utf8")).toContain("架空");
  });
  it("templates/nextjs/concierge.config.json も読める", async () => {
    const file = JSON.parse(await readFile("templates/nextjs/concierge.config.json", "utf8")) as Record<string, unknown>;
    const config = resolveLineConfig({ file, env: {} });
    expect(config.concierge.content).toBe("content");
    expect(config.line.handoff.keywords).toContain("担当者");
    expect(config.line.handoff.keywords).not.toContain("電話");
  });
  it("テンプレの route は after() で先に 200 を返す形", async () => {
    const route = await readFile("templates/nextjs/app/api/line/route.ts", "utf8");
    expect(route).toContain('import { after } from "next/server"');
    expect(route).toContain("after(() => work)");
    expect(route).toContain('export const maxDuration = 60');
    expect(route).toContain("createStoreFromEnv(process.env)");
  });
  it("テンプレは 2 つの tgz を指す", async () => {
    const pkg = JSON.parse(await readFile("templates/nextjs/package.json", "utf8")) as { dependencies: Record<string, string> };
    expect(pkg.dependencies["@suminawa/ai-concierge"]).toBe("file:./vendor/suminawa-ai-concierge-1.0.0.tgz");
    expect(pkg.dependencies["@suminawa/line-concierge"]).toBe("file:./vendor/suminawa-line-concierge-1.0.0.tgz");
  });
});
