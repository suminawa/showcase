import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { fakeFetch, jsonResponse } from "../test/fake-fetch";
import { fixtureIndex } from "../test/index-fixture";
import { parseArgs, run, USAGE, type CliIo } from "./cli";

// 索引の場所は core と同じく環境変数 CONCIERGE_INDEX で渡す（設定ファイルの indexPath は core が読まない）
let currentIndexPath = "";

async function workdir(): Promise<{ dir: string; configPath: string }> {
  const dir = await mkdtemp(join(tmpdir(), "line-concierge-"));
  const configPath = join(dir, "concierge.config.json");
  const indexPath = join(dir, "index.json");
  await writeFile(indexPath, JSON.stringify(fixtureIndex().file));
  await writeFile(configPath, JSON.stringify({ site: { name: "みなと工務店" }, content: dir, suggestions: ["対応エリアは"] }));
  currentIndexPath = indexPath;
  return { dir, configPath };
}

function io(env: Record<string, string> = {}, fetchImpl?: typeof fetch): CliIo & { out: string[]; err: string[] } {
  const out: string[] = [];
  const err: string[] = [];
  return { out, err, env: { CONCIERGE_INDEX: currentIndexPath, ...env }, fetchImpl, log: (m) => out.push(m), error: (m) => err.push(m) };
}

describe("parseArgs", () => {
  it("check / simulate / help と引数", () => {
    expect(parseArgs(["check"]).command).toBe("check");
    expect(parseArgs([]).command).toBe("help");
    expect(parseArgs(["--help"]).command).toBe("help");
    const sim = parseArgs(["simulate", "--question", "営業時間は", "--user", "U9", "--config", "x.json"]);
    expect(sim).toEqual({ command: "simulate", question: "営業時間は", user: "U9", follow: false, configPath: "x.json" });
    expect(parseArgs(["simulate", "--follow"]).follow).toBe(true);
    expect(parseArgs(["simulate"]).user).toBe("U-simulate");
    expect(parseArgs(["simulate"]).configPath).toBe("concierge.config.json");
  });
});

describe("run: help", () => {
  it("使い方を出して 0", async () => {
    const o = io();
    expect(await run([], o)).toBe(0);
    expect(o.out.join("\n")).toBe(USAGE);
  });
});

describe("run: check", () => {
  it("揃っていれば LINE の名前を出して 0", async () => {
    const { configPath } = await workdir();
    const net = fakeFetch([["/v2/bot/info", () => jsonResponse({ basicId: "@minato", displayName: "みなと工務店" })]]);
    const o = io({ ANTHROPIC_API_KEY: "sk", LINE_CHANNEL_SECRET: "s", LINE_CHANNEL_ACCESS_TOKEN: "t" }, net.fetch);
    expect(await run(["check", "--config", configPath], o)).toBe(0);
    const text = o.out.join("\n");
    expect(text).toContain("みなと工務店 @minato");
    expect(text).toContain("設定済み");
    expect(text).toContain("すべて揃っています");
    expect(text).not.toContain("sk");
    expect(text).not.toContain("t\n");
  });
  it("足りなければ「必須」を示して 1。トークンが通らなければ 1", async () => {
    const { configPath } = await workdir();
    const o = io({});
    expect(await run(["check", "--config", configPath], o)).toBe(1);
    expect(o.out.join("\n")).toContain("ANTHROPIC_API_KEY: ありません（必須）");
    const net = fakeFetch([["/v2/bot/info", () => new Response("Unauthorized", { status: 401 })]]);
    const o2 = io({ ANTHROPIC_API_KEY: "sk", LINE_CHANNEL_SECRET: "s", LINE_CHANNEL_ACCESS_TOKEN: "bad" }, net.fetch);
    expect(await run(["check", "--config", configPath], o2)).toBe(1);
    expect(o2.out.join("\n")).toContain("通りません");
  });
  it("設定や索引が壊れていれば 1", async () => {
    const o = io({ CONCIERGE_INDEX: "/no/such/index.json" });
    expect(await run(["check", "--config", "/no/such/concierge.config.json"], o)).toBe(1);
    expect(o.err.join("\n")).toMatch(/索引|設定/);
  });
});

describe("run: simulate", () => {
  it("LINE_FAKE=1 なら鍵なしで答えを JSON で出す", async () => {
    const { configPath } = await workdir();
    const o = io({ LINE_FAKE: "1" });
    expect(await run(["simulate", "--question", "対応エリアは", "--config", configPath], o)).toBe(0);
    const result = JSON.parse(o.out.join("\n")) as { reason: string; messages: Array<{ text: string }> };
    expect(result.reason).toBe("answered");
    expect(result.messages[0].text).toContain("市内と、隣接する三つの市");
  });
  it("--follow はあいさつを出す", async () => {
    const { configPath } = await workdir();
    const o = io({ LINE_FAKE: "1" });
    expect(await run(["simulate", "--follow", "--config", configPath], o)).toBe(0);
    expect(o.out.join("\n")).toContain('"event": "follow"');
  });
  it("鍵も LINE_FAKE も無ければ 1。--question が無ければ 1", async () => {
    const { configPath } = await workdir();
    const o = io({});
    expect(await run(["simulate", "--question", "x", "--config", configPath], o)).toBe(1);
    expect(o.err.join("\n")).toContain("LINE_FAKE=1");
    const o2 = io({ LINE_FAKE: "1" });
    expect(await run(["simulate", "--config", configPath], o2)).toBe(1);
  });
});
