import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";

describe("package.json", () => {
  it("名前・bin・files・core への依存が揃っている", async () => {
    const pkg = JSON.parse(await readFile("package.json", "utf8")) as {
      name: string;
      version: string;
      bin: Record<string, string>;
      files: string[];
      peerDependencies: Record<string, string>;
      devDependencies: Record<string, string>;
      dependencies?: Record<string, string>;
    };
    expect(pkg.name).toBe("@suminawa/line-concierge");
    expect(pkg.version).toBe("1.0.0");
    expect(pkg.bin["line-concierge"]).toBe("./dist/cli.js");
    expect(pkg.files).toEqual(["dist", "README.ja.md", "LICENSE.md"]);
    expect(pkg.peerDependencies["@suminawa/ai-concierge"]).toBe("1.0.0");
    expect(pkg.devDependencies["@suminawa/ai-concierge"]).toBe("file:./vendor/suminawa-ai-concierge-1.0.0.tgz");
    expect(pkg.dependencies).toBeUndefined();
  });
  it("core の版と vendor の tgz 名が一致している", async () => {
    const core = JSON.parse(await readFile("../ai-concierge/package.json", "utf8")) as { version: string };
    const pkg = JSON.parse(await readFile("package.json", "utf8")) as { peerDependencies: Record<string, string> };
    expect(pkg.peerDependencies["@suminawa/ai-concierge"]).toBe(core.version);
  });
  it("release.mjs は 2 つの tgz を入れ、node_modules を入れない", async () => {
    const script = await readFile("scripts/release.mjs", "utf8");
    expect(script).toContain("vendor-core.mjs");
    expect(script).toContain("templates/nextjs/vendor");
    expect(script).toContain("*/node_modules/*");
    expect(script).toContain("line-concierge-v");
  });
});
