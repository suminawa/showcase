import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";

describe("README.ja.md", () => {
  it("必須の環境変数と LINE 側の設定、確かめ方、上限が書かれている", async () => {
    const readme = await readFile("README.ja.md", "utf8");
    for (const needle of [
      "LINE_CHANNEL_SECRET",
      "LINE_CHANNEL_ACCESS_TOKEN",
      "ANTHROPIC_API_KEY",
      "HANDOFF_WEBHOOK_URL",
      "UPSTASH_REDIS_REST_URL",
      "LINE Developers",
      "応答メッセージ",
      "あいさつメッセージ",
      "検証",
      "line-concierge check",
      "simulate",
      "LINE_FAKE",
      "/api/line",
      "13 個",
      "20 字",
      "担当者",
      "hello@suminawa.dev",
      // 引き継ぎの言葉は部分一致であること（短い言葉を入れる落とし穴）
      "部分一致",
      "電話で話",
      // Node サーバーの手順
      "npm install",
      "node dist/adapters/node.js",
      "npx ai-concierge index",
      // 状態確認の道は誰でも開ける
      "/api/line/health",
      "署名を求めない",
    ]) {
      expect(readme, needle).toContain(needle);
    }
  });
  it("本物の鍵らしい文字列が無い", async () => {
    const readme = await readFile("README.ja.md", "utf8");
    expect(readme).not.toMatch(/sk-ant-[A-Za-z0-9_-]{20,}/);
    expect(readme).not.toMatch(/hooks\.slack\.com\/services\/T[A-Z0-9]{8,}/);
  });
  it("CHANGELOG と LICENSE がある", async () => {
    expect(await readFile("CHANGELOG.md", "utf8")).toContain("1.0.0");
    expect(await readFile("LICENSE.md", "utf8")).toContain("LINE 案内窓口キット");
  });
});
