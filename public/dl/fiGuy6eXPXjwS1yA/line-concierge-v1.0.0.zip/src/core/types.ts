import type { ConciergeConfig } from "@suminawa/ai-concierge";

/** 引き継ぎ（有人対応）の決めごと */
export interface HandoffSettings {
  /** この言葉を含む文が来たら担当者へ引き継ぐ */
  keywords: string[];
  /** 答えられなかったときに出すボタンの文字（20 字以内。押すとこの文字がそのまま送られる） */
  label: string;
  /** 引き継ぐときに返す文 */
  reply: string;
  /** 引き継いでから AI が黙る時間 */
  hours: number;
}

/** concierge.config.json の line の節（既定値は config.ts） */
export interface LineSettings {
  greeting: string;
  suggestions: string[];
  fallback: string;
  handoff: HandoffSettings;
  nonTextReply: string;
  limitReply: string;
  unavailableReply: string;
  tooLongReply: string;
  sourcesLabel: string;
  maxSources: number;
  loading: boolean;
  perUserDaily: number;
  historyMinutes: number;
}

/** 環境変数から読む秘密。無いものは null */
export interface LineSecrets {
  channelSecret: string | null;
  channelAccessToken: string | null;
  handoffWebhookUrl: string | null;
  upstashUrl: string | null;
  upstashToken: string | null;
}

export interface LineConfig {
  concierge: ConciergeConfig;
  line: LineSettings;
  secrets: LineSecrets;
}

/** LINE の Webhook の出来事（使う項目だけ） */
export interface LineSource {
  type: "user" | "group" | "room";
  userId?: string;
  groupId?: string;
  roomId?: string;
}

export interface LineEventBase {
  type: string;
  timestamp?: number;
  source?: LineSource | null;
  webhookEventId?: string;
  deliveryContext?: { isRedelivery?: boolean } | null;
  mode?: string;
}

export interface LineMessageEvent extends LineEventBase {
  type: "message";
  replyToken?: string;
  message: { id?: string; type: string; text?: string };
}

export type LineTextMessageEvent = LineMessageEvent & { message: { id?: string; type: "text"; text: string } };

export interface LineFollowEvent extends LineEventBase {
  type: "follow";
  replyToken?: string;
}

export interface LineUnfollowEvent extends LineEventBase {
  type: "unfollow";
}

export type LineEvent = LineMessageEvent | LineFollowEvent | LineUnfollowEvent | LineEventBase;

export interface LineWebhookBody {
  destination: string;
  events: LineEvent[];
}

/** LINE に送るメッセージ（文字だけ） */
export interface QuickReplyItem {
  type: "action";
  action: { type: "message"; label: string; text: string };
}

export interface LineTextMessage {
  type: "text";
  text: string;
  quickReply?: { items: QuickReplyItem[] };
}

/** LINE の Messaging API のうち、使う 4 つ */
export interface LineApi {
  reply(replyToken: string, messages: LineTextMessage[]): Promise<void>;
  loading(chatId: string, seconds?: number): Promise<void>;
  profile(userId: string): Promise<{ displayName: string } | null>;
  info(): Promise<{ basicId: string; displayName: string }>;
}

/** 会話・有人対応の印・再送の印・回数の保存先。メモリと Upstash の 2 つを同梱する */
export interface Store {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, ttlSeconds: number): Promise<void>;
  incr(key: string, ttlSeconds: number): Promise<number>;
  del(key: string): Promise<void>;
}
