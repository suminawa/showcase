import type { LineApi, LineTextMessage } from "./types";

export const LINE_API_BASE = "https://api.line.me";
export const LINE_TIMEOUT_MS = 10_000;
/** 「入力中」のアニメーションの秒数（LINE は 5〜60 秒、5 秒刻み） */
export const LOADING_SECONDS = 20;
/** 1 回の返信で送れるメッセージの数（LINE の上限） */
export const MAX_REPLY_MESSAGES = 5;

export class LineApiError extends Error {
  readonly status: number;
  readonly body: string;
  constructor(status: number, body: string) {
    super(`LINE API ${status}: ${body.slice(0, 200)}`);
    this.name = "LineApiError";
    this.status = status;
    this.body = body;
  }
}

/** Messaging API のうち、このキットが使う 4 つ。鍵は Bearer で送る */
export function createLineApi(token: string, fetchImpl: typeof fetch = fetch, base: string = LINE_API_BASE): LineApi {
  const headers = { authorization: `Bearer ${token}`, "content-type": "application/json" };

  async function call(method: "GET" | "POST", path: string, body?: unknown): Promise<Response> {
    return fetchImpl(`${base}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(LINE_TIMEOUT_MS),
    });
  }

  async function okOrThrow(res: Response): Promise<void> {
    if (res.ok) return;
    throw new LineApiError(res.status, await res.text().catch(() => ""));
  }

  return {
    async reply(replyToken, messages) {
      await okOrThrow(await call("POST", "/v2/bot/message/reply", { replyToken, messages: messages.slice(0, MAX_REPLY_MESSAGES) }));
    },
    async loading(chatId, seconds = LOADING_SECONDS) {
      await okOrThrow(await call("POST", "/v2/bot/chat/loading/start", { chatId, loadingSeconds: seconds }));
    },
    async profile(userId) {
      const res = await call("GET", `/v2/bot/profile/${encodeURIComponent(userId)}`);
      if (!res.ok) return null;
      const data = (await res.json().catch(() => ({}))) as { displayName?: unknown };
      return typeof data.displayName === "string" ? { displayName: data.displayName } : null;
    },
    async info() {
      const res = await call("GET", "/v2/bot/info");
      await okOrThrow(res);
      const data = (await res.json().catch(() => ({}))) as { basicId?: unknown; displayName?: unknown };
      return {
        basicId: typeof data.basicId === "string" ? data.basicId : "",
        displayName: typeof data.displayName === "string" ? data.displayName : "",
      };
    },
  };
}

export type { LineTextMessage };
