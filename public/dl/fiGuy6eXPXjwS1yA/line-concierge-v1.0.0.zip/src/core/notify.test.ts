import { describe, expect, it } from "vitest";
import { fakeFetch, jsonResponse } from "../../test/fake-fetch";
import { HANDOFF_MESSAGE_CHARS, handoffText, postJson, postSlack } from "./notify";

describe("postJson / postSlack", () => {
  it("JSON を POST して、2xx なら true", async () => {
    const net = fakeFetch([["hooks.slack.com", () => jsonResponse("ok")]]);
    expect(await postSlack("https://hooks.slack.com/services/x", "知らせ", net.fetch)).toBe(true);
    expect(net.calls[0].method).toBe("POST");
    expect(net.calls[0].headers["content-type"]).toBe("application/json");
    expect(net.calls[0].body).toEqual({ text: "知らせ" });
  });
  it("2xx でなければ false。届かなくても false（投げない）", async () => {
    const bad = fakeFetch([["x", () => new Response("", { status: 500 })]]);
    expect(await postJson("https://x/", { a: 1 }, bad.fetch)).toBe(false);
    const down = fakeFetch([["x", () => new Error("ECONNREFUSED")]]);
    expect(await postJson("https://x/", { a: 1 }, down.fetch)).toBe(false);
  });
});

describe("handoffText", () => {
  it("会社名・相手・文・次にすることが入る", () => {
    const text = handoffText("みなと工務店", "みなと 太郎", "U1", "担当者と話したい");
    expect(text).toContain("[みなと工務店]");
    expect(text).toContain("みなと 太郎（U1）");
    expect(text).toContain("担当者と話したい");
    expect(text).toContain("チャット画面");
  });
  it("長いお客さまの文は 500 字で切る", () => {
    const long = "あ".repeat(HANDOFF_MESSAGE_CHARS + 200);
    const text = handoffText("みなと工務店", "みなと 太郎", "U1", long);
    const body = text.split("\n").find((line) => line.startsWith("文: "));
    expect(body).toBe(`文: ${"あ".repeat(HANDOFF_MESSAGE_CHARS - 1)}…`);
    // 切っても案内の行は残る
    expect(text).toContain("チャット画面");
  });
});
