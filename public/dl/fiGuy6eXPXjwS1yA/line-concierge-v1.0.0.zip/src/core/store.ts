import type { Store } from "./types";

/** メモリの保存先が持てる鍵の数。超えたら古い順に落とす */
export const MAX_KEYS = 10_000;
const UPSTASH_TIMEOUT_MS = 5000;

interface Entry {
  value: string;
  expiresAt: number;
}

/** プロセス内の保存先（既定）。Node サーバーではこれで足りる。Vercel では暖かいインスタンスの間だけ残る */
export function createMemoryStore(now: () => number = () => Date.now()): Store {
  const map = new Map<string, Entry>();

  const live = (key: string): Entry | undefined => {
    const entry = map.get(key);
    if (entry === undefined) return undefined;
    if (entry.expiresAt <= now()) {
      map.delete(key);
      return undefined;
    }
    return entry;
  };

  const put = (key: string, entry: Entry): void => {
    // 触った鍵を末尾に置き直し、あふれたら先頭（いちばん古い）から落とす
    map.delete(key);
    map.set(key, entry);
    while (map.size > MAX_KEYS) {
      const oldest = map.keys().next().value;
      if (oldest === undefined) break;
      map.delete(oldest);
    }
  };

  return {
    async get(key) {
      return live(key)?.value ?? null;
    },
    async set(key, value, ttlSeconds) {
      put(key, { value, expiresAt: now() + ttlSeconds * 1000 });
    },
    async incr(key, ttlSeconds) {
      const entry = live(key);
      if (entry === undefined) {
        put(key, { value: "1", expiresAt: now() + ttlSeconds * 1000 });
        return 1;
      }
      const next = Number(entry.value) + 1;
      put(key, { value: String(next), expiresAt: entry.expiresAt });
      return next;
    },
    async del(key) {
      map.delete(key);
    },
  };
}

export class StoreError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "StoreError";
  }
}

/** Upstash Redis の REST（POST にコマンドの配列を送る形）。会話を Vercel でも続けたい人向け */
export function createUpstashStore(url: string, token: string, fetchImpl: typeof fetch = fetch): Store {
  async function command<T>(...args: Array<string | number>): Promise<T> {
    let res: Response;
    try {
      res = await fetchImpl(url, {
        method: "POST",
        headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(UPSTASH_TIMEOUT_MS),
      });
    } catch (error) {
      throw new StoreError(`Upstash に届きません: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!res.ok) throw new StoreError(`Upstash が ${res.status} を返しました`);
    const data = (await res.json().catch(() => ({}))) as { result?: T; error?: string };
    if (typeof data.error === "string") throw new StoreError(`Upstash: ${data.error}`);
    return data.result as T;
  }

  return {
    async get(key) {
      const value = await command<string | null>("GET", key);
      return typeof value === "string" ? value : null;
    },
    async set(key, value, ttlSeconds) {
      await command("SET", key, value, "EX", ttlSeconds);
    },
    async incr(key, ttlSeconds) {
      const count = await command<number>("INCR", key);
      if (count === 1) await command("EXPIRE", key, ttlSeconds);
      return count;
    },
    async del(key) {
      await command("DEL", key);
    },
  };
}

/** 主（Upstash）が失敗したら控え（メモリ）で続ける。知らせるのは最初の 1 回だけ。主は毎回試す（戻れば戻る） */
export function withFallback(primary: Store, fallback: Store, onError: (error: unknown) => void): Store {
  let reported = false;
  const guard = async <T>(run: (store: Store) => Promise<T>): Promise<T> => {
    try {
      return await run(primary);
    } catch (error) {
      if (!reported) {
        reported = true;
        onError(error);
      }
      return run(fallback);
    }
  };
  return {
    get: (key) => guard((store) => store.get(key)),
    set: (key, value, ttl) => guard((store) => store.set(key, value, ttl)),
    incr: (key, ttl) => guard((store) => store.incr(key, ttl)),
    del: (key) => guard((store) => store.del(key)),
  };
}

/** 環境変数に Upstash があれば Upstash（控えはメモリ）、無ければメモリ */
export function createStoreFromEnv(
  env: Record<string, string | undefined>,
  fetchImpl: typeof fetch = fetch,
  onError: (error: unknown) => void = (error) => console.error("line-concierge: 保存先に届かないので、メモリで続けます:", error),
): Store {
  const url = env.UPSTASH_REDIS_REST_URL?.trim() ?? "";
  const token = env.UPSTASH_REDIS_REST_TOKEN?.trim() ?? "";
  const memory = createMemoryStore();
  if (url === "" || token === "") return memory;
  return withFallback(createUpstashStore(url, token, fetchImpl), memory, onError);
}
