import {
  buildPrompt,
  createAnthropicClient,
  createLogRing,
  emptyIndex,
  retrieve,
  streamAnswer,
  type AnswerResult,
  type AnthropicClientLike,
  type LoadedIndex,
  type LogEntry,
  type LogSink,
} from "@suminawa/ai-concierge";
import { isFollow, isTextMessage, isUnfollow, MAX_BODY_BYTES, parseWebhookBody, replyTokenOf, userIdOf } from "./events";
import { createLineApi, LOADING_SECONDS } from "./line-api";
import { handoffText, postJson, postSlack } from "./notify";
import { answerMessages, fallbackMessages, quickReplyOf, textMessage } from "./reply";
import { clearUser, countTotal, countUser, inHandoff, loadHistory, markHandoff, saveHistory, seenEvent } from "./session";
import { verifySignature } from "./signature";
import { createMemoryStore } from "./store";
import type { LineApi, LineConfig, LineEvent, LineTextMessage, Store } from "./types";

export interface LineBotDeps {
  /** null を渡すと鍵なし（Claude を呼ばない）。省略時は ANTHROPIC_API_KEY から作る */
  client?: AnthropicClientLike | null;
  index?: LoadedIndex;
  store?: Store;
  /** null を渡すと LINE を呼ばない（simulate 用）。省略時は LINE_CHANNEL_ACCESS_TOKEN から作る */
  lineApi?: LineApi | null;
  fetch?: typeof fetch;
  now?: () => number;
  log?: LogSink;
  logger?: (message: string) => void;
}

export interface HandleResult {
  /** 先に返す応答（LINE には 200 をすぐ返す） */
  response: Response;
  /** 答えを作って返信する仕事。決して reject しない。Next.js は after() で、Node は応答のあとに待つ */
  work: Promise<void>;
}

export type OutcomeReason = "answered" | "not_in_documents" | "handoff" | "in_handoff" | "limit" | "too_long" | "empty" | "unavailable";

export interface Outcome {
  messages: LineTextMessage[];
  answered: boolean;
  handoff: boolean;
  reason: OutcomeReason;
  /**
   * 返信のあとに回す仕事（いまは担当者への通知）。返信を待たせないために、
   * 呼び出し側が replyTo のあとで待つ。processEvent と simulate が待つので、
   * ほかから二度呼ぶ必要はない（simulate の戻り値には残さない）
   */
  followUp?: () => Promise<void>;
}

export interface LineBot {
  handle(request: Request): Promise<HandleResult>;
  /** LINE を呼ばずに、文字のメッセージが来たときの答えを作る（CLI の simulate と、テスト用） */
  simulate(userId: string, text: string): Promise<Outcome>;
  greet(): LineTextMessage[];
  config: LineConfig;
  index: LoadedIndex;
  log: LogSink;
}

export const ANSWER_HEAD_CHARS = 200;
const ZERO_USAGE = { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 };
/** Claude を呼ばずに終えたとき（上限・引き継ぎ・長すぎ・空）の記録。回数だけ残し、費用は 0 */
const NOT_ANSWERED = { answered: false, text: "", citations: [] as number[], usage: ZERO_USAGE, truncated: false };

/** 記録に残す前に、メール・電話番号・長い数字を伏せる（core の log と同じ） */
export function redact(text: string): string {
  return text
    .replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, "***@***")
    .replace(/0\d{1,3}[-\s]?\d{2,4}[-\s]?\d{3,4}/g, "***")
    .replace(/\d{9,}/g, "***");
}

export function headOf(text: string, max: number = ANSWER_HEAD_CHARS): string {
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

/** 引き継ぎの言葉を含むか、ボタンの文字そのものか */
export function isHandoffRequest(text: string, keywords: string[], label: string): boolean {
  const trimmed = text.trim();
  if (trimmed === "") return false;
  if (trimmed === label) return true;
  return keywords.some((keyword) => keyword !== "" && trimmed.includes(keyword));
}

function json(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export function createLineBot(config: LineConfig, deps: LineBotDeps = {}): LineBot {
  const { concierge, line: settings, secrets } = config;
  const index = deps.index ?? emptyIndex("1970-01-01T00:00:00.000Z");
  const now = deps.now ?? (() => Date.now());
  const store = deps.store ?? createMemoryStore(now);
  const doFetch = deps.fetch ?? fetch;
  const log = deps.log ?? createLogRing();
  const logger = deps.logger ?? ((message: string) => console.error(`line-concierge: ${message}`));
  const lineApi: LineApi | null =
    deps.lineApi !== undefined ? deps.lineApi : secrets.channelAccessToken === null ? null : createLineApi(secrets.channelAccessToken, doFetch);
  const client: AnthropicClientLike | null =
    deps.client !== undefined ? deps.client : concierge.apiKey === null ? null : createAnthropicClient(concierge.apiKey);
  let logId = 0;

  const greet = (): LineTextMessage[] => [textMessage(settings.greeting, quickReplyOf(settings.suggestions))];

  /**
   * 記録に 1 件足す。記録の Webhook への送信は返信を待たせないよう pending に積み、
   * 呼び出しごとの一覧（processEvents / simulate が持つ）の最後でまとめて待つ
   */
  async function record(
    at: number,
    question: string,
    result: Pick<AnswerResult, "answered" | "text" | "citations" | "usage" | "truncated">,
    pending: Promise<unknown>[],
  ): Promise<void> {
    logId += 1;
    const entry: LogEntry = {
      id: logId,
      at: new Date(at).toISOString(),
      // 長すぎる文（too_long）も記録に残るので、上限の字数で切ってから伏せ字にする（記録の Webhook に 64 KB を流さない）
      question: redact(headOf(question, concierge.limits.maxInputChars)),
      answerHead: headOf(redact(result.text)),
      sources: result.citations,
      answered: result.answered,
      ms: now() - at,
      model: concierge.answer.model,
      inputTokens: result.usage.inputTokens,
      outputTokens: result.usage.outputTokens,
      cacheReadTokens: result.usage.cacheReadTokens,
      truncated: result.truncated,
      disconnected: false,
    };
    log.push(entry);
    if (concierge.logWebhookUrl === null) return;
    const payload =
      concierge.logWebhookFormat === "slack"
        ? { text: `[${concierge.site.name}] LINE ${entry.answered ? "答えました" : "答えられませんでした"}: ${entry.question}` }
        : { site: concierge.site.name, channel: "line", ...entry };
    // 記録の送信は返信を待たせない（遅い送り先が返信を遅らせないように。postJson は失敗しても投げない）
    pending.push(postJson(concierge.logWebhookUrl, payload, doFetch));
  }

  async function notifyHandoff(userId: string, text: string): Promise<void> {
    if (secrets.handoffWebhookUrl === null) return;
    let displayName = "（名前は取れませんでした）";
    if (lineApi !== null) {
      try {
        const profile = await lineApi.profile(userId);
        if (profile !== null) displayName = profile.displayName;
      } catch {
        // 名前が取れなくても知らせる
      }
    }
    const ok = await postSlack(secrets.handoffWebhookUrl, handoffText(concierge.site.name, displayName, userId, text), doFetch);
    if (!ok) logger("引き継ぎの通知を送れませんでした。HANDOFF_WEBHOOK_URL をご確認ください。");
  }

  async function answerFor(userId: string, rawText: string, pending: Promise<unknown>[]): Promise<Outcome> {
    const at = now();
    const text = rawText.trim();
    if (await inHandoff(store, userId)) {
      await record(at, text, NOT_ANSWERED, pending);
      return { messages: [], answered: false, handoff: true, reason: "in_handoff" };
    }
    if (isHandoffRequest(text, settings.handoff.keywords, settings.handoff.label)) {
      await markHandoff(store, userId, settings.handoff.hours);
      await record(at, text, NOT_ANSWERED, pending);
      // 通知は返信のあとに回す（相手のプロフィールの取得と Slack への送信で、お客さまへの返事を待たせないため）
      return {
        messages: [textMessage(settings.handoff.reply)],
        answered: false,
        handoff: true,
        reason: "handoff",
        followUp: () => notifyHandoff(userId, text),
      };
    }
    if (text === "") {
      await record(at, text, NOT_ANSWERED, pending);
      return { messages: [], answered: false, handoff: false, reason: "empty" };
    }
    if (text.length > concierge.limits.maxInputChars) {
      await record(at, text, NOT_ANSWERED, pending);
      return { messages: [textMessage(settings.tooLongReply)], answered: false, handoff: false, reason: "too_long" };
    }
    // 1 人の上限を先に見る。超えた人のぶんは全体の回数に数えない（1 人が全員の枠を使い切らないように）
    if ((await countUser(store, userId, at)) > settings.perUserDaily) {
      await record(at, text, NOT_ANSWERED, pending);
      return { messages: [textMessage(settings.limitReply)], answered: false, handoff: false, reason: "limit" };
    }
    if ((await countTotal(store, at)) > concierge.limits.dailyQuestions) {
      await record(at, text, NOT_ANSWERED, pending);
      return { messages: [textMessage(settings.limitReply)], answered: false, handoff: false, reason: "limit" };
    }
    if (client === null) {
      await record(at, text, NOT_ANSWERED, pending);
      return { messages: [textMessage(settings.unavailableReply)], answered: false, handoff: false, reason: "unavailable" };
    }
    if (settings.loading && lineApi !== null) {
      // 「入力中」は出せなくても続ける
      void lineApi.loading(userId, LOADING_SECONDS).catch(() => {});
    }
    const history = await loadHistory(store, userId);
    const found = retrieve({ index, config: concierge, question: text, history });
    const { params, sources } = buildPrompt({ config: concierge, entries: found.entries, question: text, history });
    const result = await streamAnswer({ client, params, sources, onEvent: () => {} });
    await record(at, text, result, pending);
    if (result.error !== null) {
      logger(`Claude の呼び出しに失敗: ${result.error}`);
      return { messages: [textMessage(settings.unavailableReply)], answered: false, handoff: false, reason: "unavailable" };
    }
    if (!result.answered) return { messages: fallbackMessages(settings), answered: false, handoff: false, reason: "not_in_documents" };
    await saveHistory(store, userId, history, text, result.text, settings.historyMinutes * 60);
    return { messages: answerMessages(result.text, sources, result.citations, settings), answered: true, handoff: false, reason: "answered" };
  }

  async function replyTo(event: LineEvent, messages: LineTextMessage[]): Promise<void> {
    if (messages.length === 0 || lineApi === null) return;
    const token = replyTokenOf(event);
    if (token === null) return;
    try {
      await lineApi.reply(token, messages);
    } catch (error) {
      logger(`返信に失敗: ${messageOf(error)}`);
    }
  }

  async function processEvent(event: LineEvent, pending: Promise<unknown>[]): Promise<void> {
    const userId = userIdOf(event);
    if (userId === null) return;
    if (typeof event.webhookEventId === "string" && event.webhookEventId !== "" && (await seenEvent(store, event.webhookEventId))) return;
    if (isUnfollow(event)) {
      await clearUser(store, userId);
      return;
    }
    if (isFollow(event)) {
      await replyTo(event, greet());
      return;
    }
    if (event.type !== "message") return;
    const message = (event as { message?: unknown }).message;
    if (message === null || message === undefined) {
      logger("message イベントに message がありません。飛ばします。");
      return;
    }
    // 検証用のダミーの replyToken には答えない（回数にも数えない。Claude も呼ばない）
    if (replyTokenOf(event) === null) return;
    if (!isTextMessage(event)) {
      if (settings.nonTextReply !== "") await replyTo(event, [textMessage(settings.nonTextReply)]);
      return;
    }
    const outcome = await answerFor(userId, event.message.text, pending);
    // 先にお客さまへ返信し、そのあとで担当者への通知を済ませる
    await replyTo(event, outcome.messages);
    if (outcome.followUp !== undefined) await outcome.followUp();
  }

  async function processEvents(events: LineEvent[]): Promise<void> {
    // 後回しにした送信（記録の Webhook）は、この呼び出しのぶんだけを持つ（同時に来た要求と混ざらないように）
    const pending: Promise<unknown>[] = [];
    for (const event of events) {
      try {
        await processEvent(event, pending);
      } catch (error) {
        try {
          logger(`出来事の処理に失敗（${event.type}）: ${messageOf(error)}`);
        } catch {
          // 記録に失敗しても次の出来事へ進む
        }
      }
    }
    // 返信を済ませてから、後回しにした送信を待つ
    await Promise.allSettled(pending.splice(0));
  }

  /** LINE を呼ばずに答えを作る。通知と記録の送信も、ここで待ってから返す */
  async function simulate(userId: string, text: string): Promise<Outcome> {
    const pending: Promise<unknown>[] = [];
    const outcome = await answerFor(userId, text, pending);
    if (outcome.followUp !== undefined) await outcome.followUp();
    await Promise.allSettled(pending.splice(0));
    const { followUp: _done, ...rest } = outcome;
    return rest;
  }

  async function handle(request: Request): Promise<HandleResult> {
    const done = Promise.resolve();
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname.endsWith("/health")) {
      const body = {
        ok: true,
        documents: index.stats.documents,
        chunks: index.stats.chunks,
        totalTokens: index.stats.totalTokens,
        builtAt: index.file.builtAt,
        lineToken: lineApi !== null,
        apiKey: client !== null,
      };
      return { response: json(body, 200), work: done };
    }
    if (request.method !== "POST") return { response: json({ ok: false, message: "POST で送ってください。" }, 405), work: done };
    if (secrets.channelSecret === null) {
      logger("LINE_CHANNEL_SECRET がありません。署名を確かめられないので受け付けません。");
      return { response: json({ ok: false, message: "LINE_CHANNEL_SECRET がありません。" }, 500), work: done };
    }
    const declared = Number(request.headers.get("content-length") ?? "0");
    if (Number.isFinite(declared) && declared > MAX_BODY_BYTES) {
      return { response: json({ ok: false, message: "本文が大きすぎます。" }, 413), work: done };
    }
    let bytes: Uint8Array;
    try {
      bytes = new Uint8Array(await request.arrayBuffer());
    } catch {
      return { response: json({ ok: false, message: "本文を読み取れませんでした。" }, 400), work: done };
    }
    if (bytes.byteLength > MAX_BODY_BYTES) return { response: json({ ok: false, message: "本文が大きすぎます。" }, 413), work: done };
    if (!(await verifySignature(secrets.channelSecret, bytes, request.headers.get("x-line-signature")))) {
      return { response: json({ ok: false, message: "署名が合いません。" }, 401), work: done };
    }
    let events: LineEvent[];
    try {
      events = parseWebhookBody(JSON.parse(new TextDecoder().decode(bytes))).events;
    } catch {
      return { response: json({ ok: false, message: "本文の形が違います。" }, 400), work: done };
    }
    return { response: json({ ok: true }, 200), work: processEvents(events) };
  }

  return { handle, simulate, greet, config, index, log };
}
