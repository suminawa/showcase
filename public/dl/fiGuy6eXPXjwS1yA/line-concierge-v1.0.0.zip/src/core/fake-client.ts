import type { AnthropicClientLike, MessageParams } from "@suminawa/ai-concierge";
import type { FinalMessageLike, MessageStreamLike, StreamEventLike } from "./anthropic-types";

/** 鍵を使わずに動きを見るための、決まった答え（LINE_FAKE=1 と simulate 用。見本の会社の対応エリア） */
export const FAKE_ANSWER = "市内と、隣接する三つの市までお伺いしております。現地調査とお見積もりは無料です。[1]";

/**
 * 決まった答えの根拠になる文書を見つけるための言葉。前から順に探し、
 * 見つかった document ブロックを出典にする（どれにも当たらなければ 0 番）。
 * これをしないと「参考」に無関係な文書（先頭の会社概要など）が出てしまう。
 */
export const FAKE_SOURCE_MARKERS = ["三つの市", "対応エリア"];

const PIECE = 8;

function pieces(text: string): string[] {
  const out: string[] = [];
  for (let i = 0; i < text.length; i += PIECE) out.push(text.slice(i, i + PIECE));
  return out;
}

/** 送った文書（document ブロック）のうち、決まった答えの根拠に近いものの番号（0 始まり） */
export function fakeDocumentIndex(params: MessageParams, markers: string[] = FAKE_SOURCE_MARKERS): number {
  const documents: string[] = [];
  for (const message of params.messages) {
    if (typeof message.content === "string") continue;
    for (const block of message.content) {
      if (block.type !== "document") continue;
      documents.push(`${block.title}\n${block.source.data}`);
    }
  }
  for (const marker of markers) {
    const found = documents.findIndex((text) => text.includes(marker));
    if (found !== -1) return found;
  }
  return 0;
}

export function createFakeClient(answer: string = FAKE_ANSWER): AnthropicClientLike {
  return {
    messages: {
      stream(params: MessageParams): MessageStreamLike {
        const documentIndex = fakeDocumentIndex(params);
        return {
          async *[Symbol.asyncIterator](): AsyncGenerator<StreamEventLike> {
            for (const text of pieces(answer)) {
              yield { type: "content_block_delta", index: 0, delta: { type: "text_delta", text } } as StreamEventLike;
            }
            yield {
              type: "content_block_delta",
              index: 0,
              delta: {
                type: "citations_delta",
                citation: {
                  type: "char_location",
                  cited_text: "市内と隣の三市にお伺いします。",
                  document_index: documentIndex,
                  start_char_index: 0,
                  end_char_index: 15,
                },
              },
            } as StreamEventLike;
          },
          async finalMessage(): Promise<FinalMessageLike> {
            return {
              stop_reason: "end_turn",
              usage: { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 },
              content: [{ type: "text", text: answer }],
            } as FinalMessageLike;
          },
          abort(): void {},
        } as MessageStreamLike;
      },
    },
  };
}
