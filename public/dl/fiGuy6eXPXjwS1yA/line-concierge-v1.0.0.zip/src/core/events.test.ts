import { describe, expect, it } from "vitest";
import { isFollow, isRedelivery, isTextMessage, isUnfollow, MAX_BODY_BYTES, parseWebhookBody, replyTokenOf, userIdOf } from "./events";
import type { LineEvent } from "./types";

const TEXT: LineEvent = {
  type: "message",
  timestamp: 1700000000000,
  source: { type: "user", userId: "U1" },
  replyToken: "r1",
  webhookEventId: "e1",
  deliveryContext: { isRedelivery: false },
  message: { id: "m1", type: "text", text: "営業時間は？" },
};

describe("parseWebhookBody", () => {
  it("destination と events を取り出す", () => {
    const body = parseWebhookBody({ destination: "Ubot", events: [TEXT] });
    expect(body.destination).toBe("Ubot");
    expect(body.events).toHaveLength(1);
  });
  it("検証の要求（events が空）も通る", () => {
    expect(parseWebhookBody({ destination: "Ubot", events: [] }).events).toEqual([]);
  });
  it("type の無い出来事や壊れた要素は捨てる", () => {
    const body = parseWebhookBody({ events: [null, 1, { foo: "bar" }, { type: "follow" }] });
    expect(body.events).toEqual([{ type: "follow" }]);
    expect(body.destination).toBe("");
  });
  it("events が一覧でなければ止める", () => {
    expect(() => parseWebhookBody({ events: "x" })).toThrow(/events/);
    expect(() => parseWebhookBody([])).toThrow(/本文/);
    expect(() => parseWebhookBody(null)).toThrow(/本文/);
  });
});

describe("型で絞る", () => {
  it("文字のメッセージ", () => {
    expect(isTextMessage(TEXT)).toBe(true);
    expect(isTextMessage({ ...TEXT, message: { id: "m2", type: "sticker" } } as LineEvent)).toBe(false);
    expect(isTextMessage({ type: "follow" })).toBe(false);
  });
  it("follow / unfollow", () => {
    expect(isFollow({ type: "follow", replyToken: "r" })).toBe(true);
    expect(isUnfollow({ type: "unfollow" })).toBe(true);
    expect(isFollow(TEXT)).toBe(false);
  });
  it("userIdOf は 1 対 1 の user だけ返す", () => {
    expect(userIdOf(TEXT)).toBe("U1");
    expect(userIdOf({ ...TEXT, source: { type: "group", groupId: "G1", userId: "U1" } })).toBeNull();
    expect(userIdOf({ ...TEXT, source: { type: "user" } })).toBeNull();
    expect(userIdOf({ type: "follow" })).toBeNull();
  });
  it("replyTokenOf は検証用のダミーを捨てる", () => {
    expect(replyTokenOf(TEXT)).toBe("r1");
    expect(replyTokenOf({ ...TEXT, replyToken: "00000000000000000000000000000000" })).toBeNull();
    expect(replyTokenOf({ ...TEXT, replyToken: "ffffffffffffffffffffffffffffffff" })).toBeNull();
    expect(replyTokenOf({ type: "unfollow" })).toBeNull();
  });
  it("isRedelivery", () => {
    expect(isRedelivery(TEXT)).toBe(false);
    expect(isRedelivery({ ...TEXT, deliveryContext: { isRedelivery: true } })).toBe(true);
    expect(isRedelivery({ type: "follow" })).toBe(false);
  });
  it("本文の上限は 64 KB", () => {
    expect(MAX_BODY_BYTES).toBe(64 * 1024);
  });
});
