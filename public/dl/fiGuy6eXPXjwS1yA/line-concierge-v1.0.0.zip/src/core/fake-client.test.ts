import type { MessageParams } from "@suminawa/ai-concierge";
import { describe, expect, it } from "vitest";
import { createFakeClient, fakeDocumentIndex, FAKE_ANSWER } from "./fake-client";

/** buildPrompt が作るのと同じ形（先頭の user に document ブロックを並べる） */
function paramsWith(documents: Array<{ title: string; data: string }>): MessageParams {
  return {
    model: "claude-opus-5",
    max_tokens: 10,
    system: [],
    messages: [
      {
        role: "user",
        content: [
          ...documents.map((doc) => ({
            type: "document" as const,
            source: { type: "text" as const, media_type: "text/plain" as const, data: doc.data },
            title: doc.title,
            citations: { enabled: true as const },
          })),
          { type: "text" as const, text: "上の文書だけを使ってください。" },
        ],
      },
      { role: "assistant", content: "承知しました。" },
      { role: "user", content: [{ type: "text" as const, text: "対応エリアはどこまでですか" }] },
    ],
  };
}

async function citationOf(params: MessageParams): Promise<number> {
  const stream = createFakeClient().messages.stream(params);
  let documentIndex = -1;
  for await (const event of stream) {
    const citation = (event as { delta?: { type?: string; citation?: { document_index: number } } }).delta?.citation;
    if (citation !== undefined) documentIndex = citation.document_index;
  }
  return documentIndex;
}

describe("createFakeClient", () => {
  it("決まった答えを流し、出典 [1] を付け、最後の返事にも本文を持つ", async () => {
    const stream = createFakeClient().messages.stream({ model: "claude-opus-5", max_tokens: 10, system: [], messages: [] });
    let text = "";
    let citations = 0;
    for await (const event of stream) {
      const delta = (event as { delta?: { type?: string; text?: string } }).delta;
      if (delta?.type === "text_delta") text += delta.text ?? "";
      if (delta?.type === "citations_delta") citations += 1;
    }
    expect(text).toBe(FAKE_ANSWER);
    expect(citations).toBe(1);
    const final = await stream.finalMessage();
    expect(final.stop_reason).toBe("end_turn");
    expect(final.content?.[0]?.text).toBe(FAKE_ANSWER);
  });
  it("答えを差し替えられる", async () => {
    const stream = createFakeClient("別の答え。[1]").messages.stream({ model: "claude-opus-5", max_tokens: 10, system: [], messages: [] });
    let text = "";
    for await (const event of stream) {
      const delta = (event as { delta?: { type?: string; text?: string } }).delta;
      if (delta?.type === "text_delta") text += delta.text ?? "";
    }
    expect(text).toBe("別の答え。[1]");
  });
});

describe("fakeDocumentIndex", () => {
  it("決まった答えの根拠になる文書を出典にする（先頭の文書ではなく）", async () => {
    const params = paramsWith([
      { title: "[1] 会社概要", data: "みなと工務店は架空の会社です。" },
      { title: "[2] 料金の目安", data: "キッチンの入れ替えは 80 万円からです。" },
      { title: "[3] 対応エリア > お伺いする範囲", data: "市内と、隣接する三つの市までお伺いしております。" },
    ]);
    expect(fakeDocumentIndex(params)).toBe(2);
    expect(await citationOf(params)).toBe(2);
  });

  it("「三つの市」が無ければ題名の「対応エリア」で探す", () => {
    const params = paramsWith([
      { title: "[1] 会社概要", data: "みなと工務店は架空の会社です。" },
      { title: "[2] 対応エリア > お伺いできる範囲", data: "みなと市を中心に、隣接するしおかぜ市までお伺いしております。" },
    ]);
    expect(fakeDocumentIndex(params)).toBe(1);
  });

  it("どれにも当たらなければ 0 番。文書が無くても落ちない", async () => {
    const params = paramsWith([{ title: "[1] 会社概要", data: "みなと工務店は架空の会社です。" }]);
    expect(fakeDocumentIndex(params)).toBe(0);
    const empty: MessageParams = { model: "claude-opus-5", max_tokens: 10, system: [], messages: [] };
    expect(fakeDocumentIndex(empty)).toBe(0);
    expect(await citationOf(empty)).toBe(0);
  });
});
