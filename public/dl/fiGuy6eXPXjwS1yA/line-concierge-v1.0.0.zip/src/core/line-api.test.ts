import { describe, expect, it } from "vitest";
import { fakeFetch, jsonResponse } from "../../test/fake-fetch";
import { createLineApi, LINE_API_BASE, LineApiError, LOADING_SECONDS } from "./line-api";
import type { LineTextMessage } from "./types";

const message = (text: string): LineTextMessage => ({ type: "text", text });

describe("createLineApi", () => {
  it("reply は reply API に Bearer とメッセージを送る", async () => {
    const net = fakeFetch([["/v2/bot/message/reply", () => jsonResponse({})]]);
    const api = createLineApi("tok", net.fetch);
    await api.reply("r1", [message("こんにちは")]);
    expect(net.calls).toHaveLength(1);
    expect(net.calls[0].url).toBe(`${LINE_API_BASE}/v2/bot/message/reply`);
    expect(net.calls[0].method).toBe("POST");
    expect(net.calls[0].headers.authorization).toBe("Bearer tok");
    expect(net.calls[0].headers["content-type"]).toBe("application/json");
    expect(net.calls[0].body).toEqual({ replyToken: "r1", messages: [{ type: "text", text: "こんにちは" }] });
  });

  it("1 回の返信は 5 通まで", async () => {
    const net = fakeFetch([["/reply", () => jsonResponse({})]]);
    await createLineApi("tok", net.fetch).reply("r1", [1, 2, 3, 4, 5, 6].map((n) => message(String(n))));
    expect((net.calls[0].body as { messages: unknown[] }).messages).toHaveLength(5);
  });

  it("2xx でなければ LineApiError（status と本文を持つ）", async () => {
    const net = fakeFetch([["/reply", () => new Response('{"message":"Invalid reply token"}', { status: 400 })]]);
    await expect(createLineApi("tok", net.fetch).reply("r1", [message("x")])).rejects.toMatchObject({
      name: "LineApiError",
      status: 400,
      body: '{"message":"Invalid reply token"}',
    });
  });

  it("loading は chatId と秒数（既定 20）を送る", async () => {
    const net = fakeFetch([["/loading/start", () => new Response("", { status: 202 })]]);
    await createLineApi("tok", net.fetch).loading("U1");
    expect(net.calls[0].url).toBe(`${LINE_API_BASE}/v2/bot/chat/loading/start`);
    expect(net.calls[0].body).toEqual({ chatId: "U1", loadingSeconds: LOADING_SECONDS });
    expect(LOADING_SECONDS).toBe(20);
  });

  it("profile は displayName を返し、取れなければ null", async () => {
    const net = fakeFetch([
      ["/profile/U1", () => jsonResponse({ displayName: "みなと 太郎", userId: "U1" })],
      ["/profile/U2", () => new Response("", { status: 404 })],
    ]);
    const api = createLineApi("tok", net.fetch);
    expect(await api.profile("U1")).toEqual({ displayName: "みなと 太郎" });
    expect(await api.profile("U2")).toBeNull();
    expect(net.calls[0].method).toBe("GET");
  });

  it("info は basicId と displayName を返し、401 なら投げる", async () => {
    const ok = fakeFetch([["/v2/bot/info", () => jsonResponse({ basicId: "@abc", displayName: "みなと工務店" })]]);
    expect(await createLineApi("tok", ok.fetch).info()).toEqual({ basicId: "@abc", displayName: "みなと工務店" });
    const bad = fakeFetch([["/v2/bot/info", () => new Response("Unauthorized", { status: 401 })]]);
    await expect(createLineApi("tok", bad.fetch).info()).rejects.toBeInstanceOf(LineApiError);
  });

  it("base を差し替えられる（テストや代理サーバー用）", async () => {
    const net = fakeFetch([["/reply", () => jsonResponse({})]]);
    await createLineApi("tok", net.fetch, "http://127.0.0.1:9").reply("r", [message("x")]);
    expect(net.calls[0].url).toBe("http://127.0.0.1:9/v2/bot/message/reply");
  });
});
