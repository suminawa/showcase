import type { PromptSource } from "@suminawa/ai-concierge";
import { describe, expect, it } from "vitest";
import { resolveLineConfig } from "./config";
import { answerMessages, clip, fallbackMessages, quickReplyOf, sourcesBlock, stripMarkers, textMessage } from "./reply";

const settings = resolveLineConfig({
  file: { site: { name: "みなと工務店" }, suggestions: ["対応エリアはどこまでですか", "見積もりは無料ですか"] },
  env: {},
}).line;

const sources: PromptSource[] = [
  { index: 1, docId: "area", chunkId: "area-1", title: "対応エリア", url: "https://example.com/area", breadcrumb: "対応エリア" },
  { index: 2, docId: "price", chunkId: "price-1", title: "料金", url: "https://example.com/price", breadcrumb: "料金 > 目安" },
  { index: 3, docId: "faq", chunkId: "faq-1", title: "よくある質問", url: null, breadcrumb: "よくある質問" },
  { index: 4, docId: "area2", chunkId: "area-2", title: "対応エリア", url: "https://example.com/area", breadcrumb: "対応エリア > 遠方" },
];

describe("stripMarkers / clip", () => {
  it("[1] の印を取り、前後の空白を落とす", () => {
    expect(stripMarkers("市内にお伺いします。[1] 見積もりは無料です。 [2]\n")).toBe("市内にお伺いします。 見積もりは無料です。");
  });
  it("5,000 字で切る", () => {
    expect(clip("あ".repeat(5000))).toHaveLength(5000);
    expect(clip("あ".repeat(5001))).toHaveLength(5000);
    expect(clip("あ".repeat(5001)).endsWith("…")).toBe(true);
  });
});

describe("quickReplyOf / textMessage", () => {
  it("候補をボタンにする。無ければ undefined", () => {
    expect(quickReplyOf([])).toBeUndefined();
    expect(quickReplyOf(["営業時間は"])).toEqual({ items: [{ type: "action", action: { type: "message", label: "営業時間は", text: "営業時間は" } }] });
  });
  it("14 個目は落とし、ラベルは 20 字で切る（本文はそのまま）", () => {
    const long = "あ".repeat(25);
    const reply = quickReplyOf([...Array.from({ length: 13 }, (_, i) => `候補${i}`), long]);
    expect(reply?.items).toHaveLength(13);
    const only = quickReplyOf([long]);
    expect(only?.items[0].action.label).toHaveLength(20);
    expect(only?.items[0].action.text).toBe(long);
  });
  it("textMessage は quickReply が無ければ鍵を持たない", () => {
    expect(textMessage("こんにちは")).toEqual({ type: "text", text: "こんにちは" });
  });
});

describe("sourcesBlock", () => {
  it("引用された順に、URL のあるものだけ、同じ URL は 1 度、max まで", () => {
    expect(sourcesBlock("参考", sources, [3, 1, 4, 2], 3)).toBe("参考:\n対応エリア https://example.com/area\n料金 https://example.com/price");
    expect(sourcesBlock("参考", sources, [1, 2], 1)).toBe("参考:\n対応エリア https://example.com/area");
    expect(sourcesBlock("参考", sources, [3], 3)).toBe("");
    expect(sourcesBlock("参考", sources, [9], 3)).toBe("");
    expect(sourcesBlock("参考", sources, [1], 0)).toBe("");
  });
});

describe("answerMessages / fallbackMessages", () => {
  it("本文 + 参考 + 候補のボタンが 1 通に入る", () => {
    const [message] = answerMessages("市内にお伺いします。[1]", sources, [1], settings);
    expect(message.text).toBe("市内にお伺いします。\n\n参考:\n対応エリア https://example.com/area");
    expect(message.quickReply?.items.map((item) => item.action.text)).toEqual(["対応エリアはどこまでですか", "見積もりは無料ですか"]);
  });
  it("参考が無ければ本文だけ", () => {
    expect(answerMessages("お答えします。", sources, [], settings)[0].text).toBe("お答えします。");
  });
  it("答えられないときは断りの文と、先頭に「担当者に相談する」のボタン", () => {
    const [message] = fallbackMessages(settings);
    expect(message.text).toBe(settings.fallback);
    expect(message.quickReply?.items[0].action).toEqual({ type: "message", label: "担当者に相談する", text: "担当者に相談する" });
    expect(message.quickReply?.items).toHaveLength(3);
  });
});
