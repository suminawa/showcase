import { HISTORY_TURNS, type ChatTurn } from "@suminawa/ai-concierge";
import type { Store } from "./types";

export const KEY_PREFIX = "lc:";
/** 同じ webhookEventId を覚えておく時間 */
export const EVENT_TTL_SECONDS = 60 * 60;
/** 日ごとの回数を持つ時間（日付をまたいでも消えるように 2 日） */
export const COUNT_TTL_SECONDS = 2 * 24 * 60 * 60;
const JST_OFFSET_MS = 9 * 60 * 60 * 1000;

/** JST の YYYY-MM-DD */
export function dayKeyOf(now: number): string {
  return new Date(now + JST_OFFSET_MS).toISOString().slice(0, 10);
}

export const keys = {
  history: (userId: string): string => `${KEY_PREFIX}h:${userId}`,
  handoff: (userId: string): string => `${KEY_PREFIX}o:${userId}`,
  event: (eventId: string): string => `${KEY_PREFIX}e:${eventId}`,
  day: (day: string): string => `${KEY_PREFIX}d:${day}`,
  userDay: (userId: string, day: string): string => `${KEY_PREFIX}u:${userId}:${day}`,
};

function isTurn(value: unknown): value is ChatTurn {
  if (typeof value !== "object" || value === null) return false;
  const turn = value as { role?: unknown; content?: unknown };
  return (turn.role === "user" || turn.role === "assistant") && typeof turn.content === "string";
}

/** 直近の往復。壊れていれば空 */
export async function loadHistory(store: Store, userId: string): Promise<ChatTurn[]> {
  const raw = await store.get(keys.history(userId));
  if (raw === null) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isTurn).slice(-HISTORY_TURNS * 2);
  } catch {
    return [];
  }
}

export async function saveHistory(store: Store, userId: string, history: ChatTurn[], question: string, answer: string, ttlSeconds: number): Promise<void> {
  const combined: ChatTurn[] = [...history, { role: "user", content: question }, { role: "assistant", content: answer }];
  const next = combined.slice(-HISTORY_TURNS * 2);
  await store.set(keys.history(userId), JSON.stringify(next), ttlSeconds);
}

export async function clearUser(store: Store, userId: string): Promise<void> {
  await store.del(keys.history(userId));
  await store.del(keys.handoff(userId));
}

export async function markHandoff(store: Store, userId: string, hours: number): Promise<void> {
  await store.set(keys.handoff(userId), "1", Math.round(hours * 3600));
}

export async function inHandoff(store: Store, userId: string): Promise<boolean> {
  return (await store.get(keys.handoff(userId))) !== null;
}

/** 見たことのある出来事なら true。初めてなら印を付けて false */
export async function seenEvent(store: Store, eventId: string): Promise<boolean> {
  const key = keys.event(eventId);
  if ((await store.get(key)) !== null) return true;
  await store.set(key, "1", EVENT_TTL_SECONDS);
  return false;
}

/** その人の今日の回数（この呼び出しを含む） */
export async function countUser(store: Store, userId: string, now: number): Promise<number> {
  return store.incr(keys.userDay(userId, dayKeyOf(now)), COUNT_TTL_SECONDS);
}

/** 全体の今日の回数（この呼び出しを含む） */
export async function countTotal(store: Store, now: number): Promise<number> {
  return store.incr(keys.day(dayKeyOf(now)), COUNT_TTL_SECONDS);
}

/** その人と全体の、今日の回数（この呼び出しを含む）。1 人の上限を先に見たいときは countUser → countTotal の順に呼ぶ */
export async function countQuestion(store: Store, userId: string, now: number): Promise<{ user: number; total: number }> {
  const user = await countUser(store, userId, now);
  const total = await countTotal(store, now);
  return { user, total };
}
