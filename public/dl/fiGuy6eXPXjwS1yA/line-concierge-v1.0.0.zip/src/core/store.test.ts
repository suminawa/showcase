import { describe, expect, it } from "vitest";
import { fakeFetch, jsonResponse } from "../../test/fake-fetch";
import { createMemoryStore, createStoreFromEnv, createUpstashStore, MAX_KEYS, StoreError, withFallback } from "./store";

describe("createMemoryStore", () => {
  it("set / get / del と、期限切れ", async () => {
    let now = 1_000_000;
    const store = createMemoryStore(() => now);
    await store.set("a", "1", 10);
    expect(await store.get("a")).toBe("1");
    now += 9_999;
    expect(await store.get("a")).toBe("1");
    now += 1;
    expect(await store.get("a")).toBeNull();
    await store.set("b", "x", 10);
    await store.del("b");
    expect(await store.get("b")).toBeNull();
  });

  it("incr は 1 から数え、期限は最初の incr で決まる", async () => {
    let now = 0;
    const store = createMemoryStore(() => now);
    expect(await store.incr("c", 60)).toBe(1);
    now += 30_000;
    expect(await store.incr("c", 60)).toBe(2);
    now += 30_000;
    expect(await store.get("c")).toBeNull();
    expect(await store.incr("c", 60)).toBe(1);
  });

  it("鍵が上限を超えたら古いものから落とす", async () => {
    const store = createMemoryStore(() => 0);
    for (let i = 0; i < MAX_KEYS + 1; i += 1) await store.set(`k${i}`, "v", 3600);
    expect(await store.get("k0")).toBeNull();
    expect(await store.get(`k${MAX_KEYS}`)).toBe("v");
  });
});

describe("createUpstashStore", () => {
  it("REST にコマンドの配列を POST する", async () => {
    const net = fakeFetch([
      ["upstash", ({ body }) => {
        const [command] = body as [string];
        if (command === "GET") return jsonResponse({ result: "v" });
        if (command === "INCR") return jsonResponse({ result: 1 });
        return jsonResponse({ result: "OK" });
      }],
    ]);
    const store = createUpstashStore("https://x.upstash.io", "tok", net.fetch);
    await store.set("a", "v", 60);
    expect(net.calls[0].headers.authorization).toBe("Bearer tok");
    expect(net.calls[0].body).toEqual(["SET", "a", "v", "EX", 60]);
    expect(await store.get("a")).toBe("v");
    expect(net.calls[1].body).toEqual(["GET", "a"]);
    expect(await store.incr("c", 60)).toBe(1);
    expect(net.calls[2].body).toEqual(["INCR", "c"]);
    expect(net.calls[3].body).toEqual(["EXPIRE", "c", 60]);
    await store.del("a");
    expect(net.calls[4].body).toEqual(["DEL", "a"]);
  });

  it("2 回目以降の incr は EXPIRE を送らない", async () => {
    const net = fakeFetch([["upstash", () => jsonResponse({ result: 2 })]]);
    const store = createUpstashStore("https://x.upstash.io", "tok", net.fetch);
    expect(await store.incr("c", 60)).toBe(2);
    expect(net.calls).toHaveLength(1);
  });

  it("GET の null は null", async () => {
    const net = fakeFetch([["upstash", () => jsonResponse({ result: null })]]);
    expect(await createUpstashStore("https://x.upstash.io", "tok", net.fetch).get("a")).toBeNull();
  });

  it("届かない・2xx でない・error は StoreError", async () => {
    const down = fakeFetch([["upstash", () => new Error("ECONNREFUSED")]]);
    await expect(createUpstashStore("https://x.upstash.io", "tok", down.fetch).get("a")).rejects.toBeInstanceOf(StoreError);
    const bad = fakeFetch([["upstash", () => new Response("", { status: 500 })]]);
    await expect(createUpstashStore("https://x.upstash.io", "tok", bad.fetch).get("a")).rejects.toBeInstanceOf(StoreError);
    const err = fakeFetch([["upstash", () => jsonResponse({ error: "WRONGPASS" })]]);
    await expect(createUpstashStore("https://x.upstash.io", "tok", err.fetch).get("a")).rejects.toThrow(/WRONGPASS/);
  });
});

describe("withFallback", () => {
  it("主が失敗したら控えに落ち、知らせるのは 1 度だけ", async () => {
    const failing = createUpstashStore("https://x.upstash.io", "tok", fakeFetch([["upstash", () => new Error("down")]]).fetch);
    const memory = createMemoryStore(() => 0);
    const errors: unknown[] = [];
    const store = withFallback(failing, memory, (error) => errors.push(error));
    await store.set("a", "1", 60);
    expect(await store.get("a")).toBe("1");
    expect(await store.incr("c", 60)).toBe(1);
    expect(errors).toHaveLength(1);
  });
});

describe("createStoreFromEnv", () => {
  it("Upstash の設定が無ければメモリ、あれば Upstash（控えつき）", async () => {
    const memory = createStoreFromEnv({});
    await memory.set("a", "1", 60);
    expect(await memory.get("a")).toBe("1");
    const net = fakeFetch([["upstash", () => jsonResponse({ result: "v" })]]);
    const upstash = createStoreFromEnv({ UPSTASH_REDIS_REST_URL: "https://x.upstash.io", UPSTASH_REDIS_REST_TOKEN: "t" }, net.fetch, () => {});
    expect(await upstash.get("a")).toBe("v");
    expect(net.calls).toHaveLength(1);
  });
});
