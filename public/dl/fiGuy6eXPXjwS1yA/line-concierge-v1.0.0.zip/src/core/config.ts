import { resolveConfig, type ConciergeConfig } from "@suminawa/ai-concierge";
import type { HandoffSettings, LineConfig, LineSettings } from "./types";

/** LINE の上限。quick reply は 13 個・ラベル 20 字、1 通の文は 5,000 字 */
export const MAX_SUGGESTIONS = 13;
export const MAX_LABEL_CHARS = 20;
export const MAX_TEXT_CHARS = 5000;

// 言葉は部分一致で見るので、短い言葉は入れない（「電話」だけだと「電話番号を教えてください」まで引き継ぎになる）
export const DEFAULT_HANDOFF: HandoffSettings = {
  keywords: ["担当者", "人と話", "スタッフ", "電話で話", "お電話ください", "オペレーター"],
  label: "担当者に相談する",
  reply: "担当者におつなぎします。営業時間内に順次お返事します。",
  hours: 24,
};

export const DEFAULT_LINE = {
  fallback: "資料に載っていないため、お答えできません。担当者におつなぎしますか？",
  nonTextReply: "文字でご質問ください。",
  limitReply: "本日の受付の上限に達しました。明日またお試しください。",
  unavailableReply: "いまはお答えできません。しばらくしてからもう一度お送りください。",
  tooLongReply: "ご質問は {上限} 字以内でお送りください。",
  sourcesLabel: "参考",
  maxSources: 3,
  loading: true,
  perUserDaily: 30,
  historyMinutes: 60,
};

function fail(message: string): never {
  throw new Error(`concierge.config.json: ${message}`);
}

/** 環境変数の誤りは、設定ファイルではなく環境変数の話だと分かる書き出しにする */
function failEnv(message: string): never {
  throw new Error(`環境変数: ${message}`);
}

function recordOf(value: unknown, where: string): Record<string, unknown> {
  if (value === undefined || value === null) return {};
  if (typeof value !== "object" || Array.isArray(value)) fail(`${where} は { } の形にしてください`);
  return value as Record<string, unknown>;
}

function stringOf(value: unknown, where: string, fallback: string): string {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== "string") fail(`${where} は文字列にしてください`);
  if (value.length > MAX_TEXT_CHARS) fail(`${where} は ${MAX_TEXT_CHARS} 字以内にしてください（LINE の 1 通の上限）`);
  return value;
}

function numberOf(value: unknown, where: string, min: number, max: number, fallback: number, integer = false): number {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== "number" || !Number.isFinite(value)) fail(`${where} は数にしてください`);
  if (integer && !Number.isInteger(value)) fail(`${where} は整数にしてください（いまの値: ${value}）`);
  if (value < min || value > max) fail(`${where} は ${min} 〜 ${max} にしてください（いまの値: ${value}）`);
  return value;
}

function booleanOf(value: unknown, where: string, fallback: boolean): boolean {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== "boolean") fail(`${where} は true か false にしてください`);
  return value;
}

function stringArrayOf(value: unknown, where: string, fallback: string[]): string[] {
  if (value === undefined || value === null) return fallback;
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) fail(`${where} は文字列の一覧にしてください`);
  return (value as string[]).map((item) => item.trim()).filter((item) => item !== "");
}

function labelOf(value: string, where: string): string {
  if (value.length > MAX_LABEL_CHARS) {
    fail(`${where} の「${value}」は ${MAX_LABEL_CHARS} 字以内にしてください（LINE のボタンの上限）`);
  }
  return value;
}

export function checkSuggestions(list: string[], where: string): string[] {
  if (list.length > MAX_SUGGESTIONS) {
    fail(`${where} は ${MAX_SUGGESTIONS} 個までです（LINE のボタンの上限。いまは ${list.length} 個）`);
  }
  for (const item of list) labelOf(item, where);
  return list;
}

export function resolveLineSettings(file: unknown, concierge: ConciergeConfig): LineSettings {
  const root = recordOf(file, "設定");
  const raw = recordOf(root.line, "line");
  const handoffRaw = recordOf(raw.handoff, "line.handoff");
  const limitsRaw = recordOf(raw.limits, "line.limits");

  const handoff: HandoffSettings = {
    keywords: stringArrayOf(handoffRaw.keywords, "line.handoff.keywords", DEFAULT_HANDOFF.keywords),
    label: labelOf(stringOf(handoffRaw.label, "line.handoff.label", DEFAULT_HANDOFF.label), "line.handoff.label"),
    reply: stringOf(handoffRaw.reply, "line.handoff.reply", DEFAULT_HANDOFF.reply),
    hours: numberOf(handoffRaw.hours, "line.handoff.hours", 1, 720, DEFAULT_HANDOFF.hours, true),
  };

  // 候補（quick reply）は line.suggestions が無ければ core の suggestions を使う。core 側は字数を見ないので、ここで見る
  const suggestions = checkSuggestions(stringArrayOf(raw.suggestions, "line.suggestions", concierge.suggestions), "line.suggestions");

  return {
    greeting: stringOf(raw.greeting, "line.greeting", concierge.greeting),
    suggestions,
    fallback: stringOf(raw.fallback, "line.fallback", DEFAULT_LINE.fallback),
    handoff,
    nonTextReply: stringOf(raw.nonTextReply, "line.nonTextReply", DEFAULT_LINE.nonTextReply),
    limitReply: stringOf(raw.limitReply, "line.limitReply", DEFAULT_LINE.limitReply),
    unavailableReply: stringOf(raw.unavailableReply, "line.unavailableReply", DEFAULT_LINE.unavailableReply),
    tooLongReply: stringOf(raw.tooLongReply, "line.tooLongReply", DEFAULT_LINE.tooLongReply).replace(
      "{上限}",
      String(concierge.limits.maxInputChars),
    ),
    sourcesLabel: stringOf(raw.sourcesLabel, "line.sourcesLabel", DEFAULT_LINE.sourcesLabel),
    maxSources: numberOf(raw.maxSources, "line.maxSources", 0, 5, DEFAULT_LINE.maxSources, true),
    loading: booleanOf(raw.loading, "line.loading", DEFAULT_LINE.loading),
    perUserDaily: numberOf(limitsRaw.perUserDaily, "line.limits.perUserDaily", 1, 1000, DEFAULT_LINE.perUserDaily, true),
    historyMinutes: numberOf(raw.historyMinutes, "line.historyMinutes", 1, 1440, DEFAULT_LINE.historyMinutes, true),
  };
}

function envString(value: string | undefined): string | null {
  const trimmed = value?.trim() ?? "";
  return trimmed === "" ? null : trimmed;
}

export interface ResolveLineConfigInput {
  file?: unknown;
  env?: Record<string, string | undefined>;
}

/** core の resolveConfig（site / content / answer / limits など）に、line の節と LINE の秘密を足す */
export function resolveLineConfig(input: ResolveLineConfigInput = {}): LineConfig {
  const env = input.env ?? {};
  const concierge = resolveConfig({ file: input.file, env });
  const line = resolveLineSettings(input.file, concierge);

  const handoffWebhookUrl = envString(env.HANDOFF_WEBHOOK_URL);
  if (handoffWebhookUrl !== null && !/^https?:\/\//.test(handoffWebhookUrl)) {
    failEnv("HANDOFF_WEBHOOK_URL は http:// か https:// で始めてください");
  }
  const upstashUrl = envString(env.UPSTASH_REDIS_REST_URL);
  const upstashToken = envString(env.UPSTASH_REDIS_REST_TOKEN);
  if ((upstashUrl === null) !== (upstashToken === null)) {
    failEnv("UPSTASH_REDIS_REST_URL と UPSTASH_REDIS_REST_TOKEN は両方入れてください");
  }

  return {
    concierge,
    line,
    secrets: {
      channelSecret: envString(env.LINE_CHANNEL_SECRET),
      channelAccessToken: envString(env.LINE_CHANNEL_ACCESS_TOKEN),
      handoffWebhookUrl,
      upstashUrl,
      upstashToken,
    },
  };
}
