import { describe, expect, it } from "vitest";
import { citationDelta, fakeClient, finalOf, textDelta, type FakeClient } from "../../test/fake-anthropic";
import { fakeFetch, jsonResponse, type FakeFetch } from "../../test/fake-fetch";
import { fixtureIndex } from "../../test/index-fixture";
import { createLineBot, isHandoffRequest, redact, type LineBot } from "./bot";
import { resolveLineConfig } from "./config";
import { keys } from "./session";
import { signBody } from "./signature";
import { createMemoryStore } from "./store";
import type { LineApi, LineEvent, LineTextMessage, Store } from "./types";

const SECRET = "test-secret";

interface RecordingLineApi extends LineApi {
  replies: Array<{ replyToken: string; messages: LineTextMessage[] }>;
  loadings: string[];
  /** 呼ばれた順（返信が通知より先かを見る） */
  order: string[];
  replyError?: Error;
}

function recordingLineApi(): RecordingLineApi {
  const api: RecordingLineApi = {
    replies: [],
    loadings: [],
    order: [],
    async reply(replyToken, messages) {
      if (api.replyError !== undefined) throw api.replyError;
      api.order.push("reply");
      api.replies.push({ replyToken, messages });
    },
    async loading(chatId) {
      api.loadings.push(chatId);
    },
    async profile() {
      api.order.push("profile");
      return { displayName: "みなと 太郎" };
    },
    async info() {
      return { basicId: "@minato", displayName: "みなと工務店" };
    },
  };
  return api;
}

interface Harness {
  bot: LineBot;
  client: FakeClient;
  lineApi: RecordingLineApi;
  net: FakeFetch;
  store: Store;
  logs: string[];
  now: { value: number };
}

function answeredScript(): FakeClient {
  return fakeClient({
    events: [textDelta("市内と、隣接する三つの市までお伺いしております。[1]"), citationDelta(0, "市内と")],
    final: finalOf({ content: [{ type: "text", text: "市内と、隣接する三つの市までお伺いしております。[1]" }] }),
  });
}

function harness(
  options: { client?: FakeClient | null; env?: Record<string, string>; line?: Record<string, unknown>; store?: Store; net?: FakeFetch } = {},
): Harness {
  const now = { value: Date.UTC(2026, 8, 14, 1, 0, 0) };
  const config = resolveLineConfig({
    file: {
      site: { name: "みなと工務店" },
      suggestions: ["対応エリアはどこまでですか", "見積もりは無料ですか"],
      limits: { maxInputChars: 40, dailyQuestions: 5 },
      line: { limits: { perUserDaily: 2 }, ...(options.line ?? {}) },
    },
    env: { LINE_CHANNEL_SECRET: SECRET, LINE_CHANNEL_ACCESS_TOKEN: "tok", ANTHROPIC_API_KEY: "sk-test", ...(options.env ?? {}) },
  });
  const client = options.client === undefined ? answeredScript() : options.client;
  const lineApi = recordingLineApi();
  const net = options.net ?? fakeFetch([["hooks.slack.com", () => jsonResponse("ok")]]);
  const store = options.store ?? createMemoryStore(() => now.value);
  const logs: string[] = [];
  const bot = createLineBot(config, {
    client,
    index: fixtureIndex(),
    store,
    lineApi,
    fetch: net.fetch,
    now: () => now.value,
    logger: (message) => logs.push(message),
  });
  return { bot, client: client as FakeClient, lineApi, net, store, logs, now };
}

function textEvent(text: string, patch: Partial<LineEvent> & Record<string, unknown> = {}): LineEvent {
  return {
    type: "message",
    timestamp: 1700000000000,
    source: { type: "user", userId: "U1" },
    replyToken: "r1",
    webhookEventId: `e-${Math.random().toString(36).slice(2)}`,
    deliveryContext: { isRedelivery: false },
    message: { id: "m1", type: "text", text },
    ...patch,
  } as LineEvent;
}

interface PostOptions {
  secret?: string;
  raw?: string;
  signature?: string | null;
  path?: string;
}

/** 応答だけ受け取り、返信の仕事（work）は待たない */
async function send(bot: LineBot, events: LineEvent[], options: PostOptions = {}) {
  const raw = options.raw ?? JSON.stringify({ destination: "Ubot", events });
  const signature = options.signature === undefined ? await signBody(options.secret ?? SECRET, raw) : options.signature;
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (signature !== null) headers["x-line-signature"] = signature;
  const request = new Request(`http://localhost${options.path ?? "/api/line"}`, { method: "POST", headers, body: raw });
  return bot.handle(request);
}

async function post(bot: LineBot, events: LineEvent[], options: PostOptions = {}) {
  const { response, work } = await send(bot, events, options);
  await work;
  return response;
}

const tick = (): Promise<void> => new Promise((done) => setTimeout(done, 1));

describe("handle: 入口の守り", () => {
  it("GET /health は索引の様子を返す", async () => {
    const { bot } = harness();
    const { response } = await bot.handle(new Request("http://localhost/api/line/health"));
    expect(response.status).toBe(200);
    const body = (await response.json()) as { ok: boolean; documents: number; chunks: number; lineToken: boolean; apiKey: boolean };
    expect(body.ok).toBe(true);
    expect(body.documents).toBe(2);
    expect(body.chunks).toBeGreaterThan(0);
    expect(body.lineToken).toBe(true);
    expect(body.apiKey).toBe(true);
  });
  it("POST 以外は 405", async () => {
    const { bot } = harness();
    const { response } = await bot.handle(new Request("http://localhost/api/line", { method: "PUT" }));
    expect(response.status).toBe(405);
  });
  it("署名が合わなければ 401 で、何もしない", async () => {
    const h = harness();
    expect((await post(h.bot, [textEvent("営業時間は")], { secret: "wrong" })).status).toBe(401);
    expect((await post(h.bot, [textEvent("営業時間は")], { signature: null })).status).toBe(401);
    expect(h.lineApi.replies).toHaveLength(0);
    expect(h.client.calls).toHaveLength(0);
  });
  it("LINE_CHANNEL_SECRET が無ければ 500 で受け付けない", async () => {
    const h = harness({ env: { LINE_CHANNEL_SECRET: "" } });
    expect((await post(h.bot, [textEvent("x")])).status).toBe(500);
    expect(h.logs.join("\n")).toContain("LINE_CHANNEL_SECRET");
  });
  it("本文が壊れていれば 400、大きすぎれば 413", async () => {
    const h = harness();
    expect((await post(h.bot, [], { raw: "{bad" })).status).toBe(400);
    expect((await post(h.bot, [], { raw: JSON.stringify({ events: "x" }) })).status).toBe(400);
    expect((await post(h.bot, [], { raw: JSON.stringify({ events: [], pad: "x".repeat(70 * 1024) }) })).status).toBe(413);
  });
  it("検証の要求（events が空）は 200。LINE も Claude も呼ばない", async () => {
    const h = harness();
    expect((await post(h.bot, [])).status).toBe(200);
    expect(h.lineApi.replies).toHaveLength(0);
    expect(h.client.calls).toHaveLength(0);
  });
});

describe("handle: 文字のメッセージ", () => {
  it("答えて、参考と候補のボタンを付けて返信し、会話と記録を残す", async () => {
    const h = harness();
    const response = await post(h.bot, [textEvent("対応エリアはどこまでですか")]);
    expect(response.status).toBe(200);
    expect(h.lineApi.loadings).toEqual(["U1"]);
    expect(h.lineApi.replies).toHaveLength(1);
    expect(h.lineApi.replies[0].replyToken).toBe("r1");
    const [message] = h.lineApi.replies[0].messages;
    expect(message.text).toBe("市内と、隣接する三つの市までお伺いしております。\n\n参考:\n対応エリア https://example.com/area");
    expect(message.quickReply?.items.map((item) => item.action.text)).toEqual(["対応エリアはどこまでですか", "見積もりは無料ですか"]);
    expect(await h.store.get(keys.history("U1"))).toContain("対応エリアはどこまでですか");
    expect(h.bot.log.list()).toHaveLength(1);
    expect(h.bot.log.list()[0].answered).toBe(true);
    expect(h.bot.log.list()[0].question).toBe("対応エリアはどこまでですか");
  });

  it("2 問目は直近の会話を添えて Claude に送る", async () => {
    const h = harness();
    await post(h.bot, [textEvent("対応エリアはどこまでですか")]);
    await post(h.bot, [textEvent("見積もりは無料ですか", { replyToken: "r2" })]);
    expect(h.client.calls).toHaveLength(2);
    // 1 問目: 資料の確認の往復 + 質問。2 問目: それに前の往復（2 通）が足される
    expect(h.client.calls[1].messages.length).toBe(h.client.calls[0].messages.length + 2);
  });

  it("答えられなければ、断りの文と「担当者に相談する」のボタン。会話には残さない", async () => {
    const h = harness({ client: fakeClient({ events: [textDelta("資料に載っていません。")], final: finalOf() }) });
    await post(h.bot, [textEvent("社長の趣味は")]);
    const [message] = h.lineApi.replies[0].messages;
    expect(message.text).toBe(h.bot.config.line.fallback);
    expect(message.quickReply?.items[0].action.text).toBe("担当者に相談する");
    expect(await h.store.get(keys.history("U1"))).toBeNull();
    expect(h.bot.log.unanswered()).toHaveLength(1);
  });

  it("Claude が失敗したら「いまはお答えできません」", async () => {
    const h = harness({ client: fakeClient({ streamError: new Error("boom") }) });
    await post(h.bot, [textEvent("対応エリアは")]);
    expect(h.lineApi.replies[0].messages[0].text).toBe(h.bot.config.line.unavailableReply);
    expect(h.logs.join("\n")).toContain("boom");
  });

  it("鍵が無ければ Claude を呼ばずに「いまはお答えできません」", async () => {
    const h = harness({ client: null });
    await post(h.bot, [textEvent("対応エリアは")]);
    expect(h.lineApi.replies[0].messages[0].text).toBe(h.bot.config.line.unavailableReply);
  });

  it("長すぎる質問は字数の案内。空白だけなら黙る", async () => {
    const h = harness();
    await post(h.bot, [textEvent("あ".repeat(41))]);
    expect(h.lineApi.replies[0].messages[0].text).toBe("ご質問は 40 字以内でお送りください。");
    await post(h.bot, [textEvent("   ", { replyToken: "r2" })]);
    expect(h.lineApi.replies).toHaveLength(1);
    expect(h.client.calls).toHaveLength(0);
    // どちらも記録に残る（答えていない扱い）
    expect(h.bot.log.list()).toHaveLength(2);
    expect(h.bot.log.unanswered()).toHaveLength(2);
  });

  it("1 人 1 日の上限を超えたら limitReply。日が変われば戻る", async () => {
    const h = harness();
    await post(h.bot, [textEvent("対応エリアは")]);
    await post(h.bot, [textEvent("料金は", { replyToken: "r2" })]);
    await post(h.bot, [textEvent("保証は", { replyToken: "r3" })]);
    expect(h.lineApi.replies[2].messages[0].text).toBe(h.bot.config.line.limitReply);
    expect(h.client.calls).toHaveLength(2);
    // 上限で断った分も記録に残る（買い手が「断られた数」を見られるように）
    expect(h.bot.log.list()).toHaveLength(3);
    expect(h.bot.log.list()[0].answered).toBe(false);
    expect(h.bot.log.list()[0].question).toBe("保証は");
    expect(h.bot.log.list()[0].outputTokens).toBe(0);
    // 上限を超えた人のぶんは、全体の回数に数えない
    expect(await h.store.get(keys.day("2026-09-14"))).toBe("2");
    h.now.value += 24 * 3600 * 1000;
    await post(h.bot, [textEvent("保証は", { replyToken: "r4" })]);
    expect(h.client.calls).toHaveLength(3);
  });

  it("全体の 1 日の上限も効く", async () => {
    const h = harness();
    for (let i = 0; i < 5; i += 1) {
      await post(h.bot, [textEvent("対応エリアは", { source: { type: "user", userId: `U${i}` }, replyToken: `r${i}` })]);
    }
    await post(h.bot, [textEvent("対応エリアは", { source: { type: "user", userId: "U9" }, replyToken: "r9" })]);
    expect(h.lineApi.replies[5].messages[0].text).toBe(h.bot.config.line.limitReply);
    expect(h.client.calls).toHaveLength(5);
  });

  it("文字以外のメッセージには nonTextReply。空なら黙る", async () => {
    const h = harness();
    await post(h.bot, [textEvent("", { message: { id: "m2", type: "sticker" } })]);
    expect(h.lineApi.replies[0].messages[0].text).toBe("文字でご質問ください。");
    const quiet = harness({ line: { nonTextReply: "" } });
    await post(quiet.bot, [textEvent("", { message: { id: "m2", type: "image" } })]);
    expect(quiet.lineApi.replies).toHaveLength(0);
  });

  it("loading を切れば「入力中」を出さない", async () => {
    const h = harness({ line: { loading: false } });
    await post(h.bot, [textEvent("対応エリアは")]);
    expect(h.lineApi.loadings).toEqual([]);
  });

  it("返信に失敗しても落ちず、記録に残す", async () => {
    const h = harness();
    h.lineApi.replyError = new Error("Invalid reply token");
    const response = await post(h.bot, [textEvent("対応エリアは")]);
    expect(response.status).toBe(200);
    expect(h.logs.join("\n")).toContain("Invalid reply token");
  });
});

describe("handle: 引き継ぎ", () => {
  it("引き継ぎの言葉が来たら返事をして印を付け、Slack に知らせる。その後は黙る", async () => {
    const h = harness({ env: { HANDOFF_WEBHOOK_URL: "https://hooks.slack.com/services/x" } });
    await post(h.bot, [textEvent("担当者と話したいです")]);
    expect(h.lineApi.replies[0].messages[0].text).toBe(h.bot.config.line.handoff.reply);
    expect(h.client.calls).toHaveLength(0);
    expect(await h.store.get(keys.handoff("U1"))).toBe("1");
    const slack = h.net.calls.find((call) => call.url.includes("hooks.slack.com"));
    expect(slack).toBeDefined();
    const text = (slack?.body as { text: string }).text;
    expect(text).toContain("みなと 太郎（U1）");
    expect(text).toContain("担当者と話したいです");
    // お客さまへの返信を、担当者への通知（名前の取得と Slack への送信）より先に済ませる
    expect(h.lineApi.order).toEqual(["reply", "profile"]);
    // 引き継ぎも記録に残る（費用は 0、答えていない扱い）
    expect(h.bot.log.list()[0].answered).toBe(false);
    expect(h.bot.log.list()[0].question).toBe("担当者と話したいです");
    expect(h.bot.log.list()[0].inputTokens).toBe(0);
    await post(h.bot, [textEvent("対応エリアは", { replyToken: "r2" })]);
    expect(h.lineApi.replies).toHaveLength(1);
    expect(h.client.calls).toHaveLength(0);
    // 有人対応中に届いた文も記録に残す（買い手が黙っていた分を見られるように）
    expect(h.bot.log.list()).toHaveLength(2);
    expect(h.bot.log.list()[0].question).toBe("対応エリアは");
    expect(h.bot.log.list()[0].answered).toBe(false);
  });

  it("「電話番号を教えてください」は引き継がずに答える。「電話で話したいです」は引き継ぐ", async () => {
    const h = harness({ env: { HANDOFF_WEBHOOK_URL: "https://hooks.slack.com/services/x" } });
    await post(h.bot, [textEvent("電話番号を教えてください")]);
    expect(h.client.calls).toHaveLength(1);
    expect(h.lineApi.replies[0].messages[0].text).toContain("参考:");
    expect(await h.store.get(keys.handoff("U1"))).toBeNull();
    expect(h.net.calls).toHaveLength(0);
    await post(h.bot, [textEvent("電話で話したいです", { source: { type: "user", userId: "U2" }, replyToken: "r2" })]);
    expect(h.lineApi.replies[1].messages[0].text).toBe(h.bot.config.line.handoff.reply);
    expect(h.client.calls).toHaveLength(1);
    expect(await h.store.get(keys.handoff("U2"))).toBe("1");
  });

  it("ボタンの文字そのものでも引き継ぐ。Webhook が無ければ通知は送らない", async () => {
    const h = harness({ line: { handoff: { keywords: ["人間"], label: "人に聞く" } } });
    await post(h.bot, [textEvent("人に聞く")]);
    expect(await h.store.get(keys.handoff("U1"))).toBe("1");
    expect(h.net.calls).toHaveLength(0);
  });

  it("hours が過ぎれば AI が答える", async () => {
    const h = harness({ line: { handoff: { hours: 1 } } });
    await post(h.bot, [textEvent("担当者")]);
    h.now.value += 3600 * 1000;
    await post(h.bot, [textEvent("対応エリアは", { replyToken: "r2" })]);
    expect(h.client.calls).toHaveLength(1);
  });
});

describe("handle: follow / unfollow / その他", () => {
  it("follow にはあいさつと候補のボタン", async () => {
    const h = harness();
    await post(h.bot, [{ type: "follow", source: { type: "user", userId: "U1" }, replyToken: "rf", webhookEventId: "ef" }]);
    const [message] = h.lineApi.replies[0].messages;
    expect(message.text).toBe(h.bot.config.line.greeting);
    expect(message.quickReply?.items).toHaveLength(2);
  });
  it("unfollow は会話と印を消す", async () => {
    const h = harness();
    await post(h.bot, [textEvent("対応エリアは")]);
    await post(h.bot, [{ type: "unfollow", source: { type: "user", userId: "U1" }, webhookEventId: "eu" }]);
    expect(await h.store.get(keys.history("U1"))).toBeNull();
  });
  it("グループの出来事と、知らない type は無視する", async () => {
    const h = harness();
    await post(h.bot, [textEvent("対応エリアは", { source: { type: "group", groupId: "G1", userId: "U1" } }), { type: "postback", source: { type: "user", userId: "U1" }, replyToken: "rp" } as LineEvent]);
    expect(h.lineApi.replies).toHaveLength(0);
    expect(h.client.calls).toHaveLength(0);
  });
  it("同じ webhookEventId は 2 度処理しない。検証用のトークンには返信しない", async () => {
    const h = harness();
    const event = textEvent("対応エリアは", { webhookEventId: "same" });
    await post(h.bot, [event]);
    await post(h.bot, [{ ...event, deliveryContext: { isRedelivery: true } }]);
    expect(h.client.calls).toHaveLength(1);
    await post(h.bot, [textEvent("対応エリアは", { replyToken: "00000000000000000000000000000000" })]);
    expect(h.lineApi.replies).toHaveLength(1);
    // ダミーのトークンでは Claude も呼ばない（回数にも数えない）
    expect(h.client.calls).toHaveLength(1);
  });
  it("1 件が失敗しても次の出来事は処理する。work は決して reject しない", async () => {
    // 保存先が 1 件目の再送の印で落ちる。2 件目はそのまま処理される
    const memory = createMemoryStore(() => 0);
    const failing: Store = {
      get: async (key) => {
        if (key.includes("boom")) throw new Error("store down");
        return memory.get(key);
      },
      set: memory.set,
      incr: memory.incr,
      del: memory.del,
    };
    const h = harness({ store: failing });
    const broken = textEvent("対応エリアは", { webhookEventId: "boom" });
    await expect(post(h.bot, [broken, textEvent("料金は", { replyToken: "r2" })])).resolves.toBeDefined();
    expect(h.lineApi.replies).toHaveLength(1);
    expect(h.logs.join("\n")).toContain("store down");
    // message の無い message イベントは飛ばす（落ちない）
    await post(h.bot, [textEvent("x", { message: null as unknown as { type: string }, replyToken: "r3" })]);
    expect(h.lineApi.replies).toHaveLength(1);
  });
});

describe("simulate / greet", () => {
  it("LINE を呼ばずに、返すはずのメッセージを返す", async () => {
    const h = harness();
    const outcome = await h.bot.simulate("Usim", "対応エリアはどこまでですか");
    expect(outcome.answered).toBe(true);
    expect(outcome.reason).toBe("answered");
    expect(outcome.messages[0].text).toContain("参考:");
    expect(h.bot.greet()[0].text).toBe(h.bot.config.line.greeting);
  });
});

describe("記録の Webhook", () => {
  it("LOG_WEBHOOK_URL があれば 1 件ずつ送る（slack 形は text）", async () => {
    const h = harness({ env: { LOG_WEBHOOK_URL: "https://hooks.slack.com/services/log", LOG_WEBHOOK_FORMAT: "slack" } });
    await post(h.bot, [textEvent("対応エリアは")]);
    const call = h.net.calls.find((item) => item.url.endsWith("/log"));
    expect((call?.body as { text: string }).text).toContain("LINE");
  });

  it("simulate も自分の送信を待ってから返す", async () => {
    const sent: string[] = [];
    const net = fakeFetch([
      [
        "hooks.slack.com",
        async () => {
          await new Promise((done) => setTimeout(done, 20));
          sent.push("log");
          return jsonResponse("ok");
        },
      ],
    ]);
    const h = harness({ env: { LOG_WEBHOOK_URL: "https://hooks.slack.com/services/log" }, net });
    await h.bot.simulate("Usim", "対応エリアはどこまでですか");
    expect(sent).toEqual(["log"]);
  });

  it("同時に来た 2 本の要求は、それぞれの送信を自分の work で待つ", async () => {
    const gates: Array<() => void> = [];
    const net = fakeFetch([["hooks.slack.com", () => new Promise<Response>((resolve) => gates.push(() => resolve(jsonResponse("ok"))))]]);
    const h = harness({ env: { LOG_WEBHOOK_URL: "https://hooks.slack.com/services/log" }, net });
    const first = await send(h.bot, [textEvent("対応エリアは")]);
    const second = await send(h.bot, [textEvent("料金は", { source: { type: "user", userId: "U2" }, replyToken: "r2" })]);
    const done = [false, false];
    void first.work.then(() => {
      done[0] = true;
    });
    void second.work.then(() => {
      done[1] = true;
    });
    while (gates.length < 2) await tick();
    // どちらの work も、自分の送信が終わるまで待っている
    expect(done).toEqual([false, false]);
    gates[0]();
    await tick();
    expect(done.filter(Boolean)).toHaveLength(1);
    gates[1]();
    await Promise.all([first.work, second.work]);
    expect(done).toEqual([true, true]);
  });
});

describe("isHandoffRequest / redact", () => {
  it("言葉を含むか、ボタンの文字そのもの", () => {
    expect(isHandoffRequest("担当者をお願いします", ["担当者"], "人に聞く")).toBe(true);
    expect(isHandoffRequest("人に聞く", ["担当者"], "人に聞く")).toBe(true);
    expect(isHandoffRequest("料金は", ["担当者"], "人に聞く")).toBe(false);
    expect(isHandoffRequest("料金は", [""], "人に聞く")).toBe(false);
  });
  it("メールと電話番号と長い数字を伏せる", () => {
    expect(redact("taro@example.com へ 090-1234-5678 か 123456789012")).toBe("***@*** へ *** か ***");
  });
});
