import type { LineEvent, LineFollowEvent, LineMessageEvent, LineTextMessageEvent, LineUnfollowEvent, LineWebhookBody } from "./types";

/** LINE の Webhook は小さい。これより大きい本文は読まない */
export const MAX_BODY_BYTES = 64 * 1024;

/** LINE Developers Console の「検証」や古い案内の試験用トークン。返信には使えない */
const DUMMY_TOKENS = new Set(["00000000000000000000000000000000", "ffffffffffffffffffffffffffffffff"]);

function fail(message: string): never {
  throw new Error(`webhook: ${message}`);
}

/** JSON.parse したものを、使う形に絞る。壊れた要素は捨て、events が無ければ止める */
export function parseWebhookBody(value: unknown): LineWebhookBody {
  if (typeof value !== "object" || value === null || Array.isArray(value)) fail("本文が { } の形ではありません");
  const raw = value as Record<string, unknown>;
  if (!Array.isArray(raw.events)) fail("events が一覧ではありません");
  const events: LineEvent[] = [];
  for (const item of raw.events) {
    if (typeof item !== "object" || item === null || Array.isArray(item)) continue;
    const event = item as Record<string, unknown>;
    if (typeof event.type !== "string") continue;
    events.push(event as unknown as LineEvent);
  }
  return { destination: typeof raw.destination === "string" ? raw.destination : "", events };
}

export function isTextMessage(event: LineEvent): event is LineTextMessageEvent {
  if (event.type !== "message") return false;
  const message = (event as LineMessageEvent).message;
  return typeof message === "object" && message !== null && message.type === "text" && typeof message.text === "string";
}

export function isFollow(event: LineEvent): event is LineFollowEvent {
  return event.type === "follow";
}

export function isUnfollow(event: LineEvent): event is LineUnfollowEvent {
  return event.type === "unfollow";
}

/** 1 対 1 のトーク（source.type が user）の相手だけ。グループ・複数人は null */
export function userIdOf(event: LineEvent): string | null {
  const source = event.source;
  if (source === undefined || source === null || source.type !== "user") return null;
  if (typeof source.userId !== "string" || source.userId === "") return null;
  return source.userId;
}

export function replyTokenOf(event: LineEvent): string | null {
  const token = (event as { replyToken?: unknown }).replyToken;
  if (typeof token !== "string" || token === "" || DUMMY_TOKENS.has(token)) return null;
  return token;
}

export function isRedelivery(event: LineEvent): boolean {
  return event.deliveryContext?.isRedelivery === true;
}
