const encoder = new TextEncoder();

function base64Of(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

/** チャネルシークレットを鍵にした本文の HMAC-SHA256 を Base64 で返す（LINE の署名と同じ作り方） */
export async function signBody(secret: string, body: Uint8Array | string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const data = typeof body === "string" ? encoder.encode(body) : body;
  // TS の Uint8Array<ArrayBufferLike> と BufferSource（ArrayBuffer 限定）の食い違い。実行時は常に有効な BufferSource
  const mac = await crypto.subtle.sign("HMAC", key, data as BufferSource);
  return base64Of(new Uint8Array(mac));
}

/** 長さが同じ文字列を、途中で抜けずに比べる（署名の比較で時間の差を出さないため） */
export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** x-line-signature が、本文の生バイトから作った署名と一致するか */
export async function verifySignature(secret: string, body: Uint8Array, header: string | null): Promise<boolean> {
  if (header === null || header === "") return false;
  const expected = await signBody(secret, body);
  return timingSafeEqual(expected, header);
}
