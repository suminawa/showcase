import { clip } from "./reply";

export const NOTIFY_TIMEOUT_MS = 5000;
/** 通知に載せるお客さまの文の上限。長い文で Slack 側に弾かれないように切る */
export const HANDOFF_MESSAGE_CHARS = 500;

/** JSON を POST する。届かなくても投げず false（通知は答えを止めない） */
export async function postJson(url: string, payload: unknown, fetchImpl: typeof fetch = fetch, timeoutMs: number = NOTIFY_TIMEOUT_MS): Promise<boolean> {
  try {
    const res = await fetchImpl(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(timeoutMs),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/** Slack の Incoming Webhook（{ text } を受け取る）へ */
export function postSlack(url: string, text: string, fetchImpl: typeof fetch = fetch): Promise<boolean> {
  return postJson(url, { text }, fetchImpl);
}

/** 担当者への引き継ぎを知らせる文。相手の文は伏せ字にせず載せる（担当者が返事をするために要る。長い文は 500 字で切る） */
export function handoffText(siteName: string, displayName: string, userId: string, message: string): string {
  return [
    `[${siteName}] LINE で担当者への引き継ぎがありました`,
    `相手: ${displayName}（${userId}）`,
    `文: ${clip(message, HANDOFF_MESSAGE_CHARS)}`,
    "LINE Official Account Manager のチャット画面からお返事ください。",
  ].join("\n");
}
