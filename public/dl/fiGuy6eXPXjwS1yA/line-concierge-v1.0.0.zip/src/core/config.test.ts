import { describe, expect, it } from "vitest";
import { DEFAULT_HANDOFF, DEFAULT_LINE, MAX_LABEL_CHARS, MAX_SUGGESTIONS, resolveLineConfig } from "./config";

const FILE = {
  site: { name: "みなと工務店" },
  content: "samples/content",
  greeting: "こんにちは。みなと工務店です。",
  suggestions: ["対応エリアはどこまでですか", "見積もりは無料ですか"],
  limits: { maxInputChars: 400, dailyQuestions: 500 },
};

describe("resolveLineConfig", () => {
  it("line の節が無ければ既定値で埋まり、あいさつと候補は core の値を使う", () => {
    const config = resolveLineConfig({ file: FILE, env: {} });
    expect(config.concierge.site.name).toBe("みなと工務店");
    expect(config.line.greeting).toBe("こんにちは。みなと工務店です。");
    expect(config.line.suggestions).toEqual(["対応エリアはどこまでですか", "見積もりは無料ですか"]);
    expect(config.line.fallback).toBe(DEFAULT_LINE.fallback);
    expect(config.line.handoff).toEqual(DEFAULT_HANDOFF);
    // 言葉は部分一致で見るので、既定には「電話」のような短い言葉を入れない
    expect(config.line.handoff.keywords).toEqual(["担当者", "人と話", "スタッフ", "電話で話", "お電話ください", "オペレーター"]);
    expect(config.line.handoff.keywords).not.toContain("電話");
    expect(config.line.perUserDaily).toBe(30);
    expect(config.line.historyMinutes).toBe(60);
    expect(config.line.maxSources).toBe(3);
    expect(config.line.loading).toBe(true);
    expect(config.line.tooLongReply).toBe("ご質問は 400 字以内でお送りください。");
    expect(config.secrets).toEqual({
      channelSecret: null,
      channelAccessToken: null,
      handoffWebhookUrl: null,
      upstashUrl: null,
      upstashToken: null,
    });
  });

  it("line の節の値が既定値より優先される", () => {
    const config = resolveLineConfig({
      file: {
        ...FILE,
        line: {
          greeting: "友だち追加ありがとうございます。",
          suggestions: ["営業時間は"],
          fallback: "載っていません。",
          handoff: { keywords: ["人間"], label: "人に聞く", reply: "つなぎます。", hours: 2 },
          nonTextReply: "",
          limitReply: "上限です。",
          unavailableReply: "後でどうぞ。",
          tooLongReply: "{上限} 字まで。",
          sourcesLabel: "出典",
          maxSources: 1,
          loading: false,
          limits: { perUserDaily: 5 },
          historyMinutes: 10,
        },
      },
      env: {},
    });
    expect(config.line.greeting).toBe("友だち追加ありがとうございます。");
    expect(config.line.suggestions).toEqual(["営業時間は"]);
    expect(config.line.handoff).toEqual({ keywords: ["人間"], label: "人に聞く", reply: "つなぎます。", hours: 2 });
    expect(config.line.nonTextReply).toBe("");
    expect(config.line.tooLongReply).toBe("400 字まで。");
    expect(config.line.sourcesLabel).toBe("出典");
    expect(config.line.maxSources).toBe(1);
    expect(config.line.loading).toBe(false);
    expect(config.line.perUserDaily).toBe(5);
    expect(config.line.historyMinutes).toBe(10);
  });

  it("環境変数の秘密を読む。前後の空白は落とす", () => {
    const config = resolveLineConfig({
      file: FILE,
      env: {
        LINE_CHANNEL_SECRET: " secret ",
        LINE_CHANNEL_ACCESS_TOKEN: "token",
        ANTHROPIC_API_KEY: "sk-test",
        HANDOFF_WEBHOOK_URL: "https://hooks.slack.com/services/x",
        UPSTASH_REDIS_REST_URL: "https://x.upstash.io",
        UPSTASH_REDIS_REST_TOKEN: "t",
      },
    });
    expect(config.secrets.channelSecret).toBe("secret");
    expect(config.secrets.channelAccessToken).toBe("token");
    expect(config.concierge.apiKey).toBe("sk-test");
    expect(config.secrets.handoffWebhookUrl).toBe("https://hooks.slack.com/services/x");
    expect(config.secrets.upstashUrl).toBe("https://x.upstash.io");
    expect(config.secrets.upstashToken).toBe("t");
  });

  it("ボタンが 14 個あれば止める", () => {
    const suggestions = Array.from({ length: MAX_SUGGESTIONS + 1 }, (_, i) => `候補 ${i}`);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { suggestions } }, env: {} })).toThrow(/13 個まで/);
  });

  it("ボタンの文字が 21 字あれば止める", () => {
    const long = "あ".repeat(MAX_LABEL_CHARS + 1);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { suggestions: [long] } }, env: {} })).toThrow(/20 字以内/);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { handoff: { label: long } } }, env: {} })).toThrow(/20 字以内/);
  });

  it("範囲の外の数は止める", () => {
    expect(() => resolveLineConfig({ file: { ...FILE, line: { handoff: { hours: 0 } } }, env: {} })).toThrow(/line\.handoff\.hours/);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { limits: { perUserDaily: 1001 } } }, env: {} })).toThrow(/perUserDaily/);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { maxSources: 6 } }, env: {} })).toThrow(/maxSources/);
  });

  it("小数は止める（回数と時間は整数だけ）", () => {
    expect(() => resolveLineConfig({ file: { ...FILE, line: { limits: { perUserDaily: 30.5 } } }, env: {} })).toThrow(
      /line\.limits\.perUserDaily は整数にしてください/,
    );
    expect(() => resolveLineConfig({ file: { ...FILE, line: { handoff: { hours: 1.5 } } }, env: {} })).toThrow(/整数/);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { maxSources: 2.5 } }, env: {} })).toThrow(/整数/);
    expect(() => resolveLineConfig({ file: { ...FILE, line: { historyMinutes: 10.5 } }, env: {} })).toThrow(/整数/);
  });

  it("Upstash の URL とトークンは両方要る", () => {
    expect(() => resolveLineConfig({ file: FILE, env: { UPSTASH_REDIS_REST_URL: "https://x.upstash.io" } })).toThrow(/^環境変数: .*両方/);
  });

  it("HANDOFF_WEBHOOK_URL は http か https", () => {
    expect(() => resolveLineConfig({ file: FILE, env: { HANDOFF_WEBHOOK_URL: "ftp://x" } })).toThrow(/^環境変数: .*https/);
  });

  it("core 側の検査もそのまま効く（answer.model が claude- で始まらなければ止める）", () => {
    expect(() => resolveLineConfig({ file: { ...FILE, answer: { model: "gpt-x" } }, env: {} })).toThrow(/claude-/);
  });
});
