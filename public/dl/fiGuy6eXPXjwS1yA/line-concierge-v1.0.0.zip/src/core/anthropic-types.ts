import type { AnthropicClientLike } from "@suminawa/ai-concierge";

/**
 * core は AnthropicClientLike と MessageParams だけを公開している。
 * 偽の client を作るために要る型を、公開型から派生させる（core の types.ts と同じ形になる）。
 */
export type MessageStreamLike = ReturnType<AnthropicClientLike["messages"]["stream"]>;
export type FinalMessageLike = Awaited<ReturnType<MessageStreamLike["finalMessage"]>>;
export type StreamEventLike = MessageStreamLike extends AsyncIterable<infer Event> ? Event : never;
