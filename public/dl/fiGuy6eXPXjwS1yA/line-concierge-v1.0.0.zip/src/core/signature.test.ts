import { describe, expect, it } from "vitest";
import { signBody, timingSafeEqual, verifySignature } from "./signature";

// LINE の文書「署名を検証する」の例と同じ値（openssl で確認済み）
const BODY = '{"destination":"U8e742f61d673b39c7fff3cecb7536ef0","events":[]}';
const SECRET = "8c570fa6dd201bb328f1c1eac23a96d8";
const SIGNATURE = "GhRKmvmHys4Pi8DxkF4+EayaH0OqtJtaZxgTD9fMDLs=";

describe("signBody", () => {
  it("LINE の文書の例と同じ署名になる", async () => {
    expect(await signBody(SECRET, BODY)).toBe(SIGNATURE);
    expect(await signBody(SECRET, new TextEncoder().encode(BODY))).toBe(SIGNATURE);
  });
});

describe("verifySignature", () => {
  const bytes = new TextEncoder().encode(BODY);
  it("合えば true", async () => {
    expect(await verifySignature(SECRET, bytes, SIGNATURE)).toBe(true);
  });
  it("秘密が違えば false", async () => {
    expect(await verifySignature("other", bytes, SIGNATURE)).toBe(false);
  });
  it("本文が 1 字でも違えば false", async () => {
    expect(await verifySignature(SECRET, new TextEncoder().encode(BODY + " "), SIGNATURE)).toBe(false);
  });
  it("ヘッダーが無い・空なら false", async () => {
    expect(await verifySignature(SECRET, bytes, null)).toBe(false);
    expect(await verifySignature(SECRET, bytes, "")).toBe(false);
  });
});

describe("timingSafeEqual", () => {
  it("同じなら true、長さが違っても違っても false", () => {
    expect(timingSafeEqual("abc", "abc")).toBe(true);
    expect(timingSafeEqual("abc", "abd")).toBe(false);
    expect(timingSafeEqual("abc", "ab")).toBe(false);
  });
});
