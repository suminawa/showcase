import type { PromptSource } from "@suminawa/ai-concierge";
import { MAX_LABEL_CHARS, MAX_SUGGESTIONS, MAX_TEXT_CHARS } from "./config";
import type { LineSettings, LineTextMessage, QuickReplyItem } from "./types";

/** 本文の [1] [2] の印を取る（LINE では番号の付いた出典は「参考」の行にまとめる） */
export function stripMarkers(text: string): string {
  return text
    .replace(/\s*\[\d+\]/g, "")
    .replace(/[ \t]+$/gm, "")
    .trim();
}

/** LINE の 1 通の上限で切る */
export function clip(text: string, max: number = MAX_TEXT_CHARS): string {
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

/** 候補の質問を quick reply のボタンにする（13 個まで、ラベルは 20 字まで。押すと本文がそのまま送られる） */
export function quickReplyOf(items: string[]): { items: QuickReplyItem[] } | undefined {
  const list = items.slice(0, MAX_SUGGESTIONS).map(
    (text): QuickReplyItem => ({ type: "action", action: { type: "message", label: text.slice(0, MAX_LABEL_CHARS), text } }),
  );
  return list.length === 0 ? undefined : { items: list };
}

export function textMessage(text: string, quickReply?: { items: QuickReplyItem[] }): LineTextMessage {
  const message: LineTextMessage = { type: "text", text: clip(text) };
  if (quickReply !== undefined) message.quickReply = quickReply;
  return message;
}

/** 引用された順に「タイトル URL」を並べる。URL の無い文書は載せない。同じ URL は 1 度 */
export function sourcesBlock(label: string, sources: PromptSource[], citations: number[], max: number): string {
  if (max <= 0) return "";
  const seen = new Set<string>();
  const lines: string[] = [];
  for (const index of citations) {
    const source = sources.find((item) => item.index === index);
    if (source === undefined || source.url === null || seen.has(source.url)) continue;
    seen.add(source.url);
    lines.push(`${source.title} ${source.url}`);
    if (lines.length >= max) break;
  }
  return lines.length === 0 ? "" : `${label}:\n${lines.join("\n")}`;
}

/** 答えられたとき: 本文 + 参考 + 候補のボタン（1 通） */
export function answerMessages(text: string, sources: PromptSource[], citations: number[], settings: LineSettings): LineTextMessage[] {
  const body = stripMarkers(text);
  const refs = sourcesBlock(settings.sourcesLabel, sources, citations, settings.maxSources);
  return [textMessage(refs === "" ? body : `${body}\n\n${refs}`, quickReplyOf(settings.suggestions))];
}

/** 答えられなかったとき: 断りの文 + 先頭に「担当者に相談する」のボタン */
export function fallbackMessages(settings: LineSettings): LineTextMessage[] {
  return [textMessage(settings.fallback, quickReplyOf([settings.handoff.label, ...settings.suggestions]))];
}
