import { HISTORY_TURNS } from "@suminawa/ai-concierge";
import { describe, expect, it } from "vitest";
import { clearUser, countQuestion, COUNT_TTL_SECONDS, dayKeyOf, EVENT_TTL_SECONDS, inHandoff, keys, loadHistory, markHandoff, saveHistory, seenEvent } from "./session";
import { createMemoryStore } from "./store";

describe("dayKeyOf", () => {
  it("JST の日付になる（UTC の 15:00 は翌日）", () => {
    expect(dayKeyOf(Date.UTC(2026, 8, 14, 14, 59, 59))).toBe("2026-09-14");
    expect(dayKeyOf(Date.UTC(2026, 8, 14, 15, 0, 0))).toBe("2026-09-15");
  });
});

describe("会話", () => {
  it("往復を貯め、直近 HISTORY_TURNS 往復だけ残す", async () => {
    let now = 0;
    const store = createMemoryStore(() => now);
    expect(await loadHistory(store, "U1")).toEqual([]);
    for (let i = 0; i < HISTORY_TURNS + 2; i += 1) {
      const history = await loadHistory(store, "U1");
      await saveHistory(store, "U1", history, `質問 ${i}`, `答え ${i}`, 60);
    }
    const history = await loadHistory(store, "U1");
    expect(history).toHaveLength(HISTORY_TURNS * 2);
    expect(history[0]).toEqual({ role: "user", content: "質問 2" });
    expect(history[history.length - 1]).toEqual({ role: "assistant", content: `答え ${HISTORY_TURNS + 1}` });
    now += 60_001;
    expect(await loadHistory(store, "U1")).toEqual([]);
  });

  it("壊れた保存内容は空として扱う", async () => {
    const store = createMemoryStore(() => 0);
    await store.set(keys.history("U1"), "{bad json", 60);
    expect(await loadHistory(store, "U1")).toEqual([]);
    await store.set(keys.history("U1"), JSON.stringify([{ role: "x", content: 1 }, { role: "user", content: "ok" }]), 60);
    expect(await loadHistory(store, "U1")).toEqual([{ role: "user", content: "ok" }]);
  });

  it("clearUser は会話と有人対応の印を消す", async () => {
    const store = createMemoryStore(() => 0);
    await saveHistory(store, "U1", [], "q", "a", 60);
    await markHandoff(store, "U1", 1);
    await clearUser(store, "U1");
    expect(await loadHistory(store, "U1")).toEqual([]);
    expect(await inHandoff(store, "U1")).toBe(false);
  });
});

describe("有人対応の印", () => {
  it("hours の間だけ true", async () => {
    let now = 0;
    const store = createMemoryStore(() => now);
    expect(await inHandoff(store, "U1")).toBe(false);
    await markHandoff(store, "U1", 2);
    expect(await inHandoff(store, "U1")).toBe(true);
    now += 2 * 3600 * 1000 - 1;
    expect(await inHandoff(store, "U1")).toBe(true);
    now += 1;
    expect(await inHandoff(store, "U1")).toBe(false);
  });
});

describe("再送の印", () => {
  it("同じ webhookEventId は 2 回目から true。1 時間で忘れる", async () => {
    let now = 0;
    const store = createMemoryStore(() => now);
    expect(await seenEvent(store, "e1")).toBe(false);
    expect(await seenEvent(store, "e1")).toBe(true);
    now += EVENT_TTL_SECONDS * 1000;
    expect(await seenEvent(store, "e1")).toBe(false);
  });
});

describe("回数", () => {
  it("1 人と全体を日ごとに数える", async () => {
    const store = createMemoryStore(() => 0);
    const at = Date.UTC(2026, 8, 14, 1, 0, 0);
    expect(await countQuestion(store, "U1", at)).toEqual({ user: 1, total: 1 });
    expect(await countQuestion(store, "U2", at)).toEqual({ user: 1, total: 2 });
    expect(await countQuestion(store, "U1", at)).toEqual({ user: 2, total: 3 });
    expect(await store.get(keys.userDay("U1", "2026-09-14"))).toBe("2");
    expect(await store.get(keys.day("2026-09-14"))).toBe("3");
    expect(COUNT_TTL_SECONDS).toBe(2 * 24 * 3600);
  });
});
