import { spawn, type ChildProcessByStdio } from "node:child_process";
import { existsSync } from "node:fs";
import { mkdtemp, writeFile } from "node:fs/promises";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import type { Readable } from "node:stream";
import { afterEach, describe, expect, it } from "vitest";
import { fixtureIndex } from "../../test/index-fixture";

type Child = ChildProcessByStdio<null, Readable, Readable>;

/**
 * 組み上げた dist/adapters/node.js が「node で直に起動して立ち上がるか」を見る。
 * tsup が分割すると main() の判定（import.meta.url）が外れて何も起きなくなるので、
 * 組み上げたファイルそのものを動かして確かめる。
 */
const ENTRY = resolve(process.cwd(), "dist/adapters/node.js");
const built = existsSync(ENTRY);
if (!built) {
  console.warn(`node.e2e.test.ts を飛ばします: ${ENTRY} がありません。npm run build のあとに走ります。`);
}

/** 環境変数をまるごと決める（親の LINE_* や ANTHROPIC_API_KEY を持ち込まない） */
function cleanEnv(extra: Record<string, string> = {}): Record<string, string> {
  const base: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value === undefined) continue;
    if (/^(LINE_|ANTHROPIC_|CONCIERGE_|UPSTASH_|HANDOFF_|LOG_|PORT$|MAX_INPUT_|DAILY_)/.test(key)) continue;
    base[key] = value;
  }
  return { ...base, ...extra };
}

async function freePort(): Promise<number> {
  return new Promise((done, fail) => {
    const probe = createServer();
    probe.on("error", fail);
    probe.listen(0, "127.0.0.1", () => {
      const address = probe.address();
      const port = typeof address === "object" && address !== null ? address.port : 0;
      probe.close(() => done(port));
    });
  });
}

const children: Child[] = [];
afterEach(() => {
  for (const child of children.splice(0)) if (child.exitCode === null) child.kill("SIGKILL");
});

function start(cwd: string, env: Record<string, string>): { child: Child; out: () => string } {
  const child = spawn(process.execPath, [ENTRY], { cwd, env, stdio: ["ignore", "pipe", "pipe"] });
  children.push(child);
  let text = "";
  child.stdout.setEncoding("utf8");
  child.stderr.setEncoding("utf8");
  child.stdout.on("data", (chunk: string) => {
    text += chunk;
  });
  child.stderr.on("data", (chunk: string) => {
    text += chunk;
  });
  return { child, out: () => text };
}

describe.skipIf(!built)("node dist/adapters/node.js", () => {
  it("鍵が無ければ、足りないものを伝えて 1 で終わる（main() が動いている証拠）", async () => {
    const dir = await mkdtemp(join(tmpdir(), "lc-e2e-"));
    const { child, out } = start(dir, cleanEnv());
    const code = await new Promise<number | null>((done) => child.on("exit", done));
    expect(code).toBe(1);
    expect(out()).toContain("LINE_CHANNEL_SECRET と LINE_CHANNEL_ACCESS_TOKEN を環境変数に入れてください");
  }, 20000);

  it("設定と索引と鍵が揃えば待ち受け、/api/line/health が 200 を返す", async () => {
    const dir = await mkdtemp(join(tmpdir(), "lc-e2e-"));
    const indexPath = join(dir, "index.json");
    await writeFile(indexPath, JSON.stringify(fixtureIndex().file), "utf8");
    await writeFile(
      join(dir, "concierge.config.json"),
      JSON.stringify({ site: { name: "みなと工務店" }, suggestions: ["対応エリアはどこまでですか"] }),
      "utf8",
    );
    const port = await freePort();
    const { child, out } = start(
      dir,
      cleanEnv({
        LINE_CHANNEL_SECRET: "e2e-secret",
        LINE_CHANNEL_ACCESS_TOKEN: "e2e-token",
        ANTHROPIC_API_KEY: "sk-e2e",
        CONCIERGE_INDEX: indexPath,
        PORT: String(port),
      }),
    );
    let body: { ok?: boolean; documents?: number } | null = null;
    const until = Date.now() + 10000;
    while (Date.now() < until) {
      if (child.exitCode !== null) break;
      try {
        const res = await fetch(`http://127.0.0.1:${port}/api/line/health`);
        if (res.status === 200) {
          body = (await res.json()) as { ok?: boolean; documents?: number };
          break;
        }
      } catch {
        // まだ待ち受けていない
      }
      await new Promise((done) => setTimeout(done, 100));
    }
    expect(body, `立ち上がりませんでした: ${out()}`).not.toBeNull();
    expect(body?.ok).toBe(true);
    expect(body?.documents).toBe(2);
    expect(out()).toContain("/api/line で待っています");
    child.kill("SIGKILL");
  }, 30000);
});
