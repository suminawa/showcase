import { describe, expect, it } from "vitest";
import { isMainModule } from "./main-module";

describe("isMainModule", () => {
  it("同じファイルなら true、違えば false、無ければ false", () => {
    const self = new URL(import.meta.url);
    expect(isMainModule(self.pathname, import.meta.url)).toBe(true);
    expect(isMainModule("/no/such/file.js", import.meta.url)).toBe(false);
    expect(isMainModule(undefined, import.meta.url)).toBe(false);
  });
});
