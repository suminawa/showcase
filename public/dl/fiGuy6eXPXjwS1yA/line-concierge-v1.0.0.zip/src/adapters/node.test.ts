import type { AddressInfo } from "node:net";
import { afterEach, describe, expect, it } from "vitest";
import { citationDelta, fakeClient, finalOf, textDelta } from "../../test/fake-anthropic";
import { fixtureIndex } from "../../test/index-fixture";
import { createLineBot, type LineBot } from "../core/bot";
import { resolveLineConfig } from "../core/config";
import { signBody } from "../core/signature";
import type { LineApi, LineTextMessage } from "../core/types";
import { createNodeServer } from "./node";

const SECRET = "s";

function slowLineApi(): LineApi & { replies: LineTextMessage[][]; repliedAt: number[] } {
  const api = {
    replies: [] as LineTextMessage[][],
    repliedAt: [] as number[],
    async reply(_token: string, messages: LineTextMessage[]) {
      await new Promise((done) => setTimeout(done, 30));
      api.replies.push(messages);
      api.repliedAt.push(Date.now());
    },
    async loading() {},
    async profile() {
      return null;
    },
    async info() {
      return { basicId: "@x", displayName: "x" };
    },
  };
  return api;
}

function makeBot(lineApi: LineApi): LineBot {
  const config = resolveLineConfig({
    file: { site: { name: "みなと工務店" } },
    env: { LINE_CHANNEL_SECRET: SECRET, LINE_CHANNEL_ACCESS_TOKEN: "tok", ANTHROPIC_API_KEY: "sk" },
  });
  return createLineBot(config, {
    index: fixtureIndex(),
    lineApi,
    client: fakeClient({ events: [textDelta("市内にお伺いします。[1]"), citationDelta(0, "市内")], final: finalOf() }),
    logger: () => {},
  });
}

const servers: Array<ReturnType<typeof createNodeServer>> = [];
afterEach(async () => {
  for (const server of servers.splice(0)) await new Promise<void>((done) => server.close(() => done()));
});

async function listen(bot: LineBot, onWork?: (work: Promise<void>) => void): Promise<string> {
  const server = createNodeServer(bot, { onWork });
  servers.push(server);
  await new Promise<void>((done) => server.listen(0, "127.0.0.1", done));
  const { port } = server.address() as AddressInfo;
  return `http://127.0.0.1:${port}`;
}

describe("createNodeServer", () => {
  it("先に 200 を返し、そのあとで返信が飛ぶ", async () => {
    const lineApi = slowLineApi();
    const works: Promise<void>[] = [];
    const base = await listen(makeBot(lineApi), (work) => works.push(work));
    const body = JSON.stringify({
      destination: "Ubot",
      events: [{ type: "message", source: { type: "user", userId: "U1" }, replyToken: "r1", message: { type: "text", text: "対応エリアは" } }],
    });
    const res = await fetch(`${base}/api/line`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-line-signature": await signBody(SECRET, body) },
      body,
    });
    const respondedAt = Date.now();
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true });
    expect(lineApi.replies).toHaveLength(0);
    await works[0];
    expect(lineApi.replies).toHaveLength(1);
    expect(lineApi.repliedAt[0]).toBeGreaterThanOrEqual(respondedAt);
  });

  it("署名が違えば 401、GET /health は 200、ほかの道は 404、大きな本文は 413", async () => {
    const base = await listen(makeBot(slowLineApi()));
    const bad = await fetch(`${base}/api/line`, { method: "POST", headers: { "x-line-signature": "x" }, body: "{}" });
    expect(bad.status).toBe(401);
    const health = await fetch(`${base}/api/line/health`);
    expect(health.status).toBe(200);
    expect(((await health.json()) as { documents: number }).documents).toBe(2);
    expect((await fetch(`${base}/other`)).status).toBe(404);
    const big = await fetch(`${base}/api/line`, { method: "POST", headers: { "x-line-signature": "x" }, body: "x".repeat(70 * 1024) });
    expect(big.status).toBe(413);
  });
});
