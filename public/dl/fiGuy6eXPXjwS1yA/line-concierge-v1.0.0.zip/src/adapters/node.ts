import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { indexSummary, loadConfigFile, loadIndex } from "@suminawa/ai-concierge";
import { createLineBot, type LineBot } from "../core/bot";
import { resolveLineConfig } from "../core/config";
import { MAX_BODY_BYTES } from "../core/events";
import { createFakeClient } from "../core/fake-client";
import { createStoreFromEnv } from "../core/store";
import { isMainModule } from "./main-module";

export interface NodeServerOptions {
  /** Webhook の道。既定 /api/line（/api/line/health も含む） */
  apiPrefix?: string;
  /** 応答を返したあとの仕事（返信）を受け取る。テストで待つため */
  onWork?: (work: Promise<void>) => void;
}

class BodyTooLargeError extends Error {}

function firstHeaderValue(value: string | string[] | undefined): string | undefined {
  if (value === undefined) return undefined;
  const first = (Array.isArray(value) ? value[0] : value.split(",")[0]).trim();
  return first === "" ? undefined : first;
}

export async function toWebRequest(req: IncomingMessage, origin: string): Promise<Request> {
  const url = new URL(req.url ?? "/", origin);
  const headers = new Headers();
  for (const [key, value] of Object.entries(req.headers)) {
    if (value === undefined) continue;
    headers.set(key, Array.isArray(value) ? value.join(", ") : value);
  }
  const method = req.method ?? "GET";
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return new Request(url, { method, headers });
  const chunks: Uint8Array[] = [];
  let total = 0;
  for await (const chunk of req) {
    const piece = chunk as Uint8Array;
    total += piece.byteLength;
    if (total > MAX_BODY_BYTES) throw new BodyTooLargeError();
    chunks.push(piece);
  }
  return new Request(url, { method, headers, body: Buffer.concat(chunks) });
}

export async function sendWebResponse(res: ServerResponse, response: Response): Promise<void> {
  res.on("error", () => {});
  res.statusCode = response.status;
  response.headers.forEach((value, key) => res.setHeader(key, value));
  res.end(await response.text());
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  res.statusCode = status;
  res.setHeader("content-type", "application/json; charset=utf-8");
  res.end(JSON.stringify(body));
}

export function createNodeServer(bot: LineBot, options: NodeServerOptions = {}): Server {
  const apiPrefix = options.apiPrefix ?? "/api/line";
  return createServer((req, res) => {
    res.on("error", () => {});
    void (async () => {
      try {
        const host = req.headers.host ?? "127.0.0.1";
        const proto = firstHeaderValue(req.headers["x-forwarded-proto"]) ?? "http";
        const origin = `${proto}://${host}`;
        const pathname = new URL(req.url ?? "/", origin).pathname;
        if (pathname !== apiPrefix && !pathname.startsWith(`${apiPrefix}/`)) {
          res.statusCode = 404;
          res.end("Not Found");
          return;
        }
        let request: Request;
        try {
          request = await toWebRequest(req, origin);
        } catch (error) {
          if (!(error instanceof BodyTooLargeError)) throw error;
          sendJson(res, 413, { ok: false, message: "本文が大きすぎます。" });
          return;
        }
        const { response, work } = await bot.handle(request);
        // LINE には先に 200 を返し、それから答えを作って返信する（LINE の推奨どおり）
        await sendWebResponse(res, response);
        options.onWork?.(work);
        await work;
      } catch (error) {
        console.error("line-concierge:", error);
        if (!res.headersSent) {
          res.statusCode = 500;
          res.end("Server Error");
        } else if (!res.writableEnded) {
          res.end();
        }
      }
    })();
  });
}

/** node dist/adapters/node.js で立ち上がる。設定と索引はカレントから読む */
export async function main(): Promise<Server> {
  const config = resolveLineConfig({ file: await loadConfigFile("concierge.config.json"), env: process.env });
  if (config.secrets.channelSecret === null || config.secrets.channelAccessToken === null) {
    console.error("line-concierge: LINE_CHANNEL_SECRET と LINE_CHANNEL_ACCESS_TOKEN を環境変数に入れてください。");
    process.exit(1);
  }
  const index = await loadIndex(config.concierge.indexPath);
  // LINE_FAKE=1 のときは鍵を使わず、決まった答えを返す（動きの確認用）
  const client = process.env.LINE_FAKE === "1" ? createFakeClient() : undefined;
  const bot = createLineBot(config, { index, client, store: createStoreFromEnv(process.env) });
  const server = createNodeServer(bot);
  const port = Number(process.env.PORT ?? 8787);
  server.listen(port, () => {
    console.log(
      `line-concierge: http://127.0.0.1:${port}/api/line で待っています（${indexSummary(index)}）。公開した URL を LINE Developers の Webhook URL に入れてください。`,
    );
  });
  return server;
}

if (isMainModule(process.argv[1], import.meta.url)) {
  void main();
}
