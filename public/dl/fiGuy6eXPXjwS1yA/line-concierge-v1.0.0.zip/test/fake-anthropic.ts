import type { AnthropicClientLike, MessageParams } from "@suminawa/ai-concierge";
import type { FinalMessageLike, MessageStreamLike, StreamEventLike } from "../src/core/anthropic-types";

export interface FakeScript {
  events?: StreamEventLike[];
  final?: FinalMessageLike;
  streamError?: Error;
  finalError?: Error;
}

export interface FakeClient extends AnthropicClientLike {
  calls: MessageParams[];
}

export function textDelta(text: string): StreamEventLike {
  return { type: "content_block_delta", index: 0, delta: { type: "text_delta", text } } as StreamEventLike;
}

export function citationDelta(documentIndex: number, citedText: string): StreamEventLike {
  return {
    type: "content_block_delta",
    index: 0,
    delta: {
      type: "citations_delta",
      citation: {
        type: "char_location",
        cited_text: citedText,
        document_index: documentIndex,
        document_title: `[${documentIndex + 1}] 見本`,
        start_char_index: 0,
        end_char_index: citedText.length,
      },
    },
  } as StreamEventLike;
}

export function finalOf(patch: Partial<FinalMessageLike> = {}): FinalMessageLike {
  return {
    stop_reason: "end_turn",
    usage: { input_tokens: 120, output_tokens: 80, cache_read_input_tokens: 29800, cache_creation_input_tokens: 0 },
    content: [{ type: "text", text: "" }],
    ...patch,
  } as FinalMessageLike;
}

export function fakeClient(script: FakeScript = {}): FakeClient {
  const calls: MessageParams[] = [];
  return {
    calls,
    messages: {
      stream(params: MessageParams): MessageStreamLike {
        calls.push(params);
        const events = script.events ?? [];
        return {
          async *[Symbol.asyncIterator](): AsyncGenerator<StreamEventLike> {
            if (script.streamError !== undefined) throw script.streamError;
            for (const event of events) yield event;
          },
          async finalMessage(): Promise<FinalMessageLike> {
            if (script.finalError !== undefined) throw script.finalError;
            return script.final ?? finalOf();
          },
          abort(): void {},
        } as MessageStreamLike;
      },
    },
  };
}
