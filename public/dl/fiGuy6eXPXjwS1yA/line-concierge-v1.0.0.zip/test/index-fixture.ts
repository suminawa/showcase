import { buildIndexFile, chunkDocument, parseMarkdown, toLoadedIndex, type LoadedIndex } from "@suminawa/ai-concierge";

const AREA = `---
url: https://example.com/area
updatedAt: 2026-09-01
---
# 対応エリア

## お伺いする範囲

市内と、隣接する三つの市までお伺いしております。現地調査とお見積もりは無料です。
`;

const PRICE = `---
url: https://example.com/price
updatedAt: 2026-09-01
---
# 料金の目安

## キッチン

キッチンの入れ替えは 80 万円からです。
`;

/** 見本の会社（架空）の小さな索引。全文投入（whole）の範囲に収まる */
export function fixtureIndex(): LoadedIndex {
  const drafts = [chunkDocument(parseMarkdown(AREA, "area")), chunkDocument(parseMarkdown(PRICE, "price"))];
  return toLoadedIndex(buildIndexFile(drafts, "2026-09-14T00:00:00.000Z"));
}
