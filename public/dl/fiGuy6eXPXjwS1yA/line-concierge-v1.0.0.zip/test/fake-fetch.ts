export interface FakeCall {
  url: string;
  method: string;
  headers: Record<string, string>;
  body: unknown;
}

export type FakeRoute = (call: FakeCall) => Response | Promise<Response> | Error;

export interface FakeFetch {
  fetch: typeof fetch;
  calls: FakeCall[];
  /** url に含まれる文字列で応答を選ぶ。合うものが無ければ 404 */
  routes: Array<[string, FakeRoute]>;
}

export function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

/** fetch の偽物。要求を記録し、url の部分一致で応答を返す */
export function fakeFetch(routes: Array<[string, FakeRoute]> = []): FakeFetch {
  const calls: FakeCall[] = [];
  const state: FakeFetch = { calls, routes, fetch: async () => new Response("", { status: 404 }) };
  state.fetch = (async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    const headers: Record<string, string> = {};
    new Headers(init?.headers).forEach((value, key) => {
      headers[key] = value;
    });
    let body: unknown = null;
    if (typeof init?.body === "string") {
      try {
        body = JSON.parse(init.body);
      } catch {
        body = init.body;
      }
    }
    const call: FakeCall = { url, method: init?.method ?? "GET", headers, body };
    calls.push(call);
    for (const [needle, route] of state.routes) {
      if (!url.includes(needle)) continue;
      const result = await route(call);
      if (result instanceof Error) throw result;
      return result;
    }
    return new Response("", { status: 404 });
  }) as typeof fetch;
  return state;
}
