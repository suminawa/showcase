# LINE 案内窓口 ── Next.js テンプレ

Vercel に置くだけで、LINE 公式アカウントの Webhook を受けて答えるアプリです。画面はありません。

## 1. 文書を置く

`content/` に Markdown を置きます。書き方は core の README.ja.md「3. 文書を用意する」と同じです。元になる公開ページがあるときは、先頭に次の front matter を付けると、答えの根拠がそのページへ向きます。

```markdown
---
url: https://example.com/price
updatedAt: 2026-09-01
---
```

`concierge.config.json` も自社向けに書き換えます。

- `site.name`: 会社名
- `line.greeting`: 友だち追加のあいさつ
- `suggestions`: 質問の候補
- `line.handoff`: 担当者に引き継ぐときの言葉・返信・受付時間

## 2. 索引を作る

```bash
npm install
npm run index
```

`data/index.json` ができます。Vercel は索引を作れないため、置く前に手元で作っておいてください。

## 3. 環境変数を入れる

| 名前 | 要否 | 説明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | 必須 | Anthropic Console で発行した鍵 |
| `LINE_CHANNEL_SECRET` | 必須 | LINE Developers で確認できるチャネルシークレット |
| `LINE_CHANNEL_ACCESS_TOKEN` | 必須 | LINE Developers で発行する長期のチャネルアクセストークン |
| `HANDOFF_WEBHOOK_URL` | 任意 | 担当者への引き継ぎを知らせる送り先 |
| `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN` | 任意 | 会話を続けたいときに設定します |
| `LOG_WEBHOOK_URL` / `LOG_WEBHOOK_FORMAT` | 任意 | ご質問の記録を送る先と形式 |

手元では `.env.local` に書きます。Vercel では Settings → Environment Variables から入れます。どちらも、最初の Deploy より前に済ませてください。

## 4. 手元で確かめる

1. `npm run check` を実行し、設定・索引・環境変数・LINE のトークンを確かめます。
2. `LINE_FAKE=1 npm run simulate -- --question "対応エリアは"` を実行し、Claude を呼ばずに返信の中身を確かめます。
3. `npm run dev` を実行し、`http://localhost:3000/api/line/health` を開いて動作を確かめます。

## 5. Vercel に置く手順

置く前に、手元で `npm install` と `npm run index` を済ませ、`data/index.json` があることを確かめてください。索引が無いと、Vercel では `/api/line/health` が 500 になります（Vercel の上では索引を作れません）。

1. Vercel でこのフォルダを Import します（GitHub を使わない場合は、このフォルダで `npx vercel login` → `npx vercel --prod`）。
2. 環境変数（§3 の表）を入れます。
3. Deploy します。
4. `https://<app>.vercel.app/api/line/health` を開き、`{"ok":true,...}` が返ることを確かめます。

Hobby プランでも動きます（`maxDuration = 60`）。

## 6. LINE 公式アカウントにつなぐ

1. LINE Developers でチャネルを開き、「Messaging API 設定」タブに進みます。
2. Webhook URL に `https://<app>.vercel.app/api/line` を入力し、「検証」を押して成功を確かめます。
3. 「Webhook の利用」をオンにします。
4. LINE Official Account Manager の「設定」→「応答設定」を開き、「応答メッセージ」と「あいさつメッセージ」をオフにします（キットが代わりに答えます）。
5. 同じ画面で「Webhook」をオンにします。
6. 自分のアカウントを友だち追加し、あいさつが届けば完了です。
