import type { NextConfig } from "next";

const config: NextConfig = {
  serverExternalPackages: ["@anthropic-ai/sdk"],
  // Route Handler は concierge.config.json と data/ 以下を「実行時」に読む。
  // Next.js の自動追跡はこの読み込みを見つけられないため、ここで明示しないと Vercel の束から漏れる
  outputFileTracingIncludes: {
    "/*": ["./concierge.config.json", "./data/**/*"],
  },
};

export default config;
