export default function Page() {
  return (
    <main>
      <h1>LINE 案内窓口</h1>
      <p>このアプリは LINE 公式アカウントの Webhook を受けるためのものです。画面はありません。</p>
      <p>
        Webhook の URL は <code>/api/line</code>、動作の確認は <code>/api/line/health</code> です。
      </p>
    </main>
  );
}
