import type { ReactNode } from "react";

export const metadata = {
  title: "LINE 案内窓口",
  description: "LINE 公式アカウントの Webhook を受けるアプリです。",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ja">
      <body style={{ fontFamily: "system-ui, sans-serif", margin: "0 auto", maxWidth: "40rem", padding: "3rem 1rem", lineHeight: 1.8 }}>
        {children}
      </body>
    </html>
  );
}
