import { loadConfigFile, loadIndex } from "@suminawa/ai-concierge";
import { createLineBot, createStoreFromEnv, resolveLineConfig, type LineBot } from "@suminawa/line-concierge";

// Next.js のファイルベースの経路では、../route.ts（/api/line）だけでは /api/line/health に届かない。
// 確認用の GET だけをここに置く（Webhook 本体は ../route.ts の POST）
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

let ready: Promise<LineBot> | null = null;

function bot(): Promise<LineBot> {
  if (ready === null) {
    ready = (async () => {
      const config = resolveLineConfig({ file: await loadConfigFile("concierge.config.json"), env: process.env });
      const index = await loadIndex(config.concierge.indexPath);
      return createLineBot(config, { index, store: createStoreFromEnv(process.env) });
    })();
  }
  return ready;
}

/** GET /api/line/health */
export async function GET(request: Request): Promise<Response> {
  return (await (await bot()).handle(request)).response;
}
