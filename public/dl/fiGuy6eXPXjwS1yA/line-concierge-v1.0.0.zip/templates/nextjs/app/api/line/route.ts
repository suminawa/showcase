import { loadConfigFile, loadIndex } from "@suminawa/ai-concierge";
import { createLineBot, createStoreFromEnv, resolveLineConfig, type LineBot } from "@suminawa/line-concierge";
import { after } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;
export const dynamic = "force-dynamic";

let ready: Promise<LineBot> | null = null;

function bot(): Promise<LineBot> {
  if (ready === null) {
    ready = (async () => {
      const config = resolveLineConfig({ file: await loadConfigFile("concierge.config.json"), env: process.env });
      const index = await loadIndex(config.concierge.indexPath);
      return createLineBot(config, { index, store: createStoreFromEnv(process.env) });
    })();
  }
  return ready;
}

/** LINE からの Webhook。先に 200 を返し、答えは after() で作って返信する */
export async function POST(request: Request): Promise<Response> {
  const { response, work } = await (await bot()).handle(request);
  after(() => work);
  return response;
}

/** GET /api/line/health */
export async function GET(request: Request): Promise<Response> {
  return (await (await bot()).handle(request)).response;
}
