import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    globals: true,
    // *.e2e.test.ts（組み上げた dist を動かす試験）も同じ形なのでこの一行に含まれる。
    // dist が無いときは、その中で飛ばす
    include: ["src/**/*.test.ts"],
    // 組み上げたファイルを spawn する試験があるので、既定より長めに待つ
    testTimeout: 15000,
  },
});
