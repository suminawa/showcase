/** スプレッドシートから設定と期限の行を読む。初期化では、足りないシート・見出し・設定の行だけを足す。 */
import { SETTINGS_TAB, sheetNamesFor } from "./check.js";
import { ConfigError, parseConfig } from "./config.js";
import { initFailureText } from "./setup.js";

/** 書き込みの権限が無いときに出す 1 文 */
const PERMISSION_TEXT = "このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください";

export function readConfig_() {
  const book = SpreadsheetApp.getActiveSpreadsheet();
  const timeZone = book.getSpreadsheetTimeZone();
  if (timeZone !== "Asia/Tokyo") {
    throw new ConfigError(
      "スプレッドシートのタイムゾーンが " +
        timeZone +
        " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。",
    );
  }
  const sheet = book.getSheetByName("設定");
  if (!sheet) throw new ConfigError("「設定」シートがありません。メニュー「期限アラート」→「初期化」を実行してください。");
  return parseConfig(sheet.getDataRange().getValues());
}

export function readItemValues_(sheetName) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) {
    throw new Error("「" + sheetName + "」シートがありません。設定シートの「対象シート名」と揃えてください。");
  }
  return sheet.getDataRange().getValues();
}

/**
 * 設定が壊れていてもエラーだけは届くように、通知先と Webhook URL だけを検証せずに読む。
 * 読めなければ null（そのときは実行ログだけが頼りになる）。
 */
export function readRawTarget_() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("設定");
    if (!sheet) return null;
    const rows = sheet.getDataRange().getValues();
    let webhookUrl = "";
    let target = "slack";
    for (let i = 0; i < rows.length; i += 1) {
      const key = String(rows[i][0]).replace(/\s+/g, "").toLowerCase();
      const value = String(rows[i][1]).trim();
      if (key === "webhookurl") webhookUrl = value;
      if (key === "通知先") target = value.toLowerCase() === "discord" ? "discord" : "slack";
    }
    if (webhookUrl.indexOf("https://") !== 0) return null;
    return { webhookUrl: webhookUrl, target: target };
  } catch (error) {
    return null;
  }
}

/** シートの値。1 行も無ければ [] */
function sheetValues_(sheet) {
  return sheet.getLastRow() === 0 ? [] : sheet.getDataRange().getValues();
}

/**
 * 初期化と「設定を確かめる」が読むもの。読むだけで、何も書かない。
 * sheets には「設定」と、設定「対象シート名」のシートのうち、あるものだけを載せる。
 */
export function readSetupSnapshot_(today) {
  const book = SpreadsheetApp.getActiveSpreadsheet();
  const sheets = {};
  const settings = book.getSheetByName(SETTINGS_TAB);
  if (settings) sheets[SETTINGS_TAB] = sheetValues_(settings);
  const names = sheetNamesFor(sheets[SETTINGS_TAB]);
  for (let i = 0; i < names.length; i += 1) {
    const sheet = book.getSheetByName(names[i]);
    if (sheet) sheets[names[i]] = sheetValues_(sheet);
  }
  return { timeZone: book.getSpreadsheetTimeZone(), today: today, sheets: sheets, hasTrigger: false };
}

/** 権限の例外を敬体の 1 文に言い換える。ほかはそのまま */
export function initPermissionError_(error) {
  const message = String(error && error.message ? error.message : error);
  if (/permission|権限|does not have|not have access|protected|保護/i.test(message)) return new Error(PERMISSION_TEXT);
  return error;
}

/** 「3,0」のような数とカンマだけの値は、Sheets が数と読み替えないよう ' を付けて字のまま置く */
function settingCell_(value) {
  const text = value === null || value === undefined ? "" : String(value);
  return /^[\d０-９\s]+([,、][\d０-９\s]+)+$/.test(text) ? "'" + text : text;
}

/** 行の長さをそろえる（setValues は長さの違う行を受け取らない） */
function squaredRows_(rows) {
  let width = 0;
  for (let i = 0; i < rows.length; i += 1) width = Math.max(width, rows[i].length);
  return rows.map((row) => {
    const line = row.map(settingCell_);
    while (line.length < width) line.push("");
    return line;
  });
}

/**
 * check.js の planInit が決めたものを足す。既にあるセルには 1 つも書かない。
 * 設定の行 → シート（作る・空のシートに書く）→ 見出し（1 行目のいまの右端の右）の順。
 */
export function applyInit_(plan) {
  const book = SpreadsheetApp.getActiveSpreadsheet();
  const done = [];
  try {
    const settingRows = plan.appendSettings.rows;
    if (settingRows.length > 0) {
      const sheet = book.getSheetByName(plan.appendSettings.sheet);
      sheet.getRange(sheet.getLastRow() + 1, 1, settingRows.length, 2).setValues(squaredRows_(settingRows));
      done.push("「" + plan.appendSettings.sheet + "」に " + settingRows.length + " 行を足しました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "設定への書き込み", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.createSheets.length; i += 1) {
      const made = plan.createSheets[i];
      const sheet = made.exists === true ? book.getSheetByName(made.name) : book.insertSheet(made.name);
      const rows = squaredRows_(made.rows);
      sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
      if (made.freeze === true) sheet.setFrozenRows(1);
      done.push(made.exists === true ? "空だった「" + made.name + "」シートに見出しを書きました" : "「" + made.name + "」シートを作りました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "シートの作成", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.appendHeaders.length; i += 1) {
      const entry = plan.appendHeaders[i];
      const sheet = book.getSheetByName(entry.sheet);
      const start = sheet.getLastColumn() + 1;
      const last = start + entry.names.length - 1;
      if (last > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), last - sheet.getMaxColumns());
      sheet.getRange(1, start, 1, entry.names.length).setValues([entry.names]);
      done.push("「" + entry.sheet + "」シートの見出しに足しました: " + entry.names.join("、"));
    }
  } catch (error) {
    throw new Error(initFailureText(done, "見出しの追記", initPermissionError_(error)));
  }
}
