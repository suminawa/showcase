/**
 * 入口。毎朝のトリガーは runDeadlineAlert を呼ぶ。
 * 失敗したときは、同じ通知先にエラーを 1 通流してから投げ直す（実行ログにも残す）。
 */
import { collectSections } from "./buckets.js";
import { todayKey } from "./dates.js";
import { removeSent } from "./dedupe.js";
import { parseItems } from "./items.js";
import { buildErrorMessage, buildMessage } from "./message.js";
import { checkNotes, findProblems, planInit, summaryLines } from "./check.js";
import { checkReport, initReport } from "./setup.js";
import { postWebhook_ } from "./gas_notify.js";
import { applyInit_, readConfig_, readItemValues_, readRawTarget_, readSetupSnapshot_ } from "./gas_sheets.js";
import { pruneSentStore_, readSentKeys_, saveSentKeys_ } from "./gas_store.js";

/**
 * 毎朝 8 時（Asia/Tokyo）に動く。メニューの「今すぐ通知を送る」からも呼べる。
 * dist/Code.gs の先頭に来る関数なので、エディタの実行ボタンは既定でこれを選ぶ。
 */
export function runDeadlineAlert() {
  const runDate = todayKey(new Date());
  let config = null;
  try {
    config = readConfig_();
    const parsed = parseItems(readItemValues_(config.sheetName), config);
    const sections = collectSections(parsed.items, config, runDate);
    pruneSentStore_(runDate);
    const sentKeys = readSentKeys_(runDate);
    const fresh = removeSent(sections, sentKeys, runDate);
    const text = buildMessage(fresh.sections, {
      todayKey: runDate,
      itemTemplate: config.itemTemplate,
      skipped: parsed.skipped,
    });
    if (text === null) {
      Logger.log("知らせるものがありません（" + runDate + "）");
      return;
    }
    postWebhook_(config.webhookUrl, text, config.target);
    saveSentKeys_(runDate, sentKeys.concat(fresh.keys));
    Logger.log("送信しました: " + fresh.keys.length + " 件");
  } catch (error) {
    reportError_(error, runDate, config);
    throw error;
  }
}

/** 失敗を同じ通知先へ流す。関数宣言は巻き上がるので、呼び出しより後ろに置いても動く */
export function reportError_(error, runDate, config) {
  try {
    const destination = config ? config : readRawTarget_();
    if (!destination || !destination.webhookUrl) return;
    postWebhook_(destination.webhookUrl, buildErrorMessage(error, runDate), destination.target);
  } catch (sendError) {
    Logger.log("エラー通知も送れませんでした: " + sendError);
  }
}

/** 通知先が合っているかだけを確かめる 1 通 */
export function sendTestNotification() {
  const runDate = todayKey(new Date());
  try {
    const config = readConfig_();
    postWebhook_(
      config.webhookUrl,
      "【期限アラート】テスト送信です。この文が見えていれば、通知先の設定は合っています。",
      config.target,
    );
  } catch (error) {
    reportError_(error, runDate, null);
    throw error;
  }
}

/** 毎朝 8 時（Asia/Tokyo）のトリガーを作り直す。何度押しても増えない */
export function createDailyTrigger() {
  const triggers = ScriptApp.getProjectTriggers();
  for (let i = 0; i < triggers.length; i += 1) {
    if (triggers[i].getHandlerFunction() === "runDeadlineAlert") ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger("runDeadlineAlert").timeBased().everyDays(1).atHour(8).inTimezone("Asia/Tokyo").create();
  Logger.log("毎朝 8 時のトリガーを作りました");
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

/** 毎朝の runDeadlineAlert のトリガーがあるか */
function hasDailyTrigger_() {
  const triggers = ScriptApp.getProjectTriggers();
  for (let i = 0; i < triggers.length; i += 1) {
    if (triggers[i].getHandlerFunction() === "runDeadlineAlert") return true;
  }
  return false;
}

/**
 * 足りないシート・見出し・設定の行だけを足す。何度押してもよく、既にある予定と設定の値は変えない。
 * runDeadlineAlert より後ろに置く（dist/Code.gs の最初の関数は runDeadlineAlert のまま）。
 */
export function initializeSheets() {
  const ui = SpreadsheetApp.getUi();
  try {
    const plan = planInit(readSetupSnapshot_(todayKey(new Date())));
    applyInit_(plan);
    ui.alert(initReport(plan, plan.nextStep));
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/** 直すところを全部並べる。無ければ、これから何が起きるかを短く出す */
export function checkSettings() {
  const ui = SpreadsheetApp.getUi();
  try {
    const snapshot = readSetupSnapshot_(todayKey(new Date()));
    snapshot.hasTrigger = hasDailyTrigger_();
    const problems = findProblems(snapshot);
    ui.alert(checkReport(problems, problems.length === 0 ? summaryLines(snapshot) : [], "", checkNotes(snapshot)));
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/** シートを開いたときにメニューを足す */
export function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("期限アラート")
    .addItem("初期化（足りないシート・見出し・設定を足す。データは消しません）", "initializeSheets")
    .addItem("設定を確かめる", "checkSettings")
    .addSeparator()
    .addItem("テスト送信", "sendTestNotification")
    .addItem("今すぐ通知を送る", "runDeadlineAlert")
    .addItem("毎朝 8 時に動かす", "createDailyTrigger")
    .addToUi();
}
