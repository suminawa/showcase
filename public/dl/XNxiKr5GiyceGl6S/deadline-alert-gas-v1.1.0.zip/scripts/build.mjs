#!/usr/bin/env node
// src/*.js を 1 本の dist/Code.gs にまとめる。買い手は Apps Script のエディタにこの 1 ファイルを貼る。
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/**
 * つなぐ順。先頭は入口の gas_main.js にする。
 * Apps Script のエディタは最初の関数を既定で選ぶので、買い手が実行ボタンを押すと runDeadlineAlert が動く。
 * 関数宣言は巻き上がるうえ、どのファイルも先頭で走るのは定数の初期化だけなので、前に置いても壊れない。
 * 以降は 純粋な処理 → GAS に触る部分。
 */
export const SOURCE_ORDER = [
  "gas_main.js",
  "dates.js",
  "config.js",
  "items.js",
  "buckets.js",
  "message.js",
  "dedupe.js",
  "setup.js",
  "check.js",
  "gas_store.js",
  "gas_sheets.js",
  "gas_notify.js",
];

export const MANIFEST = {
  timeZone: "Asia/Tokyo",
  dependencies: {},
  exceptionLogging: "STACKDRIVER",
  runtimeVersion: "V8",
};

/**
 * Apps Script は import / export を解さない。
 * 1 ファイルに並べれば同じ名前空間になるので、import 行は落とし、行頭の export だけを剥がす。
 */
export function toGasSource(source) {
  const lines = String(source).split("\n");
  const kept = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (/^import\s[^;]*from\s+["'][^"']+["'];?\s*$/.test(line)) continue;
    kept.push(line.replace(/^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\s)/, ""));
  }
  return kept.join("\n").trim();
}

export function buildSource(root) {
  const base = root === undefined ? ROOT : root;
  const parts = [];
  for (let i = 0; i < SOURCE_ORDER.length; i += 1) {
    const name = SOURCE_ORDER[i];
    parts.push("// ===== " + name + " =====\n" + toGasSource(readFileSync(join(base, "src", name), "utf8")));
  }
  const code = parts.join("\n\n");
  const leftover = code.match(/^\s*(import|export)\s/m);
  if (leftover) throw new Error("import / export が残っている: " + leftover[0].trim());
  return code;
}

export function build(root) {
  const base = root === undefined ? ROOT : root;
  mkdirSync(join(base, "dist"), { recursive: true });
  const header = "// 期限アラート GAS キット — scripts/build.mjs が src/ から作る。ここを直接編集しない\n\n";
  writeFileSync(join(base, "dist", "Code.gs"), header + buildSource(base) + "\n");
  writeFileSync(join(base, "dist", "appsscript.json"), JSON.stringify(MANIFEST, null, 2) + "\n");
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  build();
  console.log("wrote dist/Code.gs, dist/appsscript.json");
}
