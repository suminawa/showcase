import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";
import { buildSource } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const REAL_URL = "https://hooks.slack.com/services/T000/B000/xxxx";

// ===== つないだ 1 本を、GAS の偽物を並べた入れ物の中で実際に動かす =====
// 偽物の元: フォーム受付 GAS キット 1.0.0 の test/build.test.mjs の fakeSheet / runBundle。
// 初期化を通すために、getRange を行と列の位置どおりに書く形に広げ、insertSheet・setFrozenRows・
// insertColumnsAfter・getLastColumn・メニュー・トリガー・書き込みの権限なしを足した。

/** 見本 CSV を行と列に割る（"..." の中のカンマは区切りにしない） */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function sample(name) {
  return rowsOf(readFileSync(join(root, "samples", name), "utf8"));
}

/** 本物の Sheets と同じく、先頭の ' は字のままにする印として落とす */
function written(value) {
  return typeof value === "string" && value.charAt(0) === "'" ? value.slice(1) : value;
}

function fakeSheet(values, options) {
  const rows = values.map((row) => Array.from(row));
  const denied = (c) => {
    if (options.denyWrite === "protected") {
      throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit.");
    }
    if (options.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
    if (options.denyHeaderWrite && c > 1) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
  };
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const sheet = {
    rows: rows,
    frozen: 0,
    getLastRow: () => rows.length,
    getLastColumn: () => width(),
    getMaxColumns: () => Math.max(26, width()),
    insertColumnsAfter: () => {},
    setFrozenRows: (n) => {
      sheet.frozen = n;
    },
    getDataRange: () => ({ getValues: () => rows.map((row) => row.slice()) }),
    getRange: (r, c) => ({
      setValues: (block) => {
        denied(c);
        for (let i = 0; i < block.length; i += 1) {
          while (rows.length < r + i) rows.push([]);
          const line = rows[r - 1 + i];
          for (let j = 0; j < block[i].length; j += 1) {
            while (line.length < c - 1 + j) line.push("");
            line[c - 1 + j] = written(block[i][j]);
          }
        }
        const w = width();
        for (const line of rows) while (line.length < w) line.push("");
      },
    }),
    appendRow: (row) => {
      denied();
      rows.push(Array.from(row));
    },
  };
  return sheet;
}

/** つないだ 1 本を偽の GAS の上で読み込み、入口と、触った跡を返す */
function runBundle(seed, options) {
  const opts = options || {};
  const trace = { alerts: [], menu: [], logs: [], fetched: [] };
  const sheets = {};
  for (const name of Object.keys(seed)) sheets[name] = fakeSheet(seed[name], opts);
  const book = {
    getSpreadsheetTimeZone: () => (opts.timeZone === undefined ? "Asia/Tokyo" : opts.timeZone),
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (opts.denyWrite === "protected") {
        throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit.");
      }
      if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Spreadsheet.insertSheet.");
      sheets[name] = fakeSheet([], opts);
      return sheets[name];
    },
  };
  const menu = {
    addItem: (label, handler) => {
      trace.menu.push(label + " → " + handler);
      return menu;
    },
    addSeparator: () => {
      trace.menu.push("──");
      return menu;
    },
    addToUi: () => {},
  };
  const sandbox = {
    SpreadsheetApp: {
      getActiveSpreadsheet: () => book,
      getUi: () => ({ alert: (text) => trace.alerts.push(String(text)), createMenu: () => menu }),
    },
    ScriptApp: {
      getProjectTriggers: () => (opts.triggers || []).map((handler) => ({ getHandlerFunction: () => handler })),
    },
    PropertiesService: {
      getScriptProperties: () => ({ getProperty: () => null, setProperty: () => {}, getKeys: () => [], deleteProperty: () => {} }),
    },
    UrlFetchApp: {
      fetch: (url, fetchOptions) => {
        trace.fetched.push({ url: url, payload: fetchOptions.payload });
        return { getResponseCode: () => 200, getContentText: () => "ok" };
      },
    },
    Utilities: { newBlob: (text) => ({ getBytes: () => Array.from(Buffer.from(String(text), "utf8")) }) },
    Logger: { log: (text) => trace.logs.push(String(text)) },
  };
  const context = createContext(sandbox);
  runInContext(
    buildSource(root) +
      "\nglobalThis.__entry = { initializeSheets: initializeSheets, checkSettings: checkSettings, onOpen: onOpen, runDeadlineAlert: runDeadlineAlert };\n",
    context,
  );
  return { entry: sandbox.__entry, trace: trace, sheets: sheets };
}

function sampleSeed(withRealUrl) {
  return {
    設定: sample("settings-sample.csv").map((row) => (withRealUrl && row[0] === "Webhook URL" ? [row[0], REAL_URL] : row)),
    期限: sample("deadlines-sample.csv"),
  };
}

test("initializeSheets: 空のブックに 設定・期限 を作り、2 回目は「変更はありません」", () => {
  const run = runBundle({});
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("・シートを作りました: 設定、期限"), run.trace.alerts[0]);
  assert.equal(run.sheets["設定"].rows.length, 12);
  assert.deepEqual(run.sheets["設定"].rows[3], ["しきい値", "3,0"], "3,0 は字のまま入る");
  assert.deepEqual(run.sheets["期限"].rows, [["件名", "期限", "担当", "状態"]]);
  assert.equal(run.sheets["期限"].frozen, 1);

  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[1].startsWith("変更はありません。"), run.trace.alerts[1]);
  assert.equal(run.sheets["設定"].rows.length, 12);
});

test("checkSettings: 初期化しただけのブックでは、Webhook URL が空だと出る", () => {
  const run = runBundle({});
  run.entry.initializeSheets();
  run.entry.checkSettings();
  const text = run.trace.alerts[1];
  assert.ok(text.startsWith("直すところがあります。"), text);
  assert.ok(text.includes("・「設定」シートの「Webhook URL」が空です。README の手順 2 で作った URL を貼ってください。"));
  assert.ok(text.includes("ご参考:\n・毎朝 8 時の実行はまだ作っていません。"));
});

test("1.0 の見本のブック: 初期化は何も変えず、設定を確かめるは「問題ありません。」", () => {
  const seed = sampleSeed(true);
  const run = runBundle(seed, { triggers: ["runDeadlineAlert"] });
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].startsWith("変更はありません。"), run.trace.alerts[0]);
  assert.deepEqual(run.sheets["期限"].rows, seed.期限);
  assert.deepEqual(run.sheets["設定"].rows, seed.設定);

  run.entry.checkSettings();
  const text = run.trace.alerts[1];
  assert.ok(text.startsWith("問題ありません。\n\n通知: slack に、毎朝 8 時ごろ 1 通送ります（毎朝の実行: 作ってあります）"), text);
  assert.equal(text.includes(REAL_URL), false, "URL は出さない");
});

test("initializeSheets: 設定の行を行ごと消してから押すと、最終行の下に既定値で足す", () => {
  const seed = sampleSeed(true);
  seed.設定 = seed.設定.filter((row) => row[0] !== "しきい値");
  const run = runBundle(seed);
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("・「設定」シートに 1 行足しました: しきい値（値は既定値です。変えるときは書き換えてください）"));
  const rows = run.sheets["設定"].rows;
  assert.deepEqual(rows[rows.length - 1], ["しきい値", "3,0"]);
  assert.equal(rows.length, 12);
});

test("initializeSheets: 見出しが 1 列足りない期限シートに、既存の見出し・データはそのまま、新しい見出しだけ最終列の右に足す", () => {
  const seed = {
    設定: sample("settings-sample.csv").map((row) => (row[0] === "Webhook URL" ? [row[0], REAL_URL] : row)),
    期限: [
      ["件名", "期限", "担当"],
      ["A 社への請求書送付", "2026-09-20", "自分"],
      ["B 社との契約更新", "2026-09-25", "自分"],
    ],
  };
  const before = seed.期限.map((row) => row.slice());
  const run = runBundle(seed);
  run.entry.initializeSheets();
  const after = run.sheets["期限"].rows;
  // 新しい見出しは、それまでの最終列のすぐ右に 1 列だけ足される
  assert.equal(after[0].length, before[0].length + 1);
  assert.equal(after[0][before[0].length], "状態");
  // 既存の見出し・データのセルは 1 つも変わらない（バイト同一）
  for (let i = 0; i < before.length; i += 1) {
    assert.deepEqual(after[i].slice(0, before[i].length), before[i]);
  }
  // 知らせにも足した見出しが出る
  assert.ok(run.trace.alerts[0].includes("・「期限」シートの見出しに足しました: 状態"), run.trace.alerts[0]);
});

test("編集権限が無いときは、敬体の 1 文で知らせる", () => {
  const run = runBundle({}, { denyWrite: true });
  run.entry.initializeSheets();
  assert.equal(
    run.trace.alerts[0],
    "うまくいきませんでした。次の内容をご確認ください。\n\nシートの作成で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください",
  );
});

test("保護されたレンジで止まったときも、権限の 1 文に言い換える", () => {
  const run = runBundle({}, { denyWrite: "protected" });
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), run.trace.alerts[0]);
});

test("初期化の途中(見出しの追記)で失敗しても、そこまでにできたことを知らせる", () => {
  const seed = {
    設定: sample("settings-sample.csv")
      .map((row) => (row[0] === "Webhook URL" ? [row[0], REAL_URL] : row))
      .filter((row) => row[0] !== "しきい値"),
    期限: [["件名", "期限", "担当"]],
  };
  const run = runBundle(seed, { denyHeaderWrite: true });
  run.entry.initializeSheets();
  const text = run.trace.alerts[0];
  assert.ok(text.includes("「設定」に 1 行を足しました"), text);
  assert.ok(text.includes("そのあと 見出しの追記で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), text);
});

test("onOpen: 1 番目が初期化、2 番目が設定を確かめる", () => {
  const run = runBundle({});
  run.entry.onOpen();
  assert.deepEqual(run.trace.menu, [
    "初期化（足りないシート・見出し・設定を足す。データは消しません） → initializeSheets",
    "設定を確かめる → checkSettings",
    "──",
    "テスト送信 → sendTestNotification",
    "今すぐ通知を送る → runDeadlineAlert",
    "毎朝 8 時に動かす → createDailyTrigger",
  ]);
});

test("設定シートが無いまま毎朝の実行が動くと、初期化を案内する", () => {
  const run = runBundle({});
  assert.throws(() => run.entry.runDeadlineAlert(), /メニュー「期限アラート」→「初期化」を実行してください。/);
});
