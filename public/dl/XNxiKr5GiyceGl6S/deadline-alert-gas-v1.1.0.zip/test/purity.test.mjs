import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const PURE = ["dates.js", "config.js", "items.js", "buckets.js", "message.js", "dedupe.js", "setup.js", "check.js"];
const GLUE = ["gas_store.js", "gas_sheets.js", "gas_notify.js", "gas_main.js"];
const GAS_GLOBALS = ["SpreadsheetApp", "UrlFetchApp", "PropertiesService", "ScriptApp", "Logger", "Utilities", "Session"];

test("純粋な処理は GAS のグローバルに触らない", () => {
  for (const name of PURE) {
    const source = readFileSync(join(root, "src", name), "utf8");
    for (const global of GAS_GLOBALS) {
      assert.equal(source.includes(global), false, name + " が " + global + " に触っている");
    }
  }
});

test("純粋な処理は GAS 側のファイルを読み込まない", () => {
  for (const name of PURE) {
    const source = readFileSync(join(root, "src", name), "utf8");
    assert.equal(/from\s+["']\.\/gas_/.test(source), false, name + " が gas_ を読み込んでいる");
  }
});

test("src にあるのは純粋な処理と GAS 側の 2 種類だけ", () => {
  const files = readdirSync(join(root, "src")).filter((name) => name.endsWith(".js")).sort();
  assert.deepEqual(files, PURE.concat(GLUE).sort());
});

test("入口の 4 つが gas_main.js にある", () => {
  const source = readFileSync(join(root, "src", "gas_main.js"), "utf8");
  for (const name of ["runDeadlineAlert", "sendTestNotification", "createDailyTrigger", "onOpen"]) {
    assert.ok(source.includes("export function " + name + "("), name + " が無い");
  }
});

test("初期化と設定を確かめるの入口が gas_main.js の runDeadlineAlert より後ろにある", () => {
  const source = readFileSync(join(root, "src", "gas_main.js"), "utf8");
  const first = source.indexOf("export function runDeadlineAlert(");
  for (const name of ["initializeSheets", "checkSettings"]) {
    const at = source.indexOf("export function " + name + "(");
    assert.ok(at > first && first >= 0, name + " が runDeadlineAlert より後ろに無い");
  }
});
