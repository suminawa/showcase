import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CONFIG_KEYS, DEFAULT_ROWS, configKeyOf } from "../src/config.js";
import { SETTINGS_TAB, checkNotes, collectConfigProblems, findProblems, planInit, sheetNamesFor, summaryLines } from "../src/check.js";
import { initReport } from "../src/setup.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const REAL_URL = "https://hooks.slack.com/services/T000/B000/xxxx";
const SAMPLE_TODAY = "2026-09-13";

/** 見本 CSV を行と列に割る（"..." の中のカンマは区切りにしない）。docs.test.mjs と同じ */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function sample(name) {
  return rowsOf(readFileSync(join(root, "samples", name), "utf8"));
}

/** 1.0 の見本 2 枚を読み込んだブック。withRealUrl なら Webhook URL を見本の URL から差し替える */
function sampleBook(withRealUrl) {
  const settings = sample("settings-sample.csv").map((row) => (withRealUrl && row[0] === "Webhook URL" ? [row[0], REAL_URL] : row));
  return { timeZone: "Asia/Tokyo", today: SAMPLE_TODAY, hasTrigger: true, sheets: { 設定: settings, 期限: sample("deadlines-sample.csv") } };
}

function book(sheets, extra) {
  return Object.assign({ timeZone: "Asia/Tokyo", today: SAMPLE_TODAY, hasTrigger: true, sheets: sheets }, extra || {});
}

/** plan を 2 次元配列に当てる（足すだけ）。GAS 側の applyInit_ と同じ置き方: 設定の行は最終行の下、見出しはいまの右端の右 */
function applyPlan(snapshot, plan) {
  const sheets = {};
  for (const name of Object.keys(snapshot.sheets)) sheets[name] = snapshot.sheets[name].map((row) => row.slice());
  if (plan.appendSettings.rows.length > 0) {
    sheets[plan.appendSettings.sheet] = sheets[plan.appendSettings.sheet].concat(plan.appendSettings.rows.map((row) => row.slice()));
  }
  for (const made of plan.createSheets) sheets[made.name] = made.rows.map((row) => row.slice());
  for (const entry of plan.appendHeaders) {
    const rows = sheets[entry.sheet];
    const width = Math.max(...rows.map((row) => row.length));
    rows[0] = rows[0].concat(new Array(width - rows[0].length).fill("")).concat(entry.names);
  }
  return Object.assign({}, snapshot, { sheets: sheets });
}

function isEmptyPlan(plan) {
  return plan.createSheets.length === 0 && plan.appendHeaders.length === 0 && plan.appendSettings.rows.length === 0;
}

test("DEFAULT_ROWS は CONFIG_KEYS の順に 11 行で、Webhook URL だけが空", () => {
  assert.deepEqual(DEFAULT_ROWS.map((row) => row[0]), CONFIG_KEYS);
  assert.deepEqual(DEFAULT_ROWS.filter((row) => row[1] === "").map((row) => row[0]), ["Webhook URL"]);
  assert.equal(configKeyOf("列名 (件名)"), configKeyOf("列名（件名）"));
  assert.equal(configKeyOf("webhook url"), configKeyOf("Webhook URL"));
});

test("planInit: 空のブック → 設定と期限を作り、2 回目は足すものが無い", () => {
  const empty = book({});
  const plan = planInit(empty);
  assert.deepEqual(plan.createSheets.map((sheet) => sheet.name), ["設定", "期限"]);
  assert.deepEqual(plan.createSheets[0].rows, [["項目", "値"]].concat(DEFAULT_ROWS));
  assert.deepEqual(plan.createSheets[1].rows, [["件名", "期限", "担当", "状態"]]);
  assert.equal(plan.createSheets.every((sheet) => sheet.freeze === true && sheet.exists === false), true);
  assert.deepEqual(plan.appendSettings.rows, []);
  assert.equal(plan.nextStep, "次は「設定」シートの「Webhook URL」に、README の手順 2 で作る URL を貼り、「設定を確かめる」を実行してください。");
  assert.equal(
    initReport(plan, plan.nextStep),
    "初期化しました。足したものは次のとおりです（すでにあったデータは変えていません）。\n\n・シートを作りました: 設定、期限\n\n次は「設定」シートの「Webhook URL」に、README の手順 2 で作る URL を貼り、「設定を確かめる」を実行してください。",
  );

  const again = planInit(applyPlan(empty, plan));
  assert.equal(isEmptyPlan(again), true);
  assert.ok(initReport(again, again.nextStep).startsWith("変更はありません。"));
});

test("planInit: 1.0 の見本のブック → 足すものが無い", () => {
  const plan = planInit(sampleBook(false));
  assert.equal(isEmptyPlan(plan), true);
  assert.deepEqual(plan.notes, []);
  assert.equal(plan.nextStep, "次は「設定を確かめる」を実行してください。");
});

test("planInit: 設定の行を 3 つと見出しを 1 つ消したブック → その 4 つだけを足し、2 回目は空", () => {
  const removed = ["しきい値", "文面テンプレ", "完了とみなす状態の値"];
  const base = sampleBook(true);
  base.sheets.設定 = base.sheets.設定.filter((row) => removed.indexOf(row[0]) < 0);
  base.sheets.期限 = base.sheets.期限.map((row) => [row[0], row[1], row[3]]);
  const plan = planInit(base);
  assert.deepEqual(plan.createSheets, []);
  assert.deepEqual(plan.appendSettings.rows, [["しきい値", "3,0"], ["文面テンプレ", "・{件名}（{期限}・{担当}）"], ["完了とみなす状態の値", "完了"]]);
  assert.equal(plan.appendSettings.blank, false);
  assert.deepEqual(plan.appendHeaders, [{ sheet: "期限", names: ["担当"] }]);
  const applied = applyPlan(base, plan);
  assert.deepEqual(applied.sheets.期限[0], ["件名", "期限", "状態", "担当"], "見出しは右端に足し、並びは変えない");
  assert.deepEqual(applied.sheets.期限.slice(1), base.sheets.期限.slice(1), "データの行は変えない");
  assert.equal(isEmptyPlan(planInit(applied)), true);
});

test("planInit: 項目名の書き方の揺れ（空白・大文字小文字・半角括弧）は同じ行とみなして足さない", () => {
  const base = sampleBook(true);
  base.sheets.設定 = base.sheets.設定.map((row) => {
    if (row[0] === "Webhook URL") return ["webhookurl", row[1]];
    if (row[0] === "列名（件名）") return ["列名 (件名)", row[1]];
    if (row[0] === "しきい値") return [" しきい値 ", row[1]];
    return row;
  });
  assert.deepEqual(planInit(base).appendSettings.rows, []);
});

test("planInit: 予定の入ったシートに「件名」「期限」が無ければ足さずに案内し、担当・状態は足す", () => {
  const base = book({
    設定: [["項目", "値"]].concat(DEFAULT_ROWS),
    期限: [["タスク", "締切"], ["請求書", "2026-09-30"]],
  });
  const plan = planInit(base);
  assert.deepEqual(plan.appendHeaders, [{ sheet: "期限", names: ["担当", "状態"] }]);
  assert.deepEqual(plan.notes, [
    "「期限」シートの 1 行目に「件名」の列がありません。いまの予定が別の見出しの列に入っているなら、設定「列名（件名）」にその見出しを書いてください。新しく使うなら、1 行目の空いているところに「件名」と書いてください。",
    "「期限」シートの 1 行目に「期限」の列がありません。いまの予定が別の見出しの列に入っているなら、設定「列名（期限）」にその見出しを書いてください。新しく使うなら、1 行目の空いているところに「期限」と書いてください。",
  ]);
  // データの行が無ければ 4 つとも足す
  const blank = planInit(book({ 設定: [["項目", "値"]].concat(DEFAULT_ROWS), 期限: [["メモ"], ["", ""]] }));
  assert.deepEqual(blank.appendHeaders, [{ sheet: "期限", names: ["件名", "期限", "担当", "状態"] }]);
});

test("planInit: 空のシートには中身を書く・対象シート名と列名は設定から読む・タイムゾーンは変えずに案内", () => {
  const plan = planInit(
    book(
      {
        設定: [["項目", "値"], ["対象シート名", "支払い"], ["列名（件名）", "内容"], ["列名（期限）", "支払日"]],
        支払い: [],
      },
      { timeZone: "America/New_York" },
    ),
  );
  assert.deepEqual(plan.createSheets, [{ name: "支払い", rows: [["内容", "支払日", "担当", "状態"]], freeze: true, exists: true }]);
  assert.equal(plan.appendSettings.rows.length, 8);
  assert.deepEqual(plan.notes, ["スプレッドシートのタイムゾーンが America/New_York です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。"]);
  assert.deepEqual(sheetNamesFor(undefined), ["期限"]);
  assert.deepEqual(sheetNamesFor([["対象シート名", "支払い"]]), ["支払い"]);
});

test("findProblems: 対象シートがあっても空なら、見出しの並べ替えではなく初期化を勧める", () => {
  const empty = sampleBook(true);
  empty.sheets.期限 = [];
  assert.deepEqual(findProblems(empty), ["「期限」シートに見出しがありません。初期化を実行すると見出しを書きます。"]);
});

test("findProblems: 見本（URL をご自身のものに差し替えたもの）→ 0 件。見本の URL のままなら 1 件", () => {
  assert.deepEqual(findProblems(sampleBook(true)), []);
  assert.deepEqual(findProblems(sampleBook(false)), ["「設定」シートの「Webhook URL」が見本の URL のままです。README の手順 2 で作ったご自身の URL に貼り替えてください。"]);
});

/** 見本のブックの設定を 1 行だけ書き換えた snapshot */
function withSetting(key, value) {
  const base = sampleBook(true);
  base.sheets.設定 = base.sheets.設定.map((row) => (row[0] === key ? [key, value] : row));
  return base;
}

test("findProblems: 表の各行について、その文が 1 回だけ出る", () => {
  const cases = [
    [book({}, { timeZone: "America/New_York" }), "スプレッドシートのタイムゾーンが America/New_York です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。"],
    [book({}), "「設定」シートがありません。メニュー「期限アラート」→「初期化」を実行してください。"],
    [withSetting("通知先", "line"), "「設定」シートの「通知先」は slack か discord にしてください（いまは「line」）。"],
    [withSetting("Webhook URL", ""), "「設定」シートの「Webhook URL」が空です。README の手順 2 で作った URL を貼ってください。"],
    [withSetting("Webhook URL", " http://hooks.slack.com/x"), "「設定」シートの「Webhook URL」は https:// で始まる URL です。前後に余分な字が入っていないかも確かめてください。"],
    [withSetting("Webhook URL", "https://discord.com/api/webhooks/1/abc"), "「通知先」が slack ですが、「Webhook URL」は Discord の URL です。「通知先」を discord にしてください。"],
    [withSetting("しきい値", "3日,0"), "「設定」シートの「しきい値」は、0 以上の整数をカンマで区切って書いてください（いまは「3日,0」）。例: 3,0"],
    [withSetting("超過も通知する", "はい、する"), "「設定」シートの「超過も通知する」は TRUE か FALSE にしてください（いまは「はい、する」）。"],
    [withSetting("文面テンプレ", "・{件名}（{期日}）"), "「文面テンプレ」の {期日} は置き換わりません。使えるのは {件名} {期限} {担当} {残日数} です。"],
    [withSetting("対象シート名", "タスク"), "設定「対象シート名」の「タスク」シートがありません。シートの名前を「タスク」にするか、設定「対象シート名」をいまのシートの名前にしてください。"],
    [withSetting("列名（件名）", "タスク名"), "「期限」シートの 1 行目に「タスク名」の列がありません。見出しを「タスク名」にするか、設定「列名（件名）」にいまの見出しの名前を書いてください。"],
  ];
  for (const [snapshot, message] of cases) {
    const found = findProblems(snapshot);
    assert.equal(found.filter((line) => line === message).length, 1, message + "\n" + found.join("\n"));
  }
  // Discord を選んで Slack の URL を貼ったとき
  const discord = withSetting("通知先", "discord");
  assert.deepEqual(findProblems(discord), ["「通知先」が discord ですが、「Webhook URL」は Slack の URL です。「通知先」を slack にしてください。"]);
});

test("findProblems: 期限を読めない行と件名の空の行を、行の番号つきで全部並べる", () => {
  const base = sampleBook(true);
  base.sheets.期限 = [["件名", "期限", "担当", "状態"], ["家賃", "2026-09-30", "", ""], ["保険", "来週", "", ""], ["", "", "", ""], ["", "2026-10-01", "", ""]];
  assert.deepEqual(findProblems(base), [
    "「期限」シートの 3 行目の期限を日付として読めません。2026-09-30 の形で入れ直してください。",
    "「期限」シートの 5 行目は期限がありますが、件名が空です。件名を書いてください。",
  ]);
});

test("findProblems: 最初の 1 つで止めずに集め、URL の値は文に出さない", () => {
  const base = withSetting("通知先", "line");
  base.sheets.設定 = base.sheets.設定.map((row) => (row[0] === "しきい値" ? ["しきい値", "三日"] : row));
  base.sheets.設定.push(["Webhook URL", "http://secret.example/abc"]);
  const found = findProblems(base);
  assert.equal(found.length, 3);
  assert.equal(found.join("\n").includes("secret.example"), false);
  assert.deepEqual(collectConfigProblems([["項目", "値"], ["Webhook URL", REAL_URL]]), []);
});

test("checkNotes: 設定の行が無い項目・状態の列が無い・トリガーが無い", () => {
  const base = sampleBook(true);
  base.sheets.設定 = base.sheets.設定.filter((row) => row[0] !== "しきい値" && row[0] !== "文面テンプレ");
  base.sheets.期限 = base.sheets.期限.map((row) => row.slice(0, 3));
  base.hasTrigger = false;
  assert.deepEqual(checkNotes(base), [
    "「設定」シートに「しきい値」「文面テンプレ」の行がありません。既定値（3,0 と ・{件名}（{期限}・{担当}））で動きます。「初期化」を実行すると、既定値の行を足します。",
    "「期限」シートに「状態」の列がないため、完了した予定も知らせます。",
    "毎朝 8 時の実行はまだ作っていません。メニュー「毎朝 8 時に動かす」を押してください。",
  ]);
  assert.deepEqual(checkNotes(sampleBook(true)), []);
});

test("summaryLines: 見本の 2 枚を 2026-09-13 に確かめたときの 5 行", () => {
  assert.deepEqual(summaryLines(sampleBook(true)), [
    "通知: slack に、毎朝 8 時ごろ 1 通送ります（毎朝の実行: 作ってあります）",
    "知らせる日: 期限を過ぎたもの・当日・3 日前",
    "読むシート: 「期限」の 件名・期限・担当・状態。完了とみなす値: 完了",
    "いま知らせる対象の予定: 5 件（完了の 1 件は除きます）",
    "今日の分: 期限切れ 1 件・今日 1 件・3 日後 1 件（今日すでに送った分も数えています）",
  ]);
  const quiet = sampleBook(true);
  quiet.today = "2026-12-01";
  quiet.hasTrigger = false;
  const lines = summaryLines(quiet);
  assert.equal(lines[0], "通知: slack に、毎朝 8 時ごろ 1 通送ります（毎朝の実行: まだ作っていません）");
  assert.equal(lines[4], "今日の分: 期限切れ 5 件（今日すでに送った分も数えています）");
  assert.equal(SETTINGS_TAB, "設定");
});
