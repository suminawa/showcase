/** Slack / Discord / Google Chat の Webhook と、メール（gmail）に 1 通送る。 */
import { buildPayload } from "./message.js";

/** メールの差出人名（アドレスはスクリプトを動かす人の Gmail） */
const MAIL_SENDER_NAME = "期限アラート";

export function postWebhook_(url, text, target) {
  const response = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(buildPayload(text, target)),
    muteHttpExceptions: true,
  });
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error("Webhook が " + status + " を返しました: " + String(response.getContentText()).slice(0, 200));
  }
}

/** 宛先（複数可）へ 1 通。本文は Slack と同じ字のまま（メールでは & < > を文字参照にしない） */
export function sendMail_(addresses, subject, body) {
  if (MailApp.getRemainingDailyQuota() <= 0) throw new Error("今日送れるメールの数の上限に達しました");
  MailApp.sendEmail({ to: addresses.join(","), subject: subject, body: body, name: MAIL_SENDER_NAME });
}

/**
 * 通知先すべてに送る。1 か所が失敗しても残りには送り、失敗は実行ログに残す。
 * destination は parseConfig か rawTargetsOf の返り値（targets・webhookUrl・mailTo・chatWebhookUrl）。
 * 返り値: { sent: 送れた数, failures: [{ target, message }] }
 */
export function notifyAll_(destination, text, subject) {
  const failures = [];
  let sent = 0;
  for (let i = 0; i < destination.targets.length; i += 1) {
    const target = destination.targets[i];
    try {
      if (target === "gmail") sendMail_(destination.mailTo, subject, text);
      else if (target === "googlechat") postWebhook_(destination.chatWebhookUrl, text, target);
      else postWebhook_(destination.webhookUrl, text, target);
      sent += 1;
    } catch (error) {
      Logger.log("期限アラート: " + target + " に送れませんでした: " + error);
      failures.push({ target: target, message: String(error && error.message ? error.message : error) });
    }
  }
  return { sent: sent, failures: failures };
}
