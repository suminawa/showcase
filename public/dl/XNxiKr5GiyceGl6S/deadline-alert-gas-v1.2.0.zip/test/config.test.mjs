import { test } from "node:test";
import assert from "node:assert/strict";
import { CONFIG_KEYS, ConfigError, DEFAULT_CONFIG, mailListOf, parseConfig, rawTargetsOf, targetNamesOf } from "../src/config.js";

const WEBHOOK = "https://hooks.slack.com/services/T000/B000/xxxx";

function rows(extra) {
  const base = [
    ["項目", "値"],
    ["通知先", "slack"],
    ["Webhook URL", WEBHOOK],
  ];
  return extra ? base.concat(extra) : base;
}

test("Webhook URL だけあれば残りは既定値", () => {
  const config = parseConfig(rows());
  assert.deepEqual(config.targets, ["slack"]);
  assert.equal(config.webhookUrl, WEBHOOK);
  assert.deepEqual(config.mailTo, []);
  assert.deepEqual(config.thresholds, [0, 3]);
  assert.equal(config.notifyOverdue, true);
  assert.equal(config.itemTemplate, DEFAULT_CONFIG.itemTemplate);
  assert.equal(config.sheetName, "期限");
  assert.deepEqual(config.columns, { subject: "件名", due: "期限", assignee: "担当", status: "状態" });
  assert.deepEqual(config.doneValues, ["完了"]);
});

test("しきい値は重複を落として昇順に並べる", () => {
  assert.deepEqual(parseConfig(rows([["しきい値", "7,3,0,3"]])).thresholds, [0, 3, 7]);
});

test("しきい値は全角読点でも区切れる", () => {
  assert.deepEqual(parseConfig(rows([["しきい値", "5、1、0"]])).thresholds, [0, 1, 5]);
});

test("しきい値: 全角の数字と読点でも読める", () => {
  const config = parseConfig(rows([["しきい値", "３、０"]]));
  assert.deepEqual(config.thresholds, [0, 3]);
});

test("空欄は既定値に戻る", () => {
  const config = parseConfig(rows([["しきい値", ""], ["対象シート名", "   "], ["文面テンプレ", ""]]));
  assert.deepEqual(config.thresholds, [0, 3]);
  assert.equal(config.sheetName, "期限");
  assert.equal(config.itemTemplate, DEFAULT_CONFIG.itemTemplate);
});

test("チェックボックス（真偽値）でも TRUE / FALSE の文字でも読める", () => {
  assert.equal(parseConfig(rows([["超過も通知する", false]])).notifyOverdue, false);
  assert.equal(parseConfig(rows([["超過も通知する", "FALSE"]])).notifyOverdue, false);
  assert.equal(parseConfig(rows([["超過も通知する", "いいえ"]])).notifyOverdue, false);
  assert.equal(parseConfig(rows([["超過も通知する", true]])).notifyOverdue, true);
});

test("列名と完了の値を変えられる", () => {
  const config = parseConfig(
    rows([
      ["対象シート名", "支払い"],
      ["列名（件名）", "内容"],
      ["列名（期限）", "支払日"],
      ["列名（担当）", "担当者"],
      ["列名（状態）", "ステータス"],
      ["完了とみなす状態の値", "完了,支払済,不要"],
    ]),
  );
  assert.equal(config.sheetName, "支払い");
  assert.deepEqual(config.columns, { subject: "内容", due: "支払日", assignee: "担当者", status: "ステータス" });
  assert.deepEqual(config.doneValues, ["完了", "支払済", "不要"]);
});

test("キーの半角括弧・余分な空白・大文字小文字は吸収する", () => {
  const config = parseConfig([
    ["通知先", "Discord"],
    ["webhook url", WEBHOOK],
    ["列名 (件名)", "内容"],
  ]);
  assert.deepEqual(config.targets, ["discord"]);
  assert.equal(config.columns.subject, "内容");
});

test("知らないキーは無視する", () => {
  const config = parseConfig(rows([["メモ", "ここは自由に書いてよい"], [], [""]]));
  assert.equal(config.webhookUrl, WEBHOOK);
});

test("間違いは ConfigError で、どこが悪いか日本語で言う", () => {
  assert.throws(() => parseConfig([["通知先", "slack"]]), ConfigError);
  assert.throws(() => parseConfig(rows([["通知先", "line"]])), /通知先/);
  assert.throws(() => parseConfig([["通知先", "slack"], ["Webhook URL", "http://example.com"]]), /https/);
  assert.throws(() => parseConfig(rows([["しきい値", "三日前"]])), /しきい値/);
  assert.throws(() => parseConfig(rows([["しきい値", "-1"]])), /しきい値/);
  assert.throws(() => parseConfig(rows([["超過も通知する", "たぶん"]])), /超過も通知する/);
});

test("CONFIG_KEYS は設定シートに並べる 13 個", () => {
  assert.deepEqual(CONFIG_KEYS, [
    "通知先",
    "Webhook URL",
    "メールの宛先",
    "Google Chat の Webhook URL",
    "しきい値",
    "超過も通知する",
    "文面テンプレ",
    "対象シート名",
    "列名（件名）",
    "列名（期限）",
    "列名（担当）",
    "列名（状態）",
    "完了とみなす状態の値",
  ]);
});

test("通知先: カンマで並べられ、空白・大文字小文字・全角のカンマを吸収する。空なら slack", () => {
  assert.deepEqual(targetNamesOf(" Slack ，Gmail、gmail "), ["slack", "gmail"]);
  assert.deepEqual(targetNamesOf(""), []);
  assert.deepEqual(parseConfig(rows([["通知先", ""]])).targets, ["slack"]);
  const both = parseConfig(rows([["通知先", "slack, gmail"], ["メールの宛先", "keiri@example.co.jp"]]));
  assert.deepEqual(both.targets, ["slack", "gmail"]);
  assert.deepEqual(both.mailTo, ["keiri@example.co.jp"]);
});

test("通知先: gmail だけなら Webhook URL は要らない。宛先は複数・全角でも読める", () => {
  const config = parseConfig([
    ["通知先", "gmail"],
    ["メールの宛先", "ｋｅｉｒｉ＠ｅｘａｍｐｌｅ．ｃｏ．ｊｐ、tanaka@example.co.jp; keiri@example.co.jp"],
  ]);
  assert.deepEqual(config.targets, ["gmail"]);
  assert.equal(config.webhookUrl, "");
  assert.deepEqual(config.mailTo, ["keiri@example.co.jp", "tanaka@example.co.jp"]);
});

test("通知先: gmail の宛先が空・形が崩れている、slack と discord の同時指定は ConfigError", () => {
  assert.throws(() => parseConfig([["通知先", "gmail"]]), /「メールの宛先」が空です/);
  assert.throws(() => parseConfig([["通知先", "gmail"], ["メールの宛先", "keiri@example"]]), /「メールの宛先」の「keiri@example」はメールアドレスの形ではありません/);
  assert.throws(() => parseConfig(rows([["通知先", "slack,discord"]])), /slack と discord は同時に書けません/);
  assert.throws(() => parseConfig([["通知先", "gmail,slack"], ["メールの宛先", "a@example.jp"]]), /「Webhook URL」が空です/);
});

test("mailListOf: 区切りはカンマ・読点・セミコロン・空白。重なりは落とす", () => {
  assert.deepEqual(mailListOf("a@example.jp b@example.jp,a@example.jp；c@example.jp"), {
    addresses: ["a@example.jp", "b@example.jp", "c@example.jp"],
    invalid: [],
  });
  assert.deepEqual(mailListOf(undefined), { addresses: [], invalid: [] });
  assert.deepEqual(mailListOf("田中 a@example.jp").invalid, ["田中"]);
});

test("rawTargetsOf: 設定が壊れていても、送り先がそろった通知先だけでエラーを届ける", () => {
  // しきい値が壊れていても、gmail の宛先が読めればメールで届ける
  assert.deepEqual(rawTargetsOf([["通知先", "gmail"], ["メールの宛先", "a@example.jp"], ["しきい値", "三日"]]), {
    targets: ["gmail"],
    webhookUrl: "",
    mailTo: ["a@example.jp"],
    chatWebhookUrl: "",
  });
  // 通知先が読めなければ、これまでどおり slack とみなす。URL が https で無ければ送らない
  assert.deepEqual(rawTargetsOf([["通知先", "line"], ["Webhook URL", WEBHOOK]]).targets, ["slack"]);
  assert.equal(rawTargetsOf([["通知先", "slack"], ["Webhook URL", "http://example.com"]]), null);
  // 宛先の無い gmail は外し、slack と discord が両方あれば先の 1 つだけ
  assert.deepEqual(rawTargetsOf([["通知先", "discord,slack,gmail"], ["Webhook URL", WEBHOOK]]).targets, ["discord"]);
  assert.equal(rawTargetsOf([]), null, "空の設定では送り先が無い");
});

const CHAT_URL = "https://chat.googleapis.com/v1/spaces/AAAA/messages?key=k&token=t";

test("通知先 googlechat: 「Google Chat の Webhook URL」が要り、chat.googleapis.com の URL だけを受ける", () => {
  const config = parseConfig([["通知先", "Google Chat, gmail"], ["Google Chat の Webhook URL", CHAT_URL], ["メールの宛先", "a@example.jp"]]);
  assert.deepEqual(config.targets, ["googlechat", "gmail"]);
  assert.equal(config.chatWebhookUrl, CHAT_URL);
  assert.equal(config.webhookUrl, "");
  assert.throws(() => parseConfig([["通知先", "googlechat"]]), /「Google Chat の Webhook URL」が空です/);
  assert.throws(() => parseConfig([["通知先", "googlechat"], ["Google Chat の Webhook URL", WEBHOOK]]), (error) => {
    assert.ok(error instanceof ConfigError);
    assert.equal(error.message, "「Google Chat の Webhook URL」は https://chat.googleapis.com/ で始まる URL です。");
    return true;
  });
  // 使わない行は確かめない
  assert.equal(parseConfig(rows([["Google Chat の Webhook URL", "まだ"]])).chatWebhookUrl, "まだ");
});

test("rawTargetsOf: googlechat は chat.googleapis.com の URL があるときだけ残す", () => {
  assert.deepEqual(rawTargetsOf([["通知先", "googlechat,slack"], ["Google Chat の Webhook URL", CHAT_URL]]).targets, ["googlechat"]);
  assert.equal(rawTargetsOf([["通知先", "googlechat"], ["Google Chat の Webhook URL", WEBHOOK]]), null);
});
