/** Slack / Discord の Webhook に 1 通送る。 */
import { buildPayload } from "./message.js";

export function postWebhook_(url, text, target) {
  const response = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(buildPayload(text, target)),
    muteHttpExceptions: true,
  });
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error("Webhook が " + status + " を返しました: " + String(response.getContentText()).slice(0, 200));
  }
}
