/** スプレッドシートから設定と期限の行を読む。 */
import { ConfigError, parseConfig } from "./config.js";

export function readConfig_() {
  const book = SpreadsheetApp.getActiveSpreadsheet();
  const timeZone = book.getSpreadsheetTimeZone();
  if (timeZone !== "Asia/Tokyo") {
    throw new ConfigError(
      "スプレッドシートのタイムゾーンが " +
        timeZone +
        " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。",
    );
  }
  const sheet = book.getSheetByName("設定");
  if (!sheet) throw new ConfigError("「設定」シートがありません。README.ja.md の手順 1 を見てください。");
  return parseConfig(sheet.getDataRange().getValues());
}

export function readItemValues_(sheetName) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) {
    throw new Error("「" + sheetName + "」シートがありません。設定シートの「対象シート名」と揃えてください。");
  }
  return sheet.getDataRange().getValues();
}

/**
 * 設定が壊れていてもエラーだけは届くように、通知先と Webhook URL だけを検証せずに読む。
 * 読めなければ null（そのときは実行ログだけが頼りになる）。
 */
export function readRawTarget_() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("設定");
    if (!sheet) return null;
    const rows = sheet.getDataRange().getValues();
    let webhookUrl = "";
    let target = "slack";
    for (let i = 0; i < rows.length; i += 1) {
      const key = String(rows[i][0]).replace(/\s+/g, "").toLowerCase();
      const value = String(rows[i][1]).trim();
      if (key === "webhookurl") webhookUrl = value;
      if (key === "通知先") target = value.toLowerCase() === "discord" ? "discord" : "slack";
    }
    if (webhookUrl.indexOf("https://") !== 0) return null;
    return { webhookUrl: webhookUrl, target: target };
  } catch (error) {
    return null;
  }
}
