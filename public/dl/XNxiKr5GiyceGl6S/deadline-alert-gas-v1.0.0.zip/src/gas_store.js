/**
 * 送信済みの鍵を、スクリプトのプロパティに日付ごとに貯める。
 * 1 日分だけ持ち、前日までのぶんは消す（プロパティの上限に当たらないように）。
 */
import { staleStoreNames, storeNameOf } from "./dedupe.js";

/** PropertiesService の単一プロパティは約 9 KB まで。余裕を見てこのバイト数で頭打ちにする */
const STORE_LIMIT_BYTES = 8000;

function scriptProperties_() {
  return PropertiesService.getScriptProperties();
}

export function readSentKeys_(runDate) {
  const raw = scriptProperties_().getProperty(storeNameOf(runDate));
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    // 壊れていたら「まだ何も送っていない」とみなす。送りすぎる方が、黙って止まるよりましだから
    return [];
  }
}

export function saveSentKeys_(runDate, keys) {
  // 上限はバイト数で測る（日本語は UTF-8 で 1 字 3 バイト）。あふれたら古いものから捨てる
  // 通知を送りすぎる方が、黙って止まるよりましだから
  let keysToSave = keys;
  let json = JSON.stringify(keysToSave);
  let dropped = 0;
  while (Utilities.newBlob(json).getBytes().length > STORE_LIMIT_BYTES && keysToSave.length > 0) {
    keysToSave = keysToSave.slice(1);
    json = JSON.stringify(keysToSave);
    dropped += 1;
  }
  if (dropped > 0) {
    Logger.log("期限アラート: 送信済みの鍵が多いため古い " + dropped + " 件を保存しませんでした（再通知の可能性があります）");
  }
  scriptProperties_().setProperty(storeNameOf(runDate), json);
}

export function pruneSentStore_(runDate) {
  const store = scriptProperties_();
  const stale = staleStoreNames(store.getKeys(), runDate);
  for (let i = 0; i < stale.length; i += 1) store.deleteProperty(stale[i]);
}
