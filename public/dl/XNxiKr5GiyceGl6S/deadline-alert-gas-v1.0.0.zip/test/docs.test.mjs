import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { collectSections } from "../src/buckets.js";
import { CONFIG_KEYS, parseConfig } from "../src/config.js";
import { parseItems } from "../src/items.js";
import { buildMessage } from "../src/message.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 見本 CSV を行と列に割る。"..." の中のカンマは区切りにしない */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += ch;
    }
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function read(name) {
  return readFileSync(join(root, name), "utf8");
}

test("README と見本 CSV は設定の項目を全部載せている", () => {
  const readme = read("README.ja.md");
  const csv = read("samples/settings-sample.csv");
  for (const key of CONFIG_KEYS) {
    assert.ok(readme.includes(key), "README に「" + key + "」が無い");
    assert.ok(csv.includes(key), "見本の設定シートに「" + key + "」が無い");
  }
});

test("見本の期限シートの見出しは既定の列名", () => {
  assert.deepEqual(rowsOf(read("samples/deadlines-sample.csv"))[0], ["件名", "期限", "担当", "状態"]);
});

/** 見本の期限はこの日を「今日」として引いてある（README の「届く文面」もこの日のもの） */
const SAMPLE_TODAY = "2026-09-13";

test("見本 2 枚をそのまま読むと、3 つの節が揃った 1 通ができる", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const parsed = parseItems(rowsOf(read("samples/deadlines-sample.csv")), config);
  const sections = collectSections(parsed.items, config, SAMPLE_TODAY);
  const text = buildMessage(sections, {
    todayKey: SAMPLE_TODAY,
    itemTemplate: config.itemTemplate,
    skipped: parsed.skipped,
  });
  assert.equal(
    text,
    [
      "【期限アラート】9/13（日）",
      "",
      "■ 期限を過ぎています",
      "・事務所家賃の振込（9/11（金）・自分）",
      "",
      "■ 今日が期限",
      "・A 社への請求書送付（9/13（日）・自分）",
      "",
      "■ 3 日後が期限",
      "・源泉所得税の納付（9/16（水）・自分）",
    ].join("\n"),
  );
});

test("見本には完了の行が 1 つあり、その行は知らせない", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const parsed = parseItems(rowsOf(read("samples/deadlines-sample.csv")), config);
  assert.deepEqual(parsed.skipped, []);
  assert.equal(
    parsed.items.filter(function (item) {
      return item.dueKey === SAMPLE_TODAY;
    }).length,
    1,
    "見本の当日の行は、完了の 1 行を除いた 1 件のはず",
  );
});

test("README に載せている文面の例は、実際に出るものと同じ", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const parsed = parseItems(rowsOf(read("samples/deadlines-sample.csv")), config);
  const text = buildMessage(collectSections(parsed.items, config, SAMPLE_TODAY), {
    todayKey: SAMPLE_TODAY,
    itemTemplate: config.itemTemplate,
  });
  assert.ok(read("README.ja.md").includes(text), "README の例が実際の出力と食い違っている");
});
