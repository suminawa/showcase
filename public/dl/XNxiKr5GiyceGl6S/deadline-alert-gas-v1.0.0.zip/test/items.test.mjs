import { test } from "node:test";
import assert from "node:assert/strict";
import { parseConfig } from "../src/config.js";
import { parseItems, SheetError } from "../src/items.js";

const config = parseConfig([
  ["通知先", "slack"],
  ["Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
]);

test("ヘッダーの名前で列を見つけ、行番号を覚えている", () => {
  const result = parseItems(
    [
      ["件名", "期限", "担当", "状態"],
      ["家賃の振込", "2026-09-18", "自分", ""],
      ["請求書の送付", new Date("2026-09-19T15:00:00Z"), "自分", "着手"],
    ],
    config,
  );
  assert.deepEqual(result.items, [
    { subject: "家賃の振込", dueKey: "2026-09-18", assignee: "自分", status: "", rowNumber: 2 },
    { subject: "請求書の送付", dueKey: "2026-09-20", assignee: "自分", status: "着手", rowNumber: 3 },
  ]);
  assert.deepEqual(result.skipped, []);
});

test("列の順番が違っても名前で拾う", () => {
  const result = parseItems(
    [
      ["状態", "期限", "件名"],
      ["", "2026-09-18", "家賃の振込"],
    ],
    config,
  );
  assert.equal(result.items[0].subject, "家賃の振込");
  assert.equal(result.items[0].dueKey, "2026-09-18");
  assert.equal(result.items[0].assignee, "");
});

test("完了の行は飛ばす", () => {
  const result = parseItems(
    [
      ["件名", "期限", "担当", "状態"],
      ["終わった仕事", "2026-09-18", "自分", "完了"],
      ["残っている仕事", "2026-09-18", "自分", "着手"],
    ],
    config,
  );
  assert.deepEqual(
    result.items.map(function (item) {
      return item.subject;
    }),
    ["残っている仕事"],
  );
});

test("空の行は数えない", () => {
  const result = parseItems(
    [
      ["件名", "期限", "担当", "状態"],
      ["", "", "", ""],
      [],
      ["家賃の振込", "2026-09-18", "自分", ""],
    ],
    config,
  );
  assert.equal(result.items.length, 1);
  assert.deepEqual(result.skipped, []);
});

test("期限が読めない行は skipped に入れて、行番号を覚える", () => {
  const result = parseItems(
    [
      ["件名", "期限", "担当", "状態"],
      ["来週やる", "来週", "自分", ""],
      ["家賃の振込", "2026-09-18", "自分", ""],
    ],
    config,
  );
  assert.equal(result.items.length, 1);
  assert.deepEqual(result.skipped, [{ rowNumber: 2, reason: "期限が読めません" }]);
});

test("件名が空の行も skipped に入れる", () => {
  const result = parseItems(
    [
      ["件名", "期限", "担当", "状態"],
      ["", "2026-09-18", "自分", ""],
    ],
    config,
  );
  assert.equal(result.items.length, 0);
  assert.deepEqual(result.skipped, [{ rowNumber: 2, reason: "「件名」が空です" }]);
});

test("件名か期限の列が無ければ SheetError", () => {
  assert.throws(function () {
    parseItems([["名前", "期限"], ["a", "2026-09-18"]], config);
  }, SheetError);
  assert.throws(function () {
    parseItems([["件名", "日付"], ["a", "2026-09-18"]], config);
  }, /期限/);
});

test("シートが空なら SheetError", () => {
  assert.throws(function () {
    parseItems([], config);
  }, SheetError);
});
