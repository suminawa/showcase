import { test } from "node:test";
import assert from "node:assert/strict";
import { CONFIG_KEYS, ConfigError, DEFAULT_CONFIG, parseConfig } from "../src/config.js";

const WEBHOOK = "https://hooks.slack.com/services/T000/B000/xxxx";

function rows(extra) {
  const base = [
    ["項目", "値"],
    ["通知先", "slack"],
    ["Webhook URL", WEBHOOK],
  ];
  return extra ? base.concat(extra) : base;
}

test("Webhook URL だけあれば残りは既定値", () => {
  const config = parseConfig(rows());
  assert.equal(config.target, "slack");
  assert.equal(config.webhookUrl, WEBHOOK);
  assert.deepEqual(config.thresholds, [0, 3]);
  assert.equal(config.notifyOverdue, true);
  assert.equal(config.itemTemplate, DEFAULT_CONFIG.itemTemplate);
  assert.equal(config.sheetName, "期限");
  assert.deepEqual(config.columns, { subject: "件名", due: "期限", assignee: "担当", status: "状態" });
  assert.deepEqual(config.doneValues, ["完了"]);
});

test("しきい値は重複を落として昇順に並べる", () => {
  assert.deepEqual(parseConfig(rows([["しきい値", "7,3,0,3"]])).thresholds, [0, 3, 7]);
});

test("しきい値は全角読点でも区切れる", () => {
  assert.deepEqual(parseConfig(rows([["しきい値", "5、1、0"]])).thresholds, [0, 1, 5]);
});

test("しきい値: 全角の数字と読点でも読める", () => {
  const config = parseConfig(rows([["しきい値", "３、０"]]));
  assert.deepEqual(config.thresholds, [0, 3]);
});

test("空欄は既定値に戻る", () => {
  const config = parseConfig(rows([["しきい値", ""], ["対象シート名", "   "], ["文面テンプレ", ""]]));
  assert.deepEqual(config.thresholds, [0, 3]);
  assert.equal(config.sheetName, "期限");
  assert.equal(config.itemTemplate, DEFAULT_CONFIG.itemTemplate);
});

test("チェックボックス（真偽値）でも TRUE / FALSE の文字でも読める", () => {
  assert.equal(parseConfig(rows([["超過も通知する", false]])).notifyOverdue, false);
  assert.equal(parseConfig(rows([["超過も通知する", "FALSE"]])).notifyOverdue, false);
  assert.equal(parseConfig(rows([["超過も通知する", "いいえ"]])).notifyOverdue, false);
  assert.equal(parseConfig(rows([["超過も通知する", true]])).notifyOverdue, true);
});

test("列名と完了の値を変えられる", () => {
  const config = parseConfig(
    rows([
      ["対象シート名", "支払い"],
      ["列名（件名）", "内容"],
      ["列名（期限）", "支払日"],
      ["列名（担当）", "担当者"],
      ["列名（状態）", "ステータス"],
      ["完了とみなす状態の値", "完了,支払済,不要"],
    ]),
  );
  assert.equal(config.sheetName, "支払い");
  assert.deepEqual(config.columns, { subject: "内容", due: "支払日", assignee: "担当者", status: "ステータス" });
  assert.deepEqual(config.doneValues, ["完了", "支払済", "不要"]);
});

test("キーの半角括弧・余分な空白・大文字小文字は吸収する", () => {
  const config = parseConfig([
    ["通知先", "Discord"],
    ["webhook url", WEBHOOK],
    ["列名 (件名)", "内容"],
  ]);
  assert.equal(config.target, "discord");
  assert.equal(config.columns.subject, "内容");
});

test("知らないキーは無視する", () => {
  const config = parseConfig(rows([["メモ", "ここは自由に書いてよい"], [], [""]]));
  assert.equal(config.webhookUrl, WEBHOOK);
});

test("間違いは ConfigError で、どこが悪いか日本語で言う", () => {
  assert.throws(() => parseConfig([["通知先", "slack"]]), ConfigError);
  assert.throws(() => parseConfig(rows([["通知先", "line"]])), /通知先/);
  assert.throws(() => parseConfig([["通知先", "slack"], ["Webhook URL", "http://example.com"]]), /https/);
  assert.throws(() => parseConfig(rows([["しきい値", "三日前"]])), /しきい値/);
  assert.throws(() => parseConfig(rows([["しきい値", "-1"]])), /しきい値/);
  assert.throws(() => parseConfig(rows([["超過も通知する", "たぶん"]])), /超過も通知する/);
});

test("CONFIG_KEYS は設定シートに並べる 11 個", () => {
  assert.deepEqual(CONFIG_KEYS, [
    "通知先",
    "Webhook URL",
    "しきい値",
    "超過も通知する",
    "文面テンプレ",
    "対象シート名",
    "列名（件名）",
    "列名（期限）",
    "列名（担当）",
    "列名（状態）",
    "完了とみなす状態の値",
  ]);
});
