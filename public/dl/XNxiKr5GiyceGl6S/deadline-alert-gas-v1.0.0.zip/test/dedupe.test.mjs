import { test } from "node:test";
import assert from "node:assert/strict";
import { dedupeKeyOf, removeSent, rowKeyOf, staleStoreNames, storeNameOf } from "../src/dedupe.js";

function row(subject, dueKey, rowNumber, assignee) {
  return {
    subject: subject,
    dueKey: dueKey,
    assignee: assignee === undefined ? "自分" : assignee,
    status: "",
    rowNumber: rowNumber,
    daysLeft: 0,
  };
}

function sections() {
  return [
    { bucket: "overdue", heading: "■ 期限を過ぎています", items: [row("家賃の振込", "2026-09-18", 2)] },
    {
      bucket: "d0",
      heading: "■ 今日が期限",
      items: [row("請求書の送付", "2026-09-20", 3), row("ドメイン更新", "2026-09-20", 4)],
    },
  ];
}

test("鍵の形は <件名>@<期限>@<担当>|<バケット>|<実行日>", () => {
  assert.equal(rowKeyOf(row("家賃の振込", "2026-09-18", 2)), "家賃の振込@2026-09-18@自分");
  assert.equal(rowKeyOf(row("家賃の振込", "2026-09-18", 2, "")), "家賃の振込@2026-09-18@");
  assert.equal(
    dedupeKeyOf(row("家賃の振込", "2026-09-18", 2), "overdue", "2026-09-20"),
    "家賃の振込@2026-09-18@自分|overdue|2026-09-20",
  );
});

test("初回は全部残り、鍵が全部返る", () => {
  const result = removeSent(sections(), [], "2026-09-20");
  assert.equal(result.sections.length, 2);
  assert.deepEqual(result.keys, [
    "家賃の振込@2026-09-18@自分|overdue|2026-09-20",
    "請求書の送付@2026-09-20@自分|d0|2026-09-20",
    "ドメイン更新@2026-09-20@自分|d0|2026-09-20",
  ]);
});

test("送信済みの行は落ち、空になった節ごと消える", () => {
  const result = removeSent(sections(), ["家賃の振込@2026-09-18@自分|overdue|2026-09-20"], "2026-09-20");
  assert.deepEqual(
    result.sections.map(function (section) {
      return section.bucket;
    }),
    ["d0"],
  );
  assert.equal(result.keys.length, 2);
});

test("全部送信済みなら節が残らない", () => {
  const all = removeSent(sections(), [], "2026-09-20").keys;
  const result = removeSent(sections(), all, "2026-09-20");
  assert.deepEqual(result.sections, []);
  assert.deepEqual(result.keys, []);
});

test("日付が変われば同じ行がまた通る", () => {
  const yesterday = removeSent(sections(), [], "2026-09-19").keys;
  const result = removeSent(sections(), yesterday, "2026-09-20");
  assert.equal(result.keys.length, 3);
});

test("まったく同じ行は 1 つにまとまり、担当だけ違う行は両方残る", () => {
  const doubled = [
    {
      bucket: "d0",
      heading: "■ 今日が期限",
      items: [row("重複", "2026-09-20", 2), row("重複", "2026-09-20", 9)],
    },
  ];
  const same = removeSent(doubled, [], "2026-09-20");
  assert.deepEqual(same.keys, ["重複@2026-09-20@自分|d0|2026-09-20"]);
  assert.equal(same.sections[0].items.length, 1);

  // 同じ作業を 2 人で分担している行。担当が違えば別の予定として両方知らせる
  const shared = [
    {
      bucket: "d0",
      heading: "■ 今日が期限",
      items: [row("月次の締め", "2026-09-20", 2, "経理"), row("月次の締め", "2026-09-20", 3, "営業")],
    },
  ];
  const result = removeSent(shared, [], "2026-09-20");
  assert.deepEqual(result.keys, [
    "月次の締め@2026-09-20@経理|d0|2026-09-20",
    "月次の締め@2026-09-20@営業|d0|2026-09-20",
  ]);
  assert.equal(result.sections[0].items.length, 2);
});

test("保存領域の名前と、古い保存領域の見分け", () => {
  assert.equal(storeNameOf("2026-09-20"), "sent:2026-09-20");
  assert.deepEqual(
    staleStoreNames(["sent:2026-09-18", "sent:2026-09-20", "何か別のプロパティ"], "2026-09-20"),
    ["sent:2026-09-18"],
  );
});
