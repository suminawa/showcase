import { test } from "node:test";
import assert from "node:assert/strict";
import { buildErrorMessage, buildMessage, buildPayload, renderItem } from "../src/message.js";

const TEMPLATE = "・{件名}（{期限}・{担当}）";

function row(subject, dueKey, daysLeft, assignee) {
  return {
    subject: subject,
    dueKey: dueKey,
    assignee: assignee === undefined ? "自分" : assignee,
    status: "",
    rowNumber: 2,
    daysLeft: daysLeft,
  };
}

const SECTIONS = [
  { bucket: "overdue", heading: "■ 期限を過ぎています", items: [row("家賃の振込", "2026-09-18", -2)] },
  {
    bucket: "d0",
    heading: "■ 今日が期限",
    items: [row("請求書の送付", "2026-09-20", 0), row("ドメイン更新", "2026-09-20", 0)],
  },
  { bucket: "d3", heading: "■ 3 日後が期限", items: [row("納付", "2026-09-23", 3)] },
];

test("テンプレの 4 つの差し込みが効く", () => {
  assert.equal(renderItem(TEMPLATE, row("家賃の振込", "2026-09-18", -2)), "・家賃の振込（9/18（金）・自分）");
  assert.equal(renderItem("{件名}｜{残日数}", row("納付", "2026-09-23", 3)), "納付｜あと 3 日");
  assert.equal(renderItem("{残日数}", row("今日", "2026-09-20", 0)), "今日");
  assert.equal(renderItem("{残日数}", row("超過", "2026-09-18", -2)), "2 日超過");
});

test("担当が空なら「担当なし」", () => {
  assert.equal(renderItem("{担当}", row("x", "2026-09-20", 0, "")), "担当なし");
});

test("同じ差し込みが 2 回出ても両方置き換わる", () => {
  assert.equal(renderItem("{件名}/{件名}", row("納付", "2026-09-23", 3)), "納付/納付");
});

test("件名に置き換え語が含まれていても、後から置き換えられない", () => {
  const item = row("見積 {担当} 送付", "2026-09-20", 0, "経理");
  const out = renderItem("・{件名}（{担当}）", item);
  assert.equal(out, "・見積 {担当} 送付（経理）");
});

test("1 通にまとまる", () => {
  const text = buildMessage(SECTIONS, { todayKey: "2026-09-20", itemTemplate: TEMPLATE });
  assert.equal(
    text,
    [
      "【期限アラート】9/20（日）",
      "",
      "■ 期限を過ぎています",
      "・家賃の振込（9/18（金）・自分）",
      "",
      "■ 今日が期限",
      "・請求書の送付（9/20（日）・自分）",
      "・ドメイン更新（9/20（日）・自分）",
      "",
      "■ 3 日後が期限",
      "・納付（9/23（水）・自分）",
    ].join("\n"),
  );
});

test("知らせるものも飛ばした行も無ければ null（送らない）", () => {
  assert.equal(buildMessage([], { todayKey: "2026-09-20", itemTemplate: TEMPLATE }), null);
  assert.equal(buildMessage(null, { todayKey: "2026-09-20", itemTemplate: TEMPLATE }), null);
  assert.equal(buildMessage([], { todayKey: "2026-09-20", itemTemplate: TEMPLATE, skipped: [] }), null);
});

test("読めない行があれば末尾に注意書きを足す", () => {
  const text = buildMessage(SECTIONS, {
    todayKey: "2026-09-20",
    itemTemplate: TEMPLATE,
    skipped: [{ rowNumber: 4, reason: "期限が読めません" }, { rowNumber: 7, reason: "期限が読めません" }],
  });
  assert.ok(text.endsWith("※ 期限が読めません: 2 件（4 行目、7 行目）"));
});

test("飛ばした行は理由ごとにまとめ、理由の文言をそのまま出す", () => {
  const text = buildMessage(SECTIONS, {
    todayKey: "2026-09-20",
    itemTemplate: TEMPLATE,
    skipped: [
      { rowNumber: 5, reason: "期限が読めません" },
      { rowNumber: 7, reason: "「件名」が空です" },
      { rowNumber: 8, reason: "期限が読めません" },
    ],
  });
  assert.ok(text.endsWith("※ 期限が読めません: 2 件（5 行目、8 行目）、「件名」が空です: 1 件（7 行目）"));
});

test("全部の行が読めない日でも黙らない", () => {
  const text = buildMessage([], {
    todayKey: "2026-09-20",
    itemTemplate: TEMPLATE,
    skipped: [{ rowNumber: 7, reason: "期限が読めません" }],
  });
  assert.equal(
    text,
    ["【期限アラート】9/20（日）", "今日の通知はありません。", "※ 期限が読めません: 1 件（7 行目）"].join("\n"),
  );
});

test("エラーは別の見出しで出す", () => {
  const text = buildErrorMessage(new Error("「設定」シートがありません"), "2026-09-20");
  assert.ok(text.indexOf("【期限アラート｜エラー】9/20（日）") === 0);
  assert.ok(text.indexOf("「設定」シートがありません") > 0);
  assert.ok(buildErrorMessage("文字列でも受ける", "2026-09-20").indexOf("文字列でも受ける") > 0);
});

test("Slack と Discord で送信データの形が違う", () => {
  assert.deepEqual(buildPayload("やあ", "slack"), { text: "やあ" });
  assert.deepEqual(buildPayload("やあ", "discord"), { content: "やあ" });
});

test("Discord の 2000 字制限に引っかからないよう切る", () => {
  const long = "あ".repeat(5000);
  const payload = buildPayload(long, "discord");
  assert.ok(payload.content.length <= 1900);
  assert.ok(payload.content.endsWith("…（以下省略）"));
  assert.equal(buildPayload(long, "slack").text.length, 5000);
});
