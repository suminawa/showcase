import { test } from "node:test";
import assert from "node:assert/strict";
import { readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildSource, MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("import 行は落ち、export だけが剥がれる", () => {
  const input = 'import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\n';
  assert.equal(toGasSource(input), "function f() {\n  return 1;\n}");
});

test("export const / export class も剥がれ、中身の行は触らない", () => {
  const input = 'export const A = 1;\nexport class B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}\n';
  assert.equal(toGasSource(input), "const A = 1;\nclass B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}");
});

test("つないだ結果に import / export は残らない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(buildSource(root)), false);
});

test("入口の 4 つが入っている", () => {
  const code = buildSource(root);
  for (const name of ["function runDeadlineAlert()", "function onOpen()", "function createDailyTrigger()", "function sendTestNotification()"]) {
    assert.ok(code.includes(name), name + " が無い");
  }
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = buildSource(root);
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("SOURCE_ORDER に src の取りこぼしが無い", () => {
  const files = readdirSync(join(root, "src")).filter((name) => name.endsWith(".js")).sort();
  assert.deepEqual(SOURCE_ORDER.slice().sort(), files);
});

test("マニフェストは Asia/Tokyo の V8", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
});
