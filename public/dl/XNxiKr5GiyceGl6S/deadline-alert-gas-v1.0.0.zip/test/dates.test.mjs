import { test } from "node:test";
import assert from "node:assert/strict";
import { diffDays, formatDisplay, toDateKey, todayKey } from "../src/dates.js";

test("日付セル（Date）は Asia/Tokyo の日付になる", () => {
  assert.equal(toDateKey(new Date("2026-09-19T15:00:00Z")), "2026-09-20");
  assert.equal(toDateKey(new Date("2026-09-19T14:59:00Z")), "2026-09-19");
});

test("文字列は - / . 年月日 のどれでも読む", () => {
  assert.equal(toDateKey("2026-09-20"), "2026-09-20");
  assert.equal(toDateKey("2026/9/20"), "2026-09-20");
  assert.equal(toDateKey("2026.9.20"), "2026-09-20");
  assert.equal(toDateKey("2026年9月20日"), "2026-09-20");
  assert.equal(toDateKey(" 2026-09-20 "), "2026-09-20");
});

test("読めない値は null", () => {
  assert.equal(toDateKey(""), null);
  assert.equal(toDateKey(null), null);
  assert.equal(toDateKey(undefined), null);
  assert.equal(toDateKey("来週"), null);
  assert.equal(toDateKey("2026-02-30"), null);
  assert.equal(toDateKey("2026-13-01"), null);
  assert.equal(toDateKey(new Date("x")), null);
});

test("diffDays は月をまたいでも数えられる", () => {
  assert.equal(diffDays("2026-09-20", "2026-09-20"), 0);
  assert.equal(diffDays("2026-09-20", "2026-09-23"), 3);
  assert.equal(diffDays("2026-09-20", "2026-09-18"), -2);
  assert.equal(diffDays("2026-09-30", "2026-10-01"), 1);
});

test("formatDisplay は曜日つきで短く出す", () => {
  assert.equal(formatDisplay("2026-09-20"), "9/20（日）");
  assert.equal(formatDisplay("2026-09-18"), "9/18（金）");
  assert.equal(formatDisplay("2026-10-01"), "10/1（木）");
});

test("todayKey は Asia/Tokyo の今日", () => {
  assert.equal(todayKey(new Date("2026-09-19T23:30:00Z")), "2026-09-20");
});
