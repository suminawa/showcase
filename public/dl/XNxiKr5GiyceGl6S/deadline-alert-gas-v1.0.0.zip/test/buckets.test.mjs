import { test } from "node:test";
import assert from "node:assert/strict";
import { collectSections, headingOf, OVERDUE } from "../src/buckets.js";
import { parseConfig } from "../src/config.js";

const WEBHOOK = "https://hooks.slack.com/services/T000/B000/xxxx";

function configWith(extra) {
  return parseConfig([["通知先", "slack"], ["Webhook URL", WEBHOOK]].concat(extra || []));
}

function item(subject, dueKey, rowNumber) {
  return { subject: subject, dueKey: dueKey, assignee: "自分", status: "", rowNumber: rowNumber };
}

const TODAY = "2026-09-20";

test("しきい値に当たる日と超過だけを拾う", () => {
  const sections = collectSections(
    [
      item("超過", "2026-09-18", 2),
      item("今日", "2026-09-20", 3),
      item("明日", "2026-09-21", 4),
      item("3 日後", "2026-09-23", 5),
      item("ずっと先", "2026-10-10", 6),
    ],
    configWith(),
    TODAY,
  );
  assert.deepEqual(
    sections.map(function (section) {
      return section.bucket;
    }),
    ["overdue", "d0", "d3"],
  );
  assert.deepEqual(
    sections.map(function (section) {
      return section.items.map(function (row) {
        return row.subject;
      });
    }),
    [["超過"], ["今日"], ["3 日後"]],
  );
});

test("残り日数を足す", () => {
  const sections = collectSections([item("超過", "2026-09-18", 2), item("今日", "2026-09-20", 3)], configWith(), TODAY);
  assert.equal(sections[0].items[0].daysLeft, -2);
  assert.equal(sections[1].items[0].daysLeft, 0);
});

test("超過を通知しない設定なら超過の節は出ない", () => {
  const sections = collectSections(
    [item("超過", "2026-09-18", 2), item("今日", "2026-09-20", 3)],
    configWith([["超過も通知する", "FALSE"]]),
    TODAY,
  );
  assert.deepEqual(
    sections.map(function (section) {
      return section.bucket;
    }),
    ["d0"],
  );
});

test("節の中は期限の早い順、同じ日なら行番号の順", () => {
  const sections = collectSections(
    [item("後の行", "2026-09-20", 9), item("古い超過", "2026-09-10", 5), item("先の行", "2026-09-20", 3), item("新しい超過", "2026-09-19", 4)],
    configWith(),
    TODAY,
  );
  assert.deepEqual(
    sections[0].items.map(function (row) {
      return row.subject;
    }),
    ["古い超過", "新しい超過"],
  );
  assert.deepEqual(
    sections[1].items.map(function (row) {
      return row.subject;
    }),
    ["先の行", "後の行"],
  );
});

test("何も当たらなければ空の配列", () => {
  assert.deepEqual(collectSections([item("ずっと先", "2026-10-10", 2)], configWith(), TODAY), []);
  assert.deepEqual(collectSections([], configWith(), TODAY), []);
});

test("しきい値を増やすと節が増え、近い順に並ぶ", () => {
  const sections = collectSections(
    [item("7 日後", "2026-09-27", 2), item("今日", "2026-09-20", 3), item("1 日後", "2026-09-21", 4)],
    configWith([["しきい値", "7,1,0"]]),
    TODAY,
  );
  assert.deepEqual(
    sections.map(function (section) {
      return section.bucket;
    }),
    ["d0", "d1", "d7"],
  );
});

test("見出しの文言", () => {
  assert.equal(headingOf(OVERDUE), "■ 期限を過ぎています");
  assert.equal(headingOf("d0"), "■ 今日が期限");
  assert.equal(headingOf("d3"), "■ 3 日後が期限");
});
