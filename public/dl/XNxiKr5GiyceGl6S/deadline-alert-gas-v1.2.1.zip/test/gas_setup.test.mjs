import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";
import { buildSource } from "../scripts/build.mjs";
import { todayKey } from "../src/dates.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const REAL_URL = "https://hooks.slack.com/services/T000/B000/xxxx";
const VERSION = JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version;
/** 「設定を確かめる」の 1 行目（サポートで版を確かめられるように） */
const VERSION_LINE = "期限アラート GAS キット v" + VERSION + "\n\n";

// ===== つないだ 1 本を、GAS の偽物を並べた入れ物の中で実際に動かす =====
// 偽物の元: フォーム受付 GAS キット 1.0.0 の test/build.test.mjs の fakeSheet / runBundle。
// 初期化を通すために、getRange を行と列の位置どおりに書く形に広げ、insertSheet・setFrozenRows・
// insertColumnsAfter・getLastColumn・メニュー・トリガー・書き込みの権限なしを足した。

/** 見本 CSV を行と列に割る（"..." の中のカンマは区切りにしない） */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function sample(name) {
  return rowsOf(readFileSync(join(root, "samples", name), "utf8"));
}

/** 本物の Sheets と同じく、先頭の ' は字のままにする印として落とす */
function written(value) {
  return typeof value === "string" && value.charAt(0) === "'" ? value.slice(1) : value;
}

function fakeSheet(values, options) {
  const rows = values.map((row) => Array.from(row));
  const denied = (c) => {
    if (options.denyWrite === "protected") {
      throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit.");
    }
    if (options.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
    if (options.denyHeaderWrite && c > 1) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
  };
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const sheet = {
    rows: rows,
    frozen: 0,
    getLastRow: () => rows.length,
    getLastColumn: () => width(),
    getMaxColumns: () => Math.max(26, width()),
    insertColumnsAfter: () => {},
    setFrozenRows: (n) => {
      sheet.frozen = n;
    },
    getDataRange: () => ({ getValues: () => rows.map((row) => row.slice()) }),
    getRange: (r, c) => ({
      setValues: (block) => {
        denied(c);
        for (let i = 0; i < block.length; i += 1) {
          while (rows.length < r + i) rows.push([]);
          const line = rows[r - 1 + i];
          for (let j = 0; j < block[i].length; j += 1) {
            while (line.length < c - 1 + j) line.push("");
            line[c - 1 + j] = written(block[i][j]);
          }
        }
        const w = width();
        for (const line of rows) while (line.length < w) line.push("");
      },
    }),
    appendRow: (row) => {
      denied();
      rows.push(Array.from(row));
    },
  };
  return sheet;
}

/** つないだ 1 本を偽の GAS の上で読み込み、入口と、触った跡を返す */
function runBundle(seed, options) {
  const opts = options || {};
  const trace = { alerts: [], menu: [], logs: [], fetched: [], mailed: [] };
  const props = Object.assign({}, opts.props);
  const sheets = {};
  for (const name of Object.keys(seed)) sheets[name] = fakeSheet(seed[name], opts);
  const book = {
    getSpreadsheetTimeZone: () => (opts.timeZone === undefined ? "Asia/Tokyo" : opts.timeZone),
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (opts.denyWrite === "protected") {
        throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit.");
      }
      if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Spreadsheet.insertSheet.");
      sheets[name] = fakeSheet([], opts);
      return sheets[name];
    },
  };
  const menu = {
    addItem: (label, handler) => {
      trace.menu.push(label + " → " + handler);
      return menu;
    },
    addSeparator: () => {
      trace.menu.push("──");
      return menu;
    },
    addToUi: () => {},
  };
  const sandbox = {
    SpreadsheetApp: {
      getActiveSpreadsheet: () => book,
      getUi: () => ({ alert: (text) => trace.alerts.push(String(text)), createMenu: () => menu }),
    },
    ScriptApp: {
      getProjectTriggers: () => (opts.triggers || []).map((handler) => ({ getHandlerFunction: () => handler })),
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (props[key] === undefined ? null : props[key]),
        setProperty: (key, value) => {
          props[key] = String(value);
        },
        getKeys: () => Object.keys(props),
        deleteProperty: (key) => {
          delete props[key];
        },
      }),
    },
    UrlFetchApp: {
      fetch: (url, fetchOptions) => {
        trace.fetched.push({ url: url, payload: fetchOptions.payload });
        const status = opts.fetchStatus === undefined ? 200 : opts.fetchStatus;
        return { getResponseCode: () => status, getContentText: () => (status === 200 ? "ok" : "no_service") };
      },
    },
    MailApp: {
      getRemainingDailyQuota: () => (opts.quota === undefined ? 100 : opts.quota),
      sendEmail: (mail) => {
        if (opts.mailThrows) throw new Error("Invalid email: " + mail.to);
        trace.mailed.push(mail);
      },
    },
    Utilities: { newBlob: (text) => ({ getBytes: () => Array.from(Buffer.from(String(text), "utf8")) }) },
    Logger: { log: (text) => trace.logs.push(String(text)) },
    LockService: {
      getScriptLock: () => ({ tryLock: () => opts.lockBusy !== true, releaseLock: () => {} }),
    },
  };
  const context = createContext(sandbox);
  runInContext(
    buildSource(root) +
      "\nglobalThis.__entry = { initializeSheets: initializeSheets, checkSettings: checkSettings, onOpen: onOpen, runDeadlineAlert: runDeadlineAlert, sendTestNotification: sendTestNotification, saveSecrets: saveSecrets };\n",
    context,
  );
  return { entry: sandbox.__entry, trace: trace, sheets: sheets, props: props };
}

function sampleSeed(withRealUrl) {
  return {
    設定: sample("settings-sample.csv").map((row) => (withRealUrl && row[0] === "Webhook URL" ? [row[0], REAL_URL] : row)),
    期限: sample("deadlines-sample.csv"),
  };
}

test("initializeSheets: 空のブックに 設定・期限 を作り、2 回目は「変更はありません」", () => {
  const run = runBundle({});
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("・シートを作りました: 設定、期限"), run.trace.alerts[0]);
  assert.equal(run.sheets["設定"].rows.length, 16);
  assert.deepEqual(run.sheets["設定"].rows[6], ["しきい値", "3,0"], "3,0 は字のまま入る");
  assert.deepEqual(run.sheets["期限"].rows, [["件名", "期限", "担当", "状態"]]);
  assert.equal(run.sheets["期限"].frozen, 1);

  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[1].startsWith("変更はありません。"), run.trace.alerts[1]);
  assert.equal(run.sheets["設定"].rows.length, 16);
});

test("checkSettings: 初期化しただけのブックでは、通知先を決める案内が出る（Webhook URL が空とは言わない）", () => {
  const run = runBundle({});
  run.entry.initializeSheets();
  run.entry.checkSettings();
  const text = run.trace.alerts[1];
  assert.ok(text.startsWith(VERSION_LINE + "直すところがあります。"), text);
  assert.ok(text.includes("・「設定」シートの「通知先」と送り先がまだ空です。"), text);
  assert.equal(text.includes("「Webhook URL」が空です"), false, text);
  assert.ok(text.includes("ご参考:\n・毎朝 8 時の実行はまだ作っていません。"));
});

test("1.0 の見本のブック: 初期化は何も変えず、設定を確かめるは「問題ありません。」", () => {
  const seed = sampleSeed(true);
  const run = runBundle(seed, { triggers: ["runDeadlineAlert"] });
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].startsWith("変更はありません。"), run.trace.alerts[0]);
  assert.deepEqual(run.sheets["期限"].rows, seed.期限);
  assert.deepEqual(run.sheets["設定"].rows, seed.設定);

  run.entry.checkSettings();
  const text = run.trace.alerts[1];
  assert.ok(text.startsWith(VERSION_LINE + "問題ありません。\n\n通知: slack に、毎朝 8 時ごろ 1 通送ります（毎朝の実行: 作ってあります）"), text);
  assert.equal(text.includes(REAL_URL), false, "URL は出さない");
});

test("initializeSheets: 設定の行を行ごと消してから押すと、最終行の下に既定値で足す", () => {
  const seed = sampleSeed(true);
  seed.設定 = seed.設定.filter((row) => row[0] !== "しきい値");
  const run = runBundle(seed);
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("・「設定」シートに 1 行足しました: しきい値（値は既定値です。変えるときは書き換えてください）"));
  const rows = run.sheets["設定"].rows;
  assert.deepEqual(rows[rows.length - 1], ["しきい値", "3,0"]);
  assert.equal(rows.length, 16);
});

test("initializeSheets: 見出しが 1 列足りない期限シートに、既存の見出し・データはそのまま、新しい見出しだけ最終列の右に足す", () => {
  const seed = {
    設定: sample("settings-sample.csv").map((row) => (row[0] === "Webhook URL" ? [row[0], REAL_URL] : row)),
    期限: [
      ["件名", "期限", "担当"],
      ["A 社への請求書送付", "2026-09-20", "自分"],
      ["B 社との契約更新", "2026-09-25", "自分"],
    ],
  };
  const before = seed.期限.map((row) => row.slice());
  const run = runBundle(seed);
  run.entry.initializeSheets();
  const after = run.sheets["期限"].rows;
  // 新しい見出しは、それまでの最終列のすぐ右に 1 列だけ足される
  assert.equal(after[0].length, before[0].length + 1);
  assert.equal(after[0][before[0].length], "状態");
  // 既存の見出し・データのセルは 1 つも変わらない（バイト同一）
  for (let i = 0; i < before.length; i += 1) {
    assert.deepEqual(after[i].slice(0, before[i].length), before[i]);
  }
  // 知らせにも足した見出しが出る
  assert.ok(run.trace.alerts[0].includes("・「期限」シートの見出しに足しました: 状態"), run.trace.alerts[0]);
});

test("編集権限が無いときは、敬体の 1 文で知らせる", () => {
  const run = runBundle({}, { denyWrite: true });
  run.entry.initializeSheets();
  assert.equal(
    run.trace.alerts[0],
    "うまくいきませんでした。次の内容をご確認ください。\n\nシートの作成で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください",
  );
});

test("保護されたレンジで止まったときも、権限の 1 文に言い換える", () => {
  const run = runBundle({}, { denyWrite: "protected" });
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), run.trace.alerts[0]);
});

test("初期化の途中(見出しの追記)で失敗しても、そこまでにできたことを知らせる", () => {
  const seed = {
    設定: sample("settings-sample.csv")
      .map((row) => (row[0] === "Webhook URL" ? [row[0], REAL_URL] : row))
      .filter((row) => row[0] !== "しきい値"),
    期限: [["件名", "期限", "担当"]],
  };
  const run = runBundle(seed, { denyHeaderWrite: true });
  run.entry.initializeSheets();
  const text = run.trace.alerts[0];
  assert.ok(text.includes("「設定」に 1 行を足しました"), text);
  assert.ok(text.includes("そのあと 見出しの追記で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), text);
});

test("onOpen: 1 番目が初期化、2 番目が設定を確かめる", () => {
  const run = runBundle({});
  run.entry.onOpen();
  assert.deepEqual(run.trace.menu, [
    "初期化（足りないシート・見出し・設定を足す。データは消しません） → initializeSheets",
    "設定を確かめる → checkSettings",
    "──",
    "テスト送信 → sendTestNotification",
    "今すぐ通知を送る → runDeadlineAlert",
    "毎朝 8 時に動かす → createDailyTrigger",
    "──",
    "鍵を保存（Webhook の URL をシートから隠す） → saveSecrets",
  ]);
});

test("設定シートが無いまま毎朝の実行が動くと、初期化を案内する", () => {
  const run = runBundle({});
  assert.throws(() => run.entry.runDeadlineAlert(), /メニュー「期限アラート」→「初期化」を実行してください。/);
});

test("runDeadlineAlert: ほかの実行が走っている間は送らない（二重送信を防ぐ）", () => {
  const seed = sampleSeed(true);
  seed.期限 = seed.期限.concat([["今日の予定", todayKey(new Date()), "自分", ""]]);
  const busy = runBundle(seed, { lockBusy: true });
  busy.entry.runDeadlineAlert();
  assert.equal(busy.trace.fetched.length, 0);
  assert.ok(busy.trace.logs.some((line) => line.includes("今回は送りませんでした")), busy.trace.logs.join("\n"));

  const free = runBundle(seed, {});
  free.entry.runDeadlineAlert();
  assert.equal(free.trace.fetched.length, 1);
});

/** 見本のブックの設定を書き換え、今日が期限の行を 1 つ足した seed */
function todaySeed(pairs) {
  const seed = sampleSeed(true);
  for (const [key, value] of pairs) {
    const at = seed.設定.findIndex((row) => row[0] === key);
    if (at >= 0) seed.設定[at] = [key, value];
    else seed.設定.push([key, value]);
  }
  // 入れ物（vm）の外で作った Date は instanceof Date にならないので、今日の日付は字で書く
  seed.期限 = seed.期限.concat([["今日の予定 <!channel>", todayKey(new Date()), "自分", ""]]);
  return seed;
}

/** いまの日本の日付の「M/D」 */
function todayLabel() {
  const parts = todayKey(new Date()).split("-");
  return Number(parts[1]) + "/" + Number(parts[2]);
}

test("runDeadlineAlert: 通知先 gmail は、メールの宛先へ件名つきで 1 通送り、Webhook には送らない", () => {
  const run = runBundle(todaySeed([["通知先", "gmail"], ["メールの宛先", "keiri@example.co.jp, tanaka@example.co.jp"]]));
  run.entry.runDeadlineAlert();
  assert.equal(run.trace.fetched.length, 0);
  assert.equal(run.trace.mailed.length, 1);
  const mail = run.trace.mailed[0];
  assert.equal(mail.to, "keiri@example.co.jp,tanaka@example.co.jp");
  assert.equal(mail.name, "期限アラート");
  assert.match(mail.subject, new RegExp("^【期限】" + todayLabel() + " の通知（\\d+ 件）$"));
  assert.ok(mail.body.includes("■ 今日が期限\n・今日の予定 <!channel>（"), "メールの本文は字のまま（文字参照にしない）: " + mail.body);

  // 同じ日にもう一度動かしても、二度は送らない
  run.entry.runDeadlineAlert();
  assert.equal(run.trace.mailed.length, 1);
});

test("runDeadlineAlert: slack,gmail で Slack だけ 404 でも、メールは届き、Slack の失敗をメールで知らせる", () => {
  const run = runBundle(todaySeed([["通知先", "slack,gmail"], ["メールの宛先", "keiri@example.co.jp"]]), { fetchStatus: 404 });
  assert.throws(() => run.entry.runDeadlineAlert(), /送れなかった通知先があります。\n・Slack: 送れませんでした（Webhook が 404 を返しました: no_service）/);
  assert.equal(run.trace.mailed.length, 2, "本番の 1 通と、エラーの 1 通");
  assert.match(run.trace.mailed[0].subject, /^【期限】/);
  assert.match(run.trace.mailed[1].subject, /^【期限アラート｜エラー】/);
  assert.ok(run.trace.mailed[1].body.includes("「Webhook URL」が違うか、Webhook が消されています。"), run.trace.mailed[1].body);
  // メールには届いたので、送った記録は残す（次の実行で、メールに同じ通知を重ねて送らない）
  assert.equal(Object.keys(run.props).filter((key) => key.indexOf("sent:") === 0).length, 1);
  run.entry.runDeadlineAlert();
  assert.equal(run.trace.mailed.length, 2);
});

test("runDeadlineAlert: 設定が壊れていても、宛先が読めれば gmail にエラーを届ける", () => {
  const run = runBundle(todaySeed([["通知先", "gmail"], ["メールの宛先", "keiri@example.co.jp"], ["しきい値", "三日"]]));
  assert.throws(() => run.entry.runDeadlineAlert(), /しきい値/);
  assert.equal(run.trace.mailed.length, 1);
  assert.match(run.trace.mailed[0].subject, /^【期限アラート｜エラー】/);
  assert.ok(run.trace.mailed[0].body.includes("「しきい値」は 0 以上の整数"), run.trace.mailed[0].body);
});

test("sendTestNotification: 送れた先と、送れなかった先の直し方を画面に出す", () => {
  const ok = runBundle(todaySeed([["通知先", "slack,gmail"], ["メールの宛先", "keiri@example.co.jp"]]));
  ok.entry.sendTestNotification();
  assert.equal(ok.trace.alerts[0], "Slack・Gmail に送りました。届いていれば、通知先の設定は合っています。\n\nメールが見当たらないときは、迷惑メールのフォルダもご確認ください。");
  assert.equal(ok.trace.mailed[0].subject, "【期限アラート】テスト送信");

  const failing = runBundle(todaySeed([["通知先", "slack,gmail"], ["メールの宛先", "keiri@example.co.jp"]]), { mailThrows: true });
  failing.entry.sendTestNotification();
  assert.equal(
    failing.trace.alerts[0],
    "1 か所に送り、1 か所は送れませんでした。次のとおり直して、もう一度お試しください。\n\n・Gmail: 送れませんでした（Invalid email: keiri@example.co.jp）。「メールの宛先」のアドレスをご確認ください。",
  );
});

test("runDeadlineAlert: 通知先 googlechat は、スペースの Webhook へ {text} で送り、<users/all> は呼び出しにしない", () => {
  const chat = "https://chat.googleapis.com/v1/spaces/AAAA/messages?key=k&token=t";
  const run = runBundle(todaySeed([["通知先", "googlechat"], ["Google Chat の Webhook URL", chat], ["文面テンプレ", "・{件名} <users/all>"]]));
  run.entry.runDeadlineAlert();
  assert.equal(run.trace.mailed.length, 0);
  assert.equal(run.trace.fetched.length, 1);
  assert.equal(run.trace.fetched[0].url, chat);
  const payload = JSON.parse(run.trace.fetched[0].payload);
  assert.deepEqual(Object.keys(payload), ["text"]);
  assert.ok(payload.text.includes("・今日の予定 ＜!channel＞ ＜users/all＞"), payload.text);
  assert.equal(payload.text.includes("<"), false);
});

// ===== 1.2.1 =====
test("1.2.1 版: 「設定を確かめる」の 1 行目と、毎朝の実行ログに出る", () => {
  const run = runBundle(todaySeed([]), { triggers: ["runDeadlineAlert"] });
  run.entry.checkSettings();
  assert.ok(run.trace.alerts[0].startsWith(VERSION_LINE), run.trace.alerts[0]);
  run.entry.runDeadlineAlert();
  assert.ok(run.trace.logs.some((line) => line.startsWith("期限アラート v" + VERSION + ": ")), run.trace.logs.join("\n"));
});

test("1.2.1 鍵を保存: URL をスクリプト プロパティへ移してシートには（保存済み）と書き、そのあとも同じ URL に届く", () => {
  const run = runBundle(todaySeed([]), { triggers: ["runDeadlineAlert"] });
  run.entry.saveSecrets();
  assert.equal(run.props["secret:Webhook URL"], REAL_URL);
  const row = run.sheets["設定"].rows.find((r) => r[0] === "Webhook URL");
  assert.equal(row[1], "（保存済み）");
  assert.ok(run.trace.alerts[0].includes("「Webhook URL」"), run.trace.alerts[0]);
  assert.equal(run.trace.alerts[0].includes(REAL_URL), false, "URL は画面に出さない");

  run.entry.runDeadlineAlert();
  assert.equal(run.trace.fetched.length, 1);
  assert.equal(run.trace.fetched[0].url, REAL_URL);
  run.entry.checkSettings();
  const text = run.trace.alerts[run.trace.alerts.length - 1];
  assert.ok(text.startsWith(VERSION_LINE + "問題ありません。"), text);
  assert.equal(text.includes("鍵を保存"), false, "移したあとは勧めない");
  assert.equal(run.trace.logs.join("\n").includes(REAL_URL), false, "実行ログにも出さない");

  // 2 回目は移すものが無い
  run.entry.saveSecrets();
  assert.ok(run.trace.alerts[run.trace.alerts.length - 1].startsWith("シートに書かれた URL はありません。"), run.trace.alerts[run.trace.alerts.length - 1]);
});

test("1.2.1 鍵を保存のあと、設定が壊れていても保存した URL でエラーを届ける", () => {
  const run = runBundle(todaySeed([["Webhook URL", "（保存済み）"], ["しきい値", "三日"]]), { props: { "secret:Webhook URL": REAL_URL } });
  assert.throws(() => run.entry.runDeadlineAlert(), /しきい値/);
  assert.equal(run.trace.fetched.length, 1);
  assert.equal(run.trace.fetched[0].url, REAL_URL);
});

test("1.2.1 超過が 150 件あっても、上限日数（30 日）より前のものは送らず、送信済みの鍵もあふれない", () => {
  const seed = todaySeed([]);
  const base = new Date(todayKey(new Date()) + "T00:00:00+09:00").getTime();
  for (let i = 1; i <= 150; i += 1) {
    seed.期限.push(["放置 " + i, todayKey(new Date(base - i * 86400000)), "自分", ""]);
  }
  const run = runBundle(seed);
  run.entry.runDeadlineAlert();
  const payload = JSON.parse(run.trace.fetched[0].payload).text;
  assert.ok(payload.includes("放置 30（"), payload);
  assert.equal(payload.includes("放置 31（"), false);
  assert.equal(run.trace.logs.some((line) => line.includes("保存しませんでした")), false, run.trace.logs.join("\n"));
});
