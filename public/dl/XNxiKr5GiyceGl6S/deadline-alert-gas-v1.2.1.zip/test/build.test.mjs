import { test } from "node:test";
import assert from "node:assert/strict";
import { readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildSource, headerOf, MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("import 行は落ち、export だけが剥がれる", () => {
  const input = 'import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\n';
  assert.equal(toGasSource(input), "function f() {\n  return 1;\n}");
});

test("export const / export class も剥がれ、中身の行は触らない", () => {
  const input = 'export const A = 1;\nexport class B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}\n';
  assert.equal(toGasSource(input), "const A = 1;\nclass B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}");
});

test("つないだ結果に import / export は残らない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(buildSource(root)), false);
});

test("入口の 4 つが入っている", () => {
  const code = buildSource(root);
  for (const name of ["function runDeadlineAlert()", "function onOpen()", "function createDailyTrigger()", "function sendTestNotification()"]) {
    assert.ok(code.includes(name), name + " が無い");
  }
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = buildSource(root);
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("SOURCE_ORDER に src の取りこぼしが無い", () => {
  const files = readdirSync(join(root, "src")).filter((name) => name.endsWith(".js")).sort();
  assert.deepEqual(SOURCE_ORDER.slice().sort(), files);
});

test("マニフェストは Asia/Tokyo の V8", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
});

test("マニフェストの許可は、使う GAS のサービスとそろっている（書き漏らすと、その働きだけ動かない）", () => {
  const code = buildSource(root);
  const needs = {
    "https://www.googleapis.com/auth/spreadsheets.currentonly": "SpreadsheetApp.getActiveSpreadsheet",
    "https://www.googleapis.com/auth/script.external_request": "UrlFetchApp.fetch",
    "https://www.googleapis.com/auth/script.send_mail": "MailApp.sendEmail",
    "https://www.googleapis.com/auth/script.container.ui": "SpreadsheetApp.getUi",
    "https://www.googleapis.com/auth/script.scriptapp": "ScriptApp.newTrigger",
  };
  assert.deepEqual(MANIFEST.oauthScopes.slice().sort(), Object.keys(needs).sort());
  for (const scope of Object.keys(needs)) assert.ok(code.includes(needs[scope]), needs[scope] + " を使っていない");
});

test("最初の関数は runDeadlineAlert のまま（エディタの実行ボタンの既定）。初期化と設定を確かめるも入っている", () => {
  const code = buildSource(root);
  assert.equal(code.match(/^function\s+([A-Za-z0-9_$]+)/m)[1], "runDeadlineAlert");
  for (const name of ["function initializeSheets()", "function checkSettings()"]) {
    assert.ok(code.includes(name), name + " が無い");
  }
});

test("1.2.1: 権限は「このスプレッドシートだけ」。ほかのシートを開く呼び出しを使っていない", () => {
  const code = buildSource(root);
  assert.equal(MANIFEST.oauthScopes.includes("https://www.googleapis.com/auth/spreadsheets"), false);
  for (const call of ["SpreadsheetApp.openById", "SpreadsheetApp.openByUrl", "SpreadsheetApp.open(", "SpreadsheetApp.create"]) {
    assert.equal(code.includes(call), false, call);
  }
});

test("1.2.1: Code.gs の 1 行目に版、2 行目に @OnlyCurrentDoc（マニフェストを差し替えなくても権限が「このスプレッドシート」になる）", () => {
  const lines = headerOf("9.9.9").split("\n");
  assert.ok(lines[0].startsWith("// 期限アラート GAS キット v9.9.9 "), lines[0]);
  assert.equal(lines[1], "/** @OnlyCurrentDoc */");
});
