import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

/*
 * tokens.css の色を書き換えたときに、字が読めなくなっていないかを npm test で見張る。
 * 基準は WCAG 2.2 AA（本文 4.5:1）。ヒーローの飾りが重なる地は、tokens.css のコメントに
 * 個別の計算がある ── ここでは平らな地と、半透明のヘッダーの上だけを見る。
 */
const css = readFileSync(fileURLToPath(new URL("./tokens.css", import.meta.url)), "utf8");

function block(selector: string): string {
  const start = css.indexOf(`${selector} {`);
  if (start < 0) throw new Error(`${selector} が tokens.css に無い`);
  return css.slice(start, css.indexOf("}", start));
}

const root = block(":root");

/** 組の中の --d-* を #rrggbb で返す。var(--x-paper) は :root から引く */
function token(theme: string, name: string): string {
  const read = (src: string, key: string) =>
    src.match(new RegExp(`${key}:\\s*([^;]+);`))?.[1].trim();
  let value = read(block(theme), name);
  const ref = value?.match(/^var\((--[\w-]+)\)$/);
  if (ref) value = read(root, ref[1]);
  if (!value?.match(/^#[0-9a-f]{6}$/i)) throw new Error(`${theme} ${name} が #rrggbb でない: ${value}`);
  return value;
}

type Rgb = [number, number, number];
const rgb = (hex: string): Rgb => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as Rgb;
const mix = (top: Rgb, bottom: Rgb, alpha: number): Rgb =>
  top.map((c, i) => c * alpha + bottom[i] * (1 - alpha)) as Rgb;

function luminance([r, g, b]: Rgb): number {
  const f = (v: number) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}

function contrast(a: Rgb, b: Rgb): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

const themes = [
  ".theme-saas",
  ".theme-shop",
  ".theme-construction",
  ".theme-professional",
  ".theme-clinic",
  ".theme-corporate",
];

describe("tokens.css のコントラスト", () => {
  it("計算が WCAG の値と合う", () => {
    expect(contrast([0, 0, 0], [255, 255, 255])).toBeCloseTo(21, 5);
    expect(contrast(rgb("#767676"), rgb("#ffffff"))).toBeCloseTo(4.54, 2);
  });

  for (const theme of themes) {
    it(`${theme}: 本文・控えめな字（ナビ・注記）は、地・面・淡い面の上で 4.5:1 以上`, () => {
      for (const fg of ["--d-fg", "--d-muted", "--d-brand-ink"]) {
        for (const bg of ["--d-bg", "--d-surface", "--d-soft"]) {
          const ratio = contrast(rgb(token(theme, fg)), rgb(token(theme, bg)));
          expect(ratio, `${fg} on ${bg} = ${ratio.toFixed(2)}`).toBeGreaterThanOrEqual(4.5);
        }
      }
    });

    it(`${theme}: 半透明のヘッダー（面 88%）が最も暗い字の上に来ても、ナビは 4.5:1 以上`, () => {
      // ヘッダーは color-mix(--d-surface 88〜90%, transparent)。下を流れる面で最も暗いのは --d-fg
      const under = mix(rgb(token(theme, "--d-surface")), rgb(token(theme, "--d-fg")), 0.88);
      const ratio = contrast(rgb(token(theme, "--d-muted")), under);
      expect(ratio, ratio.toFixed(2)).toBeGreaterThanOrEqual(4.5);
    });

    it(`${theme}: ブランド色の上の字は 4.5:1 以上`, () => {
      const ratio = contrast(rgb(token(theme, "--d-on-brand")), rgb(token(theme, "--d-brand")));
      expect(ratio, ratio.toFixed(2)).toBeGreaterThanOrEqual(4.5);
    });
  }
});
