import type { ReactNode } from "react";

import "../styles/globals.css";
import "../styles/tokens.css";

/*
 * 本文の書体は、既定では端末の書体（iPhone・Mac はヒラギノ角ゴ、Windows はメイリオ、
 * Android は Noto Sans CJK）。並びは styles/tokens.css の --font-sans。
 * 書体ファイルを 1 つも読まないので、スマホで最初の表示が速い。
 *
 * どの端末でも Noto Sans JP に揃えたいときは、下の 3 か所のコメントを外す
 * （import と const の行頭の // と、html の className を囲むコメントの記号）。
 * ただし日本語の書体は字の範囲ごとに 100 以上の片に分かれていて、その一覧の CSS（約 100 KB）を
 * 読み終えるまで画面が描かれない。スマホの Lighthouse で LCP が 2〜4 秒遅くなる（README の「書体」）。
 */
// import { Noto_Sans_JP } from "next/font/google";
// const notoSansJp = Noto_Sans_JP({ subsets: ["latin"], display: "swap", variable: "--font-noto-sans-jp" });

export default function RootLayout({
  children,
}: Readonly<{ children: ReactNode }>) {
  return (
    // 書体の変数は html に付ける。tokens.css の :root（= html）で --font-sans がこれを読むので、
    // body に付けると :root から見えず、指定が効かない
    <html lang="ja" /* className={notoSansJp.variable} */>
      <body>{children}</body>
    </html>
  );
}
