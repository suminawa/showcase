import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "ページが見つかりません",
  robots: { index: false },
};

/**
 * 無いページを開いたときの面。書き出すと out/404.html になる。
 * 一覧ページ（app/page.tsx・index.module.css）を消しても動くよう、見た目はここに閉じている。
 * 戻り先の「/」は、公開する LP の場所に合わせて書き換える（例: "/shop/"）。
 */
export default function NotFound() {
  return (
    <main
      className="theme-index"
      style={{
        minHeight: "100vh",
        padding: "4rem 1.25rem",
        background: "var(--d-bg)",
        color: "var(--d-fg)",
        lineHeight: 1.8,
      }}
    >
      <div style={{ maxWidth: "36rem", marginInline: "auto" }}>
        <p style={{ margin: 0, color: "var(--d-muted)" }}>404</p>
        <h1 style={{ margin: "0.5rem 0 0", fontSize: "1.75rem", lineHeight: 1.4 }}>
          ページが見つかりません
        </h1>
        <p style={{ margin: "1rem 0 0" }}>
          お探しのページは、移動したか削除された可能性があります。お手数ですが、トップページからお探しください。
        </p>
        <p style={{ margin: "1.5rem 0 0" }}>
          <Link href="/" style={{ color: "var(--d-brand-ink)" }}>
            トップページへ戻る
          </Link>
        </p>
      </div>
    </main>
  );
}
