/**
 * 見出しを句読点（、。！？）の後ろで区切る。区切った片は components/Phrases.tsx が
 * 折り返さない塊（inline-block）にするので、「当日うか／がいます」のような切れ方をしない。
 * 片が 1 行に収まらないときだけ、片の中で折り返す（Chrome・Edge は文節で、他は字で）。
 * 句読点の無い見出しは 1 片のまま返す。
 * 半角の空白は改行しない空白（U+00A0）に置き換える ── 「30 分」の 30 と分の間で折らない。
 */
export function splitPhrases(text: string): string[] {
  return text
    .replace(/ /g, "\u00a0")
    .split(/(?<=[、。！？])/)
    .filter((part) => part !== "");
}
