import { describe, expect, it } from "vitest";
import { splitPhrases } from "./phrases";

describe("splitPhrases", () => {
  it("読点・句点の後ろで区切り、句読点は前の片に残す", () => {
    expect(splitPhrases("水まわりと電気のお困りごと、当日うかがいます")).toEqual([
      "水まわりと電気のお困りごと、",
      "当日うかがいます",
    ]);
    expect(splitPhrases("海を測り、記録を残す。")).toEqual(["海を測り、", "記録を残す。"]);
  });

  it("空白では区切らず、改行しない空白にする（「30 分」を割らない）", () => {
    expect(splitPhrases("税務調査の連絡が来たら、まず 30 分ご相談ください")).toEqual([
      "税務調査の連絡が来たら、",
      "まず\u00a030\u00a0分ご相談ください",
    ]);
  });

  it("句読点の無い見出しは 1 片、つなげると元に戻る", () => {
    expect(splitPhrases("粉とゆげ")).toEqual(["粉とゆげ"]);
    const title = "勤怠と工数を、ひとつに束ねる。";
    expect(splitPhrases(title).join("")).toBe(title);
    expect(splitPhrases("まず 30 分").join("").replace(/\u00a0/g, " ")).toBe("まず 30 分");
    expect(splitPhrases("")).toEqual([]);
  });
});
