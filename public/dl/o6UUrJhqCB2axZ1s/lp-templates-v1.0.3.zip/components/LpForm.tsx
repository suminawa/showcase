"use client";

import { useId, useState, type FormEvent } from "react";

import type { FormContent, FormField } from "@/content/types";
import { submitForm } from "@/lib/form-submit";

import s from "./shared.module.css";

/**
 * 入力欄の type から決まる autoComplete。
 * 電話とメールだけ、ブラウザが覚えている値を出せるようにする
 * ── 名前や住所は content の name が何を指すか決まらないので、付けない。
 */
const AUTO_COMPLETE: Partial<Record<NonNullable<FormField["type"]>, string>> = {
  tel: "tel",
  email: "email",
};

/**
 * 問い合わせ・予約のフォーム。
 * content の form.endpoint が空なら、どこにも送らない。手元で開いているときは見本の文言を、
 * 公開先では失敗の文言を出す ── 手元では置いたその日から画面が動き、公開先では
 * 設定を忘れても送れたようには見えない。送信先が決まったら 1 行書き足すだけで届くようになる。
 * 送るか送らないかの判断と文言の選び方は lib/form-submit.ts にある。
 *
 * form.honeypot に name を書くと、迷惑投稿よけの見えない欄を 1 つ足す。
 * 画面の外へ出すだけで display: none にはしない ── 消した欄を bot は読み飛ばすため。
 *
 * 入力欄の type は content が決める。"select" のときは options を並べ、
 * 先頭に placeholder の行を選べない状態で置く（選ばせる前の「未選択」を表す）。
 */
export function LpForm({ form }: { form: FormContent }) {
  const id = useId();
  const [status, setStatus] = useState("");
  const [sending, setSending] = useState(false);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (sending) return;

    // await をまたぐと event.currentTarget は null になるので、先に控える
    const element = event.currentTarget;
    const values: Record<string, string> = {};
    for (const [key, value] of new FormData(element).entries()) {
      values[key] = typeof value === "string" ? value : value.name;
    }

    setSending(true);
    setStatus(form.messages.sending);
    const result = await submitForm({
      endpoint: form.endpoint,
      contentType: form.contentType,
      values,
      messages: form.messages,
      honeypot: form.honeypot,
      hostname: window.location.hostname,
    });
    setSending(false);
    setStatus(result.message);
    if (result.ok) element.reset();
  }

  return (
    <form className={s.form} onSubmit={onSubmit}>
      {form.fields.map((field) => {
        const fieldId = `${id}-${field.name}`;
        return (
          <div key={field.name} className={s.field}>
            <label htmlFor={fieldId}>
              {field.label}
              {field.required ? <span aria-hidden="true">＊</span> : null}
            </label>
            {field.type === "textarea" ? (
              <textarea
                id={fieldId}
                name={field.name}
                placeholder={field.placeholder}
                required={field.required}
                rows={4}
              />
            ) : field.type === "select" ? (
              <select
                id={fieldId}
                name={field.name}
                required={field.required}
                defaultValue=""
              >
                <option value="" disabled>
                  {field.placeholder}
                </option>
                {(field.options ?? []).map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            ) : (
              <input
                id={fieldId}
                name={field.name}
                type={field.type ?? "text"}
                placeholder={field.placeholder}
                required={field.required}
                autoComplete={AUTO_COMPLETE[field.type ?? "text"]}
              />
            )}
          </div>
        );
      })}
      {form.honeypot ? (
        <div className={s.trap} aria-hidden="true">
          <label htmlFor={`${id}-${form.honeypot}`}>
            この欄は空のままにしてください
          </label>
          <input
            id={`${id}-${form.honeypot}`}
            name={form.honeypot}
            type="text"
            tabIndex={-1}
            autoComplete="off"
          />
        </div>
      ) : null}
      <button type="submit" className={s.submit} disabled={sending}>
        {form.submitLabel}
      </button>
      <p className={s.status} role="status" aria-live="polite">
        {status}
      </p>
    </form>
  );
}
