import { splitPhrases } from "@/lib/phrases";

/**
 * 見出しの字を、句読点の後ろでだけ折り返す形で出す（lib/phrases.ts）。
 * 片の見た目は styles/globals.css の .phrase。読み上げは元の 1 文のまま。
 */
export function Phrases({ text }: { text: string }) {
  return splitPhrases(text).map((part, i) => (
    <span key={i} className="phrase">
      {part}
    </span>
  ));
}
