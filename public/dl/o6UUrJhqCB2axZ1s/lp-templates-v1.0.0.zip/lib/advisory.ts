import type { AdvisoryLine } from "@/content/types";

/**
 * 年間の目安。「／月」の行は 12 倍、「／年」の行はそのまま足す。
 * 単発（spot）しか無いプランは顧問契約が無いので null を返す ── 0 円ではない。
 * 数字を二か所に書かないための関数（content には月額と年額しか書かない）。
 */
export function yearlyEstimate(lines: readonly AdvisoryLine[]): number | null {
  let total = 0;
  let recurring = false;
  for (const line of lines) {
    if (line.unit === "month") {
      total += line.price * 12;
      recurring = true;
    } else if (line.unit === "year") {
      total += line.price;
      recurring = true;
    }
  }
  return recurring ? total : null;
}
