const formatter = new Intl.NumberFormat("ja-JP");

/** 12345 -> "¥12,345" */
export function formatYen(amount: number): string {
  return `¥${formatter.format(amount)}`;
}

/** 380 -> "380 円"。店の品書きは通貨記号ではなく「円」で出す */
export function formatPrice(price: number): string {
  return `${formatter.format(price)} 円`;
}

/**
 * 電話番号を tel: のリンクにする。区切りの記号は落とし、数字と + だけを残す
 * （`tel:` は記号を無視する端末が多いが、揃えておくとダイヤルの取り違えが起きない）。
 */
export function telHref(tel: string): string {
  return `tel:${tel.replace(/[^0-9+]/g, "")}`;
}

/** 8800 -> "8,800 円〜"。目安の下限であることを「〜」で示す */
export function formatFrom(amount: number): string {
  return `${formatPrice(amount)}〜`;
}

/** 1240 -> "1,240"。単位を付けずに三桁で区切る（数え上げの数字） */
export function formatNumber(value: number): string {
  return formatter.format(value);
}

/** "2026-08-27" -> "2026.08.27"。<time datetime> には元の形をそのまま入れる */
export function formatNewsDate(date: string): string {
  return date.split("-").join(".");
}
