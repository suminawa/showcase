const formatter = new Intl.NumberFormat("ja-JP");

/** 12345 -> "¥12,345" */
export function formatYen(amount: number): string {
  return `¥${formatter.format(amount)}`;
}

/** 380 -> "380 円"。店の品書きは通貨記号ではなく「円」で出す */
export function formatPrice(price: number): string {
  return `${formatter.format(price)} 円`;
}
