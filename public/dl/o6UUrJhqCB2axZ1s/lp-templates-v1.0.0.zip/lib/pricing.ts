export type Cycle = "monthly" | "yearly";

/**
 * 1 人あたりの月額。年額払いは yearlyDiscount ぶん引いた月あたり換算（端数切り捨て）。
 * 割引率は content の pricing.yearlyDiscount から来る。
 */
export function priceFor(
  monthly: number,
  cycle: Cycle,
  yearlyDiscount: number,
): number {
  if (cycle === "monthly") return monthly;
  return Math.floor(monthly * (1 - yearlyDiscount));
}
