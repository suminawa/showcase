import type { Hours, Weekday } from "@/content/types";

/** 表示は月曜起点で並べる（日曜起点だと「日・木・金・土」になって読みにくい） */
const WEEK_FROM_MONDAY: readonly Weekday[] = [1, 2, 3, 4, 5, 6, 0];

const DAY_LABELS = ["日", "月", "火", "水", "木", "金", "土"] as const;

/** "10:00" -> 600。形が違えば null（content/validate.ts はこれで形を見る） */
export function parseTime(value: string): number | null {
  const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) return null;
  return hour * 60 + minute;
}

function labelFor(days: readonly Weekday[]): string {
  return days.map((day) => DAY_LABELS[day]).join("・");
}

/** 開く曜日の並び。「木・金・土・日」 */
export function openDaysLabel(hours: Hours): string {
  return labelFor(
    WEEK_FROM_MONDAY.filter((day) => !hours.closedDays.includes(day)),
  );
}

/** 「定休日：月・火・水」の形で返す。休みがなければ空文字（行ごと出さない） */
export function closedDaysLabel(hours: Hours): string {
  const days = WEEK_FROM_MONDAY.filter((day) => hours.closedDays.includes(day));
  if (days.length === 0) return "";
  return `定休日：${labelFor(days)}`;
}

/** 「木・金・土・日 10:00 - 18:00（ラストオーダー 17:30）」。lastOrder が空なら括弧を出さない */
export function scheduleLabel(hours: Hours): string {
  const base = `${openDaysLabel(hours)} ${hours.open} - ${hours.close}`;
  return hours.lastOrder
    ? `${base}（ラストオーダー ${hours.lastOrder}）`
    : base;
}

/** その時刻に開いているか。開店ちょうどは開き、閉店ちょうどは閉まっているものとして扱う */
export function isOpenAt(date: Date, hours: Hours): boolean {
  const day = date.getDay() as Weekday;
  if (hours.closedDays.includes(day)) return false;
  const open = parseTime(hours.open);
  const close = parseTime(hours.close);
  if (open === null || close === null) return false;
  const minute = date.getHours() * 60 + date.getMinutes();
  return minute >= open && minute < close;
}
