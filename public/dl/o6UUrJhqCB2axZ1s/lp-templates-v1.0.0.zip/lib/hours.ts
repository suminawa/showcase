import type { DayHours, Hours, Mark, Span, Weekday } from "@/content/types";

/** 表示は月曜起点で並べる（日曜起点だと「日・木・金・土」になって読みにくい） */
const WEEK_FROM_MONDAY: readonly Weekday[] = [1, 2, 3, 4, 5, 6, 0];

const DAY_LABELS = ["日", "月", "火", "水", "木", "金", "土"] as const;

/** "10:00" -> 600。形が違えば null（content/validate.ts はこれで形を見る） */
export function parseTime(value: string): number | null {
  const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) return null;
  return hour * 60 + minute;
}

function labelFor(days: readonly Weekday[]): string {
  return days.map((day) => DAY_LABELS[day]).join("・");
}

/** 開く曜日の並び。「木・金・土・日」 */
export function openDaysLabel(hours: Hours): string {
  return labelFor(
    WEEK_FROM_MONDAY.filter((day) => !hours.closedDays.includes(day)),
  );
}

/** 「定休日：月・火・水」の形で返す。休みがなければ空文字（行ごと出さない） */
export function closedDaysLabel(hours: Hours): string {
  const days = WEEK_FROM_MONDAY.filter((day) => hours.closedDays.includes(day));
  if (days.length === 0) return "";
  return `定休日：${labelFor(days)}`;
}

/** 「木・金・土・日 10:00 - 18:00（ラストオーダー 17:30）」。lastOrder が空なら括弧を出さない */
export function scheduleLabel(hours: Hours): string {
  const base = `${openDaysLabel(hours)} ${hours.open} - ${hours.close}`;
  return hours.lastOrder
    ? `${base}（ラストオーダー ${hours.lastOrder}）`
    : base;
}

/** その時刻に開いているか。開店ちょうどは開き、閉店ちょうどは閉まっているものとして扱う */
export function isOpenAt(date: Date, hours: Hours): boolean {
  const day = date.getDay() as Weekday;
  if (hours.closedDays.includes(day)) return false;
  const open = parseTime(hours.open);
  const close = parseTime(hours.close);
  if (open === null || close === null) return false;
  const minute = date.getHours() * 60 + date.getMinutes();
  return minute >= open && minute < close;
}

/* ---- ここから下は、午前・午後に分かれる診療時間むけ。上の 1 スパンの関数は変えていない ---- */

/** Span の両端を分に直す。形が違うときと、start が end より後ろのときは null */
export function parseSpan(span: Span): { start: number; end: number } | null {
  const start = parseTime(span.start);
  const end = parseTime(span.end);
  if (start === null || end === null || start >= end) return null;
  return { start, end };
}

/** その分がその時間帯の中か。始まりちょうどは中、終わりちょうどは外として扱う */
function inSpan(minute: number, span: Span): boolean {
  const parsed = parseSpan(span);
  if (parsed === null) return false;
  return minute >= parsed.start && minute < parsed.end;
}

/**
 * その時刻に開いているか。午前と午後のどちらかに入っていれば開いている。
 * days に無い曜日（休みの日）は閉まっているものとして扱う。
 */
export function isOpenAtSpans(
  date: Date,
  days: readonly DayHours[],
): boolean {
  const day = date.getDay() as Weekday;
  const today = days.find((entry) => entry.day === day);
  if (!today) return false;
  const minute = date.getHours() * 60 + date.getMinutes();
  return (
    (today.morning !== null && inSpan(minute, today.morning)) ||
    (today.afternoon !== null && inSpan(minute, today.afternoon))
  );
}

/** 「9:30 - 13:00」。content に書いた字をそのまま挟む（掲示の書き方に合わせる） */
export function spanLabel(span: Span): string {
  return `${span.start} - ${span.end}`;
}

/** 表の見出しに出す曜日。並びは days のまま */
export function dayLabels(days: readonly DayHours[]): string[] {
  return days.map((entry) => DAY_LABELS[entry.day]);
}

/** その日のその時間帯が、標準どおりか・短縮か・休みか */
export function markFor(span: Span | null, standard: Span): Mark {
  if (span === null) return "closed";
  return span.start === standard.start && span.end === standard.end
    ? "open"
    : "short";
}
