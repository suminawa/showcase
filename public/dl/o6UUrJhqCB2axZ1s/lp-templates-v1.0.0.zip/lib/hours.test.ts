import { describe, expect, it } from "vitest";
import type { Hours } from "@/content/types";
import {
  closedDaysLabel,
  isOpenAt,
  openDaysLabel,
  parseTime,
  scheduleLabel,
} from "./hours";

/** 見本の店と同じ時間割。月・火・水が休み */
const hours: Hours = {
  closedDays: [1, 2, 3],
  open: "10:00",
  close: "18:00",
  lastOrder: "17:30",
  openLabel: "いまは開いています",
  closedLabel: "いまは閉まっています",
};

describe("shop hours", () => {
  it("parseTime は「時:分」を一日の始まりからの分に直す", () => {
    expect(parseTime("10:00")).toBe(600);
    expect(parseTime("09:00")).toBe(540);
    expect(parseTime("9:00")).toBe(540);
    expect(parseTime("17:30")).toBe(1050);
  });

  it("parseTime は形が違えば null を返す", () => {
    expect(parseTime("")).toBeNull();
    expect(parseTime("10時")).toBeNull();
    expect(parseTime("1000")).toBeNull();
    expect(parseTime("24:00")).toBeNull();
    expect(parseTime("10:60")).toBeNull();
  });

  it("開く日の昼は開いていて、休みの日は閉まっている", () => {
    // 2026-09-10 は木曜、2026-09-13 は日曜、2026-09-07 は月曜
    expect(isOpenAt(new Date(2026, 8, 10, 11, 0), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 13, 17, 0), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 7, 11, 0), hours)).toBe(false);
    expect(isOpenAt(new Date(2026, 8, 9, 11, 0), hours)).toBe(false);
  });

  it("開店ちょうどは開き、閉店ちょうどは閉まっている", () => {
    expect(isOpenAt(new Date(2026, 8, 10, 9, 59), hours)).toBe(false);
    expect(isOpenAt(new Date(2026, 8, 10, 10, 0), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 10, 17, 59), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 10, 18, 0), hours)).toBe(false);
  });

  it("時間の形が壊れていたら閉まっているものとして扱う", () => {
    expect(isOpenAt(new Date(2026, 8, 10, 11, 0), { ...hours, open: "10時" })).toBe(
      false,
    );
  });

  it("曜日の並びは月曜から始まる", () => {
    expect(openDaysLabel(hours)).toBe("木・金・土・日");
    expect(closedDaysLabel(hours)).toBe("定休日：月・火・水");
  });

  it("休みがなければ定休日の行を出さない", () => {
    expect(closedDaysLabel({ ...hours, closedDays: [] })).toBe("");
  });

  it("営業時間の一行は、ラストオーダーがあれば括弧で添える", () => {
    expect(scheduleLabel(hours)).toBe(
      "木・金・土・日 10:00 - 18:00（ラストオーダー 17:30）",
    );
    expect(scheduleLabel({ ...hours, lastOrder: "" })).toBe(
      "木・金・土・日 10:00 - 18:00",
    );
  });
});
