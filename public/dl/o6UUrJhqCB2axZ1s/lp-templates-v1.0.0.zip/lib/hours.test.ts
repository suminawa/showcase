import { describe, expect, it } from "vitest";
import type { DayHours, Hours, Span } from "@/content/types";
import {
  closedDaysLabel,
  dayLabels,
  isOpenAt,
  isOpenAtSpans,
  markFor,
  openDaysLabel,
  parseSpan,
  parseTime,
  scheduleLabel,
  spanLabel,
} from "./hours";

/** 見本の店と同じ時間割。月・火・水が休み */
const hours: Hours = {
  closedDays: [1, 2, 3],
  open: "10:00",
  close: "18:00",
  lastOrder: "17:30",
  openLabel: "いまは開いています",
  closedLabel: "いまは閉まっています",
};

describe("shop hours", () => {
  it("parseTime は「時:分」を一日の始まりからの分に直す", () => {
    expect(parseTime("10:00")).toBe(600);
    expect(parseTime("09:00")).toBe(540);
    expect(parseTime("9:00")).toBe(540);
    expect(parseTime("17:30")).toBe(1050);
  });

  it("parseTime は形が違えば null を返す", () => {
    expect(parseTime("")).toBeNull();
    expect(parseTime("10時")).toBeNull();
    expect(parseTime("1000")).toBeNull();
    expect(parseTime("24:00")).toBeNull();
    expect(parseTime("10:60")).toBeNull();
  });

  it("開く日の昼は開いていて、休みの日は閉まっている", () => {
    // 2026-09-10 は木曜、2026-09-13 は日曜、2026-09-07 は月曜
    expect(isOpenAt(new Date(2026, 8, 10, 11, 0), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 13, 17, 0), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 7, 11, 0), hours)).toBe(false);
    expect(isOpenAt(new Date(2026, 8, 9, 11, 0), hours)).toBe(false);
  });

  it("開店ちょうどは開き、閉店ちょうどは閉まっている", () => {
    expect(isOpenAt(new Date(2026, 8, 10, 9, 59), hours)).toBe(false);
    expect(isOpenAt(new Date(2026, 8, 10, 10, 0), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 10, 17, 59), hours)).toBe(true);
    expect(isOpenAt(new Date(2026, 8, 10, 18, 0), hours)).toBe(false);
  });

  it("時間の形が壊れていたら閉まっているものとして扱う", () => {
    expect(isOpenAt(new Date(2026, 8, 10, 11, 0), { ...hours, open: "10時" })).toBe(
      false,
    );
  });

  it("曜日の並びは月曜から始まる", () => {
    expect(openDaysLabel(hours)).toBe("木・金・土・日");
    expect(closedDaysLabel(hours)).toBe("定休日：月・火・水");
  });

  it("休みがなければ定休日の行を出さない", () => {
    expect(closedDaysLabel({ ...hours, closedDays: [] })).toBe("");
  });

  it("営業時間の一行は、ラストオーダーがあれば括弧で添える", () => {
    expect(scheduleLabel(hours)).toBe(
      "木・金・土・日 10:00 - 18:00（ラストオーダー 17:30）",
    );
    expect(scheduleLabel({ ...hours, lastOrder: "" })).toBe(
      "木・金・土・日 10:00 - 18:00",
    );
  });
});

/** 見本の医院と同じ時間割。木曜の午後は休診、土曜の午後だけ短い */
const MORNING: Span = { start: "9:30", end: "13:00" };
const AFTERNOON: Span = { start: "14:30", end: "19:00" };
const SATURDAY_AFTERNOON: Span = { start: "14:00", end: "17:00" };

const days: DayHours[] = [
  { day: 1, morning: MORNING, afternoon: AFTERNOON },
  { day: 2, morning: MORNING, afternoon: AFTERNOON },
  { day: 3, morning: MORNING, afternoon: AFTERNOON },
  { day: 4, morning: MORNING, afternoon: null },
  { day: 5, morning: MORNING, afternoon: AFTERNOON },
  { day: 6, morning: MORNING, afternoon: SATURDAY_AFTERNOON },
];

describe("午前・午後の 2 スパン", () => {
  it("parseSpan は両端を分に直す", () => {
    expect(parseSpan(MORNING)).toEqual({ start: 570, end: 780 });
    expect(parseSpan(AFTERNOON)).toEqual({ start: 870, end: 1140 });
  });

  it("parseSpan は形が違うときと、前後が逆のときに null を返す", () => {
    expect(parseSpan({ start: "9時半", end: "13:00" })).toBeNull();
    expect(parseSpan({ start: "9:30", end: "" })).toBeNull();
    expect(parseSpan({ start: "13:00", end: "9:30" })).toBeNull();
    expect(parseSpan({ start: "9:30", end: "9:30" })).toBeNull();
  });

  it("spanLabel は content の字をそのまま挟む（時の 0 詰めをしない）", () => {
    expect(spanLabel(MORNING)).toBe("9:30 - 13:00");
    expect(spanLabel(SATURDAY_AFTERNOON)).toBe("14:00 - 17:00");
  });

  it("dayLabels は days の並びのまま曜日を返す", () => {
    expect(dayLabels(days)).toEqual(["月", "火", "水", "木", "金", "土"]);
  });

  it("markFor は 標準どおり・短縮・休み を見分ける", () => {
    expect(markFor(MORNING, MORNING)).toBe("open");
    expect(markFor(SATURDAY_AFTERNOON, AFTERNOON)).toBe("short");
    expect(markFor(null, AFTERNOON)).toBe("closed");
  });

  it("午前と午後は開いていて、昼休みは閉まっている", () => {
    // 2026-09-14 は月曜
    expect(isOpenAtSpans(new Date(2026, 8, 14, 10, 0), days)).toBe(true);
    expect(isOpenAtSpans(new Date(2026, 8, 14, 13, 30), days)).toBe(false);
    expect(isOpenAtSpans(new Date(2026, 8, 14, 15, 0), days)).toBe(true);
  });

  it("始まりちょうどは開き、終わりちょうどは閉まっている", () => {
    expect(isOpenAtSpans(new Date(2026, 8, 14, 9, 29), days)).toBe(false);
    expect(isOpenAtSpans(new Date(2026, 8, 14, 9, 30), days)).toBe(true);
    expect(isOpenAtSpans(new Date(2026, 8, 14, 13, 0), days)).toBe(false);
    expect(isOpenAtSpans(new Date(2026, 8, 14, 14, 30), days)).toBe(true);
    expect(isOpenAtSpans(new Date(2026, 8, 14, 19, 0), days)).toBe(false);
  });

  it("片方だけ休みの日と、days に無い曜日", () => {
    // 2026-09-17 は木曜、2026-09-19 は土曜、2026-09-13 は日曜
    expect(isOpenAtSpans(new Date(2026, 8, 17, 10, 0), days)).toBe(true);
    expect(isOpenAtSpans(new Date(2026, 8, 17, 15, 0), days)).toBe(false);
    expect(isOpenAtSpans(new Date(2026, 8, 19, 14, 0), days)).toBe(true);
    expect(isOpenAtSpans(new Date(2026, 8, 19, 16, 59), days)).toBe(true);
    expect(isOpenAtSpans(new Date(2026, 8, 19, 17, 0), days)).toBe(false);
    expect(isOpenAtSpans(new Date(2026, 8, 13, 10, 0), days)).toBe(false);
  });

  it("時間の形が壊れていたら閉まっているものとして扱う", () => {
    const broken: DayHours[] = [
      { day: 1, morning: { start: "9時半", end: "13:00" }, afternoon: null },
    ];
    expect(isOpenAtSpans(new Date(2026, 8, 14, 10, 0), broken)).toBe(false);
  });
});
