/** 末尾のスラッシュを落とす。根（"/"）だけはスラッシュ 1 本に揃える */
function normalize(path: string): string {
  const trimmed = path.replace(/\/+$/, "");
  return trimmed === "" ? "/" : trimmed;
}

/**
 * 2 つのパスが同じ面を指すか。末尾のスラッシュの有無は見ない
 * ── next.config.ts は trailingSlash: true だが、usePathname が返す形は
 * 開き方（静的な HTML / 開発サーバー）で揺れるため。
 */
export function samePath(a: string, b: string): boolean {
  return normalize(a) === normalize(b);
}
