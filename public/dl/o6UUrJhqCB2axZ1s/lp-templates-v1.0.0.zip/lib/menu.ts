import type { MenuItem } from "@/content/types";

/** 組ごとの品。並びは content の items のまま（組の中で並べ替えはしない） */
export function itemsByCategory(
  items: readonly MenuItem[],
  category: string,
): MenuItem[] {
  return items.filter((item) => item.category === category);
}
