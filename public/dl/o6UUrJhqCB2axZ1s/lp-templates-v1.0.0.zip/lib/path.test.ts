import { describe, expect, it } from "vitest";
import { samePath } from "./path";

describe("samePath", () => {
  it("末尾のスラッシュがあってもなくても同じ面とみなす", () => {
    expect(samePath("/corporate/", "/corporate/")).toBe(true);
    expect(samePath("/corporate", "/corporate/")).toBe(true);
    expect(samePath("/corporate/services/", "/corporate/services")).toBe(true);
  });

  it("違う面は同じとみなさない", () => {
    expect(samePath("/corporate/", "/corporate/services/")).toBe(false);
    expect(samePath("/corporate/company/", "/corporate/contact/")).toBe(false);
  });

  it("根はスラッシュ 1 本に揃える", () => {
    expect(samePath("/", "")).toBe(true);
    expect(samePath("/", "/corporate/")).toBe(false);
  });
});
