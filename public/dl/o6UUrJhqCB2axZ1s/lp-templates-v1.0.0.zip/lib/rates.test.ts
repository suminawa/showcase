import { describe, expect, it } from "vitest";
import { rateFor } from "./rates";

/** 見本と同じ 3 行ぶんの形だけを借りる（文言は content にある） */
const trip = { weekday: 2200, surcharged: true };
const base = { weekday: 5500, surcharged: true };
const estimate = { weekday: 0, surcharged: false };

describe("construction rates", () => {
  it("平日はそのままの金額", () => {
    expect(rateFor(trip, "weekday", 1.5)).toBe(2200);
    expect(rateFor(base, "weekday", 1.5)).toBe(5500);
  });

  it("夜間・休日は割増を掛けて丸める", () => {
    expect(rateFor(trip, "night", 1.5)).toBe(3300);
    expect(rateFor(base, "night", 1.5)).toBe(8250);
    expect(rateFor({ weekday: 3300, surcharged: true }, "night", 1.25)).toBe(4125);
    expect(rateFor({ weekday: 1111, surcharged: true }, "night", 1.5)).toBe(1667);
  });

  it("割増を掛けない行は、夜間・休日でも変わらない", () => {
    expect(rateFor(estimate, "weekday", 1.5)).toBe(0);
    expect(rateFor(estimate, "night", 1.5)).toBe(0);
    expect(rateFor({ weekday: 2200, surcharged: false }, "night", 1.5)).toBe(2200);
  });

  it("割増が 1 なら、どちらの時間帯も同じ金額", () => {
    expect(rateFor(base, "night", 1)).toBe(5500);
  });
});
