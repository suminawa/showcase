import { describe, expect, it } from "vitest";
import { areaPoint } from "./areas";

describe("construction areas", () => {
  it("角度 0 は真上、90 は右、180 は真下、270 は左", () => {
    expect(areaPoint({ radius: 1, angle: 0 }, 100, 80)).toEqual({ x: 100, y: 20 });
    expect(areaPoint({ radius: 1, angle: 90 }, 100, 80)).toEqual({ x: 180, y: 100 });
    expect(areaPoint({ radius: 1, angle: 180 }, 100, 80)).toEqual({ x: 100, y: 180 });
    expect(areaPoint({ radius: 1, angle: 270 }, 100, 80)).toEqual({ x: 20, y: 100 });
  });

  it("斜めの点は小数第 2 位まで丸める", () => {
    expect(areaPoint({ radius: 1, angle: 45 }, 100, 80)).toEqual({
      x: 156.57,
      y: 43.43,
    });
  });

  it("中心に近いほど点も中心に寄る", () => {
    expect(areaPoint({ radius: 0.5, angle: 90 }, 100, 80)).toEqual({
      x: 140,
      y: 100,
    });
    expect(areaPoint({ radius: 0, angle: 123 }, 100, 80)).toEqual({
      x: 100,
      y: 100,
    });
  });

  it("半径 1 までの点は、外周の円の中に収まる", () => {
    for (const angle of [0, 37, 95, 200, 250, 340]) {
      const point = areaPoint({ radius: 0.9, angle }, 100, 90);
      expect(Math.hypot(point.x - 100, point.y - 100)).toBeLessThanOrEqual(81.01);
    }
  });
});
