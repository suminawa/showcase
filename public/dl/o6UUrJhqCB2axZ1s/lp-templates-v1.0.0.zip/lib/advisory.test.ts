import { describe, expect, it } from "vitest";
import type { AdvisoryLine } from "@/content/types";
import { yearlyEstimate } from "./advisory";

const sole: AdvisoryLine[] = [
  { label: "月額顧問料", price: 15000, unit: "month" },
  { label: "決算・確定申告", price: 80000, unit: "year" },
];

const spot: AdvisoryLine[] = [
  { label: "税務調査の立ち会い（1 日）", price: 80000, unit: "spot" },
  { label: "決算・申告だけ", price: 120000, unit: "spot" },
];

describe("advisory", () => {
  it("年間の目安は 月額 ×12 と 年 1 回の料金の合計", () => {
    expect(yearlyEstimate(sole)).toBe(260000);
    expect(
      yearlyEstimate([
        { label: "月額顧問料", price: 30000, unit: "month" },
        { label: "決算・申告", price: 150000, unit: "year" },
      ]),
    ).toBe(510000);
  });

  it("単発だけのプランに年間の目安は出さない（0 円ではなく null）", () => {
    expect(yearlyEstimate(spot)).toBeNull();
    expect(yearlyEstimate([])).toBeNull();
  });

  it("単発の行は合計に入れない", () => {
    expect(
      yearlyEstimate([
        { label: "月額顧問料", price: 10000, unit: "month" },
        { label: "研修", price: 60000, unit: "spot" },
      ]),
    ).toBe(120000);
  });
});
