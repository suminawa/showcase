import type { FormContent, FormContentType } from "@/content/types";

/**
 * 送信に使う関数の形。既定はブラウザの fetch。
 * テストではここを差し替えて、呼ばれた回数と中身を見る。
 * json は省いてよい ── 本文を返さない送信先や、テストの差し替えではそのまま成功として扱う。
 */
export type FetchLike = (
  url: string,
  init: { method: string; headers: Record<string, string>; body: string },
) => Promise<{ ok: boolean; json?: () => Promise<unknown> }>;

export type SubmitOutcome = {
  /** 送れた、または送らずに見本を出したとき true */
  ok: boolean;
  /** 実際に送信先へ送ったか。endpoint が空なら false */
  sent: boolean;
  /** 画面に出す一行 */
  message: string;
};

const CONTENT_TYPES: Record<FormContentType, string> = {
  json: "application/json",
  text: "text/plain;charset=utf-8",
};

/** 送るときに付ける見出し。json のときだけ Accept も添える（Formspree がこれで JSON を返す） */
function headersFor(contentType: FormContentType): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": CONTENT_TYPES[contentType],
  };
  if (contentType === "json") headers.Accept = "application/json";
  return headers;
}

/**
 * 受け側が返す本文が、失敗を伝えているか。
 * ok が明に false のときだけ失敗として扱う ── それ以外（本文がそもそも
 * オブジェクトでない、ok を持たない、ok: true）は今までどおり成功とみなす。
 */
function isFailureAnswer(
  answer: unknown,
): answer is { ok: false; message?: unknown } {
  return (
    typeof answer === "object" &&
    answer !== null &&
    "ok" in answer &&
    (answer as { ok: unknown }).ok === false
  );
}

/**
 * フォームの送信。
 * endpoint が空なら一切通信せず、見本の文言を返す（置いたその日から画面は動く）。
 * 送信先があれば、入力欄の name を鍵にした JSON を POST する。
 *
 * honeypot には、見えない欄の name を渡す。そこに字が入っていたら bot なので、
 * 何も送らずに成功の文言だけ返す ── 画面の見た目が変わらないので、bot は弾かれたと気づかない。
 * 見えない欄そのものは、送る JSON からも外す。
 *
 * 受け側（対になる受信キット）は、はねるときも HTTP は 200 のまま
 * `{ ok: false, reason, message }` を返す ── フォーム側が待たされたままにならないため。
 * なので 200 台でも本文を読み、ok: false なら失敗として扱う。本文が JSON で
 * なければ（Formspree や、素の受信先はここを通る）今までどおり成功とみなす。
 */
export async function submitForm(args: {
  endpoint: string;
  contentType: FormContentType;
  values: Record<string, string>;
  messages: FormContent["messages"];
  /** 見えない欄の name。content の form.honeypot をそのまま渡す */
  honeypot?: string;
  fetchImpl?: FetchLike;
}): Promise<SubmitOutcome> {
  const endpoint = args.endpoint.trim();
  if (endpoint === "") {
    return { ok: true, sent: false, message: args.messages.sample };
  }

  const trap = args.honeypot?.trim() ?? "";
  const values = { ...args.values };
  if (trap !== "") {
    const filled = (values[trap] ?? "").trim() !== "";
    delete values[trap];
    if (filled) {
      return { ok: true, sent: false, message: args.messages.success };
    }
  }

  // fetch は window に束ねられているので、そのまま渡さず包んで呼ぶ
  const send: FetchLike = args.fetchImpl ?? ((url, init) => fetch(url, init));

  try {
    const response = await send(endpoint, {
      method: "POST",
      headers: headersFor(args.contentType),
      body: JSON.stringify(values),
    });
    if (!response.ok) {
      return { ok: false, sent: true, message: args.messages.failure };
    }
    try {
      const answer = await response.json?.();
      if (isFailureAnswer(answer)) {
        const message =
          typeof answer.message === "string" && answer.message !== ""
            ? answer.message
            : args.messages.failure;
        return { ok: false, sent: true, message };
      }
    } catch {
      // 本文が JSON として読めない ── 受信キットではなく、Formspree や
      // 素の送信先とみなして、今までどおり成功として扱う
    }
    return { ok: true, sent: true, message: args.messages.success };
  } catch {
    return { ok: false, sent: true, message: args.messages.failure };
  }
}
