import type { RateRow } from "@/content/types";

/** 平日（昼）と、夜間・休日の二本立て */
export type RatePlan = "weekday" | "night";

/**
 * その行の、その時間帯の金額。
 * 夜間・休日は nightRate 倍にして丸める（content の price.nightRate。1.5 なら 5 割増）。
 * 見積もりのように割増を掛けない行は、content 側で surcharged: false にしておく。
 */
export function rateFor(
  row: Pick<RateRow, "weekday" | "surcharged">,
  plan: RatePlan,
  nightRate: number,
): number {
  if (plan === "weekday" || !row.surcharged) return row.weekday;
  return Math.round(row.weekday * nightRate);
}
