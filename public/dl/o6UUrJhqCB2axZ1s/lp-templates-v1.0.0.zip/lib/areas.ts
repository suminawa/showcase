import type { Area } from "@/content/types";

/** SVG の座標に載せるので、桁を小数第 2 位で切る（パスの文字数を抑える） */
function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

/**
 * 中心が center、外周までの長さが scale の座標系に、area を置いたときの点。
 * 角度は真上を 0 度とした時計回り（0 が上、90 が右）、半径は中心からの割合。
 */
export function areaPoint(
  area: Pick<Area, "radius" | "angle">,
  center: number,
  scale: number,
): { x: number; y: number } {
  const rad = (area.angle * Math.PI) / 180;
  return {
    x: round2(center + scale * area.radius * Math.sin(rad)),
    y: round2(center - scale * area.radius * Math.cos(rad)),
  };
}
