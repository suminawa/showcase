import { describe, expect, it } from "vitest";
import { priceFor } from "./pricing";

describe("pricing", () => {
  it("月額はそのまま、年額払いは 20% 引きの月あたり換算", () => {
    expect(priceFor(500, "monthly", 0.2)).toBe(500);
    expect(priceFor(500, "yearly", 0.2)).toBe(400);
    expect(priceFor(900, "yearly", 0.2)).toBe(720);
    expect(priceFor(1500, "yearly", 0.2)).toBe(1200);
  });

  it("端数は切り捨て", () => {
    expect(priceFor(999, "yearly", 0.2)).toBe(799);
  });

  it("割引率を変えると年額の換算も変わる", () => {
    expect(priceFor(1000, "yearly", 0.15)).toBe(850);
    expect(priceFor(1000, "yearly", 0)).toBe(1000);
  });
});
