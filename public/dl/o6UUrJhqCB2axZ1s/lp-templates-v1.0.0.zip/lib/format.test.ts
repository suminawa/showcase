import { describe, expect, it } from "vitest";
import { formatPrice, formatYen } from "./format";

describe("format", () => {
  it("formatYen は通貨記号を前に付けて三桁で区切る", () => {
    expect(formatYen(500)).toBe("¥500");
    expect(formatYen(12345)).toBe("¥12,345");
  });

  it("formatPrice は三桁区切りに「円」を付ける", () => {
    expect(formatPrice(380)).toBe("380 円");
    expect(formatPrice(1200)).toBe("1,200 円");
  });
});
