import { describe, expect, it } from "vitest";
import { formatFrom, formatNewsDate, formatNumber, formatPrice, formatYen, telHref } from "./format";

describe("format", () => {
  it("formatYen は通貨記号を前に付けて三桁で区切る", () => {
    expect(formatYen(500)).toBe("¥500");
    expect(formatYen(12345)).toBe("¥12,345");
  });

  it("formatPrice は三桁区切りに「円」を付ける", () => {
    expect(formatPrice(380)).toBe("380 円");
    expect(formatPrice(1200)).toBe("1,200 円");
  });

  it("telHref は数字と + だけを残す", () => {
    expect(telHref("000-0000-0000")).toBe("tel:00000000000");
    expect(telHref("03-0000-0000")).toBe("tel:0300000000");
    expect(telHref("+81 90-0000-0000")).toBe("tel:+819000000000");
    expect(telHref("")).toBe("tel:");
  });

  it("formatFrom は下限を「〜」で示す", () => {
    expect(formatFrom(8800)).toBe("8,800 円〜");
    expect(formatFrom(88000)).toBe("88,000 円〜");
  });

  it("formatNumber は単位なしの三桁区切り", () => {
    expect(formatNumber(0)).toBe("0");
    expect(formatNumber(38)).toBe("38");
    expect(formatNumber(1240)).toBe("1,240");
  });

  it("formatNewsDate は点区切りにする", () => {
    expect(formatNewsDate("2026-08-27")).toBe("2026.08.27");
    expect(formatNewsDate("2026-01-09")).toBe("2026.01.09");
  });
});
