import { describe, expect, it } from "vitest";
import type { MenuItem } from "@/content/types";
import { itemsByCategory } from "./menu";

const items: MenuItem[] = [
  { id: "scone", name: "バターのスコーン", price: 380, category: "bake", note: "" },
  { id: "coffee", name: "本日のコーヒー", price: 520, category: "drink", note: "" },
  { id: "cookie", name: "塩のクッキー（三枚）", price: 360, category: "bake", note: "" },
];

describe("menu", () => {
  it("組で絞り込み、並びは items のまま", () => {
    expect(itemsByCategory(items, "bake").map((item) => item.id)).toEqual([
      "scone",
      "cookie",
    ]);
  });

  it("品のない組は空の配列", () => {
    expect(itemsByCategory(items, "wine")).toEqual([]);
  });
});
