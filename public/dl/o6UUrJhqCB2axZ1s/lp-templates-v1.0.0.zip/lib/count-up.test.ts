import { describe, expect, it } from "vitest";
import { COUNT_UP_DURATION, countUpValue, easeOutCubic } from "./count-up";

describe("count up", () => {
  it("easeOutCubic は 0 から 1 へ、外れた t は端で止める", () => {
    expect(easeOutCubic(0)).toBe(0);
    expect(easeOutCubic(0.5)).toBe(0.875);
    expect(easeOutCubic(1)).toBe(1);
    expect(easeOutCubic(-1)).toBe(0);
    expect(easeOutCubic(2)).toBe(1);
  });

  it("countUpValue は 0 から最終値まで、終わりに近づくほど遅くなる", () => {
    expect(countUpValue(1240, 0, 1200)).toBe(0);
    expect(countUpValue(1240, 600, 1200)).toBe(1085);
    expect(countUpValue(1240, 1200, 1200)).toBe(1240);
    expect(countUpValue(24, 300, 1200)).toBe(14);
  });

  it("時間を過ぎても最終値を超えない", () => {
    expect(countUpValue(1240, 2400, 1200)).toBe(1240);
  });

  it("duration が 0 以下なら最初から最終値", () => {
    expect(countUpValue(1240, 0, 0)).toBe(1240);
    expect(countUpValue(1240, 600, -1)).toBe(1240);
  });

  it("数え上げは 1 秒台で終わる", () => {
    expect(COUNT_UP_DURATION).toBeGreaterThan(0);
    expect(COUNT_UP_DURATION).toBeLessThanOrEqual(2000);
  });
});
