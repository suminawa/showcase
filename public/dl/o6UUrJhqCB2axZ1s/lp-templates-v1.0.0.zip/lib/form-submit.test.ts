import { describe, expect, it } from "vitest";
import { submitForm, type FetchLike } from "./form-submit";

const messages = {
  sample: "送信されました（見本）",
  sending: "送信しています…",
  success: "送信しました",
  failure: "送信できませんでした",
};

type Call = { url: string; init: { method: string; headers: Record<string, string>; body: string } };

/** 呼ばれた回数と中身を覚える差し替え用の fetch */
function spy(result: { ok: boolean } | Error): { calls: Call[]; fetchImpl: FetchLike } {
  const calls: Call[] = [];
  const fetchImpl: FetchLike = async (url, init) => {
    calls.push({ url, init });
    if (result instanceof Error) throw result;
    return result;
  };
  return { calls, fetchImpl };
}

describe("submitForm", () => {
  it("endpoint が空なら送らず、見本の文言を返す", async () => {
    const { calls, fetchImpl } = spy({ ok: true });
    const result = await submitForm({
      endpoint: "",
      contentType: "json",
      values: { email: "you@example.com" },
      messages,
      fetchImpl,
    });
    expect(calls).toHaveLength(0);
    expect(result).toEqual({ ok: true, sent: false, message: "送信されました（見本）" });
  });

  it("空白だけの endpoint も空として扱う", async () => {
    const { calls, fetchImpl } = spy({ ok: true });
    const result = await submitForm({
      endpoint: "   ",
      contentType: "json",
      values: {},
      messages,
      fetchImpl,
    });
    expect(calls).toHaveLength(0);
    expect(result.sent).toBe(false);
  });

  it("endpoint があれば JSON を POST して、成功の文言を返す", async () => {
    const { calls, fetchImpl } = spy({ ok: true });
    const result = await submitForm({
      endpoint: "https://example.com/form",
      contentType: "json",
      values: { company: "〇〇", email: "you@example.com" },
      messages,
      fetchImpl,
    });
    expect(calls).toHaveLength(1);
    expect(calls[0].url).toBe("https://example.com/form");
    expect(calls[0].init.method).toBe("POST");
    expect(calls[0].init.headers["Content-Type"]).toBe("application/json");
    expect(calls[0].init.headers.Accept).toBe("application/json");
    expect(JSON.parse(calls[0].init.body)).toEqual({
      company: "〇〇",
      email: "you@example.com",
    });
    expect(result).toEqual({ ok: true, sent: true, message: "送信しました" });
  });

  it("contentType が text なら text/plain で送る（Apps Script 向け。中身は同じ JSON）", async () => {
    const { calls, fetchImpl } = spy({ ok: true });
    await submitForm({
      endpoint: "https://script.google.com/macros/s/xxx/exec",
      contentType: "text",
      values: { name: "〇〇" },
      messages,
      fetchImpl,
    });
    expect(calls[0].init.headers["Content-Type"]).toBe("text/plain;charset=utf-8");
    expect(calls[0].init.headers.Accept).toBeUndefined();
    expect(JSON.parse(calls[0].init.body)).toEqual({ name: "〇〇" });
  });

  it("返事が 200 台でなければ失敗の文言を返す", async () => {
    const { fetchImpl } = spy({ ok: false });
    const result = await submitForm({
      endpoint: "https://example.com/form",
      contentType: "json",
      values: {},
      messages,
      fetchImpl,
    });
    expect(result).toEqual({ ok: false, sent: true, message: "送信できませんでした" });
  });

  it("見えない欄が埋まっていたら送らず、成功の文言だけ返す", async () => {
    const { calls, fetchImpl } = spy({ ok: true });
    const result = await submitForm({
      endpoint: "https://example.com/form",
      contentType: "json",
      values: { email: "you@example.com", homepage: "https://spam.example" },
      messages,
      honeypot: "homepage",
      fetchImpl,
    });
    expect(calls).toHaveLength(0);
    expect(result).toEqual({ ok: true, sent: false, message: "送信しました" });
  });

  it("見えない欄が空なら、いつもどおり送る。欄そのものは JSON に入れない", async () => {
    const { calls, fetchImpl } = spy({ ok: true });
    const result = await submitForm({
      endpoint: "https://example.com/form",
      contentType: "json",
      values: { email: "you@example.com", homepage: "" },
      messages,
      honeypot: "homepage",
      fetchImpl,
    });
    expect(calls).toHaveLength(1);
    expect(JSON.parse(calls[0].init.body)).toEqual({ email: "you@example.com" });
    expect(result).toEqual({ ok: true, sent: true, message: "送信しました" });
  });

  it("通信そのものが失敗しても投げずに、失敗の文言を返す", async () => {
    const { fetchImpl } = spy(new Error("network down"));
    const result = await submitForm({
      endpoint: "https://example.com/form",
      contentType: "json",
      values: {},
      messages,
      fetchImpl,
    });
    expect(result).toEqual({ ok: false, sent: true, message: "送信できませんでした" });
  });
});
