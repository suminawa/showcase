import type { ProfessionalContent } from "./types";

/**
 * 士業・研修の LP の全文。
 * 初期値は架空の会計事務所「霜月会計事務所」。公開する前に自分のものへ差し替える。
 * 色と見出しの明朝は styles/tokens.css の .theme-professional にある。
 */
export const professional: ProfessionalContent = {
  brand: "霜月会計事務所",
  meta: {
    title: "霜月会計事務所 ｜ 税務調査の立ち会いと、記帳・決算",
    description:
      "税務調査の連絡が来たら、まず 30 分ご相談ください。初回は無料、オンラインで全国から承ります。記帳・決算・経理研修まで。",
  },
  nav: [
    { label: "こまりごと", href: "#issues" },
    { label: "サービス", href: "#services" },
    { label: "料金", href: "#pricing" },
    { label: "よくある質問", href: "#faq" },
  ],
  navLabel: "ページ内",
  headerCta: { label: "無料で相談する", href: "#contact" },
  hero: {
    eyebrow: "税務調査の立ち会いと、記帳・決算",
    title: "税務調査の連絡が来たら、まず 30 分ご相談ください",
    lead: "何を聞かれるのか、何を用意すればいいのか。初回の 30 分は無料です。オンラインで全国からご相談いただけます。",
    primary: { label: "無料で 30 分相談する", href: "#contact" },
    secondary: { label: "サービスを見る", href: "#services" },
    fine: "初回の相談は無料です。オンラインのみで承ります。",
  },
  issues: {
    id: "issues",
    heading: "こんなときに、ご相談ください",
    items: [
      {
        title: "税務署から連絡が来た",
        body: "「調査に伺います」の電話のあと、何を用意すればいいのか分からない。",
      },
      {
        title: "記帳が追いつかない",
        body: "領収書が箱のまま残り、決算の前に一年分をまとめて片づけている。",
      },
      {
        title: "経理を任せられる人がいない",
        body: "担当が辞めたあと、社長が夜に数字を入力している。",
      },
    ],
  },
  services: {
    id: "services",
    heading: "三つのサービス",
    items: [
      {
        title: "税務調査の立ち会い",
        body: "事前の打ち合わせから当日の立ち会い、調査後の対応まで承ります。聞かれそうなことと答え方は、事前に一緒に整理します。",
        icon: "audit",
      },
      {
        title: "記帳と決算",
        body: "月ごとの記帳から決算・申告までお引き受けします。領収書や請求書のやり取りはオンラインで完結します。",
        icon: "books",
      },
      {
        title: "経理研修",
        body: "経理のご担当者に向けて、半日の研修を行います。仕訳の考え方と、月次を締めるまでの手順をお伝えします。",
        icon: "training",
      },
    ],
  },
  pricing: {
    id: "pricing",
    heading: "顧問料の目安",
    switchLabel: "料金のプラン",
    unitLabels: { month: "／月", year: "／年", spot: "／回" },
    yearlyLabel: "年間の目安",
    spotNote: "顧問契約はありません。必要なときだけお受けします。",
    plans: [
      {
        id: "sole",
        name: "個人事業",
        audience: "売上 1,000 万円までの個人事業の方へ",
        lines: [
          { label: "月額顧問料", price: 15000, unit: "month" },
          { label: "決算・確定申告", price: 80000, unit: "year" },
        ],
        includes: [
          "月 1 回のオンライン面談",
          "記帳の確認と月次のご報告",
          "確定申告書の作成",
          "税務調査の立ち会いは別料金",
        ],
        note: "記帳の代行が必要な場合は、月額 5,000 円を別途申し受けます。",
      },
      {
        id: "corp",
        name: "法人",
        audience: "従業員 20 人までの法人へ",
        lines: [
          { label: "月額顧問料", price: 30000, unit: "month" },
          { label: "決算・申告", price: 150000, unit: "year" },
        ],
        includes: [
          "月 1 回のオンライン面談",
          "記帳の確認と月次のご報告",
          "決算書と申告書の作成",
          "年末調整と法定調書",
          "税務調査の立ち会い（年 1 回まで）",
        ],
        note: "消費税の申告が必要な場合も、料金は変わりません。",
      },
      {
        id: "spot",
        name: "スポット",
        audience: "顧問契約はせず、必要なときだけご利用いただく方へ",
        lines: [
          { label: "税務調査の立ち会い（1 日）", price: 80000, unit: "spot" },
          { label: "決算・申告のみ", price: 120000, unit: "spot" },
          { label: "経理研修（半日）", price: 60000, unit: "spot" },
        ],
        includes: [
          "事前の打ち合わせ（1 時間）",
          "お約束の日までの作業",
          "終了後のご質問への回答（1 回まで）",
        ],
        note: "顧問契約への切り替えは、いつでも承ります。",
      },
    ],
    note: "価格は税込みです。記帳の代行や過去の分の申告が必要な場合は、範囲をうかがったうえで別途お見積もりします。",
  },
  flow: {
    id: "flow",
    heading: "ご相談から着手まで",
    steps: [
      {
        title: "フォームからご連絡ください",
        body: "当日か翌営業日にご返信します。",
      },
      {
        title: "30 分の無料相談",
        body: "オンラインで状況をうかがい、何が必要かをお伝えします。",
      },
      { title: "お見積もりとご契約", body: "料金と範囲を書面でお示しします。" },
      { title: "着手", body: "税務調査なら、事前の打ち合わせから始めます。" },
    ],
  },
  cases: {
    id: "cases",
    heading: "これまでの例",
    labels: { industry: "業種", issue: "ご相談", result: "結果" },
    items: [
      {
        industry: "飲食（個人事業）",
        issue: "税務署から調査の連絡",
        result: "3 年分の帳簿を先に整理し、申告の修正なく終わりました。",
      },
      {
        industry: "建設（法人・従業員 8 人）",
        issue: "記帳が 10 か月分たまっていた",
        result: "2 か月で最新の月に追いつき、いまは毎月締められています。",
      },
      {
        industry: "小売（法人・2 店舗）",
        issue: "経理の担当者が辞めた",
        result:
          "半日の研修を 2 回行い、引き継いだ方が一人で月次を締められるようになりました。",
      },
    ],
    note: "結果は状況によって変わります。同じ結果をお約束するものではありません。",
  },
  faq: {
    id: "faq",
    heading: "よくある質問",
    items: [
      {
        q: "初回の相談は本当に無料ですか。",
        a: "30 分までは無料です。それを超える場合は、先に料金をお伝えします。",
      },
      {
        q: "顧問契約をしていなくても、税務調査の立ち会いを頼めますか。",
        a: "顧問契約がなくてもお受けします。スポットの料金でご依頼いただけます。過去の申告書を拝見してから、お見積もりします。",
      },
      {
        q: "遠方でも依頼できますか。",
        a: "はい、承ります。面談も書類のやり取りも、オンラインで完結します。",
      },
      {
        q: "記帳は自分でやりたいのですが、見てもらえますか。",
        a: "拝見します。会計ソフトの画面を共有していただき、仕訳の付け方を確認します。",
      },
      {
        q: "研修は何人まで受けられますか。",
        a: "1 回あたり 10 人までです。人数が多い場合は、2 回に分けて行います。",
      },
    ],
  },
  contact: {
    id: "contact",
    heading: "30 分の無料相談",
    lead: "お名前、メールアドレス、電話番号、ご相談の内容、ご希望の日時をご記入ください。当日か翌営業日にご返信します。",
  },
  form: {
    fields: [
      { name: "name", label: "お名前", required: true },
      {
        name: "email",
        label: "メールアドレス",
        type: "email",
        required: true,
        placeholder: "you@example.com",
      },
      {
        name: "tel",
        label: "電話番号",
        type: "tel",
        required: true,
        placeholder: "日中つながる番号",
      },
      {
        name: "message",
        label: "ご相談の内容",
        type: "textarea",
        required: true,
        placeholder: "例: 税務署から調査の連絡がありました",
      },
      {
        name: "when",
        label: "ご希望の日時",
        placeholder: "例: 平日の午前中、来週の水曜",
      },
    ],
    submitLabel: "無料相談を申し込む",
    endpoint: "",
    contentType: "json",
    honeypot: "homepage",
    messages: {
      sample:
        "送信されました（見本の表示です。送信先を設定するまで、実際には送られません）。",
      sending: "送信しています…",
      success: "お申し込みを受け付けました。当日か翌営業日にご返信します。",
      failure: "送信できませんでした。時間をおいて、もう一度お試しください。",
    },
  },
  footer: {
    company: "霜月会計事務所",
    entity: "事務所",
    address: "〒000-0000 ○○県○○市○○ 1-2-3",
    email: "hello@example.com",
    tel: "000-0000-0000",
    copyright: "© 2026 霜月会計事務所",
  },
};
