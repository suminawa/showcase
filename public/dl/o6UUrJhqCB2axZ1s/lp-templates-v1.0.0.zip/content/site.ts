import type { SiteContent } from "./types";

/**
 * サイト全体の設定と、一覧ページ（/）の中身。
 * url は共有カードの絶対 URL に使うので、公開する前に自分の URL に直す。
 */
export const site: SiteContent = {
  url: "https://example.com",
  name: "業種別 LP テンプレ",
  home: {
    meta: {
      title: "業種別 LP テンプレ",
      description:
        "BtoB・SaaS と店舗・サロン、2 本の 1 ページ LP テンプレート。写真を 1 枚も使わずに公開できます。",
    },
    heading: "業種別 LP テンプレ",
    lead: "素材を用意しなくても出せる 1 ページ LP が 2 本。文言は content の 1 ファイルで、色は styles/tokens.css で書き換えられます。",
    templates: [
      {
        href: "/saas/",
        name: "BtoB・SaaS の LP",
        industry: "SaaS・受託・BtoB サービス",
        description:
          "架空の勤怠・工数 SaaS「Tabane Works」の 1 ページ。料金の切替、FAQ、問い合わせフォームまで動きます。",
        sections: [
          "課題",
          "機能",
          "料金（月額／年額の切替）",
          "導入の流れ",
          "FAQ",
          "問い合わせフォーム",
        ],
      },
      {
        href: "/shop/",
        name: "店舗・サロンの LP",
        industry: "飲食・美容・教室・サロン",
        description:
          "架空の焼き菓子とコーヒーの店「粉とゆげ」の 1 ページ。品書きと席の案内、予約フォームまで動きます。",
        sections: [
          "こだわり",
          "お品書き",
          "席と過ごし方",
          "行き方",
          "予約フォーム",
          "営業時間の「いまは開いています」",
        ],
      },
    ],
    note: "このページ（app/page.tsx）は 2 本を見比べるための一覧です。公開するときは消すか、自分のトップページに書き換えてください。",
  },
};
