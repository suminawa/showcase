import { describe, expect, it } from "vitest";
import type { SpanHours } from "./types";
import { clinic } from "./clinic";
import { construction } from "./construction";
import { corporate } from "./corporate";
import { professional } from "./professional";
import { saas } from "./saas";
import { shop } from "./shop";
import { site } from "./site";
import {
  validateClinic,
  validateConstruction,
  validateCorporate,
  validateProfessional,
  validateSaas,
  validateShop,
  validateSite,
  validateSpanHours,
} from "./validate";

describe("content の検証", () => {
  it("同梱の content はそのままで問題なし", () => {
    expect(validateSite(site)).toEqual([]);
    expect(validateSaas(saas)).toEqual([]);
    expect(validateShop(shop)).toEqual([]);
    expect(validateConstruction(construction)).toEqual([]);
    expect(validateProfessional(professional)).toEqual([]);
    expect(validateClinic(clinic)).toEqual([]);
    expect(validateCorporate(corporate)).toEqual([]);
  });

  it("空の文言を指摘する", () => {
    const broken = { ...saas, hero: { ...saas.hero, title: "" } };
    expect(validateSaas(broken)).toContain("hero.title が空です");
  });

  it("節の見出しとボタンの字の抜けを指摘する", () => {
    const broken = {
      ...saas,
      pricing: { ...saas.pricing, heading: "", unit: "" },
      headerCta: { ...saas.headerCta, label: "" },
      contact: { ...saas.contact, lead: "" },
    };
    const issues = validateSaas(broken);
    expect(issues).toContain("pricing.heading が空です");
    expect(issues).toContain("pricing.unit が空です");
    expect(issues).toContain("headerCta.label が空です");
    expect(issues).toContain("contact.lead が空です");
  });

  it("店舗側の見出しと項目の抜けを指摘する", () => {
    const broken = {
      ...shop,
      menu: { ...shop.menu, note: "" },
      seats: { ...shop.seats, heading: "", items: [{ term: "", body: "十二席です。" }] },
    };
    const issues = validateShop(broken);
    expect(issues).toContain("menu.note が空です");
    expect(issues).toContain("seats.heading が空です");
    expect(issues).toContain("seats.items[0] の term が空です");
  });

  it("送信先の URL の打ち間違いを指摘する", () => {
    const broken = {
      ...saas,
      form: { ...saas.form, endpoint: "htps://example.com/form" },
    };
    expect(validateSaas(broken)).toContain(
      "form.endpoint は https:// から書きます（送らないときは空にします）",
    );
  });

  it("送信先が空、または https:// から始まっていれば通す", () => {
    expect(validateSaas({ ...saas, form: { ...saas.form, endpoint: "" } })).toEqual([]);
    expect(
      validateSaas({
        ...saas,
        form: { ...saas.form, endpoint: "https://formspree.io/f/xxxxxxx" },
      }),
    ).toEqual([]);
  });

  it("一覧ページのテンプレ紹介の抜けを指摘する", () => {
    const broken = {
      ...site,
      home: {
        ...site.home,
        templates: [{ ...site.home.templates[0], industry: "", sections: [] }],
      },
    };
    const issues = validateSite(broken);
    expect(issues).toContain(
      `home.templates「${site.home.templates[0].name}」の industry が空です`,
    );
    expect(issues).toContain(
      `home.templates「${site.home.templates[0].name}」の sections が空です`,
    );
  });

  it("飛び先のない節リンクを指摘する", () => {
    const broken = { ...saas, nav: [{ label: "料金", href: "#price" }] };
    expect(validateSaas(broken)).toContain(
      "リンク「料金」の飛び先 #price に合う節がありません",
    );
  });

  it("料金の id の重なりと、範囲の外の割引率を指摘する", () => {
    const broken = {
      ...saas,
      pricing: {
        ...saas.pricing,
        yearlyDiscount: 1.5,
        plans: [saas.pricing.plans[0], saas.pricing.plans[0]],
      },
    };
    const issues = validateSaas(broken);
    expect(issues).toContain("pricing.plans の id「starter」が重なっています");
    expect(issues).toContain("pricing.yearlyDiscount は 0 以上 1 未満にします");
  });

  it("メールアドレスの形を見る", () => {
    const broken = { ...saas, footer: { ...saas.footer, email: "hello.example.com" } };
    expect(validateSaas(broken)).toContain(
      "footer.email がメールアドレスの形ではありません",
    );
  });

  it("営業時間の形が違えば指摘する", () => {
    const broken = { ...shop, hours: { ...shop.hours, open: "10時" } };
    expect(validateShop(broken)).toContain('hours.open は "10:00" の形で書きます');
  });

  it("開店より前の閉店を指摘する", () => {
    const broken = { ...shop, hours: { ...shop.hours, open: "18:00", close: "10:00" } };
    expect(validateShop(broken)).toContain("hours.open は hours.close より前にします");
  });

  it("営業時間の外のラストオーダーを指摘する", () => {
    const broken = { ...shop, hours: { ...shop.hours, lastOrder: "19:00" } };
    expect(validateShop(broken)).toContain("hours.lastOrder は営業時間の中にします");
  });

  it("品のない組を指摘する", () => {
    const broken = {
      ...shop,
      menu: {
        ...shop.menu,
        groups: [...shop.menu.groups, { category: "wine", label: "お酒" }],
      },
    };
    expect(validateShop(broken)).toContain("menu.groups「お酒」に品がありません");
  });

  it("組のない品を指摘する", () => {
    const broken = {
      ...shop,
      menu: {
        ...shop.menu,
        items: [{ ...shop.menu.items[0], category: "wine" }],
      },
    };
    expect(validateShop(broken)).toContain(
      "menu.items「バターのスコーン」の category「wine」に合う組が menu.groups にありません",
    );
  });

  it("公開 URL の形を見る", () => {
    expect(validateSite({ ...site, url: "example.com" })).toContain(
      "url は https:// から書きます",
    );
    expect(validateSite({ ...site, url: "https://example.com/" })).toContain(
      "url の末尾のスラッシュは外します",
    );
  });

  it("午前・午後の診療時間の形を見る", () => {
    const hours: SpanHours = {
      days: [
        {
          day: 1,
          morning: { start: "9:30", end: "13:00" },
          afternoon: { start: "14:30", end: "19:00" },
        },
      ],
      openLabel: "いまは診療中です",
      closedLabel: "いまは診療時間外です",
    };
    expect(validateSpanHours(hours)).toEqual([]);

    expect(validateSpanHours({ ...hours, days: [] })).toContain(
      "hours.days が空です。開く曜日がありません",
    );
    expect(
      validateSpanHours({
        ...hours,
        days: [{ day: 1, morning: null, afternoon: null }],
      }),
    ).toContain(
      "hours.days[0] は午前も午後も空です。休みの曜日は days に入れません",
    );
    expect(
      validateSpanHours({
        ...hours,
        days: [
          { ...hours.days[0], morning: { start: "13:00", end: "9:30" } },
        ],
      }),
    ).toContain(
      'hours.days[0].morning は { start: "9:30", end: "13:00" } の形で、start を end より前にします',
    );
    expect(
      validateSpanHours({
        ...hours,
        days: [hours.days[0], hours.days[0]],
      }),
    ).toContain("hours.days に同じ曜日が二度出ています（月）");
    expect(validateSpanHours({ ...hours, openLabel: "" })).toContain(
      "hours.openLabel が空です",
    );
  });

  it("建設・工事の料金とエリアの数字を見る", () => {
    const brokenPrice = {
      ...construction,
      price: {
        ...construction.price,
        nightRate: 0.8,
        rows: [{ ...construction.price.rows[0], weekday: -100 }],
      },
    };
    const priceIssues = validateConstruction(brokenPrice);
    expect(priceIssues).toContain(
      "price.nightRate は 1 以上にします（1.5 で 5 割増）",
    );
    expect(priceIssues).toContain(
      "price.rows「出張費（片道 15 km まで）」の weekday は 0 以上の整数にします",
    );

    const brokenArea = {
      ...construction,
      areas: {
        ...construction.areas,
        items: [{ id: "far", label: "遠いところ", radius: 1.4, angle: 400 }],
      },
    };
    const areaIssues = validateConstruction(brokenArea);
    expect(areaIssues).toContain(
      "areas.items「遠いところ」の radius は 0 より大きく 1 以下にします",
    );
    expect(areaIssues).toContain(
      "areas.items「遠いところ」の angle は 0 以上 360 未満にします",
    );
  });

  it("電話番号の形と、番号が空のときを見る", () => {
    const broken = {
      ...construction,
      call: { ...construction.call, phone: "電話してね" },
    };
    expect(validateConstruction(broken)).toContain(
      "call.phone は数字と + と - だけで書きます（電話ボタンを出さないときは空にします）",
    );

    // 番号が空なら電話ボタンを出さないので、ボタンの字が空でも指摘しない
    const noPhone = {
      ...construction,
      call: { phone: "", headerLabel: "", heroLabel: "", heroSub: "" },
    };
    expect(validateConstruction(noPhone)).toEqual([]);
  });

  it("メニューの目安料金と id の重なりを見る", () => {
    const broken = {
      ...construction,
      services: {
        ...construction.services,
        items: [
          { ...construction.services.items[0], from: 0 },
          construction.services.items[0],
        ],
      },
    };
    const issues = validateConstruction(broken);
    expect(issues).toContain("services.items「水漏れの修理」の from は 1 以上にします");
    expect(issues).toContain("services.items の id「leak」が重なっています");
  });

  it("顧問料の金額と、プランの中身を見る", () => {
    const broken = {
      ...professional,
      pricing: {
        ...professional.pricing,
        plans: [
          {
            ...professional.pricing.plans[0],
            lines: [{ label: "月額顧問料", price: 0, unit: "month" as const }],
            includes: [],
          },
          professional.pricing.plans[0],
        ],
      },
    };
    const issues = validateProfessional(broken);
    expect(issues).toContain(
      "pricing.plans「個人事業」の lines「月額顧問料」の price は 1 以上にします",
    );
    expect(issues).toContain("pricing.plans「個人事業」の includes が空です");
    expect(issues).toContain("pricing.plans の id「sole」が重なっています");
  });

  it("金額の行が 1 つも無いプランを指摘する", () => {
    const broken = {
      ...professional,
      pricing: {
        ...professional.pricing,
        plans: [{ ...professional.pricing.plans[0], lines: [] }],
      },
    };
    expect(validateProfessional(broken)).toContain(
      "pricing.plans「個人事業」の lines が空です",
    );
  });

  it("単位の字の抜けを指摘する", () => {
    const broken = {
      ...professional,
      pricing: {
        ...professional.pricing,
        unitLabels: { month: "", year: "／年", spot: "／回" },
      },
    };
    expect(validateProfessional(broken)).toContain(
      "pricing.unitLabels.month が空です",
    );
  });

  it("診療時間の表と、印の抜けを指摘する", () => {
    const broken = {
      ...clinic,
      schedule: {
        ...clinic.schedule,
        morning: {
          ...clinic.schedule.morning,
          span: { start: "13:00", end: "9:30" },
        },
        marks: {
          ...clinic.schedule.marks,
          short: { symbol: "", label: "短縮" },
        },
        legend: [],
      },
    };
    const issues = validateClinic(broken);
    expect(issues).toContain(
      'schedule.morning.span は { start: "9:30", end: "13:00" } の形で、start を end より前にします',
    );
    expect(issues).toContain("schedule.marks.short.symbol が空です");
    expect(issues).toContain("schedule.legend が空です");
  });

  it("診療する曜日が無ければ指摘する", () => {
    const broken = { ...clinic, hours: { ...clinic.hours, days: [] } };
    expect(validateClinic(broken)).toContain(
      "hours.days が空です。開く曜日がありません",
    );
  });

  it("選ぶ欄の選択肢と、選ぶ前の字の抜けを指摘する", () => {
    const broken = {
      ...clinic,
      form: {
        ...clinic.form,
        fields: [
          { name: "slot", label: "時間帯", type: "select" as const, required: true },
        ],
      },
    };
    const issues = validateClinic(broken);
    expect(issues).toContain(
      'form.fields「slot」は type: "select" なので options を 1 つ以上書きます',
    );
    expect(issues).toContain(
      'form.fields「slot」は type: "select" なので placeholder（選ぶ前に出す字）を書きます',
    );
  });

  it("会社案内の行き先の書き方を見る", () => {
    const broken = {
      ...corporate,
      nav: [{ label: "ホーム", href: "corporate" }],
    };
    expect(validateCorporate(broken)).toContain(
      'nav「ホーム」の href は "/corporate/" のように前後をスラッシュで囲みます',
    );
  });

  it("4 枚の面に無い行き先を指摘する", () => {
    const broken = {
      ...corporate,
      nav: [...corporate.nav, { label: "採用情報", href: "/corporate/recruit/" }],
    };
    expect(validateCorporate(broken)).toContain(
      "nav「採用情報」の href「/corporate/recruit/」に合う面がありません。面を足したときは content/validate.ts の CORPORATE_PAGES にも足します",
    );
    // 同梱の 4 本はどれも指摘されない
    expect(validateCorporate(corporate)).toEqual([]);
  });

  it("数字とお知らせが 1 つも無ければ指摘する", () => {
    const broken = {
      ...corporate,
      home: {
        ...corporate.home,
        stats: { ...corporate.home.stats, items: [] },
        news: { ...corporate.home.news, items: [] },
      },
    };
    const issues = validateCorporate(broken);
    expect(issues).toContain("stats.items が空です");
    expect(issues).toContain("news.items が空です");
  });

  it("上の帯の読み上げ用の名前の抜けを指摘する", () => {
    expect(validateSaas({ ...saas, navLabel: "" })).toContain("navLabel が空です");
    expect(validateConstruction({ ...construction, navLabel: "" })).toContain(
      "navLabel が空です",
    );
    expect(validateProfessional({ ...professional, navLabel: "" })).toContain(
      "navLabel が空です",
    );
    expect(validateClinic({ ...clinic, navLabel: "" })).toContain(
      "navLabel が空です",
    );
    expect(validateCorporate({ ...corporate, navLabel: "" })).toContain(
      "navLabel が空です",
    );
  });

  it("お知らせの日付の形と並びを見る", () => {
    const brokenDate = {
      ...corporate,
      home: {
        ...corporate.home,
        news: {
          ...corporate.home.news,
          items: [{ ...corporate.home.news.items[0], date: "2026/08/27" }],
        },
      },
    };
    expect(validateCorporate(brokenDate)).toContain(
      'news.items「夏季の観測機器の点検について」の date は "2026-08-27" の形で書きます',
    );

    const brokenOrder = {
      ...corporate,
      home: {
        ...corporate.home,
        news: {
          ...corporate.home.news,
          items: [
            corporate.home.news.items[2],
            corporate.home.news.items[0],
          ],
        },
      },
    };
    expect(validateCorporate(brokenOrder)).toContain(
      "news.items は新しい順に並べます",
    );
  });

  it("数字と三つの柱の抜けを指摘する", () => {
    const broken = {
      ...corporate,
      home: {
        ...corporate.home,
        stats: {
          ...corporate.home.stats,
          items: [{ id: "surveys", label: "", value: 0, unit: "件" }],
        },
      },
      pillars: [{ ...corporate.pillars[0], steps: [], gear: [] }],
    };
    const issues = validateCorporate(broken);
    expect(issues).toContain("stats.items[0] の label が空です");
    expect(issues).toContain("stats.items「surveys」の value は 1 以上の整数にします");
    expect(issues).toContain("pillars「海域調査」の steps が空です");
    expect(issues).toContain("pillars「海域調査」の gear が空です");
  });

  it("一覧は 6 件で、行き先はページと同じ", () => {
    expect(site.home.templates.map((template) => template.href)).toEqual([
      "/saas/",
      "/shop/",
      "/construction/",
      "/professional/",
      "/clinic/",
      "/corporate/",
    ]);
  });
});
