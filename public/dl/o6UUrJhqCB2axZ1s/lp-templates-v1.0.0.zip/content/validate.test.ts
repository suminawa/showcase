import { describe, expect, it } from "vitest";
import { saas } from "./saas";
import { shop } from "./shop";
import { site } from "./site";
import { validateSaas, validateShop, validateSite } from "./validate";

describe("content の検証", () => {
  it("同梱の content はそのままで問題なし", () => {
    expect(validateSite(site)).toEqual([]);
    expect(validateSaas(saas)).toEqual([]);
    expect(validateShop(shop)).toEqual([]);
  });

  it("空の文言を指摘する", () => {
    const broken = { ...saas, hero: { ...saas.hero, title: "" } };
    expect(validateSaas(broken)).toContain("hero.title が空です");
  });

  it("節の見出しとボタンの字の抜けを指摘する", () => {
    const broken = {
      ...saas,
      pricing: { ...saas.pricing, heading: "", unit: "" },
      headerCta: { ...saas.headerCta, label: "" },
      contact: { ...saas.contact, lead: "" },
    };
    const issues = validateSaas(broken);
    expect(issues).toContain("pricing.heading が空です");
    expect(issues).toContain("pricing.unit が空です");
    expect(issues).toContain("headerCta.label が空です");
    expect(issues).toContain("contact.lead が空です");
  });

  it("店舗側の見出しと項目の抜けを指摘する", () => {
    const broken = {
      ...shop,
      menu: { ...shop.menu, note: "" },
      seats: { ...shop.seats, heading: "", items: [{ term: "", body: "十二席です。" }] },
    };
    const issues = validateShop(broken);
    expect(issues).toContain("menu.note が空です");
    expect(issues).toContain("seats.heading が空です");
    expect(issues).toContain("seats.items[0] の term が空です");
  });

  it("送信先の URL の打ち間違いを指摘する", () => {
    const broken = {
      ...saas,
      form: { ...saas.form, endpoint: "htps://example.com/form" },
    };
    expect(validateSaas(broken)).toContain(
      "form.endpoint は https:// から書きます（送らないときは空にします）",
    );
  });

  it("送信先が空、または https:// から始まっていれば通す", () => {
    expect(validateSaas({ ...saas, form: { ...saas.form, endpoint: "" } })).toEqual([]);
    expect(
      validateSaas({
        ...saas,
        form: { ...saas.form, endpoint: "https://formspree.io/f/xxxxxxx" },
      }),
    ).toEqual([]);
  });

  it("一覧ページのテンプレ紹介の抜けを指摘する", () => {
    const broken = {
      ...site,
      home: {
        ...site.home,
        templates: [{ ...site.home.templates[0], industry: "", sections: [] }],
      },
    };
    const issues = validateSite(broken);
    expect(issues).toContain(
      `home.templates「${site.home.templates[0].name}」の industry が空です`,
    );
    expect(issues).toContain(
      `home.templates「${site.home.templates[0].name}」の sections が空です`,
    );
  });

  it("飛び先のない節リンクを指摘する", () => {
    const broken = { ...saas, nav: [{ label: "料金", href: "#price" }] };
    expect(validateSaas(broken)).toContain(
      "リンク「料金」の飛び先 #price に合う節がありません",
    );
  });

  it("料金の id の重なりと、範囲の外の割引率を指摘する", () => {
    const broken = {
      ...saas,
      pricing: {
        ...saas.pricing,
        yearlyDiscount: 1.5,
        plans: [saas.pricing.plans[0], saas.pricing.plans[0]],
      },
    };
    const issues = validateSaas(broken);
    expect(issues).toContain("pricing.plans の id「starter」が重なっています");
    expect(issues).toContain("pricing.yearlyDiscount は 0 以上 1 未満にします");
  });

  it("メールアドレスの形を見る", () => {
    const broken = { ...saas, footer: { ...saas.footer, email: "hello.example.com" } };
    expect(validateSaas(broken)).toContain(
      "footer.email がメールアドレスの形ではありません",
    );
  });

  it("営業時間の形が違えば指摘する", () => {
    const broken = { ...shop, hours: { ...shop.hours, open: "10時" } };
    expect(validateShop(broken)).toContain('hours.open は "10:00" の形で書きます');
  });

  it("開店より前の閉店を指摘する", () => {
    const broken = { ...shop, hours: { ...shop.hours, open: "18:00", close: "10:00" } };
    expect(validateShop(broken)).toContain("hours.open は hours.close より前にします");
  });

  it("営業時間の外のラストオーダーを指摘する", () => {
    const broken = { ...shop, hours: { ...shop.hours, lastOrder: "19:00" } };
    expect(validateShop(broken)).toContain("hours.lastOrder は営業時間の中にします");
  });

  it("品のない組を指摘する", () => {
    const broken = {
      ...shop,
      menu: {
        ...shop.menu,
        groups: [...shop.menu.groups, { category: "wine", label: "お酒" }],
      },
    };
    expect(validateShop(broken)).toContain("menu.groups「お酒」に品がありません");
  });

  it("組のない品を指摘する", () => {
    const broken = {
      ...shop,
      menu: {
        ...shop.menu,
        items: [{ ...shop.menu.items[0], category: "wine" }],
      },
    };
    expect(validateShop(broken)).toContain(
      "menu.items「バターのスコーン」の category「wine」に合う組が menu.groups にありません",
    );
  });

  it("公開 URL の形を見る", () => {
    expect(validateSite({ ...site, url: "example.com" })).toContain(
      "url は https:// から書きます",
    );
    expect(validateSite({ ...site, url: "https://example.com/" })).toContain(
      "url の末尾のスラッシュは外します",
    );
  });
});
