import type { ShopContent } from "./types";

/**
 * 店舗・サロンの LP の全文。
 * 初期値は架空の焼き菓子とコーヒーの店「粉とゆげ」。公開する前に自分のものへ差し替える。
 * 色は styles/tokens.css の .theme-shop にある。
 */
export const shop: ShopContent = {
  brand: "粉とゆげ",
  meta: {
    title: "粉とゆげ ｜ 焼き菓子と、淹れたてのコーヒー",
    description:
      "朝に窯から出した焼き菓子と、注文を受けてから挽くコーヒー。売り切れたらその日は終わりです。",
  },
  hero: {
    eyebrow: "焼き菓子と、淹れたてのコーヒー",
    tagline: "今日焼いた分だけ、並べています。",
    lead: "朝に窯から出した焼き菓子と、注文を受けてから挽くコーヒー。売り切れたらその日は終わりです。",
    primary: { label: "席を予約する", href: "#reserve" },
    secondary: { label: "お品書きを見る", href: "#menu" },
    fieldCount: 140,
  },
  hours: {
    closedDays: [1, 2, 3],
    open: "10:00",
    close: "18:00",
    lastOrder: "17:30",
    openLabel: "いまは開いています",
    closedLabel: "いまは閉まっています",
  },
  points: {
    id: "about",
    heading: "三つのこと",
    items: [
      {
        title: "朝に焼いて、その日に出す",
        body: "前の日のものは棚に残しません。並ぶのは今日の分だけです。",
      },
      {
        title: "豆は二週間で使い切る",
        body: "焙煎から二週間を過ぎた豆は挽きません。注文を受けてから挽いています。",
      },
      {
        title: "材料は、名前が分かるものだけ",
        body: "粉、バター、砂糖、卵、塩。紙の裏に書ける数で作ります。",
      },
    ],
  },
  menu: {
    id: "menu",
    heading: "お品書き",
    groups: [
      { category: "bake", label: "焼き菓子" },
      { category: "drink", label: "飲みもの" },
    ],
    items: [
      {
        id: "scone",
        name: "バターのスコーン",
        price: 380,
        category: "bake",
        note: "外は硬め、中はほろりと崩れます。",
      },
      {
        id: "weekend",
        name: "レモンのウィークエンド",
        price: 420,
        category: "bake",
        note: "皮ごと煮たレモンを生地に混ぜ、表に砂糖の膜をかけます。",
      },
      {
        id: "cookie",
        name: "塩のクッキー（三枚）",
        price: 360,
        category: "bake",
        note: "甘さは控えめです。コーヒーのあとに一枚ずつ。",
      },
      {
        id: "coffee",
        name: "本日のコーヒー",
        price: 520,
        category: "drink",
        note: "豆は週ごとに変わります。産地は黒板に書いています。",
      },
      {
        id: "milk-brew",
        name: "ミルクブリュー",
        price: 580,
        category: "drink",
        note: "一晩かけて牛乳で出したコーヒーです。氷を入れずに冷やして出します。",
      },
      {
        id: "hojicha",
        name: "ほうじ茶",
        price: 480,
        category: "drink",
        note: "挽いた茶葉を、その場で急須に入れます。",
      },
    ],
    note: "価格は税込みです。品切れの日もあります。",
  },
  seats: {
    id: "seats",
    heading: "席と、過ごし方",
    items: [
      { term: "席", body: "席は十二。カウンターが六つ、二人がけのテーブルが三つです。" },
      { term: "音", body: "小さな音で音楽をかけています。通話はご遠慮ください。" },
      { term: "時間", body: "混んでいる日は、一時間を目安にお願いします。" },
    ],
  },
  access: {
    id: "access",
    heading: "行き方",
    steps: [
      "駅の西口から歩いて八分です。",
      "川沿いの道を上流へ。二つめの橋は渡らず、手前で左に曲がります。",
      "角に大きな銀杏の木があり、その裏の一階です。看板は出していません。緑色の扉が目印です。",
      "自転車は建物の脇に停められます。駐車場はありません。",
    ],
  },
  reserve: {
    id: "reserve",
    heading: "席の予約",
    lead: "二名から承ります。焼き菓子の取り置きも一緒にどうぞ。日付と人数、お名前とメールアドレスを入れてください。",
  },
  form: {
    fields: [
      { name: "date", label: "日付", type: "date", required: true },
      { name: "guests", label: "人数", type: "number", required: true, placeholder: "2" },
      { name: "name", label: "お名前", required: true },
      {
        name: "email",
        label: "メールアドレス",
        type: "email",
        required: true,
        placeholder: "you@example.com",
      },
      {
        name: "hold",
        label: "取り置き（任意）",
        type: "textarea",
        placeholder: "例: バターのスコーン 2、ほうじ茶 1",
      },
    ],
    submitLabel: "予約を送る",
    endpoint: "",
    contentType: "json",
    honeypot: "homepage",
    messages: {
      sample:
        "送信されました（見本の表示です。送信先を設定するまで、実際には送られません）。",
      sending: "送信しています…",
      success: "予約の希望を送りました。折り返しご連絡します。",
      failure: "送信できませんでした。時間をおいて、もう一度お試しください。",
    },
  },
  footer: {
    company: "粉とゆげ",
    entity: "店",
    address: "〒000-0000 ○○県○○市○○ 4-5-6",
    email: "hello@example.com",
    tel: "000-0000-0000",
    copyright: "© 2026 粉とゆげ",
  },
};
