import type { SaasContent } from "./types";

/**
 * BtoB・SaaS の LP の全文。
 * 初期値は架空の勤怠・工数 SaaS「Tabane Works」。公開する前に自分のものへ差し替える。
 * 色は styles/tokens.css の .theme-saas にある。
 */
export const saas: SaasContent = {
  brand: "Tabane Works",
  meta: {
    title: "Tabane Works ｜ 勤怠と工数を、ひとつに束ねる",
    description:
      "打刻も工数の入力も、同じ画面で 10 秒。集計は毎晩自動で終わり、月末に慌てなくなります。",
  },
  nav: [
    { label: "課題", href: "#issues" },
    { label: "機能", href: "#features" },
    { label: "料金", href: "#pricing" },
    { label: "FAQ", href: "#faq" },
  ],
  headerCta: { label: "無料で試す", href: "#contact" },
  hero: {
    eyebrow: "勤怠・工数管理 SaaS",
    title: "勤怠と工数を、ひとつに束ねる。",
    lead: "打刻も工数の入力も、同じ画面で 10 秒。集計は毎晩自動で終わり、月末に慌てなくなります。",
    primary: { label: "14 日間無料で試す", href: "#contact" },
    secondary: { label: "資料を見る", href: "#features" },
    fine: "クレジットカード不要。最短 1 日で導入できます。",
    fieldCount: 48,
  },
  issues: {
    id: "issues",
    heading: "月末の「あの作業」をなくす",
    items: [
      {
        title: "打刻と工数が別のツールにある",
        body: "二重入力になり、締めのたびに突き合わせが要ります。",
      },
      {
        title: "集計が手作業",
        body: "スプレッドシートに貼り直す作業が、毎月 3 時間かかっています。",
      },
      {
        title: "誰が何にどれだけ使ったか、見えない",
        body: "案件ごとの原価が分かるのは翌月です。",
      },
    ],
  },
  features: {
    id: "features",
    heading: "三つの機能で、締めが軽くなる",
    items: [
      {
        title: "一画面で打刻と工数",
        body: "出勤ボタンの横に今日の案件が並び、入力は 10 秒で終わります。",
        icon: "screen",
      },
      {
        title: "毎晩の自動集計",
        body: "日次で案件別・人別の集計が閉じるので、月末にまとめて直す作業がありません。",
        icon: "clock",
      },
      {
        title: "会計・給与ソフトへの書き出し",
        body: "CSV と API で、使っているソフトにそのまま渡せます。",
        icon: "export",
      },
    ],
  },
  pricing: {
    id: "pricing",
    heading: "人数に応じた、シンプルな料金",
    yearlyDiscount: 0.2,
    toggleLabel: "支払いの周期",
    monthlyLabel: "月額払い",
    yearlyLabel: "年額払い（20% 引き）",
    unit: "／人／月",
    recommendedBadge: "おすすめ",
    monthlyNote: "年額払いは 20% 引きです。",
    yearlyNote: "年額払いの月あたり換算です。",
    plans: [
      {
        id: "starter",
        name: "スターター",
        monthly: 500,
        audience: "10 人までの会社向け",
        features: ["打刻と工数入力", "日次の自動集計", "CSV 書き出し"],
      },
      {
        id: "standard",
        name: "スタンダード",
        monthly: 900,
        audience: "11 人から 100 人の会社向け",
        features: ["スターターの全部", "案件別の原価", "承認フロー", "API 連携"],
        recommended: true,
      },
      {
        id: "business",
        name: "ビジネス",
        monthly: 1500,
        audience: "100 人以上の会社向け",
        features: ["スタンダードの全部", "SSO", "監査ログ", "専任サポート"],
      },
    ],
  },
  flow: {
    id: "flow",
    heading: "導入は三つの段階で、最短 1 日",
    steps: [
      { title: "社員と案件を CSV で取り込む", time: "30 分" },
      { title: "打刻と工数の入力ルールを決める", time: "1 時間" },
      { title: "翌朝から集計が届く", time: "" },
    ],
  },
  faq: {
    id: "faq",
    heading: "よくある質問",
    items: [
      {
        q: "既存の勤怠ツールから移れますか。",
        a: "主要な勤怠ツールの CSV 形式に対応しています。過去 12 か月分まで取り込めます。",
      },
      {
        q: "スマホで打刻できますか。",
        a: "できます。ブラウザから使えるので、アプリの配布は要りません。",
      },
      {
        q: "承認は必要ですか。",
        a: "スタンダード以上で承認フローを使えます。承認なしの運用もできます。",
      },
      {
        q: "データはどこに保存されますか。",
        a: "国内のデータセンターに保存し、毎日バックアップします。",
      },
      {
        q: "途中でプランを変えられますか。",
        a: "月の途中でも変えられます。差額は日割りで計算します。",
      },
    ],
  },
  contact: {
    id: "contact",
    heading: "まずは 14 日間、無料で",
    lead: "会社名、メールアドレス、相談したいことを入れて送ってください。営業日の翌日までに返事をします。",
  },
  form: {
    fields: [
      { name: "company", label: "会社名", required: true, placeholder: "例: 株式会社〇〇" },
      {
        name: "email",
        label: "メールアドレス",
        type: "email",
        required: true,
        placeholder: "you@example.com",
      },
      {
        name: "message",
        label: "相談したいこと",
        type: "textarea",
        placeholder: "人数や、いま使っているツールなど",
      },
    ],
    submitLabel: "無料で試す",
    endpoint: "",
    contentType: "json",
    honeypot: "homepage",
    messages: {
      sample:
        "送信されました（見本の表示です。送信先を設定するまで、実際には送られません）。",
      sending: "送信しています…",
      success: "送信しました。営業日の翌日までに返事をします。",
      failure: "送信できませんでした。時間をおいて、もう一度お試しください。",
    },
  },
  footer: {
    company: "Tabane Works",
    address: "〒000-0000 ○○県○○市○○町 1-2-3 ○○ビル 5F",
    email: "hello@example.com",
    tel: "",
    copyright: "© 2026 Tabane Works",
  },
};
