import type { CorporateContent } from "./types";

/**
 * 会社案内サイト 4 ページの全文。
 * 初期値は架空の海洋・環境調査の計測会社「潮見計測」。公開する前に自分のものへ差し替える。
 * 色は styles/tokens.css の .theme-corporate にある。
 *
 * nav の href は 4 枚の面の実際の場所。面を足したら、この配列と app/corporate/ の
 * フォルダの両方を直す。
 */
export const corporate: CorporateContent = {
  brand: "潮見計測",
  navLabel: "サイト内",
  nav: [
    { label: "ホーム", href: "/corporate/" },
    { label: "事業内容", href: "/corporate/services/" },
    { label: "会社概要", href: "/corporate/company/" },
    { label: "お問い合わせ", href: "/corporate/contact/" },
  ],
  pillars: [
    {
      id: "survey",
      name: "海域調査",
      summary:
        "船を出し、水深と流れ、底の質を測ります。工事の前後を比べる調査でもご利用いただいています。",
      body: "船を出し、水深と流れ、底の質を測ります。護岸工事の前後を比べる調査や、漁場の状態を調べる調査でご依頼をいただいています。",
      steps: ["調査計画のご提案", "現地での計測", "図と表の作成"],
      gear: [
        "音響測深機（浅い海域用と深い海域用）",
        "流向流速計",
        "採泥器",
        "水質計",
        "衛星測位の装置",
      ],
      icon: "survey",
    },
    {
      id: "monitoring",
      name: "環境モニタリング",
      summary: "ご指定の地点に機器を設置し、水質と水温を一年を通して記録します。",
      body: "ご指定の地点に機器を設置し、水質と水温を一年を通して記録します。数値があらかじめ決めた範囲を外れたときは、その日のうちにご連絡します。",
      steps: [
        "地点の選定",
        "機器の設置",
        "定期点検とデータの回収",
        "月ごとのご報告",
      ],
      gear: [
        "観測ブイ（太陽電池式）",
        "自動採水器",
        "水位計",
        "データロガー",
        "通信ユニット",
      ],
      icon: "monitoring",
    },
    {
      id: "analysis",
      name: "データ解析",
      summary:
        "集めた記録をまとめ、図と報告書にします。解析だけのご依頼もお受けします。",
      body: "集めた記録をまとめ、図と報告書にします。他社が測ったデータの解析だけでもお引き受けします。",
      steps: [
        "データのお預かり",
        "欠測と異常値の確認",
        "図と統計の作成",
        "報告書へのとりまとめ",
      ],
      gear: [
        "解析用のワークステーション",
        "大容量のストレージ",
        "地理情報システム",
        "作図と製図の道具",
      ],
      icon: "analysis",
    },
  ],
  home: {
    meta: {
      title: "潮見計測 ｜ 海を測り、記録を残す",
      description:
        "水深も、流れも、水の質も。船を出して測り、設置した機器で記録を続け、図と報告書にしてお渡しします。海洋・環境調査の計測会社です。",
    },
    hero: {
      eyebrow: "海洋・環境調査の計測",
      title: "海を測り、記録を残す。",
      lead: "水深も、流れも、水の質も。船を出して測り、設置した機器で記録を続け、図と報告書にしてお渡しします。",
      primary: { label: "事業内容を見る", href: "/corporate/services/" },
      secondary: { label: "お問い合わせ", href: "/corporate/contact/" },
    },
    pillars: { heading: "三つの柱" },
    stats: {
      heading: "これまでに測ったもの",
      items: [
        { id: "surveys", label: "これまでの調査", value: 1240, unit: "件" },
        { id: "years", label: "計測を続けた年数", value: 24, unit: "年" },
        { id: "devices", label: "海に設置した観測機器", value: 96, unit: "台" },
        { id: "data", label: "解析したデータ", value: 38, unit: "TB" },
      ],
    },
    news: {
      heading: "お知らせ",
      items: [
        {
          id: "inspection",
          date: "2026-08-27",
          tag: "お知らせ",
          title: "夏季の観測機器の点検について",
        },
        {
          id: "coastal-survey",
          date: "2026-07-15",
          tag: "実績",
          title: "沿岸部の底質調査を 3 件受託しました",
        },
        {
          id: "report-format",
          date: "2026-06-02",
          tag: "お知らせ",
          title: "解析レポートの様式を改めました",
        },
      ],
    },
    cta: {
      title: "調査のご相談は、まず内容をお聞かせください",
      body: "測る範囲や期間が決まっていない段階でも、ご相談いただけます。現場の条件をうかがったうえで、進め方をご提案します。",
      link: { label: "お問い合わせへ", href: "/corporate/contact/" },
    },
  },
  services: {
    meta: {
      title: "事業内容 ｜ 潮見計測",
      description:
        "海域調査・環境モニタリング・データ解析。海で測り、機器を置いて記録し、読み解くまでを自社で行います。",
    },
    title: "海を測り、記録し、読み解く",
    lead: "三つの事業はつながっています。海で測り、機器を置いて記録し、そのデータを読み解く。現場で数字の癖をつかんでいますので、解析でも異常値を見分けられます。",
    flowTitle: "進め方",
    gearTitle: "使う機材",
  },
  company: {
    meta: {
      title: "会社概要 ｜ 潮見計測",
      description:
        "潮見計測の概要と沿革、仕事の方針。海の計測を 2002 年から続けています。",
    },
    title: "会社概要",
    lead: "海の計測を、2002 年から続けています。",
    profile: {
      heading: "概要",
      rows: [
        { term: "社名", body: "潮見計測" },
        { term: "設立", body: "2002 年 4 月" },
        { term: "資本金", body: "4,800 万円" },
        { term: "従業員数", body: "38 名（うち技術職 27 名）" },
        { term: "代表者", body: "代表取締役" },
        { term: "所在地", body: "◯◯港エリア（最寄り駅から徒歩 12 分）" },
        { term: "事業内容", body: "海域調査／環境モニタリング／データ解析" },
        { term: "主な取引先", body: "自治体、建設会社、大学の研究室" },
      ],
      note: "記載の内容は 2026 年 4 月現在のものです。",
    },
    history: {
      heading: "沿革",
      rows: [
        { year: "2002 年", body: "計測機器の保守を請け負う会社として創業しました。" },
        {
          year: "2007 年",
          body: "自社の観測ブイを海に設置し、水温と塩分の記録を始めました。",
        },
        {
          year: "2012 年",
          body: "解析の部署を設け、報告書の作成まで自社で行う体制を整えました。",
        },
        {
          year: "2018 年",
          body: "観測データを自動で集める仕組みを導入し、現場に出る回数を減らしています。",
        },
        {
          year: "2024 年",
          body: "長期の記録を公開する仕組みをつくり、大学との共同研究を始めています。",
        },
      ],
    },
    policies: {
      heading: "方針",
      items: [
        {
          title: "測った数字を、そのまま出す。",
          body: "都合のよい数字だけを選ぶことはしません。測れなかったことも報告書に記します。数字は加工せず、そのままお渡しします。",
        },
        {
          title: "現場を見てから決める。",
          body: "海の条件は場所ごとに違います。機器の置き方は、現地を確かめてから決めています。",
        },
        {
          title: "記録を絶やさない。",
          body: "一度はじめた観測を途切れさせないことを、何よりも優先しています。",
        },
      ],
    },
  },
  contact: {
    meta: {
      title: "お問い合わせ ｜ 潮見計測",
      description:
        "調査のご相談を承ります。測る範囲や期間が決まっていない段階でも、お問い合わせください。",
    },
    title: "お問い合わせ",
    lead: "調査のご相談を承ります。",
    heading: "お問い合わせにあたって",
    intro:
      "測る範囲や期間が決まっていない段階でも、ご相談いただけます。現場の条件と、知りたいことをお書きください。",
    hours: [
      {
        term: "受付時間",
        body: "平日 9:00 - 17:30（土日祝と年末年始はお休みをいただいています）",
      },
      {
        term: "お返事",
        body: "2 営業日以内にご返信します。お急ぎのご用件は、その旨をお書き添えください。",
      },
    ],
    form: {
      fields: [
        {
          name: "company",
          label: "会社名・団体名",
          required: true,
          placeholder: "例: ◯◯県◯◯課",
        },
        { name: "name", label: "ご担当者のお名前", required: true },
        {
          name: "email",
          label: "メールアドレス",
          type: "email",
          required: true,
          placeholder: "you@example.com",
        },
        {
          name: "message",
          label: "ご相談の内容",
          type: "textarea",
          required: true,
          placeholder: "測りたい場所、期間、知りたいことなど",
        },
      ],
      submitLabel: "この内容で送信する",
      endpoint: "",
      contentType: "json",
      honeypot: "homepage",
      messages: {
        sample:
          "送信されました（見本の表示です。送信先を設定するまで、実際には送られません）。",
        sending: "送信しています…",
        success: "お問い合わせを受け付けました。2 営業日以内にご返信します。",
        failure: "送信できませんでした。時間をおいて、もう一度お試しください。",
      },
    },
  },
  footer: {
    company: "潮見計測",
    entity: "会社",
    address: "〒000-0000 ○○県○○市○○ 1-2-3",
    email: "hello@example.com",
    tel: "000-0000-0000",
    copyright: "© 2026 潮見計測",
  },
};
