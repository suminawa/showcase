import { spanLabel } from "@/lib/hours";

import type { ClinicContent, Span } from "./types";

/**
 * クリニック・医院の LP の全文。
 * 初期値は架空の歯科医院「月白歯科クリニック」。公開する前に自分のものへ差し替える。
 * 色は styles/tokens.css の .theme-clinic にある。
 *
 * 時間の数字は下の 3 つの Span にしか書かない。
 * 見出し・凡例・予約の選択肢は spanLabel で組み立てる ── 数字を二か所に書くと、
 * 片方だけ直したときに掲示と予約の時間が食い違う。
 */
const MORNING: Span = { start: "9:30", end: "13:00" };
const AFTERNOON: Span = { start: "14:30", end: "19:00" };
/** 土曜の午後だけ、始まりが早く終わりも早い */
const SATURDAY_AFTERNOON: Span = { start: "14:00", end: "17:00" };

const MORNING_LABEL = "午前";
const AFTERNOON_LABEL = "午後";
const CLOSED_NOTE = "休診：木曜の午後、日曜・祝日";

export const clinic: ClinicContent = {
  brand: "月白歯科クリニック",
  meta: {
    title: "月白歯科クリニック ｜ 痛みに配慮した治療と、通いやすい予約",
    description:
      "歯医者が苦手な方や、お子さんを連れて通う方に合わせた歯科医院です。診療時間と Web 予約はこのページから。",
  },
  nav: [
    { label: "特長", href: "#about" },
    { label: "診療内容", href: "#treatments" },
    { label: "診療時間", href: "#hours" },
    { label: "よくある質問", href: "#faq" },
  ],
  navLabel: "ページ内",
  headerCta: { label: "Web で予約する", href: "#reserve" },
  hero: {
    eyebrow: "駅前の歯科医院",
    title: "痛みに配慮した治療と、通いやすい予約",
    lead: "歯医者が苦手な方や、お子さんを連れて通う方に合わせて、診療の進め方と予約の取り方を整えています。",
    facts: [
      `${MORNING_LABEL} ${spanLabel(MORNING)}`,
      `${AFTERNOON_LABEL} ${spanLabel(AFTERNOON)}`,
      CLOSED_NOTE,
    ],
    walk: "駅の東口から徒歩 3 分",
    primary: { label: "Web で予約する", href: "#reserve" },
    secondary: { label: "診療時間を見る", href: "#hours" },
    fine: "ご予約はこのページのフォームから承ります。当日の急な痛みは、お電話でご相談ください。",
  },
  hours: {
    // 日曜と祝日は休診なので、この配列に入れない
    days: [
      { day: 1, morning: MORNING, afternoon: AFTERNOON },
      { day: 2, morning: MORNING, afternoon: AFTERNOON },
      { day: 3, morning: MORNING, afternoon: AFTERNOON },
      { day: 4, morning: MORNING, afternoon: null },
      { day: 5, morning: MORNING, afternoon: AFTERNOON },
      { day: 6, morning: MORNING, afternoon: SATURDAY_AFTERNOON },
    ],
    openLabel: "いまは診療中です",
    closedLabel: "いまは診療時間外です",
  },
  schedule: {
    id: "hours",
    heading: "診療時間",
    morning: { label: MORNING_LABEL, span: MORNING },
    afternoon: { label: AFTERNOON_LABEL, span: AFTERNOON },
    caption: "曜日ごとの診療時間。",
    columnHeader: "時間帯",
    marks: {
      open: { symbol: "●", label: "診療" },
      short: { symbol: "▲", label: "短縮" },
      closed: { symbol: "−", label: "休診" },
    },
    legend: [
      { mark: "open", text: "診療" },
      {
        mark: "short",
        text: `土曜の${AFTERNOON_LABEL}は ${spanLabel(SATURDAY_AFTERNOON)}`,
      },
      { mark: "closed", text: "休診" },
    ],
    closedNote: CLOSED_NOTE,
  },
  points: {
    id: "about",
    heading: "医院の三つの特長",
    items: [
      {
        title: "痛みに配慮した手順",
        body: "表面の麻酔をしてから、細い針でゆっくり注射します。麻酔液は体温に温めて使います。",
      },
      {
        title: "削る範囲はできるだけ小さく",
        body: "虫歯の範囲をカメラで確かめ、削る前に何をするかを画面でご説明します。",
      },
      {
        title: "予約は 30 分ずつ",
        body: "お一人ずつお時間を取りますので、待合室でお待ちいただく時間を短くできます。",
      },
    ],
  },
  treatments: {
    id: "treatments",
    heading: "診療内容",
    items: [
      {
        title: "一般歯科",
        body: "虫歯と歯周病の治療を行います。しみる、噛むと痛いといったご相談からどうぞ。",
        icon: "general",
      },
      {
        title: "小児歯科",
        body: "3 歳からお受けします。初回は診療台に座る練習だけで終わることもあります。",
        icon: "kids",
      },
      {
        title: "予防・クリーニング",
        body: "3 か月に 1 回の定期検診と、歯石の除去を行います。",
        icon: "cleaning",
      },
      {
        title: "矯正相談",
        body: "相談と検査は無料です。方針と期間、費用の目安をお伝えします。",
        icon: "braces",
      },
      {
        title: "ホワイトニング",
        body: "医院で行う方法と、ご自宅で続けていただく方法の 2 つをご用意しています。",
        icon: "whitening",
      },
      {
        title: "インプラント相談",
        body: "骨の状態を撮影し、治療ができるかどうかと、ほかの選択肢をご説明します。",
        icon: "implant",
      },
    ],
  },
  rooms: {
    id: "rooms",
    heading: "院内のご案内",
    items: [
      {
        title: "入口とスロープ",
        body: "段差はありません。ベビーカーや車いすのまま、診療室までお入りいただけます。",
        figure: "entrance",
      },
      {
        title: "診療室",
        body: "半個室の診療台が 4 台あります。となりの音や話し声が気になりにくいよう、台のあいだに壁を設けています。",
        figure: "rooms",
      },
      {
        title: "キッズスペース",
        body: "待合の一角に、靴を脱いで上がれる場所をご用意しています。診療のあいだは、スタッフが様子を見守ります。",
        figure: "kids",
      },
    ],
  },
  faq: {
    id: "faq",
    heading: "よくある質問",
    items: [
      {
        q: "予約なしでも診てもらえますか。",
        a: "急な痛みのときは、当日の空いた時間にご案内します。まずはご連絡ください。ご予約の方を優先しますので、お待ちいただくことがあります。",
      },
      {
        q: "子どもは何歳から診てもらえますか。",
        a: "3 歳からお受けします。初回は診療台に座る練習から始めます。",
      },
      {
        q: "治療は何回くらいかかりますか。",
        a: "小さな虫歯なら 1 回か 2 回です。神経の治療が必要な場合は、4 回から 6 回が目安です。",
      },
      {
        q: "保険は使えますか。",
        a: "一般歯科と小児歯科、歯周病の治療は保険で行います。矯正とホワイトニングは保険の対象外です。",
      },
      {
        q: "駐車場はありますか。",
        a: "医院の駐車場はございません。お近くのコインパーキングをご利用ください。",
      },
    ],
  },
  reserve: {
    id: "reserve",
    heading: "Web 予約",
    lead: "お名前、電話番号、ご希望の日と時間帯、気になることをご記入ください。翌診療日までに、こちらからご連絡します。",
    note: "ご予約が決まるのは、こちらからのご連絡のあとです。",
  },
  form: {
    fields: [
      { name: "name", label: "お名前", required: true },
      {
        name: "tel",
        label: "電話番号",
        type: "tel",
        required: true,
        placeholder: "日中つながる番号",
      },
      { name: "date", label: "ご希望の日", type: "date", required: true },
      {
        name: "slot",
        label: "ご希望の時間帯",
        type: "select",
        required: true,
        placeholder: "選んでください",
        options: [
          `${MORNING_LABEL}（${spanLabel(MORNING)}）`,
          `${AFTERNOON_LABEL}（${spanLabel(AFTERNOON)}）`,
          `土曜の${AFTERNOON_LABEL}（${spanLabel(SATURDAY_AFTERNOON)}）`,
        ],
      },
      {
        name: "symptom",
        label: "気になること",
        type: "textarea",
        placeholder: "例: 右下の奥歯がしみます",
      },
    ],
    submitLabel: "予約を申し込む",
    endpoint: "",
    contentType: "json",
    honeypot: "homepage",
    messages: {
      sample:
        "送信されました（見本の表示です。送信先を設定するまで、実際には送られません）。",
      sending: "送信しています…",
      success: "ご希望を受け付けました。翌診療日までにご連絡します。",
      failure: "送信できませんでした。時間をおいて、もう一度お試しください。",
    },
  },
  footer: {
    company: "月白歯科クリニック",
    entity: "医院",
    address: "〒000-0000 ○○県○○市○○ 1-2-3",
    email: "hello@example.com",
    tel: "000-0000-0000",
    copyright: "© 2026 月白歯科クリニック",
  },
};
