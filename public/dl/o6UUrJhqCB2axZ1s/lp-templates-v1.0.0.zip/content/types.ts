/**
 * LP の中身を決める型。文言・料金・営業時間・送信先はすべて content/ に集めてある。
 * app/ のページはここにあるものを読むだけで、文字も色も持たない。
 */

/** リンク 1 本。href はページ内なら "#pricing"、別のページなら "/shop/" */
export type Link = {
  label: string;
  href: string;
};

/** タブ・検索結果・共有カード（OGP）に出る文字 */
export type Meta = {
  /** 30 字前後。ブランド名を入れる */
  title: string;
  /** 80〜120 字 */
  description: string;
};

/** 一覧ページに並べるテンプレ 1 枚 */
export type TemplateCard = {
  /** テンプレのページ。"/saas/" のように前後をスラッシュで囲む */
  href: string;
  name: string;
  /** 効く業種 */
  industry: string;
  description: string;
  /** 入っている節。箇条書きで並べる */
  sections: string[];
};

/** サイト全体の設定と、一覧ページ（/）の中身 */
export type SiteContent = {
  /** 公開する URL。末尾のスラッシュは付けない。共有カードの絶対 URL に使う */
  url: string;
  /** 共有カードに出すサイトの名前 */
  name: string;
  home: {
    meta: Meta;
    heading: string;
    lead: string;
    templates: TemplateCard[];
    /** 一覧の下に出す但し書き */
    note: string;
  };
};

/** 入力欄 1 つ */
export type FormField = {
  /** 送信するときの鍵。半角英数字で書く */
  name: string;
  label: string;
  /** 既定は "text" */
  type?: "text" | "email" | "textarea" | "date" | "number";
  placeholder?: string;
  required?: boolean;
};

/**
 * 送信のかたち。"json" は application/json、"text" は text/plain。
 * 中身はどちらも同じ JSON。Google Apps Script のウェブアプリは "text" で送る
 * ── "json" だとブラウザが先に許可を問い合わせ（プリフライト）、Apps Script が
 * それに答えられないため。
 */
export type FormContentType = "json" | "text";

export type FormContent = {
  fields: FormField[];
  submitLabel: string;
  /** 送信先の URL。空なら送らずに messages.sample を出す */
  endpoint: string;
  contentType: FormContentType;
  /**
   * 迷惑投稿よけの、見えない欄の name。人には見えず、bot だけが埋める。
   * 字が入っていたら送信せず、成功の文言だけ出す。送る JSON にも入れない。
   * 空にするか項目ごと外すと、この仕掛けを使わない。
   */
  honeypot?: string;
  messages: {
    /** endpoint が空のときに出す文言 */
    sample: string;
    /** 送っている間に出す文言 */
    sending: string;
    /** 送れたときの文言 */
    success: string;
    /** 送れなかったときの文言 */
    failure: string;
  };
};

export type FooterContent = {
  /** 会社名・屋号 */
  company: string;
  address: string;
  email: string;
  /** 空ならこの行を出さない */
  tel: string;
  /** 「© 2026 〇〇」。年は自分で書き換える */
  copyright: string;
};

/**
 * 機能の節に出す線画の名前。
 * 増やすときは、ここに名前を足して components/FeatureIcon.tsx に形を足す。
 */
export type FeatureIcon = "screen" | "clock" | "export";

export type Plan = {
  id: string;
  name: string;
  /** 1 人あたりの月額（円） */
  monthly: number;
  /** 対象の会社の規模 */
  audience: string;
  features: string[];
  /** 1 つだけ true にすると「おすすめ」が付く */
  recommended?: boolean;
};

/** BtoB・SaaS の LP（/saas）の全文 */
export type SaasContent = {
  brand: string;
  meta: Meta;
  /** 上の帯のページ内リンク。href は各節の id とそろえる */
  nav: Link[];
  /** 上の帯の右のボタン */
  headerCta: Link;
  hero: {
    eyebrow: string;
    title: string;
    lead: string;
    primary: Link;
    secondary: Link;
    /** ボタンの下の小さい一行 */
    fine: string;
    /** 背景の粒の数。0 で粒なし。色は styles/tokens.css の --d-field-rgb */
    fieldCount: number;
  };
  issues: {
    /** ページ内リンクの飛び先（"issues" なら #issues） */
    id: string;
    heading: string;
    items: { title: string; body: string }[];
  };
  features: {
    id: string;
    heading: string;
    items: { title: string; body: string; icon: FeatureIcon }[];
  };
  pricing: {
    id: string;
    heading: string;
    /** 年額払いの割引率。0.2 なら 20% 引き。変えたら yearlyLabel と monthlyNote の「20%」も直す */
    yearlyDiscount: number;
    /** 切替の組に付ける読み上げ用の名前 */
    toggleLabel: string;
    monthlyLabel: string;
    yearlyLabel: string;
    /** 金額の後ろに添える単位 */
    unit: string;
    recommendedBadge: string;
    /** 月額を選んでいるときの但し書き */
    monthlyNote: string;
    /** 年額を選んでいるときの但し書き */
    yearlyNote: string;
    plans: Plan[];
  };
  flow: {
    id: string;
    heading: string;
    /** time は空にすると所要時間を出さない */
    steps: { title: string; time: string }[];
  };
  faq: {
    id: string;
    heading: string;
    items: { q: string; a: string }[];
  };
  contact: {
    id: string;
    heading: string;
    lead: string;
  };
  form: FormContent;
  footer: FooterContent;
};

/** 0 = 日曜 … 6 = 土曜。Date#getDay と同じ並び */
export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6;

/** 営業時間。日をまたぐ営業は扱わない（日中だけ開く店を想定） */
export type Hours = {
  /** 定休日。[1, 2, 3] で月・火・水が休み */
  closedDays: Weekday[];
  /** "10:00" の形 */
  open: string;
  /** "18:00" の形 */
  close: string;
  /** ラストオーダー。空なら括弧ごと出さない */
  lastOrder: string;
  /** 開いているときの一行 */
  openLabel: string;
  /** 閉まっているときの一行 */
  closedLabel: string;
};

export type MenuItem = {
  id: string;
  name: string;
  /** 税込みの価格（円） */
  price: number;
  /** MenuGroup の category と同じ字にする */
  category: string;
  /** 品書きに一行だけ添える説明 */
  note: string;
};

/** 品書きの組。表示の順もこの配列の順 */
export type MenuGroup = {
  category: string;
  label: string;
};

/** 店舗・サロンの LP（/shop）の全文 */
export type ShopContent = {
  brand: string;
  meta: Meta;
  hero: {
    eyebrow: string;
    /** 大見出しの下に置く一言。見出しそのものは brand を使う */
    tagline: string;
    lead: string;
    primary: Link;
    secondary: Link;
    fieldCount: number;
  };
  hours: Hours;
  points: {
    id: string;
    heading: string;
    items: { title: string; body: string }[];
  };
  menu: {
    id: string;
    heading: string;
    groups: MenuGroup[];
    items: MenuItem[];
    /** 品書きの下の但し書き */
    note: string;
  };
  seats: {
    id: string;
    heading: string;
    items: { term: string; body: string }[];
  };
  access: {
    id: string;
    heading: string;
    steps: string[];
  };
  reserve: {
    id: string;
    heading: string;
    lead: string;
  };
  form: FormContent;
  footer: FooterContent;
};
