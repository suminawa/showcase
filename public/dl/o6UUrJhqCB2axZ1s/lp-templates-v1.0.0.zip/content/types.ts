/**
 * LP の中身を決める型。文言・料金・営業時間・送信先はすべて content/ に集めてある。
 * app/ のページはここにあるものを読むだけで、文字も色も持たない。
 */

/** リンク 1 本。href はページ内なら "#pricing"、別のページなら "/shop/" */
export type Link = {
  label: string;
  href: string;
};

/** タブ・検索結果・共有カード（OGP）に出る文字 */
export type Meta = {
  /** 30 字前後。ブランド名を入れる */
  title: string;
  /** 80〜120 字 */
  description: string;
};

/** 一覧ページに並べるテンプレ 1 枚 */
export type TemplateCard = {
  /** テンプレのページ。"/saas/" のように前後をスラッシュで囲む */
  href: string;
  name: string;
  /** 効く業種 */
  industry: string;
  description: string;
  /** 入っている節。箇条書きで並べる */
  sections: string[];
};

/** サイト全体の設定と、一覧ページ（/）の中身 */
export type SiteContent = {
  /** 公開する URL。末尾のスラッシュは付けない。共有カードの絶対 URL に使う */
  url: string;
  /** 共有カードに出すサイトの名前 */
  name: string;
  home: {
    meta: Meta;
    heading: string;
    lead: string;
    templates: TemplateCard[];
    /** 一覧の下に出す但し書き */
    note: string;
  };
};

/** 入力欄 1 つ */
export type FormField = {
  /** 送信するときの鍵。半角英数字で書く */
  name: string;
  label: string;
  /** 既定は "text" */
  type?:
    | "text"
    | "email"
    | "tel"
    | "textarea"
    | "date"
    | "number"
    | "select";
  placeholder?: string;
  required?: boolean;
  /**
   * type: "select" のときの選択肢。1 つ以上書く。
   * 先頭には placeholder の行が、選べない状態で入る
   * ── "select" のときは placeholder も必ず書く（空だと npm test が指摘する）。
   */
  options?: string[];
};

/**
 * 送信のかたち。"json" は application/json、"text" は text/plain。
 * 中身はどちらも同じ JSON。Google Apps Script のウェブアプリは "text" で送る
 * ── "json" だとブラウザが先に許可を問い合わせ（プリフライト）、Apps Script が
 * それに答えられないため。
 */
export type FormContentType = "json" | "text";

export type FormContent = {
  fields: FormField[];
  submitLabel: string;
  /** 送信先の URL。空なら送らずに messages.sample を出す */
  endpoint: string;
  contentType: FormContentType;
  /**
   * 迷惑投稿よけの、見えない欄の name。人には見えず、bot だけが埋める。
   * 字が入っていたら送信せず、成功の文言だけ出す。送る JSON にも入れない。
   * 空にするか項目ごと外すと、この仕掛けを使わない。
   */
  honeypot?: string;
  messages: {
    /** endpoint が空のときに出す文言 */
    sample: string;
    /** 送っている間に出す文言 */
    sending: string;
    /** 送れたときの文言 */
    success: string;
    /** 送れなかったときの文言 */
    failure: string;
  };
};

export type FooterContent = {
  /** 会社名・屋号 */
  company: string;
  /**
   * 読み上げのときに「○○の情報」と呼ばれる語。会社／事務所／医院／店。
   * 画面には出ない。省くと「会社」になる。
   */
  entity?: string;
  address: string;
  email: string;
  /** 空ならこの行を出さない */
  tel: string;
  /** 「© 2026 〇〇」。年は自分で書き換える */
  copyright: string;
};

/**
 * 機能の節に出す線画の名前。
 * 増やすときは、ここに名前を足して components/FeatureIcon.tsx に形を足す。
 */
export type FeatureIcon = "screen" | "clock" | "export";

export type Plan = {
  id: string;
  name: string;
  /** 1 人あたりの月額（円） */
  monthly: number;
  /** 対象の会社の規模 */
  audience: string;
  features: string[];
  /** 1 つだけ true にすると「おすすめ」が付く */
  recommended?: boolean;
};

/** BtoB・SaaS の LP（/saas）の全文 */
export type SaasContent = {
  brand: string;
  meta: Meta;
  /** 上の帯のページ内リンク。href は各節の id とそろえる */
  nav: Link[];
  /** 上の帯の組に付ける読み上げ用の名前。画面には出ない */
  navLabel: string;
  /** 上の帯の右のボタン */
  headerCta: Link;
  hero: {
    eyebrow: string;
    title: string;
    lead: string;
    primary: Link;
    secondary: Link;
    /** ボタンの下の小さい一行 */
    fine: string;
    /** 背景の粒の数。0 で粒なし。色は styles/tokens.css の --d-field-rgb */
    fieldCount: number;
  };
  issues: {
    /** ページ内リンクの飛び先（"issues" なら #issues） */
    id: string;
    heading: string;
    items: { title: string; body: string }[];
  };
  features: {
    id: string;
    heading: string;
    items: { title: string; body: string; icon: FeatureIcon }[];
  };
  pricing: {
    id: string;
    heading: string;
    /** 年額払いの割引率。0.2 なら 20% 引き。変えたら yearlyLabel と monthlyNote の「20%」も直す */
    yearlyDiscount: number;
    /** 切替の組に付ける読み上げ用の名前 */
    toggleLabel: string;
    monthlyLabel: string;
    yearlyLabel: string;
    /** 金額の後ろに添える単位 */
    unit: string;
    recommendedBadge: string;
    /** 月額を選んでいるときの但し書き */
    monthlyNote: string;
    /** 年額を選んでいるときの但し書き */
    yearlyNote: string;
    plans: Plan[];
  };
  flow: {
    id: string;
    heading: string;
    /** time は空にすると所要時間を出さない */
    steps: { title: string; time: string }[];
  };
  faq: {
    id: string;
    heading: string;
    items: { q: string; a: string }[];
  };
  contact: {
    id: string;
    heading: string;
    lead: string;
  };
  form: FormContent;
  footer: FooterContent;
};

/** 0 = 日曜 … 6 = 土曜。Date#getDay と同じ並び */
export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6;

/** 営業時間。日をまたぐ営業は扱わない（日中だけ開く店を想定） */
export type Hours = {
  /** 定休日。[1, 2, 3] で月・火・水が休み */
  closedDays: Weekday[];
  /** "10:00" の形 */
  open: string;
  /** "18:00" の形 */
  close: string;
  /** ラストオーダー。空なら括弧ごと出さない */
  lastOrder: string;
  /** 開いているときの一行 */
  openLabel: string;
  /** 閉まっているときの一行 */
  closedLabel: string;
};

export type MenuItem = {
  id: string;
  name: string;
  /** 税込みの価格（円） */
  price: number;
  /** MenuGroup の category と同じ字にする */
  category: string;
  /** 品書きに一行だけ添える説明 */
  note: string;
};

/** 品書きの組。表示の順もこの配列の順 */
export type MenuGroup = {
  category: string;
  label: string;
};

/** 店舗・サロンの LP（/shop）の全文 */
export type ShopContent = {
  brand: string;
  meta: Meta;
  hero: {
    eyebrow: string;
    /** 大見出しの下に置く一言。見出しそのものは brand を使う */
    tagline: string;
    lead: string;
    primary: Link;
    secondary: Link;
    fieldCount: number;
  };
  hours: Hours;
  points: {
    id: string;
    heading: string;
    items: { title: string; body: string }[];
  };
  menu: {
    id: string;
    heading: string;
    groups: MenuGroup[];
    items: MenuItem[];
    /** 品書きの下の但し書き */
    note: string;
  };
  seats: {
    id: string;
    heading: string;
    items: { term: string; body: string }[];
  };
  access: {
    id: string;
    heading: string;
    steps: string[];
  };
  reserve: {
    id: string;
    heading: string;
    lead: string;
  };
  form: FormContent;
  footer: FooterContent;
};

/* ============================================================
 * ここから下は、あとから足した 4 本（建設・工事／士業・研修／クリニック・医院／会社案内）の型。
 * 上の SaasContent・ShopContent には手を入れていない。
 * ============================================================ */

/** 一日のうちの、開いている時間帯。"9:30" の形で書く（時の 0 詰めはしてもしなくてもよい） */
export type Span = {
  start: string;
  end: string;
};

/** 曜日ごとの、午前と午後。その時間帯が休みなら null */
export type DayHours = {
  day: Weekday;
  morning: Span | null;
  afternoon: Span | null;
};

/**
 * 午前・午後に分かれる診療時間。開く曜日だけを days に並べる（休診の曜日は入れない）。
 * 表の列の並びも days の順。
 */
export type SpanHours = {
  days: DayHours[];
  /** 開いているときの一行 */
  openLabel: string;
  /** 閉まっているときの一行 */
  closedLabel: string;
};

/** 診療時間の表のます目。標準どおり・短縮・休み */
export type Mark = "open" | "short" | "closed";

/* ---- 建設・工事の LP（/construction） ---- */

/**
 * 対応メニューの線画の名前。
 * 増やすときは、ここに名前を足して components/ServiceIcon.tsx に形を足す。
 */
export type ServiceIcon =
  | "leak"
  | "clog"
  | "water-heater"
  | "outlet"
  | "panel"
  | "aircon";

export type ServiceItem = {
  id: string;
  name: string;
  /** 目安の下限（税込・円）。「8,800 円〜」と出る */
  from: number;
  note: string;
  icon: ServiceIcon;
};

export type RateRow = {
  id: string;
  label: string;
  /** 平日（昼）の税込価格（円）。0 は freeLabel（「無料」）と出る */
  weekday: number;
  /** 夜間・休日の割増を掛ける行か。見積もりのように掛けない行は false */
  surcharged: boolean;
  note: string;
};

/**
 * 対応エリアの点。
 * 角度は真上を 0 度とした時計回り、半径は中心（営業所）から外周までの割合（0 より大きく 1 以下）。
 */
export type Area = {
  id: string;
  label: string;
  radius: number;
  angle: number;
};

/** 建設・工事の LP（/construction）の全文 */
export type ConstructionContent = {
  brand: string;
  meta: Meta;
  /** 上の帯のページ内リンク。href は各節の id とそろえる */
  nav: Link[];
  /** 上の帯の組に付ける読み上げ用の名前。画面には出ない */
  navLabel: string;
  /** 電話の CTA。phone が空ならボタンを出さない（上の帯もヒーローも出さない） */
  call: {
    /** 「000-0000-0000」の形。tel: のリンクでは数字と + 以外を落とす */
    phone: string;
    /** 上の帯の小さいボタンの字 */
    headerLabel: string;
    /** ヒーローの大きいボタンの字 */
    heroLabel: string;
    /** 大きいボタンの中の小さい一行（受付時間など） */
    heroSub: string;
  };
  hero: {
    eyebrow: string;
    title: string;
    lead: string;
    /** 受付時間と対応エリアの箇条。行は増やしてよい */
    facts: string[];
    secondary: Link;
    /** ボタンの下の小さい一行 */
    fine: string;
    /** 背景の粒の数。0 で粒なし。色は styles/tokens.css の --d-field-rgb */
    fieldCount: number;
  };
  services: {
    id: string;
    heading: string;
    items: ServiceItem[];
    /** 一覧の下の但し書き */
    note: string;
  };
  price: {
    id: string;
    heading: string;
    lead: string;
    /** 夜間・休日の割増。1.5 で 5 割増。変えたら weekdayNote と nightNote の「5 割増」も直す */
    nightRate: number;
    /** 切替の組に付ける読み上げ用の名前 */
    toggleLabel: string;
    weekdayLabel: string;
    nightLabel: string;
    /** 平日を選んでいるときの但し書き */
    weekdayNote: string;
    /** 夜間・休日を選んでいるときの但し書き */
    nightNote: string;
    /** 0 円の行に出す字 */
    freeLabel: string;
    rows: RateRow[];
  };
  areas: {
    id: string;
    heading: string;
    lead: string;
    items: Area[];
    note: string;
  };
  flow: {
    id: string;
    heading: string;
    steps: { title: string; body: string }[];
  };
  voices: {
    id: string;
    heading: string;
    items: { who: string; body: string }[];
  };
  faq: {
    id: string;
    heading: string;
    items: { q: string; a: string }[];
  };
  contact: {
    id: string;
    heading: string;
    lead: string;
  };
  form: FormContent;
  footer: FooterContent;
};

/* ---- 士業・研修の LP（/professional） ---- */

/**
 * サービスの節に出す線画の名前。
 * 増やすときは、ここに名前を足して components/ProfessionalIcon.tsx に形を足す。
 */
export type ProfessionalIcon = "audit" | "books" | "training";

/** 料金の単位。month は毎月、year は年に 1 回、spot は単発 */
export type AdvisoryUnit = "month" | "year" | "spot";

export type AdvisoryLine = {
  label: string;
  /** 税込みの金額（円） */
  price: number;
  unit: AdvisoryUnit;
};

export type AdvisoryPlan = {
  id: string;
  /** 切替のボタンに出す短い名前 */
  name: string;
  /** 誰向けかの一行 */
  audience: string;
  /** 金額の行。先頭の行だけ大きく出す */
  lines: AdvisoryLine[];
  /** 料金に含むもの */
  includes: string[];
  /** カードの結びの一行 */
  note: string;
};

/** 士業・研修の LP（/professional）の全文 */
export type ProfessionalContent = {
  brand: string;
  meta: Meta;
  nav: Link[];
  /** 上の帯の組に付ける読み上げ用の名前。画面には出ない */
  navLabel: string;
  headerCta: Link;
  hero: {
    eyebrow: string;
    title: string;
    lead: string;
    primary: Link;
    secondary: Link;
    fine: string;
  };
  issues: {
    id: string;
    heading: string;
    items: { title: string; body: string }[];
  };
  services: {
    id: string;
    heading: string;
    items: { title: string; body: string; icon: ProfessionalIcon }[];
  };
  pricing: {
    id: string;
    heading: string;
    /** 切替の組に付ける読み上げ用の名前 */
    switchLabel: string;
    /** 金額の後ろに添える単位 */
    unitLabels: Record<AdvisoryUnit, string>;
    /** 「年間の目安」の前置き */
    yearlyLabel: string;
    /** 単発だけのプランで、年間の目安の代わりに出す一行 */
    spotNote: string;
    plans: AdvisoryPlan[];
    /** 料金表の下の但し書き */
    note: string;
  };
  flow: {
    id: string;
    heading: string;
    steps: { title: string; body: string }[];
  };
  cases: {
    id: string;
    heading: string;
    /** 各行の見出し（業種・ご相談・結果） */
    labels: { industry: string; issue: string; result: string };
    items: { industry: string; issue: string; result: string }[];
    note: string;
  };
  faq: {
    id: string;
    heading: string;
    items: { q: string; a: string }[];
  };
  contact: {
    id: string;
    heading: string;
    lead: string;
  };
  form: FormContent;
  footer: FooterContent;
};

/* ---- クリニック・医院の LP（/clinic） ---- */

/**
 * 診療内容の線画の名前。
 * 増やすときは、ここに名前を足して components/TreatmentIcon.tsx に形を足す。
 */
export type TreatmentIcon =
  | "general"
  | "kids"
  | "cleaning"
  | "braces"
  | "whitening"
  | "implant";

/** 院内の図の名前。components/RoomFigure.tsx に形がある */
export type RoomFigure = "entrance" | "rooms" | "kids";

/** クリニック・医院の LP（/clinic）の全文 */
export type ClinicContent = {
  brand: string;
  meta: Meta;
  nav: Link[];
  /** 上の帯の組に付ける読み上げ用の名前。画面には出ない */
  navLabel: string;
  headerCta: Link;
  hero: {
    eyebrow: string;
    title: string;
    lead: string;
    /** 午前・午後・休診の箇条。時間は schedule の Span から組み立てる */
    facts: string[];
    /** 行き方の一行 */
    walk: string;
    primary: Link;
    secondary: Link;
    fine: string;
  };
  /** いま診療中かどうかの判定に使う。曜日ごとの午前・午後 */
  hours: SpanHours;
  /** 診療時間の表。時間の出どころは morning.span / afternoon.span だけにする */
  schedule: {
    id: string;
    heading: string;
    morning: { label: string; span: Span };
    afternoon: { label: string; span: Span };
    /** 表の頭に付ける説明。読み上げにだけ出る */
    caption: string;
    /** 左上のます目の見出し。読み上げにだけ出る */
    columnHeader: string;
    /** ます目の印と、その意味（読み上げに渡す語） */
    marks: Record<Mark, { symbol: string; label: string }>;
    /** 表の下の凡例。印と、その説明の一行 */
    legend: { mark: Mark; text: string }[];
    /** 凡例の下に出す一行（休診日） */
    closedNote: string;
  };
  points: {
    id: string;
    heading: string;
    items: { title: string; body: string }[];
  };
  treatments: {
    id: string;
    heading: string;
    items: { title: string; body: string; icon: TreatmentIcon }[];
  };
  rooms: {
    id: string;
    heading: string;
    items: { title: string; body: string; figure: RoomFigure }[];
  };
  faq: {
    id: string;
    heading: string;
    items: { q: string; a: string }[];
  };
  reserve: {
    id: string;
    heading: string;
    lead: string;
    note: string;
  };
  form: FormContent;
  footer: FooterContent;
};

/* ---- 会社案内サイト（/corporate と下層 3 枚） ---- */

/**
 * 三つの柱の線画の名前。
 * 増やすときは、ここに名前を足して components/PillarIcon.tsx に形を足す。
 */
export type PillarIcon = "survey" | "monitoring" | "analysis";

export type Pillar = {
  id: string;
  name: string;
  /** TOP の三つの柱で出す一文 */
  summary: string;
  /** 事業内容の面で出す説明 */
  body: string;
  /** 仕事の進み方 */
  steps: string[];
  /** 使う機材 */
  gear: string[];
  icon: PillarIcon;
};

export type NewsItem = {
  id: string;
  /** "2026-08-27" の形。<time datetime> にそのまま入り、画面には 2026.08.27 と出る */
  date: string;
  /** 「お知らせ」「実績」など、短い区分 */
  tag: string;
  title: string;
};

export type Stat = {
  id: string;
  label: string;
  /** 数え上げの行き先。整数で書く */
  value: number;
  unit: string;
};

/** 会社案内サイト 4 ページの全文 */
export type CorporateContent = {
  brand: string;
  /** 4 枚の面の行き先。ヘッダーの並びもこの順。href は "/corporate/" のように前後をスラッシュで囲む */
  nav: Link[];
  /** ヘッダーの組に付ける読み上げ用の名前 */
  navLabel: string;
  /** TOP と事業内容の面で分け合う三つの柱 */
  pillars: Pillar[];
  home: {
    meta: Meta;
    hero: {
      eyebrow: string;
      title: string;
      lead: string;
      primary: Link;
      secondary: Link;
    };
    pillars: { heading: string };
    stats: { heading: string; items: Stat[] };
    news: { heading: string; items: NewsItem[] };
    cta: { title: string; body: string; link: Link };
  };
  services: {
    meta: Meta;
    title: string;
    lead: string;
    /** 各柱の中の小見出し */
    flowTitle: string;
    gearTitle: string;
  };
  company: {
    meta: Meta;
    title: string;
    lead: string;
    profile: {
      heading: string;
      rows: { term: string; body: string }[];
      note: string;
    };
    history: { heading: string; rows: { year: string; body: string }[] };
    policies: { heading: string; items: { title: string; body: string }[] };
  };
  contact: {
    meta: Meta;
    title: string;
    lead: string;
    heading: string;
    intro: string;
    hours: { term: string; body: string }[];
    form: FormContent;
  };
  footer: FooterContent;
};
