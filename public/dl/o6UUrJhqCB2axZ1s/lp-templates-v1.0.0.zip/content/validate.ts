import { parseTime } from "@/lib/hours";
import { itemsByCategory } from "@/lib/menu";

import type {
  FooterContent,
  FormContent,
  Hours,
  Link,
  Meta,
  SaasContent,
  ShopContent,
  SiteContent,
} from "./types";

/**
 * content の抜けと形式を調べて、直すところを日本語で返す。空の配列なら問題なし。
 * content を書き換えたら npm test を 1 回通すこと ── ここが抜けと形の崩れを拾う。
 */

function requireText(issues: string[], label: string, value: string): void {
  if (value.trim() === "") issues.push(`${label} が空です`);
}

function checkMeta(issues: string[], prefix: string, meta: Meta): void {
  requireText(issues, `${prefix}.title`, meta.title);
  requireText(issues, `${prefix}.description`, meta.description);
}

/** 節の見出し。空だと画面に穴が開くので、まとめて見る */
function checkHeadings(
  issues: string[],
  sections: Record<string, { heading: string }>,
): void {
  for (const [key, section] of Object.entries(sections)) {
    requireText(issues, `${key}.heading`, section.heading);
  }
}

/** ページ内リンク（#で始まる href）の飛び先が、節の id にあるか */
function checkAnchors(issues: string[], links: Link[], ids: string[]): void {
  const known = new Set([...ids, "top"]);
  for (const link of links) {
    if (!link.href.startsWith("#")) continue;
    if (!known.has(link.href.slice(1))) {
      issues.push(
        `リンク「${link.label}」の飛び先 ${link.href} に合う節がありません`,
      );
    }
  }
}

function checkForm(issues: string[], form: FormContent): void {
  if (form.fields.length === 0) issues.push("form.fields が空です");
  const names = new Set<string>();
  form.fields.forEach((field, index) => {
    requireText(issues, `form.fields[${index}].name`, field.name);
    requireText(issues, `form.fields[${index}].label`, field.label);
    if (names.has(field.name)) {
      issues.push(`form.fields の name「${field.name}」が重なっています`);
    }
    names.add(field.name);
  });
  requireText(issues, "form.submitLabel", form.submitLabel);
  if (form.endpoint.trim() !== "" && !/^https?:\/\//.test(form.endpoint.trim())) {
    issues.push("form.endpoint は https:// から書きます（送らないときは空にします）");
  }
  requireText(issues, "form.messages.sample", form.messages.sample);
  requireText(issues, "form.messages.sending", form.messages.sending);
  requireText(issues, "form.messages.success", form.messages.success);
  requireText(issues, "form.messages.failure", form.messages.failure);
}

function checkFooter(issues: string[], footer: FooterContent): void {
  requireText(issues, "footer.company", footer.company);
  requireText(issues, "footer.address", footer.address);
  requireText(issues, "footer.email", footer.email);
  if (footer.email.trim() !== "" && !footer.email.includes("@")) {
    issues.push("footer.email がメールアドレスの形ではありません");
  }
  requireText(issues, "footer.copyright", footer.copyright);
}

function checkHours(issues: string[], hours: Hours): void {
  const open = parseTime(hours.open);
  const close = parseTime(hours.close);
  if (open === null) issues.push('hours.open は "10:00" の形で書きます');
  if (close === null) issues.push('hours.close は "18:00" の形で書きます');
  if (open !== null && close !== null && open >= close) {
    issues.push("hours.open は hours.close より前にします");
  }
  if (hours.lastOrder.trim() !== "") {
    const last = parseTime(hours.lastOrder);
    if (last === null) {
      issues.push(
        'hours.lastOrder は "17:30" の形で書きます（出さないときは空にします）',
      );
    } else if (open !== null && close !== null && (last < open || last > close)) {
      issues.push("hours.lastOrder は営業時間の中にします");
    }
  }
  if (hours.closedDays.length >= 7) {
    issues.push("hours.closedDays が 7 日すべてです。開く日がありません");
  }
  if (new Set(hours.closedDays).size !== hours.closedDays.length) {
    issues.push("hours.closedDays に同じ曜日が二度出ています");
  }
  requireText(issues, "hours.openLabel", hours.openLabel);
  requireText(issues, "hours.closedLabel", hours.closedLabel);
}

export function validateSite(site: SiteContent): string[] {
  const issues: string[] = [];
  requireText(issues, "name", site.name);
  if (!/^https?:\/\//.test(site.url)) issues.push("url は https:// から書きます");
  if (site.url.endsWith("/")) issues.push("url の末尾のスラッシュは外します");
  checkMeta(issues, "home.meta", site.home.meta);
  requireText(issues, "home.heading", site.home.heading);
  requireText(issues, "home.lead", site.home.lead);
  if (site.home.templates.length === 0) issues.push("home.templates が空です");
  site.home.templates.forEach((template, index) => {
    // 名前が空のときは「」で呼べないので、番号で指す
    const at = (key: string) =>
      template.name.trim() === ""
        ? `home.templates[${index}] の ${key}`
        : `home.templates「${template.name}」の ${key}`;
    requireText(issues, `home.templates[${index}] の name`, template.name);
    requireText(issues, at("industry"), template.industry);
    requireText(issues, at("description"), template.description);
    if (template.sections.length === 0) {
      issues.push(`${at("sections")} が空です`);
    }
    if (!template.href.startsWith("/") || !template.href.endsWith("/")) {
      issues.push(`${at("href")} は "/saas/" のように前後をスラッシュで囲みます`);
    }
  });
  return issues;
}

export function validateSaas(content: SaasContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.title", content.hero.title);
  requireText(issues, "hero.lead", content.hero.lead);
  requireText(issues, "hero.fine", content.hero.fine);

  checkHeadings(issues, {
    issues: content.issues,
    features: content.features,
    pricing: content.pricing,
    flow: content.flow,
    faq: content.faq,
    contact: content.contact,
  });

  content.nav.forEach((link, index) => {
    requireText(issues, `nav[${index}].label`, link.label);
  });
  requireText(issues, "headerCta.label", content.headerCta.label);

  checkAnchors(
    issues,
    [
      ...content.nav,
      content.headerCta,
      content.hero.primary,
      content.hero.secondary,
    ],
    [
      content.issues.id,
      content.features.id,
      content.pricing.id,
      content.flow.id,
      content.faq.id,
      content.contact.id,
    ],
  );

  content.issues.items.forEach((item, index) => {
    requireText(issues, `issues.items[${index}] の title`, item.title);
    requireText(issues, `issues「${item.title}」の body`, item.body);
  });
  content.features.items.forEach((item, index) => {
    requireText(issues, `features.items[${index}] の title`, item.title);
    requireText(issues, `features「${item.title}」の body`, item.body);
  });
  for (const step of content.flow.steps) {
    requireText(issues, "flow.steps の title", step.title);
  }
  content.faq.items.forEach((item, index) => {
    requireText(issues, `faq.items[${index}] の q`, item.q);
    requireText(issues, `faq「${item.q}」の a`, item.a);
  });

  requireText(issues, "pricing.toggleLabel", content.pricing.toggleLabel);
  requireText(issues, "pricing.monthlyLabel", content.pricing.monthlyLabel);
  requireText(issues, "pricing.yearlyLabel", content.pricing.yearlyLabel);
  requireText(issues, "pricing.unit", content.pricing.unit);
  requireText(issues, "pricing.recommendedBadge", content.pricing.recommendedBadge);
  requireText(issues, "pricing.monthlyNote", content.pricing.monthlyNote);
  requireText(issues, "pricing.yearlyNote", content.pricing.yearlyNote);

  if (content.pricing.plans.length === 0) issues.push("pricing.plans が空です");
  const planIds = new Set<string>();
  for (const plan of content.pricing.plans) {
    requireText(issues, `pricing.plans「${plan.id}」の name`, plan.name);
    requireText(issues, `pricing.plans「${plan.id}」の audience`, plan.audience);
    if (plan.monthly <= 0) {
      issues.push(`pricing.plans「${plan.id}」の monthly は 1 以上にします`);
    }
    if (plan.features.length === 0) {
      issues.push(`pricing.plans「${plan.id}」の features が空です`);
    }
    if (planIds.has(plan.id)) {
      issues.push(`pricing.plans の id「${plan.id}」が重なっています`);
    }
    planIds.add(plan.id);
  }
  if (content.pricing.plans.filter((plan) => plan.recommended).length > 1) {
    issues.push("pricing.plans の recommended は 1 つだけにします");
  }
  const discount = content.pricing.yearlyDiscount;
  if (!(discount >= 0 && discount < 1)) {
    issues.push("pricing.yearlyDiscount は 0 以上 1 未満にします");
  }

  requireText(issues, "contact.lead", content.contact.lead);

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}

export function validateShop(content: ShopContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.tagline", content.hero.tagline);
  requireText(issues, "hero.lead", content.hero.lead);

  checkHeadings(issues, {
    points: content.points,
    menu: content.menu,
    seats: content.seats,
    access: content.access,
    reserve: content.reserve,
  });

  checkAnchors(
    issues,
    [content.hero.primary, content.hero.secondary],
    [
      content.points.id,
      content.menu.id,
      content.seats.id,
      content.access.id,
      content.reserve.id,
    ],
  );

  checkHours(issues, content.hours);

  content.points.items.forEach((item, index) => {
    requireText(issues, `points.items[${index}] の title`, item.title);
    requireText(issues, `points「${item.title}」の body`, item.body);
  });
  content.seats.items.forEach((seat, index) => {
    requireText(issues, `seats.items[${index}] の term`, seat.term);
    requireText(issues, `seats「${seat.term}」の body`, seat.body);
  });
  if (content.access.steps.length === 0) issues.push("access.steps が空です");
  requireText(issues, "reserve.lead", content.reserve.lead);
  requireText(issues, "menu.note", content.menu.note);

  if (content.menu.items.length === 0) issues.push("menu.items が空です");
  const categories = new Set(content.menu.groups.map((group) => group.category));
  const itemIds = new Set<string>();
  for (const item of content.menu.items) {
    requireText(issues, `menu.items「${item.id}」の name`, item.name);
    if (item.price <= 0) {
      issues.push(`menu.items「${item.name}」の price は 1 以上にします`);
    }
    if (itemIds.has(item.id)) {
      issues.push(`menu.items の id「${item.id}」が重なっています`);
    }
    itemIds.add(item.id);
    if (!categories.has(item.category)) {
      issues.push(
        `menu.items「${item.name}」の category「${item.category}」に合う組が menu.groups にありません`,
      );
    }
  }
  for (const group of content.menu.groups) {
    requireText(issues, `menu.groups「${group.category}」の label`, group.label);
    if (itemsByCategory(content.menu.items, group.category).length === 0) {
      issues.push(`menu.groups「${group.label}」に品がありません`);
    }
  }

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}
