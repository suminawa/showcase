import { parseSpan, parseTime } from "@/lib/hours";
import { itemsByCategory } from "@/lib/menu";

import type {
  AdvisoryUnit,
  ClinicContent,
  ConstructionContent,
  CorporateContent,
  FooterContent,
  FormContent,
  Hours,
  Link,
  Mark,
  Meta,
  ProfessionalContent,
  SaasContent,
  ShopContent,
  SiteContent,
  SpanHours,
  Weekday,
} from "./types";

/**
 * content の抜けと形式を調べて、直すところを日本語で返す。空の配列なら問題なし。
 * content を書き換えたら npm test を 1 回通すこと ── ここが抜けと形の崩れを拾う。
 */

function requireText(issues: string[], label: string, value: string): void {
  if (value.trim() === "") issues.push(`${label} が空です`);
}

function checkMeta(issues: string[], prefix: string, meta: Meta): void {
  requireText(issues, `${prefix}.title`, meta.title);
  requireText(issues, `${prefix}.description`, meta.description);
}

/** 節の見出し。空だと画面に穴が開くので、まとめて見る */
function checkHeadings(
  issues: string[],
  sections: Record<string, { heading: string }>,
): void {
  for (const [key, section] of Object.entries(sections)) {
    requireText(issues, `${key}.heading`, section.heading);
  }
}

/** ページ内リンク（#で始まる href）の飛び先が、節の id にあるか */
function checkAnchors(issues: string[], links: Link[], ids: string[]): void {
  const known = new Set([...ids, "top"]);
  for (const link of links) {
    if (!link.href.startsWith("#")) continue;
    if (!known.has(link.href.slice(1))) {
      issues.push(
        `リンク「${link.label}」の飛び先 ${link.href} に合う節がありません`,
      );
    }
  }
}

function checkForm(issues: string[], form: FormContent): void {
  if (form.fields.length === 0) issues.push("form.fields が空です");
  const names = new Set<string>();
  form.fields.forEach((field, index) => {
    requireText(issues, `form.fields[${index}].name`, field.name);
    requireText(issues, `form.fields[${index}].label`, field.label);
    if (names.has(field.name)) {
      issues.push(`form.fields の name「${field.name}」が重なっています`);
    }
    names.add(field.name);
    if (field.type === "select") {
      if (!field.options || field.options.length === 0) {
        issues.push(
          `form.fields「${field.name}」は type: "select" なので options を 1 つ以上書きます`,
        );
      }
      if ((field.placeholder ?? "").trim() === "") {
        issues.push(
          `form.fields「${field.name}」は type: "select" なので placeholder（選ぶ前に出す字）を書きます`,
        );
      }
    }
  });
  requireText(issues, "form.submitLabel", form.submitLabel);
  if (form.endpoint.trim() !== "" && !/^https?:\/\//.test(form.endpoint.trim())) {
    issues.push("form.endpoint は https:// から書きます（送らないときは空にします）");
  }
  requireText(issues, "form.messages.sample", form.messages.sample);
  requireText(issues, "form.messages.sending", form.messages.sending);
  requireText(issues, "form.messages.success", form.messages.success);
  requireText(issues, "form.messages.failure", form.messages.failure);
}

function checkFooter(issues: string[], footer: FooterContent): void {
  requireText(issues, "footer.company", footer.company);
  requireText(issues, "footer.address", footer.address);
  requireText(issues, "footer.email", footer.email);
  if (footer.email.trim() !== "" && !footer.email.includes("@")) {
    issues.push("footer.email がメールアドレスの形ではありません");
  }
  requireText(issues, "footer.copyright", footer.copyright);
}

function checkHours(issues: string[], hours: Hours): void {
  const open = parseTime(hours.open);
  const close = parseTime(hours.close);
  if (open === null) issues.push('hours.open は "10:00" の形で書きます');
  if (close === null) issues.push('hours.close は "18:00" の形で書きます');
  if (open !== null && close !== null && open >= close) {
    issues.push("hours.open は hours.close より前にします");
  }
  if (hours.lastOrder.trim() !== "") {
    const last = parseTime(hours.lastOrder);
    if (last === null) {
      issues.push(
        'hours.lastOrder は "17:30" の形で書きます（出さないときは空にします）',
      );
    } else if (open !== null && close !== null && (last < open || last > close)) {
      issues.push("hours.lastOrder は営業時間の中にします");
    }
  }
  if (hours.closedDays.length >= 7) {
    issues.push("hours.closedDays が 7 日すべてです。開く日がありません");
  }
  if (new Set(hours.closedDays).size !== hours.closedDays.length) {
    issues.push("hours.closedDays に同じ曜日が二度出ています");
  }
  requireText(issues, "hours.openLabel", hours.openLabel);
  requireText(issues, "hours.closedLabel", hours.closedLabel);
}

export function validateSite(site: SiteContent): string[] {
  const issues: string[] = [];
  requireText(issues, "name", site.name);
  if (!/^https?:\/\//.test(site.url)) issues.push("url は https:// から書きます");
  if (site.url.endsWith("/")) issues.push("url の末尾のスラッシュは外します");
  checkMeta(issues, "home.meta", site.home.meta);
  requireText(issues, "home.heading", site.home.heading);
  requireText(issues, "home.lead", site.home.lead);
  if (site.home.templates.length === 0) issues.push("home.templates が空です");
  site.home.templates.forEach((template, index) => {
    // 名前が空のときは「」で呼べないので、番号で指す
    const at = (key: string) =>
      template.name.trim() === ""
        ? `home.templates[${index}] の ${key}`
        : `home.templates「${template.name}」の ${key}`;
    requireText(issues, `home.templates[${index}] の name`, template.name);
    requireText(issues, at("industry"), template.industry);
    requireText(issues, at("description"), template.description);
    if (template.sections.length === 0) {
      issues.push(`${at("sections")} が空です`);
    }
    if (!template.href.startsWith("/") || !template.href.endsWith("/")) {
      issues.push(`${at("href")} は "/saas/" のように前後をスラッシュで囲みます`);
    }
  });
  return issues;
}

const DAY_NAMES = ["日", "月", "火", "水", "木", "金", "土"] as const;

/**
 * 午前・午後に分かれる診療時間を見る。
 * 休みの曜日は days に入れない決まりなので、両方 null の行は間違いとして拾う。
 */
export function validateSpanHours(hours: SpanHours): string[] {
  const issues: string[] = [];
  if (hours.days.length === 0) {
    issues.push("hours.days が空です。開く曜日がありません");
  }
  const seen = new Set<Weekday>();
  hours.days.forEach((entry, index) => {
    if (seen.has(entry.day)) {
      issues.push(
        `hours.days に同じ曜日が二度出ています（${DAY_NAMES[entry.day]}）`,
      );
    }
    seen.add(entry.day);
    if (entry.morning === null && entry.afternoon === null) {
      issues.push(
        `hours.days[${index}] は午前も午後も空です。休みの曜日は days に入れません`,
      );
    }
    const spans = [
      ["morning", entry.morning],
      ["afternoon", entry.afternoon],
    ] as const;
    for (const [key, span] of spans) {
      if (span === null) continue;
      if (parseSpan(span) === null) {
        issues.push(
          `hours.days[${index}].${key} は { start: "9:30", end: "13:00" } の形で、start を end より前にします`,
        );
      }
    }
  });
  requireText(issues, "hours.openLabel", hours.openLabel);
  requireText(issues, "hours.closedLabel", hours.closedLabel);
  return issues;
}

export function validateSaas(content: SaasContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.title", content.hero.title);
  requireText(issues, "hero.lead", content.hero.lead);
  requireText(issues, "hero.fine", content.hero.fine);

  checkHeadings(issues, {
    issues: content.issues,
    features: content.features,
    pricing: content.pricing,
    flow: content.flow,
    faq: content.faq,
    contact: content.contact,
  });

  requireText(issues, "navLabel", content.navLabel);
  content.nav.forEach((link, index) => {
    requireText(issues, `nav[${index}].label`, link.label);
  });
  requireText(issues, "headerCta.label", content.headerCta.label);

  checkAnchors(
    issues,
    [
      ...content.nav,
      content.headerCta,
      content.hero.primary,
      content.hero.secondary,
    ],
    [
      content.issues.id,
      content.features.id,
      content.pricing.id,
      content.flow.id,
      content.faq.id,
      content.contact.id,
    ],
  );

  content.issues.items.forEach((item, index) => {
    requireText(issues, `issues.items[${index}] の title`, item.title);
    requireText(issues, `issues「${item.title}」の body`, item.body);
  });
  content.features.items.forEach((item, index) => {
    requireText(issues, `features.items[${index}] の title`, item.title);
    requireText(issues, `features「${item.title}」の body`, item.body);
  });
  for (const step of content.flow.steps) {
    requireText(issues, "flow.steps の title", step.title);
  }
  content.faq.items.forEach((item, index) => {
    requireText(issues, `faq.items[${index}] の q`, item.q);
    requireText(issues, `faq「${item.q}」の a`, item.a);
  });

  requireText(issues, "pricing.toggleLabel", content.pricing.toggleLabel);
  requireText(issues, "pricing.monthlyLabel", content.pricing.monthlyLabel);
  requireText(issues, "pricing.yearlyLabel", content.pricing.yearlyLabel);
  requireText(issues, "pricing.unit", content.pricing.unit);
  requireText(issues, "pricing.recommendedBadge", content.pricing.recommendedBadge);
  requireText(issues, "pricing.monthlyNote", content.pricing.monthlyNote);
  requireText(issues, "pricing.yearlyNote", content.pricing.yearlyNote);

  if (content.pricing.plans.length === 0) issues.push("pricing.plans が空です");
  const planIds = new Set<string>();
  for (const plan of content.pricing.plans) {
    requireText(issues, `pricing.plans「${plan.id}」の name`, plan.name);
    requireText(issues, `pricing.plans「${plan.id}」の audience`, plan.audience);
    if (plan.monthly <= 0) {
      issues.push(`pricing.plans「${plan.id}」の monthly は 1 以上にします`);
    }
    if (plan.features.length === 0) {
      issues.push(`pricing.plans「${plan.id}」の features が空です`);
    }
    if (planIds.has(plan.id)) {
      issues.push(`pricing.plans の id「${plan.id}」が重なっています`);
    }
    planIds.add(plan.id);
  }
  if (content.pricing.plans.filter((plan) => plan.recommended).length > 1) {
    issues.push("pricing.plans の recommended は 1 つだけにします");
  }
  const discount = content.pricing.yearlyDiscount;
  if (!(discount >= 0 && discount < 1)) {
    issues.push("pricing.yearlyDiscount は 0 以上 1 未満にします");
  }

  requireText(issues, "contact.lead", content.contact.lead);

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}

export function validateShop(content: ShopContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.tagline", content.hero.tagline);
  requireText(issues, "hero.lead", content.hero.lead);

  checkHeadings(issues, {
    points: content.points,
    menu: content.menu,
    seats: content.seats,
    access: content.access,
    reserve: content.reserve,
  });

  checkAnchors(
    issues,
    [content.hero.primary, content.hero.secondary],
    [
      content.points.id,
      content.menu.id,
      content.seats.id,
      content.access.id,
      content.reserve.id,
    ],
  );

  checkHours(issues, content.hours);

  content.points.items.forEach((item, index) => {
    requireText(issues, `points.items[${index}] の title`, item.title);
    requireText(issues, `points「${item.title}」の body`, item.body);
  });
  content.seats.items.forEach((seat, index) => {
    requireText(issues, `seats.items[${index}] の term`, seat.term);
    requireText(issues, `seats「${seat.term}」の body`, seat.body);
  });
  if (content.access.steps.length === 0) issues.push("access.steps が空です");
  requireText(issues, "reserve.lead", content.reserve.lead);
  requireText(issues, "menu.note", content.menu.note);

  if (content.menu.items.length === 0) issues.push("menu.items が空です");
  const categories = new Set(content.menu.groups.map((group) => group.category));
  const itemIds = new Set<string>();
  for (const item of content.menu.items) {
    requireText(issues, `menu.items「${item.id}」の name`, item.name);
    if (item.price <= 0) {
      issues.push(`menu.items「${item.name}」の price は 1 以上にします`);
    }
    if (itemIds.has(item.id)) {
      issues.push(`menu.items の id「${item.id}」が重なっています`);
    }
    itemIds.add(item.id);
    if (!categories.has(item.category)) {
      issues.push(
        `menu.items「${item.name}」の category「${item.category}」に合う組が menu.groups にありません`,
      );
    }
  }
  for (const group of content.menu.groups) {
    requireText(issues, `menu.groups「${group.category}」の label`, group.label);
    if (itemsByCategory(content.menu.items, group.category).length === 0) {
      issues.push(`menu.groups「${group.label}」に品がありません`);
    }
  }

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}

export function validateConstruction(content: ConstructionContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.title", content.hero.title);
  requireText(issues, "hero.lead", content.hero.lead);
  requireText(issues, "hero.fine", content.hero.fine);
  if (content.hero.facts.length === 0) issues.push("hero.facts が空です");

  checkHeadings(issues, {
    services: content.services,
    price: content.price,
    areas: content.areas,
    flow: content.flow,
    voices: content.voices,
    faq: content.faq,
    contact: content.contact,
  });

  requireText(issues, "navLabel", content.navLabel);
  content.nav.forEach((link, index) => {
    requireText(issues, `nav[${index}].label`, link.label);
  });
  checkAnchors(
    issues,
    [...content.nav, content.hero.secondary],
    [
      content.services.id,
      content.price.id,
      content.areas.id,
      content.flow.id,
      content.voices.id,
      content.faq.id,
      content.contact.id,
    ],
  );

  // 電話。番号が空ならボタンごと出さないので、ボタンの字は見ない
  const phone = content.call.phone.trim();
  if (phone !== "") {
    if (!/^[0-9+][0-9+-]*$/.test(phone)) {
      issues.push(
        "call.phone は数字と + と - だけで書きます（電話ボタンを出さないときは空にします）",
      );
    }
    requireText(issues, "call.headerLabel", content.call.headerLabel);
    requireText(issues, "call.heroLabel", content.call.heroLabel);
  }

  if (content.services.items.length === 0) issues.push("services.items が空です");
  const serviceIds = new Set<string>();
  for (const item of content.services.items) {
    requireText(issues, `services.items「${item.id}」の name`, item.name);
    requireText(issues, `services.items「${item.id}」の note`, item.note);
    if (item.from <= 0) {
      issues.push(`services.items「${item.name}」の from は 1 以上にします`);
    }
    if (serviceIds.has(item.id)) {
      issues.push(`services.items の id「${item.id}」が重なっています`);
    }
    serviceIds.add(item.id);
  }
  requireText(issues, "services.note", content.services.note);

  requireText(issues, "price.lead", content.price.lead);
  requireText(issues, "price.toggleLabel", content.price.toggleLabel);
  requireText(issues, "price.weekdayLabel", content.price.weekdayLabel);
  requireText(issues, "price.nightLabel", content.price.nightLabel);
  requireText(issues, "price.weekdayNote", content.price.weekdayNote);
  requireText(issues, "price.nightNote", content.price.nightNote);
  requireText(issues, "price.freeLabel", content.price.freeLabel);
  if (!(content.price.nightRate >= 1)) {
    issues.push("price.nightRate は 1 以上にします（1.5 で 5 割増）");
  }
  if (content.price.rows.length === 0) issues.push("price.rows が空です");
  const rateIds = new Set<string>();
  for (const row of content.price.rows) {
    requireText(issues, `price.rows「${row.id}」の label`, row.label);
    requireText(issues, `price.rows「${row.id}」の note`, row.note);
    if (!Number.isInteger(row.weekday) || row.weekday < 0) {
      issues.push(`price.rows「${row.label}」の weekday は 0 以上の整数にします`);
    }
    if (rateIds.has(row.id)) {
      issues.push(`price.rows の id「${row.id}」が重なっています`);
    }
    rateIds.add(row.id);
  }

  requireText(issues, "areas.lead", content.areas.lead);
  requireText(issues, "areas.note", content.areas.note);
  if (content.areas.items.length === 0) issues.push("areas.items が空です");
  const areaIds = new Set<string>();
  for (const area of content.areas.items) {
    requireText(issues, `areas.items「${area.id}」の label`, area.label);
    if (!(area.radius > 0 && area.radius <= 1)) {
      issues.push(
        `areas.items「${area.label}」の radius は 0 より大きく 1 以下にします`,
      );
    }
    if (!(area.angle >= 0 && area.angle < 360)) {
      issues.push(`areas.items「${area.label}」の angle は 0 以上 360 未満にします`);
    }
    if (areaIds.has(area.id)) {
      issues.push(`areas.items の id「${area.id}」が重なっています`);
    }
    areaIds.add(area.id);
  }

  content.flow.steps.forEach((step, index) => {
    requireText(issues, `flow.steps[${index}] の title`, step.title);
    requireText(issues, `flow「${step.title}」の body`, step.body);
  });
  content.voices.items.forEach((voice, index) => {
    requireText(issues, `voices.items[${index}] の who`, voice.who);
    requireText(issues, `voices「${voice.who}」の body`, voice.body);
  });
  content.faq.items.forEach((item, index) => {
    requireText(issues, `faq.items[${index}] の q`, item.q);
    requireText(issues, `faq「${item.q}」の a`, item.a);
  });
  requireText(issues, "contact.lead", content.contact.lead);

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}

const ADVISORY_UNITS: AdvisoryUnit[] = ["month", "year", "spot"];

export function validateProfessional(content: ProfessionalContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.title", content.hero.title);
  requireText(issues, "hero.lead", content.hero.lead);
  requireText(issues, "hero.fine", content.hero.fine);
  requireText(issues, "headerCta.label", content.headerCta.label);

  checkHeadings(issues, {
    issues: content.issues,
    services: content.services,
    pricing: content.pricing,
    flow: content.flow,
    cases: content.cases,
    faq: content.faq,
    contact: content.contact,
  });

  requireText(issues, "navLabel", content.navLabel);
  content.nav.forEach((link, index) => {
    requireText(issues, `nav[${index}].label`, link.label);
  });
  checkAnchors(
    issues,
    [
      ...content.nav,
      content.headerCta,
      content.hero.primary,
      content.hero.secondary,
    ],
    [
      content.issues.id,
      content.services.id,
      content.pricing.id,
      content.flow.id,
      content.cases.id,
      content.faq.id,
      content.contact.id,
    ],
  );

  content.issues.items.forEach((item, index) => {
    requireText(issues, `issues.items[${index}] の title`, item.title);
    requireText(issues, `issues「${item.title}」の body`, item.body);
  });
  content.services.items.forEach((item, index) => {
    requireText(issues, `services.items[${index}] の title`, item.title);
    requireText(issues, `services「${item.title}」の body`, item.body);
  });

  requireText(issues, "pricing.switchLabel", content.pricing.switchLabel);
  requireText(issues, "pricing.yearlyLabel", content.pricing.yearlyLabel);
  requireText(issues, "pricing.spotNote", content.pricing.spotNote);
  requireText(issues, "pricing.note", content.pricing.note);
  for (const unit of ADVISORY_UNITS) {
    requireText(
      issues,
      `pricing.unitLabels.${unit}`,
      content.pricing.unitLabels[unit],
    );
  }
  if (content.pricing.plans.length === 0) issues.push("pricing.plans が空です");
  const planIds = new Set<string>();
  for (const plan of content.pricing.plans) {
    requireText(issues, `pricing.plans「${plan.id}」の name`, plan.name);
    requireText(issues, `pricing.plans「${plan.name}」の audience`, plan.audience);
    requireText(issues, `pricing.plans「${plan.name}」の note`, plan.note);
    if (plan.includes.length === 0) {
      issues.push(`pricing.plans「${plan.name}」の includes が空です`);
    }
    if (plan.lines.length === 0) {
      issues.push(`pricing.plans「${plan.name}」の lines が空です`);
    }
    for (const line of plan.lines) {
      requireText(
        issues,
        `pricing.plans「${plan.name}」の lines の label`,
        line.label,
      );
      if (!Number.isInteger(line.price) || line.price <= 0) {
        issues.push(
          `pricing.plans「${plan.name}」の lines「${line.label}」の price は 1 以上にします`,
        );
      }
    }
    if (planIds.has(plan.id)) {
      issues.push(`pricing.plans の id「${plan.id}」が重なっています`);
    }
    planIds.add(plan.id);
  }

  content.flow.steps.forEach((step, index) => {
    requireText(issues, `flow.steps[${index}] の title`, step.title);
    requireText(issues, `flow「${step.title}」の body`, step.body);
  });

  requireText(issues, "cases.labels.industry", content.cases.labels.industry);
  requireText(issues, "cases.labels.issue", content.cases.labels.issue);
  requireText(issues, "cases.labels.result", content.cases.labels.result);
  requireText(issues, "cases.note", content.cases.note);
  content.cases.items.forEach((item, index) => {
    requireText(issues, `cases.items[${index}] の industry`, item.industry);
    requireText(issues, `cases.items[${index}] の issue`, item.issue);
    requireText(issues, `cases.items[${index}] の result`, item.result);
  });

  content.faq.items.forEach((item, index) => {
    requireText(issues, `faq.items[${index}] の q`, item.q);
    requireText(issues, `faq「${item.q}」の a`, item.a);
  });
  requireText(issues, "contact.lead", content.contact.lead);

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}

const MARKS: Mark[] = ["open", "short", "closed"];

export function validateClinic(content: ClinicContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  checkMeta(issues, "meta", content.meta);
  requireText(issues, "hero.eyebrow", content.hero.eyebrow);
  requireText(issues, "hero.title", content.hero.title);
  requireText(issues, "hero.lead", content.hero.lead);
  requireText(issues, "hero.walk", content.hero.walk);
  requireText(issues, "hero.fine", content.hero.fine);
  if (content.hero.facts.length === 0) issues.push("hero.facts が空です");
  requireText(issues, "headerCta.label", content.headerCta.label);

  checkHeadings(issues, {
    points: content.points,
    treatments: content.treatments,
    schedule: content.schedule,
    rooms: content.rooms,
    faq: content.faq,
    reserve: content.reserve,
  });

  requireText(issues, "navLabel", content.navLabel);
  content.nav.forEach((link, index) => {
    requireText(issues, `nav[${index}].label`, link.label);
  });
  checkAnchors(
    issues,
    [
      ...content.nav,
      content.headerCta,
      content.hero.primary,
      content.hero.secondary,
    ],
    [
      content.points.id,
      content.treatments.id,
      content.schedule.id,
      content.rooms.id,
      content.faq.id,
      content.reserve.id,
    ],
  );

  // 診療時間（判定に使う表）
  issues.push(...validateSpanHours(content.hours));

  // 診療時間（掲示に出る表）
  const schedule = content.schedule;
  const standards = [
    ["morning", schedule.morning],
    ["afternoon", schedule.afternoon],
  ] as const;
  for (const [key, entry] of standards) {
    requireText(issues, `schedule.${key}.label`, entry.label);
    if (parseSpan(entry.span) === null) {
      issues.push(
        `schedule.${key}.span は { start: "9:30", end: "13:00" } の形で、start を end より前にします`,
      );
    }
  }
  requireText(issues, "schedule.caption", schedule.caption);
  requireText(issues, "schedule.columnHeader", schedule.columnHeader);
  requireText(issues, "schedule.closedNote", schedule.closedNote);
  for (const mark of MARKS) {
    requireText(issues, `schedule.marks.${mark}.symbol`, schedule.marks[mark].symbol);
    requireText(issues, `schedule.marks.${mark}.label`, schedule.marks[mark].label);
  }
  if (schedule.legend.length === 0) issues.push("schedule.legend が空です");
  schedule.legend.forEach((row, index) => {
    requireText(issues, `schedule.legend[${index}] の text`, row.text);
  });

  content.points.items.forEach((item, index) => {
    requireText(issues, `points.items[${index}] の title`, item.title);
    requireText(issues, `points「${item.title}」の body`, item.body);
  });
  content.treatments.items.forEach((item, index) => {
    requireText(issues, `treatments.items[${index}] の title`, item.title);
    requireText(issues, `treatments「${item.title}」の body`, item.body);
  });
  content.rooms.items.forEach((item, index) => {
    requireText(issues, `rooms.items[${index}] の title`, item.title);
    requireText(issues, `rooms「${item.title}」の body`, item.body);
  });
  content.faq.items.forEach((item, index) => {
    requireText(issues, `faq.items[${index}] の q`, item.q);
    requireText(issues, `faq「${item.q}」の a`, item.a);
  });

  requireText(issues, "reserve.lead", content.reserve.lead);
  requireText(issues, "reserve.note", content.reserve.note);

  checkForm(issues, content.form);
  checkFooter(issues, content.footer);
  return issues;
}

/** "/corporate/services/" のように、前後をスラッシュで囲んだ面の場所か */
function checkPagePath(issues: string[], label: string, href: string): void {
  if (!href.startsWith("/") || !href.endsWith("/")) {
    issues.push(
      `${label} は "/corporate/" のように前後をスラッシュで囲みます`,
    );
  }
}

/**
 * 会社案内サイトにある 4 枚の面。ヘッダーの nav はこの中から選ぶ。
 * 面を足したときは app/corporate/<名前>/page.tsx と一緒に、ここにも足す。
 */
export const CORPORATE_PAGES = [
  "/corporate/",
  "/corporate/services/",
  "/corporate/company/",
  "/corporate/contact/",
];

export function validateCorporate(content: CorporateContent): string[] {
  const issues: string[] = [];
  requireText(issues, "brand", content.brand);
  requireText(issues, "navLabel", content.navLabel);
  if (content.nav.length === 0) issues.push("nav が空です");
  const navHrefs = new Set<string>();
  content.nav.forEach((link, index) => {
    requireText(issues, `nav[${index}] の label`, link.label);
    checkPagePath(issues, `nav「${link.label}」の href`, link.href);
    // 形が整っているものだけ、実際にある 4 枚の面とつき合わせる
    if (
      link.href.startsWith("/") &&
      link.href.endsWith("/") &&
      !CORPORATE_PAGES.includes(link.href)
    ) {
      issues.push(
        `nav「${link.label}」の href「${link.href}」に合う面がありません。面を足したときは content/validate.ts の CORPORATE_PAGES にも足します`,
      );
    }
    if (navHrefs.has(link.href)) {
      issues.push(`nav の href「${link.href}」が重なっています`);
    }
    navHrefs.add(link.href);
  });

  // 三つの柱（TOP と事業内容の面が分け合う）
  if (content.pillars.length === 0) issues.push("pillars が空です");
  const pillarIds = new Set<string>();
  for (const pillar of content.pillars) {
    requireText(issues, `pillars「${pillar.id}」の name`, pillar.name);
    requireText(issues, `pillars「${pillar.name}」の summary`, pillar.summary);
    requireText(issues, `pillars「${pillar.name}」の body`, pillar.body);
    if (pillar.steps.length === 0) {
      issues.push(`pillars「${pillar.name}」の steps が空です`);
    }
    if (pillar.gear.length === 0) {
      issues.push(`pillars「${pillar.name}」の gear が空です`);
    }
    if (pillarIds.has(pillar.id)) {
      issues.push(`pillars の id「${pillar.id}」が重なっています`);
    }
    pillarIds.add(pillar.id);
  }

  // TOP
  const home = content.home;
  checkMeta(issues, "home.meta", home.meta);
  requireText(issues, "home.hero.eyebrow", home.hero.eyebrow);
  requireText(issues, "home.hero.title", home.hero.title);
  requireText(issues, "home.hero.lead", home.hero.lead);
  requireText(issues, "home.hero.primary.label", home.hero.primary.label);
  requireText(issues, "home.hero.secondary.label", home.hero.secondary.label);
  checkPagePath(issues, "home.hero.primary.href", home.hero.primary.href);
  checkPagePath(issues, "home.hero.secondary.href", home.hero.secondary.href);
  requireText(issues, "home.pillars.heading", home.pillars.heading);
  requireText(issues, "home.stats.heading", home.stats.heading);
  requireText(issues, "home.news.heading", home.news.heading);
  requireText(issues, "home.cta.title", home.cta.title);
  requireText(issues, "home.cta.body", home.cta.body);
  requireText(issues, "home.cta.link.label", home.cta.link.label);
  checkPagePath(issues, "home.cta.link.href", home.cta.link.href);

  if (home.stats.items.length === 0) issues.push("stats.items が空です");
  const statIds = new Set<string>();
  home.stats.items.forEach((stat, index) => {
    requireText(issues, `stats.items[${index}] の label`, stat.label);
    requireText(issues, `stats.items[${index}] の unit`, stat.unit);
    if (!Number.isInteger(stat.value) || stat.value < 1) {
      issues.push(`stats.items「${stat.id}」の value は 1 以上の整数にします`);
    }
    if (statIds.has(stat.id)) {
      issues.push(`stats.items の id「${stat.id}」が重なっています`);
    }
    statIds.add(stat.id);
  });

  if (home.news.items.length === 0) issues.push("news.items が空です");
  const newsIds = new Set<string>();
  const dates: string[] = [];
  for (const item of home.news.items) {
    requireText(issues, `news.items「${item.id}」の title`, item.title);
    requireText(issues, `news.items「${item.id}」の tag`, item.tag);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(item.date)) {
      issues.push(
        `news.items「${item.title}」の date は "2026-08-27" の形で書きます`,
      );
    }
    if (newsIds.has(item.id)) {
      issues.push(`news.items の id「${item.id}」が重なっています`);
    }
    newsIds.add(item.id);
    dates.push(item.date);
  }
  const sorted = [...dates].sort().reverse();
  if (dates.join() !== sorted.join()) {
    issues.push("news.items は新しい順に並べます");
  }

  // 事業内容
  checkMeta(issues, "services.meta", content.services.meta);
  requireText(issues, "services.title", content.services.title);
  requireText(issues, "services.lead", content.services.lead);
  requireText(issues, "services.flowTitle", content.services.flowTitle);
  requireText(issues, "services.gearTitle", content.services.gearTitle);

  // 会社概要
  const company = content.company;
  checkMeta(issues, "company.meta", company.meta);
  requireText(issues, "company.title", company.title);
  requireText(issues, "company.lead", company.lead);
  requireText(issues, "company.profile.heading", company.profile.heading);
  requireText(issues, "company.profile.note", company.profile.note);
  if (company.profile.rows.length === 0) {
    issues.push("company.profile.rows が空です");
  }
  company.profile.rows.forEach((row, index) => {
    requireText(issues, `company.profile.rows[${index}] の term`, row.term);
    requireText(issues, `company.profile「${row.term}」の body`, row.body);
  });
  requireText(issues, "company.history.heading", company.history.heading);
  company.history.rows.forEach((row, index) => {
    requireText(issues, `company.history.rows[${index}] の year`, row.year);
    requireText(issues, `company.history「${row.year}」の body`, row.body);
  });
  requireText(issues, "company.policies.heading", company.policies.heading);
  company.policies.items.forEach((policy, index) => {
    requireText(issues, `company.policies.items[${index}] の title`, policy.title);
    requireText(issues, `company.policies「${policy.title}」の body`, policy.body);
  });

  // お問い合わせ
  const contact = content.contact;
  checkMeta(issues, "contact.meta", contact.meta);
  requireText(issues, "contact.title", contact.title);
  requireText(issues, "contact.lead", contact.lead);
  requireText(issues, "contact.heading", contact.heading);
  requireText(issues, "contact.intro", contact.intro);
  contact.hours.forEach((row, index) => {
    requireText(issues, `contact.hours[${index}] の term`, row.term);
    requireText(issues, `contact.hours「${row.term}」の body`, row.body);
  });
  checkForm(issues, contact.form);

  checkFooter(issues, content.footer);
  return issues;
}
