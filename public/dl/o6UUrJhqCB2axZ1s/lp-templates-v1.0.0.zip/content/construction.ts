import type { ConstructionContent } from "./types";

/**
 * 建設・工事の LP の全文。
 * 初期値は架空の設備工事会社「灯月設備」。公開する前に自分のものへ差し替える。
 * 色は styles/tokens.css の .theme-construction にある。
 */
export const construction: ConstructionContent = {
  brand: "灯月設備",
  meta: {
    title: "灯月設備 ｜ 水まわりと電気の修理・小工事",
    description:
      "蛇口のにじみ、動かないコンセント、効かないエアコン。当日うかがって、お見積もりを無料でお出しします。受付は 8:00 - 20:00、年中無休です。",
  },
  nav: [
    { label: "対応メニュー", href: "#menu" },
    { label: "料金", href: "#price" },
    { label: "流れ", href: "#flow" },
    { label: "よくある質問", href: "#faq" },
  ],
  navLabel: "ページ内",
  call: {
    phone: "000-0000-0000",
    headerLabel: "電話する",
    heroLabel: "いますぐ電話する",
    heroSub: "受付 8:00 - 20:00",
  },
  hero: {
    eyebrow: "水道・電気・空調の修理と小工事",
    title: "水まわりと電気のお困りごと、当日うかがいます",
    lead: "蛇口のにじみ、動かないコンセント、効かないエアコン。そのままにしておくと、修理にかかる費用は増えていきます。まずは点検とお見積もりだけでもご依頼ください。直すかどうかは、金額をご覧になってからお決めいただけます。お見積もりは無料です。",
    facts: [
      "受付 8:00 - 20:00（年中無休）",
      "対応エリア：営業所から車で 30 分まで",
    ],
    secondary: { label: "フォームで相談する", href: "#contact" },
    fine: "お見積もり後にお断りいただいても、費用はかかりません。夜間と休日も受け付けております。",
    fieldCount: 70,
  },
  services: {
    id: "menu",
    heading: "こんな作業を承っています",
    items: [
      {
        id: "leak",
        name: "水漏れの修理",
        from: 8800,
        note: "蛇口や排水管、トイレのにじみを止めます。部品の交換が必要な場合は別途部品代がかかります。",
        icon: "leak",
      },
      {
        id: "clog",
        name: "排水の詰まり抜き",
        from: 11000,
        note: "台所や洗面所、トイレの詰まりを取り除きます。高圧洗浄が必要な場合は別途費用がかかります。",
        icon: "clog",
      },
      {
        id: "water-heater",
        name: "給湯器の交換",
        from: 88000,
        note: "給湯器本体代と設置工事費を合わせた金額です。給湯器の号数（大きさ）と設置場所で変わります。在庫のある型なら、その日のうちに交換できます。",
        icon: "water-heater",
      },
      {
        id: "outlet",
        name: "コンセントの増設",
        from: 16500,
        note: "壁の中に配線を通して増設します。壁を壊さずに工事できる場合が多いです。",
        icon: "outlet",
      },
      {
        id: "panel",
        name: "分電盤の交換",
        from: 44000,
        note: "ブレーカーがよく落ちるお住まいにおすすめです。作業は半日で終わります。",
        icon: "panel",
      },
      {
        id: "aircon",
        name: "エアコンの取り付け",
        from: 14300,
        note: "標準工事の金額です。配管が 4 m を超える場合は追加費用がかかります。",
        icon: "aircon",
      },
    ],
    note: "金額はすべて税込みです。現場を拝見してから正式なお見積もりを提示いたします。",
  },
  price: {
    id: "price",
    heading: "料金の目安",
    lead: "作業の代金は、この目安に部品代と作業時間分を加えた金額です。時間帯を切り替えてご確認ください。",
    nightRate: 1.5,
    toggleLabel: "時間帯",
    weekdayLabel: "平日（昼）",
    nightLabel: "夜間・休日",
    weekdayNote:
      "平日の 8 時から 18 時までの金額です。18 時以降と土日祝は 5 割増になります。",
    nightNote:
      "夜間・休日は 18 時以降と、土日祝の扱いです。基本料金と出張費が 5 割増になります。",
    freeLabel: "無料",
    rows: [
      {
        id: "trip",
        label: "出張費（片道 15 km まで）",
        weekday: 2200,
        surcharged: true,
        note: "対応エリアの外は、1 km ごとに 110 円を加算いたします。",
      },
      {
        id: "base",
        label: "基本料金（作業 30 分まで）",
        weekday: 5500,
        surcharged: true,
        note: "30 分を超えた分は、15 分ごとに 2,750 円です。",
      },
      {
        id: "estimate",
        label: "見積もり",
        weekday: 0,
        surcharged: false,
        note: "作業の前に金額をお出しします。お見積もり後にお断りいただいても、費用はかかりません。",
      },
    ],
  },
  areas: {
    id: "area",
    heading: "対応エリア",
    lead: "営業所から車で 30 分の範囲",
    items: [
      { id: "center", label: "市の中心部", radius: 0.28, angle: 20 },
      { id: "north", label: "北側の住宅地", radius: 0.62, angle: 340 },
      { id: "east", label: "川の東側", radius: 0.55, angle: 95 },
      { id: "station", label: "駅から車で 20 分まで", radius: 0.42, angle: 200 },
      { id: "next-city", label: "となりの市（一部）", radius: 0.9, angle: 250 },
      { id: "hill", label: "山側の集落（要相談）", radius: 0.86, angle: 130 },
    ],
    note: "対応エリアの外でも、出張費をいただければうかがえます。まずはお電話でご相談ください。",
  },
  flow: {
    id: "flow",
    heading: "作業の流れ",
    steps: [
      {
        title: "お電話でお聞きします",
        body: "症状と場所、建物の種類をお聞かせください。その場でおおよその金額をお伝えできることもあります。",
      },
      {
        title: "訪問して点検します",
        body: "お約束の時間にうかがい、原因を調べます。床下や壁の中まで確認いたします。",
      },
      {
        title: "お見積もりをお出しします",
        body: "金額を記した見積書をお渡しします。この時点でお断りいただいても、費用はかかりません。",
      },
      {
        title: "作業にとりかかります",
        body: "その場でできる作業は当日中に終わらせます。部材の取り寄せが必要なときは、日を改めてうかがいます。",
      },
    ],
  },
  voices: {
    id: "voice",
    heading: "お客様の声",
    items: [
      {
        who: "S 様（戸建て）",
        body: "夜に水が止まらなくなって電話しました。1 時間ほどで来てくれて、その場で直りました。",
      },
      {
        who: "K 様（集合住宅の管理）",
        body: "見積書を先に出してくれるので、入居者の方に説明しやすいです。相見積もりを取ったうえで、お願いしています。",
      },
      {
        who: "T 様（飲食店）",
        body: "換気扇とコンセントをまとめてお願いしました。開店前に終わらせてもらえました。",
      },
    ],
  },
  faq: {
    id: "faq",
    heading: "よくある質問",
    items: [
      {
        q: "お見積もりは無料ですか。",
        a: "無料です。作業の前に金額をお出しし、お断りいただいても費用はかかりません。お見積もりだけのご依頼なら、出張費もいただきません。",
      },
      {
        q: "当日でも来てもらえますか。",
        a: "午前中にご連絡いただければ、その日のうちにうかがえることが多いです。混み合っている日は翌日のご案内になります。",
      },
      {
        q: "夜間や休日も対応していますか。",
        a: "20 時まで受け付けております。18 時以降と土日祝は、基本料金と出張費が 5 割増になります。",
      },
      {
        q: "支払いはどうすればいいですか。",
        a: "作業が終わったあと、現金またはクレジットカードでお支払いいただけます。法人のお客様には請求書でのお支払いも承ります。",
      },
      {
        q: "賃貸でも頼めますか。",
        a: "承ります。ただし設備の交換は、大家さんか管理会社へ先にご確認をお願いしております。",
      },
    ],
  },
  contact: {
    id: "contact",
    heading: "電話がつながらないときは、こちらから",
    lead: "症状と場所をご記入いただければ、折り返しご連絡いたします。夜間にいただいたご相談は、翌朝 8 時から順にお返事いたします。",
  },
  form: {
    fields: [
      { name: "name", label: "お名前", required: true },
      {
        name: "tel",
        label: "電話番号",
        type: "tel",
        required: true,
        placeholder: "ハイフンありでご記入ください",
      },
      {
        name: "city",
        label: "お住まいの市区町村",
        required: true,
        placeholder: "例: ◯◯市◯◯町",
      },
      {
        name: "trouble",
        label: "お困りの内容",
        type: "textarea",
        required: true,
        placeholder: "例: 台所の蛇口から水がしたたり続けています",
      },
      {
        name: "when",
        label: "ご希望の日時",
        placeholder: "例: 明日の午前中 / 今日の 18 時以降",
      },
    ],
    submitLabel: "この内容で相談する",
    endpoint: "",
    contentType: "json",
    honeypot: "homepage",
    messages: {
      sample:
        "送信されました（見本の表示です。送信先を設定するまで、実際には送られません）。",
      sending: "送信しています…",
      success: "ご相談を受け付けました。折り返しご連絡いたします。",
      failure: "送信できませんでした。時間をおいて、もう一度お試しください。",
    },
  },
  footer: {
    company: "灯月設備",
    entity: "会社",
    address: "〒000-0000 ○○県○○市○○ 1-2-3",
    email: "hello@example.com",
    tel: "000-0000-0000",
    copyright: "© 2026 灯月設備",
  },
};
