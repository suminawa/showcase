# 業種別 LP テンプレ パック v1.0.0

写真を 1 枚も使わずに公開できる、1 ページ LP のテンプレートが 2 本入っています。色と余白と書体、それに canvas の粒だけで作ってあるので、素材を用意しなくてもその日のうちに出せます。

| テンプレ | 想定する業種 | ページ | 入っている節 |
|---|---|---|---|
| BtoB・SaaS の LP | SaaS・受託・BtoB サービス | `/saas` | 課題・機能・料金（月額／年額の切替）・導入の流れ・FAQ・問い合わせフォーム |
| 店舗・サロンの LP | 飲食・美容・教室・サロン | `/shop` | こだわり・お品書き・席・行き方・予約フォーム・営業時間の「いまは開いています」 |

`/` は 2 本を見比べるための一覧ページです。公開するときは消すか、自分のトップページに書き換えてください（`app/page.tsx`）。

初期値に入っている「Tabane Works」「粉とゆげ」は、どちらも架空の名前です。そのまま公開しないでください。

## 動かす

Node.js 20.9 以上が要ります。

```bash
npm install
npm run dev     # http://localhost:3020
```

| コマンド | すること |
|---|---|
| `npm run dev` | 手元で開く |
| `npm test` | 文言の抜け、営業時間の形式、料金の計算、フォーム送信の筋道を確かめる |
| `npm run build` | `out/` に HTML を書き出す |
| `npm run lint` | 書き方の検査 |
| `npm run typecheck` | 型の検査。先に `npm run build` を 1 回通してください（土台になる `next-env.d.ts` が、そのときに作られます） |

## 置き方

### Vercel に置く
GitHub に上げたリポジトリを Vercel につなぐだけです。Framework は Next.js のまま、変えるところはありません。

### 静的サーバーに置く（HTML だけ欲しいとき）
`npm run build` でできる `out/` の中身を、そのままサーバーの公開フォルダに上げます。zip には書き出し済みの `out/` も入っているので、Node.js を用意せずに上げることもできます。

同梱の `out/` は、見本の文言のまま書き出してあります（「Tabane Works」「粉とゆげ」、公開 URL は `https://example.com`、フォームの送信先は空）。自分のものに直すには、`content/` を書き換えて `npm run build` をやり直すか、`out/index.html`・`out/saas/index.html`・`out/shop/index.html` の 3 枚を直接書き換えます。ただし `form.endpoint` は HTML に埋め込まれた JSON の中に、`site.url` は `og:url` などの meta に入っています。この二つは `content/` を直して書き出し直すほうが確実です。

```
out/
├── index.html        /
├── saas/index.html   /saas
├── shop/index.html   /shop
└── _next/            CSS・JS・書体
```

`_next/` を一緒に上げないと、見た目と動きが付きません。

`out/` は全体で約 13 MB あります。その大半は `_next/static/media/` に入った Google Fonts の書体ファイルです。書体は字の範囲ごとに細かく分かれているので、見る人が受け取るのは、そのページに出た字を含むいくつかだけです。

### サブディレクトリに置くとき
`https://example.com/lp/` のように下の階層へ置くなら、`next.config.ts` に `basePath` を足してから書き出し直します。

```ts
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
  basePath: "/lp",
};
```

## 文言を書き換える（content/）

触るのは `content/` の 3 ファイルだけです。ページの `.tsx` に文字は入っていません。

| ファイル | 中身 |
|---|---|
| `content/saas.ts` | BtoB・SaaS の LP の全文 |
| `content/shop.ts` | 店舗・サロンの LP の全文 |
| `content/site.ts` | 公開する URL と、一覧ページ（/）の文 |

型と項目の意味は `content/types.ts` に書いてあります。編集中もエディタが項目名を教えてくれます。

### 両方に共通の項目

| 項目 | 意味 |
|---|---|
| `brand` | ヘッダーと見出しに出る名前 |
| `meta.title` / `meta.description` | タブ・検索結果・共有カードに出る文字 |
| `hero.*` | 一番上の大きな文。`fieldCount` は背景の粒の数（0 で粒なし） |
| `form.*` | 入力欄と送信先（下の「フォームの送信先」を見てください） |
| `footer.*` | 会社名・住所・メール・電話・著作権表示。`tel` を空にするとその行を出しません |

各節の `id`（`"pricing"` など）は、ページ内リンクの飛び先です。`nav` の `href`（`"#pricing"`）とそろえてください。ずれていると `npm test` が教えます。

### BtoB・SaaS だけの項目

| 項目 | 意味 |
|---|---|
| `nav` / `headerCta` | 上の帯のリンクとボタン |
| `issues.items` | 課題。3 つ並びます |
| `features.items` | 機能。`icon` は `"screen"` `"clock"` `"export"` のどれか |
| `pricing.plans` | 料金。`monthly` は 1 人あたりの月額。`recommended: true` の 1 つに「おすすめ」が付きます |
| `pricing.yearlyDiscount` | 年額払いの割引率。`0.2` なら 20% 引き |
| `flow.steps` | 導入の流れ。`time` を空にすると所要時間を出しません |
| `faq.items` | よくある質問 |

`yearlyDiscount` を変えたときは、`yearlyLabel`（「年額払い（20% 引き）」）と `monthlyNote`（「年額払いは 20% 引きです。」）の数字も直してください。文言は自動では変わりません。

絵を増やすときは、`content/types.ts` の `FeatureIcon` に名前を足して、`components/FeatureIcon.tsx` に形（線だけの SVG）を足します。

### 店舗・サロンだけの項目

| 項目 | 意味 |
|---|---|
| `hours.closedDays` | 定休日。0 = 日曜 … 6 = 土曜。`[1, 2, 3]` で月・火・水が休み |
| `hours.open` / `close` / `lastOrder` | `"10:00"` の形。`lastOrder` を空にすると括弧ごと出しません |
| `hours.openLabel` / `closedLabel` | 「いまは開いています」「いまは閉まっています」の文言 |
| `menu.groups` / `menu.items` | お品書き。`items` の `category` は `groups` の `category` と同じ字にします |
| `points` / `seats` / `access` | こだわり・席・行き方 |

営業時間の一行（「木・金・土・日 10:00 - 18:00（ラストオーダー 17:30）」「定休日：月・火・水」）は `hours` から組み立てます。組み立て方そのものを変えるなら `lib/hours.ts` です。

「いまは開いています」は、画面が出てから 1 分ごとに見直します。静的な HTML に焼き付けると「書き出した時刻の営業中」が貼り付いてしまうので、そうしていません。

## 色を変える（styles/tokens.css）

色・角丸・書体は、この 1 ファイルにまとまっています。`.theme-saas` と `.theme-shop` が、それぞれのテンプレの組です。

| 変数 | どこの色か |
|---|---|
| `--d-bg` | 地 |
| `--d-fg` | 本文の字 |
| `--d-muted` | 補助の字（小さい説明文） |
| `--d-brand` | ブランド色。ボタン・見出しの飾り |
| `--d-brand-ink` | ブランド色の濃いほう。ホバーと輪郭 |
| `--d-line` | 罫線・枠 |
| `--d-soft` | 一段沈めた節の地 |
| `--d-surface` | カード・入力欄の面 |
| `--d-on-brand` | ブランド色の上に載せる字 |
| `--d-input-line` | 入力欄の枠線。地の色に対して 3:1 以上にします |
| `--d-field-rgb` | ヒーローの粒の色。`31, 94, 255` のように R, G, B を並べて書きます |
| `--d-hero-a` / `--d-hero-b` | SaaS のヒーローに敷く光 |
| `--d-wash-a` / `-b` / `-c` | 店舗のヒーローの、ゆっくり動く濃淡 |
| `--d-serif` | 店舗の見出しの明朝。`.theme-shop` にだけあります |
| `--index-paper` | 一覧ページ（/）の地。`:root` にあります |
| `--radius-card` ほか | 角丸 |

`--d-bg` を変えたら、同じ値を `:root` の `--saas-paper` / `--shop-paper` にも書いてください。画面を引っ張ったときに出る余白の色です。

字は `--font-sans`。別の書体にするなら `app/layout.tsx` の `Noto_Sans_JP` を差し替えます（店舗テンプレの見出しの明朝は `app/shop/page.tsx` の `Shippori_Mincho`）。

色を変えたら、字と地のコントラストを確かめてください。`styles/tokens.css` の括弧の中に、いまの比率を書いてあります。本文は 4.5:1 以上が目安です。

## フォームの送信先

`content/saas.ts`（または `shop.ts`）の `form.endpoint` に URL を書くと、そこへ JSON を POST します。空のままなら送信せず、`form.messages.sample` の文言を出します。

```ts
form: {
  endpoint: "",          // ← ここに URL を書く
  contentType: "json",   // "json" か "text"
  messages: {
    sample: "…",   // endpoint が空のときに出る
    sending: "…",  // 送っている間
    success: "…",  // 送れたとき
    failure: "…",  // 送れなかったとき
  },
}
```

送る中身は、入力欄の `name` をそのまま鍵にした JSON です。

```json
{ "company": "株式会社〇〇", "email": "you@example.com", "message": "…" }
```

### 迷惑投稿よけの、見えない欄

`form.honeypot` に name を書くと、画面に出ない入力欄が 1 つ増えます（初期値は `homepage`）。人の目には入らないので空のままですが、フォームを機械的に埋める bot はここにも字を入れます。字が入っていたときは、送信せずに成功の文言だけ出します。画面の見え方が変わらないので、bot は弾かれたことに気づきません。この欄は、送る JSON には入りません。name を変えるなら `content/*.ts` の `honeypot` を書き換え、使わないなら空にします。

### Google Apps Script のウェブアプリで受ける

1. Google スプレッドシートを作り、拡張機能 → Apps Script を開きます。
2. 下のコードを貼ります（宛先は自分のアドレスに直します）。

```js
function doPost(e) {
  var data = JSON.parse(e.postData.contents);
  var keys = Object.keys(data);
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  sheet.appendRow([new Date()].concat(keys.map(function (key) { return data[key]; })));
  MailApp.sendEmail({
    to: "宛先@example.com",
    subject: "LP から問い合わせが届きました",
    body: keys.map(function (key) { return key + ": " + data[key]; }).join("\n"),
  });
  return ContentService.createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}
```

3. 「デプロイ」→「新しいデプロイ」→ 種類は **ウェブアプリ**、実行するユーザーは **自分**、アクセスできるユーザーは **全員**。
4. 出てきた URL を `form.endpoint` に貼り、`contentType` を `"text"` にします。

`"text"` にするのは、`application/json` で送るとブラウザが先に許可を問い合わせ（プリフライト）、Apps Script がそれに答えられないからです。送る中身はどちらも同じ JSON で、`e.postData.contents` から読めます。

### Formspree で受ける
Formspree で作ったフォームの URL（`https://formspree.io/f/xxxxxxx`）を `endpoint` に入れ、`contentType` は `"json"` のままにします。

### 自前の API で受ける
POST で JSON を受け取れれば何でも構いません。LP と別のドメインに置くときは、CORS の設定が要ります。

`contentType` が `"json"` のとき、ブラウザは POST の前に `OPTIONS` で許可を問い合わせます（プリフライト）。サーバーは `OPTIONS` にも応答し、次の三つを返してください。

- `Access-Control-Allow-Origin`: LP を公開するドメイン
- `Access-Control-Allow-Methods: POST`
- `Access-Control-Allow-Headers: Content-Type`

`contentType` を `"text"` にすると、この問い合わせ自体が起きません（Apps Script で `"text"` を使うのと同じ理由です）。POST の返事に `Access-Control-Allow-Origin` を付けるだけで済みます。

返事が 200 番台でないとき、通信そのものが失敗したときは `messages.failure` を出します。送信中はボタンを押せなくなります。

## 公開する前に直すところ

- `content/site.ts` の `url` を、自分が公開する URL に（末尾のスラッシュなし）
- `content/*.ts` の `footer`（会社名・住所・メール・電話・著作権表示）を自分のものに
- `form.endpoint` を設定する（空のままだと、送信されずに見本の文言が出ます）
- ファビコン（`app/icon.svg`）を自分のものにする
- `app/page.tsx`（一覧ページ）を消すか、自分のトップに書き換える
- 「Tabane Works」「粉とゆげ」を残さない
- 共有カードの画像（`og:image`）は同梱していません。要るなら `app/opengraph-image.tsx` を足すと、写真を使わずに作れます（書き方は Next.js の説明にあります）

直したら `npm test` を 1 回通してください。抜けと形式の崩れはここで見つかります。

## ライセンス

全文は LICENSE.md にあります。要約すると、購入したご本人（購入が組織なら、その組織の案件）で自由に使えます。クライアントのサイトに組み込んで納品することもできます。禁止しているのは、このファイル一式の再配布・転売・共有と、同種の商品としての販売です。

## 困ったら

hello@suminawa.dev（購入者の質問には 3 営業日以内に返信します）
