# 業種別 LP テンプレ パック v1.0.0

写真を 1 枚も使わずに公開できる 1 ページ LP が 5 本と、4 ページの会社案内サイトが 1 式入っています。色と余白と書体、それに canvas の粒と SVG だけで作ってあるので、素材を用意しなくてもその日のうちに出せます。

| テンプレ | 想定する業種 | ページ | 入っている節 |
|---|---|---|---|
| BtoB・SaaS の LP | SaaS・受託・BtoB サービス | `/saas` | 課題・機能・料金（月額／年額の切替）・導入の流れ・FAQ・問い合わせフォーム |
| 店舗・サロンの LP | 飲食・美容・教室・サロン | `/shop` | こだわり・お品書き・席・行き方・予約フォーム・営業時間の「いまは開いています」 |
| 建設・工事の LP | 設備工事・リフォーム・水道・電気 | `/construction` | 対応メニュー・料金の目安（平日／夜間・休日の切替）・対応エリアの図・作業の流れ・お客様の声・FAQ・相談フォーム・電話の CTA |
| 士業・研修の LP | 税理士・社労士・行政書士・研修 | `/professional` | こまりごと・三つのサービス・顧問料（プランの切替）・流れ・これまでの例・FAQ・相談フォーム |
| クリニック・医院の LP | 歯科・内科・整骨院・動物病院 | `/clinic` | 特長・診療内容・診療時間の表・院内のご案内・FAQ・Web 予約フォーム・「いまは診療中です」 |
| 会社案内サイト | 製造・建設・調査・BtoB | `/corporate` ほか 3 枚 | TOP（三つの柱・数字の数え上げ・お知らせ）・事業内容・会社概要と沿革・お問い合わせ |

会社案内サイトだけは 4 ページです。ページと content の対応は「会社案内だけの項目」を見てください。

`/` は 6 つを見比べるための一覧ページです。公開するときは消すか、自分のトップページに書き換えてください（`app/page.tsx`）。

初期値に入っている「Tabane Works」「粉とゆげ」「灯月設備」「霜月会計事務所」「月白歯科クリニック」「潮見計測」は、すべて架空の名前です。そのまま公開しないでください。

## 動かす

Node.js 20.9 以上が要ります。

```bash
npm install
npm run dev     # http://localhost:3020
```

| コマンド | すること |
|---|---|
| `npm run dev` | 手元で開く |
| `npm test` | 文言の抜け、営業時間の形式、料金の計算、フォーム送信の筋道を確かめる |
| `npm run build` | `out/` に HTML を書き出す |
| `npm run lint` | 書き方の検査 |
| `npm run typecheck` | 型の検査。先に `npm run build` を 1 回通してください（土台になる `next-env.d.ts` が、そのときに作られます） |

## 置き方

### Vercel に置く
GitHub に上げたリポジトリを Vercel につなぐだけです。Framework は Next.js のまま、変えるところはありません。

### 静的サーバーに置く（HTML だけ欲しいとき）
`npm run build` でできる `out/` の中身を、そのままサーバーの公開フォルダに上げます。zip には書き出し済みの `out/` も入っているので、Node.js を用意せずに上げることもできます。

同梱の `out/` は、見本の文言のまま書き出してあります（社名は上の 6 つの架空名、公開 URL は `https://example.com`、フォームの送信先は空）。自分のものに直すには、`content/` を書き換えて `npm run build` をやり直すか、`out/**/index.html`（全 10 ページ）を直接書き換えます。ただし `form.endpoint` は HTML に埋め込まれた JSON の中に、`site.url` は `og:url` などの meta に入っています。この二つは `content/` を直して書き出し直すほうが確実です。

```
out/
├── index.html                       /
├── saas/index.html                  /saas
├── shop/index.html                  /shop
├── construction/index.html          /construction
├── professional/index.html          /professional
├── clinic/index.html                /clinic
├── corporate/index.html             /corporate
├── corporate/services/index.html    /corporate/services
├── corporate/company/index.html     /corporate/company
├── corporate/contact/index.html     /corporate/contact
└── _next/                           CSS・JS・書体
```

`_next/` を一緒に上げないと、見た目と動きが付きません。

`out/` は全体で約 15 MB あります。その大半（13 MB ほど）は `_next/static/media/` に入った Google Fonts の書体ファイルです。書体は字の範囲ごとに細かく分かれているので、見る人が受け取るのは、そのページに出た字を含むいくつかだけです。

### サブディレクトリに置くとき
`https://example.com/lp/` のように下の階層へ置くなら、`next.config.ts` に `basePath` を足してから書き出し直します。

```ts
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
  basePath: "/lp",
};
```

## 文言を書き換える（content/）

触るのは `content/` のファイルだけです。テンプレのページの `.tsx` に文字は入っていません（一覧ページ `app/page.tsx` のカードに出る「開く →」だけは例外です。公開する前に消すか書き換えるページなので、content には出していません）。

| ファイル | 中身 |
|---|---|
| `content/saas.ts` | BtoB・SaaS の LP の全文 |
| `content/shop.ts` | 店舗・サロンの LP の全文 |
| `content/construction.ts` | 建設・工事の LP の全文 |
| `content/professional.ts` | 士業・研修の LP の全文 |
| `content/clinic.ts` | クリニック・医院の LP の全文 |
| `content/corporate.ts` | 会社案内サイト 4 ページの全文 |
| `content/site.ts` | 公開する URL と、一覧ページ（/）の文 |

型と項目の意味は `content/types.ts` に書いてあります。編集中もエディタが項目名を教えてくれます。

### どのテンプレにも共通の項目

| 項目 | 意味 |
|---|---|
| `brand` | ヘッダーと見出しに出る名前 |
| `meta.title` / `meta.description` | タブ・検索結果・共有カードに出る文字 |
| `hero.*` | 一番上の大きな文。`fieldCount` は背景の粒の数（0 で粒なし。粒を使うのは SaaS・店舗・建設） |
| `form.*` | 入力欄と送信先（下の「フォームの送信先」を見てください） |
| `footer.*` | 会社名・住所・メール・電話・著作権表示。`tel` を空にするとその行を出しません |
| `footer.entity` | 読み上げのときの呼び名（会社／事務所／医院／店）。画面には出ません。省くと「会社」になります |

入力欄（`form.fields[].type`）に使えるのは `"text"`（既定）・`"email"`・`"tel"`・`"date"`・`"number"`・`"textarea"`・`"select"` です。`"select"` のときは `options`（選択肢の配列）と `placeholder`（選ぶ前に出す字）も書きます。

各節の `id`（`"pricing"` など）は、ページ内リンクの飛び先です。`nav` の `href`（`"#pricing"`）とそろえてください。ずれていると `npm test` が教えます。

上の帯にページ内リンクを置く 4 本（BtoB・SaaS／建設・工事／士業・研修／クリニック・医院）には `navLabel` があります。リンクの組に付ける読み上げ用の名前で、画面には出ません。初期値は「ページ内」です。

### BtoB・SaaS だけの項目

| 項目 | 意味 |
|---|---|
| `nav` / `headerCta` | 上の帯のリンクとボタン |
| `issues.items` | 課題。3 つ並びます |
| `features.items` | 機能。`icon` は `"screen"` `"clock"` `"export"` のどれか |
| `pricing.plans` | 料金。`monthly` は 1 人あたりの月額。`recommended: true` の 1 つに「おすすめ」が付きます |
| `pricing.yearlyDiscount` | 年額払いの割引率。`0.2` なら 20% 引き |
| `flow.steps` | 導入の流れ。`time` を空にすると所要時間を出しません |
| `faq.items` | よくある質問 |

`yearlyDiscount` を変えたときは、`yearlyLabel`（「年額払い（20% 引き）」）と `monthlyNote`（「年額払いは 20% 引きです。」）の数字も直してください。文言は自動では変わりません。

絵を増やすときは、`content/types.ts` の `FeatureIcon` に名前を足して、`components/FeatureIcon.tsx` に形（線だけの SVG）を足します。

### 店舗・サロンだけの項目

| 項目 | 意味 |
|---|---|
| `hours.closedDays` | 定休日。0 = 日曜 … 6 = 土曜。`[1, 2, 3]` で月・火・水が休み |
| `hours.open` / `close` / `lastOrder` | `"10:00"` の形。`lastOrder` を空にすると括弧ごと出しません |
| `hours.openLabel` / `closedLabel` | 「いまは開いています」「いまは閉まっています」の文言 |
| `menu.groups` / `menu.items` | お品書き。`items` の `category` は `groups` の `category` と同じ字にします |
| `points` / `seats` / `access` | こだわり・席・行き方 |

営業時間の一行（「木・金・土・日 10:00 - 18:00（ラストオーダー 17:30）」「定休日：月・火・水」）は `hours` から組み立てます。組み立て方そのものを変えるなら `lib/hours.ts` です。

「いまは開いています」は、画面が出てから 1 分ごとに見直します。静的な HTML に焼き付けると「書き出した時刻の営業中」が貼り付いてしまうので、そうしていません。

### 建設・工事だけの項目

| 項目 | 意味 |
|---|---|
| `call.phone` | 電話の CTA の番号。**空にするとボタンを出しません**。書くと本物の `tel:` リンクになります |
| `call.headerLabel` / `heroLabel` / `heroSub` | 上の帯の小さいボタンの字／ヒーローの大きいボタンの字／その下の小さい一行 |
| `hero.facts` | ヒーローの囲みに出す箇条（受付時間・対応エリアなど）。行は増やせます |
| `services.items` | 対応メニュー。`from` は目安の下限で「8,800 円〜」と出ます。`icon` は `"leak"` `"clog"` `"water-heater"` `"outlet"` `"panel"` `"aircon"` のどれか |
| `price.rows` | 料金の行。`weekday` は平日（昼）の税込価格、`surcharged: true` の行だけ夜間・休日の割増が掛かります。`weekday: 0` の行は `freeLabel`（「無料」）と出ます |
| `price.nightRate` | 夜間・休日の割増。`1.5` で 5 割増。変えたら `weekdayNote` と `nightNote` の「5 割増」も直します |
| `areas.items` | 対応エリア。`angle` は真上を 0 度とした時計回り、`radius` は中心からの割合（0 より大きく 1 以下）。図はこの 2 つから描きます |
| `flow.steps` / `voices.items` / `faq.items` | 作業の流れ・お客様の声・よくある質問 |

`footer.tel` と `call.phone` は別の項目です。両方に同じ番号を書いてください。

### 士業・研修だけの項目

| 項目 | 意味 |
|---|---|
| `services.items` | 三つのサービス。`icon` は `"audit"` `"books"` `"training"` のどれか |
| `pricing.plans` | 顧問料のプラン。ボタンで切り替わり、選んだものだけが大きく出ます |
| `pricing.plans[].lines` | 金額の行。先頭の行だけ大きく出ます。`unit` は `"month"`（毎月）・`"year"`（年 1 回）・`"spot"`（単発） |
| `pricing.unitLabels` | 単位の字（`／月` `／年` `／回`） |
| `pricing.yearlyLabel` | 「年間の目安」の前置き。金額は `month` × 12 と `year` の合計を、こちらで計算します |
| `pricing.spotNote` | 単発だけのプランで、年間の目安の代わりに出す一行 |
| `cases.items` / `cases.labels` | これまでの例と、その行の見出し（業種・ご相談・結果） |

見出しの明朝は `app/professional/page.tsx` の `Shippori_Mincho` です。

### クリニック・医院だけの項目

| 項目 | 意味 |
|---|---|
| `hours.days` | 診療する曜日だけを並べます（休診の曜日は入れません）。`day` は 0 = 日曜 … 6 = 土曜。`morning` / `afternoon` は `{ start: "9:30", end: "13:00" }`、休みの時間帯は `null` |
| `hours.openLabel` / `closedLabel` | 「いまは診療中です」「いまは診療時間外です」の文言 |
| `schedule.morning` / `afternoon` | 表の見出しに出す**標準の**時間帯と、その呼び名（午前・午後） |
| `schedule.marks` | 表のます目の印と、その意味。印は目で読み、意味の語は読み上げに渡します |
| `schedule.legend` | 表の下の凡例。`mark` は `marks` のどれかを指します |
| `schedule.caption` / `columnHeader` | 読み上げにだけ出る説明と、左上のます目の見出し |
| `schedule.closedNote` | 「休診：木曜の午後、日曜・祝日」の一行 |
| `treatments.items` | 診療内容。`icon` は `"general"` `"kids"` `"cleaning"` `"braces"` `"whitening"` `"implant"` のどれか |
| `rooms.items` | 院内のご案内。`figure` は `"entrance"` `"rooms"` `"kids"` のどれか |

表のます目は、その曜日の時間帯を `schedule` の標準とくらべて決まります ── 同じなら `open`（●）、違えば `short`（▲）、`null` なら `closed`（−）。**時間の数字は `content/clinic.ts` の上にある 3 つの `Span` にだけ書いてあり**、ヒーローの箇条・表の見出し・凡例・予約の選択肢は、そこから組み立てています。時間を変えるときは `Span` だけを直してください。

### 会社案内だけの項目

4 ページと content の対応。

| ページ | URL | content | ファイル |
|---|---|---|---|
| TOP | `/corporate` | `corporate.home`（+ `pillars`） | `app/corporate/page.tsx` |
| 事業内容 | `/corporate/services` | `corporate.services`（+ `pillars`） | `app/corporate/services/page.tsx` |
| 会社概要 | `/corporate/company` | `corporate.company` | `app/corporate/company/page.tsx` |
| お問い合わせ | `/corporate/contact` | `corporate.contact`（フォームもここ） | `app/corporate/contact/page.tsx` |
| 共通の枠（ヘッダー・フッター） | 全ページ | `corporate.brand` `nav` `navLabel` `footer` | `app/corporate/layout.tsx` |

| 項目 | 意味 |
|---|---|
| `nav` | ヘッダーの 4 リンク。並びもこの順。`href` は `/corporate/services/` のように前後をスラッシュで囲みます。いま開いている面には下線と色が付きます |
| `pillars` | 三つの柱。TOP は `name` と `summary` だけ、事業内容の面は `body` `steps` `gear` まで使います。`icon` は `"survey"` `"monitoring"` `"analysis"` のどれか |
| `home.stats.items` | 数字。画面に入ると 0 から数え上げます（減速の設定のときは動きません） |
| `home.news.items` | お知らせ。`date` は `"2026-08-27"` の形で、**新しい順に**並べます。画面には `2026.08.27` と出ます |
| `home.cta` | 下のひと押し。`link.href` はページの場所です |
| `company.profile.rows` / `history.rows` / `policies.items` | 概要・沿革・方針 |
| `contact.hours` | 受付時間とお返事の目安 |

ページを足すときは、`content/corporate.ts` の `nav` にリンクを足して、同じ場所に `app/corporate/<名前>/page.tsx` を作ります。`content/validate.ts` の `CORPORATE_PAGES` にも、その場所を書き足します。`npm test` が `nav` の行き先をこの一覧とつき合わせるので、忘れると「合う面がありません」と出ます。

## 色を変える（styles/tokens.css）

色・角丸・書体は、この 1 ファイルにまとまっています。`.theme-saas` `.theme-shop` `.theme-construction` `.theme-professional` `.theme-clinic` `.theme-corporate` が、それぞれのテンプレの組です（`.theme-index` は一覧ページの分）。

| 変数 | どこの色か |
|---|---|
| `--d-bg` | 地 |
| `--d-fg` | 本文の字 |
| `--d-muted` | 補助の字（小さい説明文） |
| `--d-brand` | ブランド色。ボタン・見出しの飾り |
| `--d-brand-ink` | ブランド色の濃いほう。ホバーと輪郭 |
| `--d-line` | 罫線・枠 |
| `--d-soft` | 一段沈めた節の地 |
| `--d-surface` | カード・入力欄の面 |
| `--d-on-brand` | ブランド色の上に載せる字 |
| `--d-input-line` | 入力欄の枠線。地の色に対して 3:1 以上にします |
| `--d-field-rgb` | ヒーローの粒の色。`31, 94, 255` のように R, G, B を並べて書きます |
| `--d-hero-a` / `--d-hero-b` | SaaS のヒーローに敷く光 |
| `--d-wash-a` / `-b` / `-c` | 店舗のヒーローの、ゆっくり動く濃淡 |
| `--d-serif` | 見出しの明朝。`.theme-shop` と `.theme-professional` にあります |
| `--d-accent` | 飾り専用の色。`.theme-construction` にだけあります（斜めストライプ・エリアの点・脈打つ輪）。文字には使いません |
| `--index-paper` | 一覧ページ（/）の地。`:root` にあります |
| `--radius-card` ほか | 角丸 |

`--d-bg` を変えたら、同じ値を `:root` の `--saas-paper` / `--shop-paper` / `--construction-paper` / `--professional-paper` / `--clinic-paper` / `--corporate-paper` にも書いてください。画面を引っ張ったときに出る余白の色です。

`.theme-construction` の `--d-accent` と `--d-field-rgb` は同じ色です（片方は `#f07a12`、もう片方は `240, 122, 18`）。色を変えるときは両方を直してください。

字は `--font-sans`。別の書体にするなら `app/layout.tsx` の `Noto_Sans_JP` を差し替えます（見出しの明朝は `app/shop/page.tsx` と `app/professional/page.tsx` の `Shippori_Mincho`）。

色を変えたら、字と地のコントラストを確かめてください。`styles/tokens.css` の括弧の中に、いまの比率を書いてあります。本文は 4.5:1 以上が目安です。

## フォームの送信先

各テンプレの content（会社案内は `contact.form`）の `form.endpoint` に URL を書くと、そこへ JSON を POST します。空のままなら送信せず、`form.messages.sample` の文言を出します。テンプレごとに別の送信先にもできます。

送信先には、対の商品「フォーム受付 GAS キット」を使うと、`contentType: "text"` の JSON を受け取ってスプレッドシートに保存し、Slack・Discord・LINE に通知したうえで、送信した人に自動返信までできます。

```ts
form: {
  endpoint: "",          // ← ここに URL を書く
  contentType: "json",   // "json" か "text"
  messages: {
    sample: "…",   // endpoint が空のときに出る
    sending: "…",  // 送っている間
    success: "…",  // 送れたとき
    failure: "…",  // 送れなかったとき
  },
}
```

送る中身は、入力欄の `name` をそのまま鍵にした JSON です。

```json
{ "company": "株式会社〇〇", "email": "you@example.com", "message": "…" }
```

### 迷惑投稿よけの、見えない欄

`form.honeypot` に name を書くと、画面に出ない入力欄が 1 つ増えます（初期値は `homepage`）。人の目には入らないので空のままですが、フォームを機械的に埋める bot はここにも字を入れます。字が入っていたときは、送信せずに成功の文言だけ出します。画面の見え方が変わらないので、bot は弾かれたことに気づきません。この欄は、送る JSON には入りません。name を変えるなら `content/*.ts` の `honeypot` を書き換え、使わないなら空にします。

### Google Apps Script のウェブアプリで受ける

1. Google スプレッドシートを作り、拡張機能 → Apps Script を開きます。
2. 下のコードを貼ります（宛先は自分のアドレスに直します）。

```js
function doPost(e) {
  var data = JSON.parse(e.postData.contents);
  var keys = Object.keys(data);
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  sheet.appendRow([new Date()].concat(keys.map(function (key) { return data[key]; })));
  MailApp.sendEmail({
    to: "宛先@example.com",
    subject: "LP から問い合わせが届きました",
    body: keys.map(function (key) { return key + ": " + data[key]; }).join("\n"),
  });
  return ContentService.createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}
```

3. 「デプロイ」→「新しいデプロイ」→ 種類は **ウェブアプリ**、実行するユーザーは **自分**、アクセスできるユーザーは **全員**。
4. 出てきた URL を `form.endpoint` に貼り、`contentType` を `"text"` にします。

`"text"` にするのは、`application/json` で送るとブラウザが先に許可を問い合わせ（プリフライト）、Apps Script がそれに答えられないからです。送る中身はどちらも同じ JSON で、`e.postData.contents` から読めます。

### Formspree で受ける
Formspree で作ったフォームの URL（`https://formspree.io/f/xxxxxxx`）を `endpoint` に入れ、`contentType` は `"json"` のままにします。

### 自前の API で受ける
POST で JSON を受け取れれば何でも構いません。LP と別のドメインに置くときは、CORS の設定が要ります。

`contentType` が `"json"` のとき、ブラウザは POST の前に `OPTIONS` で許可を問い合わせます（プリフライト）。サーバーは `OPTIONS` にも応答し、次の三つを返してください。

- `Access-Control-Allow-Origin`: LP を公開するドメイン
- `Access-Control-Allow-Methods: POST`
- `Access-Control-Allow-Headers: Content-Type`

`contentType` を `"text"` にすると、この問い合わせ自体が起きません（Apps Script で `"text"` を使うのと同じ理由です）。POST の返事に `Access-Control-Allow-Origin` を付けるだけで済みます。

返事が 200 番台でないとき、通信そのものが失敗したときは `messages.failure` を出します。返事が 200 番台でも、本文が `{ "ok": false, "message": "…" }` なら失敗として扱い、その `message` を出します（対の商品「フォーム受付 GAS キット」が「満席です。」などを返すのは、この形です。`message` が空なら `messages.failure` を出します）。本文が JSON でなければ、そのまま成功として扱います ── Formspree や自前の API はここを通ります。送信中はボタンを押せなくなります。

## 公開する前に直すところ

- `content/site.ts` の `url` を、自分が公開する URL に（末尾のスラッシュなし）
- `content/*.ts` の `footer`（会社名・住所・メール・電話・著作権表示）を自分のものに
- `form.endpoint` を設定する（空のままだと、送信されずに見本の文言が出ます）
- `content/construction.ts` の `call.phone` を自分の番号に（電話を出さないなら空に）
- 使わないテンプレのフォルダ（`app/<名前>/`）と content を消す。一覧の `content/site.ts` と、`content/validate.test.ts` の import・検証からも外す（外さないと `npm test` が読み込みで失敗します）
- ファビコン（`app/icon.svg`）を自分のものにする
- `app/page.tsx`（一覧ページ）を消すか、自分のトップに書き換える
- `out/404.html` を日本語にする（いまは Next.js の既定で、英語の「This page could not be found.」が出ます。`app/not-found.tsx` を作って書き出し直すと差し替わります）
- 「Tabane Works」「粉とゆげ」「灯月設備」「霜月会計事務所」「月白歯科クリニック」「潮見計測」を残さない
- 共有カードの画像（`og:image`）は同梱していません。要るなら `app/opengraph-image.tsx` を足すと、写真を使わずに作れます（書き方は Next.js の説明にあります）

直したら `npm test` を 1 回通してください。抜けと形式の崩れはここで見つかります。

## ライセンス

全文は LICENSE.md にあります。要約すると、購入したご本人（購入が組織なら、その組織の案件）で自由に使えます。クライアントのサイトに組み込んで納品することもできます。禁止しているのは、このファイル一式の再配布・転売・共有と、同種の商品としての販売です。

## 困ったら

hello@suminawa.dev（購入者の質問には 3 営業日以内に返信します）
