#!/usr/bin/env node
// 配布 zip を release/ に作る。書き出し済みの out/ も入れる（Next.js を動かさない買い手のため）。
// node_modules と .next は入れない ── 並べたものだけを zip する。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const zipPath = `release/lp-templates-v${pkg.version}.zip`;

if (!existsSync("out/index.html")) {
  console.error("out が無い。先に npm run build");
  process.exit(1);
}
for (const page of ["out/saas/index.html", "out/shop/index.html"]) {
  if (!existsSync(page)) {
    console.error(`${page} が無い。ビルドが途中で失敗している`);
    process.exit(1);
  }
}

mkdirSync("release", { recursive: true });
if (existsSync(zipPath)) rmSync(zipPath);

execFileSync(
  "zip",
  [
    "-r",
    zipPath,
    "app",
    "components",
    "content",
    "lib",
    "styles",
    "scripts",
    "out",
    "README.ja.md",
    "LICENSE.md",
    "CHANGELOG.md",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "next.config.ts",
    "eslint.config.mjs",
    "vitest.config.mts",
    ".gitignore",
    "-x",
    "*.DS_Store",
  ],
  { stdio: "inherit" },
);
console.log(`wrote ${zipPath}`);
