import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

// 拡張子が .mts なのは、Vite に ESM として読ませるため（.ts だと読み込みの警告が出る）。
// ESM には __dirname が無いので、このファイルの場所から組み立てる。
const here = fileURLToPath(new URL(".", import.meta.url));

export default defineConfig({
  resolve: {
    alias: { "@": here },
  },
  test: {
    include: ["content/**/*.test.ts", "lib/**/*.test.ts"],
  },
});
