import type { ReactNode } from "react";

import type { ProfessionalIcon as IconName } from "@/content/types";

/**
 * サービスの節に出す線画。塗りなし、線の太さ 2 で統一する。
 * 増やすときは content/types.ts の ProfessionalIcon に名前を足して、ここに形を足す。
 */
const SHAPES: Record<IconName, ReactNode> = {
  audit: (
    <>
      <path d="M9 4h12l6 6v22H9z" />
      <path d="M20 4v7h7" />
      <circle cx="17" cy="21" r="4.5" />
      <path d="M20.5 24.5 24 28" />
    </>
  ),
  books: (
    <>
      <rect x="5" y="6" width="26" height="24" rx="3" />
      <path d="M12 6v24" />
      <path d="M17 13h9M17 19h9M17 25h5" />
    </>
  ),
  training: (
    <>
      <rect x="4" y="6" width="28" height="18" rx="2" />
      <path d="M10 19l5-6 4 4 6-7" />
      <path d="M18 24v6M13 30h10" />
    </>
  ),
};

export function ProfessionalIcon({
  name,
  className,
}: {
  name: IconName;
  className?: string;
}) {
  return (
    <span className={className} aria-hidden="true">
      <svg viewBox="0 0 36 36" fill="none" stroke="currentColor" strokeWidth="2">
        {SHAPES[name]}
      </svg>
    </span>
  );
}
