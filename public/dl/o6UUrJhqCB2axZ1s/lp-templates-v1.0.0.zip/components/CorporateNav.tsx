"use client";

import NextLink from "next/link";
import { usePathname } from "next/navigation";

import type { Link } from "@/content/types";
import { samePath } from "@/lib/path";

import s from "./corporate-parts.module.css";

/**
 * 共通ヘッダーのリンク。いま開いている面に aria-current を付ける。
 * 現在地を知るのに usePathname が要るので、ここだけクライアント部品にする
 * （枠の layout.tsx はサーバー部品のまま）。
 */
export function CorporateNav({
  links,
  label,
}: {
  links: Link[];
  label: string;
}) {
  const pathname = usePathname();

  return (
    <nav className={s.nav} aria-label={label}>
      {links.map((link) => (
        <NextLink
          key={link.href}
          href={link.href}
          className={s.navLink}
          aria-current={samePath(pathname, link.href) ? "page" : undefined}
        >
          {link.label}
        </NextLink>
      ))}
    </nav>
  );
}
