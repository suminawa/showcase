"use client";

import { useState } from "react";

import type { SaasContent } from "@/content/types";
import { formatYen } from "@/lib/format";
import { priceFor, type Cycle } from "@/lib/pricing";

import s from "./pricing.module.css";

/** 月額払い／年額払いを切り替える料金表。金額の計算は lib/pricing.ts */
export function PricingTable({ pricing }: { pricing: SaasContent["pricing"] }) {
  const [cycle, setCycle] = useState<Cycle>("monthly");

  return (
    <div className={s.wrap}>
      <div className={s.toggle} role="group" aria-label={pricing.toggleLabel}>
        <button
          type="button"
          className={s.toggleButton}
          aria-pressed={cycle === "monthly"}
          onClick={() => setCycle("monthly")}
        >
          {pricing.monthlyLabel}
        </button>
        <button
          type="button"
          className={s.toggleButton}
          aria-pressed={cycle === "yearly"}
          onClick={() => setCycle("yearly")}
        >
          {pricing.yearlyLabel}
        </button>
      </div>

      {/* 切替で金額だけが変わるので、読み上げにも変化を伝える */}
      <ul className={s.plans} aria-live="polite">
        {pricing.plans.map((plan) => (
          <li
            key={plan.id}
            className={`${s.plan} ${plan.recommended ? s.recommended : ""}`}
          >
            {plan.recommended ? (
              <span className={s.badge}>{pricing.recommendedBadge}</span>
            ) : null}
            <h3 className={s.name}>{plan.name}</h3>
            <p className={s.price}>
              <span className={s.amount}>
                {formatYen(priceFor(plan.monthly, cycle, pricing.yearlyDiscount))}
              </span>
              <span className={s.unit}>{pricing.unit}</span>
            </p>
            <p className={s.audience}>{plan.audience}</p>
            <ul className={s.features}>
              {plan.features.map((feature) => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
          </li>
        ))}
      </ul>

      <p className={s.note}>
        {cycle === "yearly" ? pricing.yearlyNote : pricing.monthlyNote}
      </p>
    </div>
  );
}
