"use client";

import { useState } from "react";

import type { ConstructionContent } from "@/content/types";
import { formatPrice } from "@/lib/format";
import { rateFor, type RatePlan } from "@/lib/rates";

import s from "./construction-parts.module.css";

/** 平日（昼）と夜間・休日を切り替える料金の目安。金額の計算は lib/rates.ts */
export function PriceTable({ price }: { price: ConstructionContent["price"] }) {
  const [plan, setPlan] = useState<RatePlan>("weekday");
  const tabs: { plan: RatePlan; label: string }[] = [
    { plan: "weekday", label: price.weekdayLabel },
    { plan: "night", label: price.nightLabel },
  ];

  return (
    <div className={s.priceWrap}>
      <div className={s.toggle} role="group" aria-label={price.toggleLabel}>
        {tabs.map((tab) => (
          <button
            key={tab.plan}
            type="button"
            className={s.toggleButton}
            aria-pressed={plan === tab.plan}
            onClick={() => setPlan(tab.plan)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 切り替えで変わるのは金額の列と下の一行の両方なので、二つまとめて
          読み上げに載せる。切替ボタンは外に置く（押した状態まで読ませない） */}
      <div className={s.priceLive} aria-live="polite">
        <ul className={s.rates}>
          {price.rows.map((row) => {
            const amount = rateFor(row, plan, price.nightRate);
            return (
              <li key={row.id} className={s.rate}>
                <p className={s.rateLabel}>{row.label}</p>
                <p className={s.rateAmount}>
                  {amount === 0 ? price.freeLabel : formatPrice(amount)}
                </p>
                <p className={s.rateNote}>{row.note}</p>
              </li>
            );
          })}
        </ul>

        <p className={s.priceNote}>
          {plan === "night" ? price.nightNote : price.weekdayNote}
        </p>
      </div>
    </div>
  );
}
