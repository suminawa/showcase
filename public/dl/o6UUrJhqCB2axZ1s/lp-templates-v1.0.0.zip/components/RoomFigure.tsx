import type { ReactNode } from "react";

import type { RoomFigure as FigureName } from "@/content/types";

/**
 * 院内のご案内の図。写真の代わりに、線だけの見取り図で見せる。
 * 図は飾りなので aria-hidden ── 意味は隣の見出しと本文が文字で持つ。
 * 増やすときは content/types.ts の RoomFigure に名前を足して、ここに形を足す。
 */
const SHAPES: Record<FigureName, ReactNode> = {
  entrance: (
    <>
      <path d="M6 66h108" />
      <path d="M18 66 62 40h18v26" />
      <rect x="80" y="18" width="30" height="48" rx="2" />
      <path d="M88 30h14v36H88z" />
      <path d="M96 46v6" />
    </>
  ),
  rooms: (
    <>
      <rect x="6" y="10" width="108" height="60" rx="3" />
      <path d="M33 10v60M60 10v60M87 10v60" />
      <rect x="12" y="28" width="15" height="26" rx="4" />
      <rect x="39" y="28" width="15" height="26" rx="4" />
      <rect x="66" y="28" width="15" height="26" rx="4" />
      <rect x="93" y="28" width="15" height="26" rx="4" />
    </>
  ),
  kids: (
    <>
      <rect x="6" y="14" width="108" height="52" rx="3" />
      <rect x="14" y="24" width="44" height="34" rx="8" />
      <path d="M22 58v-8h12v8M40 50h10v8" />
      <path d="M70 58h36M70 46h24" />
      <circle cx="94" cy="32" r="6" />
    </>
  ),
};

export function RoomFigure({
  name,
  className,
}: {
  name: FigureName;
  className?: string;
}) {
  return (
    <span className={className} aria-hidden="true">
      <svg viewBox="0 0 120 80" fill="none" stroke="currentColor" strokeWidth="2">
        {SHAPES[name]}
      </svg>
    </span>
  );
}
