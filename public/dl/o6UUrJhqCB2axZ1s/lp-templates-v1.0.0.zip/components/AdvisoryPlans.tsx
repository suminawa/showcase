"use client";

import { useState } from "react";

import type { ProfessionalContent } from "@/content/types";
import { yearlyEstimate } from "@/lib/advisory";
import { formatPrice } from "@/lib/format";

import s from "./advisory.module.css";

/**
 * 顧問料のプランを切り替える。選んだプランだけをカードで大きく出す ──
 * 3 つ横に並べると、スマホでは縦に長い列が 3 本続いて読み通せない。
 * 年間の目安の計算は lib/advisory.ts にあり、ここでは表示だけをする。
 */
export function AdvisoryPlans({
  pricing,
}: {
  pricing: ProfessionalContent["pricing"];
}) {
  const [id, setId] = useState(pricing.plans[0].id);
  const plan = pricing.plans.find((item) => item.id === id) ?? pricing.plans[0];
  const yearly = yearlyEstimate(plan.lines);
  const [head, ...rest] = plan.lines;

  return (
    <div className={s.wrap}>
      <div className={s.switch} role="group" aria-label={pricing.switchLabel}>
        {pricing.plans.map((option) => (
          <button
            key={option.id}
            type="button"
            className={s.switchButton}
            aria-pressed={option.id === plan.id}
            onClick={() => setId(option.id)}
          >
            {option.name}
          </button>
        ))}
      </div>

      {/* 切り替えるとカードの中身が丸ごと入れ替わるので、ここを読み上げに載せる。
          金額は「15,000 円」の書き方（formatPrice）── カードの本文と揃える */}
      <div className={s.card} aria-live="polite">
        <h3 className={s.name}>{plan.name}</h3>
        <p className={s.audience}>{plan.audience}</p>
        <p className={s.price}>
          <span className={s.priceLabel}>{head.label}</span>
          <span className={s.amount}>{formatPrice(head.price)}</span>
          <span className={s.unit}>{pricing.unitLabels[head.unit]}</span>
        </p>
        {rest.length > 0 ? (
          <ul className={s.lines}>
            {rest.map((line) => (
              <li key={line.label}>
                <span>{line.label}</span>
                <span className={s.lineAmount}>
                  {formatPrice(line.price)}
                  {pricing.unitLabels[line.unit]}
                </span>
              </li>
            ))}
          </ul>
        ) : null}
        {yearly === null ? (
          <p className={s.yearly}>{pricing.spotNote}</p>
        ) : (
          <p className={s.yearly}>
            {pricing.yearlyLabel} <strong>{formatPrice(yearly)}</strong>
          </p>
        )}
        <ul className={s.includes}>
          {plan.includes.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
        <p className={s.note}>{plan.note}</p>
      </div>
    </div>
  );
}
