import type { FooterContent } from "@/content/types";

import s from "./shared.module.css";

/**
 * ページの結び。会社名・住所・連絡先・著作権表示。
 * tel が空ならその行を出さない。中身はすべて content の footer から来る。
 */
export function LpFooter({ footer }: { footer: FooterContent }) {
  return (
    <footer className={s.footer}>
      <p className={s.company}>{footer.company}</p>
      <address className={s.address}>
        <span>{footer.address}</span>
        {footer.tel ? (
          <span>
            <a href={`tel:${footer.tel.replace(/[^0-9+]/g, "")}`}>{footer.tel}</a>
          </span>
        ) : null}
        <span>
          <a href={`mailto:${footer.email}`}>{footer.email}</a>
        </span>
      </address>
      <p className={s.copyright}>{footer.copyright}</p>
    </footer>
  );
}
