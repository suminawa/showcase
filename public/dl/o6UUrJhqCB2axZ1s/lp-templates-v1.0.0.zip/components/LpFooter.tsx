import type { FooterContent } from "@/content/types";
import { telHref } from "@/lib/format";

import s from "./shared.module.css";

/**
 * 読み上げのときの呼び名。content の footer.entity を省いたときに使う。
 * 画面には出ない語なので、ここだけは日本語を持つ（ほかの文字はすべて content にある）。
 */
const DEFAULT_ENTITY = "会社";

/**
 * ページの結び。会社名・住所・連絡先・著作権表示。
 * tel が空ならその行を出さない。中身はすべて content の footer から来る。
 * entity（会社／事務所／医院／店）は、読み上げのときの「○○の情報」に使う。
 */
export function LpFooter({ footer }: { footer: FooterContent }) {
  return (
    <footer
      className={s.footer}
      aria-label={`${footer.entity ?? DEFAULT_ENTITY}の情報`}
    >
      <p className={s.company}>{footer.company}</p>
      <address className={s.address}>
        <span>{footer.address}</span>
        {footer.tel ? (
          <span>
            <a href={telHref(footer.tel)}>{footer.tel}</a>
          </span>
        ) : null}
        <span>
          <a href={`mailto:${footer.email}`}>{footer.email}</a>
        </span>
      </address>
      <p className={s.copyright}>{footer.copyright}</p>
    </footer>
  );
}
