import type { ReactNode } from "react";

import type { FeatureIcon as IconName } from "@/content/types";

/**
 * 機能の節に出す線画。塗りなし、線の太さ 2 で統一する。
 * 増やすときは content/types.ts の FeatureIcon に名前を足して、ここに形を足す。
 */
const SHAPES: Record<IconName, ReactNode> = {
  screen: (
    <>
      <rect x="4" y="6" width="28" height="24" rx="3" />
      <path d="M4 14h28M12 22h6" />
    </>
  ),
  clock: (
    <>
      <circle cx="18" cy="18" r="13" />
      <path d="M18 10v8l6 4" />
    </>
  ),
  export: (
    <>
      <path d="M18 5v18M11 16l7 7 7-7" />
      <path d="M6 26v4h24v-4" />
    </>
  ),
};

export function FeatureIcon({
  name,
  className,
}: {
  name: IconName;
  className?: string;
}) {
  return (
    <span className={className} aria-hidden="true">
      <svg viewBox="0 0 36 36" fill="none" stroke="currentColor" strokeWidth="2">
        {SHAPES[name]}
      </svg>
    </span>
  );
}
