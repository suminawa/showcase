import type { ReactNode } from "react";

import type { TreatmentIcon as IconName } from "@/content/types";

/**
 * 診療内容の線画。塗りなし、線の太さ 2、角は丸める（歯の輪郭が尖らないように）。
 * 増やすときは content/types.ts の TreatmentIcon に名前を足して、ここに形を足す。
 */
const SHAPES: Record<IconName, ReactNode> = {
  general: (
    <path d="M11 7c-3 0-5 2-5 6 0 6 2 8 3 13 .5 2.5 1 4 2.5 4s2-2 2.5-5c.4-2.4 1-3.5 2-3.5s1.6 1.1 2 3.5c.5 3 1 5 2.5 5s2-1.5 2.5-4c1-5 3-7 3-13 0-4-2-6-5-6-2 0-3 1-5 1s-3-1-5-1z" />
  ),
  kids: (
    <>
      <path d="M13 12c-2.4 0-4 1.6-4 4.8 0 4.8 1.6 6.4 2.4 10.4.4 2 .8 3.2 2 3.2s1.6-1.6 2-4c.32-1.92.8-2.8 1.6-2.8s1.28.88 1.6 2.8c.4 2.4.8 4 2 4s1.6-1.2 2-3.2c.8-4 2.4-5.6 2.4-10.4 0-3.2-1.6-4.8-4-4.8-1.6 0-2.4.8-4 .8s-2.4-.8-4-.8z" />
      <circle cx="9" cy="7" r="1.5" />
      <circle cx="27" cy="9" r="1.5" />
    </>
  ),
  cleaning: (
    <>
      <rect x="5" y="14" width="12" height="7" rx="2" />
      <path d="M8 14v-3M11 14v-4M14 14v-3" />
      <path d="M17 17.5h13" />
    </>
  ),
  braces: (
    <>
      <path d="M3 18h30" />
      <rect x="5" y="14" width="6" height="8" rx="1.5" />
      <rect x="15" y="14" width="6" height="8" rx="1.5" />
      <rect x="25" y="14" width="6" height="8" rx="1.5" />
    </>
  ),
  whitening: (
    <>
      <path d="M13 9c-2.4 0-4 1.6-4 4.8 0 4.8 1.6 6.4 2.4 10.4.4 2 .8 3.2 2 3.2s1.6-1.6 2-4c.32-1.92.8-2.8 1.6-2.8s1.28.88 1.6 2.8c.4 2.4.8 4 2 4s1.6-1.2 2-3.2c.8-4 2.4-5.6 2.4-10.4 0-3.2-1.6-4.8-4-4.8-1.6 0-2.4.8-4 .8s-2.4-.8-4-.8z" />
      <path d="M28 4v6M25 7h6" />
    </>
  ),
  implant: (
    <>
      <path d="M12 6h12v6H12z" />
      <path d="M18 12v18" />
      <path d="M14 16h8M14.5 20h7M15 24h6" />
    </>
  ),
};

export function TreatmentIcon({
  name,
  className,
}: {
  name: IconName;
  className?: string;
}) {
  return (
    <span className={className} aria-hidden="true">
      <svg
        viewBox="0 0 36 36"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      >
        {SHAPES[name]}
      </svg>
    </span>
  );
}
