"use client";

import { useId, useState, type FormEvent } from "react";

import type { FormContent } from "@/content/types";
import { submitForm } from "@/lib/form-submit";

import s from "./shared.module.css";

/**
 * 問い合わせ・予約のフォーム。
 * content の form.endpoint が空なら、どこにも送らずに見本の文言を出す
 * ── 置いたその日から画面は動き、送信先が決まったら 1 行書き足すだけで届くようになる。
 * 送るか送らないかの判断と文言の選び方は lib/form-submit.ts にある。
 *
 * form.honeypot に name を書くと、迷惑投稿よけの見えない欄を 1 つ足す。
 * 画面の外へ出すだけで display: none にはしない ── 消した欄を bot は読み飛ばすため。
 */
export function LpForm({ form }: { form: FormContent }) {
  const id = useId();
  const [status, setStatus] = useState("");
  const [sending, setSending] = useState(false);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (sending) return;

    // await をまたぐと event.currentTarget は null になるので、先に控える
    const element = event.currentTarget;
    const values: Record<string, string> = {};
    for (const [key, value] of new FormData(element).entries()) {
      values[key] = typeof value === "string" ? value : value.name;
    }

    setSending(true);
    setStatus(form.messages.sending);
    const result = await submitForm({
      endpoint: form.endpoint,
      contentType: form.contentType,
      values,
      messages: form.messages,
      honeypot: form.honeypot,
    });
    setSending(false);
    setStatus(result.message);
    if (result.ok) element.reset();
  }

  return (
    <form className={s.form} onSubmit={onSubmit}>
      {form.fields.map((field) => {
        const fieldId = `${id}-${field.name}`;
        return (
          <div key={field.name} className={s.field}>
            <label htmlFor={fieldId}>
              {field.label}
              {field.required ? <span aria-hidden="true">＊</span> : null}
            </label>
            {field.type === "textarea" ? (
              <textarea
                id={fieldId}
                name={field.name}
                placeholder={field.placeholder}
                required={field.required}
                rows={4}
              />
            ) : (
              <input
                id={fieldId}
                name={field.name}
                type={field.type ?? "text"}
                placeholder={field.placeholder}
                required={field.required}
              />
            )}
          </div>
        );
      })}
      {form.honeypot ? (
        <div className={s.trap} aria-hidden="true">
          <label htmlFor={`${id}-${form.honeypot}`}>
            この欄は空のままにしてください
          </label>
          <input
            id={`${id}-${form.honeypot}`}
            name={form.honeypot}
            type="text"
            tabIndex={-1}
            autoComplete="off"
          />
        </div>
      ) : null}
      <button type="submit" className={s.submit} disabled={sending}>
        {form.submitLabel}
      </button>
      <p className={s.status} role="status" aria-live="polite">
        {status}
      </p>
    </form>
  );
}
