"use client";

import { useEffect, useState } from "react";

import type { Hours, SpanHours } from "@/content/types";
import { isOpenAt, isOpenAtSpans } from "@/lib/hours";

/**
 * いま開いているかどうかの一行。
 * hours には、1 スパンの営業時間（店）か、曜日ごとの午前・午後（医院）を渡す。
 * どちらも openLabel / closedLabel を持っているので、出す文言の出どころは 1 つで済む。
 *
 * このページは静的に書き出すので、サーバーでは何も出さず、画面に出てから判定する
 * ── そうしないと「ビルドした時刻の営業中」が貼り付いたままになる。
 * 出てからは 1 分ごとに見直すので、開店・閉店の時刻をまたいでも表示が追いつく。
 */
export function OpenNow({
  hours,
  className,
}: {
  hours: Hours | SpanHours;
  className?: string;
}) {
  const [open, setOpen] = useState<boolean | null>(null);

  useEffect(() => {
    const update = () =>
      setOpen(
        "days" in hours
          ? isOpenAtSpans(new Date(), hours.days)
          : isOpenAt(new Date(), hours),
      );
    update();
    const timer = window.setInterval(update, 60_000);
    return () => window.clearInterval(timer);
  }, [hours]);

  if (open === null) return null;

  return (
    <span className={className} data-open={open}>
      {open ? hours.openLabel : hours.closedLabel}
    </span>
  );
}
