import { telHref } from "@/lib/format";

import s from "./construction-parts.module.css";

/**
 * 電話の CTA。本物の tel: を開く。
 * content の call.phone が空なら何も出さない ── 番号の無い LP に、押せない電話ボタンを置かない。
 * 脈打つ輪は飾りなので、減速の設定のときは CSS 側で止まる。
 */
export function CallButton({
  phone,
  label,
  sub,
  variant = "hero",
}: {
  phone: string;
  label: string;
  /** ボタンの中の小さい一行（受付時間など）。header の形では隠れる */
  sub?: string;
  /** hero は大きく、header は 1 行の小さい形 */
  variant?: "hero" | "header";
}) {
  if (phone.trim() === "") return null;

  return (
    <a
      href={telHref(phone)}
      className={`${s.call} ${variant === "header" ? s.callSmall : ""}`}
    >
      <span className={s.callRing} aria-hidden="true" />
      <svg
        className={s.callIcon}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 6.5 6.5L17 13l4 1.5v3a2 2 0 0 1-2.2 2A17 17 0 0 1 4 5.2 2 2 0 0 1 6 3Z" />
      </svg>
      <span className={s.callText}>
        <span className={s.callLabel}>{label}</span>
        {sub ? <span className={s.callSub}>{sub}</span> : null}
      </span>
    </a>
  );
}
