import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // 静的書き出し。npm run build で out/ に HTML が出る
  output: "export",
  // /saas を out/saas/index.html にする。フォルダごとサーバーに上げられる形
  trailingSlash: true,
  // このテンプレは画像を使わない。next/image を足すときだけ要る設定
  images: { unoptimized: true },
  // https://example.com/lp/ のように下の階層へ置くときは、ここに "/lp" と書いてビルドし直す
  // basePath: "/lp",
};

export default nextConfig;
