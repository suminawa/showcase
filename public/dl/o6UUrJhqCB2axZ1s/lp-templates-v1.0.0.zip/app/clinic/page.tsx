import type { Metadata } from "next";

import { HeroCircles } from "@/components/HeroCircles";
import { LpFooter } from "@/components/LpFooter";
import { LpForm } from "@/components/LpForm";
import { OpenNow } from "@/components/OpenNow";
import { RoomFigure } from "@/components/RoomFigure";
import { TreatmentIcon } from "@/components/TreatmentIcon";
import { clinic } from "@/content/clinic";
import { site } from "@/content/site";
import type { Span } from "@/content/types";
import { dayLabels, markFor, spanLabel } from "@/lib/hours";

import s from "./clinic.module.css";

export const metadata: Metadata = {
  title: clinic.meta.title,
  description: clinic.meta.description,
  openGraph: {
    title: clinic.meta.title,
    description: clinic.meta.description,
    url: `${site.url}/clinic/`,
    type: "website",
    siteName: clinic.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: clinic.meta.title,
    description: clinic.meta.description,
  },
};

/** 表のます目。記号は目で読み、同じ意味の語を読み上げに渡す */
function HoursCell({ span, standard }: { span: Span | null; standard: Span }) {
  const mark = markFor(span, standard);
  const { symbol, label } = clinic.schedule.marks[mark];
  return (
    <td data-mark={mark}>
      <span aria-hidden="true">{symbol}</span>
      <span className={s.srOnly}>{label}</span>
    </td>
  );
}

export default function ClinicPage() {
  const columns = dayLabels(clinic.hours.days);

  return (
    <div className={`${s.page} theme-clinic`}>
      <header className={s.header}>
        <div className={`${s.container} ${s.headerRow}`}>
          <a href="#top" className={s.brand}>
            {clinic.brand}
          </a>
          <nav className={s.nav} aria-label={clinic.navLabel}>
            {clinic.nav.map((link) => (
              <a key={link.href} href={link.href}>
                {link.label}
              </a>
            ))}
          </nav>
          <a
            href={clinic.headerCta.href}
            className={`${s.primary} ${s.small} ${s.headerCta}`}
          >
            {clinic.headerCta.label}
          </a>
        </div>
      </header>

      <main id="top" className={s.main}>
        <section className={s.hero}>
          <HeroCircles className={s.circlesLayer} />
          <div className={s.container}>
            <p className={s.eyebrow}>{clinic.hero.eyebrow}</p>
            <h1 className={s.h1}>{clinic.hero.title}</h1>
            <p className={s.heroLead}>{clinic.hero.lead}</p>
            <div className={s.heroHours}>
              {clinic.hero.facts.map((fact) => (
                <p key={fact}>{fact}</p>
              ))}
            </div>
            <p className={s.heroWalk}>{clinic.hero.walk}</p>
            <p className={s.ctas}>
              <a href={clinic.hero.primary.href} className={s.primary}>
                {clinic.hero.primary.label}
              </a>
              <a href={clinic.hero.secondary.href} className={s.secondary}>
                {clinic.hero.secondary.label}
              </a>
            </p>
            <p className={s.fine}>{clinic.hero.fine}</p>
          </div>
        </section>

        <section id={clinic.points.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{clinic.points.heading}</h2>
            <ul className={s.grid3}>
              {clinic.points.items.map((point) => (
                <li key={point.title} className={s.card}>
                  <h3 className={s.cardTitle}>{point.title}</h3>
                  <p className={s.cardBody}>{point.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section
          id={clinic.treatments.id}
          className={`${s.section} ${s.soft}`}
        >
          <div className={s.container}>
            <h2 className={s.h2}>{clinic.treatments.heading}</h2>
            <ul className={s.grid3}>
              {clinic.treatments.items.map((item) => (
                <li key={item.title} className={s.card}>
                  <TreatmentIcon name={item.icon} className={s.icon} />
                  <h3 className={s.cardTitle}>{item.title}</h3>
                  <p className={s.cardBody}>{item.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={clinic.schedule.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{clinic.schedule.heading}</h2>
            <div className={s.tableWrap}>
              <table className={s.table}>
                {/* 時刻は表の外へ出す。行の見出しに入れたままだと、せまい画面で
                    表が入れ物からはみ出し、右側の曜日が読めなくなる */}
                <caption className={s.tableCaption}>
                  <span className={s.srOnly}>{clinic.schedule.caption}</span>
                  <span className={s.spanTime}>
                    {clinic.schedule.morning.label}{" "}
                    {spanLabel(clinic.schedule.morning.span)}
                  </span>{" "}
                  <span className={s.spanTime}>
                    {clinic.schedule.afternoon.label}{" "}
                    {spanLabel(clinic.schedule.afternoon.span)}
                  </span>
                </caption>
                <thead>
                  <tr>
                    <th scope="col">
                      <span className={s.srOnly}>
                        {clinic.schedule.columnHeader}
                      </span>
                    </th>
                    {columns.map((label) => (
                      <th key={label} scope="col">
                        {label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">{clinic.schedule.morning.label}</th>
                    {clinic.hours.days.map((entry) => (
                      <HoursCell
                        key={entry.day}
                        span={entry.morning}
                        standard={clinic.schedule.morning.span}
                      />
                    ))}
                  </tr>
                  <tr>
                    <th scope="row">{clinic.schedule.afternoon.label}</th>
                    {clinic.hours.days.map((entry) => (
                      <HoursCell
                        key={entry.day}
                        span={entry.afternoon}
                        standard={clinic.schedule.afternoon.span}
                      />
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
            <p className={s.legend}>
              {clinic.schedule.legend.map((row) => (
                <span key={row.mark}>
                  {clinic.schedule.marks[row.mark].symbol} {row.text}
                </span>
              ))}
            </p>
            <p className={s.closedNote}>{clinic.schedule.closedNote}</p>
            <p className={s.openNowRow}>
              <OpenNow hours={clinic.hours} className={s.openNow} />
            </p>
          </div>
        </section>

        <section id={clinic.rooms.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{clinic.rooms.heading}</h2>
            <ul className={s.rooms}>
              {clinic.rooms.items.map((room) => (
                <li key={room.title} className={s.room}>
                  <RoomFigure name={room.figure} className={s.roomFigure} />
                  <h3 className={s.cardTitle}>{room.title}</h3>
                  <p className={s.cardBody}>{room.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={clinic.faq.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{clinic.faq.heading}</h2>
            <div className={s.faq}>
              {clinic.faq.items.map((item) => (
                <details key={item.q}>
                  <summary>{item.q}</summary>
                  <p>{item.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id={clinic.reserve.id} className={`${s.section} ${s.soft}`}>
          <div className={`${s.container} ${s.reserve}`}>
            <div>
              <h2 className={s.h2}>{clinic.reserve.heading}</h2>
              <p className={s.reserveLead}>{clinic.reserve.lead}</p>
              <p className={s.reserveNote}>{clinic.reserve.note}</p>
            </div>
            <LpForm form={clinic.form} />
          </div>
        </section>
      </main>

      <div className={s.container}>
        <LpFooter footer={clinic.footer} />
      </div>
    </div>
  );
}
