import type { ReactNode } from "react";
import { Noto_Sans_JP } from "next/font/google";

import "../styles/globals.css";
import "../styles/tokens.css";

/** 本文の書体。別の書体にするならここを差し替える */
const notoSansJp = Noto_Sans_JP({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-noto-sans-jp",
});

export default function RootLayout({
  children,
}: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="ja">
      <body className={notoSansJp.variable}>{children}</body>
    </html>
  );
}
