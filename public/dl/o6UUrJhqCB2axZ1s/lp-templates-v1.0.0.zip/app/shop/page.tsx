import type { Metadata } from "next";
import { Shippori_Mincho } from "next/font/google";

import { HeroField } from "@/components/HeroField";
import { LpFooter } from "@/components/LpFooter";
import { LpForm } from "@/components/LpForm";
import { OpenNow } from "@/components/OpenNow";
import { shop } from "@/content/shop";
import { site } from "@/content/site";
import { formatPrice } from "@/lib/format";
import { closedDaysLabel, scheduleLabel } from "@/lib/hours";
import { itemsByCategory } from "@/lib/menu";

import s from "./shop.module.css";

/** 見出しの明朝。本文は app/layout.tsx が読んでいる Noto Sans JP のまま */
const mincho = Shippori_Mincho({
  subsets: ["latin"],
  weight: ["500", "600"],
  display: "swap",
  variable: "--d-mincho",
  preload: false,
});

export const metadata: Metadata = {
  title: shop.meta.title,
  description: shop.meta.description,
  openGraph: {
    title: shop.meta.title,
    description: shop.meta.description,
    url: `${site.url}/shop/`,
    type: "website",
    siteName: shop.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: shop.meta.title,
    description: shop.meta.description,
  },
};

export default function ShopPage() {
  const closed = closedDaysLabel(shop.hours);

  return (
    <div className={`${s.page} theme-shop ${mincho.variable}`}>
      <main>
        <section className={s.hero}>
          <div className={s.wash} aria-hidden="true" />
          <HeroField className={s.field} count={shop.hero.fieldCount} />
          <div className={s.container}>
            <p className={s.eyebrow}>{shop.hero.eyebrow}</p>
            <h1 className={s.h1}>{shop.brand}</h1>
            <p className={s.tagline}>{shop.hero.tagline}</p>
            <p className={s.heroLead}>{shop.hero.lead}</p>
            <div className={s.hours}>
              <p className={s.hoursLine}>{scheduleLabel(shop.hours)}</p>
              {closed ? <p className={s.hoursClosed}>{closed}</p> : null}
              <p className={s.openNowRow}>
                <OpenNow hours={shop.hours} className={s.openNow} />
              </p>
            </div>
            <p className={s.ctas}>
              <a href={shop.hero.primary.href} className={s.primary}>
                {shop.hero.primary.label}
              </a>
              <a href={shop.hero.secondary.href} className={s.secondary}>
                {shop.hero.secondary.label}
              </a>
            </p>
          </div>
        </section>

        <section id={shop.points.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{shop.points.heading}</h2>
            <ul className={s.points}>
              {shop.points.items.map((point) => (
                <li key={point.title} className={s.point}>
                  <h3 className={s.pointTitle}>{point.title}</h3>
                  <p className={s.pointBody}>{point.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={shop.menu.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{shop.menu.heading}</h2>
            <div className={s.menu}>
              {shop.menu.groups.map((group) => (
                <div key={group.category}>
                  <h3 className={s.h3}>{group.label}</h3>
                  <ul className={s.items}>
                    {itemsByCategory(shop.menu.items, group.category).map((item) => (
                      <li key={item.id}>
                        <p className={s.itemHead}>
                          <span className={s.itemName}>{item.name}</span>
                          <span className={s.itemLeader} aria-hidden="true" />
                          <span className={s.itemPrice}>
                            {formatPrice(item.price)}
                          </span>
                        </p>
                        <p className={s.itemNote}>{item.note}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <p className={s.menuNote}>{shop.menu.note}</p>
          </div>
        </section>

        <section id={shop.seats.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{shop.seats.heading}</h2>
            <dl className={s.seats}>
              {shop.seats.items.map((seat) => (
                <div key={seat.term} className={s.seatRow}>
                  <dt>{seat.term}</dt>
                  <dd>{seat.body}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section id={shop.access.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{shop.access.heading}</h2>
            <ol className={s.access}>
              {shop.access.steps.map((line) => (
                <li key={line} className={s.accessItem}>
                  {line}
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id={shop.reserve.id} className={s.section}>
          <div className={`${s.container} ${s.reserve}`}>
            <div>
              <h2 className={s.h2}>{shop.reserve.heading}</h2>
              <p className={s.reserveLead}>{shop.reserve.lead}</p>
            </div>
            <LpForm form={shop.form} />
          </div>
        </section>
      </main>

      <div className={s.container}>
        <LpFooter footer={shop.footer} />
      </div>
    </div>
  );
}
