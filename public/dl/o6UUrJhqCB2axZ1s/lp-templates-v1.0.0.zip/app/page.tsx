import type { Metadata } from "next";
import Link from "next/link";

import { site } from "@/content/site";

import s from "./index.module.css";

export const metadata: Metadata = {
  title: site.home.meta.title,
  description: site.home.meta.description,
  openGraph: {
    title: site.home.meta.title,
    description: site.home.meta.description,
    url: `${site.url}/`,
    type: "website",
    siteName: site.name,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: site.home.meta.title,
    description: site.home.meta.description,
  },
};

export default function HomePage() {
  return (
    <div className={`${s.page} theme-index`}>
      <main className={s.container}>
        <h1 className={s.heading}>{site.home.heading}</h1>
        <p className={s.lead}>{site.home.lead}</p>

        <ul className={s.cards}>
          {site.home.templates.map((template) => (
            <li key={template.href}>
              <Link href={template.href} className={s.card}>
                <p className={s.industry}>{template.industry}</p>
                <p className={s.name}>{template.name}</p>
                <p className={s.description}>{template.description}</p>
                <ul className={s.sections}>
                  {template.sections.map((section) => (
                    <li key={section}>{section}</li>
                  ))}
                </ul>
                <p className={s.open}>開く →</p>
              </Link>
            </li>
          ))}
        </ul>

        <p className={s.note}>{site.home.note}</p>
      </main>
    </div>
  );
}
