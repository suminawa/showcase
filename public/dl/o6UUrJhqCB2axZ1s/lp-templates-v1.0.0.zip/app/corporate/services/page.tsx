import type { Metadata } from "next";

import { PillarIcon } from "@/components/PillarIcon";
import { corporate } from "@/content/corporate";
import { site } from "@/content/site";

import c from "../corporate.module.css";
import s from "../sub.module.css";

export const metadata: Metadata = {
  title: corporate.services.meta.title,
  description: corporate.services.meta.description,
  openGraph: {
    title: corporate.services.meta.title,
    description: corporate.services.meta.description,
    url: `${site.url}/corporate/services/`,
    type: "website",
    siteName: corporate.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: corporate.services.meta.title,
    description: corporate.services.meta.description,
  },
};

export default function CorporateServicesPage() {
  return (
    <>
      <section className={c.pageHead}>
        <div className={c.container}>
          <h1 className={c.h1}>{corporate.services.title}</h1>
          <p className={c.lead}>{corporate.services.lead}</p>
        </div>
      </section>

      <section className={c.section}>
        <div className={c.container}>
          <div className={s.blocks}>
            {corporate.pillars.map((pillar) => (
              <article key={pillar.id} className={s.block}>
                <div className={s.blockHead}>
                  <PillarIcon name={pillar.icon} className={s.blockIcon} />
                  <h2 className={c.h2}>{pillar.name}</h2>
                  <p className={s.blockBody}>{pillar.body}</p>
                </div>
                <div className={s.blockDetail}>
                  <div>
                    <h3 className={s.detailTitle}>
                      {corporate.services.flowTitle}
                    </h3>
                    <ol className={s.flow}>
                      {pillar.steps.map((step) => (
                        <li key={step} className={s.flowStep}>
                          {step}
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div>
                    <h3 className={s.detailTitle}>
                      {corporate.services.gearTitle}
                    </h3>
                    <ul className={s.gear}>
                      {pillar.gear.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
