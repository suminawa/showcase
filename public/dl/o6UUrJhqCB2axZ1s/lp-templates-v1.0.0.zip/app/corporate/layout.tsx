/*
 * 会社案内サイトの共通の枠。4 枚の面がこれを共有する。
 * 入れ子の layout なので <html> と <body> は書かない（app/layout.tsx が持っている）。
 * テーマのクラスはここで付ける ── 下の面は --d-* を継承するだけ。
 */
import type { ReactNode } from "react";
import Link from "next/link";

import { CorporateNav } from "@/components/CorporateNav";
import { LpFooter } from "@/components/LpFooter";
import { corporate } from "@/content/corporate";

import s from "./corporate.module.css";

export default function CorporateLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <div className={`${s.page} theme-corporate`}>
      <header className={s.header}>
        <div className={`${s.container} ${s.headerRow}`}>
          <Link href={corporate.nav[0].href} className={s.logo}>
            {corporate.brand}
          </Link>
          <CorporateNav links={corporate.nav} label={corporate.navLabel} />
        </div>
      </header>

      <main className={s.body}>{children}</main>

      <div className={s.container}>
        <LpFooter footer={corporate.footer} />
      </div>
    </div>
  );
}
