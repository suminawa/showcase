import type { Metadata } from "next";
import Link from "next/link";

import { CountUp } from "@/components/CountUp";
import { NewsList } from "@/components/NewsList";
import { PillarIcon } from "@/components/PillarIcon";
import { WaveField } from "@/components/WaveField";
import { corporate } from "@/content/corporate";
import { site } from "@/content/site";
import { formatNumber } from "@/lib/format";

import c from "./corporate.module.css";
import s from "./top.module.css";

export const metadata: Metadata = {
  title: corporate.home.meta.title,
  description: corporate.home.meta.description,
  openGraph: {
    title: corporate.home.meta.title,
    description: corporate.home.meta.description,
    url: `${site.url}/corporate/`,
    type: "website",
    siteName: corporate.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: corporate.home.meta.title,
    description: corporate.home.meta.description,
  },
};

export default function CorporateTopPage() {
  const home = corporate.home;

  return (
    <>
      <section className={s.hero}>
        <WaveField className={s.waves} />
        <div className={c.container}>
          <p className={s.heroEyebrow}>{home.hero.eyebrow}</p>
          <h1 className={c.h1}>{home.hero.title}</h1>
          <p className={s.heroLead}>{home.hero.lead}</p>
          <div className={s.heroCtas}>
            <Link href={home.hero.primary.href} className={c.primary}>
              {home.hero.primary.label}
            </Link>
            <Link href={home.hero.secondary.href} className={c.secondary}>
              {home.hero.secondary.label}
            </Link>
          </div>
        </div>
      </section>

      <section className={c.section}>
        <div className={c.container}>
          <h2 className={c.h2}>{home.pillars.heading}</h2>
          <ul className={s.pillars}>
            {corporate.pillars.map((pillar) => (
              <li key={pillar.id} className={s.pillar}>
                <PillarIcon name={pillar.icon} className={s.pillarIcon} />
                <h3 className={s.pillarName}>{pillar.name}</h3>
                <p className={s.pillarBody}>{pillar.summary}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={`${c.section} ${c.soft}`}>
        <div className={c.container}>
          <h2 className={c.h2}>{home.stats.heading}</h2>
          <dl className={s.stats}>
            {home.stats.items.map((stat) => (
              <div key={stat.id} className={s.stat}>
                <dt className={s.statLabel}>{stat.label}</dt>
                <dd className={s.statValue}>
                  <CountUp target={stat.value} className={s.statNumber} />
                  <span className={s.statUnit} aria-hidden="true">
                    {stat.unit}
                  </span>
                  <span className={c.srOnly}>
                    {formatNumber(stat.value)}
                    {stat.unit}
                  </span>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className={c.section}>
        <div className={c.container}>
          <h2 className={c.h2}>{home.news.heading}</h2>
          <NewsList items={home.news.items} />
        </div>
      </section>

      <section className={c.section}>
        <div className={c.container}>
          <div className={s.cta}>
            <div>
              <h2 className={s.ctaTitle}>{home.cta.title}</h2>
              <p className={s.ctaBody}>{home.cta.body}</p>
            </div>
            <Link href={home.cta.link.href} className={s.ctaButton}>
              {home.cta.link.label}
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
