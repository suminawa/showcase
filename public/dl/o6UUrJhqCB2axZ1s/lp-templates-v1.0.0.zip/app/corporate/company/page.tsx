import type { Metadata } from "next";

import { corporate } from "@/content/corporate";
import { site } from "@/content/site";

import c from "../corporate.module.css";
import s from "../sub.module.css";

export const metadata: Metadata = {
  title: corporate.company.meta.title,
  description: corporate.company.meta.description,
  openGraph: {
    title: corporate.company.meta.title,
    description: corporate.company.meta.description,
    url: `${site.url}/corporate/company/`,
    type: "website",
    siteName: corporate.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: corporate.company.meta.title,
    description: corporate.company.meta.description,
  },
};

export default function CorporateCompanyPage() {
  const company = corporate.company;

  return (
    <>
      <section className={c.pageHead}>
        <div className={c.container}>
          <h1 className={c.h1}>{company.title}</h1>
          <p className={c.lead}>{company.lead}</p>
        </div>
      </section>

      <section className={c.section}>
        <div className={c.container}>
          <h2 className={c.h2}>{company.profile.heading}</h2>
          <dl className={s.profile}>
            {company.profile.rows.map((row) => (
              <div key={row.term} className={s.profileRow}>
                <dt>{row.term}</dt>
                <dd>{row.body}</dd>
              </div>
            ))}
          </dl>
          <p className={s.note}>{company.profile.note}</p>
        </div>
      </section>

      <section className={`${c.section} ${c.soft}`}>
        <div className={c.container}>
          <h2 className={c.h2}>{company.history.heading}</h2>
          <dl className={s.history}>
            {company.history.rows.map((row) => (
              <div key={row.year} className={s.historyRow}>
                <dt>{row.year}</dt>
                <dd>{row.body}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className={c.section}>
        <div className={c.container}>
          <h2 className={c.h2}>{company.policies.heading}</h2>
          <ul className={s.policies}>
            {company.policies.items.map((policy) => (
              <li key={policy.title}>
                <h3 className={s.policyTitle}>{policy.title}</h3>
                <p className={s.policyBody}>{policy.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
}
