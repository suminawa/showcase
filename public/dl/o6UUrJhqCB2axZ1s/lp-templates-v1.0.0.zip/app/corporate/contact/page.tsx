import type { Metadata } from "next";

import { LpForm } from "@/components/LpForm";
import { corporate } from "@/content/corporate";
import { site } from "@/content/site";

import c from "../corporate.module.css";
import s from "../sub.module.css";

export const metadata: Metadata = {
  title: corporate.contact.meta.title,
  description: corporate.contact.meta.description,
  openGraph: {
    title: corporate.contact.meta.title,
    description: corporate.contact.meta.description,
    url: `${site.url}/corporate/contact/`,
    type: "website",
    siteName: corporate.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: corporate.contact.meta.title,
    description: corporate.contact.meta.description,
  },
};

export default function CorporateContactPage() {
  const contact = corporate.contact;

  return (
    <>
      <section className={c.pageHead}>
        <div className={c.container}>
          <h1 className={c.h1}>{contact.title}</h1>
          <p className={c.lead}>{contact.lead}</p>
        </div>
      </section>

      <section className={c.section}>
        <div className={`${c.container} ${s.contact}`}>
          <div>
            <h2 className={c.h2}>{contact.heading}</h2>
            <p className={s.contactIntro}>{contact.intro}</p>
            <dl className={s.hours}>
              {contact.hours.map((row) => (
                <div key={row.term} className={s.hoursRow}>
                  <dt>{row.term}</dt>
                  <dd>{row.body}</dd>
                </div>
              ))}
            </dl>
          </div>
          <LpForm form={contact.form} />
        </div>
      </section>
    </>
  );
}
