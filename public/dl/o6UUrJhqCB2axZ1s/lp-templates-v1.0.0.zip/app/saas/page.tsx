import type { Metadata } from "next";

import { FeatureIcon } from "@/components/FeatureIcon";
import { HeroField } from "@/components/HeroField";
import { LpFooter } from "@/components/LpFooter";
import { LpForm } from "@/components/LpForm";
import { PricingTable } from "@/components/PricingTable";
import { saas } from "@/content/saas";
import { site } from "@/content/site";

import s from "./saas.module.css";

export const metadata: Metadata = {
  title: saas.meta.title,
  description: saas.meta.description,
  openGraph: {
    title: saas.meta.title,
    description: saas.meta.description,
    url: `${site.url}/saas/`,
    type: "website",
    siteName: saas.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: saas.meta.title,
    description: saas.meta.description,
  },
};

export default function SaasPage() {
  return (
    <div className={`${s.page} theme-saas`}>
      <header className={s.header}>
        <div className={`${s.container} ${s.headerRow}`}>
          <a href="#top" className={s.brand}>
            {saas.brand}
          </a>
          <nav className={s.nav} aria-label={saas.navLabel}>
            {saas.nav.map((link) => (
              <a key={link.href} href={link.href}>
                {link.label}
              </a>
            ))}
          </nav>
          <a
            href={saas.headerCta.href}
            className={`${s.primary} ${s.small} ${s.headerCta}`}
          >
            {saas.headerCta.label}
          </a>
        </div>
      </header>

      <main id="top" className={s.main}>
        <section className={s.hero}>
          <HeroField className={s.field} count={saas.hero.fieldCount} />
          <div className={s.container}>
            <p className={s.eyebrow}>{saas.hero.eyebrow}</p>
            <h1 className={s.h1}>{saas.hero.title}</h1>
            <p className={s.lead}>{saas.hero.lead}</p>
            <p className={s.ctas}>
              <a href={saas.hero.primary.href} className={s.primary}>
                {saas.hero.primary.label}
              </a>
              <a href={saas.hero.secondary.href} className={s.secondary}>
                {saas.hero.secondary.label}
              </a>
            </p>
            <p className={s.fine}>{saas.hero.fine}</p>
          </div>
        </section>

        <section id={saas.issues.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{saas.issues.heading}</h2>
            <ul className={s.grid3}>
              {saas.issues.items.map((issue) => (
                <li key={issue.title} className={s.card}>
                  <h3 className={s.cardTitle}>{issue.title}</h3>
                  <p className={s.cardBody}>{issue.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={saas.features.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{saas.features.heading}</h2>
            <ul className={s.grid3}>
              {saas.features.items.map((feature) => (
                <li key={feature.title} className={s.card}>
                  <FeatureIcon name={feature.icon} className={s.icon} />
                  <h3 className={s.cardTitle}>{feature.title}</h3>
                  <p className={s.cardBody}>{feature.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={saas.pricing.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{saas.pricing.heading}</h2>
            <PricingTable pricing={saas.pricing} />
          </div>
        </section>

        <section id={saas.flow.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{saas.flow.heading}</h2>
            <ol className={s.steps}>
              {saas.flow.steps.map((step) => (
                <li key={step.title} className={s.step}>
                  <p className={s.stepTitle}>{step.title}</p>
                  {step.time ? <p className={s.stepTime}>{step.time}</p> : null}
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id={saas.faq.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{saas.faq.heading}</h2>
            <div className={s.faq}>
              {saas.faq.items.map((item) => (
                <details key={item.q}>
                  <summary>{item.q}</summary>
                  <p>{item.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id={saas.contact.id} className={`${s.section} ${s.soft}`}>
          <div className={`${s.container} ${s.contact}`}>
            <div>
              <h2 className={s.h2}>{saas.contact.heading}</h2>
              <p className={s.contactLead}>{saas.contact.lead}</p>
            </div>
            <LpForm form={saas.form} />
          </div>
        </section>
      </main>

      <div className={s.container}>
        <LpFooter footer={saas.footer} />
      </div>
    </div>
  );
}
