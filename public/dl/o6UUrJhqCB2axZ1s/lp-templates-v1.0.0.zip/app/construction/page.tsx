import type { Metadata } from "next";

import { AreaTags } from "@/components/AreaTags";
import { CallButton } from "@/components/CallButton";
import { HeroField } from "@/components/HeroField";
import { LpFooter } from "@/components/LpFooter";
import { LpForm } from "@/components/LpForm";
import { PriceTable } from "@/components/PriceTable";
import { ServiceIcon } from "@/components/ServiceIcon";
import { construction } from "@/content/construction";
import { site } from "@/content/site";
import { formatFrom } from "@/lib/format";

import s from "./construction.module.css";

export const metadata: Metadata = {
  title: construction.meta.title,
  description: construction.meta.description,
  openGraph: {
    title: construction.meta.title,
    description: construction.meta.description,
    url: `${site.url}/construction/`,
    type: "website",
    siteName: construction.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: construction.meta.title,
    description: construction.meta.description,
  },
};

export default function ConstructionPage() {
  return (
    <div className={`${s.page} theme-construction`}>
      <header className={s.header}>
        <div className={`${s.container} ${s.headerRow}`}>
          <a href="#top" className={s.logo}>
            {construction.brand}
          </a>
          <nav className={s.nav} aria-label={construction.navLabel}>
            {construction.nav.map((link) => (
              <a key={link.href} href={link.href}>
                {link.label}
              </a>
            ))}
          </nav>
          <span className={s.headerCall}>
            <CallButton
              phone={construction.call.phone}
              label={construction.call.headerLabel}
              variant="header"
            />
          </span>
        </div>
      </header>

      <main id="top" className={s.main}>
        <section className={s.hero}>
          <div className={s.stripes} aria-hidden="true" />
          <HeroField className={s.field} count={construction.hero.fieldCount} />
          <div className={s.container}>
            <p className={s.eyebrow}>{construction.hero.eyebrow}</p>
            <h1 className={s.h1}>{construction.hero.title}</h1>
            <p className={s.lead}>{construction.hero.lead}</p>
            <div className={s.heroMeta}>
              {construction.hero.facts.map((fact) => (
                <p key={fact}>{fact}</p>
              ))}
            </div>
            <div className={s.ctas}>
              <CallButton
                phone={construction.call.phone}
                label={construction.call.heroLabel}
                sub={construction.call.heroSub}
              />
              <a href={construction.hero.secondary.href} className={s.secondary}>
                {construction.hero.secondary.label}
              </a>
            </div>
            <p className={s.fine}>{construction.hero.fine}</p>
          </div>
        </section>

        <section id={construction.services.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{construction.services.heading}</h2>
            <ul className={s.menu}>
              {construction.services.items.map((item) => (
                <li key={item.id} className={s.menuItem}>
                  <ServiceIcon id={item.icon} />
                  <h3 className={s.menuName}>{item.name}</h3>
                  <p className={s.menuPrice}>{formatFrom(item.from)}</p>
                  <p className={s.menuNote}>{item.note}</p>
                </li>
              ))}
            </ul>
            <p className={s.menuFoot}>{construction.services.note}</p>
          </div>
        </section>

        <section
          id={construction.price.id}
          className={`${s.section} ${s.soft}`}
        >
          <div className={s.container}>
            <h2 className={s.h2}>{construction.price.heading}</h2>
            <p className={s.sectionLead}>{construction.price.lead}</p>
            <PriceTable price={construction.price} />
          </div>
        </section>

        <section id={construction.areas.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{construction.areas.heading}</h2>
            <p className={s.sectionLead}>{construction.areas.lead}</p>
            <AreaTags areas={construction.areas.items} />
            <p className={s.menuFoot}>{construction.areas.note}</p>
          </div>
        </section>

        <section id={construction.flow.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{construction.flow.heading}</h2>
            <ol className={s.steps}>
              {construction.flow.steps.map((step) => (
                <li key={step.title} className={s.step}>
                  <h3 className={s.stepTitle}>{step.title}</h3>
                  <p className={s.stepBody}>{step.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id={construction.voices.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{construction.voices.heading}</h2>
            <ul className={s.voices}>
              {construction.voices.items.map((voice) => (
                <li key={voice.who}>
                  <figure className={s.voice}>
                    <blockquote className={s.voiceBody}>{voice.body}</blockquote>
                    <figcaption className={s.voiceWho}>{voice.who}</figcaption>
                  </figure>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={construction.faq.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{construction.faq.heading}</h2>
            <div className={s.faq}>
              {construction.faq.items.map((item) => (
                <details key={item.q}>
                  <summary>{item.q}</summary>
                  <p>{item.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id={construction.contact.id} className={s.section}>
          <div className={`${s.container} ${s.contact}`}>
            <div>
              <h2 className={s.h2}>{construction.contact.heading}</h2>
              <p className={s.contactLead}>{construction.contact.lead}</p>
            </div>
            <LpForm form={construction.form} />
          </div>
        </section>
      </main>

      <div className={s.container}>
        <LpFooter footer={construction.footer} />
      </div>
    </div>
  );
}
