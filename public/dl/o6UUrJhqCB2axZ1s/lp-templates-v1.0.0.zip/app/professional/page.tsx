import type { Metadata } from "next";
import { Shippori_Mincho } from "next/font/google";

import { AdvisoryPlans } from "@/components/AdvisoryPlans";
import { HeroRules } from "@/components/HeroRules";
import { LpFooter } from "@/components/LpFooter";
import { LpForm } from "@/components/LpForm";
import { ProfessionalIcon } from "@/components/ProfessionalIcon";
import { professional } from "@/content/professional";
import { site } from "@/content/site";

import s from "./professional.module.css";

/** 見出しの明朝。本文は app/layout.tsx が読んでいる Noto Sans JP のまま。
    CJK は片が多いので preload: false（先読みすると 3.7 MB になる） */
const mincho = Shippori_Mincho({
  subsets: ["latin"],
  weight: ["500", "600"],
  display: "swap",
  variable: "--d-mincho",
  preload: false,
});

export const metadata: Metadata = {
  title: professional.meta.title,
  description: professional.meta.description,
  openGraph: {
    title: professional.meta.title,
    description: professional.meta.description,
    url: `${site.url}/professional/`,
    type: "website",
    siteName: professional.brand,
    locale: "ja_JP",
  },
  twitter: {
    card: "summary",
    title: professional.meta.title,
    description: professional.meta.description,
  },
};

export default function ProfessionalPage() {
  return (
    <div className={`${s.page} theme-professional ${mincho.variable}`}>
      <header className={s.header}>
        <div className={`${s.container} ${s.headerRow}`}>
          <a href="#top" className={s.brand}>
            {professional.brand}
          </a>
          <nav className={s.nav} aria-label={professional.navLabel}>
            {professional.nav.map((link) => (
              <a key={link.href} href={link.href}>
                {link.label}
              </a>
            ))}
          </nav>
          <a
            href={professional.headerCta.href}
            className={`${s.primary} ${s.small} ${s.headerCta}`}
          >
            {professional.headerCta.label}
          </a>
        </div>
      </header>

      <main id="top" className={s.main}>
        <section className={s.hero}>
          <HeroRules className={s.rulesLayer} />
          <div className={s.container}>
            <p className={s.eyebrow}>{professional.hero.eyebrow}</p>
            <h1 className={s.h1}>{professional.hero.title}</h1>
            <p className={s.lead}>{professional.hero.lead}</p>
            <p className={s.ctas}>
              <a href={professional.hero.primary.href} className={s.primary}>
                {professional.hero.primary.label}
              </a>
              <a href={professional.hero.secondary.href} className={s.secondary}>
                {professional.hero.secondary.label}
              </a>
            </p>
            <p className={s.fine}>{professional.hero.fine}</p>
          </div>
        </section>

        <section id={professional.issues.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{professional.issues.heading}</h2>
            <ul className={s.grid3}>
              {professional.issues.items.map((issue) => (
                <li key={issue.title} className={s.card}>
                  <h3 className={s.cardTitle}>{issue.title}</h3>
                  <p className={s.cardBody}>{issue.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section
          id={professional.services.id}
          className={`${s.section} ${s.soft}`}
        >
          <div className={s.container}>
            <h2 className={s.h2}>{professional.services.heading}</h2>
            <ul className={s.grid3}>
              {professional.services.items.map((service) => (
                <li key={service.title} className={s.card}>
                  <ProfessionalIcon name={service.icon} className={s.icon} />
                  <h3 className={s.cardTitle}>{service.title}</h3>
                  <p className={s.cardBody}>{service.body}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id={professional.pricing.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{professional.pricing.heading}</h2>
            <AdvisoryPlans pricing={professional.pricing} />
            <p className={s.pricingNote}>{professional.pricing.note}</p>
          </div>
        </section>

        <section id={professional.flow.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{professional.flow.heading}</h2>
            <ol className={s.steps}>
              {professional.flow.steps.map((step) => (
                <li key={step.title} className={s.step}>
                  <h3 className={s.stepTitle}>{step.title}</h3>
                  <p className={s.stepBody}>{step.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id={professional.cases.id} className={s.section}>
          <div className={s.container}>
            <h2 className={s.h2}>{professional.cases.heading}</h2>
            <ul className={s.cases}>
              {professional.cases.items.map((item) => (
                <li key={item.industry} className={s.case}>
                  <dl className={s.caseRow}>
                    <dt className={s.caseTerm}>
                      {professional.cases.labels.industry}
                    </dt>
                    <dd className={s.caseBody}>{item.industry}</dd>
                  </dl>
                  <dl className={s.caseRow}>
                    <dt className={s.caseTerm}>
                      {professional.cases.labels.issue}
                    </dt>
                    <dd className={s.caseBody}>{item.issue}</dd>
                  </dl>
                  <dl className={s.caseRow}>
                    <dt className={s.caseTerm}>
                      {professional.cases.labels.result}
                    </dt>
                    <dd className={`${s.caseBody} ${s.caseResult}`}>
                      {item.result}
                    </dd>
                  </dl>
                </li>
              ))}
            </ul>
            <p className={s.casesNote}>{professional.cases.note}</p>
          </div>
        </section>

        <section id={professional.faq.id} className={`${s.section} ${s.soft}`}>
          <div className={s.container}>
            <h2 className={s.h2}>{professional.faq.heading}</h2>
            <div className={s.faq}>
              {professional.faq.items.map((item) => (
                <details key={item.q}>
                  <summary>{item.q}</summary>
                  <p>{item.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id={professional.contact.id} className={s.section}>
          <div className={`${s.container} ${s.contact}`}>
            <div>
              <h2 className={s.h2}>{professional.contact.heading}</h2>
              <p className={s.contactLead}>{professional.contact.lead}</p>
            </div>
            <LpForm form={professional.form} />
          </div>
        </section>
      </main>

      <div className={s.container}>
        <LpFooter footer={professional.footer} />
      </div>
    </div>
  );
}
