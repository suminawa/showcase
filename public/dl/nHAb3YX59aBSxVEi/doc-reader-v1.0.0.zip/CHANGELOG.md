# Changelog

## 1.0.0 — 2026-09-21
- 初版。請求書・領収書・注文書・名刺・申込書の PDF や写真から、帳票の型で決めた項目を読み取ります
- サーバー部品 `createReader(config, { forms })`: Web 標準の `Request → Response`。Next.js・Vercel・Node のどれでも動きます
- 帳票の型 `forms/*.json` 5 種と、画面の「自由項目」
- 項目ごとの値・信頼度・根拠。必須・形式・突き合わせ・信頼度・重複の警告で「要確認」を判定します
- 確認画面つきの Next.js 16 テンプレ（CSV・TSV・スプレッドシートへの送信）
- コマンド `npx doc-reader run / check / forms`
- スプレッドシートの受け口 `gas/receiver.gs`
- 架空の会社の見本 12 枚と、期待値との一致率を測る `check`
- 書類も値もサーバーに残しません。記録は件数と信頼度だけです
