import { defineConfig } from "tsup";

export default defineConfig([
  {
    entry: { index: "src/index.ts", "adapters/node": "src/adapters/node.ts" },
    format: ["esm", "cjs"],
    dts: { entry: { index: "src/index.ts" } },
    sourcemap: false,
    clean: true,
    target: "node22",
    platform: "node",
    external: ["@anthropic-ai/sdk"],
    shims: true,
  },
  {
    entry: { cli: "src/cli.ts" },
    format: ["esm"],
    sourcemap: false,
    target: "node22",
    platform: "node",
    external: ["@anthropic-ai/sdk"],
    banner: { js: "#!/usr/bin/env node" },
  },
  {
    entry: { ui: "src/ui/index.ts" },
    format: ["esm"],
    dts: { entry: { ui: "src/ui/index.ts" } },
    sourcemap: false,
    target: "es2020",
    platform: "browser",
  },
]);
