#!/usr/bin/env node
// 同梱の帳票の型を、Next.js テンプレの forms/ に写す（pack:template と release が呼ぶ）
import { copyFile, mkdir, readdir } from "node:fs/promises";
await mkdir("templates/nextjs/forms", { recursive: true });
for (const name of await readdir("forms")) {
  if (!name.endsWith(".json")) continue;
  await copyFile(`forms/${name}`, `templates/nextjs/forms/${name}`);
}
console.log("templates/nextjs/forms を更新しました");
