// 架空の会社の書類を 12 枚作る（PDF 6・写真風 JPEG 6）。同じデータから expected JSON も書く。
// 使い方: node scripts/make-samples.mjs（playwright が別の場所にあるときは環境変数 PLAYWRIGHT_MODULE にその入口のパスを入れてください）
import { mkdirSync, writeFileSync } from "node:fs";

const modulePath = process.env.PLAYWRIGHT_MODULE ?? "playwright";
const { chromium } = await import(modulePath);

mkdirSync("samples/docs", { recursive: true });
mkdirSync("samples/expected", { recursive: true });

const yen = (n) => "¥" + n.toLocaleString("ja-JP");
const CSS = `body{font-family:'Hiragino Sans','Noto Sans JP',sans-serif;color:#111;margin:0;padding:48px 56px;font-size:13px;line-height:1.6}
h1{font-size:22px;letter-spacing:.3em;text-align:center;margin:0 0 24px}table{border-collapse:collapse;width:100%;margin-top:12px}
th,td{border:1px solid #444;padding:6px 8px;font-size:12px}th{background:#eee}.r{text-align:right}.meta{display:flex;justify-content:space-between}
.stamp{display:inline-block;border:2px solid #b3261e;color:#b3261e;border-radius:50%;width:44px;height:44px;line-height:44px;text-align:center;font-size:12px;margin-left:8px}
.box{border:1px solid #444;padding:8px 12px;margin-top:12px}.small{font-size:11px;color:#333}`;

const lines = (items, cols = ["品名", "数量", "単価", "金額"]) => `<table><tr>${cols.map((c) => `<th>${c}</th>`).join("")}</tr>${items
  .map((i) => `<tr><td>${i.description}</td><td class="r">${i.quantity}</td><td class="r">${yen(i.unitPrice)}</td><td class="r">${yen(i.amount)}</td></tr>`)
  .join("")}</table>`;

function invoiceHtml(d) {
  return `<html><head><meta charset="utf-8"><style>${CSS}</style></head><body>
<h1>請求書</h1>
<div class="meta"><div><b>${d.recipient} 御中</b><br>下記のとおりご請求申し上げます。</div>
<div class="small">請求書番号: ${d.invoiceNumber}<br>発行日: ${d.issueDate}<br>お支払期限: ${d.dueDate}</div></div>
<div class="box"><b>ご請求金額 ${yen(d.total)}（税込）</b></div>
${lines(d.items)}
<table style="width:40%;margin-left:auto"><tr><th>小計</th><td class="r">${yen(d.subtotal)}</td></tr><tr><th>消費税（10%）</th><td class="r">${yen(d.tax)}</td></tr><tr><th>合計</th><td class="r">${yen(d.total)}</td></tr></table>
<div style="margin-top:28px" class="small"><b>${d.issuer}</b><span class="stamp">印</span><br>${d.issuerAddress}<br>TEL ${d.issuerPhone}<br>登録番号 ${d.registrationNumber}<br>振込先: ${d.bankAccount}</div>
</body></html>`;
}

function receiptHtml(d) {
  if (d.style === "register") {
    return `<html><head><meta charset="utf-8"><style>body{font-family:'Menlo','Hiragino Sans',monospace;font-size:13px;margin:0;padding:24px 28px;width:300px;color:#111}p{margin:2px 0}.c{text-align:center}.r{display:flex;justify-content:space-between}</style></head><body>
<p class="c"><b>${d.issuer}</b></p><p class="c">${d.issuerAddress}<br>TEL ${d.issuerPhone}</p><p class="c">${d.issueDate} ${d.time}</p><p>--------------------------------</p>
${d.items.map((i) => `<p class="r"><span>${i.description}${i.rate === 8 ? " ※" : ""}</span><span>${yen(i.amount)}</span></p>`).join("")}
<p>--------------------------------</p><p class="r"><span>小計</span><span>${yen(d.subtotal)}</span></p><p class="r"><span>内消費税</span><span>${yen(d.tax)}</span></p><p class="r"><b>合計</b><b>${yen(d.total)}</b></p>
<p class="r"><span>お預り（${d.paymentMethod}）</span><span>${yen(d.tendered)}</span></p><p class="r"><span>お釣り</span><span>${yen(d.tendered - d.total)}</span></p>
<p>※は軽減税率対象（8%）</p><p>登録番号 ${d.registrationNumber}</p></body></html>`;
  }
  return `<html><head><meta charset="utf-8"><style>${CSS} h1{letter-spacing:.6em}</style></head><body>
<h1>領収書</h1><p style="font-size:16px"><b>${d.recipient} 様</b></p>
<div class="box" style="font-size:20px;text-align:center">${yen(d.total)}<span class="small">（税込）</span></div>
<p>但 ${d.purpose} として<br>上記正に領収いたしました。</p>
<p class="small">内訳: 税抜 ${yen(d.subtotal)}・消費税（${d.taxRate}） ${yen(d.tax)}<br>お支払方法: ${d.paymentMethod}</p>
<div class="meta"><div class="small">${d.issueDate}</div><div class="small"><b>${d.issuer}</b><span class="stamp">印</span><br>${d.issuerAddress}<br>登録番号 ${d.registrationNumber}</div></div>
</body></html>`;
}

function purchaseOrderHtml(d) {
  return `<html><head><meta charset="utf-8"><style>${CSS}</style></head><body>
<h1>注文書</h1>
<div class="meta"><div><b>${d.supplier} 御中</b><br>下記のとおり注文いたします。</div><div class="small">注文番号: ${d.orderNumber}<br>注文日: ${d.orderDate}<br>納期: ${d.deliveryDate}</div></div>
<div class="box">納品場所: ${d.deliveryPlace}</div>
${lines(d.items)}
<table style="width:40%;margin-left:auto"><tr><th>合計（税込）</th><td class="r">${yen(d.total)}</td></tr></table>
<p class="small">備考: ${d.notes}</p>
<div style="margin-top:20px" class="small"><b>${d.orderer}</b><span class="stamp">印</span><br>${d.ordererAddress}<br>担当 ${d.contact}</div>
</body></html>`;
}

function businessCardHtml(d) {
  return `<html><head><meta charset="utf-8"><style>body{margin:0;width:540px;height:330px;font-family:'Hiragino Sans','Noto Sans JP',sans-serif;color:#1b1b1b;background:#fff;padding:36px 40px;box-sizing:border-box;position:relative}
.co{font-size:14px;letter-spacing:.1em}.dept{font-size:11px;color:#444;margin-top:2px}.name{font-size:28px;margin-top:26px;letter-spacing:.2em}.kana{font-size:10px;color:#666;letter-spacing:.3em}
.addr{position:absolute;left:40px;bottom:32px;font-size:10.5px;line-height:1.7;color:#333}.bar{position:absolute;right:0;top:0;width:14px;height:100%;background:#1f3d2b}</style></head><body>
<div class="bar"></div><div class="co">${d.company}</div><div class="dept">${d.department}　${d.title}</div>
<div class="kana">${d.nameReading}</div><div class="name">${d.name}</div>
<div class="addr">〒${d.postalCode} ${d.address}<br>TEL ${d.phone}　Mobile ${d.mobile}<br>${d.email}<br>${d.url}</div></body></html>`;
}

function applicationHtml(d) {
  const cb = (on) => (on ? "☑" : "☐");
  return `<html><head><meta charset="utf-8"><style>${CSS} td.v{font-family:'Hiragino Maru Gothic ProN','Hiragino Sans',sans-serif;font-size:15px;color:#1a2a6b}</style></head><body>
<h1>お申込書</h1><p class="small">太枠の中をご記入ください。受付日 ${d.receivedDate}</p>
<table>
<tr><th style="width:26%">ふりがな</th><td class="v">${d.nameReading}</td></tr>
<tr><th>お名前</th><td class="v">${d.name}</td></tr>
<tr><th>生年月日</th><td class="v">${d.birthDate}</td></tr>
<tr><th>ご住所</th><td class="v">〒${d.postalCode}　${d.address}</td></tr>
<tr><th>お電話</th><td class="v">${d.phone}</td></tr>
<tr><th>メール</th><td class="v">${d.email}</td></tr>
<tr><th>ご希望日</th><td class="v">${d.preferredDate}</td></tr>
<tr><th>コース</th><td>${d.plans.map((p) => `${cb(p === d.plan)} ${p}`).join("　")}</td></tr>
<tr><th>ご要望</th><td class="v">${d.notes}</td></tr>
<tr><th>規約への同意</th><td>${cb(d.agreed)} 利用規約に同意します</td></tr>
</table></body></html>`;
}

// ---- データ（すべて架空。住所は架空の市、電話は 03-0000 の欠番帯、登録番号は 0 並び） ----
const inv = (n, issuer, issuerAddress, issuerPhone, registrationNumber, bankAccount, recipient, issueDate, dueDate, items, invoiceNumber) => {
  const subtotal = items.reduce((a, i) => a + i.amount, 0);
  const tax = Math.floor(subtotal * 0.1);
  return { name: n, form: "invoice", issuer, issuerAddress, issuerPhone, registrationNumber, bankAccount, recipient, issueDate, dueDate, items, invoiceNumber, subtotal, tax, total: subtotal + tax };
};
const item = (description, quantity, unitPrice) => ({ description, quantity, unitPrice, amount: quantity * unitPrice });

const docs = [
  { kind: "pdf", ...inv("invoice-01", "さくら設備株式会社", "みなと市中央1-2-3 さくらビル4F", "03-0000-1111", "T0000000000001", "うみかぜ銀行 中央支店 普通 0000001 サクラセツビ（カ", "みなと商会", "2026年9月1日", "2026年9月30日", [item("給湯器交換工事", 1, 128000), item("配管部材一式", 1, 18500), item("出張費", 2, 3000)], "INV-2026-0901") },
  { kind: "jpg", tilt: 1.2, ...inv("invoice-02", "ひかり工務店", "みなと市港町5-6 ひかりビル2F", "03-0000-2222", "T0000000000002", "しおかぜ信用金庫 本店 普通 0000002 ヒカリコウムテン", "みなと商会 総務部", "令和8年9月5日", "令和8年10月31日", [item("内装工事（会議室）", 1, 240000), item("養生費", 1, 12000)], "H-0905") },
  { kind: "pdf", ...inv("invoice-03", "あおば印刷", "みなと市東3-4-5", "03-0000-3333", "T0000000000003", "うみかぜ銀行 さくら支店 当座 0000003 アオバインサツ", "みなと商会", "2026/09/10", "2026/10/10", [item("パンフレット A4 三つ折り", 500, 68), item("名刺 100枚", 3, 1800), item("封筒 長3 印刷", 1000, 22)], "AP-260910-07") },
  { kind: "jpg", tilt: -1.8, ...inv("invoice-04", "みなと清掃サービス", "みなと市西1-1", "03-0000-4444", "T0000000000004", "うみかぜ銀行 西支店 普通 0000004 ミナトセイソウ", "みなと商会", "2026年8月31日", "2026年9月30日", [item("定期清掃（8月分）", 4, 22000)], "S-2608") },
  { name: "receipt-01", kind: "jpg", tilt: 0.8, form: "receipt", style: "register", issuer: "みなとマート 港町店", issuerAddress: "みなと市港町2-8", issuerPhone: "03-0000-5555", issueDate: "2026/09/12", time: "12:41", registrationNumber: "T0000000000005", paymentMethod: "現金", tendered: 2000,
    items: [{ description: "コピー用紙 A4", amount: 548, rate: 10 }, { description: "お茶 500ml", amount: 130, rate: 8 }, { description: "サンドイッチ", amount: 398, rate: 8 }, { description: "ボールペン", amount: 220, rate: 10 }], subtotal: 1207, tax: 89, total: 1296 },
  { name: "receipt-02", kind: "pdf", form: "receipt", style: "formal", issuer: "有限会社しおかぜ商店", issuerAddress: "みなと市浜1-9", registrationNumber: "T0000000000006", recipient: "みなと商会", issueDate: "2026年9月8日", purpose: "会議用飲料代", subtotal: 4000, taxRate: "8%", tax: 320, total: 4320, paymentMethod: "現金" },
  { name: "receipt-03", kind: "jpg", tilt: -1.0, form: "receipt", style: "formal", issuer: "みなと駐車場", issuerAddress: "みなと市中央4-1", registrationNumber: "T0000000000007", recipient: "みなと商会", issueDate: "令和8年9月11日", purpose: "駐車料金", subtotal: 1500, taxRate: "10%", tax: 150, total: 1650, paymentMethod: "クレジットカード" },
  { name: "purchase-order-01", kind: "pdf", form: "purchase-order", orderer: "みなと商会", ordererAddress: "みなと市中央2-2-2", contact: "総務部 海野", supplier: "さくら設備株式会社", orderNumber: "PO-2026-0115", orderDate: "2026年9月3日", deliveryDate: "2026年9月20日", deliveryPlace: "みなと商会 本社 3F 倉庫", notes: "納品時は事前にお電話ください。", items: [item("エアコン 業務用 4馬力", 2, 385000), item("配管・据付工事", 2, 48000), item("既存機撤去", 2, 15000)], total: 985600 },
  { name: "purchase-order-02", kind: "pdf", form: "purchase-order", orderer: "ひかり工務店", ordererAddress: "みなと市港町5-6", contact: "工事部 浜田", supplier: "あおば建材", orderNumber: "2026-0912-A", orderDate: "2026/9/12", deliveryDate: "2026/9/25", deliveryPlace: "みなと市東 新築現場（みなと商会 倉庫）", notes: "午前中納品希望", items: [item("石膏ボード 12.5mm", 120, 980), item("木材 2×4 6F", 80, 620), item("ビス 箱", 10, 1450)], total: 199870 },
  { id: "business-card-01", kind: "jpg", tilt: 0.6, form: "business-card", company: "みなと商会", department: "総務部", title: "課長", name: "海野 ひかり", nameReading: "うみの ひかり", postalCode: "000-0001", address: "みなと市中央2-2-2 みなとビル5F", phone: "03-0000-6666", mobile: "090-0000-0001", email: "umino@example.com", url: "https://example.com" },
  { id: "business-card-02", kind: "jpg", tilt: -0.9, form: "business-card", company: "さくら設備株式会社", department: "営業部 第二課", title: "主任", name: "浜田 悠", nameReading: "はまだ ゆう", postalCode: "000-0002", address: "みなと市中央1-2-3 さくらビル4F", phone: "03-0000-1111", mobile: "090-0000-0002", email: "hamada@example.com", url: "https://example.com/sakura" },
  { id: "application-01", kind: "pdf", form: "application", receivedDate: "2026年9月13日", name: "潮見 さくら", nameReading: "しおみ さくら", birthDate: "1990年5月4日", postalCode: "000-0003", address: "みなと市浜3-3-3", phone: "090-0000-0003", email: "shiomi@example.com", preferredDate: "2026年9月20日", plans: ["体験コース", "月4回コース", "月8回コース"], plan: "月4回コース", notes: "平日の夜を希望します", agreed: true },
];

const html = (d) => ({ invoice: invoiceHtml, receipt: receiptHtml, "purchase-order": purchaseOrderHtml, "business-card": businessCardHtml, application: applicationHtml })[d.form](d);
const photoWrap = (inner, tilt) => `<html><head><meta charset="utf-8"><style>html,body{margin:0;background:#8f8a80}.desk{padding:40px;display:inline-block}.paper{display:inline-block;background:#fff;box-shadow:0 8px 30px rgba(0,0,0,.35);transform:rotate(${tilt}deg);filter:contrast(.92) brightness(.97)}</style></head><body><div class="desk"><div class="paper">${inner.replace(/<html>|<\/html>|<head>|<\/head>|<body>|<\/body>/g, "")}</div></div></body></html>`;

const expectedOf = (d) => {
  const s = (v) => (v === undefined || v === null ? null : String(v));
  const money = (n) => yen(n);
  if (d.form === "invoice") return { form: "invoice", fields: { issuer: d.issuer, recipient: d.recipient, invoiceNumber: d.invoiceNumber, issueDate: d.issueDate, dueDate: d.dueDate, subtotal: money(d.subtotal), tax: money(d.tax), total: money(d.total), registrationNumber: d.registrationNumber, bankAccount: d.bankAccount }, tables: { lineItems: d.items.map((i) => ({ description: i.description, quantity: String(i.quantity), unitPrice: money(i.unitPrice), amount: money(i.amount) })) } };
  if (d.form === "receipt") return { form: "receipt", fields: { issuer: d.issuer, issueDate: d.issueDate, total: money(d.total), tax: money(d.tax), taxRate: d.style === "register" ? "混在" : d.taxRate, paymentMethod: d.paymentMethod, registrationNumber: d.registrationNumber, purpose: s(d.purpose) }, tables: { lineItems: d.style === "register" ? d.items.map((i) => ({ description: i.description, quantity: "1", amount: money(i.amount) })) : [] } };
  if (d.form === "purchase-order") return { form: "purchase-order", fields: { orderer: d.orderer, supplier: d.supplier, orderNumber: d.orderNumber, orderDate: d.orderDate, deliveryDate: d.deliveryDate, deliveryPlace: d.deliveryPlace, total: money(d.total), notes: d.notes }, tables: { lineItems: d.items.map((i) => ({ description: i.description, quantity: String(i.quantity), unitPrice: money(i.unitPrice), amount: money(i.amount) })) } };
  if (d.form === "business-card") return { form: "business-card", fields: { name: d.name, nameReading: d.nameReading, company: d.company, department: d.department, title: d.title, email: d.email, phone: d.phone, mobile: d.mobile, postalCode: d.postalCode, address: d.address, url: d.url }, tables: {} };
  return { form: "application", fields: { name: d.name, nameReading: d.nameReading, postalCode: d.postalCode, address: d.address, phone: d.phone, email: d.email, birthDate: d.birthDate, preferredDate: d.preferredDate, plan: d.plan, agreed: d.agreed ? "☑" : "☐", notes: d.notes }, tables: {} };
};

const browser = await chromium.launch();
const index = [];
for (const d of docs) {
  const page = await browser.newPage({ viewport: { width: 900, height: 1200 }, deviceScaleFactor: 2 });
  if (d.kind === "pdf") {
    await page.setContent(html(d));
    await page.pdf({ path: `samples/docs/${d.id ?? d.name}.pdf`, format: "A4", printBackground: true });
  } else {
    await page.setContent(photoWrap(html(d), d.tilt ?? 1));
    const paper = page.locator(".desk");
    await paper.screenshot({ path: `samples/docs/${d.id ?? d.name}.jpg`, type: "jpeg", quality: 78 });
  }
  await page.close();
  writeFileSync(`samples/expected/${d.id ?? d.name}.json`, JSON.stringify(expectedOf(d), null, 2) + "\n");
  console.log("wrote", d.id ?? d.name);
}
await browser.close();

const titles = { "invoice-01": "請求書（設備工事）", "receipt-01": "レシート（コンビニ風）", "purchase-order-01": "注文書（空調）", "business-card-01": "名刺", "application-01": "申込書" };
for (const d of docs) {
  const id = d.id ?? d.name;
  if (titles[id]) index.push({ file: `${id}.${d.kind}`, title: titles[id], form: d.form });
}
writeFileSync("samples/index.json", JSON.stringify(index, null, 2) + "\n");
