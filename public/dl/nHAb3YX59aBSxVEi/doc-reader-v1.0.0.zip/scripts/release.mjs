#!/usr/bin/env node
// dist を含む配布 zip を release/ に作る。改造できるよう src / test / eval / scripts も入れる。node_modules は入れない
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/doc-reader-v${pkg.version}.zip`;

// zip に入れるものが揃っているか、先に確かめる
// samples/ は zip にだけ入れる。偽の答えは走っているフォルダの samples/ から引くので（cli.ts / node.ts の loadFakeAnswers("samples")）、tgz に入れても読まれない
for (const file of ["dist/index.js", "dist/cli.js", "dist/ui.js", "dist/adapters/node.js", "forms/invoice.json", "gas/receiver.gs", "samples/index.json", "README.ja.md", "LICENSE.md", "CHANGELOG.md"]) {
  if (!existsSync(file)) {
    console.error(`${file} が無い。先に npm run build（と samples の生成）`);
    process.exit(1);
  }
}

execFileSync("node", ["scripts/copy-forms.mjs"], { stdio: "inherit" });
execFileSync("npm", ["pack", "--pack-destination", "templates/nextjs/vendor"], { stdio: "inherit" });
const tgzName = `${pkg.name.replace(/^@/, "").replace(/\//g, "-")}-${pkg.version}.tgz`;
if (!existsSync(`templates/nextjs/vendor/${tgzName}`)) {
  console.error(`templates/nextjs/vendor/${tgzName} が無い`);
  process.exit(1);
}

mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);
execFileSync(
  "zip",
  [
    "-r", out,
    "dist", "src", "test", "demo", "forms", "gas", "templates", "samples", "eval", "scripts",
    "package.json", "package-lock.json", "tsconfig.json", "tsup.config.ts", "vitest.config.ts", ".gitignore",
    "README.ja.md", "LICENSE.md", "CHANGELOG.md",
    "-x", "*.DS_Store", "-x", "*/node_modules/*", "-x", "eval/results/*", "-x", "*/.next/*",
  ],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
