import { describe, expect, it } from "vitest";
import { parseForm } from "../src/core/forms";
import type { ExtractResult } from "../src/core/types";
import { compareDocument, sameValue, summarizeScores } from "./compare";

const form = parseForm({ id: "invoice", name: "請求書", fields: [
  { key: "issuer", label: "請求元", type: "string" },
  { key: "total", label: "合計金額", type: "money" },
  { key: "issueDate", label: "発行日", type: "date" },
  { key: "lineItems", label: "明細", type: "table", columns: [{ key: "description", label: "品名", type: "string" }, { key: "amount", label: "金額", type: "money" }] },
] });
const expected = { form: "invoice", fields: { issuer: "さくら設備株式会社", total: "¥151,800", issueDate: "2026年9月1日" }, tables: { lineItems: [{ description: "給湯器交換工事", amount: "¥128,000" }, { description: "出張費", amount: "¥6,000" }] } };
const result: ExtractResult = {
  ok: true, documentId: "d", form: "invoice", fileName: "x.pdf", pages: 1,
  fields: { issuer: { value: "さくら設備 株式会社", confidence: 1, evidence: "" }, total: { value: 151800, confidence: 1, evidence: "" }, issueDate: { value: "2026-09-02", confidence: 1, evidence: "" } },
  tables: { lineItems: { rows: [{ description: "給湯器交換工事", amount: 128000 }, { description: "出張費", amount: 5000 }], confidence: 1 } },
  warnings: [], needsReview: false, notes: "", usage: { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 }, ms: 0,
};

describe("sameValue", () => {
  it("文字は空白と全角半角を無視、数は等しいか、日付は同じ文字", () => {
    expect(sameValue("string", "さくら設備株式会社", "さくら設備 株式会社")).toBe(true);
    expect(sameValue("string", "ＡＢＣ", "abc")).toBe(false);
    expect(sameValue("string", "ＡＢＣ", "ABC")).toBe(true);
    expect(sameValue("money", 100, 100)).toBe(true);
    expect(sameValue("money", 100, 101)).toBe(false);
    expect(sameValue("date", "2026-09-01", "2026-09-01")).toBe(true);
    expect(sameValue("string", null, null)).toBe(true);
    expect(sameValue("string", null, "x")).toBe(false);
  });
});

describe("compareDocument / summarizeScores", () => {
  it("期待値を正規化して項目ごとに比べ、表はセル単位で数える", () => {
    const score = compareDocument(form, expected, result, "x");
    expect(score.ok).toBe(true);
    expect(score.fields.map((f) => `${f.key}:${f.match}`)).toEqual(["issuer:true", "total:true", "issueDate:false"]);
    expect(score.tables[0]).toEqual({ key: "lineItems", expectedRows: 2, actualRows: 2, cells: 4, matched: 3 });
    const summary = summarizeScores([score]);
    expect(summary.docs).toBe(1);
    expect(summary.fieldAccuracy).toBeCloseTo(2 / 3, 5);
    expect(summary.cellAccuracy).toBe(0.75);
    expect(summary.byForm.invoice.docs).toBe(1);
  });
  it("読めなかった書類は ok false で、項目は全部不一致", () => {
    const score = compareDocument(form, expected, { ok: false, code: "unreadable", message: "" }, "x");
    expect(score.ok).toBe(false);
    expect(score.fields.every((f) => !f.match)).toBe(true);
    expect(summarizeScores([score]).failed).toBe(1);
  });
});
