import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import { inspectDocument, sha256Hex } from "../src/core/document";
import { extractDocument } from "../src/core/extract";
import { loadFakeAnswers } from "../src/core/fake-answers-fs";
import type { FakeAnswer } from "../src/core/fake-client";
import { loadForms } from "../src/core/forms-fs";
import type { AnthropicClientLike, Extraction, ReaderConfig } from "../src/core/types";
import { compareDocument, summarizeScores, type DocScore } from "./compare";

export interface RunEvalOptions {
  samplesDir: string;
  formsDir: string;
  config: ReaderConfig;
  client: AnthropicClientLike;
  log?: (line: string) => void;
}

export async function runEval(opts: RunEvalOptions): Promise<{ scores: DocScore[]; summary: ReturnType<typeof summarizeScores> }> {
  const forms = await loadForms(opts.formsDir);
  const answers = await loadFakeAnswers(opts.samplesDir);
  const docsDir = join(opts.samplesDir, "docs");
  const files = (await readdir(docsDir)).sort();
  const scores: DocScore[] = [];
  for (const file of files) {
    const bytes = new Uint8Array(await readFile(join(docsDir, file)));
    const documentId = await sha256Hex(bytes);
    const expected: FakeAnswer | undefined = answers.get(documentId);
    if (expected === undefined) {
      console.warn(`${file}: 期待値が samples/expected にありません（飛ばします）`);
      continue;
    }
    const form = forms.get(expected.form);
    if (form === undefined) continue;
    const inspected = await inspectDocument(file, bytes);
    let result: Extraction;
    if (!inspected.ok) result = { ok: false, code: "unsupported", message: inspected.message };
    else result = await extractDocument({ client: opts.client, config: opts.config, form, document: inspected.input, pages: inspected.pages, documentId });
    const score = compareDocument(form, expected, result, file);
    scores.push(score);
    opts.log?.(`${file}: ${score.ok ? `${score.fields.filter((f) => f.match).length}/${score.fields.length} 項目` : "読めませんでした"}`);
  }
  return { scores, summary: summarizeScores(scores) };
}

const pct = (n: number): string => `${Math.round(n * 100)}%`;

export function formatReport(summary: ReturnType<typeof summarizeScores>, scores: DocScore[]): string {
  const lines = [`見本 ${summary.docs} 枚（読めなかったもの ${summary.failed}）: 項目の一致率 ${pct(summary.fieldAccuracy)}、表のセルの一致率 ${pct(summary.cellAccuracy)}`];
  for (const [id, f] of Object.entries(summary.byForm)) lines.push(`  ${id}: ${f.docs} 枚・項目 ${pct(f.fieldAccuracy)}`);
  const misses = scores.flatMap((s) => s.fields.filter((f) => !f.match).map((f) => `  ${s.name} ${f.label}: 期待 ${JSON.stringify(f.expected)} / 実際 ${JSON.stringify(f.actual)}`));
  if (misses.length > 0) lines.push("不一致:", ...misses);
  return lines.join("\n");
}
