import type { FakeAnswer } from "../src/core/fake-client";
import { normalizeValue, toHalfWidth } from "../src/core/normalize";
import type { ColumnType, Extraction, FieldDef, FormDef, ScalarType, ScalarValue } from "../src/core/types";

export interface FieldScore { key: string; label: string; expected: ScalarValue; actual: ScalarValue; match: boolean }
export interface TableScore { key: string; expectedRows: number; actualRows: number; cells: number; matched: number }
export interface DocScore { name: string; form: string; ok: boolean; fields: FieldScore[]; tables: TableScore[] }

const flat = (s: string): string => toHalfWidth(s).replace(/\s+/g, "");

export function sameValue(type: ScalarType | ColumnType, expected: ScalarValue, actual: ScalarValue): boolean {
  if (expected === null || actual === null) return expected === actual;
  if (type === "string" || type === "enum") return flat(String(expected)) === flat(String(actual));
  return expected === actual;
}

export function compareDocument(form: FormDef, expected: FakeAnswer, result: Extraction, name: string): DocScore {
  const fields: FieldScore[] = [];
  const tables: TableScore[] = [];
  for (const field of form.fields) {
    if (field.type === "table") {
      const columns = field.columns ?? [];
      const expRows = expected.tables[field.key] ?? [];
      const actRows = result.ok ? (result.tables[field.key]?.rows ?? []) : [];
      let matched = 0;
      expRows.forEach((row, i) => {
        for (const column of columns) {
          const exp = normalizeValue(column.type, row[column.key] ?? null, null).value;
          const act = actRows[i]?.[column.key] ?? null;
          if (sameValue(column.type, exp, act)) matched += 1;
        }
      });
      tables.push({ key: field.key, expectedRows: expRows.length, actualRows: actRows.length, cells: expRows.length * columns.length, matched });
      continue;
    }
    const exp = normalizeValue(field.type as Exclude<FieldDef["type"], "table">, expected.fields[field.key] ?? null, field.options).value;
    const act = result.ok ? (result.fields[field.key]?.value ?? null) : null;
    fields.push({ key: field.key, label: field.label, expected: exp, actual: act, match: result.ok && sameValue(field.type as ScalarType, exp, act) });
  }
  return { name, form: form.id, ok: result.ok, fields, tables };
}

export function summarizeScores(scores: DocScore[]) {
  const byForm: Record<string, { docs: number; fieldAccuracy: number }> = {};
  let fieldTotal = 0;
  let fieldMatched = 0;
  let cellTotal = 0;
  let cellMatched = 0;
  const perForm = new Map<string, { docs: number; total: number; matched: number }>();
  for (const s of scores) {
    const f = perForm.get(s.form) ?? { docs: 0, total: 0, matched: 0 };
    f.docs += 1;
    for (const field of s.fields) {
      fieldTotal += 1;
      f.total += 1;
      if (field.match) {
        fieldMatched += 1;
        f.matched += 1;
      }
    }
    for (const t of s.tables) {
      cellTotal += t.cells;
      cellMatched += t.matched;
    }
    perForm.set(s.form, f);
  }
  for (const [id, f] of perForm) byForm[id] = { docs: f.docs, fieldAccuracy: f.total === 0 ? 0 : f.matched / f.total };
  return {
    docs: scores.length,
    failed: scores.filter((s) => !s.ok).length,
    fieldAccuracy: fieldTotal === 0 ? 0 : fieldMatched / fieldTotal,
    cellAccuracy: cellTotal === 0 ? 0 : cellMatched / cellTotal,
    byForm,
  };
}
