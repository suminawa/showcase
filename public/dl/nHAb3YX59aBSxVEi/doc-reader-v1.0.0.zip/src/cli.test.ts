import { describe, expect, it } from "vitest";
import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { collectFiles, parseArgs, runCommand } from "./cli";

const samples = new URL("../samples", import.meta.url).pathname;
const forms = new URL("../forms", import.meta.url).pathname;

describe("parseArgs", () => {
  it("run / check / forms / help を読む", () => {
    expect(parseArgs(["run", "a.pdf", "b/", "--form", "receipt", "--out", "r.csv", "--concurrency", "3"])).toEqual({ kind: "run", paths: ["a.pdf", "b/"], form: "receipt", out: "r.csv", concurrency: 3, model: null });
    expect(parseArgs(["run", "a.pdf"])).toEqual({ kind: "run", paths: ["a.pdf"], form: null, out: null, concurrency: 2, model: null });
    expect(parseArgs(["check", "--model", "claude-sonnet-5"])).toEqual({ kind: "check", model: "claude-sonnet-5" });
    expect(parseArgs(["forms"])).toEqual({ kind: "forms" });
    expect(parseArgs([])).toEqual({ kind: "help" });
    expect(parseArgs(["run"])).toEqual({ kind: "help" });
  });
  it("--out には値が要る。--concurrency は 1〜4", () => {
    expect(() => parseArgs(["run", "a.pdf", "--out"])).toThrow(/--out/);
    expect(parseArgs(["run", "a.pdf", "--concurrency", "9"])).toMatchObject({ concurrency: 4 });
  });
});

describe("collectFiles", () => {
  it("フォルダは 1 段だけ、対応する拡張子だけ、名前順", async () => {
    const files = await collectFiles([join(samples, "docs")]);
    expect(files.length).toBe(12);
    expect(files[0].endsWith("application-01.pdf")).toBe(true);
    expect(await collectFiles([join(samples, "docs", "invoice-01.pdf"), join(samples, "README.md")])).toEqual([join(samples, "docs", "invoice-01.pdf")]);
  });
});

describe("runCommand", () => {
  it("run は見本を鍵なし（偽の答え）で読み、CSV を書く", async () => {
    const out: string[] = [];
    const dir = await mkdtemp(join(tmpdir(), "dr-"));
    const code = await runCommand(
      { kind: "run", paths: [join(samples, "docs", "invoice-01.pdf"), join(samples, "docs", "invoice-03.pdf")], form: "invoice", out: join(dir, "r.csv"), concurrency: 2, model: null },
      { cwd: samples.replace(/\/samples$/, ""), env: { READER_FAKE: "1" }, log: (l) => out.push(l), formsDir: forms, samplesDir: samples },
    );
    expect(code).toBe(0);
    const csv = await readFile(join(dir, "r.csv"), "utf8");
    expect(csv.split("\r\n")[0]).toContain("請求元");
    expect(csv.split("\r\n").filter((l) => l !== "").length).toBe(3);
    expect(out.join("\n")).toContain("2 件");
  });

  it("check は見本 12 枚の一致率を出す（偽の答えなので 100%）", async () => {
    const out: string[] = [];
    const code = await runCommand({ kind: "check", model: null }, { cwd: samples.replace(/\/samples$/, ""), env: { READER_FAKE: "1" }, log: (l) => out.push(l), formsDir: forms, samplesDir: samples });
    expect(code).toBe(0);
    expect(out.join("\n")).toContain("12 枚");
    expect(out.join("\n")).toContain("100%");
  });

  it("forms は型の一覧", async () => {
    const out: string[] = [];
    await runCommand({ kind: "forms" }, { cwd: "", env: {}, log: (l) => out.push(l), formsDir: forms, samplesDir: samples });
    expect(out.join("\n")).toContain("invoice");
    expect(out.join("\n")).toContain("請求書");
  });
});
