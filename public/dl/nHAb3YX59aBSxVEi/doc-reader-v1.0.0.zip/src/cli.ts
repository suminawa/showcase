import { readdir, readFile, stat, writeFile } from "node:fs/promises";
import { basename, extname, join, resolve } from "node:path";
import { formatReport, runEval } from "../eval/run";
import { createAnthropicClient } from "./core/client";
import { resolveConfig } from "./core/config";
import { loadConfigFile } from "./core/config-fs";
import { toCsv } from "./core/csv";
import { inspectDocument, sha256Hex } from "./core/document";
import { extractDocument } from "./core/extract";
import { loadFakeAnswers, SAMPLE_EXTENSIONS } from "./core/fake-answers-fs";
import { createFakeClient } from "./core/fake-client";
import { loadForms } from "./core/forms-fs";
import type { AnthropicClientLike, Extraction, ExtractResult, ReaderConfig } from "./core/types";
import { isMainModule } from "./adapters/main-module";

export type Command =
  | { kind: "run"; paths: string[]; form: string | null; out: string | null; concurrency: number; model: string | null }
  | { kind: "check"; model: string | null }
  | { kind: "forms" }
  | { kind: "help" };

export const HELP = `使い方:
  npx doc-reader run <ファイルかフォルダ…> [--form <型>] [--out 結果.csv|結果.jsonl] [--concurrency 2] [--model <モデル>]
  npx doc-reader check [--model <モデル>]     同梱の見本 12 枚を読んで、期待値との一致率を出します
  npx doc-reader forms                          使える帳票の型と項目の一覧

環境変数: ANTHROPIC_API_KEY（必須。READER_FAKE=1 なら鍵なしで見本だけ読めます）`;

export function parseArgs(argv: string[]): Command {
  const [kind, ...rest] = argv;
  if (kind === "forms") return { kind: "forms" };
  if (kind === "check") return { kind: "check", model: valueOf(rest, "--model") };
  if (kind !== "run") return { kind: "help" };
  const paths: string[] = [];
  let form: string | null = null;
  let out: string | null = null;
  let concurrency = 2;
  let model: string | null = null;
  for (let i = 0; i < rest.length; i += 1) {
    const arg = rest[i];
    if (arg === "--form" || arg === "--out" || arg === "--concurrency" || arg === "--model") {
      const value = rest[i + 1];
      if (value === undefined || value.startsWith("--")) throw new Error(`${arg} には値が要ります`);
      i += 1;
      if (arg === "--form") form = value;
      else if (arg === "--out") out = value;
      else if (arg === "--model") model = value;
      else concurrency = Math.min(4, Math.max(1, Number.parseInt(value, 10) || 2));
      continue;
    }
    paths.push(arg);
  }
  if (paths.length === 0) return { kind: "help" };
  return { kind: "run", paths, form, out, concurrency, model };
}

function valueOf(args: string[], name: string): string | null {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] !== undefined ? args[i + 1] : null;
}

const supported = (file: string): boolean => SAMPLE_EXTENSIONS.includes(extname(file).slice(1).toLowerCase());

/** ファイルはそのまま、フォルダは 1 段だけ。対応する拡張子だけを名前順に */
export async function collectFiles(paths: string[]): Promise<string[]> {
  const files: string[] = [];
  for (const path of paths) {
    const info = await stat(path).catch(() => null);
    if (info === null) continue;
    if (info.isDirectory()) {
      for (const name of (await readdir(path)).sort()) if (supported(name)) files.push(join(path, name));
    } else if (supported(path)) files.push(path);
  }
  return files;
}

export interface CliIo {
  cwd: string;
  env: Record<string, string | undefined>;
  log: (line: string) => void;
  /** テストで差し替える。既定は cwd の forms と samples */
  formsDir?: string;
  samplesDir?: string;
}

async function clientFor(config: ReaderConfig, samplesDir: string): Promise<AnthropicClientLike | null> {
  if (config.fake) return createFakeClient(await loadFakeAnswers(samplesDir));
  if (config.apiKey === null) return null;
  return createAnthropicClient(config.apiKey);
}

async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    for (;;) {
      const i = next;
      next += 1;
      if (i >= items.length) return;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}

export async function runCommand(command: Command, io: CliIo): Promise<number> {
  if (command.kind === "help") {
    io.log(HELP);
    return 0;
  }
  const formsDir = io.formsDir ?? resolve(io.cwd, "forms");
  const samplesDir = io.samplesDir ?? resolve(io.cwd, "samples");
  if (command.kind === "forms") {
    const forms = await loadForms(formsDir);
    for (const form of forms.values()) {
      io.log(`${form.id}  ${form.name}`);
      for (const f of form.fields) io.log(`  - ${f.key}  ${f.label}（${f.type}${f.required ? "・必須" : ""}）`);
    }
    return 0;
  }
  const file = await loadConfigFile(resolve(io.cwd, "reader.config.json"));
  const config = resolveConfig({ file, env: io.env });
  if (command.model !== null) config.model = command.model;
  const client = await clientFor(config, samplesDir);
  if (client === null) {
    io.log("ANTHROPIC_API_KEY が設定されていません。鍵を入れるか、READER_FAKE=1 で見本だけお試しください。");
    return 1;
  }
  if (command.kind === "check") {
    const { scores, summary } = await runEval({ samplesDir, formsDir, config, client, log: io.log });
    io.log(formatReport(summary, scores));
    return summary.failed === 0 ? 0 : 1;
  }
  const forms = await loadForms(formsDir);
  const form = forms.get(command.form ?? config.defaultForm);
  if (form === undefined) {
    io.log(`帳票の型「${command.form ?? config.defaultForm}」が見つかりません。npx doc-reader forms で一覧を確かめてください。`);
    return 1;
  }
  const files = await collectFiles(command.paths.map((p) => resolve(io.cwd, p)));
  if (files.length === 0) {
    io.log("読み取れるファイルがありません（PDF・JPEG・PNG・WebP）。");
    return 1;
  }
  const results = await mapLimit(files, command.concurrency, async (path): Promise<{ path: string; result: Extraction }> => {
    const bytes = new Uint8Array(await readFile(path));
    const inspected = await inspectDocument(basename(path), bytes);
    if (!inspected.ok) return { path, result: { ok: false, code: "unsupported", message: inspected.message } };
    const documentId = await sha256Hex(bytes);
    const result = await extractDocument({ client, config, form, document: inspected.input, pages: inspected.pages, documentId });
    const head = result.ok ? Object.values(result.fields).slice(0, 2).map((f) => (f.value === null ? "-" : String(f.value))).join(" / ") : result.message;
    io.log(`${basename(path)}: ${result.ok ? (result.needsReview ? "要確認" : "OK") : "失敗"}  ${head}`);
    return { path, result };
  });
  const okResults = results.map((r) => r.result).filter((r): r is ExtractResult => r.ok);
  const failed = results.length - okResults.length;
  const review = okResults.filter((r) => r.needsReview).length;
  if (command.out !== null) {
    const outPath = resolve(io.cwd, command.out);
    if (outPath.endsWith(".jsonl")) await writeFile(outPath, results.map((r) => JSON.stringify(r.result)).join("\n") + "\n");
    else await writeFile(outPath, toCsv(form, okResults));
    io.log(`${command.out} に書きました。`);
  }
  io.log(`${results.length} 件のうち、要確認 ${review} 件、読めなかったもの ${failed} 件。`);
  return failed === 0 ? 0 : 1;
}

export async function main(argv: string[] = process.argv.slice(2)): Promise<void> {
  let command: Command;
  try {
    command = parseArgs(argv);
  } catch (error) {
    console.error((error as Error).message);
    process.exitCode = 1;
    return;
  }
  try {
    process.exitCode = await runCommand(command, { cwd: process.cwd(), env: process.env, log: (line) => console.log(line) });
  } catch (error) {
    console.error(`doc-reader: ${(error as Error).message}`);
    process.exitCode = 1;
  }
}

if (isMainModule(process.argv[1], import.meta.url)) {
  void main();
}
