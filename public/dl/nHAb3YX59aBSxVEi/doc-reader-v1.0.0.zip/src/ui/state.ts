import type { ExtractResult, ReaderLabels, ScalarValue, TableRow } from "../core/types";

export type DocStatus = "waiting" | "reading" | "review" | "done" | "failed";

export interface DocItem {
  id: string;
  fileName: string;
  status: DocStatus;
  result: ExtractResult | null;
  error: string | null;
  sent: boolean;
}

export interface UiState {
  form: string;
  items: DocItem[];
  selected: string | null;
  message: string | null;
}

export type UiAction =
  | { type: "add"; items: Array<{ id: string; fileName: string }> }
  | { type: "start"; id: string }
  | { type: "succeed"; id: string; result: ExtractResult }
  | { type: "fail"; id: string; message: string }
  | { type: "retry"; id: string }
  | { type: "select"; id: string | null }
  | { type: "edit"; id: string; key: string; value: ScalarValue }
  | { type: "editCell"; id: string; table: string; row: number; column: string; value: ScalarValue }
  | { type: "addRow"; id: string; table: string; columns: string[] }
  | { type: "removeRow"; id: string; table: string; row: number }
  | { type: "confirm"; id: string }
  | { type: "remove"; id: string }
  | { type: "setForm"; form: string }
  | { type: "sent"; ids: string[] }
  | { type: "message"; text: string | null };

export function initialState(form: string): UiState {
  return { form, items: [], selected: null, message: null };
}

const update = (state: UiState, id: string, fn: (item: DocItem) => DocItem): UiState => ({
  ...state,
  items: state.items.map((item) => (item.id === id ? fn(item) : item)),
});

const updateResult = (state: UiState, id: string, fn: (result: ExtractResult) => ExtractResult): UiState =>
  update(state, id, (item) => (item.result === null ? item : { ...item, result: fn(item.result) }));

export function reducer(state: UiState, action: UiAction): UiState {
  switch (action.type) {
    case "add":
      return { ...state, items: [...state.items, ...action.items.map((i) => ({ ...i, status: "waiting" as const, result: null, error: null, sent: false }))] };
    case "start":
      return update(state, action.id, (item) => ({ ...item, status: "reading", error: null }));
    case "succeed": {
      const next = update(state, action.id, (item) => ({ ...item, status: action.result.needsReview ? "review" : "done", result: action.result, error: null }));
      // 要確認になった最初の書類を開く。すでに何かを開いていれば動かさない
      return { ...next, selected: state.selected ?? (action.result.needsReview ? action.id : null) };
    }
    case "fail":
      return update(state, action.id, (item) => ({ ...item, status: "failed", error: action.message }));
    case "retry":
      return update(state, action.id, (item) => ({ ...item, status: "waiting", error: null, result: null }));
    case "select":
      return { ...state, selected: action.id };
    case "edit":
      return updateResult(state, action.id, (r) => ({
        ...r,
        fields: { ...r.fields, [action.key]: { value: action.value, confidence: 1, evidence: r.fields[action.key]?.evidence ?? "" } },
      }));
    case "editCell":
      return updateResult(state, action.id, (r) => {
        const table = r.tables[action.table];
        if (table === undefined) return r;
        const rows = table.rows.map((row, i) => (i === action.row ? { ...row, [action.column]: action.value } : row));
        return { ...r, tables: { ...r.tables, [action.table]: { ...table, rows } } };
      });
    case "addRow":
      return updateResult(state, action.id, (r) => {
        const table = r.tables[action.table] ?? { rows: [], confidence: 1 };
        const empty: TableRow = Object.fromEntries(action.columns.map((c) => [c, null]));
        return { ...r, tables: { ...r.tables, [action.table]: { ...table, rows: [...table.rows, empty] } } };
      });
    case "removeRow":
      return updateResult(state, action.id, (r) => {
        const table = r.tables[action.table];
        if (table === undefined) return r;
        return { ...r, tables: { ...r.tables, [action.table]: { ...table, rows: table.rows.filter((_, i) => i !== action.row) } } };
      });
    case "confirm": {
      const next = update(state, action.id, (item) =>
        item.result === null ? item : { ...item, status: "done", result: { ...item.result, needsReview: false, warnings: [] } },
      );
      return { ...next, selected: state.selected === action.id ? null : state.selected };
    }
    case "remove":
      return { ...state, items: state.items.filter((i) => i.id !== action.id), selected: state.selected === action.id ? null : state.selected };
    case "setForm":
      return { ...state, form: action.form };
    case "sent":
      return { ...state, items: state.items.map((i) => (action.ids.includes(i.id) ? { ...i, sent: true } : i)) };
    case "message":
      return { ...state, message: action.text };
  }
}

export const nextWaiting = (state: UiState): DocItem | undefined => state.items.find((i) => i.status === "waiting");
export const readingCount = (state: UiState): number => state.items.filter((i) => i.status === "reading").length;
export const confirmedResults = (state: UiState): ExtractResult[] =>
  state.items.filter((i) => i.status === "done" && i.result !== null).map((i) => i.result as ExtractResult);
export const unsentConfirmed = (state: UiState): DocItem[] => state.items.filter((i) => i.status === "done" && i.result !== null && !i.sent);

export function statusLabel(status: DocStatus, labels: ReaderLabels): string {
  const map: Record<DocStatus, string> = {
    waiting: labels.statusWaiting,
    reading: labels.statusReading,
    review: labels.statusReview,
    done: labels.statusDone,
    failed: labels.statusFailed,
  };
  return map[status];
}
