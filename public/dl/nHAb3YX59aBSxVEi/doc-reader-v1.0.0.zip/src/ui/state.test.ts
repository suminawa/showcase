import { describe, expect, it } from "vitest";
import { DEFAULT_LABELS } from "../core/config";
import type { ExtractResult } from "../core/types";
import { confirmedResults, initialState, nextWaiting, readingCount, reducer, statusLabel, unsentConfirmed } from "./state";

const result = (needsReview: boolean): ExtractResult => ({
  ok: true, documentId: "d", form: "invoice", fileName: "a.pdf", pages: 1,
  fields: { issuer: { value: "x", confidence: 0.9, evidence: "" }, total: { value: 100, confidence: 0.5, evidence: "" } },
  tables: { lineItems: { rows: [{ description: "a", amount: 100 }], confidence: 0.9 } },
  warnings: needsReview ? [{ key: "total", code: "confidence", message: "低い" }] : [], needsReview, notes: "",
  usage: { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 }, ms: 0,
});

describe("reducer", () => {
  it("add → start → succeed で要確認か確定になり、選択が動く", () => {
    let s = reducer(initialState("invoice"), { type: "add", items: [{ id: "1", fileName: "a.pdf" }, { id: "2", fileName: "b.pdf" }] });
    expect(s.items.map((i) => i.status)).toEqual(["waiting", "waiting"]);
    expect(nextWaiting(s)?.id).toBe("1");
    s = reducer(s, { type: "start", id: "1" });
    expect(readingCount(s)).toBe(1);
    s = reducer(s, { type: "succeed", id: "1", result: result(true) });
    expect(s.items[0].status).toBe("review");
    expect(s.selected).toBe("1");
    s = reducer(s, { type: "start", id: "2" });
    s = reducer(s, { type: "succeed", id: "2", result: result(false) });
    expect(s.items[1].status).toBe("done");
    expect(confirmedResults(s)).toHaveLength(1);
  });

  it("fail は failed とメッセージ、retry で待ちに戻る", () => {
    let s = reducer(initialState("invoice"), { type: "add", items: [{ id: "1", fileName: "a.pdf" }] });
    s = reducer(s, { type: "fail", id: "1", message: "読めませんでした" });
    expect(s.items[0]).toMatchObject({ status: "failed", error: "読めませんでした" });
    s = reducer(s, { type: "retry", id: "1" });
    expect(s.items[0]).toMatchObject({ status: "waiting", error: null });
  });

  it("edit は値を書き換えて信頼度を 1 にし、confirm で確定、表の行は足したり消したりできる", () => {
    let s = reducer(initialState("invoice"), { type: "add", items: [{ id: "1", fileName: "a.pdf" }] });
    s = reducer(s, { type: "succeed", id: "1", result: result(true) });
    s = reducer(s, { type: "edit", id: "1", key: "total", value: 200 });
    expect(s.items[0].result?.fields.total).toEqual({ value: 200, confidence: 1, evidence: "" });
    s = reducer(s, { type: "addRow", id: "1", table: "lineItems", columns: ["description", "amount"] });
    expect(s.items[0].result?.tables.lineItems.rows).toHaveLength(2);
    s = reducer(s, { type: "editCell", id: "1", table: "lineItems", row: 1, column: "amount", value: 50 });
    expect(s.items[0].result?.tables.lineItems.rows[1]).toEqual({ description: null, amount: 50 });
    s = reducer(s, { type: "removeRow", id: "1", table: "lineItems", row: 0 });
    expect(s.items[0].result?.tables.lineItems.rows).toHaveLength(1);
    s = reducer(s, { type: "confirm", id: "1" });
    expect(s.items[0].status).toBe("done");
    expect(s.items[0].result?.needsReview).toBe(false);
    expect(s.selected).toBeNull();
  });

  it("remove で消え、sent で印が付き、unsentConfirmed は未送信の確定だけ", () => {
    let s = reducer(initialState("invoice"), { type: "add", items: [{ id: "1", fileName: "a.pdf" }, { id: "2", fileName: "b.pdf" }] });
    s = reducer(s, { type: "succeed", id: "1", result: result(false) });
    s = reducer(s, { type: "succeed", id: "2", result: result(false) });
    expect(unsentConfirmed(s)).toHaveLength(2);
    s = reducer(s, { type: "sent", ids: ["1"] });
    expect(unsentConfirmed(s).map((i) => i.id)).toEqual(["2"]);
    s = reducer(s, { type: "remove", id: "2" });
    expect(s.items).toHaveLength(1);
  });

  it("setForm は型を変え、message は文言を出し入れする", () => {
    let s = reducer(initialState("invoice"), { type: "setForm", form: "receipt" });
    expect(s.form).toBe("receipt");
    s = reducer(s, { type: "message", text: "送りました" });
    expect(s.message).toBe("送りました");
    expect(reducer(s, { type: "message", text: null }).message).toBeNull();
  });

  it("statusLabel は labels の文言", () => {
    expect(statusLabel("review", DEFAULT_LABELS)).toBe("要確認");
    expect(statusLabel("failed", DEFAULT_LABELS)).toBe("読めませんでした");
  });
});
