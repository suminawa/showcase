import type { FieldResult, FormDef, Warning } from "./types";
import { dedupeKeyFields } from "./forms";

export const DEDUPE_MESSAGES = {
  sameFile: "同じファイルを本日すでに読み込んでいます。",
  sameKeys: (labels: string[], values: string[]) =>
    `同じ${labels.map((l) => `「${l}」`).join("")}（${values.join(" / ")}）の書類を本日すでに読み込んでいます。`,
} as const;

const JST_OFFSET_MS = 9 * 60 * 60 * 1000;
/** 複合キーの区切り。値に混ざらない文字 */
const SEP = String.fromCharCode(1);

export interface DedupeState {
  day: string;
  ids: Set<string>;
  keys: Set<string>;
}

export function createDedupeState(): DedupeState {
  return { day: "", ids: new Set(), keys: new Set() };
}

/** 日本時間の YYYY-MM-DD。夏時間が無いので UTC に +9 時間して切り出すだけでよい */
export function dayKeyOf(now: number): string {
  return new Date(now + JST_OFFSET_MS).toISOString().slice(0, 10);
}

export interface NoteInput {
  documentId: string;
  form: FormDef;
  fields: Record<string, FieldResult>;
  now: number;
}

/** 当日の記録に照らして重複の警告を返し、記録に足す。値そのものは残さない（鍵にするだけ） */
export function noteDocument(state: DedupeState, input: NoteInput): Warning[] {
  const day = dayKeyOf(input.now);
  if (state.day !== day) {
    state.day = day;
    state.ids.clear();
    state.keys.clear();
  }
  const warnings: Warning[] = [];
  const sameFile = state.ids.has(input.documentId);
  if (sameFile) warnings.push({ key: null, code: "duplicate", message: DEDUPE_MESSAGES.sameFile });
  state.ids.add(input.documentId);

  const keys = dedupeKeyFields(input.form);
  const values = keys.map((key) => input.fields[key]?.value ?? null);
  if (keys.length > 0 && values.every((v) => v !== null)) {
    const composite = [input.form.id, ...values.map(String)].join(SEP);
    // 同じファイルなら主キーも同じなので、二重には鳴らさない。記録だけは必ず足す
    if (!sameFile && state.keys.has(composite)) {
      const labels = keys.map((key) => input.form.fields.find((f) => f.key === key)?.label ?? key);
      warnings.push({ key: keys[0], code: "duplicate", message: DEDUPE_MESSAGES.sameKeys(labels, values.map(String)) });
    }
    state.keys.add(composite);
  }
  return warnings;
}
