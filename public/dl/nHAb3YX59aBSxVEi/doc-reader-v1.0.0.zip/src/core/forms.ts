import type { CheckDef, ColumnDef, ColumnType, FieldDef, FieldType, FormDef, ScalarType } from "./types";

export class FormError extends Error {}

export const FIELD_TYPES: readonly FieldType[] = ["string", "number", "money", "date", "boolean", "enum", "table"];
export const COLUMN_TYPES: readonly ColumnType[] = ["string", "number", "money", "date"];
export const MAX_FIELDS = 60;
export const MAX_COLUMNS = 12;

const ID_RE = /^[a-z][a-z0-9-]*$/;
const KEY_RE = /^[a-z][a-zA-Z0-9]*$/;
const NUMERIC: readonly string[] = ["number", "money"];
/** 行の見出しに使う主キーの候補。この順で採る */
const KEY_CANDIDATES = ["invoiceNumber", "orderNumber", "receiptNumber", "name", "issuer", "company"];
/** そのうち、書類そのものを指さないもの（同じ相手の別の書類でも同じ値になる） */
const WEAK_KEYS: readonly string[] = ["name", "issuer", "company"];

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

function fail(source: string, message: string): never {
  throw new FormError(`帳票の型 ${source}: ${message}`);
}

function parseColumn(raw: unknown, source: string, fieldKey: string, seen: Set<string>): ColumnDef {
  if (!isRecord(raw)) fail(source, `${fieldKey} の columns の要素はオブジェクトにしてください`);
  const key = raw.key;
  if (typeof key !== "string" || !KEY_RE.test(key)) fail(source, `${fieldKey} の columns の key は英字で始まる英数字にしてください`);
  if (seen.has(key)) fail(source, `${fieldKey} の columns の key「${key}」が重複しています`);
  seen.add(key);
  if (typeof raw.label !== "string" || raw.label.trim() === "") fail(source, `${fieldKey} の columns の label を書いてください`);
  if (!COLUMN_TYPES.includes(raw.type as ColumnType)) fail(source, `${fieldKey} の columns の type は ${COLUMN_TYPES.join(" / ")} のどれかにしてください`);
  return { key, label: raw.label.trim(), type: raw.type as ColumnType };
}

function parseField(raw: unknown, source: string, seen: Set<string>): FieldDef {
  if (!isRecord(raw)) fail(source, "fields の要素はオブジェクトにしてください");
  const key = raw.key;
  if (typeof key !== "string" || !KEY_RE.test(key)) fail(source, "fields の key は英字で始まる英数字にしてください（例: invoiceNumber）");
  if (seen.has(key)) fail(source, `fields の key「${key}」が重複しています`);
  seen.add(key);
  if (typeof raw.label !== "string" || raw.label.trim() === "") fail(source, `${key} の label を書いてください`);
  const type = raw.type;
  if (!FIELD_TYPES.includes(type as FieldType)) fail(source, `${key} の type は ${FIELD_TYPES.join(" / ")} のどれかにしてください`);
  const field: FieldDef = {
    key,
    label: raw.label.trim(),
    type: type as FieldType,
    required: raw.required === true,
    hint: typeof raw.hint === "string" && raw.hint.trim() !== "" ? raw.hint.trim() : null,
    pattern: null,
    options: null,
    columns: null,
  };
  if (raw.pattern !== undefined) {
    if (type !== "string" || typeof raw.pattern !== "string") fail(source, `${key} の pattern は string の項目にだけ書けます`);
    try {
      new RegExp(raw.pattern);
    } catch {
      fail(source, `${key} の pattern が正規表現として読めません`);
    }
    field.pattern = raw.pattern;
  }
  if (type === "enum") {
    const options = raw.options;
    if (!Array.isArray(options) || options.length < 2 || !options.every((o) => typeof o === "string" && o.trim() !== "")) {
      fail(source, `${key} の options は 2 つ以上の文字列にしてください`);
    }
    const trimmed = (options as string[]).map((o) => o.trim());
    if (new Set(trimmed).size !== trimmed.length) fail(source, `${key} の options が重複しています`);
    field.options = trimmed;
  }
  if (type === "table") {
    const columns = raw.columns;
    if (!Array.isArray(columns) || columns.length === 0 || columns.length > MAX_COLUMNS) {
      fail(source, `${key} の columns は 1〜${MAX_COLUMNS} 列にしてください`);
    }
    const seenColumns = new Set<string>();
    field.columns = columns.map((c) => parseColumn(c, source, key, seenColumns));
  }
  return field;
}

function parseCheck(raw: unknown, source: string, fields: FieldDef[]): CheckDef {
  if (!isRecord(raw)) fail(source, "checks の要素はオブジェクトにしてください");
  if (raw.type !== "sum") fail(source, "checks の type は sum だけです");
  const numericField = (key: unknown): FieldDef | undefined =>
    fields.find((f) => f.key === key && NUMERIC.includes(f.type));
  const equals = raw.equals;
  if (typeof equals !== "string" || numericField(equals) === undefined) fail(source, "checks の equals は number か money の項目の key にしてください");
  const tolerance = typeof raw.tolerance === "number" && raw.tolerance >= 0 ? raw.tolerance : 1;
  if (typeof raw.items === "string") {
    const [tableKey, columnKey] = raw.items.split(".");
    const table = fields.find((f) => f.key === tableKey && f.type === "table");
    const column = table?.columns?.find((c) => c.key === columnKey);
    if (table === undefined || column === undefined || !NUMERIC.includes(column.type)) {
      fail(source, "checks の items は「表の key.数か金額の列の key」にしてください（例: lineItems.amount）");
    }
    return { type: "sum", items: raw.items, parts: null, equals, tolerance };
  }
  if (Array.isArray(raw.parts) && raw.parts.length > 0 && raw.parts.every((p) => numericField(p) !== undefined)) {
    return { type: "sum", items: null, parts: raw.parts as string[], equals, tolerance };
  }
  fail(source, "checks には items か parts（number か money の項目の key の配列）を書いてください");
}

export function parseForm(raw: unknown, source: string = "form"): FormDef {
  if (!isRecord(raw)) fail(source, "オブジェクトにしてください");
  const id = raw.id;
  if (typeof id !== "string" || !ID_RE.test(id)) fail(source, "id は小文字の英字で始まる英数字とハイフンにしてください");
  if (typeof raw.name !== "string" || raw.name.trim() === "") fail(source, "name を書いてください");
  if (!Array.isArray(raw.fields) || raw.fields.length === 0 || raw.fields.length > MAX_FIELDS) {
    fail(source, `fields は 1〜${MAX_FIELDS} 個にしてください`);
  }
  const seen = new Set<string>();
  const fields = raw.fields.map((f) => parseField(f, source, seen));
  const checksRaw = raw.checks === undefined ? [] : raw.checks;
  if (!Array.isArray(checksRaw)) fail(source, "checks は配列にしてください");
  const checks = checksRaw.map((c) => parseCheck(c, source, fields));
  return {
    id,
    name: raw.name.trim(),
    description: typeof raw.description === "string" ? raw.description.trim() : "",
    fields,
    checks,
  };
}

export interface CustomFieldInput {
  label: string;
  type?: ScalarType;
  key?: string;
}

/** 画面の「自由項目」。項目名を並べただけの型を作る（表は作れない） */
export function customForm(inputs: CustomFieldInput[]): FormDef {
  if (!Array.isArray(inputs) || inputs.length === 0 || inputs.length > MAX_FIELDS) {
    fail("自由項目", `項目は 1〜${MAX_FIELDS} 個にしてください`);
  }
  const fields = inputs.map((input, i) => {
    const label = typeof input.label === "string" ? input.label.trim() : "";
    if (label === "") fail("自由項目", `${i + 1} 番目の項目名が空です`);
    const type: ScalarType = input.type !== undefined && FIELD_TYPES.includes(input.type) && (input.type as string) !== "table" ? input.type : "string";
    const key = typeof input.key === "string" && KEY_RE.test(input.key) ? input.key : `f${i + 1}`;
    return { key, label, type, required: false, hint: null, pattern: null, options: null, columns: null };
  });
  const seen = new Set<string>();
  for (const field of fields) {
    if (seen.has(field.key)) fail("自由項目", `key「${field.key}」が重複しています`);
    seen.add(field.key);
  }
  return { id: "custom", name: "自由項目", description: "", fields, checks: [] };
}

const TYPE_NOTE: Record<ScalarType | ColumnType, string> = {
  string: "書かれている文字をそのまま",
  number: "数。桁区切りや単位が付いていてもそのままの文字で",
  money: "金額。「¥」「円」「,」が付いていてもそのままの文字で",
  date: "日付。和暦や「2026/9/13」のような表記もそのままの文字で",
  boolean: "はい／いいえ、有／無、チェックの有無。書かれている文字で",
  enum: "選択肢のどれか",
};

const nullableString = (description: string): Record<string, unknown> => ({
  anyOf: [{ type: "string" }, { type: "null" }],
  description,
});

function valueDescription(label: string, type: ScalarType | ColumnType, hint: string | null, options: string[] | null): string {
  const parts = [label, TYPE_NOTE[type]];
  if (options !== null) parts.push(`選択肢: ${options.join(" / ")}`);
  if (hint !== null) parts.push(hint);
  parts.push("書類に無ければ null");
  return parts.join("。");
}

/** 帳票の型 → structured outputs に渡す JSON Schema */
export function toOutputSchema(form: FormDef): Record<string, unknown> {
  const fieldProps: Record<string, unknown> = {};
  const fieldKeys: string[] = [];
  const tableProps: Record<string, unknown> = {};
  const tableKeys: string[] = [];
  for (const field of form.fields) {
    if (field.type === "table") {
      const columns = field.columns ?? [];
      const rowProps: Record<string, unknown> = {};
      for (const column of columns) rowProps[column.key] = nullableString(valueDescription(column.label, column.type, null, null));
      tableProps[field.key] = {
        type: "object",
        description: `${field.label}${field.hint === null ? "" : `。${field.hint}`}。1 行 1 要素`,
        properties: {
          rows: { type: "array", items: { type: "object", properties: rowProps, required: columns.map((c) => c.key), additionalProperties: false } },
          confidence: { type: "number", description: "表全体の読み取りの確かさ。0 から 1" },
        },
        required: ["rows", "confidence"],
        additionalProperties: false,
      };
      tableKeys.push(field.key);
      continue;
    }
    fieldProps[field.key] = {
      type: "object",
      properties: {
        value: nullableString(valueDescription(field.label, field.type, field.hint, field.options)),
        confidence: { type: "number", description: "この値の確かさ。0 から 1。書類に根拠が無ければ低く" },
        evidence: { type: "string", description: "書類に書かれていた文字そのまま。無ければ空の文字" },
      },
      required: ["value", "confidence", "evidence"],
      additionalProperties: false,
    };
    fieldKeys.push(field.key);
  }
  return {
    type: "object",
    properties: {
      fields: { type: "object", properties: fieldProps, required: fieldKeys, additionalProperties: false },
      tables: { type: "object", properties: tableProps, required: tableKeys, additionalProperties: false },
      notes: { type: "string", description: "読めなかった箇所や迷った点。無ければ空の文字" },
    },
    required: ["fields", "tables", "notes"],
    additionalProperties: false,
  };
}

export interface FormSummary {
  id: string;
  name: string;
  description: string;
  fields: Array<{ key: string; label: string; type: FieldType; required: boolean; options: string[] | null; columns: ColumnDef[] | null }>;
}

export function formSummary(form: FormDef): FormSummary {
  return {
    id: form.id,
    name: form.name,
    description: form.description,
    fields: form.fields.map((f) => ({ key: f.key, label: f.label, type: f.type, required: f.required, options: f.options, columns: f.columns })),
  };
}

export function findField(form: FormDef, key: string): FieldDef | undefined {
  return form.fields.find((f) => f.key === key);
}

export function keyFields(form: FormDef): string[] {
  const found = KEY_CANDIDATES.filter((key) => form.fields.some((f) => f.key === key && f.type !== "table"));
  if (found.length > 0) return found;
  const first = form.fields.find((f) => f.type === "string");
  return first === undefined ? [] : [first.key];
}

/**
 * 重複の見分けに使う主キー。2 つそろったときだけ複合キーにする（請求書は請求書番号 + 請求元）。
 * 1 つしか無いときは、書類の番号のときだけ使う。「発行者」や「お名前」だけで見分けると、
 * 同じお店の別の領収書や、同じ方の別の申込書まで重複に見えてしまう
 */
export function dedupeKeyFields(form: FormDef): string[] {
  const found = KEY_CANDIDATES.filter((key) => form.fields.some((f) => f.key === key && f.type !== "table"));
  if (found.length >= 2) return found;
  if (found.length === 1 && !WEAK_KEYS.includes(found[0])) return found;
  return [];
}
