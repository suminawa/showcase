import type { ExtractResult, FieldDef, FormDef, ScalarValue } from "./types";
import { keyFields } from "./forms";

export const BOM = "﻿";
const HEAD = ["書類ID", "ファイル名"];

const text = (value: ScalarValue): string => {
  if (value === null) return "";
  if (typeof value === "boolean") return value ? "はい" : "いいえ";
  return String(value);
};

/**
 * 表計算ソフトが数式として実行しないよう、= + - @ で始まる文字には ' を付ける。
 * 頭に空白やタブがあっても見る（Excel は文字として扱いますが、表計算ソフトによっては空白を落としてから読みます）
 */
export const guardFormula = (s: string): string => (/^\s*[=+\-@]/.test(s) ? `'${s}` : s);

export function csvCell(value: ScalarValue): string {
  const s = typeof value === "string" ? guardFormula(value) : text(value);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function tsvCell(value: ScalarValue): string {
  const s = typeof value === "string" ? guardFormula(value) : text(value);
  return s.replace(/[\t\r\n]+/g, " ");
}

export const scalarFields = (form: FormDef): FieldDef[] => form.fields.filter((f) => f.type !== "table");
export const tableFields = (form: FormDef): FieldDef[] => form.fields.filter((f) => f.type === "table");

function rowsOf(form: FormDef, results: ExtractResult[]): ScalarValue[][] {
  const fields = scalarFields(form);
  return results.map((r) => [r.documentId, r.fileName, ...fields.map((f) => r.fields[f.key]?.value ?? null)]);
}

export function toCsv(form: FormDef, results: ExtractResult[]): string {
  const header = [...HEAD, ...scalarFields(form).map((f) => f.label)];
  const lines = [header, ...rowsOf(form, results)].map((row) => row.map(csvCell).join(","));
  return BOM + lines.join("\r\n") + "\r\n";
}

export function toTsv(form: FormDef, results: ExtractResult[]): string {
  const header = [...HEAD, ...scalarFields(form).map((f) => f.label)];
  const lines = [header, ...rowsOf(form, results)].map((row) => row.map(tsvCell).join("\t"));
  return lines.join("\n") + "\n";
}

/** 明細を 1 行 1 レコードで。親の書類が分かるよう、書類ID・ファイル名・主キー項目を先頭に付ける */
export function toLinesCsv(form: FormDef, results: ExtractResult[], tableKey: string): string {
  const keys = keyFields(form).map((key) => form.fields.find((f) => f.key === key)).filter((f): f is FieldDef => f !== undefined);
  const table = form.fields.find((f) => f.key === tableKey && f.type === "table");
  const columns = table?.columns ?? [];
  const header = [...HEAD, ...keys.map((f) => f.label), "行", ...columns.map((c) => c.label)];
  const rows: ScalarValue[][] = [];
  if (table !== undefined) {
    for (const r of results) {
      const parents: ScalarValue[] = [r.documentId, r.fileName, ...keys.map((f) => r.fields[f.key]?.value ?? null)];
      (r.tables[tableKey]?.rows ?? []).forEach((row, i) => {
        rows.push([...parents, i + 1, ...columns.map((c) => row[c.key] ?? null)]);
      });
    }
  }
  const lines = [header, ...rows].map((row) => row.map(csvCell).join(","));
  return BOM + lines.join("\r\n") + "\r\n";
}
