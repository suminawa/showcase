import type { ExtractErrorCode, LimitsConfig } from "./types";

export interface Bucket {
  tokens: number;
  updatedAt: number;
}

export interface GuardState {
  minute: Map<string, Bucket>;
  hour: Map<string, Bucket>;
  day: { key: string; count: number };
}

export type GuardVerdict = { ok: true } | { ok: false; status: number; code: ExtractErrorCode; message: string };

export const GUARD_MESSAGES = {
  forbidden: "このページからのご利用は受け付けておりません。",
  rateLimited: "少し時間をおいてからお試しください。",
  dailyLimit: "本日の読み取りの受付は終了しました。",
  tooLarge: (mb: number) => `ファイルは ${mb} MB までにしてください。`,
  tooManyPages: (pages: number) => `PDF は ${pages} ページまでにしてください。分けてお試しください。`,
} as const;

/** Node のアダプタが接続元のアドレスを押すヘッダー。訪問者が名乗っても必ず上書きされる */
export const REMOTE_ADDR_HEADER = "x-reader-remote-addr";

const MINUTE_MS = 60 * 1000;
const HOUR_MS = 60 * MINUTE_MS;
const JST_OFFSET_MS = 9 * HOUR_MS;

/** IP ごとのバケツを覚えておく数の上限。超えたら最後に使ったのが古いものから捨てる */
export const MAX_KEYS = 10000;

export function createGuardState(): GuardState {
  return { minute: new Map(), hour: new Map(), day: { key: "", count: 0 } };
}

function dayKeyOf(now: number): string {
  return new Date(now + JST_OFFSET_MS).toISOString().slice(0, 10);
}

/** ALLOWED_ORIGINS が空のときは「自分のサイトから」だけを許す */
export function originAllowed(origin: string | null, allowed: string[], selfOrigin: string | null): boolean {
  if (origin === null || origin === "") return true;
  if (selfOrigin !== null && origin === selfOrigin) return true;
  return allowed.includes(origin);
}

export function checkOrigin(origin: string | null, allowed: string[], selfOrigin: string | null): GuardVerdict {
  if (originAllowed(origin, allowed, selfOrigin)) return { ok: true };
  return { ok: false, status: 403, code: "forbidden", message: GUARD_MESSAGES.forbidden };
}

/** pages が null（数えられなかった PDF）のときはページの上限を当てない。読み取りは通し、警告で知らせる */
export function checkSize(bytes: number, pages: number | null, limits: LimitsConfig): GuardVerdict {
  if (bytes > limits.maxFileBytes) {
    return { ok: false, status: 413, code: "too_large", message: GUARD_MESSAGES.tooLarge(Math.round(limits.maxFileBytes / 1024 / 1024)) };
  }
  if (pages !== null && pages > limits.maxPages) {
    return { ok: false, status: 413, code: "too_many_pages", message: GUARD_MESSAGES.tooManyPages(limits.maxPages) };
  }
  return { ok: true };
}

/** トークンバケツ。最初は満タンで、windowMs のあいだに capacity 個ぶん戻る */
export function takeToken(bucket: Bucket | undefined, capacity: number, windowMs: number, now: number): { bucket: Bucket; ok: boolean } {
  const previous = bucket ?? { tokens: capacity, updatedAt: now };
  const refilled = Math.min(capacity, previous.tokens + ((now - previous.updatedAt) * capacity) / windowMs);
  if (refilled < 1) return { bucket: { tokens: refilled, updatedAt: now }, ok: false };
  return { bucket: { tokens: refilled - 1, updatedAt: now }, ok: true };
}

function touch(map: Map<string, Bucket>, ip: string, bucket: Bucket): void {
  map.delete(ip);
  map.set(ip, bucket);
}

function evict(map: Map<string, Bucket>, windowMs: number, now: number): void {
  for (const [ip, bucket] of map) {
    if (now - bucket.updatedAt < windowMs) break;
    map.delete(ip);
  }
  while (map.size > MAX_KEYS) {
    const oldest = map.keys().next();
    if (oldest.done === true) break;
    map.delete(oldest.value);
  }
}

export function checkRate(state: GuardState, ip: string, limits: LimitsConfig, now: number): GuardVerdict {
  const perMinute = takeToken(state.minute.get(ip), limits.perMinute, MINUTE_MS, now);
  touch(state.minute, ip, perMinute.bucket);
  evict(state.minute, MINUTE_MS, now);
  // 分の上限で断った要求は、時間の枠を減らさない（断られた相手の 1 時間の枠が消えていくのは筋が悪い）
  if (!perMinute.ok) return { ok: false, status: 429, code: "rate_limited", message: GUARD_MESSAGES.rateLimited };
  const perHour = takeToken(state.hour.get(ip), limits.perHour, HOUR_MS, now);
  touch(state.hour, ip, perHour.bucket);
  evict(state.hour, HOUR_MS, now);
  if (!perHour.ok) return { ok: false, status: 429, code: "rate_limited", message: GUARD_MESSAGES.rateLimited };
  return { ok: true };
}

export function checkDaily(state: GuardState, limits: LimitsConfig, now: number): GuardVerdict {
  const key = dayKeyOf(now);
  if (state.day.key !== key) {
    state.day.key = key;
    state.day.count = 0;
  }
  if (state.day.count >= limits.daily) return { ok: false, status: 429, code: "daily_limit", message: GUARD_MESSAGES.dailyLimit };
  state.day.count += 1;
  return { ok: true };
}

/**
 * 回数の上限を数える鍵。TRUST_PROXY のときは proxy が足した x-forwarded-for の末尾
 * （proxy 自身が付けた、いちばん信用できる値）。そうでなければ Node のアダプタが押した接続元。
 */
export function clientIpOf(request: Request, trustProxy: boolean): string {
  if (trustProxy) {
    const forwarded = request.headers.get("x-forwarded-for");
    if (forwarded !== null) {
      const parts = forwarded.split(",").map((s) => s.trim()).filter((s) => s !== "");
      if (parts.length > 0) return parts[parts.length - 1];
    }
  }
  return request.headers.get(REMOTE_ADDR_HEADER) ?? "unknown";
}
