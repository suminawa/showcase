import { describe, expect, it } from "vitest";
import { BOM, csvCell, toCsv, toLinesCsv, toTsv, tsvCell } from "./csv";
import { parseForm } from "./forms";
import type { ExtractResult } from "./types";

const form = parseForm({
  id: "invoice",
  name: "請求書",
  fields: [
    { key: "issuer", label: "請求元", type: "string" },
    { key: "invoiceNumber", label: "請求書番号", type: "string" },
    { key: "issueDate", label: "発行日", type: "date" },
    { key: "total", label: "合計金額", type: "money" },
    { key: "paid", label: "入金済", type: "boolean" },
    { key: "lineItems", label: "明細", type: "table", columns: [{ key: "description", label: "品名", type: "string" }, { key: "amount", label: "金額", type: "money" }] },
  ],
});

const result = (over: Partial<ExtractResult> = {}): ExtractResult => ({
  ok: true,
  documentId: "id1",
  form: "invoice",
  fileName: "a.pdf",
  pages: 1,
  fields: {
    issuer: { value: "さくら設備, 東京", confidence: 1, evidence: "" },
    invoiceNumber: { value: "=INV-1", confidence: 1, evidence: "" },
    issueDate: { value: "2026-09-01", confidence: 1, evidence: "" },
    total: { value: 11000, confidence: 1, evidence: "" },
    paid: { value: false, confidence: 1, evidence: "" },
  },
  tables: { lineItems: { rows: [{ description: "配管\n工事", amount: 6000 }, { description: "部材", amount: null }], confidence: 1 } },
  warnings: [],
  needsReview: false,
  notes: "",
  usage: { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 },
  ms: 0,
  ...over,
});

describe("csvCell / tsvCell", () => {
  it("null は空、真偽は はい／いいえ、数はそのまま、カンマ・引用符・改行は引用、数式の頭文字は守る", () => {
    expect(csvCell(null)).toBe("");
    expect(csvCell(true)).toBe("はい");
    expect(csvCell(false)).toBe("いいえ");
    expect(csvCell(12800)).toBe("12800");
    expect(csvCell("a,b")).toBe('"a,b"');
    expect(csvCell('say "hi"')).toBe('"say ""hi"""');
    expect(csvCell("line\nbreak")).toBe('"line\nbreak"');
    expect(csvCell("=SUM(A1)")).toBe("'=SUM(A1)");
    expect(csvCell("+1")).toBe("'+1");
    expect(csvCell("-1")).toBe("'-1");
    expect(csvCell("@x")).toBe("'@x");
    expect(tsvCell("a\tb\nc")).toBe("a b c");
    expect(tsvCell("=x")).toBe("'=x");
  });

  it("数式の頭文字は前に空白やタブがあっても守る", () => {
    expect(csvCell(" =SUM(A1)")).toBe("' =SUM(A1)");
    expect(csvCell("\t=x")).toBe("'\t=x");
    expect(csvCell("  @x")).toBe("'  @x");
    expect(tsvCell("\t=x")).toBe("' =x");
    // 数式でない文字はそのまま
    expect(csvCell(" さくら設備")).toBe(" さくら設備");
  });
});

describe("toCsv", () => {
  it("BOM・見出し・行。表の項目は入れない。行末は CRLF", () => {
    const csv = toCsv(form, [result()]);
    expect(csv.startsWith(BOM)).toBe(true);
    const lines = csv.slice(1).split("\r\n");
    expect(lines[0]).toBe("書類ID,ファイル名,請求元,請求書番号,発行日,合計金額,入金済");
    expect(lines[1]).toBe('id1,a.pdf,"さくら設備, 東京",\'=INV-1,2026-09-01,11000,いいえ');
    expect(lines[2]).toBe("");
  });
  it("結果が無ければ見出しだけ", () => {
    expect(toCsv(form, []).slice(1)).toBe("書類ID,ファイル名,請求元,請求書番号,発行日,合計金額,入金済\r\n");
  });
});

describe("toTsv", () => {
  it("BOM なし・タブ区切り・LF", () => {
    const tsv = toTsv(form, [result()]);
    expect(tsv.startsWith(BOM)).toBe(false);
    expect(tsv.split("\n")[1]).toBe("id1\ta.pdf\tさくら設備, 東京\t'=INV-1\t2026-09-01\t11000\tいいえ");
  });
});

describe("toLinesCsv", () => {
  it("明細は 1 行 1 レコード。書類ID・ファイル名・主キー項目・行番号・列", () => {
    const lines = toLinesCsv(form, [result()], "lineItems").slice(1).split("\r\n");
    expect(lines[0]).toBe("書類ID,ファイル名,請求書番号,請求元,行,品名,金額");
    expect(lines[1]).toBe('id1,a.pdf,\'=INV-1,"さくら設備, 東京",1,"配管\n工事",6000');
    expect(lines[2]).toBe("id1,a.pdf,'=INV-1,\"さくら設備, 東京\",2,部材,");
  });
  it("無い表の key は見出しだけ", () => {
    expect(toLinesCsv(form, [result()], "nope").slice(1)).toBe("書類ID,ファイル名,請求書番号,請求元,行\r\n");
  });
});
