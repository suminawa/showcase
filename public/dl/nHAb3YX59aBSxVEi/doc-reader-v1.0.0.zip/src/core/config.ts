import type { EffortLevel, LimitsConfig, ReaderConfig, ReaderLabels } from "./types";

export const DEFAULT_MODEL = "claude-opus-5";
export const DEFAULT_MAX_TOKENS = 4096;
export const DEFAULT_THRESHOLD = 0.8;
export const EFFORTS: readonly EffortLevel[] = ["low", "medium", "high"];

export const DEFAULT_LIMITS: LimitsConfig = {
  maxFileBytes: 10 * 1024 * 1024,
  maxPages: 20,
  perMinute: 5,
  perHour: 30,
  daily: 200,
};

export const DEFAULT_LABELS: ReaderLabels = {
  title: "書類の読み取り",
  dropHere: "ここに書類を置くか、ファイルを選んでください（PDF・JPEG・PNG・WebP、1 ファイル 10 MB まで）",
  choose: "ファイルを選ぶ",
  formLabel: "帳票の型",
  customFields: "自由項目",
  statusWaiting: "待ち",
  statusReading: "読み取り中",
  statusReview: "要確認",
  statusDone: "確定",
  statusFailed: "読めませんでした",
  confirm: "確定",
  retry: "もう一度",
  remove: "取り消す",
  saveCsv: "CSV を保存",
  saveLinesCsv: "明細の CSV を保存",
  copyTsv: "TSV をコピー",
  send: "スプレッドシートに送る",
  sent: "送りました",
  lowConfidence: "読み取りに自信がありません。書類を見て確かめてください。",
  privacy: "書類はサーバーに保存しません。読み取りの結果はこのブラウザの中にだけ残ります。",
};

export interface ResolveConfigInput {
  file?: unknown;
  env?: Record<string, string | undefined>;
}

const asRecord = (value: unknown): Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

const asString = (value: unknown, fallback: string): string =>
  typeof value === "string" && value.trim() !== "" ? value : fallback;

const asPositiveInt = (value: unknown, fallback: number): number =>
  typeof value === "number" && Number.isInteger(value) && value > 0 ? value : fallback;

const asEffort = (value: unknown): EffortLevel => (EFFORTS.includes(value as EffortLevel) ? (value as EffortLevel) : "low");

const asThreshold = (value: unknown): number =>
  typeof value === "number" && value >= 0 && value <= 1 ? value : DEFAULT_THRESHOLD;

const envText = (env: Record<string, string | undefined>, key: string): string | null => {
  const value = (env[key] ?? "").trim();
  return value === "" ? null : value;
};

/** "https://a.example/path" → "https://a.example"。URL でないものは捨てる */
export function normalizeOrigins(raw: string | null): string[] {
  if (raw === null) return [];
  const out: string[] = [];
  for (const piece of raw.split(",")) {
    const text = piece.trim();
    if (text === "") continue;
    try {
      const origin = new URL(text).origin;
      if (origin !== "null" && !out.includes(origin)) out.push(origin);
    } catch {
      // URL でない項目は無視する
    }
  }
  return out;
}

export function resolveConfig(input: ResolveConfigInput = {}): ReaderConfig {
  const file = asRecord(input.file);
  const env = input.env ?? {};
  const site = asRecord(file.site);
  const limitsIn = asRecord(file.limits);
  const labelsIn = asRecord(file.labels);
  const sendIn = asRecord(file.send);

  const labels: ReaderLabels = { ...DEFAULT_LABELS };
  for (const key of Object.keys(DEFAULT_LABELS) as (keyof ReaderLabels)[]) {
    const value = labelsIn[key];
    if (typeof value === "string" && value.trim() !== "") labels[key] = value;
  }

  const dailyFromEnv = Number(env.DAILY_LIMIT);
  const daily = Number.isInteger(dailyFromEnv) && dailyFromEnv > 0 ? dailyFromEnv : asPositiveInt(limitsIn.daily, DEFAULT_LIMITS.daily);

  return {
    site: { name: asString(site.name, "書類の読み取り") },
    formsDir: asString(file.forms, "forms"),
    defaultForm: asString(file.defaultForm, "invoice"),
    model: asString(file.model, DEFAULT_MODEL),
    effort: asEffort(file.effort),
    maxTokens: asPositiveInt(file.maxTokens, DEFAULT_MAX_TOKENS),
    confidenceThreshold: asThreshold(file.confidenceThreshold),
    limits: {
      maxFileBytes: asPositiveInt(limitsIn.maxFileBytes, DEFAULT_LIMITS.maxFileBytes),
      maxPages: asPositiveInt(limitsIn.maxPages, DEFAULT_LIMITS.maxPages),
      perMinute: asPositiveInt(limitsIn.perMinute, DEFAULT_LIMITS.perMinute),
      perHour: asPositiveInt(limitsIn.perHour, DEFAULT_LIMITS.perHour),
      daily,
    },
    send: { sheet: asString(sendIn.sheet, "読み取り") },
    labels,
    apiKey: envText(env, "ANTHROPIC_API_KEY"),
    adminToken: envText(env, "ADMIN_TOKEN"),
    allowedOrigins: normalizeOrigins(envText(env, "ALLOWED_ORIGINS")),
    trustProxy: env.TRUST_PROXY === "1",
    sendWebhookUrl: envText(env, "SEND_WEBHOOK_URL"),
    sendToken: envText(env, "SEND_TOKEN"),
    logWebhookUrl: envText(env, "LOG_WEBHOOK_URL"),
    fake: env.READER_FAKE === "1",
  };
}
