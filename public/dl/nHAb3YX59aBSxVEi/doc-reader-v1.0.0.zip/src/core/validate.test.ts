import { describe, expect, it } from "vitest";
import { parseForm } from "./forms";
import type { RawExtraction } from "./types";
import { clampConfidence, validateExtraction } from "./validate";

const invoice = parseForm({
  id: "invoice",
  name: "請求書",
  fields: [
    { key: "issuer", label: "請求元", type: "string", required: true },
    { key: "invoiceNumber", label: "請求書番号", type: "string" },
    { key: "issueDate", label: "発行日", type: "date", required: true },
    { key: "subtotal", label: "税抜金額", type: "money" },
    { key: "tax", label: "消費税", type: "money" },
    { key: "total", label: "合計金額", type: "money", required: true },
    { key: "registrationNumber", label: "登録番号", type: "string", pattern: "^T\\d{13}$" },
    { key: "lineItems", label: "明細", type: "table", columns: [{ key: "description", label: "品名", type: "string" }, { key: "amount", label: "金額", type: "money" }] },
  ],
  checks: [
    { type: "sum", items: "lineItems.amount", equals: "subtotal" },
    { type: "sum", parts: ["subtotal", "tax"], equals: "total" },
  ],
});

const good: RawExtraction = {
  fields: {
    issuer: { value: "さくら設備", confidence: 0.98, evidence: "さくら設備" },
    invoiceNumber: { value: "INV-001", confidence: 0.95, evidence: "No. INV-001" },
    issueDate: { value: "令和8年9月1日", confidence: 0.9, evidence: "令和8年9月1日" },
    subtotal: { value: "10,000", confidence: 0.97, evidence: "小計 10,000" },
    tax: { value: "1,000", confidence: 0.97, evidence: "消費税 1,000" },
    total: { value: "¥11,000", confidence: 0.99, evidence: "合計 ¥11,000" },
    registrationNumber: { value: "T1234567890123", confidence: 0.9, evidence: "T1234567890123" },
  },
  tables: { lineItems: { rows: [{ description: "配管工事", amount: "6,000" }, { description: "部材", amount: "4,000" }], confidence: 0.9 } },
  notes: "",
};

describe("validateExtraction", () => {
  it("正しい読み取りは警告なし・needsReview false・値は変換済み", () => {
    const out = validateExtraction(invoice, good, 0.8);
    expect(out.warnings).toEqual([]);
    expect(out.needsReview).toBe(false);
    expect(out.fields.issueDate.value).toBe("2026-09-01");
    expect(out.fields.total.value).toBe(11000);
    expect(out.fields.total.evidence).toBe("合計 ¥11,000");
    expect(out.tables.lineItems.rows).toEqual([{ description: "配管工事", amount: 6000 }, { description: "部材", amount: 4000 }]);
  });

  it("必須が null なら required、形式違いは pattern、変換できなければ invalid", () => {
    const raw: RawExtraction = {
      ...good,
      fields: {
        ...good.fields,
        issuer: { value: null, confidence: 0, evidence: "" },
        registrationNumber: { value: "T123", confidence: 0.9, evidence: "T123" },
        issueDate: { value: "来月末", confidence: 0.9, evidence: "来月末" },
      },
    };
    const out = validateExtraction(invoice, raw, 0.8);
    const codes = out.warnings.map((w) => `${w.key}:${w.code}`);
    expect(codes).toContain("issuer:required");
    expect(codes).toContain("registrationNumber:pattern");
    expect(codes).toContain("issueDate:invalid");
    expect(codes).toContain("issueDate:required");
    expect(out.needsReview).toBe(true);
    expect(out.warnings.find((w) => w.code === "required" && w.key === "issuer")?.message).toBe("「請求元」が読み取れませんでした。書類を見てご入力ください。");
  });

  it("信頼度が閾値未満なら confidence の警告（値は残す）", () => {
    const raw: RawExtraction = { ...good, fields: { ...good.fields, total: { value: "11,000", confidence: 0.5, evidence: "" } } };
    const out = validateExtraction(invoice, raw, 0.8);
    expect(out.warnings).toEqual([{ key: "total", code: "confidence", message: "「合計金額」は読み取りに自信がありません（50%）。書類を見て確かめてください。" }]);
    expect(out.fields.total.value).toBe(11000);
  });

  it("表の信頼度が閾値未満なら confidence の警告。行が無ければ鳴らさない", () => {
    const raw: RawExtraction = { ...good, tables: { lineItems: { rows: good.tables.lineItems.rows, confidence: 0.2 } } };
    const out = validateExtraction(invoice, raw, 0.8);
    expect(out.warnings).toEqual([{ key: "lineItems", code: "confidence", message: "「明細」は読み取りに自信がありません（20%）。書類を見て確かめてください。" }]);
    expect(out.needsReview).toBe(true);
    expect(out.tables.lineItems.rows).toHaveLength(2);
    const empty: RawExtraction = { ...good, tables: { lineItems: { rows: [], confidence: 0 } } };
    expect(validateExtraction(invoice, empty, 0.8).warnings).toEqual([]);
  });

  it("突き合わせ: 明細の合計と税抜、税抜 + 税と税込", () => {
    const raw: RawExtraction = { ...good, fields: { ...good.fields, total: { value: "12,000", confidence: 0.99, evidence: "" } } };
    const out = validateExtraction(invoice, raw, 0.8);
    expect(out.warnings).toEqual([{ key: "total", code: "check", message: "「税抜金額」+「消費税」の合計（11,000）と「合計金額」（12,000）が合いません。" }]);
    const raw2: RawExtraction = { ...good, tables: { lineItems: { rows: [{ description: "a", amount: "9,000" }], confidence: 0.9 } } };
    expect(validateExtraction(invoice, raw2, 0.8).warnings[0]).toEqual({ key: "subtotal", code: "check", message: "「明細」の「金額」の合計（9,000）と「税抜金額」（10,000）が合いません。" });
  });

  it("突き合わせは許容差の中なら鳴らさず、null が混ざれば行わない", () => {
    const raw: RawExtraction = { ...good, fields: { ...good.fields, total: { value: "11,001", confidence: 0.99, evidence: "" } } };
    expect(validateExtraction(invoice, raw, 0.8).warnings).toEqual([]);
    const raw2: RawExtraction = { ...good, fields: { ...good.fields, tax: { value: null, confidence: 0, evidence: "" } } };
    expect(validateExtraction(invoice, raw2, 0.8).warnings.filter((w) => w.code === "check")).toEqual([]);
  });

  it("表のセルが変換できなければ invalid（列ごとに 1 回）、notes があれば notes の警告", () => {
    const raw: RawExtraction = {
      ...good,
      tables: { lineItems: { rows: [{ description: "a", amount: "一式" }, { description: "b", amount: "x" }], confidence: 0.9 } },
      notes: "印影で金額の一部が読めません",
    };
    const out = validateExtraction(invoice, raw, 0.8);
    expect(out.warnings.filter((w) => w.code === "invalid")).toEqual([{ key: "lineItems", code: "invalid", message: "「明細」の「金額」に読めない行があります（一式 ほか）。" }]);
    expect(out.warnings.find((w) => w.code === "notes")).toEqual({ key: null, code: "notes", message: "読み取りの注記: 印影で金額の一部が読めません" });
    expect(out.tables.lineItems.rows[0].amount).toBeNull();
  });

  it("モデルの答えに無い項目は null・confidence 0・空の evidence として扱い、余分な項目は捨てる", () => {
    const raw = { fields: { issuer: { value: "x", confidence: 1, evidence: "x" }, extra: { value: "y", confidence: 1, evidence: "" } }, tables: {}, notes: "" } as unknown as RawExtraction;
    const out = validateExtraction(invoice, raw, 0.8);
    expect(out.fields.total).toEqual({ value: null, confidence: 0, evidence: "" });
    expect((out.fields as Record<string, unknown>).extra).toBeUndefined();
    expect(out.tables.lineItems).toEqual({ rows: [], confidence: 0 });
  });

  it("clampConfidence は 0〜1 に収め、数でなければ 0", () => {
    expect(clampConfidence(1.4)).toBe(1);
    expect(clampConfidence(-1)).toBe(0);
    expect(clampConfidence("0.5")).toBe(0);
    expect(clampConfidence(Number.NaN)).toBe(0);
  });
});
