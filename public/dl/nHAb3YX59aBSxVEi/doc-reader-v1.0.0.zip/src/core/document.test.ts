import { deflateSync } from "node:zlib";
import { describe, expect, it } from "vitest";
import { fromBase64, inspectDocument, pdfPageCount, sha256Hex, sniffMediaType, toBase64 } from "./document";

const bytes = (...parts: Array<string | number[]>): Uint8Array => {
  const out: number[] = [];
  for (const part of parts) {
    if (typeof part === "string") for (const ch of part) out.push(ch.charCodeAt(0) & 0xff);
    else out.push(...part);
  }
  return Uint8Array.from(out);
};

describe("sniffMediaType", () => {
  it("magic bytes で PDF・JPEG・PNG・WebP・GIF・HEIC を見分ける", () => {
    expect(sniffMediaType(bytes("%PDF-1.7\n"))).toBe("application/pdf");
    expect(sniffMediaType(bytes([0xff, 0xd8, 0xff, 0xe0]))).toBe("image/jpeg");
    expect(sniffMediaType(bytes([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))).toBe("image/png");
    expect(sniffMediaType(bytes("RIFF", [0, 0, 0, 0], "WEBPVP8 "))).toBe("image/webp");
    expect(sniffMediaType(bytes("GIF89a"))).toBe("image/gif");
    expect(sniffMediaType(bytes([0, 0, 0, 0x18], "ftypheic"))).toBe("image/heic");
    expect(sniffMediaType(bytes("hello"))).toBeNull();
    expect(sniffMediaType(new Uint8Array(0))).toBeNull();
  });
});

/**
 * PDF 1.5 風のファイルを組む。ページの辞書はオブジェクトストリームに畳んで圧縮する
 * （zlib を使うのはこのテストの中だけ。src/core は Web 標準の DecompressionStream で開く）
 */
function pdfWithObjectStream(pageCount: number, eolBeforeEndstream = true, extraDict = ""): Uint8Array {
  const pages = Array.from({ length: pageCount }, (_, i) => `<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Contents ${i + 10} 0 R>>`);
  const inner = `<</Type/Pages/Count ${pageCount}/Kids[]>>${pages.join("")}`;
  const compressed = deflateSync(Buffer.from(inner, "latin1"));
  const head = `%PDF-1.5\n1 0 obj\n<</Type/ObjStm/N ${pageCount + 1}/First 24/Filter/FlateDecode${extraDict}/Length ${compressed.length}>>\nstream\n`;
  const tail = `${eolBeforeEndstream ? "\n" : ""}endstream\nendobj\ntrailer\n<</Root 3 0 R>>\n%%EOF\n`;
  return Uint8Array.from([...Buffer.from(head, "latin1"), ...compressed, ...Buffer.from(tail, "latin1")]);
}

describe("pdfPageCount", () => {
  it("/Type /Page を数え、/Pages は数えない", async () => {
    expect(await pdfPageCount(bytes("%PDF-1.4 1 0 obj << /Type /Pages /Kids [] >> 2 0 obj << /Type /Page >> 3 0 obj <</Type/Page>>"))).toBe(2);
  });

  it("/Type /Page が無ければ、ページの木の /Count のうち最大のものを採る", async () => {
    expect(await pdfPageCount(bytes("%PDF-1.5 1 0 obj << /Type /Pages /Count 30 /Kids [2 0 R] >> 2 0 obj << /Type /Pages /Count 12 >>"))).toBe(30);
  });

  it("圧縮されたオブジェクトストリームの中の /Type /Page も数える（PDF 1.5 以降）", async () => {
    expect(await pdfPageCount(pdfWithObjectStream(30))).toBe(30);
    expect(await pdfPageCount(pdfWithObjectStream(1))).toBe(1);
    // endstream の前に改行が無い書き方でも数えられる
    expect(await pdfPageCount(pdfWithObjectStream(3, false))).toBe(3);
    // 辞書に入れ子の辞書（/DecodeParms<<…>>）があっても、オブジェクトストリームと分かる
    expect(await pdfPageCount(pdfWithObjectStream(30, true, "/DecodeParms<</Predictor 12/Columns 5>>"))).toBe(30);
  });

  it("stream の語だけを並べた 1 MB のファイルでも、すぐに返って例外も投げない", async () => {
    // 辞書も /Type /Page も /Count も無いので、いちばん手間のかかる道（オブジェクトストリームの走査）に入る
    const crafted = bytes("%PDF-1.5\n<<\n" + "stream endstream ".repeat(62_000));
    expect(crafted.byteLength).toBeGreaterThan(1_000_000);
    const startedAt = Date.now();
    expect(await pdfPageCount(crafted)).toBeNull();
    expect(await inspectDocument("a.pdf", crafted)).toMatchObject({ ok: true, pages: null });
    expect(Date.now() - startedAt).toBeLessThan(1000);
  });

  it("どこにも手がかりが無ければ null（数えられなかった）", async () => {
    expect(await pdfPageCount(bytes("%PDF-1.4 << /Type /Pages >>"))).toBeNull();
    expect(await pdfPageCount(bytes("%PDF-1.7\n1 0 obj\n<</Type/Catalog>>\n%%EOF"))).toBeNull();
    // 開けない（壊れた）オブジェクトストリームも null
    expect(await pdfPageCount(bytes("%PDF-1.5 1 0 obj <</Type/ObjStm/Filter/FlateDecode>>\nstream\nnot-deflate\nendstream"))).toBeNull();
  });
});

describe("sha256Hex / base64", () => {
  it("同じ中身は同じ id（32 桁）、違えば違う", async () => {
    const a = await sha256Hex(bytes("abc"));
    expect(a).toBe("ba7816bf8f01cfea414140de5dae2223");
    expect(await sha256Hex(bytes("abd"))).not.toBe(a);
  });
  it("base64 の往復", () => {
    const data = Uint8Array.from({ length: 70000 }, (_, i) => i % 251);
    expect(fromBase64(toBase64(data))).toEqual(data);
    expect(toBase64(bytes("hi"))).toBe("aGk=");
  });
});

describe("inspectDocument", () => {
  it("PDF はページ数つき、画像は 1 ページ、HEIC と不明は unsupported", async () => {
    const pdf = await inspectDocument("a.pdf", bytes("%PDF-1.4 << /Type /Page >> << /Type /Page >>"));
    expect(pdf).toMatchObject({ ok: true, pages: 2, input: { fileName: "a.pdf", mediaType: "application/pdf" } });
    const jpg = await inspectDocument("b.jpg", bytes([0xff, 0xd8, 0xff]));
    expect(jpg).toMatchObject({ ok: true, pages: 1, input: { mediaType: "image/jpeg" } });
    const heic = await inspectDocument("c.heic", bytes([0, 0, 0, 0x18], "ftypheic"));
    expect(heic).toMatchObject({ ok: false, code: "unsupported" });
    expect((heic as { message: string }).message).toContain("JPEG");
    expect(await inspectDocument("d.txt", bytes("plain"))).toMatchObject({ ok: false, code: "unsupported" });
  });
  it("ページ数を数えられない PDF は pages が null", async () => {
    expect(await inspectDocument("a.pdf", bytes("%PDF-1.7\n<</Type/Catalog>>"))).toMatchObject({ ok: true, pages: null });
  });
  it("ファイル名は 200 字に切り、無ければ「書類」", async () => {
    const long = await inspectDocument("x".repeat(300) + ".pdf", bytes("%PDF-1.4"));
    expect((long as { input: { fileName: string } }).input.fileName.length).toBe(200);
    expect(((await inspectDocument("", bytes("%PDF-1.4"))) as { input: { fileName: string } }).input.fileName).toBe("書類");
  });
});
