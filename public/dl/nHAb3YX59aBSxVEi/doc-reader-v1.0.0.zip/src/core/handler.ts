import type { AnthropicClientLike, ExtractErrorCode, ExtractResult, Extraction, FormDef, ReaderConfig, ScalarValue } from "./types";
import { createAnthropicClient } from "./client";
import { guardFormula, scalarFields, toCsv, toLinesCsv } from "./csv";
import { createDedupeState, noteDocument, type DedupeState } from "./dedupe";
import { fromBase64, inspectDocument, sha256Hex } from "./document";
import { extractDocument } from "./extract";
import { createFakeClient } from "./fake-client";
import { customForm, FormError, formSummary } from "./forms";
import { checkDaily, checkOrigin, checkRate, checkSize, clientIpOf, createGuardState, type GuardState } from "./guard";
import { createLogRing, entryFrom, postWebhook, webhookPayload, adminHtml, type LogSink } from "./log";

export type Route = "extract" | "forms" | "config" | "csv" | "send" | "health" | "admin" | "none";

/** multipart の本文の上限（書類 10 MB + 余白）。config.limits.maxFileBytes は中のファイルの上限 */
export const MAX_BODY_BYTES = 12 * 1024 * 1024;
export const MAX_RESULTS = 1000;
export const MAX_SEND_ROWS = 50;
/** 受け口が詰まっているときだけ届く長さ。受け口側の待ちは 5 秒なので、成功したものを失敗と伝えない */
export const SEND_TIMEOUT_MS = 20000;

export const HANDLER_MESSAGES = {
  unavailable: "いまは読み取れません。しばらくしてからもう一度お試しください。",
  badRequest: "送られた内容を読み取れませんでした。",
  noFile: "ファイルを 1 つ選んでください。",
  noForm: "帳票の型が見つかりません。",
  tooManyResults: `一度に扱えるのは ${MAX_RESULTS} 件までです。`,
  noSend: "スプレッドシートの送り先が設定されていません。",
  tooManySend: `一度に送れるのは ${MAX_SEND_ROWS} 件までです。`,
  sendFailed: "送れませんでした。しばらくしてからもう一度お試しください。",
  method: "POST で送ってください。",
  notFound: "そのような道はありません。",
} as const;

const STATUS: Record<ExtractErrorCode, number> = {
  bad_request: 400,
  forbidden: 403,
  unsupported: 415,
  too_large: 413,
  too_many_pages: 413,
  rate_limited: 429,
  daily_limit: 429,
  unreadable: 422,
  refused: 422,
  unavailable: 503,
};

export function routeOf(url: URL): Route {
  const path = url.pathname.replace(/\/+$/, "");
  for (const route of ["extract", "forms", "config", "csv", "send", "health", "admin"] as const) {
    if (path.endsWith(`/${route}`)) return route;
  }
  return "none";
}

export interface ReaderDeps {
  forms?: Map<string, FormDef>;
  client?: AnthropicClientLike;
  log?: LogSink;
  guard?: GuardState;
  dedupe?: DedupeState;
  now?: () => number;
  fetch?: typeof fetch;
}

export interface Reader {
  fetch(request: Request): Promise<Response>;
  forms: Map<string, FormDef>;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

function jsonResponse(body: unknown, status: number, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers },
  });
}

const failure = (code: ExtractErrorCode, message: string, headers: Record<string, string> = {}): Response =>
  jsonResponse({ ok: false, code, message }, STATUS[code], headers);

/**
 * 合い言葉を突き合わせる。長さが同じなら、どこで食い違っても同じ回数だけ回す
 * （早く終わるかどうかで 1 文字ずつ言い当てられるのを防ぐ）
 */
export function tokenEquals(given: string, expected: string): boolean {
  if (given.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < given.length; i += 1) diff |= given.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

/** ブラウザが素通しできる content-type（text/plain など）で書き込みの道を叩かれないよう、JSON だけを受ける */
const isJsonBody = (request: Request): boolean => (request.headers.get("content-type") ?? "").includes("application/json");

/** スプレッドシートの受け口へ渡す形。表（明細）は送らない */
export function sheetRows(form: FormDef, results: ExtractResult[]): { headers: string[]; rows: Array<Array<string | number>> } {
  const fields = scalarFields(form);
  const cell = (value: ScalarValue): string | number => {
    if (value === null) return "";
    if (typeof value === "boolean") return value ? "はい" : "いいえ";
    // 同梱の受け口も守っているが、買い手が別の受け口（Zapier など）に替えても効くよう、送る側でも数式の頭文字を止める
    return typeof value === "string" ? guardFormula(value) : value;
  };
  return {
    headers: ["書類ID", "ファイル名", ...fields.map((f) => f.label)],
    rows: results.map((r) => [r.documentId, r.fileName, ...fields.map((f) => cell(r.fields[f.key]?.value ?? null))]),
  };
}

function looksLikeResult(value: unknown): value is ExtractResult {
  return isRecord(value) && value.ok === true && typeof value.documentId === "string" && typeof value.form === "string" && typeof value.fileName === "string" && isRecord(value.fields) && isRecord(value.tables);
}

/** /csv と /send の本文。型と結果の配列。壊れていれば null */
export function parseResultsBody(body: unknown, forms: Map<string, FormDef>): { form: FormDef; results: ExtractResult[]; table: string | null } | null {
  if (!isRecord(body) || typeof body.form !== "string" || !Array.isArray(body.results)) return null;
  const form = forms.get(body.form);
  if (form === undefined || !body.results.every(looksLikeResult)) return null;
  // 別の型で読んだ結果を混ぜない（見出しは body.form の型で作るので、混ざると中身のずれた行ができてしまう）
  if (body.results.some((r) => r.form !== form.id)) return null;
  const table = typeof body.table === "string" ? body.table : null;
  // table は型の表の key だけを受ける（ファイル名のヘッダーに入るので、勝手な文字を通さない）
  if (table !== null && !form.fields.some((f) => f.key === table && f.type === "table")) return null;
  return { form, results: body.results as ExtractResult[], table };
}

interface Incoming {
  fileName: string;
  bytes: Uint8Array;
  form: string | null;
  fields: unknown;
}

async function readIncoming(request: Request): Promise<Incoming | "no_file" | "bad"> {
  const type = request.headers.get("content-type") ?? "";
  if (type.startsWith("multipart/form-data")) {
    let data: FormData;
    try {
      data = await request.formData();
    } catch {
      return "bad";
    }
    const file = data.get("file");
    if (!(file instanceof Blob)) return "no_file";
    const fields = data.get("fields");
    let parsedFields: unknown = undefined;
    if (typeof fields === "string" && fields.trim() !== "") {
      try {
        parsedFields = JSON.parse(fields);
      } catch {
        return "bad";
      }
    }
    const form = data.get("form");
    return {
      fileName: file instanceof File ? file.name : "",
      bytes: new Uint8Array(await file.arrayBuffer()),
      form: typeof form === "string" && form.trim() !== "" ? form.trim() : null,
      fields: parsedFields,
    };
  }
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return "bad";
  }
  if (!isRecord(body) || typeof body.data !== "string") return "no_file";
  let bytes: Uint8Array;
  try {
    bytes = fromBase64(body.data);
  } catch {
    return "bad";
  }
  return {
    fileName: typeof body.fileName === "string" ? body.fileName : "",
    bytes,
    form: typeof body.form === "string" && body.form.trim() !== "" ? body.form.trim() : null,
    fields: body.fields,
  };
}

export function createReader(config: ReaderConfig, deps: ReaderDeps = {}): Reader {
  const forms = deps.forms ?? new Map<string, FormDef>();
  const log = deps.log ?? createLogRing();
  const guard = deps.guard ?? createGuardState();
  const dedupe = deps.dedupe ?? createDedupeState();
  const now = deps.now ?? (() => Date.now());
  const doFetch = deps.fetch ?? fetch;
  const client: AnthropicClientLike | null =
    deps.client ?? (config.fake ? createFakeClient(new Map()) : config.apiKey === null ? null : createAnthropicClient(config.apiKey));
  let logId = 0;

  const corsOf = (request: Request): Record<string, string> => {
    const origin = request.headers.get("origin");
    if (origin === null) return {};
    if (!checkOrigin(origin, config.allowedOrigins, new URL(request.url).origin).ok) return {};
    return { "access-control-allow-origin": origin, vary: "Origin" };
  };

  const preflight = (cors: Record<string, string>, methods: string): Response =>
    new Response(null, {
      status: 204,
      headers: { ...cors, "access-control-allow-methods": methods, "access-control-allow-headers": "content-type", "access-control-max-age": "86400" },
    });

  const authorized = (request: Request, url: URL): boolean => {
    if (config.adminToken === null) return false;
    const bearer = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
    return tokenEquals(url.searchParams.get("token") ?? "", config.adminToken) || tokenEquals(bearer, config.adminToken);
  };

  const record = async (result: Extraction, documentId: string, form: string, pages: number | null, startedAt: number): Promise<void> => {
    logId += 1;
    const entry = entryFrom({ id: logId, at: new Date(startedAt).toISOString(), model: config.model, result, documentId, form, pages, ms: now() - startedAt });
    log.push(entry);
    if (config.logWebhookUrl !== null) await postWebhook(config.logWebhookUrl, webhookPayload(entry, config.site.name), doFetch);
  };

  const resolveForm = (incoming: Incoming): FormDef | Response => {
    if (incoming.fields !== undefined) {
      try {
        if (!Array.isArray(incoming.fields)) throw new FormError("自由項目: 項目の配列にしてください");
        return customForm(incoming.fields as never);
      } catch (error) {
        return failure("bad_request", error instanceof FormError ? error.message : HANDLER_MESSAGES.badRequest);
      }
    }
    const form = forms.get(incoming.form ?? config.defaultForm);
    return form === undefined ? failure("bad_request", HANDLER_MESSAGES.noForm) : form;
  };

  async function handleExtract(request: Request, url: URL): Promise<Response> {
    const cors = corsOf(request);
    if (request.method === "OPTIONS") return preflight(cors, "POST, OPTIONS");
    if (request.method !== "POST") return jsonResponse({ ok: false, code: "bad_request", message: HANDLER_MESSAGES.method }, 405, cors);
    const origin = checkOrigin(request.headers.get("origin"), config.allowedOrigins, url.origin);
    if (!origin.ok) return failure(origin.code, origin.message, cors);

    const contentLength = Number(request.headers.get("content-length") ?? "");
    if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
      return failure("too_large", `送信できる大きさを超えています（${Math.round(MAX_BODY_BYTES / 1024 / 1024)} MB まで）。`, cors);
    }
    const incoming = await readIncoming(request);
    if (incoming === "bad") return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    if (incoming === "no_file") return failure("bad_request", HANDLER_MESSAGES.noFile, cors);

    // 大きさは中身の種類が分かる前に確かめる。判定できない中身でも大きすぎれば 413 を返す（DEVIATION: 検討事項参照）
    const earlySize = checkSize(incoming.bytes.byteLength, 0, config.limits);
    if (!earlySize.ok) return failure(earlySize.code, earlySize.message, cors);

    // 回数の枠は書類を調べる前に見る。断る求めに PDF の走査の手間をかけないため
    const at = now();
    const rate = checkRate(guard, clientIpOf(request, config.trustProxy), config.limits, at);
    if (!rate.ok) return failure(rate.code, rate.message, cors);
    const daily = checkDaily(guard, config.limits, at);
    if (!daily.ok) return failure(daily.code, daily.message, cors);

    const inspected = await inspectDocument(incoming.fileName, incoming.bytes);
    if (!inspected.ok) return failure(inspected.code, inspected.message, cors);
    const size = checkSize(incoming.bytes.byteLength, inspected.pages, config.limits);
    if (!size.ok) return failure(size.code, size.message, cors);

    const form = resolveForm(incoming);
    if (form instanceof Response) return form;

    const documentId = await sha256Hex(incoming.bytes);
    if (client === null) {
      const result: Extraction = { ok: false, code: "unavailable", message: HANDLER_MESSAGES.unavailable, reason: "no_key" };
      await record(result, documentId, form.id, inspected.pages, at);
      return failure(result.code, result.message, cors);
    }
    const result = await extractDocument({ client, config, form, document: inspected.input, pages: inspected.pages, documentId, now });
    if (result.ok) {
      const duplicates = noteDocument(dedupe, { documentId, form, fields: result.fields, now: at });
      if (duplicates.length > 0) {
        result.warnings.push(...duplicates);
        result.needsReview = true;
      }
    }
    await record(result, documentId, form.id, inspected.pages, at);
    if (!result.ok) return failure(result.code, result.message, cors);
    return jsonResponse(result, 200, cors);
  }

  async function handleCsv(request: Request, url: URL): Promise<Response> {
    const cors = corsOf(request);
    if (request.method === "OPTIONS") return preflight(cors, "POST, OPTIONS");
    if (request.method !== "POST") return jsonResponse({ ok: false, code: "bad_request", message: HANDLER_MESSAGES.method }, 405, cors);
    const origin = checkOrigin(request.headers.get("origin"), config.allowedOrigins, url.origin);
    if (!origin.ok) return failure(origin.code, origin.message, cors);
    if (!isJsonBody(request)) return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    }
    const parsed = parseResultsBody(body, forms);
    if (parsed === null) return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    if (parsed.results.length > MAX_RESULTS) return failure("bad_request", HANDLER_MESSAGES.tooManyResults, cors);
    const text = parsed.table === null ? toCsv(parsed.form, parsed.results) : toLinesCsv(parsed.form, parsed.results, parsed.table);
    const name = parsed.table === null ? `${parsed.form.id}.csv` : `${parsed.form.id}-${parsed.table}.csv`;
    return new Response(text, {
      status: 200,
      headers: { ...cors, "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="${name}"`, "cache-control": "no-store" },
    });
  }

  async function handleSend(request: Request, url: URL): Promise<Response> {
    const cors = corsOf(request);
    if (request.method === "OPTIONS") return preflight(cors, "POST, OPTIONS");
    if (request.method !== "POST") return jsonResponse({ ok: false, code: "bad_request", message: HANDLER_MESSAGES.method }, 405, cors);
    const origin = checkOrigin(request.headers.get("origin"), config.allowedOrigins, url.origin);
    if (!origin.ok) return failure(origin.code, origin.message, cors);
    if (!isJsonBody(request)) return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    if (config.sendWebhookUrl === null) return failure("bad_request", HANDLER_MESSAGES.noSend, cors);
    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    }
    const parsed = parseResultsBody(body, forms);
    if (parsed === null) return failure("bad_request", HANDLER_MESSAGES.badRequest, cors);
    if (parsed.results.length > MAX_SEND_ROWS) return failure("bad_request", HANDLER_MESSAGES.tooManySend, cors);
    const payload = { token: config.sendToken ?? "", sheet: config.send.sheet, ...sheetRows(parsed.form, parsed.results) };
    try {
      const response = await doFetch(config.sendWebhookUrl, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(SEND_TIMEOUT_MS),
      });
      if (!response.ok) return jsonResponse({ ok: false, code: "unavailable", message: HANDLER_MESSAGES.sendFailed }, 502, cors);
      const reply = (await response.json()) as { ok?: boolean; appended?: number };
      if (reply.ok !== true) return jsonResponse({ ok: false, code: "unavailable", message: HANDLER_MESSAGES.sendFailed }, 502, cors);
      return jsonResponse({ ok: true, appended: typeof reply.appended === "number" ? reply.appended : parsed.results.length }, 200, cors);
    } catch {
      return jsonResponse({ ok: false, code: "unavailable", message: HANDLER_MESSAGES.sendFailed }, 502, cors);
    }
  }

  return {
    forms,
    async fetch(request: Request): Promise<Response> {
      const url = new URL(request.url);
      const route = routeOf(url);
      const cors = corsOf(request);
      if (route === "extract") return handleExtract(request, url);
      if (route === "csv") return handleCsv(request, url);
      if (route === "send") return handleSend(request, url);
      if (route === "forms") {
        if (request.method === "OPTIONS") return preflight(cors, "GET, OPTIONS");
        return jsonResponse(
          { ok: true, forms: [...forms.values()].map(formSummary), defaultForm: config.defaultForm },
          200,
          { ...cors, "cache-control": "public, max-age=300" },
        );
      }
      if (route === "config") {
        if (request.method === "OPTIONS") return preflight(cors, "GET, OPTIONS");
        return jsonResponse(
          {
            ok: true,
            site: config.site,
            labels: config.labels,
            defaultForm: config.defaultForm,
            limits: { maxFileBytes: config.limits.maxFileBytes, maxPages: config.limits.maxPages },
            canSend: config.sendWebhookUrl !== null,
          },
          200,
          { ...cors, "cache-control": "public, max-age=300" },
        );
      }
      if (route === "health") {
        return jsonResponse({ ok: true, forms: forms.size, model: config.model, hasKey: config.apiKey !== null, fake: config.fake }, 200, cors);
      }
      if (route === "admin") {
        if (!authorized(request, url)) return new Response("Not Found", { status: 404 });
        return new Response(adminHtml(config, log.list(), url.searchParams.get("token")), {
          status: 200,
          headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
        });
      }
      return jsonResponse({ ok: false, code: "bad_request", message: HANDLER_MESSAGES.notFound }, 404, cors);
    },
  };
}
