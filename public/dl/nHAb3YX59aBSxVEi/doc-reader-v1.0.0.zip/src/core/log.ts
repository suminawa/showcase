import type { ExtractErrorCode, ExtractResult, Extraction, FailureReason, ReaderConfig } from "./types";

export const LOG_RING_SIZE = 500;
export const WEBHOOK_TIMEOUT_MS = 5000;

/** 記録に残すのは数とコードだけ。ファイル名・読み取った値・警告文は残さない */
export interface LogEntry {
  id: number;
  at: string;
  documentId: string;
  form: string;
  ok: boolean;
  code: ExtractErrorCode | null;
  /** 失敗のもう少し詳しい理由（鍵・通信など）。お客さまへの応答には出さない */
  reason: FailureReason | null;
  needsReview: boolean;
  warningCodes: string[];
  fieldCount: number;
  avgConfidence: number;
  pages: number | null;
  ms: number;
  model: string;
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
}

export interface LogSink {
  push(entry: LogEntry): void;
  /** 新しいものから */
  list(): LogEntry[];
  size(): number;
}

export function createLogRing(size: number = LOG_RING_SIZE): LogSink {
  const entries: LogEntry[] = [];
  return {
    push(entry: LogEntry): void {
      entries.push(entry);
      if (entries.length > size) entries.splice(0, entries.length - size);
    },
    list(): LogEntry[] {
      return [...entries].reverse();
    },
    size(): number {
      return entries.length;
    },
  };
}

export function avgConfidenceOf(result: ExtractResult): number {
  const values = Object.values(result.fields).map((f) => f.confidence);
  if (values.length === 0) return 0;
  return Math.round((values.reduce((a, b) => a + b, 0) / values.length) * 100) / 100;
}

export interface EntryInput {
  id: number;
  at: string;
  model: string;
  result: Extraction;
  documentId: string;
  form: string;
  pages: number | null;
  ms: number;
}

export function entryFrom(input: EntryInput): LogEntry {
  const { result } = input;
  const base = { id: input.id, at: input.at, documentId: input.documentId, form: input.form, pages: input.pages, ms: input.ms, model: input.model };
  if (!result.ok) {
    return { ...base, ok: false, code: result.code, reason: result.reason ?? null, needsReview: false, warningCodes: [], fieldCount: 0, avgConfidence: 0, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0 };
  }
  return {
    ...base,
    ok: true,
    code: null,
    reason: null,
    needsReview: result.needsReview,
    warningCodes: result.warnings.map((w) => w.code),
    fieldCount: Object.keys(result.fields).length,
    avgConfidence: avgConfidenceOf(result),
    inputTokens: result.usage.inputTokens,
    outputTokens: result.usage.outputTokens,
    cacheReadTokens: result.usage.cacheReadTokens,
  };
}

export function summarize(entries: LogEntry[]): { total: number; needsReview: number; failed: number; avgMs: number; cacheHitRate: number } {
  if (entries.length === 0) return { total: 0, needsReview: 0, failed: 0, avgMs: 0, cacheHitRate: 0 };
  const succeeded = entries.filter((e) => e.ok);
  const cacheHits = succeeded.filter((e) => e.cacheReadTokens > 0).length;
  return {
    total: entries.length,
    needsReview: entries.filter((e) => e.needsReview).length,
    failed: entries.length - succeeded.length,
    avgMs: Math.round(entries.reduce((a, e) => a + e.ms, 0) / entries.length),
    cacheHitRate: succeeded.length === 0 ? 0 : Math.round((cacheHits / succeeded.length) * 100) / 100,
  };
}

export function webhookPayload(entry: LogEntry, siteName: string): unknown {
  return {
    site: siteName,
    at: entry.at,
    documentId: entry.documentId,
    form: entry.form,
    ok: entry.ok,
    code: entry.code,
    reason: entry.reason,
    needsReview: entry.needsReview,
    warningCodes: entry.warningCodes,
    pages: entry.pages,
    ms: entry.ms,
    model: entry.model,
    tokens: { input: entry.inputTokens, output: entry.outputTokens, cacheRead: entry.cacheReadTokens },
  };
}

/** 記録の送信で読み取りを止めない。失敗したら false。送り先が黙っていても timeoutMs で切り上げる */
export async function postWebhook(url: string, payload: unknown, fetchImpl: typeof fetch = fetch, timeoutMs: number = WEBHOOK_TIMEOUT_MS): Promise<boolean> {
  const signal = AbortSignal.timeout(timeoutMs);
  try {
    const response = await Promise.race([
      fetchImpl(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload), signal }),
      new Promise<Response>((_resolve, reject) => {
        signal.addEventListener("abort", () => reject(new Error("webhook timeout")));
      }),
    ]);
    return response.ok;
  } catch {
    return false;
  }
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

export function adminHtml(config: ReaderConfig, entries: LogEntry[], token: string | null): string {
  const query = token === null ? "" : `?token=${encodeURIComponent(token)}`;
  const s = summarize(entries);
  const rows = entries
    .map(
      (e) => `<tr${e.needsReview || !e.ok ? ' class="ng"' : ""}>
<td>${escapeHtml(e.at)}</td><td>${escapeHtml(e.form)}</td><td>${escapeHtml(e.documentId.slice(0, 8))}</td>
<td>${e.ok ? (e.needsReview ? "要確認" : "確定できる") : `失敗（${escapeHtml(e.code ?? "")}${e.reason === null ? "" : ` / ${escapeHtml(e.reason)}`}）`}</td>
<td>${escapeHtml(e.warningCodes.join(" "))}</td><td>${e.pages ?? "?"}</td><td>${Math.round(e.avgConfidence * 100)}%</td>
<td>${e.ms}</td><td>${e.cacheReadTokens}</td>
</tr>`,
    )
    .join("\n");
  const empty = '<tr><td colspan="9">まだ記録がありません。</td></tr>';
  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>読み取りの記録（${escapeHtml(config.site.name)}）</title>
<style>
body { font-family: system-ui, sans-serif; margin: 0 auto; max-width: 64rem; padding: 2rem 1rem; color: #1b1b1b; }
h1 { font-size: 1.25rem; }
p { color: #555; }
table { border-collapse: collapse; width: 100%; font-size: 0.875rem; }
th, td { border-bottom: 1px solid #ddd; padding: 0.5rem; text-align: left; vertical-align: top; }
tr.ng { background: #fff7f0; }
</style>
</head>
<body>
<h1>読み取りの記録（${escapeHtml(config.site.name)}）</h1>
<p>直近 ${entries.length} 件: 要確認 ${s.needsReview}、失敗 ${s.failed}、平均 ${s.avgMs} ms、キャッシュ読みあり ${Math.round(s.cacheHitRate * 100)}%。書類の中身や読み取った値はここには残していません。<a href="${escapeHtml(query === "" ? "?" : query)}">更新</a></p>
<table>
<thead><tr><th>受付日時</th><th>型</th><th>書類ID</th><th>結果</th><th>警告</th><th>ページ</th><th>平均信頼度</th><th>所要 ms</th><th>キャッシュ読み</th></tr></thead>
<tbody>
${rows === "" ? empty : rows}
</tbody>
</table>
</body>
</html>
`;
}
