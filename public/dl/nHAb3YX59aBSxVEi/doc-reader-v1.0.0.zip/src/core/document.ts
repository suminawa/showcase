import type { DocumentInput, MediaType } from "./types";

export const DOCUMENT_MESSAGES = {
  heic: "HEIC の写真は読み取れません。iPhone は設定 → カメラ → フォーマットを「互換性優先」にするか、写真アプリから JPEG で書き出してください。",
  unsupported: "PDF・JPEG・PNG・WebP のファイルを置いてください。",
} as const;

export const MAX_FILE_NAME = 200;

const startsWith = (bytes: Uint8Array, text: string, offset: number = 0): boolean => {
  if (bytes.length < offset + text.length) return false;
  for (let i = 0; i < text.length; i += 1) if (bytes[offset + i] !== text.charCodeAt(i)) return false;
  return true;
};

export function sniffMediaType(bytes: Uint8Array): MediaType | "image/heic" | null {
  if (startsWith(bytes, "%PDF-")) return "application/pdf";
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.length >= 8 && bytes[0] === 0x89 && startsWith(bytes, "PNG", 1)) return "image/png";
  if (startsWith(bytes, "RIFF") && startsWith(bytes, "WEBP", 8)) return "image/webp";
  if (startsWith(bytes, "GIF8")) return "image/gif";
  if (startsWith(bytes, "ftyphei", 4) || startsWith(bytes, "ftypheix", 4) || startsWith(bytes, "ftypmif1", 4)) return "image/heic";
  return null;
}

/** バイト列を 1 バイト 1 文字の文字列として読む（PDF の構造の走査用。日本語の文字としては読まない） */
function asLatin1(bytes: Uint8Array): string {
  let text = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    text += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + 0x8000)));
  }
  return text;
}

const PAGE_RE = /\/Type\s*\/Page(?![s\w])/g;

/** 開いて数えるオブジェクトストリームの数と、1 本の大きさの上限（壊れた PDF で時間を使いすぎないため） */
const MAX_OBJECT_STREAMS = 50;
const MAX_OBJECT_STREAM_BYTES = 4 * 1024 * 1024;
/** 見に行く stream の語の数の上限。stream だけを並べたファイルを送られても、ここで走査を打ち切る */
const MAX_STREAM_KEYWORDS = 2000;
/** stream の手前で辞書（<<）を探す幅。オブジェクトストリームの辞書は stream の直前にあるので、これで足りる */
const DICT_WINDOW_BYTES = 2048;

/** ページの木（/Type /Pages）に書かれた /Count の最大値。上限の判定用なので、多めに見積もるほうが安全 */
function pagesTreeCount(text: string): number {
  let max = 0;
  for (const found of text.matchAll(/\/Type\s*\/Pages(?![\w])/g)) {
    const window = text.slice(Math.max(0, found.index - 600), found.index + 600);
    for (const count of window.matchAll(/\/Count\s+(\d+)/g)) max = Math.max(max, Number(count[1]));
  }
  return max;
}

/** zlib 形式（PDF の /FlateDecode）を Web 標準の DecompressionStream で開く。開けなければ null */
async function inflate(data: Uint8Array): Promise<Uint8Array | null> {
  try {
    // DecompressionStream の書き込み側は BufferSource を受けるので、流し込む側もその型で作る
    // DEVIATION: TS 5.9 は Uint8Array を Uint8Array<ArrayBufferLike> に広げるため BufferSource と合わず、sha256Hex と同じ最小限のキャストで通す
    const source = new ReadableStream<BufferSource>({
      start(controller) {
        controller.enqueue(data as BufferSource);
        controller.close();
      },
    });
    const out = source.pipeThrough(new DecompressionStream("deflate"));
    return new Uint8Array(await new Response(out).arrayBuffer());
  } catch {
    return null;
  }
}

/**
 * PDF 1.5 以降はページの辞書がオブジェクトストリーム（/Type /ObjStm）の中に圧縮されて入る。
 * その中身を開いて /Type /Page を数える（/Pages は数えない）。
 * 辞書を探す範囲は stream の手前 DICT_WINDOW_BYTES だけ、見に行く stream の語は MAX_STREAM_KEYWORDS まで。
 * どちらもファイルの大きさに比例した時間で終わらせるための枠で、打ち切ったときは数えられたぶんだけを返す
 */
async function pagesInObjectStreams(bytes: Uint8Array, text: string): Promise<number> {
  let total = 0;
  let opened = 0;
  let scanned = 0;
  let from = 0;
  while (opened < MAX_OBJECT_STREAMS && scanned < MAX_STREAM_KEYWORDS) {
    const at = text.indexOf("stream", from);
    if (at < 0) break;
    from = at + 6;
    scanned += 1;
    const back = text.slice(Math.max(0, at - DICT_WINDOW_BYTES), at);
    // 辞書は「N G obj」から stream まで。最後の「<<」だけを見ると /DecodeParms<<…>> のような入れ子の辞書で止まる
    const objAt = back.lastIndexOf("obj");
    const dictAt = objAt >= 0 ? objAt : back.lastIndexOf("<<");
    if (dictAt < 0) continue;
    const dict = back.slice(dictAt);
    if (!dict.includes("/ObjStm") || !dict.includes("/FlateDecode")) continue;
    // stream のあとの改行を飛ばして、次の endstream までが圧縮された中身
    let start = from;
    if (text[start] === "\r") start += 1;
    if (text[start] === "\n") start += 1;
    const end = text.indexOf("endstream", start);
    if (end < 0) break;
    from = end + 9;
    if (end - start > MAX_OBJECT_STREAM_BYTES) continue;
    // endstream の直前の改行は中身に数えない（PDF の決まり）。念のため、外さない形でも試す
    let stop = end;
    if (text[stop - 1] === "\n") stop -= 1;
    if (text[stop - 1] === "\r") stop -= 1;
    opened += 1;
    const inflated = (await inflate(bytes.subarray(start, stop))) ?? (await inflate(bytes.subarray(start, end)));
    if (inflated === null) continue;
    total += (asLatin1(inflated).match(PAGE_RE) ?? []).length;
  }
  return total;
}

/**
 * PDF のページ数。生のバイト列の /Type /Page を数え、無ければページの木の /Count、
 * それも無ければオブジェクトストリームを開いて数える。どこにも手がかりが無ければ null（数えられなかった）。
 * 上限の判定用なので、多めに見積もるのは構わない
 */
export async function pdfPageCount(bytes: Uint8Array): Promise<number | null> {
  const text = asLatin1(bytes);
  const literal = (text.match(PAGE_RE) ?? []).length;
  if (literal > 0) return literal;
  const tree = pagesTreeCount(text);
  if (tree > 0) return tree;
  const compressed = await pagesInObjectStreams(bytes, text);
  return compressed > 0 ? compressed : null;
}

export async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", bytes as BufferSource);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

export function toBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + 0x8000)));
  }
  return btoa(binary);
}

export function fromBase64(text: string): Uint8Array {
  const binary = atob(text);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
  return out;
}

/** pages が null なら、PDF のページ数を数えられなかったということ（上限は当てられない） */
export type Inspection = { ok: true; input: DocumentInput; pages: number | null } | { ok: false; code: "unsupported"; message: string };

export async function inspectDocument(fileName: string, bytes: Uint8Array): Promise<Inspection> {
  const media = sniffMediaType(bytes);
  if (media === null) return { ok: false, code: "unsupported", message: DOCUMENT_MESSAGES.unsupported };
  if (media === "image/heic") return { ok: false, code: "unsupported", message: DOCUMENT_MESSAGES.heic };
  const name = fileName.trim() === "" ? "書類" : fileName.trim().slice(0, MAX_FILE_NAME);
  return { ok: true, input: { fileName: name, mediaType: media, bytes }, pages: media === "application/pdf" ? await pdfPageCount(bytes) : 1 };
}
