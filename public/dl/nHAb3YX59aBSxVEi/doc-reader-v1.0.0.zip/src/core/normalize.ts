import type { ColumnType, ScalarType, ScalarValue } from "./types";

/** 全角の英数記号（U+FF01〜FF5E）と全角空白を半角に。かな・漢字は触らない */
export function toHalfWidth(text: string): string {
  return text
    .replace(/[！-～]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/　/g, " ");
}

export function normalizeString(raw: string): string {
  return raw.replace(/\s+/g, " ").trim();
}

/** 「△」「▲」「−」「-」の負号。末尾の「-」（12,800- の書き方）は負号ではない */
function signOf(text: string): 1 | -1 {
  return /^\s*[△▲−-]/.test(text) ? -1 : 1;
}

function firstNumber(text: string): number | null {
  const half = toHalfWidth(text).replace(/[,\s]/g, "");
  const match = half.match(/\d+(?:\.\d+)?/);
  if (match === null) return null;
  return Number(match[0]) * signOf(half);
}

export function normalizeNumber(raw: string): number | null {
  const value = firstNumber(raw);
  return value === null || !Number.isFinite(value) ? null : value;
}

/** 「10%」のような割合は金額ではない。金額を探す前に落とす */
const RATE_RE = /\d[\d,.]*\s*%/g;

/**
 * 金額は整数の円。小数は四捨五入。
 * 「税抜 △1,000」のように頭に見出しが付いていても、数のすぐ手前の負号を見る。
 * 「(1,000)」は会計の書き方の負の金額。「12,800-」の末尾の「-」は負号ではない
 */
export function normalizeMoney(raw: string): number | null {
  const text = toHalfWidth(raw).replace(/[¥円也]/g, "").replace(RATE_RE, " ");
  const at = text.search(/\d/);
  if (at < 0) return null;
  const head = text.slice(0, at);
  const tail = text.slice(at);
  const negative = /[△▲−-]\s*$/.test(head) || (/\(\s*$/.test(head) && /^[\d,.]+\s*\)/.test(tail));
  const match = tail.replace(/\s+/g, "").match(/\d[\d,]*(?:\.\d+)?/);
  if (match === null) return null;
  const value = Number(match[0].replace(/,/g, ""));
  if (!Number.isFinite(value)) return null;
  return Math.round(negative ? -value : value);
}

const ERA_START: Record<string, number> = { 令和: 2018, 平成: 1988, 昭和: 1925, 大正: 1911, R: 2018, H: 1988, S: 1925, T: 1911 };

function isValidDate(y: number, m: number, d: number): boolean {
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 1900 || y > 2100) return false;
  const date = new Date(Date.UTC(y, m - 1, d));
  return date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d;
}

const ymd = (y: number, m: number, d: number): string | null =>
  isValidDate(y, m, d) ? `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}` : null;

/** 西暦・和暦・区切り違いを YYYY-MM-DD に。読めなければ null（2 桁の年は扱わない） */
export function normalizeDate(raw: string): string | null {
  const text = toHalfWidth(raw).replace(/元年/g, "1年");
  const era = text.match(/(令和|平成|昭和|大正|[RHST])\s*(\d{1,2})\s*[年.\/-]\s*(\d{1,2})\s*[月.\/-]\s*(\d{1,2})\s*日?/);
  if (era !== null) {
    return ymd(ERA_START[era[1]] + Number(era[2]), Number(era[3]), Number(era[4]));
  }
  const western = text.match(/(\d{4})\s*[年.\/-]\s*(\d{1,2})\s*[月.\/-]\s*(\d{1,2})\s*日?/);
  if (western !== null) return ymd(Number(western[1]), Number(western[2]), Number(western[3]));
  const compact = text.match(/(?<!\d)(\d{4})(\d{2})(\d{2})(?!\d)/);
  if (compact !== null) return ymd(Number(compact[1]), Number(compact[2]), Number(compact[3]));
  return null;
}

const TRUE_WORDS = ["はい", "有", "あり", "有り", "true", "yes", "○", "〇", "レ", "✓", "✔", "☑", "1", "済", "同意"];
const FALSE_WORDS = ["いいえ", "無", "なし", "無し", "false", "no", "×", "✕", "☐", "0", "未"];

export function normalizeBoolean(raw: string): boolean | null {
  const text = toHalfWidth(raw).trim().toLowerCase();
  if (text === "") return null;
  if (TRUE_WORDS.some((w) => w.toLowerCase() === text)) return true;
  if (FALSE_WORDS.some((w) => w.toLowerCase() === text)) return false;
  return null;
}

export function normalizeEnum(raw: string, options: string[]): string | null {
  const text = toHalfWidth(raw).trim();
  if (text === "") return null;
  const exact = options.find((o) => toHalfWidth(o) === text);
  if (exact !== undefined) return exact;
  const partial = options.filter((o) => {
    const option = toHalfWidth(o);
    return option.includes(text) || text.includes(option);
  });
  return partial.length === 1 ? partial[0] : null;
}

export function normalizeValue(
  type: ScalarType | ColumnType,
  raw: string | null,
  options: string[] | null,
): { value: ScalarValue; invalid: boolean } {
  if (raw === null || raw.trim() === "") return { value: null, invalid: false };
  let value: ScalarValue;
  switch (type) {
    case "string":
      return { value: normalizeString(raw), invalid: false };
    case "number":
      value = normalizeNumber(raw);
      break;
    case "money":
      value = normalizeMoney(raw);
      break;
    case "date":
      value = normalizeDate(raw);
      break;
    case "boolean":
      value = normalizeBoolean(raw);
      break;
    case "enum":
      value = normalizeEnum(raw, options ?? []);
      break;
  }
  return { value, invalid: value === null };
}

export function yen(n: number): string {
  const sign = n < 0 ? "-" : "";
  return sign + String(Math.abs(Math.round(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
