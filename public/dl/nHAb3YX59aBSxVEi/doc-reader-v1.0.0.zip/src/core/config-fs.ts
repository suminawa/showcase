import { readFile } from "node:fs/promises";

/** reader.config.json を読む。無ければ undefined（既定値で動く）。壊れていれば投げる */
export async function loadConfigFile(path: string): Promise<unknown> {
  try {
    return JSON.parse(await readFile(path, "utf8")) as unknown;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined;
    throw new Error(`設定: ${path} を読めません（${(error as Error).message}）`);
  }
}
