import Anthropic from "@anthropic-ai/sdk";
import type { AnthropicClientLike, FinalMessageLike, MessageParams } from "./types";

/** 本物の SDK に触る唯一の場所。MessageParams はこちらで決めた最小の形なので、ここで 1 回だけ型を外す */
export function createAnthropicClient(apiKey: string): AnthropicClientLike {
  const client = new Anthropic({ apiKey });
  return {
    messages: {
      async create(params: MessageParams): Promise<FinalMessageLike> {
        return (await client.messages.create(params as never)) as unknown as FinalMessageLike;
      },
    },
  };
}
