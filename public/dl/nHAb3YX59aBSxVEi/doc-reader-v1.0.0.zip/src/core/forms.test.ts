import { describe, expect, it } from "vitest";
import { readFile, readdir } from "node:fs/promises";
import { customForm, dedupeKeyFields, FormError, formSummary, keyFields, parseForm, toOutputSchema } from "./forms";
import { loadForms } from "./forms-fs";

const minimal = {
  id: "memo",
  name: "メモ",
  fields: [
    { key: "title", label: "題名", type: "string", required: true },
    { key: "amount", label: "金額", type: "money" },
    { key: "kind", label: "区分", type: "enum", options: ["請求", "領収"] },
    { key: "lines", label: "明細", type: "table", columns: [{ key: "name", label: "品名", type: "string" }, { key: "amount", label: "金額", type: "money" }] },
  ],
  checks: [{ type: "sum", items: "lines.amount", equals: "amount" }],
};

describe("parseForm", () => {
  it("最小の型を読み、省略した欄に既定値を入れる", () => {
    const form = parseForm(minimal);
    expect(form.id).toBe("memo");
    expect(form.description).toBe("");
    expect(form.fields[0]).toEqual({ key: "title", label: "題名", type: "string", required: true, hint: null, pattern: null, options: null, columns: null });
    expect(form.fields[1].required).toBe(false);
    expect(form.fields[3].columns?.length).toBe(2);
    expect(form.checks[0]).toEqual({ type: "sum", items: "lines.amount", parts: null, equals: "amount", tolerance: 1 });
  });

  it.each([
    [{ ...minimal, id: "Memo" }, /id/],
    [{ ...minimal, fields: [] }, /fields/],
    [{ ...minimal, fields: [{ key: "a b", label: "x", type: "string" }] }, /key/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "string" }, { key: "a", label: "y", type: "string" }] }, /重複/],
    [{ ...minimal, fields: [{ key: "a", label: "", type: "string" }] }, /label/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "text" }] }, /type/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "enum" }] }, /options/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "enum", options: ["一"] }] }, /options/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "table" }] }, /columns/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "table", columns: [{ key: "n", label: "n", type: "enum" }] }] }, /columns/],
    [{ ...minimal, fields: [{ key: "a", label: "x", type: "string", pattern: "(" }] }, /pattern/],
    [{ ...minimal, checks: [{ type: "sum", items: "lines.name", equals: "amount" }] }, /items/],
    [{ ...minimal, checks: [{ type: "sum", parts: ["title"], equals: "amount" }] }, /parts/],
    [{ ...minimal, checks: [{ type: "sum", parts: ["amount"], equals: "nope" }] }, /equals/],
    [{ ...minimal, checks: [{ type: "avg", equals: "amount" }] }, /type/],
  ])("壊れた型は FormError で止める %#", (raw, re) => {
    expect(() => parseForm(raw)).toThrow(FormError);
    expect(() => parseForm(raw)).toThrow(re);
  });

  it("エラーには型の名前（source）が入る", () => {
    expect(() => parseForm({ ...minimal, fields: [] }, "memo.json")).toThrow(/memo\.json/);
  });
});

describe("customForm", () => {
  it("項目名だけから型を作る。key は f1, f2 …、type は string が既定", () => {
    const form = customForm([{ label: "工事名" }, { label: "金額", type: "money" }, { label: "着工日", type: "date", key: "start" }]);
    expect(form.id).toBe("custom");
    expect(form.fields.map((f) => f.key)).toEqual(["f1", "f2", "start"]);
    expect(form.fields[1].type).toBe("money");
    expect(form.checks).toEqual([]);
  });

  it("項目が無い・多すぎる・label が空なら FormError", () => {
    expect(() => customForm([])).toThrow(FormError);
    expect(() => customForm([{ label: "" }])).toThrow(FormError);
    expect(() => customForm([{ label: "あ".repeat(41) }])).toThrow(/40 字/);
    expect(customForm([{ label: "あ".repeat(40) }]).fields[0].label).toBe("あ".repeat(40));
    expect(() => customForm(Array.from({ length: 61 }, (_, i) => ({ label: `x${i}` })))).toThrow(FormError);
  });
});

describe("toOutputSchema", () => {
  it("項目ごとに value/confidence/evidence、表は rows、additionalProperties は false", () => {
    const schema = toOutputSchema(parseForm(minimal)) as any;
    expect(schema.type).toBe("object");
    expect(schema.required).toEqual(["fields", "tables", "notes"]);
    expect(schema.additionalProperties).toBe(false);
    expect(Object.keys(schema.properties.fields.properties)).toEqual(["title", "amount", "kind"]);
    const title = schema.properties.fields.properties.title;
    expect(title.properties.value).toEqual({ anyOf: [{ type: "string" }, { type: "null" }], description: expect.stringContaining("題名") });
    expect(title.required).toEqual(["value", "confidence", "evidence"]);
    expect(title.additionalProperties).toBe(false);
    const lines = schema.properties.tables.properties.lines;
    expect(lines.properties.rows.type).toBe("array");
    expect(lines.properties.rows.items.required).toEqual(["name", "amount"]);
    expect(lines.properties.rows.items.additionalProperties).toBe(false);
    expect(schema.properties.fields.required).toEqual(["title", "amount", "kind"]);
    expect(schema.properties.tables.required).toEqual(["lines"]);
  });

  it("enum は選択肢を description に並べ、表の無い型は tables が空の object", () => {
    const form = parseForm({ id: "a", name: "A", fields: [{ key: "kind", label: "区分", type: "enum", options: ["請求", "領収"] }] });
    const schema = toOutputSchema(form) as any;
    expect(schema.properties.fields.properties.kind.properties.value.description).toContain("請求");
    expect(schema.properties.tables).toEqual({ type: "object", properties: {}, required: [], additionalProperties: false });
  });
});

describe("formSummary / keyFields", () => {
  it("画面向けの要約に hint と pattern は出さない", () => {
    const summary = formSummary(parseForm({ ...minimal, fields: [{ key: "a", label: "x", type: "string", hint: "右上", pattern: "^x$" }], checks: [] }));
    expect(summary.fields[0]).toEqual({ key: "a", label: "x", type: "string", required: false, options: null, columns: null });
  });

  it("keyFields は主キーになりそうな項目を順に返し、無ければ先頭の string", () => {
    const form = parseForm(minimal);
    expect(keyFields(form)).toEqual(["title"]);
    const inv = parseForm({ id: "i", name: "I", fields: [{ key: "issuer", label: "請求元", type: "string" }, { key: "invoiceNumber", label: "番号", type: "string" }] });
    expect(keyFields(inv)).toEqual(["invoiceNumber", "issuer"]);
  });

  it("dedupeKeyFields は 2 つそろえば複合キー、1 つなら書類の番号だけ、それ以外は空", () => {
    const inv = parseForm({ id: "i", name: "I", fields: [{ key: "issuer", label: "請求元", type: "string" }, { key: "invoiceNumber", label: "番号", type: "string" }] });
    expect(dedupeKeyFields(inv)).toEqual(["invoiceNumber", "issuer"]);
    const order = parseForm({ id: "o", name: "O", fields: [{ key: "orderNumber", label: "注文番号", type: "string" }] });
    expect(dedupeKeyFields(order)).toEqual(["orderNumber"]);
    const receipt = parseForm({ id: "r", name: "R", fields: [{ key: "issuer", label: "発行者", type: "string" }] });
    expect(dedupeKeyFields(receipt)).toEqual([]);
    const application = parseForm({ id: "a", name: "A", fields: [{ key: "name", label: "お名前", type: "string" }] });
    expect(dedupeKeyFields(application)).toEqual([]);
    // 候補が無い型は、先頭の string に落とさない（勝手な項目を重複の鍵にしない）
    expect(dedupeKeyFields(parseForm(minimal))).toEqual([]);
  });
});

describe("同梱の型", () => {
  it("forms/ の 5 本が読め、id がファイル名と一致する", async () => {
    const forms = await loadForms(new URL("../../forms", import.meta.url).pathname);
    expect([...forms.keys()].sort()).toEqual(["application", "business-card", "invoice", "purchase-order", "receipt"]);
    for (const [id, form] of forms) expect(form.id).toBe(id);
    const invoice = forms.get("invoice")!;
    expect(invoice.fields.find((f) => f.key === "total")?.required).toBe(true);
    expect(invoice.fields.find((f) => f.key === "lineItems")?.columns?.map((c) => c.key)).toEqual(["description", "quantity", "unitPrice", "amount"]);
    expect(invoice.checks.length).toBe(2);
  });

  it("同梱の型の文面に実在の社名・電話が無い（見本の語彙だけ）", async () => {
    const dir = new URL("../../forms", import.meta.url).pathname;
    for (const name of await readdir(dir)) {
      const text = await readFile(`${dir}/${name}`, "utf8");
      expect(text).not.toMatch(/0\d{1,3}-\d{2,4}-\d{3,4}/);
      expect(text).not.toMatch(/株式会社|有限会社/);
    }
  });
});
