import type { FieldDef, FieldResult, FormDef, RawExtraction, ScalarValue, TableResult, TableRow, Warning } from "./types";
import { normalizeValue, yen } from "./normalize";

export interface ValidatedExtraction {
  fields: Record<string, FieldResult>;
  tables: Record<string, TableResult>;
  warnings: Warning[];
  needsReview: boolean;
  notes: string;
}

export const MESSAGES = {
  required: (label: string) => `「${label}」が読み取れませんでした。書類を見てご入力ください。`,
  pattern: (label: string, value: string) => `「${label}」の形式が合いません（${value}）。`,
  invalid: (label: string, kind: string, raw: string) => `「${label}」を${kind}として読めませんでした（${raw}）。`,
  invalidCell: (label: string, column: string, sample: string) =>
    `「${label}」の「${column}」に読めない行があります（${sample} ほか）。`,
  confidence: (label: string, percent: number) => `「${label}」は読み取りに自信がありません（${percent}%）。書類を見て確かめてください。`,
  checkItems: (table: string, column: string, sum: number, label: string, value: number) =>
    `「${table}」の「${column}」の合計（${yen(sum)}）と「${label}」（${yen(value)}）が合いません。`,
  checkParts: (labels: string[], sum: number, label: string, value: number) =>
    `${labels.map((l) => `「${l}」`).join("+")}の合計（${yen(sum)}）と「${label}」（${yen(value)}）が合いません。`,
  notes: (text: string) => `読み取りの注記: ${text}`,
} as const;

const KIND: Record<string, string> = { number: "数", money: "金額", date: "日付", boolean: "はい／いいえ", enum: "選択肢" };

export function clampConfidence(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return 0;
  return Math.min(1, Math.max(0, value));
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const rawString = (value: unknown): string | null => (typeof value === "string" ? value : null);

function fieldFrom(field: FieldDef, raw: unknown, threshold: number, warnings: Warning[]): FieldResult {
  const record = isRecord(raw) ? raw : {};
  const rawValue = rawString(record.value);
  const confidence = clampConfidence(record.confidence);
  const evidence = typeof record.evidence === "string" ? record.evidence.trim() : "";
  const { value, invalid } = normalizeValue(field.type as Exclude<FieldDef["type"], "table">, rawValue, field.options);
  if (invalid) warnings.push({ key: field.key, code: "invalid", message: MESSAGES.invalid(field.label, KIND[field.type] ?? "値", (rawValue ?? "").trim()) });
  if (value === null && field.required) warnings.push({ key: field.key, code: "required", message: MESSAGES.required(field.label) });
  if (value !== null && field.pattern !== null && typeof value === "string" && !new RegExp(field.pattern).test(value)) {
    warnings.push({ key: field.key, code: "pattern", message: MESSAGES.pattern(field.label, value) });
  }
  if (value !== null && confidence < threshold) {
    warnings.push({ key: field.key, code: "confidence", message: MESSAGES.confidence(field.label, Math.round(confidence * 100)) });
  }
  return { value, confidence, evidence };
}

function tableFrom(field: FieldDef, raw: unknown, threshold: number, warnings: Warning[]): TableResult {
  const record = isRecord(raw) ? raw : {};
  const columns = field.columns ?? [];
  const rowsRaw = Array.isArray(record.rows) ? record.rows : [];
  const invalidSamples = new Map<string, string>();
  const rows: TableRow[] = rowsRaw.map((rowRaw) => {
    const source = isRecord(rowRaw) ? rowRaw : {};
    const row: TableRow = {};
    for (const column of columns) {
      const cell = rawString(source[column.key]);
      const { value, invalid } = normalizeValue(column.type, cell, null);
      if (invalid && !invalidSamples.has(column.key)) invalidSamples.set(column.key, (cell ?? "").trim());
      row[column.key] = value;
    }
    return row;
  });
  for (const [columnKey, sample] of invalidSamples) {
    const column = columns.find((c) => c.key === columnKey);
    if (column === undefined) continue;
    warnings.push({ key: field.key, code: "invalid", message: MESSAGES.invalidCell(field.label, column.label, sample) });
  }
  const confidence = clampConfidence(record.confidence);
  // 表は行が読めていても、全体の確かさが低ければ推測が混ざる。仕様どおり警告にする
  if (rows.length > 0 && confidence < threshold) {
    warnings.push({ key: field.key, code: "confidence", message: MESSAGES.confidence(field.label, Math.round(confidence * 100)) });
  }
  return { rows, confidence };
}

const numberOf = (value: ScalarValue | undefined): number | null => (typeof value === "number" ? value : null);

function runChecks(form: FormDef, fields: Record<string, FieldResult>, tables: Record<string, TableResult>, warnings: Warning[]): void {
  for (const check of form.checks) {
    const target = form.fields.find((f) => f.key === check.equals);
    const expected = numberOf(fields[check.equals]?.value);
    if (target === undefined || expected === null) continue;
    if (check.items !== null) {
      const [tableKey, columnKey] = check.items.split(".");
      const table = form.fields.find((f) => f.key === tableKey);
      const column = table?.columns?.find((c) => c.key === columnKey);
      const rows = tables[tableKey]?.rows ?? [];
      if (table === undefined || column === undefined || rows.length === 0) continue;
      const values = rows.map((row) => numberOf(row[columnKey]));
      if (values.some((v) => v === null)) continue;
      const sum = values.reduce<number>((acc, v) => acc + (v as number), 0);
      if (Math.abs(sum - expected) > check.tolerance) {
        warnings.push({ key: check.equals, code: "check", message: MESSAGES.checkItems(table.label, column.label, sum, target.label, expected) });
      }
      continue;
    }
    const parts = check.parts ?? [];
    const values = parts.map((key) => numberOf(fields[key]?.value));
    if (values.some((v) => v === null)) continue;
    const sum = values.reduce<number>((acc, v) => acc + (v as number), 0);
    if (Math.abs(sum - expected) > check.tolerance) {
      const labels = parts.map((key) => form.fields.find((f) => f.key === key)?.label ?? key);
      warnings.push({ key: check.equals, code: "check", message: MESSAGES.checkParts(labels, sum, target.label, expected) });
    }
  }
}

/** モデルの答え（値は文字）を、型に沿って変換・検証する。答えに無い項目は null、余分な項目は捨てる */
export function validateExtraction(form: FormDef, raw: RawExtraction, threshold: number): ValidatedExtraction {
  const warnings: Warning[] = [];
  const rawFields = isRecord(raw?.fields) ? raw.fields : {};
  const rawTables = isRecord(raw?.tables) ? raw.tables : {};
  const fields: Record<string, FieldResult> = {};
  const tables: Record<string, TableResult> = {};
  for (const field of form.fields) {
    if (field.type === "table") tables[field.key] = tableFrom(field, rawTables[field.key], threshold, warnings);
    else fields[field.key] = fieldFrom(field, rawFields[field.key], threshold, warnings);
  }
  runChecks(form, fields, tables, warnings);
  const notes = typeof raw?.notes === "string" ? raw.notes.trim() : "";
  if (notes !== "") warnings.push({ key: null, code: "notes", message: MESSAGES.notes(notes) });
  return { fields, tables, warnings, needsReview: warnings.length > 0, notes };
}
