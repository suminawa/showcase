import type { AnthropicClientLike, DocumentInput, ExtractFailure, Extraction, FinalMessageLike, FormDef, RawExtraction, ReaderConfig, Usage } from "./types";
import { buildParams } from "./prompt";
import { validateExtraction } from "./validate";

/** max_tokens で切れたら max_tokens を倍にしてもう 1 回だけ試す */
const MAX_ATTEMPTS = 2;

export const EXTRACT_MESSAGES = {
  unreadable: "この書類は読み取れませんでした。写真なら、明るい場所で書類全体が入るように撮り直してお試しください。",
  refused: "この書類は読み取りの対象外と判断されました。",
  unavailable: "いまは読み取れません。しばらくしてからもう一度お試しください。",
  rateLimited: "ただいま混み合っています。少し時間をおいてからお試しください。",
  pagesUnknown: (maxPages: number) => `ページ数を確かめられませんでした。${maxPages} ページを超える書類は読み取りに時間と費用がかかります。`,
} as const;

/** 1 ページあたりの入力トークンの目安。これを上限のページ数ぶん超えたら、数え損ねた大きな書類として手元に残す */
export const TOKENS_PER_PAGE = 3000;

export interface ExtractInput {
  client: AnthropicClientLike;
  config: ReaderConfig;
  form: FormDef;
  document: DocumentInput;
  /** 数えられなかった PDF は null */
  pages: number | null;
  documentId: string;
  now?: () => number;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

/** SDK の例外に付いてくる HTTP の状態。無ければ null（通信そのものが届かなかったとき） */
const statusOf = (error: unknown): number | null => {
  const status = isRecord(error) ? error.status : undefined;
  return typeof status === "number" ? status : null;
};

/**
 * API の失敗を仕分ける。お客さまへの文面はぼかしたまま、記録には理由を残す
 * （買い手は運用する人なので、「鍵が違う」と「この写真が壊れている」を /admin で見分けられる必要がある）
 */
export function failureFor(error: unknown): ExtractFailure {
  const status = statusOf(error);
  // 400・422 は送った書類そのものが受け付けられなかった。やり直しても同じなので、読めなかったと伝える
  if (status === 400 || status === 422) return { ok: false, code: "unreadable", message: EXTRACT_MESSAGES.unreadable, reason: "request" };
  if (status === 401 || status === 403) return { ok: false, code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "auth" };
  if (status === 429) return { ok: false, code: "rate_limited", message: EXTRACT_MESSAGES.rateLimited, reason: "rate_limited" };
  if (status !== null) return { ok: false, code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "server" };
  return { ok: false, code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "network" };
}

/** 前後に文が混ざっても、最初の { から最後の } を JSON として読む */
export function parseRawExtraction(text: string): RawExtraction | null {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const parsed: unknown = JSON.parse(text.slice(start, end + 1));
    if (!isRecord(parsed) || !isRecord(parsed.fields)) return null;
    return {
      fields: parsed.fields as RawExtraction["fields"],
      tables: isRecord(parsed.tables) ? (parsed.tables as RawExtraction["tables"]) : {},
      notes: typeof parsed.notes === "string" ? parsed.notes : "",
    };
  } catch {
    return null;
  }
}

const textOf = (message: FinalMessageLike): string =>
  message.content.filter((block) => block.type === "text").map((block) => block.text ?? "").join("");

const usageOf = (message: FinalMessageLike): Usage => ({
  inputTokens: message.usage.input_tokens,
  outputTokens: message.usage.output_tokens,
  cacheReadTokens: message.usage.cache_read_input_tokens ?? 0,
  cacheCreationTokens: message.usage.cache_creation_input_tokens ?? 0,
});

const addUsage = (a: Usage, b: Usage): Usage => ({
  inputTokens: a.inputTokens + b.inputTokens,
  outputTokens: a.outputTokens + b.outputTokens,
  cacheReadTokens: a.cacheReadTokens + b.cacheReadTokens,
  cacheCreationTokens: a.cacheCreationTokens + b.cacheCreationTokens,
});

export async function extractDocument(input: ExtractInput): Promise<Extraction> {
  const now = input.now ?? (() => Date.now());
  const started = now();
  let usage: Usage = { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 };
  let maxTokens = input.config.maxTokens;

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt += 1) {
    let message: FinalMessageLike;
    try {
      message = await input.client.messages.create(buildParams({ config: input.config, form: input.form, document: input.document, maxTokens }));
    } catch (error) {
      // 鍵・通信・上限などの中身は外に出さず、手元の記録にだけ残す
      const failure = failureFor(error);
      console.error(`doc-reader: ${failure.reason ?? "unknown"}:`, error instanceof Error ? error.message : error);
      return failure;
    }
    usage = addUsage(usage, usageOf(message));
    if (message.stop_reason === "refusal") return { ok: false, code: "refused", message: EXTRACT_MESSAGES.refused };
    const raw = message.stop_reason === "max_tokens" ? null : parseRawExtraction(textOf(message));
    if (raw === null) {
      maxTokens *= 2;
      continue;
    }
    const validated = validateExtraction(input.form, raw, input.config.confidenceThreshold);
    const maxPages = input.config.limits.maxPages;
    const warnings = [...validated.warnings];
    if (input.pages === null) {
      // ページ数を数えられなかった PDF は止めずに通し、人に確かめてもらう（上限を当てられないことを隠さない）
      warnings.push({ key: null, code: "pages_unknown", message: EXTRACT_MESSAGES.pagesUnknown(maxPages) });
    }
    // 読み取ったあとに費用の跡を残す。書類の中身は書かない
    if (usage.inputTokens > maxPages * TOKENS_PER_PAGE) {
      console.warn(`doc-reader: 入力トークンが多い読み取りです（${usage.inputTokens} トークン・型 ${input.form.id}）。${maxPages} ページを超える書類かもしれません`);
    }
    return {
      ok: true,
      documentId: input.documentId,
      form: input.form.id,
      fileName: input.document.fileName,
      pages: input.pages,
      fields: validated.fields,
      tables: validated.tables,
      warnings,
      needsReview: warnings.length > 0,
      notes: validated.notes,
      usage,
      ms: now() - started,
    };
  }
  return { ok: false, code: "unreadable", message: EXTRACT_MESSAGES.unreadable };
}
