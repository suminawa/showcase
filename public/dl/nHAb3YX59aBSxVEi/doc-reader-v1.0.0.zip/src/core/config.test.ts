import { describe, expect, it } from "vitest";
import { DEFAULT_LABELS, DEFAULT_LIMITS, DEFAULT_MODEL, resolveConfig } from "./config";

describe("resolveConfig", () => {
  it("何も無ければ既定値になる", () => {
    const config = resolveConfig();
    expect(config.model).toBe(DEFAULT_MODEL);
    expect(config.effort).toBe("low");
    expect(config.maxTokens).toBe(4096);
    expect(config.confidenceThreshold).toBe(0.8);
    expect(config.limits).toEqual(DEFAULT_LIMITS);
    expect(config.labels).toEqual(DEFAULT_LABELS);
    expect(config.formsDir).toBe("forms");
    expect(config.defaultForm).toBe("invoice");
    expect(config.site.name).toBe("書類の読み取り");
    expect(config.apiKey).toBeNull();
    expect(config.allowedOrigins).toEqual([]);
    expect(config.fake).toBe(false);
  });

  it("ファイルの値が既定値に上書きされ、labels は 1 つずつ差し替わる", () => {
    const config = resolveConfig({
      file: {
        site: { name: "みなと商会" },
        model: "claude-sonnet-5",
        effort: "medium",
        confidenceThreshold: 0.9,
        limits: { daily: 50 },
        labels: { title: "帳票の読み取り" },
        send: { sheet: "請求書" },
      },
    });
    expect(config.site.name).toBe("みなと商会");
    expect(config.model).toBe("claude-sonnet-5");
    expect(config.effort).toBe("medium");
    expect(config.confidenceThreshold).toBe(0.9);
    expect(config.limits.daily).toBe(50);
    expect(config.limits.perMinute).toBe(DEFAULT_LIMITS.perMinute);
    expect(config.labels.title).toBe("帳票の読み取り");
    expect(config.labels.confirm).toBe(DEFAULT_LABELS.confirm);
    expect(config.send.sheet).toBe("請求書");
  });

  it("環境変数は鍵・合い言葉・送信元・送り先・上限を持ち込む", () => {
    const config = resolveConfig({
      env: {
        ANTHROPIC_API_KEY: " sk-ant-x ",
        ADMIN_TOKEN: "t",
        ALLOWED_ORIGINS: "https://a.example, https://b.example/",
        TRUST_PROXY: "1",
        SEND_WEBHOOK_URL: "https://script.google.com/macros/s/x/exec",
        SEND_TOKEN: "s",
        LOG_WEBHOOK_URL: "https://hooks.example/x",
        DAILY_LIMIT: "30",
        READER_FAKE: "1",
      },
    });
    expect(config.apiKey).toBe("sk-ant-x");
    expect(config.adminToken).toBe("t");
    expect(config.allowedOrigins).toEqual(["https://a.example", "https://b.example"]);
    expect(config.trustProxy).toBe(true);
    expect(config.sendWebhookUrl).toBe("https://script.google.com/macros/s/x/exec");
    expect(config.sendToken).toBe("s");
    expect(config.logWebhookUrl).toBe("https://hooks.example/x");
    expect(config.limits.daily).toBe(30);
    expect(config.fake).toBe(true);
  });

  it("おかしな値は既定値に戻す（effort・閾値・上限・空の鍵）", () => {
    const config = resolveConfig({
      file: { effort: "ultra", confidenceThreshold: 7, limits: { perMinute: -1, maxPages: 0 }, maxTokens: "many" },
      env: { ANTHROPIC_API_KEY: "   ", DAILY_LIMIT: "abc" },
    });
    expect(config.effort).toBe("low");
    expect(config.confidenceThreshold).toBe(0.8);
    expect(config.limits.perMinute).toBe(DEFAULT_LIMITS.perMinute);
    expect(config.limits.maxPages).toBe(DEFAULT_LIMITS.maxPages);
    expect(config.maxTokens).toBe(4096);
    expect(config.apiKey).toBeNull();
    expect(config.limits.daily).toBe(DEFAULT_LIMITS.daily);
  });

  it("ALLOWED_ORIGINS の壊れた項目は捨て、origin だけを残す", () => {
    const config = resolveConfig({ env: { ALLOWED_ORIGINS: "https://a.example/path?x=1, not a url, ,http://b.example:3000" } });
    expect(config.allowedOrigins).toEqual(["https://a.example", "http://b.example:3000"]);
  });
});
