import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import { sha256Hex } from "./document";
import type { FakeAnswer } from "./fake-client";

export const SAMPLE_EXTENSIONS = ["pdf", "jpg", "jpeg", "png", "webp"];

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

/** samples/expected/<name>.json と samples/docs/<name>.<ext> を、書類のハッシュで結ぶ */
export async function loadFakeAnswers(samplesDir: string): Promise<Map<string, FakeAnswer>> {
  const answers = new Map<string, FakeAnswer>();
  let names: string[];
  try {
    names = (await readdir(join(samplesDir, "expected"))).filter((n) => n.endsWith(".json")).sort();
  } catch {
    return answers;
  }
  let docs: string[];
  try {
    docs = await readdir(join(samplesDir, "docs"));
  } catch {
    return answers;
  }
  for (const name of names) {
    const base = name.slice(0, -".json".length);
    const doc = docs.find((d) => SAMPLE_EXTENSIONS.some((ext) => d === `${base}.${ext}`));
    if (doc === undefined) continue;
    let raw: unknown;
    try {
      raw = JSON.parse(await readFile(join(samplesDir, "expected", name), "utf8")) as unknown;
    } catch {
      continue;
    }
    if (!isRecord(raw) || typeof raw.form !== "string") continue;
    const bytes = new Uint8Array(await readFile(join(samplesDir, "docs", doc)));
    answers.set(await sha256Hex(bytes), {
      form: raw.form,
      fields: isRecord(raw.fields) ? (raw.fields as Record<string, string | null>) : {},
      tables: isRecord(raw.tables) ? (raw.tables as Record<string, Record<string, string | null>[]>) : {},
    });
  }
  return answers;
}
