/** 帳票の型と読み取りの結果の型。実行するコードは置かない */

export type EffortLevel = "low" | "medium" | "high";

export type ScalarType = "string" | "number" | "money" | "date" | "boolean" | "enum";
export type ColumnType = "string" | "number" | "money" | "date";
export type FieldType = ScalarType | "table";

export interface ColumnDef {
  key: string;
  label: string;
  type: ColumnType;
}

export interface FieldDef {
  key: string;
  label: string;
  type: FieldType;
  required: boolean;
  /** 書類のどこにあるか。モデルへの手がかり */
  hint: string | null;
  /** string の形式（正規表現の文字列）。null なら見ない */
  pattern: string | null;
  /** enum の選択肢 */
  options: string[] | null;
  /** table の列 */
  columns: ColumnDef[] | null;
}

export interface SumCheck {
  type: "sum";
  /** "<table の key>.<列の key>" 例: "lineItems.amount"。parts と排他 */
  items: string | null;
  /** 足す項目の key の配列。items と排他 */
  parts: string[] | null;
  /** 合計と比べる項目の key */
  equals: string;
  /** 許す差（円）。既定 1 */
  tolerance: number;
}
export type CheckDef = SumCheck;

export interface FormDef {
  id: string;
  name: string;
  description: string;
  fields: FieldDef[];
  checks: CheckDef[];
}

export type ScalarValue = string | number | boolean | null;

export interface FieldResult {
  value: ScalarValue;
  /** 0〜1 */
  confidence: number;
  /** 書類に書かれていた文字そのまま */
  evidence: string;
}

export type TableRow = Record<string, ScalarValue>;

export interface TableResult {
  rows: TableRow[];
  confidence: number;
}

/** モデルが返す形。値はすべて文字か null（変換はこちらで行う） */
export interface RawFieldResult {
  value: string | null;
  confidence: number;
  evidence: string;
}
export interface RawTableResult {
  rows: Record<string, string | null>[];
  confidence: number;
}
export interface RawExtraction {
  fields: Record<string, RawFieldResult>;
  tables: Record<string, RawTableResult>;
  notes: string;
}

export type WarningCode = "required" | "pattern" | "invalid" | "check" | "confidence" | "duplicate" | "notes" | "pages_unknown";

export interface Warning {
  /** 項目の key。書類全体の警告は null */
  key: string | null;
  code: WarningCode;
  message: string;
}

export interface Usage {
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  cacheCreationTokens: number;
}

export interface ExtractResult {
  ok: true;
  documentId: string;
  form: string;
  fileName: string;
  /** PDF のページ数。画像は 1。数えられなかった PDF は null */
  pages: number | null;
  fields: Record<string, FieldResult>;
  tables: Record<string, TableResult>;
  warnings: Warning[];
  needsReview: boolean;
  notes: string;
  usage: Usage;
  ms: number;
}

export type ExtractErrorCode =
  | "unreadable"
  | "too_large"
  | "too_many_pages"
  | "unsupported"
  | "unavailable"
  | "rate_limited"
  | "daily_limit"
  | "forbidden"
  | "bad_request"
  | "refused";

/** 手元の記録にだけ残す、失敗のもう少し詳しい理由。お客さまへの文面は変えない */
export type FailureReason = "auth" | "request" | "rate_limited" | "server" | "network" | "no_key";

export interface ExtractFailure {
  ok: false;
  code: ExtractErrorCode;
  message: string;
  /** 記録用。お客さまへの応答には入れない */
  reason?: FailureReason;
}

export type Extraction = ExtractResult | ExtractFailure;

export type ImageMediaType = "image/jpeg" | "image/png" | "image/webp" | "image/gif";
export type MediaType = "application/pdf" | ImageMediaType;

export interface DocumentInput {
  fileName: string;
  mediaType: MediaType;
  bytes: Uint8Array;
}

/* ---- Anthropic（最小の形。本物の SDK は client.ts だけが知る） ---- */

export interface CacheControl {
  type: "ephemeral";
  ttl?: "5m" | "1h";
}

export interface TextBlockParam {
  type: "text";
  text: string;
  cache_control?: CacheControl;
}

export interface DocumentBlockParam {
  type: "document";
  source: { type: "base64"; media_type: "application/pdf"; data: string };
  title?: string;
}

export interface ImageBlockParam {
  type: "image";
  source: { type: "base64"; media_type: ImageMediaType; data: string };
}

export type UserContentBlock = TextBlockParam | DocumentBlockParam | ImageBlockParam;

export interface MessageParamLike {
  role: "user" | "assistant";
  content: UserContentBlock[] | string;
}

export interface JsonOutputFormat {
  type: "json_schema";
  schema: Record<string, unknown>;
}

export interface MessageParams {
  model: string;
  max_tokens: number;
  system: TextBlockParam[];
  messages: MessageParamLike[];
  output_config?: { effort?: EffortLevel; format?: JsonOutputFormat };
}

export interface FinalMessageLike {
  stop_reason: string | null;
  content: Array<{ type: string; text?: string }>;
  usage: {
    input_tokens: number;
    output_tokens: number;
    cache_read_input_tokens?: number | null;
    cache_creation_input_tokens?: number | null;
  };
}

export interface AnthropicClientLike {
  messages: { create(params: MessageParams): Promise<FinalMessageLike> };
}

/* ---- 設定 ---- */

export interface LimitsConfig {
  maxFileBytes: number;
  maxPages: number;
  perMinute: number;
  perHour: number;
  daily: number;
}

export interface ReaderLabels {
  title: string;
  dropHere: string;
  choose: string;
  formLabel: string;
  customFields: string;
  statusWaiting: string;
  statusReading: string;
  statusReview: string;
  statusDone: string;
  statusFailed: string;
  confirm: string;
  retry: string;
  remove: string;
  saveCsv: string;
  saveLinesCsv: string;
  copyTsv: string;
  send: string;
  sent: string;
  lowConfidence: string;
  privacy: string;
}

export interface ReaderConfig {
  site: { name: string };
  formsDir: string;
  defaultForm: string;
  model: string;
  effort: EffortLevel;
  maxTokens: number;
  confidenceThreshold: number;
  limits: LimitsConfig;
  send: { sheet: string };
  labels: ReaderLabels;
  apiKey: string | null;
  adminToken: string | null;
  allowedOrigins: string[];
  trustProxy: boolean;
  sendWebhookUrl: string | null;
  sendToken: string | null;
  logWebhookUrl: string | null;
  fake: boolean;
}
