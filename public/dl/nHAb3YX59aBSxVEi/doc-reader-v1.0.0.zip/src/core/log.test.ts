import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { adminHtml, avgConfidenceOf, createLogRing, entryFrom, postWebhook, summarize, webhookPayload } from "./log";
import type { ExtractResult } from "./types";

const ok: ExtractResult = {
  ok: true,
  documentId: "d1",
  form: "invoice",
  fileName: "田中様_請求書.pdf",
  pages: 2,
  fields: { a: { value: "x", confidence: 0.9, evidence: "" }, b: { value: null, confidence: 0.5, evidence: "" } },
  tables: {},
  warnings: [{ key: "b", code: "required", message: "「b」が読み取れませんでした。値: 秘密" }],
  needsReview: true,
  notes: "",
  usage: { inputTokens: 3000, outputTokens: 400, cacheReadTokens: 900, cacheCreationTokens: 0 },
  ms: 1200,
};

describe("entryFrom / avgConfidenceOf", () => {
  it("ファイル名・値・警告文は残さず、コードと数だけ", () => {
    const entry = entryFrom({ id: 1, at: "2026-09-13T00:00:00.000Z", model: "claude-opus-5", result: ok, documentId: "d1", form: "invoice", pages: 2, ms: 1200 });
    expect(entry).toEqual({
      id: 1, at: "2026-09-13T00:00:00.000Z", documentId: "d1", form: "invoice", ok: true, code: null, reason: null, needsReview: true,
      warningCodes: ["required"], fieldCount: 2, avgConfidence: 0.7, pages: 2, ms: 1200, model: "claude-opus-5",
      inputTokens: 3000, outputTokens: 400, cacheReadTokens: 900,
    });
    expect(JSON.stringify(entry)).not.toContain("田中");
    expect(JSON.stringify(entry)).not.toContain("秘密");
  });
  it("失敗は code を残し、数は 0", () => {
    const entry = entryFrom({ id: 2, at: "x", model: "m", result: { ok: false, code: "unreadable", message: "…" }, documentId: "d2", form: "receipt", pages: 1, ms: 300 });
    expect(entry).toMatchObject({ ok: false, code: "unreadable", reason: null, needsReview: false, fieldCount: 0, avgConfidence: 0, inputTokens: 0 });
    // 失敗の理由は記録にだけ残す（お客さまへの応答には出さない）
    const auth = entryFrom({ id: 3, at: "x", model: "m", result: { ok: false, code: "unavailable", message: "…", reason: "auth" }, documentId: "d3", form: "receipt", pages: 1, ms: 10 });
    expect(auth).toMatchObject({ ok: false, code: "unavailable", reason: "auth" });
  });
  it("avgConfidence は項目の平均。項目が無ければ 0", () => {
    expect(avgConfidenceOf(ok)).toBe(0.7);
    expect(avgConfidenceOf({ ...ok, fields: {} })).toBe(0);
  });
});

describe("createLogRing / summarize", () => {
  it("新しい順に返し、上限を超えたら古いものから消える", () => {
    const ring = createLogRing(2);
    for (let i = 1; i <= 3; i += 1) ring.push(entryFrom({ id: i, at: "x", model: "m", result: ok, documentId: `d${i}`, form: "f", pages: 1, ms: i }));
    expect(ring.size()).toBe(2);
    expect(ring.list().map((e) => e.id)).toEqual([3, 2]);
  });
  it("要確認・失敗・平均 ms・キャッシュ読みの割合", () => {
    const entries = [
      entryFrom({ id: 1, at: "x", model: "m", result: ok, documentId: "a", form: "f", pages: 1, ms: 1000 }),
      entryFrom({ id: 2, at: "x", model: "m", result: { ...ok, needsReview: false, warnings: [] }, documentId: "b", form: "f", pages: 1, ms: 3000 }),
      entryFrom({ id: 3, at: "x", model: "m", result: { ok: false, code: "unavailable", message: "" }, documentId: "c", form: "f", pages: 1, ms: 200 }),
    ];
    expect(summarize(entries)).toEqual({ total: 3, needsReview: 1, failed: 1, avgMs: 1400, cacheHitRate: 1 });
    expect(summarize([])).toEqual({ total: 0, needsReview: 0, failed: 0, avgMs: 0, cacheHitRate: 0 });
  });
});

describe("webhookPayload / postWebhook", () => {
  it("JSON の形。site と entry の数だけ", () => {
    const entry = entryFrom({ id: 1, at: "t", model: "m", result: ok, documentId: "d1", form: "invoice", pages: 2, ms: 10 });
    expect(webhookPayload(entry, "みなと商会")).toEqual({
      site: "みなと商会", at: "t", documentId: "d1", form: "invoice", ok: true, code: null, reason: null, needsReview: true, warningCodes: ["required"],
      pages: 2, ms: 10, model: "m", tokens: { input: 3000, output: 400, cacheRead: 900 },
    });
  });
  it("送れれば true、失敗と時間切れは false", async () => {
    const okFetch = (async () => new Response("", { status: 200 })) as unknown as typeof fetch;
    expect(await postWebhook("https://h.example/x", {}, okFetch)).toBe(true);
    const bad = (async () => new Response("", { status: 500 })) as unknown as typeof fetch;
    expect(await postWebhook("https://h.example/x", {}, bad)).toBe(false);
    const hang = (() => new Promise<Response>(() => {})) as unknown as typeof fetch;
    expect(await postWebhook("https://h.example/x", {}, hang, 20)).toBe(false);
  });
});

describe("adminHtml", () => {
  it("件数の要約と表。合い言葉はリンクに入り、値は出ない", () => {
    const config = resolveConfig({ file: { site: { name: "みなと商会" } } });
    const entry = entryFrom({ id: 1, at: "2026-09-13T00:00:00.000Z", model: "m", result: ok, documentId: "d1", form: "invoice", pages: 2, ms: 10 });
    const html = adminHtml(config, [entry], "tok");
    expect(html).toContain("読み取りの記録（みなと商会）");
    expect(html).toContain("要確認 1");
    expect(html).toContain("?token=tok");
    expect(html).toContain("required");
    expect(html).not.toContain("田中");
    expect(adminHtml(config, [], null)).toContain("まだ記録がありません");
  });
});
