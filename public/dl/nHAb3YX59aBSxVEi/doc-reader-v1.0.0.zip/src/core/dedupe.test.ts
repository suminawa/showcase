import { describe, expect, it } from "vitest";
import { createDedupeState, dayKeyOf, DEDUPE_MESSAGES, noteDocument } from "./dedupe";
import { parseForm } from "./forms";
import type { FieldResult } from "./types";

const form = parseForm({
  id: "invoice",
  name: "請求書",
  fields: [
    { key: "issuer", label: "請求元", type: "string" },
    { key: "invoiceNumber", label: "請求書番号", type: "string" },
  ],
});
const f = (value: string | null): FieldResult => ({ value, confidence: 1, evidence: "" });
const T0 = Date.UTC(2026, 8, 13, 3, 0, 0); // 2026-09-13 12:00 JST

describe("dayKeyOf", () => {
  it("JST の日付。UTC の 15 時を過ぎると翌日", () => {
    expect(dayKeyOf(Date.UTC(2026, 8, 13, 14, 59))).toBe("2026-09-13");
    expect(dayKeyOf(Date.UTC(2026, 8, 13, 15, 0))).toBe("2026-09-14");
  });
});

describe("noteDocument", () => {
  it("初めてなら警告なし。同じファイルは duplicate、同じ番号+請求元も duplicate", () => {
    const state = createDedupeState();
    expect(noteDocument(state, { documentId: "a", form, fields: { issuer: f("さくら設備"), invoiceNumber: f("INV-1") }, now: T0 })).toEqual([]);
    expect(noteDocument(state, { documentId: "a", form, fields: { issuer: f("さくら設備"), invoiceNumber: f("INV-1") }, now: T0 })).toEqual([
      { key: null, code: "duplicate", message: DEDUPE_MESSAGES.sameFile },
    ]);
    expect(noteDocument(state, { documentId: "b", form, fields: { issuer: f("さくら設備"), invoiceNumber: f("INV-1") }, now: T0 })).toEqual([
      { key: "invoiceNumber", code: "duplicate", message: "同じ「請求書番号」「請求元」（INV-1 / さくら設備）の書類を本日すでに読み込んでいます。" },
    ]);
  });

  it("主キーが「発行者」だけの型（領収書）では、別のファイルを番号の重複にしない", () => {
    const receipt = parseForm({
      id: "receipt",
      name: "領収書",
      fields: [{ key: "issuer", label: "発行者", type: "string" }, { key: "total", label: "合計金額", type: "money" }],
    });
    const state = createDedupeState();
    noteDocument(state, { documentId: "a", form: receipt, fields: { issuer: f("みなとマート 港町店") }, now: T0 });
    // 同じお店の別のレシートは重複ではない
    expect(noteDocument(state, { documentId: "b", form: receipt, fields: { issuer: f("みなとマート 港町店") }, now: T0 })).toEqual([]);
    // 同じファイルなら今までどおり鳴る
    expect(noteDocument(state, { documentId: "a", form: receipt, fields: { issuer: f("みなとマート 港町店") }, now: T0 })).toEqual([
      { key: null, code: "duplicate", message: DEDUPE_MESSAGES.sameFile },
    ]);
  });

  it("主キーが「お名前」だけの型（申込書）でも番号の重複は見ない", () => {
    const application = parseForm({ id: "application", name: "申込書", fields: [{ key: "name", label: "お名前", type: "string" }] });
    const state = createDedupeState();
    noteDocument(state, { documentId: "a", form: application, fields: { name: f("潮見 さくら") }, now: T0 });
    expect(noteDocument(state, { documentId: "b", form: application, fields: { name: f("潮見 さくら") }, now: T0 })).toEqual([]);
  });

  it("番号 1 つだけの型（注文書）は、その番号で重複を見る", () => {
    const order = parseForm({ id: "purchase-order", name: "注文書", fields: [{ key: "orderNumber", label: "注文番号", type: "string" }] });
    const state = createDedupeState();
    noteDocument(state, { documentId: "a", form: order, fields: { orderNumber: f("PO-1") }, now: T0 });
    expect(noteDocument(state, { documentId: "b", form: order, fields: { orderNumber: f("PO-1") }, now: T0 })).toEqual([
      { key: "orderNumber", code: "duplicate", message: "同じ「注文番号」（PO-1）の書類を本日すでに読み込んでいます。" },
    ]);
  });

  it("主キーのどれかが null なら番号の重複は見ない。日付が変わると忘れる", () => {
    const state = createDedupeState();
    noteDocument(state, { documentId: "a", form, fields: { issuer: f("x"), invoiceNumber: f(null) }, now: T0 });
    expect(noteDocument(state, { documentId: "b", form, fields: { issuer: f("x"), invoiceNumber: f(null) }, now: T0 })).toEqual([]);
    noteDocument(state, { documentId: "c", form, fields: { issuer: f("x"), invoiceNumber: f("1") }, now: T0 });
    const nextDay = T0 + 24 * 60 * 60 * 1000;
    expect(noteDocument(state, { documentId: "c", form, fields: { issuer: f("x"), invoiceNumber: f("1") }, now: nextDay })).toEqual([]);
  });
});
