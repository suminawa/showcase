import type { AnthropicClientLike, FinalMessageLike, MessageParams, RawExtraction } from "./types";
import { fromBase64, sha256Hex } from "./document";

export const FAKE_NOTES = "API キーが設定されていないため、同梱の見本の書類だけ読み取れます。";
export const FAKE_CONFIDENCE = 0.95;

export interface FakeAnswer {
  form: string;
  fields: Record<string, string | null>;
  tables: Record<string, Record<string, string | null>[]>;
}

/** schema の項目の key を拾う（答えの形をそろえるため） */
function keysOf(params: MessageParams): { fields: string[]; tables: string[] } {
  const schema = params.output_config?.format?.schema as { properties?: { fields?: { properties?: Record<string, unknown> }; tables?: { properties?: Record<string, unknown> } } } | undefined;
  return {
    fields: Object.keys(schema?.properties?.fields?.properties ?? {}),
    tables: Object.keys(schema?.properties?.tables?.properties ?? {}),
  };
}

function documentData(params: MessageParams): string | null {
  const content = params.messages[0]?.content;
  if (!Array.isArray(content)) return null;
  for (const block of content) {
    if (block.type === "document" || block.type === "image") return block.source.data;
  }
  return null;
}

/** 鍵なしで見本の書類だけ答える偽のクライアント。答えは書類のハッシュで引く */
export function createFakeClient(answers: Map<string, FakeAnswer>, opts: { confidence?: number } = {}): AnthropicClientLike {
  const confidence = opts.confidence ?? FAKE_CONFIDENCE;
  return {
    messages: {
      async create(params: MessageParams): Promise<FinalMessageLike> {
        const data = documentData(params);
        const id = data === null ? "" : await sha256Hex(fromBase64(data));
        const answer = answers.get(id);
        const { fields, tables } = keysOf(params);
        const raw: RawExtraction = { fields: {}, tables: {}, notes: answer === undefined ? FAKE_NOTES : "" };
        for (const key of fields) {
          const value = answer?.fields[key] ?? null;
          raw.fields[key] = value === null ? { value: null, confidence: 0, evidence: "" } : { value, confidence, evidence: value };
        }
        for (const key of tables) {
          const rows = answer?.tables[key] ?? [];
          raw.tables[key] = { rows, confidence: rows.length === 0 ? 0 : confidence };
        }
        return {
          stop_reason: "end_turn",
          content: [{ type: "text", text: JSON.stringify(raw) }],
          usage: { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 },
        };
      },
    },
  };
}
