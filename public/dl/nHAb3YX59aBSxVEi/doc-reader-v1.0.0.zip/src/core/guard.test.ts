import { describe, expect, it } from "vitest";
import { DEFAULT_LIMITS } from "./config";
import { checkDaily, checkOrigin, checkRate, checkSize, clientIpOf, createGuardState, GUARD_MESSAGES, MAX_KEYS, originAllowed, REMOTE_ADDR_HEADER } from "./guard";

const limits = { ...DEFAULT_LIMITS, perMinute: 2, perHour: 3, daily: 3 };

describe("origin", () => {
  it("origin 無し・自分のオリジン・許可リストは通し、他は 403", () => {
    expect(originAllowed(null, [], "https://a.example")).toBe(true);
    expect(originAllowed("https://a.example", [], "https://a.example")).toBe(true);
    expect(originAllowed("https://b.example", ["https://b.example"], "https://a.example")).toBe(true);
    expect(checkOrigin("https://c.example", [], "https://a.example")).toEqual({ ok: false, status: 403, code: "forbidden", message: GUARD_MESSAGES.forbidden });
  });
});

describe("checkSize", () => {
  it("大きすぎる・ページが多すぎるは 413", () => {
    expect(checkSize(100, 1, limits)).toEqual({ ok: true });
    expect(checkSize(limits.maxFileBytes + 1, 1, limits)).toMatchObject({ ok: false, status: 413, code: "too_large" });
    expect(checkSize(100, limits.maxPages + 1, limits)).toMatchObject({ ok: false, status: 413, code: "too_many_pages" });
    expect((checkSize(100, 99, limits) as { message: string }).message).toContain("20 ページ");
    // 数えられなかった PDF（null）はページの上限を当てない。大きさの上限は当てる
    expect(checkSize(100, null, limits)).toEqual({ ok: true });
    expect(checkSize(limits.maxFileBytes + 1, null, limits)).toMatchObject({ ok: false, code: "too_large" });
  });
});

describe("checkRate / checkDaily", () => {
  it("1 分の上限を超えると 429、時間が過ぎると戻る", () => {
    const state = createGuardState();
    const t0 = 1_000_000;
    expect(checkRate(state, "1.1.1.1", limits, t0)).toEqual({ ok: true });
    expect(checkRate(state, "1.1.1.1", limits, t0 + 1)).toEqual({ ok: true });
    expect(checkRate(state, "1.1.1.1", limits, t0 + 2)).toMatchObject({ ok: false, status: 429, code: "rate_limited" });
    expect(checkRate(state, "2.2.2.2", limits, t0 + 2)).toEqual({ ok: true });
    expect(checkRate(state, "1.1.1.1", limits, t0 + 61_000)).toEqual({ ok: true });
  });
  it("1 時間の上限も見る", () => {
    const state = createGuardState();
    const t0 = 1_000_000;
    checkRate(state, "x", limits, t0);
    checkRate(state, "x", limits, t0 + 40_000);
    checkRate(state, "x", limits, t0 + 80_000);
    expect(checkRate(state, "x", limits, t0 + 120_000)).toMatchObject({ ok: false, code: "rate_limited" });
  });
  it("覚える IP は MAX_KEYS まで", () => {
    const state = createGuardState();
    for (let i = 0; i < MAX_KEYS + 50; i += 1) checkRate(state, `ip-${i}`, limits, 1_000_000 + i);
    expect(state.minute.size).toBeLessThanOrEqual(MAX_KEYS);
  });
  it("1 日の上限は JST の日付で数え直す", () => {
    const state = createGuardState();
    const noon = Date.UTC(2026, 8, 13, 3);
    expect(checkDaily(state, limits, noon)).toEqual({ ok: true });
    checkDaily(state, limits, noon);
    checkDaily(state, limits, noon);
    expect(checkDaily(state, limits, noon)).toMatchObject({ ok: false, status: 429, code: "daily_limit" });
    expect(checkDaily(state, limits, Date.UTC(2026, 8, 13, 15))).toEqual({ ok: true });
  });
});

describe("clientIpOf", () => {
  it("TRUST_PROXY なら x-forwarded-for の末尾、無ければアダプタが押した印、無ければ unknown", () => {
    const req = (headers: Record<string, string>) => new Request("https://a.example/x", { headers });
    expect(clientIpOf(req({ "x-forwarded-for": "1.1.1.1, 2.2.2.2" }), true)).toBe("2.2.2.2");
    expect(clientIpOf(req({ "x-forwarded-for": "1.1.1.1", [REMOTE_ADDR_HEADER]: "9.9.9.9" }), false)).toBe("9.9.9.9");
    expect(clientIpOf(req({}), false)).toBe("unknown");
  });
});
