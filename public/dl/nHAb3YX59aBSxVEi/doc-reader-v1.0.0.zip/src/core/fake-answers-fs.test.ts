import { describe, expect, it } from "vitest";
import { mkdtemp, mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { sha256Hex } from "./document";
import { loadFakeAnswers } from "./fake-answers-fs";

describe("loadFakeAnswers", () => {
  it("expected の JSON と docs の書類をハッシュで結ぶ。書類が無い期待値は飛ばす", async () => {
    const dir = await mkdtemp(join(tmpdir(), "dr-"));
    await mkdir(join(dir, "docs"));
    await mkdir(join(dir, "expected"));
    const pdf = Uint8Array.from(Array.from("%PDF-1.4 x", (c) => c.charCodeAt(0)));
    await writeFile(join(dir, "docs", "invoice-01.pdf"), pdf);
    await writeFile(join(dir, "expected", "invoice-01.json"), JSON.stringify({ form: "invoice", fields: { issuer: "さくら設備" }, tables: {} }));
    await writeFile(join(dir, "expected", "orphan.json"), JSON.stringify({ form: "invoice", fields: {}, tables: {} }));
    const answers = await loadFakeAnswers(dir);
    expect(answers.size).toBe(1);
    expect(answers.get(await sha256Hex(pdf))).toEqual({ form: "invoice", fields: { issuer: "さくら設備" }, tables: {} });
  });

  it("フォルダが無ければ空", async () => {
    expect((await loadFakeAnswers("/nonexistent/samples")).size).toBe(0);
  });
});
