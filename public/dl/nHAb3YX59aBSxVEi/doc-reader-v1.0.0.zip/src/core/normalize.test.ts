import { describe, expect, it } from "vitest";
import { normalizeBoolean, normalizeDate, normalizeEnum, normalizeMoney, normalizeNumber, normalizeString, normalizeValue, toHalfWidth, yen } from "./normalize";

describe("toHalfWidth / normalizeString", () => {
  it("全角の英数記号と空白を半角にする。かなと漢字は変えない", () => {
    expect(toHalfWidth("１２，８００円　ＡＢＣ")).toBe("12,800円 ABC");
    expect(toHalfWidth("みなと商会")).toBe("みなと商会");
  });
  it("文字は前後の空白と改行を落とし、中の空白は 1 つにする。全角半角はそのまま", () => {
    expect(normalizeString("  株式会社\n みなと商会 　")).toBe("株式会社 みなと商会");
    expect(normalizeString("ＡＢＣ")).toBe("ＡＢＣ");
  });
});

describe("normalizeNumber", () => {
  it.each([
    ["3", 3],
    ["１２", 12],
    ["1,200", 1200],
    ["2.5", 2.5],
    ["−3", -3],
    ["△3", -3],
    ["▲1,000", -1000],
    ["3 個", 3],
    ["10本", 10],
  ])("%s → %s", (raw, expected) => {
    expect(normalizeNumber(raw)).toBe(expected);
  });
  it("数が無ければ null", () => {
    expect(normalizeNumber("")).toBeNull();
    expect(normalizeNumber("なし")).toBeNull();
    expect(normalizeNumber("-")).toBeNull();
  });

  it("負号と会計の括弧は金額と同じ規則で読む。末尾の - は負号ではない", () => {
    expect(normalizeNumber("合計 -1,000")).toBe(-1000);
    expect(normalizeNumber("(1,000)")).toBe(-1000);
    expect(normalizeNumber("△3")).toBe(-3);
    expect(normalizeNumber("12,800-")).toBe(12800);
    expect(normalizeNumber("数量 2.5")).toBe(2.5);
  });
});

describe("normalizeMoney", () => {
  it.each([
    ["¥12,800", 12800],
    ["￥１２，８００", 12800],
    ["12,800円", 12800],
    ["12,800-", 12800],
    ["12,800 -", 12800],
    ["金12,800円也", 12800],
    ["△1,000", -1000],
    ["-500", -500],
    ["1,234.56", 1235],
    ["0", 0],
    // 会計の書き方の負（括弧囲み）と、頭に見出しが付いた負号、割合が先に来る書き方
    ["(1,000)", -1000],
    ["（1,000）", -1000],
    ["税抜 △1,000", -1000],
    ["合計 -1,000", -1000],
    ["10% 1,000円", 1000],
    ["消費税（10%） 1,000円", 1000],
  ])("%s → %s", (raw, expected) => {
    expect(normalizeMoney(raw)).toBe(expected);
  });
  it("金額が無ければ null", () => {
    expect(normalizeMoney("")).toBeNull();
    expect(normalizeMoney("円")).toBeNull();
    expect(normalizeMoney("後日")).toBeNull();
  });
});

describe("normalizeDate", () => {
  it.each([
    ["2026-09-13", "2026-09-13"],
    ["2026/9/13", "2026-09-13"],
    ["2026.09.13", "2026-09-13"],
    ["2026年9月13日", "2026-09-13"],
    ["２０２６年９月１３日", "2026-09-13"],
    ["20260913", "2026-09-13"],
    ["発行日:20260913", "2026-09-13"],
    ["No.20260913", null],
    ["#20260913", null],
    ["INV20260913", null],
    ["令和8年9月13日", "2026-09-13"],
    ["令和元年5月1日", "2019-05-01"],
    ["R8.9.13", "2026-09-13"],
    ["平成31年4月30日", "2019-04-30"],
    ["昭和64年1月7日", "1989-01-07"],
    ["2026年9月13日（日）", "2026-09-13"],
    ["発行日: 2026/09/13 10:30", "2026-09-13"],
  ])("%s → %s", (raw, expected) => {
    expect(normalizeDate(raw)).toBe(expected);
  });
  it("読めない・存在しない日付は null", () => {
    expect(normalizeDate("")).toBeNull();
    expect(normalizeDate("9/13")).toBeNull();
    expect(normalizeDate("2026-13-01")).toBeNull();
    expect(normalizeDate("2026-02-30")).toBeNull();
    expect(normalizeDate("来月末")).toBeNull();
  });
});

describe("normalizeBoolean / normalizeEnum", () => {
  it("はい・有・チェックは true、いいえ・無・×は false、それ以外は null", () => {
    for (const t of ["はい", "有", "あり", "✓", "☑", "○", "true", "yes", "1"]) expect(normalizeBoolean(t)).toBe(true);
    for (const f of ["いいえ", "無", "なし", "×", "false", "no", "0"]) expect(normalizeBoolean(f)).toBe(false);
    expect(normalizeBoolean("")).toBeNull();
    expect(normalizeBoolean("たぶん")).toBeNull();
  });
  it("選択肢は完全一致 → 片方が含む → null の順", () => {
    const options = ["現金", "クレジットカード", "電子マネー", "不明"];
    expect(normalizeEnum("クレジットカード", options)).toBe("クレジットカード");
    expect(normalizeEnum(" 現金 ", options)).toBe("現金");
    expect(normalizeEnum("カード", options)).toBe("クレジットカード");
    expect(normalizeEnum("電子マネー（交通系）", options)).toBe("電子マネー");
    expect(normalizeEnum("小切手", options)).toBeNull();
    expect(normalizeEnum("10%", ["10%", "8%"])).toBe("10%");
  });
});

describe("normalizeValue", () => {
  it("型ごとに変換し、文字があったのに変換できなければ invalid", () => {
    expect(normalizeValue("money", "¥1,000", null)).toEqual({ value: 1000, invalid: false });
    expect(normalizeValue("money", "後日", null)).toEqual({ value: null, invalid: true });
    expect(normalizeValue("money", null, null)).toEqual({ value: null, invalid: false });
    expect(normalizeValue("string", "  a  b ", null)).toEqual({ value: "a b", invalid: false });
    expect(normalizeValue("string", "   ", null)).toEqual({ value: null, invalid: false });
    expect(normalizeValue("enum", "カード", ["現金", "クレジットカード"])).toEqual({ value: "クレジットカード", invalid: false });
    expect(normalizeValue("boolean", "有", null)).toEqual({ value: true, invalid: false });
    expect(normalizeValue("date", "R8.9.13", null)).toEqual({ value: "2026-09-13", invalid: false });
  });
});

describe("yen", () => {
  it("3 桁区切り", () => {
    expect(yen(0)).toBe("0");
    expect(yen(12800)).toBe("12,800");
    expect(yen(-1000)).toBe("-1,000");
  });
});
