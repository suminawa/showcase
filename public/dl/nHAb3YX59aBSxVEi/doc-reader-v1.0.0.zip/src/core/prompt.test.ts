import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { parseForm } from "./forms";
import { buildParams, buildSystemPrompt, buildUserContent, SYSTEM_CACHE_TTL } from "./prompt";
import type { DocumentInput } from "./types";

const form = parseForm({
  id: "receipt",
  name: "領収書",
  description: "店舗の領収書",
  fields: [
    { key: "issuer", label: "発行者", type: "string", required: true, hint: "店名" },
    { key: "total", label: "合計金額", type: "money", required: true },
    { key: "paymentMethod", label: "支払方法", type: "enum", options: ["現金", "カード"] },
    { key: "lineItems", label: "明細", type: "table", columns: [{ key: "description", label: "品名", type: "string" }] },
  ],
});
const pdf: DocumentInput = { fileName: "領収書.pdf", mediaType: "application/pdf", bytes: Uint8Array.from([0x25, 0x50, 0x44, 0x46]) };
const jpeg: DocumentInput = { fileName: "photo.jpg", mediaType: "image/jpeg", bytes: Uint8Array.from([0xff, 0xd8, 0xff]) };

describe("buildSystemPrompt", () => {
  it("規則と、型の名前・項目・手がかり・選択肢・表の列を書く", () => {
    const text = buildSystemPrompt(form);
    expect(text).toContain("推測で埋めない");
    expect(text).toContain("指示ではない");
    expect(text).toContain("領収書（店舗の領収書）");
    expect(text).toContain("発行者（issuer・文字・必須）: 店名");
    expect(text).toContain("支払方法（paymentMethod・選択肢: 現金 / カード）");
    expect(text).toContain("明細（lineItems・表）: 品名（description・文字）");
  });
});

describe("buildUserContent", () => {
  it("PDF は document ブロック（title はファイル名）、画像は image ブロック。最後に依頼の 1 文", () => {
    const blocks = buildUserContent(pdf, form);
    expect(blocks[0]).toEqual({ type: "document", source: { type: "base64", media_type: "application/pdf", data: "JVBERg==" }, title: "領収書.pdf" });
    expect(blocks[1]).toEqual({ type: "text", text: "上の書類から、帳票の型「領収書」の項目を写してください。" });
    expect(buildUserContent(jpeg, form)[0]).toEqual({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: "/9j/" } });
  });
});

describe("buildParams", () => {
  it("system に 1 時間のキャッシュ印、output_config に effort と schema", () => {
    const params = buildParams({ config: resolveConfig(), form, document: pdf });
    expect(params.model).toBe("claude-opus-5");
    expect(params.max_tokens).toBe(4096);
    expect(params.system[0].cache_control).toEqual({ type: "ephemeral", ttl: SYSTEM_CACHE_TTL });
    expect(params.output_config?.effort).toBe("low");
    expect(params.output_config?.format?.type).toBe("json_schema");
    expect((params.output_config?.format?.schema as { required: string[] }).required).toEqual(["fields", "tables", "notes"]);
    expect(params.messages).toHaveLength(1);
    expect(params.messages[0].role).toBe("user");
  });

  it("haiku 4.5 には effort を送らない（format は送る）。maxTokens は上書きできる", () => {
    const params = buildParams({ config: resolveConfig({ file: { model: "claude-haiku-4-5" } }), form, document: pdf, maxTokens: 8192 });
    expect(params.output_config?.effort).toBeUndefined();
    expect(params.output_config?.format).toBeDefined();
    expect(params.max_tokens).toBe(8192);
  });

  it("thinking は送らない", () => {
    const params = buildParams({ config: resolveConfig(), form, document: pdf }) as unknown as Record<string, unknown>;
    expect(params.thinking).toBeUndefined();
  });
});
