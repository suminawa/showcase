import { describe, expect, it } from "vitest";
import { reply, scriptedClient } from "../../test/scripted-client";
import { resolveConfig } from "./config";
import { parseForm } from "./forms";
import { EXTRACT_MESSAGES, extractDocument, failureFor, parseRawExtraction, TOKENS_PER_PAGE } from "./extract";
import type { DocumentInput } from "./types";

const form = parseForm({
  id: "receipt",
  name: "領収書",
  fields: [
    { key: "issuer", label: "発行者", type: "string", required: true },
    { key: "total", label: "合計金額", type: "money", required: true },
  ],
});
const doc: DocumentInput = { fileName: "r.pdf", mediaType: "application/pdf", bytes: Uint8Array.from([0x25, 0x50, 0x44, 0x46]) };
const goodJson = JSON.stringify({
  fields: { issuer: { value: "さくら設備", confidence: 0.95, evidence: "さくら設備" }, total: { value: "¥1,100", confidence: 0.9, evidence: "合計 ¥1,100" } },
  tables: {},
  notes: "",
});
const base = (client: ReturnType<typeof scriptedClient>["client"]) => ({
  client,
  config: resolveConfig(),
  form,
  document: doc,
  pages: 1,
  documentId: "abc",
});

describe("extractDocument", () => {
  it("答えを検証して ExtractResult にする（usage・ms・pages・documentId つき）", async () => {
    let t = 1000;
    const { client, calls } = scriptedClient([reply(goodJson)]);
    const out = await extractDocument({ ...base(client), now: () => (t += 250) });
    expect(out).toMatchObject({ ok: true, documentId: "abc", form: "receipt", fileName: "r.pdf", pages: 1, needsReview: false, ms: 250 });
    if (!out.ok) throw new Error();
    expect(out.fields.total.value).toBe(1100);
    expect(out.usage).toEqual({ inputTokens: 3000, outputTokens: 400, cacheReadTokens: 900, cacheCreationTokens: 0 });
    expect(calls).toHaveLength(1);
    expect(calls[0].output_config?.format?.type).toBe("json_schema");
  });

  it("JSON が壊れていたら max_tokens を 2 倍にして 1 回だけ送り直す", async () => {
    const { client, calls } = scriptedClient([reply("{ broken"), reply(goodJson)]);
    const out = await extractDocument(base(client));
    expect(out.ok).toBe(true);
    expect(calls).toHaveLength(2);
    expect(calls[1].max_tokens).toBe(8192);
  });

  it("2 回とも壊れていれば unreadable", async () => {
    const { client } = scriptedClient([reply("nope"), reply("still nope")]);
    const out = await extractDocument(base(client));
    expect(out).toEqual({ ok: false, code: "unreadable", message: EXTRACT_MESSAGES.unreadable });
  });

  it("max_tokens で切れたら送り直す。断られたら refused", async () => {
    const { client, calls } = scriptedClient([reply(goodJson.slice(0, 40), { stop_reason: "max_tokens" }), reply(goodJson)]);
    expect((await extractDocument(base(client))).ok).toBe(true);
    expect(calls[1].max_tokens).toBe(8192);
    const refused = scriptedClient([reply("", { stop_reason: "refusal", content: [] })]);
    expect(await extractDocument(base(refused.client))).toEqual({ ok: false, code: "refused", message: EXTRACT_MESSAGES.refused });
  });

  it("API が失敗したら unavailable（中身は外に出さない）", async () => {
    const { client } = scriptedClient([new Error("boom: sk-ant-secret")]);
    const out = await extractDocument(base(client));
    expect(out).toEqual({ ok: false, code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "network" });
  });

  it("API の失敗は状態で仕分ける。お客さまへの文面はぼかし、理由は記録に残す", async () => {
    const withStatus = (status: number): Error => Object.assign(new Error(`api ${status}`), { status });
    const cases = [
      [400, { code: "unreadable", message: EXTRACT_MESSAGES.unreadable, reason: "request" }],
      [422, { code: "unreadable", message: EXTRACT_MESSAGES.unreadable, reason: "request" }],
      [401, { code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "auth" }],
      [403, { code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "auth" }],
      [429, { code: "rate_limited", message: EXTRACT_MESSAGES.rateLimited, reason: "rate_limited" }],
      [500, { code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "server" }],
      [529, { code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "server" }],
    ] as const;
    for (const [status, expected] of cases) {
      const { client } = scriptedClient([withStatus(status)]);
      expect(await extractDocument(base(client)), `status ${status}`).toEqual({ ok: false, ...expected });
    }
    // 状態が付かない例外（通信そのものが届かなかった）は network
    expect(failureFor(new Error("fetch failed"))).toEqual({ ok: false, code: "unavailable", message: EXTRACT_MESSAGES.unavailable, reason: "network" });
    // 鍵の文字列のような中身は返さない
    const leak = scriptedClient([Object.assign(new Error("invalid x-api-key sk-ant-secret"), { status: 401 })]);
    const out = await extractDocument(base(leak.client));
    expect(JSON.stringify(out)).not.toContain("sk-ant");
  });

  it("text ブロックが複数でも連結して読む", async () => {
    const { client } = scriptedClient([reply("", { content: [{ type: "text", text: goodJson.slice(0, 30) }, { type: "text", text: goodJson.slice(30) }] })]);
    expect((await extractDocument(base(client))).ok).toBe(true);
  });

  it("pages が null なら pages_unknown の警告を積み、要確認にする（読み取りは止めない）", async () => {
    const { client } = scriptedClient([reply(goodJson)]);
    const out = await extractDocument({ ...base(client), pages: null });
    expect(out.ok).toBe(true);
    if (!out.ok) throw new Error();
    expect(out.pages).toBeNull();
    expect(out.needsReview).toBe(true);
    const warning = out.warnings.find((w) => w.code === "pages_unknown");
    expect(warning?.message).toBe("ページ数を確かめられませんでした。20 ページを超える書類は読み取りに時間と費用がかかります。");
    expect(out.fields.total.value).toBe(1100);
  });

  it("入力トークンが上限のページ数 × 3000 を超えたら手元に書き残す（値や中身は書かない）", async () => {
    const seen: string[] = [];
    const original = console.warn;
    console.warn = (...args: unknown[]) => void seen.push(args.map(String).join(" "));
    try {
      const big = scriptedClient([reply(goodJson, { usage: { input_tokens: 20 * TOKENS_PER_PAGE + 1, output_tokens: 100 } })]);
      expect((await extractDocument({ ...base(big.client), pages: null })).ok).toBe(true);
      const small = scriptedClient([reply(goodJson)]);
      expect((await extractDocument(base(small.client))).ok).toBe(true);
    } finally {
      console.warn = original;
    }
    expect(seen).toHaveLength(1);
    expect(seen[0]).toContain("入力トークンが多い読み取りです");
    expect(seen[0]).toContain("60001");
    expect(seen[0]).not.toContain("さくら設備");
  });
});

describe("parseRawExtraction", () => {
  it("JSON の object だけを受け、前後の文があっても最初の { から最後の } を読む", () => {
    expect(parseRawExtraction("以下です。" + goodJson + " 以上")?.fields.issuer.value).toBe("さくら設備");
    expect(parseRawExtraction("[1,2]")).toBeNull();
    expect(parseRawExtraction("")).toBeNull();
  });
});
