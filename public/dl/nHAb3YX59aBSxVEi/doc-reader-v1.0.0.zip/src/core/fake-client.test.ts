import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { sha256Hex, toBase64 } from "./document";
import { createFakeClient, FAKE_NOTES } from "./fake-client";
import { parseForm } from "./forms";
import { buildParams } from "./prompt";
import type { DocumentInput, RawExtraction } from "./types";

const form = parseForm({ id: "r", name: "R", fields: [{ key: "issuer", label: "発行者", type: "string" }, { key: "lines", label: "明細", type: "table", columns: [{ key: "n", label: "n", type: "string" }] }] });
const bytes = Uint8Array.from([0x25, 0x50, 0x44, 0x46, 1, 2, 3]);
const doc: DocumentInput = { fileName: "a.pdf", mediaType: "application/pdf", bytes };

describe("createFakeClient", () => {
  it("書類のハッシュに合う答えを、値は文字・confidence 0.95・evidence は値で返す", async () => {
    const id = await sha256Hex(bytes);
    const client = createFakeClient(new Map([[id, { form: "r", fields: { issuer: "さくら設備" }, tables: { lines: [{ n: "x" }] } }]]));
    const message = await client.messages.create(buildParams({ config: resolveConfig(), form, document: doc }));
    const raw = JSON.parse(message.content[0].text ?? "") as RawExtraction;
    expect(raw.fields.issuer).toEqual({ value: "さくら設備", confidence: 0.95, evidence: "さくら設備" });
    expect(raw.tables.lines).toEqual({ rows: [{ n: "x" }], confidence: 0.95 });
    expect(message.usage.input_tokens).toBe(0);
    expect(message.stop_reason).toBe("end_turn");
  });

  it("知らない書類は全部 null・confidence 0・notes に案内", async () => {
    const client = createFakeClient(new Map());
    const message = await client.messages.create(buildParams({ config: resolveConfig(), form, document: doc }));
    const raw = JSON.parse(message.content[0].text ?? "") as RawExtraction;
    expect(raw.fields.issuer).toEqual({ value: null, confidence: 0, evidence: "" });
    expect(raw.tables.lines).toEqual({ rows: [], confidence: 0 });
    expect(raw.notes).toBe(FAKE_NOTES);
    expect(toBase64(bytes)).toBe("JVBERgECAw==");
  });
});
