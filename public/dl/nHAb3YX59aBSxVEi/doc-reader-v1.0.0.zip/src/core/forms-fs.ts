import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import type { FormDef } from "./types";
import { FormError, parseForm } from "./forms";

/** forms/ の *.json を名前順に読む。1 本でも壊れていれば止める（黙って抜けると読み取りが変わる） */
export async function loadForms(dir: string): Promise<Map<string, FormDef>> {
  let names: string[];
  try {
    names = (await readdir(dir)).filter((name) => name.endsWith(".json")).sort();
  } catch (error) {
    throw new FormError(`帳票の型のフォルダ ${dir} が読めません`, { cause: error });
  }
  const forms = new Map<string, FormDef>();
  for (const name of names) {
    let raw: unknown;
    try {
      raw = JSON.parse(await readFile(join(dir, name), "utf8")) as unknown;
    } catch (error) {
      throw new FormError(`帳票の型 ${name}: JSON として読めません`, { cause: error });
    }
    const form = parseForm(raw, name);
    if (forms.has(form.id)) throw new FormError(`帳票の型 ${name}: id「${form.id}」が重複しています`);
    forms.set(form.id, form);
  }
  return forms;
}
