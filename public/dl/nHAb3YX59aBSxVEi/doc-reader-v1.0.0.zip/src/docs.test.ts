import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";
import { DEFAULT_LABELS, DEFAULT_LIMITS, DEFAULT_MODEL, DEFAULT_THRESHOLD } from "./core/config";

const root = new URL("../", import.meta.url);
const read = (name: string) => readFile(new URL(name, root), "utf8");

describe("README と実物がずれていないか", () => {
  it("画面の文言の表が DEFAULT_LABELS と同じ", async () => {
    const text = await read("README.ja.md");
    for (const [key, value] of Object.entries(DEFAULT_LABELS)) expect(text).toContain(`| \`${key}\` | ${value} |`);
  });
  it("既定値の表が config.ts と同じ", async () => {
    const text = await read("README.ja.md");
    expect(text).toContain(`| \`model\` | \`${DEFAULT_MODEL}\``);
    expect(text).toContain(`| \`confidenceThreshold\` | \`${DEFAULT_THRESHOLD}\``);
    expect(text).toContain(`| \`limits.maxPages\` | \`${DEFAULT_LIMITS.maxPages}\``);
    expect(text).toContain(`| \`limits.daily\` | \`${DEFAULT_LIMITS.daily}\``);
  });
  it("環境変数の表が resolveConfig の読む名前をすべて載せている", async () => {
    const text = await read("README.ja.md");
    for (const name of ["ANTHROPIC_API_KEY", "ADMIN_TOKEN", "ALLOWED_ORIGINS", "TRUST_PROXY", "SEND_WEBHOOK_URL", "SEND_TOKEN", "LOG_WEBHOOK_URL", "DAILY_LIMIT", "READER_FAKE"]) {
      expect(text).toContain(`| \`${name}\` |`);
    }
  });
  it("大げさな言い方をしていない。実在の社名・電話・登録番号を書いていない", async () => {
    for (const name of ["README.ja.md", "LICENSE.md", "CHANGELOG.md", "templates/nextjs/README.md", "samples/README.md"]) {
      const text = await read(name);
      for (const word of ["業界初", "圧倒的", "完全に", "100%", "何でも読め"]) expect(text, name).not.toContain(word);
      expect(text, name).not.toMatch(/0\d{1,3}-[1-9]\d{1,3}-\d{3,4}/);
    }
  });
  it("テンプレの 1 ファイルの上限が、テンプレと README の説明と合っている", async () => {
    const config = JSON.parse(await read("templates/nextjs/reader.config.json")) as { limits: { maxFileBytes: number }; labels: { dropHere?: string } };
    // Vercel の関数が受け取れる本文は 4.5 MB まで。テンプレはその内側に収める
    expect(config.limits.maxFileBytes).toBe(4 * 1024 * 1024);
    expect(config.labels.dropHere).toContain("4 MB");
    for (const name of ["templates/nextjs/README.md", "README.ja.md"]) {
      expect(await read(name), name).toContain(String(config.limits.maxFileBytes));
      expect(await read(name), name).toContain("4.5 MB");
    }
  });
  it("ライセンスと変更履歴に必要な節がある", async () => {
    const license = await read("LICENSE.md");
    for (const word of ["個人ライセンス", "組織ライセンス", "再配布", "API の費用", "読み取りの内容", "返金"]) expect(license).toContain(word);
    const changelog = await read("CHANGELOG.md");
    expect(changelog).toContain("## 1.0.0");
  });
});
