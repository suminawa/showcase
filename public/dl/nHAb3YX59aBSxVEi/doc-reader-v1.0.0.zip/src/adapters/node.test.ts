import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { AddressInfo } from "node:net";
import type { Server } from "node:http";
import { resolveConfig } from "../core/config";
import { createFakeClient } from "../core/fake-client";
import { parseForm } from "../core/forms";
import { createReader } from "../core/handler";
import { createNodeServer } from "./node";

const forms = new Map([["receipt", parseForm({ id: "receipt", name: "領収書", fields: [{ key: "issuer", label: "発行者", type: "string" }] })]]);
const pdf = Uint8Array.from(Array.from("%PDF-1.4 << /Type /Page >>", (c) => c.charCodeAt(0)));
let server: Server;
let base = "";

beforeAll(async () => {
  const reader = createReader(resolveConfig({ file: { defaultForm: "receipt" } }), { forms, client: createFakeClient(new Map()) });
  server = createNodeServer(reader, { staticDir: new URL("../..", import.meta.url).pathname, staticPrefixes: ["demo", "dist", "samples"] });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
});

describe("createNodeServer", () => {
  it("API に multipart を渡せて、health も答える", async () => {
    const body = new FormData();
    body.set("file", new File([pdf], "r.pdf"));
    const res = await fetch(`${base}/api/reader/extract`, { method: "POST", body });
    expect(res.status).toBe(200);
    expect(((await res.json()) as { ok: boolean; form: string }).form).toBe("receipt");
    expect(((await (await fetch(`${base}/api/reader/health`)).json()) as { ok: boolean }).ok).toBe(true);
  });

  it("demo と samples は配り、package.json や上の階層は配らない", async () => {
    expect((await fetch(`${base}/demo/index.html`)).status).toBe(200);
    expect((await fetch(`${base}/`)).status).toBe(200);
    expect((await fetch(`${base}/samples/index.json`)).status).toBe(200);
    expect((await fetch(`${base}/package.json`)).status).toBe(404);
    expect((await fetch(`${base}/demo/../package.json`)).status).toBe(404);
    expect((await fetch(`${base}/%ff`)).status).toBe(404);
  });

  it("大きすぎる本文は 413", async () => {
    const res = await fetch(`${base}/api/reader/extract`, { method: "POST", headers: { "content-type": "application/json" }, body: "x".repeat(13 * 1024 * 1024) });
    expect(res.status).toBe(413);
  });

  it("接続元のアドレスをヘッダーに押し、訪問者の名乗りは上書きする", async () => {
    const res = await fetch(`${base}/api/reader/health`, { headers: { "x-reader-remote-addr": "9.9.9.9" } });
    expect(res.status).toBe(200);
  });
});
