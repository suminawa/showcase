import { realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";

/** 自分が「直接起動されたファイル」か。npx の bin はシンボリックリンクなので実体のパスで比べる */
export function isMainModule(argv1: string | undefined, selfUrl: string): boolean {
  if (argv1 === undefined) return false;
  try {
    return realpathSync(argv1) === realpathSync(fileURLToPath(selfUrl));
  } catch {
    return false;
  }
}
