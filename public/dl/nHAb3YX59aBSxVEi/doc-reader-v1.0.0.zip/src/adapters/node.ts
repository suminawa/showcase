import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, normalize, resolve, sep } from "node:path";
import { createAnthropicClient } from "../core/client";
import { resolveConfig } from "../core/config";
import { loadConfigFile } from "../core/config-fs";
import { loadFakeAnswers } from "../core/fake-answers-fs";
import { createFakeClient } from "../core/fake-client";
import { loadForms } from "../core/forms-fs";
import { REMOTE_ADDR_HEADER } from "../core/guard";
import { createReader, HANDLER_MESSAGES, MAX_BODY_BYTES, type Reader } from "../core/handler";
import { isMainModule } from "./main-module";

export interface NodeServerOptions {
  staticDir?: string | null;
  /** 先頭要素がこの一覧にある道だけを配る。"demo" を含めば "/" は "/demo/index.html" */
  staticPrefixes?: string[];
  apiPrefix?: string;
}

class BodyTooLargeError extends Error {}

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".pdf": "application/pdf",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
};

const firstHeaderValue = (value: string | string[] | undefined): string | undefined => {
  if (value === undefined) return undefined;
  const first = (Array.isArray(value) ? value[0] : value.split(",")[0]).trim();
  return first === "" ? undefined : first;
};

export async function toWebRequest(req: IncomingMessage, origin: string): Promise<Request> {
  const url = new URL(req.url ?? "/", origin);
  const headers = new Headers();
  for (const [key, value] of Object.entries(req.headers)) {
    if (value === undefined) continue;
    headers.set(key, Array.isArray(value) ? value.join(", ") : value);
  }
  // 回数の上限は接続元で数える。訪問者が同じ名前のヘッダーを送っても必ず上書きする
  const remoteAddress = req.socket.remoteAddress;
  if (remoteAddress !== undefined && remoteAddress !== "") headers.set(REMOTE_ADDR_HEADER, remoteAddress);
  else headers.delete(REMOTE_ADDR_HEADER);
  const method = req.method ?? "GET";
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return new Request(url, { method, headers });
  const chunks: Uint8Array[] = [];
  let total = 0;
  for await (const chunk of req) {
    const piece = chunk as Uint8Array;
    total += piece.byteLength;
    if (total > MAX_BODY_BYTES) throw new BodyTooLargeError();
    chunks.push(piece);
  }
  return new Request(url, { method, headers, body: Buffer.concat(chunks) });
}

export async function sendWebResponse(res: ServerResponse, response: Response): Promise<void> {
  res.on("error", () => {});
  res.statusCode = response.status;
  response.headers.forEach((value, key) => res.setHeader(key, value));
  const body = Buffer.from(await response.arrayBuffer());
  res.end(body);
}

async function serveStatic(res: ServerResponse, staticDir: string, pathname: string, prefixes?: string[]): Promise<boolean> {
  const rootFile = prefixes?.includes("demo") ? "/demo/index.html" : "/index.html";
  const target = pathname === "/" ? rootFile : pathname;
  let relative: string;
  try {
    relative = normalize(decodeURIComponent(target)).replace(/^([/\\])+/, "");
  } catch {
    return false;
  }
  if (prefixes !== undefined && !prefixes.includes(relative.split(/[/\\]/)[0])) return false;
  const file = resolve(staticDir, relative);
  if (file !== resolve(staticDir) && !file.startsWith(resolve(staticDir) + sep)) return false;
  try {
    const body = await readFile(file);
    res.statusCode = 200;
    res.setHeader("content-type", MIME[extname(file)] ?? "application/octet-stream");
    res.setHeader("cache-control", "no-store");
    res.end(body);
    return true;
  } catch {
    return false;
  }
}

export function createNodeServer(reader: Reader, options: NodeServerOptions = {}): Server {
  const staticDir = options.staticDir === undefined ? null : options.staticDir;
  const apiPrefix = options.apiPrefix ?? "/api/reader";
  return createServer((req, res) => {
    res.on("error", () => {});
    void (async () => {
      try {
        const host = req.headers.host ?? "127.0.0.1";
        const proto = firstHeaderValue(req.headers["x-forwarded-proto"]) ?? "http";
        const origin = `${proto}://${host}`;
        const pathname = new URL(req.url ?? "/", origin).pathname;
        if (pathname.startsWith(apiPrefix)) {
          let request: Request;
          try {
            request = await toWebRequest(req, origin);
          } catch (error) {
            if (!(error instanceof BodyTooLargeError)) throw error;
            res.statusCode = 413;
            res.setHeader("content-type", "application/json; charset=utf-8");
            res.end(JSON.stringify({ ok: false, code: "too_large", message: `送信できる大きさを超えています（${Math.round(MAX_BODY_BYTES / 1024 / 1024)} MB まで）。` }));
            return;
          }
          await sendWebResponse(res, await reader.fetch(request));
          return;
        }
        const readOnly = req.method === "GET" || req.method === "HEAD";
        if (staticDir !== null && readOnly && (await serveStatic(res, staticDir, pathname, options.staticPrefixes))) return;
        res.statusCode = 404;
        res.end("Not Found");
      } catch (error) {
        console.error("doc-reader:", error);
        if (res.headersSent || res.writableEnded) {
          if (!res.writableEnded) res.end();
          return;
        }
        res.statusCode = 500;
        res.end("Server Error");
      }
    })();
  });
}

/** node dist/adapters/node.js で立ち上がる。設定と型はカレントから読む */
export async function main(): Promise<Server> {
  const config = resolveConfig({ file: await loadConfigFile("reader.config.json"), env: process.env });
  const forms = await loadForms(config.formsDir);
  const client = config.fake
    ? createFakeClient(await loadFakeAnswers("samples"))
    : config.apiKey === null
      ? undefined
      : createAnthropicClient(config.apiKey);
  const reader = createReader(config, { client, forms });
  const server = createNodeServer(reader, { staticDir: process.cwd(), staticPrefixes: ["demo", "dist", "samples"] });
  const port = Number(process.env.PORT ?? 8790);
  // 既定は手元だけ。同じ LAN の誰かに買い手の API の費用を使われないようにする。外に出すときは HOST=0.0.0.0
  const host = process.env.HOST ?? "127.0.0.1";
  server.listen(port, host, () => {
    const note = config.fake ? "鍵なし。見本の書類だけ読み取れます" : config.apiKey === null ? `鍵がありません。${HANDLER_MESSAGES.unavailable}` : `${config.model}`;
    console.log(`doc-reader: http://${host}:${port}/demo/index.html を開いてください（型 ${forms.size} 種・${note}）`);
  });
  return server;
}

if (isMainModule(process.argv[1], import.meta.url)) {
  void main();
}
