import type { AnthropicClientLike, FinalMessageLike, MessageParams } from "../src/core/types";

/** 筋書きどおりに答える偽のクライアント。呼ばれた引数を calls に残す */
export function scriptedClient(replies: Array<FinalMessageLike | Error>): { client: AnthropicClientLike; calls: MessageParams[] } {
  const calls: MessageParams[] = [];
  const queue = [...replies];
  return {
    calls,
    client: {
      messages: {
        async create(params: MessageParams): Promise<FinalMessageLike> {
          calls.push(params);
          const next = queue.shift();
          if (next === undefined) throw new Error("scripted-client: 筋書きが尽きました");
          if (next instanceof Error) throw next;
          return next;
        },
      },
    },
  };
}

export const reply = (text: string, extra: Partial<FinalMessageLike> = {}): FinalMessageLike => ({
  stop_reason: "end_turn",
  content: [{ type: "text", text }],
  usage: { input_tokens: 3000, output_tokens: 400, cache_read_input_tokens: 900, cache_creation_input_tokens: 0 },
  ...extra,
});
