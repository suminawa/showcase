import { test } from "node:test";
import assert from "node:assert/strict";
import { buildNotifyText, buildPayload } from "../src/message.js";

// 2026-09-19 は土曜
const RESERVATION = {
  ID: "20260918-001",
  状態: "確定",
  日付: "2026-09-19",
  開始: "10:00",
  終了: "11:00",
  サービス: "初回カウンセリング",
  お名前: "山川",
  メール: "taro@example.com",
  電話: "045-000-0000",
  ご要望: "特にありません",
};

test("buildNotifyText: 予約", () => {
  const text = buildNotifyText("reserve", {}, RESERVATION);
  assert.equal(text, "【予約】9/19（土）10:00〜11:00 初回カウンセリング 山川 様（受付番号 20260918-001）");
});

test("buildNotifyText: キャンセル", () => {
  const text = buildNotifyText("cancel", {}, RESERVATION);
  assert.equal(text, "【キャンセル】9/19（土）10:00〜11:00 初回カウンセリング 山川 様（受付番号 20260918-001）");
});

test("buildNotifyText: サービスが空なら、その項目を省く", () => {
  const text = buildNotifyText("reserve", {}, Object.assign({}, RESERVATION, { サービス: "" }));
  assert.equal(text, "【予約】9/19（土）10:00〜11:00 山川 様（受付番号 20260918-001）");
});

test("buildNotifyText: メールと電話は含まれない", () => {
  const text = buildNotifyText("reserve", {}, RESERVATION);
  assert.equal(text.includes("taro@example.com"), false);
  assert.equal(text.includes("045-000-0000"), false);
});

test("buildNotifyText: 1,900 字を超えたら切り詰め、末尾は …", () => {
  const longName = "山".repeat(3000);
  const text = buildNotifyText("reserve", {}, Object.assign({}, RESERVATION, { お名前: longName }));
  assert.equal(text.length, 1900);
  assert.equal(text.endsWith("…"), true);
});

test("buildNotifyText: 1,900 字以内ならそのまま（切り詰めない）", () => {
  const text = buildNotifyText("reserve", {}, RESERVATION);
  assert.ok(text.length < 1900);
  assert.equal(text.endsWith("…"), false);
});

test("buildPayload: Slack は text、Discord は content、LINE は push の形", () => {
  assert.deepEqual(buildPayload("やあ", "slack"), { text: "やあ" });
  assert.deepEqual(buildPayload("やあ", "discord"), { content: "やあ", allowed_mentions: { parse: [] } });
  assert.deepEqual(buildPayload("やあ", "line", { lineTo: " U0000 " }), { to: "U0000", messages: [{ type: "text", text: "やあ" }] });
  assert.deepEqual(buildPayload("やあ", "line"), { to: "", messages: [{ type: "text", text: "やあ" }] });
});

test("buildPayload: お客さまのお名前が呼び出しにならない（Slack は & < > を文字参照に、Discord は allowed_mentions を空に、LINE はそのまま）", () => {
  const text = buildNotifyText("reserve", {}, Object.assign({}, RESERVATION, { お名前: "<!channel> @everyone <@U123> A&B" }));
  assert.equal(text, "【予約】9/19（土）10:00〜11:00 初回カウンセリング <!channel> @everyone <@U123> A&B 様（受付番号 20260918-001）");
  assert.deepEqual(buildPayload(text, "slack"), {
    text: "【予約】9/19（土）10:00〜11:00 初回カウンセリング &lt;!channel&gt; @everyone &lt;@U123&gt; A&amp;B 様（受付番号 20260918-001）",
  });
  assert.deepEqual(buildPayload(text, "discord"), { content: text, allowed_mentions: { parse: [] } });
  assert.equal(buildPayload(text, "line", { lineTo: "U0000" }).messages[0].text, text);
  // URL と改行はそのまま届く（& だけ文字参照になり、Slack が & に戻して開く）
  assert.deepEqual(buildPayload("予約ページ\nhttps://example.com/exec?a=1&b=2", "slack"), { text: "予約ページ\nhttps://example.com/exec?a=1&amp;b=2" });
});

test("buildPayload: 1,900 字に切ってから文字参照にするので、&amp; が途中で割れない", () => {
  for (const head of ["", "x", "xx", "xxx", "xxxx"]) {
    const text = buildNotifyText("reserve", {}, Object.assign({}, RESERVATION, { お名前: head + "&".repeat(3000) }));
    assert.equal(text.length, 1900);
    const slack = buildPayload(text, "slack").text;
    assert.ok(/^【予約】9\/19（土）10:00〜11:00 初回カウンセリング x{0,4}(&amp;)+…$/.test(slack), head.length + " 字ずらし: " + slack.slice(-20));
  }
});
