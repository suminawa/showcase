import { test } from "node:test";
import assert from "node:assert/strict";
import { buildNotifyText } from "../src/message.js";

// 2026-09-19 は土曜
const RESERVATION = {
  ID: "20260918-001",
  状態: "確定",
  日付: "2026-09-19",
  開始: "10:00",
  終了: "11:00",
  サービス: "初回カウンセリング",
  お名前: "山川",
  メール: "taro@example.com",
  電話: "045-000-0000",
  ご要望: "特にありません",
};

test("buildNotifyText: 予約", () => {
  const text = buildNotifyText("reserve", {}, RESERVATION);
  assert.equal(text, "【予約】9/19（土）10:00〜11:00 初回カウンセリング 山川 様（受付番号 20260918-001）");
});

test("buildNotifyText: キャンセル", () => {
  const text = buildNotifyText("cancel", {}, RESERVATION);
  assert.equal(text, "【キャンセル】9/19（土）10:00〜11:00 初回カウンセリング 山川 様（受付番号 20260918-001）");
});

test("buildNotifyText: サービスが空なら、その項目を省く", () => {
  const text = buildNotifyText("reserve", {}, Object.assign({}, RESERVATION, { サービス: "" }));
  assert.equal(text, "【予約】9/19（土）10:00〜11:00 山川 様（受付番号 20260918-001）");
});

test("buildNotifyText: メールと電話は含まれない", () => {
  const text = buildNotifyText("reserve", {}, RESERVATION);
  assert.equal(text.includes("taro@example.com"), false);
  assert.equal(text.includes("045-000-0000"), false);
});

test("buildNotifyText: 1,900 字を超えたら切り詰め、末尾は …", () => {
  const longName = "山".repeat(3000);
  const text = buildNotifyText("reserve", {}, Object.assign({}, RESERVATION, { お名前: longName }));
  assert.equal(text.length, 1900);
  assert.equal(text.endsWith("…"), true);
});

test("buildNotifyText: 1,900 字以内ならそのまま（切り詰めない）", () => {
  const text = buildNotifyText("reserve", {}, RESERVATION);
  assert.ok(text.length < 1900);
  assert.equal(text.endsWith("…"), false);
});
