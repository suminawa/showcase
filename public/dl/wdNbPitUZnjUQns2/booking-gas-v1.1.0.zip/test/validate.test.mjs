import { test } from "node:test";
import assert from "node:assert/strict";
import { LIMITS, validateReservation } from "../src/validate.js";
import { DEFAULT_SETTINGS } from "../src/settings.js";

function settings_(over) {
  return Object.assign({}, DEFAULT_SETTINGS, over);
}

const SERVICES = [
  { name: "初回カウンセリング", minutes: 60, description: "", active: true },
  { name: "休止中のメニュー", minutes: 30, description: "", active: false },
];

const VALID_INPUT = {
  name: "山川太郎",
  email: "taro@example.com",
  phone: "045-000-0000",
  note: "特にありません",
  date: "2026-09-19",
  start: "10:00",
  service: "初回カウンセリング",
};

test("お名前にオブジェクトや配列を送っても通らない（画面を通さない送信の備え）", () => {
  for (const bad of [{}, { toString: 1 }, ["山川", "太郎"], () => "山川"]) {
    const input = Object.assign({}, VALID_INPUT, { name: bad });
    const result = validateReservation(input, { settings: settings_(), services: SERVICES });
    assert.equal(result.ok, false, JSON.stringify(bad) + " は通らない");
    assert.equal(result.errors.name, "お名前をご記入ください");
  }
});

test("LIMITS は名前 40・メール 100・電話 20・ご要望 500", () => {
  assert.deepEqual(LIMITS, { name: 40, email: 100, phone: 20, note: 500 });
});

test("正しい入力は ok:true。全角メールは半角になる", () => {
  const input = Object.assign({}, VALID_INPUT, { email: "ｔａｒｏ＠ｅｘａｍｐｌｅ．ｃｏｍ" });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.deepEqual(result, {
    ok: true,
    value: {
      date: "2026-09-19",
      start: "10:00",
      service: "初回カウンセリング",
      name: "山川太郎",
      email: "taro@example.com",
      phone: "045-000-0000",
      note: "特にありません",
    },
  });
});

test("サービスが 1 つも無ければ service は空でも通り、value.service は空になる", () => {
  const input = Object.assign({}, VALID_INPUT, { service: "" });
  const result = validateReservation(input, { settings: settings_(), services: [] });
  assert.equal(result.ok, true);
  assert.equal(result.value.service, "");
});

test("サービスが 1 つも無ければ、何を送ってきても service は空になる", () => {
  const input = Object.assign({}, VALID_INPUT, { service: "何か" });
  const result = validateReservation(input, { settings: settings_(), services: [] });
  assert.equal(result.ok, true);
  assert.equal(result.value.service, "");
});

test("電話は必須でなければ空でも通る", () => {
  const input = Object.assign({}, VALID_INPUT, { phone: "" });
  const result = validateReservation(input, { settings: settings_({ phoneRequired: false }), services: SERVICES });
  assert.equal(result.ok, true);
  assert.equal(result.value.phone, "");
});

test("誤り 1/11: お名前が空", () => {
  const input = Object.assign({}, VALID_INPUT, { name: "" });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.ok, false);
  assert.equal(result.errors.name, "お名前をご記入ください");
});

test("誤り 2/11: お名前が 41 字", () => {
  const input = Object.assign({}, VALID_INPUT, { name: "あ".repeat(41) });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.errors.name, "お名前は 40 字までにしてください");
});

test("誤り 3/11: メールが空", () => {
  const input = Object.assign({}, VALID_INPUT, { email: "" });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.errors.email, "メールアドレスをご記入ください");
});

test("誤り 4/11: メールの形式が違う", () => {
  const input = Object.assign({}, VALID_INPUT, { email: "taro-at-example.com" });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.errors.email, "メールアドレスの形式をご確認ください");
});

test("誤り 5/11: メールが 101 字", () => {
  const input = Object.assign({}, VALID_INPUT, { email: "a".repeat(95) + "@example.com" });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.errors.email, "メールアドレスは 100 字までにしてください");
});

test("誤り 6/11: 電話が必須なのに空", () => {
  const input = Object.assign({}, VALID_INPUT, { phone: "" });
  const result = validateReservation(input, { settings: settings_({ phoneRequired: true }), services: SERVICES });
  assert.equal(result.errors.phone, "電話番号をご記入ください");
});

test("誤り 7/11: 電話が 21 字", () => {
  const input = Object.assign({}, VALID_INPUT, { phone: "1".repeat(21) });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.errors.phone, "電話番号は 20 字までにしてください");
});

test("誤り 8/11: ご要望が 501 字", () => {
  const input = Object.assign({}, VALID_INPUT, { note: "あ".repeat(501) });
  const result = validateReservation(input, { settings: settings_(), services: SERVICES });
  assert.equal(result.errors.note, "ご要望は 500 字までにしてください");
});

test("誤り 9/11: 日付が選ばれていない・形が違う", () => {
  const empty = validateReservation(Object.assign({}, VALID_INPUT, { date: "" }), { settings: settings_(), services: SERVICES });
  assert.equal(empty.errors.date, "日付をお選びください");
  const wrong = validateReservation(Object.assign({}, VALID_INPUT, { date: "2026/09/19" }), { settings: settings_(), services: SERVICES });
  assert.equal(wrong.errors.date, "日付をお選びください");
});

test("誤り 10/11: 時間が選ばれていない・形が違う", () => {
  const empty = validateReservation(Object.assign({}, VALID_INPUT, { start: "" }), { settings: settings_(), services: SERVICES });
  assert.equal(empty.errors.start, "時間をお選びください");
  const wrong = validateReservation(Object.assign({}, VALID_INPUT, { start: "10時00分" }), { settings: settings_(), services: SERVICES });
  assert.equal(wrong.errors.start, "時間をお選びください");
});

test("誤り 11/11: サービスをお選びください（未選択・受付停止中・存在しない名前）", () => {
  const empty = validateReservation(Object.assign({}, VALID_INPUT, { service: "" }), { settings: settings_(), services: SERVICES });
  assert.equal(empty.errors.service, "サービスをお選びください");
  const inactive = validateReservation(Object.assign({}, VALID_INPUT, { service: "休止中のメニュー" }), { settings: settings_(), services: SERVICES });
  assert.equal(inactive.errors.service, "サービスをお選びください");
  const unknown = validateReservation(Object.assign({}, VALID_INPUT, { service: "存在しないメニュー" }), { settings: settings_(), services: SERVICES });
  assert.equal(unknown.errors.service, "サービスをお選びください");
});

test("誤りは項目ごとに集まる。キーは date email name note phone service start の 7 種", () => {
  const input = { name: "", email: "", phone: "", note: "あ".repeat(501), date: "", start: "", service: "" };
  const result = validateReservation(input, { settings: settings_({ phoneRequired: true }), services: SERVICES });
  assert.equal(result.ok, false);
  assert.deepEqual(Object.keys(result.errors).sort(), ["date", "email", "name", "note", "phone", "service", "start"]);
});
