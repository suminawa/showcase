import { test } from "node:test";
import assert from "node:assert/strict";
import { slotsFor, remainingFor, isBookable, daySummary, calendarDays, cancelAllowed } from "../src/availability.js";
import { parseRules, parseClosedDays } from "../src/rules.js";
import { DEFAULT_SETTINGS } from "../src/settings.js";
import { SERVER_ORDER, ROOT, buildDemoScript } from "../scripts/build.mjs";

/** parseRules が返す 1 行と同じ形を作る */
function rule_(over) {
  return Object.assign(
    { row: 2, weekdays: [], date: null, start: "10:00", end: "12:00", interval: 30, capacity: 1, service: "" },
    over
  );
}

function settings_(over) {
  return Object.assign({}, DEFAULT_SETTINGS, over);
}

/** 確定の予約 1 件 */
function booked_(date, start, state) {
  return { 日付: date, 開始: start, 状態: state === undefined ? "確定" : state };
}

const WEEKDAYS_ALL = [0, 1, 2, 3, 4, 5, 6];

// 2026-10-05 は月曜（1）、10-06 は火（2）、10-07 は水（3）、10-08 は木（4）、10-03 は土（6）

// ---- slotsFor ----

test("slotsFor: 平日の行 10:00〜12:00 間隔 30 定員 1 → 4 枠", () => {
  const rules = [rule_({ weekdays: [1, 2, 3, 4, 5] })];
  assert.deepEqual(slotsFor("2026-10-05", rules, [], ""), [
    { start: "10:00", end: "10:30", capacity: 1 },
    { start: "10:30", end: "11:00", capacity: 1 },
    { start: "11:00", end: "11:30", capacity: 1 },
    { start: "11:30", end: "12:00", capacity: 1 },
  ]);
});

test("slotsFor: 曜日の合わない日は枠なし", () => {
  const rules = [rule_({ weekdays: [1, 2, 3, 4, 5] })];
  // 2026-10-03 は土曜
  assert.deepEqual(slotsFor("2026-10-03", rules, [], ""), []);
});

test("slotsFor: 枠は「終了」までに終わるものだけ作る（終了を越える枠は作らない）", () => {
  // 10:00〜11:10 を 30 分で区切ると、11:00 から始まる枠は 11:30 に終わってしまうので作らない
  const rules = [rule_({ weekdays: [1], start: "10:00", end: "11:10", interval: 30 })];
  assert.deepEqual(slotsFor("2026-10-05", rules, [], ""), [
    { start: "10:00", end: "10:30", capacity: 1 },
    { start: "10:30", end: "11:00", capacity: 1 },
  ]);
  // 割り切れるときは、最後の枠の終わりが「終了」ちょうどになる
  const even = [rule_({ weekdays: [1], start: "10:00", end: "11:00", interval: 30 })];
  assert.deepEqual(slotsFor("2026-10-05", even, [], ""), [
    { start: "10:00", end: "10:30", capacity: 1 },
    { start: "10:30", end: "11:00", capacity: 1 },
  ]);
  // 間隔が受付時間より長いときは、枠が 1 つもできない
  assert.deepEqual(slotsFor("2026-10-05", [rule_({ weekdays: [1], start: "10:00", end: "11:00", interval: 90 })], [], ""), []);
});

test("slotsFor: 日付の行はその日だけ曜日の行に勝つ", () => {
  const rules = [
    rule_({ row: 2, weekdays: [1, 2, 3, 4, 5], start: "10:00", end: "12:00", interval: 30 }),
    rule_({ row: 3, weekdays: [], date: "2026-10-05", start: "13:00", end: "14:00", interval: 60, capacity: 2 }),
  ];
  assert.deepEqual(slotsFor("2026-10-05", rules, [], ""), [{ start: "13:00", end: "14:00", capacity: 2 }]);
  // 別の日は曜日の行のまま（日付の行は漏れない）
  assert.deepEqual(slotsFor("2026-10-06", rules, [], ""), [
    { start: "10:00", end: "10:30", capacity: 1 },
    { start: "10:30", end: "11:00", capacity: 1 },
    { start: "11:00", end: "11:30", capacity: 1 },
    { start: "11:30", end: "12:00", capacity: 1 },
  ]);
});

test("slotsFor: 同じ日付の行が複数あればすべて使う", () => {
  const rules = [
    rule_({ row: 2, weekdays: [1, 2, 3, 4, 5] }),
    rule_({ row: 3, weekdays: [], date: "2026-10-05", start: "13:00", end: "14:00", interval: 60 }),
    rule_({ row: 4, weekdays: [], date: "2026-10-05", start: "15:00", end: "16:00", interval: 60 }),
  ];
  assert.deepEqual(slotsFor("2026-10-05", rules, [], ""), [
    { start: "13:00", end: "14:00", capacity: 1 },
    { start: "15:00", end: "16:00", capacity: 1 },
  ]);
});

test("slotsFor: 休みの日は空（1 日の休みも期間の休みも）", () => {
  const rules = [rule_({ weekdays: WEEKDAYS_ALL })];
  assert.deepEqual(slotsFor("2026-10-05", rules, [{ from: "2026-10-05", to: "2026-10-05" }], ""), []);
  assert.deepEqual(slotsFor("2026-10-05", rules, [{ from: "2026-10-03", to: "2026-10-07" }], ""), []);
  // 期間の外は出る
  assert.equal(slotsFor("2026-10-08", rules, [{ from: "2026-10-03", to: "2026-10-07" }], "").length, 4);
  // 日付の行があっても休みが勝つ
  const dated = [rule_({ weekdays: [], date: "2026-10-05", start: "13:00", end: "14:00", interval: 60 })];
  assert.deepEqual(slotsFor("2026-10-05", dated, [{ from: "2026-10-05", to: "2026-10-05" }], ""), []);
});

test("slotsFor: 同じ開始は定員を足し、終わりは遅い方にする", () => {
  const rules = [
    rule_({ row: 2, weekdays: [1], start: "10:00", end: "11:00", interval: 30, capacity: 1 }),
    rule_({ row: 3, weekdays: [1], start: "10:00", end: "11:00", interval: 60, capacity: 2 }),
  ];
  assert.deepEqual(slotsFor("2026-10-05", rules, [], ""), [
    { start: "10:00", end: "11:00", capacity: 3 },
    { start: "10:30", end: "11:00", capacity: 1 },
  ]);
});

test("slotsFor: 枠は開始の早い順に並ぶ（行の順に関わらず）", () => {
  const rules = [
    rule_({ row: 2, weekdays: [1], start: "15:00", end: "16:00", interval: 60 }),
    rule_({ row: 3, weekdays: [1], start: "09:00", end: "10:00", interval: 60 }),
    rule_({ row: 4, weekdays: [1], start: "12:00", end: "13:00", interval: 60 }),
  ];
  assert.deepEqual(
    slotsFor("2026-10-05", rules, [], "").map((slot) => slot.start),
    ["09:00", "12:00", "15:00"]
  );
});

test("slotsFor: 夜遅い枠も日をまたがない（終了を越える枠は作らないため）", () => {
  const rules = [rule_({ weekdays: [1], start: "23:00", end: "23:59", interval: 30 })];
  assert.deepEqual(slotsFor("2026-10-05", rules, [], ""), [{ start: "23:00", end: "23:30", capacity: 1 }]);
  // 23:30 から 30 分の枠は 00:00 に終わる＝「終了」（最大 23:59）を越えるので作らない
  const late = [rule_({ weekdays: [1], start: "23:30", end: "23:59", interval: 30 })];
  assert.deepEqual(slotsFor("2026-10-05", late, [], ""), []);
});

test("slotsFor: サービスの指定が無ければサービス名の付いた行は出さない", () => {
  const rules = [
    rule_({ row: 2, weekdays: [1], start: "10:00", end: "11:00", interval: 60, service: "" }),
    rule_({ row: 3, weekdays: [1], start: "13:00", end: "14:00", interval: 60, service: "初回カウンセリング" }),
    rule_({ row: 4, weekdays: [1], start: "15:00", end: "16:00", interval: 60, service: "整体 60 分" }),
  ];
  assert.deepEqual(
    slotsFor("2026-10-05", rules, [], "").map((slot) => slot.start),
    ["10:00"]
  );
});

test("slotsFor: サービスを指定すると、その行とサービス名の無い行が出る", () => {
  const rules = [
    rule_({ row: 2, weekdays: [1], start: "10:00", end: "11:00", interval: 60, service: "" }),
    rule_({ row: 3, weekdays: [1], start: "13:00", end: "14:00", interval: 60, service: "初回カウンセリング" }),
    rule_({ row: 4, weekdays: [1], start: "15:00", end: "16:00", interval: 60, service: "整体 60 分" }),
  ];
  assert.deepEqual(
    slotsFor("2026-10-05", rules, [], "初回カウンセリング").map((slot) => slot.start),
    ["10:00", "13:00"]
  );
  assert.deepEqual(
    slotsFor("2026-10-05", rules, [], "整体 60 分").map((slot) => slot.start),
    ["10:00", "15:00"]
  );
  // 知らないサービス名では、サービス名の無い行だけ
  assert.deepEqual(
    slotsFor("2026-10-05", rules, [], "無い名前").map((slot) => slot.start),
    ["10:00"]
  );
});

test("slotsFor: うるう日 2028-02-29 は火曜（2）として扱う", () => {
  const rules = [rule_({ weekdays: [2], start: "10:00", end: "11:00", interval: 60 })];
  assert.deepEqual(slotsFor("2028-02-29", rules, [], ""), [{ start: "10:00", end: "11:00", capacity: 1 }]);
  // 翌日 2028-03-01 は水曜なので出ない
  assert.deepEqual(slotsFor("2028-03-01", rules, [], ""), []);
  // うるう日の日付の行も読める
  const dated = [rule_({ weekdays: [], date: "2028-02-29", start: "09:00", end: "10:00", interval: 60 })];
  assert.deepEqual(slotsFor("2028-02-29", dated, [], ""), [{ start: "09:00", end: "10:00", capacity: 1 }]);
});

test("slotsFor: parseRules / parseClosedDays の返り値をそのまま渡せる", () => {
  const parsed = parseRules([
    ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"],
    ["平日", "", "10:00", "12:00", 30, 1, ""],
    ["", "2026-10-07", "14:00", "15:00", 60, 2, ""],
  ]);
  assert.deepEqual(parsed.errors, []);
  const holidays = parseClosedDays([
    ["日付", "開始日", "終了日", "理由"],
    ["2026-10-06", "", "", "定休日"],
  ]);
  assert.deepEqual(holidays.errors, []);
  assert.equal(slotsFor("2026-10-05", parsed.rules, holidays.closed, "").length, 4);
  assert.deepEqual(slotsFor("2026-10-06", parsed.rules, holidays.closed, ""), []);
  assert.deepEqual(slotsFor("2026-10-07", parsed.rules, holidays.closed, ""), [
    { start: "14:00", end: "15:00", capacity: 2 },
  ]);
});

test("slotsFor: 枠が無い・読めない引数でも落ちない", () => {
  assert.deepEqual(slotsFor("2026-10-05", [], [], ""), []);
  assert.deepEqual(slotsFor("2026-10-05", null, null, ""), []);
  assert.deepEqual(slotsFor("だめな日付", [rule_({ weekdays: WEEKDAYS_ALL })], [], ""), []);
});

// ---- remainingFor ----

test("remainingFor: 確定の予約だけを引く", () => {
  const slots = [
    { start: "10:00", end: "10:30", capacity: 2 },
    { start: "10:30", end: "11:00", capacity: 1 },
  ];
  const reservations = [
    booked_("2026-10-05", "10:00"),
    booked_("2026-10-05", "10:00", "キャンセル"),
    booked_("2026-10-06", "10:00"),
    booked_("2026-10-05", "10:30"),
  ];
  assert.deepEqual(remainingFor(slots, reservations, "2026-10-05"), [
    { start: "10:00", end: "10:30", capacity: 2, remaining: 1 },
    { start: "10:30", end: "11:00", capacity: 1, remaining: 0 },
  ]);
});

test("remainingFor: 定員を超えて入っていても残りは 0 で止める", () => {
  const slots = [{ start: "10:00", end: "10:30", capacity: 1 }];
  const reservations = [booked_("2026-10-05", "10:00"), booked_("2026-10-05", "10:00"), booked_("2026-10-05", "10:00")];
  assert.deepEqual(remainingFor(slots, reservations, "2026-10-05"), [
    { start: "10:00", end: "10:30", capacity: 1, remaining: 0 },
  ]);
});

test("remainingFor: 予約が無ければ残りは定員のまま", () => {
  const slots = [{ start: "10:00", end: "10:30", capacity: 3 }];
  assert.deepEqual(remainingFor(slots, [], "2026-10-05"), [
    { start: "10:00", end: "10:30", capacity: 3, remaining: 3 },
  ]);
  assert.deepEqual(remainingFor(slots, null, "2026-10-05"), [
    { start: "10:00", end: "10:30", capacity: 3, remaining: 3 },
  ]);
  assert.deepEqual(remainingFor([], [booked_("2026-10-05", "10:00")], "2026-10-05"), []);
});

test("remainingFor: 予約の日付・開始がシートの Date でも数える", () => {
  const slots = [{ start: "10:00", end: "10:30", capacity: 2 }];
  // 日付セルは Asia/Tokyo の 0 時、時刻セルは Date で来る
  const reservations = [
    { 日付: new Date(Date.UTC(2026, 9, 5) - 9 * 3600000), 開始: new Date(Date.UTC(1899, 11, 30, 1, 0)), 状態: "確定" },
  ];
  assert.deepEqual(remainingFor(slots, reservations, "2026-10-05"), [
    { start: "10:00", end: "10:30", capacity: 2, remaining: 1 },
  ]);
});

// ---- isBookable ----

test("isBookable: 締切ちょうど（now = 開始 − 24 時間）は false、その 1 分前は true", () => {
  const s = settings_({ leadHours: 24, daysAhead: 30 });
  assert.equal(isBookable("2026-10-05", "10:00", "2026-10-04 09:59", s), true);
  assert.equal(isBookable("2026-10-05", "10:00", "2026-10-04 10:00", s), false);
  assert.equal(isBookable("2026-10-05", "10:00", "2026-10-04 10:01", s), false);
});

test("isBookable: 締切が前の日に回る（開始 00:30・2 時間前）", () => {
  const s = settings_({ leadHours: 2, daysAhead: 30 });
  assert.equal(isBookable("2026-10-05", "00:30", "2026-10-04 22:29", s), true);
  assert.equal(isBookable("2026-10-05", "00:30", "2026-10-04 22:30", s), false);
});

test("isBookable: 日の境をまたぐ締切（開始 23:30・2 時間前）", () => {
  const s = settings_({ leadHours: 2, daysAhead: 30 });
  assert.equal(isBookable("2026-10-05", "23:30", "2026-10-04 23:59", s), true);
  assert.equal(isBookable("2026-10-05", "23:30", "2026-10-05 21:29", s), true);
  assert.equal(isBookable("2026-10-05", "23:30", "2026-10-05 21:30", s), false);
});

test("isBookable: 何時間前まで 0 なら開始の分まで受ける", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  assert.equal(isBookable("2026-10-05", "10:00", "2026-10-05 09:59", s), true);
  assert.equal(isBookable("2026-10-05", "10:00", "2026-10-05 10:00", s), false);
});

test("isBookable: 何日先まで 30 なら 30 日目は true、31 日目は false、昨日は false", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  const now = "2026-10-01 00:00";
  assert.equal(isBookable("2026-10-01", "23:00", now, s), true); // 今日（1 日目）
  assert.equal(isBookable("2026-10-30", "23:00", now, s), true); // 30 日目
  assert.equal(isBookable("2026-10-31", "23:00", now, s), false); // 31 日目
  assert.equal(isBookable("2026-09-30", "23:00", now, s), false); // 昨日
});

test("isBookable: 何日先まで 1 なら今日だけ", () => {
  const s = settings_({ leadHours: 0, daysAhead: 1 });
  assert.equal(isBookable("2026-10-01", "23:00", "2026-10-01 00:00", s), true);
  assert.equal(isBookable("2026-10-02", "23:00", "2026-10-01 00:00", s), false);
});

test("isBookable: 読めない引数は false", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  assert.equal(isBookable("だめな日付", "10:00", "2026-10-01 00:00", s), false);
  assert.equal(isBookable("2026-10-01", "だめな時刻", "2026-10-01 00:00", s), false);
  assert.equal(isBookable("2026-10-01", "10:00", "だめな日時", s), false);
});

// ---- daySummary ----

test("daySummary: 枠が無ければ closed", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  assert.equal(daySummary("2026-10-05", [], "2026-10-05 08:00", s), "closed");
  assert.equal(daySummary("2026-10-05", null, "2026-10-05 08:00", s), "closed");
});

test("daySummary: 全部の枠が締切を過ぎていれば past", () => {
  const s = settings_({ leadHours: 24, daysAhead: 30 });
  const slots = [{ start: "10:00", end: "11:00", capacity: 1, remaining: 1 }];
  assert.equal(daySummary("2026-10-05", slots, "2026-10-05 09:00", s), "past");
});

test("daySummary: 何日先までの外の日も past", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  const slots = [{ start: "10:00", end: "11:00", capacity: 1, remaining: 1 }];
  assert.equal(daySummary("2026-11-05", slots, "2026-10-01 08:00", s), "past");
});

test("daySummary: 受けられる枠の残りが全部 0 なら full", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  const slots = [
    { start: "10:00", end: "11:00", capacity: 1, remaining: 0 },
    { start: "11:00", end: "12:00", capacity: 1, remaining: 0 },
    { start: "12:00", end: "13:00", capacity: 1, remaining: 0 },
  ];
  assert.equal(daySummary("2026-10-05", slots, "2026-10-05 08:00", s), "full");
});

test("daySummary: 残りのある枠が 2 つ以下なら few、3 つ以上なら open", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  const two = [
    { start: "10:00", end: "11:00", capacity: 1, remaining: 1 },
    { start: "11:00", end: "12:00", capacity: 1, remaining: 0 },
    { start: "12:00", end: "13:00", capacity: 1, remaining: 1 },
  ];
  assert.equal(daySummary("2026-10-05", two, "2026-10-05 08:00", s), "few");
  const three = [
    { start: "10:00", end: "11:00", capacity: 1, remaining: 1 },
    { start: "11:00", end: "12:00", capacity: 1, remaining: 1 },
    { start: "12:00", end: "13:00", capacity: 1, remaining: 1 },
  ];
  assert.equal(daySummary("2026-10-05", three, "2026-10-05 08:00", s), "open");
});

test("daySummary: 締切を過ぎた枠は数に入れない", () => {
  const s = settings_({ leadHours: 2, daysAhead: 30 });
  const slots = [
    { start: "10:00", end: "11:00", capacity: 1, remaining: 1 }, // 締切 08:00（過ぎた）
    { start: "18:00", end: "19:00", capacity: 1, remaining: 1 }, // 締切 16:00（まだ）
  ];
  assert.equal(daySummary("2026-10-05", slots, "2026-10-05 09:30", s), "few");
  // 残っているのが締切を過ぎた枠だけなら full ではなく…受けられる枠の残りが 0 で full
  const filled = [
    { start: "10:00", end: "11:00", capacity: 1, remaining: 1 },
    { start: "18:00", end: "19:00", capacity: 1, remaining: 0 },
  ];
  assert.equal(daySummary("2026-10-05", filled, "2026-10-05 09:30", s), "full");
});

// ---- calendarDays ----

test("calendarDays: 今日から何日先までの日と状態を返す", () => {
  const s = settings_({ leadHours: 0, daysAhead: 4 });
  const rules = [rule_({ weekdays: [1, 2, 3, 4, 5], start: "10:00", end: "13:00", interval: 60 })];
  const closed = [{ from: "2026-10-06", to: "2026-10-06" }];
  const reservations = [
    booked_("2026-10-07", "10:00"),
    booked_("2026-10-07", "11:00"),
    booked_("2026-10-07", "12:00"),
  ];
  assert.deepEqual(calendarDays("2026-10-05 08:00", s, rules, closed, reservations, ""), [
    { date: "2026-10-05", status: "open" },
    { date: "2026-10-06", status: "closed" },
    { date: "2026-10-07", status: "full" },
    { date: "2026-10-08", status: "open" },
  ]);
});

test("calendarDays: 今日の枠が終わっていれば past", () => {
  const s = settings_({ leadHours: 0, daysAhead: 2 });
  const rules = [rule_({ weekdays: [1, 2, 3, 4, 5], start: "10:00", end: "13:00", interval: 60 })];
  assert.deepEqual(calendarDays("2026-10-05 12:30", s, rules, [], [], ""), [
    { date: "2026-10-05", status: "past" },
    { date: "2026-10-06", status: "open" },
  ]);
});

test("calendarDays: 日数は「何日先まで」の数と同じ。サービスで絞れる", () => {
  const s = settings_({ leadHours: 0, daysAhead: 30 });
  const rules = [
    rule_({ row: 2, weekdays: WEEKDAYS_ALL, start: "10:00", end: "13:00", interval: 60, service: "初回カウンセリング" }),
  ];
  const days = calendarDays("2026-10-05 08:00", s, rules, [], [], "初回カウンセリング");
  assert.equal(days.length, 30);
  assert.deepEqual(days[0], { date: "2026-10-05", status: "open" });
  assert.deepEqual(days[29], { date: "2026-11-03", status: "open" });
  // サービスを選んでいなければ、サービス名の付いた行は出ないので休みと同じ扱い
  const none = calendarDays("2026-10-05 08:00", s, rules, [], [], "");
  assert.deepEqual(none[0], { date: "2026-10-05", status: "closed" });
});

// ---- cancelAllowed ----

test("cancelAllowed: 締切ちょうどは false、その 1 分前は true", () => {
  const s = settings_({ cancelHours: 24 });
  const reservation = { 日付: "2026-10-05", 開始: "10:00" };
  assert.equal(cancelAllowed(reservation, "2026-10-04 09:59", s), true);
  assert.equal(cancelAllowed(reservation, "2026-10-04 10:00", s), false);
  assert.equal(cancelAllowed(reservation, "2026-10-05 09:00", s), false);
});

test("cancelAllowed: キャンセルは何時間前まで 0 なら開始の分まで", () => {
  const s = settings_({ cancelHours: 0 });
  const reservation = { 日付: "2026-10-05", 開始: "10:00" };
  assert.equal(cancelAllowed(reservation, "2026-10-05 09:59", s), true);
  assert.equal(cancelAllowed(reservation, "2026-10-05 10:00", s), false);
});

test("cancelAllowed: 締切が前の日に回る", () => {
  const s = settings_({ cancelHours: 2 });
  const reservation = { 日付: "2026-10-05", 開始: "00:30" };
  assert.equal(cancelAllowed(reservation, "2026-10-04 22:29", s), true);
  assert.equal(cancelAllowed(reservation, "2026-10-04 22:30", s), false);
});

test("cancelAllowed: 読めない予約は false", () => {
  const s = settings_({ cancelHours: 24 });
  assert.equal(cancelAllowed({}, "2026-10-04 09:59", s), false);
  assert.equal(cancelAllowed(null, "2026-10-04 09:59", s), false);
  assert.equal(cancelAllowed({ 日付: "2026-10-05", 開始: "10:00" }, "だめな日時", s), false);
});

// ---- build への組み込み ----

test("availability.js が Code.gs と見本ページに入る", () => {
  assert.ok(SERVER_ORDER.indexOf("availability.js") > SERVER_ORDER.indexOf("services.js"));
  assert.ok(buildDemoScript(ROOT).includes("// ===== availability.js ====="));
});
