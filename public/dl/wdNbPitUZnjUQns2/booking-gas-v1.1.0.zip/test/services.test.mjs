import { test } from "node:test";
import assert from "node:assert/strict";
import { parseServices, findService } from "../src/services.js";

const SERVICE_HEADER = ["サービス", "所要時間", "説明", "受付"];

test("parseServices: 通常の行を読む", () => {
  const { services, errors } = parseServices([
    SERVICE_HEADER,
    ["初回カウンセリング", "60", "初めての方はこちら", "TRUE"],
    ["再来のご相談", "30", "", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(services, [
    { name: "初回カウンセリング", minutes: 60, description: "初めての方はこちら", active: true },
    { name: "再来のご相談", minutes: 30, description: "", active: true },
  ]);
});

test("parseServices: 所要時間は空なら null、受付は空なら TRUE、FALSE も読む", () => {
  const { services, errors } = parseServices([
    SERVICE_HEADER,
    ["ご相談", "", "", ""],
    ["休止中のメニュー", "45", "", "FALSE"],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(services[0].minutes, null);
  assert.equal(services[0].active, true);
  assert.equal(services[1].active, false);
});

test("parseServices: 誤り サービス名が空", () => {
  const { services, errors } = parseServices([
    SERVICE_HEADER,
    ["", "30", "", ""],
  ]);
  assert.deepEqual(errors, ["booking: サービスシートの 2 行目: サービス名をご記入ください"]);
  assert.deepEqual(services, []);
});

test("parseServices: 誤り サービス名の重複", () => {
  const { services, errors } = parseServices([
    SERVICE_HEADER,
    ["初回カウンセリング", "60", "", ""],
    ["初回カウンセリング", "90", "", ""],
  ]);
  assert.deepEqual(errors, ["booking: サービスシートの 3 行目: サービス名「初回カウンセリング」が重複しています"]);
  assert.deepEqual(services, [
    { name: "初回カウンセリング", minutes: 60, description: "", active: true },
  ]);
});

test("parseServices: 誤り 所要時間が範囲外", () => {
  const tooShort = parseServices([SERVICE_HEADER, ["ご相談", "3", "", ""]]);
  assert.deepEqual(tooShort.errors, ["booking: サービスシートの 2 行目: 所要時間は 5〜480 の整数にしてください"]);
  assert.deepEqual(tooShort.services, []);

  const tooLong = parseServices([SERVICE_HEADER, ["ご相談", "9999", "", ""]]);
  assert.deepEqual(tooLong.errors, ["booking: サービスシートの 2 行目: 所要時間は 5〜480 の整数にしてください"]);
});

test("parseServices: 列の並びが違っても見出し名で読み取る", () => {
  const shuffled = ["受付", "説明", "サービス", "所要時間"];
  const { services, errors } = parseServices([
    shuffled,
    ["TRUE", "初めての方はこちら", "初回カウンセリング", "60"],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(services, [
    { name: "初回カウンセリング", minutes: 60, description: "初めての方はこちら", active: true },
  ]);
});

test("parseServices: 空行は飛ばす。見出しのみ・空配列は誤りなく空", () => {
  assert.deepEqual(parseServices([]), { services: [], errors: [] });
  assert.deepEqual(parseServices([SERVICE_HEADER]), { services: [], errors: [] });
  const { services, errors } = parseServices([
    SERVICE_HEADER,
    ["", "", "", ""],
    ["初回カウンセリング", "60", "", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(services.length, 1);
});

test("findService: 名前が一致するものを探す。前後の空白は無視。無ければ null", () => {
  const services = [
    { name: "初回カウンセリング", minutes: 60, description: "", active: true },
    { name: "再来のご相談", minutes: 30, description: "", active: true },
  ];
  assert.deepEqual(findService(services, "再来のご相談"), services[1]);
  assert.deepEqual(findService(services, "  初回カウンセリング  "), services[0]);
  assert.equal(findService(services, "存在しない"), null);
  assert.equal(findService([], "初回カウンセリング"), null);
});
