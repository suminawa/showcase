/**
 * 見本ページ用の api（ブラウザの中の見本データ）。サーバー（gas_web.js）と同じ規則で動くことを確かめる。
 * 時計はテストのあいだ止める（memoryApi の引数。見本ページは渡さない）。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { memoryApi } from "../src/ui/api-memory.js";
import { sampleData } from "../src/samples.js";

/** 2026-09-18（金）の昼。見本データはこの日から作られる */
const FIXED_NOW = "2026-09-18 12:00:00";
const FIXED_TODAY = "2026-09-18";
const FIRST = "初回カウンセリング（60 分）";
const REGULAR = "通常の施術";

const SAMPLE = sampleData(FIXED_TODAY);
const HEADER = SAMPLE.reservations[0];

/** 見本の予約（8 件）のキャンセル用の合い言葉を受付番号で引く */
function tokenOf(id) {
  const idAt = HEADER.indexOf("ID");
  const tokenAt = HEADER.indexOf("キャンセル用");
  const found = SAMPLE.reservations.slice(1).filter((row) => row[idAt] === id)[0];
  return found === undefined ? "" : found[tokenAt];
}

/** 予約 1 件ぶんの入力（見えない欄も空で送る） */
function input(extra) {
  return Object.assign({ date: "", start: "", service: FIRST, name: "見本 太郎", email: "taro@example.com", phone: "", note: "", website: "" }, extra || {});
}

test("見本の api: 読み込みは店・サービス・30 日ぶんの空き状況を返す", async () => {
  const api = memoryApi(FIXED_NOW);
  const boot = await api.bootstrap();
  assert.equal(boot.shop.name, "ひだまり整体院");
  assert.equal(boot.shop.phone, "045-000-0000");
  assert.equal(boot.shop.themeColor, "#2f6f5e");
  assert.equal(boot.shop.phoneRequired, false);
  assert.equal(boot.shop.dateFormat, "yyyy-MM-dd");
  assert.equal(boot.shop.cancelHours, 24);
  assert.ok(boot.shop.notice.includes("10 分前"));
  assert.deepEqual(boot.services.map((s) => s.name), [FIRST, REGULAR]);
  assert.equal(boot.services[0].minutes, 60);
  assert.deepEqual(boot.errors, []);
  assert.equal(boot.today, FIXED_TODAY);

  assert.equal(boot.days.length, 30, "設定「何日先まで」は 30");
  assert.deepEqual(boot.days[0], { date: "2026-09-18", status: "closed" }, "サービスを選ぶ前は、サービス名の無い枠だけで数える");
  assert.equal(boot.days.filter((d) => d.status === "open").length > 0, true, "空きのある日がある");
  assert.equal(boot.days.filter((d) => d.date === "2026-09-19")[0].status, "open");
  assert.equal(boot.days.filter((d) => d.date === "2026-09-23")[0].status, "closed", "休みの日");
});

test("見本の api: 日ごとの印は受付中のサービスごとに返す", async () => {
  const api = memoryApi(FIXED_NOW);
  const boot = await api.bootstrap();
  assert.deepEqual(Object.keys(boot.daysByService), [FIRST, REGULAR]);

  /** その日の印を引く */
  const markOf = (days, date) => days.filter((day) => day.date === date)[0].status;
  for (const name of [FIRST, REGULAR]) {
    assert.equal(boot.daysByService[name].length, 30);
    assert.equal(markOf(boot.daysByService[name], "2026-09-18"), "past", "今日は締切を過ぎている");
  }
  // 火曜は 10:00〜13:00 が初回・14:00〜19:00 が通常。サービスによって印が変わる
  assert.equal(markOf(boot.daysByService[FIRST], "2026-09-22"), "few", "残りわずか");
  assert.equal(markOf(boot.daysByService[REGULAR], "2026-09-22"), "open");
  assert.equal(markOf(boot.days, "2026-09-22"), "closed");
  // 土曜はサービスを問わない枠なので、どのサービスでも同じ印
  for (const days of [boot.days, boot.daysByService[FIRST], boot.daysByService[REGULAR]]) {
    assert.equal(markOf(days, "2026-09-19"), "open");
  }
});

test("見本の api: 空きは受け付けられる枠だけを返す（締切を過ぎた枠は出さない）", async () => {
  const api = memoryApi(FIXED_NOW);

  assert.deepEqual(await api.availability("2026-09-18", FIRST), { date: "2026-09-18", slots: [] }, "今日はすべて締切を過ぎている");

  const saturday = await api.availability("2026-09-19", FIRST);
  assert.equal(saturday.date, "2026-09-19");
  assert.deepEqual(saturday.slots[0], { start: "12:15", end: "13:00", remaining: 2 }, "24 時間前を過ぎた枠は出さない");

  const tuesday = await api.availability("2026-09-22", FIRST);
  assert.deepEqual(tuesday.slots, [
    { start: "10:00", end: "11:00", remaining: 0 },
    { start: "11:00", end: "12:00", remaining: 1 },
    { start: "12:00", end: "13:00", remaining: 1 },
  ]);
  assert.deepEqual((await api.availability("2026-09-23", FIRST)).slots, [], "休みの日は空");
  await assert.rejects(api.availability("きのう", FIRST), /日付をお選びください/);
});

test("見本の api: 予約すると受付番号が返り、その枠の残りが減る", async () => {
  const api = memoryApi(FIXED_NOW);
  const before = await api.availability("2026-09-21", FIRST);
  assert.deepEqual(before.slots[0], { start: "10:00", end: "11:00", remaining: 1 });

  const done = await api.reserve(input({ date: "2026-09-21", start: "10:00" }));
  assert.equal(done.ok, true);
  assert.equal(done.id, "20260918-009", "受付番号は見本の予約（8 件）の続きから");
  assert.equal(done.date, "2026-09-21");
  assert.equal(done.start, "10:00");
  assert.equal(done.end, "11:00");
  assert.equal(done.service, FIRST);

  const after = await api.availability("2026-09-21", FIRST);
  assert.deepEqual(after.slots[0], { start: "10:00", end: "11:00", remaining: 0 });

  const second = await api.reserve(input({ date: "2026-09-21", start: "11:00", email: "hanako@example.com" }));
  assert.equal(second.id, "20260918-010", "受付番号は続き番号");
});

test("見本の api: 満席の枠と、入力の誤りは断る", async () => {
  const api = memoryApi(FIXED_NOW);
  // 見本の予約が入っている枠（2026-09-22 10:00）
  await assert.rejects(api.reserve(input({ date: "2026-09-22", start: "10:00" })), /満席/);
  // 締切を過ぎた枠
  await assert.rejects(api.reserve(input({ date: "2026-09-18", start: "10:00" })), /受付を終了しました/);
  await assert.rejects(api.reserve(input({ date: "2026-09-21", start: "10:00", email: "ちがう" })), /メールアドレスの形式をご確認ください/);
  await assert.rejects(api.reserve(input({ date: "2026-09-21", start: "10:00", name: "" })), /お名前をご記入ください/);
  await assert.rejects(api.reserve(input({ date: "2026-09-21", start: "10:00", service: "無いサービス" })), /サービスをお選びください/);
  await assert.rejects(api.reserve(input({ date: "2026-09-21", start: "10:00" })).then(() => api.reserve(input({ date: "2026-09-21", start: "10:00", email: "hanako@example.com" }))), /満席/);
});

test("見本の api: 同じメールアドレスのご予約は 3 件まで", async () => {
  const api = memoryApi(FIXED_NOW);
  await api.reserve(input({ date: "2026-09-21", start: "10:00" }));
  await api.reserve(input({ date: "2026-09-21", start: "11:00" }));
  await api.reserve(input({ date: "2026-09-25", start: "10:00" }));
  await assert.rejects(api.reserve(input({ date: "2026-09-25", start: "11:00" })), /同じメールアドレスでのご予約は 3 件までです。/);
  const other = await api.reserve(input({ date: "2026-09-25", start: "11:00", email: "Hanako@example.com" }));
  assert.equal(other.ok, true, "別のメールアドレスなら受け付ける");
});

test("見本の api: 見えない欄が埋まっていたら、成功したように見せて何も書かない", async () => {
  const api = memoryApi(FIXED_NOW);
  const before = await api.availability("2026-09-21", FIRST);
  const done = await api.reserve(input({ date: "2026-09-21", start: "10:00", website: "http://example.com" }));
  assert.equal(done.ok, true);
  assert.equal(done.id, "—");
  assert.equal(done.mailSent, false);
  const after = await api.availability("2026-09-21", FIRST);
  assert.deepEqual(after.slots, before.slots, "残りは変わらない");
});

test("見本の api: 合い言葉でご予約を出し、キャンセルすると枠が空く", async () => {
  const api = memoryApi(FIXED_NOW);
  assert.deepEqual(await api.cancelInfo("ありません"), { found: false });
  assert.deepEqual(await api.cancelInfo(""), { found: false });

  // 見本の 3 件目（2026-09-25 14:00 通常の施術）
  const token = tokenOf("20260918-003");
  const info = await api.cancelInfo(token);
  assert.equal(info.found, true);
  assert.equal(info.reservation.id, "20260918-003");
  assert.equal(info.reservation.date, "2026-09-25");
  assert.equal(info.reservation.start, "14:00");
  assert.equal(info.reservation.service, REGULAR);
  assert.equal(info.reservation.status, "確定");
  assert.equal(info.canCancel, true);
  assert.equal(info.phone, "045-000-0000");

  assert.deepEqual((await api.availability("2026-09-25", REGULAR)).slots[0], { start: "14:00", end: "14:45", remaining: 0 });
  assert.deepEqual(await api.cancel(token), { ok: true, id: "20260918-003" });
  assert.deepEqual((await api.availability("2026-09-25", REGULAR)).slots[0], { start: "14:00", end: "14:45", remaining: 1 }, "キャンセルすると枠が空く");

  const again = await api.cancelInfo(token);
  assert.equal(again.reservation.status, "キャンセル");
  assert.equal(again.canCancel, false);
  await assert.rejects(api.cancel(token), /すでにキャンセルされています/);
  await assert.rejects(api.cancel("ffffffffffffffffffffffff"), /ご予約が見つかりませんでした/);
  await assert.rejects(api.cancel("ありません"), /キャンセルの URL が正しくありません/);
});

test("見本の api: 締切を過ぎたご予約は、ページからはキャンセルできない", async () => {
  const api = memoryApi(FIXED_NOW);
  // 見本の 1 件目（2026-09-19 10:00。いまの 22 時間後なので 24 時間前を過ぎている）
  const info = await api.cancelInfo(tokenOf("20260918-001"));
  assert.equal(info.found, true);
  assert.equal(info.canCancel, false);
  await assert.rejects(api.cancel(tokenOf("20260918-001")), /キャンセルの受付は開始の 24 時間前までです。お電話でご連絡ください。/);
});

test("見本の api: 誤りは敬体の Error で返し、中身の細かい様子は出さない", async () => {
  const api = memoryApi(FIXED_NOW);
  await assert.rejects(api.cancel("ありません"), (error) => {
    assert.ok(error instanceof Error);
    assert.equal(/at |undefined|null|Object/.test(error.message), false, error.message);
    assert.ok(error.message.endsWith("。"));
    return true;
  });
});

test("見本の api: 時計を渡さなければ、その日を見本データの起点にする", async () => {
  const api = memoryApi();
  const boot = await api.bootstrap();
  assert.match(boot.today, /^\d{4}-\d{2}-\d{2}$/);
  assert.equal(boot.days.length, 30);
  assert.equal(boot.days[0].date, boot.today);
  assert.deepEqual(boot.errors, []);
  assert.deepEqual(boot.services.map((s) => s.name), [FIRST, REGULAR]);
});
