/**
 * 画面のつなぎ（main.js）と、束ねた 1 本（dist/App.html・demo/app.js）の確かめ。
 * ブラウザは使わず、innerHTML と addEventListener だけを持つ最小の偽 DOM で動かす。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Script, runInNewContext } from "node:vm";
import { mountBooking } from "../src/ui/main.js";
import { CLIENT_SHARED, CLIENT_UI, DEMO_EXTRA_SHARED, build } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
// dist と demo は npm test（pretest）で作られるが、このファイルだけを走らせても通るように作り直す
build(root);

const SHOP = {
  name: "ひだまり整体院",
  phone: "045-000-0000",
  address: "みなと市しおかぜ町 1-2-3",
  notice: "初めての方は、開始の 10 分前にお越しください。",
  themeColor: "#2f6f5e",
  phoneRequired: false,
  dateFormat: "yyyy-MM-dd",
  cancelHours: 24,
  leadHours: 24,
};
const SERVICES = [
  { name: "初回カウンセリング（60 分）", minutes: 60, description: "初めての方はこちら" },
  { name: "通常の施術", minutes: 45, description: "2 回目以降の方" },
];
const DAYS = [
  { date: "2026-09-18", status: "past" },
  { date: "2026-09-19", status: "open" },
  { date: "2026-09-21", status: "few" },
];
const BOOT = { shop: SHOP, services: SERVICES, days: DAYS, today: "2026-09-18", errors: [] };
const SLOTS = [{ start: "10:00", end: "11:00", remaining: 1 }];
const TOKEN = "0123456789abcdef01234561";

/** 次の順番まで待つ（偽の api はすぐ答えるので、これで約束がほどける） */
function tick() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

/** innerHTML と委譲の受け口だけを持つ偽の root */
function fakeRoot() {
  const handlers = {};
  return {
    innerHTML: "",
    addEventListener(type, handler) {
      handlers[type] = handler;
    },
    querySelector() {
      return null;
    },
    querySelectorAll() {
      return [];
    },
    contains() {
      return true;
    },
    listeners() {
      return Object.keys(handlers).sort();
    },
    fire(type, event) {
      assert.ok(handlers[type], type + " の受け口がありません");
      handlers[type](event);
    },
  };
}

/** 見出し 1 つぶんの偽の節点（目線を受け取れる） */
function fakeHeading(doc) {
  const node = { tag: "h2", isConnected: true, attrs: {} };
  node.setAttribute = (name, value) => (node.attrs[name] = String(value));
  node.focus = () => (doc.activeElement = node);
  return node;
}

/**
 * 目線（focus）まで追える偽の root。
 * 描き直すと、前の節点は外れてブラウザと同じく目線は <body> へ落ちる
 */
function focusFakeRoot() {
  const handlers = {};
  const body = { tag: "body", isConnected: true };
  const doc = { body: body, activeElement: body };
  let heading = null;
  let html = "";
  return {
    doc: doc,
    heading: () => heading,
    get innerHTML() {
      return html;
    },
    set innerHTML(value) {
      html = String(value);
      if (heading !== null) heading.isConnected = false;
      doc.activeElement = body;
      heading = html.includes('class="bk-h2"') ? fakeHeading(doc) : null;
    },
    addEventListener(type, handler) {
      handlers[type] = handler;
    },
    querySelector(selector) {
      return selector === ".bk-h2" ? heading : null;
    },
    querySelectorAll() {
      return [];
    },
    contains() {
      return true;
    },
    fire(type, event) {
      assert.ok(handlers[type], type + " の受け口がありません");
      handlers[type](event);
    },
  };
}

/** data-action の付いた要素を押したときの event */
function clickOn(dataset) {
  const element = { dataset: dataset };
  return { target: { closest: (selector) => (selector === "[data-action]" ? element : null) } };
}

/** 入力欄を打ったときの event */
function inputOn(name, value) {
  return { target: { name: name, value: value, dataset: {} } };
}

/** 予約フォームを送ったときの event */
function submitOn(values) {
  const prevented = { count: 0 };
  const form = {
    dataset: { form: "reserve" },
    elements: {
      namedItem(name) {
        return Object.prototype.hasOwnProperty.call(values, name) ? { name: name, value: values[name] } : null;
      },
    },
  };
  return { target: form, prevented: prevented, preventDefault: () => (prevented.count += 1) };
}

/** 呼ばれた順に記録する偽の api */
function fakeApi(overrides) {
  const calls = [];
  const api = {
    calls: calls,
    bootstrap() {
      calls.push(["bootstrap"]);
      return Promise.resolve(BOOT);
    },
    availability(date, service) {
      calls.push(["availability", date, service]);
      return Promise.resolve({ date: date, slots: SLOTS });
    },
    reserve(values) {
      calls.push(["reserve", values]);
      return Promise.resolve({ ok: true, id: "20260918-001", date: values.date, start: values.start, end: "11:00", service: values.service, mailSent: true });
    },
    cancelInfo(token) {
      calls.push(["cancelInfo", token]);
      return Promise.resolve({ found: false });
    },
    cancel(token) {
      calls.push(["cancel", token]);
      return Promise.resolve({ ok: true, id: "20260918-001" });
    },
  };
  return Object.assign(api, overrides || {});
}

test("読み込み: まず読み込み中を描き、bootstrap を呼んで画面を作る", async () => {
  const root = fakeRoot();
  const api = fakeApi();
  const app = mountBooking(root, api);
  assert.ok(root.innerHTML.includes("読み込んでいます"));
  assert.deepEqual(root.listeners(), ["change", "click", "input", "submit"]);

  await app.ready;
  assert.deepEqual(api.calls, [["bootstrap"]]);
  assert.equal(app.getState().step, "service");
  assert.ok(root.innerHTML.includes("ひだまり整体院"));
  assert.ok(root.innerHTML.includes("ご希望のサービスをお選びください"));
});

test("読み込み: bootstrap が失敗したら、その文を赤い帯に出す", async () => {
  const root = fakeRoot();
  const api = fakeApi({ bootstrap: () => Promise.reject(new Error("ただいま読み込めませんでした。")) });
  const app = mountBooking(root, api);
  await app.ready;
  assert.equal(app.getState().error, "ただいま読み込めませんでした。");
  assert.ok(root.innerHTML.includes("ただいま読み込めませんでした。"));
  assert.ok(root.innerHTML.includes('role="alert"'));
});

test("キャンセルの URL: window.__BOOKING_CANCEL__ があれば cancelInfo を呼ぶ", async () => {
  const root = fakeRoot();
  const api = fakeApi({
    cancelInfo(token) {
      api.calls.push(["cancelInfo", token]);
      return Promise.resolve({
        found: true,
        reservation: { id: "20260918-003", date: "2026-09-25", start: "14:00", end: "14:45", service: "通常の施術", name: "見本 太郎", status: "確定" },
        canCancel: true,
        phone: "045-000-0000",
      });
    },
  });
  globalThis.window = { __BOOKING_CANCEL__: TOKEN };
  try {
    const app = mountBooking(root, api);
    await app.ready;
    assert.deepEqual(api.calls, [["bootstrap"], ["cancelInfo", TOKEN]]);
    assert.equal(app.getState().step, "cancel");
    assert.ok(root.innerHTML.includes("20260918-003"));
    assert.ok(root.innerHTML.includes("このご予約をキャンセルする"));

    root.fire("click", clickOn({ action: "cancel" }));
    await tick();
    assert.deepEqual(api.calls[2], ["cancel", TOKEN]);
    assert.equal(app.getState().step, "cancelled");
    assert.ok(root.innerHTML.includes("ご予約をキャンセルしました。"));
  } finally {
    delete globalThis.window;
  }
});

test("キャンセルの URL が無ければ cancelInfo は呼ばない", async () => {
  const root = fakeRoot();
  const api = fakeApi();
  const app = mountBooking(root, api);
  await app.ready;
  assert.deepEqual(api.calls, [["bootstrap"]]);
});

test("日を押すと availability を呼び、返ってきた枠を描く（古い返事は捨てる）", async () => {
  const root = fakeRoot();
  const api = fakeApi();
  const app = mountBooking(root, api);
  await app.ready;

  root.fire("click", clickOn({ action: "select-service", name: "初回カウンセリング（60 分）" }));
  assert.equal(app.getState().step, "calendar");

  root.fire("click", clickOn({ action: "select-date", date: "2026-09-21" }));
  assert.deepEqual(api.calls[1], ["availability", "2026-09-21", "初回カウンセリング（60 分）"]);
  assert.equal(app.getState().step, "slots");
  assert.ok(root.innerHTML.includes("空きを読み込んでいます"));

  await tick();
  assert.deepEqual(app.getState().slots, SLOTS);
  assert.ok(root.innerHTML.includes("10:00〜11:00"));

  // 別の日に押し替えたあとに届いた古い返事は捨てる
  root.fire("click", clickOn({ action: "select-date", date: "2026-09-19" }));
  await tick();
  assert.equal(app.getState().date, "2026-09-19");
  assert.deepEqual(api.calls[2], ["availability", "2026-09-19", "初回カウンセリング（60 分）"]);
});

test("目線: 空きが届いて描き直したあとも、見出しに目線が残る", async () => {
  const root = focusFakeRoot();
  globalThis.document = root.doc;
  try {
    const api = fakeApi();
    const app = mountBooking(root, api);
    await app.ready;
    assert.equal(root.doc.activeElement, root.doc.body, "はじめの読み込みでは目線を動かさない");

    root.fire("click", clickOn({ action: "select-service", name: SERVICES[0].name }));
    assert.equal(root.doc.activeElement, root.heading(), "画面が変わったら新しい見出しへ");

    root.fire("click", clickOn({ action: "select-date", date: "2026-09-21" }));
    const beforeSlots = root.heading();
    assert.equal(root.doc.activeElement, beforeSlots);
    assert.ok(root.innerHTML.includes("空きを読み込んでいます"));

    // 空きが届くと、同じ画面のまま描き直す。目線のあった見出しは捨てられる
    await tick();
    assert.equal(beforeSlots.isConnected, false);
    assert.notEqual(root.doc.activeElement, root.doc.body, "目線を body へ落とさない");
    assert.equal(root.doc.activeElement, root.heading(), "描き直したあとの見出しへ移す");
    assert.equal(root.heading().attrs.tabindex, "-1");
    assert.ok(root.innerHTML.includes("10:00〜11:00"));

    // 完了の画面でも、見出しに目線が移る
    root.fire("click", clickOn({ action: "select-slot", start: "10:00" }));
    root.fire("submit", submitOn({ name: "見本 太郎", email: "taro@example.com", phone: "", note: "", website: "" }));
    root.fire("click", clickOn({ action: "reserve" }));
    await tick();
    assert.ok(root.innerHTML.includes("ご予約を受け付けました。"));
    assert.equal(root.doc.activeElement, root.heading());
  } finally {
    delete globalThis.document;
  }
});

test("入力 → 確認へ → 予約する の流れ。誤りがあれば確認へ進まない", async () => {
  const root = fakeRoot();
  const api = fakeApi();
  const app = mountBooking(root, api);
  await app.ready;
  root.fire("click", clickOn({ action: "select-service", name: "通常の施術" }));
  root.fire("click", clickOn({ action: "select-date", date: "2026-09-21" }));
  await tick();
  root.fire("click", clickOn({ action: "select-slot", start: "10:00" }));
  assert.equal(app.getState().step, "form");

  // 打った字は state に残す（描き直しは入力の途中で行わない）
  root.fire("input", inputOn("name", "見本 太郎"));
  assert.equal(app.getState().values.name, "見本 太郎");

  const bad = submitOn({ name: "見本 太郎", email: "ちがう", phone: "", note: "", website: "" });
  root.fire("submit", bad);
  assert.equal(bad.prevented.count, 1, "ページの送信は止める");
  assert.equal(app.getState().step, "form");
  assert.ok(app.getState().errors.email.includes("メールアドレス"));
  assert.ok(root.innerHTML.includes("メールアドレスの形式をご確認ください"));

  root.fire("submit", submitOn({ name: "見本 太郎", email: "taro@example.com", phone: "", note: "肩こり", website: "" }));
  assert.equal(app.getState().step, "confirm");
  assert.deepEqual(app.getState().errors, {});
  assert.ok(root.innerHTML.includes("ご予約の内容をご確認ください"));

  root.fire("click", clickOn({ action: "reserve" }));
  assert.equal(app.getState().busy, true, "送信中は busy");
  root.fire("click", clickOn({ action: "reserve" }));
  await tick();
  assert.equal(api.calls.filter((call) => call[0] === "reserve").length, 1, "二重送信をしない");
  assert.deepEqual(api.calls[api.calls.length - 1], [
    "reserve",
    { name: "見本 太郎", email: "taro@example.com", phone: "", note: "肩こり", website: "", date: "2026-09-21", start: "10:00", service: "通常の施術" },
  ]);
  assert.equal(app.getState().step, "done");
  assert.ok(root.innerHTML.includes("20260918-001"));
  assert.ok(root.innerHTML.includes("ご予約を受け付けました。"));
});

test("予約が断られたら赤い帯に出し、その日の空きを読み直す", async () => {
  const root = fakeRoot();
  const api = fakeApi({ reserve: (values) => { api.calls.push(["reserve", values]); return Promise.reject(new Error("選ばれた時間は、ただいま満席になりました。別の時間をお選びください。")); } });
  const app = mountBooking(root, api);
  await app.ready;
  root.fire("click", clickOn({ action: "select-service", name: "通常の施術" }));
  root.fire("click", clickOn({ action: "select-date", date: "2026-09-21" }));
  await tick();
  root.fire("click", clickOn({ action: "select-slot", start: "10:00" }));
  root.fire("submit", submitOn({ name: "見本 太郎", email: "taro@example.com", phone: "", note: "", website: "" }));
  root.fire("click", clickOn({ action: "reserve" }));
  await tick();
  assert.equal(app.getState().busy, false);
  assert.equal(app.getState().step, "confirm");
  assert.ok(app.getState().error.includes("満席"));
  assert.ok(root.innerHTML.includes("ただいま満席になりました"));
  assert.equal(api.calls.filter((call) => call[0] === "availability").length, 2, "空きを読み直す");

  root.fire("click", clickOn({ action: "dismiss-error" }));
  assert.equal(app.getState().error, "");
});

test("戻るは 確認 → 入力 → 時間 → カレンダー の順、月送りは month を送る", async () => {
  const root = fakeRoot();
  const api = fakeApi();
  const app = mountBooking(root, api);
  await app.ready;
  root.fire("click", clickOn({ action: "select-service", name: "通常の施術" }));
  root.fire("click", clickOn({ action: "month", delta: "1" }));
  assert.equal(app.getState().month, "2026-09", "受け付ける最後の日の月を越えない");
  root.fire("click", clickOn({ action: "select-date", date: "2026-09-21" }));
  await tick();
  root.fire("click", clickOn({ action: "select-slot", start: "10:00" }));
  root.fire("click", clickOn({ action: "back" }));
  assert.equal(app.getState().step, "slots");
  root.fire("click", clickOn({ action: "back" }));
  assert.equal(app.getState().step, "calendar");
  root.fire("click", clickOn({ action: "back" }));
  assert.equal(app.getState().step, "service");
});

test("dist/App.html: google.script.run で動き、見本データを含まず、構文が通る", () => {
  const html = readFileSync(join(root, "dist", "App.html"), "utf8");
  assert.ok(html.includes("google.script.run"));
  assert.ok(html.includes("function mountBooking("));
  assert.ok(html.includes("function renderApp("));
  assert.ok(html.includes("function validateReservation("), "検査は画面でも同じものを動かす");
  assert.ok(html.includes("function findService("), "validate.js が呼ぶので画面の束にも要る");
  assert.equal(html.includes("memoryApi"), false);
  assert.equal(html.includes("sampleData"), false);
  assert.equal(html.includes("ひだまり整体院"), false);
  assert.ok(html.includes('<title>予約</title>'));
  assert.ok(html.includes('name="viewport"'));
  assert.ok(html.includes('lang="ja"'));

  const js = html.slice(html.indexOf("<script>") + 8, html.lastIndexOf("</script>"));
  assert.doesNotThrow(() => new Script(js));
  const css = html.slice(html.indexOf("<style>") + 7, html.indexOf("</style>"));
  assert.ok(css.includes("--bk-accent"));
  assert.ok(css.includes(".bk-sr"), "読み上げ用の隠し文字");
  assert.ok(css.includes(".bk-hp"), "見えない欄");
  assert.ok(css.includes("@media (min-width: 640px)"));
});

test("demo/app.js: 見本データで動き、google に触らない", () => {
  const js = readFileSync(join(root, "demo", "app.js"), "utf8");
  assert.ok(js.includes("window.Booking = { mount:"));
  assert.ok(js.includes("function memoryApi("));
  assert.ok(js.includes("function sampleData("));
  assert.equal(js.includes("google.script.run"), false);
  assert.doesNotThrow(() => new Script(js));

  const html = readFileSync(join(root, "demo", "index.html"), "utf8");
  assert.ok(html.includes('<script src="app.js"></script>'));
  assert.ok(html.includes('window.Booking.mount(document.getElementById("app"))'));
  const css = readFileSync(join(root, "demo", "app.css"), "utf8");
  assert.ok(css.includes("--bk-accent"));
});

test("dist/App.html: 偽の DOM と偽の google.script.run で、読み込みから完了まで通る", async () => {
  const html = readFileSync(join(root, "dist", "App.html"), "utf8");
  const js = html.slice(html.indexOf("<script>") + 8, html.lastIndexOf("</script>"));
  const calls = [];
  const page = fakeRoot();

  /** google.script.run の代わり。答えは次の順番で返す */
  function runner_() {
    const api = {};
    let ok = null;
    let ng = null;
    api.withSuccessHandler = function (fn) {
      ok = fn;
      return api;
    };
    api.withFailureHandler = function (fn) {
      ng = fn;
      return api;
    };
    const answers = {
      api_bootstrap: () => BOOT,
      api_availability: (date) => ({ date: date, slots: SLOTS }),
      api_reserve: (values) => ({ ok: true, id: "20260918-009", date: values.date, start: values.start, end: "11:00", service: values.service, mailSent: true }),
      api_cancelInfo: () => ({ found: false }),
      api_cancel: () => ({ ok: true, id: "20260918-009" }),
    };
    for (const name of Object.keys(answers)) {
      api[name] = function () {
        const args = Array.prototype.slice.call(arguments);
        calls.push(name);
        const answer = answers[name].apply(null, args);
        setTimeout(() => (answer instanceof Error ? ng(answer) : ok(answer)), 0);
      };
    }
    return api;
  }

  const sandbox = { setTimeout: setTimeout, clearTimeout: clearTimeout, document: { getElementById: () => page }, google: { script: { run: runner_() } } };
  sandbox.window = sandbox;
  runInNewContext(js, sandbox);

  await tick();
  assert.ok(page.innerHTML.includes("ひだまり整体院"));
  page.fire("click", clickOn({ action: "select-service", name: SERVICES[0].name }));
  page.fire("click", clickOn({ action: "select-date", date: "2026-09-19" }));
  await tick();
  assert.ok(page.innerHTML.includes("10:00〜11:00"));
  page.fire("click", clickOn({ action: "select-slot", start: "10:00" }));
  assert.ok(page.innerHTML.includes("お客さまの情報をご記入ください"));
  page.fire("submit", submitOn({ name: "見本 太郎", email: "taro@example.com", phone: "", note: "", website: "" }));
  assert.ok(page.innerHTML.includes("ご予約の内容をご確認ください"));
  page.fire("click", clickOn({ action: "reserve" }));
  await tick();
  assert.ok(page.innerHTML.includes("ご予約を受け付けました。"));
  assert.ok(page.innerHTML.includes("20260918-009"));
  assert.deepEqual(calls, ["api_bootstrap", "api_availability", "api_reserve"]);
});

/** 束ねた 1 本の中で宣言されている名前（build の重複検査と同じ読み方） */
function declaredNames_(code) {
  const found = code.match(/^(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm) || [];
  return new Set(found.map((line) => line.replace(/^(?:async\s+)?(?:function|class|const|let|var)\s+/, "")));
}

/** そのファイルが import している名前 */
function importedNames_(path) {
  const code = readFileSync(join(root, path), "utf8");
  const names = [];
  const matched = code.match(/^import\s*\{[^}]*\}\s*from\s*["'][^"']+["'];?\s*$/gm) || [];
  for (const line of matched) {
    const inner = line.slice(line.indexOf("{") + 1, line.indexOf("}"));
    for (const part of inner.split(",")) {
      const name = part.trim().split(/\s+as\s+/).pop().trim();
      if (name !== "") names.push(name);
    }
  }
  return names;
}

test("束ね: 画面のファイルが import している名前は、すべて束の中にある", () => {
  const cases = [
    { bundle: readFileSync(join(root, "dist", "App.html"), "utf8"), files: CLIENT_SHARED.map((f) => "src/" + f).concat(CLIENT_UI.concat(["api-gas.js", "main.js"]).map((f) => "src/ui/" + f)) },
    {
      bundle: readFileSync(join(root, "demo", "app.js"), "utf8"),
      files: CLIENT_SHARED.concat(DEMO_EXTRA_SHARED).map((f) => "src/" + f).concat(CLIENT_UI.concat(["api-memory.js", "main.js"]).map((f) => "src/ui/" + f)),
    },
  ];
  for (const item of cases) {
    const declared = declaredNames_(item.bundle);
    for (const file of item.files) {
      for (const name of importedNames_(file)) {
        assert.ok(declared.has(name), file + " の " + name + " が束の中にありません");
      }
    }
  }
});

test("束ね: 同じ名前を 2 つのファイルで宣言していない（shared と ui をまたいでも）", () => {
  for (const path of ["dist/App.html", "demo/app.js"]) {
    const code = readFileSync(join(root, path), "utf8");
    const body = path.endsWith(".html") ? code.slice(code.indexOf("<script>") + 8, code.lastIndexOf("</script>")) : code;
    const found = body.match(/^(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm) || [];
    const names = found.map((line) => line.replace(/^(?:async\s+)?(?:function|class|const|let|var)\s+/, ""));
    const seen = new Set();
    const duplicated = [];
    for (const name of names) {
      if (seen.has(name)) duplicated.push(name);
      seen.add(name);
    }
    assert.deepEqual(duplicated, [], path);
  }
});
