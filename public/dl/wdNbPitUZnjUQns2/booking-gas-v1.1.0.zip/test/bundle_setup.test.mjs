/**
 * 1.1 の「初期化」と「設定を確かめる」を、Code.gs を偽の GAS の上で走らせて確かめる。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { runInContext } from "node:vm";
import { build } from "../scripts/build.mjs";
import { FIXED_TODAY, loadBundle, plain } from "./fakes.mjs";
import { sampleData } from "../src/samples.js";
import { SHEET_HEADERS } from "../src/check.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
build(root);

const SAMPLE = sampleData(FIXED_TODAY);

/** 見本の店を入れたスプレッドシートで Code.gs を走らせる（bundle.test.mjs の seeded と同じ）。extraSettings は「設定」に足す行 */
function seeded(options) {
  const opts = options || {};
  const settings = SAMPLE.settings.concat(opts.extraSettings || []);
  return loadBundle(
    Object.assign({ props: { lastId: "20260918-008" } }, opts, {
      sheets: Object.assign({ 設定: settings, 枠: SAMPLE.rules, 休み: SAMPLE.closed, サービス: SAMPLE.services, 予約: SAMPLE.reservations }, opts.sheets || {}),
    }),
  );
}

test("check.js の SHEET_HEADERS は、gas_sheets.js の SHEET_HEADERS_ と同じ", () => {
  const run = loadBundle({ sheets: {} });
  assert.deepEqual(plain(runInContext("SHEET_HEADERS_", run.context)), SHEET_HEADERS);
});

test("menu_init: 見本のブックで 2 回押しても「変更はありません」で、ご予約の行は変わらない", () => {
  const run = seeded();
  const before = run.sheets["予約"].rows.map((row) => row.slice());
  run.entry.menu_init();
  run.entry.menu_init();
  assert.ok(run.trace.alerts[0].startsWith("変更はありません。"), run.trace.alerts[0]);
  assert.ok(run.trace.alerts[1].startsWith("変更はありません。"));
  assert.deepEqual(run.sheets["予約"].rows, before);
});

test("menu_init: 1.0 のブックに足りない見出しを右端に、足りない設定の行を最終行の下に足す（2 回目は変更なし）", () => {
  const settings = SAMPLE.settings.filter((row) => row[0] !== "カレンダー ID" && row[0] !== "テーマ色").concat([["カレンダーID", "primary"]]);
  const reservations = SAMPLE.reservations.map((row) => row.slice(0, 14));
  const run = seeded({ sheets: { 設定: settings, 予約: reservations } });
  run.entry.menu_init();
  const text = run.trace.alerts[0];
  assert.ok(text.includes("・「予約」シートの見出しに足しました: キャンセル用"), text);
  assert.ok(text.includes("・「設定」シートに 1 行足しました: テーマ色（値は空のままです。空の項目は既定値で動きます）"), "「カレンダーID」は同じ項目とみなして足さない");
  assert.equal(run.sheets["予約"].rows[0][14], "キャンセル用");
  assert.deepEqual(run.sheets["予約"].rows.slice(1).map((row) => row.slice(0, 14)), reservations.slice(1), "ご予約の行は変えない");
  const last = run.sheets["設定"].rows[run.sheets["設定"].rows.length - 1];
  assert.deepEqual(last, ["テーマ色", ""]);

  run.entry.menu_init();
  assert.ok(run.trace.alerts[1].startsWith("変更はありません。"));
});

test("menu_init: 書き込みの権限が無いときは、敬体の 1 文で知らせる", () => {
  const run = loadBundle({ sheets: {}, denyWrite: true });
  run.entry.menu_init();
  assert.equal(
    run.trace.alerts[0],
    "うまくいきませんでした。次の内容をご確認ください。\n\nシートの作成で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください",
  );
});

test("menu_init: 保護されたレンジで止まったときも、権限の 1 文に言い換える", () => {
  const run = loadBundle({ sheets: {}, denyWrite: "protected" });
  run.entry.menu_init();
  assert.ok(run.trace.alerts[0].includes("このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), run.trace.alerts[0]);
});

test("menu_init: 途中(見出しの追記)で失敗しても、そこまでにできたことを知らせる", () => {
  const settings = SAMPLE.settings.filter((row) => row[0] !== "テーマ色");
  const reservations = SAMPLE.reservations.map((row) => row.slice(0, 14));
  const run = seeded({ sheets: { 設定: settings, 予約: reservations }, denyHeaderWrite: true });
  run.entry.menu_init();
  const text = run.trace.alerts[0];
  assert.ok(text.includes("「設定」に 1 行を足しました"), text);
  assert.ok(text.includes("そのあと 見出しの追記で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), text);
});

test("menu_init: ロックが取れなかったときは、ほかの処理中の 1 文で知らせる（doPost と同じロックを使う）", () => {
  const run = loadBundle({ sheets: {}, lockBusy: true });
  run.entry.menu_init();
  assert.equal(run.trace.alerts[0], "うまくいきませんでした。次の内容をご確認ください。\n\nただいま混み合っています。もう一度お試しください。");
});

test("menu_check: 枠とサービスの名前の食い違い・開けないカレンダー・タイムゾーンを booking: で並べる", () => {
  const rules = SAMPLE.rules.map((row, i) => (i === 1 ? row.slice(0, 6).concat(["初回カウンセリング"]) : row));
  const run = seeded({
    sheets: { 枠: rules },
    extraSettings: [["カレンダー ID", "shop@example.com"]],
    calendarMissing: true,
    timeZone: "America/New_York",
  });
  run.entry.menu_check();
  const text = run.trace.alerts[0];
  assert.ok(text.startsWith("直すところがあります。\n\n"), text);
  assert.ok(text.includes("\nbooking: 枠シートの 2 行目: サービス「初回カウンセリング」はサービスシートにありません。サービスシートの名前と同じ字にしてください。\n"));
  assert.ok(text.includes("\nbooking: 設定「カレンダー ID」のカレンダーを開けません。"));
  assert.ok(text.includes("\nbooking: スプレッドシートのタイムゾーンが America/New_York です。"));
  assert.equal(text.includes("・booking"), false);
});

test("menu_check: 問題が無いときは概要。トリガーと公開の様子は外の様子から読む", () => {
  const run = seeded({ triggers: ["remind_"] });
  run.entry.menu_check();
  const text = run.trace.alerts[0];
  assert.ok(text.startsWith("問題ありません。\n\n店名: ひだまり整体院\n"), text);
  assert.ok(text.includes("\n前日のリマインド: 毎日 18 時（トリガー: 作ってあります）\n予約ページ: 公開済み"));
  assert.equal(text.includes("ご参考:"), false);

  const unpublished = seeded({ appUrl: "" });
  unpublished.entry.menu_check();
  assert.ok(unpublished.trace.alerts[0].includes("ご参考:\n・前日のリマインドはまだ動いていません。"));
  assert.ok(unpublished.trace.alerts[0].includes("\n・予約ページはまだ公開されていません。「デプロイ」→"));
});

test("api_bootstrap: 1.1 の検査は予約ページの受付を止めない（枠とサービスが食い違っていても画面は出る）", () => {
  const rules = SAMPLE.rules.map((row, i) => (i === 1 ? row.slice(0, 6).concat(["初回カウンセリング"]) : row));
  const run = seeded({ sheets: { 枠: rules } });
  assert.deepEqual(run.entry.api_bootstrap().errors, []);
});
