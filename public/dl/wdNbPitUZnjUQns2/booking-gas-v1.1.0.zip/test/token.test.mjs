import { test } from "node:test";
import assert from "node:assert/strict";
import { TOKEN_RE, isToken, tokenFromUuid } from "../src/token.js";

test("TOKEN_RE は 24 桁の英数字（小文字）", () => {
  assert.equal(TOKEN_RE.test("0123456789abcdef01234567"), true);
  assert.equal(TOKEN_RE.test("0123456789ABCDEF01234567"), false);
  assert.equal(TOKEN_RE.test("0123456789abcdef0123456"), false);
  assert.equal(TOKEN_RE.test("0123456789abcdef012345678"), false);
});

test("tokenFromUuid: ハイフンを除き、小文字にして先頭 24 桁にする", () => {
  assert.equal(tokenFromUuid("1A2B3C4D-5E6F-7A8B-9C0D-1E2F3A4B5C6D"), "1a2b3c4d5e6f7a8b9c0d1e2f");
  assert.equal(tokenFromUuid("1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d"), "1a2b3c4d5e6f7a8b9c0d1e2f");
});

test("isToken: 合い言葉の形のときだけ true", () => {
  const token = tokenFromUuid("1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d");
  assert.equal(isToken(token), true);
  assert.equal(isToken(token.toUpperCase()), false);
  assert.equal(isToken(""), false);
  assert.equal(isToken("abc"), false);
  assert.equal(isToken(null), false);
  assert.equal(isToken(undefined), false);
  assert.equal(isToken(12345), false);
});
