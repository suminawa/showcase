import { test } from "node:test";
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

// 空きの計算などの純粋な処理は「いま」を自分で読んではいけない（now は呼び出し側が引数で渡す）。
// GAS の値も読み書きしない。触ってよいのは gas_*.js と、UI 側で今日を知る必要がある api-memory.js だけ。
const FORBIDDEN_GLOBALS = ["SpreadsheetApp", "CalendarApp", "MailApp", "UrlFetchApp", "PropertiesService", "LockService", "ScriptApp", "Session", "Utilities"];

function jsFilesIn_(dir) {
  return readdirSync(join(root, dir))
    .filter((name) => name.endsWith(".js"))
    .map((name) => dir + "/" + name);
}

/** src/ の gas_ で始まらないファイルと src/ui/*.js。api-memory.js は今日を知るために new Date() を使ってよいので除く */
function targetFiles_() {
  const top = jsFilesIn_("src").filter((path) => !path.split("/").pop().startsWith("gas_"));
  const ui = jsFilesIn_("src/ui").filter((path) => path !== "src/ui/api-memory.js");
  return top.concat(ui);
}

test("純粋な処理に new Date()（引数なし）と Date.now( が無い", () => {
  const files = targetFiles_();
  assert.ok(files.length > 0);
  for (const path of files) {
    const code = readFileSync(join(root, path), "utf8");
    assert.equal(/new\s+Date\s*\(\s*\)/.test(code), false, path + " に new Date() があります");
    assert.equal(code.includes("Date.now("), false, path + " に Date.now( があります");
  }
});

test("純粋な処理は GAS のグローバルに触らない", () => {
  const files = targetFiles_();
  for (const path of files) {
    const code = readFileSync(join(root, path), "utf8");
    for (const name of FORBIDDEN_GLOBALS) {
      assert.equal(code.includes(name), false, path + " に " + name + " があります");
    }
  }
});

test("初期化と設定を確かめるの純粋な部品（setup.js・check.js）も、この見張りの中にある", () => {
  const files = targetFiles_();
  for (const name of ["src/setup.js", "src/check.js"]) assert.ok(files.indexOf(name) >= 0, name);
});
