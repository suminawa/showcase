import { test } from "node:test";
import assert from "node:assert/strict";
import { addDays } from "../src/dates.js";
import { initialState, reduce } from "../src/ui/state.js";

const SHOP = {
  name: "ひだまり整体院",
  phone: "045-000-0000",
  address: "みなと市しおかぜ町 1-2-3",
  notice: "初めての方は、開始の 10 分前にお越しください。",
  themeColor: "#2f6f5e",
  phoneRequired: false,
  dateFormat: "yyyy-MM-dd",
  cancelHours: 24,
  leadHours: 24,
};

const SERVICES = [
  { name: "初回カウンセリング", minutes: 60, description: "初めての方はこちら" },
  { name: "通常の施術", minutes: 45, description: "" },
];

/** 今日（2026-09-18）から 30 日ぶんの日。最後は 2026-10-17 */
const STATUS = { "2026-09-18": "closed", "2026-09-20": "few", "2026-09-21": "full", "2026-09-22": "past" };
const DAYS = (function () {
  const out = [];
  let date = "2026-09-18";
  for (let i = 0; i < 30; i += 1) {
    out.push({ date: date, status: STATUS[date] || "open" });
    date = addDays(date, 1);
  }
  return out;
})();

const BOOT = { shop: SHOP, services: SERVICES, days: DAYS, today: "2026-09-18", errors: [] };

function boot_(extra) {
  return reduce(initialState(), { type: "bootstrap", data: Object.assign({}, BOOT, extra || {}) });
}

const SLOTS = [
  { start: "10:00", end: "11:00", remaining: 1 },
  { start: "11:00", end: "12:00", remaining: 0 },
];

/** カレンダー → 日 → 時間 → 入力 まで進めた state */
function atForm_() {
  let s = boot_();
  s = reduce(s, { type: "select-service", name: "初回カウンセリング" });
  s = reduce(s, { type: "select-date", date: "2026-10-03" });
  s = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  return reduce(s, { type: "select-slot", start: "10:00" });
}

test("はじめの状態は読み込み中で、値は空", () => {
  const s = initialState();
  assert.equal(s.step, "loading");
  assert.equal(s.boot, null);
  assert.equal(s.service, "");
  assert.equal(s.month, "");
  assert.equal(s.date, "");
  assert.equal(s.slots, null);
  assert.equal(s.slot, null);
  assert.deepEqual(s.values, { name: "", email: "", phone: "", note: "", website: "" });
  assert.deepEqual(s.errors, {});
  assert.equal(s.busy, false);
  assert.equal(s.error, "");
  assert.equal(s.done, null);
  assert.equal(s.cancel, null);
  assert.deepEqual(s.days, []);
});

test("bootstrap: サービスが 2 つ以上なら選ぶ画面、1 つなら飛ばして選んでおく、0 ならカレンダー", () => {
  const many = boot_();
  assert.equal(many.step, "service");
  assert.equal(many.service, "");
  assert.equal(many.month, "2026-09", "月は今日の月から始める");
  assert.equal(many.boot.shop.name, "ひだまり整体院");

  const one = boot_({ services: [SERVICES[0]] });
  assert.equal(one.step, "calendar");
  assert.equal(one.service, "初回カウンセリング");

  const none = boot_({ services: [] });
  assert.equal(none.step, "calendar");
  assert.equal(none.service, "");
});

test("bootstrap: 受付を止める知らせが届けば boot-error の画面", () => {
  const stopped = boot_({ errors: ["ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。"], days: [] });
  assert.equal(stopped.step, "boot-error");
  assert.deepEqual(stopped.boot.errors, ["ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。"]);
  assert.deepEqual(stopped.days, []);
});

test("サービスを選ぶとカレンダーへ進む", () => {
  const s = reduce(boot_(), { type: "select-service", name: "通常の施術" });
  assert.equal(s.service, "通常の施術");
  assert.equal(s.step, "calendar");
});

test("カレンダーの印は、選ばれたサービスのものに入れ替わる", () => {
  const first = DAYS.map((day) => ({ date: day.date, status: day.date === "2026-09-25" ? "open" : "closed" }));
  const regular = DAYS.map((day) => ({ date: day.date, status: day.date === "2026-09-25" ? "full" : "closed" }));
  const data = { daysByService: { 初回カウンセリング: first, 通常の施術: regular } };

  // サービスを選ぶ前は、サービス名の無い枠で数えたぶん（days）
  const many = boot_(data);
  assert.deepEqual(many.days, DAYS);

  const chosen = reduce(many, { type: "select-service", name: "通常の施術" });
  assert.deepEqual(chosen.days, regular);
  assert.deepEqual(reduce(chosen, { type: "select-service", name: "初回カウンセリング" }).days, first, "選び直せば入れ替わる");

  // サービスが 1 つだけの店は、読み込みのときからそのサービスで数える
  const one = boot_(Object.assign({ services: [SERVICES[0]] }, data));
  assert.equal(one.service, "初回カウンセリング");
  assert.deepEqual(one.days, first);

  // daysByService に無いサービスは、読み込みのときのぶんで数える（古い版の返事との行き違いを防ぐ）
  assert.deepEqual(reduce(boot_(), { type: "select-service", name: "通常の施術" }).days, DAYS);
});

test("月の前後は、今日の月と最後の日の月で止まる", () => {
  let s = boot_();
  assert.equal(s.month, "2026-09");
  s = reduce(s, { type: "month", delta: -1 });
  assert.equal(s.month, "2026-09", "今日の月より前には行かない");
  s = reduce(s, { type: "month", delta: 1 });
  assert.equal(s.month, "2026-10");
  s = reduce(s, { type: "month", delta: 1 });
  assert.equal(s.month, "2026-10", "受け付ける最後の日（2026-10-17）の月より先には行かない");
  s = reduce(s, { type: "month", delta: -1 });
  assert.equal(s.month, "2026-09");
});

test("年をまたぐ月送り", () => {
  const days = [{ date: "2026-12-20", status: "open" }, { date: "2027-01-05", status: "open" }];
  let s = boot_({ today: "2026-12-20", days: days });
  assert.equal(s.month, "2026-12");
  s = reduce(s, { type: "month", delta: 1 });
  assert.equal(s.month, "2027-01");
  s = reduce(s, { type: "month", delta: -1 });
  assert.equal(s.month, "2026-12");
});

test("日を選ぶと時間の画面。前の時間と枠は捨てる", () => {
  let s = atForm_();
  s = reduce(s, { type: "select-date", date: "2026-10-05" });
  assert.equal(s.step, "slots");
  assert.equal(s.date, "2026-10-05");
  assert.equal(s.slots, null);
  assert.equal(s.slot, null);
});

test("時間の一覧は、いま選んでいる日のものだけ入れる（古い返事は捨てる）", () => {
  let s = reduce(boot_(), { type: "select-date", date: "2026-10-03" });
  s = reduce(s, { type: "slots", date: "2026-10-04", slots: SLOTS });
  assert.equal(s.slots, null, "別の日の返事は入れない");
  s = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  assert.deepEqual(s.slots, SLOTS);
  assert.equal(s.busy, false);
});

test("時間を選ぶと入力画面。一覧に無い時間では動かない", () => {
  let s = reduce(boot_(), { type: "select-date", date: "2026-10-03" });
  s = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  const same = reduce(s, { type: "select-slot", start: "09:00" });
  assert.equal(same, s, "一覧に無い時間では state を変えない");
  const chosen = reduce(s, { type: "select-slot", start: "11:00" });
  assert.deepEqual(chosen.slot, { start: "11:00", end: "12:00", remaining: 0 });
  assert.equal(chosen.step, "form");
});

test("入力・誤り・確認へ", () => {
  let s = atForm_();
  s = reduce(s, { type: "input", field: "name", value: "山川 太郎" });
  s = reduce(s, { type: "input", field: "email", value: "taro@example.com" });
  assert.equal(s.values.name, "山川 太郎");
  assert.equal(s.values.email, "taro@example.com");
  assert.equal(s.values.phone, "", "ほかの欄はそのまま");
  s = reduce(s, { type: "errors", errors: { email: "メールアドレスの形式をご確認ください" } });
  assert.equal(s.errors.email, "メールアドレスの形式をご確認ください");
  assert.equal(s.step, "form");
  s = reduce(s, { type: "errors", errors: {} });
  s = reduce(s, { type: "confirm" });
  assert.equal(s.step, "confirm");
  assert.equal(s.values.name, "山川 太郎", "確認へ進んでも入力は残る");
});

test("戻るは 確認 → 入力 → 時間 → カレンダー → サービス の順。サービスが 1 つならカレンダーで止まる", () => {
  let s = reduce(atForm_(), { type: "confirm" });
  s = reduce(s, { type: "back" });
  assert.equal(s.step, "form");
  s = reduce(s, { type: "back" });
  assert.equal(s.step, "slots");
  s = reduce(s, { type: "back" });
  assert.equal(s.step, "calendar");
  s = reduce(s, { type: "back" });
  assert.equal(s.step, "service", "サービスが 2 つ以上なら選び直せる");

  let one = boot_({ services: [SERVICES[0]] });
  one = reduce(one, { type: "back" });
  assert.equal(one.step, "calendar", "サービスが 1 つならカレンダーで止まる");
});

test("busy・完了・誤りの帯", () => {
  let s = reduce(atForm_(), { type: "confirm" });
  s = reduce(s, { type: "busy", on: true });
  assert.equal(s.busy, true);
  const failed = reduce(s, { type: "error", message: "選ばれた時間は、ただいま満席になりました。別の時間をお選びください。" });
  assert.equal(failed.error, "選ばれた時間は、ただいま満席になりました。別の時間をお選びください。");
  assert.equal(failed.busy, false, "誤りが返ったら押せるように戻す");
  assert.equal(failed.step, "confirm");
  assert.equal(reduce(failed, { type: "dismiss-error" }).error, "");

  const result = { ok: true, id: "20260918-001", date: "2026-10-03", start: "10:00", end: "11:00", service: "初回カウンセリング", mailSent: true };
  const done = reduce(s, { type: "done", result: result });
  assert.equal(done.step, "done");
  assert.deepEqual(done.done, result);
  assert.equal(done.busy, false);
});

test("キャンセルの画面とキャンセル後", () => {
  const info = { found: true, reservation: { id: "20260918-001", date: "2026-10-03", start: "10:00", end: "11:00", service: "初回カウンセリング", name: "山川 太郎", status: "確定" }, canCancel: true, phone: "045-000-0000" };
  let s = reduce(boot_(), { type: "cancel-info", data: info });
  assert.equal(s.step, "cancel");
  assert.deepEqual(s.cancel, info);
  assert.equal(s.busy, false);
  s = reduce(s, { type: "cancelled", id: "20260918-001" });
  assert.equal(s.step, "cancelled");
  assert.equal(s.done.id, "20260918-001");
});

test("知らない action では同じ state を返し、元の state を書き換えない", () => {
  const s = atForm_();
  const copy = structuredClone(s);
  assert.equal(reduce(s, { type: "なにか" }), s);
  assert.equal(reduce(s, null), s);
  reduce(s, { type: "input", field: "name", value: "書き換え" });
  reduce(s, { type: "errors", errors: { name: "x" } });
  reduce(s, { type: "select-date", date: "2026-10-09" });
  reduce(s, { type: "month", delta: 1 });
  assert.deepEqual(s, copy, "reduce は渡された state を変えない");
});
