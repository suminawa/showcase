import { test } from "node:test";
import assert from "node:assert/strict";
import {
  WEEKDAY_WORDS,
  parseWeekdays,
  parseTime,
  parseRules,
  parseClosedDays,
  isClosed,
} from "../src/rules.js";

test("WEEKDAY_WORDS: 日〜土は 0〜6", () => {
  assert.deepEqual(WEEKDAY_WORDS, { 日: 0, 月: 1, 火: 2, 水: 3, 木: 4, 金: 5, 土: 6 });
});

test("parseWeekdays: 曜日の語の揺れ", () => {
  assert.deepEqual(parseWeekdays("火, 水, 金"), [2, 3, 5]);
  assert.deepEqual(parseWeekdays("平日"), [1, 2, 3, 4, 5]);
  assert.deepEqual(parseWeekdays("土日"), [0, 6]);
  assert.deepEqual(parseWeekdays("毎日"), [0, 1, 2, 3, 4, 5, 6]);
  assert.deepEqual(parseWeekdays("月曜"), [1]);
  assert.deepEqual(parseWeekdays("月・火"), [1, 2]);
  assert.deepEqual(parseWeekdays("月曜日"), [1]);
  assert.equal(parseWeekdays("英語"), null);
});

test("parseWeekdays: 読点・空白区切り、重複と順は整える。空文字は null", () => {
  assert.deepEqual(parseWeekdays("金、月、月"), [1, 5]);
  assert.deepEqual(parseWeekdays("土 木"), [4, 6]);
  assert.equal(parseWeekdays(""), null);
  assert.equal(parseWeekdays("  "), null);
});

test("parseTime: 書き方の揺れ", () => {
  assert.equal(parseTime("10:00"), "10:00");
  assert.equal(parseTime("9:30"), "09:30");
  assert.equal(parseTime("10時"), "10:00");
  assert.equal(parseTime("10時30分"), "10:30");
  assert.equal(parseTime("10:00:00"), "10:00");
  assert.equal(parseTime("１０：００"), "10:00");
});

test("parseTime: セルの Date は時刻だけ使う（Asia/Tokyo）", () => {
  // 2026-01-01T01:00:00Z は +9 時間で 2026-01-01 10:00（JST）
  assert.equal(parseTime(new Date("2026-01-01T01:00:00Z")), "10:00");
  // 分もそのまま読む
  assert.equal(parseTime(new Date("2026-01-01T00:15:00Z")), "09:15");
});

test("parseTime: 読めない値は null", () => {
  assert.equal(parseTime("25:00"), null);
  assert.equal(parseTime("正午"), null);
  assert.equal(parseTime(""), null);
  assert.equal(parseTime(null), null);
});

const RULE_HEADER = ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"];

test("parseRules: 見出しどおりの並びを読み、空は定員 1・サービス空にする", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["火, 水, 金", "", "10:00", "18:00", "30", "", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(rules, [
    { row: 2, weekdays: [2, 3, 5], date: null, start: "10:00", end: "18:00", interval: 30, capacity: 1, service: "" },
  ]);
});

test("parseRules: 列の並びが違っても見出し名で読み取る", () => {
  const shuffledHeader = ["サービス", "定員", "終了", "開始", "間隔", "日付", "曜日"];
  const { rules, errors } = parseRules([
    shuffledHeader,
    ["初回カウンセリング", "2", "12:00", "10:00", "20", "", "月"],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(rules, [
    { row: 2, weekdays: [1], date: null, start: "10:00", end: "12:00", interval: 20, capacity: 2, service: "初回カウンセリング" },
  ]);
});

test("parseRules: 日付があれば曜日より優先し、weekdays は空配列", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["月", "2026-10-03", "10:00", "11:00", "30", "1", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(rules[0].date, "2026-10-03");
  assert.deepEqual(rules[0].weekdays, []);
});

test("parseRules: 空行は飛ばし、行番号は 1 始まりのシート行", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["月", "", "10:00", "11:00", "30", "1", ""],
    ["", "", "", "", "", "", ""],
    ["火", "", "10:00", "11:00", "30", "1", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(rules.map((r) => r.row), [2, 4]);
});

test("parseRules: 誤り7種 曜日も日付も空", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["", "", "10:00", "11:00", "30", "1", ""],
  ]);
  assert.deepEqual(errors, ["booking: 枠シートの 2 行目: 曜日か日付のどちらかをご記入ください"]);
  assert.deepEqual(rules, []);
});

test("parseRules: 誤り 曜日が読めない", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["英語", "", "10:00", "11:00", "30", "1", ""],
  ]);
  assert.deepEqual(errors, ["booking: 枠シートの 2 行目: 曜日を読み取れません"]);
  assert.deepEqual(rules, []);
});

test("parseRules: 誤り 日付が読めない", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["", "2026-13-40", "10:00", "11:00", "30", "1", ""],
  ]);
  assert.deepEqual(errors, ["booking: 枠シートの 2 行目: 日付を読み取れません"]);
  assert.deepEqual(rules, []);
});

test("parseRules: 誤り 開始・終了が読めない", () => {
  const startBad = parseRules([RULE_HEADER, ["月", "", "変な時刻", "11:00", "30", "1", ""]]);
  assert.deepEqual(startBad.errors, ["booking: 枠シートの 2 行目: 開始を読み取れません"]);
  assert.deepEqual(startBad.rules, []);

  const endBad = parseRules([RULE_HEADER, ["月", "", "10:00", "変な時刻", "30", "1", ""]]);
  assert.deepEqual(endBad.errors, ["booking: 枠シートの 2 行目: 終了を読み取れません"]);
  assert.deepEqual(endBad.rules, []);
});

test("parseRules: 誤り 終了が開始以下", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["月", "", "10:00", "10:00", "30", "1", ""],
  ]);
  assert.deepEqual(errors, ["booking: 枠シートの 2 行目: 終了は開始より後にしてください"]);
  assert.deepEqual(rules, []);
});

test("parseRules: 誤り 間隔が範囲外・空", () => {
  const outOfRange = parseRules([RULE_HEADER, ["月", "", "10:00", "11:00", "3", "1", ""]]);
  assert.deepEqual(outOfRange.errors, ["booking: 枠シートの 2 行目: 間隔は 5〜480 の整数にしてください"]);

  const blank = parseRules([RULE_HEADER, ["月", "", "10:00", "11:00", "", "1", ""]]);
  assert.deepEqual(blank.errors, ["booking: 枠シートの 2 行目: 間隔は 5〜480 の整数にしてください"]);
});

test("parseRules: 間隔は 5 と 480 の境界を受け付ける", () => {
  const min = parseRules([RULE_HEADER, ["月", "", "10:00", "11:00", "5", "1", ""]]);
  assert.deepEqual(min.errors, []);
  assert.equal(min.rules[0].interval, 5);

  const max = parseRules([RULE_HEADER, ["月", "", "10:00", "11:00", "480", "1", ""]]);
  assert.deepEqual(max.errors, []);
  assert.equal(max.rules[0].interval, 480);
});

test("parseRules: 間隔は 4 と 481 を範囲外として拒否する", () => {
  const tooSmall = parseRules([RULE_HEADER, ["月", "", "10:00", "11:00", "4", "1", ""]]);
  assert.deepEqual(tooSmall.errors, ["booking: 枠シートの 2 行目: 間隔は 5〜480 の整数にしてください"]);
  assert.deepEqual(tooSmall.rules, []);

  const tooBig = parseRules([RULE_HEADER, ["月", "", "10:00", "11:00", "481", "1", ""]]);
  assert.deepEqual(tooBig.errors, ["booking: 枠シートの 2 行目: 間隔は 5〜480 の整数にしてください"]);
  assert.deepEqual(tooBig.rules, []);
});

test("parseRules: 誤り 定員が範囲外", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["月", "", "10:00", "11:00", "30", "100", ""],
  ]);
  assert.deepEqual(errors, ["booking: 枠シートの 2 行目: 定員は 0〜99 の整数にしてください"]);
  assert.deepEqual(rules, []);
});

test("parseRules: 定員 0 は誤りにならず、その値のまま保持する", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["月", "", "10:00", "11:00", "30", "0", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(rules[0].capacity, 0);
});

test("parseRules: 1 行に複数の誤りがあれば両方並ぶ", () => {
  const { rules, errors } = parseRules([
    RULE_HEADER,
    ["英語", "", "10:00", "11:00", "3", "1", ""],
  ]);
  assert.deepEqual(errors, [
    "booking: 枠シートの 2 行目: 曜日を読み取れません",
    "booking: 枠シートの 2 行目: 間隔は 5〜480 の整数にしてください",
  ]);
  assert.deepEqual(rules, []);
});

test("parseRules: 見出しのみ・空配列は誤りなく空", () => {
  assert.deepEqual(parseRules([]), { rules: [], errors: [] });
  assert.deepEqual(parseRules([RULE_HEADER]), { rules: [], errors: [] });
});

const CLOSED_HEADER = ["日付", "開始日", "終了日", "理由"];

test("parseClosedDays: 単日と期間", () => {
  const { closed, errors } = parseClosedDays([
    CLOSED_HEADER,
    ["2026-10-10", "", "", "祝日"],
    ["", "2026-12-29", "2027-01-03", "年末年始"],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(closed, [
    { from: "2026-10-10", to: "2026-10-10" },
    { from: "2026-12-29", to: "2027-01-03" },
  ]);
});

test("parseClosedDays: 誤り 日付・開始日・終了日が読めない、終了日が開始日より前", () => {
  const badDate = parseClosedDays([CLOSED_HEADER, ["2026-13-40", "", "", ""]]);
  assert.deepEqual(badDate.errors, ["booking: 休みシートの 2 行目: 日付を読み取れません"]);
  assert.deepEqual(badDate.closed, []);

  const badFrom = parseClosedDays([CLOSED_HEADER, ["", "変な日付", "2026-10-10", ""]]);
  assert.deepEqual(badFrom.errors, ["booking: 休みシートの 2 行目: 開始日を読み取れません"]);

  const badTo = parseClosedDays([CLOSED_HEADER, ["", "2026-10-01", "変な日付", ""]]);
  assert.deepEqual(badTo.errors, ["booking: 休みシートの 2 行目: 終了日を読み取れません"]);

  const reversed = parseClosedDays([CLOSED_HEADER, ["", "2026-10-10", "2026-10-01", ""]]);
  assert.deepEqual(reversed.errors, ["booking: 休みシートの 2 行目: 終了日は開始日より後にしてください"]);
  assert.deepEqual(reversed.closed, []);
});

test("parseClosedDays: 空行は飛ばす", () => {
  const { closed, errors } = parseClosedDays([
    CLOSED_HEADER,
    ["", "", "", ""],
    ["2026-10-10", "", "", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(closed, [{ from: "2026-10-10", to: "2026-10-10" }]);
});

test("isClosed: 期間の両端を含む。範囲外は false", () => {
  const closed = [
    { from: "2026-10-10", to: "2026-10-10" },
    { from: "2026-12-29", to: "2027-01-03" },
  ];
  assert.equal(isClosed(closed, "2026-10-10"), true);
  assert.equal(isClosed(closed, "2026-12-29"), true);
  assert.equal(isClosed(closed, "2027-01-03"), true);
  assert.equal(isClosed(closed, "2026-12-31"), true);
  assert.equal(isClosed(closed, "2026-10-11"), false);
  assert.equal(isClosed([], "2026-10-10"), false);
});
