import { test } from "node:test";
import assert from "node:assert/strict";
import { eventFor } from "../src/calendar.js";
import { DEFAULT_SETTINGS } from "../src/settings.js";

const SERVICES = [
  { name: "初回カウンセリング", minutes: 60, description: "", active: true },
  { name: "所要時間なしメニュー", minutes: null, description: "", active: true },
];

const RESERVATION = {
  ID: "20260918-001",
  状態: "確定",
  日付: "2026-09-19",
  開始: "10:00",
  終了: "10:30",
  サービス: "初回カウンセリング",
  お名前: "山川",
  メール: "taro@example.com",
  電話: "045-000-0000",
  ご要望: "特にありません",
};

test("eventFor: サービスの所要時間ぶん終了が伸びる（枠の終了より優先）", () => {
  const event = eventFor(DEFAULT_SETTINGS, SERVICES, RESERVATION);
  assert.equal(event.title, "予約: 山川 様（初回カウンセリング）");
  assert.equal(event.start, "2026-09-19 10:00");
  assert.equal(event.end, "2026-09-19 11:00");
});

test("eventFor: サービスに所要時間が無ければ枠の終了を使う", () => {
  const row = Object.assign({}, RESERVATION, { サービス: "所要時間なしメニュー" });
  const event = eventFor(DEFAULT_SETTINGS, SERVICES, row);
  assert.equal(event.title, "予約: 山川 様（所要時間なしメニュー）");
  assert.equal(event.end, "2026-09-19 10:30");
});

test("eventFor: サービスが見つからなければ枠の終了を使う", () => {
  const row = Object.assign({}, RESERVATION, { サービス: "存在しないメニュー" });
  const event = eventFor(DEFAULT_SETTINGS, SERVICES, row);
  assert.equal(event.end, "2026-09-19 10:30");
  assert.equal(event.title, "予約: 山川 様（存在しないメニュー）");
});

test("eventFor: サービスが空なら題名にサービスを付けず、枠の終了を使う", () => {
  const row = Object.assign({}, RESERVATION, { サービス: "" });
  const event = eventFor(DEFAULT_SETTINGS, SERVICES, row);
  assert.equal(event.title, "予約: 山川 様");
  assert.equal(event.end, "2026-09-19 10:30");
});

test("eventFor: description は受付番号・メール・電話・ご要望", () => {
  const event = eventFor(DEFAULT_SETTINGS, SERVICES, RESERVATION);
  assert.equal(
    event.description,
    "受付番号: 20260918-001\nメール: taro@example.com\n電話: 045-000-0000\nご要望: 特にありません"
  );
});

test("eventFor: 所要時間が日をまたげば end の日付側が繰り上がる", () => {
  const row = Object.assign({}, RESERVATION, { 日付: "2026-09-19", 開始: "23:45", 終了: "23:59" });
  const event = eventFor(DEFAULT_SETTINGS, SERVICES, row);
  assert.equal(event.start, "2026-09-19 23:45");
  assert.equal(event.end, "2026-09-20 00:45");
});
