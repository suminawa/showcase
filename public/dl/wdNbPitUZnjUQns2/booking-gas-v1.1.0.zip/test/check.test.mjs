import { test } from "node:test";
import assert from "node:assert/strict";
import { DEPLOY_STEPS, SHEET_HEADERS, checkNotes, findProblems, planInit, summaryLines } from "../src/check.js";
import { SETTING_KEYS, settingKeyOf } from "../src/settings.js";
import { sampleData } from "../src/samples.js";
import { initReport } from "../src/setup.js";

const TODAY = "2026-09-18";

/** 見本の店を入れたブック（メニュー「見本を入れる」のあと） */
function sampleBook() {
  const data = sampleData(TODAY);
  return {
    timeZone: "Asia/Tokyo",
    today: TODAY,
    hasTrigger: true,
    calendar: "none",
    appUrl: "https://script.google.com/macros/s/XXX/exec",
    sheets: { 設定: data.settings, 枠: data.rules, 休み: data.closed, サービス: data.services, 予約: data.reservations },
  };
}

function withSetting(key, value) {
  const base = sampleBook();
  base.sheets.設定 = base.sheets.設定.map((row) => (row[0] === key ? [key, value] : row));
  return base;
}

/** plan を 2 次元配列に当てる（足すだけ）。GAS 側の applyInit_ と同じ置き方 */
function applyPlan(snapshot, plan) {
  const sheets = {};
  for (const name of Object.keys(snapshot.sheets)) sheets[name] = snapshot.sheets[name].map((row) => row.slice());
  if (plan.appendSettings.rows.length > 0) {
    sheets[plan.appendSettings.sheet] = sheets[plan.appendSettings.sheet].concat(plan.appendSettings.rows.map((row) => row.slice()));
  }
  for (const made of plan.createSheets) sheets[made.name] = made.rows.map((row) => row.slice());
  for (const entry of plan.appendHeaders) {
    const rows = sheets[entry.sheet];
    const width = Math.max(...rows.map((row) => row.length));
    rows[0] = rows[0].concat(new Array(width - rows[0].length).fill("")).concat(entry.names);
  }
  return Object.assign({}, snapshot, { sheets: sheets });
}

function isEmptyPlan(plan) {
  return plan.createSheets.length === 0 && plan.appendHeaders.length === 0 && plan.appendSettings.rows.length === 0;
}

test("planInit: 空のブック → 5 枚を作り（設定は項目だけ・値は空）、2 回目は足すものが無い", () => {
  const empty = { timeZone: "Asia/Tokyo", today: TODAY, sheets: {} };
  const plan = planInit(empty);
  assert.deepEqual(plan.createSheets.map((sheet) => sheet.name), ["設定", "枠", "休み", "サービス", "予約"]);
  assert.deepEqual(plan.createSheets[0].rows, [["項目", "値"]].concat(SETTING_KEYS.map((key) => [key, ""])));
  assert.deepEqual(plan.createSheets[4].rows, [SHEET_HEADERS["予約"]]);
  assert.equal(
    plan.nextStep,
    "「設定」「枠」「休み」「サービス」をご記入のうえ、「設定を確かめる」を実行してください。まず動かしてみるなら、メニューの「見本を入れる」が早いです。\n次は " + DEPLOY_STEPS,
  );
  const again = planInit(applyPlan(empty, plan));
  assert.equal(isEmptyPlan(again), true);
  assert.equal(initReport(again, again.nextStep), "変更はありません。シート・見出し・設定の行はそろっています。\n\n次は " + DEPLOY_STEPS);
});

test("planInit: 見本のブック → 足すものが無い", () => {
  assert.equal(isEmptyPlan(planInit(sampleBook())), true);
});

test("planInit: 設定の行を 3 つと予約の見出しを 1 つ消したブック → その 4 つだけを足す（設定の値は空のまま）。2 回目は空", () => {
  const removed = ["カレンダー ID", "Slack Webhook URL", "日付の書式"];
  const base = sampleBook();
  base.sheets.設定 = base.sheets.設定.filter((row) => removed.indexOf(row[0]) < 0);
  base.sheets.予約 = base.sheets.予約.map((row) => row.slice(0, 14));
  const plan = planInit(base);
  assert.deepEqual(plan.createSheets, []);
  assert.deepEqual(plan.appendSettings, { sheet: "設定", rows: [["カレンダー ID", ""], ["Slack Webhook URL", ""], ["日付の書式", ""]], blank: true });
  assert.deepEqual(plan.appendHeaders, [{ sheet: "予約", names: ["キャンセル用"] }]);
  assert.ok(initReport(plan, "").includes("・「設定」シートに 3 行足しました: カレンダー ID、Slack Webhook URL、日付の書式（値は空のままです。空の項目は既定値で動きます）"));
  const applied = applyPlan(base, plan);
  assert.deepEqual(applied.sheets.予約.slice(1).map((row) => row.slice(0, 14)), base.sheets.予約.slice(1), "ご予約の行は変えない");
  assert.equal(isEmptyPlan(planInit(applied)), true);
});

test("planInit: 項目名の全角空白・空白の抜けは同じ行とみなして足さない（parseSettings と同じそろえ方）", () => {
  const base = sampleBook();
  base.sheets.設定 = base.sheets.設定.map((row) => {
    if (row[0] === "カレンダー ID") return ["カレンダーID", "primary"];
    if (row[0] === "Slack Webhook URL") return ["Slack　Webhook URL", ""];
    return row;
  });
  assert.deepEqual(planInit(base).appendSettings.rows, []);
  assert.equal(settingKeyOf("カレンダー　ID"), "カレンダー ID");
});

test("planInit: 空のシートには見出しを書き、設定シートには見出しを足さない。タイムゾーンは案内だけ", () => {
  const base = sampleBook();
  base.timeZone = "America/New_York";
  base.sheets.休み = [];
  base.sheets.設定 = [["店名", "ひだまり整体院"]].concat(SETTING_KEYS.slice(1).map((key) => [key, ""]));
  const plan = planInit(base);
  assert.deepEqual(plan.createSheets, [{ name: "休み", rows: [SHEET_HEADERS["休み"]], freeze: true, exists: true }]);
  assert.deepEqual(plan.appendHeaders, []);
  assert.deepEqual(plan.notes, ["スプレッドシートのタイムゾーンが America/New_York です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと予約の日時がずれます）。"]);
});

test("findProblems: 見本のブック → 0 件", () => {
  assert.deepEqual(findProblems(sampleBook()), []);
});

test("findProblems: 1.1 の検査の各行について、その文が 1 回だけ出る（すべて booking: で始まる）", () => {
  const noReservations = sampleBook();
  delete noReservations.sheets.予約;
  const noToken = sampleBook();
  noToken.sheets.予約 = noToken.sheets.予約.map((row) => row.slice(0, 14));
  const noRules = sampleBook();
  noRules.sheets.枠 = [SHEET_HEADERS["枠"], ["", "", "", "", "", "", ""]];
  const wrongService = sampleBook();
  wrongService.sheets.枠 = wrongService.sheets.枠.map((row, i) => (i === 2 ? row.slice(0, 6).concat(["通常の施術（45 分）"]) : row));
  const allOff = sampleBook();
  allOff.sheets.サービス = allOff.sheets.サービス.map((row, i) => (i === 0 ? row : row.slice(0, 3).concat(["FALSE"])));
  const lineHalf = withSetting("LINE 送信先 ID", "U0123");
  const cases = [
    [Object.assign(sampleBook(), { timeZone: "America/New_York" }), "booking: スプレッドシートのタイムゾーンが America/New_York です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと予約の日時がずれます）。"],
    [noReservations, "booking: 「予約」シートがありません。メニュー「初期化」を実行してください。"],
    [noToken, "booking: 予約シートの 1 行目に「キャンセル用」がありません。「初期化」を実行すると右端に足します（無いままだと、確認メールのキャンセル URL がどのご予約にも当たりません）。"],
    [noRules, "booking: 枠シートに受け付ける時間が 1 行もありません。予約ページに空きが出ません。README の 3 章のとおりに書くか、メニュー「見本を入れる」で見本を入れてください。"],
    [wrongService, "booking: 枠シートの 3 行目: サービス「通常の施術（45 分）」はサービスシートにありません。サービスシートの名前と同じ字にしてください。"],
    [allOff, "booking: サービスシートの受付がすべて FALSE です。お客さまが選べるサービスがありません。"],
    [withSetting("Slack Webhook URL", "hooks.slack.com/services/T/B/x"), "booking: 設定「Slack Webhook URL」は https:// で始まる URL です。設定シートのその行を確かめてください。"],
    [lineHalf, "booking: 設定「LINE 送信先 ID」が書いてありますが、「LINE チャネルアクセストークン」が空です。"],
    [Object.assign(withSetting("カレンダー ID", "shop@example.com"), { calendar: "missing" }), "booking: 設定「カレンダー ID」のカレンダーを開けません。ID の写し間違いか、このアカウントに共有されていない可能性があります。主カレンダーなら primary と書いてください。"],
  ];
  for (const [snapshot, message] of cases) {
    const found = findProblems(snapshot);
    assert.equal(found.filter((line) => line === message).length, 1, message + "\n" + found.join("\n"));
    assert.equal(found.every((line) => line.startsWith("booking: ")), true);
  }
});

test("findProblems: 1.0 の誤りを先に、1.1 の検査を後ろに並べる。URL とトークンは文に出さない", () => {
  const base = withSetting("何日先まで", "0");
  base.sheets.設定 = base.sheets.設定.map((row) => (row[0] === "Discord Webhook URL" ? [row[0], "http://secret.example/hook"] : row));
  delete base.sheets.予約;
  const found = findProblems(base);
  assert.deepEqual(found, [
    "booking: 設定「何日先まで」は 1〜180 にしてください",
    "booking: 「予約」シートがありません。メニュー「初期化」を実行してください。",
    "booking: 設定「Discord Webhook URL」は https:// で始まる URL です。設定シートのその行を確かめてください。",
  ]);
  assert.equal(found.join("\n").includes("secret"), false);
});

test("checkNotes: 設定の行が無い項目・リマインドのトリガーが無い・未公開", () => {
  const base = sampleBook();
  base.sheets.設定 = base.sheets.設定.filter((row) => row[0] !== "テーマ色");
  base.hasTrigger = false;
  base.appUrl = "";
  assert.deepEqual(checkNotes(base), [
    "「設定」シートに「テーマ色」の行がありません。空の項目と同じく、既定値で動きます。「初期化」を実行すると、空の行を足します。",
    "前日のリマインドはまだ動いていません。メニュー「リマインドのトリガーを作る」を実行してください。",
    "予約ページはまだ公開されていません。" + DEPLOY_STEPS,
  ]);
  assert.deepEqual(checkNotes(sampleBook()), []);
});

test("summaryLines: 見本「ひだまり整体院」の概要", () => {
  assert.deepEqual(summaryLines(sampleBook()), [
    "店名: ひだまり整体院",
    "受け付ける時間: 火・水・金 10:00〜13:00（60 分ごと・定員 1・初回カウンセリング（60 分））",
    "　　　　　　　　火・水・金 14:00〜18:30（45 分ごと・定員 1・通常の施術）",
    "　　　　　　　　土 10:00〜16:45（45 分ごと・定員 2）",
    "　　　　　　　　2026-09-21 10:00〜12:00（60 分ごと・定員 1）",
    "受付の期間: 30 日先まで、開始の 24 時間前まで。キャンセルは 24 時間前まで",
    "休み: 2 件（次は 2026-09-23）",
    "サービス: 受付中 2 つ（初回カウンセリング（60 分）、通常の施術）",
    "お知らせメール: 所有者のアドレスに送ります（設定「連絡先メール」が空のため）",
    "カレンダー: 登録しません（設定「カレンダー ID」が空です）",
    "通知: 使っていません",
    "前日のリマインド: 毎日 18 時（トリガー: 作ってあります）",
    "予約ページ: 公開済み",
  ]);
  // 枠の行は 5 行まで。越えたら「ほか N 行」
  const many = sampleBook();
  many.sheets.枠 = many.sheets.枠.concat([["月", "", "10:00", "11:00", "60", "1", ""], ["日", "", "10:00", "11:00", "60", "1", ""], ["毎日", "", "20:00", "21:00", "60", "1", ""]]);
  const lines = summaryLines(many);
  assert.equal(lines[6], "　　　　　　　　ほか 2 行");
  assert.equal(lines[7].startsWith("受付の期間: "), true);
});
