import { test } from "node:test";
import assert from "node:assert/strict";
import {
  toDateKey,
  toDateTimeKey,
  formatStamp,
  compactDate,
  toHalfWidth,
  dateFromKey,
  dateTimeFromKey,
  minutesOf,
  timeOf,
  addMinutes,
  weekdayOf,
  weekdayKanjiOf,
  shortDateOf,
  longDateOf,
  addDays,
} from "../src/dates.js";

test("toDateKey: Date は +9 時間、文字は - / 年月日 を読む。2/30 は null", () => {
  assert.equal(toDateKey(new Date("2026-09-15T15:30:00Z")), "2026-09-16");
  assert.equal(toDateKey("2026/9/6"), "2026-09-06");
  assert.equal(toDateKey("２０２６－０９－０６"), "2026-09-06");
  assert.equal(toDateKey("2026年9月6日"), "2026-09-06");
  assert.equal(toDateKey("2026-02-30"), null);
  assert.equal(toDateKey(""), null);
  assert.equal(toDateKey("きょう"), null);
});

test("toDateTimeKey: Date と 3 つの書き方を読み、秒は落とす", () => {
  assert.equal(toDateTimeKey(new Date("2026-09-16T01:05:09Z")), "2026-09-16 10:05");
  assert.equal(toDateTimeKey("2026-09-16 10:30"), "2026-09-16 10:30");
  assert.equal(toDateTimeKey("2026/9/16T9:05"), "2026-09-16 09:05");
  assert.equal(toDateTimeKey("2026-09-16 10:30:45"), "2026-09-16 10:30");
  assert.equal(toDateTimeKey("2026-09-16 25:00"), null);
  assert.equal(toDateTimeKey("2026-09-16"), null);
});

test("formatStamp・compactDate・toHalfWidth・dateFromKey・dateTimeFromKey", () => {
  assert.equal(formatStamp(new Date("2026-09-16T01:05:09Z")), "2026-09-16 10:05:09");
  assert.throws(() => formatStamp("x"), /日時を読めません/);
  assert.equal(compactDate("2026-09-16"), "20260916");
  assert.equal(toHalfWidth("ＡＢＣ１２３＠　x"), "ABC123@ x");
  assert.equal(dateFromKey("2026-09-16").toISOString(), "2026-09-15T15:00:00.000Z");
  assert.equal(dateFromKey("x"), null);
  assert.equal(dateTimeFromKey("2026-09-16 10:30").toISOString(), "2026-09-16T01:30:00.000Z");
  assert.equal(dateTimeFromKey("x"), null);
});

test("minutesOf・timeOf: HH:mm と真夜中からの分の変換", () => {
  assert.equal(minutesOf("09:05"), 545);
  assert.equal(timeOf(545), "09:05");
});

test("addMinutes: 日をまたぐ加算・減算", () => {
  assert.deepEqual(addMinutes("2026-09-30", "23:30", 45), { date: "2026-10-01", time: "00:15" });
  assert.deepEqual(addMinutes("2026-03-01", "00:10", -20), { date: "2026-02-28", time: "23:50" });
});

test("weekdayOf: 0（日）〜6（土）", () => {
  assert.equal(weekdayOf("2026-09-18"), 5);
  assert.equal(weekdayOf("2026-09-20"), 0);
});

test("weekdayKanjiOf: 曜日を漢字 1 字にする（weekdayOf を土台にする）", () => {
  assert.equal(weekdayKanjiOf("2026-09-19"), "土");
  assert.equal(weekdayKanjiOf("2026-09-20"), "日");
});

test("shortDateOf: 0 埋めなしの短い日付「M/D（曜）」、空文字は空文字のまま", () => {
  assert.equal(shortDateOf("2026-09-19"), "9/19（土）");
  // 2026-12-01 の実際の曜日を weekdayOf で確かめてから期待値にする（火＝index 2）
  assert.equal(weekdayOf("2026-12-01"), 2);
  assert.equal(shortDateOf("2026-12-01"), "12/1（火）");
  assert.equal(shortDateOf(""), "");
});

test("addDays: うるう年をまたぐ", () => {
  assert.equal(addDays("2026-02-28", 1), "2026-03-01");
  assert.equal(addDays("2028-02-28", 1), "2028-02-29");
});

test("longDateOf: 設定の書式で、曜日つきの長い日付にする（画面もメールも同じ 1 つを使う）", () => {
  assert.equal(longDateOf("2026-10-03"), "2026-10-03（土）");
  assert.equal(longDateOf("2026-10-03", "yyyy-MM-dd"), "2026-10-03（土）");
  assert.equal(longDateOf("2026-10-03", "yyyy/MM/dd"), "2026/10/03（土）");
  assert.equal(longDateOf("2026-09-19", "yyyy/MM/dd"), "2026/09/19（土）");
  assert.equal(longDateOf(""), "");
  assert.equal(longDateOf(null), "");
  assert.equal(longDateOf(undefined), "");
  assert.equal(longDateOf(" 2026-10-03 "), "2026-10-03（土）", "前後の空白は落とす");
  assert.equal(longDateOf("あした", "yyyy/MM/dd"), "あした", "日付の形でなければそのまま返す");
});
