import { test } from "node:test";
import assert from "node:assert/strict";
import { textOf, boolOf, pad2, escapeHtml, politeError } from "../src/text.js";

test("textOf: 前後の空白を落とした文字。null / undefined は空", () => {
  assert.equal(textOf(" a "), "a");
  assert.equal(textOf(null), "");
  assert.equal(textOf(undefined), "");
  assert.equal(textOf(0), "0");
  assert.equal(textOf(true), "true");
});

test("textOf: 配列やオブジェクトは空（検査をすり抜けさせない）。日付のセルは文字にする", () => {
  // 画面から送られた値が "[object Object]" や "a,b" として検査を通らないこと
  assert.equal(textOf({}), "");
  assert.equal(textOf({ name: "山川" }), "");
  assert.equal(textOf(["a", "b"]), "");
  assert.equal(textOf(() => "x"), "");
  // toString が壊れている値でも落ちない
  assert.equal(textOf({ toString: 1 }), "");
  assert.equal(textOf(Object.create(null)), "");
  // 日付のセルは Date で来るので、これまでどおり文字にする
  assert.ok(textOf(new Date(Date.UTC(2026, 8, 18))).length > 0);
});

test("politeError: お客さまに見せてよい誤りには expected の印が付く", () => {
  const error = politeError("日付をお選びください");
  assert.ok(error instanceof Error);
  assert.equal(error.message, "日付をお選びください");
  assert.equal(error.expected, true);
  assert.equal(new Error("ふつうの誤り").expected, undefined);
});

test("boolOf: TRUE / FALSE / はい / いいえ / 1 / 0 / ○ / ×。空や読めない字は fallback", () => {
  assert.equal(boolOf(true, false), true);
  assert.equal(boolOf("true", false), true);
  assert.equal(boolOf(" はい ", false), true);
  assert.equal(boolOf("○", false), true);
  assert.equal(boolOf("1", false), true);
  assert.equal(boolOf("FALSE", true), false);
  assert.equal(boolOf("いいえ", true), false);
  assert.equal(boolOf("×", true), false);
  assert.equal(boolOf("0", true), false);
  assert.equal(boolOf("", true), true);
  assert.equal(boolOf("たぶん", false), false);
});

test("pad2", () => {
  assert.equal(pad2(3), "03");
  assert.equal(pad2(12), "12");
});

test("escapeHtml: & < > \" ' を実体参照にする。null / undefined は空", () => {
  assert.equal(escapeHtml("<b>a & b</b>"), "&lt;b&gt;a &amp; b&lt;/b&gt;");
  assert.equal(escapeHtml(`it's "ok"`), "it&#39;s &quot;ok&quot;");
  assert.equal(escapeHtml(null), "");
  assert.equal(escapeHtml(undefined), "");
});
