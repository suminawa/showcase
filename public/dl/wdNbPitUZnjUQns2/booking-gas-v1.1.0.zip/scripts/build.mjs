#!/usr/bin/env node
// src/*.js を 1 本の dist/Code.gs に、src/ui/* を dist/App.html（GAS 用）と demo/app.js・demo/app.css（見本用）にまとめる。
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/** サーバー側（Code.gs）。先頭は入口の gas_main.js。純粋な処理 → GAS に触る部分の順 */
export const SERVER_ORDER = [
  "gas_main.js",
  "text.js",
  "dates.js",
  "settings.js",
  "rules.js",
  "services.js",
  "availability.js",
  "validate.js",
  "receipt.js",
  "token.js",
  "mail.js",
  "message.js",
  "calendar.js",
  "samples.js",
  "setup.js",
  "check.js",
  "gas_store.js",
  "gas_sheets.js",
  "gas_calendar.js",
  "gas_mail.js",
  "gas_notify.js",
  "gas_web.js",
];

/** 画面側でも使う純粋な処理（検証は画面でも同じものを動かす。validate.js が services.js の findService を呼ぶ） */
export const CLIENT_SHARED = ["text.js", "dates.js", "services.js", "validate.js"];
/** 画面の部品。api ファイル（api-gas.js か api-memory.js）→ main.js の順に続く */
export const CLIENT_UI = ["render.js", "state.js"];
/** 見本ページ（demo/app.js）だけに足す純粋な処理。api-memory.js がサーバーと同じ規則で動くために要る */
export const DEMO_EXTRA_SHARED = ["settings.js", "rules.js", "availability.js", "receipt.js", "token.js", "mail.js", "samples.js"];

export const MANIFEST = {
  timeZone: "Asia/Tokyo",
  dependencies: {},
  exceptionLogging: "STACKDRIVER",
  runtimeVersion: "V8",
  // ANYONE_ANONYMOUS = リンクを知っていれば誰でも（ログイン不要）。USER_DEPLOYING = 公開した人の権限で動く
  webapp: { access: "ANYONE_ANONYMOUS", executeAs: "USER_DEPLOYING" },
  // spreadsheets = シートの読み書き、calendar = 予定の登録、script.send_mail = メール送信、script.external_request = 通知の送信、script.container.ui = メニュー、script.scriptapp = トリガー
  oauthScopes: [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/script.send_mail",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/script.container.ui",
    "https://www.googleapis.com/auth/script.scriptapp",
  ],
};

/**
 * Apps Script も素の <script> も import / export を解さない。
 * 1 ファイルに並べれば同じ名前空間になるので、import 行は落とし、行頭の export だけを剥がす。
 */
export function toGasSource(source) {
  const lines = String(source).split("\n");
  const kept = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (/^import\s[^;]*from\s+["'][^"']+["'];?\s*$/.test(line)) continue;
    kept.push(line.replace(/^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\s)/, ""));
  }
  return kept.join("\n").trim();
}

/** 同じ名前の関数・定数が 2 つのファイルにあると、束ねたときに後勝ちで壊れる。先に見つける */
function checkDuplicates_(parts) {
  const seen = {};
  for (let i = 0; i < parts.length; i += 1) {
    const names = parts[i].code.match(/^(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm) || [];
    for (let j = 0; j < names.length; j += 1) {
      const name = names[j].replace(/^(?:async\s+)?(?:function|class|const|let|var)\s+/, "");
      if (seen[name] !== undefined && seen[name] !== parts[i].file) {
        throw new Error("同じ名前「" + name + "」が " + seen[name] + " と " + parts[i].file + " にあります");
      }
      seen[name] = parts[i].file;
    }
  }
}

function concat_(root, dir, files) {
  const parts = [];
  for (let i = 0; i < files.length; i += 1) {
    const code = toGasSource(readFileSync(join(root, dir, files[i]), "utf8"));
    parts.push({ file: files[i], code: "// ===== " + files[i] + " =====\n" + code });
  }
  checkDuplicates_(parts);
  const joined = parts.map((p) => p.code).join("\n\n");
  const leftover = joined.match(/^\s*(import|export)\s/m);
  if (leftover) throw new Error("import / export が残っている: " + leftover[0].trim());
  return joined;
}

export function buildServer(root) {
  return concat_(root === undefined ? ROOT : root, "src", SERVER_ORDER);
}

/** 画面の JS。shared → ui → api → main の順。extraShared は見本ページだけに足す純粋な処理 */
export function buildClient(root, apiFile, extraShared) {
  const base = root === undefined ? ROOT : root;
  const shared = concat_(base, "src", CLIENT_SHARED.concat(extraShared || []));
  const ui = concat_(base, join("src", "ui"), CLIENT_UI.concat([apiFile, "main.js"]));
  return shared + "\n\n" + ui;
}

function fill_(template, marker, content) {
  return template.split(marker).join(content);
}

export function buildAppHtml(root) {
  const base = root === undefined ? ROOT : root;
  const html = readFileSync(join(base, "src", "ui", "index.html"), "utf8");
  const css = readFileSync(join(base, "src", "ui", "style.css"), "utf8");
  const js = buildClient(base, "api-gas.js") + "\n\nmountBooking(document.getElementById(\"app\"), gasApi());\n";
  if (js.indexOf("</script") >= 0) throw new Error("画面の JS に </script が含まれています");
  return fill_(fill_(html, "/*__STYLE__*/", css), "/*__SCRIPT__*/", js);
}

export function buildDemoScript(root) {
  const base = root === undefined ? ROOT : root;
  return buildClient(base, "api-memory.js", DEMO_EXTRA_SHARED) + "\n\nwindow.Booking = { mount: function (root) { return mountBooking(root, memoryApi()); } };\n";
}

export function build(root) {
  const base = root === undefined ? ROOT : root;
  mkdirSync(join(base, "dist"), { recursive: true });
  mkdirSync(join(base, "demo"), { recursive: true });
  const header = "// 予約ページ キット — scripts/build.mjs が src/ から作る。ここを直接編集しない\n\n";
  writeFileSync(join(base, "dist", "Code.gs"), header + buildServer(base) + "\n");
  writeFileSync(join(base, "dist", "App.html"), buildAppHtml(base));
  writeFileSync(join(base, "dist", "appsscript.json"), JSON.stringify(MANIFEST, null, 2) + "\n");
  writeFileSync(join(base, "demo", "app.js"), "// scripts/build.mjs が src/ から作る。ここを直接編集しない\n" + buildDemoScript(base));
  writeFileSync(join(base, "demo", "app.css"), readFileSync(join(base, "src", "ui", "style.css"), "utf8"));
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  build();
  console.log("wrote dist/Code.gs, dist/App.html, dist/appsscript.json, demo/app.js, demo/app.css");
}
