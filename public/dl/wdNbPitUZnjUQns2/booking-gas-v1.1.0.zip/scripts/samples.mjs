#!/usr/bin/env node
// samples/*.csv を src/samples.js の sampleData から作る（npm run samples）。
// UTF-8 BOM 付き・CRLF（Excel でそのまま開ける。姉妹キットの CSV と同じ形）。
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { sampleData } from "../src/samples.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** CSV の 1 セル。カンマ・引用符・改行を含むときだけ引用符で囲む */
export function csvCell(value) {
  const text = value === null || value === undefined ? "" : String(value);
  if (/[",\r\n]/.test(text)) return '"' + text.replace(/"/g, '""') + '"';
  return text;
}

/** 見出し行つきの 2 次元配列 → CSV の文字（UTF-8 BOM 付き、CRLF、末尾も改行） */
export function toCsv(rows) {
  return "﻿" + rows.map((row) => row.map(csvCell).join(",")).join("\r\n") + "\r\n";
}

/** samples/ に書く 5 つの CSV。ファイル名 → 中身の文字。test/samples.test.mjs もこれで一致を確かめる */
export function sampleCsvFiles(today) {
  const data = sampleData(today);
  return {
    "設定.csv": toCsv(data.settings),
    "枠.csv": toCsv(data.rules),
    "休み.csv": toCsv(data.closed),
    "サービス.csv": toCsv(data.services),
    "予約.csv": toCsv(data.reservations),
  };
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  const files = sampleCsvFiles("2026-09-18");
  mkdirSync(join(root, "samples"), { recursive: true });
  for (const name of Object.keys(files)) writeFileSync(join(root, "samples", name), files[name]);
  console.log("wrote samples/設定.csv 枠.csv 休み.csv サービス.csv 予約.csv");
}
