/**
 * スクリプト プロパティに置く覚え書き（受付番号の続き）と、二重予約を防ぐ排他。
 * 「いま」を読むのもここ（純粋な処理は now を引数で受け取る）。
 */
import { formatStamp } from "./dates.js";
import { politeError } from "./text.js";

/** 同時に来た予約を待たせる時間（設計書 §7） */
const LOCK_WAIT_MS = 10000;
/** 受付番号の続きを覚えておくキー */
const LAST_ID_KEY = "lastId";

function props_() {
  return PropertiesService.getScriptProperties();
}

/**
 * 「いま」を "yyyy-MM-dd HH:mm:ss"（Asia/Tokyo）で返す。
 * 分までの "yyyy-MM-dd HH:mm" は slice(0, 16)、日付キーは slice(0, 10) で作る
 */
export function nowStamp_() {
  return formatStamp(new Date());
}

/** 所有者（このスクリプトを公開した人）のメールアドレス。取れなければ空 */
export function ownerEmail_() {
  try {
    return String(Session.getEffectiveUser().getEmail() || "").trim();
  } catch (error) {
    return "";
  }
}

/** 前回の受付番号（"20260918-003" の形）。無ければ空 */
export function readLastId_() {
  const raw = props_().getProperty(LAST_ID_KEY);
  return raw ? String(raw) : "";
}

export function saveLastId_(id) {
  props_().setProperty(LAST_ID_KEY, String(id));
}

/**
 * action を 1 つずつ順番に実行する（枠の数え直しと行の追加が重ならないように）。
 * 待っても取れなければ敬体の誤りを投げる。取れたら必ず解く
 */
export function withLock_(action) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(LOCK_WAIT_MS);
  } catch (error) {
    throw politeError("ただいま混み合っています。もう一度お試しください。");
  }
  try {
    return action();
  } finally {
    lock.releaseLock();
  }
}
