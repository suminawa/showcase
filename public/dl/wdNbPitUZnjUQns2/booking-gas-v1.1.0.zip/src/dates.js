/**
 * 日付と時刻の扱い。GAS のグローバルには触らないので、Node でそのままテストできる。
 * 日付キーは "YYYY-MM-DD"、日時キーは "YYYY-MM-DD HH:mm"（Asia/Tokyo）で統一する。
 */

import { pad2, textOf } from "./text.js";

/** Asia/Tokyo は夏時間が無いので、UTC からの +9 時間は年中変わらない */
const JST_OFFSET_MINUTES = 540;

/** Date かどうか。別の realm（node:vm やテストの偽の GAS）から来た Date も見分けられるよう、instanceof は使わない */
function isDate_(value) {
  return Object.prototype.toString.call(value) === "[object Date]";
}

function shifted_(value) {
  if (!isDate_(value) || Number.isNaN(value.getTime())) return null;
  return new Date(value.getTime() + JST_OFFSET_MINUTES * 60000);
}

/** 全角の英数記号と全角空白を半角にする（入力欄と検索で同一視するため） */
export function toHalfWidth(text) {
  return String(text === null || text === undefined ? "" : text)
    .replace(/[！-～]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/　/g, " ");
}

/** 全角数字を半角にしてから整数として読む。整数でないか範囲外なら null */
export function integerInRange(raw, min, max) {
  const n = Number(toHalfWidth(textOf(raw)));
  if (!Number.isInteger(n) || n < min || n > max) return null;
  return n;
}

/** Date を Asia/Tokyo の時刻 "HH:mm" にする（時刻だけのセルもこれで読む）。Date でない・不正な日付は null */
export function jstTimeOf(date) {
  const at = shifted_(date);
  if (at === null) return null;
  return pad2(at.getUTCHours()) + ":" + pad2(at.getUTCMinutes());
}

function ymd_(year, month, day) {
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  // Date.UTC(2026, 1, 30) は 3/2 に繰り上がるだけで NaN にならないので、年月日で照合する
  const probe = new Date(Date.UTC(year, month - 1, day));
  if (probe.getUTCMonth() + 1 !== month || probe.getUTCDate() !== day) return null;
  return year + "-" + pad2(month) + "-" + pad2(day);
}

/**
 * セルの値（Date・文字列・空）を "YYYY-MM-DD" にする。読めなければ null。
 * 日付セルは Date で来るので、+9 時間ずらしてから年月日を取り出す。
 */
export function toDateKey(value) {
  if (value === null || value === undefined || value === "") return null;
  if (isDate_(value)) {
    const at = shifted_(value);
    if (at === null) return null;
    return at.getUTCFullYear() + "-" + pad2(at.getUTCMonth() + 1) + "-" + pad2(at.getUTCDate());
  }
  const matched = toHalfWidth(value).trim().match(/^(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})日?$/);
  if (!matched) return null;
  return ymd_(Number(matched[1]), Number(matched[2]), Number(matched[3]));
}

/** "YYYY-MM-DD HH:mm"。Date、"2026-09-16 10:30"、"2026/09/16T10:30"、"2026-09-16 10:30:00" を読む。読めなければ null */
export function toDateTimeKey(value) {
  if (value === null || value === undefined || value === "") return null;
  if (isDate_(value)) {
    const at = shifted_(value);
    if (at === null) return null;
    return at.getUTCFullYear() + "-" + pad2(at.getUTCMonth() + 1) + "-" + pad2(at.getUTCDate()) + " " + pad2(at.getUTCHours()) + ":" + pad2(at.getUTCMinutes());
  }
  const matched = toHalfWidth(value).trim().match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T](\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (!matched) return null;
  const date = ymd_(Number(matched[1]), Number(matched[2]), Number(matched[3]));
  const hour = Number(matched[4]);
  const minute = Number(matched[5]);
  if (date === null || hour > 23 || minute > 59) return null;
  return date + " " + pad2(hour) + ":" + pad2(minute);
}

/** 作成日時・更新日時に書く "2026-09-16 10:32:05"（Asia/Tokyo） */
export function formatStamp(value) {
  const at = shifted_(value);
  if (at === null) throw new Error("日時を読めません: " + String(value));
  return (
    at.getUTCFullYear() + "-" + pad2(at.getUTCMonth() + 1) + "-" + pad2(at.getUTCDate()) +
    " " + pad2(at.getUTCHours()) + ":" + pad2(at.getUTCMinutes()) + ":" + pad2(at.getUTCSeconds())
  );
}

/** "2026-09-16" → "20260916"。ID の前半に使う */
export function compactDate(dateKey) {
  return String(dateKey).replace(/-/g, "");
}

/** "YYYY-MM-DD" を、その日の 0 時（Asia/Tokyo）の Date にする（シートの日付セルに書く形）。読めなければ null */
export function dateFromKey(dateKey) {
  const key = toDateKey(dateKey);
  if (key === null) return null;
  const parts = key.split("-");
  return new Date(Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])) - JST_OFFSET_MINUTES * 60000);
}

/** "YYYY-MM-DD HH:mm" を Date（Asia/Tokyo）にする。読めなければ null */
export function dateTimeFromKey(key) {
  const k = toDateTimeKey(key);
  if (k === null) return null;
  const m = k.match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/);
  return new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5])) - JST_OFFSET_MINUTES * 60000);
}

/** "HH:mm" を 0 時からの分にする */
export function minutesOf(time) {
  const parts = String(time).split(":");
  return Number(parts[0]) * 60 + Number(parts[1]);
}

/** 0 時からの分を "HH:mm" にする */
export function timeOf(minutes) {
  return pad2(Math.floor(minutes / 60)) + ":" + pad2(minutes % 60);
}

/**
 * "YYYY-MM-DD" の日付・"HH:mm" の時刻に分を足す（負の数は引く）。日をまたいだ分は date 側に繰り上げ・繰り下げる。
 * 空きの計算で締切や枠の終わりを出すのに使う。文字だけの計算で、Date は日付の境をまたぐときだけ Date.UTC 経由で使う。
 */
export function addMinutes(dateKey, time, minutes) {
  const total = minutesOf(time) + minutes;
  const dayOffset = Math.floor(total / 1440);
  const remainder = total - dayOffset * 1440;
  return { date: addDays(dateKey, dayOffset), time: timeOf(remainder) };
}

/** "YYYY-MM-DD" の曜日。0（日）〜6（土） */
export function weekdayOf(dateKey) {
  const parts = String(dateKey).split("-").map(Number);
  return new Date(Date.UTC(parts[0], parts[1] - 1, parts[2])).getUTCDay();
}

/** "YYYY-MM-DD" の曜日を漢字 1 字にする（日・月・火・水・木・金・土）。メールの日付表示・通知文の短い日付が共通で使う道具 */
export function weekdayKanjiOf(dateKey) {
  const names = ["日", "月", "火", "水", "木", "金", "土"];
  return names[weekdayOf(dateKey)];
}

/**
 * 画面とメールに出す長い日付。設定「日付の書式」に沿って区切りを選び、曜日を添える：
 * "2026-10-03（土）"（`yyyy/MM/dd` なら "2026/10/03（土）"）。
 * 日付の形（YYYY-MM-DD）でない字は、そのまま返す（空は空のまま）
 */
export function longDateOf(dateKey, dateFormat) {
  const key = textOf(dateKey);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return key;
  const shown = textOf(dateFormat) === "yyyy/MM/dd" ? key.split("-").join("/") : key;
  return shown + "（" + weekdayKanjiOf(key) + "）";
}

/** 件名・通知文に使う短い日付（0 埋めなし、曜日は全角カッコ）："9/19（土）" */
export function shortDateOf(dateKey) {
  if (dateKey === "") return "";
  const parts = String(dateKey).split("-");
  return Number(parts[1]) + "/" + Number(parts[2]) + "（" + weekdayKanjiOf(dateKey) + "）";
}

/** "YYYY-MM-DD" に日数を足す（負の数は引く）。月・年をまたいでもよい */
export function addDays(dateKey, days) {
  const parts = String(dateKey).split("-").map(Number);
  const at = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + days));
  return at.getUTCFullYear() + "-" + pad2(at.getUTCMonth() + 1) + "-" + pad2(at.getUTCDate());
}
