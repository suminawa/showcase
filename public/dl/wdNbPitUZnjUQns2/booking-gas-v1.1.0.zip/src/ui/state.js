/**
 * 画面の状態と、それを変える reduce。純粋（DOM にも google にも触らない）。
 * reduce は渡された state を書き換えず、必ず新しい入れ物を返す（変わらないときは同じ state をそのまま返す）。
 *
 * step の流れ:
 *   loading → （boot-error）
 *           → service → calendar → slots → form → confirm → done
 *   キャンセルの URL で開いたときは cancel → cancelled
 */
import { pad2 } from "../text.js";

/** 「戻る」の行き先。calendar から service へはサービスが 2 つ以上のときだけ */
const BACK_TO = { confirm: "form", form: "slots", slots: "calendar", calendar: "service" };

export function initialState() {
  return {
    step: "loading",
    boot: null,
    service: "",
    days: [],
    month: "",
    date: "",
    slots: null,
    slot: null,
    values: { name: "", email: "", phone: "", note: "", website: "" },
    errors: {},
    busy: false,
    error: "",
    done: null,
    cancel: null,
  };
}

function next_(state, patch) {
  return Object.assign({}, state, patch);
}

function serviceList_(state) {
  const boot = state === null || state === undefined ? null : state.boot;
  return boot && Array.isArray(boot.services) ? boot.services : [];
}

/**
 * カレンダーの印は、選ばれたサービスで数えたものを使う。
 * bootstrap が返す daysByService にそのサービスが無ければ、サービスを選ぶ前のぶん（days）で代える
 */
function daysFor_(data, service) {
  const boot = data === null || data === undefined ? {} : data;
  const byService = boot.daysByService === null || typeof boot.daysByService !== "object" ? {} : boot.daysByService;
  const name = String(service === null || service === undefined ? "" : service);
  const chosen = Object.prototype.hasOwnProperty.call(byService, name) ? byService[name] : null;
  if (Array.isArray(chosen)) return chosen;
  return Array.isArray(boot.days) ? boot.days : [];
}

/** "2026-09" に月を足し引きする（年をまたいでもよい） */
function shiftMonth_(month, delta) {
  const parts = String(month).split("-");
  const total = Number(parts[0]) * 12 + (Number(parts[1]) - 1) + delta;
  return Math.floor(total / 12) + "-" + pad2((total % 12) + 1);
}

/** 行き来できる月の範囲。今日の月から、受け付ける最後の日の月まで */
function monthRange_(state) {
  const boot = state.boot || {};
  const bootDays = Array.isArray(boot.days) ? boot.days : [];
  const days = Array.isArray(state.days) && state.days.length > 0 ? state.days : bootDays;
  const min = String(boot.today === null || boot.today === undefined ? "" : boot.today).slice(0, 7);
  const last = days.length > 0 ? String(days[days.length - 1].date).slice(0, 7) : min;
  return { min: min, max: last < min ? min : last };
}

export function reduce(state, action) {
  const type = action === null || action === undefined ? "" : action.type;

  if (type === "bootstrap") {
    const data = action.data === null || action.data === undefined ? {} : action.data;
    const services = Array.isArray(data.services) ? data.services : [];
    const errors = Array.isArray(data.errors) ? data.errors : [];
    const today = String(data.today === null || data.today === undefined ? "" : data.today);
    let step = "calendar";
    if (errors.length > 0) step = "boot-error";
    else if (services.length >= 2) step = "service";
    // サービスが 1 つだけなら選ぶ画面を出さずに、そのサービスで進める
    const service = services.length === 1 ? String(services[0].name) : "";
    // 読み込み直しでも前の入力が残らないよう、はじめの状態から作り直す
    return Object.assign(initialState(), {
      step: step,
      boot: data,
      service: service,
      days: daysFor_(data, service),
      month: today.slice(0, 7),
    });
  }

  if (type === "select-service") {
    const name = String(action.name === null || action.name === undefined ? "" : action.name);
    const services = serviceList_(state);
    let known = services.length === 0;
    for (let i = 0; i < services.length; i += 1) {
      if (String(services[i].name) === name) known = true;
    }
    if (!known) return state;
    // カレンダーの印も、そのサービスで数えたものに入れ替える
    return next_(state, { service: name, step: "calendar", days: daysFor_(state.boot, name) });
  }

  if (type === "month") {
    if (state.month === "") return state;
    const range = monthRange_(state);
    const moved = shiftMonth_(state.month, Number(action.delta) < 0 ? -1 : 1);
    if (moved < range.min || moved > range.max) return state;
    return next_(state, { month: moved });
  }

  if (type === "select-date") {
    const date = String(action.date === null || action.date === undefined ? "" : action.date);
    return next_(state, { step: "slots", date: date, slots: null, slot: null });
  }

  if (type === "slots") {
    // 日を押し直したあとに届いた古い返事は捨てる
    const date = String(action.date === null || action.date === undefined ? "" : action.date);
    if (date !== state.date) return state;
    return next_(state, { slots: Array.isArray(action.slots) ? action.slots : [], busy: false });
  }

  if (type === "select-slot") {
    const slots = Array.isArray(state.slots) ? state.slots : [];
    const start = String(action.start === null || action.start === undefined ? "" : action.start);
    for (let i = 0; i < slots.length; i += 1) {
      if (String(slots[i].start) === start) return next_(state, { slot: slots[i], step: "form" });
    }
    return state;
  }

  if (type === "input") {
    const field = String(action.field === null || action.field === undefined ? "" : action.field);
    if (!Object.prototype.hasOwnProperty.call(state.values, field)) return state;
    const values = Object.assign({}, state.values);
    values[field] = action.value === null || action.value === undefined ? "" : String(action.value);
    return next_(state, { values: values });
  }

  if (type === "errors") return next_(state, { errors: action.errors === null || action.errors === undefined ? {} : action.errors });
  if (type === "confirm") return next_(state, { step: "confirm" });

  if (type === "back") {
    const to = BACK_TO[state.step];
    if (to === undefined) return state;
    if (to === "service" && serviceList_(state).length < 2) return state;
    return next_(state, { step: to });
  }

  if (type === "busy") return next_(state, { busy: action.on === true });
  // サーバーから返事が届いた action は、押せるように busy を下ろす
  if (type === "done") return next_(state, { step: "done", done: action.result === undefined ? null : action.result, busy: false });
  if (type === "error") return next_(state, { error: String(action.message === null || action.message === undefined ? "" : action.message), busy: false });
  if (type === "dismiss-error") return next_(state, { error: "" });
  if (type === "cancel-info") return next_(state, { step: "cancel", cancel: action.data === undefined ? null : action.data, busy: false });
  if (type === "cancelled") {
    const id = String(action.id === null || action.id === undefined ? "" : action.id);
    return next_(state, { step: "cancelled", done: { id: id }, busy: false });
  }

  return state;
}
