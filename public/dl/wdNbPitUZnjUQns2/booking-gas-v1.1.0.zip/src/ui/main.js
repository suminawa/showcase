/**
 * 画面の組み立て。state（state.js）と描画（render.js）と api（api-gas.js / api-memory.js）をつなぐ。
 * DOM に触るのはこのファイルだけ。HTML の組み立ては render.js だけが行う（ここで文字を HTML にしない）。
 *
 * 流れ: bootstrap → サービス → カレンダー → 時間 → 入力 → 確認 → 完了。
 * キャンセルの URL（window.__BOOKING_CANCEL__）で開かれたときは、読み込みのあとキャンセルの画面から始める。
 */
import { renderApp } from "./render.js";
import { initialState, reduce } from "./state.js";
import { validateReservation } from "../validate.js";

/** 入力欄の名前（state.values と render.js の name 属性にそろえる） */
const FIELD_NAMES = ["name", "email", "phone", "note", "website"];

/** キャンセルの URL で開かれたときに doGet が差し込む合い言葉。無ければ空 */
function cancelTokenOf_() {
  if (typeof window === "undefined" || window === null) return "";
  return typeof window.__BOOKING_CANCEL__ === "string" ? window.__BOOKING_CANCEL__ : "";
}

/**
 * 画面の検査に渡すサービスの一覧。
 * bootstrap が返すのは受付中のサービスだけなので、validate.js が見る active を足す
 */
function servicesToCheck_(boot) {
  const services = boot && Array.isArray(boot.services) ? boot.services : [];
  const out = [];
  for (let i = 0; i < services.length; i += 1) out.push({ name: services[i].name, active: true });
  return out;
}

export function mountBooking(root, api) {
  let state = initialState();
  /** 空きの要求の番号。日を押し替えたあとに届いた古い返事を捨てるために使う */
  let slotsSeq = 0;
  const cancelToken = cancelTokenOf_();

  function paint() {
    root.innerHTML = renderApp(state);
  }

  /** 新しい画面の見出しへ、読み上げと目線を移す */
  function focusHeading_() {
    const heading = root.querySelector(".bk-h2");
    if (!heading) return;
    if (heading.setAttribute) heading.setAttribute("tabindex", "-1");
    if (heading.focus) heading.focus();
  }

  /** いま目線のある要素。document の無いところ（テストの偽 DOM）では null */
  function activeElement_() {
    if (typeof document === "undefined" || document === null) return null;
    return document.activeElement === undefined ? null : document.activeElement;
  }

  /**
   * 描き直しで、目線の置きどころが無くなったか。
   * 同じ画面のまま描き直すと（空きが届いたときなど）目線のあった節点は捨てられ、
   * ブラウザは目線を <body> へ落としてしまう。そのときは見出しへ戻す
   */
  function focusLost_(before) {
    if (typeof document === "undefined" || document === null) return false;
    const active = activeElement_();
    if (active === null) return true;
    if (document.body !== undefined && document.body !== null && active === document.body) return true;
    return before !== null && before !== undefined && before.isConnected === false;
  }

  /** 誤りのある最初の入力欄へ移る */
  function focusFirstError_() {
    const field = root.querySelector(".bk-has-error input, .bk-has-error textarea");
    if (field && field.focus) field.focus();
  }

  function dispatch(action) {
    const before = state.step;
    const focused = activeElement_();
    state = reduce(state, action);
    paint();
    // はじめの読み込みでは目線を動かさない（お客さまが触る前から画面が動いて見えないように）
    if (before === "loading") return;
    // 画面が変わったとき、または描き直しで目線の置きどころが消えたときは、いまの画面の見出しへ移す
    if (state.step !== before || focusLost_(focused)) focusHeading_();
  }

  function fail(error) {
    dispatch({ type: "error", message: error && error.message ? error.message : String(error) });
  }

  /** 選んだ日の空きを取り直す。古い返事は捨てる */
  function loadSlots(date) {
    slotsSeq += 1;
    const seq = slotsSeq;
    return api
      .availability(date, state.service)
      .then(function (result) {
        if (seq !== slotsSeq) return;
        const answer = result === null || result === undefined ? {} : result;
        dispatch({ type: "slots", date: answer.date === undefined ? date : answer.date, slots: answer.slots });
      })
      .catch(function (error) {
        if (seq !== slotsSeq) return;
        fail(error);
      });
  }

  function chooseDate(date) {
    dispatch({ type: "select-date", date: date });
    loadSlots(state.date);
  }

  /** フォームの 5 つの欄を { name, email, phone, note, website } にする */
  function valuesOf(form) {
    const values = {};
    for (let i = 0; i < FIELD_NAMES.length; i += 1) {
      const field = FIELD_NAMES[i];
      const element = form && form.elements && form.elements.namedItem ? form.elements.namedItem(field) : null;
      values[field] = element === null || element === undefined ? state.values[field] : String(element.value === undefined ? "" : element.value);
    }
    return values;
  }

  /** 「確認へ」。サーバーと同じ検査を画面でも通し、誤りがあれば欄の下に出す */
  function toConfirm(form) {
    const values = valuesOf(form);
    for (let i = 0; i < FIELD_NAMES.length; i += 1) {
      state = reduce(state, { type: "input", field: FIELD_NAMES[i], value: values[FIELD_NAMES[i]] });
    }
    const slot = state.slot === null || state.slot === undefined ? {} : state.slot;
    const shop = state.boot && state.boot.shop ? state.boot.shop : {};
    const checked = validateReservation(
      { name: values.name, email: values.email, phone: values.phone, note: values.note, date: state.date, start: slot.start, service: state.service },
      { settings: { phoneRequired: shop.phoneRequired === true }, services: servicesToCheck_(state.boot) }
    );
    if (!checked.ok) {
      dispatch({ type: "errors", errors: checked.errors });
      focusFirstError_();
      return;
    }
    dispatch({ type: "errors", errors: {} });
    dispatch({ type: "confirm" });
  }

  /** 「この内容で予約する」。busy のあいだは二重に送らない */
  function reserve() {
    if (state.busy === true) return;
    const slot = state.slot === null || state.slot === undefined ? {} : state.slot;
    const values = state.values;
    const date = state.date;
    dispatch({ type: "busy", on: true });
    api
      .reserve({
        name: values.name,
        email: values.email,
        phone: values.phone,
        note: values.note,
        website: values.website,
        date: date,
        start: slot.start,
        service: state.service,
      })
      .then(function (result) {
        dispatch({ type: "done", result: result });
      })
      .catch(function (error) {
        fail(error);
        // 先に取られていた・締切を過ぎたときのために、その日の空きを読み直す（設計書 §2-5）
        if (state.date === date) loadSlots(date);
      });
  }

  /** キャンセルの画面の「このご予約をキャンセルする」 */
  function cancel() {
    if (state.busy === true || cancelToken === "") return;
    dispatch({ type: "busy", on: true });
    api
      .cancel(cancelToken)
      .then(function (result) {
        dispatch({ type: "cancelled", id: result && result.id ? result.id : "" });
      })
      .catch(fail);
  }

  root.addEventListener("click", function (event) {
    const element = event.target && event.target.closest ? event.target.closest("[data-action]") : null;
    if (!element || (root.contains && !root.contains(element))) return;
    const data = element.dataset || {};
    const action = data.action;
    if (action === "select-service") dispatch({ type: "select-service", name: data.name });
    else if (action === "month") dispatch({ type: "month", delta: Number(data.delta) });
    else if (action === "select-date") chooseDate(data.date);
    else if (action === "select-slot") dispatch({ type: "select-slot", start: data.start });
    else if (action === "back") dispatch({ type: "back" });
    else if (action === "reserve") reserve();
    else if (action === "cancel") cancel();
    else if (action === "dismiss-error") dispatch({ type: "dismiss-error" });
  });

  // 打っている字は state に写すだけで描き直さない（描き直すと、書きかけの字と変換が消えてしまう）
  function keep(event) {
    const element = event.target;
    if (!element || !element.name) return;
    state = reduce(state, { type: "input", field: element.name, value: element.value });
  }
  root.addEventListener("input", keep);
  root.addEventListener("change", keep);

  root.addEventListener("submit", function (event) {
    const form = event.target;
    if (!form || !form.dataset || form.dataset.form !== "reserve") return;
    event.preventDefault();
    toConfirm(form);
  });

  paint();
  const ready = api
    .bootstrap()
    .then(function (data) {
      dispatch({ type: "bootstrap", data: data });
      // 設定に誤りがあるときは、その知らせを消さない
      if (cancelToken === "" || state.step === "boot-error") return null;
      return api.cancelInfo(cancelToken).then(function (info) {
        dispatch({ type: "cancel-info", data: info });
      });
    })
    .catch(fail);

  return { getState: () => state, dispatch: dispatch, ready: ready };
}
