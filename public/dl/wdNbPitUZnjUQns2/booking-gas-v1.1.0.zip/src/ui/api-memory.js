/**
 * 見本ページ用の api。GAS には触らず、見本の店「ひだまり整体院」のデータをブラウザの中の配列で動かす。
 * 予約・キャンセルはその場の配列に書くだけで、ページを閉じれば消える。
 * 規則（空き・検査・受付番号・合い言葉）はサーバー（gas_web.js）と同じものを呼ぶので、動きは実物と変わらない。
 *
 * 「いま」を知るために new Date() を使うのは、src の中でこのファイルだけ（purity テストもここだけ外している）。
 */
import { calendarDays, cancelAllowed, isBookable, remainingFor, slotsFor } from "../availability.js";
import { formatStamp, toDateKey } from "../dates.js";
import { nextReceipt } from "../receipt.js";
import { parseClosedDays, parseRules } from "../rules.js";
import { parseServices } from "../services.js";
import { parseSettings } from "../settings.js";
import { sampleData } from "../samples.js";
import { textOf } from "../text.js";
import { isToken, tokenFromUuid } from "../token.js";
import { validateReservation } from "../validate.js";

/** サーバーを待つ感じを出すための遅れ（ミリ秒） */
const DEMO_DELAY_MS = 120;
const DEMO_CONFIRMED = "確定";
const DEMO_CANCELLED = "キャンセル";
/** 見えない欄が埋まっていたときに返す受付番号（何も書かない） */
const DEMO_DECOY_ID = "—";
/** 設定・枠・休み・サービスに誤りがあるときに、お客さまの画面へ出す 1 文（gas_web.js と同じ言い方） */
const DEMO_BOOT_STOPPED_TEXT = "ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。";

/** お客さまに見せてよい、こちらで用意した誤り（これ以外は当たりさわりのない文に置き換える） */
function demoStop_(message) {
  const error = new Error(message);
  error.expected = true;
  return error;
}

function demoWait_() {
  return new Promise(function (resolve) {
    setTimeout(resolve, DEMO_DELAY_MS);
  });
}

/** 遅れてから中身を動かす。中で投げた誤りは Promise の失敗になる */
function demoCall_(action) {
  return function () {
    const args = arguments;
    return demoWait_().then(function () {
      try {
        return action.apply(null, args);
      } catch (error) {
        if (error !== null && error !== undefined && error.expected === true) throw error;
        throw new Error("ただいま処理できませんでした。ページを読み込み直してください。");
      }
    });
  };
}

/** 2 次元の表（1 行目が見出し）を、見出しをキーにした行の配列にする */
function demoRecords_(values) {
  const rows = Array.isArray(values) ? values : [];
  const header = Array.isArray(rows[0]) ? rows[0] : [];
  const records = [];
  for (let i = 1; i < rows.length; i += 1) {
    const row = Array.isArray(rows[i]) ? rows[i] : [];
    const record = {};
    for (let j = 0; j < header.length; j += 1) record[textOf(header[j])] = row[j] === undefined ? "" : row[j];
    records.push(record);
  }
  return records;
}

/** 見本の合い言葉。実物は Utilities.getUuid() なので、ここでは同じ形の字を順番に作って token.js に通す */
function demoUuid_(sequence) {
  let hex = Number(sequence).toString(16);
  while (hex.length < 8) hex = "0" + hex;
  return hex.slice(-8) + "-0000-4000-8000-000000000000";
}

/** 画面に渡す店の情報（gas_web.js の shopOf_ と同じ形） */
function demoShop_(settings) {
  return {
    name: textOf(settings.shopName),
    phone: textOf(settings.phone),
    address: textOf(settings.address),
    notice: textOf(settings.notice),
    themeColor: textOf(settings.themeColor),
    phoneRequired: settings.phoneRequired === true,
    dateFormat: textOf(settings.dateFormat),
    cancelHours: settings.cancelHours,
    leadHours: settings.leadHours,
  };
}

/** 受付中のサービスだけを画面の形にする */
function demoOpenServices_(services) {
  const out = [];
  for (let i = 0; i < services.length; i += 1) {
    if (services[i].active !== true) continue;
    out.push({ name: services[i].name, minutes: services[i].minutes, description: services[i].description });
  }
  return out;
}

function demoFirstError_(errors) {
  const names = Object.keys(errors);
  return names.length === 0 ? "入力をご確認ください" : errors[names[0]];
}

function demoFindSlot_(slots, start) {
  for (let i = 0; i < slots.length; i += 1) if (slots[i].start === start) return slots[i];
  return null;
}

function demoFindByToken_(reservations, token) {
  for (let i = 0; i < reservations.length; i += 1) {
    if (textOf(reservations[i]["キャンセル用"]) === token) return reservations[i];
  }
  return null;
}

/**
 * 見本ページの api。fixedNow は「いま」を止めるための引数で、テストからだけ渡す
 * （見本ページは何も渡さず、ブラウザの時計を読む）。
 */
export function memoryApi(fixedNow) {
  const fixed = textOf(fixedNow);

  /** "YYYY-MM-DD HH:mm:ss"（Asia/Tokyo） */
  function stamp_() {
    return fixed === "" ? formatStamp(new Date()) : fixed;
  }
  /** 空きの計算に渡す「いま」 */
  function now_() {
    return stamp_().slice(0, 16);
  }

  const today = now_().slice(0, 10);
  const data = sampleData(today);
  const settingsRead = parseSettings(data.settings);
  const rulesRead = parseRules(data.rules);
  const closedRead = parseClosedDays(data.closed);
  const servicesRead = parseServices(data.services);
  const settings = settingsRead.settings;
  const reservations = demoRecords_(data.reservations);

  // 受付番号は見本の予約の続きから。合い言葉は順番に作る
  let lastId = reservations.length === 0 ? "" : textOf(reservations[reservations.length - 1]["ID"]);
  let tokenCount = 0;

  return {
    bootstrap: demoCall_(function () {
      const now = now_();
      const services = demoOpenServices_(servicesRead.services);
      const errors = settingsRead.errors.concat(rulesRead.errors, closedRead.errors, servicesRead.errors);
      const boot = { shop: demoShop_(settings), services: services, days: [], daysByService: {}, today: now.slice(0, 10), errors: [] };
      // 誤りの中身はお客さまの画面に出さない（実物はメニュー「設定を確かめる」でお店にだけお伝えする）
      if (errors.length > 0) {
        boot.errors = [DEMO_BOOT_STOPPED_TEXT];
        return boot;
      }
      // サービスを選ぶ前のぶんと、受付中のサービスごとのぶん（選び替えたら印も入れ替わる）
      boot.days = calendarDays(now, settings, rulesRead.rules, closedRead.closed, reservations, "");
      for (let i = 0; i < services.length; i += 1) {
        boot.daysByService[services[i].name] = calendarDays(now, settings, rulesRead.rules, closedRead.closed, reservations, services[i].name);
      }
      return boot;
    }),

    availability: demoCall_(function (date, service) {
      const key = toDateKey(textOf(date));
      if (key === null) throw demoStop_("日付をお選びください");

      const now = now_();
      const slots = remainingFor(slotsFor(key, rulesRead.rules, closedRead.closed, textOf(service)), reservations, key);
      const out = [];
      for (let i = 0; i < slots.length; i += 1) {
        if (!isBookable(key, slots[i].start, now, settings)) continue;
        out.push({ start: slots[i].start, end: slots[i].end, remaining: slots[i].remaining });
      }
      return { date: key, slots: out };
    }),

    reserve: demoCall_(function (input) {
      const raw = input === null || input === undefined ? {} : input;

      // 見えない欄が埋まっていたら、成功したように見せて何も書かない（設計書 §7）
      if (textOf(raw.website) !== "") {
        return { ok: true, id: DEMO_DECOY_ID, date: textOf(raw.date), start: textOf(raw.start), end: textOf(raw.start), service: textOf(raw.service), mailSent: false };
      }

      const checked = validateReservation(raw, { settings: settings, services: servicesRead.services });
      if (!checked.ok) throw demoStop_(demoFirstError_(checked.errors));
      const value = checked.value;

      // 数えるのはこれからのご予約だけ（サーバーの gas_web.js と同じ数え方）
      let same = 0;
      for (let i = 0; i < reservations.length; i += 1) {
        if (textOf(reservations[i]["状態"]) !== DEMO_CONFIRMED) continue;
        if (textOf(reservations[i]["日付"]) < today) continue;
        if (textOf(reservations[i]["メール"]).toLowerCase() === value.email.toLowerCase()) same += 1;
      }
      if (same >= settings.maxPerEmail) throw demoStop_("同じメールアドレスでのご予約は " + settings.maxPerEmail + " 件までです。");

      const now = now_();
      const slots = remainingFor(slotsFor(value.date, rulesRead.rules, closedRead.closed, value.service), reservations, value.date);
      const slot = demoFindSlot_(slots, value.start);
      if (slot === null || !isBookable(value.date, value.start, now, settings)) {
        throw demoStop_("選ばれた時間は、受付を終了しました。別の時間をお選びください。");
      }
      if (slot.remaining <= 0) throw demoStop_("選ばれた時間は、ただいま満席になりました。別の時間をお選びください。");

      const id = nextReceipt(lastId, today);
      lastId = id;
      tokenCount += 1;
      reservations.push({
        "ID": id,
        "状態": DEMO_CONFIRMED,
        "日付": value.date,
        "開始": value.start,
        "終了": slot.end,
        "サービス": value.service,
        "お名前": value.name,
        "メール": value.email,
        "電話": value.phone,
        "ご要望": value.note,
        "受付日時": stamp_(),
        "キャンセル日時": "",
        "カレンダー": "",
        "リマインド": "",
        "キャンセル用": tokenFromUuid(demoUuid_(tokenCount)),
      });
      // 見本ページはメールを送らないが、画面の流れは実物と同じ（送れたときの完了画面）を見せる
      return { ok: true, id: id, date: value.date, start: value.start, end: slot.end, service: value.service, mailSent: true };
    }),

    cancelInfo: demoCall_(function (token) {
      const key = textOf(token);
      if (!isToken(key)) return { found: false };
      const found = demoFindByToken_(reservations, key);
      if (found === null) return { found: false };

      const status = textOf(found["状態"]);
      return {
        found: true,
        reservation: {
          id: textOf(found["ID"]),
          date: textOf(found["日付"]),
          start: textOf(found["開始"]),
          end: textOf(found["終了"]),
          service: textOf(found["サービス"]),
          name: textOf(found["お名前"]),
          status: status,
        },
        canCancel: status === DEMO_CONFIRMED && cancelAllowed(found, now_(), settings),
        phone: textOf(settings.phone),
      };
    }),

    cancel: demoCall_(function (token) {
      const key = textOf(token);
      if (!isToken(key)) throw demoStop_("キャンセルの URL が正しくありません。メールの URL をもう一度お確かめください。");
      const found = demoFindByToken_(reservations, key);
      if (found === null) throw demoStop_("ご予約が見つかりませんでした。メールの URL をもう一度お確かめください。");
      if (textOf(found["状態"]) !== DEMO_CONFIRMED) throw demoStop_("このご予約はすでにキャンセルされています。");
      if (!cancelAllowed(found, now_(), settings)) {
        throw demoStop_("キャンセルの受付は開始の " + settings.cancelHours + " 時間前までです。お電話でご連絡ください。");
      }
      found["状態"] = DEMO_CANCELLED;
      found["キャンセル日時"] = stamp_();
      return { ok: true, id: textOf(found["ID"]) };
    }),
  };
}
