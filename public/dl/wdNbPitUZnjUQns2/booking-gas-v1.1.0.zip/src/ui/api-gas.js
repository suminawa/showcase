/**
 * GAS 上で動く画面から、サーバーの api_*（gas_web.js の 5 つ）を呼ぶ。
 * google.script.run に触るのはこのファイルだけ。答えも誤りも Promise にして main.js に渡す。
 */

/**
 * 失敗のときに来る値は Error とはかぎらないので、敬体の文を持つ Error にそろえる。
 * 文が無い（null や空）ときは、こちらで用意した 1 文に倒す
 */
function gasError_(error) {
  const raw = error === null || error === undefined ? "" : String(error.message === undefined ? error : error.message);
  const message = raw === "null" || raw === "undefined" ? "" : raw;
  return new Error(message === "" ? "ただいま処理できませんでした。しばらく経ってから、もう一度お試しください。" : message);
}

/** api_xxx を 1 つ呼ぶ。args はそのまま渡す引数の配列 */
function callGas_(name, args) {
  return new Promise(function (resolve, reject) {
    const runner = google.script.run.withSuccessHandler(resolve).withFailureHandler(function (error) {
      reject(gasError_(error));
    });
    runner[name].apply(runner, args);
  });
}

export function gasApi() {
  return {
    bootstrap: function () {
      return callGas_("api_bootstrap", []);
    },
    availability: function (date, service) {
      return callGas_("api_availability", [date, service]);
    },
    reserve: function (input) {
      return callGas_("api_reserve", [input]);
    },
    cancelInfo: function (token) {
      return callGas_("api_cancelInfo", [token]);
    },
    cancel: function (token) {
      return callGas_("api_cancel", [token]);
    },
  };
}
