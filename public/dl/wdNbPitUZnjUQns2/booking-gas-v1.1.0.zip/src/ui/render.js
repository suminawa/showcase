/**
 * 画面の描画。state から HTML の文字列を作るだけ（DOM に触るのは main.js）。
 * 画面に出す値はすべて escapeHtml / attr_ を通す（シートの文字がそのまま HTML にならないように）。
 * 押せるところは data-action で印をつけ、main.js が委譲で受ける。
 */
import { addDays, longDateOf, shortDateOf, weekdayOf } from "../dates.js";
import { escapeHtml, textOf } from "../text.js";
import { LIMITS } from "../validate.js";

/** テーマ色は # と 16 進（3 桁か 6 桁）だけ通す。ほかの値は style に入れない */
const ACCENT_RE = /^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/;
const WEEKDAY_HEADS = ["日", "月", "火", "水", "木", "金", "土"];
/** 空きのある日の印。読み上げには DAY_LABELS の言葉を隠し文字で添える */
const DAY_MARKS = { open: "○", few: "△" };
const DAY_LABELS = { open: "空きあり", few: "残りわずか", full: "満席", closed: "受付なし", past: "受付終了" };
const CONFIRMED_LABEL = "確定";
/** 受付を止めているのに知らせの文が届かなかったときの、控えめな言い方 */
const BOOT_STOPPED_FALLBACK = "ただいま予約を受け付けられません。";

function attr_(value) {
  return escapeHtml(value);
}

/** 読み込み前（boot が null）でも壊れないよう、無ければ空の入れ物を返す */
function shopFrom_(state) {
  const boot = state === null || state === undefined ? null : state.boot;
  return boot && boot.shop ? boot.shop : {};
}

function servicesOf_(state) {
  const boot = state === null || state === undefined ? null : state.boot;
  return boot && Array.isArray(boot.services) ? boot.services : [];
}

function accentStyle_(shop) {
  const color = textOf(shop.themeColor);
  if (!ACCENT_RE.test(color)) return "";
  return ' style="--bk-accent: ' + attr_(color) + '"';
}

/** 読み上げ用の隠し文字（style.css の .bk-sr で見えなくする） */
function srOnly_(text) {
  return '<span class="bk-sr">' + escapeHtml(text) + "</span>";
}

/** "10:00〜10:45"。終わりが無ければ始まりだけ。返り値はエスケープ済み */
function timeRange_(start, end) {
  const from = textOf(start);
  const to = textOf(end);
  return escapeHtml(to === "" ? from : from + "〜" + to);
}

/** "2026-10-03（土） 10:00〜10:45"。日付は dates.js の longDateOf（メールと同じ言い方）。返り値はエスケープ済み */
function whenHtml_(shop, dateKey, start, end) {
  return escapeHtml(longDateOf(dateKey, shop.dateFormat)) + " " + timeRange_(start, end);
}

/** 電話はかけられるようにする。href には数字と + だけを入れる */
function phoneHtml_(phone) {
  const text = textOf(phone);
  if (text === "") return "";
  return '<a class="bk-tel" href="tel:' + attr_(text.replace(/[^0-9+]/g, "")) + '">' + escapeHtml(text) + "</a>";
}

/** rows は [見出し, 中身の HTML] の配列。null の行は出さない（中身は呼ぶ側でエスケープ済み） */
function defList_(className, rows) {
  let items = "";
  for (let i = 0; i < rows.length; i += 1) {
    if (rows[i] === null) continue;
    items += "<dt>" + escapeHtml(rows[i][0]) + "</dt><dd>" + rows[i][1] + "</dd>";
  }
  return '<dl class="' + className + '">' + items + "</dl>";
}

/** 「内容」の行に出す言葉。サービスを選んでいない・登録の無い店は「ご予約」（mail.js の差し込みと同じ） */
function serviceLabel_(service) {
  const text = textOf(service);
  return escapeHtml(text === "" ? "ご予約" : text);
}

function orNone_(value) {
  const text = textOf(value);
  return text === "" ? '<span class="bk-muted">ご記入なし</span>' : escapeHtml(text);
}

function backButton_(label) {
  return '<div class="bk-actions"><button type="button" class="bk-btn bk-btn-quiet" data-action="back">' + escapeHtml(label) + "</button></div>";
}

/** 赤い帯。誤りが無ければ空文字 */
export function renderError(state) {
  const message = textOf(state.error);
  if (message === "") return "";
  return (
    '<div class="bk-error" role="alert"><span class="bk-error-text">' + escapeHtml(message) +
    '</span><button type="button" class="bk-error-x" data-action="dismiss-error" aria-label="この知らせを閉じる">×</button></div>'
  );
}

/**
 * 受付を止めている画面。お客さまには当たりさわりのない 1 文とお店の電話だけを出す。
 * 何が起きているかは、お店の方がメニュー「設定を確かめる」でご覧になれる
 */
function bootErrorHtml_(state) {
  const shop = shopFrom_(state);
  const boot = state.boot || {};
  const errors = Array.isArray(boot.errors) ? boot.errors : [];
  const message = textOf(errors[0]) === "" ? BOOT_STOPPED_FALLBACK : textOf(errors[0]);
  const phone = textOf(shop.phone) === "" ? "" : '<p class="bk-boot-tel">' + phoneHtml_(shop.phone) + "</p>";
  return '<section class="bk-step bk-boot-error" role="alert"><h2 class="bk-h2">' + escapeHtml(message) + "</h2>" + phone + "</section>";
}

/** サービスを選ぶ画面（サービスが 2 つ以上のときだけ出る） */
export function renderServices(state) {
  const services = servicesOf_(state);
  let items = "";
  for (let i = 0; i < services.length; i += 1) {
    const service = services[i];
    const minutes = service.minutes === null || service.minutes === undefined || service.minutes === ""
      ? ""
      : '<span class="bk-service-minutes">' + escapeHtml(service.minutes) + " 分</span>";
    const description = textOf(service.description) === ""
      ? ""
      : '<span class="bk-service-note">' + escapeHtml(service.description) + "</span>";
    items +=
      '<li><button type="button" class="bk-service" data-action="select-service" data-name="' + attr_(service.name) +
      '"><span class="bk-service-name">' + escapeHtml(service.name) + "</span>" + minutes + description + "</button></li>";
  }
  return '<section class="bk-step"><h2 class="bk-h2">ご希望のサービスをお選びください。</h2><ul class="bk-services">' + items + "</ul></section>";
}

function chosenServiceHtml_(state) {
  const service = textOf(state.service);
  if (service === "") return "";
  return '<p class="bk-chosen">ご希望のサービス：' + escapeHtml(service) + "</p>";
}

/** その月の 1 日から末日までを、日曜はじまりの 7 列に並べる。月の外は "" */
function monthCells_(month) {
  const first = month + "-01";
  const cells = [];
  for (let i = 0; i < weekdayOf(first); i += 1) cells.push("");
  let date = first;
  while (date.slice(0, 7) === month) {
    cells.push(date);
    date = addDays(date, 1);
  }
  while (cells.length % 7 !== 0) cells.push("");
  return cells;
}

function dayCellHtml_(date, marks, today) {
  // 受け付ける範囲の外（days に無い日）と月の外は、押せない空のマスにする
  if (date === "" || !Object.prototype.hasOwnProperty.call(marks, date)) return '<td class="bk-cal-empty"></td>';

  const status = Object.prototype.hasOwnProperty.call(DAY_LABELS, marks[date]) ? marks[date] : "closed";
  const number = Number(date.slice(8, 10));
  const cls = "bk-cal-cell bk-" + status + (date === today ? " bk-today" : "");
  const label = srOnly_(DAY_LABELS[status]);

  // 満席・休み・締切の日は押せない（data-action を付けないので main.js の委譲も拾わない）
  if (!Object.prototype.hasOwnProperty.call(DAY_MARKS, status)) {
    return (
      '<td class="' + cls + '"><button type="button" class="bk-day" data-date="' + attr_(date) +
      '" disabled aria-disabled="true"><span class="bk-day-n">' + number + "</span>" + label + "</button></td>"
    );
  }
  return (
    '<td class="' + cls + '"><button type="button" class="bk-day" data-action="select-date" data-date="' + attr_(date) +
    '"><span class="bk-day-n">' + number + '</span><span class="bk-day-mark" aria-hidden="true">' + DAY_MARKS[status] + "</span>" + label + "</button></td>"
  );
}

/** 月ごとの空きのカレンダー。前後の月は、今日の月と受け付ける最後の日の月で止まる */
export function renderCalendar(state) {
  const boot = state.boot || {};
  // 印は選ばれたサービスで数えたもの（state.days）。無ければ読み込みのときのぶんを使う
  const bootDays = Array.isArray(boot.days) ? boot.days : [];
  const days = Array.isArray(state.days) && state.days.length > 0 ? state.days : bootDays;
  const today = textOf(boot.today);
  const month = textOf(state.month) || today.slice(0, 7);
  if (!/^\d{4}-\d{2}$/.test(month)) return "";

  const marks = {};
  for (let i = 0; i < days.length; i += 1) marks[textOf(days[i].date)] = textOf(days[i].status);

  const min = today.slice(0, 7);
  const last = days.length > 0 ? textOf(days[days.length - 1].date).slice(0, 7) : min;
  const max = last < min ? min : last;
  const title = Number(month.slice(0, 4)) + "年" + Number(month.slice(5, 7)) + "月";

  let heads = "";
  for (let i = 0; i < WEEKDAY_HEADS.length; i += 1) heads += '<th scope="col">' + WEEKDAY_HEADS[i] + "</th>";

  const cells = monthCells_(month);
  let body = "";
  for (let i = 0; i < cells.length; i += 7) {
    let row = "";
    for (let j = i; j < i + 7; j += 1) row += dayCellHtml_(cells[j], marks, today);
    body += "<tr>" + row + "</tr>";
  }

  const nav =
    '<div class="bk-cal-nav"><button type="button" class="bk-nav" data-action="month" data-delta="-1"' + (month <= min ? " disabled" : "") +
    '>前の月</button><h3 class="bk-month">' + escapeHtml(title) + '</h3><button type="button" class="bk-nav" data-action="month" data-delta="1"' +
    (month >= max ? " disabled" : "") + ">次の月</button></div>";

  return (
    '<section class="bk-step"><h2 class="bk-h2">ご希望の日をお選びください。</h2>' + chosenServiceHtml_(state) + nav +
    '<table class="bk-cal"><caption class="bk-sr">' + escapeHtml(title) + 'の空き状況</caption><thead><tr>' + heads + "</tr></thead><tbody>" + body + "</tbody></table>" +
    '<p class="bk-legend">○ は空きあり、△ は残りわずかです。押せない日は受け付けていません。</p>' +
    (servicesOf_(state).length >= 2 ? backButton_("サービスを選び直す") : "") + "</section>"
  );
}

function slotItemHtml_(slot) {
  const time = timeRange_(slot.start, slot.end);
  const remaining = Number(slot.remaining);
  if (!(remaining > 0)) {
    return (
      '<li><button type="button" class="bk-slot" disabled aria-disabled="true"><span class="bk-slot-time">' + time +
      '</span><span class="bk-slot-left">満席</span></button></li>'
    );
  }
  return (
    '<li><button type="button" class="bk-slot" data-action="select-slot" data-start="' + attr_(slot.start) +
    '"><span class="bk-slot-time">' + time + '</span><span class="bk-slot-left">残り ' + escapeHtml(remaining) + "</span></button></li>"
  );
}

/** 選んだ日の時間の一覧 */
export function renderSlots(state) {
  let body = "";
  if (state.slots === null || state.slots === undefined) {
    body = '<p class="bk-loading">空きを読み込んでいます…</p>';
  } else if (state.slots.length === 0) {
    body = '<p class="bk-empty">この日は受け付けていません。</p>';
  } else {
    let items = "";
    for (let i = 0; i < state.slots.length; i += 1) items += slotItemHtml_(state.slots[i]);
    body = '<ul class="bk-slots">' + items + "</ul>";
  }
  return (
    '<section class="bk-step"><h2 class="bk-h2">' + escapeHtml(shortDateOf(textOf(state.date))) + "の時間をお選びください。</h2>" +
    chosenServiceHtml_(state) + body + backButton_("日を選び直す") + "</section>"
  );
}

/** 入力欄 1 つ。誤りは欄の下に置き、aria-describedby で入力と結ぶ */
function fieldHtml_(spec, values, errors) {
  const id = "bk-f-" + spec.field;
  const errorId = "bk-err-" + spec.field;
  const message = textOf(errors[spec.field]);
  const value = values[spec.field] === null || values[spec.field] === undefined ? "" : String(values[spec.field]);
  const described = message === "" ? "" : ' aria-describedby="' + errorId + '" aria-invalid="true"';
  const badge = spec.required
    ? ' <span class="bk-required">必須</span>'
    : ' <span class="bk-optional">任意</span>';
  const common = ' name="' + spec.field + '" id="' + id + '" maxlength="' + spec.max + '"' + (spec.required ? " required" : "") + described;
  const input = spec.type === "textarea"
    ? "<textarea" + common + ' rows="4">' + escapeHtml(value) + "</textarea>"
    : '<input type="' + spec.type + '"' + common + ' autocomplete="' + spec.autocomplete + '" value="' + attr_(value) + '">';
  const note = message === "" ? "" : '<p class="bk-field-error" id="' + errorId + '">' + escapeHtml(message) + "</p>";
  return (
    '<div class="bk-field' + (message === "" ? "" : " bk-has-error") + '"><label for="' + id + '">' + escapeHtml(spec.label) + badge + "</label>" +
    input + note + "</div>"
  );
}

/** お客さまの情報を書く画面。website は人には見えない欄（埋まっていたら書き込まない） */
export function renderForm(state) {
  const shop = shopFrom_(state);
  const values = state.values || {};
  const errors = state.errors || {};
  const slot = state.slot || {};
  const summary = defList_("bk-summary", [
    ["日時", whenHtml_(shop, state.date, slot.start, slot.end)],
    ["内容", serviceLabel_(state.service)],
  ]);
  const notice = textOf(shop.notice) === "" ? "" : '<p class="bk-notice">' + escapeHtml(shop.notice) + "</p>";
  const fields =
    fieldHtml_({ field: "name", label: "お名前", type: "text", autocomplete: "name", max: LIMITS.name, required: true }, values, errors) +
    fieldHtml_({ field: "email", label: "メールアドレス", type: "email", autocomplete: "email", max: LIMITS.email, required: true }, values, errors) +
    fieldHtml_({ field: "phone", label: "電話番号", type: "tel", autocomplete: "tel", max: LIMITS.phone, required: shop.phoneRequired === true }, values, errors) +
    fieldHtml_({ field: "note", label: "ご要望", type: "textarea", max: LIMITS.note, required: false }, values, errors);
  const honeypot =
    '<input type="text" name="website" class="bk-hp" tabindex="-1" autocomplete="off" aria-hidden="true" value="' + attr_(values.website) + '">';
  return (
    '<form class="bk-form" data-form="reserve" novalidate><h2 class="bk-h2">お客さまの情報をご記入ください。</h2>' + summary + notice + fields + honeypot +
    '<div class="bk-actions"><button type="submit" class="bk-btn bk-btn-primary">確認へ</button>' +
    '<button type="button" class="bk-btn bk-btn-quiet" data-action="back">戻る</button></div></form>'
  );
}

/** 送る前の確認。送信中は二重に押せないよう disabled にする */
export function renderConfirm(state) {
  const shop = shopFrom_(state);
  const values = state.values || {};
  const slot = state.slot || {};
  const list = defList_("bk-confirm", [
    ["日時", whenHtml_(shop, state.date, slot.start, slot.end)],
    ["内容", serviceLabel_(state.service)],
    ["お名前", escapeHtml(values.name)],
    ["メール", escapeHtml(values.email)],
    ["電話", orNone_(values.phone)],
    ["ご要望", orNone_(values.note)],
  ]);
  const off = state.busy === true ? " disabled" : "";
  const waiting = state.busy === true ? '<p class="bk-busy" role="status">お受けしています。そのままお待ちください。</p>' : "";
  return (
    '<section class="bk-step"><h2 class="bk-h2">ご予約の内容をご確認ください。</h2>' + list + waiting +
    '<div class="bk-actions"><button type="button" class="bk-btn bk-btn-primary" data-action="reserve"' + off + ">この内容で予約する</button>" +
    '<button type="button" class="bk-btn bk-btn-quiet" data-action="back"' + off + ">戻る</button></div></section>"
  );
}

/** 受け付けたあとの画面。メールが送れなかったときは正直に書く */
export function renderDone(state) {
  const shop = shopFrom_(state);
  const done = state.done || {};
  const list = defList_("bk-done-list", [
    ["受付番号", escapeHtml(done.id)],
    ["日時", whenHtml_(shop, done.date, done.start, done.end)],
    textOf(done.service) === "" ? null : ["サービス", escapeHtml(done.service)],
  ]);
  const mail = done.mailSent === true
    ? "<p>確認メールをお送りしました。ご予約の取り消しは、メールの URL からお手続きいただけます。</p>"
    : '<p class="bk-caution">受付はできています。確認メールは届いていませんので、この画面の受付番号をお控えください。</p>';
  const phone = textOf(shop.phone) === "" ? "" : "<p>ご不明な点は " + phoneHtml_(shop.phone) + " までお電話ください。</p>";
  return '<section class="bk-step bk-done"><h2 class="bk-h2">ご予約を受け付けました。</h2>' + list + mail + phone + "</section>";
}

/** キャンセルの URL で開いた画面 */
export function renderCancel(state) {
  const shop = shopFrom_(state);
  const info = state.cancel || {};
  if (info.found !== true) {
    return (
      '<section class="bk-step"><h2 class="bk-h2">このご予約は見つかりませんでした。</h2>' +
      "<p>メールに書かれた URL を、もう一度お確かめください。</p></section>"
    );
  }

  const reservation = info.reservation || {};
  const list = defList_("bk-confirm", [
    ["受付番号", escapeHtml(reservation.id)],
    ["日時", whenHtml_(shop, reservation.date, reservation.start, reservation.end)],
    textOf(reservation.service) === "" ? null : ["サービス", escapeHtml(reservation.service)],
    ["お名前", escapeHtml(reservation.name)],
  ]);

  let body = "";
  if (textOf(reservation.status) !== CONFIRMED_LABEL) {
    body = "<p>このご予約はすでにキャンセルされています。</p>";
  } else if (info.canCancel === true) {
    const off = state.busy === true ? " disabled" : "";
    body =
      '<p class="bk-caution">キャンセルすると元に戻せません。ご確認のうえ、お進みください。</p>' +
      '<div class="bk-actions"><button type="button" class="bk-btn bk-btn-danger" data-action="cancel"' + off + ">このご予約をキャンセルする</button></div>";
  } else {
    const hours = Number(shop.cancelHours);
    const limit = Number.isFinite(hours) && hours > 0
      ? "キャンセルの受付は開始の " + hours + " 時間前までです。"
      : "このご予約は、ページからのキャンセルの受付を終了しました。";
    const phone = textOf(info.phone) === "" ? textOf(shop.phone) : textOf(info.phone);
    body = "<p>" + escapeHtml(limit + "お電話でご連絡ください。") + "</p>" + (phone === "" ? "" : "<p>" + phoneHtml_(phone) + "</p>");
  }
  return '<section class="bk-step"><h2 class="bk-h2">ご予約の内容</h2>' + list + body + "</section>";
}

export function renderCancelled(state) {
  const done = state.done || {};
  const id = textOf(done.id);
  return (
    '<section class="bk-step"><h2 class="bk-h2">ご予約をキャンセルしました。</h2>' +
    (id === "" ? "" : "<p>受付番号：" + escapeHtml(id) + "</p>") +
    "<p>またのご利用をお待ちしております。</p></section>"
  );
}

function stepHtml_(state) {
  const step = state.step;
  if (step === "boot-error") return bootErrorHtml_(state);
  if (step === "service") return renderServices(state);
  if (step === "calendar") return renderCalendar(state);
  if (step === "slots") return renderSlots(state);
  if (step === "form") return renderForm(state);
  if (step === "confirm") return renderConfirm(state);
  if (step === "done") return renderDone(state);
  if (step === "cancel") return renderCancel(state);
  if (step === "cancelled") return renderCancelled(state);
  return '<p class="bk-loading">読み込んでいます…</p>';
}

/** ページ全体。main.js はこの文字列を root に入れ直す */
export function renderApp(state) {
  const shop = shopFrom_(state);
  const name = textOf(shop.name) === "" ? "予約ページ" : textOf(shop.name);
  return (
    '<div class="bk-shell"' + accentStyle_(shop) + '><header class="bk-head"><h1 class="bk-title">' + escapeHtml(name) + "</h1></header>" +
    renderError(state) + '<main class="bk-main">' + stepHtml_(state) + "</main></div>"
  );
}
