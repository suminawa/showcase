/**
 * 見本の店「ひだまり整体院」（架空）。メニュー「見本を入れる」（Task 7）と scripts/samples.mjs（samples/*.csv）、
 * 見本ページ（api-memory.js、Task 9）が使う。同じ today（"YYYY-MM-DD"）から同じ出力になる（乱数を使わない）。
 */
import { addDays, addMinutes, weekdayOf } from "./dates.js";
import { pad2 } from "./text.js";
import { parseRules, parseClosedDays } from "./rules.js";
import { slotsFor } from "./availability.js";
import { formatReceipt } from "./receipt.js";
import { SETTING_KEYS } from "./settings.js";

export const SHOP_NAME = "ひだまり整体院";

const SAMPLE_PHONE = "045-000-0000";
const SAMPLE_ADDRESS = "みなと市しおかぜ町 1-2-3";
const SAMPLE_NOTICE = "初めての方は、開始の 10 分前にお越しください。";

const SERVICE_FIRST = "初回カウンセリング（60 分）";
const SERVICE_REGULAR = "通常の施術";

/** 予約の見本を入れる曜日（火・水・金・土）。weekdayOf と同じ 0（日）〜6（土） */
const SAMPLE_RESERVATION_WEEKDAYS = [2, 3, 5, 6];
/** 予約の見本で使う架空のお客さま。実在の人物ではない */
const SAMPLE_NAMES = ["山川", "田中", "佐藤", "鈴木", "高橋", "伊藤", "渡辺", "中村"];
/** SAMPLE_NAMES のローマ字（メールの見本用） */
const SAMPLE_NAME_ROMAJI = {
  山川: "yamakawa",
  田中: "tanaka",
  佐藤: "sato",
  鈴木: "suzuki",
  高橋: "takahashi",
  伊藤: "ito",
  渡辺: "watanabe",
  中村: "nakamura",
};
/** SAMPLE_NAMES と同じ並びのご要望。空は「ご要望なし」 */
const SAMPLE_WISHES = ["", "初めての利用です。", "", "", "肩こりが気になります。", "", "腰まわりをお願いします。", ""];
/** 何件目（1 始まり）をキャンセル扱いにするか */
const SAMPLE_CANCELLED_AT = 5;
/** キャンセル用の見本トークン（24 桁の英数）の先頭 23 桁。末尾に 1 桁の連番を足す */
const SAMPLE_TOKEN_PREFIX = "0123456789abcdef0123456";

const RESERVATION_HEADER = [
  "ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話",
  "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用",
];

/** 設定の見本。項目は「初期化」と同じ全部の行を並べ、見本の店の値を入れる（空の項目は既定値で動く） */
function settingsRows_() {
  const values = { 店名: SHOP_NAME, 電話: SAMPLE_PHONE, 住所: SAMPLE_ADDRESS, 注意書き: SAMPLE_NOTICE };
  return [["項目", "値"]].concat(SETTING_KEYS.map((key) => [key, Object.prototype.hasOwnProperty.call(values, key) ? values[key] : ""]));
}

function serviceRows_() {
  return [
    ["サービス", "所要時間", "説明", "受付"],
    [SERVICE_FIRST, "60", "初めての方はこちら", "TRUE"],
    [SERVICE_REGULAR, "45", "2 回目以降の方", "TRUE"],
  ];
}

/**
 * 火水金の 2 本（初回・通常）、土（サービス指定なし）、today + 3 日だけの日付指定（曜日は空）。
 * 枠は「終了」までに終わるものだけを作るので、終了 − 開始はどの行も間隔で割り切れるようにしてある
 * （60 分 × 3・45 分 × 6・45 分 × 9・60 分 × 2）
 */
function ruleRows_(today) {
  return [
    ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"],
    ["火, 水, 金", "", "10:00", "13:00", "60", "1", SERVICE_FIRST],
    ["火, 水, 金", "", "14:00", "18:30", "45", "1", SERVICE_REGULAR],
    ["土", "", "10:00", "16:45", "45", "2", ""],
    ["", addDays(today, 3), "10:00", "12:00", "60", "1", ""],
  ];
}

/** today + 5 日の単発休みと、today + 12〜13 日の期間休み */
function closedRows_(today) {
  return [
    ["日付", "開始日", "終了日", "理由"],
    [addDays(today, 5), "", "", "臨時休業"],
    ["", addDays(today, 12), addDays(today, 13), "研修"],
  ];
}

/** addMinutes などが返す { date, time } を "YYYY-MM-DD HH:mm:ss" の文字にする */
function sampleStampOf_(part) {
  return part.date + " " + part.time + ":00";
}

/** 1 件分の予約行。slot は slotsFor が返す { start, end } のどれか */
function reservationRow_(today, index, date, service, slot, cancelled) {
  const sequence = index + 1;
  const name = SAMPLE_NAMES[index];
  const receivedAt = addMinutes(today, "09:00", index * 5);
  const cancelledAt = cancelled ? sampleStampOf_(addMinutes(receivedAt.date, receivedAt.time, 120)) : "";

  return [
    formatReceipt(today, sequence),
    cancelled ? "キャンセル" : "確定",
    date,
    slot.start,
    slot.end,
    service,
    name,
    SAMPLE_NAME_ROMAJI[name] + "@example.com",
    "045-000-00" + pad2(sequence),
    SAMPLE_WISHES[index],
    sampleStampOf_(receivedAt),
    cancelledAt,
    "",
    "",
    SAMPLE_TOKEN_PREFIX + sequence,
  ];
}

/**
 * today + 1 日から先を 1 日ずつ確かめ、曜日が火・水・金・土で休みでない日を 8 つ選ぶ（休みの日は次の日へ）。
 * 火・水・金は初回カウンセリングと通常の施術を交互に、土はサービスを指定しない（枠の §2-2 のとおり）。
 * rules・closed は parseRules / parseClosedDays を通した後の形
 */
function reservationRows_(today, rules, closed) {
  const rows = [RESERVATION_HEADER];
  const total = SAMPLE_NAMES.length;
  const slotTurn = { first: 0, regular: 0, saturday: 0 };
  let weekdayTurn = 0;
  let date = addDays(today, 1);

  while (rows.length - 1 < total) {
    const weekday = weekdayOf(date);
    if (SAMPLE_RESERVATION_WEEKDAYS.indexOf(weekday) >= 0) {
      const isSaturday = weekday === 6;
      const service = isSaturday ? "" : weekdayTurn % 2 === 0 ? SERVICE_FIRST : SERVICE_REGULAR;
      const slots = slotsFor(date, rules, closed, service);
      // slots が空なら休みの日（isClosed）。この日は数えず、次の日へ進む
      if (slots.length > 0) {
        const turnKey = isSaturday ? "saturday" : service === SERVICE_FIRST ? "first" : "regular";
        const slot = slots[Math.min(slotTurn[turnKey], slots.length - 1)];
        slotTurn[turnKey] += 1;
        const index = rows.length - 1;
        rows.push(reservationRow_(today, index, date, service, slot, index + 1 === SAMPLE_CANCELLED_AT));
        if (!isSaturday) weekdayTurn += 1;
      }
    }
    date = addDays(date, 1);
  }

  return rows;
}

/** 見本の店「ひだまり整体院」の全シート。today（"YYYY-MM-DD"）から作る。同じ today なら同じ出力 */
export function sampleData(today) {
  const rules = ruleRows_(today);
  const closed = closedRows_(today);
  const { rules: parsedRules } = parseRules(rules);
  const { closed: parsedClosed } = parseClosedDays(closed);

  return {
    settings: settingsRows_(),
    rules: rules,
    closed: closed,
    services: serviceRows_(),
    reservations: reservationRows_(today, parsedRules, parsedClosed),
  };
}
