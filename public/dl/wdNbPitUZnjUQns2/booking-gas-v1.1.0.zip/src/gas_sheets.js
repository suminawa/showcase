/**
 * スプレッドシートの読み書き。見出しは名前で探す（人が列を並べ替えても、右に列を足しても壊れない）。
 * 読んだ値は純粋な処理が扱える形（日付は "YYYY-MM-DD"、時刻は "HH:mm"、日時は "yyyy-MM-dd HH:mm:ss"）にそろえる。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { safeCell } from "./mail.js";
import { parseClosedDays, parseRules, parseTime } from "./rules.js";
import { parseServices } from "./services.js";
import { SETTING_KEYS, parseSettings } from "./settings.js";
import { headerIndex, isBlankRow, textOf } from "./text.js";
import { initFailureText } from "./setup.js";

/** 書き込みの権限が無いときに出す 1 文 */
const PERMISSION_TEXT = "このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください";

export const SETTINGS_SHEET = "設定";
export const RULES_SHEET = "枠";
export const CLOSED_SHEET = "休み";
export const SERVICES_SHEET = "サービス";
export const RESERVATIONS_SHEET = "予約";

/** 予約の状態。人が「キャンセル」に直せばその枠は空く（設計書 §2-4） */
export const CONFIRMED_ = "確定";
export const CANCELLED_ = "キャンセル";

/** 作る順と、1 行目に書く見出し。「設定」は項目の名前を縦に並べる */
const SHEET_HEADERS_ = {
  設定: ["項目", "値"],
  枠: ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"],
  休み: ["日付", "開始日", "終了日", "理由"],
  サービス: ["サービス", "所要時間", "説明", "受付"],
  予約: ["ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話", "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用"],
};

/** 日付として読む列・時刻として読む列・日時として読む列（残りは文字のまま） */
const DATE_COLUMNS_ = ["日付"];
const TIME_COLUMNS_ = ["開始", "終了"];
const STAMP_COLUMNS_ = ["受付日時", "キャンセル日時", "リマインド"];

export function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

function sheetOf_(name) {
  return book_().getSheetByName(name);
}

function values_(sheet) {
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getDataRange().getValues();
}

/** 1 行目の見出し（前後の空白を落とした文字） */
function headerOf_(sheet) {
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(textOf);
}

/** 日時のセル。Date で来ることも文字で来ることもある。読めなければ空 */
function stampCell_(value) {
  if (Object.prototype.toString.call(value) === "[object Date]") {
    try {
      return formatStamp(value);
    } catch (error) {
      return "";
    }
  }
  return textOf(value);
}

export function readSettings_() {
  return parseSettings(values_(sheetOf_(SETTINGS_SHEET)));
}

export function readRules_() {
  return parseRules(values_(sheetOf_(RULES_SHEET)));
}

export function readClosed_() {
  return parseClosedDays(values_(sheetOf_(CLOSED_SHEET)));
}

export function readServices_() {
  return parseServices(values_(sheetOf_(SERVICES_SHEET)));
}

/**
 * 「予約」の全行を見出し名のキーで返す（`_row` はシートの行番号。1 から数える）。
 * 空の行は飛ばす。日付・時刻・日時は文字にそろえるので、空きの計算とメール文がそのまま使える
 */
export function readReservations_() {
  const values = values_(sheetOf_(RESERVATIONS_SHEET));
  const rows = [];
  if (values.length < 2) return rows;
  const header = values[0].map(textOf);

  for (let r = 1; r < values.length; r += 1) {
    if (isBlankRow(values[r])) continue;
    const record = { _row: r + 1 };
    for (let c = 0; c < header.length; c += 1) {
      const name = header[c];
      if (name === "") continue;
      const cell = values[r][c];
      if (DATE_COLUMNS_.indexOf(name) >= 0) {
        const date = toDateKey(cell);
        record[name] = date === null ? "" : date;
      } else if (TIME_COLUMNS_.indexOf(name) >= 0) {
        const time = parseTime(cell);
        record[name] = time === null ? "" : time;
      } else if (STAMP_COLUMNS_.indexOf(name) >= 0) {
        record[name] = stampCell_(cell);
      } else {
        record[name] = textOf(cell);
      }
    }
    rows.push(record);
  }
  return rows;
}

/** シートを取り、無ければ作って見出しを書く */
export function ensureSheet_(name) {
  const book = book_();
  let sheet = book.getSheetByName(name);
  const made = !sheet;
  if (made) sheet = book.insertSheet(name);
  if (sheet.getLastRow() === 0) {
    const header = SHEET_HEADERS_[name];
    if (name === SETTINGS_SHEET) {
      // 設定は「項目」と「値」の 2 列に、項目の名前を縦に並べる（値は空のまま＝既定値）
      const rows = [header].concat(SETTING_KEYS.map((key) => [key, ""]));
      sheet.getRange(1, 1, rows.length, 2).setValues(rows);
    } else {
      sheet.getRange(1, 1, 1, header.length).setValues([header]);
    }
    sheet.setFrozenRows(1);
  }
  return sheet;
}

/** 5 つのシートと見出しを用意する。新しく作ったシートの名前を返す */
export function ensureSheets_() {
  const made = [];
  const names = Object.keys(SHEET_HEADERS_);
  for (let i = 0; i < names.length; i += 1) {
    if (!sheetOf_(names[i])) made.push(names[i]);
    ensureSheet_(names[i]);
  }
  return made;
}

/** 予約 1 件を末尾に足す。record は見出し名のキー。シートの行番号を返す */
export function appendReservation_(record) {
  const sheet = ensureSheet_(RESERVATIONS_SHEET);
  const header = headerOf_(sheet);
  const source = record === null || record === undefined ? {} : record;
  const row = header.map((name) => {
    const value = Object.prototype.hasOwnProperty.call(source, name) ? source[name] : "";
    return safeCell(value === null || value === undefined ? "" : String(value));
  });
  sheet.appendRow(row);
  return sheet.getLastRow();
}

/** fields にある見出しの列だけ書き換える（触らない列はそのまま残す） */
export function updateReservation_(rowNumber, fields) {
  const sheet = ensureSheet_(RESERVATIONS_SHEET);
  const header = headerOf_(sheet);
  const source = fields === null || fields === undefined ? {} : fields;
  const names = Object.keys(source);
  for (let i = 0; i < names.length; i += 1) {
    const at = headerIndex(header, names[i]);
    if (at < 0) continue;
    const value = source[names[i]];
    sheet.getRange(rowNumber, at + 1, 1, 1).setValues([[safeCell(value === null || value === undefined ? "" : String(value))]]);
  }
}

/** 2 次元配列の行の長さをそろえる（setValues は長さの違う行を受け取らない） */
function squared_(values) {
  const rows = Array.isArray(values) ? values : [];
  let width = 0;
  for (let i = 0; i < rows.length; i += 1) width = Math.max(width, rows[i].length);
  return rows.map((row) => {
    const line = row.map((cell) => safeCell(cell === null || cell === undefined ? "" : String(cell)));
    while (line.length < width) line.push("");
    return line;
  });
}

/** シートの中身を入れ替える（見出しも含めて書き直す） */
function replaceBlock_(name, values) {
  const sheet = ensureSheet_(name);
  const rows = squared_(values);
  if (rows.length === 0) return;
  sheet.clearContents();
  sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
  sheet.setFrozenRows(1);
}

/**
 * 見本の店を流し込む（sample は samples.js の sampleData が返したもの）。
 * 設定・枠・休み・サービスは入れ替え、予約は今ある行の後ろに足す。
 * 返り値の lastId は足した予約の最後の受付番号（続きから振るために覚えておく）
 */
export function writeSamples_(sample) {
  const source = sample === null || sample === undefined ? {} : sample;
  ensureSheets_();
  replaceBlock_(SETTINGS_SHEET, source.settings);
  replaceBlock_(RULES_SHEET, source.rules);
  replaceBlock_(CLOSED_SHEET, source.closed);
  replaceBlock_(SERVICES_SHEET, source.services);

  const sheet = ensureSheet_(RESERVATIONS_SHEET);
  const header = headerOf_(sheet);
  const rows = Array.isArray(source.reservations) ? source.reservations.slice(1) : [];
  const sampleHeader = Array.isArray(source.reservations) && source.reservations.length > 0 ? source.reservations[0].map(textOf) : [];
  const idAt = headerIndex(sampleHeader, "ID");
  let lastId = "";
  for (let i = 0; i < rows.length; i += 1) {
    const row = header.map((name) => {
      const at = headerIndex(sampleHeader, name);
      const value = at < 0 ? "" : rows[i][at];
      return safeCell(value === null || value === undefined ? "" : String(value));
    });
    sheet.appendRow(row);
    if (idAt >= 0) lastId = textOf(rows[i][idAt]);
  }
  return { reservations: rows.length, lastId: lastId };
}

/**
 * 初期化と「設定を確かめる」が読むもの。読むだけで、何も書かない（シートも作らない）。
 * sheets には 5 枚のうち、あるものだけを載せる。today は "YYYY-MM-DD"
 */
export function readSetupSnapshot_(today) {
  const book = book_();
  const sheets = {};
  const names = Object.keys(SHEET_HEADERS_);
  for (let i = 0; i < names.length; i += 1) {
    const sheet = book.getSheetByName(names[i]);
    if (sheet) sheets[names[i]] = values_(sheet);
  }
  return { timeZone: book.getSpreadsheetTimeZone(), today: today, sheets: sheets, hasTrigger: false, calendar: "none", appUrl: "" };
}

/** 権限の例外を敬体の 1 文に言い換える。ほかはそのまま */
export function initPermissionError_(error) {
  const message = String(error && error.message ? error.message : error);
  if (/permission|権限|does not have|not have access|protected|保護/i.test(message)) return new Error(PERMISSION_TEXT);
  return error;
}

/**
 * check.js の planInit が決めたものを足す。既にあるセルには 1 つも書かない。
 * 設定の行 → シート（作る・空のシートに書く）→ 見出し（1 行目のいまの右端の右）の順。
 * ensureSheet_（予約の書き込みでも呼ばれる）は変えず、初期化だけがここを通る。
 */
export function applyInit_(plan) {
  const book = book_();
  const done = [];
  try {
    const settingRows = plan.appendSettings.rows;
    if (settingRows.length > 0) {
      const sheet = book.getSheetByName(plan.appendSettings.sheet);
      sheet.getRange(sheet.getLastRow() + 1, 1, settingRows.length, 2).setValues(squared_(settingRows));
      done.push("「" + plan.appendSettings.sheet + "」に " + settingRows.length + " 行を足しました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "設定への書き込み", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.createSheets.length; i += 1) {
      const made = plan.createSheets[i];
      const sheet = made.exists === true ? book.getSheetByName(made.name) : book.insertSheet(made.name);
      const rows = squared_(made.rows);
      sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
      if (made.freeze === true) sheet.setFrozenRows(1);
      done.push(made.exists === true ? "空だった「" + made.name + "」シートに見出しを書きました" : "「" + made.name + "」シートを作りました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "シートの作成", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.appendHeaders.length; i += 1) {
      const entry = plan.appendHeaders[i];
      const sheet = book.getSheetByName(entry.sheet);
      const start = sheet.getLastColumn() + 1;
      const last = start + entry.names.length - 1;
      if (last > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), last - sheet.getMaxColumns());
      sheet.getRange(1, start, 1, entry.names.length).setValues([entry.names]);
      done.push("「" + entry.sheet + "」シートの見出しに足しました: " + entry.names.join("、"));
    }
  } catch (error) {
    throw new Error(initFailureText(done, "見出しの追記", initPermissionError_(error)));
  }
}
