/**
 * メールを 1 通送る。1 日の上限に達していたら送らない（設計書 §6）。
 * 姉妹キット（フォーム受付キット）のメール送信と同じ作り。送れたかどうかを返すので、
 * 完了画面で「メールは届いていません」と正直に出せる。
 */
import { textOf } from "./text.js";

/** 今日あと送れるメールの数。読めなければ 1 通ぶんは残っているものとして進む */
export function remainingQuota_() {
  try {
    return MailApp.getRemainingDailyQuota();
  } catch (error) {
    Logger.log("予約ページ: 残りの送信可能数を読めませんでした: " + error);
    return 1;
  }
}

/** 送れたら true。宛先が空・上限に達した・送信が失敗したときは false（予約そのものは止めない） */
export function sendMail_(to, subject, body, fromName) {
  const address = textOf(to);
  if (address === "") {
    Logger.log("予約ページ: 宛先が空のため、メールを送りませんでした");
    return false;
  }
  if (remainingQuota_() <= 0) {
    Logger.log("予約ページ: MailApp の 1 日の上限に達したため、メールを送りませんでした");
    return false;
  }
  try {
    const options = { to: address, subject: textOf(subject), body: body === null || body === undefined ? "" : String(body) };
    const name = textOf(fromName);
    if (name !== "") options.name = name;
    MailApp.sendEmail(options);
    return true;
  } catch (error) {
    Logger.log("予約ページ: メールを送れませんでした: " + error);
    return false;
  }
}
