/**
 * Web アプリの入口（doGet）と、画面から google.script.run で呼ぶ api_*（5 つ）。
 * 流れは「引数を検査 → 純粋な処理 → シートの読み書き」。誤りは敬体の Error を投げる（画面の赤い帯に出る）。
 * カレンダー・メール・通知の失敗は握って、予約そのものは成立させる（設計書 §2-6）。
 */
import { calendarDays, cancelAllowed, isBookable, remainingFor, slotsFor } from "./availability.js";
import { eventFor } from "./calendar.js";
import { toDateKey } from "./dates.js";
import { buildCancelMail, buildConfirmMail, buildOwnerMail } from "./mail.js";
import { buildNotifyText } from "./message.js";
import { nextReceipt } from "./receipt.js";
import { isToken, tokenFromUuid } from "./token.js";
import { escapeHtml, politeError, textOf } from "./text.js";
import { validateReservation } from "./validate.js";
import { nowStamp_, ownerEmail_, readLastId_, saveLastId_, withLock_ } from "./gas_store.js";
import { CANCELLED_, CONFIRMED_, appendReservation_, readClosed_, readReservations_, readRules_, readServices_, readSettings_, updateReservation_ } from "./gas_sheets.js";
import { createEvent_, deleteEvent_ } from "./gas_calendar.js";
import { remainingQuota_, sendMail_ } from "./gas_mail.js";
import { notifyAll_ } from "./gas_notify.js";

/** 予約 1 件で送るメールの数（確認・店への知らせ・前日のリマインド）。残り枠がこれを切ったら確認メールを止める */
const MAIL_PER_RESERVATION_ = 3;
/** 見えない欄（honeypot）が埋まっていたときに返す受付番号。何も書かない */
const DECOY_ID_ = "—";
/** 設定・枠・休み・サービスに誤りがあるときに、お客さまの画面へ出す 1 文（中身の様子は出さない） */
const BOOT_STOPPED_TEXT_ = "ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。";
/** こちらで用意していない誤りが起きたときに、お客さまの画面へ出す 1 文（中身の様子は出さない） */
const UNEXPECTED_TEXT_ = "ただいま処理できませんでした。しばらくしてからお試しください。";

/**
 * api_* の本体を包む。お客さまに見せてよいのは、こちらで用意した敬体の誤り（politeError）だけ。
 * それ以外（権限・通信・思いがけない不具合）は実行ログに残し、当たりさわりのない 1 文に置き換える。
 * GAS の例外はスプレッドシートの ID を文に含むことがあるので、そのまま画面に出さない（設計書 §7）
 */
function publicly_(action) {
  try {
    return action();
  } catch (error) {
    if (error !== null && error !== undefined && error.expected === true) throw error;
    Logger.log("予約ページ: 思いがけない誤り: " + error);
    throw new Error(UNEXPECTED_TEXT_);
  }
}

/** 設定・枠・休み・サービスをまとめて読む（4 つの誤りも 1 つにまとめる） */
function readAll_() {
  const settingsRead = readSettings_();
  const rulesRead = readRules_();
  const closedRead = readClosed_();
  const servicesRead = readServices_();
  return {
    settings: settingsRead.settings,
    rules: rulesRead.rules,
    closed: closedRead.closed,
    services: servicesRead.services,
    errors: settingsRead.errors.concat(rulesRead.errors, closedRead.errors, servicesRead.errors),
  };
}

/**
 * 誤りが 1 つでもあれば受付を止める（画面だけでなく、機械からの求めも断る）。
 * どこが誤っているかはお店だけが見る実行ログに残し、お客さまには中立の 1 文をお返しする
 */
function stopIfBroken_(errors) {
  if (errors.length === 0) return;
  Logger.log("予約ページ: 設定に直すところがあります:\n" + errors.join("\n"));
  throw politeError(BOOT_STOPPED_TEXT_);
}

/** 外に出る処理を包む。失敗しても予約は止めず、実行ログに残す */
export function safely_(label, action, fallback) {
  try {
    return action();
  } catch (error) {
    Logger.log("予約ページ: " + label + ": " + error);
    return fallback;
  }
}

/** 公開した Web アプリの URL。まだ公開されていなければ空 */
export function appUrl_() {
  try {
    return textOf(ScriptApp.getService().getUrl());
  } catch (error) {
    return "";
  }
}

/** キャンセル用の URL。公開前は空（メールには URL を載せない） */
export function cancelUrl_(token) {
  const url = appUrl_();
  return url === "" ? "" : url + "?cancel=" + textOf(token);
}

/** 予約が入ったことを知らせる先。設定「連絡先メール」が空なら所有者 */
function noticeTo_(settings) {
  const contact = textOf(settings.contactEmail);
  return contact === "" ? ownerEmail_() : contact;
}

/** 画面に渡す店の情報 */
function shopOf_(settings) {
  return {
    name: textOf(settings.shopName),
    phone: textOf(settings.phone),
    address: textOf(settings.address),
    notice: textOf(settings.notice),
    themeColor: textOf(settings.themeColor),
    phoneRequired: settings.phoneRequired === true,
    dateFormat: textOf(settings.dateFormat),
    cancelHours: settings.cancelHours,
    leadHours: settings.leadHours,
  };
}

/** 受付中のサービスだけを画面の形にする */
function activeServices_(services) {
  const out = [];
  for (let i = 0; i < services.length; i += 1) {
    const service = services[i];
    if (service.active !== true) continue;
    out.push({ name: service.name, minutes: service.minutes, description: service.description });
  }
  return out;
}

/** 枠の一覧から開始の時刻が一致するものを探す。無ければ null */
function findSlot_(slots, start) {
  for (let i = 0; i < slots.length; i += 1) if (slots[i].start === start) return slots[i];
  return null;
}

/** 合い言葉で予約を 1 件探す。無ければ null */
function findByToken_(reservations, token) {
  for (let i = 0; i < reservations.length; i += 1) {
    if (textOf(reservations[i]["キャンセル用"]) === token) return reservations[i];
  }
  return null;
}

/** 検査の誤り（項目ごとに 1 つ）から、画面に出す 1 文を選ぶ */
function firstErrorOf_(errors) {
  const names = Object.keys(errors);
  return names.length === 0 ? "入力をご確認ください" : errors[names[0]];
}

/** <head> の終わりの直前に差し込む（画面の JS より先に動かすため）。head が無ければ先頭に付ける */
function injectHead_(html, tag) {
  const text = String(html);
  const at = text.indexOf("</head>");
  return at < 0 ? tag + text : text.slice(0, at) + tag + text.slice(at);
}

/** 予約ページ。`?cancel=<合い言葉>` で開かれたときは、画面がキャンセルの確認から始められるように合い言葉を渡す */
export function doGet(e) {
  const settings = readSettings_().settings;
  const out = HtmlService.createHtmlOutputFromFile("App")
    .setTitle(textOf(settings.shopName))
    .addMetaTag("viewport", "width=device-width, initial-scale=1")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);

  const token = e && e.parameter ? textOf(e.parameter.cancel) : "";
  // 合い言葉は 24 桁の英数だけ。形が違うものは差し込まない（escapeHtml は念のため）
  if (isToken(token)) {
    out.setContent(injectHead_(out.getContent(), '<script>window.__BOOKING_CANCEL__ = "' + escapeHtml(token) + '";</script>'));
  }
  return out;
}

/**
 * 画面の読み込みで 1 回呼ぶ。設定・サービス・日ごとの状態をまとめて返す。
 * 設定や枠に誤りがあれば、お客さまには当たりさわりのない 1 文だけを返し、日ごとの状態は空にする
 * （どこが誤っているかは実行ログとメニュー「設定を確かめる」でお店にだけお伝えする）。
 * days はサービスを選んでいないとき、daysByService は受付中のサービスごとに数えたもの
 */
export function api_bootstrap() {
  return publicly_(function () {
    const stamp = nowStamp_();
    const read = readAll_();
    const settings = read.settings;
    const services = activeServices_(read.services);

    const bootstrap = { shop: shopOf_(settings), services: services, days: [], daysByService: {}, today: stamp.slice(0, 10), errors: [] };
    if (read.errors.length > 0) {
      // 誤りの中身はお店だけが見る。お客さまの画面には出さない（設計書 §7）
      Logger.log("予約ページ: 設定に直すところがあります:\n" + read.errors.join("\n"));
      bootstrap.errors = [BOOT_STOPPED_TEXT_];
      return bootstrap;
    }

    const now = stamp.slice(0, 16);
    const reservations = readReservations_();
    // サービスを選ぶ前のぶん（サービス名の無い枠だけ）と、受付中のサービスごとのぶん
    bootstrap.days = calendarDays(now, settings, read.rules, read.closed, reservations, "");
    for (let i = 0; i < services.length; i += 1) {
      const name = services[i].name;
      bootstrap.daysByService[name] = calendarDays(now, settings, read.rules, read.closed, reservations, name);
    }
    return bootstrap;
  });
}

/**
 * 選ばれた日の、いま受け付けられる枠と残りの数。締切を過ぎた枠は一覧から外す。
 * 設定・枠・休み・サービスに誤りがあるあいだは、api_bootstrap と同じ 1 文で断る
 * （既に開いている画面や、機械からの求めも通さないため）
 */
export function api_availability(date, service) {
  return publicly_(function () {
    const key = toDateKey(textOf(date));
    if (key === null) throw politeError("日付をお選びください");

    const stamp = nowStamp_();
    const now = stamp.slice(0, 16);
    const read = readAll_();
    stopIfBroken_(read.errors);
    const slots = remainingFor(slotsFor(key, read.rules, read.closed, textOf(service)), readReservations_(), key);

    const out = [];
    for (let i = 0; i < slots.length; i += 1) {
      if (!isBookable(key, slots[i].start, now, read.settings)) continue;
      out.push({ start: slots[i].start, end: slots[i].end, remaining: slots[i].remaining });
    }
    return { date: key, slots: out };
  });
}

/**
 * 予約を 1 件受け付ける。
 * 見えない欄 → 入力の検査 → ロックの中で（同じメールの数・枠と残りを数え直す → 行を足す）→
 * ロックを解いてから カレンダー・確認メール・店への知らせ・通知。外の失敗は握る
 */
export function api_reserve(input) {
  return publicly_(function () {
    return reserve_(input);
  });
}

function reserve_(input) {
  const raw = input === null || input === undefined ? {} : input;

  // 見えない欄が埋まっていたら、成功したように見せて何も書かない（設計書 §7）。シートを読む前、いちばん先に検査する
  if (textOf(raw.website) !== "") {
    return { ok: true, id: DECOY_ID_, date: textOf(raw.date), start: textOf(raw.start), end: textOf(raw.start), service: textOf(raw.service), mailSent: false };
  }

  const stamp = nowStamp_();
  const now = stamp.slice(0, 16);
  const today = stamp.slice(0, 10);
  const read = readAll_();
  // 設定・枠・休み・サービスに誤りがあるあいだは、書き込みまで進まない（画面と同じところで止める）
  stopIfBroken_(read.errors);
  const settings = read.settings;
  const services = read.services;

  const checked = validateReservation(raw, { settings: settings, services: services });
  if (!checked.ok) throw politeError(firstErrorOf_(checked.errors));
  const value = checked.value;

  const made = withLock_(function () {
    const reservations = readReservations_();

    // 数えるのはこれからのご予約だけ。済んだご来店は数えない（常連の方が予約できなくならないように）
    let same = 0;
    for (let i = 0; i < reservations.length; i += 1) {
      if (textOf(reservations[i]["状態"]) !== CONFIRMED_) continue;
      if (textOf(reservations[i]["日付"]) < today) continue;
      if (textOf(reservations[i]["メール"]).toLowerCase() === value.email.toLowerCase()) same += 1;
    }
    if (same >= settings.maxPerEmail) throw politeError("同じメールアドレスでのご予約は " + settings.maxPerEmail + " 件までです。");

    const slots = remainingFor(slotsFor(value.date, read.rules, read.closed, value.service), reservations, value.date);
    const slot = findSlot_(slots, value.start);
    if (slot === null || !isBookable(value.date, value.start, now, settings)) {
      throw politeError("選ばれた時間は、受付を終了しました。別の時間をお選びください。");
    }
    if (slot.remaining <= 0) throw politeError("選ばれた時間は、ただいま満席になりました。別の時間をお選びください。");

    const id = nextReceipt(readLastId_(), today);
    saveLastId_(id);
    const token = tokenFromUuid(Utilities.getUuid());
    const record = {
      "ID": id,
      "状態": CONFIRMED_,
      "日付": value.date,
      "開始": value.start,
      "終了": slot.end,
      "サービス": value.service,
      "お名前": value.name,
      "メール": value.email,
      "電話": value.phone,
      "ご要望": value.note,
      "受付日時": stamp,
      "キャンセル日時": "",
      "カレンダー": "",
      "リマインド": "",
      "キャンセル用": token,
    };
    return { record: record, row: appendReservation_(record), token: token };
  });

  const reservation = made.record;

  // カレンダー（設定が空なら登録しない。登録できたら予定の ID を行に書き戻す）。予定を組み立てる段も safely_ の中で
  const eventId = safely_("予定を登録できませんでした", () => createEvent_(settings, eventFor(settings, services, reservation)), "");
  if (eventId !== "") {
    reservation["カレンダー"] = eventId;
    safely_("予定の ID を書き戻せませんでした", () => updateReservation_(made.row, { "カレンダー": eventId }), null);
  }

  // お客さまへの確認メール（1 日の残り枠が 3 を切ったら送らない。完了画面で正直に出す）。文面の組み立ても safely_ の中で
  let mailSent = false;
  const remaining = remainingQuota_();
  if (remaining >= MAIL_PER_RESERVATION_) {
    mailSent = safely_(
      "確認メールを送れませんでした",
      () => {
        const confirm = buildConfirmMail(settings, reservation, cancelUrl_(made.token));
        return sendMail_(reservation["メール"], confirm.subject, confirm.body, settings.shopName);
      },
      false
    );
  } else {
    Logger.log("予約ページ: 1 日のメールの上限が近いため、確認メールを送りませんでした（残り " + remaining + " 通）");
  }

  // 店への知らせ（文面の組み立ても safely_ の中で）
  safely_(
    "店への知らせを送れませんでした",
    () => {
      const owner = buildOwnerMail(settings, reservation);
      return sendMail_(noticeTo_(settings), owner.subject, owner.body, settings.shopName);
    },
    false
  );

  // 通知（Slack / Discord / LINE）。文面の組み立ても safely_ の中で
  safely_("通知を送れませんでした", () => notifyAll_(settings, buildNotifyText("reserve", settings, reservation)), null);

  return { ok: true, id: reservation["ID"], date: reservation["日付"], start: reservation["開始"], end: reservation["終了"], service: reservation["サービス"], mailSent: mailSent };
}

/** キャンセルの URL で開かれた画面に出す 1 件。合い言葉が違う・無いときは found だけ返す */
export function api_cancelInfo(token) {
  return publicly_(function () {
    const key = textOf(token);
    if (!isToken(key)) return { found: false };

    const stamp = nowStamp_();
    const settings = readSettings_().settings;
    const found = findByToken_(readReservations_(), key);
    if (found === null) return { found: false };

    const status = textOf(found["状態"]);
    return {
      found: true,
      reservation: {
        id: textOf(found["ID"]),
        date: textOf(found["日付"]),
        start: textOf(found["開始"]),
        end: textOf(found["終了"]),
        service: textOf(found["サービス"]),
        name: textOf(found["お名前"]),
        status: status,
      },
      canCancel: status === CONFIRMED_ && cancelAllowed(found, stamp.slice(0, 16), settings),
      phone: textOf(settings.phone),
    };
  });
}

/** 予約をキャンセルする。状態とキャンセル日時 → カレンダーの予定を消す → お客さまへメール → 通知 */
export function api_cancel(token) {
  return publicly_(function () {
    return cancel_(token);
  });
}

function cancel_(token) {
  const key = textOf(token);
  if (!isToken(key)) throw politeError("キャンセルの URL が正しくありません。メールの URL をもう一度お確かめください。");

  const stamp = nowStamp_();
  const now = stamp.slice(0, 16);
  const settings = readSettings_().settings;

  const cancelled = withLock_(function () {
    const found = findByToken_(readReservations_(), key);
    if (found === null) throw politeError("ご予約が見つかりませんでした。メールの URL をもう一度お確かめください。");
    if (textOf(found["状態"]) !== CONFIRMED_) throw politeError("このご予約はすでにキャンセルされています。");
    if (!cancelAllowed(found, now, settings)) {
      throw politeError("キャンセルの受付は開始の " + settings.cancelHours + " 時間前までです。お電話でご連絡ください。");
    }
    updateReservation_(found._row, { "状態": CANCELLED_, "キャンセル日時": stamp });
    found["状態"] = CANCELLED_;
    return found;
  });

  deleteEvent_(settings, cancelled["カレンダー"]);

  // キャンセルのメール（文面の組み立ても safely_ の中で）
  safely_(
    "キャンセルのメールを送れませんでした",
    () => {
      const mail = buildCancelMail(settings, cancelled);
      return sendMail_(cancelled["メール"], mail.subject, mail.body, settings.shopName);
    },
    false
  );

  // 通知（Slack / Discord / LINE）。文面の組み立ても safely_ の中で
  safely_("通知を送れませんでした", () => notifyAll_(settings, buildNotifyText("cancel", settings, cancelled)), null);

  return { ok: true, id: textOf(cancelled["ID"]) };
}
