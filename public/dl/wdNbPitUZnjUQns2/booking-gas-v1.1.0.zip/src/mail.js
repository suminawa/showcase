/**
 * 確認・リマインド・キャンセルのメール文と、店への知らせメールを作る。
 * 差し込みは fillTemplate（{お名前} など）。メールは文字だけで、HTML にはしない。
 */
import { longDateOf, shortDateOf } from "./dates.js";
import { textOf } from "./text.js";

/**
 * シートのセルに書く前に、数式と誤認される文字列と、数として読まれて形の崩れる文字列を無害にする。
 * ' を前置するのは次の 3 つ。空はそのまま（設計書 §7）
 *   1. 先頭が = + - @ かタブ・CR・LF（数式・コマンドと誤認される）
 *   2. 先頭が 0 の数字だけの文字列（"09012345678" が 9012345678 になって先頭の 0 が消える）
 *   3. 16 桁以上の数字だけの文字列（表計算の数は 15 桁までしか正しく持てない）
 * 日付（"2026-09-22"）と時刻（"11:00"）はここに当てはまらないので、これまでどおり日付・時刻のセルとして書く
 * （並べ替えや絞り込みに使えるようにするため。読み戻す toDateKey / parseTime は Date でも文字でも読める）
 */
export function safeCell(value) {
  const text = value === null || value === undefined ? "" : String(value);
  if (text === "") return text;
  const numberLike = /^0\d+$/.test(text) || (/^\d+$/.test(text) && text.length > 15);
  return /^[=+\-@\t\r\n]/.test(text) || numberLike ? "'" + text : text;
}

/**
 * テンプレの {お名前} のような差し込みを置き換える。
 * vars に無い名前は、そのままの字（{…}）で残す
 */
export function fillTemplate(template, vars) {
  const map = vars === null || vars === undefined ? {} : vars;
  const text = template === null || template === undefined ? "" : String(template);
  return text.replace(/\{([^{}\n]+)\}/g, function (whole, name) {
    return Object.prototype.hasOwnProperty.call(map, name) ? String(map[name]) : whole;
  });
}

/**
 * メールの差し込み用の値。settings.dateFormat に沿って日付を作り、曜日を付ける。
 * reservation はシートの見出し名をキーにした 1 件（ID 状態 日付 開始 終了 サービス お名前 メール 電話 ご要望）
 */
export function varsFor(settings, reservation, cancelUrl) {
  const s = settings === null || settings === undefined ? {} : settings;
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const service = textOf(row["サービス"]);
  return {
    "お名前": textOf(row["お名前"]),
    "日付": longDateOf(row["日付"], s.dateFormat),
    "時間": textOf(row["開始"]) + "〜" + textOf(row["終了"]),
    "サービス": service === "" ? "ご予約" : service,
    "店名": textOf(s.shopName),
    "電話": textOf(s.phone),
    "住所": textOf(s.address),
    "受付番号": textOf(row["ID"]),
    "キャンセルURL": cancelUrl === null || cancelUrl === undefined ? "" : String(cancelUrl),
  };
}

/** 確認メール（設定「確認メールの件名・本文」に差し込む） */
export function buildConfirmMail(settings, reservation, cancelUrl) {
  const s = settings === null || settings === undefined ? {} : settings;
  const vars = varsFor(s, reservation, cancelUrl);
  return { subject: fillTemplate(s.confirmSubject, vars), body: fillTemplate(s.confirmBody, vars) };
}

/** 前日リマインドのメール（設定「リマインドの件名・本文」に差し込む） */
export function buildRemindMail(settings, reservation, cancelUrl) {
  const s = settings === null || settings === undefined ? {} : settings;
  const vars = varsFor(s, reservation, cancelUrl);
  return { subject: fillTemplate(s.remindSubject, vars), body: fillTemplate(s.remindBody, vars) };
}

/** 店（連絡先メール）へ送る、予約が入ったことの知らせ */
export function buildOwnerMail(settings, reservation) {
  const s = settings === null || settings === undefined ? {} : settings;
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const vars = varsFor(s, row, "");
  const lines = [
    "ご予約が入りました。",
    "",
    "日時: " + vars["日付"] + " " + vars["時間"],
    "サービス: " + vars["サービス"],
    "お名前: " + vars["お名前"] + " 様",
    "メール: " + textOf(row["メール"]),
    "電話: " + textOf(row["電話"]),
    "ご要望: " + textOf(row["ご要望"]),
    "受付番号: " + vars["受付番号"],
  ];
  const subject =
    "ご予約が入りました: " + shortDateOf(textOf(row["日付"])) + textOf(row["開始"]) + " " + textOf(row["お名前"]) + " 様";
  return { subject: subject, body: lines.join("\n") };
}

/** お客さまへ送る、キャンセルの確認メール */
export function buildCancelMail(settings, reservation) {
  const s = settings === null || settings === undefined ? {} : settings;
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const vars = varsFor(s, row, "");
  const lines = [
    vars["お名前"] + " 様",
    "",
    "ご予約をキャンセルしました。",
    "",
    "日時: " + vars["日付"] + " " + vars["時間"],
    "内容: " + vars["サービス"],
    "",
    vars["店名"],
    vars["電話"],
    vars["住所"],
  ];
  return { subject: fillTemplate("ご予約をキャンセルしました（{店名}）", vars), body: lines.join("\n") };
}
