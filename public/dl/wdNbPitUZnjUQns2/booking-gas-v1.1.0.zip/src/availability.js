/**
 * 空きの計算。「枠」「休み」「予約」と設定から、その日に出す時間と残りの数、カレンダーの日ごとの状態を出す。
 *
 * 日付は "YYYY-MM-DD"、時刻は "HH:mm"、日時は "YYYY-MM-DD HH:mm"（Asia/Tokyo）の文字だけで計算する。
 * 「いま」は必ず now（"YYYY-MM-DD HH:mm"）を引数で受け取り、このファイルからは時計を読まない。
 */
import { addDays, addMinutes, minutesOf, timeOf, toDateKey, toDateTimeKey, weekdayOf } from "./dates.js";
import { isClosed, parseTime } from "./rules.js";
import { DEFAULT_SETTINGS } from "./settings.js";
import { textOf } from "./text.js";

/** 枠を埋めるのは「確定」の予約だけ。人が状態を「キャンセル」に直せばその枠は空く */
const CONFIRMED_STATE_ = "確定";

/** 時刻をキーにした覚え書きを引くとき、Object の元からある名前（constructor など）と取り違えないようにする */
function has_(map, key) {
  return Object.prototype.hasOwnProperty.call(map, key);
}

/** 数として使える値ならそのまま、そうでなければ既定値 */
function numberOr_(value, fallback) {
  return typeof value === "number" && isFinite(value) ? value : fallback;
}

/** 設定の数を 1 つ読む。渡されていない・数でないときは既定値（設定シートの誤りで計算が壊れないように） */
function settingNumber_(settings, key) {
  const source = settings === null || settings === undefined ? {} : settings;
  return numberOr_(source[key], DEFAULT_SETTINGS[key]);
}

/** "YYYY-MM-DD" と "HH:mm" を、比べられる 1 つの文字 "YYYY-MM-DD HH:mm" にする */
function stampOf_(dateKey, time) {
  return dateKey + " " + time;
}

/** 開始の leadHours 時間前（締切）。日をまたぐときは日付も繰り下がる */
function deadlineOf_(dateKey, time, hours) {
  const at = addMinutes(dateKey, time, -hours * 60);
  return stampOf_(at.date, at.time);
}

/**
 * その日に使う「枠」の行を選ぶ。
 * 同じ日付の「日付」の行があればその日はそれだけを使い、曜日の行は見ない（設計書 §2-2）
 */
function rulesForDay_(dateKey, rules) {
  const list = Array.isArray(rules) ? rules : [];
  const dated = [];
  const weekly = [];
  const weekday = weekdayOf(dateKey);

  for (let i = 0; i < list.length; i += 1) {
    const rule = list[i];
    if (rule === null || rule === undefined) continue;
    if (rule.date !== null && rule.date !== undefined && rule.date !== "") {
      if (rule.date === dateKey) dated.push(rule);
      continue;
    }
    if (Array.isArray(rule.weekdays) && rule.weekdays.indexOf(weekday) >= 0) weekly.push(rule);
  }

  return dated.length > 0 ? dated : weekly;
}

/**
 * サービスの絞り込み。サービス名の無い行はいつでも出し、サービス名の付いた行はそのサービスが選ばれているときだけ出す
 * （サービスを選んでいないときに、特定のサービス専用の枠を出さないため）
 */
function matchesService_(rule, serviceName) {
  const bound = textOf(rule.service);
  if (bound === "") return true;
  return serviceName !== "" && bound === serviceName;
}

/**
 * その日に出す枠 → `{ start, end, capacity }[]`（開始の早い順）。休みの日は空。
 * 開始から終了まで間隔ごとに区切り、枠の終わりは開始＋間隔。
 * 枠は「終了」までに終わるものだけを作る（開始＋間隔が終了を過ぎる枠は作らない）ので、
 * 終了 − 開始が間隔で割り切れないときは、終わりに余りの時間が残る。
 * 別の行に同じ開始があれば 1 つにまとめ、定員を足して終わりは遅い方にする
 */
export function slotsFor(dateKey, rules, closed, serviceName) {
  const date = toDateKey(dateKey);
  if (date === null) return [];
  if (isClosed(closed, date)) return [];

  const name = textOf(serviceName);
  const dayRules = rulesForDay_(date, rules);
  const found = [];
  const indexByStart = {};

  for (let i = 0; i < dayRules.length; i += 1) {
    const rule = dayRules[i];
    if (!matchesService_(rule, name)) continue;

    const interval = numberOr_(rule.interval, 0);
    const startMinutes = minutesOf(rule.start);
    const endMinutes = minutesOf(rule.end);
    if (interval <= 0 || !isFinite(startMinutes) || !isFinite(endMinutes)) continue;

    const capacity = Math.max(0, numberOr_(rule.capacity, 1));
    // 枠の終わり（開始＋間隔）が「終了」に収まるあいだだけ作る
    for (let at = startMinutes; at + interval <= endMinutes; at += interval) {
      const start = timeOf(at);
      const finish = at + interval;
      const seen = has_(indexByStart, start) ? indexByStart[start] : undefined;
      if (seen === undefined) {
        indexByStart[start] = found.length;
        found.push({ minutes: at, finish: finish, capacity: capacity });
      } else {
        found[seen].capacity += capacity;
        if (finish > found[seen].finish) found[seen].finish = finish;
      }
    }
  }

  found.sort((a, b) => a.minutes - b.minutes);

  const slots = [];
  for (let i = 0; i < found.length; i += 1) {
    const start = timeOf(found[i].minutes);
    // 枠は「終了」（最大 23:59）までに終わるので日はまたがないが、念のため addMinutes で丸める
    const end = addMinutes(date, start, found[i].finish - found[i].minutes).time;
    slots.push({ start: start, end: end, capacity: found[i].capacity });
  }
  return slots;
}

/**
 * 枠に残りの数を足す → `{ start, end, capacity, remaining }[]`。
 * その日・その開始の「確定」の予約の数を定員から引く（0 より下にはしない）
 */
export function remainingFor(slots, reservations, dateKey) {
  const list = Array.isArray(slots) ? slots : [];
  const date = toDateKey(dateKey);
  const rows = Array.isArray(reservations) ? reservations : [];
  const taken = {};

  if (date !== null) {
    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i];
      if (row === null || row === undefined) continue;
      if (textOf(row["状態"]) !== CONFIRMED_STATE_) continue;
      if (toDateKey(row["日付"]) !== date) continue;
      const start = parseTime(row["開始"]);
      if (start === null) continue;
      taken[start] = (has_(taken, start) ? taken[start] : 0) + 1;
    }
  }

  const out = [];
  for (let i = 0; i < list.length; i += 1) {
    const slot = list[i];
    const capacity = Math.max(0, numberOr_(slot.capacity, 0));
    const used = has_(taken, slot.start) ? taken[slot.start] : 0;
    out.push({ start: slot.start, end: slot.end, capacity: capacity, remaining: Math.max(0, capacity - used) });
  }
  return out;
}

/**
 * その枠をいま受け付けられるか。
 * 「何日先まで」の範囲（今日を 1 日目とする）の外は false。開始の「何時間前まで」を過ぎていても false
 */
export function isBookable(dateKey, start, now, settings) {
  const date = toDateKey(dateKey);
  const time = parseTime(start);
  const nowStamp = toDateTimeKey(now);
  if (date === null || time === null || nowStamp === null) return false;

  const today = nowStamp.slice(0, 10);
  const daysAhead = settingNumber_(settings, "daysAhead");
  if (date < today) return false;
  if (date > addDays(today, daysAhead - 1)) return false;

  return nowStamp < deadlineOf_(date, time, settingNumber_(settings, "leadHours"));
}

/**
 * その日のカレンダーに出す状態。slots は remainingFor を通した枠。
 * closed（枠が無い・休み）／past（受けられる枠が無い）／full（残り 0）／few（残りのある枠が 2 つ以下）／open
 */
export function daySummary(dateKey, slots, now, settings) {
  const list = Array.isArray(slots) ? slots : [];
  if (list.length === 0) return "closed";

  let bookable = 0;
  let withRoom = 0;
  let total = 0;
  for (let i = 0; i < list.length; i += 1) {
    const slot = list[i];
    if (!isBookable(dateKey, slot.start, now, settings)) continue;
    bookable += 1;
    const remaining = Math.max(0, numberOr_(slot.remaining, 0));
    total += remaining;
    if (remaining > 0) withRoom += 1;
  }

  if (bookable === 0) return "past";
  if (total === 0) return "full";
  return withRoom <= 2 ? "few" : "open";
}

/** 今日から「何日先まで」の日ごとの `{ date, status }`。画面のカレンダーはこれを並べる */
export function calendarDays(now, settings, rules, closed, reservations, serviceName) {
  const nowStamp = toDateTimeKey(now);
  if (nowStamp === null) return [];

  const today = nowStamp.slice(0, 10);
  const daysAhead = settingNumber_(settings, "daysAhead");
  const days = [];
  for (let i = 0; i < daysAhead; i += 1) {
    const date = addDays(today, i);
    const slots = remainingFor(slotsFor(date, rules, closed, serviceName), reservations, date);
    days.push({ date: date, status: daySummary(date, slots, now, settings) });
  }
  return days;
}

/** ページからキャンセルできるか。開始の「キャンセルは何時間前まで」より前なら true */
export function cancelAllowed(reservation, now, settings) {
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const date = toDateKey(row["日付"]);
  const time = parseTime(row["開始"]);
  const nowStamp = toDateTimeKey(now);
  if (date === null || time === null || nowStamp === null) return false;

  return nowStamp < deadlineOf_(date, time, settingNumber_(settings, "cancelHours"));
}
