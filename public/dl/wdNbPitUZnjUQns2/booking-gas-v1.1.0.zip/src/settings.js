/**
 * 「設定」シート（項目・値の 2 列）を読む。空欄は既定値、知らない行は無視する。
 * 誤りは敬体の文で集め、誤りのあった項目だけ既定値のまま返す（他の項目はそのまま読み込む）。
 */
import { integerInRange } from "./dates.js";
import { boolOf, textOf } from "./text.js";

/** 設定シートに並べるキー。README.ja.md と samples/設定.csv はこの並びと一致させる */
/** 設定の項目名をそろえる: 全角空白を半角に、連続する空白を 1 つに、英字の前後の空白の抜けを補う */
function normalizeKey_(key) {
  const flat = key.replace(/[\u3000\s]+/g, " ").trim();
  const found = SETTING_KEYS.find((k) => k.replace(/ /g, "") === flat.replace(/ /g, ""));
  return found === undefined ? flat : found;
}

/** 設定の項目名を parseSettings と同じそろえ方にする（初期化と「設定を確かめる」の突き合わせに使う） */
export function settingKeyOf(key) {
  return normalizeKey_(String(key === null || key === undefined ? "" : key));
}

export const SETTING_KEYS = [
  "店名",
  "連絡先メール",
  "電話",
  "住所",
  "何日先まで",
  "何時間前まで",
  "キャンセルは何時間前まで",
  "電話を必須にする",
  "同じメールの予約数",
  "注意書き",
  "確認メールの件名",
  "確認メールの本文",
  "リマインドの件名",
  "リマインドの本文",
  "リマインドの時刻",
  "カレンダー ID",
  "Slack Webhook URL",
  "Discord Webhook URL",
  "LINE チャネルアクセストークン",
  "LINE 送信先 ID",
  "テーマ色",
  "日付の書式",
];

/** 既定の確認メール本文（設計書 §4）。{お名前} などの差し込みは mail.js が埋める */
export const DEFAULT_CONFIRM_BODY = [
  "{お名前} 様",
  "",
  "ご予約を受け付けました。",
  "",
  "日時: {日付} {時間}",
  "内容: {サービス}",
  "受付番号: {受付番号}",
  "",
  "ご都合が悪くなった場合は、下の URL からキャンセルできます。",
  "{キャンセルURL}",
  "",
  "{店名}",
  "{電話}",
  "{住所}",
].join("\n");

/** 既定のリマインド本文。差し込みは確認メールと同じ */
export const DEFAULT_REMIND_BODY = [
  "{お名前} 様",
  "",
  "明日のご予約のご案内です。",
  "",
  "日時: {日付} {時間}",
  "内容: {サービス}",
  "受付番号: {受付番号}",
  "",
  "ご都合が悪くなった場合は、下の URL からキャンセルできます。",
  "{キャンセルURL}",
  "",
  "{店名}",
  "{電話}",
  "{住所}",
].join("\n");

export const DEFAULT_SETTINGS = {
  shopName: "予約ページ",
  contactEmail: "",
  phone: "",
  address: "",
  daysAhead: 30,
  leadHours: 24,
  cancelHours: 24,
  phoneRequired: false,
  maxPerEmail: 3,
  notice: "",
  confirmSubject: "ご予約を受け付けました（{店名}）",
  confirmBody: DEFAULT_CONFIRM_BODY,
  remindSubject: "明日のご予約のご案内（{店名}）",
  remindBody: DEFAULT_REMIND_BODY,
  remindHour: 18,
  calendarId: "",
  slackUrl: "",
  discordUrl: "",
  lineToken: "",
  lineTo: "",
  themeColor: "#2f6f5e",
  dateFormat: "yyyy-MM-dd",
};

/** 「日付の書式」に使える値 */
const SETTINGS_DATE_FORMATS = ["yyyy-MM-dd", "yyyy/MM/dd"];
/** 「テーマ色」の形。# + 3 桁か 6 桁の 16 進 */
const THEME_COLOR_PATTERN = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

/**
 * rows は「設定」シートの 2 次元配列。1 行目が見出し（1 列目が「項目」）でも、無くてもよい。
 * 空欄は既定値、知らない項目は無視する。
 */
export function parseSettings(rows) {
  const settings = Object.assign({}, DEFAULT_SETTINGS);
  const errors = [];
  const list = Array.isArray(rows) ? rows : [];

  for (let i = 0; i < list.length; i += 1) {
    const row = Array.isArray(list[i]) ? list[i] : [];
    // 項目名は、全角の空白や空白の抜けがあっても読めるようにそろえる（「カレンダー　ID」「カレンダーID」→「カレンダー ID」）
    const key = normalizeKey_(textOf(row[0]));
    if (i === 0 && key === "項目") continue;
    const value = row.length > 1 ? row[1] : "";
    const raw = textOf(value);

    if (key === "店名") {
      if (raw !== "") settings.shopName = raw;
    } else if (key === "連絡先メール") {
      if (raw !== "") {
        if (raw.indexOf("@") < 0) errors.push("booking: 設定「連絡先メール」の形式をご確認ください");
        else settings.contactEmail = raw;
      }
    } else if (key === "電話") {
      if (raw !== "") settings.phone = raw;
    } else if (key === "住所") {
      if (raw !== "") settings.address = raw;
    } else if (key === "何日先まで") {
      if (raw !== "") {
        const n = integerInRange(raw, 1, 180);
        if (n === null) errors.push("booking: 設定「何日先まで」は 1〜180 にしてください");
        else settings.daysAhead = n;
      }
    } else if (key === "何時間前まで") {
      if (raw !== "") {
        const n = integerInRange(raw, 0, 720);
        if (n === null) errors.push("booking: 設定「何時間前まで」は 0〜720 にしてください");
        else settings.leadHours = n;
      }
    } else if (key === "キャンセルは何時間前まで") {
      if (raw !== "") {
        const n = integerInRange(raw, 0, 720);
        if (n === null) errors.push("booking: 設定「キャンセルは何時間前まで」は 0〜720 にしてください");
        else settings.cancelHours = n;
      }
    } else if (key === "電話を必須にする") {
      settings.phoneRequired = boolOf(value, DEFAULT_SETTINGS.phoneRequired);
    } else if (key === "同じメールの予約数") {
      if (raw !== "") {
        const n = integerInRange(raw, 1, 20);
        if (n === null) errors.push("booking: 設定「同じメールの予約数」は 1〜20 にしてください");
        else settings.maxPerEmail = n;
      }
    } else if (key === "注意書き") {
      if (raw !== "") settings.notice = raw;
    } else if (key === "確認メールの件名") {
      if (raw !== "") settings.confirmSubject = raw;
    } else if (key === "確認メールの本文") {
      if (raw !== "") settings.confirmBody = raw;
    } else if (key === "リマインドの件名") {
      if (raw !== "") settings.remindSubject = raw;
    } else if (key === "リマインドの本文") {
      if (raw !== "") settings.remindBody = raw;
    } else if (key === "リマインドの時刻") {
      if (raw !== "") {
        const n = integerInRange(raw, 0, 23);
        if (n === null) errors.push("booking: 設定「リマインドの時刻」は 0〜23 にしてください");
        else settings.remindHour = n;
      }
    } else if (key === "カレンダー ID") {
      if (raw !== "") settings.calendarId = raw;
    } else if (key === "Slack Webhook URL") {
      if (raw !== "") settings.slackUrl = raw;
    } else if (key === "Discord Webhook URL") {
      if (raw !== "") settings.discordUrl = raw;
    } else if (key === "LINE チャネルアクセストークン") {
      if (raw !== "") settings.lineToken = raw;
    } else if (key === "LINE 送信先 ID") {
      if (raw !== "") settings.lineTo = raw;
    } else if (key === "テーマ色") {
      if (raw !== "") {
        if (!THEME_COLOR_PATTERN.test(raw)) errors.push("booking: 設定「テーマ色」は #2f6f5e のような形にしてください");
        else settings.themeColor = raw;
      }
    } else if (key === "日付の書式") {
      if (raw !== "") {
        if (SETTINGS_DATE_FORMATS.indexOf(raw) < 0) errors.push("booking: 設定「日付の書式」は yyyy-MM-dd か yyyy/MM/dd にしてください");
        else settings.dateFormat = raw;
      }
    }
  }

  return { settings: settings, errors: errors };
}
