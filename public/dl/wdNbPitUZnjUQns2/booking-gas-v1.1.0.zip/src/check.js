/**
 * 初期化（何を足すか）と「設定を確かめる」（何を直すか・これから何が起きるか）を決める。純粋な処理。
 * 受け取るのはシートの値をそのまま写した snapshot（gas_sheets.js の readSetupSnapshot_ が作る）:
 *   { timeZone, today: "YYYY-MM-DD", sheets: { シート名: 2 次元配列 }, hasTrigger, calendar, appUrl }
 * 無いシートは sheets に載せない。空のシート（1 行も無い）は []。
 * calendar は "none"（設定「カレンダー ID」が空）/ "ok" / "missing"（開けない）。
 * hasTrigger・calendar・appUrl は「設定を確かめる」のときだけ使う。
 * ここで足す検査は、メニューの「設定を確かめる」だけに出す。予約ページ（api_bootstrap）の受付は止めない。
 */
import { parseClosedDays, parseRules } from "./rules.js";
import { findService, parseServices } from "./services.js";
import { SETTING_KEYS, parseSettings, settingKeyOf } from "./settings.js";
import { errorAt, isBlankRow, textOf } from "./text.js";
import { missingHeaders, missingSettingRows } from "./setup.js";

/** 公開の手順（初期化の次の一歩・URL の案内・未公開のお知らせに添える） */
export const DEPLOY_STEPS = "「デプロイ」→「新しいデプロイ」→ 種類「ウェブアプリ」→ 次のユーザーとして実行「自分」・アクセスできるユーザー「全員」で公開してください。";

/** 作る順と、1 行目に書く見出し。gas_sheets.js の SHEET_HEADERS_ と同じ（bundle_setup.test が突き合わせる） */
export const SHEET_HEADERS = {
  設定: ["項目", "値"],
  枠: ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"],
  休み: ["日付", "開始日", "終了日", "理由"],
  サービス: ["サービス", "所要時間", "説明", "受付"],
  予約: ["ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話", "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用"],
};

/** 初期化で足す設定の行。値は空のまま（1.0 の初期化と見本と同じ。空の項目は既定値で動く） */
const BLANK_SETTING_ROWS = SETTING_KEYS.map((key) => [key, ""]);

/** 初期化でシートを作ったときに、次の一歩の前に置く文 */
const INIT_INTRO = "「設定」「枠」「休み」「サービス」をご記入のうえ、「設定を確かめる」を実行してください。まず動かしてみるなら、メニューの「見本を入れる」が早いです。";

/** 受け付ける時間の行は 5 行まで出す */
const SUMMARY_RULE_LIMIT = 5;

const WEEKDAY_KANJI = ["日", "月", "火", "水", "木", "金", "土"];

function valuesOf_(snapshot, name) {
  const values = snapshot.sheets[name];
  return values === undefined ? [] : values;
}

function missingSettingsOf_(values) {
  return missingSettingRows(values, BLANK_SETTING_ROWS, settingKeyOf);
}

/** 初期化で足すもの。返り値は setup.js の Plan に、次の一歩の文 nextStep を足したもの */
export function planInit(snapshot) {
  const plan = { createSheets: [], appendHeaders: [], appendSettings: { sheet: "設定", rows: [], blank: true }, notes: [], nextStep: "" };
  const names = Object.keys(SHEET_HEADERS);
  for (let i = 0; i < names.length; i += 1) {
    const name = names[i];
    const header = SHEET_HEADERS[name];
    const values = snapshot.sheets[name];
    if (values === undefined || values.length === 0) {
      const rows = name === "設定" ? [header].concat(BLANK_SETTING_ROWS) : [header];
      plan.createSheets.push({ name: name, rows: rows, freeze: true, exists: values !== undefined });
    } else if (name === "設定") {
      // 設定は項目と値の 2 列。見出しの行は足さず、足りない項目の行だけを最終行の下に足す
      plan.appendSettings.rows = missingSettingsOf_(values);
    } else {
      const missing = missingHeaders(values[0], header);
      if (missing.length > 0) plan.appendHeaders.push({ sheet: name, names: missing });
    }
  }
  if (snapshot.timeZone !== "Asia/Tokyo") plan.notes.push(timeZoneText_(snapshot.timeZone));
  plan.nextStep = (plan.createSheets.length > 0 ? INIT_INTRO + "\n" : "") + "次は " + DEPLOY_STEPS;
  return plan;
}

function timeZoneText_(timeZone) {
  return "スプレッドシートのタイムゾーンが " + timeZone + " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと予約の日時がずれます）。";
}

/**
 * 設定を確かめるの「直すところ」。1.0 の誤り（設定・枠・休み・サービスの読み取り）を先に、1.1 の検査を後ろに並べる。
 * 文はすべて booking: で始める（1.0 の決まり）。
 */
export function findProblems(snapshot) {
  const settings = parseSettings(valuesOf_(snapshot, "設定"));
  const rules = parseRules(valuesOf_(snapshot, "枠"));
  const closed = parseClosedDays(valuesOf_(snapshot, "休み"));
  const services = parseServices(valuesOf_(snapshot, "サービス"));
  const problems = settings.errors.concat(rules.errors, closed.errors, services.errors);

  if (snapshot.timeZone !== "Asia/Tokyo") problems.push("booking: " + timeZoneText_(snapshot.timeZone));

  const names = Object.keys(SHEET_HEADERS);
  for (let i = 0; i < names.length; i += 1) {
    const name = names[i];
    const values = snapshot.sheets[name];
    if (values === undefined) {
      problems.push("booking: 「" + name + "」シートがありません。メニュー「初期化」を実行してください。");
    } else if (values.length === 0) {
      problems.push("booking: 「" + name + "」シートが空です。メニュー「初期化」を実行すると見出しを書きます。");
    } else if (name !== "設定") {
      const missing = missingHeaders(values[0], SHEET_HEADERS[name]);
      for (let j = 0; j < missing.length; j += 1) {
        const after = missing[j] === "キャンセル用" ? "（無いままだと、確認メールのキャンセル URL がどのご予約にも当たりません）" : "";
        problems.push("booking: " + name + "シートの 1 行目に「" + missing[j] + "」がありません。「初期化」を実行すると右端に足します" + after + "。");
      }
    }
  }

  const ruleValues = snapshot.sheets["枠"];
  if (ruleValues !== undefined && ruleValues.length > 0 && ruleValues.slice(1).every(isBlankRow)) {
    problems.push("booking: 枠シートに受け付ける時間が 1 行もありません。予約ページに空きが出ません。README の 3 章のとおりに書くか、メニュー「見本を入れる」で見本を入れてください。");
  }
  for (let i = 0; i < rules.rules.length; i += 1) {
    const rule = rules.rules[i];
    if (rule.service !== "" && findService(services.services, rule.service) === null) {
      problems.push(errorAt("枠", rule.row, "サービス「" + rule.service + "」はサービスシートにありません。サービスシートの名前と同じ字にしてください。"));
    }
  }
  if (services.services.length > 0 && services.services.every((service) => service.active !== true)) {
    problems.push("booking: サービスシートの受付がすべて FALSE です。お客さまが選べるサービスがありません。");
  }

  // URL とトークンは人に見せない鍵なので、文には出さない
  const s = settings.settings;
  const hooks = [
    ["Slack Webhook URL", s.slackUrl],
    ["Discord Webhook URL", s.discordUrl],
  ];
  for (let i = 0; i < hooks.length; i += 1) {
    const url = textOf(hooks[i][1]);
    if (url !== "" && url.indexOf("https://") !== 0) problems.push("booking: 設定「" + hooks[i][0] + "」は https:// で始まる URL です。設定シートのその行を確かめてください。");
  }
  if (textOf(s.lineToken) === "" && textOf(s.lineTo) !== "") problems.push("booking: 設定「LINE 送信先 ID」が書いてありますが、「LINE チャネルアクセストークン」が空です。");
  if (textOf(s.lineToken) !== "" && textOf(s.lineTo) === "") problems.push("booking: 設定「LINE チャネルアクセストークン」が書いてありますが、「LINE 送信先 ID」が空です。");
  if (snapshot.calendar === "missing") {
    problems.push("booking: 設定「カレンダー ID」のカレンダーを開けません。ID の写し間違いか、このアカウントに共有されていない可能性があります。主カレンダーなら primary と書いてください。");
  }
  return problems;
}

/** 誤りではないが知っておくとよいこと（「ご参考:」の下に並べる） */
export function checkNotes(snapshot) {
  const notes = [];
  const settings = snapshot.sheets["設定"];
  if (settings !== undefined && settings.length > 0) {
    const missing = missingSettingsOf_(settings);
    if (missing.length > 0) {
      notes.push("「設定」シートに" + missing.map((row) => "「" + row[0] + "」").join("") + "の行がありません。空の項目と同じく、既定値で動きます。「初期化」を実行すると、空の行を足します。");
    }
  }
  if (snapshot.hasTrigger === false) notes.push("前日のリマインドはまだ動いていません。メニュー「リマインドのトリガーを作る」を実行してください。");
  if (textOf(snapshot.appUrl) === "") notes.push("予約ページはまだ公開されていません。" + DEPLOY_STEPS);
  return notes;
}

/** 枠の 1 行を「火・水・金 10:00〜13:00（60 分ごと・定員 1・通常の施術）」の形にする */
function ruleLine_(rule) {
  const when = rule.date !== null ? rule.date : rule.weekdays.map((day) => WEEKDAY_KANJI[day]).join("・");
  const parts = [rule.interval + " 分ごと", "定員 " + rule.capacity];
  if (rule.service !== "") parts.push(rule.service);
  return when + " " + rule.start + "〜" + rule.end + "（" + parts.join("・") + "）";
}

/** 直すところが無いときの「これから起きること」。findProblems が 0 件のときだけ呼ぶ */
export function summaryLines(snapshot) {
  const s = parseSettings(valuesOf_(snapshot, "設定")).settings;
  const rules = parseRules(valuesOf_(snapshot, "枠")).rules;
  const closed = parseClosedDays(valuesOf_(snapshot, "休み")).closed;
  const services = parseServices(valuesOf_(snapshot, "サービス")).services;

  const lines = ["店名: " + s.shopName];
  const shown = rules.slice(0, SUMMARY_RULE_LIMIT).map(ruleLine_);
  if (rules.length > SUMMARY_RULE_LIMIT) shown.push("ほか " + (rules.length - SUMMARY_RULE_LIMIT) + " 行");
  for (let i = 0; i < shown.length; i += 1) lines.push((i === 0 ? "受け付ける時間: " : "　　　　　　　　") + shown[i]);
  lines.push("受付の期間: " + s.daysAhead + " 日先まで、開始の " + s.leadHours + " 時間前まで。キャンセルは " + s.cancelHours + " 時間前まで");

  const coming = closed.filter((period) => period.to >= snapshot.today).sort((a, b) => (a.from < b.from ? -1 : a.from > b.from ? 1 : 0));
  if (closed.length === 0) lines.push("休み: ありません");
  else if (coming.length === 0) lines.push("休み: " + closed.length + " 件（これから先の休みはありません）");
  else lines.push("休み: " + closed.length + " 件（次は " + coming[0].from + (coming[0].to === coming[0].from ? "" : "〜" + coming[0].to) + "）");

  const active = services.filter((service) => service.active === true);
  lines.push(services.length === 0 ? "サービス: 使っていません（お客さまはサービスを選ばずにご予約いただきます）" : "サービス: 受付中 " + active.length + " つ（" + active.map((service) => service.name).join("、") + "）");
  lines.push("お知らせメール: " + (textOf(s.contactEmail) === "" ? "所有者のアドレスに送ります（設定「連絡先メール」が空のため）" : "「" + s.contactEmail + "」に送ります"));
  lines.push("カレンダー: " + (textOf(s.calendarId) === "" ? "登録しません（設定「カレンダー ID」が空です）" : "「" + s.calendarId + "」に登録します"));
  const notify = [];
  if (textOf(s.slackUrl) !== "") notify.push("Slack");
  if (textOf(s.discordUrl) !== "") notify.push("Discord");
  if (textOf(s.lineToken) !== "" && textOf(s.lineTo) !== "") notify.push("LINE");
  lines.push("通知: " + (notify.length === 0 ? "使っていません" : notify.join("・") + " に送ります"));
  lines.push("前日のリマインド: 毎日 " + s.remindHour + " 時（トリガー: " + (snapshot.hasTrigger === true ? "作ってあります" : "まだ作っていません") + "）");
  lines.push("予約ページ: " + (textOf(snapshot.appUrl) === "" ? "まだ公開していません" : "公開済み"));
  return lines;
}
