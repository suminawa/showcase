/**
 * 「枠」シート（受け付ける曜日・時間・間隔・定員・サービス）と「休み」シート（受け付けない日）を読む。
 * 誤りは敬体の文で `booking: ` から始めて集め、誤りのあった行は rules / closed に含めない。
 */
import { integerInRange, jstTimeOf, minutesOf, toDateKey, toHalfWidth } from "./dates.js";
import { errorAt, headerIndex, isBlankRow, pad2, textOf } from "./text.js";

/** 曜日の文字 → 0（日）〜6（土） */
export const WEEKDAY_WORDS = { 日: 0, 月: 1, 火: 2, 水: 3, 木: 4, 金: 5, 土: 6 };

/** 「平日」「土日」「毎日」のように、1 語でまとめて複数の曜日を指す言い方 */
const WEEKDAY_GROUPS_ = {
  平日: [1, 2, 3, 4, 5],
  土日: [0, 6],
  毎日: [0, 1, 2, 3, 4, 5, 6],
};

/**
 * 曜日の文字を読む。「火, 水, 金」「平日」「土日」「毎日」「月曜」「月・火」「月曜日」などを受ける。
 * 区切りはカンマ・読点・中黒・空白。語の末尾の `曜日` `曜` は落とす。知らない語があれば null。
 * 返す配列は重複のない昇順（0〜6）
 */
export function parseWeekdays(text) {
  const normalized = toHalfWidth(textOf(text));
  if (normalized === "") return null;
  const tokens = normalized.split(/[,、・\s]+/).filter((token) => token !== "");
  if (tokens.length === 0) return null;

  const found = new Set();
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    if (Object.prototype.hasOwnProperty.call(WEEKDAY_GROUPS_, token)) {
      const group = WEEKDAY_GROUPS_[token];
      for (let j = 0; j < group.length; j += 1) found.add(group[j]);
      continue;
    }
    const stripped = token.replace(/曜日$|曜$/, "");
    if (!Object.prototype.hasOwnProperty.call(WEEKDAY_WORDS, stripped)) return null;
    found.add(WEEKDAY_WORDS[stripped]);
  }
  return Array.from(found).sort((a, b) => a - b);
}

/**
 * 時刻を "HH:mm" にする。"10:00" "9:30" "10時" "10時30分" "10:00:00"、全角の書き方、
 * セルの Date（時刻だけ使う。Asia/Tokyo）を受ける。読めなければ null
 */
export function parseTime(value) {
  if (value === null || value === undefined) return null;
  if (Object.prototype.toString.call(value) === "[object Date]") {
    // 時刻だけのセルも Date で来るので、dates.js の JST 変換をそのまま使う
    return jstTimeOf(value);
  }

  const text = toHalfWidth(textOf(value));
  if (text === "") return null;

  let matched = text.match(/^([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?$/);
  if (matched) return pad2(Number(matched[1])) + ":" + matched[2];

  matched = text.match(/^([01]?\d|2[0-3])時(?:([0-5]?\d)分)?$/);
  if (matched) return pad2(Number(matched[1])) + ":" + pad2(matched[2] === undefined ? 0 : Number(matched[2]));

  return null;
}

/**
 * 「枠」シートの 2 次元配列（1 行目が見出し）→ { rules, errors }。
 * 空行は飛ばす。誤りのあった行は rules に含めない
 */
export function parseRules(values) {
  const rows = Array.isArray(values) ? values : [];
  const rules = [];
  const errors = [];
  if (rows.length < 2) return { rules: rules, errors: errors };

  const header = Array.isArray(rows[0]) ? rows[0] : [];
  const col = {
    weekday: headerIndex(header, "曜日"),
    date: headerIndex(header, "日付"),
    start: headerIndex(header, "開始"),
    end: headerIndex(header, "終了"),
    interval: headerIndex(header, "間隔"),
    capacity: headerIndex(header, "定員"),
    service: headerIndex(header, "サービス"),
  };

  for (let i = 1; i < rows.length; i += 1) {
    const row = Array.isArray(rows[i]) ? rows[i] : [];
    if (isBlankRow(row)) continue;
    const rowNum = i + 1;
    let ok = true;

    const weekdayText = textOf(row[col.weekday]);
    const dateRaw = row[col.date];
    const dateText = textOf(dateRaw);
    let weekdays = [];
    let date = null;

    if (weekdayText === "" && dateText === "") {
      errors.push(errorAt("枠", rowNum, "曜日か日付のどちらかをご記入ください"));
      ok = false;
    } else if (dateText !== "") {
      // 日付があれば曜日より優先する。weekdays は空のまま
      date = toDateKey(dateRaw);
      if (date === null) {
        errors.push(errorAt("枠", rowNum, "日付を読み取れません"));
        ok = false;
      }
    } else {
      weekdays = parseWeekdays(weekdayText);
      if (weekdays === null) {
        errors.push(errorAt("枠", rowNum, "曜日を読み取れません"));
        ok = false;
        weekdays = [];
      }
    }

    const start = parseTime(row[col.start]);
    if (start === null) {
      errors.push(errorAt("枠", rowNum, "開始を読み取れません"));
      ok = false;
    }
    const end = parseTime(row[col.end]);
    if (end === null) {
      errors.push(errorAt("枠", rowNum, "終了を読み取れません"));
      ok = false;
    }
    if (start !== null && end !== null && minutesOf(end) <= minutesOf(start)) {
      errors.push(errorAt("枠", rowNum, "終了は開始より後にしてください"));
      ok = false;
    }

    const intervalText = textOf(row[col.interval]);
    let interval = null;
    if (intervalText === "") {
      errors.push(errorAt("枠", rowNum, "間隔は 5〜480 の整数にしてください"));
      ok = false;
    } else {
      interval = integerInRange(row[col.interval], 5, 480);
      if (interval === null) {
        errors.push(errorAt("枠", rowNum, "間隔は 5〜480 の整数にしてください"));
        ok = false;
      }
    }

    const capacityText = textOf(row[col.capacity]);
    let capacity = 1;
    if (capacityText !== "") {
      const n = integerInRange(row[col.capacity], 0, 99);
      if (n === null) {
        errors.push(errorAt("枠", rowNum, "定員は 0〜99 の整数にしてください"));
        ok = false;
      } else {
        capacity = n;
      }
    }

    const service = textOf(row[col.service]);

    if (ok) {
      rules.push({
        row: rowNum,
        weekdays: weekdays,
        date: date,
        start: start,
        end: end,
        interval: interval,
        capacity: capacity,
        service: service,
      });
    }
  }

  return { rules: rules, errors: errors };
}

/**
 * 「休み」シートの 2 次元配列（1 行目が見出し）→ { closed, errors }。
 * `日付` があればその日だけ、無ければ `開始日`・`終了日` の期間にする
 */
export function parseClosedDays(values) {
  const rows = Array.isArray(values) ? values : [];
  const closed = [];
  const errors = [];
  if (rows.length < 2) return { closed: closed, errors: errors };

  const header = Array.isArray(rows[0]) ? rows[0] : [];
  const col = {
    date: headerIndex(header, "日付"),
    from: headerIndex(header, "開始日"),
    to: headerIndex(header, "終了日"),
  };

  for (let i = 1; i < rows.length; i += 1) {
    const row = Array.isArray(rows[i]) ? rows[i] : [];
    if (isBlankRow(row)) continue;
    const rowNum = i + 1;
    const dateText = textOf(row[col.date]);

    if (dateText !== "") {
      const date = toDateKey(row[col.date]);
      if (date === null) {
        errors.push(errorAt("休み", rowNum, "日付を読み取れません"));
        continue;
      }
      closed.push({ from: date, to: date });
      continue;
    }

    const from = toDateKey(row[col.from]);
    if (from === null) {
      errors.push(errorAt("休み", rowNum, "開始日を読み取れません"));
      continue;
    }
    const to = toDateKey(row[col.to]);
    if (to === null) {
      errors.push(errorAt("休み", rowNum, "終了日を読み取れません"));
      continue;
    }
    if (to < from) {
      errors.push(errorAt("休み", rowNum, "終了日は開始日より後にしてください"));
      continue;
    }
    closed.push({ from: from, to: to });
  }

  return { closed: closed, errors: errors };
}

/** dateKey（"YYYY-MM-DD"）が休みの期間のどれかに入っているか（両端を含む） */
export function isClosed(closed, dateKey) {
  const list = Array.isArray(closed) ? closed : [];
  for (let i = 0; i < list.length; i += 1) {
    const period = list[i] || {};
    if (dateKey >= period.from && dateKey <= period.to) return true;
  }
  return false;
}
