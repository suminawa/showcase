/**
 * Slack / Discord の Webhook と、LINE の push message に 1 通送る。
 * 姉妹キット（フォーム受付キット）の通知と同じ作り。
 * 文は message.js の buildNotifyText が 1,900 字までに収めてあるので、ここでは切り詰めない。
 * 送り先ごとの本文の形（Slack の文字参照、Discord の allowed_mentions）は message.js の buildPayload が作る。
 */
import { buildPayload } from "./message.js";
import { textOf } from "./text.js";

const LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push";

function post_(url, payload, headers) {
  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  if (headers) options.headers = headers;
  const response = UrlFetchApp.fetch(url, options);
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(status + " が返りました: " + String(response.getContentText()).slice(0, 200));
  }
}

export function postSlack_(url, text) {
  post_(url, buildPayload(text, "slack"));
}

export function postDiscord_(url, text) {
  post_(url, buildPayload(text, "discord"));
}

export function pushLine_(token, to, text) {
  post_(LINE_PUSH_URL, buildPayload(text, "line", { lineTo: to }), { Authorization: "Bearer " + token });
}

/** 設定に入っている送り先（空の設定は送らない） */
export function notifyTargets_(config) {
  const source = config === null || config === undefined ? {} : config;
  const targets = [];
  if (textOf(source.slackUrl) !== "") targets.push("slack");
  if (textOf(source.discordUrl) !== "") targets.push("discord");
  if (textOf(source.lineToken) !== "" && textOf(source.lineTo) !== "") targets.push("line");
  return targets;
}

/**
 * 設定の通知先すべてに送る。1 つが失敗しても残りには送り、失敗は実行ログに残す（鍵や URL そのものは残さない）。
 * 返り値: 送れた宛先の数
 */
export function notifyAll_(config, text) {
  const source = config === null || config === undefined ? {} : config;
  const targets = notifyTargets_(source);
  let sent = 0;
  for (let i = 0; i < targets.length; i += 1) {
    const target = targets[i];
    try {
      if (target === "slack") postSlack_(source.slackUrl, text);
      else if (target === "discord") postDiscord_(source.discordUrl, text);
      else if (target === "line") pushLine_(source.lineToken, source.lineTo, text);
      sent += 1;
    } catch (error) {
      Logger.log("予約ページ: " + target + " に送れませんでした: " + error);
    }
  }
  return sent;
}
