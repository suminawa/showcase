/**
 * 予約 1 件から、Google カレンダーに登録する予定の題名・説明・開始/終了を作る。
 * 開始・終了は "yyyy-MM-dd HH:mm"（Asia/Tokyo）の文字のまま返す。Date に直すのは gas_calendar.js の役目
 */
import { addMinutes } from "./dates.js";
import { textOf } from "./text.js";
import { findService } from "./services.js";

/**
 * settings は今のところ使わないが、他の純粋な処理と引数の形をそろえてある。
 * end はサービスの所要時間があれば開始＋所要時間、無ければ枠の終了（reservation の「終了」）
 */
export function eventFor(settings, services, reservation) {
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const serviceName = textOf(row["サービス"]);
  const service = serviceName === "" ? null : findService(services, serviceName);
  const name = textOf(row["お名前"]);
  const title = serviceName === "" ? "予約: " + name + " 様" : "予約: " + name + " 様（" + serviceName + "）";

  const date = textOf(row["日付"]);
  const start = textOf(row["開始"]);
  let endDate = date;
  let endTime = textOf(row["終了"]);
  if (service !== null && typeof service.minutes === "number" && service.minutes > 0) {
    const at = addMinutes(date, start, service.minutes);
    endDate = at.date;
    endTime = at.time;
  }

  const description = [
    "受付番号: " + textOf(row["ID"]),
    "メール: " + textOf(row["メール"]),
    "電話: " + textOf(row["電話"]),
    "ご要望: " + textOf(row["ご要望"]),
  ].join("\n");

  return { title: title, description: description, start: date + " " + start, end: endDate + " " + endTime };
}
