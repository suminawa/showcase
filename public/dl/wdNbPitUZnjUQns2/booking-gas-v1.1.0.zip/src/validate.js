/**
 * 予約フォームの入力を検査する。
 * 値は textOf で前後の空白を落とし、メールと電話は toHalfWidth で半角にする。
 * 誤りは項目ごとに 1 つ、敬体の文で返す（キーは name email phone note date start service）。
 * 画面（demo を含む）でも同じ検査を動かすので、GAS のグローバルには触らない。
 */
import { toHalfWidth } from "./dates.js";
import { textOf } from "./text.js";
import { findService } from "./services.js";

/** 入力の上限（字数） */
export const LIMITS = { name: 40, email: 100, phone: 20, note: 500 };

/**
 * input は画面から届く生の値（{ name, email, phone, note, date, start, service }）。
 * ctx = { settings, services }（services は「サービス」シートの一覧。空でもよい）。
 * 返り値: { ok: true, value } | { ok: false, errors }
 */
export function validateReservation(input, ctx) {
  const row = input === null || input === undefined ? {} : input;
  const context = ctx === null || ctx === undefined ? {} : ctx;
  const settings = context.settings === null || context.settings === undefined ? {} : context.settings;
  const services = Array.isArray(context.services) ? context.services : [];
  const errors = {};

  const name = textOf(row.name);
  if (name === "") errors.name = "お名前をご記入ください";
  else if (name.length > LIMITS.name) errors.name = "お名前は " + LIMITS.name + " 字までにしてください";

  const email = toHalfWidth(textOf(row.email));
  if (email === "") errors.email = "メールアドレスをご記入ください";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = "メールアドレスの形式をご確認ください";
  else if (email.length > LIMITS.email) errors.email = "メールアドレスは " + LIMITS.email + " 字までにしてください";

  const phone = toHalfWidth(textOf(row.phone));
  if (phone === "") {
    if (settings.phoneRequired === true) errors.phone = "電話番号をご記入ください";
  } else if (phone.length > LIMITS.phone) {
    errors.phone = "電話番号は " + LIMITS.phone + " 字までにしてください";
  }

  const note = textOf(row.note);
  if (note.length > LIMITS.note) errors.note = "ご要望は " + LIMITS.note + " 字までにしてください";

  const date = textOf(row.date);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) errors.date = "日付をお選びください";

  const start = textOf(row.start);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(start)) errors.start = "時間をお選びください";

  // サービスが 1 つも登録されていなければ、その項目自体が無いものとして扱う
  let service = textOf(row.service);
  if (services.length > 0) {
    const found = findService(services, service);
    if (!found || found.active !== true) errors.service = "サービスをお選びください";
  } else {
    service = "";
  }

  if (Object.keys(errors).length > 0) return { ok: false, errors: errors };

  return {
    ok: true,
    value: { date: date, start: start, service: service, name: name, email: email, phone: phone, note: note },
  };
}
