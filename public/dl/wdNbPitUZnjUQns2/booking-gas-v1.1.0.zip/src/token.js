/**
 * キャンセル用の合い言葉の形と検査。
 * 生成そのものは GAS 側の役目（getUuid() で作った UUID を渡す）なので、ここでは UUID から作る関数だけを持つ。
 */

/** 合い言葉の形：24 桁の英数字（小文字） */
export const TOKEN_RE = /^[0-9a-f]{24}$/;

/** UUID（"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"）からハイフンを除き、小文字にして先頭 24 桁にする */
export function tokenFromUuid(uuid) {
  const text = String(uuid === null || uuid === undefined ? "" : uuid)
    .replace(/-/g, "")
    .toLowerCase();
  return text.slice(0, 24);
}

/** 値が合い言葉の形をしているか */
export function isToken(value) {
  return typeof value === "string" && TOKEN_RE.test(value);
}
