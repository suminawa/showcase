/**
 * 束ねた 1 本の中で共有する小さな道具。どのファイルからも import して使う（各ファイルで同名の関数を定義しない）。
 */

/**
 * セルや入力の値を、前後の空白を落とした文字にする。null / undefined は ""。
 * 配列やオブジェクトは "" にする（画面から送られた変な値が "[object Object]" として
 * 検査を通り抜けないように。toString が壊れた値で落ちることも防ぐ）。日付のセルは Date で来るので通す
 */
export function textOf(value) {
  if (value === null || value === undefined) return "";
  const kind = typeof value;
  if (kind === "string") return value.trim();
  if (kind === "number" || kind === "boolean" || kind === "bigint") return String(value);
  if (kind !== "object") return "";
  if (Object.prototype.toString.call(value) !== "[object Date]") return "";
  try {
    return String(value).trim();
  } catch (error) {
    return "";
  }
}

/** TRUE / FALSE のほか、はい・いいえ・1・0・○・× も読む。空や読めない字は fallback */
export function boolOf(value, fallback) {
  if (value === true) return true;
  if (value === false) return false;
  const t = textOf(value).toUpperCase();
  if (t === "") return fallback;
  if (t === "TRUE" || t === "1" || t === "はい" || t === "○") return true;
  if (t === "FALSE" || t === "0" || t === "いいえ" || t === "×") return false;
  return fallback;
}

/** 2 桁に揃える */
export function pad2(value) {
  return value < 10 ? "0" + value : String(value);
}

/** 画面に出す前に HTML として安全な文字にする。null / undefined は "" */
export function escapeHtml(value) {
  return String(value === null || value === undefined ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** すべてのセルが空の行か */
export function isBlankRow(row) {
  const cells = Array.isArray(row) ? row : [];
  for (let i = 0; i < cells.length; i += 1) {
    if (textOf(cells[i]) !== "") return false;
  }
  return true;
}

/** 見出し行から列の位置を名前で探す。無ければ -1 */
export function headerIndex(header, name) {
  const row = Array.isArray(header) ? header : [];
  for (let i = 0; i < row.length; i += 1) {
    if (textOf(row[i]) === name) return i;
  }
  return -1;
}

/**
 * お客さまに見せてよい、こちらで用意した敬体の誤り。
 * expected の印が付いたものだけをそのまま画面に出し、それ以外は当たりさわりのない 1 文に置き換える
 */
export function politeError(message) {
  const error = new Error(message);
  error.expected = true;
  return error;
}

/** "booking: ○○シートの N 行目: message" の形にする */
export function errorAt(sheet, row, message) {
  return "booking: " + sheet + "シートの " + row + " 行目: " + message;
}
