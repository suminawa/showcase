/**
 * 通知の文（Slack / Discord / LINE で同じ形。送信そのものは gas_notify.js の役目）。
 * 1,900 字を超える分は切り詰める。電話とメールは載せない（設計書 §7）。
 */
import { shortDateOf } from "./dates.js";
import { textOf } from "./text.js";

/** 通知の本文の上限 */
const NOTIFY_LIMIT_ = 1900;

function truncateNotify_(text) {
  if (text.length <= NOTIFY_LIMIT_) return text;
  return text.slice(0, NOTIFY_LIMIT_ - 1) + "…";
}

/**
 * kind: "reserve" | "cancel"。
 * 例: 【予約】9/19（土）10:00〜11:00 初回カウンセリング 山川 様（受付番号 20260918-001）
 * サービスが空ならその項目を省く。電話・メールは載せない
 */
export function buildNotifyText(kind, settings, reservation) {
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const label = kind === "cancel" ? "キャンセル" : "予約";

  const dateLabel = shortDateOf(textOf(row["日付"]));

  const time = textOf(row["開始"]) + "〜" + textOf(row["終了"]);
  const service = textOf(row["サービス"]);
  const servicePart = service === "" ? "" : service + " ";

  const text =
    "【" + label + "】" + dateLabel + time + " " + servicePart + textOf(row["お名前"]) + " 様（受付番号 " + textOf(row["ID"]) + "）";
  return truncateNotify_(text);
}
