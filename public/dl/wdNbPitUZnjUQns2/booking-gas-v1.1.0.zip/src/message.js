/**
 * 通知の文（Slack / Discord / LINE で同じ形）と、送り先ごとの本文の形。送信そのものは gas_notify.js の役目。
 * 1,900 字を超える分は切り詰める。電話とメールは載せない（設計書 §7）。
 */
import { shortDateOf } from "./dates.js";
import { textOf } from "./text.js";

/** 通知の本文の上限 */
const NOTIFY_LIMIT_ = 1900;

function truncateNotify_(text) {
  if (text.length <= NOTIFY_LIMIT_) return text;
  return text.slice(0, NOTIFY_LIMIT_ - 1) + "…";
}

/** Slack の text では & < > が制御の字（<!channel> や <@U…> の呼び出し・リンク）なので、字のまま送る */
function escapeSlack_(text) {
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * kind: "reserve" | "cancel"。
 * 例: 【予約】9/19（土）10:00〜11:00 初回カウンセリング 山川 様（受付番号 20260918-001）
 * サービスが空ならその項目を省く。電話・メールは載せない
 */
export function buildNotifyText(kind, settings, reservation) {
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const label = kind === "cancel" ? "キャンセル" : "予約";

  const dateLabel = shortDateOf(textOf(row["日付"]));

  const time = textOf(row["開始"]) + "〜" + textOf(row["終了"]);
  const service = textOf(row["サービス"]);
  const servicePart = service === "" ? "" : service + " ";

  const text =
    "【" + label + "】" + dateLabel + time + " " + servicePart + textOf(row["お名前"]) + " 様（受付番号 " + textOf(row["ID"]) + "）";
  return truncateNotify_(text);
}

/**
 * 送り先ごとの本文の形（Slack は text、Discord は content、LINE は push message の中身）。
 * 通知にはお客さまが書いたお名前がそのまま入るので、@everyone や呼び出しとして働かせない:
 * Slack は & < > を文字参照にし、Discord は allowed_mentions を空にする。
 * 文は buildNotifyText が 1,900 字までに収めてから渡すので、ここでは切り詰めない（文字参照を途中で切ることも無い）
 */
export function buildPayload(text, target, options) {
  if (target === "discord") return { content: text, allowed_mentions: { parse: [] } };
  if (target === "line") {
    const to = options === undefined || options === null ? "" : textOf(options.lineTo);
    return { to: to, messages: [{ type: "text", text: text }] };
  }
  return { text: escapeSlack_(text) };
}
