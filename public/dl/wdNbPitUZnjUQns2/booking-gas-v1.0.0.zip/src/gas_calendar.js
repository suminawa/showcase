/**
 * Google カレンダーへの登録と削除。設定「カレンダー ID」が空なら何もしない。
 * 失敗しても予約は成立させたいので、例外は握って ""／false を返し、実行ログに残す（設計書 §2-6）。
 */
import { dateTimeFromKey } from "./dates.js";
import { textOf } from "./text.js";

/** 設定のカレンダー。ID が空・開けないときは null */
function calendarOf_(settings) {
  const id = textOf(settings === null || settings === undefined ? "" : settings.calendarId);
  if (id === "") return null;
  const calendar = CalendarApp.getCalendarById(id);
  if (!calendar) {
    Logger.log("予約ページ: カレンダーが見つかりませんでした（設定「カレンダー ID」をご確認ください）");
    return null;
  }
  return calendar;
}

/** event は calendar.js の eventFor が返したもの。登録できたら予定の ID、できなければ "" */
export function createEvent_(settings, event) {
  try {
    const calendar = calendarOf_(settings);
    if (calendar === null) return "";
    const source = event === null || event === undefined ? {} : event;
    const start = dateTimeFromKey(source.start);
    const end = dateTimeFromKey(source.end);
    if (start === null || end === null) {
      Logger.log("予約ページ: 予定の日時を読み取れなかったため、カレンダーには登録しませんでした");
      return "";
    }
    const made = calendar.createEvent(textOf(source.title), start, end, { description: textOf(source.description) });
    return textOf(made ? made.getId() : "");
  } catch (error) {
    Logger.log("予約ページ: 予定を登録できませんでした: " + error);
    return "";
  }
}

/** 予定を消せたら true。無い・消せないときは false */
export function deleteEvent_(settings, eventId) {
  try {
    const id = textOf(eventId);
    if (id === "") return false;
    const calendar = calendarOf_(settings);
    if (calendar === null) return false;
    const event = calendar.getEventById(id);
    if (!event) {
      Logger.log("予約ページ: 消す予定が見つかりませんでした");
      return false;
    }
    event.deleteEvent();
    return true;
  } catch (error) {
    Logger.log("予約ページ: 予定を消せませんでした: " + error);
    return false;
  }
}
