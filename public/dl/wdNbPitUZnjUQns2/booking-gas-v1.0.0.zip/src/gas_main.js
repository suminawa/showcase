/**
 * スプレッドシートのメニュー「予約ページ」と、前日リマインドの入口（時間主導トリガー）。
 * Web アプリの入口は gas_web.js。dist/Code.gs の先頭に来るファイル。
 */
import { addDays } from "./dates.js";
import { buildConfirmMail, buildRemindMail } from "./mail.js";
import { formatReceipt } from "./receipt.js";
import { SHOP_NAME, sampleData } from "./samples.js";
import { textOf } from "./text.js";
import { nowStamp_, ownerEmail_, saveLastId_ } from "./gas_store.js";
import { CONFIRMED_, RULES_SHEET, SETTINGS_SHEET, book_, ensureSheets_, readClosed_, readReservations_, readRules_, readServices_, readSettings_, updateReservation_, writeSamples_ } from "./gas_sheets.js";
import { sendMail_ } from "./gas_mail.js";
import { appUrl_, cancelUrl_, safely_ } from "./gas_web.js";

const MENU_TITLE = "予約ページ";
/** 時間主導トリガーが呼ぶ関数の名前 */
const REMIND_HANDLER_ = "remind_";
/** 公開の手順（URL の案内と初期化のあとに添える） */
const DEPLOY_STEPS_ = "「デプロイ」→「新しいデプロイ」→ 種類「ウェブアプリ」→ 次のユーザーとして実行「自分」・アクセスできるユーザー「全員」で公開してください。";

function ui_() {
  return SpreadsheetApp.getUi();
}

function alert_(text) {
  ui_().alert(text);
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

export function onOpen() {
  ui_()
    .createMenu(MENU_TITLE)
    .addItem("初期化（シートと見出しを作る）", "menu_init")
    .addItem("見本を入れる", "menu_samples")
    .addItem("設定を確かめる", "menu_check")
    .addItem("予約ページの URL", "menu_url")
    .addItem("リマインドのトリガーを作る", "menu_trigger")
    .addItem("テスト送信（自分にメール）", "menu_testMail")
    .addToUi();
}

/** 「設定」「枠」「休み」「サービス」「予約」の 5 シートと見出しを作る */
export function menu_init() {
  try {
    const made = ensureSheets_();
    if (made.length === 0) {
      alert_("シートと見出しはそろっています。\n\n次は " + DEPLOY_STEPS_);
      return;
    }
    alert_("シートを作りました: " + made.join("、") + "。\n\n「設定」「枠」「休み」「サービス」をご記入のうえ、" + DEPLOY_STEPS_ + "\nまず動かしてみるなら、メニューの「見本を入れる」が早いです。");
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 見本の店を流し込む（「予約」に書き足すので、先に確認をいただく） */
export function menu_samples() {
  try {
    const ui = ui_();
    const answer = ui.alert(
      "見本を入れてもよろしいですか？",
      "「設定」「枠」「休み」「サービス」は見本の内容に置き換わります。「予約」には見本のご予約が書き足されます。よろしければ「OK」を押してください。",
      ui.ButtonSet.OK_CANCEL
    );
    if (answer !== ui.Button.OK) {
      alert_("見本は入れませんでした。");
      return;
    }
    const today = nowStamp_().slice(0, 10);
    const made = writeSamples_(sampleData(today));
    // 見本の受付番号の続きから振れるように、最後の番号を覚えておく
    if (made.lastId !== "") saveLastId_(made.lastId);
    alert_("見本「" + SHOP_NAME + "」を入れました。ご予約の見本は " + made.reservations + " 件です。\n\n中身を見ながら「設定」「枠」「休み」「サービス」をお店の内容に書き換えてください。");
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 設定・枠・休み・サービスの誤りを一覧で出す。「設定」「枠」のどちらかが無ければ、先に初期化を案内する */
export function menu_check() {
  try {
    const book = book_();
    if (!book.getSheetByName(SETTINGS_SHEET) || !book.getSheetByName(RULES_SHEET)) {
      alert_("まず「初期化（シートと見出しを作る）」を実行してください。");
      return;
    }
    const errors = readSettings_().errors.concat(readRules_().errors, readClosed_().errors, readServices_().errors);
    if (errors.length === 0) {
      alert_("設定に問題はありません。");
      return;
    }
    alert_("直すところがあります。\n\n" + errors.join("\n"));
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 公開した予約ページの URL を出す */
export function menu_url() {
  const url = appUrl_();
  if (url === "") {
    alert_("まだ公開されていません。" + DEPLOY_STEPS_ + "\n公開してから、もう一度お試しください。");
    return;
  }
  alert_("予約ページの URL:\n" + url + "\n\nこの URL をお客さまにお知らせください。Google アカウントをお持ちでない方もご予約いただけます。");
}

/** 前日リマインドの時間主導トリガーを作り直す（同じものが増えないように、先に消す） */
export function menu_trigger() {
  try {
    const settings = readSettings_().settings;
    const existing = ScriptApp.getProjectTriggers();
    let removed = 0;
    for (let i = 0; i < existing.length; i += 1) {
      if (existing[i].getHandlerFunction() !== REMIND_HANDLER_) continue;
      ScriptApp.deleteTrigger(existing[i]);
      removed += 1;
    }
    ScriptApp.newTrigger(REMIND_HANDLER_).timeBased().atHour(settings.remindHour).everyDays(1).create();
    alert_(
      "前日のリマインドのトリガーを作りました。毎日 " + settings.remindHour + " 時ごろに、翌日のご予約へメールをお送りします。" +
        (removed > 0 ? "（前のトリガー " + removed + " 件は消しました）" : "") +
        "\n\n時刻は「設定」の「リマインドの時刻」で変えられます。変えたあとは、もう一度このメニューを実行してください。"
    );
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 確認メールの見本を自分に送る（文面と差出人の名前を確かめるため） */
export function menu_testMail() {
  try {
    const to = ownerEmail_();
    if (to === "") {
      alert_("メールアドレスを読み取れませんでした。スプレッドシートを開き直してから、もう一度お試しください。");
      return;
    }
    const settings = readSettings_().settings;
    const services = readServices_().services;
    const today = nowStamp_().slice(0, 10);
    const sample = {
      "ID": formatReceipt(today, 1),
      "状態": CONFIRMED_,
      "日付": addDays(today, 1),
      "開始": "10:00",
      "終了": "11:00",
      "サービス": services.length > 0 ? textOf(services[0].name) : "",
      "お名前": "見本",
      "メール": to,
      "電話": "",
      "ご要望": "",
    };
    // テスト送信の見本には合い言葉が無いので、キャンセルの URL は空にする（どのご予約にも当たらない URL を載せない）
    const mail = buildConfirmMail(settings, sample, "");
    const sent = sendMail_(to, "【テスト送信】" + mail.subject, mail.body, settings.shopName);
    if (!sent) {
      alert_("テスト送信できませんでした。1 日に送れるメールの数の上限に達している可能性があります。しばらくしてから、もう一度お試しください。");
      return;
    }
    alert_("テスト送信しました: " + to + "\n\n件名と本文は「設定」の「確認メールの件名」「確認メールの本文」で変えられます。");
  } catch (error) {
    alert_(failureText_(error));
  }
}

/**
 * 前日リマインド（時間主導トリガーの入口）。
 * 翌日の「確定」で「リマインド」が空の予約にメールし、送れた分だけ日時を書く
 */
export function remind_() {
  const stamp = nowStamp_();
  const target = addDays(stamp.slice(0, 10), 1);
  const settings = readSettings_().settings;
  const reservations = readReservations_();
  let sent = 0;

  for (let i = 0; i < reservations.length; i += 1) {
    const row = reservations[i];
    if (textOf(row["状態"]) !== CONFIRMED_) continue;
    if (textOf(row["日付"]) !== target) continue;
    if (textOf(row["リマインド"]) !== "") continue;

    const sentOk = safely_(
      "前日のリマインドを送れませんでした",
      () => {
        const mail = buildRemindMail(settings, row, cancelUrl_(row["キャンセル用"]));
        return sendMail_(row["メール"], mail.subject, mail.body, settings.shopName);
      },
      false
    );
    // 送れなかった分は日時を書かないでおく（次にこの日が対象になったときに送り直せる）
    if (!sentOk) continue;
    updateReservation_(row._row, { "リマインド": stamp });
    sent += 1;
  }

  Logger.log("予約ページ: " + target + " のご予約に、前日のリマインドを " + sent + " 件送りました");
  return sent;
}
