/**
 * dist/Code.gs（scripts/build.mjs が束ねた 1 本）を偽の GAS の上で走らせ、
 * 予約 → カレンダー → メール → 通知 → キャンセル → リマインドの流れを端から端まで確かめる。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "../scripts/build.mjs";
import { FIXED_STAMP, FIXED_TODAY, loadBundle } from "./fakes.mjs";
import { sampleData } from "../src/samples.js";
import { formatStamp, toDateKey } from "../src/dates.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
// dist/Code.gs は npm test（pretest）で作られるが、このファイルだけを走らせても通るように作り直す
build(root);

const SAMPLE = sampleData(FIXED_TODAY);
const FIRST = SAMPLE.services[1][0];
const REGULAR = SAMPLE.services[2][0];
const SHOP = "ひだまり整体院";
const APP_URL = "https://script.google.com/macros/s/XXX/exec";
/** 見本の設定に足す、カレンダー・通知・連絡先メールの設定（見本は空のまま） */
const WIRED = [
  ["連絡先メール", "shop@example.com"],
  ["カレンダー ID", "primary"],
  ["Slack Webhook URL", "https://example.com/hooks/slack"],
];
/** 予約シートの列の位置（見出しの順） */
const AT = { id: 0, state: 1, date: 2, start: 3, end: 4, service: 5, name: 6, email: 7, phone: 8, note: 9, received: 10, cancelled: 11, calendar: 12, remind: 13, token: 14 };

/** 見本の店を入れたスプレッドシートで Code.gs を走らせる。extraSettings は「設定」に足す行 */
function seeded(options) {
  const opts = options || {};
  const settings = SAMPLE.settings.concat(opts.extraSettings || []);
  return loadBundle(
    Object.assign({ props: { lastId: "20260918-008" } }, opts, {
      sheets: Object.assign({ 設定: settings, 枠: SAMPLE.rules, 休み: SAMPLE.closed, サービス: SAMPLE.services, 予約: SAMPLE.reservations }, opts.sheets || {}),
    })
  );
}

/** 予約シートの 1 行（1 から数える行番号） */
function rowOf(run, rowNumber) {
  return run.sheets["予約"].rows[rowNumber - 1];
}

/** 日時のセル（本物の Sheets と同じく Date で読めることもある）を "yyyy-MM-dd HH:mm:ss" にする */
function stampOf(value) {
  return value && typeof value.getTime === "function" ? formatStamp(value) : String(value);
}

function input(extra) {
  return Object.assign({ name: "小川", email: "ogawa@example.com", phone: "045-000-0099", note: "はじめてです。", date: "2026-09-22", start: "11:00", service: FIRST, website: "" }, extra || {});
}

test("Code.gs に 5 つの api_ と入口・メニュー・リマインドがある", () => {
  const code = readFileSync(join(root, "dist", "Code.gs"), "utf8");
  for (const name of ["api_bootstrap", "api_availability", "api_reserve", "api_cancelInfo", "api_cancel", "doGet", "onOpen", "remind_", "menu_init", "menu_samples", "menu_check", "menu_url", "menu_trigger", "menu_testMail"]) {
    assert.ok(new RegExp("^function " + name + "\\(", "m").test(code), name);
  }
  assert.equal((code.match(/^function api_/gm) || []).length, 5);
  assert.equal(/^\s*(import|export)\s/m.test(code), false);
});

test("api_bootstrap: 見本の店・受付中のサービス・日ごとの状態・今日", () => {
  const run = seeded();
  const boot = run.entry.api_bootstrap();
  assert.deepEqual(boot.shop, {
    name: SHOP,
    phone: "045-000-0000",
    address: "みなと市しおかぜ町 1-2-3",
    notice: "初めての方は、開始の 10 分前にお越しください。",
    themeColor: "#2f6f5e",
    phoneRequired: false,
    dateFormat: "yyyy-MM-dd",
    cancelHours: 24,
    leadHours: 24,
  });
  assert.deepEqual(boot.services, [
    { name: FIRST, minutes: 60, description: "初めての方はこちら" },
    { name: REGULAR, minutes: 45, description: "2 回目以降の方" },
  ]);
  assert.equal(boot.today, FIXED_TODAY);
  assert.deepEqual(boot.errors, []);
  // days は「何日先まで」（既定 30）の分だけ。サービスを選ぶ前なので、サービス名の無い枠だけで数える
  assert.equal(boot.days.length, 30);
  assert.deepEqual(boot.days.slice(0, 5), [
    { date: "2026-09-18", status: "closed" },
    { date: "2026-09-19", status: "open" },
    { date: "2026-09-20", status: "closed" },
    { date: "2026-09-21", status: "few" },
    { date: "2026-09-22", status: "closed" },
  ]);
  // 見本の休み（today + 5 の単発、today + 12〜13 の期間）
  assert.equal(boot.days[5].status, "closed");
  assert.equal(boot.days[12].status, "closed");
  assert.equal(boot.days[13].status, "closed");
});

test("api_bootstrap: 日ごとの印は受付中のサービスごとに返す", () => {
  const run = seeded();
  const boot = run.entry.api_bootstrap();
  // 受付中のサービスの数だけ、30 日ぶんの印がそろう
  assert.deepEqual(Object.keys(boot.daysByService), [FIRST, REGULAR]);
  for (const name of [FIRST, REGULAR]) {
    assert.equal(boot.daysByService[name].length, 30);
    assert.equal(boot.daysByService[name][0].date, FIXED_TODAY);
  }

  /** その日の印を引く */
  const markOf = (days, date) => days.filter((day) => day.date === date)[0].status;
  // 火曜（9/22）は 10:00〜13:00 が初回・14:00〜19:00 が通常の枠。サービスによって印が変わる
  assert.equal(markOf(boot.daysByService[FIRST], "2026-09-22"), "few");
  assert.equal(markOf(boot.daysByService[REGULAR], "2026-09-22"), "open");
  // サービス名の無い枠だけで数えるぶん（days）では、その日は押せない
  assert.equal(markOf(boot.days, "2026-09-22"), "closed");
  // 土曜（9/19）はサービスを問わない枠なので、どのサービスでも同じ印
  for (const days of [boot.days, boot.daysByService[FIRST], boot.daysByService[REGULAR]]) {
    assert.equal(markOf(days, "2026-09-19"), "open");
  }
});

test("api_bootstrap: 片方のサービスにだけ枠のある日は、もう片方では押せない", () => {
  const run = loadBundle({
    sheets: {
      設定: [["項目", "値"], ["店名", SHOP], ["何時間前まで", "0"]],
      枠: [
        ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"],
        ["月", "", "10:00", "13:00", "60", "1", REGULAR],
      ],
      休み: [["日付", "開始日", "終了日", "理由"]],
      サービス: [["サービス", "所要時間", "説明", "受付"], [FIRST, "60", "", "TRUE"], [REGULAR, "60", "", "TRUE"]],
      予約: [SAMPLE.reservations[0]],
    },
  });
  const boot = run.entry.api_bootstrap();
  const monday = (days) => days.filter((day) => day.date === "2026-09-21")[0].status;
  assert.equal(monday(boot.daysByService[REGULAR]), "open", "通常の施術には枠がある");
  assert.equal(monday(boot.daysByService[FIRST]), "closed", "初回カウンセリングには枠が無い");
  assert.equal(monday(boot.days), "closed", "サービスを選ぶ前も押せない");
});

/** 設定・枠・休み・サービスのすべてに誤りのあるスプレッドシート */
function brokenSheets() {
  return {
    設定: [["項目", "値"], ["店名", "ひだまり整体院"], ["何日先まで", "0"], ["テーマ色", "みどり"]],
    枠: [["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"], ["げつ", "", "10:00", "12:00", "60", "1", ""]],
    休み: [["日付", "開始日", "終了日", "理由"], ["きのう", "", "", "臨時"]],
    サービス: [["サービス", "所要時間", "説明", "受付"], ["", "60", "", "TRUE"]],
  };
}

test("api_bootstrap: シートの誤りは当たりさわりのない 1 文にして返す（中身は出さない）", () => {
  const run = loadBundle({ sheets: brokenSheets() });
  const boot = run.entry.api_bootstrap();
  assert.deepEqual(boot.days, []);
  assert.deepEqual(boot.daysByService, {});
  assert.equal(boot.shop.name, SHOP);
  assert.equal(boot.shop.themeColor, "#2f6f5e", "誤りのあった項目は既定値のまま返す");
  assert.deepEqual(boot.errors, ["ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。"]);
  // 中身の様子（どの項目が・何行目が）は、お客さまの画面には渡さない
  for (const word of ["booking: ", "設定", "シート", "何日先まで", "テーマ色"]) {
    assert.equal(boot.errors[0].includes(word), false, word);
  }
  // お店だけが見る実行ログには、直すところを残す
  const logged = run.trace.logs.join("\n");
  assert.ok(logged.includes("何日先まで"));
  assert.ok(logged.includes("テーマ色"));
  assert.ok(logged.includes("枠シートの 2 行目"));
  assert.ok(logged.includes("休みシートの 2 行目"));
  assert.ok(logged.includes("サービスシートの 2 行目"));
});

test("menu_check: お店には、直すところを 1 件ずつお伝えする", () => {
  const run = loadBundle({ sheets: brokenSheets() });
  run.entry.menu_check();
  const alert = run.trace.alerts[0];
  assert.ok(alert.startsWith("直すところがあります。"));
  for (const part of ["何日先まで", "テーマ色", "枠シートの 2 行目", "休みシートの 2 行目", "サービスシートの 2 行目"]) {
    assert.ok(alert.includes(part), part);
  }
  assert.equal((alert.match(/booking: /g) || []).length, 5);
});

test("api_availability: 締切を過ぎた枠は外し、満席の枠は残りを 0 で残す", () => {
  const run = seeded();
  const saturday = run.entry.api_availability("2026-09-19", FIRST);
  assert.equal(saturday.date, "2026-09-19");
  // 10:00 は締切（開始の 24 時間前）を過ぎているので出さない。土は定員 2 で 1 件入っている
  assert.equal(saturday.slots.length, 8);
  assert.deepEqual(saturday.slots[0], { start: "10:45", end: "11:30", remaining: 2 });
  // 枠（10:00〜16:45 間隔 45）の最後は 16:00〜16:45。終わりが「終了」を越える枠は作らない
  assert.deepEqual(saturday.slots[saturday.slots.length - 1], { start: "16:00", end: "16:45", remaining: 2 });

  const tuesday = run.entry.api_availability("2026-09-22", FIRST);
  assert.deepEqual(tuesday.slots, [
    { start: "10:00", end: "11:00", remaining: 0 },
    { start: "11:00", end: "12:00", remaining: 1 },
    { start: "12:00", end: "13:00", remaining: 1 },
  ]);
  // サービスごとに枠が分かれている（火曜の午後は通常の施術だけ）
  assert.equal(run.entry.api_availability("2026-09-22", REGULAR).slots[0].start, "14:00");
  // 日曜は枠が無い。休みの日も空
  assert.deepEqual(run.entry.api_availability("2026-09-20", FIRST).slots, []);
  assert.deepEqual(run.entry.api_availability("2026-09-23", FIRST).slots, []);
  // 日付の書き方は揺れても読む
  assert.equal(run.entry.api_availability("2026/09/22", FIRST).date, "2026-09-22");
  assert.throws(() => run.entry.api_availability("", FIRST), /日付をお選びください/);
  assert.throws(() => run.entry.api_availability("きのう", FIRST), /日付をお選びください/);
});

test("api_reserve: 行・カレンダー・メール 2 通・通知 1 通・mailSent true", () => {
  const run = seeded({ extraSettings: WIRED });
  const out = run.entry.api_reserve(input());
  assert.deepEqual(out, { ok: true, id: "20260918-009", date: "2026-09-22", start: "11:00", end: "12:00", service: FIRST, mailSent: true });

  // 予約シートに 1 行（見出し + 見本 8 件 + 1 件）
  assert.equal(run.sheets["予約"].rows.length, 10);
  const row = rowOf(run, 10);
  assert.equal(row[AT.id], "20260918-009");
  assert.equal(row[AT.state], "確定");
  assert.equal(toDateKey(row[AT.date]), "2026-09-22");
  assert.equal(row[AT.start], "11:00");
  assert.equal(row[AT.end], "12:00");
  assert.equal(row[AT.service], FIRST);
  assert.equal(row[AT.name], "小川");
  assert.equal(row[AT.email], "ogawa@example.com");
  assert.equal(row[AT.phone], "045-000-0099");
  assert.equal(row[AT.note], "はじめてです。");
  assert.equal(stampOf(row[AT.received]), FIXED_STAMP);
  assert.equal(row[AT.cancelled], "");
  assert.equal(row[AT.remind], "");
  assert.equal(row[AT.token], "aaaaaaaabbbbccccdddd0001");
  assert.equal(run.props.lastId, "20260918-009", "次の受付番号のために覚え書きを進める");
  assert.deepEqual(run.trace.locks, { waited: 1, released: 1 }, "ロックは必ず解く");

  // カレンダー（開始・終了は JST。所要時間 60 分）
  assert.equal(run.events.length, 1);
  assert.equal(run.events[0].calendarId, "owner@example.com", "primary は getDefaultCalendar で主カレンダーに開く");
  assert.equal(run.events[0].title, "予約: 小川 様（" + FIRST + "）");
  assert.equal(run.events[0].start, "2026-09-22T02:00:00.000Z");
  assert.equal(run.events[0].end, "2026-09-22T03:00:00.000Z");
  assert.ok(run.events[0].description.includes("受付番号: 20260918-009"));
  assert.equal(row[AT.calendar], "event1@google.com", "予定の ID を行に書き戻す");

  // メールはお客さまと店に 1 通ずつ。差出人の名前は店名
  assert.equal(run.trace.mails.length, 2);
  assert.equal(run.trace.mails[0].to, "ogawa@example.com");
  assert.equal(run.trace.mails[0].subject, "ご予約を受け付けました（" + SHOP + "）");
  assert.equal(run.trace.mails[0].name, SHOP);
  assert.ok(run.trace.mails[0].body.includes("小川 様"));
  assert.ok(run.trace.mails[0].body.includes("2026-09-22（火） 11:00〜12:00"));
  assert.ok(run.trace.mails[0].body.includes(APP_URL + "?cancel=aaaaaaaabbbbccccdddd0001"));
  assert.equal(run.trace.mails[0].body.includes("<"), false, "メールは文字だけ");
  assert.equal(run.trace.mails[1].to, "shop@example.com");
  assert.equal(run.trace.mails[1].subject, "ご予約が入りました: 9/22（火）11:00 小川 様");
  assert.ok(run.trace.mails[1].body.includes("メール: ogawa@example.com"));

  // 通知は 1 通（Slack だけ設定してある）。電話とメールは載せない
  assert.equal(run.trace.fetched.length, 1);
  assert.equal(run.trace.fetched[0].url, "https://example.com/hooks/slack");
  const payload = JSON.parse(run.trace.fetched[0].payload);
  assert.equal(payload.text, "【予約】9/22（火）11:00〜12:00 " + FIRST + " 小川 様（受付番号 20260918-009）");
  assert.equal(payload.text.includes("ogawa"), false);
  assert.equal(payload.text.includes("045-"), false);
});

test("api_reserve: 連絡先メールが空なら所有者に送り、カレンダー ID が空なら登録しない", () => {
  const run = seeded();
  const out = run.entry.api_reserve(input());
  assert.equal(out.mailSent, true);
  assert.equal(run.events.length, 0);
  assert.equal(rowOf(run, 10)[AT.calendar], "");
  assert.equal(run.trace.mails.length, 2);
  assert.equal(run.trace.mails[1].to, "owner@example.com");
  assert.equal(run.trace.fetched.length, 0, "通知先が無ければ送らない");
});

test("api_reserve: 満席の枠と締切を過ぎた枠は断る", () => {
  const run = seeded();
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-22", start: "10:00" })), /選ばれた時間は、ただいま満席になりました。別の時間をお選びください。/);
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-19", start: "10:00", service: FIRST })), /選ばれた時間は、受付を終了しました。別の時間をお選びください。/);
  // 枠に無い時間・休みの日・枠の無い曜日も「受付を終了しました」
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-22", start: "03:00" })), /受付を終了しました/);
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-23", start: "11:00" })), /受付を終了しました/);
  assert.equal(run.sheets["予約"].rows.length, 9, "断ったときは 1 行も書かない");
  assert.equal(run.trace.mails.length, 0);
  assert.deepEqual(run.trace.locks, { waited: 4, released: 4 }, "断ってもロックは解く");
});

test("api_reserve: 同じメールアドレスの確定は 3 件まで", () => {
  const run = seeded();
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-22", start: "11:00" })).id, "20260918-009");
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-22", start: "12:00" })).id, "20260918-010");
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-25", start: "10:00" })).id, "20260918-011");
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-25", start: "11:00" })), /同じメールアドレスでのご予約は 3 件までです。/);
  // 大文字小文字は同じものとして数える
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-25", start: "11:00", email: "OGAWA@example.com" })), /3 件までです。/);
  // 別のメールなら入る
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-25", start: "11:00", email: "mori@example.com", name: "森" })).id, "20260918-012");
  // 設定で上限を変えられる
  const strict = seeded({ extraSettings: [["同じメールの予約数", "1"]] });
  assert.equal(strict.entry.api_reserve(input()).id, "20260918-009");
  assert.throws(() => strict.entry.api_reserve(input({ date: "2026-09-22", start: "12:00" })), /同じメールアドレスでのご予約は 1 件までです。/);
});

/** 済んだご来店の 1 行（状態は「確定」のまま残る。seq は 1〜9 で合い言葉の末尾に使う） */
function visitedRow(seq, date) {
  const row = [];
  row[AT.id] = "20260101-00" + seq;
  row[AT.state] = "確定";
  row[AT.date] = date;
  row[AT.start] = "10:00";
  row[AT.end] = "11:00";
  row[AT.service] = FIRST;
  row[AT.name] = "小川";
  row[AT.email] = "ogawa@example.com";
  row[AT.phone] = "045-000-0099";
  row[AT.note] = "";
  row[AT.received] = date + " 09:00:00";
  row[AT.cancelled] = "";
  row[AT.calendar] = "";
  row[AT.remind] = "";
  row[AT.token] = "0123456789abcdef0123450" + seq;
  return row;
}

test("api_reserve: 済んだご来店は「同じメールの予約数」に数えない（常連のお客さまも予約できる）", () => {
  // 6 月・7 月・8 月に来店済み（状態は「確定」のまま）のお客さま
  const visited = [visitedRow(1, "2026-06-10"), visitedRow(2, "2026-07-15"), visitedRow(3, "2026-08-20")];
  const run = seeded({ sheets: { 予約: SAMPLE.reservations.concat(visited) } });
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-22", start: "11:00" })).id, "20260918-009");
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-22", start: "12:00" })).id, "20260918-010");
  assert.equal(run.entry.api_reserve(input({ date: "2026-09-25", start: "10:00" })).id, "20260918-011");
  // 数えるのはこれからのご予約。4 件目で初めて止まる
  assert.throws(() => run.entry.api_reserve(input({ date: "2026-09-25", start: "11:00" })), /同じメールアドレスでのご予約は 3 件までです。/);

  // 今日のご予約は「これから」に数える
  const todayRows = [visitedRow(4, FIXED_TODAY), visitedRow(5, FIXED_TODAY), visitedRow(6, FIXED_TODAY)];
  const today = seeded({ sheets: { 予約: SAMPLE.reservations.concat(todayRows) } });
  assert.throws(() => today.entry.api_reserve(input()), /同じメールアドレスでのご予約は 3 件までです。/);
});

test("api_reserve: ハイフン無しの電話番号は、予約シートで先頭の 0 が消えない", () => {
  const run = seeded({ extraSettings: WIRED });
  run.entry.api_reserve(input({ phone: "09012345678" }));
  const cell = rowOf(run, 10)[AT.phone];
  assert.equal(typeof cell, "string", "数にされると先頭の 0 が落ちる");
  assert.equal(cell, "09012345678");
  assert.equal(rowOf(run, 10)[AT.token], "aaaaaaaabbbbccccdddd0001", "合い言葉もそのまま読める");
  // お店へのお知らせメールと台帳で、同じ番号が読める
  assert.ok(run.trace.mails[1].body.includes("電話: 09012345678"));
});

test("api_*: こちらで用意していない誤りは、当たりさわりのない 1 文にして返す", () => {
  // 予約シートが保護されていて、行を足せない状態
  const run = seeded({ denyWrite: true, extraSettings: WIRED });
  assert.throws(
    () => run.entry.api_reserve(input()),
    (error) => {
      assert.equal(error.message, "ただいま処理できませんでした。しばらくしてからお試しください。");
      return true;
    }
  );
  // 英語の内部の誤りも、スプレッドシートの ID も、お客さまには出さない
  assert.equal(run.trace.mails.length, 0, "書けていないのにメールは送らない");
  assert.equal(run.events.length, 0);
  assert.deepEqual(run.trace.locks, { waited: 1, released: 1 }, "途中で落ちてもロックは解く");
  // お店だけが見る実行ログには、元の誤りを残す
  assert.ok(run.trace.logs.join("\n").includes("permission"));

  // 合い言葉に、文字にできない値が来ても落ちない
  assert.deepEqual(run.entry.api_cancelInfo({ toString: 1 }), { found: false });
  assert.throws(() => run.entry.api_cancel({ toString: 1 }), /キャンセルの URL が正しくありません/);
});

test("api_availability / api_reserve: シートに誤りがあるあいだは、サーバーでも受付を止める", () => {
  const run = loadBundle({ sheets: brokenSheets() });
  const stopped = "ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。";
  assert.deepEqual(run.entry.api_bootstrap().errors, [stopped]);
  // 画面が止まっていても、既に開いているタブや機械からの求めは届く。サーバーでも同じ 1 文で断る
  assert.throws(() => run.entry.api_availability("2026-09-22", FIRST), new RegExp(stopped));
  assert.throws(() => run.entry.api_reserve(input()), new RegExp(stopped));
  assert.equal(run.sheets["予約"], undefined, "予約の行は 1 つも書かない");
  assert.equal(run.trace.locks.waited, 0, "ロックも取らない");
  // どこが誤っているかは、お店だけが見る実行ログに残す
  assert.ok(run.trace.logs.join("\n").includes("枠シートの 2 行目"));

  // 直せば、また受け付けられる
  const fixed = seeded();
  assert.ok(fixed.entry.api_availability("2026-09-22", FIRST).slots.length > 0);
  assert.equal(fixed.entry.api_reserve(input()).ok, true);
});

test("api_reserve: メールの残り枠が 3 を切ったら確認メールは送らないが、予約は入る", () => {
  const run = seeded({ quota: 2 });
  const out = run.entry.api_reserve(input());
  assert.equal(out.ok, true);
  assert.equal(out.id, "20260918-009");
  assert.equal(out.mailSent, false, "完了画面で「メールは届いていません」と出すため");
  assert.equal(run.sheets["予約"].rows.length, 10, "行はちゃんと入る");
  assert.equal(run.trace.mails.length, 1, "店への知らせは送る");
  assert.equal(run.trace.mails[0].to, "owner@example.com");
  assert.ok(run.trace.logs.join("\n").includes("上限"));
});

test("api_reserve: 見えない欄が埋まっていたら、成功したふりをして何も書かない", () => {
  const run = seeded({ extraSettings: WIRED });
  const out = run.entry.api_reserve(input({ website: "https://example.com/spam" }));
  assert.deepEqual(out, { ok: true, id: "—", date: "2026-09-22", start: "11:00", end: "11:00", service: FIRST, mailSent: false });
  assert.equal(run.sheets["予約"].rows.length, 9);
  assert.equal(run.trace.mails.length, 0);
  assert.equal(run.trace.fetched.length, 0);
  assert.equal(run.events.length, 0);
  assert.equal(run.trace.locks.waited, 0);
});

test("api_reserve: 見えない欄はシートに触れる前に断るので、設定シートが無くても（読めなくても）落ちない", () => {
  // SpreadsheetApp.getActiveSpreadsheet() 自体が落ちる状態（設定どころかシートが 1 つも無い）でも確かめる
  const run = loadBundle({ noSpreadsheet: true });
  const out = run.entry.api_reserve(input({ website: "https://example.com/spam" }));
  assert.deepEqual(out, { ok: true, id: "—", date: "2026-09-22", start: "11:00", end: "11:00", service: FIRST, mailSent: false });
  assert.equal(run.sheets["予約"], undefined, "シートには一度も触れていない");
  assert.equal(run.trace.mails.length, 0);
  assert.equal(run.trace.fetched.length, 0);
  assert.equal(run.trace.locks.waited, 0);
});

test("api_reserve: 入力の誤りは敬体の文で断る（画面の検査をすり抜けた分の備え）", () => {
  const run = seeded();
  assert.throws(() => run.entry.api_reserve(input({ name: "" })), /お名前をご記入ください/);
  assert.throws(() => run.entry.api_reserve(input({ email: "ogawa" })), /メールアドレスの形式をご確認ください/);
  assert.throws(() => run.entry.api_reserve(input({ note: "あ".repeat(501) })), /ご要望は 500 字までにしてください/);
  assert.throws(() => run.entry.api_reserve(input({ service: "ない名前" })), /サービスをお選びください/);
  assert.throws(() => run.entry.api_reserve(undefined), /お名前をご記入ください/);
  assert.equal(run.trace.locks.waited, 0, "検査で断る分はロックも取らない");
  assert.equal(run.sheets["予約"].rows.length, 9);
  // 電話を必須にすると、空の電話も断る
  const strict = seeded({ extraSettings: [["電話を必須にする", "TRUE"]] });
  assert.throws(() => strict.entry.api_reserve(input({ phone: "" })), /電話番号をご記入ください/);
});

test("api_reserve: カレンダー・メール・通知が落ちても予約は残る", () => {
  const run = seeded({ extraSettings: WIRED, calendarFails: true, mailFails: true, fetchStatus: 500 });
  const out = run.entry.api_reserve(input());
  assert.equal(out.ok, true);
  assert.equal(out.mailSent, false);
  assert.equal(run.sheets["予約"].rows.length, 10);
  assert.equal(rowOf(run, 10)[AT.calendar], "");
  const logs = run.trace.logs.join("\n");
  assert.ok(logs.includes("予定"));
  assert.ok(logs.includes("メール"));
  assert.ok(logs.includes("slack"));
  // カレンダーそのものが見つからないときも落とさない
  const missing = seeded({ extraSettings: WIRED, calendarMissing: true });
  assert.equal(missing.entry.api_reserve(input()).ok, true);
  assert.ok(missing.trace.logs.join("\n").includes("カレンダー"));
});

test("api_reserve: 文面・予定を組み立てる純粋な処理が落ちても予約は残る", () => {
  const run = seeded({ extraSettings: WIRED });
  // gas_calendar / gas_mail / gas_notify は自分の中で例外を握るが、eventFor や buildOwnerMail のような
  // 「組み立てるだけ」の純粋な処理はそのまま例外を投げる。safely_ の中で呼ぶようになったかを、
  // グローバルを差し替えて確かめる（vm の中の関数はこの realm から書き換えられる）
  run.sandbox.buildOwnerMail = () => {
    throw new Error("店への知らせの文面を組み立てられません（テスト用）");
  };
  const out = run.entry.api_reserve(input());
  assert.equal(out.ok, true, "文面の組み立てで落ちても、予約そのものは成立する");
  assert.equal(out.mailSent, true, "お客さまへの確認メールは影響を受けない");
  assert.equal(run.sheets["予約"].rows.length, 10, "行はちゃんと入る");
  assert.equal(rowOf(run, 10)[AT.id], "20260918-009");
  // 店への知らせは組み立てで落ちたので送れない。お客さまへの確認メールだけ 1 通
  assert.equal(run.trace.mails.length, 1);
  assert.equal(run.trace.mails[0].to, "ogawa@example.com");
  assert.ok(run.trace.logs.join("\n").includes("店への知らせを送れませんでした"), "実行ログに残す");
});

test("api_reserve: 混み合っていたら敬体で断る", () => {
  const run = seeded({ lockBusy: true });
  assert.throws(() => run.entry.api_reserve(input()), /ただいま混み合っています。もう一度お試しください。/);
  assert.equal(run.sheets["予約"].rows.length, 9);
});

test("api_cancelInfo: 合い言葉から予約を返す。締切後は canCancel が false", () => {
  const run = seeded();
  const info = run.entry.api_cancelInfo("0123456789abcdef01234562");
  assert.deepEqual(info, {
    found: true,
    reservation: { id: "20260918-002", date: "2026-09-22", start: "10:00", end: "11:00", service: FIRST, name: "田中", status: "確定" },
    canCancel: true,
    phone: "045-000-0000",
  });
  // 2026-09-19 10:00 の分は、開始の 24 時間前を過ぎている
  const late = run.entry.api_cancelInfo("0123456789abcdef01234561");
  assert.equal(late.found, true);
  assert.equal(late.canCancel, false);
  assert.equal(late.phone, "045-000-0000", "締切後は電話でのご連絡をお願いするので、電話を返す");
  // すでにキャンセル済み
  assert.equal(run.entry.api_cancelInfo("0123456789abcdef01234565").reservation.status, "キャンセル");
  assert.equal(run.entry.api_cancelInfo("0123456789abcdef01234565").canCancel, false);
  // 知らない合い言葉・合い言葉の形でないもの
  assert.deepEqual(run.entry.api_cancelInfo("ffffffffffffffffffffffff"), { found: false });
  assert.deepEqual(run.entry.api_cancelInfo("abc"), { found: false });
  assert.deepEqual(run.entry.api_cancelInfo(""), { found: false });
  assert.deepEqual(run.entry.api_cancelInfo(undefined), { found: false });
});

test("api_cancel: 状態とキャンセル日時・カレンダーの予定を消す・お客さまへメール・通知", () => {
  const run = seeded({ extraSettings: WIRED });
  // まず 1 件予約して、カレンダーの予定が付いた行を作る
  run.entry.api_reserve(input());
  const token = rowOf(run, 10)[AT.token];
  assert.equal(run.events[0].deleted, false);

  const out = run.entry.api_cancel(token);
  assert.deepEqual(out, { ok: true, id: "20260918-009" });
  const row = rowOf(run, 10);
  assert.equal(row[AT.state], "キャンセル");
  assert.equal(stampOf(row[AT.cancelled]), FIXED_STAMP);
  assert.equal(row[AT.calendar], "event1@google.com", "予定の ID は履歴として残す");
  assert.equal(run.events[0].deleted, true);
  assert.equal(run.trace.calendar[run.trace.calendar.length - 1].action, "delete");

  // メールは予約の 2 通 + キャンセルの 1 通
  assert.equal(run.trace.mails.length, 3);
  assert.equal(run.trace.mails[2].to, "ogawa@example.com");
  assert.equal(run.trace.mails[2].subject, "ご予約をキャンセルしました（" + SHOP + "）");
  assert.ok(run.trace.mails[2].body.includes("ご予約をキャンセルしました。"));
  // 通知も 2 通め
  assert.equal(run.trace.fetched.length, 2);
  assert.equal(JSON.parse(run.trace.fetched[1].payload).text, "【キャンセル】9/22（火）11:00〜12:00 " + FIRST + " 小川 様（受付番号 20260918-009）");
  // 枠が空く
  assert.equal(run.entry.api_availability("2026-09-22", FIRST).slots[1].remaining, 1);
  assert.equal(run.entry.api_cancelInfo(token).canCancel, false);
});

test("api_cancel: すでにキャンセル・締切後・知らない合い言葉は断る", () => {
  const run = seeded();
  assert.throws(() => run.entry.api_cancel("0123456789abcdef01234565"), /このご予約はすでにキャンセルされています。/);
  assert.throws(() => run.entry.api_cancel("0123456789abcdef01234561"), /キャンセルの受付は開始の 24 時間前までです。お電話でご連絡ください。/);
  assert.throws(() => run.entry.api_cancel("ffffffffffffffffffffffff"), /ご予約が見つかりませんでした/);
  assert.throws(() => run.entry.api_cancel("abc"), /キャンセルの URL が正しくありません/);
  assert.equal(run.trace.mails.length, 0);
  assert.equal(run.trace.locks.released, run.trace.locks.waited, "断ってもロックは解く");
  // 締切の時間は設定で変えられる
  const loose = seeded({ extraSettings: [["キャンセルは何時間前まで", "0"]] });
  assert.deepEqual(loose.entry.api_cancel("0123456789abcdef01234561"), { ok: true, id: "20260918-001" });
});

test("remind_: 翌日の確定にだけ送り、2 回目は送らない", () => {
  const run = seeded();
  run.entry.remind_();
  // 翌日（2026-09-19）は見本の 1 件だけ
  assert.equal(run.trace.mails.length, 1);
  assert.equal(run.trace.mails[0].to, "yamakawa@example.com");
  assert.equal(run.trace.mails[0].subject, "明日のご予約のご案内（" + SHOP + "）");
  assert.equal(run.trace.mails[0].name, SHOP);
  assert.ok(run.trace.mails[0].body.includes("明日のご予約のご案内です。"));
  assert.ok(run.trace.mails[0].body.includes(APP_URL + "?cancel=0123456789abcdef01234561"));
  assert.equal(stampOf(rowOf(run, 2)[AT.remind]), FIXED_STAMP);

  run.entry.remind_();
  assert.equal(run.trace.mails.length, 1, "リマインドが入っている行には送らない");

  // 送れなかったときは日時を書かず、次の機会に送り直せるようにする
  const failing = seeded({ mailFails: true });
  failing.entry.remind_();
  assert.equal(failing.trace.mails.length, 0);
  assert.equal(rowOf(failing, 2)[AT.remind], "");
  assert.ok(failing.trace.logs.join("\n").includes("メール"));
});

test("1 件の予約で送るメールは 3 通（確認・店への知らせ・前日のリマインド）", () => {
  const run = seeded({ sheets: { 予約: [SAMPLE.reservations[0]] }, extraSettings: WIRED });
  const out = run.entry.api_reserve(input({ date: "2026-09-19", start: "10:45", service: REGULAR }));
  assert.equal(out.id, "20260918-009");
  assert.equal(out.end, "11:30");
  run.entry.remind_();
  assert.deepEqual(run.trace.mails.map((mail) => mail.to), ["ogawa@example.com", "shop@example.com", "ogawa@example.com"]);
  assert.deepEqual(run.trace.mails.map((mail) => mail.subject), [
    "ご予約を受け付けました（" + SHOP + "）",
    "ご予約が入りました: 9/19（土）10:45 小川 様",
    "明日のご予約のご案内（" + SHOP + "）",
  ]);
});

/** doGet が差し込む 1 行の頭（画面の JS は window.__BOOKING_CANCEL__ を読むだけなので、代入で見分ける） */
const INJECTED_ = 'window.__BOOKING_CANCEL__ = "';

test("doGet: 題名・ビューポート・埋め込み許可。cancel は合い言葉のときだけ差し込む", () => {
  const run = seeded();
  const plain = run.entry.doGet();
  assert.equal(plain.file, "App");
  assert.equal(plain.title, SHOP);
  assert.deepEqual(plain.meta, [["viewport", "width=device-width, initial-scale=1"]]);
  assert.equal(plain.xFrame, "ALLOWALL");
  // main.js は window.__BOOKING_CANCEL__ を読むので、差し込みの有無は「代入の 1 行」で見る
  assert.equal(plain.content.includes(INJECTED_), false);

  const cancelling = run.entry.doGet({ parameter: { cancel: "0123456789abcdef01234562" } });
  const tag = '<script>window.__BOOKING_CANCEL__ = "0123456789abcdef01234562";</script>';
  assert.ok(cancelling.content.includes(tag));
  assert.ok(cancelling.content.indexOf(tag) < cancelling.content.indexOf("</head>"), "画面の JS より先に動くよう head に入れる");
  assert.equal(cancelling.title, SHOP);

  // 合い言葉の形でないものは差し込まない
  for (const bad of ['<script>alert(1)</script>', "abc", "", "0123456789ABCDEF01234562"]) {
    assert.equal(run.entry.doGet({ parameter: { cancel: bad } }).content.includes(INJECTED_), false, bad);
  }
  assert.equal(run.entry.doGet({}).content.includes(INJECTED_), false);
  assert.equal(run.entry.doGet({ parameter: {} }).content.includes(INJECTED_), false);
});

test("menu_init: 5 つのシートと見出しを作る（2 回目は壊さない）", () => {
  const run = loadBundle({ sheets: {} });
  run.entry.onOpen();
  run.entry.menu_init();
  assert.deepEqual(Object.keys(run.sheets), ["設定", "枠", "休み", "サービス", "予約"]);
  assert.deepEqual(run.sheets["枠"].rows[0], ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"]);
  assert.deepEqual(run.sheets["休み"].rows[0], ["日付", "開始日", "終了日", "理由"]);
  assert.deepEqual(run.sheets["サービス"].rows[0], ["サービス", "所要時間", "説明", "受付"]);
  assert.deepEqual(run.sheets["予約"].rows[0], ["ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話", "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用"]);
  // 設定は項目の名前を並べて、値は空にしておく
  assert.deepEqual(run.sheets["設定"].rows[0], ["項目", "値"]);
  assert.deepEqual(run.sheets["設定"].rows[1], ["店名", ""]);
  assert.equal(run.sheets["設定"].rows.length, 23);
  assert.ok(run.trace.alerts[0].includes("設定"));

  run.entry.menu_init();
  assert.equal(run.sheets["設定"].rows.length, 23, "2 回目は書き換えない");
  assert.equal(run.entry.api_bootstrap().errors.length, 0, "作ったばかりでも誤りは出ない");
});

test("menu_samples: 確認してから見本を入れる（取り消せば書かない）", () => {
  const run = loadBundle({ sheets: {} });
  run.entry.menu_samples();
  assert.equal(run.sheets["予約"].rows.length, 9, "見出し + 見本 8 件");
  assert.equal(run.sheets["設定"].rows[1][1], SHOP);
  assert.equal(run.sheets["枠"].rows.length, 5);
  assert.equal(run.sheets["休み"].rows.length, 3);
  assert.equal(run.sheets["サービス"].rows.length, 3);
  assert.equal(run.props.lastId, "20260918-008", "見本の続きから受付番号を振る");
  assert.ok(run.trace.alerts[0].includes("見本"));
  assert.equal(run.entry.api_bootstrap().shop.name, SHOP);
  assert.equal(run.entry.api_reserve(input()).id, "20260918-009");

  const cancelled = loadBundle({ sheets: {}, dialogButton: "CANCEL" });
  cancelled.entry.menu_samples();
  assert.equal(cancelled.sheets["予約"], undefined, "取り消したらシートも作らない");
  assert.equal(cancelled.trace.alerts.length, 2);
});

test("menu_check / menu_url / menu_testMail", () => {
  const run = seeded();
  run.entry.menu_check();
  assert.equal(run.trace.alerts[0], "設定に問題はありません。");
  run.entry.menu_url();
  assert.ok(run.trace.alerts[1].includes(APP_URL));
  run.entry.menu_testMail();
  assert.equal(run.trace.mails.length, 1);
  assert.equal(run.trace.mails[0].to, "owner@example.com");
  assert.ok(run.trace.mails[0].subject.startsWith("【テスト送信】"));
  assert.ok(run.trace.mails[0].subject.includes(SHOP));
  assert.ok(run.trace.mails[0].body.includes("ご予約を受け付けました。"));
  assert.ok(run.trace.alerts[2].includes("owner@example.com"));

  // シートはあっても値に誤りがあるだけなら、これまでどおりその誤りを出す（初期化の案内ではない）
  const broken = loadBundle({
    sheets: {
      設定: [["項目", "値"], ["リマインドの時刻", "25"]],
      枠: [["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"]],
    },
  });
  broken.entry.menu_check();
  assert.ok(broken.trace.alerts[0].includes("リマインドの時刻"));

  // まだ初期化していない（シートが 1 つも無い）ときは、その案内を出す
  const empty = loadBundle({ sheets: {} });
  empty.entry.menu_check();
  assert.equal(empty.trace.alerts[0], "まず「初期化（シートと見出しを作る）」を実行してください。");

  // 「設定」だけあって「枠」が無いときも同じ案内（枠が無いと空きの計算ができない）
  const noRules = loadBundle({ sheets: { 設定: [["項目", "値"], ["店名", SHOP]] } });
  noRules.entry.menu_check();
  assert.equal(noRules.trace.alerts[0], "まず「初期化（シートと見出しを作る）」を実行してください。");

  const noUrl = seeded({ appUrl: null });
  noUrl.entry.menu_url();
  assert.ok(noUrl.trace.alerts[0].includes("デプロイ"));
});

test("menu_trigger: 既存の remind_ を消して 1 つだけ残す", () => {
  const run = seeded({ triggers: ["remind_", "remind_", "onOpen"] });
  run.entry.menu_trigger();
  assert.deepEqual(
    run.triggers.map((t) => t.handler),
    ["onOpen", "remind_"]
  );
  assert.equal(run.triggers[1].hour, 18);
  assert.equal(run.triggers[1].days, 1);
  assert.ok(run.trace.alerts[0].includes("18"));

  const early = seeded({ extraSettings: [["リマインドの時刻", "9"]] });
  early.entry.menu_trigger();
  assert.equal(early.triggers.length, 1);
  assert.equal(early.triggers[0].hour, 9);
});
