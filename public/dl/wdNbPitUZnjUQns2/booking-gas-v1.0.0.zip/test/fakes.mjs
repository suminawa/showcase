/**
 * 偽の GAS。dist/Code.gs と同じ中身（scripts/build.mjs）を node:vm で走らせるための最小のグローバル。
 * シートは 2 次元配列、プロパティは辞書、メール・カレンダー・通知・トリガーは記録するだけ。
 * 姉妹キット（業務アプリ キット）の偽の GAS に、予約ページで使う分を足したもの。
 */
import { createContext, runInContext } from "node:vm";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildAppHtml, buildServer } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 引数なしの new Date() と Date.now() は 2026-09-18（金）10:40 JST に固定する */
export const FIXED_NOW = Date.UTC(2026, 8, 18, 1, 40, 0);
/** 固定した「いま」を、シートに書く日時の形にしたもの */
export const FIXED_STAMP = "2026-09-18 10:40:00";
/** 固定した「いま」の日付キー */
export const FIXED_TODAY = "2026-09-18";

class FixedDate extends Date {
  constructor(...args) {
    if (args.length === 0) super(FIXED_NOW);
    else super(...args);
  }
  static now() {
    return FIXED_NOW;
  }
}

function copy_(rows) {
  return rows.map((row) => Array.from(row));
}

/**
 * 本物の Sheets は、書き込んだ文字を人が打ち込んだときと同じように読み直す。
 * 先頭が ' なら文字（' は残らない）、数に見えれば数、日付に見えれば日付（JST）。
 */
export function parseWritten_(value) {
  if (typeof value !== "string") return value;
  if (value.charAt(0) === "'") return value.slice(1);
  if (/^-?\d+(\.\d+)?$/.test(value)) return Number(value);
  if (/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$/.test(value)) {
    return new Date((value.indexOf(" ") < 0 ? value + "T00:00:00" : value.replace(" ", "T")) + "+09:00");
  }
  return value;
}

export function fakeSheet(name, values, options) {
  const opts = options || {};
  const rows = copy_(values || []);
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const pad = () => {
    const w = width();
    for (const row of rows) while (row.length < w) row.push("");
  };
  const denied = () => {
    if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
  };
  const at_ = (r, c) => (rows[r] && rows[r][c] !== undefined ? rows[r][c] : "");
  /** r・c は 0 から数える */
  const write_ = (r, c, value) => {
    while (rows.length <= r) rows.push([]);
    while (rows[r].length <= c) rows[r].push("");
    rows[r][c] = parseWritten_(value);
  };
  const sheet = {
    rows: rows,
    /** setValues / appendRow を呼ばれた回数（まとめて書けているかを見る） */
    writes: 0,
    frozen: 0,
    getName: () => name,
    getLastRow: () => rows.length,
    getLastColumn: () => width(),
    getMaxColumns: () => Math.max(26, width()),
    setFrozenRows: (n) => {
      sheet.frozen = n;
    },
    clearContents: () => {
      denied();
      rows.length = 0;
    },
    getDataRange: () => ({ getValues: () => copy_(rows) }),
    getRange: (r, c, nr, nc) => ({
      getValues: () => {
        const out = [];
        for (let i = 0; i < (nr || 1); i += 1) {
          const line = [];
          for (let j = 0; j < (nc || 1); j += 1) line.push(at_(r - 1 + i, c - 1 + j));
          out.push(line);
        }
        return out;
      },
      setValues: (written) => {
        denied();
        sheet.writes += 1;
        for (let i = 0; i < written.length; i += 1) for (let j = 0; j < written[i].length; j += 1) write_(r - 1 + i, c - 1 + j, written[i][j]);
        pad();
      },
    }),
    appendRow: (row) => {
      denied();
      sheet.writes += 1;
      const r = rows.length;
      rows.push([]);
      for (let j = 0; j < row.length; j += 1) write_(r, j, row[j]);
      pad();
    },
  };
  return sheet;
}

/** vm の中から渡された Date を、この realm の ISO 文字にする（別 realm なので instanceof は使えない） */
function iso_(value) {
  return value && typeof value.getTime === "function" ? new Date(value.getTime()).toISOString() : String(value);
}

export function createSandbox(options) {
  const opts = options || {};
  const trace = { fetched: [], alerts: [], logs: [], html: [], mails: [], calendar: [], locks: { waited: 0, released: 0 } };
  const props = Object.assign({}, opts.props || {});
  const sheets = {};
  const seed = opts.sheets || {};
  for (const name of Object.keys(seed)) sheets[name] = fakeSheet(name, seed[name], { denyWrite: opts.denyWrite });

  /** カレンダーに入った予定（deleted で消されたかを見る） */
  const events = [];
  /** 作られたトリガー（ハンドラ名・時刻・間隔） */
  const triggers = [];
  let triggerSeq = 0;
  let uuidSeq = 0;
  let mailsUsed = 0;
  let appHtml = null;

  for (const handler of opts.triggers || []) {
    triggerSeq += 1;
    triggers.push({ id: "T" + triggerSeq, handler: handler, hour: null, days: null });
  }

  const book = {
    getUrl: () => "https://docs.google.com/spreadsheets/d/SHEETID/edit",
    getSpreadsheetTimeZone: () => "Asia/Tokyo",
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Spreadsheet.insertSheet.");
      sheets[name] = fakeSheet(name, [], { denyWrite: opts.denyWrite });
      return sheets[name];
    },
  };
  const menu = { addItem: () => menu, addSeparator: () => menu, addToUi: () => {} };
  const wrapTrigger_ = (t) => ({ getHandlerFunction: () => t.handler, getUniqueId: () => t.id });

  const sandbox = {
    Date: FixedDate,
    SpreadsheetApp: {
      getActiveSpreadsheet: () => {
        if (opts.noSpreadsheet) throw new Error("You do not have permission to access the requested document.");
        return book;
      },
      getUi: () => ({
        // alert(message) と alert(title, message, buttons) の 2 通り
        alert: (a, b, c) => {
          if (c === undefined) {
            trace.alerts.push(String(a));
            return "OK";
          }
          trace.alerts.push(String(a) + "\n" + String(b));
          return opts.dialogButton === undefined ? "OK" : opts.dialogButton;
        },
        createMenu: () => menu,
        ButtonSet: { OK: "OK", OK_CANCEL: "OK_CANCEL", YES_NO: "YES_NO" },
        Button: { OK: "OK", CANCEL: "CANCEL", YES: "YES", NO: "NO" },
      }),
    },
    HtmlService: {
      XFrameOptionsMode: { ALLOWALL: "ALLOWALL", DEFAULT: "DEFAULT", SAMEORIGIN: "SAMEORIGIN" },
      createHtmlOutput: (html) => {
        const out = { html: html, title: "" };
        out.setTitle = (t) => {
          out.title = t;
          return out;
        };
        trace.html.push(out);
        return out;
      },
      createHtmlOutputFromFile: (file) => {
        if (appHtml === null) appHtml = buildAppHtml(root);
        const out = { file: file, title: "", meta: [], xFrame: "", content: appHtml };
        out.setTitle = (t) => {
          out.title = t;
          return out;
        };
        out.addMetaTag = (k, v) => {
          out.meta.push([k, v]);
          return out;
        };
        out.setXFrameOptionsMode = (mode) => {
          out.xFrame = mode;
          return out;
        };
        out.getContent = () => out.content;
        out.setContent = (c) => {
          out.content = String(c);
          return out;
        };
        out.append = (c) => {
          out.content += String(c);
          return out;
        };
        trace.html.push(out);
        return out;
      },
    },
    CalendarApp: {
      getDefaultCalendar: () => sandbox.CalendarApp.getCalendarById("owner@example.com"),
      getCalendarById: (id) => {
        // 本物の CalendarApp は "primary" を ID として受け付けない
        if (opts.calendarMissing || id === "primary") return null;
        return {
          getId: () => id,
          createEvent: (title, start, end, eventOptions) => {
            if (opts.calendarFails) throw new Error("Calendar usage limits exceeded");
            const eventId = "event" + (events.length + 1) + "@google.com";
            const made = { id: eventId, calendarId: id, title: title, start: iso_(start), end: iso_(end), description: eventOptions ? eventOptions.description : "", deleted: false };
            events.push(made);
            trace.calendar.push({ action: "create", calendarId: id, title: title, start: made.start, end: made.end });
            return { getId: () => eventId };
          },
          getEventById: (eventId) => {
            let found = null;
            for (const event of events) if (event.id === eventId && !event.deleted) found = event;
            if (found === null) return null;
            return {
              getId: () => found.id,
              deleteEvent: () => {
                if (opts.calendarDeleteFails) throw new Error("Calendar usage limits exceeded");
                found.deleted = true;
                trace.calendar.push({ action: "delete", calendarId: id, id: eventId });
              },
            };
          },
        };
      },
    },
    MailApp: {
      sendEmail: (mailOptions) => {
        if (opts.mailFails) throw new Error("Service invoked too many times: email");
        mailsUsed += 1;
        trace.mails.push({ to: String(mailOptions.to), subject: String(mailOptions.subject), body: String(mailOptions.body), name: mailOptions.name === undefined ? "" : String(mailOptions.name) });
      },
      getRemainingDailyQuota: () => {
        if (opts.quotaFails) throw new Error("Service unavailable: Mail");
        return Math.max(0, (opts.quota === undefined ? 100 : opts.quota) - mailsUsed);
      },
    },
    UrlFetchApp: {
      fetch: (url, fetchOptions) => {
        trace.fetched.push({ url: url, payload: fetchOptions.payload, headers: fetchOptions.headers || {} });
        const status = opts.fetchStatus || 200;
        return { getResponseCode: () => status, getContentText: () => (status === 200 ? "ok" : "error") };
      },
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (props[key] === undefined ? null : props[key]),
        setProperty: (key, value) => {
          props[key] = value;
        },
        getKeys: () => Object.keys(props),
        deleteProperty: (key) => {
          delete props[key];
        },
      }),
    },
    LockService: {
      getScriptLock: () => ({
        waitLock: () => {
          trace.locks.waited += 1;
          if (opts.lockBusy) throw new Error("Could not acquire lock");
        },
        releaseLock: () => {
          trace.locks.released += 1;
        },
      }),
    },
    ScriptApp: {
      getService: () => ({ getUrl: () => (opts.appUrl === undefined ? "https://script.google.com/macros/s/XXX/exec" : opts.appUrl) }),
      newTrigger: (handler) => {
        const built = { id: "", handler: String(handler), hour: null, days: null };
        const timeBased = {
          atHour: (hour) => {
            built.hour = hour;
            return timeBased;
          },
          everyDays: (days) => {
            built.days = days;
            return timeBased;
          },
          create: () => {
            triggerSeq += 1;
            built.id = "T" + triggerSeq;
            triggers.push(built);
            return wrapTrigger_(built);
          },
        };
        return { timeBased: () => timeBased };
      },
      getProjectTriggers: () => triggers.map(wrapTrigger_),
      deleteTrigger: (wrapped) => {
        const id = wrapped.getUniqueId();
        for (let i = triggers.length - 1; i >= 0; i -= 1) if (triggers[i].id === id) triggers.splice(i, 1);
      },
    },
    Session: {
      getEffectiveUser: () => ({ getEmail: () => (opts.email === undefined ? "owner@example.com" : opts.email) }),
      getActiveUser: () => ({ getEmail: () => (opts.email === undefined ? "owner@example.com" : opts.email) }),
    },
    Utilities: {
      sleep: () => {},
      // 合い言葉は Utilities.getUuid() から作るので、テストでは 1 つずつ増える固定の列にする
      getUuid: () => {
        uuidSeq += 1;
        const tail = String(uuidSeq);
        return "aaaaaaaa-bbbb-cccc-dddd-" + "0".repeat(4 - tail.length) + tail + "eeeeeeee";
      },
    },
    Logger: { log: (t) => trace.logs.push(String(t)) },
  };
  return { sandbox: sandbox, sheets: sheets, props: props, trace: trace, events: events, triggers: triggers };
}

const ENTRY_NAMES = [
  "api_bootstrap",
  "api_availability",
  "api_reserve",
  "api_cancelInfo",
  "api_cancel",
  "doGet",
  "onOpen",
  "remind_",
  "menu_init",
  "menu_samples",
  "menu_check",
  "menu_url",
  "menu_trigger",
  "menu_testMail",
];

/**
 * vm の中で作られた配列・オブジェクトは prototype が別の realm のものなので、node:assert/strict の deepEqual が通らない。
 * JSON を経由して、この realm の素のオブジェクトにする（undefined はそのまま）
 */
export function plain(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

/** Code.gs を偽の GAS の上で走らせ、入口の関数を返す（返り値は plain() を通す。例外はそのまま投げる） */
export function loadBundle(options) {
  const made = createSandbox(options);
  const context = createContext(made.sandbox);
  const exports = ENTRY_NAMES.map((n) => n + ": typeof " + n + " === 'function' ? " + n + " : null").join(", ");
  runInContext(buildServer(root) + "\nglobalThis.__entry = { " + exports + " };\n", context);
  const entry = {};
  ENTRY_NAMES.forEach((name) => {
    const fn = made.sandbox.__entry[name];
    entry[name] = fn === null ? null : (...args) => plain(fn.apply(null, args));
  });
  return { entry: entry, sheets: made.sheets, props: made.props, trace: made.trace, events: made.events, triggers: made.triggers, sandbox: made.sandbox, context: context };
}
