import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { SHOP_NAME, sampleData } from "../src/samples.js";
import { sampleCsvFiles } from "../scripts/samples.mjs";
import { parseSettings } from "../src/settings.js";
import { parseRules, parseClosedDays } from "../src/rules.js";
import { parseServices } from "../src/services.js";
import { calendarDays, slotsFor } from "../src/availability.js";
import { TOKEN_RE } from "../src/token.js";
import { minutesOf } from "../src/dates.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const TODAY = "2026-09-18";

/**
 * 実在を思わせる語・社内でだけ使う呼び名。見本の文面に混ざっていないことを確かめる。
 * 社内でだけ使う呼び名（後ろの 4 つ）は、この検査そのものが配布物に入るので文字コードで書く
 */
const FORBIDDEN_WORDS = [
  "株式会社",
  "有限会社",
  "合同会社",
  "〒",
  "suminawa",
  "\u924b",
  "\u68df\u6881",
  "\u0043\u006c\u0061\u0075\u0064\u0065\u0020\u0043\u006f\u0064\u0065",
  "\u0041\u006e\u0074\u0068\u0072\u006f\u0070\u0069\u0063",
];
// 予約の見本で使う架空の名前（設計どおりの固定リスト）
const FICTIONAL_NAMES = ["山川", "田中", "佐藤", "鈴木", "高橋", "伊藤", "渡辺", "中村"];

/** 見出し行つきの 2 次元配列 → { 見出し: 値 } の配列。calendarDays に渡す形にする */
function rowsToObjects_(rows) {
  const header = rows[0];
  return rows.slice(1).map((row) => {
    const record = {};
    header.forEach((name, i) => {
      record[name] = row[i];
    });
    return record;
  });
}

function reservationRows_(data) {
  const header = data.reservations[0];
  return data.reservations.slice(1).map((row) => {
    const record = {};
    header.forEach((name, i) => {
      record[name] = row[i];
    });
    return record;
  });
}

test("SHOP_NAME はひだまり整体院", () => {
  assert.equal(SHOP_NAME, "ひだまり整体院");
});

test("sampleData は見出し行つきの 2 次元配列を 5 つ返す", () => {
  const data = sampleData(TODAY);
  assert.deepEqual(data.settings[0], ["項目", "値"]);
  assert.deepEqual(data.rules[0], ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"]);
  assert.deepEqual(data.closed[0], ["日付", "開始日", "終了日", "理由"]);
  assert.deepEqual(data.services[0], ["サービス", "所要時間", "説明", "受付"]);
  assert.deepEqual(data.reservations[0], [
    "ID", "状態", "日付", "開始", "終了", "サービス", "お名前", "メール", "電話",
    "ご要望", "受付日時", "キャンセル日時", "カレンダー", "リマインド", "キャンセル用",
  ]);
});

test("sampleData は同じ today なら同じ出力（乱数を使わない）", () => {
  assert.deepEqual(sampleData(TODAY), sampleData(TODAY));
});

test("設定の見本: 店名・電話・住所・注意書きが入り、連絡先メールは空。誤りは無い", () => {
  const data = sampleData(TODAY);
  const { settings, errors } = parseSettings(data.settings);
  assert.deepEqual(errors, []);
  assert.equal(settings.shopName, "ひだまり整体院");
  assert.equal(settings.phone, "045-000-0000");
  assert.equal(settings.address, "横浜市中区みなと町 1-2-3");
  assert.equal(settings.notice, "初めての方は、開始の 10 分前にお越しください。");
  assert.equal(settings.contactEmail, "");
});

test("サービスの見本: 初回カウンセリングと通常の施術。誤りは無い", () => {
  const data = sampleData(TODAY);
  const { services, errors } = parseServices(data.services);
  assert.deepEqual(errors, []);
  assert.deepEqual(services.map((s) => s.name), ["初回カウンセリング（60 分）", "通常の施術"]);
  assert.deepEqual(services.map((s) => s.minutes), [60, 45]);
  assert.equal(services.every((s) => s.active === true), true);
});

test("枠の見本: 火水金 2 本・土・日付指定の 4 行。誤りは無い", () => {
  const data = sampleData(TODAY);
  const { rules, errors } = parseRules(data.rules);
  assert.deepEqual(errors, []);
  assert.equal(rules.length, 4);
  assert.deepEqual(rules[0].weekdays, [2, 3, 5]);
  assert.equal(rules[0].service, "初回カウンセリング（60 分）");
  assert.deepEqual(rules[1].weekdays, [2, 3, 5]);
  assert.equal(rules[1].service, "通常の施術");
  assert.deepEqual(rules[2].weekdays, [6]);
  assert.equal(rules[2].service, "");
  assert.deepEqual(rules[3].weekdays, []);
  assert.equal(rules[3].date, "2026-09-21"); // today + 3 日、曜日は空
});

test("枠の見本は、最後の枠の終わりが「終了」とそろう（間隔で割り切れる時間帯）", () => {
  const data = sampleData(TODAY);
  const { rules } = parseRules(data.rules);
  for (const rule of rules) {
    const span = minutesOf(rule.end) - minutesOf(rule.start);
    assert.equal(span % rule.interval, 0, rule.start + "〜" + rule.end + " は間隔 " + rule.interval + " で割り切れない");
  }
  // 実際に枠を作っても、最後の枠の終わりが「終了」を越えない
  const saturday = slotsFor("2026-09-19", rules, [], "");
  assert.deepEqual(saturday[saturday.length - 1], { start: "16:00", end: "16:45", capacity: 2 });
  const friday = slotsFor("2026-09-25", rules, [], "通常の施術");
  assert.deepEqual(friday[friday.length - 1], { start: "17:45", end: "18:30", capacity: 1 });
});

test("休みの見本: 単発の休みと期間の休み。誤りは無い", () => {
  const data = sampleData(TODAY);
  const { closed, errors } = parseClosedDays(data.closed);
  assert.deepEqual(errors, []);
  assert.deepEqual(closed, [
    { from: "2026-09-23", to: "2026-09-23" },
    { from: "2026-09-30", to: "2026-10-01" },
  ]);
});

test("calendarDays: 今日 2026-09-18 09:00 で見本を読むと open の日がある", () => {
  const data = sampleData(TODAY);
  const { settings } = parseSettings(data.settings);
  const { rules } = parseRules(data.rules);
  const { closed } = parseClosedDays(data.closed);
  const reservations = rowsToObjects_(data.reservations);
  const days = calendarDays(TODAY + " 09:00", settings, rules, closed, reservations, "");
  assert.ok(days.some((d) => d.status === "open"), JSON.stringify(days));
});

test("calendarDays: 見本の 30 日は 9 月から 10 月へまたいでも、日付が 1 日ずつ続く", () => {
  const data = sampleData(TODAY);
  const { settings } = parseSettings(data.settings);
  const { rules } = parseRules(data.rules);
  const { closed } = parseClosedDays(data.closed);
  const reservations = rowsToObjects_(data.reservations);
  const days = calendarDays(TODAY + " 09:00", settings, rules, closed, reservations, "");

  assert.equal(days.length, 30, "設定「何日先まで」の既定は 30");
  assert.equal(days[0].date, TODAY);
  assert.equal(days[12].date, "2026-09-30", "9 月の最終日");
  assert.equal(days[13].date, "2026-10-01", "翌日は 10 月 1 日");
  assert.equal(days[29].date, "2026-10-17", "30 日目");
  assert.deepEqual(days.map((day) => day.date), Array.from(new Set(days.map((day) => day.date))), "同じ日は出てこない");
  // 月をまたいだ先の土曜（10/3）にも枠がある
  assert.equal(days.filter((day) => day.date === "2026-10-03")[0].status, "open");
});

test("予約の見本: 8 件（確定 7・キャンセル 1）で、日付・開始が実際の枠と一致する", () => {
  const data = sampleData(TODAY);
  const { rules } = parseRules(data.rules);
  const { closed } = parseClosedDays(data.closed);
  const records = reservationRows_(data);
  assert.equal(records.length, 8);

  let confirmed = 0;
  let cancelled = 0;
  const seenIds = new Set();
  const usedNames = new Set();

  for (const record of records) {
    assert.ok(record["日付"] > TODAY, "予約日は今日より後のはず: " + record["日付"]);
    assert.equal(seenIds.has(record["ID"]), false, "ID が重複: " + record["ID"]);
    seenIds.add(record["ID"]);
    assert.match(record["ID"], /^\d{8}-\d{3}$/);

    const slots = slotsFor(record["日付"], rules, closed, record["サービス"]);
    assert.ok(slots.length > 0, record["日付"] + " に枠がありません");
    assert.ok(
      slots.some((slot) => slot.start === record["開始"] && slot.end === record["終了"]),
      record["日付"] + " " + record["開始"] + " は枠と一致しません",
    );

    assert.ok(FICTIONAL_NAMES.includes(record["お名前"]), "架空の名前のはず: " + record["お名前"]);
    usedNames.add(record["お名前"]);
    assert.match(record["メール"], /^[a-z]+@example\.com$/);
    assert.match(record["電話"], /^045-000-00\d{2}$/);
    assert.match(record["キャンセル用"], TOKEN_RE);
    assert.match(record["受付日時"], /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
    assert.equal(record["カレンダー"], "");
    assert.equal(record["リマインド"], "");

    if (record["状態"] === "確定") {
      confirmed += 1;
      assert.equal(record["キャンセル日時"], "");
    } else if (record["状態"] === "キャンセル") {
      cancelled += 1;
      assert.match(record["キャンセル日時"], /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
    } else {
      assert.fail("知らない状態: " + record["状態"]);
    }
  }

  assert.equal(confirmed, 7);
  assert.equal(cancelled, 1);
  assert.deepEqual(Array.from(usedNames).sort(), [...FICTIONAL_NAMES].sort());
});

test("実在の会社名・社内でだけ使う呼び名を含まない", () => {
  const data = sampleData(TODAY);
  const text = JSON.stringify(data);
  for (const word of FORBIDDEN_WORDS) assert.equal(text.includes(word), false, word + " が見本データに含まれています");
});

test("samples/*.csv は sampleData(\"2026-09-18\") の中身と一致する（古ければ npm run samples）", () => {
  const files = sampleCsvFiles(TODAY);
  assert.deepEqual(Object.keys(files), ["設定.csv", "枠.csv", "休み.csv", "サービス.csv", "予約.csv"]);
  for (const name of Object.keys(files)) {
    const path = join(root, "samples", name);
    assert.ok(existsSync(path), path + " がありません。npm run samples を実行してください");
    assert.equal(readFileSync(path, "utf8"), files[name], path + " が古いです。npm run samples を実行してください");
  }
  assert.ok(files["設定.csv"].startsWith("﻿項目,値\r\n"));
});
