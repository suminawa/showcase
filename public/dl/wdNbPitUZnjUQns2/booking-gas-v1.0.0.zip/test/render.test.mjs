import { test } from "node:test";
import assert from "node:assert/strict";
import { addDays } from "../src/dates.js";
import { initialState, reduce } from "../src/ui/state.js";
import { renderApp, renderCalendar, renderCancel, renderConfirm, renderDone, renderError, renderForm, renderServices, renderSlots } from "../src/ui/render.js";

const SHOP = {
  name: "ひだまり整体院",
  phone: "045-000-0000",
  address: "横浜市中区みなと町 1-2-3",
  notice: "初めての方は、開始の 10 分前にお越しください。",
  themeColor: "#2f6f5e",
  phoneRequired: false,
  dateFormat: "yyyy-MM-dd",
  cancelHours: 24,
  leadHours: 24,
};

const SERVICES = [
  { name: "初回カウンセリング", minutes: 60, description: "初めての方はこちら" },
  { name: "通常の施術", minutes: null, description: "" },
];

/** 今日（2026-09-18・金）から 30 日ぶん。最後は 2026-10-17 */
const STATUS = {
  "2026-09-18": "closed",
  "2026-10-03": "open",
  "2026-10-04": "few",
  "2026-10-05": "full",
  "2026-10-06": "closed",
  "2026-10-07": "past",
};
const DAYS = (function () {
  const out = [];
  let date = "2026-09-18";
  for (let i = 0; i < 30; i += 1) {
    out.push({ date: date, status: STATUS[date] || "open" });
    date = addDays(date, 1);
  }
  return out;
})();

const BOOT = { shop: SHOP, services: SERVICES, days: DAYS, today: "2026-09-18", errors: [] };
const SLOTS = [
  { start: "10:00", end: "10:45", remaining: 1 },
  { start: "11:00", end: "11:45", remaining: 0 },
];

function boot_(extra) {
  return reduce(initialState(), { type: "bootstrap", data: Object.assign({}, BOOT, extra || {}) });
}

/** 入力画面まで進めた state。shop を差し替えたいときは extra で */
function atForm_(extra) {
  let s = boot_(extra);
  s = reduce(s, { type: "select-service", name: "初回カウンセリング" });
  s = reduce(s, { type: "select-date", date: "2026-10-03" });
  s = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  s = reduce(s, { type: "select-slot", start: "10:00" });
  s = reduce(s, { type: "input", field: "name", value: "山川 <太郎>" });
  s = reduce(s, { type: "input", field: "email", value: "taro@example.com" });
  s = reduce(s, { type: "input", field: "phone", value: "045-111-2222" });
  return reduce(s, { type: "input", field: "note", value: "肩こりが気になります。" });
}

/** サービスを登録していない店で、入力画面まで進めた state */
function atFormNoService_() {
  let s = boot_({ services: [] });
  s = reduce(s, { type: "select-date", date: "2026-10-03" });
  s = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  s = reduce(s, { type: "select-slot", start: "10:00" });
  s = reduce(s, { type: "input", field: "name", value: "山川 太郎" });
  s = reduce(s, { type: "input", field: "email", value: "taro@example.com" });
  return s;
}

/** その日付のマス（<td …>…）だけを取り出す */
function cellOf_(html, date) {
  const parts = html.split("<td");
  for (let i = 0; i < parts.length; i += 1) {
    if (parts[i].includes('data-date="' + date + '"')) return parts[i];
  }
  return "";
}

test("外枠: 店名の見出しと、テーマ色は 16 進のときだけ style に入れる", () => {
  const html = renderApp(boot_());
  assert.ok(html.includes('<div class="bk-shell"'));
  assert.ok(html.includes("ひだまり整体院"));
  assert.ok(html.includes('style="--bk-accent: #2f6f5e"'));
  assert.ok(renderApp(boot_({ shop: Object.assign({}, SHOP, { themeColor: "#abc" }) })).includes('style="--bk-accent: #abc"'));
  for (const bad of ["red", "#12345", "", "#fff\" onload=\"alert(1)", "url(x)"]) {
    const out = renderApp(boot_({ shop: Object.assign({}, SHOP, { themeColor: bad }) }));
    assert.equal(out.includes("--bk-accent"), false, "色として読めない値は style に入れない: " + bad);
    assert.equal(out.includes("onload"), false);
  }
});

test("読み込み中と、受付を止めているときの画面", () => {
  assert.ok(renderApp(initialState()).includes("読み込んでいます…"));
  const stopped = boot_({ errors: ["ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。"], days: [] });
  const html = renderApp(stopped);
  assert.ok(html.includes('role="alert"'));
  assert.ok(html.includes("ただいま予約を受け付けられません。お手数ですが、お電話でご連絡ください。"));
  // お店の電話は、そのままかけられるようにする
  assert.ok(html.includes('href="tel:0450000000"'));
  assert.ok(html.includes("045-000-0000"));
  // お店の中の言葉は出さない
  for (const word of ["設定", "シート", "booking: ", "<li>"]) {
    assert.equal(html.includes(word), false, word);
  }

  // 電話を登録していないお店では、文だけを出す
  const noPhone = renderApp(boot_({ shop: Object.assign({}, SHOP, { phone: "" }), errors: ["ただいま予約を受け付けられません。"], days: [] }));
  assert.ok(noPhone.includes("ただいま予約を受け付けられません。"));
  assert.equal(noPhone.includes("tel:"), false);
});

test("誤りの帯: role=alert と閉じるボタン。誤りが無ければ出さない", () => {
  assert.equal(renderError(boot_()), "");
  const s = reduce(boot_(), { type: "error", message: "ただいま満席になりました。<br>" });
  const html = renderError(s);
  assert.ok(html.includes('class="bk-error"'));
  assert.ok(html.includes('role="alert"'));
  assert.ok(html.includes("ただいま満席になりました。&lt;br&gt;"));
  assert.equal(html.includes("<br>"), false);
  assert.ok(html.includes('data-action="dismiss-error"'));
  assert.ok(renderApp(s).includes('data-action="dismiss-error"'), "帯は外枠にも出る");
});

test("サービス: ボタンに名前・所要時間・説明。名前は data-name に入れてエスケープする", () => {
  const s = boot_({ services: [{ name: "初回<相談>", minutes: 60, description: "初めての方はこちら" }, SERVICES[1]] });
  const html = renderServices(s);
  assert.ok(html.includes('data-action="select-service"'));
  assert.ok(html.includes('data-name="初回&lt;相談&gt;"'));
  assert.equal(html.includes("<相談>"), false);
  assert.ok(html.includes("60 分"));
  assert.ok(html.includes("初めての方はこちら"));
  assert.ok(html.includes("通常の施術"));
  assert.equal(html.includes("null 分"), false, "所要時間が無いサービスには分を出さない");
  assert.ok(renderApp(s).includes('data-action="select-service"'));
});

test("カレンダー: 月の見出し・曜日・○△・押せない日・今日", () => {
  let s = reduce(boot_(), { type: "select-service", name: "初回カウンセリング" });
  const september = renderCalendar(s);
  assert.ok(september.includes("2026年9月"));
  assert.ok(september.includes('<table class="bk-cal">'));
  assert.ok(september.includes("<caption"));
  assert.ok(september.includes("<thead"));
  for (const day of ["日", "月", "火", "水", "木", "金", "土"]) {
    assert.ok(september.includes(">" + day + "</th>"), day + " の見出し");
  }
  assert.ok(cellOf_(september, "2026-09-18").includes("bk-today"), "今日のマスに bk-today");
  assert.equal(cellOf_(september, "2026-09-19").includes("bk-today"), false);
  assert.equal(september.includes('data-date="2026-09-17"'), false, "受け付ける範囲の外は空のマス");
  assert.equal(september.includes('data-date="2026-10-01"'), false, "別の月は出さない");

  s = reduce(s, { type: "month", delta: 1 });
  const october = renderCalendar(s);
  assert.ok(october.includes("2026年10月"));

  const open = cellOf_(october, "2026-10-03");
  assert.ok(open.includes('data-action="select-date"'));
  assert.ok(open.includes("○"));
  assert.ok(open.includes(">3<"), "日の数字");
  assert.equal(open.includes("disabled"), false);

  assert.ok(cellOf_(october, "2026-10-04").includes("△"));

  const full = cellOf_(october, "2026-10-05");
  assert.ok(full.includes("disabled"));
  assert.ok(full.includes('aria-disabled="true"'));
  assert.ok(full.includes("満席"));
  assert.ok(full.includes(">5<"), "押せない日も日の数字は出す");
  assert.equal(full.includes('data-action="select-date"'), false, "押せない日に data-action は付けない");
  assert.ok(cellOf_(october, "2026-10-06").includes("受付なし"));
  assert.ok(cellOf_(october, "2026-10-07").includes("受付終了"));
  assert.equal(october.includes('data-date="2026-10-18"'), false, "受け付ける範囲の外は空のマス");
  assert.equal(cellOf_(october, "2026-10-03").includes("bk-today"), false);
});

test("カレンダー: 月の前後のボタンは、今日の月と最後の月で押せなくなる", () => {
  let s = boot_();
  const september = renderCalendar(s);
  assert.ok(september.includes('data-action="month" data-delta="-1"'));
  assert.ok(september.includes('data-action="month" data-delta="1"'));
  assert.match(september, /data-delta="-1"[^>]*disabled/, "今日の月では前の月を押せない");
  assert.equal(/data-delta="1"[^>]*disabled/.test(september), false);

  const october = renderCalendar(reduce(s, { type: "month", delta: 1 }));
  assert.match(october, /data-delta="1"[^>]*disabled/, "最後の日の月では次の月を押せない");
  assert.equal(/data-delta="-1"[^>]*disabled/.test(october), false);
});

test("カレンダー: 印は選ばれたサービスのぶん（state.days）を使う", () => {
  // 通常の施術では 10/3 に枠が無い店
  const regular = DAYS.map((day) => (day.date === "2026-10-03" ? { date: day.date, status: "closed" } : day));
  const base = boot_({ daysByService: { 初回カウンセリング: DAYS, 通常の施術: regular } });

  const first = reduce(reduce(base, { type: "select-service", name: "初回カウンセリング" }), { type: "month", delta: 1 });
  const openCell = cellOf_(renderCalendar(first), "2026-10-03");
  assert.ok(openCell.includes('data-action="select-date"'));
  assert.ok(openCell.includes("○"));

  const other = reduce(reduce(base, { type: "select-service", name: "通常の施術" }), { type: "month", delta: 1 });
  const closedCell = cellOf_(renderCalendar(other), "2026-10-03");
  assert.ok(closedCell.includes("受付なし"));
  assert.ok(closedCell.includes("disabled"));
  assert.equal(closedCell.includes('data-action="select-date"'), false);
});

test("カレンダー: サービスが 2 つ以上なら選び直せる戻るボタンを出す", () => {
  const many = renderCalendar(reduce(boot_(), { type: "select-service", name: "初回カウンセリング" }));
  assert.ok(many.includes('data-action="back"'));
  assert.ok(many.includes("初回カウンセリング"));
  const one = renderCalendar(boot_({ services: [SERVICES[0]] }));
  assert.equal(one.includes('data-action="back"'), false, "サービスが 1 つなら戻る先が無い");
});

test("時間: 読み込み中・空・一覧・満席", () => {
  let s = reduce(boot_(), { type: "select-service", name: "初回カウンセリング" });
  s = reduce(s, { type: "select-date", date: "2026-10-03" });
  assert.ok(renderSlots(s).includes("空きを読み込んでいます…"));

  const empty = reduce(s, { type: "slots", date: "2026-10-03", slots: [] });
  assert.ok(renderSlots(empty).includes("この日は受け付けていません。"));

  const filled = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  const html = renderSlots(filled);
  assert.ok(html.includes("10/3（土）"), "見出しに短い日付");
  assert.ok(html.includes("初回カウンセリング"), "見出しにサービス名");
  assert.ok(html.includes('data-action="select-slot" data-start="10:00"'));
  assert.ok(html.includes("10:00〜10:45"));
  assert.ok(html.includes("残り 1"));
  assert.ok(html.includes("11:00〜11:45"));
  const fullItem = html.split("<li>").filter((part) => part.includes("11:00〜11:45"))[0];
  assert.ok(fullItem.includes("満席"));
  assert.ok(fullItem.includes("disabled"), "満席の枠は押せない");
  assert.equal(html.includes('data-start="11:00"'), false, "満席の枠に data-start は付けない");
  assert.ok(html.includes('data-action="back"'));
});

test("入力: ラベルと入力が for / id で結ばれ、字数の上限と autocomplete が付く", () => {
  const html = renderForm(atForm_());
  assert.ok(html.includes('<form class="bk-form" data-form="reserve" novalidate>'));
  assert.ok(html.includes("2026-10-03（土）"));
  assert.ok(html.includes("10:00〜10:45"));
  assert.ok(html.includes("初回カウンセリング"));

  assert.ok(html.includes('<label for="bk-f-name"'));
  assert.ok(html.includes('id="bk-f-name"'));
  assert.ok(html.includes('name="name"'));
  assert.ok(html.includes('maxlength="40"'));
  assert.ok(html.includes('autocomplete="name"'));
  assert.ok(html.includes('type="email"'));
  assert.ok(html.includes('maxlength="100"'));
  assert.ok(html.includes('autocomplete="email"'));
  assert.ok(html.includes('type="tel"'));
  assert.ok(html.includes('maxlength="20"'));
  assert.ok(html.includes('autocomplete="tel"'));
  assert.ok(html.includes("<textarea"));
  assert.ok(html.includes('maxlength="500"'));
  assert.ok(html.includes("山川 &lt;太郎&gt;"), "入力した値は戻して出す");
  assert.equal(html.includes("<太郎>"), false);
  assert.ok(html.includes("肩こりが気になります。"));
  assert.ok(html.includes("初めての方は、開始の 10 分前にお越しください。"), "設定の注意書き");
  assert.ok(html.includes("確認へ"));
  assert.ok(html.includes('data-action="back"'));
});

test("入力: 見えない欄と、電話の必須", () => {
  const html = renderForm(atForm_());
  assert.ok(html.includes('<input type="text" name="website" class="bk-hp" tabindex="-1" autocomplete="off" aria-hidden="true" value="">'));
  const phoneField = html.split('for="bk-f-phone"')[1].split("</div>")[0];
  assert.equal(phoneField.includes("必須"), false, "設定が FALSE なら電話は任意");

  const required = renderForm(atForm_({ shop: Object.assign({}, SHOP, { phoneRequired: true }) }));
  assert.ok(required.split('for="bk-f-phone"')[1].split("</div>")[0].includes("必須"));
});

test("入力: 誤りは欄の下に出て、aria-describedby と aria-invalid で結ばれる", () => {
  const s = reduce(atForm_(), { type: "errors", errors: { name: "お名前をご記入ください", email: "メールアドレスの形式をご確認ください" } });
  const html = renderForm(s);
  assert.ok(html.includes('id="bk-err-name"'));
  assert.ok(html.includes("お名前をご記入ください"));
  assert.match(html, /id="bk-f-name"[^>]*aria-describedby="bk-err-name"/);
  assert.match(html, /id="bk-f-name"[^>]*aria-invalid="true"/);
  assert.ok(html.includes('id="bk-err-email"'));
  assert.equal(html.includes('aria-describedby="bk-err-note"'), false, "誤りの無い欄には付けない");
});

test("確認: 4 つの入力と日時・内容が並び、送信中はボタンを押せない", () => {
  const s = reduce(atForm_(), { type: "confirm" });
  const html = renderConfirm(s);
  assert.ok(html.includes("<dl"));
  for (const label of ["日時", "内容", "お名前", "メール", "電話", "ご要望"]) {
    assert.ok(html.includes("<dt>" + label + "</dt>"), label);
  }
  assert.ok(html.includes("2026-10-03（土）"));
  assert.ok(html.includes("10:00〜10:45"));
  assert.ok(html.includes("山川 &lt;太郎&gt;"));
  assert.equal(html.includes("<太郎>"), false);
  assert.ok(html.includes("taro@example.com"));
  assert.ok(html.includes("045-111-2222"));
  assert.ok(html.includes("肩こりが気になります。"));
  assert.ok(html.includes('data-action="reserve"'));
  assert.ok(html.includes("この内容で予約する"));
  assert.ok(html.includes('data-action="back"'));
  assert.equal(html.includes("disabled"), false);

  const busy = renderConfirm(reduce(s, { type: "busy", on: true }));
  assert.match(busy, /data-action="reserve"[^>]*disabled/);
  assert.match(busy, /data-action="back"[^>]*disabled/);
});

test("確認・入力: サービスの無い店でも「内容」の行を出し、中身は「ご予約」にする", () => {
  const s = atFormNoService_();
  const form = renderForm(s);
  assert.ok(form.includes("<dt>内容</dt>"));
  assert.ok(form.includes("<dd>ご予約</dd>"), "メールの文面と同じ言い方にそろえる");

  const html = renderConfirm(reduce(s, { type: "confirm" }));
  for (const label of ["日時", "内容", "お名前", "メール", "電話", "ご要望"]) {
    assert.ok(html.includes("<dt>" + label + "</dt>"), label);
  }
  assert.equal(html.split("<dt>").length - 1, 6, "6 行そろえる");
  assert.ok(html.includes("<dd>ご予約</dd>"));

  // サービスのある店では、選んだサービスの名前がそのまま入る
  const chosen = renderConfirm(reduce(atForm_(), { type: "confirm" }));
  assert.ok(chosen.includes("<dd>初回カウンセリング</dd>"));
  assert.equal(chosen.includes("ご予約</dd>"), false);
});

test("確認・入力: 日付の書式は設定どおり", () => {
  const slashed = reduce(atForm_({ shop: Object.assign({}, SHOP, { dateFormat: "yyyy/MM/dd" }) }), { type: "confirm" });
  assert.ok(renderConfirm(slashed).includes("2026/10/03（土）"));
  assert.equal(renderConfirm(slashed).includes("2026-10-03"), false);
});

test("完了: 受付番号と日時、メールを送れたかどうかの文、店の電話", () => {
  const result = { ok: true, id: "20260918-001", date: "2026-10-03", start: "10:00", end: "10:45", service: "初回カウンセリング", mailSent: true };
  const sent = renderDone(reduce(atForm_(), { type: "done", result: result }));
  assert.ok(sent.includes("ご予約を受け付けました。"));
  assert.ok(sent.includes("20260918-001"));
  assert.ok(sent.includes("2026-10-03（土）"));
  assert.ok(sent.includes("10:00〜10:45"));
  assert.ok(sent.includes("初回カウンセリング"));
  assert.ok(sent.includes("確認メールをお送りしました。"));
  assert.ok(sent.includes("045-000-0000"));

  const notSent = renderDone(reduce(atForm_(), { type: "done", result: Object.assign({}, result, { mailSent: false }) }));
  assert.ok(notSent.includes("受付はできています。確認メールは届いていませんので、この画面の受付番号をお控えください。"));
  assert.equal(notSent.includes("確認メールをお送りしました。"), false);

  const noPhone = renderDone(reduce(atForm_({ shop: Object.assign({}, SHOP, { phone: "" }) }), { type: "done", result: result }));
  assert.equal(noPhone.includes("お電話"), false, "電話の設定が空なら案内を出さない");
});

test("キャンセル: 見つからない・キャンセルできる・すでにキャンセル済み・締切後", () => {
  const reservation = { id: "20260918-001", date: "2026-10-03", start: "10:00", end: "10:45", service: "初回カウンセリング", name: "山川 <太郎>", status: "確定" };
  const missing = renderCancel(reduce(boot_(), { type: "cancel-info", data: { found: false } }));
  assert.ok(missing.includes("このご予約は見つかりませんでした。"));
  assert.equal(missing.includes('data-action="cancel"'), false);

  const canCancel = reduce(boot_(), { type: "cancel-info", data: { found: true, reservation: reservation, canCancel: true, phone: "045-000-0000" } });
  const html = renderCancel(canCancel);
  assert.ok(html.includes("<dl"));
  assert.ok(html.includes("20260918-001"));
  assert.ok(html.includes("2026-10-03（土）"));
  assert.ok(html.includes("10:00〜10:45"));
  assert.ok(html.includes("山川 &lt;太郎&gt;"));
  assert.equal(html.includes("<太郎>"), false);
  assert.ok(html.includes('data-action="cancel"'));
  assert.ok(html.includes("このご予約をキャンセルする"));
  assert.match(renderCancel(reduce(canCancel, { type: "busy", on: true })), /data-action="cancel"[^>]*disabled/);

  const already = renderCancel(reduce(boot_(), { type: "cancel-info", data: { found: true, reservation: Object.assign({}, reservation, { status: "キャンセル" }), canCancel: false, phone: "045-000-0000" } }));
  assert.ok(already.includes("このご予約はすでにキャンセルされています。"));
  assert.equal(already.includes('data-action="cancel"'), false);

  const late = renderCancel(reduce(boot_(), { type: "cancel-info", data: { found: true, reservation: reservation, canCancel: false, phone: "045-000-0000" } }));
  assert.ok(late.includes("キャンセルの受付は開始の 24 時間前までです。お電話でご連絡ください。"));
  assert.ok(late.includes("045-000-0000"));
  assert.equal(late.includes('data-action="cancel"'), false);
});

test("キャンセル後の画面", () => {
  let s = reduce(boot_(), { type: "cancel-info", data: { found: true, reservation: { id: "20260918-001", date: "2026-10-03", start: "10:00", end: "10:45", service: "初回カウンセリング", name: "山川 太郎", status: "確定" }, canCancel: true, phone: "045-000-0000" } });
  s = reduce(s, { type: "cancelled", id: "20260918-001" });
  const html = renderApp(s);
  assert.ok(html.includes("ご予約をキャンセルしました。"));
  assert.ok(html.includes("20260918-001"));
});

test("renderApp は step ごとに画面を出し分ける", () => {
  let s = boot_();
  assert.ok(renderApp(s).includes('data-action="select-service"'));
  s = reduce(s, { type: "select-service", name: "初回カウンセリング" });
  assert.ok(renderApp(s).includes('<table class="bk-cal">'));
  s = reduce(s, { type: "select-date", date: "2026-10-03" });
  assert.ok(renderApp(s).includes("空きを読み込んでいます…"));
  s = reduce(s, { type: "slots", date: "2026-10-03", slots: SLOTS });
  assert.ok(renderApp(s).includes('data-action="select-slot"'));
  s = reduce(s, { type: "select-slot", start: "10:00" });
  assert.ok(renderApp(s).includes('data-form="reserve"'));
  s = reduce(s, { type: "confirm" });
  assert.ok(renderApp(s).includes('data-action="reserve"'));
  s = reduce(s, { type: "done", result: { ok: true, id: "20260918-001", date: "2026-10-03", start: "10:00", end: "10:45", service: "初回カウンセリング", mailSent: true } });
  assert.ok(renderApp(s).includes("ご予約を受け付けました。"));
});
