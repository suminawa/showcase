import { test } from "node:test";
import assert from "node:assert/strict";
import {
  buildCancelMail,
  buildConfirmMail,
  buildOwnerMail,
  buildRemindMail,
  fillTemplate,
  safeCell,
  varsFor,
} from "../src/mail.js";
import { DEFAULT_SETTINGS } from "../src/settings.js";

function settings_(over) {
  return Object.assign({}, DEFAULT_SETTINGS, over);
}

// 2026-09-19 は土曜（rules.test.mjs / availability.test.mjs と同じ現実の暦で確かめている）
const RESERVATION = {
  ID: "20260918-001",
  状態: "確定",
  日付: "2026-09-19",
  開始: "10:00",
  終了: "11:00",
  サービス: "初回カウンセリング",
  お名前: "山川",
  メール: "taro@example.com",
  電話: "045-000-0000",
  ご要望: "特にありません",
};

const SHOP = settings_({ shopName: "ひだまり整体院", phone: "045-000-0000", address: "横浜市中区みなと町 1-2-3" });

test("fillTemplate: {名前} を差し替え、知らない名前はそのまま残す", () => {
  const out = fillTemplate("こんにちは {お名前} 様。{知らない名前} は残る。", { お名前: "山川" });
  assert.equal(out, "こんにちは 山川 様。{知らない名前} は残る。");
});

test("fillTemplate: テンプレが空でも壊れない", () => {
  assert.equal(fillTemplate("", { お名前: "山川" }), "");
  assert.equal(fillTemplate(null, {}), "");
});

test("varsFor: 日付は曜日つき、時間は 開始〜終了（既定の書式 yyyy-MM-dd）", () => {
  const vars = varsFor(DEFAULT_SETTINGS, RESERVATION, "https://example.com/c/abc");
  assert.equal(vars["日付"], "2026-09-19（土）");
  assert.equal(vars["時間"], "10:00〜11:00");
  assert.equal(vars["サービス"], "初回カウンセリング");
  assert.equal(vars["お名前"], "山川");
  assert.equal(vars["受付番号"], "20260918-001");
  assert.equal(vars["キャンセルURL"], "https://example.com/c/abc");
});

test("varsFor: 日付の書式 yyyy/MM/dd", () => {
  const vars = varsFor(settings_({ dateFormat: "yyyy/MM/dd" }), RESERVATION, "");
  assert.equal(vars["日付"], "2026/09/19（土）");
  assert.equal(vars["キャンセルURL"], "");
});

test("varsFor: サービスが空なら「ご予約」", () => {
  const vars = varsFor(DEFAULT_SETTINGS, Object.assign({}, RESERVATION, { サービス: "" }), "");
  assert.equal(vars["サービス"], "ご予約");
});

test("既定の確認メールを埋めると件名・本文どちらにも { が残らない", () => {
  const { subject, body } = buildConfirmMail(SHOP, RESERVATION, "https://example.com/c/abc");
  assert.equal(subject.includes("{"), false);
  assert.equal(body.includes("{"), false);
  assert.equal(subject, "ご予約を受け付けました（ひだまり整体院）");
  assert.ok(body.includes("山川 様"));
  assert.ok(body.includes("日時: 2026-09-19（土） 10:00〜11:00"));
  assert.ok(body.includes("受付番号: 20260918-001"));
  assert.ok(body.includes("https://example.com/c/abc"));
  assert.ok(body.includes("ひだまり整体院"));
});

test("既定のリマインド本文も件名・本文どちらにも { が残らない", () => {
  const { subject, body } = buildRemindMail(DEFAULT_SETTINGS, RESERVATION, "https://example.com/c/abc");
  assert.equal(subject.includes("{"), false);
  assert.equal(body.includes("{"), false);
  assert.equal(subject, "明日のご予約のご案内（予約ページ）");
});

test("buildOwnerMail: 件名と本文", () => {
  const { subject, body } = buildOwnerMail(DEFAULT_SETTINGS, RESERVATION);
  assert.equal(subject, "ご予約が入りました: 9/19（土）10:00 山川 様");
  assert.ok(body.includes("日時: 2026-09-19（土） 10:00〜11:00"));
  assert.ok(body.includes("サービス: 初回カウンセリング"));
  assert.ok(body.includes("お名前: 山川 様"));
  assert.ok(body.includes("メール: taro@example.com"));
  assert.ok(body.includes("電話: 045-000-0000"));
  assert.ok(body.includes("ご要望: 特にありません"));
  assert.ok(body.includes("受付番号: 20260918-001"));
});

test("buildOwnerMail: サービスが空でも件名が壊れない", () => {
  const { subject } = buildOwnerMail(DEFAULT_SETTINGS, Object.assign({}, RESERVATION, { サービス: "" }));
  assert.equal(subject, "ご予約が入りました: 9/19（土）10:00 山川 様");
});

test("buildCancelMail: 件名と本文", () => {
  const { subject, body } = buildCancelMail(SHOP, RESERVATION);
  assert.equal(subject, "ご予約をキャンセルしました（ひだまり整体院）");
  assert.ok(body.startsWith("山川 様"));
  assert.ok(body.includes("ご予約をキャンセルしました。"));
  assert.ok(body.includes("日時: 2026-09-19（土） 10:00〜11:00"));
  assert.ok(body.includes("内容: 初回カウンセリング"));
  assert.ok(body.includes("ひだまり整体院"));
  assert.ok(body.includes("045-000-0000"));
  assert.ok(body.trim().endsWith("横浜市中区みなと町 1-2-3"));
});

test("safeCell: 数式・タブ・改行よけ", () => {
  assert.equal(safeCell("=SUM(A1)"), "'=SUM(A1)");
  assert.equal(safeCell("+81"), "'+81");
  assert.equal(safeCell("-1"), "'-1");
  assert.equal(safeCell("@here"), "'@here");
  assert.equal(safeCell("\tタブ始まり"), "'\tタブ始まり");
  assert.equal(safeCell("\r改行"), "'\r改行");
  assert.equal(safeCell("\n改行"), "'\n改行");
  assert.equal(safeCell("ふつうの文字"), "ふつうの文字");
  assert.equal(safeCell("途中に=がある文字"), "途中に=がある文字");
  assert.equal(safeCell(""), "");
  assert.equal(safeCell(null), "");
  assert.equal(safeCell(undefined), "");
});

test("safeCell: 先頭が 0 の数字だけの文字列は、数にされないように ' を付ける", () => {
  // 電話番号をハイフン無しで入れると、そのままでは 9012345678 になって先頭の 0 が消える
  assert.equal(safeCell("09012345678"), "'09012345678");
  assert.equal(safeCell("0120000000"), "'0120000000");
  assert.equal(safeCell("0"), "0", "0 の 1 文字はそのまま");
  assert.equal(safeCell("01"), "'01");
  // 先頭が 0 でない数字は、これまでどおりそのまま（受付番号や定員の見た目を変えない）
  assert.equal(safeCell("123"), "123");
  assert.equal(safeCell("9012345678"), "9012345678");
  // 16 桁以上の数字は、表計算の数では桁が落ちるので文字として書く（合い言葉が数字だけになったときの備え）
  assert.equal(safeCell("123456789012345"), "123456789012345");
  assert.equal(safeCell("1234567890123456"), "'1234567890123456");
  assert.equal(safeCell("012345678901234567890123"), "'012345678901234567890123");
  // 日付と時刻は日付・時刻のセルのまま書く（並べ替えや絞り込みに使えるように）
  assert.equal(safeCell("2026-09-19"), "2026-09-19");
  assert.equal(safeCell("09:30"), "09:30");
  assert.equal(safeCell("2026-09-19 10:40:00"), "2026-09-19 10:40:00");
});
