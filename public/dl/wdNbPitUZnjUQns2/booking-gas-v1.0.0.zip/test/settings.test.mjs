import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_CONFIRM_BODY, DEFAULT_REMIND_BODY, DEFAULT_SETTINGS, SETTING_KEYS, parseSettings } from "../src/settings.js";

const ALL_KEYS = [
  "店名",
  "連絡先メール",
  "電話",
  "住所",
  "何日先まで",
  "何時間前まで",
  "キャンセルは何時間前まで",
  "電話を必須にする",
  "同じメールの予約数",
  "注意書き",
  "確認メールの件名",
  "確認メールの本文",
  "リマインドの件名",
  "リマインドの本文",
  "リマインドの時刻",
  "カレンダー ID",
  "Slack Webhook URL",
  "Discord Webhook URL",
  "LINE チャネルアクセストークン",
  "LINE 送信先 ID",
  "テーマ色",
  "日付の書式",
];

test("SETTING_KEYS は設計書 §3 の 22 項目、この順", () => {
  assert.equal(SETTING_KEYS.length, 22);
  assert.deepEqual(SETTING_KEYS, ALL_KEYS);
});

test("既定の確認メール・リマインドの本文は設計書のとおり", () => {
  const confirm = [
    "{お名前} 様",
    "",
    "ご予約を受け付けました。",
    "",
    "日時: {日付} {時間}",
    "内容: {サービス}",
    "受付番号: {受付番号}",
    "",
    "ご都合が悪くなった場合は、下の URL からキャンセルできます。",
    "{キャンセルURL}",
    "",
    "{店名}",
    "{電話}",
    "{住所}",
  ].join("\n");
  const remind = [
    "{お名前} 様",
    "",
    "明日のご予約のご案内です。",
    "",
    "日時: {日付} {時間}",
    "内容: {サービス}",
    "受付番号: {受付番号}",
    "",
    "ご都合が悪くなった場合は、下の URL からキャンセルできます。",
    "{キャンセルURL}",
    "",
    "{店名}",
    "{電話}",
    "{住所}",
  ].join("\n");
  assert.equal(DEFAULT_CONFIRM_BODY, confirm);
  assert.equal(DEFAULT_REMIND_BODY, remind);
  assert.equal(DEFAULT_SETTINGS.confirmBody, DEFAULT_CONFIRM_BODY);
  assert.equal(DEFAULT_SETTINGS.remindBody, DEFAULT_REMIND_BODY);
});

test("空欄・見出し行だけなら誤りなく既定値になる", () => {
  const empty = parseSettings([]);
  assert.deepEqual(empty.errors, []);
  assert.deepEqual(empty.settings, DEFAULT_SETTINGS);

  const headerOnly = parseSettings([
    ["項目", "値"],
    ["何日先まで", ""],
  ]);
  assert.deepEqual(headerOnly.errors, []);
  assert.deepEqual(headerOnly.settings, DEFAULT_SETTINGS);
});

test("22 項目すべてを設定すると読み込める（見出し行なし）", () => {
  const rows = [
    ["店名", "ひだまり整体院"],
    ["連絡先メール", "info@example.com"],
    ["電話", "045-000-0000"],
    ["住所", "横浜市中区みなと町 1-2-3"],
    ["何日先まで", "60"],
    ["何時間前まで", "48"],
    ["キャンセルは何時間前まで", "12"],
    ["電話を必須にする", "TRUE"],
    ["同じメールの予約数", "5"],
    ["注意書き", "当日は 5 分前にお越しください。"],
    ["確認メールの件名", "ご予約ありがとうございます"],
    ["確認メールの本文", "確認メールの本文のテストです。"],
    ["リマインドの件名", "明日のご案内"],
    ["リマインドの本文", "リマインド本文のテストです。"],
    ["リマインドの時刻", "9"],
    ["カレンダー ID", "primary"],
    ["Slack Webhook URL", "https://hooks.slack.com/services/xxx"],
    ["Discord Webhook URL", "https://discord.com/api/webhooks/xxx"],
    ["LINE チャネルアクセストークン", "line-token-xxx"],
    ["LINE 送信先 ID", "line-to-xxx"],
    ["テーマ色", "#123abc"],
    ["日付の書式", "yyyy/MM/dd"],
  ];
  assert.equal(rows.length, 22, "テストの行数が 22 項目からずれていないことの確認");
  const { settings, errors } = parseSettings(rows);
  assert.deepEqual(errors, []);
  assert.deepEqual(settings, {
    shopName: "ひだまり整体院",
    contactEmail: "info@example.com",
    phone: "045-000-0000",
    address: "横浜市中区みなと町 1-2-3",
    daysAhead: 60,
    leadHours: 48,
    cancelHours: 12,
    phoneRequired: true,
    maxPerEmail: 5,
    notice: "当日は 5 分前にお越しください。",
    confirmSubject: "ご予約ありがとうございます",
    confirmBody: "確認メールの本文のテストです。",
    remindSubject: "明日のご案内",
    remindBody: "リマインド本文のテストです。",
    remindHour: 9,
    calendarId: "primary",
    slackUrl: "https://hooks.slack.com/services/xxx",
    discordUrl: "https://discord.com/api/webhooks/xxx",
    lineToken: "line-token-xxx",
    lineTo: "line-to-xxx",
    themeColor: "#123abc",
    dateFormat: "yyyy/MM/dd",
  });
});

test("全角の数字も半角として読む「３０」→ 30", () => {
  const { settings, errors } = parseSettings([["何日先まで", "３０"]]);
  assert.deepEqual(errors, []);
  assert.equal(settings.daysAhead, 30);
});

test("範囲外・色・メール・書式の誤りは敬体で並び、誤りの項目だけ既定値のまま。他の項目は読み込む", () => {
  const rows = [
    ["何日先まで", "0"],
    ["何時間前まで", "800"],
    ["キャンセルは何時間前まで", "-1"],
    ["同じメールの予約数", "0"],
    ["リマインドの時刻", "24"],
    ["テーマ色", "green"],
    ["連絡先メール", "not-an-email"],
    ["日付の書式", "dd/MM/yyyy"],
    ["店名", "ひだまり整体院"],
  ];
  const { settings, errors } = parseSettings(rows);
  assert.deepEqual(errors, [
    "booking: 設定「何日先まで」は 1〜180 にしてください",
    "booking: 設定「何時間前まで」は 0〜720 にしてください",
    "booking: 設定「キャンセルは何時間前まで」は 0〜720 にしてください",
    "booking: 設定「同じメールの予約数」は 1〜20 にしてください",
    "booking: 設定「リマインドの時刻」は 0〜23 にしてください",
    "booking: 設定「テーマ色」は #2f6f5e のような形にしてください",
    "booking: 設定「連絡先メール」の形式をご確認ください",
    "booking: 設定「日付の書式」は yyyy-MM-dd か yyyy/MM/dd にしてください",
  ]);
  // 誤りのあった項目は既定値のまま
  assert.equal(settings.daysAhead, DEFAULT_SETTINGS.daysAhead);
  assert.equal(settings.leadHours, DEFAULT_SETTINGS.leadHours);
  assert.equal(settings.cancelHours, DEFAULT_SETTINGS.cancelHours);
  assert.equal(settings.maxPerEmail, DEFAULT_SETTINGS.maxPerEmail);
  assert.equal(settings.remindHour, DEFAULT_SETTINGS.remindHour);
  assert.equal(settings.themeColor, DEFAULT_SETTINGS.themeColor);
  assert.equal(settings.contactEmail, DEFAULT_SETTINGS.contactEmail);
  assert.equal(settings.dateFormat, DEFAULT_SETTINGS.dateFormat);
  // 誤りが無かった項目は読み込まれる
  assert.equal(settings.shopName, "ひだまり整体院");
});

test("テーマ色は 3 桁の 16 進も通る", () => {
  const { settings, errors } = parseSettings([["テーマ色", "#0f0"]]);
  assert.deepEqual(errors, []);
  assert.equal(settings.themeColor, "#0f0");
});

test("知らない行は無視する", () => {
  const { settings, errors } = parseSettings([
    ["項目", "値"],
    ["謎の項目", "abc"],
    ["", ""],
    ["何日先まで", "45"],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(settings.daysAhead, 45);
  assert.equal(settings.shopName, DEFAULT_SETTINGS.shopName);
});

test("電話を必須にするは boolOf と同じ読み方（はい・いいえ・1・0・○・×も）", () => {
  assert.equal(parseSettings([["電話を必須にする", "TRUE"]]).settings.phoneRequired, true);
  assert.equal(parseSettings([["電話を必須にする", "はい"]]).settings.phoneRequired, true);
  assert.equal(parseSettings([["電話を必須にする", "0"]]).settings.phoneRequired, false);
  assert.equal(parseSettings([["電話を必須にする", ""]]).settings.phoneRequired, false);
});
