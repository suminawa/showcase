/**
 * Google カレンダーへの登録と削除。設定「カレンダー ID」が空なら何もしない。
 * 失敗しても予約は成立させたいので、例外は握って ""／false を返し、実行ログに残す（設計書 §2-6）。
 */
import { MEET_REASONS, apiCalendarId, apiEventId, meetPatch, meetStatusOf, meetUrlOf } from "./calendar.js";
import { dateTimeFromKey } from "./dates.js";
import { textOf } from "./text.js";

/** 設定のカレンダー。ID が空・開けないときは null（「設定を確かめる」も、開けるかどうかをこれで見る） */
export function calendarOf_(settings) {
  const id = textOf(settings === null || settings === undefined ? "" : settings.calendarId);
  if (id === "") return null;
  // CalendarApp の getCalendarById は "primary" を受け付けない（null が返る）。主カレンダーは getDefaultCalendar で開く
  const calendar = id.toLowerCase() === "primary" ? CalendarApp.getDefaultCalendar() : CalendarApp.getCalendarById(id);
  if (!calendar) {
    Logger.log("予約ページ: カレンダーが見つかりませんでした（設定「カレンダー ID」をご確認ください）");
    return null;
  }
  return calendar;
}

/** event は calendar.js の eventFor が返したもの。登録できたら予定の ID、できなければ "" */
export function createEvent_(settings, event) {
  try {
    const calendar = calendarOf_(settings);
    if (calendar === null) return "";
    const source = event === null || event === undefined ? {} : event;
    const start = dateTimeFromKey(source.start);
    const end = dateTimeFromKey(source.end);
    if (start === null || end === null) {
      Logger.log("予約ページ: 予定の日時を読み取れなかったため、カレンダーには登録しませんでした");
      return "";
    }
    const made = calendar.createEvent(textOf(source.title), start, end, { description: textOf(source.description) });
    return textOf(made ? made.getId() : "");
  } catch (error) {
    Logger.log("予約ページ: 予定を登録できませんでした: " + error);
    return "";
  }
}

/** 予定を消せたら true。無い・消せないときは false */
export function deleteEvent_(settings, eventId) {
  try {
    const id = textOf(eventId);
    if (id === "") return false;
    const calendar = calendarOf_(settings);
    if (calendar === null) return false;
    const event = calendar.getEventById(id);
    if (!event) {
      Logger.log("予約ページ: 消す予定が見つかりませんでした");
      return false;
    }
    event.deleteEvent();
    return true;
  } catch (error) {
    Logger.log("予約ページ: 予定を消せませんでした: " + error);
    return false;
  }
}

/** 会議の作成が「作っている途中」で返ってきたときに、読み直すまで待つ時間 */
const MEET_WAIT_MS_ = 2000;

/** 拡張サービスの Calendar（appsscript.json の enabledAdvancedServices）が使えるか */
export function hasCalendarApi_() {
  return typeof Calendar !== "undefined" && Calendar !== null && typeof Calendar.Events === "object" && Calendar.Events !== null;
}

/**
 * 登録した予定に Google Meet の会議を付ける。{ url, reason } を返し、例外は投げない。
 * url が "" のときは reason に理由（calendar.js の MEET_REASONS）が入る。予定そのものは消さない
 */
export function addMeet_(settings, eventId) {
  if (!hasCalendarApi_()) return { url: "", reason: MEET_REASONS.noService };
  if (textOf(settings === null || settings === undefined ? "" : settings.calendarId) === "") return { url: "", reason: MEET_REASONS.noCalendar };
  if (textOf(eventId) === "") return { url: "", reason: MEET_REASONS.noEvent };
  try {
    const calendarId = apiCalendarId(settings.calendarId);
    const id = apiEventId(eventId);
    let event = Calendar.Events.patch(meetPatch(Utilities.getUuid()), calendarId, id, { conferenceDataVersion: 1 });
    // 作っている途中（pending）で返ることがある。1 回だけ待って読み直す
    if (meetUrlOf(event) === "" && meetStatusOf(event) === "pending") {
      Utilities.sleep(MEET_WAIT_MS_);
      event = Calendar.Events.get(calendarId, id);
    }
    const url = meetUrlOf(event);
    if (url !== "") return { url: url, reason: "" };
    Logger.log("予約ページ: Google Meet の会議を作れませんでした（状態: " + (meetStatusOf(event) || "なし") + "）");
    return { url: "", reason: MEET_REASONS.refused };
  } catch (error) {
    Logger.log("予約ページ: Google Meet の会議を作れませんでした: " + error);
    return { url: "", reason: MEET_REASONS.refused };
  }
}
