/**
 * 確認・リマインド・キャンセルのメール文と、店への知らせメールを作る。
 * 差し込みは fillTemplate（{お名前} など）。メールは文字だけで、HTML にはしない。
 */
import { longDateOf, shortDateOf } from "./dates.js";
import { findService } from "./services.js";
import { textOf } from "./text.js";

/**
 * シートのセルに書く前に、数式と誤認される文字列と、数として読まれて形の崩れる文字列を無害にする。
 * ' を前置するのは次の 3 つ。空はそのまま（設計書 §7）
 *   1. 先頭が = + - @ かタブ・CR・LF（数式・コマンドと誤認される）
 *   2. 先頭が 0 の数字だけの文字列（"09012345678" が 9012345678 になって先頭の 0 が消える）
 *   3. 16 桁以上の数字だけの文字列（表計算の数は 15 桁までしか正しく持てない）
 * 日付（"2026-09-22"）と時刻（"11:00"）はここに当てはまらないので、これまでどおり日付・時刻のセルとして書く
 * （並べ替えや絞り込みに使えるようにするため。読み戻す toDateKey / parseTime は Date でも文字でも読める）
 */
export function safeCell(value) {
  const text = value === null || value === undefined ? "" : String(value);
  if (text === "") return text;
  const numberLike = /^0\d+$/.test(text) || (/^\d+$/.test(text) && text.length > 15);
  return /^[=+\-@\t\r\n]/.test(text) || numberLike ? "'" + text : text;
}

/**
 * テンプレの {お名前} のような差し込みを置き換える。
 * vars に無い名前は、そのままの字（{…}）で残す
 */
export function fillTemplate(template, vars) {
  const map = vars === null || vars === undefined ? {} : vars;
  const text = template === null || template === undefined ? "" : String(template);
  return text.replace(/\{([^{}\n]+)\}/g, function (whole, name) {
    return Object.prototype.hasOwnProperty.call(map, name) ? String(map[name]) : whole;
  });
}

/**
 * メールの差し込み用の値。settings.dateFormat に沿って日付を作り、曜日を付ける。
 * reservation はシートの見出し名をキーにした 1 件（ID 状態 日付 開始 終了 サービス お名前 メール 電話 ご要望）
 */
export function varsFor(settings, reservation, cancelUrl) {
  const s = settings === null || settings === undefined ? {} : settings;
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const service = textOf(row["サービス"]);
  return {
    "お名前": textOf(row["お名前"]),
    "日付": longDateOf(row["日付"], s.dateFormat),
    "時間": textOf(row["開始"]) + "〜" + textOf(row["終了"]),
    "サービス": service === "" ? "ご予約" : service,
    "店名": textOf(s.shopName),
    "電話": textOf(s.phone),
    "住所": textOf(s.address),
    "受付番号": textOf(row["ID"]),
    "キャンセルURL": cancelUrl === null || cancelUrl === undefined ? "" : String(cancelUrl),
  };
}

/** 会議の URL が無い（作れなかった）ときに、お客さまへのメールに入れる 1 行 */
export const MEET_LATER_LINE = "会議の URL は追ってお知らせします。";

/** 会議の URL をメールに入れる 1 行 */
export function meetUrlLine(url) {
  return "オンラインの会議の URL: " + textOf(url);
}

/**
 * お客さまへのメールに入れる会議の 1 行。URL があればその行、オンラインのサービスで URL が無ければ「追って」の行、
 * それ以外（対面のサービス）は ""。URL は「予約」シートの「会議URL」列から読む（店が手で書いた URL も載る）
 */
export function meetLineFor(services, reservation) {
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const url = textOf(row["会議URL"]);
  if (url !== "") return meetUrlLine(url);
  const service = findService(services, row["サービス"]);
  return service !== null && service.meet === true ? MEET_LATER_LINE : "";
}
/**
 * 本文に会議の 1 行を入れる。本文に {会議URL} があればそこに（1.2 より前の本文にも効くように）、
 * 無ければ「受付番号」で始まる行のすぐ下に、それも無ければ末尾に足す。line が "" なら本文はそのまま
 */
export function withMeetLine(template, vars, line) {
  const text = template === null || template === undefined ? "" : String(template);
  if (text.indexOf("{会議URL}") >= 0) return fillTemplate(text, Object.assign({}, vars, { "会議URL": line }));
  const body = fillTemplate(text, vars);
  if (line === "") return body;
  const lines = body.split("\n");
  for (let i = 0; i < lines.length; i += 1) {
    if (lines[i].indexOf("受付番号") === 0) {
      lines.splice(i + 1, 0, line);
      return lines.join("\n");
    }
  }
  return body + "\n\n" + line;
}

/** 確認メール（設定「確認メールの件名・本文」に差し込む）。services は会議の 1 行を決めるのに使う */
export function buildConfirmMail(settings, reservation, cancelUrl, services) {
  const s = settings === null || settings === undefined ? {} : settings;
  const vars = varsFor(s, reservation, cancelUrl);
  return { subject: fillTemplate(s.confirmSubject, vars), body: withMeetLine(s.confirmBody, vars, meetLineFor(services, reservation)) };
}

/** 前日リマインドのメール（設定「リマインドの件名・本文」に差し込む） */
export function buildRemindMail(settings, reservation, cancelUrl, services) {
  const s = settings === null || settings === undefined ? {} : settings;
  const vars = varsFor(s, reservation, cancelUrl);
  return { subject: fillTemplate(s.remindSubject, vars), body: withMeetLine(s.remindBody, vars, meetLineFor(services, reservation)) };
}

/**
 * 店に知らせる会議の 1 行。meetFailure は会議を作れなかった理由（calendar.js の MEET_REASONS）。
 * オンラインでないご予約は ""
 */
export function ownerMeetLine(services, reservation, meetFailure) {
  const line = meetLineFor(services, reservation);
  if (line !== MEET_LATER_LINE) return line;
  return (
    "オンラインの会議: 作れませんでした。" + textOf(meetFailure) +
    " お客さまのメールには「" + MEET_LATER_LINE + "」と書いています。カレンダーの予定に Meet を付け、その URL を「予約」シートの「会議URL」列に書くと、前日のリマインドに載ります。"
  );
}

/** 店（連絡先メール）へ送る、予約が入ったことの知らせ */
export function buildOwnerMail(settings, reservation, services, meetFailure) {
  const s = settings === null || settings === undefined ? {} : settings;
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const vars = varsFor(s, row, "");
  const lines = [
    "ご予約が入りました。",
    "",
    "日時: " + vars["日付"] + " " + vars["時間"],
    "サービス: " + vars["サービス"],
    "お名前: " + vars["お名前"] + " 様",
    "メール: " + textOf(row["メール"]),
    "電話: " + textOf(row["電話"]),
    "ご要望: " + textOf(row["ご要望"]),
    "受付番号: " + vars["受付番号"],
  ];
  const meet = ownerMeetLine(services, row, meetFailure);
  if (meet !== "") lines.push(meet);
  const subject =
    "ご予約が入りました: " + shortDateOf(textOf(row["日付"])) + textOf(row["開始"]) + " " + textOf(row["お名前"]) + " 様";
  return { subject: subject, body: lines.join("\n") };
}

/** お客さまへ送る、キャンセルの確認メール */
export function buildCancelMail(settings, reservation) {
  const s = settings === null || settings === undefined ? {} : settings;
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const vars = varsFor(s, row, "");
  const lines = [
    vars["お名前"] + " 様",
    "",
    "ご予約をキャンセルしました。",
    "",
    "日時: " + vars["日付"] + " " + vars["時間"],
    "内容: " + vars["サービス"],
    "",
    vars["店名"],
    vars["電話"],
    vars["住所"],
  ];
  return { subject: fillTemplate("ご予約をキャンセルしました（{店名}）", vars), body: lines.join("\n") };
}
