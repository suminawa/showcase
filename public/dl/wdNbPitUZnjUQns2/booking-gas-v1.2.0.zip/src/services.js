/**
 * 「サービス」シート（任意。予約の種類ごとの所要時間・説明・受付可否・オンライン（Meet）か）を読む。
 * 「オンライン」列は 1.2 で足した列。無いシート（1.1 までの）でも、すべて「付けない」として読む。
 * 誤りは敬体の文で `booking: ` から始めて集め、誤りのあった行は services に含めない。
 */
import { integerInRange } from "./dates.js";
import { boolOf, errorAt, headerIndex, isBlankRow, textOf } from "./text.js";

/**
 * 「サービス」シートの 2 次元配列（1 行目が見出し）→ { services, errors }。
 * サービス名が空・重複、所要時間が範囲外の行は services に含めない
 */
export function parseServices(values) {
  const rows = Array.isArray(values) ? values : [];
  const services = [];
  const errors = [];
  if (rows.length < 2) return { services: services, errors: errors };

  const header = Array.isArray(rows[0]) ? rows[0] : [];
  const col = {
    name: headerIndex(header, "サービス"),
    minutes: headerIndex(header, "所要時間"),
    description: headerIndex(header, "説明"),
    active: headerIndex(header, "受付"),
    meet: headerIndex(header, "オンライン"),
  };

  const seen = new Set();

  for (let i = 1; i < rows.length; i += 1) {
    const row = Array.isArray(rows[i]) ? rows[i] : [];
    if (isBlankRow(row)) continue;
    const rowNum = i + 1;
    let ok = true;

    const name = textOf(row[col.name]);
    if (name === "") {
      errors.push(errorAt("サービス", rowNum, "サービス名をご記入ください"));
      ok = false;
    } else if (seen.has(name)) {
      errors.push(errorAt("サービス", rowNum, "サービス名「" + name + "」が重複しています"));
      ok = false;
    }

    const minutesText = textOf(row[col.minutes]);
    let minutes = null;
    if (minutesText !== "") {
      minutes = integerInRange(row[col.minutes], 5, 480);
      if (minutes === null) {
        errors.push(errorAt("サービス", rowNum, "所要時間は 5〜480 の整数にしてください"));
        ok = false;
      }
    }

    const description = textOf(row[col.description]);
    const active = boolOf(row[col.active], true);
    const meet = meetOf_(row[col.meet]);
    if (meet === null) {
      errors.push(errorAt("サービス", rowNum, "オンラインは Meet・TRUE・FALSE のどれかにしてください（空欄は付けません）"));
      ok = false;
    }

    if (ok) {
      if (name !== "") seen.add(name);
      services.push({ name: name, minutes: minutes, description: description, active: active, meet: meet });
    }
  }

  return { services: services, errors: errors };
}

/** 「オンライン」列の値。Meet と TRUE の仲間は true、空と FALSE の仲間は false、読めない字は null */
function meetOf_(value) {
  if (textOf(value).toUpperCase() === "MEET") return true;
  const flag = boolOf(value, null);
  if (flag !== null) return flag;
  return textOf(value) === "" ? false : null;
}

/** サービスの一覧から名前が一致するものを探す。前後の空白は無視。無ければ null */
export function findService(services, name) {
  const list = Array.isArray(services) ? services : [];
  const target = textOf(name);
  for (let i = 0; i < list.length; i += 1) {
    const service = list[i];
    if (service && textOf(service.name) === target) return service;
  }
  return null;
}
