/**
 * 予約 1 件から、Google カレンダーに登録する予定の題名・説明・開始/終了を作る。
 * 開始・終了は "yyyy-MM-dd HH:mm"（Asia/Tokyo）の文字のまま返す。Date に直すのは gas_calendar.js の役目
 */
import { addMinutes } from "./dates.js";
import { textOf } from "./text.js";
import { findService } from "./services.js";

/**
 * settings.calendarContact が false なら、説明は受付番号だけにする（スタッフと共有するカレンダーに連絡先を広げない）。
 * end はサービスの所要時間があれば開始＋所要時間、無ければ枠の終了（reservation の「終了」）
 */
export function eventFor(settings, services, reservation) {
  const row = reservation === null || reservation === undefined ? {} : reservation;
  const serviceName = textOf(row["サービス"]);
  const service = serviceName === "" ? null : findService(services, serviceName);
  const name = textOf(row["お名前"]);
  const title = serviceName === "" ? "予約: " + name + " 様" : "予約: " + name + " 様（" + serviceName + "）";

  const date = textOf(row["日付"]);
  const start = textOf(row["開始"]);
  let endDate = date;
  let endTime = textOf(row["終了"]);
  if (service !== null && typeof service.minutes === "number" && service.minutes > 0) {
    const at = addMinutes(date, start, service.minutes);
    endDate = at.date;
    endTime = at.time;
  }

  const contact = !(settings && settings.calendarContact === false);
  const description = ["受付番号: " + textOf(row["ID"])]
    .concat(contact ? ["メール: " + textOf(row["メール"]), "電話: " + textOf(row["電話"]), "ご要望: " + textOf(row["ご要望"])] : [])
    .join("\n");

  return { title: title, description: description, start: date + " " + start, end: endDate + " " + endTime };
}

/**
 * Google Meet を付けられなかったときの理由（店への知らせと「設定を確かめる」に同じ字で出す）。
 * お客さまへのメールには理由を書かず、MEET_LATER_LINE の 1 行だけを入れる
 */
export const MEET_REASONS = {
  noService: "Apps Script の「サービス」に Google Calendar API（拡張サービス）が入っていません。appsscript.json の中身を 1.2.0 の dist/appsscript.json の中身に貼り替えてください。",
  noCalendar: "設定「カレンダー ID」が空のため、カレンダーの予定と会議を作れません。",
  noEvent: "カレンダーの予定を登録できなかったため、会議も作れませんでした。",
  refused: "Google Meet の会議を作れませんでした。Google Workspace の管理者が Meet を止めている、またはこのアカウントでは予定に Meet を付けられない可能性があります。",
};

/**
 * 拡張サービス（Calendar API v3）で使うカレンダー ID。設定の "primary" は API でもそのまま主カレンダーを指す
 */
export function apiCalendarId(calendarId) {
  const id = textOf(calendarId);
  return id.toLowerCase() === "primary" ? "primary" : id;
}

/** 予定の ID（Apps Script のカレンダーが返す "…@google.com"）を、API の events の id にする */
export function apiEventId(eventId) {
  return textOf(eventId).replace(/@google\.com$/, "");
}

/** Events.patch に渡す中身。requestId は呼び出しごとに新しい字にする（同じ字だと求めが無視される） */
export function meetPatch(requestId) {
  return { conferenceData: { createRequest: { requestId: textOf(requestId), conferenceSolutionKey: { type: "hangoutsMeet" } } } };
}

/** API が返した予定の、会議を作る求めの状態（"pending" / "success" / "failure"。無ければ ""） */
export function meetStatusOf(event) {
  const data = event && event.conferenceData ? event.conferenceData : {};
  const request = data.createRequest && data.createRequest.status ? data.createRequest.status : {};
  return textOf(request.statusCode);
}

/** API が返した予定から、会議の URL（hangoutLink か、entryPoints の video）を取る。無ければ "" */
export function meetUrlOf(event) {
  if (!event) return "";
  const link = textOf(event.hangoutLink);
  if (/^https:\/\//.test(link)) return link;
  const points = event.conferenceData && Array.isArray(event.conferenceData.entryPoints) ? event.conferenceData.entryPoints : [];
  for (let i = 0; i < points.length; i += 1) {
    const point = points[i] || {};
    const uri = textOf(point.uri);
    if (point.entryPointType === "video" && /^https:\/\//.test(uri)) return uri;
  }
  return "";
}
