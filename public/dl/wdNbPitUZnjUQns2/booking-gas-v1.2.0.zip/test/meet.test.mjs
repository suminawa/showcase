/**
 * 1.2: オンライン（Google Meet）の純粋な部分。API の求めの中身・返りの読み取り・メール文への差し込み・失敗の文
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { MEET_REASONS, apiCalendarId, apiEventId, meetPatch, meetStatusOf, meetUrlOf } from "../src/calendar.js";
import { MEET_LATER_LINE, buildCancelMail, buildConfirmMail, buildOwnerMail, buildRemindMail, meetLineFor, withMeetLine } from "../src/mail.js";
import { buildNotifyText } from "../src/message.js";
import { DEFAULT_SETTINGS } from "../src/settings.js";

const URL = "https://meet.google.com/abc-defg-hij";
const SERVICES = [
  { name: "オンライン相談", minutes: 30, description: "", active: true, meet: true },
  { name: "来店の施術", minutes: 45, description: "", active: true, meet: false },
];
function reservation_(service, url) {
  return { ID: "20260918-009", 状態: "確定", 日付: "2026-09-22", 開始: "11:00", 終了: "11:30", サービス: service, お名前: "小川", メール: "ogawa@example.com", 電話: "", ご要望: "", 会議URL: url };
}

test("meetPatch: conferenceData.createRequest に requestId と hangoutsMeet", () => {
  assert.deepEqual(meetPatch("req-1"), { conferenceData: { createRequest: { requestId: "req-1", conferenceSolutionKey: { type: "hangoutsMeet" } } } });
});

test("apiCalendarId / apiEventId: primary はそのまま、予定の ID は @google.com を落とす", () => {
  assert.equal(apiCalendarId("primary"), "primary");
  assert.equal(apiCalendarId("PRIMARY"), "primary");
  assert.equal(apiCalendarId(" shop@group.calendar.google.com "), "shop@group.calendar.google.com");
  assert.equal(apiEventId("abc123def@google.com"), "abc123def");
  assert.equal(apiEventId("abc123def"), "abc123def");
});

test("meetUrlOf: hangoutLink を先に、無ければ entryPoints の video。https でなければ空", () => {
  assert.equal(meetUrlOf({ hangoutLink: URL }), URL);
  assert.equal(meetUrlOf({ conferenceData: { entryPoints: [{ entryPointType: "phone", uri: "tel:+81-3-0000" }, { entryPointType: "video", uri: URL }] } }), URL);
  assert.equal(meetUrlOf({ conferenceData: { entryPoints: [null, { entryPointType: "video", uri: "javascript:alert(1)" }] } }), "");
  assert.equal(meetUrlOf({ conferenceData: { createRequest: { status: { statusCode: "pending" } } } }), "");
  assert.equal(meetUrlOf(null), "");
});

test("meetStatusOf: pending / success / failure を読む。無ければ空", () => {
  assert.equal(meetStatusOf({ conferenceData: { createRequest: { status: { statusCode: "pending" } } } }), "pending");
  assert.equal(meetStatusOf({ conferenceData: { createRequest: { status: { statusCode: "failure" } } } }), "failure");
  assert.equal(meetStatusOf({}), "");
  assert.equal(meetStatusOf(undefined), "");
});

test("meetLineFor: URL があればその行、オンラインで URL が無ければ「追って」、対面は空", () => {
  assert.equal(meetLineFor(SERVICES, reservation_("オンライン相談", URL)), "オンラインの会議の URL: " + URL);
  assert.equal(meetLineFor(SERVICES, reservation_("オンライン相談", "")), MEET_LATER_LINE);
  assert.equal(meetLineFor(SERVICES, reservation_("来店の施術", "")), "");
  assert.equal(meetLineFor([], reservation_("", "")), "");
  // あとでサービスを対面に戻しても、URL のあるご予約には URL を載せる（店が手で書いた URL も）
  assert.equal(meetLineFor(SERVICES, reservation_("来店の施術", URL)), "オンラインの会議の URL: " + URL);
});

test("確認メール・リマインド: 既定の本文では「受付番号」の行のすぐ下に 1 行入る", () => {
  const confirm = buildConfirmMail(DEFAULT_SETTINGS, reservation_("オンライン相談", URL), "https://example.com/c", SERVICES).body.split("\n");
  const at = confirm.indexOf("受付番号: 20260918-009");
  assert.ok(at > 0);
  assert.equal(confirm[at + 1], "オンラインの会議の URL: " + URL);

  const remind = buildRemindMail(DEFAULT_SETTINGS, reservation_("オンライン相談", ""), "", SERVICES).body.split("\n");
  assert.equal(remind[remind.indexOf("受付番号: 20260918-009") + 1], MEET_LATER_LINE);
});

test("確認メール: 対面のサービスと、services を渡さない呼び方（1.1 まで）は、本文が変わらない", () => {
  const before = buildConfirmMail(DEFAULT_SETTINGS, reservation_("来店の施術", ""), "https://example.com/c");
  assert.equal(buildConfirmMail(DEFAULT_SETTINGS, reservation_("来店の施術", ""), "https://example.com/c", SERVICES).body, before.body);
  assert.equal(before.body.includes("会議"), false);
});

test("withMeetLine: {会議URL} があればそこに、受付番号の行が無ければ末尾に足す", () => {
  assert.equal(withMeetLine("{お名前} 様\n{会議URL}\n以上", { お名前: "小川" }, "L"), "小川 様\nL\n以上");
  assert.equal(withMeetLine("{お名前} 様\n{会議URL}", { お名前: "小川" }, ""), "小川 様\n");
  assert.equal(withMeetLine("{お名前} 様", { お名前: "小川" }, "L"), "小川 様\n\nL");
  assert.equal(withMeetLine("{お名前} 様", { お名前: "小川" }, ""), "小川 様");
});

test("店への知らせ: URL を 1 行。作れなかったときは理由と、手で直す道を 1 行", () => {
  const ok = buildOwnerMail(DEFAULT_SETTINGS, reservation_("オンライン相談", URL), SERVICES, "").body;
  assert.ok(ok.split("\n").includes("オンラインの会議の URL: " + URL));

  const failed = buildOwnerMail(DEFAULT_SETTINGS, reservation_("オンライン相談", ""), SERVICES, MEET_REASONS.refused).body.split("\n");
  const line = failed.filter((text) => text.indexOf("オンラインの会議: 作れませんでした。") === 0);
  assert.equal(line.length, 1);
  assert.ok(line[0].includes(MEET_REASONS.refused));
  assert.ok(line[0].includes("「会議URL」列"));

  assert.equal(buildOwnerMail(DEFAULT_SETTINGS, reservation_("来店の施術", ""), SERVICES, "").body.includes("会議"), false);
});

test("キャンセルのメールには会議の URL を入れない", () => {
  const body = buildCancelMail(DEFAULT_SETTINGS, reservation_("オンライン相談", URL)).body;
  assert.equal(body.includes(URL), false);
  assert.equal(body.includes("会議"), false);
});

test("通知: extra があれば末尾に足す。無ければ 1.1 と同じ文", () => {
  const row = reservation_("オンライン相談", URL);
  const plainText = buildNotifyText("reserve", DEFAULT_SETTINGS, row);
  assert.equal(buildNotifyText("reserve", DEFAULT_SETTINGS, row, ""), plainText);
  assert.equal(buildNotifyText("reserve", DEFAULT_SETTINGS, row, "Meet: " + URL), plainText + " Meet: " + URL);
});

test("MEET_REASONS: 4 つの理由は敬体の文で、使わない言い回しが無い", () => {
  for (const text of Object.values(MEET_REASONS)) {
    assert.match(text, /(ます|ません|ください|でした)。$/, text);
    for (const word of ["承ります", "必ず", "確実に", "最短"]) assert.equal(text.includes(word), false, word);
  }
});
