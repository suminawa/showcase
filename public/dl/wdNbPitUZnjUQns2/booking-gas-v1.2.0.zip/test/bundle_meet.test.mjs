/**
 * 1.2: オンライン（Google Meet）のご予約を、dist/Code.gs を偽の GAS の上で走らせて確かめる。
 * Meet あり（作れた・作っている途中から作れた）・Meet なし・作れなかった（拒まれた・例外・拡張サービスが無い・カレンダー ID が空）
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "../scripts/build.mjs";
import { loadBundle } from "./fakes.mjs";
import { sampleData } from "../src/samples.js";
import { FIXED_TODAY } from "./fakes.mjs";
import { MEET_REASONS } from "../src/calendar.js";
import { MEET_LATER_LINE } from "../src/mail.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
build(root);

const SAMPLE = sampleData(FIXED_TODAY);
const FIRST = SAMPLE.services[1][0];
const REGULAR = SAMPLE.services[2][0];
const LINK = "https://meet.google.com/abc-defg-hij";
const WIRED = [
  ["連絡先メール", "shop@example.com"],
  ["カレンダー ID", "primary"],
  ["Slack Webhook URL", "https://example.com/hooks/slack"],
];
/** 予約シートの「会議URL」列（1.2 で右端に足した列） */
const MEET_AT = 15;

/** 見本の店の「初回カウンセリング」をオンライン（Meet）にしたもの */
function meetServices() {
  return SAMPLE.services.map((row, i) => (i === 1 ? row.slice(0, 4).concat(["Meet"]) : row));
}

function seeded(options) {
  const opts = options || {};
  const settings = SAMPLE.settings.concat(opts.extraSettings === undefined ? WIRED : opts.extraSettings);
  return loadBundle(
    Object.assign({ props: { lastId: "20260918-008" } }, opts, {
      sheets: Object.assign({ 設定: settings, 枠: SAMPLE.rules, 休み: SAMPLE.closed, サービス: meetServices(), 予約: SAMPLE.reservations }, opts.sheets || {}),
    })
  );
}

function input(extra) {
  return Object.assign({ name: "小川", email: "ogawa@example.com", phone: "045-000-0099", note: "", date: "2026-09-22", start: "11:00", service: FIRST, bk_hp: "" }, extra || {});
}

function slackText(run) {
  return JSON.parse(run.trace.fetched[0].payload).text;
}

test("Meet あり: 予定に会議を付け、URL を行・確認メール・店への知らせ・通知に入れる", () => {
  const run = seeded({ calendarApi: "ok" });
  const out = run.entry.api_reserve(input());
  assert.equal(out.ok, true);

  assert.equal(run.trace.meet.length, 1);
  const call = run.trace.meet[0];
  assert.equal(call.action, "patch");
  assert.equal(call.calendarId, "primary");
  assert.equal(call.eventId, "event1", "予定の ID の @google.com を落として API に渡す");
  assert.deepEqual(call.optional, { conferenceDataVersion: 1 });
  assert.equal(call.resource.conferenceData.createRequest.conferenceSolutionKey.type, "hangoutsMeet");
  assert.ok(call.resource.conferenceData.createRequest.requestId.length > 0);

  assert.equal(run.sheets["予約"].rows[9][MEET_AT], LINK, "会議の URL を「会議URL」列に書く");
  assert.equal(run.events[0].deleted, false);

  const [customer, owner] = run.trace.mails;
  assert.ok(customer.body.split("\n").includes("オンラインの会議の URL: " + LINK));
  assert.ok(owner.body.split("\n").includes("オンラインの会議の URL: " + LINK));
  assert.ok(slackText(run).endsWith(" Meet: " + LINK));
});

test("Meet あり: 作っている途中（pending）で返ったら、1 回だけ読み直して URL を取る", () => {
  const run = seeded({ calendarApi: "pending" });
  run.entry.api_reserve(input());
  assert.deepEqual(run.trace.meet.map((call) => call.action), ["patch", "get"]);
  assert.equal(run.sheets["予約"].rows[9][MEET_AT], LINK);
  assert.ok(run.trace.mails[0].body.includes("オンラインの会議の URL: " + LINK));
});

test("Meet なし（対面のサービス）: 会議を作らず、メールと通知はこれまでどおり", () => {
  const run = seeded({ calendarApi: "ok" });
  run.entry.api_reserve(input({ service: REGULAR, start: "15:30" }));
  assert.equal(run.trace.meet.length, 0);
  assert.equal(run.sheets["予約"].rows[9][MEET_AT], "");
  for (const mail of run.trace.mails) assert.equal(mail.body.includes("会議"), false);
  assert.equal(slackText(run).includes("Meet"), false);
});

for (const [label, options, reason] of [
  ["Workspace の管理者が Meet を止めている（failure）", { calendarApi: "failure" }, MEET_REASONS.refused],
  ["API が例外を投げた", { calendarApi: "throws" }, MEET_REASONS.refused],
  ["拡張サービスの Calendar が無効（1.1 の appsscript.json のまま）", {}, MEET_REASONS.noService],
  ["設定「カレンダー ID」が空", { calendarApi: "ok", extraSettings: [["連絡先メール", "shop@example.com"], ["Slack Webhook URL", "https://example.com/hooks/slack"]] }, MEET_REASONS.noCalendar],
]) {
  test("Meet を作れなかった（" + label + "）: 予約と予定は残し、お客さまには「追って」、店には理由", () => {
    const run = seeded(options);
    const out = run.entry.api_reserve(input());
    assert.equal(out.ok, true, "予約は失敗にしない");
    assert.equal(out.mailSent, true);
    assert.equal(run.sheets["予約"].rows.length, 10);
    assert.equal(run.sheets["予約"].rows[9][MEET_AT], "");
    if (reason !== MEET_REASONS.noCalendar) assert.equal(run.events[0].deleted, false, "カレンダーの予定は残す");

    const [customer, owner] = run.trace.mails;
    assert.ok(customer.body.split("\n").includes(MEET_LATER_LINE));
    assert.equal(customer.body.includes(reason), false, "お客さまには理由を書かない");
    const failed = owner.body.split("\n").filter((line) => line.indexOf("オンラインの会議: 作れませんでした。") === 0);
    assert.equal(failed.length, 1);
    assert.ok(failed[0].includes(reason));
    assert.ok(slackText(run).endsWith(" Meet を作れませんでした（理由はお知らせのメールに）"));
  });
}

test("前日のリマインド: 「会議URL」の URL を入れる。オンラインで URL が空なら「追って」", () => {
  // 見本の 9/19 のご予約（翌日）を、オンラインのサービスにして URL を書いておく
  const reservations = SAMPLE.reservations.map((row, i) => (i === 1 ? row.slice(0, 5).concat([FIRST], row.slice(6, 15), [LINK]) : row));
  const run = seeded({ sheets: { 予約: reservations } });
  run.entry.remind_();
  assert.equal(run.trace.mails.length, 1);
  assert.ok(run.trace.mails[0].body.split("\n").includes("オンラインの会議の URL: " + LINK));

  const empty = SAMPLE.reservations.map((row, i) => (i === 1 ? row.slice(0, 5).concat([FIRST], row.slice(6, 15), [""]) : row));
  const later = seeded({ sheets: { 予約: empty } });
  later.entry.remind_();
  assert.ok(later.trace.mails[0].body.split("\n").includes(MEET_LATER_LINE));
});

test("キャンセルのメールには会議の URL を入れない（予定は消す）", () => {
  const run = seeded({ calendarApi: "ok" });
  run.entry.api_reserve(input());
  run.entry.api_cancel(run.sheets["予約"].rows[9][14]);
  const cancelMail = run.trace.mails[2];
  assert.ok(cancelMail.subject.includes("キャンセル"));
  assert.equal(cancelMail.body.includes(LINK), false);
  assert.equal(cancelMail.body.includes("会議"), false);
  assert.equal(run.events[0].deleted, true);
});

test("1.1 までのシート（「オンライン」「会議URL」の列が無い）でも、これまでどおり予約できる", () => {
  const services = SAMPLE.services.map((row) => row.slice(0, 4));
  const reservations = SAMPLE.reservations.map((row) => row.slice(0, 15));
  const run = seeded({ calendarApi: "ok", sheets: { サービス: services, 予約: reservations } });
  const out = run.entry.api_reserve(input());
  assert.equal(out.ok, true);
  assert.equal(run.trace.meet.length, 0);
  assert.equal(run.sheets["予約"].rows[9].length, 15, "無い列は書かない");
  for (const mail of run.trace.mails) assert.equal(mail.body.includes("会議"), false);
});

test("設定を確かめる: Meet のサービスがあるのに拡張サービスが無効・カレンダー ID が空なら知らせる", () => {
  const off = seeded({});
  off.entry.menu_check();
  assert.ok(off.trace.alerts[0].startsWith("直すところがあります。"));
  assert.ok(off.trace.alerts[0].includes("booking: サービス「" + FIRST + "」はオンライン（Meet）ですが、会議を付けられません。" + MEET_REASONS.noService));

  const noCalendar = seeded({ calendarApi: "ok", extraSettings: [] });
  noCalendar.entry.menu_check();
  assert.ok(noCalendar.trace.alerts[0].includes(MEET_REASONS.noCalendar));
  assert.equal(noCalendar.trace.alerts[0].includes(MEET_REASONS.noService), false);

  const ready = seeded({ calendarApi: "ok" });
  ready.entry.menu_check();
  assert.ok(ready.trace.alerts[0].startsWith("問題ありません。"), ready.trace.alerts[0]);
  assert.ok(ready.trace.alerts[0].includes("オンライン（Meet）: " + FIRST + " のご予約に、会議の URL を付けます"));
});

test("テスト送信: 先頭のサービスがオンラインなら、見本の URL で会議の 1 行を見せる", () => {
  const run = seeded({ calendarApi: "ok" });
  run.entry.menu_testMail();
  assert.ok(run.trace.mails[0].body.includes("オンラインの会議の URL: https://meet.google.com/（見本）"));
});
