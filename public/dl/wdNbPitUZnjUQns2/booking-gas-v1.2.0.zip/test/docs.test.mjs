import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { SETTING_KEYS, DEFAULT_SETTINGS } from "../src/settings.js";
import { LIMITS } from "../src/validate.js";
import { SHOP_NAME } from "../src/samples.js";
import { WEEKDAY_WORDS } from "../src/rules.js";
import { minutesOf } from "../src/dates.js";
import { MANIFEST, build } from "../scripts/build.mjs";
import { CHECK_MENU_LABEL, INIT_MENU_LABEL } from "../src/setup.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const readme = readFileSync(join(root, "README.ja.md"), "utf8");
const mainSource = readFileSync(join(root, "src", "gas_main.js"), "utf8");

/**
 * 公開する文面に書かない語（社内でだけ使う呼び名と、作るのに使った道具の名前）。
 * この検査そのものが配布物（zip）に入るので、語は文字コードで書く。
 * リテラルで置くと、検査するためのファイルが検査に引っかかる
 */
const INTERNAL_WORDS = [
  "\u924b",
  "\u68df\u6881",
  "\u0043\u006c\u0061\u0075\u0064\u0065\u0020\u0043\u006f\u0064\u0065",
  "\u0041\u006e\u0074\u0068\u0072\u006f\u0070\u0069\u0063",
];

/** 配布 zip に入るもの（scripts/release.mjs が zip に入れる並びと同じ） */
const SHIPPED = ["dist", "samples", "demo", "src", "test", "scripts", "README.ja.md", "LICENSE.md", "CHANGELOG.md", "package.json"];

/** 配下のファイルを 1 つずつ（ディレクトリは潜る） */
function filesUnder_(path) {
  if (!statSync(path).isDirectory()) return [path];
  const found = [];
  for (const name of readdirSync(path)) {
    if (name === ".DS_Store") continue;
    found.push(...filesUnder_(join(path, name)));
  }
  return found;
}

const sheetsSource = readFileSync(join(root, "src", "gas_sheets.js"), "utf8");

/** src/gas_sheets.js が作る「予約」シートの見出し（README の表と食い違わせない） */
function reservationColumns() {
  const matched = sheetsSource.match(/\n\s*予約: \[([^\]]+)\]/);
  return matched[1].split(",").map((cell) => cell.trim().replace(/^"|"$/g, ""));
}

/** README の章を 1 つ取り出す（次の "## " の手前まで） */
function section(title) {
  const after = readme.split(title)[1];
  return after.split("\n## ")[0];
}

/** src/gas_main.js の onOpen が並べるメニューの項目名（README の説明と食い違わせない） */
function menuItems() {
  const found = [];
  const pattern = /\.addItem\("([^"]+)"/g;
  let matched = pattern.exec(mainSource);
  while (matched !== null) {
    found.push(matched[1]);
    matched = pattern.exec(mainSource);
  }
  return found;
}

/** README の見出し（## …）を出てくる順に並べる */
function headings() {
  return readme
    .split("\n")
    .filter((line) => line.startsWith("## "))
    .map((line) => line.trim());
}

test("README の見出しが、この順にそろっている", () => {
  const wanted = [
    "## 1. できること",
    "## 2. 置き方（15 分）",
    "## 3. 枠シートの書き方",
    "## 4. 休みとサービス",
    "## 5. 設定シート",
    "## 6. カレンダーとメール",
    "## 7. キャンセル",
    "## 8. LP テンプレからのリンク",
    "## 9. よくある質問",
    "## 10. 更新履歴",
    "## ライセンス",
    "## 手元で動かす（開発者向け）",
    "## 困ったら",
  ];
  const found = headings();
  for (const heading of wanted) assert.ok(found.includes(heading), heading);

  let at = -1;
  for (const heading of wanted) {
    const index = found.indexOf(heading);
    assert.ok(index > at, heading + " の位置");
    at = index;
  }
});

test("設定の 23 項目すべてが、既定値と一緒に README の表にある", () => {
  assert.equal(SETTING_KEYS.length, 23);
  for (const key of SETTING_KEYS) assert.ok(readme.includes("| " + key + " |"), key);

  for (const value of [
    DEFAULT_SETTINGS.shopName,
    String(DEFAULT_SETTINGS.daysAhead),
    String(DEFAULT_SETTINGS.leadHours),
    String(DEFAULT_SETTINGS.cancelHours),
    String(DEFAULT_SETTINGS.maxPerEmail),
    String(DEFAULT_SETTINGS.remindHour),
    DEFAULT_SETTINGS.themeColor,
    DEFAULT_SETTINGS.dateFormat,
    DEFAULT_SETTINGS.confirmSubject,
    DEFAULT_SETTINGS.remindSubject,
  ]) {
    assert.ok(readme.includes(value), "既定値 " + value);
  }

  // メールの差し込み（設定「確認メールの本文」に書ける名前）
  for (const placeholder of ["{お名前}", "{日付}", "{時間}", "{サービス}", "{店名}", "{電話}", "{住所}", "{受付番号}", "{キャンセルURL}"]) {
    assert.ok(readme.includes(placeholder), placeholder);
  }
});

test("メニューの項目名と、公開の設定が README に書いてある", () => {
  const items = menuItems();
  assert.equal(items.length, 6);
  for (const item of items) assert.ok(readme.includes(item), "メニュー「" + item + "」");

  // アクセスできるユーザー「全員」= ANYONE_ANONYMOUS、実行「自分」= USER_DEPLOYING
  assert.equal(MANIFEST.webapp.access, "ANYONE_ANONYMOUS");
  assert.equal(MANIFEST.webapp.executeAs, "USER_DEPLOYING");
  assert.ok(readme.includes("ANYONE_ANONYMOUS"));
  assert.ok(readme.includes("USER_DEPLOYING"));
  assert.ok(readme.includes("「全員」"));
  assert.ok(readme.includes("「自分」"));

  // 承認画面に出る 6 つの権限の理由を 1 つずつ書いてある
  assert.equal(MANIFEST.oauthScopes.length, 6);
  assert.ok(readme.includes("6 つ"));
  for (const scope of MANIFEST.oauthScopes) {
    assert.ok(readme.includes("`" + scope.replace("https://www.googleapis.com/auth/", "") + "`"), scope);
  }
});

test("枠・休み・サービスの書き方と、入力の上限が README に書いてある", () => {
  for (const column of ["曜日", "日付", "開始", "終了", "間隔", "定員", "サービス"]) {
    assert.ok(readme.includes("| " + column + " |"), "枠の列 " + column);
  }
  for (const word of Object.keys(WEEKDAY_WORDS)) {
    assert.ok(readme.includes("`" + word + "`"), "曜日の語 " + word);
  }
  for (const word of ["平日", "土日", "毎日"]) assert.ok(readme.includes("`" + word + "`"), word);
  assert.ok(readme.includes("5〜480"), "間隔の範囲");
  assert.ok(readme.includes("開始日"));
  assert.ok(readme.includes("終了日"));
  assert.ok(readme.includes("所要時間"));

  for (const limit of [LIMITS.name, LIMITS.email, LIMITS.phone, LIMITS.note]) {
    assert.ok(readme.includes(String(limit) + " 字"), "入力の上限 " + limit);
  }
});

test("メールの上限・通知・キャンセルの決まりを書いてある", () => {
  assert.ok(readme.includes("100 通"), "個人の Gmail の 1 日の上限");
  assert.ok(readme.includes("1,500 通"), "Google Workspace の 1 日の上限");
  assert.ok(readme.includes("3 通"), "予約 1 件で送るメールの数");
  assert.ok(readme.includes("primary"), "カレンダー ID の書き方");
  // 通知に載せないもの（設計書 §7）
  assert.ok(/通知/.test(readme));
  // キャンセル用の合い言葉が共有した人に見えることを書いてある
  assert.ok(readme.includes("キャンセル用"));
  assert.ok(/キャンセル用[^\n]*共有|共有[^\n]*キャンセル用/.test(readme), "「キャンセル用」列が共有した人に見えること");
});

test("よくある質問が 8 つ以上ある", () => {
  const faq = readme.split("## 9. よくある質問")[1].split("## 10.")[0];
  const questions = faq.split("\n").filter((line) => /^\*\*.+\*\*$/.test(line.trim()));
  assert.ok(questions.length >= 8, "よくある質問は " + questions.length + " 件");
});

test("値段・鍵・内部の呼び名を書かない。見本の店は架空と断る", () => {
  assert.equal(/[¥￥]\s?\d/.test(readme), false, "値段は README に書かない");
  assert.equal(readme.includes("sk-ant-"), false);
  for (const word of INTERNAL_WORDS) {
    assert.equal(readme.includes(word), false, word + " を書かない");
  }
  // このキットに `_` で始まるシートは無い（業務アプリ キットの写しが残っていないこと）
  assert.equal(readme.includes("_ごみ箱"), false);
  assert.ok(readme.includes(SHOP_NAME));
  assert.ok(readme.includes("架空"));
});

test("README に「予約」シートの 16 列と、見出しを変えないお願いがある", () => {
  const cancel = section("## 7. キャンセル");
  const columns = reservationColumns();
  assert.equal(columns.length, 16);
  assert.ok(cancel.includes("次の " + columns.length + " 列"));
  for (const column of columns) assert.ok(cancel.includes("| " + column + " |"), "予約の列 " + column);
  assert.ok(/見出し[^\n]*変えないでください/.test(cancel), "見出しを変えないでくださいと書いてある");
  assert.ok(/キャンセル用[^\n]*当たらなく/.test(cancel), "「キャンセル用」を消したときに何が起きるかを書いてある");
  assert.ok(cancel.includes("並べ替え"), "並べ替えと右への追加は大丈夫だと書いてある");
});

test("README の枠の説明が、いまの枠の作り方と合っている（手本も割り切れる時間帯）", () => {
  const rules = section("## 3. 枠シートの書き方");
  assert.ok(rules.includes("「終了」までに終わる"), "枠は終了までに終わる、と 1 文で書いてある");
  assert.equal(rules.includes("この時刻に始まる枠は作りません"), false, "古い決まりの書き方が残っていない");

  // 手本の表（曜日 | 日付 | 開始 | 終了 | 間隔 | 定員 | サービス）は、終了 − 開始が間隔で割り切れること
  const rows = rules.split("\n").filter((line) => /^\|.*\|\s*(\d{1,2}:\d{2})\s*\|\s*(\d{1,2}:\d{2})\s*\|/.test(line));
  assert.ok(rows.length >= 2, "手本の表が " + rows.length + " 行");
  for (const row of rows) {
    const cells = row.split("|").map((cell) => cell.trim());
    const [start, end, interval] = [cells[3], cells[4], Number(cells[5])];
    const span = minutesOf(end) - minutesOf(start);
    assert.ok(span > 0 && interval > 0, row);
    assert.equal(span % interval, 0, "手本の行は間隔で割り切れる時間帯にする: " + row);
  }
});

test("受付を止めたときにお客さまへ出す文が、実装と README で同じ", () => {
  const webSource = readFileSync(join(root, "src", "gas_web.js"), "utf8");
  const matched = webSource.match(/const BOOT_STOPPED_TEXT_ = "([^"]+)"/);
  assert.ok(matched, "gas_web.js に、受付を止めたときの 1 文がある");
  assert.ok(readme.includes(matched[1]), "README にも同じ文がある: " + matched[1]);
  assert.ok(readme.includes("メニュー「設定を確かめる」"));
  // 公開ページが誤りの一覧を出す、とは書かない
  assert.equal(readme.includes("誤りの一覧"), false);
});

test("配布 zip に入るファイルのどれにも、社内でだけ使う呼び名が無い", () => {
  // dist/ と demo/app.js は src/ から作るので、先に作り直してから見る
  build(root);
  const files = SHIPPED.flatMap((name) => filesUnder_(join(root, name)));
  assert.ok(files.length > 40, "配布物は " + files.length + " ファイル");
  for (const file of files) {
    const text = readFileSync(file, "utf8");
    for (const word of INTERNAL_WORDS) {
      assert.equal(text.includes(word), false, file + " に " + word + " があります");
    }
  }
});

test("配布 zip に入るファイルの名前は英数字だけ（Windows の標準の展開で化けない）", () => {
  const files = SHIPPED.flatMap((name) => filesUnder_(join(root, name)));
  for (const file of files) assert.match(file.slice(root.length + 1), /^[\x20-\x7e]+$/, file);
  assert.ok(readme.includes("`samples/`"), "CSV の名前とシートの対応を README に書く");
});

test("LICENSE と CHANGELOG", () => {
  const license = readFileSync(join(root, "LICENSE.md"), "utf8");
  assert.ok(license.includes("予約ページ キット"));
  assert.ok(license.includes("再配布"));
  assert.equal(/[¥￥]\s?\d/.test(license), false);

  const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");
  assert.ok(changelog.includes("## 1.0.0"));
  assert.equal(/[¥￥]\s?\d/.test(changelog), false);
});

test("1.1: メニューの 2 つの字が onOpen と README にあり、更新のお知らせは 10 章の中の ### にある", () => {
  const items = menuItems();
  assert.equal(items[0], INIT_MENU_LABEL);
  assert.ok(items.indexOf(CHECK_MENU_LABEL) >= 0);
  const history = section("## 10. 更新履歴");
  assert.ok(history.includes("\n### 更新のお知らせ 1.1\n"), "10 章の中に ### で置く（## の並びは変えない）");
  // 1.1 の直し（お名前の字）は api_reserve・api_cancel の中で効くので、「新バージョン」で公開し直さないと予約ページに届かない
  assert.ok(history.includes("4. 「デプロイ」→「デプロイを管理」→ 鉛筆のしるし → バージョンを「新バージョン」にして「デプロイ」を押します。"), "上げ方に公開し直しの手順が無い");
  assert.ok(history.includes("- Slack・Discord の通知: お客さまが書いたお名前に `<!channel>` や `@everyone` のような字が入っていても、全員や特定の人への呼び出しにならないようにしました"));
  assert.equal(history.includes("公開し直しも要りません"), false, "公開し直しが要らないと書いてある");
  assert.ok(section("## 9. よくある質問").includes("**初期化をもう一度押しても大丈夫ですか**"));
});

test("版がそろっている（package.json・CHANGELOG の先頭・README の zip 名・Code.gs の版）", () => {
  // 版の正は package.json。ここに版の字を書かない（版を上げるたびにこの検査が落ちないように）
  const version = JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version;
  assert.match(version, /^\d+\.\d+\.\d+$/);
  assert.equal(mainSource.match(/^const KIT_VERSION = "([^"]+)";$/m)[1], version, "src/gas_main.js の KIT_VERSION");
  const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");
  assert.equal(changelog.match(/^## (\d+\.\d+\.\d+)/m)[1], version);
  assert.ok(readme.includes("release/booking-gas-v" + version + ".zip"));
});

test("1.1.2: 更新のお知らせ・トリガーを作る人・過去のご予約の移し方・見た目の直し方が README にある", () => {
  const version = JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version;
  const history = section("## 10. 更新履歴");
  assert.ok(history.includes("\n### 更新のお知らせ " + version + "\n"));
  assert.ok(history.includes("新バージョン"), "公開し直しの手順");
  const mailSection = section("## 6. カレンダーとメール");
  assert.ok(mailSection.includes("トリガーを作った方"), "リマインドは作った人の権限で動く");
  assert.ok(readme.includes("### 過去のご予約を別のシートへ移す"));
  assert.ok(readme.includes("予約ページ全体で 10 分に 10 件まで"));
  const faq = section("## 9. よくある質問");
  assert.ok(faq.includes("`App` の `<style>` の先頭"), "見た目は App.html で直せる");
  assert.equal(faq.includes("npm run build` で `dist/App.html` を作り直して"), false, "見た目の変更に build を求めない");
});

test("公開する文（src・samples・README・CHANGELOG・LICENSE・demo/index.html）に「承ります」を使わない", () => {
  const files = filesUnder_(join(root, "src")).concat(filesUnder_(join(root, "samples")), ["README.ja.md", "CHANGELOG.md", "LICENSE.md", join("demo", "index.html")].map((name) => join(root, name)));
  for (const file of files) assert.equal(readFileSync(file, "utf8").includes("承ります"), false, file);
});

test("1.2.0: オンライン（Meet）の列・拡張サービス・メールの 1 行・更新の手順が README にあり、使わない言い回しが無い", () => {
  // 拡張サービスの Calendar を appsscript.json に入れ、権限は 6 つのまま
  assert.deepEqual(MANIFEST.dependencies.enabledAdvancedServices, [{ userSymbol: "Calendar", serviceId: "calendar", version: "v3" }]);
  assert.equal(MANIFEST.oauthScopes.length, 6);
  assert.ok(readme.includes("Google Calendar API"));

  assert.ok(section("## 4. 休みとサービス").includes("| オンライン |"), "サービスの列「オンライン」");
  const meet = section("## 6. カレンダーとメール").split("### オンライン（Google Meet）")[1].split("\n### ")[0];
  assert.ok(meet.includes("オンラインの会議の URL: "));
  assert.ok(meet.includes("会議の URL は追ってお知らせします。"));
  assert.ok(meet.includes("キャンセルのメールには入れません"));
  assert.ok(readme.includes("`{会議URL}`"));

  const history = section("## 10. 更新履歴");
  const notice = history.split("### 更新のお知らせ 1.2.0\n")[1];
  assert.ok(notice, "10 章の中に「更新のお知らせ 1.2.0」");
  for (const step of ["`dist/Code.gs`", "`dist/appsscript.json`", "「初期化」", "新バージョン"]) assert.ok(notice.includes(step), step);
  assert.ok(notice.indexOf("`dist/appsscript.json`") < notice.indexOf("「初期化」") && notice.indexOf("「初期化」") < notice.indexOf("新バージョン"), "貼り替え → 初期化 → 公開し直しの順");

  const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");
  const latest = changelog.split("\n## ")[1];
  assert.ok(latest.startsWith("1.2.0 — 2026-10-23"));
  for (const text of [notice, meet, latest]) {
    for (const word of ["承ります", "必ず", "確実に", "最短"]) assert.equal(text.includes(word), false, word);
  }
});
