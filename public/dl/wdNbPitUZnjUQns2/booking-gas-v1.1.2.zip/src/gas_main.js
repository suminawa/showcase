/**
 * スプレッドシートのメニュー「予約ページ」と、前日リマインドの入口（時間主導トリガー）。
 * Web アプリの入口は gas_web.js。dist/Code.gs の先頭に来るファイル。
 */
import { DEPLOY_STEPS, checkNotes, findProblems, planInit, summaryLines } from "./check.js";
import { addDays } from "./dates.js";
import { buildConfirmMail, buildRemindMail } from "./mail.js";
import { formatReceipt } from "./receipt.js";
import { SHOP_NAME, sampleData } from "./samples.js";
import { parseSettings } from "./settings.js";
import { checkReport, initReport } from "./setup.js";
import { textOf } from "./text.js";
import { nowStamp_, ownerEmail_, saveLastId_, withLock_ } from "./gas_store.js";
import { CONFIRMED_, SETTINGS_SHEET, applyInit_, readReservations_, readServices_, readSettings_, readSetupSnapshot_, updateReservation_, writeSamples_ } from "./gas_sheets.js";
import { calendarOf_ } from "./gas_calendar.js";
import { sendMail_ } from "./gas_mail.js";
import { appUrl_, cancelUrl_, noticeTo_, safely_ } from "./gas_web.js";
import { notifyAll_ } from "./gas_notify.js";

const MENU_TITLE = "予約ページ";
/** このキットの版（「設定を確かめる」の最後に出す）。package.json の version と同じ字にする（docs.test が確かめる） */
const KIT_VERSION = "1.1.2";
/** 時間主導トリガーが呼ぶ関数の名前 */
const REMIND_HANDLER_ = "remind_";

/**
 * menu_* は名前が _ で終わらないので、公開した予約ページから google.script.run で誰でも呼べてしまう。
 * getUi はスプレッドシートのメニュー（とスクリプト エディタ）からの実行でしか使えず、それ以外では例外を投げる。
 * menu_* はどれも、最初にこれを try の外で呼んでから動く（予約ページから呼ばれたら、メールもシートも触らずに止まる）
 */
function ui_() {
  return SpreadsheetApp.getUi();
}

function alert_(text) {
  ui_().alert(text);
}

/** 「設定を確かめる」の最後の 1 行。お問い合わせのときに、何版が入っているかを確かめられるように */
function versionLine_() {
  return "\n\n予約ページ キット " + KIT_VERSION;
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

export function onOpen() {
  ui_()
    .createMenu(MENU_TITLE)
    .addItem("初期化（足りないシート・見出し・設定を足す。データは消しません）", "menu_init")
    .addItem("見本を入れる", "menu_samples")
    .addItem("設定を確かめる", "menu_check")
    .addItem("予約ページの URL", "menu_url")
    .addItem("リマインドのトリガーを作る", "menu_trigger")
    .addItem("テスト送信（自分にメール）", "menu_testMail")
    .addToUi();
}

/**
 * 「設定」「枠」「休み」「サービス」「予約」の 5 シートのうち、足りないシート・見出し・設定の行だけを足す。
 * 何度押してもよく、既にあるご予約・枠・設定の値は変えない
 */
export function menu_init() {
  ui_();
  try {
    const plan = withLock_(function () {
      const built = planInit(readSetupSnapshot_(nowStamp_().slice(0, 10)));
      applyInit_(built);
      return built;
    });
    alert_(initReport(plan, plan.nextStep));
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 見本の店を流し込む（「予約」に書き足すので、先に確認をいただく） */
export function menu_samples() {
  const ui = ui_();
  try {
    const answer = ui.alert(
      "見本を入れてもよろしいですか？",
      "「設定」「枠」「休み」「サービス」は見本の内容に置き換わります。「予約」には見本のご予約が書き足されます。よろしければ「OK」を押してください。",
      ui.ButtonSet.OK_CANCEL
    );
    if (answer !== ui.Button.OK) {
      alert_("見本は入れませんでした。");
      return;
    }
    const today = nowStamp_().slice(0, 10);
    const made = writeSamples_(sampleData(today));
    // 見本の受付番号の続きから振れるように、最後の番号を覚えておく
    if (made.lastId !== "") saveLastId_(made.lastId);
    alert_("見本「" + SHOP_NAME + "」を入れました。ご予約の見本は " + made.reservations + " 件です。\n\n中身を見ながら「設定」「枠」「休み」「サービス」をお店の内容に書き換えてください。");
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** リマインドの時間主導トリガーがあるか。読めなければ無いものとする */
function hasRemindTrigger_() {
  try {
    const triggers = ScriptApp.getProjectTriggers();
    for (let i = 0; i < triggers.length; i += 1) if (triggers[i].getHandlerFunction() === REMIND_HANDLER_) return true;
    return false;
  } catch (error) {
    return false;
  }
}

/** 設定「カレンダー ID」のカレンダーを開けるか: "none"（空）/ "ok" / "missing" */
function calendarState_(settings) {
  if (textOf(settings.calendarId) === "") return "none";
  try {
    return calendarOf_(settings) === null ? "missing" : "ok";
  } catch (error) {
    return "missing";
  }
}

/**
 * 設定・枠・休み・サービスの誤り（1.0 と同じ）に、シートと見出しの不足・枠とサービスの食い違い・通知の URL・
 * カレンダーを開けるかを足して一覧で出す。無ければ、これから何が起きるかを短く出す
 */
export function menu_check() {
  ui_();
  try {
    const snapshot = readSetupSnapshot_(nowStamp_().slice(0, 10));
    snapshot.hasTrigger = hasRemindTrigger_();
    snapshot.appUrl = appUrl_();
    snapshot.calendar = calendarState_(parseSettings(snapshot.sheets[SETTINGS_SHEET] || []).settings);
    const problems = findProblems(snapshot);
    alert_(checkReport(problems, problems.length === 0 ? summaryLines(snapshot) : [], "booking: ", checkNotes(snapshot)) + versionLine_());
  } catch (error) {
    alert_(failureText_(error) + versionLine_());
  }
}

/** 公開した予約ページの URL を出す */
export function menu_url() {
  ui_();
  const url = appUrl_();
  if (url === "") {
    alert_("まだ公開されていません。" + DEPLOY_STEPS + "\n公開してから、もう一度お試しください。");
    return;
  }
  alert_("予約ページの URL:\n" + url + "\n\nこの URL をお客さまにお知らせください。Google アカウントをお持ちでない方もご予約いただけます。");
}

/** 前日リマインドの時間主導トリガーを作り直す（同じものが増えないように、先に消す） */
export function menu_trigger() {
  ui_();
  try {
    const settings = readSettings_().settings;
    const existing = ScriptApp.getProjectTriggers();
    let removed = 0;
    for (let i = 0; i < existing.length; i += 1) {
      if (existing[i].getHandlerFunction() !== REMIND_HANDLER_) continue;
      ScriptApp.deleteTrigger(existing[i]);
      removed += 1;
    }
    ScriptApp.newTrigger(REMIND_HANDLER_).timeBased().atHour(settings.remindHour).everyDays(1).create();
    alert_(
      "前日のリマインドのトリガーを作りました。毎日 " + settings.remindHour + " 時ごろに、翌日のご予約へメールをお送りします。" +
        (removed > 0 ? "（前のトリガー " + removed + " 件は消しました）" : "") +
        "\n\n時刻は「設定」の「リマインドの時刻」で変えられます。変えたあとは、もう一度このメニューを実行してください。"
    );
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 確認メールの見本を自分に送る（文面と差出人の名前を確かめるため） */
export function menu_testMail() {
  ui_();
  try {
    const to = ownerEmail_();
    if (to === "") {
      alert_("メールアドレスを読み取れませんでした。スプレッドシートを開き直してから、もう一度お試しください。");
      return;
    }
    const settings = readSettings_().settings;
    const services = readServices_().services;
    const today = nowStamp_().slice(0, 10);
    const sample = {
      "ID": formatReceipt(today, 1),
      "状態": CONFIRMED_,
      "日付": addDays(today, 1),
      "開始": "10:00",
      "終了": "11:00",
      "サービス": services.length > 0 ? textOf(services[0].name) : "",
      "お名前": "見本",
      "メール": to,
      "電話": "",
      "ご要望": "",
    };
    // テスト送信の見本には合い言葉が無いので、キャンセルの URL は空にする（どのご予約にも当たらない URL を載せない）
    const mail = buildConfirmMail(settings, sample, "");
    const sent = sendMail_(to, "【テスト送信】" + mail.subject, mail.body, settings.shopName, settings.contactEmail);
    if (!sent) {
      alert_("テスト送信できませんでした。1 日に送れるメールの数の上限に達している可能性があります。しばらくしてから、もう一度お試しください。");
      return;
    }
    alert_("テスト送信しました: " + to + "\n\n件名と本文は「設定」の「確認メールの件名」「確認メールの本文」で変えられます。");
  } catch (error) {
    alert_(failureText_(error));
  }
}

/**
 * 前日リマインド（時間主導トリガーの入口）。
 * 翌日の「確定」で「リマインド」が空の予約にメールし、送れた分だけ日時を書く
 */
export function remind_() {
  const stamp = nowStamp_();
  const target = addDays(stamp.slice(0, 10), 1);
  const settings = readSettings_().settings;
  const reservations = readReservations_();
  let sent = 0;
  const failed = [];

  for (let i = 0; i < reservations.length; i += 1) {
    const row = reservations[i];
    if (textOf(row["状態"]) !== CONFIRMED_) continue;
    if (textOf(row["日付"]) !== target) continue;
    if (textOf(row["リマインド"]) !== "") continue;

    const sentOk = safely_(
      "前日のリマインドを送れませんでした",
      () => {
        const mail = buildRemindMail(settings, row, cancelUrl_(row["キャンセル用"]));
        return sendMail_(row["メール"], mail.subject, mail.body, settings.shopName, settings.contactEmail);
      },
      false
    );
    // 送れなかった分は日時を書かないでおく（お店が手でご連絡したかどうかを、空の列で見分けられる）
    if (!sentOk) {
      failed.push(textOf(row["ID"]));
      continue;
    }
    updateReservation_(row._row, { "リマインド": stamp });
    sent += 1;
  }

  Logger.log("予約ページ: " + target + " のご予約に、前日のリマインドを " + sent + " 件送りました");
  // 次の回は翌々日のぶんを見るので、送れなかった分は送り直されない。お店に知らせて、手でご連絡いただく
  if (failed.length > 0) {
    const text =
      "【予約ページ】" + target + " のご予約のうち " + failed.length + " 件に、前日のリマインドを送れませんでした（受付番号 " +
      failed.join("、") + "）。1 日に送れるメールの上限に達したか、宛先が誤っている可能性があります。お手数ですが、お電話などでご連絡ください。";
    Logger.log(text);
    safely_("リマインドの失敗を知らせられませんでした", () => notifyAll_(settings, text), 0);
    safely_("リマインドの失敗を知らせられませんでした", () => sendMail_(noticeTo_(settings), "【予約ページ】前日のリマインドを送れなかったご予約があります", text, settings.shopName), false);
  }
  return sent;
}
