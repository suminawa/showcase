import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdtempSync, readFileSync, cpSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { MANIFEST, SERVER_ORDER, ROOT, build, toGasSource, buildServer, buildAppHtml } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("import 行を落とし、行頭の export だけ剥がす", () => {
  const src = 'import { a } from "./a.js";\nexport function f() {}\nexport const X = 1;\nexport class C {}\nconst inner = "export function g";\n';
  const out = toGasSource(src);
  assert.equal(out.indexOf("import"), -1);
  assert.ok(out.startsWith("function f() {}"));
  assert.ok(out.includes("\nconst X = 1;"));
  assert.ok(out.includes("\nclass C {}"));
  assert.ok(out.includes('const inner = "export function g"'));
});

test("build は dist と demo に 5 つの生成物を書き、Code.gs に import / export が残らない", () => {
  build(ROOT);
  for (const name of ["dist/Code.gs", "dist/App.html", "dist/appsscript.json", "demo/app.js", "demo/app.css"]) {
    assert.ok(existsSync(join(root, name)), name);
  }
  const code = readFileSync(join(root, "dist", "Code.gs"), "utf8");
  assert.equal(/^\s*(import|export)\s/m.test(code), false);
  for (const name of SERVER_ORDER) assert.ok(code.includes("// ===== " + name + " ====="), name);
  const manifest = JSON.parse(readFileSync(join(root, "dist", "appsscript.json"), "utf8"));
  assert.deepEqual(manifest, MANIFEST);
  assert.deepEqual(manifest.webapp, { access: "ANYONE", executeAs: "USER_ACCESSING" });
  assert.equal(manifest.oauthScopes.length, 4);
  const html = readFileSync(join(root, "dist", "App.html"), "utf8");
  assert.ok(html.includes('<div id="app" class="sa"></div>'));
  assert.ok(html.includes('mountSheetApp(document.getElementById("app"), gasApi());'));
  assert.equal(html.includes("/*__SCRIPT__*/"), false);
  assert.equal(html.includes("/*__STYLE__*/"), false);
});

test("同じ名前の関数が 2 ファイルにあると build が止まる", () => {
  const dir = mkdtempSync(join(tmpdir(), "sheet-app-"));
  cpSync(join(root, "src"), join(dir, "src"), { recursive: true });
  writeFileSync(join(dir, "src", "dates.js"), "export function parseDefinition() {}\n");
  assert.throws(() => buildServer(dir), /同じ名前「parseDefinition」/);
});

test("画面の JS に </script が混ざると build が止まる", () => {
  const dir = mkdtempSync(join(tmpdir(), "sheet-app-"));
  cpSync(join(root, "src"), join(dir, "src"), { recursive: true });
  mkdirSync(join(dir, "src", "ui"), { recursive: true });
  writeFileSync(join(dir, "src", "ui", "render.js"), 'const BAD = "</script>";\n');
  assert.throws(() => buildAppHtml(dir), /<\/script/);
});
