import { test } from "node:test";
import assert from "node:assert/strict";
import { formatCell, toSheetValue, fromSheetValue, fromSystemValue, safeCell, withCommas } from "../src/format.js";

const col = (type) => ({ name: "x", type: type, options: [] });

test("formatCell: 金額・数値・日付の書式・日時・チェック・複数選択・空", () => {
  assert.equal(formatCell(col("金額"), 1200000), "¥1,200,000");
  assert.equal(formatCell(col("数値"), 4.5), "4.5");
  assert.equal(formatCell(col("数値"), 12345), "12,345");
  assert.equal(formatCell(col("日付"), "2026-09-16", { dateFormat: "yyyy/MM/dd" }), "2026/09/16");
  assert.equal(formatCell(col("日時"), "2026-09-16 10:30", { dateFormat: "yyyy/MM/dd" }), "2026/09/16 10:30");
  assert.equal(formatCell(col("チェック"), true), "✓");
  assert.equal(formatCell(col("チェック"), false), "");
  assert.equal(formatCell(col("複数選択"), ["設計", "施工"]), "設計、施工");
  assert.equal(formatCell(col("文字"), null), "");
  assert.equal(formatCell(col("文字"), 0), "0");
});

test("toSheetValue: 日付は Date（JST 0 時）、チェックは boolean、複数選択はカンマ区切り、文字はすべて ' を付けて書く", () => {
  assert.equal(toSheetValue(col("日付"), "2026-09-16").toISOString(), "2026-09-15T15:00:00.000Z");
  assert.equal(toSheetValue(col("日時"), "2026-09-16 10:30").toISOString(), "2026-09-16T01:30:00.000Z");
  assert.equal(toSheetValue(col("日付"), ""), "");
  assert.equal(toSheetValue(col("金額"), 1200), 1200);
  assert.equal(toSheetValue(col("金額"), null), "");
  assert.equal(toSheetValue(col("チェック"), true), true);
  assert.equal(toSheetValue(col("複数選択"), ["a", "b"]), "'a, b");
  assert.equal(toSheetValue(col("文字"), "=SUM(A1)"), "'=SUM(A1)");
  assert.equal(toSheetValue(col("文字"), "+81"), "'+81");
  assert.equal(toSheetValue(col("電話"), "09012345678"), "'09012345678", "先頭の 0 を落とさない");
  assert.equal(safeCell("普通"), "'普通");
  assert.equal(safeCell(""), "");
});

test("fromSheetValue: Date → 日付キー、数値の文字 → number、TRUE → boolean、空 → 型ごとの空", () => {
  assert.equal(fromSheetValue(col("日付"), new Date("2026-09-15T15:00:00Z")), "2026-09-16");
  assert.equal(fromSheetValue(col("日時"), new Date("2026-09-16T01:30:00Z")), "2026-09-16 10:30");
  assert.equal(fromSheetValue(col("金額"), "1,200"), 1200);
  assert.equal(fromSheetValue(col("金額"), 1200), 1200);
  assert.equal(fromSheetValue(col("金額"), ""), null);
  assert.equal(fromSheetValue(col("チェック"), "TRUE"), true);
  assert.equal(fromSheetValue(col("チェック"), ""), false);
  assert.deepEqual(fromSheetValue(col("複数選択"), "a, b"), ["a", "b"]);
  assert.deepEqual(fromSheetValue(col("複数選択"), ""), []);
  assert.equal(fromSheetValue(col("文字"), 42), "42");
  assert.equal(fromSystemValue(new Date("2026-09-16T01:30:05Z")), "2026-09-16 10:30");
  assert.equal(fromSystemValue("20260916-001"), "20260916-001");
  assert.equal(withCommas(1234567.5), "1,234,567.5");
});
