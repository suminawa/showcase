import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { buildFilterRequest, parseFilterAnswer, buildSummaryRequest, buildFilterSchema, FALLBACK_EXPLANATION, MESSAGES_URL, ANTHROPIC_VERSION } from "../src/ai_prompt.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", "法人名"],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "", ""],
]);
const T = tables[0];

test("絞り込みのリクエスト: system に列と型と選択肢と今日、user は囲みの中、structured outputs、キャッシュ", () => {
  const body = buildFilterRequest(T, "先月連絡した横浜の取引中", { today: "2026-09-16", model: "claude-sonnet-5" });
  assert.equal(body.model, "claude-sonnet-5");
  assert.equal(body.max_tokens, 1024);
  assert.equal(body.system[0].cache_control.ttl, "1h");
  assert.ok(body.system[0].text.includes("今日は 2026-09-16"));
  assert.ok(body.system[0].text.includes("- 会社名（文字）: 法人名"));
  assert.ok(body.system[0].text.includes("- 状況（選択: 見込み, 取引中, 休眠）"));
  assert.ok(body.system[0].text.includes("- 年間取引額（金額）"));
  assert.ok(body.messages[0].content[0].text.includes("<絞り込みの言葉>\n先月連絡した横浜の取引中\n</絞り込みの言葉>"));
  assert.equal(body.output_config.format.type, "json_schema");
  assert.equal(body.output_config.effort, "low");
  const schema = body.output_config.format.schema;
  assert.deepEqual(schema.properties.filters.items.properties.column.enum, ["会社名", "状況", "最終連絡日", "年間取引額", "要注意"]);
  assert.ok(schema.properties.sort.anyOf[0].properties.column.enum.includes("更新日時"));
  assert.equal(schema.additionalProperties, false);
  assert.equal(MESSAGES_URL, "https://api.anthropic.com/v1/messages");
  assert.equal(ANTHROPIC_VERSION, "2023-06-01");
  assert.deepEqual(buildFilterSchema(T).required, ["q", "filters", "sort", "explanation"]);
});

test("haiku には effort を付けない", () => {
  const body = buildFilterRequest(T, "x", { today: "2026-09-16", model: "claude-haiku-4-5" });
  assert.equal(body.output_config.effort, undefined);
});

test("答えの解釈: between と in はカンマ区切りを配列に、知らない列・op は落ちる、壊れた JSON は変えない", () => {
  const good = parseFilterAnswer(T, JSON.stringify({ q: "横浜", filters: [{ column: "状況", op: "eq", value: "取引中" }, { column: "最終連絡日", op: "between", value: "2026-08-01,2026-08-31" }, { column: "状況", op: "in", value: "見込み, 休眠" }, { column: "無い", op: "eq", value: "x" }], sort: { column: "年間取引額", dir: "desc" }, explanation: "状況が取引中で、最終連絡日が 8 月の顧客に絞りました" }));
  assert.equal(good.q, "横浜");
  assert.deepEqual(good.filters, [
    { column: "状況", op: "eq", value: "取引中" },
    { column: "最終連絡日", op: "between", value: ["2026-08-01", "2026-08-31"] },
    { column: "状況", op: "in", value: ["見込み", "休眠"] },
  ]);
  assert.deepEqual(good.sort, { column: "年間取引額", dir: "desc" });
  assert.equal(good.explanation, "状況が取引中で、最終連絡日が 8 月の顧客に絞りました");
  const broken = parseFilterAnswer(T, "{not json");
  assert.deepEqual(broken, { q: "", filters: [], sort: null, explanation: FALLBACK_EXPLANATION });
  const noSort = parseFilterAnswer(T, JSON.stringify({ q: "", filters: [], sort: null, explanation: "" }));
  assert.equal(noSort.sort, null);
  assert.equal(noSort.explanation, "条件を読み取れませんでした。言い方を変えてお試しください");
});

test("要約のリクエスト: 記録の値を書式つきで囲みに入れ、参照は表示名で、敬体と次の一手を求める", () => {
  const body = buildSummaryRequest(T, { ID: "20260901-001", 会社名: "みなと工務店", 状況: "取引中", 最終連絡日: "2026-09-10", 年間取引額: 1200000, 要注意: true, 作成日時: "2026-09-01 10:00:00", 更新日時: "2026-09-10 10:00:00", 更新者: "sample@example.com" }, {}, { today: "2026-09-16", model: "claude-sonnet-5", dateFormat: "yyyy/MM/dd" });
  assert.equal(body.max_tokens, 4096, "打ち切られないよう広めに取る");
  assert.equal(body.output_config.effort, "low");
  assert.equal(body.output_config.format, undefined, "要約は JSON ではないので format は付けない");
  assert.ok(body.system.includes("敬体"));
  assert.ok(body.system.includes("次の一手: "));
  const user = body.messages[0].content[0].text;
  assert.ok(user.includes("<記録>"));
  assert.ok(user.includes("会社名: みなと工務店"));
  assert.ok(user.includes("最終連絡日: 2026/09/10"));
  assert.ok(user.includes("年間取引額: ¥1,200,000"));
  assert.ok(user.includes("要注意: ✓"));
  assert.ok(user.includes("更新日時: 2026-09-10 10:00:00"));
  assert.equal(user.includes("sample@example.com"), false, "更新者のメールは送らない");
});
