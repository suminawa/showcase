/**
 * 「設定」シート（項目・値の 2 列）を読む。空欄は既定値、知らない行は無視。誤りは敬体の文で集める。
 */
import { toHalfWidth } from "./dates.js";
import { splitList } from "./definition.js";
import { boolOf, textOf } from "./text.js";

export const SETTING_KEYS = ["アプリ名", "編集できる人", "1 ページの件数", "日付の書式", "AI を使う", "モデル", "AI の 1 日の上限"];
export const DATE_FORMATS = ["yyyy-MM-dd", "yyyy/MM/dd"];
export const DEFAULT_SETTINGS = {
  appName: "業務アプリ",
  editors: [],
  pageSize: 50,
  dateFormat: "yyyy-MM-dd",
  aiEnabled: true,
  model: "claude-sonnet-5",
  aiDailyLimit: 200,
};

function normalizeKey_(value) {
  return String(value === null || value === undefined ? "" : value).replace(/\s+/g, "").toLowerCase();
}

function integer_(value, min, max) {
  // 全角で打たれた「１００」も数として読む
  const n = Number(toHalfWidth(textOf(value)));
  if (!Number.isInteger(n) || n < min || n > max) return null;
  return n;
}

/** rows は「設定」シートの 2 次元配列（1 行目の見出しはあってもなくてもよい） */
export function parseSettings(rows) {
  const settings = {
    appName: DEFAULT_SETTINGS.appName,
    editors: [],
    pageSize: DEFAULT_SETTINGS.pageSize,
    dateFormat: DEFAULT_SETTINGS.dateFormat,
    aiEnabled: DEFAULT_SETTINGS.aiEnabled,
    model: DEFAULT_SETTINGS.model,
    aiDailyLimit: DEFAULT_SETTINGS.aiDailyLimit,
  };
  const errors = [];
  const list = Array.isArray(rows) ? rows : [];
  for (let i = 0; i < list.length; i += 1) {
    const key = normalizeKey_(list[i][0]);
    const value = list[i].length > 1 ? list[i][1] : "";
    const raw = textOf(value);
    if (key === "アプリ名") {
      if (raw !== "") settings.appName = raw.slice(0, 40);
    } else if (key === "編集できる人") {
      settings.editors = splitList(raw).map((s) => s.toLowerCase());
    } else if (key === "1ページの件数") {
      if (raw !== "") {
        const n = integer_(raw, 10, 200);
        if (n === null) errors.push("設定「1 ページの件数」は 10〜200 の整数にしてください（いまは「" + raw + "」）");
        else settings.pageSize = n;
      }
    } else if (key === "日付の書式") {
      if (raw !== "") {
        if (DATE_FORMATS.indexOf(raw) < 0) errors.push("設定「日付の書式」は yyyy-MM-dd か yyyy/MM/dd にしてください（いまは「" + raw + "」）");
        else settings.dateFormat = raw;
      }
    } else if (key === "aiを使う") {
      settings.aiEnabled = boolOf(value, DEFAULT_SETTINGS.aiEnabled);
    } else if (key === "モデル") {
      if (raw !== "") settings.model = raw;
    } else if (key === "aiの1日の上限") {
      if (raw !== "") {
        const n = integer_(raw, 1, 10000);
        if (n === null) errors.push("設定「AI の 1 日の上限」は 1〜10000 の整数にしてください（いまは「" + raw + "」）");
        else settings.aiDailyLimit = n;
      }
    }
  }
  return { settings: settings, errors: errors };
}
