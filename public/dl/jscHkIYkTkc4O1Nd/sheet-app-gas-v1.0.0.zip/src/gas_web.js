/**
 * Web アプリの入口（doGet）と、画面から google.script.run で呼ぶ api_*。
 * 引数を検査 → 純粋な処理 → gas_sheets の順。誤りは敬体の Error を投げる（画面の帯に出る）。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { findColumn, findTable } from "./definition.js";
import { validate } from "./validate.js";
import { laterId, nextId, parseId } from "./ids.js";
import { applyQuery, filterRows, normalizeQuery, sortRows } from "./query.js";
import { toCsv } from "./csv.js";
import { canEdit } from "./access.js";
import { buildFilterRequest, buildSummaryRequest, parseFilterAnswer } from "./ai_prompt.js";
import { addUsage } from "./usage.js";
import { readApiKey_, readDailyAiCount_, readLastId_, readMonthUsage_, saveDailyAiCount_, saveLastId_, saveMonthUsage_, withLock_ } from "./gas_store.js";
import { appendRecord_, deleteRecord_, readDefinition_, readIds_, readSettings_, readTable_, sheetEditable_, updateRecord_ } from "./gas_sheets.js";
import { callClaude_ } from "./gas_claude.js";
import { textOf } from "./text.js";

const OPTIONS_LIMIT = 2000;
const AI_UNAVAILABLE = "AI の機能は使えません。設定「AI を使う」が TRUE で、スクリプト プロパティ ANTHROPIC_API_KEY が入っているかをご確認ください";
const SUMMARY_TOO_LONG = "記録が長すぎて要約を作れませんでした。長文の項目を短くしてからお試しください";
/** スプレッドシートを開けないとき（共有されていない・削除された・別のアカウントで開いている）の案内 */
function escapeHtml_(value) {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function noAccessHtml_(email) {
  const who = email === "" ? "" : "<p>いま開いている Google アカウント: <strong>" + escapeHtml_(email) + "</strong></p>";
  return (
    '<!DOCTYPE html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">' +
    '<body style="font-family:system-ui;padding:24px;line-height:1.7"><p>このアプリを使うには、元のスプレッドシートの共有が必要です。' +
    "所有者に「閲覧者」か「編集者」での共有をご依頼ください。</p>" +
    who +
    "<p>共有されているのにこの画面が出るときは、ブラウザに複数の Google アカウントでログインしていて、別のアカウントで開かれていることがあります。" +
    "シークレット ウィンドウで、共有されているアカウントだけでログインしてお試しください。</p></body></html>"
  );
}

function user_() {
  try {
    return String(Session.getActiveUser().getEmail() || "").trim().toLowerCase();
  } catch (error) {
    return "";
  }
}

/** 設定・定義・利用者をまとめて読む（1 回の API で 1 回だけ） */
function contextOf() {
  const settings = readSettings_();
  const definition = readDefinition_();
  return {
    settings: settings.settings,
    tables: definition.tables,
    errors: definition.errors.concat(settings.errors),
    email: user_(),
  };
}

/** 画面に編集の操作を出してよいか。「編集できる人」の絞り込みと、シートの共有（閲覧者には出さない）の両方 */
function canEditHere_(ctx) {
  if (!canEdit(ctx.email, ctx.settings.editors)) return false;
  return sheetEditable_(ctx.email) !== false;
}

function tableOf_(ctx, name) {
  const table = findTable(ctx.tables, textOf(name));
  if (table === null) throw new Error("テーブル「" + textOf(name) + "」は定義にありません");
  return table;
}

function requireEditor_(ctx) {
  if (!canEdit(ctx.email, ctx.settings.editors)) {
    throw new Error("この画面では閲覧のみできます。編集が必要な場合は、設定「編集できる人」への追加を所有者に依頼してください");
  }
}

function aiAvailable_(ctx) {
  return ctx.settings.aiEnabled && readApiKey_() !== "";
}

/** 参照の列の表示名。rows に出てくる ID だけ引く */
function refsFor_(ctx, table, rows) {
  const refs = {};
  const cache = {};
  for (let c = 0; c < table.columns.length; c += 1) {
    const column = table.columns[c];
    if (column.type !== "参照") continue;
    const target = findTable(ctx.tables, column.refTable);
    if (target === null) continue;
    if (cache[target.name] === undefined) {
      const map = {};
      const read = readTable_(target).records;
      for (let i = 0; i < read.length; i += 1) map[read[i].ID] = textOf(read[i][target.display]) || read[i].ID;
      cache[target.name] = map;
    }
    const map = cache[target.name];
    const out = {};
    for (let r = 0; r < rows.length; r += 1) {
      const id = textOf(rows[r][column.name]);
      if (id !== "" && map[id] !== undefined) out[id] = map[id];
    }
    refs[column.name] = out;
  }
  return refs;
}

/** 参照の値が相手のテーブルに実在するか */
function checkRefs_(ctx, table, values) {
  for (let c = 0; c < table.columns.length; c += 1) {
    const column = table.columns[c];
    if (column.type !== "参照" || !Object.prototype.hasOwnProperty.call(values, column.name)) continue;
    const id = textOf(values[column.name]);
    if (id === "") continue;
    const target = findTable(ctx.tables, column.refTable);
    if (target === null || readTable_(target).rowNumbers[id] === undefined) {
      throw new Error(column.name + ": 参照先の記録が見つかりません（" + id + "）");
    }
  }
}

function errorText_(errors) {
  const names = Object.keys(errors);
  return names.map((name) => errors[name]).join("\n");
}

function findRecord_(table, id) {
  const read = readTable_(table);
  const rowNumber = read.rowNumbers[textOf(id)];
  if (rowNumber === undefined) throw new Error("ID「" + textOf(id) + "」の記録が見つかりません。削除された可能性があります");
  let record = null;
  for (let i = 0; i < read.records.length; i += 1) {
    if (read.records[i].ID === textOf(id)) {
      record = read.records[i];
      break;
    }
  }
  return { record: record, rowNumber: rowNumber };
}

export function doGet() {
  try {
    const ctx = contextOf();
    return HtmlService.createHtmlOutputFromFile("App").setTitle(ctx.settings.appName).addMetaTag("viewport", "width=device-width, initial-scale=1");
  } catch (error) {
    // スプレッドシートを開けない人（共有されていない・元のシートが削除された）には、空白の画面ではなく案内を出す
    return HtmlService.createHtmlOutput(noAccessHtml_(user_())).setTitle("業務アプリ");
  }
}

export function api_bootstrap() {
  const ctx = contextOf();
  return {
    appName: ctx.settings.appName,
    tables: ctx.tables,
    errors: ctx.errors,
    user: { email: ctx.email, canEdit: canEditHere_(ctx) },
    ai: aiAvailable_(ctx),
    pageSize: ctx.settings.pageSize,
    dateFormat: ctx.settings.dateFormat,
    today: toDateKey(new Date()),
  };
}

function queryOf_(ctx, table, raw) {
  const source = raw === null || typeof raw !== "object" ? {} : raw;
  const merged = Object.assign({ pageSize: ctx.settings.pageSize }, source);
  if (source.pageSize === undefined || source.pageSize === null) merged.pageSize = ctx.settings.pageSize;
  return normalizeQuery(table, merged);
}

export function api_list(tableName, rawQuery) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const query = queryOf_(ctx, table, rawQuery);
  const result = applyQuery(table, readTable_(table).records, query);
  return { rows: result.rows, total: result.total, page: result.page, pageSize: result.pageSize, refs: refsFor_(ctx, table, result.rows) };
}

export function api_get(tableName, id) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const found = findRecord_(table, id);
  const refs = refsFor_(ctx, table, [found.record]);
  const flat = {};
  Object.keys(refs).forEach((name) => {
    const value = textOf(found.record[name]);
    if (value !== "" && refs[name][value] !== undefined) flat[name] = refs[name][value];
  });
  return { row: found.record, refs: flat };
}

export function api_options(tableName, columnName) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const column = findColumn(table, textOf(columnName));
  if (column === null || column.type !== "参照") throw new Error("列「" + textOf(columnName) + "」は参照の列ではありません");
  const target = tableOf_(ctx, column.refTable);
  const records = sortRows(target, readTable_(target).records, { column: target.display, dir: "asc" });
  const options = [];
  for (let i = 0; i < records.length && i < OPTIONS_LIMIT; i += 1) {
    options.push({ id: records[i].ID, label: textOf(records[i][target.display]) || records[i].ID });
  }
  return { options: options, truncated: records.length > OPTIONS_LIMIT };
}

/** ids のうち、today の日付キーで始まる ID の最大。無ければ "" */
export function maxIdOf_(ids, today) {
  let best = "";
  for (let i = 0; i < ids.length; i += 1) {
    const parsed = parseId(ids[i]);
    if (parsed === null || parsed.dateKey !== today) continue;
    best = laterId(best, ids[i]);
  }
  return best;
}

export function api_create(tableName, record) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  requireEditor_(ctx);
  const now = new Date();
  const today = toDateKey(now);
  const checked = validate(table, record, { today: today, isNew: true });
  if (!checked.ok) throw new Error(errorText_(checked.errors));
  checkRefs_(ctx, table, checked.values);
  return withLock_(() => {
    // 覚え書きが消えても（プロパティの削除・シートの複製）、シートに残っている今日の ID の続きから振る
    const id = nextId(laterId(readLastId_(table.name), maxIdOf_(readIds_(table), today)), today);
    const stamp = formatStamp(now);
    const full = Object.assign({ ID: id }, checked.values, { 作成日時: stamp, 更新日時: stamp, 更新者: ctx.email });
    appendRecord_(table, full);
    saveLastId_(table.name, id);
    return { id: id };
  });
}

export function api_update(tableName, id, record, seenUpdatedAt) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  requireEditor_(ctx);
  const now = new Date();
  const checked = validate(table, record, { today: toDateKey(now), isNew: false });
  if (!checked.ok) throw new Error(errorText_(checked.errors));
  checkRefs_(ctx, table, checked.values);
  return withLock_(() => {
    const found = findRecord_(table, id);
    if (textOf(found.record.更新日時) !== textOf(seenUpdatedAt)) {
      throw new Error("ほかの方が先に更新しました。いちど閉じて、読み直してください");
    }
    const stamp = formatStamp(new Date());
    updateRecord_(table, found.rowNumber, Object.assign({}, checked.values, { 更新日時: stamp, 更新者: ctx.email }));
    return { updatedAt: stamp };
  });
}

export function api_delete(tableName, id) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  requireEditor_(ctx);
  return withLock_(() => {
    const found = findRecord_(table, id);
    deleteRecord_(table, found.rowNumber, found.record.ID, found.record, ctx.email, formatStamp(new Date()));
    return { ok: true };
  });
}

export function api_export(tableName, rawQuery) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const query = queryOf_(ctx, table, rawQuery);
  const rows = sortRows(table, filterRows(table, readTable_(table).records, query), query.sort);
  return toCsv(table, rows);
}

/** AI の前置き: 使えるか・1 日の上限。呼べるなら回数を 1 つ進める（同時に呼ばれても上限を越えないよう、ロックの中で数える） */
function beforeAi_(ctx) {
  if (!aiAvailable_(ctx)) throw new Error(AI_UNAVAILABLE);
  const today = toDateKey(new Date());
  return withLock_(() => {
    const count = readDailyAiCount_(today);
    if (count >= ctx.settings.aiDailyLimit) throw new Error("AI の本日の上限（" + ctx.settings.aiDailyLimit + " 回）に達しました。明日またお試しください");
    saveDailyAiCount_(today, count + 1);
    return today;
  });
}

/** API の呼び出しが失敗したら、進めた回数を戻す */
function undoAi_(today) {
  withLock_(() => {
    saveDailyAiCount_(today, Math.max(0, readDailyAiCount_(today) - 1));
  });
}

function afterAi_(today, usage) {
  const month = today.slice(0, 7);
  withLock_(() => {
    saveMonthUsage_(month, addUsage(readMonthUsage_(month), usage));
  });
}

/** 前置き → 呼び出し → 後始末。失敗したら回数を戻してから投げる */
function callAi_(ctx, body) {
  const today = beforeAi_(ctx);
  let answer;
  try {
    answer = callClaude_(readApiKey_(), body);
  } catch (error) {
    undoAi_(today);
    throw error;
  }
  afterAi_(today, answer.usage);
  return answer;
}

export function api_ai_filter(tableName, text) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const words = textOf(text);
  if (words === "") throw new Error("絞り込みの言葉を入力してください");
  const answer = callAi_(ctx, buildFilterRequest(table, words.slice(0, 500), { today: toDateKey(new Date()), model: ctx.settings.model }));
  return parseFilterAnswer(table, answer.text);
}

export function api_ai_summary(tableName, id) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const got = api_get(tableName, id);
  const answer = callAi_(ctx, buildSummaryRequest(table, got.row, got.refs, { today: toDateKey(new Date()), model: ctx.settings.model, dateFormat: ctx.settings.dateFormat }));
  // 上限まで書いても終わらなかった答えは、途中で切れた文なので出さない
  if (answer.stopReason === "max_tokens") return { text: SUMMARY_TOO_LONG };
  return { text: textOf(answer.text) === "" ? "要約を作れませんでした。もう一度お試しください" : textOf(answer.text) };
}
