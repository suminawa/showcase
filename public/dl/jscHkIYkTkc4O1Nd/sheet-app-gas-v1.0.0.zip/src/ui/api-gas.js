/**
 * google.script.run を Promise に包む。画面から GAS を呼ぶのはここだけ。
 */
function call_(name, args) {
  return new Promise((resolve, reject) => {
    const runner = google.script.run
      .withSuccessHandler(resolve)
      .withFailureHandler((error) => reject(new Error(error && error.message ? error.message : String(error))));
    runner[name].apply(runner, args);
  });
}

export function gasApi() {
  return {
    bootstrap: () => call_("api_bootstrap", []),
    list: (table, query) => call_("api_list", [table, query]),
    get: (table, id) => call_("api_get", [table, id]),
    options: (table, column) => call_("api_options", [table, column]),
    create: (table, record) => call_("api_create", [table, record]),
    update: (table, id, record, seenUpdatedAt) => call_("api_update", [table, id, record, seenUpdatedAt]),
    remove: (table, id) => call_("api_delete", [table, id]),
    exportCsv: (table, query) => call_("api_export", [table, query]),
    aiFilter: (table, text) => call_("api_ai_filter", [table, text]),
    aiSummary: (table, id) => call_("api_ai_summary", [table, id]),
  };
}
