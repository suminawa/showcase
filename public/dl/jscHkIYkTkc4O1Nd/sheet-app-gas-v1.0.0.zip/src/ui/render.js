/**
 * 画面の描画。state から HTML の文字列を作るだけ（DOM に触るのは main.js）。
 */
import { findColumn } from "../definition.js";
import { formatCell } from "../format.js";
import { boolOf } from "../text.js";
import { currentTable } from "./state.js";

export const OP_LABELS = { contains: "を含む", eq: "と等しい", ne: "と等しくない", gt: "より大きい", gte: "以上", lt: "より小さい", lte: "以下", between: "の範囲", in: "のいずれか", empty: "が空", notEmpty: "が空でない" };
const LONG_TEXT_PREVIEW = 40;
const TYPE_INPUT = { 文字: "text", メール: "email", 電話: "tel", URL: "url", 日付: "date", 日時: "datetime-local" };
/** 型ごとに使える条件（当たりようのない条件は出さない） */
const TEXT_OPS = ["contains", "eq", "ne", "empty", "notEmpty"];
const ORDER_OPS = ["eq", "ne", "gt", "gte", "lt", "lte", "between", "empty", "notEmpty"];
const CHOICE_OPS = ["eq", "ne", "empty", "notEmpty"];
const FILTER_OPS = { 文字: TEXT_OPS, 長文: TEXT_OPS, メール: TEXT_OPS, 電話: TEXT_OPS, URL: TEXT_OPS, 数値: ORDER_OPS, 金額: ORDER_OPS, 日付: ORDER_OPS, 日時: ORDER_OPS, 選択: CHOICE_OPS, 参照: CHOICE_OPS, 複数選択: ["in", "contains", "empty", "notEmpty"], チェック: ["eq"] };
const FILTER_PLACEHOLDER = "範囲は 最小,最大。いずれかは 値1,値2";

export function escapeHtml(value) {
  return String(value === null || value === undefined ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function attr_(value) {
  return escapeHtml(value);
}

/** 一覧・詳細に出す文字。参照は refs（{ 列名: { ID: 表示名 } }）で表示名に */
export function labelFor(column, value, refs, opts) {
  if (column.type === "参照") {
    const id = value === null || value === undefined ? "" : String(value);
    if (id === "") return "";
    const map = refs && refs[column.name] ? refs[column.name] : {};
    return map[id] !== undefined ? map[id] : id;
  }
  return formatCell(column, value, opts);
}

function preview_(column, text) {
  if (column.type === "長文" && text.length > LONG_TEXT_PREVIEW) return text.slice(0, LONG_TEXT_PREVIEW) + "…";
  return text;
}

export function renderTabs(tables, current) {
  return '<nav class="sa-tabs" role="tablist">' + tables.map((t) => '<button type="button" role="tab" class="sa-tab" aria-selected="' + (t.name === current ? "true" : "false") + '" data-action="select-table" data-table="' + attr_(t.name) + '">' + escapeHtml(t.name) + "</button>").join("") + "</nav>";
}

function filterText_(table, filter, refs) {
  const column = table.columns.find((c) => c.name === filter.column) || { name: filter.column, type: "文字" };
  let value = "";
  if (filter.op === "between") value = escapeHtml(filter.value[0]) + "〜" + escapeHtml(filter.value[1]);
  else if (filter.op === "in") value = filter.value.map((v) => escapeHtml(labelFor(column, v, refs, {}))).join("、");
  else if (filter.op === "empty" || filter.op === "notEmpty") value = "";
  else if (column.type === "チェック") value = boolOf(filter.value, false) ? "はい" : "いいえ";
  else value = escapeHtml(labelFor(column, filter.value, refs, {}));
  const label = OP_LABELS[filter.op] || filter.op;
  // empty / notEmpty の label は「が空」「が空でない」と「が」を含むので、つなぎの「が」を重ねない
  if (filter.op === "empty" || filter.op === "notEmpty") return escapeHtml(filter.column) + " " + label;
  return escapeHtml(filter.column) + " が " + (value === "" ? "" : value + " ") + label;
}

export function renderFilterChips(table, filters, refs) {
  if (filters.length === 0) return "";
  return '<div class="sa-chips">' + filters.map((f, i) => '<span class="sa-chip">' + filterText_(table, f, refs) + ' <button type="button" class="sa-chip-x" data-action="remove-filter" data-index="' + i + '" aria-label="この条件を外す">×</button></span>').join("") + '<button type="button" class="sa-link" data-action="clear-filters">すべて外す</button></div>';
}

function choiceField_(list) {
  return '<select name="value"><option value="">（未選択）</option>' + list.map((o) => '<option value="' + attr_(o.value) + '">' + escapeHtml(o.label) + "</option>").join("") + "</select>";
}

/** 値の欄。型に合う入力にする（op が between のときは main.js が text に戻す） */
function valueField_(column, options) {
  const type = column === null ? "文字" : column.type;
  if (type === "選択" || type === "複数選択") return choiceField_(column.options.map((o) => ({ value: o, label: o })));
  if (type === "チェック") return '<select name="value"><option value="はい">はい</option><option value="いいえ">いいえ</option></select>';
  if (type === "参照") {
    const list = Array.isArray(options) ? options : null;
    if (list === null) return '<select name="value"></select><span class="sa-note">候補を読み込んでいます…</span>';
    return choiceField_(list.map((o) => ({ value: o.id, label: o.label })));
  }
  if (type === "日付") return '<input type="date" name="value">';
  if (type === "日時") return '<input type="datetime-local" name="value">';
  if (type === "数値" || type === "金額") return '<input type="text" inputmode="decimal" name="value" placeholder="範囲は 最小,最大">';
  return '<input type="text" name="value" placeholder="' + attr_(FILTER_PLACEHOLDER) + '">';
}

/** column は選ばれている列（null なら先頭の列）、options は 参照 の列の候補 [{ id, label }]（無ければ null） */
export function renderFilterPanel(table, column, options) {
  const chosen = column === null || column === undefined ? (table.columns.length > 0 ? table.columns[0] : null) : column;
  const columns = table.columns.map((c) => '<option value="' + attr_(c.name) + '"' + (chosen !== null && c.name === chosen.name ? " selected" : "") + ">" + escapeHtml(c.name) + "</option>").join("");
  const names = chosen === null ? TEXT_OPS : FILTER_OPS[chosen.type] || TEXT_OPS;
  const ops = names.map((op) => '<option value="' + op + '">' + escapeHtml(OP_LABELS[op]) + "</option>").join("");
  return '<form class="sa-filter-panel" data-form="filter"><label>列<select name="column">' + columns + "</select></label><label>条件<select name=\"op\">" + ops + "</select></label><label>値" + valueField_(chosen, options) + '</label><button type="submit" class="sa-btn">条件を足す</button></form>';
}

export function renderPager(total, page, pageSize) {
  if (total === 0) return "";
  const last = Math.max(1, Math.ceil(total / pageSize));
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  const prev = page > 1 ? '<button type="button" class="sa-btn sa-btn-quiet" data-action="page" data-page="' + (page - 1) + '">前へ</button>' : "";
  const next = page < last ? '<button type="button" class="sa-btn sa-btn-quiet" data-action="page" data-page="' + (page + 1) + '">次へ</button>' : "";
  return '<div class="sa-pager"><span>' + total + " 件中 " + from + "〜" + to + " 件</span>" + prev + next + "</div>";
}

function listColumns_(table) {
  return table.columns.filter((c) => c.inList);
}

export function renderTable(table, rows, refs, sort, opts) {
  const columns = listColumns_(table);
  const head = columns.map((c) => {
    const sorted = sort !== null && sort !== undefined && sort.column === c.name;
    const aria = sorted ? ' aria-sort="' + (sort.dir === "asc" ? "ascending" : "descending") + '"' : "";
    return "<th" + aria + '><button type="button" class="sa-th" data-action="sort" data-column="' + attr_(c.name) + '">' + escapeHtml(c.name) + (sorted ? (sort.dir === "asc" ? " ↑" : " ↓") : "") + "</button></th>";
  }).join("");
  const body = rows.map((row) => "<tr data-action=\"open\" data-id=\"" + attr_(row.ID) + '" tabindex="0">' + columns.map((c) => "<td>" + escapeHtml(preview_(c, labelFor(c, row[c.name], refs, opts))) + "</td>").join("") + "</tr>").join("");
  return '<div class="sa-table-wrap"><table class="sa-table"><thead><tr>' + head + "</tr></thead><tbody>" + body + "</tbody></table></div>";
}

export function renderCards(table, rows, refs, opts) {
  const columns = listColumns_(table);
  const cards = rows.map((row) => {
    const title = escapeHtml(labelFor(table.columns.find((c) => c.name === table.display) || { name: "ID", type: "文字" }, row[table.display], refs, opts) || row.ID);
    const lines = columns.filter((c) => c.name !== table.display).slice(0, 3).map((c) => '<div class="sa-card-line"><span>' + escapeHtml(c.name) + "</span>" + escapeHtml(preview_(c, labelFor(c, row[c.name], refs, opts))) + "</div>").join("");
    return '<article class="sa-card" data-action="open" data-id="' + attr_(row.ID) + '" tabindex="0"><h3>' + title + "</h3>" + lines + '<div class="sa-card-line sa-muted"><span>更新</span>' + escapeHtml(row.更新日時 || "") + "</div></article>";
  }).join("");
  return '<div class="sa-cards">' + cards + "</div>";
}

function valueHtml_(column, row, refs, opts) {
  const raw = row[column.name];
  const text = labelFor(column, raw, refs, opts);
  if (text === "") return '<span class="sa-muted">（空）</span>';
  // シートに直接書かれた javascript: などを href にしない。http(s) だけリンクにし、ほかは文字のまま
  if (column.type === "URL") {
    if (!/^https?:\/\//i.test(String(raw))) return escapeHtml(text);
    return '<a href="' + attr_(raw) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(text) + "</a>";
  }
  if (column.type === "メール") return '<a href="mailto:' + attr_(raw) + '">' + escapeHtml(text) + "</a>";
  if (column.type === "電話") return '<a href="tel:' + attr_(String(raw).replace(/[^0-9+]/g, "")) + '">' + escapeHtml(text) + "</a>";
  if (column.type === "長文") return '<div class="sa-pre">' + escapeHtml(text) + "</div>";
  return escapeHtml(text);
}

/** refs は { 列名: 表示名 }（api_get の形） */
export function renderDetail(table, row, refs, opts) {
  const flat = {};
  Object.keys(refs || {}).forEach((name) => {
    flat[name] = {};
    flat[name][String(row[name])] = refs[name];
  });
  const rows = table.columns.map((c) => "<dt>" + escapeHtml(c.name) + "</dt><dd>" + valueHtml_(c, row, flat, opts) + "</dd>").join("");
  const system = '<dt class="sa-muted">ID</dt><dd class="sa-muted">' + escapeHtml(row.ID) + '</dd><dt class="sa-muted">作成</dt><dd class="sa-muted">' + escapeHtml(row.作成日時 || "") + '</dd><dt class="sa-muted">更新</dt><dd class="sa-muted">' + escapeHtml(row.更新日時 || "") + " " + escapeHtml(row.更新者 || "") + "</dd>";
  const buttons = (opts.canEdit ? '<button type="button" class="sa-btn" data-action="edit">編集</button><button type="button" class="sa-btn sa-btn-danger" data-action="delete">削除</button>' : "") + (opts.ai ? '<button type="button" class="sa-btn sa-btn-quiet" data-action="ai-summary"' + (opts.summaryLoading ? " disabled" : "") + ">AI 要約</button>" : "");
  const summary = opts.summaryLoading ? '<div class="sa-summary sa-muted">要約しています…</div>' : opts.summary ? '<div class="sa-summary"><div class="sa-pre">' + escapeHtml(opts.summary) + "</div></div>" : "";
  return '<div class="sa-detail"><header class="sa-drawer-head"><h2>' + escapeHtml(labelFor(table.columns.find((c) => c.name === table.display) || { name: "ID", type: "文字" }, row[table.display], flat, opts) || row.ID) + '</h2><button type="button" class="sa-close" data-action="close" aria-label="閉じる">×</button></header><div class="sa-actions">' + buttons + "</div>" + summary + "<dl>" + rows + system + "</dl></div>";
}

function fieldHtml_(column, values, errors, options) {
  const value = values[column.name];
  const error = errors[column.name] || "";
  const id = "sa-f-" + column.name;
  const errId = "sa-err-" + column.name;
  const describe = (error ? ' aria-describedby="' + attr_(errId) + '" aria-invalid="true"' : "") ;
  let input = "";
  if (column.type === "長文") {
    input = '<textarea name="' + attr_(column.name) + '" id="' + attr_(id) + '" rows="4"' + describe + ">" + escapeHtml(value === null || value === undefined ? "" : value) + "</textarea>";
  } else if (column.type === "選択") {
    const opts = ['<option value="">（未選択）</option>'].concat(column.options.map((o) => '<option value="' + attr_(o) + '"' + (String(value) === o ? " selected" : "") + ">" + escapeHtml(o) + "</option>"));
    input = '<select name="' + attr_(column.name) + '" id="' + attr_(id) + '"' + describe + ">" + opts.join("") + "</select>";
  } else if (column.type === "複数選択") {
    const chosen = Array.isArray(value) ? value : [];
    input = '<div class="sa-checks" id="' + attr_(id) + '"' + describe + ">" + column.options.map((o) => '<label><input type="checkbox" name="' + attr_(column.name) + '" value="' + attr_(o) + '"' + (chosen.indexOf(o) >= 0 ? " checked" : "") + ">" + escapeHtml(o) + "</label>").join("") + "</div>";
  } else if (column.type === "チェック") {
    input = '<label class="sa-check"><input type="checkbox" name="' + attr_(column.name) + '" id="' + attr_(id) + '"' + (value === true ? " checked" : "") + describe + ">はい</label>";
  } else if (column.type === "参照") {
    const list = options[column.name] || [];
    const opts = ['<option value="">（未選択）</option>'].concat(list.map((o) => '<option value="' + attr_(o.id) + '"' + (String(value) === o.id ? " selected" : "") + ">" + escapeHtml(o.label) + "</option>"));
    input = '<select name="' + attr_(column.name) + '" id="' + attr_(id) + '"' + describe + ">" + opts.join("") + "</select>";
  } else if (column.type === "数値" || column.type === "金額") {
    input = '<input type="text" inputmode="' + (column.type === "金額" ? "numeric" : "decimal") + '" name="' + attr_(column.name) + '" id="' + attr_(id) + '" value="' + attr_(value === null || value === undefined ? "" : value) + '"' + describe + ">";
  } else {
    const type = TYPE_INPUT[column.type] || "text";
    const v = column.type === "日時" && value ? String(value).replace(" ", "T") : value;
    input = '<input type="' + type + '" name="' + attr_(column.name) + '" id="' + attr_(id) + '" value="' + attr_(v === null || v === undefined ? "" : v) + '"' + describe + ">";
  }
  return '<div class="sa-field' + (error ? " sa-field-error" : "") + '"><label for="' + attr_(id) + '">' + escapeHtml(column.name) + (column.required ? ' <span class="sa-required">必須</span>' : "") + "</label>" + input + (column.note ? '<div class="sa-note">' + escapeHtml(column.note) + "</div>" : "") + (error ? '<div class="sa-error" id="' + attr_(errId) + '">' + escapeHtml(error) + "</div>" : "") + "</div>";
}

/** options は { 参照の列名: [{ id, label }] } */
export function renderForm(table, values, errors, options, opts) {
  const fields = table.columns.map((c) => fieldHtml_(c, values || {}, errors || {}, options || {})).join("");
  const title = opts.isNew ? table.name + " を登録" : table.name + " を編集";
  return '<form class="sa-form" data-form="record" novalidate><header class="sa-drawer-head"><h2>' + escapeHtml(title) + '</h2><button type="button" class="sa-close" data-action="close" aria-label="閉じる">×</button></header>' + fields + '<div class="sa-actions"><button type="submit" class="sa-btn sa-btn-primary">' + (opts.isNew ? "登録" : "保存") + '</button><button type="button" class="sa-btn sa-btn-quiet" data-action="close">やめる</button></div></form>';
}

export function renderToolbar(state) {
  const table = currentTable(state);
  if (table === null) return "";
  const ai = state.ai ? '<div class="sa-ai"><input type="text" data-field="ai" value="' + attr_(state.aiText) + '" placeholder="言葉で絞り込む（例: 先月連絡した取引中の顧客）"><button type="button" class="sa-btn" data-action="ai-filter">AI で絞り込み</button></div>' + (state.aiExplanation ? '<div class="sa-ai-note">' + escapeHtml(state.aiExplanation) + "</div>" : "") : "";
  return '<div class="sa-toolbar"><input type="search" class="sa-search" data-field="q" value="' + attr_(state.q) + '" placeholder="検索" aria-label="検索"><button type="button" class="sa-btn sa-btn-quiet" data-action="toggle-filters" aria-expanded="' + (state.filterPanel ? "true" : "false") + '">絞り込み</button>' + (state.user.canEdit ? '<button type="button" class="sa-btn sa-btn-primary" data-action="new">新規</button>' : "") + '<button type="button" class="sa-btn sa-btn-quiet" data-action="csv">CSV</button>' + (state.loading ? '<span class="sa-spinner" aria-label="読み込み中"></span>' : "") + "</div>" + ai + (state.filterPanel ? renderFilterPanel(table, state.filterColumn ? findColumn(table, state.filterColumn) : null, state.filterOptions) : "") + renderFilterChips(table, state.filters, state.refs);
}

export function renderList(state) {
  const table = currentTable(state);
  if (table === null) return "";
  if (state.total === 0) return '<p class="sa-empty">' + (state.loading ? "読み込んでいます…" : "該当する記録はありません") + "</p>";
  const opts = { dateFormat: state.dateFormat };
  return renderTable(table, state.rows, state.refs, state.sort, opts) + renderCards(table, state.rows, state.refs, opts) + renderPager(state.total, state.page, state.pageSize);
}

export function renderDrawer(state) {
  const table = currentTable(state);
  if (table === null || state.view === null) return "";
  let inner = "";
  if (state.view.kind === "detail") inner = renderDetail(table, state.view.row, state.view.refs, { dateFormat: state.dateFormat, canEdit: state.user.canEdit, ai: state.ai, summary: state.view.summary, summaryLoading: state.view.summaryLoading });
  else inner = renderForm(table, state.view.values, state.view.errors, state.view.options, { isNew: state.view.isNew, id: state.view.id });
  return '<div class="sa-backdrop" data-action="close"></div><aside class="sa-drawer" role="dialog" aria-modal="true">' + inner + "</aside>";
}

function csvBox_(state) {
  if (state.csv === null) return "";
  return '<section class="sa-csv"><header class="sa-drawer-head"><h2>CSV</h2><button type="button" class="sa-close" data-action="csv-close" aria-label="閉じる">×</button></header><p>ファイルとして保存できない環境では、下の内容をコピーして .csv として保存してください。</p><div class="sa-actions"><button type="button" class="sa-btn" data-action="copy-csv">コピー</button></div><textarea readonly rows="8">' + escapeHtml(state.csv) + "</textarea></section>";
}

export function renderApp(state) {
  if (!state.ready) return '<div class="sa-shell"><p class="sa-empty">読み込んでいます…</p></div>';
  const head = '<header class="sa-head"><h1>' + escapeHtml(state.appName) + '</h1><div class="sa-user">' + escapeHtml(state.user.email || "") + (state.user.canEdit ? "" : ' <span class="sa-badge">閲覧のみ</span>') + "</div></header>";
  if (state.bootErrors.length > 0) {
    return '<div class="sa-shell">' + head + '<div class="sa-boot-errors" role="alert"><p>設定に直すところがあります。スプレッドシートの「定義」と「設定」を直してから、この画面を読み込み直してください。</p><ul>' + state.bootErrors.map((e) => "<li>" + escapeHtml(e) + "</li>").join("") + "</ul></div></div>";
  }
  const error = state.error ? '<div class="sa-alert" role="alert">' + escapeHtml(state.error) + ' <button type="button" class="sa-chip-x" data-action="dismiss-error" aria-label="閉じる">×</button></div>' : "";
  const notice = state.notice ? '<div class="sa-notice" role="status">' + escapeHtml(state.notice) + "</div>" : "";
  return '<div class="sa-shell">' + head + renderTabs(state.tables, state.current) + renderToolbar(state) + error + notice + '<main class="sa-main">' + renderList(state) + "</main>" + csvBox_(state) + renderDrawer(state) + "</div>";
}
