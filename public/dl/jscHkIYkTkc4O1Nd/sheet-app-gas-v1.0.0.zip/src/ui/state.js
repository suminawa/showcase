/**
 * 画面の状態と、それを変える reduce。純粋（DOM にも google にも触らない）。
 */
export function initialState() {
  return {
    ready: false,
    appName: "",
    tables: [],
    user: { email: "", canEdit: false },
    ai: false,
    pageSize: 50,
    dateFormat: "yyyy-MM-dd",
    today: "",
    bootErrors: [],
    current: "",
    q: "",
    filters: [],
    sort: null,
    page: 1,
    rows: [],
    total: 0,
    refs: {},
    loading: false,
    error: "",
    notice: "",
    filterPanel: false,
    filterColumn: "",
    filterOptions: null,
    aiText: "",
    aiExplanation: "",
    view: null,
    csv: null,
  };
}

export function currentTable(state) {
  for (let i = 0; i < state.tables.length; i += 1) if (state.tables[i].name === state.current) return state.tables[i];
  return null;
}

function assign_(state, patch) {
  return Object.assign({}, state, patch);
}

function withView_(state, patch) {
  if (state.view === null) return state;
  return assign_(state, { view: Object.assign({}, state.view, patch) });
}

export function reduce(state, action) {
  const type = action && action.type;
  if (type === "bootstrap") {
    const data = action.data || {};
    const tables = Array.isArray(data.tables) ? data.tables : [];
    return assign_(state, {
      ready: true,
      appName: data.appName || "業務アプリ",
      tables: tables,
      user: data.user || { email: "", canEdit: false },
      ai: data.ai === true,
      pageSize: data.pageSize || 50,
      dateFormat: data.dateFormat || "yyyy-MM-dd",
      today: data.today || "",
      bootErrors: Array.isArray(data.errors) ? data.errors : [],
      current: tables.length > 0 ? tables[0].name : "",
    });
  }
  if (type === "select-table") {
    if (!state.tables.some((t) => t.name === action.name)) return state;
    return assign_(state, { current: action.name, q: "", filters: [], sort: null, page: 1, rows: [], total: 0, refs: {}, view: null, filterPanel: false, filterColumn: "", filterOptions: null, aiText: "", aiExplanation: "", csv: null, error: "", notice: "" });
  }
  if (type === "set-q") return assign_(state, { q: String(action.q || ""), page: 1 });
  if (type === "add-filter") return assign_(state, { filters: state.filters.concat([action.filter]), page: 1 });
  if (type === "remove-filter") return assign_(state, { filters: state.filters.filter((f, i) => i !== action.index), page: 1 });
  if (type === "set-filters") {
    return assign_(state, {
      q: action.q === undefined ? state.q : String(action.q || ""),
      filters: Array.isArray(action.filters) ? action.filters : [],
      sort: action.sort === undefined ? state.sort : action.sort,
      page: 1,
    });
  }
  if (type === "clear-filters") return assign_(state, { q: "", filters: [], sort: null, page: 1, aiText: "", aiExplanation: "" });
  if (type === "toggle-sort") {
    let sort = { column: action.column, dir: "asc" };
    if (state.sort !== null && state.sort.column === action.column) sort = state.sort.dir === "asc" ? { column: action.column, dir: "desc" } : null;
    return assign_(state, { sort: sort, page: 1 });
  }
  if (type === "set-page") return assign_(state, { page: Math.max(1, Number(action.page) || 1) });
  if (type === "loading") return assign_(state, { loading: action.on === true });
  if (type === "rows") return assign_(state, { rows: action.rows || [], total: action.total || 0, refs: action.refs || {}, page: action.page || state.page, loading: false });
  if (type === "error") return assign_(state, { error: String(action.message || ""), loading: false });
  if (type === "notice") return assign_(state, { notice: String(action.message || "") });
  if (type === "toggle-filter-panel") return assign_(state, { filterPanel: !state.filterPanel });
  if (type === "filter-column") return assign_(state, { filterColumn: String(action.column || ""), filterOptions: Array.isArray(action.options) ? action.options : null });
  if (type === "ai-text") return assign_(state, { aiText: String(action.text || "") });
  if (type === "ai-explanation") return assign_(state, { aiExplanation: String(action.text || "") });
  if (type === "open-detail") return assign_(state, { view: { kind: "detail", id: action.row ? action.row.ID : "", row: action.row, refs: action.refs || {}, summary: "", summaryLoading: false }, error: "", notice: "" });
  if (type === "open-form") {
    return assign_(state, { view: { kind: "form", isNew: action.isNew === true, id: action.id || "", seenUpdatedAt: action.seenUpdatedAt || "", values: action.values || {}, errors: {}, options: action.options || {} }, error: "", notice: "" });
  }
  if (type === "form-errors") return withView_(state, { errors: action.errors || {} });
  if (type === "form-values") return withView_(state, { values: action.values || {} });
  if (type === "summary-loading") return withView_(state, { summaryLoading: action.on === true });
  if (type === "summary") return withView_(state, { summary: String(action.text || ""), summaryLoading: false });
  if (type === "close") return assign_(state, { view: null });
  if (type === "csv") return assign_(state, { csv: action.text === null || action.text === undefined ? null : String(action.text) });
  return state;
}
