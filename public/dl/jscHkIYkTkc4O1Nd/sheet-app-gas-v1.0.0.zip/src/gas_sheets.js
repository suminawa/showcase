/**
 * スプレッドシートの読み書き。見出しは名前で探す（人が列を並べ替えても、右に列を足しても壊れない）。
 */
import { parseSettings } from "./settings.js";
import { DEFINITION_HEADER, SETTINGS_ROWS } from "./samples.js";
import { SYSTEM_COLUMNS, findColumn, headerFor, parseDefinition } from "./definition.js";
import { fromSheetValue, fromSystemValue, safeCell, toSheetValue, trashJson } from "./format.js";
import { formatStamp } from "./dates.js";
import { textOf } from "./text.js";

export const SETTINGS_SHEET = "設定";
export const DEFINITION_SHEET = "定義";
export const TRASH_SHEET = "_ごみ箱";
const TRASH_HEADER = ["元テーブル", "ID", "削除日時", "削除者", "行の内容（JSON）"];
const PERMISSION_MESSAGE = "このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください";

function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

function values_(sheet) {
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getDataRange().getValues();
}

/**
 * シートの共有で、その人が編集者（か所有者）か。閲覧者には false。
 * 判定できないとき（ドメインの制限などで一覧が取れない）は null を返し、呼ぶ側は書くときの権限の例外に任せる。
 */
export function sheetEditable_(email) {
  const me = String(email || "").trim().toLowerCase();
  if (me === "") return null;
  try {
    const book = book_();
    const owner = book.getOwner();
    if (owner && String(owner.getEmail() || "").toLowerCase() === me) return true;
    const editors = book.getEditors().map((u) => String(u.getEmail() || "").toLowerCase());
    return editors.indexOf(me) >= 0;
  } catch (error) {
    return null;
  }
}

export function readSettings_() {
  return parseSettings(values_(book_().getSheetByName(SETTINGS_SHEET)));
}

export function readDefinition_() {
  const sheet = book_().getSheetByName(DEFINITION_SHEET);
  if (!sheet) return { tables: [], errors: ["sheet-app: 「定義」シートがありません。メニュー「業務アプリ」→「初期化」を実行するか、見本を読み込んでください"] };
  return parseDefinition(values_(sheet));
}

/** 1 行目の見出し（前後の空白を落とした文字） */
function headerOf_(sheet) {
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(textOf);
}

function indexOf_(header) {
  const index = {};
  for (let i = 0; i < header.length; i += 1) if (header[i] !== "" && index[header[i]] === undefined) index[header[i]] = i;
  return index;
}

/** 権限の例外を敬体に言い換える。ほかはそのまま */
export function translatePermissionError_(error) {
  const message = String(error && error.message ? error.message : error);
  if (/permission|権限|does not have|not have access/i.test(message)) return new Error(PERMISSION_MESSAGE);
  return error;
}

function guarded_(action) {
  try {
    return action();
  } catch (error) {
    throw translatePermissionError_(error);
  }
}

/** テーブルのシート。無ければ作り、見出しが無ければ書き、足りない見出しは右端に足す */
export function ensureTable_(table) {
  return guarded_(() => {
    const book = book_();
    let sheet = book.getSheetByName(table.name);
    if (!sheet) sheet = book.insertSheet(table.name);
    const wanted = headerFor(table);
    const header = headerOf_(sheet);
    if (header.length === 0) {
      sheet.getRange(1, 1, 1, wanted.length).setValues([wanted]);
      sheet.setFrozenRows(1);
      return sheet;
    }
    const missing = wanted.filter((name) => header.indexOf(name) < 0);
    if (missing.length > 0) {
      const start = header.length + 1;
      if (start + missing.length - 1 > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), start + missing.length - 1 - sheet.getMaxColumns());
      sheet.getRange(1, start, 1, missing.length).setValues([missing]);
    }
    return sheet;
  });
}

function recordFrom_(table, header, index, row) {
  const record = { ID: textOf(row[index.ID]) };
  for (let i = 0; i < table.columns.length; i += 1) {
    const column = table.columns[i];
    const at = index[column.name];
    record[column.name] = fromSheetValue(column, at === undefined ? "" : row[at]);
  }
  for (let i = 1; i < SYSTEM_COLUMNS.length; i += 1) {
    const name = SYSTEM_COLUMNS[i];
    const at = index[name];
    record[name] = at === undefined ? "" : fromSystemValue(row[at]);
  }
  return record;
}

/** テーブルを全部読む。ID の無い行は飛ばす */
export function readTable_(table) {
  const sheet = book_().getSheetByName(table.name);
  const values = values_(sheet);
  const records = [];
  const rowNumbers = {};
  if (values.length < 2) return { records: records, rowNumbers: rowNumbers };
  const header = values[0].map(textOf);
  const index = indexOf_(header);
  if (index.ID === undefined) return { records: records, rowNumbers: rowNumbers };
  for (let r = 1; r < values.length; r += 1) {
    const id = textOf(values[r][index.ID]);
    if (id === "") continue;
    records.push(recordFrom_(table, header, index, values[r]));
    if (rowNumbers[id] === undefined) rowNumbers[id] = r + 1;
  }
  return { records: records, rowNumbers: rowNumbers };
}

function cellFor_(table, name, record) {
  const column = findColumn(table, name);
  if (column !== null) return toSheetValue(column, record[name]);
  if (SYSTEM_COLUMNS.indexOf(name) >= 0) return safeCell(record[name] === undefined || record[name] === null ? "" : record[name]);
  return "";
}

/** 末尾に 1 行足し、行番号を返す */
export function appendRecord_(table, record) {
  return guarded_(() => {
    const sheet = ensureTable_(table);
    const header = headerOf_(sheet);
    const row = header.map((name) => cellFor_(table, name, record));
    sheet.appendRow(row);
    return sheet.getLastRow();
  });
}

/** record にある列だけ書き換える（定義に無い列と、record に無い列は触らない） */
export function updateRecord_(table, rowNumber, record) {
  return guarded_(() => {
    const sheet = ensureTable_(table);
    const header = headerOf_(sheet);
    const range = sheet.getRange(rowNumber, 1, 1, header.length);
    const row = range.getValues()[0];
    // 行ごと書き戻すので、触らない列に数式があれば数式のまま返す（getValues は答えの値しか返さない）
    const formulas = range.getFormulas()[0];
    for (let i = 0; i < header.length; i += 1) {
      const name = header[i];
      const known = findColumn(table, name) !== null || SYSTEM_COLUMNS.indexOf(name) >= 0;
      if (known && Object.prototype.hasOwnProperty.call(record, name)) row[i] = cellFor_(table, name, record);
      else if (textOf(formulas[i]) !== "") row[i] = formulas[i];
      // 触らない文字のセルも、書き戻すときに数値や日付に解釈されないよう ' を付け直す（作成日時や買い手の型番など）
      else if (typeof row[i] === "string") row[i] = safeCell(row[i]);
    }
    range.setValues([row]);
  });
}

function trashSheet_() {
  const book = book_();
  let sheet = book.getSheetByName(TRASH_SHEET);
  if (!sheet) sheet = book.insertSheet(TRASH_SHEET);
  if (sheet.getLastRow() === 0) sheet.getRange(1, 1, 1, TRASH_HEADER.length).setValues([TRASH_HEADER]);
  return sheet;
}

/** _ごみ箱 に写してから行を消す */
export function deleteRecord_(table, rowNumber, id, record, actor, stamp) {
  return guarded_(() => {
    trashSheet_().appendRow([safeCell(table.name), safeCell(id), safeCell(stamp), safeCell(actor), safeCell(trashJson(record))]);
    book_().getSheetByName(table.name).deleteRow(rowNumber);
  });
}

/** ID 列だけを文字の配列で読む。シートが無い・見出しに ID が無いなら [] */
export function readIds_(table) {
  const sheet = book_().getSheetByName(table.name);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const at = headerOf_(sheet).indexOf("ID");
  if (at < 0) return [];
  const column = sheet.getRange(2, at + 1, sheet.getLastRow() - 1, 1).getValues();
  const ids = [];
  for (let i = 0; i < column.length; i += 1) {
    const id = textOf(column[i][0]);
    if (id !== "") ids.push(id);
  }
  return ids;
}

/**
 * ID の無い行に番号を振る（作成日時・更新日時が空なら今を入れる）。振った数を返す。
 * 行ごとに書くと 1 行 3 回の書き込みになるので、列ごとに 1 回だけ書く（行が多いほど効く）。
 */
export function assignMissingIds_(table, idFor) {
  return guarded_(() => {
    const sheet = ensureTable_(table);
    const values = values_(sheet);
    if (values.length < 2) return 0;
    const header = values[0].map(textOf);
    const index = indexOf_(header);
    if (index.ID === undefined) return 0;
    const stamp = formatStamp(new Date());
    const changes = {};
    const change = (at, r, text) => {
      if (at === undefined) return;
      if (changes[at] === undefined) changes[at] = [];
      changes[at].push([r, text]);
    };
    let count = 0;
    for (let r = 1; r < values.length; r += 1) {
      const row = values[r];
      const blank = row.every((cell) => textOf(cell) === "");
      if (blank || textOf(row[index.ID]) !== "") continue;
      change(index.ID, r, idFor(table));
      if (index["作成日時"] !== undefined && textOf(row[index["作成日時"]]) === "") change(index["作成日時"], r, stamp);
      if (index["更新日時"] !== undefined && textOf(row[index["更新日時"]]) === "") change(index["更新日時"], r, stamp);
      count += 1;
    }
    if (count === 0) return 0;
    const names = Object.keys(changes);
    for (let i = 0; i < names.length; i += 1) {
      const at = Number(names[i]);
      const range = sheet.getRange(2, at + 1, values.length - 1, 1);
      const formulas = range.getFormulas();
      // 読んだ値をそのまま書き戻すと、文字が数や日付に化け、数式が答えの値に潰れる
      const column = range.getValues().map((cell, r) => {
        if (textOf(formulas[r][0]) !== "") return [formulas[r][0]];
        return [typeof cell[0] === "string" ? safeCell(cell[0]) : cell[0]];
      });
      const list = changes[names[i]];
      for (let j = 0; j < list.length; j += 1) column[list[j][0] - 1][0] = safeCell(list[j][1]);
      range.setValues(column);
    }
    return count;
  });
}

/** 設定シート。無ければ見本の行で作る。作ったら true */
export function ensureSettingsSheet_() {
  return guarded_(() => {
    const book = book_();
    if (book.getSheetByName(SETTINGS_SHEET)) return false;
    const sheet = book.insertSheet(SETTINGS_SHEET);
    sheet.getRange(1, 1, SETTINGS_ROWS.length, 2).setValues(SETTINGS_ROWS.map((row) => [row[0], row[1]]));
    return true;
  });
}

/** 定義シート。無ければ見出しだけで作る。作ったら true */
export function ensureDefinitionSheet_() {
  return guarded_(() => {
    const book = book_();
    if (book.getSheetByName(DEFINITION_SHEET)) return false;
    const sheet = book.insertSheet(DEFINITION_SHEET);
    sheet.getRange(1, 1, 1, DEFINITION_HEADER.length).setValues([DEFINITION_HEADER]);
    sheet.setFrozenRows(1);
    return true;
  });
}

/** 見本のテンプレを流し込む。定義に見出し以外の行があれば断る。テーブルのシートは無いか空のときだけ書く */
export function loadTemplate_(template) {
  return guarded_(() => {
    const book = book_();
    ensureDefinitionSheet_();
    const definitionSheet = book.getSheetByName(DEFINITION_SHEET);
    if (definitionSheet.getLastRow() > 1) throw new Error("定義がすでにあるので見本は読み込みません。新しいスプレッドシートでお試しください");
    const rows = template.definition.slice(1);
    definitionSheet.getRange(2, 1, rows.length, DEFINITION_HEADER.length).setValues(rows.map((row) => row.slice(0, DEFINITION_HEADER.length)));
    const parsed = parseDefinition(template.definition);
    const counts = {};
    for (let t = 0; t < parsed.tables.length; t += 1) {
      const table = parsed.tables[t];
      const existing = book.getSheetByName(table.name);
      if (existing && existing.getLastRow() > 1) {
        counts[table.name] = 0;
        continue;
      }
      const sheet = ensureTable_(table);
      const header = headerOf_(sheet);
      const records = template.tables[table.name] || [];
      if (records.length > 0) {
        const values = records.map((record) => header.map((name) => cellFor_(table, name, record)));
        sheet.getRange(2, 1, values.length, header.length).setValues(values);
      }
      counts[table.name] = records.length;
    }
    return { definitionRows: rows.length, tables: counts };
  });
}
