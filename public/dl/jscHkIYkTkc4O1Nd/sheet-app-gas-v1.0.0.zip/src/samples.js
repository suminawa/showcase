/**
 * 見本のテンプレ 3 種（顧客管理・案件管理・在庫管理）。メニュー「見本を読み込む」と、見本ページ（api-memory）が使う。
 * 社名・人名は架空。同じ入力から同じ出力になる（乱数を使わない）。
 */
import { formatId } from "./ids.js";
import { headerFor } from "./definition.js";
import { csvCell } from "./csv.js";
import { pad2 } from "./text.js";

export const TEMPLATE_NAMES = ["顧客管理", "案件管理", "在庫管理"];
export const DEFINITION_HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
export const SETTINGS_ROWS = [
  ["項目", "値"],
  ["アプリ名", "業務アプリ"],
  ["編集できる人", ""],
  ["1 ページの件数", "50"],
  ["日付の書式", "yyyy-MM-dd"],
  ["AI を使う", "TRUE"],
  ["モデル", "claude-sonnet-5"],
  ["AI の 1 日の上限", "200"],
];

const COMPANIES = ["うみかぜ商店", "みなと工務店", "さくら不動産", "ひだまり整体院", "あおば設計", "つばさ運送", "こもれび保育園", "なぎさ食堂", "かえで税理士事務所", "ふもと農園", "しおさい旅館", "ひかり電機", "まつかぜ薬局", "いぶき製作所", "そよかぜ美容室", "たかね建設", "わかば学習塾", "みどり造園", "はまべ水産", "ゆうひ写真館"];
const PEOPLE = ["山川", "田中", "佐藤", "鈴木", "高橋", "伊藤", "渡辺", "中村", "小林", "加藤"];
const TOWNS = ["横浜市中区", "横浜市西区", "川崎市中原区", "藤沢市", "鎌倉市", "横須賀市", "茅ヶ崎市", "平塚市"];
const INDUSTRIES = ["建設", "不動産", "飲食", "小売", "士業", "医療", "製造", "その他"];
// 会社名（COMPANIES）に対応する業種。並びは COMPANIES と揃えてある。選択肢そのものは INDUSTRIES を使う
const CUSTOMER_INDUSTRIES = ["小売", "建設", "不動産", "医療", "建設", "その他", "その他", "飲食", "士業", "その他", "その他", "製造", "医療", "製造", "その他", "建設", "その他", "建設", "製造", "その他"];
const STATUSES = ["見込み", "取引中", "休眠"];
const CONTACT_KINDS = ["電話", "訪問", "メール", "打ち合わせ", "その他"];
const STAGES = ["相談", "見積もり", "受注", "進行中", "完了", "失注"];
const CONFIDENCE = ["高", "中", "低"];
const PROGRESS_KINDS = ["打ち合わせ", "作業", "納品", "請求", "その他"];
const CATEGORIES = ["部材", "工具", "消耗品", "完成品"];
const MOVE_KINDS = ["入庫", "出庫", "棚卸"];
const BASE_STAMP = Date.UTC(2026, 8, 1, 1, 0, 0); // 2026-09-01 10:00:00 JST
const UPDATER = "sample@example.com";

/** 2026-06-01 から days 日後の "yyyy-MM-dd" */
function dateAfter_(days) {
  const d = new Date(Date.UTC(2026, 5, 1) + days * 86400000);
  return d.getUTCFullYear() + "-" + pad2(d.getUTCMonth() + 1) + "-" + pad2(d.getUTCDate());
}
/** 作成日時・更新日時: 2026-09-01 10:00:00 から n 分後 */
function stamp_(minutes) {
  const d = new Date(BASE_STAMP + minutes * 60000);
  return d.getUTCFullYear() + "-" + pad2(d.getUTCMonth() + 1) + "-" + pad2(d.getUTCDate()) + " " + pad2(d.getUTCHours() + 9) + ":" + pad2(d.getUTCMinutes()) + ":00";
}
/** テーブルごとに ID を振る。日付キーは 2026-09-01 固定 */
function ids_(count) { const out = []; for (let i = 1; i <= count; i += 1) out.push(formatId("2026-09-01", i)); return out; }
function pick_(list, i) { return list[i % list.length]; }
/** 入出庫の備考を区分に合わせて書く */
function movementNote_(kind, i) {
  if (kind === "入庫") return "仕入れの入庫です。";
  if (kind === "出庫") return pick_(COMPANIES, i) + "の現場向けです。";
  return "月次の棚卸しです。";
}
function system_(id, n) { return { ID: id, 作成日時: stamp_(n), 更新日時: stamp_(n), 更新者: UPDATER }; }

function def_(table, column, type, required, options, inList, searchable, defaultValue, note) {
  return [table, column, type, required ? "TRUE" : "", options || "", inList === false ? "FALSE" : "", searchable === undefined ? "" : searchable ? "TRUE" : "FALSE", defaultValue || "", note || ""];
}

const JOB_KINDS = ["新規導入", "改修", "定期保守", "移転", "点検", "増設", "更新", "調査"];
const PRODUCTS = ["ヒノキ角材 30×40", "ステンレスねじ M6", "養生テープ", "電動ドリル", "塗料（白）", "塗料（グレー）", "合板 12mm", "コンクリート釘", "電動ノコギリ", "脚立 3段", "メジャー 5.5m", "作業灯（LED）", "ブルーシート 3.6m", "結束バンド 200mm", "サンドペーパー #240", "木工用接着剤", "軍手（Lサイズ）", "安全帯", "棚板ユニット", "収納箱"];
// 商品名（PRODUCTS）に対応する分類。並びは PRODUCTS と揃えてある。選択肢そのものは CATEGORIES を使う
const PRODUCT_CATEGORIES = ["部材", "部材", "消耗品", "工具", "消耗品", "消耗品", "部材", "部材", "工具", "工具", "工具", "工具", "消耗品", "消耗品", "消耗品", "消耗品", "消耗品", "工具", "完成品", "完成品"];
const LOCATIONS = ["棚 A-1", "棚 A-2", "棚 B-1", "棚 B-2", "棚 C-1", "倉庫 2"];
// 商品の仕入先。COMPANIES（顧客）とは別の、ここでしか使わない架空の仕入れ先
const SUPPLIERS = ["きたはま建材", "とうわ金物", "みなみ工具", "ひので塗料", "あさひ資材"];

function customers_() {
  const definition = [
    DEFINITION_HEADER,
    def_("顧客", "会社名", "文字", true, "", true, undefined, "", "法人名。個人は氏名"),
    def_("顧客", "担当者", "文字", false, "", true, undefined, "", "先方のご担当者の姓"),
    def_("顧客", "業種", "選択", false, INDUSTRIES.join(", "), true, undefined, "その他", ""),
    def_("顧客", "状況", "選択", false, STATUSES.join(", "), true, undefined, "見込み", ""),
    def_("顧客", "メール", "メール", false, "", false, undefined, "", ""),
    def_("顧客", "電話", "電話", false, "", true, undefined, "", ""),
    def_("顧客", "住所", "文字", false, "", false, undefined, "", ""),
    def_("顧客", "最終連絡日", "日付", false, "", true, undefined, "今日", ""),
    def_("顧客", "年間取引額", "金額", false, "", true, undefined, "", "円。見込みは空のまま"),
    def_("顧客", "要注意", "チェック", false, "", true, undefined, "", "支払いの遅れなど"),
    def_("顧客", "メモ", "長文", false, "", false, undefined, "", ""),
    def_("対応履歴", "顧客", "参照:顧客", true, "", true, undefined, "", ""),
    def_("対応履歴", "日付", "日付", true, "", true, undefined, "今日", ""),
    def_("対応履歴", "種別", "選択", true, CONTACT_KINDS.join(", "), true, undefined, "電話", ""),
    def_("対応履歴", "担当", "文字", false, "", true, undefined, "", "こちらの担当"),
    def_("対応履歴", "内容", "長文", true, "", true, undefined, "", ""),
    def_("対応履歴", "次回対応日", "日付", false, "", true, undefined, "", ""),
  ];
  const customerIds = ids_(20);
  const customers = COMPANIES.map((company, i) => Object.assign(system_(customerIds[i], i), {
    会社名: company,
    担当者: pick_(PEOPLE, i),
    業種: CUSTOMER_INDUSTRIES[i],
    状況: pick_(STATUSES, i),
    メール: "info" + (i + 1) + "@example.com",
    電話: "045-000-00" + pad2(i + 1),
    住所: pick_(TOWNS, i) + " " + (i + 1) + "-2-3",
    最終連絡日: dateAfter_(i * 5),
    年間取引額: pick_(STATUSES, i) === "見込み" ? null : (i + 1) * 120000,
    要注意: i % 7 === 3,
    メモ: i % 4 === 0 ? "紹介で知り合いました。年度末に予算の相談があります。" : "",
  }));
  const historyIds = ids_(30);
  const histories = historyIds.map((id, i) => Object.assign(system_(id, 20 + i), {
    顧客: customerIds[i % 20],
    日付: dateAfter_(30 + i * 3),
    種別: pick_(CONTACT_KINDS, i),
    担当: pick_(PEOPLE, i + 3),
    内容: pick_(["見積もりの内容についてご説明しました。", "納期のご相談を受け、社内で確認してからご連絡することにしました。", "請求書をお送りしました。", "新しいご担当者にごあいさつしました。", "保守契約の更新についてご案内しました。"], i),
    次回対応日: dateAfter_(60 + (i % 40)),
  }));
  return { definition: definition, tables: { 顧客: customers, 対応履歴: histories } };
}

function projects_() {
  const definition = [
    DEFINITION_HEADER,
    def_("案件", "案件名", "文字", true, "", true, undefined, "", "案件・工事の名前"),
    def_("案件", "顧客名", "文字", false, "", true, undefined, "", "先方の会社名"),
    def_("案件", "段階", "選択", false, STAGES.join(", "), true, undefined, "相談", ""),
    def_("案件", "金額", "金額", false, "", true, undefined, "", "円。相談中は空のまま"),
    def_("案件", "開始日", "日付", false, "", true, undefined, "", ""),
    def_("案件", "納期", "日付", false, "", true, undefined, "", ""),
    def_("案件", "担当", "文字", false, "", true, undefined, "", "社内の担当"),
    def_("案件", "確度", "選択", false, CONFIDENCE.join(", "), true, undefined, "", ""),
    def_("案件", "メモ", "長文", false, "", false, undefined, "", ""),
    def_("進捗", "案件", "参照:案件", true, "", true, undefined, "", ""),
    def_("進捗", "日付", "日付", true, "", true, undefined, "今日", ""),
    def_("進捗", "種別", "選択", false, PROGRESS_KINDS.join(", "), true, undefined, "", ""),
    def_("進捗", "内容", "長文", true, "", true, undefined, "", ""),
    def_("進捗", "担当", "文字", false, "", true, undefined, "", ""),
  ];
  const projectIds = ids_(15);
  const projects = projectIds.map((id, i) => Object.assign(system_(id, i), {
    案件名: pick_(COMPANIES, i) + "様 " + pick_(JOB_KINDS, i),
    顧客名: pick_(COMPANIES, i),
    段階: pick_(STAGES, i),
    金額: pick_(STAGES, i) === "相談" ? null : (i + 1) * 250000,
    開始日: dateAfter_(i * 6),
    納期: dateAfter_(i * 6 + 30),
    担当: pick_(PEOPLE, i + 1),
    確度: pick_(CONFIDENCE, i),
    メモ: i % 4 === 1 ? "先方のご希望を伺いながら進めています。" : "",
  }));
  const progressIds = ids_(25);
  const progresses = progressIds.map((id, i) => Object.assign(system_(id, 15 + i), {
    案件: projectIds[i % 15],
    日付: dateAfter_(20 + i * 3),
    種別: pick_(PROGRESS_KINDS, i),
    内容: pick_(["お打ち合わせを行い、ご要望を伺いました。", "現地で作業を行いました。", "納品を完了しました。", "請求書をお送りしました。", "進捗をご確認いただきました。"], i),
    担当: pick_(PEOPLE, i + 4),
  }));
  return { definition: definition, tables: { 案件: projects, 進捗: progresses } };
}

function inventory_() {
  const definition = [
    DEFINITION_HEADER,
    def_("商品", "商品名", "文字", true, "", true, undefined, "", ""),
    def_("商品", "型番", "文字", false, "", true, undefined, "", ""),
    def_("商品", "分類", "選択", false, CATEGORIES.join(", "), true, undefined, "", ""),
    def_("商品", "単価", "金額", false, "", true, undefined, "", "円"),
    def_("商品", "在庫数", "数値", false, "", true, undefined, "", ""),
    def_("商品", "発注点", "数値", false, "", true, undefined, "", "これを下回ったら発注"),
    def_("商品", "仕入先", "文字", false, "", true, undefined, "", ""),
    def_("商品", "保管場所", "文字", false, "", true, undefined, "", ""),
    def_("商品", "販売中", "チェック", false, "", true, undefined, "TRUE", ""),
    def_("商品", "商品ページ", "URL", false, "", false, undefined, "", ""),
    def_("商品", "メモ", "長文", false, "", false, undefined, "", ""),
    def_("入出庫", "商品", "参照:商品", true, "", true, undefined, "", ""),
    def_("入出庫", "日付", "日付", true, "", true, undefined, "今日", ""),
    def_("入出庫", "区分", "選択", false, MOVE_KINDS.join(", "), true, undefined, "入庫", ""),
    def_("入出庫", "数量", "数値", true, "", true, undefined, "", ""),
    def_("入出庫", "担当", "文字", false, "", true, undefined, "", ""),
    def_("入出庫", "備考", "文字", false, "", true, undefined, "", ""),
  ];
  const productIds = ids_(20);
  const products = productIds.map((id, i) => Object.assign(system_(id, i), {
    商品名: PRODUCTS[i],
    型番: "NO-" + String(i + 1).padStart(4, "0"),
    分類: PRODUCT_CATEGORIES[i],
    単価: (i + 1) * 350,
    在庫数: ((i * 7) % 40) + 5,
    発注点: 5 + (i % 5) * 5,
    仕入先: pick_(SUPPLIERS, i),
    保管場所: pick_(LOCATIONS, i),
    販売中: i % 9 !== 8,
    商品ページ: "https://example.com/items/" + (i + 1),
    メモ: i % 5 === 0 ? "人気の商品です。切らさないようにご注意ください。" : "",
  }));
  const movementIds = ids_(40);
  const movements = movementIds.map((id, i) => {
    const kind = pick_(MOVE_KINDS, i);
    return Object.assign(system_(id, 20 + i), {
      商品: productIds[i % 20],
      日付: dateAfter_(i * 2),
      区分: kind,
      数量: ((i % 12) + 1) * 5,
      担当: pick_(PEOPLE, i + 2),
      備考: movementNote_(kind, i),
    });
  });
  return { definition: definition, tables: { 商品: products, 入出庫: movements } };
}

export const TEMPLATES = { 顧客管理: customers_(), 案件管理: projects_(), 在庫管理: inventory_() };

function csvOf_(header, rows) {
  return "﻿" + [header].concat(rows).map((row) => row.map(csvCell).join(",")).join("\r\n") + "\r\n";
}

function csvValue_(value) {
  if (value === null || value === undefined) return "";
  if (value === true) return "TRUE";
  if (value === false) return "FALSE";
  if (Array.isArray(value)) return value.join(", ");
  return value;
}

/** samples/<name>/ に置く CSV の中身。定義.csv とテーブルごとの CSV */
export function templateCsvFiles(name) {
  const template = TEMPLATES[name];
  const files = { "定義.csv": csvOf_(template.definition[0], template.definition.slice(1)) };
  const tables = {};
  for (let i = 1; i < template.definition.length; i += 1) {
    const row = template.definition[i];
    if (!tables[row[0]]) tables[row[0]] = { name: row[0], columns: [] };
    tables[row[0]].columns.push({ name: row[1], type: row[2] });
  }
  Object.keys(tables).forEach((tableName) => {
    const header = headerFor(tables[tableName]);
    const rows = template.tables[tableName].map((record) => header.map((h) => csvValue_(record[h])));
    files[tableName + ".csv"] = csvOf_(header, rows);
  });
  return files;
}

export function settingsCsv() {
  return csvOf_(SETTINGS_ROWS[0], SETTINGS_ROWS.slice(1));
}
