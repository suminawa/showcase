#!/usr/bin/env node
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { TEMPLATE_NAMES, templateCsvFiles, settingsCsv } from "../src/samples.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
mkdirSync(join(root, "samples"), { recursive: true });
writeFileSync(join(root, "samples", "設定.csv"), settingsCsv());
for (const name of TEMPLATE_NAMES) {
  const dir = join(root, "samples", name);
  mkdirSync(dir, { recursive: true });
  const files = templateCsvFiles(name);
  for (const file of Object.keys(files)) writeFileSync(join(dir, file), files[file]);
}
console.log("wrote samples/");
