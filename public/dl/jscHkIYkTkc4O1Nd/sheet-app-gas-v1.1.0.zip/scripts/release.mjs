#!/usr/bin/env node
// 配布 zip を release/ に作る。買い手が貼るのは dist/ の 3 ファイル。src / test / scripts / demo も入れる。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/sheet-app-gas-v${pkg.version}.zip`;

for (const required of ["dist/Code.gs", "dist/App.html", "dist/appsscript.json", "demo/app.js", "demo/app.css", "demo/index.html", "README.ja.md", "LICENSE.md", "CHANGELOG.md"]) {
  if (!existsSync(required)) {
    console.error(required + " がありません。先に npm run build を実行してください");
    process.exit(1);
  }
}
mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

execFileSync(
  "zip",
  ["-r", out, "dist", "samples", "demo", "src", "test", "scripts", "README.ja.md", "LICENSE.md", "CHANGELOG.md", "package.json", "-x", "*.DS_Store"],
  { stdio: "inherit" },
);
console.log(`${out} を作りました`);
