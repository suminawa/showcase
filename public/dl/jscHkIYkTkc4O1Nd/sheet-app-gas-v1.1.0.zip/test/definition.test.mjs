import { test } from "node:test";
import assert from "node:assert/strict";
import { TYPES, SYSTEM_COLUMNS, parseDefinition, headerFor, displayColumn, splitList, isReservedSheet, findTable, findColumn } from "../src/definition.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];

const GOOD = [
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", "法人名。個人は氏名"],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "TRUE", "", "見込み", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "FALSE", "", "", ""],
  ["", "", "", "", "", "", "", "", ""],
  ["対応履歴", "顧客", "参照:顧客", "TRUE", "", "", "", "", ""],
  ["対応履歴", "日付", "日付", "TRUE", "", "", "", "今日", ""],
  ["対応履歴", "内容", "長文", "TRUE", "", "", "", "", ""],
];

test("定義の行からテーブルと列を組む（空行は飛ばす。既定は 一覧 TRUE、検索は文字系だけ TRUE）", () => {
  const { tables, errors } = parseDefinition(GOOD);
  assert.deepEqual(errors, []);
  assert.equal(tables.length, 2);
  const customers = tables[0];
  assert.equal(customers.name, "顧客");
  assert.deepEqual(customers.columns.map((c) => c.name), ["会社名", "状況", "年間取引額", "メモ"]);
  const company = customers.columns[0];
  assert.equal(company.type, "文字");
  assert.equal(company.required, true);
  assert.equal(company.inList, true);
  assert.equal(company.searchable, true);
  assert.equal(company.note, "法人名。個人は氏名");
  assert.equal(company.refTable, null);
  const status = customers.columns[1];
  assert.deepEqual(status.options, ["見込み", "取引中", "休眠"]);
  assert.equal(status.searchable, false);
  assert.equal(status.defaultValue, "見込み");
  assert.equal(customers.columns[3].inList, false);
  assert.equal(customers.columns[3].searchable, true);
  const history = tables[1];
  assert.equal(history.columns[0].type, "参照");
  assert.equal(history.columns[0].refTable, "顧客");
  assert.equal(history.columns[1].defaultValue, "今日");
});

test("表示名の列は最初の 文字 型。無ければ ID。見出しは ID・定義の列・システム列の順", () => {
  const { tables } = parseDefinition(GOOD);
  assert.equal(displayColumn(tables[0]), "会社名");
  assert.equal(tables[0].display, "会社名");
  assert.equal(displayColumn(tables[1]), "ID");
  assert.deepEqual(headerFor(tables[0]), ["ID", "会社名", "状況", "年間取引額", "メモ", "作成日時", "更新日時", "更新者"]);
  assert.deepEqual(SYSTEM_COLUMNS, ["ID", "作成日時", "更新日時", "更新者"]);
  assert.deepEqual(TYPES, ["文字", "長文", "数値", "金額", "日付", "日時", "選択", "複数選択", "チェック", "メール", "電話", "URL"]);
});

test("誤りは敬体の文で集める（型・重複・参照先・選択肢・予約名・システム列）", () => {
  const rows = [
    HEADER,
    ["顧客", "番号", "整数", "", "", "", "", "", ""],
    ["顧客", "会社名", "文字", "", "", "", "", "", ""],
    ["顧客", "会社名", "文字", "", "", "", "", "", ""],
    ["顧客", "ランク", "選択", "", "", "", "", "", ""],
    ["顧客", "ID", "文字", "", "", "", "", "", ""],
    ["設定", "何か", "文字", "", "", "", "", "", ""],
    ["_内部", "何か", "文字", "", "", "", "", "", ""],
    ["対応", "顧客", "参照:取引先", "", "", "", "", "", ""],
    ["", "列だけ", "文字", "", "", "", "", "", ""],
    ["顧客", "", "文字", "", "", "", "", "", ""],
  ];
  const { tables, errors } = parseDefinition(rows);
  assert.equal(errors.length, 9);
  assert.ok(errors[0].startsWith("sheet-app: 定義の 2 行目: 型「整数」は使えません。文字・長文・"));
  assert.ok(errors[1].includes("4 行目") && errors[1].includes("列「会社名」が 2 回"));
  assert.ok(errors[2].includes("5 行目") && errors[2].includes("選択肢"));
  assert.ok(errors[3].includes("6 行目") && errors[3].includes("「ID」"));
  assert.ok(errors[4].includes("7 行目") && errors[4].includes("「設定」"));
  assert.ok(errors[5].includes("8 行目") && errors[5].includes("「_内部」"));
  assert.ok(errors[6].includes("10 行目") && errors[6].includes("テーブル名が空"));
  assert.ok(errors[7].includes("11 行目") && errors[7].includes("列名が空"));
  assert.ok(errors[8].includes("「対応」") && errors[8].includes("参照先「取引先」"));
  // 誤りの行は落とし、通った列だけ残る
  assert.deepEqual(findTable(tables, "顧客").columns.map((c) => c.name), ["会社名"]);
  assert.equal(findColumn(findTable(tables, "顧客"), "会社名").type, "文字");
  assert.equal(findColumn(findTable(tables, "顧客"), "無い"), null);
  assert.equal(findTable(tables, "無い"), null);
});

test("見出しが無い・空のシートは 1 つの誤りで止まる", () => {
  assert.equal(parseDefinition([]).errors.length, 1);
  assert.ok(parseDefinition([]).errors[0].includes("「定義」シートが空"));
  const noType = parseDefinition([["テーブル", "列"], ["顧客", "会社名"]]);
  assert.equal(noType.errors.length, 1);
  assert.ok(noType.errors[0].includes("「型」の見出し"));
  const onlyHeader = parseDefinition([HEADER]);
  assert.equal(onlyHeader.errors.length, 1);
  assert.ok(onlyHeader.errors[0].includes("テーブルがありません"));
});

test("TRUE / FALSE のほか、はい・いいえ・1・0・○・× も読む。全角のコロンの参照も読む", () => {
  const { tables, errors } = parseDefinition([
    HEADER,
    ["A", "a", "文字", "はい", "", "いいえ", "○", "", ""],
    ["A", "b", "数値", "1", "", "0", "×", "", ""],
    ["B", "a", "参照： A", "", "", "", "", "", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(tables[0].columns[0].required, true);
  assert.equal(tables[0].columns[0].inList, false);
  assert.equal(tables[0].columns[0].searchable, true);
  assert.equal(tables[0].columns[1].required, true);
  assert.equal(tables[0].columns[1].inList, false);
  assert.equal(tables[0].columns[1].searchable, false);
  assert.equal(tables[1].columns[0].refTable, "A");
});

test("splitList はカンマと読点で分け、空を落とす。isReservedSheet", () => {
  assert.deepEqual(splitList(" a, b、c ,,"), ["a", "b", "c"]);
  assert.deepEqual(splitList(""), []);
  assert.equal(isReservedSheet("設定"), true);
  assert.equal(isReservedSheet("定義"), true);
  assert.equal(isReservedSheet("_ごみ箱"), true);
  assert.equal(isReservedSheet("顧客"), false);
});
