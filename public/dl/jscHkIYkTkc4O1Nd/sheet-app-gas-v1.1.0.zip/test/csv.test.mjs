import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { toCsv, csvCell } from "../src/csv.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "", "", "", "", "", ""],
  ["顧客", "分野", "複数選択", "", "設計, 施工", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "", "", "", ""],
]);

test("csvCell: カンマ・引用符・改行を含む値だけ引用符で囲む", () => {
  assert.equal(csvCell("普通"), "普通");
  assert.equal(csvCell("a,b"), '"a,b"');
  assert.equal(csvCell('say "hi"'), '"say ""hi"""');
  assert.equal(csvCell("1\n2"), '"1\n2"');
  assert.equal(csvCell(null), "");
});

test("toCsv: BOM + 見出し（ID・列・システム列）+ 行。金額は数のまま、チェックは TRUE/FALSE、複数選択はカンマ区切り", () => {
  const csv = toCsv(tables[0], [
    { ID: "20260901-001", 会社名: "みなと工務店", 分野: ["設計", "施工"], 年間取引額: 1200000, 要注意: true, メモ: "1 行目\n2 行目", 作成日時: "2026-09-01 10:00:00", 更新日時: "2026-09-10 10:00:00", 更新者: "taro@example.com" },
    { ID: "20260901-002", 会社名: "うみかぜ商店", 分野: [], 年間取引額: null, 要注意: false, メモ: "", 作成日時: "", 更新日時: "", 更新者: "" },
  ]);
  const lines = csv.split("\r\n");
  assert.equal(lines[0], "﻿ID,会社名,分野,年間取引額,要注意,メモ,作成日時,更新日時,更新者");
  assert.equal(lines[1], '20260901-001,みなと工務店,"設計, 施工",1200000,TRUE,"1 行目\n2 行目",2026-09-01 10:00:00,2026-09-10 10:00:00,taro@example.com');
  assert.equal(lines[2], "20260901-002,うみかぜ商店,,,FALSE,,,,");
  // 先頭が = の文字は ' を前置して、Excel で数式にならないようにする（数値はそのまま）
  const guarded = toCsv(tables[0], [{ ID: "20260901-003", 会社名: "=HYPERLINK(\"x\")", 分野: [], 年間取引額: -5, 要注意: false, メモ: "+1", 作成日時: "", 更新日時: "", 更新者: "" }]);
  assert.ok(guarded.split("\r\n")[1].startsWith("20260901-003,\"'=HYPERLINK(\"\"x\"\")\",,-5,FALSE,'+1"));
  assert.equal(lines.length, 4);
  assert.equal(lines[3], "");
});
