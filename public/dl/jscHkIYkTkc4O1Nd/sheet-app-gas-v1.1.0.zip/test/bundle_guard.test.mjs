import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle } from "./fakes.mjs";

// 最終レビューの指摘の直し: webhook 用のデプロイで画面の API を断る・二重送信・下書きの前置き・ブロック中の友だち
const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const SLACK = "https://hooks.slack.com/services/T000/B000/XXXX";
const PUSH = "https://api.line.me/v2/bot/message/push";
const DEFINITION = [
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "LINE", "LINE", "", "", "FALSE", "", "", ""],
  ["案件", "案件名", "文字", "", "", "", "", "", ""],
];
const FRIENDS = [["ユーザー ID", "表示名", "追加日時", "状態"], [A, "はるか", "2026-09-10 09:00:00", "友だち"], [B, "けんた", "2026-09-11 09:00:00", "ブロック"]];
const CUSTOMERS = [["ID", "会社名", "状況", "LINE", "作成日時", "更新日時", "更新者"], ["20260916-001", "みなと工務店", "見込み", A, "2026-09-16 10:00:00", "2026-09-16 10:00:00", "taro@example.com"], ["20260916-002", "さくら不動産", "見込み", B, "2026-09-16 10:00:00", "2026-09-16 10:00:00", "taro@example.com"]];
const NOT_SIGNED_IN = /この URL からは業務アプリを使えません。画面用のデプロイの URL を、Google アカウントにログインしたブラウザで開いてください/;

function settingsWith(extra) {
  return [["項目", "値"], ["通知先", "slack"], ["Slack Webhook URL", SLACK], ["LINE チャネルアクセストークン", "line-token"]].concat(extra || []);
}

function seeded(options, extraSettings) {
  return loadBundle(Object.assign({ sheets: { 設定: settingsWith(extraSettings), 定義: DEFINITION, "_LINE友だち": FRIENDS, 顧客: CUSTOMERS } }, options || {}));
}

function sentTo(run, prefix) {
  return run.trace.fetched.filter((item) => item.url.indexOf(prefix) === 0);
}

function rowsOf(run) {
  return JSON.stringify(Object.keys(run.sheets).map((name) => [name, run.sheets[name].rows]));
}

test("webhook 用のデプロイ: ログインしていない人（利用者が空・実行ユーザーは所有者）の api_* はすべて断り、シートにも外にも触らない", () => {
  const run = seeded({ email: "", effectiveEmail: "owner@example.com", apiKey: "test-key" });
  const before = rowsOf(run);
  assert.throws(() => run.entry.api_bootstrap(), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_list("顧客", {}), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_get("顧客", "20260916-001"), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_export("顧客", {}), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_create("顧客", { 会社名: "いたずら" }), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_update("顧客", "20260916-001", { 会社名: "いたずら" }, "2026-09-16 10:00:00"), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_delete("顧客", "20260916-001"), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-001", "こんにちは"), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_ai_draft("顧客", "20260916-001", "お礼"), NOT_SIGNED_IN);
  assert.throws(() => run.entry.api_ai_filter("顧客", "横浜"), NOT_SIGNED_IN);
  assert.equal(rowsOf(run), before, "シートは変わらない");
  assert.equal(run.trace.fetched.length, 0, "LINE にも Slack にも Claude にも送らない");
  assert.equal(run.props["ai:2026-09-16"], undefined);
});

test("webhook 用のデプロイ: ログインしていても所有者以外（利用者と実行ユーザーが違う）なら断る。同じ人なら通る", () => {
  const other = seeded({ email: "taro@example.com", effectiveEmail: "owner@example.com" });
  assert.throws(() => other.entry.api_list("顧客", {}), NOT_SIGNED_IN);
  assert.throws(() => other.entry.api_create("顧客", { 会社名: "x" }), NOT_SIGNED_IN);
  assert.throws(() => other.entry.api_line_send("顧客", "20260916-001", "こんにちは"), NOT_SIGNED_IN);
  assert.equal(sentTo(other, PUSH).length, 0);
  // 画面用のデプロイ（アクセスしているユーザーとして実行）は、利用者と実行ユーザーが同じ
  const screen = seeded({ email: "taro@example.com", effectiveEmail: "taro@example.com" });
  assert.equal(screen.entry.api_list("顧客", {}).total, 2);
  assert.equal(screen.entry.api_create("顧客", { 会社名: "みなと商店" }).id, "20260916-003");
  // 所有者ご本人（大文字小文字の違いは同じ人）
  assert.equal(seeded({ email: "Owner@Example.com", effectiveEmail: "owner@example.com" }).entry.api_list("顧客", {}).total, 2);
  // どちらも空（利用者が分からない）も断る
  assert.throws(() => seeded({ email: "", effectiveEmail: "" }).entry.api_list("顧客", {}), NOT_SIGNED_IN);
});

test("api_line_send: 送れたあとに履歴へ書けなくても（ロックが取れない）誤りにせず、送れたことと注意を返す", () => {
  const run = seeded();
  // push のあと、履歴を書くときだけロックが取れない
  let busy = false;
  let armed = true;
  run.sandbox.LockService.getScriptLock = () => ({
    waitLock: () => {
      if (busy) throw new Error("Could not acquire lock");
    },
    releaseLock: () => {},
  });
  run.sandbox.UrlFetchApp.fetch = ((original) => (url, fetchOptions) => {
    const response = original(url, fetchOptions);
    if (armed && String(url) === PUSH) busy = true;
    return response;
  })(run.sandbox.UrlFetchApp.fetch);
  const result = run.entry.api_line_send("顧客", "20260916-001", "こんにちは");
  assert.equal(sentTo(run, PUSH).length, 1);
  assert.equal(result.note, "送りました（履歴には書けませんでした）。もう一度送ると 2 通届くので、送り直さないでください");
  assert.deepEqual(result.history, []);
  assert.equal(result.monthCount, 0);
  assert.equal(run.sheets["_LINE送信履歴"], undefined);
  assert.ok(run.trace.logs.some((line) => line.includes("_LINE送信履歴 に書けませんでした") && line.includes("20260916-001")));
  // ふだんは note を付けない
  busy = false;
  armed = false;
  assert.equal(run.entry.api_line_send("顧客", "20260916-001", "こんにちは").note, undefined);
});

test("api_line_send: 履歴のシートに書けない（書き込みの誤り）ときも、送れたことと注意を返す", () => {
  const run = seeded();
  run.sandbox.SpreadsheetApp.getActiveSpreadsheet().insertSheet = () => {
    throw new Error("Service Spreadsheets failed");
  };
  const result = run.entry.api_line_send("顧客", "20260916-001", "こんにちは");
  assert.equal(sentTo(run, PUSH).length, 1);
  assert.ok(result.note.startsWith("送りました（履歴には書けませんでした）"));
});

test("api_ai_draft: LINE の列が無いテーブル・トークンが無いときは、AI を呼ばずに断る（1 日の回数を使わない）", () => {
  const noColumn = seeded({ apiKey: "test-key", sheets: { 設定: settingsWith(), 定義: DEFINITION, 案件: [["ID", "案件名"], ["20260916-001", "内装"]] } });
  assert.throws(() => noColumn.entry.api_ai_draft("案件", "20260916-001", "お礼"), /このテーブルには LINE の列がありません/);
  const noToken = loadBundle({ apiKey: "test-key", sheets: { 設定: [["通知先", ""]], 定義: DEFINITION, "_LINE友だち": FRIENDS, 顧客: CUSTOMERS } });
  assert.throws(() => noToken.entry.api_ai_draft("顧客", "20260916-001", "お礼"), /LINE の送信は使えません/);
  for (const run of [noColumn, noToken]) {
    assert.equal(sentTo(run, "https://api.anthropic.com/").length, 0);
    assert.equal(run.props["ai:2026-09-16"], undefined);
  }
});

test("LINE の列にブロック中の友だちを新しく選ぶと敬体で断る。すでに結びついている値のままなら保存できる", () => {
  const run = seeded();
  assert.throws(() => run.entry.api_create("顧客", { 会社名: "x", LINE: B }), (error) => error.message === "LINE: この方は LINE でブロック中のため選べません。ほかの友だちを選ぶか、空にしてください");
  assert.throws(() => run.entry.api_update("顧客", "20260916-001", { 会社名: "みなと工務店", LINE: B }, "2026-09-16 10:00:00"), /LINE: この方は LINE でブロック中のため選べません/);
  assert.equal(run.sheets["顧客"].rows[1][3], A, "変えていない");
  assert.ok(run.entry.api_update("顧客", "20260916-002", { 会社名: "さくら不動産", 状況: "取引中", LINE: B }, "2026-09-16 10:00:00").updatedAt);
});
