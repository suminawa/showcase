import { test } from "node:test";
import assert from "node:assert/strict";
import { runInContext } from "node:vm";
import { loadBundle, plain } from "./fakes.mjs";

const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const C = "U" + "c".repeat(32);
const SETTINGS = [["項目", "値"], ["LINE チャネルアクセストークン", "line-token"]];
const SEND_HEADER = ["日時", "テーブル", "ID", "送り先ユーザー ID", "送信者", "本文", "結果"];

function evalIn(run, code) {
  return runInContext(code, run.context);
}

function hook(events) {
  return { parameter: { hook: "line" }, postData: { contents: JSON.stringify({ destination: "U" + "0".repeat(32), events: events }) } };
}

function follow(id) {
  return { type: "follow", timestamp: 1, replyToken: "r", source: { type: "user", userId: id } };
}

function message(id) {
  return { type: "message", timestamp: 3, replyToken: "r", source: { type: "user", userId: id }, message: { type: "text", id: "1", text: "こんにちは" } };
}

function unfollow(id) {
  return { type: "unfollow", timestamp: 2, source: { type: "user", userId: id } };
}

test("doPost: ?hook=line が無ければ not found だけを返し、シートにも LINE にも触らない", () => {
  const run = loadBundle({ sheets: { 設定: SETTINGS } });
  const out = run.entry.doPost({ parameter: {}, postData: { contents: JSON.stringify({ events: [follow(A)] }) } });
  assert.deepEqual(out, { text: "not found", mime: "TEXT" });
  assert.equal(run.entry.doPost(undefined).text, "not found");
  assert.equal(run.entry.doPost({ parameter: { hook: "slack" } }).text, "not found");
  assert.equal(run.sheets["_LINE友だち"], undefined);
  assert.equal(run.trace.fetched.length, 0);
});

test("doPost: follow で _LINE友だち に 1 行（表示名は profile で取る）。unfollow でブロック、また follow で友だちに戻す", () => {
  const profiles = { [A]: "はるか" };
  const run = loadBundle({ sheets: { 設定: SETTINGS }, lineProfiles: profiles });
  assert.deepEqual(run.entry.doPost(hook([follow(A)])), { text: "OK", mime: "TEXT" });
  const rows = run.sheets["_LINE友だち"].rows;
  assert.deepEqual(rows[0], ["ユーザー ID", "表示名", "追加日時", "状態"]);
  assert.deepEqual(rows[1], [A, "はるか", "2026-09-16 10:40:00", "友だち"]);
  assert.equal(run.trace.fetched[0].url, "https://api.line.me/v2/bot/profile/" + A);
  assert.equal(run.trace.fetched[0].headers.Authorization, "Bearer line-token");
  // 本物のブロックでは、LINE はもう表示名を返さない
  delete profiles[A];
  run.entry.doPost(hook([unfollow(A)]));
  assert.equal(rows.length, 2);
  assert.equal(rows[1][3], "ブロック");
  profiles[A] = "はるか";
  run.entry.doPost(hook([follow(A)]));
  assert.equal(rows.length, 2, "同じ ID は行を増やさない");
  assert.equal(rows[1][3], "友だち");
  assert.deepEqual(plain(evalIn(run, "friendsForScreen(readFriends_())")), [{ id: A, name: "はるか", blocked: false }]);
});

test("表示名が取れない ID は名前を空のまま置き、画面の候補（friendsForScreen）には出さない", () => {
  const run = loadBundle({ sheets: { 設定: SETTINGS } });
  run.entry.doPost(hook([follow(C)]));
  assert.deepEqual(run.sheets["_LINE友だち"].rows[1].slice(0, 2), [C, ""]);
  assert.deepEqual(plain(evalIn(run, "friendsForScreen(readFriends_())")), []);
});

test("doPost: postback・events が空・知らない ID の unfollow は何もせず OK。壊れた本文も OK を返して実行ログに残す", () => {
  const run = loadBundle({ sheets: { 設定: SETTINGS } });
  assert.equal(run.entry.doPost(hook([{ type: "postback", source: { type: "user", userId: A }, postback: { data: "x" } }])).text, "OK");
  assert.equal(run.entry.doPost(hook([])).text, "OK");
  assert.equal(run.entry.doPost(hook([unfollow(A)])).text, "OK");
  assert.equal(run.sheets["_LINE友だち"], undefined, "シートも作らない");
  assert.equal(run.entry.doPost({ parameter: { hook: "line" }, postData: { contents: "{not json" } }).text, "OK");
  assert.ok(run.trace.logs.some((line) => line.includes("JSON")));
  assert.equal(run.trace.fetched.length, 0);
});

test("doGet: ?hook=line の URL をブラウザで開いたら、画面ではなく webhook 用だと文字で返す", () => {
  const run = loadBundle({ sheets: { 設定: SETTINGS } });
  const out = run.entry.doGet({ parameter: { hook: "line" } });
  assert.ok(out.text.startsWith("この URL は LINE の Webhook 用です"));
  // 画面用のデプロイ（利用者 = 実行ユーザー）では、引数が無ければ画面を返す
  assert.equal(run.entry.doGet({ parameter: {} }).file, "App");
  assert.equal(run.entry.doGet().file, "App");
});

test("doGet: webhook 用のデプロイ（実行ユーザーは所有者）では、引数が無くても画面を出さない。ログインしていない人も、所有者以外の人も", () => {
  for (const email of ["", "taro@example.com"]) {
    const run = loadBundle({ sheets: { 設定: SETTINGS }, email: email, effectiveEmail: "owner@example.com" });
    for (const e of [undefined, { parameter: {} }, { parameter: { page: "1" } }]) {
      const out = run.entry.doGet(e);
      assert.equal(out.file, undefined, "画面を返さない");
      assert.ok(out.text.startsWith("この URL は LINE の Webhook 用です"));
      assert.ok(out.text.includes("画面用のデプロイの URL で開いてください"));
    }
    assert.equal(run.trace.html.length, 0);
  }
  // 利用者が分からなければ、実行ユーザーが空でも出さない
  assert.ok(loadBundle({ sheets: { 設定: SETTINGS }, email: "", effectiveEmail: "" }).entry.doGet().text.startsWith("この URL は LINE の Webhook 用です"));
  // 所有者ご本人のブラウザ（利用者 = 実行ユーザー）は通る
  assert.equal(loadBundle({ sheets: { 設定: SETTINGS }, email: "owner@example.com", effectiveEmail: "Owner@Example.com" }).entry.doGet().file, "App");
});

test("doPost: 偽の unfollow は、LINE の表示名がまだ取れる（友だちのまま）なら無視し、状態を変えない", () => {
  const FRIENDS = [["ユーザー ID", "表示名", "追加日時", "状態"], [A, "はるか", "2026-09-10 09:00:00", "友だち"]];
  const run = loadBundle({ sheets: { 設定: SETTINGS, "_LINE友だち": FRIENDS }, lineProfiles: { [A]: "はるか" } });
  assert.equal(run.entry.doPost(hook([unfollow(A)])).text, "OK");
  assert.deepEqual(run.sheets["_LINE友だち"].rows[1], [A, "はるか", "2026-09-10 09:00:00", "友だち"]);
  assert.equal(run.trace.fetched.length, 1, "表示名を問い合わせた");
  assert.ok(run.trace.logs.some((line) => line.includes("ブロックの知らせを無視しました")));
});

test("doPost: ブロック中の行への follow は、表示名が新しく取れたときだけ友だちに戻す（取れなければ状態も表示名も変えない）", () => {
  const FRIENDS = [["ユーザー ID", "表示名", "追加日時", "状態"], [A, "はるか", "2026-09-10 09:00:00", "ブロック"]];
  const profiles = {};
  const run = loadBundle({ sheets: { 設定: SETTINGS, "_LINE友だち": FRIENDS }, lineProfiles: profiles });
  run.entry.doPost(hook([follow(A)]));
  assert.deepEqual(run.sheets["_LINE友だち"].rows[1], [A, "はるか", "2026-09-10 09:00:00", "ブロック"], "偽の follow では戻さない");
  profiles[A] = "はるか（新）";
  run.entry.doPost(hook([follow(A)]));
  assert.deepEqual(run.sheets["_LINE友だち"].rows[1], [A, "はるか（新）", "2026-09-10 09:00:00", "友だち"]);
});

test("doPost: 1 回の webhook で扱う出来事は 100 件まで。残りは無視して実行ログに残す", () => {
  const ids = [];
  for (let i = 0; i < 105; i += 1) ids.push("U" + i.toString(16).padStart(32, "0"));
  const run = loadBundle({ sheets: { 設定: SETTINGS } });
  assert.equal(run.entry.doPost(hook(ids.map(follow))).text, "OK");
  const rows = run.sheets["_LINE友だち"].rows;
  assert.equal(rows.length, 101, "見出し + 100 行");
  assert.equal(rows[100][0], ids[99]);
  assert.equal(run.trace.fetched.length, 100);
  assert.ok(run.trace.logs.some((line) => line.includes("105 件") && line.includes("100 件")));
  assert.equal(runInContext("WEBHOOK_EVENT_LIMIT", run.context), 100);
});

test("_LINE送信履歴: 追記は見出しの名前で、文字は ' 付き。記録ごとに新しい順で 20 件まで。月の送信数は月またぎで数える", () => {
  const run = loadBundle({ sheets: { _LINE送信履歴: [SEND_HEADER, ["2026-08-31 23:59:59", "顧客", "20260916-001", A, "taro@example.com", "先月の分", "送信済み"]] } });
  evalIn(run, "appendSendLog_({ at: '2026-09-01 00:00:00', table: '顧客', id: '20260916-001', to: '" + A + "', sender: 'taro@example.com', text: '=1+1 こんにちは\\n2 行目', result: '送信済み' })");
  assert.deepEqual(run.sheets["_LINE送信履歴"].rows[2], ["2026-09-01 00:00:00", "顧客", "20260916-001", A, "taro@example.com", "=1+1 こんにちは\n2 行目", "送信済み"]);
  evalIn(run, "for (var i = 0; i < 21; i += 1) appendSendLog_({ at: '2026-09-16 10:40:00', table: '顧客', id: '20260916-001', to: '" + A + "', sender: 'taro@example.com', text: 'n' + i, result: '送信済み' })");
  evalIn(run, "appendSendLog_({ at: '2026-09-16 10:41:00', table: '顧客', id: '20260916-002', to: '" + A + "', sender: 'taro@example.com', text: 'ほかの記録', result: '送信済み' })");
  const history = plain(evalIn(run, "readSendLog_('顧客', '20260916-001')"));
  assert.equal(history.length, 20);
  assert.deepEqual(history[0], { at: "2026-09-16 10:40:00", sender: "taro@example.com", text: "n20", result: "送信済み" });
  assert.equal(history[19].text, "n1");
  assert.deepEqual(plain(evalIn(run, "readSendLog_('顧客', '20260916-002')")).map((h) => h.text), ["ほかの記録"]);
  assert.equal(evalIn(run, "monthSendCount_('2026-09')"), 23);
  assert.equal(evalIn(run, "monthSendCount_('2026-08')"), 1);
  const empty = loadBundle({ sheets: {} });
  assert.deepEqual(plain(evalIn(empty, "readSendLog_('顧客', '1')")), []);
  assert.equal(evalIn(empty, "monthSendCount_('2026-09')"), 0);
  assert.equal(empty.sheets["_LINE送信履歴"], undefined, "読むだけではシートを作らない");
});

test("doPost: webhook より前から友だちだった人は、メッセージを 1 通送れば _LINE友だち に入る（本文は書かない）", () => {
  const run = loadBundle({ sheets: { 設定: [["項目", "値"], ["LINE チャネルアクセストークン", "tok"]] }, lineProfiles: { [B]: "けんた" } });
  assert.deepEqual(run.entry.doPost(hook([message(B)])), { text: "OK", mime: "TEXT" });
  const rows = run.sheets["_LINE友だち"].rows;
  assert.equal(rows.length, 2);
  assert.equal(rows[1][0].replace(/^'/, ""), B);
  assert.equal(rows[1][1].replace(/^'/, ""), "けんた");
  assert.equal(rows[1][3].replace(/^'/, ""), "友だち");
  assert.ok(!JSON.stringify(rows).includes("こんにちは"), "メッセージの本文はシートに書かない");
  run.entry.doPost(hook([message(B)]));
  assert.equal(run.sheets["_LINE友だち"].rows.length, 2, "2 通目で行は増えない");
});
