import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { SETTING_KEYS, DEFAULT_SETTINGS } from "../src/settings.js";
import { TYPES } from "../src/definition.js";
import { TEMPLATE_NAMES } from "../src/samples.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const readme = readFileSync(join(root, "README.ja.md"), "utf8");

test("README に必要な見出しがそろっている", () => {
  for (const heading of ["## 1. できること", "## 2. 置き方（10 分）", "## 3. 定義シートの書き方", "## 4. 設定シート", "## 5. 権限", "## 6. AI の機能（任意）", "## 7. 使い方", "## 8. よくある質問", "## 9. 更新履歴"]) {
    assert.ok(readme.includes(heading), heading);
  }
});

test("設定の項目と型の一覧が README と一致する。価格と鍵の値を書かない", () => {
  for (const key of SETTING_KEYS) assert.ok(readme.includes("| " + key + " |"), key);
  assert.ok(readme.includes(String(DEFAULT_SETTINGS.pageSize)));
  for (const type of TYPES) assert.ok(readme.includes("`" + type + "`"), type);
  assert.ok(readme.includes("`参照:<テーブル名>`"));
  for (const name of TEMPLATE_NAMES) assert.ok(readme.includes(name), name);
  assert.equal(/[¥￥]\s?\d/.test(readme), false, "価格は README に書かない");
  assert.equal(readme.includes("sk-ant-"), false);
  assert.ok(readme.includes("ANTHROPIC_API_KEY"));
  assert.ok(readme.includes("ウェブアプリにアクセスしているユーザー"));
  assert.ok(readme.includes("Google アカウントを持つ全員"));
  assert.ok(readme.includes("_ごみ箱"));
});

test("LICENSE と CHANGELOG", () => {
  const license = readFileSync(join(root, "LICENSE.md"), "utf8");
  assert.ok(license.includes("スプレッドシート業務アプリ キット"));
  assert.ok(license.includes("再配布"));
  const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");
  assert.ok(changelog.includes("## 1.0.0"));
});
