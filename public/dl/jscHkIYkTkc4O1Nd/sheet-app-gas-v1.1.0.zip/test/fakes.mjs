/**
 * 偽の GAS。Code.gs を node:vm で走らせるための最小のグローバル。
 * シートは 2 次元配列、プロパティは辞書、fetch は記録するだけ。
 */
import { createContext, runInContext } from "node:vm";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildServer } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

const LINE_PROFILE_PREFIX = "https://api.line.me/v2/bot/profile/";

/** UrlFetchApp の答え。body は文字ならそのまま、ほかは JSON にする */
function response_(status, body) {
  return { getResponseCode: () => status, getContentText: () => (typeof body === "string" ? body : JSON.stringify(body)) };
}
/** 引数なしの new Date() と Date.now() は 2026-09-16 10:40 JST に固定する */
export const FIXED_NOW = Date.UTC(2026, 8, 16, 1, 40, 0);
class FixedDate extends Date {
  constructor(...args) {
    if (args.length === 0) super(FIXED_NOW);
    else super(...args);
  }
  static now() {
    return FIXED_NOW;
  }
}

function copy_(rows) {
  return rows.map((row) => Array.from(row));
}

/**
 * 本物の Sheets は、書き込んだ文字を人が打ち込んだときと同じように読み直す。
 * 先頭が ' なら文字（' は残らない）、数に見えれば数、日付に見えれば日付（JST）。
 */
export function parseWritten_(value) {
  if (typeof value !== "string") return value;
  if (value.charAt(0) === "'") return value.slice(1);
  if (/^-?\d+(\.\d+)?$/.test(value)) return Number(value);
  if (/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$/.test(value)) {
    return new Date((value.indexOf(" ") < 0 ? value + "T00:00:00" : value.replace(" ", "T")) + "+09:00");
  }
  return value;
}

export function fakeSheet(name, values, options) {
  const opts = options || {};
  const rows = copy_(values || []);
  /** 数式のセルだけ "=..." を覚える（値の grid には "#FORMULA" が入る） */
  const formulas = [];
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const pad = () => {
    const w = width();
    for (const row of rows) while (row.length < w) row.push("");
  };
  const denied = () => {
    if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues. Required permissions: https://www.googleapis.com/auth/spreadsheets");
  };
  const at_ = (grid, r, c, fallback) => (grid[r] && grid[r][c] !== undefined ? grid[r][c] : fallback);
  /** r・c は 0 から数える */
  const write_ = (r, c, value) => {
    while (rows.length <= r) rows.push([]);
    while (rows[r].length <= c) rows[r].push("");
    while (formulas.length <= r) formulas.push([]);
    while (formulas[r].length <= c) formulas[r].push("");
    const formula = typeof value === "string" && value.charAt(0) === "=";
    formulas[r][c] = formula ? value : "";
    rows[r][c] = formula ? "#FORMULA" : parseWritten_(value);
  };
  const sheet = {
    rows: rows,
    formulas: formulas,
    /** setValues を呼ばれた回数（まとめて書けているかを見る） */
    writes: 0,
    getName: () => name,
    getSheetId: () => 1000 + name.length,
    getLastRow: () => rows.length,
    getLastColumn: () => width(),
    getMaxColumns: () => Math.max(26, width()),
    insertColumnsAfter: () => {},
    setFrozenRows: () => {},
    getDataRange: () => ({ getValues: () => copy_(rows) }),
    getRange: (r, c, nr, nc) => {
      const grid_ = (pick) => {
        const out = [];
        for (let i = 0; i < (nr || 1); i += 1) {
          const line = [];
          for (let j = 0; j < (nc || 1); j += 1) line.push(pick(r - 1 + i, c - 1 + j));
          out.push(line);
        }
        return out;
      };
      return {
        getValues: () => grid_((rr, cc) => at_(rows, rr, cc, "")),
        getFormulas: () => grid_((rr, cc) => at_(formulas, rr, cc, "")),
        setValues: (written) => {
          denied();
          sheet.writes += 1;
          for (let i = 0; i < written.length; i += 1) for (let j = 0; j < written[i].length; j += 1) write_(r - 1 + i, c - 1 + j, written[i][j]);
          pad();
        },
        setNumberFormat: () => {},
      };
    },
    appendRow: (row) => {
      denied();
      const r = rows.length;
      rows.push([]);
      for (let j = 0; j < row.length; j += 1) write_(r, j, row[j]);
      pad();
    },
    deleteRow: (r) => {
      denied();
      rows.splice(r - 1, 1);
      formulas.splice(r - 1, 1);
    },
    /** r 行目の下に n 行の空行を入れる（本物と同じく 1 始まり） */
    insertRowsAfter: (r, n) => {
      denied();
      const width = rows.length > 0 ? rows[0].length : 1;
      for (let i = 0; i < n; i += 1) {
        rows.splice(r, 0, new Array(width).fill(""));
        formulas.splice(r, 0, new Array(width).fill(""));
      }
    },
  };
  return sheet;
}

export function createSandbox(options) {
  const opts = options || {};
  const trace = { fetched: [], alerts: [], logs: [], html: [], menu: [] };
  const props = Object.assign({}, opts.props || {});
  if (opts.apiKey !== undefined) props.ANTHROPIC_API_KEY = opts.apiKey;
  const sheets = {};
  const seed = opts.sheets || {};
  for (const name of Object.keys(seed)) sheets[name] = fakeSheet(name, seed[name], { denyWrite: opts.denyWrite });
  const book = {
    getUrl: () => "https://docs.google.com/spreadsheets/d/SHEETID/edit",
    getSpreadsheetTimeZone: () => "Asia/Tokyo",
    getOwner: () => ({ getEmail: () => (opts.owner === undefined ? "owner@example.com" : opts.owner) }),
    getEditors: () => (opts.editors === undefined ? ["taro@example.com", "hanako@example.com"] : opts.editors).map((e) => ({ getEmail: () => e })),
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Spreadsheet.insertSheet.");
      sheets[name] = fakeSheet(name, [], { denyWrite: opts.denyWrite });
      return sheets[name];
    },
  };
  const menu = {
    addItem: (label, fn) => {
      trace.menu.push([label, fn]);
      return menu;
    },
    addSeparator: () => menu,
    addToUi: () => {},
  };
  const sandbox = {
    Date: FixedDate,
    SpreadsheetApp: {
      // 共有されていない・元のシートが削除された人には、本物も例外を投げる
      getActiveSpreadsheet: () => {
        if (opts.noSpreadsheet) throw new Error("You do not have permission to access the requested document.");
        return book;
      },
      getUi: () => ({ alert: (t) => trace.alerts.push(String(t)), createMenu: () => menu }),
    },
    HtmlService: {
      createHtmlOutput: (html) => {
        const out = { html: html, title: "" };
        out.setTitle = (t) => {
          out.title = t;
          return out;
        };
        trace.html.push(out);
        return out;
      },
      createHtmlOutputFromFile: (file) => {
        const out = { file: file, title: "", meta: [] };
        out.setTitle = (t) => {
          out.title = t;
          return out;
        };
        out.addMetaTag = (k, v) => {
          out.meta.push([k, v]);
          return out;
        };
        trace.html.push(out);
        return out;
      },
    },
    ContentService: {
      MimeType: { TEXT: "TEXT", JSON: "JSON" },
      createTextOutput: (text) => {
        const out = { text: String(text), mime: "" };
        out.setMimeType = (mime) => {
          out.mime = mime;
          return out;
        };
        return out;
      },
    },
    UrlFetchApp: {
      // 記録してから答える。opts.respond(url, options) が { status, body } を返せばそれを使う。
      // LINE のプロフィールは opts.lineProfiles（{ ユーザー ID: 表示名 }）から、Claude は opts.claudeStatus / claudeBody から、ほかは 200 {}
      fetch: (url, fetchOptions) => {
        const options = fetchOptions || {};
        const address = String(url);
        trace.fetched.push({ url: address, method: options.method || "get", payload: options.payload, headers: options.headers || {} });
        const custom = typeof opts.respond === "function" ? opts.respond(address, options) : undefined;
        if (custom !== undefined) return response_(custom.status, custom.body === undefined ? {} : custom.body);
        if (address.indexOf(LINE_PROFILE_PREFIX) === 0) {
          const id = decodeURIComponent(address.slice(LINE_PROFILE_PREFIX.length));
          const profiles = opts.lineProfiles || {};
          if (Object.prototype.hasOwnProperty.call(profiles, id)) return response_(200, { userId: id, displayName: profiles[id] });
          return response_(404, { message: "Not found" });
        }
        if (address.indexOf("https://api.anthropic.com/") !== 0) return response_(200, {});
        const status = opts.claudeStatus || 200;
        const body = opts.claudeBody || { content: [{ type: "text", text: JSON.stringify({ q: "", filters: [{ column: "状況", op: "eq", value: "取引中" }], sort: null, explanation: "状況が取引中の顧客に絞りました" }) }], usage: { input_tokens: 1200, output_tokens: 80, cache_read_input_tokens: 0, cache_creation_input_tokens: 1100 }, stop_reason: "end_turn" };
        return response_(status, status === 200 ? body : { error: "x" });
      },
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (props[key] === undefined ? null : props[key]),
        setProperty: (key, value) => {
          props[key] = value;
        },
        getKeys: () => Object.keys(props),
        deleteProperty: (key) => {
          delete props[key];
        },
      }),
    },
    LockService: {
      getScriptLock: () => ({
        waitLock: () => {
          if (opts.lockBusy) throw new Error("Could not acquire lock");
        },
        releaseLock: () => {},
      }),
    },
    ScriptApp: { getService: () => ({ getUrl: () => (opts.appUrl === undefined ? "https://script.google.com/macros/s/XXX/exec" : opts.appUrl) }) },
    // 画面用のデプロイ（アクセスしているユーザーとして実行）では、実行ユーザー（effective）は利用者（active）と同じ。
    // webhook 用のデプロイ（実行ユーザー「自分」）を試すときは opts.effectiveEmail に所有者を入れる
    Session: {
      getActiveUser: () => ({ getEmail: () => (opts.email === undefined ? "taro@example.com" : opts.email) }),
      getEffectiveUser: () => ({ getEmail: () => (opts.effectiveEmail !== undefined ? opts.effectiveEmail : opts.email === undefined ? "taro@example.com" : opts.email) }),
    },
    Utilities: { sleep: () => {} },
    Logger: { log: (t) => trace.logs.push(String(t)) },
  };
  return { sandbox: sandbox, sheets: sheets, props: props, trace: trace };
}

const ENTRY_NAMES = ["api_bootstrap", "api_list", "api_get", "api_options", "api_create", "api_update", "api_delete", "api_export", "api_ai_filter", "api_ai_summary", "api_line_send", "api_ai_draft", "doGet", "doPost", "onOpen", "initializeSheets", "loadSampleCustomers", "loadSampleProjects", "loadSampleInventory", "checkSettings", "sendTestNotification", "showAppUrl", "showAiUsage"];

/**
 * vm の中で作られた配列・オブジェクトは prototype が別の realm のものなので、node:assert/strict の deepEqual が通らない。
 * JSON を経由して、この realm の素のオブジェクトにする（undefined はそのまま）
 */
export function plain(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

/** Code.gs を偽の GAS の上で走らせ、入口の関数を返す（返り値は plain() を通す。例外はそのまま投げる） */
export function loadBundle(options) {
  const made = createSandbox(options);
  const context = createContext(made.sandbox);
  const exports = ENTRY_NAMES.map((n) => n + ": typeof " + n + " === 'function' ? " + n + " : null").join(", ");
  runInContext(buildServer(root) + "\nglobalThis.__entry = { " + exports + " };\n", context);
  const entry = {};
  ENTRY_NAMES.forEach((name) => {
    const fn = made.sandbox.__entry[name];
    entry[name] = fn === null ? null : (...args) => plain(fn.apply(null, args));
  });
  return { entry: entry, sheets: made.sheets, props: made.props, trace: made.trace, sandbox: made.sandbox, context: context };
}
