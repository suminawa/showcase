import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { runInNewContext } from "node:vm";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("demo/app.js は読み込んだ時点で落ちない（見本に要る純粋な処理がそろっている）", () => {
  const js = readFileSync(join(root, "demo", "app.js"), "utf8");
  const sandbox = { window: {} };
  runInNewContext(js, sandbox);
  assert.equal(typeof sandbox.window.SheetApp.mount, "function");
});

test("App.html: LINE の送信と下書きの api、URL のハッシュの読み書き、LINE の純粋な処理と画面を含む", () => {
  const html = readFileSync(join(root, "dist", "App.html"), "utf8");
  for (const part of ['"api_line_send"', '"api_ai_draft"', "google.script.url.getLocation", "google.script.history.replace", "function fillLineTemplate(", "function parseHash(", "function renderLinePanel(", "LINE で送る"]) {
    assert.ok(html.includes(part), part);
  }
  const css = html.slice(html.indexOf("<style>") + 7, html.indexOf("</style>"));
  assert.ok(css.includes(".sa-line "));
});
