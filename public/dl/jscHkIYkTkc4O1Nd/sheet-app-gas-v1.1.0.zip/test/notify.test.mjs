import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { CHANGE_COLUMN_LIMIT, CHANGE_TEXT_LIMIT, DEFAULT_NOTIFY_TEMPLATE, NOTIFY_LOG_HEADER, NOTIFY_LOG_SHEET, NOTIFY_OPS, NOTIFY_TARGETS, buildChanges, buildNotifyText, buildPayload, buildTestNotifyText, displayValues, formatChanges, recordUrl, shortText, shouldNotify } from "../src/notify.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "FALSE", "", "", ""],
  ["対応履歴", "顧客", "参照:顧客", "TRUE", "", "", "", "", ""],
  ["対応履歴", "内容", "長文", "TRUE", "", "", "", "", ""],
]);
const T = tables[0];
const H = tables[1];
const APP = "https://script.google.com/macros/s/XXX/exec";
const BEFORE = { ID: "20260916-001", 会社名: "みなと工務店", 状況: "見込み", 最終連絡日: "2026-09-10", 年間取引額: null, 要注意: false, メモ: "", 作成日時: "2026-09-16 10:00:00", 更新日時: "2026-09-16 10:00:00", 更新者: "taro@example.com" };
const SETTINGS = { notifyTargets: ["slack"], notifyTables: [], notifyOps: ["登録", "更新", "削除"], skipOwn: false };

test("定数: 宛先・操作・_通知ログ の見出し・切る字数と列数・既定の文面", () => {
  assert.deepEqual(NOTIFY_TARGETS, ["slack", "discord", "line"]);
  assert.deepEqual(NOTIFY_OPS, ["登録", "更新", "削除"]);
  assert.equal(NOTIFY_LOG_SHEET, "_通知ログ");
  assert.deepEqual(NOTIFY_LOG_HEADER, ["日時", "テーブル", "操作", "ID", "宛先", "結果"]);
  assert.equal(CHANGE_TEXT_LIMIT, 60);
  assert.equal(CHANGE_COLUMN_LIMIT, 10);
  assert.equal(DEFAULT_NOTIFY_TEMPLATE, "【{アプリ名}】{テーブル}を{操作}しました\n{表示名}（{ID}）\n{変更点}\n{更新者}\n{URL}");
});

test("shortText: 改行は空白にして 1 行、60 字を超えたら切って … を付ける", () => {
  assert.equal(shortText("あ".repeat(60)), "あ".repeat(60));
  assert.equal(shortText("あ".repeat(61)), "あ".repeat(60) + "…");
  assert.equal(shortText("1 行目\n 2 行目 "), "1 行目 2 行目");
  assert.equal(shortText(null), "");
});

test("更新の変更点: 変わった列だけ、画面と同じ書式（日付の書式・金額・チェックは はい/いいえ・空は（空））、長文は 60 字", () => {
  const after = Object.assign({}, BEFORE, { 状況: "取引中", 最終連絡日: "2026-09-16", 年間取引額: 1200000, 要注意: true, メモ: "い".repeat(80) });
  const changes = buildChanges(T, "更新", BEFORE, after, { dateFormat: "yyyy/MM/dd" });
  assert.deepEqual(changes.items, [
    { column: "状況", before: "見込み", after: "取引中" },
    { column: "最終連絡日", before: "2026/09/10", after: "2026/09/16" },
    { column: "年間取引額", before: "", after: "¥1,200,000" },
    { column: "要注意", before: "いいえ", after: "はい" },
    { column: "メモ", before: "", after: "い".repeat(60) + "…" },
  ]);
  assert.equal(changes.more, 0);
  assert.equal(
    formatChanges("更新", changes),
    ["状況: 見込み → 取引中", "最終連絡日: 2026/09/10 → 2026/09/16", "年間取引額: （空） → ¥1,200,000", "要注意: いいえ → はい", "メモ: （空） → " + "い".repeat(60) + "…"].join("\n"),
  );
});

test("登録の変更点は、定義の順に空でない列（チェックの いいえ は空とみなす）。削除は空", () => {
  const created = buildChanges(T, "登録", null, BEFORE, {});
  assert.deepEqual(created.items.map((i) => i.column), ["会社名", "状況", "最終連絡日"]);
  assert.equal(formatChanges("登録", created), "会社名: みなと工務店\n状況: 見込み\n最終連絡日: 2026-09-10");
  const removed = buildChanges(T, "削除", BEFORE, null, {});
  assert.deepEqual(removed, { items: [], more: 0 });
  assert.equal(formatChanges("削除", removed), "");
});

test("変更点は 10 列まで。超えた分は「ほか n 列」", () => {
  const rows = [HEADER];
  for (let i = 1; i <= 12; i += 1) rows.push(["多い", "列" + i, "文字", "", "", "", "", "", ""]);
  const wide = parseDefinition(rows).tables[0];
  const after = {};
  for (let i = 1; i <= 12; i += 1) after["列" + i] = "値" + i;
  const changes = buildChanges(wide, "登録", null, after, {});
  assert.equal(changes.items.length, 10);
  assert.equal(changes.more, 2);
  assert.ok(formatChanges("登録", changes).endsWith("列10: 値10\nほか 2 列"));
});

test("参照と LINE の列は labels の表示名で出す。displayValues は切らない", () => {
  const labels = { 顧客: { "20260916-001": "みなと工務店" } };
  const changes = buildChanges(H, "登録", null, { 顧客: "20260916-001", 内容: "お見積もりをお送りしました" }, { labels: labels });
  assert.deepEqual(changes.items[0], { column: "顧客", before: "", after: "みなと工務店" });
  const values = displayValues(T, Object.assign({}, BEFORE, { メモ: "う".repeat(80), 要注意: true }), {});
  assert.equal(values.メモ, "う".repeat(80));
  assert.equal(values.要注意, "はい");
  assert.equal(values.年間取引額, "");
});

test("既定の文面: 更新は変わった列が並び、URL で詳細が開く", () => {
  const after = Object.assign({}, BEFORE, { 状況: "取引中" });
  const text = buildNotifyText(DEFAULT_NOTIFY_TEMPLATE, {
    appName: "みなと台帳",
    table: "顧客",
    op: "更新",
    id: "20260916-001",
    label: "みなと工務店",
    actor: "taro@example.com",
    changes: buildChanges(T, "更新", BEFORE, after, {}),
    url: recordUrl(APP, "顧客", "20260916-001"),
    values: displayValues(T, after, {}),
  });
  assert.equal(text, "【みなと台帳】顧客を更新しました\nみなと工務店（20260916-001）\n状況: 見込み → 取引中\ntaro@example.com\n" + APP + "#" + encodeURIComponent("顧客") + "/20260916-001");
});

test("削除は {変更点} の行ごと省く。列名の印は値に、知らない印はそのまま、値の中の {…} は置き換えない", () => {
  const removed = buildNotifyText(DEFAULT_NOTIFY_TEMPLATE, { appName: "みなと台帳", table: "顧客", op: "削除", id: "20260916-001", label: "みなと工務店", actor: "taro@example.com", changes: { items: [], more: 0 }, url: "", values: {} });
  assert.equal(removed, "【みなと台帳】顧客を削除しました\nみなと工務店（20260916-001）\ntaro@example.com");
  const custom = buildNotifyText("{会社名} 様の{操作}\n{無い印}\n\n以上", { appName: "", table: "顧客", op: "登録", id: "1", label: "", actor: "", changes: { items: [], more: 0 }, url: "", values: { 会社名: "{URL} 商店" } });
  assert.equal(custom, "{URL} 商店 様の登録\n{無い印}\n\n以上", "印の無い空行は書いたとおりに残す");
});

test("buildPayload: Slack は text、Discord は content（1,900 字）、LINE は push の形（5,000 字）。テストの文", () => {
  assert.deepEqual(buildPayload("やあ", "slack"), { text: "やあ" });
  assert.deepEqual(buildPayload("やあ", "discord"), { content: "やあ", allowed_mentions: { parse: [] } });
  assert.deepEqual(buildPayload("やあ", "line", { lineTo: "Uxxx" }), { to: "Uxxx", messages: [{ type: "text", text: "やあ" }] });
  const discord = buildPayload("あ".repeat(3000), "discord").content;
  assert.equal(discord.length, 1900);
  assert.ok(discord.endsWith("\n…（以下省略）"));
  assert.equal(buildPayload("あ".repeat(6000), "line", { lineTo: "U" }).messages[0].text.length, 5000);
  assert.equal(buildTestNotifyText("みなと台帳"), "【みなと台帳】これはテストです。通知の設定ができています。");
});

test("buildPayload: お客さまの名前がメンションにならない（Discord は allowed_mentions を空、Slack は & < > を文字参照に）", () => {
  const name = "<!channel> @everyone <@U123> A&B";
  assert.deepEqual(buildPayload(name, "discord"), { content: name, allowed_mentions: { parse: [] } });
  assert.deepEqual(buildPayload(name, "slack"), { text: "&lt;!channel&gt; @everyone &lt;@U123&gt; A&amp;B" });
  assert.deepEqual(buildPayload(name, "line", { lineTo: "U" }).messages[0].text, name, "LINE はそのまま");
  const long = buildPayload("<".repeat(20000), "slack").text;
  assert.ok(long.length <= 39000);
  assert.ok(long.endsWith("\n…（以下省略）"));
  assert.ok(/^(&lt;)+\n…（以下省略）$/.test(long), "文字参照を途中で切らない");
});

test("recordUrl: #<テーブル>/<ID>。Web アプリの URL が無ければ空", () => {
  assert.equal(recordUrl(APP, "顧客", "20260916-001"), APP + "#%E9%A1%A7%E5%AE%A2/20260916-001");
  assert.equal(recordUrl("", "顧客", "20260916-001"), "");
});

test("shouldNotify: 通知先・テーブル・操作で絞る。「自分の操作は通知しない」は所有者の操作だけ飛ばす", () => {
  const event = { table: "顧客", op: "更新", actor: "owner@example.com" };
  assert.equal(shouldNotify(SETTINGS, event, "owner@example.com"), true, "既定は自分の操作も知らせる");
  assert.equal(shouldNotify(Object.assign({}, SETTINGS, { notifyTargets: [] }), event, ""), false);
  assert.equal(shouldNotify(Object.assign({}, SETTINGS, { notifyTables: ["案件"] }), event, ""), false);
  assert.equal(shouldNotify(Object.assign({}, SETTINGS, { notifyTables: ["顧客"] }), event, ""), true);
  assert.equal(shouldNotify(Object.assign({}, SETTINGS, { notifyOps: ["登録"] }), event, ""), false);
  const skip = Object.assign({}, SETTINGS, { skipOwn: true });
  assert.equal(shouldNotify(skip, event, "Owner@Example.com"), false);
  assert.equal(shouldNotify(skip, { table: "顧客", op: "更新", actor: "taro@example.com" }, "owner@example.com"), true);
  assert.equal(shouldNotify(skip, event, ""), true, "所有者が分からなければ飛ばさない");
});
