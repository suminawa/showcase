import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { validate, checkValue, TEXT_LIMIT, LONG_TEXT_LIMIT } from "../src/validate.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "分野", "複数選択", "", "設計, 施工, 保守", "", "", "設計", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "評価", "数値", "", "", "", "", "", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "今日", ""],
  ["顧客", "次回", "日時", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "TRUE", ""],
  ["顧客", "メール", "メール", "", "", "", "", "", ""],
  ["顧客", "電話", "電話", "", "", "", "", "", ""],
  ["顧客", "サイト", "URL", "", "", "", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "", "", "", ""],
  ["顧客", "担当", "参照:顧客", "", "", "", "", "", ""],
]);
const customers = tables[0];
const TODAY = "2026-09-16";

test("新規: 揃えた値と既定値（今日・チェック・複数選択）が入る", () => {
  const result = validate(customers, { 会社名: " みなと工務店 ", 年間取引額: "1,200,000円", 評価: "４.5", メール: "ｔ@example.com", 電話: "０３-1234-5678", サイト: "https://example.com/x", 次回: "2026/9/20 10:30" }, { today: TODAY, isNew: true });
  assert.equal(result.ok, true, JSON.stringify(result.errors));
  assert.equal(result.values.会社名, "みなと工務店");
  assert.equal(result.values.状況, "見込み");
  assert.deepEqual(result.values.分野, ["設計"]);
  assert.equal(result.values.年間取引額, 1200000);
  assert.equal(result.values.評価, 4.5);
  assert.equal(result.values.最終連絡日, TODAY);
  assert.equal(result.values.次回, "2026-09-20 10:30");
  assert.equal(result.values.要注意, true);
  assert.equal(result.values.メール, "t@example.com");
  assert.equal(result.values.電話, "03-1234-5678");
  assert.equal(result.values.メモ, "");
  assert.equal(result.values.担当, "");
});

test("更新: record に無い列は触らない。知らない列は無視", () => {
  const result = validate(customers, { 状況: "休眠", 無い列: "x" }, { today: TODAY, isNew: false });
  assert.equal(result.ok, true);
  assert.deepEqual(result.values, { 状況: "休眠" });
});

test("誤りは列ごとに敬体で。必須の空、数値、金額の小数、日付、日時、選択、複数選択、メール、電話、URL、字数", () => {
  const result = validate(customers, {
    会社名: "",
    状況: "取引停止",
    分野: ["設計", "営業"],
    年間取引額: "12.5",
    評価: "高い",
    最終連絡日: "9/16",
    次回: "明日",
    要注意: "たぶん",
    メール: "no-at",
    電話: "abc",
    サイト: "example.com",
    メモ: "あ".repeat(LONG_TEXT_LIMIT + 1),
    担当: "い".repeat(TEXT_LIMIT + 1),
  }, { today: TODAY, isNew: true });
  assert.equal(result.ok, false);
  assert.equal(result.errors.会社名, "会社名 を入力してください");
  assert.equal(result.errors.状況, "候補から選んでください");
  assert.equal(result.errors.分野, "候補にない値が含まれています: 営業");
  assert.equal(result.errors.年間取引額, "金額は整数（円）で入力してください");
  assert.equal(result.errors.評価, "数値で入力してください");
  assert.equal(result.errors.最終連絡日, "日付は 2026-09-16 の形で入力してください");
  assert.equal(result.errors.次回, "日時は 2026-09-16 10:30 の形で入力してください");
  assert.equal(result.errors.要注意, "はい か いいえ で入力してください");
  assert.equal(result.errors.メール, "メールアドレスの形で入力してください");
  assert.equal(result.errors.電話, "電話番号は数字とハイフンで入力してください");
  assert.equal(result.errors.サイト, "URL は http:// か https:// から書いてください");
  assert.equal(result.errors.メモ, "5,000 字以内で入力してください");
  assert.equal(result.errors.担当, "200 字以内で入力してください");
  assert.equal(Object.keys(result.errors).length, 13);
});

test("空は空のまま通る（数値・金額は null）。複数選択はカンマ区切りの文字でも配列でも受ける", () => {
  const empty = validate(customers, { 会社名: "a", 年間取引額: "", 評価: "", 最終連絡日: "", 分野: "施工、保守" }, { today: TODAY, isNew: true });
  assert.equal(empty.ok, true);
  assert.equal(empty.values.年間取引額, null);
  assert.equal(empty.values.評価, null);
  assert.equal(empty.values.最終連絡日, "");
  assert.deepEqual(empty.values.分野, ["施工", "保守"]);
  assert.deepEqual(checkValue({ type: "チェック" }, "はい"), { error: "", value: true });
  assert.deepEqual(checkValue({ type: "チェック" }, ""), { error: "", value: false });
});
