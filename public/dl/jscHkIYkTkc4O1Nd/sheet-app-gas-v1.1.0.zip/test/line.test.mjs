import { test } from "node:test";
import assert from "node:assert/strict";
import { BLOCKED_STATE, FRIEND_STATE, FRIENDS_HEADER, FRIENDS_SHEET, HISTORY_LIMIT, LINE_MESSAGES, LINE_TEXT_LIMIT, SEND_LOG_HEADER, SEND_LOG_SHEET, SENT, countMonthSends, fillLineTemplate, findFriend, friendLabel, friendsForScreen, isLineUserId, leftoverPlaceholders, lineSendError, lineTextError, parseLineTemplates, parseWebhook, staffNameFor } from "../src/line.js";
import { checkValue } from "../src/validate.js";
import { DEFAULT_LINE_TEMPLATE_TEXT, parseSettings } from "../src/settings.js";

const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const C = "U" + "c".repeat(32);

function body(events) {
  return JSON.stringify({ destination: "U" + "0".repeat(32), events: events });
}

test("定数とユーザー ID の形（U と 32 桁の小文字の 16 進）", () => {
  assert.equal(FRIENDS_SHEET, "_LINE友だち");
  assert.deepEqual(FRIENDS_HEADER, ["ユーザー ID", "表示名", "追加日時", "状態"]);
  assert.equal(FRIEND_STATE, "友だち");
  assert.equal(BLOCKED_STATE, "ブロック");
  assert.equal(SEND_LOG_SHEET, "_LINE送信履歴");
  assert.deepEqual(SEND_LOG_HEADER, ["日時", "テーブル", "ID", "送り先ユーザー ID", "送信者", "本文", "結果"]);
  assert.equal(SENT, "送信済み");
  assert.equal(HISTORY_LIMIT, 20);
  assert.equal(LINE_TEXT_LIMIT, 5000);
  assert.equal(isLineUserId(A), true);
  assert.equal(isLineUserId(" " + A + " "), true, "前後の空白は落とす");
  assert.equal(isLineUserId("U" + "A".repeat(32)), false, "大文字の 16 進は LINE の ID ではない");
  assert.equal(isLineUserId("U" + "a".repeat(31)), false);
  assert.equal(isLineUserId("C" + "a".repeat(32)), false, "グループ ID は友だちではない");
  assert.equal(isLineUserId(""), false);
});

test("parseWebhook: follow・unfollow・message（follow 扱い。同じ人はまとめる）を読み、ほかの出来事・グループ・形の違う ID は捨てる。壊れた本文は誤り", () => {
  const parsed = parseWebhook(body([
    { type: "follow", source: { type: "user", userId: A }, replyToken: "r", timestamp: 1 },
    { type: "message", source: { type: "user", userId: A }, message: { type: "text", text: "こんにちは" } },
    { type: "unfollow", source: { type: "user", userId: A } },
    { type: "follow", source: { type: "group", groupId: "C" + "1".repeat(32), userId: A } },
    { type: "follow", source: { type: "user", userId: "U123" } },
    { type: "message", source: { type: "user", userId: B }, message: { type: "sticker" } },
    { type: "message", source: { type: "user", userId: B }, message: { type: "text", text: "2 通目" } },
    { type: "postback", source: { type: "user", userId: C } },
    null,
  ]));
  assert.deepEqual(parsed, { events: [{ type: "follow", userId: A }, { type: "unfollow", userId: A }, { type: "follow", userId: B }], error: "" }, "既存の友だちからのメッセージは follow と同じ。同じ人の 2 通目はまとめる");
  assert.deepEqual(parseWebhook(body([])), { events: [], error: "" }, "LINE の「検証」は events が空");
  assert.deepEqual(parseWebhook("{}"), { events: [], error: "" });
  const broken = parseWebhook("{not json");
  assert.deepEqual(broken.events, []);
  assert.ok(broken.error.includes("JSON"));
  assert.ok(parseWebhook("123").error.includes("JSON"));
  assert.ok(parseWebhook("").error.includes("JSON"));
});

test("parseLineTemplates: 1 行 1 本の「題|本文」（全角の｜も可）、\\n は改行、空行は飛ばす、| の無い行・題か本文が空の行は誤り", () => {
  const parsed = parseLineTemplates("お礼|ありがとうございました。\\n{担当者名}\n\n打ち合わせ｜候補日をお知らせください\n題だけ|\nこんにちは\n|本文だけ");
  assert.deepEqual(parsed.templates, [
    { title: "お礼", body: "ありがとうございました。\n{担当者名}" },
    { title: "打ち合わせ", body: "候補日をお知らせください" },
  ]);
  assert.deepEqual(parsed.errors, [
    "設定「LINE 定型文」の 4 行目は、題と本文の両方を書いてください",
    "設定「LINE 定型文」の 5 行目に「|」がありません。「題|本文」の形で書いてください",
    "設定「LINE 定型文」の 6 行目は、題と本文の両方を書いてください",
  ]);
  const defaults = parseLineTemplates(DEFAULT_LINE_TEMPLATE_TEXT);
  assert.deepEqual(defaults.errors, []);
  assert.deepEqual(defaults.templates.map((t) => t.title), ["お礼", "打ち合わせの確認", "資料のご案内"]);
  assert.ok(defaults.templates.every((t) => t.body.includes("\n") && t.body.includes("{担当者名}") && !t.body.includes("承ります")));
});

test("「LINE 定型文」の誤りは設定の notifyErrors に並ぶ", () => {
  const { errors, notifyErrors } = parseSettings([["LINE 定型文", "お礼|ありがとうございます\nこんにちは"]]);
  assert.deepEqual(errors, []);
  assert.deepEqual(notifyErrors, ["設定「LINE 定型文」の 2 行目に「|」がありません。「題|本文」の形で書いてください"]);
});

test("fillLineTemplate は列名と {担当者名} を 1 回の走査で置き換え、知らない印は残す。leftoverPlaceholders と staffNameFor", () => {
  const text = fillLineTemplate("{会社名} {担当者} 様\n{担当者名}です。{無い印}", { values: { 会社名: "みなと工務店", 担当者: "{担当者名}" }, staffName: "山田" });
  assert.equal(text, "みなと工務店 {担当者名} 様\n山田です。{無い印}", "値の中の印は置き換えない");
  assert.deepEqual(leftoverPlaceholders("みなと {無い印} {無い印} {x}"), ["{無い印}", "{x}"]);
  assert.deepEqual(leftoverPlaceholders("ありがとうございました。"), []);
  assert.equal(staffNameFor({ staffName: "山田" }, "taro@example.com"), "山田");
  assert.equal(staffNameFor({ staffName: "" }, "Taro@example.com"), "Taro");
  assert.equal(staffNameFor({ staffName: "" }, ""), "");
});

test("friendsForScreen: 表示名の取れない（未確認の）ID・形の違う ID・重複を落とし、表示名の順。findFriend と friendLabel", () => {
  const friends = friendsForScreen([
    { userId: A, name: "はるか", state: "友だち" },
    { userId: B, name: "けんた", state: "ブロック" },
    { userId: C, name: "", state: "友だち" },
    { userId: "U123", name: "形が違う", state: "友だち" },
    { userId: A, name: "はるか（重複）", state: "友だち" },
  ]);
  assert.deepEqual(friends, [{ id: B, name: "けんた", blocked: true }, { id: A, name: "はるか", blocked: false }]);
  assert.equal(findFriend(friends, A).name, "はるか");
  assert.equal(findFriend(friends, C), null);
  assert.equal(friendLabel(friends, A), "はるか");
  assert.equal(friendLabel(friends, B), "けんた（ブロック中）");
  assert.equal(friendLabel(friends, C), C, "一覧に無い ID はそのまま");
  assert.equal(friendLabel(friends, ""), "");
});

test("countMonthSends: その月の「送信済み」だけを数える（月またぎ）", () => {
  const rows = [
    { at: "2026-08-31 23:59:59", result: "送信済み" },
    { at: "2026-09-01 00:00:00", result: "送信済み" },
    { at: "2026-09-30 23:59:59", result: "送信済み" },
    { at: "2026-10-01 00:00:00", result: "送信済み" },
    { at: "2026-09-15 12:00:00", result: "失敗" },
  ];
  assert.equal(countMonthSends(rows, "2026-09"), 2);
  assert.equal(countMonthSends(rows, "2026-08"), 1);
  assert.equal(countMonthSends(rows, "2026-10"), 1);
  assert.equal(countMonthSends([], "2026-09"), 0);
});

test("LINE の応答の言い換えと、本文の検査・断りの文", () => {
  assert.equal(lineSendError(403), "送れませんでした（LINE の応答: 403）。ブロックされているか、トークンが失効しています");
  assert.ok(lineSendError(429).startsWith("送れませんでした（LINE の応答: 429）。今月の送信数の上限"));
  assert.ok(lineSendError(401).includes("LINE チャネルアクセストークン"));
  assert.ok(lineSendError(400).includes("LINE の応答: 400"));
  assert.ok(lineSendError(500).includes("しばらくしてから"));
  assert.ok(lineSendError(0).includes("LINE につながりませんでした"));
  assert.equal(lineTextError(""), "本文を入力してください");
  assert.equal(lineTextError("  \n "), "本文を入力してください");
  assert.equal(lineTextError("あ".repeat(5000)), "");
  assert.equal(lineTextError("あ".repeat(5001)), "本文は 5,000 字以内にしてください（いまは 5,001 字）");
  assert.deepEqual(Object.keys(LINE_MESSAGES).sort(), ["blocked", "blockedChoice", "emptyIntent", "emptyText", "noColumn", "noFriend", "noToken", "notSender", "unknown", "viewer"]);
  assert.ok(Object.keys(LINE_MESSAGES).every((key) => !LINE_MESSAGES[key].includes("承ります")));
});

test("validate: LINE 型は空か U と 32 桁の 16 進", () => {
  const column = { name: "LINE", type: "LINE", options: [], required: false, defaultValue: "" };
  assert.deepEqual(checkValue(column, A), { error: "", value: A });
  assert.deepEqual(checkValue(column, ""), { error: "", value: "" });
  assert.equal(checkValue(column, "U123").error, "LINE の友だちから選んでください");
});
