import { test } from "node:test";
import assert from "node:assert/strict";
import { emptyUsage, addUsage, estimateYen, formatUsage } from "../src/usage.js";

test("usage の積み上げと目安の円", () => {
  let total = emptyUsage();
  total = addUsage(total, { input_tokens: 1000, output_tokens: 200, cache_read_input_tokens: 500, cache_creation_input_tokens: 100 });
  total = addUsage(total, null);
  assert.deepEqual(total, { count: 2, input: 1000, output: 200, cacheRead: 500, cacheWrite: 100 });
  assert.equal(estimateYen({ count: 1, input: 1e6, output: 0, cacheRead: 0, cacheWrite: 0 }, "claude-sonnet-5", 150), 300);
  assert.equal(estimateYen(total, "unknown-model", 150), null);
  const text = formatUsage(total, "claude-sonnet-5", "2026-09");
  assert.ok(text.startsWith("2026-09 の AI 利用: 2 回"));
  assert.ok(text.includes("目安"));
});
