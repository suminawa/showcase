import { test } from "node:test";
import assert from "node:assert/strict";
import { initialState, reduce, currentTable } from "../src/ui/state.js";

const BOOT = { appName: "みなと台帳", tables: [{ name: "顧客", display: "会社名", columns: [{ name: "会社名", type: "文字", options: [], inList: true, searchable: true, required: true, defaultValue: "", note: "", refTable: null }] }, { name: "対応履歴", display: "ID", columns: [] }], errors: [], user: { email: "taro@example.com", canEdit: true }, ai: true, pageSize: 20, dateFormat: "yyyy/MM/dd", today: "2026-09-16" };

test("bootstrap で最初のテーブルが選ばれる。誤りがあれば bootErrors に入る", () => {
  const s = reduce(initialState(), { type: "bootstrap", data: BOOT });
  assert.equal(s.ready, true);
  assert.equal(s.current, "顧客");
  assert.equal(s.pageSize, 20);
  assert.equal(currentTable(s).name, "顧客");
  const broken = reduce(initialState(), { type: "bootstrap", data: Object.assign({}, BOOT, { errors: ["sheet-app: x"] }) });
  assert.deepEqual(broken.bootErrors, ["sheet-app: x"]);
});

test("テーブルを切り替えると検索・条件・ページ・表示が戻る", () => {
  let s = reduce(initialState(), { type: "bootstrap", data: BOOT });
  s = reduce(s, { type: "set-q", q: "みなと" });
  s = reduce(s, { type: "add-filter", filter: { column: "会社名", op: "contains", value: "工務店" } });
  s = reduce(s, { type: "set-page", page: 3 });
  s = reduce(s, { type: "open-detail", row: { ID: "x" }, refs: {} });
  s = reduce(s, { type: "notice", message: "削除しました" });
  s = reduce(s, { type: "select-table", name: "対応履歴" });
  assert.equal(s.current, "対応履歴");
  assert.equal(s.notice, "", "テーブルを切り替えたら前のお知らせは消す");
  assert.equal(s.q, "");
  assert.deepEqual(s.filters, []);
  assert.equal(s.page, 1);
  assert.equal(s.view, null);
  assert.equal(reduce(s, { type: "select-table", name: "無い" }).current, "対応履歴");
});

test("条件・並び替え・ページ・AI の答え", () => {
  let s = reduce(initialState(), { type: "bootstrap", data: BOOT });
  s = reduce(s, { type: "add-filter", filter: { column: "会社名", op: "contains", value: "a" } });
  s = reduce(s, { type: "add-filter", filter: { column: "会社名", op: "eq", value: "b" } });
  assert.equal(s.filters.length, 2);
  assert.equal(s.page, 1);
  s = reduce(s, { type: "set-page", page: 2 });
  s = reduce(s, { type: "remove-filter", index: 0 });
  assert.deepEqual(s.filters, [{ column: "会社名", op: "eq", value: "b" }]);
  assert.equal(s.page, 1, "条件を変えると 1 ページ目に戻る");
  s = reduce(s, { type: "toggle-sort", column: "会社名" });
  assert.deepEqual(s.sort, { column: "会社名", dir: "asc" });
  s = reduce(s, { type: "toggle-sort", column: "会社名" });
  assert.deepEqual(s.sort, { column: "会社名", dir: "desc" });
  s = reduce(s, { type: "toggle-sort", column: "会社名" });
  assert.equal(s.sort, null);
  s = reduce(s, { type: "set-filters", q: "横浜", filters: [{ column: "会社名", op: "contains", value: "c" }], sort: { column: "ID", dir: "desc" } });
  assert.equal(s.q, "横浜");
  assert.equal(s.filters.length, 1);
  assert.deepEqual(s.sort, { column: "ID", dir: "desc" });
  s = reduce(s, { type: "clear-filters" });
  assert.deepEqual(s.filters, []);
  assert.equal(s.q, "");
  assert.equal(s.aiExplanation, "");
  s = reduce(s, { type: "rows", rows: [{ ID: "1" }], total: 1, refs: {}, page: 1 });
  assert.equal(s.total, 1);
  assert.equal(s.loading, false);
  s = reduce(s, { type: "filter-column", column: "会社名", options: [{ id: "1", label: "みなと工務店" }] });
  assert.equal(s.filterColumn, "会社名");
  assert.deepEqual(s.filterOptions, [{ id: "1", label: "みなと工務店" }]);
  assert.equal(reduce(s, { type: "select-table", name: "対応履歴" }).filterColumn, "", "テーブルを切り替えたら選び直す");
});

test("表示（詳細・フォーム）と誤り・CSV", () => {
  let s = reduce(initialState(), { type: "bootstrap", data: BOOT });
  s = reduce(s, { type: "open-form", isNew: true, id: "", seenUpdatedAt: "", values: { 会社名: "" }, options: {} });
  assert.equal(s.view.kind, "form");
  assert.equal(s.view.isNew, true);
  s = reduce(s, { type: "form-errors", errors: { 会社名: "会社名 を入力してください" } });
  assert.equal(s.view.errors.会社名, "会社名 を入力してください");
  s = reduce(s, { type: "form-values", values: { 会社名: "みなと工務店" } });
  assert.equal(s.view.values.会社名, "みなと工務店");
  s = reduce(s, { type: "open-detail", row: { ID: "1" }, refs: { 顧客: "x" } });
  assert.equal(s.view.kind, "detail");
  s = reduce(s, { type: "summary-loading", on: true });
  assert.equal(s.view.summaryLoading, true);
  s = reduce(s, { type: "summary", text: "要約" });
  assert.equal(s.view.summary, "要約");
  assert.equal(s.view.summaryLoading, false);
  s = reduce(s, { type: "error", message: "だめ" });
  assert.equal(s.error, "だめ");
  assert.equal(s.loading, false);
  s = reduce(s, { type: "close" });
  assert.equal(s.view, null);
  s = reduce(s, { type: "csv", text: "a,b" });
  assert.equal(s.csv, "a,b");
  s = reduce(s, { type: "csv", text: null });
  assert.equal(s.csv, null);
  assert.equal(reduce(s, { type: "unknown" }), s);
});
