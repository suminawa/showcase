import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { LINE_SETTING_KEYS } from "../src/settings.js";
import { DEFAULT_NOTIFY_TEMPLATE } from "../src/notify.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const readme = readFileSync(join(root, "README.ja.md"), "utf8");
const settingsCsv = readFileSync(join(root, "samples", "設定.csv"), "utf8");
const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");

test("README に 1.1 の章（通知・LINE 送信・1.0 からの上げ方）が、9 章の後ろ・ライセンスの前に並ぶ", () => {
  let at = -1;
  for (const heading of ["## 9. 更新履歴", "## 10. 通知（任意）", "## 11. お客さまへの LINE 送信（任意）", "## 12. 1.0 からの上げ方", "## ライセンス"]) {
    const found = readme.indexOf(heading);
    assert.ok(found > at, heading);
    at = found;
  }
});

test("設定の追加行が README の表と samples/設定.csv の両方にあり、型 LINE・既定の文面・webhook・シート名・限界が書いてある", () => {
  for (const key of LINE_SETTING_KEYS) {
    assert.ok(readme.includes("| " + key + " |"), "README: " + key);
    assert.ok(settingsCsv.includes("\r\n" + key + ","), "設定.csv: " + key);
  }
  assert.ok(readme.includes("型は次の 14 種類です"));
  assert.ok(readme.includes("`URL` `LINE` `参照:<テーブル名>`"));
  for (const line of DEFAULT_NOTIFY_TEMPLATE.split("\n")) assert.ok(readme.includes(line), line);
  for (const phrase of ["?hook=line", "_LINE友だち", "_LINE送信履歴", "_通知ログ", "次のユーザーとして実行「自分」", "アクセスできるユーザー「全員」", "署名", "未確認", "LINE 窓口キット", "取り消せません", "月 200 通", "通知のテストを送る", "60 字", "ほか n 列", "5,000 字", "LINE を送れる人", "AI で下書き", "画面の URL", "今の友だちの状態は変わりません", "100 件まで", "送り直さないでください", "必ず画面用のデプロイの URL"]) {
    assert.ok(readme.includes(phrase), phrase);
  }
  assert.equal(/[¥￥]\s?\d/.test(readme), false, "価格は README に書かない");
});

test("CHANGELOG の先頭は 1.1.0 で、無料の更新と足した機能を書いている", () => {
  const top = changelog.indexOf("## 1.1.0");
  assert.ok(top >= 0 && top < changelog.indexOf("## 1.0.0"));
  const section = changelog.slice(top, changelog.indexOf("## 1.0.0"));
  for (const phrase of ["無料で更新", "_通知ログ", "LINE で送る", "_LINE送信履歴", "`LINE`", "#<テーブル>/<ID>"]) assert.ok(section.includes(phrase), phrase);
});
