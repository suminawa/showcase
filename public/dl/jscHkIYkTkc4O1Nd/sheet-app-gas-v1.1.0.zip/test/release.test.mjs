import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("版の表記がそろっている（package.json・CHANGELOG の先頭・README の zip 名）", () => {
  const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
  assert.equal(pkg.version, "1.1.0");
  const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");
  assert.equal(changelog.match(/^## (\d+\.\d+\.\d+)/m)[1], pkg.version);
  const readme = readFileSync(join(root, "README.ja.md"), "utf8");
  assert.ok(readme.includes("release/sheet-app-gas-v" + pkg.version + ".zip"));
  assert.equal(readme.includes("sheet-app-gas-v1.0.0.zip"), false);
});
