import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_LINE_TEMPLATE_TEXT, DEFAULT_SETTINGS, LINE_SETTING_KEYS, SETTING_KEYS, crossCheckSettings, parseSettings, settingsSummary } from "../src/settings.js";
import { DEFAULT_NOTIFY_TEMPLATE } from "../src/notify.js";
import { lineColumn, parseDefinition } from "../src/definition.js";
import { SETTINGS_ROWS, TEMPLATES } from "../src/samples.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const SLACK = "https://hooks.slack.com/services/T000/B000/XXXX";

test("1.1 の行: 項目名の並びと既定値。1.0 の 7 行はそのまま", () => {
  assert.equal(SETTING_KEYS.length, 7);
  assert.deepEqual(LINE_SETTING_KEYS, ["通知先", "Slack Webhook URL", "Discord Webhook URL", "LINE チャネルアクセストークン", "LINE 送信先 ID", "通知するテーブル", "通知する操作", "自分の操作は通知しない", "通知の文面", "LINE 定型文", "LINE を送れる人", "担当者名", "画面の URL"]);
  const { settings, errors, notifyErrors } = parseSettings([]);
  assert.deepEqual(errors, []);
  assert.deepEqual(notifyErrors, []);
  assert.deepEqual(settings.notifyTargets, []);
  assert.deepEqual(settings.notifyTables, []);
  assert.deepEqual(settings.notifyOps, ["登録", "更新", "削除"]);
  assert.equal(settings.skipOwn, false);
  assert.equal(settings.notifyTemplate, DEFAULT_NOTIFY_TEMPLATE);
  assert.equal(settings.lineTemplateText, DEFAULT_LINE_TEMPLATE_TEXT);
  assert.deepEqual(settings.lineSenders, []);
  assert.equal(settings.staffName, "");
  assert.equal(settings.appUrl, "");
  assert.deepEqual(settings, DEFAULT_SETTINGS);
  const lines = DEFAULT_LINE_TEMPLATE_TEXT.split("\n");
  assert.deepEqual(lines.map((line) => line.split("|")[0]), ["お礼", "打ち合わせの確認", "資料のご案内"]);
  assert.ok(lines.every((line) => line.includes("{担当者名}") && line.includes("\\n")));
});

test("値を読む（空白の揺れ・大文字小文字・重複は吸収）", () => {
  const { settings, errors, notifyErrors } = parseSettings([
    ["通知先", "Slack, line, slack"],
    ["Slack Webhook URL", SLACK],
    ["LINE チャネルアクセストークン", "line-token"],
    ["LINE送信先ID", "U" + "f".repeat(32)],
    ["通知するテーブル", "顧客、案件"],
    ["通知する操作", "登録, 削除"],
    ["自分の操作は通知しない", "TRUE"],
    ["通知の文面", "【{アプリ名}】{操作}\n{URL}"],
    ["LINE 定型文", "お礼|ありがとうございました。"],
    ["LINE を送れる人", "Taro@Example.com, hanako@example.com"],
    ["担当者名", "山田"],
  ]);
  assert.deepEqual(errors, []);
  assert.deepEqual(notifyErrors, []);
  assert.deepEqual(settings.notifyTargets, ["slack", "line"]);
  assert.equal(settings.slackWebhookUrl, SLACK);
  assert.equal(settings.lineToken, "line-token");
  assert.equal(settings.lineTo, "U" + "f".repeat(32));
  assert.deepEqual(settings.notifyTables, ["顧客", "案件"]);
  assert.deepEqual(settings.notifyOps, ["登録", "削除"]);
  assert.equal(settings.skipOwn, true);
  assert.equal(settings.notifyTemplate, "【{アプリ名}】{操作}\n{URL}");
  assert.equal(settings.lineTemplateText, "お礼|ありがとうございました。");
  assert.deepEqual(settings.lineSenders, ["taro@example.com", "hanako@example.com"]);
  assert.equal(settings.staffName, "山田");
});

test("通知・LINE の誤りは notifyErrors に（画面を止める errors には入れない）。文はフォーム受付キットと同じ", () => {
  const { errors, notifyErrors, settings } = parseSettings([["通知先", "slak, line, discord"], ["Discord Webhook URL", "http://example.com/hook"], ["通知する操作", "登録, 閲覧"]]);
  assert.deepEqual(errors, []);
  assert.deepEqual(notifyErrors, [
    "「通知先」に書けるのは slack / discord / line です: slak",
    "「通知する操作」に書けるのは 登録・更新・削除 です: 閲覧",
    "「通知先」に line がありますが、「LINE チャネルアクセストークン」が空です。設定シートのその行を埋めてください。",
    "「通知先」に line がありますが、「LINE 送信先 ID」が空です。設定シートのその行を埋めてください。",
    "「Discord Webhook URL」は https:// で始まる URL です。設定シートのその行を確かめてください。",
  ]);
  assert.deepEqual(settings.notifyTargets, ["line", "discord"]);
  assert.deepEqual(settings.notifyOps, ["登録"]);
});

test("crossCheckSettings は定義に無いテーブル名を知らせる。settingsSummary は通知と LINE の状態を敬体で 2 行", () => {
  const { tables } = parseDefinition([HEADER, ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""], ["顧客", "LINE", "LINE", "", "", "FALSE", "", "", ""]]);
  const { settings } = parseSettings([["通知先", "slack"], ["Slack Webhook URL", SLACK], ["通知するテーブル", "顧客, 案件"]]);
  assert.deepEqual(crossCheckSettings(settings, tables), ["設定「通知するテーブル」の「案件」は定義にありません。定義のテーブル名と同じに書いてください"]);
  assert.deepEqual(settingsSummary(settings, tables), [
    "通知: slack に、顧客・案件の登録・更新・削除を知らせます",
    "お客さまへの LINE 送信: 定義に LINE の列がありますが、設定「LINE チャネルアクセストークン」が空のため使えません。使うときは設定シートのその行を埋めてください",
  ]);
  const withToken = parseSettings([["LINE チャネルアクセストークン", "line-token"]]).settings;
  assert.deepEqual(settingsSummary(withToken, tables), ["通知: 使っていません（設定「通知先」が空です）", "お客さまへの LINE 送信: 使えます（顧客「LINE」）"]);
  assert.equal(settingsSummary(withToken, [])[1], "お客さまへの LINE 送信: 定義に LINE の列がないため使っていません");
  const all = parseSettings([["通知先", "slack"], ["Slack Webhook URL", SLACK]]).settings;
  assert.equal(settingsSummary(all, tables)[0], "通知: slack に、すべてのテーブルの登録・更新・削除を知らせます");
});

test("設定の見本（samples.js）に 1.1 の 13 行が既定値で並び、見本の顧客に空の LINE の列がある", () => {
  assert.deepEqual(SETTINGS_ROWS.map((row) => row[0]).slice(-13), LINE_SETTING_KEYS);
  const values = {};
  SETTINGS_ROWS.forEach((row) => {
    values[row[0]] = row[1];
  });
  assert.equal(values["通知の文面"], DEFAULT_NOTIFY_TEMPLATE);
  assert.equal(values["LINE 定型文"], DEFAULT_LINE_TEMPLATE_TEXT);
  assert.equal(values["通知する操作"], "登録, 更新, 削除");
  assert.equal(values["自分の操作は通知しない"], "FALSE");
  assert.equal(values["画面の URL"], "");
  const customers = parseDefinition(TEMPLATES["顧客管理"].definition).tables[0];
  assert.deepEqual(customers.columns.map((c) => c.name), ["会社名", "担当者", "業種", "状況", "メール", "電話", "LINE", "住所", "最終連絡日", "年間取引額", "要注意", "メモ"]);
  assert.equal(lineColumn(customers).inList, false);
  assert.ok(TEMPLATES["顧客管理"].tables.顧客.every((row) => row.LINE === ""));
});

test("画面の URL: https:// なら使い（# 以降は落とす）、空なら既定の空。https:// でなければ notifyErrors に入れて使わない", () => {
  const app = "https://script.google.com/macros/s/SCREEN/exec";
  assert.equal(parseSettings([["画面の URL", app]]).settings.appUrl, app);
  assert.equal(parseSettings([["画面のURL", app + "#顧客/1"]]).settings.appUrl, app);
  assert.equal(parseSettings([["画面の URL", ""]]).settings.appUrl, "");
  const bad = parseSettings([["画面の URL", "http://example.com/exec"]]);
  assert.equal(bad.settings.appUrl, "");
  assert.deepEqual(bad.errors, []);
  assert.deepEqual(bad.notifyErrors, ["「画面の URL」は https:// で始まる URL です（画面用のデプロイの URL を貼ってください）。いまは使わずに、Apps Script が返す URL で通知します"]);
});
