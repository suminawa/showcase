import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { fillLineTemplate } from "../src/line.js";
import { hashFor, initialState, parseHash, reduce } from "../src/ui/state.js";
import { detailValues, labelFor, lineConfirmText, remainingText, renderApp, renderDetail, renderForm, renderLineHistory } from "../src/ui/render.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "担当者", "文字", "", "", "", "", "", ""],
  ["顧客", "LINE", "LINE", "", "", "", "", "", ""],
  ["メモ帳", "本文", "長文", "", "", "", "", "", ""],
]);
const T = tables[0];
const M = tables[1];
const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const C = "U" + "c".repeat(32);
const FRIENDS = [{ id: B, name: "けんた", blocked: true }, { id: A, name: "はるか", blocked: false }];
const TEMPLATES = [{ title: "お礼", body: "{会社名} {担当者} 様\n\n{担当者名}です。" }, { title: "資料のご案内", body: "資料をお送りします。" }];
const LINE = { enabled: true, friends: FRIENDS, templates: TEMPLATES, canSend: true, monthCount: 3, staffName: "山田" };
const ROW = { ID: "20260916-001", 会社名: "みなと<工務店>", 担当者: "山川", LINE: A, 作成日時: "2026-09-16 10:00:00", 更新日時: "2026-09-16 10:00:00", 更新者: "taro@example.com" };
const VIEW = { kind: "detail", id: ROW.ID, row: ROW, refs: {}, summary: "", summaryLoading: false, history: [], lineOpen: false, lineText: "", lineIntent: "", lineError: "", lineSending: false, lineDrafting: false };
const BOOT = { appName: "みなと台帳", tables: tables, errors: [], user: { email: "taro@example.com", canEdit: true }, ai: true, pageSize: 50, dateFormat: "yyyy-MM-dd", today: "2026-09-16", line: LINE };

function detail(row, extra, view) {
  return renderDetail(T, row, {}, Object.assign({ dateFormat: "yyyy-MM-dd", canEdit: true, ai: false, summary: "", summaryLoading: false, friends: FRIENDS, line: LINE, view: Object.assign({}, VIEW, { row: row }, view || {}) }, extra || {}));
}

test("LINE の列は友だちの表示名で出す。ブロック中は印を添え、知らない ID はそのまま", () => {
  const column = T.columns[2];
  assert.equal(labelFor(column, A, {}, { friends: FRIENDS }), "はるか");
  assert.equal(labelFor(column, B, {}, { friends: FRIENDS }), "けんた（ブロック中）");
  assert.equal(labelFor(column, C, {}, { friends: FRIENDS }), C);
  assert.equal(labelFor(column, "", {}, { friends: FRIENDS }), "");
  assert.equal(labelFor(column, A, {}, {}), A, "友だちの一覧が無ければ ID のまま");
  assert.ok(detail(ROW).includes("<dd>はるか</dd>"));
});

test("「LINE で送る」は、送れる人で、LINE の列にブロック中でない友だちが結びついているときだけ出る", () => {
  assert.ok(detail(ROW).includes('data-action="line-open"'));
  assert.ok(detail(ROW).includes(">LINE で送る</button>"));
  assert.equal(detail(Object.assign({}, ROW, { LINE: "" })).includes('data-action="line-open"'), false, "LINE の列が空");
  assert.equal(detail(Object.assign({}, ROW, { LINE: B })).includes('data-action="line-open"'), false, "ブロック中");
  assert.equal(detail(Object.assign({}, ROW, { LINE: C })).includes('data-action="line-open"'), false, "友だちの一覧に無い");
  assert.equal(detail(ROW, { canEdit: false, line: Object.assign({}, LINE, { canSend: false }) }).includes('data-action="line-open"'), false, "閲覧者");
  const memo = renderDetail(M, { ID: "1", 本文: "x" }, {}, { canEdit: true, ai: false, friends: FRIENDS, line: LINE, view: {} });
  assert.equal(memo.includes("LINE"), false, "LINE の列が無いテーブルには何も出さない");
});

test("送信の欄: 定型文・AI で下書き（AI があるとき）・本文・残り字数・今月の送信数・誤り・印の残り・送信中", () => {
  assert.equal(detail(ROW, { ai: true }).includes('data-field="line-text"'), false, "押すまでは開かない");
  const html = detail(ROW, { ai: true }, { lineOpen: true, lineText: "こんにちは", lineError: "送れませんでした（LINE の応答: 403）。ブロックされているか、トークンが失効しています" });
  assert.ok(html.includes('aria-expanded="true"'));
  assert.ok(html.includes("送り先: はるか さん。今月の送信数: 3 通"));
  assert.ok(html.includes('<select data-field="line-template"'));
  assert.ok(html.includes('<option value="0">お礼</option>') && html.includes('<option value="1">資料のご案内</option>'));
  assert.ok(html.includes('data-field="line-intent"') && html.includes('data-action="line-draft"') && html.includes("AI で下書き"));
  assert.ok(html.includes('<textarea data-field="line-text"') && html.includes(">こんにちは</textarea>"));
  assert.ok(html.includes('maxlength="5000"'));
  assert.ok(html.includes("残り 4,995 字"));
  assert.ok(html.includes('role="alert"') && html.includes("LINE の応答: 403"));
  assert.ok(html.includes('data-action="line-send"'));
  assert.equal(detail(ROW, { ai: false }, { lineOpen: true }).includes('data-action="line-draft"'), false, "AI が無ければ下書きのボタンは出ない");
  assert.ok(detail(ROW, {}, { lineOpen: true, lineText: "{会社名} 様 {無い印}" }).includes("置き換わっていない印があります: {会社名} {無い印}"));
  assert.ok(detail(ROW, {}, { lineOpen: true, lineSending: true }).includes("送っています…"));
});

test("確認の文と残り字数", () => {
  assert.equal(lineConfirmText("はるか"), "はるか さんの LINE に送ります。送ったあとは取り消せません。よろしいですか？");
  assert.equal(lineConfirmText(""), "この方の LINE に送ります。送ったあとは取り消せません。よろしいですか？");
  assert.equal(remainingText(""), "残り 5,000 字");
  assert.equal(remainingText("あ".repeat(5001)), "1 字多すぎます");
});

test("送信履歴: LINE の列があるテーブルの詳細の下に。閲覧者にも出る。中身はエスケープ", () => {
  const history = [{ at: "2026-09-16 10:40:00", sender: "taro@example.com", text: "<b>こんにちは</b>\n2 行目", result: "送信済み" }];
  const html = detail(ROW, { canEdit: false, line: Object.assign({}, LINE, { canSend: false }) }, { history: history });
  assert.ok(html.includes("LINE の送信履歴"));
  assert.ok(html.includes("2026-09-16 10:40:00 taro@example.com"));
  assert.ok(html.includes("&lt;b&gt;こんにちは&lt;/b&gt;"));
  assert.ok(renderLineHistory([]).includes("まだ送っていません"));
});

test("フォームの LINE の欄: ブロック中でない友だちを表示名で選ぶ。いまの値はブロック中でも残す。多いときは探す欄", () => {
  const html = renderForm(T, { 会社名: "", 担当者: "", LINE: "" }, {}, {}, { isNew: true, id: "", friends: FRIENDS });
  assert.ok(html.includes('<select name="LINE" id="sa-f-LINE">'));
  assert.ok(html.includes('<option value="' + A + '">はるか</option>'));
  assert.equal(html.includes(B), false, "ブロック中の方は新しくは選べない");
  const kept = renderForm(T, { LINE: B }, {}, {}, { isNew: false, id: "1", friends: FRIENDS });
  assert.ok(kept.includes('<option value="' + B + '" selected>けんた（ブロック中）</option>'));
  const unknown = renderForm(T, { LINE: C }, {}, {}, { isNew: false, id: "1", friends: FRIENDS });
  assert.ok(unknown.includes('<option value="' + C + '" selected>' + C + "</option>"));
  assert.ok(renderForm(T, {}, {}, {}, { isNew: true, id: "", friends: [] }).includes("友だちがまだいません"));
  const many = [];
  for (let i = 0; i < 501; i += 1) many.push({ id: "U" + String(i).padStart(32, "0"), name: "友だち" + i, blocked: false });
  assert.ok(renderForm(T, {}, {}, {}, { isNew: true, id: "", friends: many }).includes('data-line-search="LINE"'));
  assert.equal(renderForm(T, {}, {}, {}, { isNew: true, id: "", friends: FRIENDS }).includes("data-line-search"), false);
});

test("状態: bootstrap の line、詳細の送信欄の出し入れ、送ったあと", () => {
  let s = reduce(initialState(), { type: "bootstrap", data: BOOT });
  assert.deepEqual(s.line, LINE);
  assert.deepEqual(reduce(initialState(), { type: "bootstrap", data: {} }).line, { enabled: false, friends: [], templates: [], canSend: false, monthCount: 0, staffName: "" });
  s = reduce(s, { type: "open-detail", row: ROW, refs: {}, history: [{ at: "a", sender: "b", text: "c", result: "送信済み" }] });
  assert.equal(s.view.history.length, 1);
  assert.equal(s.view.lineOpen, false);
  s = reduce(s, { type: "line-toggle" });
  assert.equal(s.view.lineOpen, true);
  s = reduce(s, { type: "line-text", text: "こんにちは" });
  s = reduce(s, { type: "line-intent", text: "お礼" });
  assert.equal(s.view.lineText, "こんにちは");
  assert.equal(s.view.lineIntent, "お礼");
  s = reduce(s, { type: "line-drafting", on: true });
  assert.equal(s.view.lineDrafting, true);
  s = reduce(s, { type: "line-error", message: "だめでした" });
  assert.equal(s.view.lineError, "だめでした");
  assert.equal(s.view.lineDrafting, false);
  s = reduce(s, { type: "line-sending", on: true });
  assert.equal(s.view.lineSending, true);
  assert.equal(s.view.lineError, "");
  s = reduce(s, { type: "line-sent", history: [{ at: "d", sender: "e", text: "f", result: "送信済み" }, { at: "a", sender: "b", text: "c", result: "送信済み" }], monthCount: 4 });
  assert.equal(s.view.history.length, 2);
  assert.equal(s.view.lineText, "");
  assert.equal(s.view.lineOpen, false);
  assert.equal(s.view.lineSending, false);
  assert.equal(s.line.monthCount, 4);
  assert.equal(reduce(reduce(s, { type: "close" }), { type: "line-text", text: "x" }).view, null, "詳細が閉じていれば何もしない");
});

test("ハッシュ #<テーブル>/<ID> で詳細を開く: parseHash と hashFor", () => {
  assert.equal(hashFor("顧客", "20260916-001"), "%E9%A1%A7%E5%AE%A2/20260916-001");
  assert.deepEqual(parseHash("#%E9%A1%A7%E5%AE%A2/20260916-001"), { table: "顧客", id: "20260916-001" });
  assert.deepEqual(parseHash("顧客/20260916-001"), { table: "顧客", id: "20260916-001" }, "# なし・エンコードなしでも読む");
  assert.equal(parseHash(""), null);
  assert.equal(parseHash("顧客"), null);
  assert.equal(parseHash("顧客/"), null);
  assert.equal(parseHash("/20260916-001"), null);
  assert.equal(parseHash("%E9%A1/1"), null, "壊れたエンコードは読まない");
});

test("定型文の置き換え: 詳細に出ている値と担当者名", () => {
  const values = detailValues(T, ROW, {}, { dateFormat: "yyyy-MM-dd", friends: FRIENDS });
  assert.equal(values.LINE, "はるか");
  assert.equal(fillLineTemplate(TEMPLATES[0].body, { values: values, staffName: LINE.staffName }), "みなと<工務店> 山川 様\n\n山田です。");
});

test("renderApp: 詳細を開くと「LINE で送る」と送信履歴が出る", () => {
  let s = reduce(initialState(), { type: "bootstrap", data: BOOT });
  s = reduce(s, { type: "open-detail", row: ROW, refs: {}, history: [] });
  const html = renderApp(s);
  assert.ok(html.includes('data-action="line-open"'));
  assert.ok(html.includes("LINE の送信履歴"));
  assert.ok(html.includes("まだ送っていません"));
});
