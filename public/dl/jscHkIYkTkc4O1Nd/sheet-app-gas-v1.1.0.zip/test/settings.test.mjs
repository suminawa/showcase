import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_SETTINGS, SETTING_KEYS, parseSettings } from "../src/settings.js";

test("空なら既定値。知らない行は無視", () => {
  const { settings, errors } = parseSettings([["項目", "値"], ["何か", "x"]]);
  assert.deepEqual(errors, []);
  assert.deepEqual(settings, DEFAULT_SETTINGS);
  assert.equal(SETTING_KEYS.length, 7);
});

test("値を読む。編集できる人は小文字にし、空白の違いは無視する", () => {
  const { settings, errors } = parseSettings([
    ["アプリ名", "みなと工務店 顧客台帳"],
    ["編集できる人", "Taro@Example.com, hanako@example.com"],
    ["1ページの件数", 100],
    ["日付の書式", "yyyy/MM/dd"],
    ["AI を使う", "FALSE"],
    ["モデル", "claude-opus-5"],
    ["AI の 1 日の上限", "50"],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(settings.appName, "みなと工務店 顧客台帳");
  assert.deepEqual(settings.editors, ["taro@example.com", "hanako@example.com"]);
  assert.equal(settings.pageSize, 100);
  assert.equal(settings.dateFormat, "yyyy/MM/dd");
  assert.equal(settings.aiEnabled, false);
  assert.equal(settings.model, "claude-opus-5");
  assert.equal(settings.aiDailyLimit, 50);
  assert.equal(parseSettings([["1 ページの件数", "１００"]]).settings.pageSize, 100, "全角の数字も読む");
});

test("範囲外は敬体の誤りにして既定値のまま", () => {
  const { settings, errors } = parseSettings([["1 ページの件数", "5"], ["日付の書式", "dd/MM/yyyy"], ["AI の 1 日の上限", "0"]]);
  assert.equal(errors.length, 3);
  assert.ok(errors[0].includes("10〜200"));
  assert.ok(errors[1].includes("yyyy-MM-dd か yyyy/MM/dd"));
  assert.ok(errors[2].includes("1〜10000"));
  assert.equal(settings.pageSize, 50);
  assert.equal(settings.dateFormat, "yyyy-MM-dd");
  assert.equal(settings.aiDailyLimit, 200);
});
