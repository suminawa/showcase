import { test } from "node:test";
import assert from "node:assert/strict";
import { LINE_TYPE, TYPES, lineColumn, parseDefinition } from "../src/definition.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];

test("型 LINE を読む（小文字でも）。検索の既定は FALSE。lineColumn で引ける。TYPES は 1.0 のまま", () => {
  const { tables, errors } = parseDefinition([
    HEADER,
    ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
    ["顧客", "LINE", "line", "", "", "FALSE", "", "", "友だちから選びます"],
    ["案件", "案件名", "文字", "", "", "", "", "", ""],
  ]);
  assert.deepEqual(errors, []);
  assert.equal(LINE_TYPE, "LINE");
  const column = lineColumn(tables[0]);
  assert.equal(column.name, "LINE");
  assert.equal(column.type, "LINE");
  assert.equal(column.inList, false);
  assert.equal(column.searchable, false);
  assert.equal(column.refTable, null);
  assert.equal(column.note, "友だちから選びます");
  assert.equal(tables[0].display, "会社名");
  assert.equal(lineColumn(tables[1]), null);
  assert.deepEqual(TYPES, ["文字", "長文", "数値", "金額", "日付", "日時", "選択", "複数選択", "チェック", "メール", "電話", "URL"]);
});

test("LINE の列は 1 テーブルに 1 つまで。型の誤りの文に LINE が並ぶ", () => {
  const { tables, errors } = parseDefinition([
    HEADER,
    ["顧客", "LINE", "LINE", "", "", "", "", "", ""],
    ["顧客", "LINE2", "LINE", "", "", "", "", "", ""],
    ["顧客", "番号", "整数", "", "", "", "", "", ""],
  ]);
  assert.equal(errors.length, 2);
  assert.equal(errors[0], "sheet-app: 定義の 3 行目: テーブル「顧客」の LINE の列は 1 つまでです（すでに「LINE」があります）");
  assert.ok(errors[1].includes("・URL・LINE・参照:<テーブル名> のいずれかにしてください"));
  assert.deepEqual(tables[0].columns.map((c) => c.name), ["LINE"]);
});
