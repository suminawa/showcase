import { test } from "node:test";
import assert from "node:assert/strict";
import { textOf, boolOf, pad2 } from "../src/text.js";

test("textOf: 前後の空白を落とした文字。null / undefined は空", () => {
  assert.equal(textOf(" a "), "a");
  assert.equal(textOf(null), "");
  assert.equal(textOf(undefined), "");
  assert.equal(textOf(0), "0");
});

test("boolOf: TRUE / FALSE / はい / いいえ / 1 / 0 / ○ / ×。空や読めない字は fallback", () => {
  assert.equal(boolOf(true, false), true);
  assert.equal(boolOf("true", false), true);
  assert.equal(boolOf(" はい ", false), true);
  assert.equal(boolOf("○", false), true);
  assert.equal(boolOf("1", false), true);
  assert.equal(boolOf("FALSE", true), false);
  assert.equal(boolOf("いいえ", true), false);
  assert.equal(boolOf("×", true), false);
  assert.equal(boolOf("0", true), false);
  assert.equal(boolOf("", true), true);
  assert.equal(boolOf("たぶん", false), false);
});

test("pad2", () => {
  assert.equal(pad2(3), "03");
  assert.equal(pad2(12), "12");
});
