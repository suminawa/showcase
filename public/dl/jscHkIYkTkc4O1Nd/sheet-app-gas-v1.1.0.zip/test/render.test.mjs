import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { initialState, reduce } from "../src/ui/state.js";
import { escapeHtml, labelFor, renderApp, renderTable, renderCards, renderDetail, renderForm, renderFilterChips, renderFilterPanel, renderPager, renderTabs, OP_LABELS } from "../src/ui/render.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", "法人名"],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "分野", "複数選択", "", "設計, 施工", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "", ""],
  ["顧客", "サイト", "URL", "", "", "FALSE", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "FALSE", "", "", ""],
  ["対応履歴", "顧客", "参照:顧客", "TRUE", "", "", "", "", ""],
  ["対応履歴", "内容", "長文", "TRUE", "", "", "", "", ""],
]);
const T = tables[0];
const H = tables[1];
const ROW = { ID: "20260901-001", 会社名: "みなと<工務店>", 状況: "取引中", 分野: ["設計"], 年間取引額: 1200000, 最終連絡日: "2026-09-10", 要注意: true, サイト: "https://example.com/?a=1&b=2", メモ: "あ".repeat(60), 作成日時: "2026-09-01 10:00:00", 更新日時: "2026-09-10 10:00:00", 更新者: "taro@example.com" };
const OPTS = { dateFormat: "yyyy/MM/dd" };

function booted(extra) {
  return reduce(initialState(), { type: "bootstrap", data: Object.assign({ appName: "みなと台帳", tables: tables, errors: [], user: { email: "taro@example.com", canEdit: true }, ai: true, pageSize: 50, dateFormat: "yyyy/MM/dd", today: "2026-09-16" }, extra || {}) });
}

test("escapeHtml と labelFor", () => {
  assert.equal(escapeHtml('<a href="x">&\'</a>'), "&lt;a href=&quot;x&quot;&gt;&amp;&#39;&lt;/a&gt;");
  assert.equal(labelFor(H.columns[0], "20260901-001", { 顧客: { "20260901-001": "みなと工務店" } }, OPTS), "みなと工務店");
  assert.equal(labelFor(H.columns[0], "20260901-999", { 顧客: {} }, OPTS), "20260901-999");
  assert.equal(labelFor(T.columns[3], 1200000, {}, OPTS), "¥1,200,000");
});

test("表: 一覧 TRUE の列だけ、値はエスケープ、長文は 40 字で切る、並び替えの印、行に data-id", () => {
  const html = renderTable(T, [ROW], {}, { column: "会社名", dir: "desc" }, OPTS);
  assert.ok(html.includes('data-action="sort" data-column="会社名"'));
  assert.ok(html.includes("aria-sort=\"descending\""));
  assert.ok(html.includes("みなと&lt;工務店&gt;"));
  assert.equal(html.includes("<工務店>"), false);
  assert.equal(html.includes("サイト"), false, "一覧 FALSE の列は出ない");
  assert.ok(html.includes("¥1,200,000"));
  assert.ok(html.includes("2026/09/10"));
  assert.ok(html.includes('data-action="open" data-id="20260901-001"'));
  assert.equal(html.includes("あ".repeat(41)), false);
  // 一覧に出る 長文 の列は 40 字 + … に切る
  const { tables: notes } = parseDefinition([HEADER, ["記録", "本文", "長文", "", "", "TRUE", "", "", ""]]);
  const long = renderTable(notes[0], [{ ID: "1", 本文: "あ".repeat(60) }], {}, null, OPTS);
  assert.ok(long.includes("あ".repeat(40) + "…"));
  assert.equal(long.includes("あ".repeat(41)), false);
  const cards = renderCards(T, [ROW], {}, OPTS);
  assert.ok(cards.includes('class="sa-card"'));
  assert.ok(cards.includes("みなと&lt;工務店&gt;"));
  assert.ok(cards.includes('data-action="open" data-id="20260901-001"'));
});

test("詳細: 全列、URL はリンク、参照は表示名、編集者にはボタン、AI があれば要約ボタン", () => {
  const html = renderDetail(T, ROW, {}, Object.assign({ canEdit: true, ai: true, summary: "", summaryLoading: false }, OPTS));
  assert.ok(html.includes('href="https://example.com/?a=1&amp;b=2"'));
  // http(s) 以外の URL はリンクにしない（シートに直接書かれた javascript: を実行させない）
  const unsafe = renderDetail(T, Object.assign({}, ROW, { サイト: "javascript:alert(1)" }), {}, Object.assign({ canEdit: false, ai: false, summary: "", summaryLoading: false }, OPTS));
  assert.equal(unsafe.includes('href="javascript:'), false);
  assert.ok(unsafe.includes("javascript:alert(1)"));
  assert.ok(html.includes("あ".repeat(60)));
  assert.ok(html.includes('data-action="edit"'));
  assert.ok(html.includes('data-action="delete"'));
  assert.ok(html.includes('data-action="ai-summary"'));
  assert.ok(html.includes("taro@example.com"));
  const viewer = renderDetail(T, ROW, {}, Object.assign({ canEdit: false, ai: false, summary: "要約です", summaryLoading: false }, OPTS));
  assert.equal(viewer.includes('data-action="edit"'), false);
  assert.equal(viewer.includes('data-action="ai-summary"'), false);
  assert.ok(viewer.includes("要約です"));
  const ref = renderDetail(H, { ID: "1", 顧客: "20260901-001", 内容: "x", 作成日時: "", 更新日時: "", 更新者: "" }, { 顧客: "みなと工務店" }, Object.assign({ canEdit: true, ai: false }, OPTS));
  assert.ok(ref.includes("みなと工務店"));
});

test("フォーム: 型ごとの入力欄、必須の印、説明、誤りは欄の下に aria-describedby で、参照は候補の select", () => {
  const html = renderForm(T, { 会社名: "", 状況: "見込み", 分野: ["設計"], 年間取引額: 1200, 最終連絡日: "2026-09-10", 要注意: true, サイト: "", メモ: "" }, { 会社名: "会社名 を入力してください" }, {}, { isNew: true, id: "" });
  assert.ok(html.includes('data-form="record"'));
  assert.ok(html.includes('name="会社名"') && html.includes("必須"));
  assert.ok(html.includes("法人名"));
  assert.ok(html.includes('aria-describedby="sa-err-会社名"') && html.includes('id="sa-err-会社名"') && html.includes("会社名 を入力してください"));
  assert.ok(html.includes('aria-invalid="true"'));
  assert.ok(html.includes('<select name="状況"') && html.includes('<option value="取引中">'));
  assert.ok(html.includes('type="checkbox" name="分野" value="設計" checked'));
  assert.ok(html.includes('type="checkbox" name="分野" value="施工"') && !html.includes('value="施工" checked'));
  assert.ok(html.includes('inputmode="numeric"') && html.includes('name="年間取引額"') && html.includes('value="1200"'));
  assert.ok(html.includes('type="date" name="最終連絡日"') && html.includes('value="2026-09-10"'));
  assert.ok(html.includes('type="checkbox" name="要注意" id="sa-f-要注意" checked'));
  assert.ok(html.includes('type="url" name="サイト"'));
  assert.ok(html.includes('<textarea name="メモ"'));
  assert.ok(html.includes("登録"));
  const edit = renderForm(H, { 顧客: "20260901-001", 内容: "" }, {}, { 顧客: [{ id: "20260901-001", label: "みなと工務店" }, { id: "20260901-002", label: "うみかぜ商店" }] }, { isNew: false, id: "1" });
  assert.ok(edit.includes('<select name="顧客"') && edit.includes('<option value="20260901-001" selected>みなと工務店</option>'));
  assert.ok(edit.includes("保存"));
});

test("条件のチップ・条件の追加・ページ送り・タブ", () => {
  const chips = renderFilterChips(T, [{ column: "状況", op: "in", value: ["見込み", "休眠"] }, { column: "年間取引額", op: "between", value: ["1000", "2000"] }, { column: "最終連絡日", op: "empty", value: "" }, { column: "要注意", op: "eq", value: "はい" }], {});
  assert.ok(chips.includes("要注意 が はい"), "チェックの値は はい / いいえ で出す");
  assert.ok(chips.includes("状況 が 見込み、休眠 のいずれか"));
  assert.ok(chips.includes("年間取引額 が 1000〜2000"));
  assert.ok(chips.includes("最終連絡日 が空"));
  assert.ok(chips.includes('data-action="remove-filter" data-index="1"'));
  const panel = renderFilterPanel(T, null, null);
  assert.ok(panel.includes('data-form="filter"'));
  assert.ok(panel.includes('<option value="会社名" selected>'), "列を選んでいなければ先頭の列");
  assert.ok(panel.includes('value="contains"') && panel.includes(OP_LABELS.contains));
  assert.ok(panel.includes('<input type="text" name="value" placeholder="範囲は 最小,最大。いずれかは 値1,値2">'));
  const check = renderFilterPanel(T, T.columns[5], null);
  assert.ok(check.includes('<option value="要注意" selected>'));
  assert.ok(check.includes('<option value="はい">'), "チェックの値は はい / いいえ の select");
  assert.equal(check.includes('value="contains"'), false, "チェックに使えるのは eq だけ");
  const amount = renderFilterPanel(T, T.columns[3], null);
  assert.ok(amount.includes('value="between"'));
  assert.equal(amount.includes('value="contains"'), false, "数値に「を含む」は出さない");
  assert.ok(renderFilterPanel(T, T.columns[4], null).includes('<input type="date" name="value">'));
  assert.ok(renderFilterPanel(T, T.columns[1], null).includes('<option value="取引中">'), "選択の値は候補の select");
  assert.ok(renderFilterPanel(H, H.columns[0], null).includes("候補を読み込んでいます"));
  assert.ok(renderFilterPanel(H, H.columns[0], [{ id: "20260901-001", label: "みなと工務店" }]).includes('<option value="20260901-001">みなと工務店</option>'));
  assert.equal(renderPager(0, 1, 50), "");
  const pager = renderPager(128, 2, 50);
  assert.ok(pager.includes("128 件中 51〜100 件"));
  assert.ok(pager.includes('data-action="page" data-page="1"') && pager.includes('data-action="page" data-page="3"'));
  const tabs = renderTabs(tables, "対応履歴");
  assert.ok(tabs.includes('data-action="select-table" data-table="顧客"'));
  assert.ok(tabs.includes('aria-selected="true"') && tabs.includes("対応履歴"));
});

test("renderApp: 骨組み、閲覧のみの印、AI の欄、誤りの帯、定義の誤り、CSV の箱", () => {
  const s = reduce(reduce(booted(), { type: "rows", rows: [ROW], total: 1, refs: {}, page: 1 }), { type: "error", message: "だめでした" });
  const html = renderApp(s);
  assert.ok(html.includes("みなと台帳"));
  assert.ok(html.includes('data-field="q"'));
  assert.ok(html.includes('data-field="ai"'));
  assert.ok(html.includes('data-action="new"'));
  assert.ok(html.includes('data-action="csv"'));
  assert.ok(html.includes("だめでした") && html.includes('role="alert"'));
  assert.ok(html.includes("1 件"));
  const viewer = renderApp(reduce(booted({ user: { email: "v@example.com", canEdit: false }, ai: false }), { type: "rows", rows: [], total: 0, refs: {}, page: 1 }));
  assert.ok(viewer.includes("閲覧のみ"));
  assert.equal(viewer.includes('data-action="new"'), false);
  assert.equal(viewer.includes('data-field="ai"'), false);
  assert.ok(viewer.includes("該当する記録はありません"));
  const broken = renderApp(booted({ errors: ["sheet-app: 定義の 2 行目: 型「整数」は使えません"] }));
  assert.ok(broken.includes("型「整数」"));
  assert.equal(broken.includes('data-field="q"'), false);
  const csv = renderApp(reduce(s, { type: "csv", text: "﻿a,b" }));
  assert.ok(csv.includes('data-action="copy-csv"') && csv.includes("<textarea"));
  assert.ok(renderApp(initialState()).includes("読み込んでいます"));
});

test("renderForm: 参照の候補が切れているときは欄の下に注記を出す。引き出しには題名の関連付け", () => {
  const options = { 顧客: [{ id: "20260901-001", label: "みなと工務店" }] };
  const plain = renderForm(H, { 顧客: "", 内容: "" }, {}, options, { isNew: true, id: "" });
  assert.equal(plain.includes("先頭の 2,000 件"), false);
  const cut = renderForm(H, { 顧客: "", 内容: "" }, {}, options, { isNew: true, id: "", optionsTruncated: { 顧客: true } });
  assert.ok(cut.includes('<div class="sa-note">候補が多いため、表示名の順で先頭の 2,000 件だけを出しています。</div>'));
  assert.ok(cut.includes('<h2 id="sa-drawer-title">対応履歴 を登録</h2>'));
  let s = reduce(initialState(), { type: "bootstrap", data: { tables: [T, H], settings: { dateFormat: "yyyy/MM/dd", pageSize: 50 }, today: "2026-09-16", ai: false, user: "taro@example.com" } });
  s = reduce(s, { type: "open-form", isNew: true, id: "", seenUpdatedAt: "", values: { 顧客: "", 内容: "" }, options: options, optionsTruncated: { 顧客: true } });
  assert.deepEqual(s.view.optionsTruncated, { 顧客: true });
  const app = renderApp(s);
  assert.ok(app.includes('aria-labelledby="sa-drawer-title"'));
});
