import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
/** 純粋なファイルが書いてはいけない名前（コメントも含む） */
const GAS_GLOBALS = ["SpreadsheetApp", "UrlFetchApp", "PropertiesService", "CacheService", "LockService", "MailApp", "ContentService", "HtmlService", "ScriptApp", "Logger", "Utilities", "Session.", "google.script"];

function jsFiles(dir) {
  return readdirSync(join(root, dir)).filter((name) => name.endsWith(".js")).map((name) => join(dir, name));
}

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(join(root, dir), { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(path));
    else out.push(path);
  }
  return out;
}

test("純粋な処理（src の gas_ 以外と、画面の api-gas.js 以外）は GAS のグローバルに触らず、gas_ を読み込まない", () => {
  const pure = jsFiles("src")
    .filter((file) => !/[\\/]gas_[^\\/]+$/.test(file))
    .concat(jsFiles(join("src", "ui")).filter((file) => !file.endsWith("api-gas.js")));
  assert.ok(pure.length >= 15, "純粋なファイルを見つけられていない");
  for (const file of pure) {
    const source = readFileSync(join(root, file), "utf8");
    for (const name of GAS_GLOBALS) assert.equal(source.includes(name), false, file + " が " + name + " に触っている");
    assert.equal(/from\s+["'](\.\.?\/)+gas_/.test(source), false, file + " が gas_ を読み込んでいる");
  }
});

test("公開する文（src・samples・README・CHANGELOG・LICENSE・demo/index.html）に「承ります」を使わない", () => {
  const files = walk("src").concat(walk("samples"), ["README.ja.md", "CHANGELOG.md", "LICENSE.md", join("demo", "index.html")]);
  for (const file of files) assert.equal(readFileSync(join(root, file), "utf8").includes("承ります"), false, file);
});
