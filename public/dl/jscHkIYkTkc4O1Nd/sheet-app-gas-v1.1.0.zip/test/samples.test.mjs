import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { TEMPLATES, TEMPLATE_NAMES, SETTINGS_ROWS, DEFINITION_HEADER, templateCsvFiles } from "../src/samples.js";
import { parseDefinition, headerFor } from "../src/definition.js";
import { validate } from "../src/validate.js";
import { isId } from "../src/ids.js";
import { parseSettings } from "../src/settings.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const EXPECTED = { 顧客管理: { 顧客: 20, 対応履歴: 30 }, 案件管理: { 案件: 15, 進捗: 25 }, 在庫管理: { 商品: 20, 入出庫: 40 } };
const REAL_NAME_WORDS = ["株式会社", "有限会社", "東京都", "大阪", "〒"];

test("3 つの見本があり、定義は誤りなく読め、件数が決まっている", () => {
  assert.deepEqual(TEMPLATE_NAMES, ["顧客管理", "案件管理", "在庫管理"]);
  assert.deepEqual(DEFINITION_HEADER, ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"]);
  for (const name of TEMPLATE_NAMES) {
    const template = TEMPLATES[name];
    const { tables, errors } = parseDefinition(template.definition);
    assert.deepEqual(errors, [], name);
    assert.deepEqual(Object.keys(template.tables), tables.map((t) => t.name), name);
    for (const table of tables) {
      assert.equal(template.tables[table.name].length, EXPECTED[name][table.name], name + "/" + table.name);
    }
  }
});

test("見本の記録はすべて検証を通り、ID・作成日時・更新日時・更新者を持ち、参照先が存在する", () => {
  for (const name of TEMPLATE_NAMES) {
    const template = TEMPLATES[name];
    const { tables } = parseDefinition(template.definition);
    const ids = {};
    for (const table of tables) ids[table.name] = new Set(template.tables[table.name].map((r) => r.ID));
    for (const table of tables) {
      const seen = new Set();
      for (const record of template.tables[table.name]) {
        assert.ok(isId(record.ID), table.name + " " + record.ID);
        assert.equal(seen.has(record.ID), false, "ID が重複: " + record.ID);
        seen.add(record.ID);
        assert.match(record.作成日時, /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
        assert.match(record.更新日時, /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
        assert.equal(record.更新者, "sample@example.com");
        const result = validate(table, record, { today: "2026-09-16", isNew: true });
        assert.equal(result.ok, true, table.name + " " + record.ID + " " + JSON.stringify(result.errors));
        for (const column of table.columns) {
          assert.ok(Object.prototype.hasOwnProperty.call(record, column.name), table.name + " に " + column.name + " が無い: " + record.ID);
          if (column.type === "参照" && record[column.name] !== "") assert.ok(ids[column.refTable].has(record[column.name]), "参照先が無い: " + record[column.name]);
        }
      }
    }
  }
});

test("実在を思わせる語を使わない。設定の見本は既定値どおりに読める", () => {
  const text = JSON.stringify(TEMPLATES);
  for (const word of REAL_NAME_WORDS) assert.equal(text.includes(word), false, word);
  const { settings, errors } = parseSettings(SETTINGS_ROWS);
  assert.deepEqual(errors, []);
  assert.equal(settings.appName, "業務アプリ");
  assert.equal(settings.pageSize, 50);
});

test("samples/ の CSV は samples.js から作ったものと一致する（npm run samples で作り直す）", () => {
  const settings = readFileSync(join(root, "samples", "設定.csv"), "utf8");
  assert.ok(settings.startsWith("﻿項目,値"));
  for (const name of TEMPLATE_NAMES) {
    const files = templateCsvFiles(name);
    assert.ok(Object.keys(files).includes("定義.csv"));
    for (const file of Object.keys(files)) {
      const path = join(root, "samples", name, file);
      assert.ok(existsSync(path), path);
      assert.equal(readFileSync(path, "utf8"), files[file], path + " が古いです。npm run samples を実行してください");
    }
  }
  const { tables } = parseDefinition(TEMPLATES["顧客管理"].definition);
  const csv = templateCsvFiles("顧客管理")["顧客.csv"];
  assert.equal(csv.split("\r\n")[0], "﻿" + headerFor(tables[0]).join(","));
});
