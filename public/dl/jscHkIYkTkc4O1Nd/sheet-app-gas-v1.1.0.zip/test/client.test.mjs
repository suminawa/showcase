import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Script } from "node:vm";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("App.html は google.script.run で動き、見本データと鍵の形を含まず、構文が通る", () => {
  const html = readFileSync(join(root, "dist", "App.html"), "utf8");
  assert.ok(html.includes("google.script.run"));
  assert.equal(html.includes("memoryApi"), false);
  assert.equal(html.includes("TEMPLATES"), false);
  assert.equal(html.includes("sk-ant-"), false);
  assert.ok(html.includes("function mountSheetApp("));
  assert.ok(html.includes("function renderApp("));
  assert.ok(html.includes("function validate("), "検証は画面でも同じものを動かす");
  const js = html.slice(html.indexOf("<script>") + 8, html.lastIndexOf("</script>"));
  assert.doesNotThrow(() => new Script(js));
  const css = html.slice(html.indexOf("<style>") + 7, html.indexOf("</style>"));
  assert.ok(css.includes("--sa-accent"));
  assert.ok(css.includes("@media (max-width: 639px)"));
});

test("demo/app.js は見本データで動き、google に触らない", () => {
  const js = readFileSync(join(root, "demo", "app.js"), "utf8");
  assert.ok(js.includes("window.SheetApp = { mount:"));
  assert.ok(js.includes("function memoryApi("));
  assert.equal(js.includes("google.script.run"), false);
  assert.doesNotThrow(() => new Script(js));
  const html = readFileSync(join(root, "demo", "index.html"), "utf8");
  assert.ok(html.includes('<script src="app.js"></script>'));
  assert.ok(html.includes('window.SheetApp.mount(document.getElementById("app"))'));
});
