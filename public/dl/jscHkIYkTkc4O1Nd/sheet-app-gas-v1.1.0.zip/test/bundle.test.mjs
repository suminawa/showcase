import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { loadBundle } from "./fakes.mjs";
import { TEMPLATES } from "../src/samples.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const DEFINITION = [
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "FALSE", "", "", ""],
  ["顧客", "電話", "電話", "", "", "FALSE", "", "", ""],
  ["対応履歴", "顧客", "参照:顧客", "TRUE", "", "", "", "", ""],
  ["対応履歴", "内容", "長文", "TRUE", "", "", "", "", ""],
];
const SETTINGS = [["項目", "値"], ["アプリ名", "みなと台帳"], ["1 ページの件数", "20"]];

function seeded(extra) {
  return loadBundle(Object.assign({ sheets: { 設定: SETTINGS, 定義: DEFINITION } }, extra || {}));
}

test("Code.gs に 12 個の api_ と入口があり、import / export と鍵の形が無い", () => {
  const code = readFileSync(join(root, "dist", "Code.gs"), "utf8");
  for (const name of ["api_bootstrap", "api_list", "api_get", "api_options", "api_create", "api_update", "api_delete", "api_export", "api_ai_filter", "api_ai_summary", "api_line_send", "api_ai_draft", "doGet", "doPost", "onOpen"]) {
    assert.ok(new RegExp("^function " + name + "\\(", "m").test(code), name);
  }
  assert.equal((code.match(/^function api_/gm) || []).length, 12);
  assert.equal(/^\s*(import|export)\s/m.test(code), false);
  assert.equal(code.includes("sk-ant-"), false);
});

test("doGet は App.html を題名とビューポートつきで返す", () => {
  const run = seeded();
  const out = run.entry.doGet();
  assert.equal(out.file, "App");
  assert.equal(out.title, "みなと台帳");
  assert.deepEqual(out.meta, [["viewport", "width=device-width, initial-scale=1"]]);
});

test("api_bootstrap: テーブル・利用者・AI の有無・設定。定義が壊れていれば errors に出る", () => {
  const run = seeded();
  const boot = run.entry.api_bootstrap();
  assert.equal(boot.appName, "みなと台帳");
  assert.deepEqual(boot.tables.map((t) => t.name), ["顧客", "対応履歴"]);
  assert.deepEqual(boot.errors, []);
  assert.deepEqual(boot.user, { email: "taro@example.com", canEdit: true });
  assert.equal(boot.ai, false, "鍵が無ければ AI は出ない");
  assert.equal(boot.pageSize, 20);
  assert.equal(boot.dateFormat, "yyyy-MM-dd");
  assert.equal(boot.today, "2026-09-16");
  assert.equal(JSON.stringify(boot).includes("ANTHROPIC"), false);
  const withKey = seeded({ apiKey: "test-key" });
  assert.equal(withKey.entry.api_bootstrap().ai, true);
  const broken = loadBundle({ sheets: { 定義: [HEADER, ["顧客", "x", "整数", "", "", "", "", "", ""]] } });
  assert.ok(broken.entry.api_bootstrap().errors[0].includes("型「整数」"));
  const restricted = loadBundle({ sheets: { 定義: DEFINITION, 設定: [["編集できる人", "hanako@example.com"]] } });
  assert.equal(restricted.entry.api_bootstrap().user.canEdit, false);
});

test("登録 → 一覧 → 更新（衝突の検出）→ CSV → 削除 の流れ", () => {
  const run = seeded();
  const created = run.entry.api_create("顧客", { 会社名: "みなと工務店", 最終連絡日: "2026/09/10", 年間取引額: "1,200,000" });
  assert.equal(created.id, "20260916-001");
  const second = run.entry.api_create("顧客", { 会社名: "うみかぜ商店", 状況: "取引中" });
  assert.equal(second.id, "20260916-002");
  assert.equal(run.props["lastId:顧客"], "20260916-002");
  // 必須の空は列ごとの誤りで断る
  assert.throws(() => run.entry.api_create("顧客", { 会社名: "" }), /会社名 を入力してください/);
  // 参照先の存在
  assert.throws(() => run.entry.api_create("対応履歴", { 顧客: "20260916-999", 内容: "x" }), /参照先の記録が見つかりません/);
  const history = run.entry.api_create("対応履歴", { 顧客: "20260916-001", 内容: "見積もりをお送りしました" });
  assert.equal(history.id, "20260916-001", "ID の連番はテーブルごと");
  // 一覧（既定は更新日時の降順。同時刻なら元の順）
  const list = run.entry.api_list("顧客", { q: "", filters: [], sort: { column: "ID", dir: "asc" }, page: 1 });
  assert.equal(list.total, 2);
  assert.equal(list.pageSize, 20, "設定の件数が既定になる");
  assert.equal(list.rows[0].会社名, "みなと工務店");
  assert.equal(list.rows[0].年間取引額, 1200000);
  assert.equal(list.rows[0].最終連絡日, "2026-09-10");
  assert.equal(list.rows[0].更新者, "taro@example.com");
  assert.match(list.rows[0].更新日時, /^2026-09-16 10:40:00$/);
  const historyList = run.entry.api_list("対応履歴", {});
  assert.deepEqual(historyList.refs, { 顧客: { "20260916-001": "みなと工務店" } });
  // 取得
  const got = run.entry.api_get("対応履歴", "20260916-001");
  assert.equal(got.row.内容, "見積もりをお送りしました");
  assert.deepEqual(got.refs, { 顧客: "みなと工務店" });
  assert.throws(() => run.entry.api_get("顧客", "20260916-999"), /見つかりません/);
  // 候補
  const options = run.entry.api_options("対応履歴", "顧客");
  assert.deepEqual(options, { options: [{ id: "20260916-002", label: "うみかぜ商店" }, { id: "20260916-001", label: "みなと工務店" }], truncated: false }, "表示名の五十音順");
  assert.throws(() => run.entry.api_options("対応履歴", "内容"), /参照の列ではありません/);
  // 更新: 読んだときの更新日時を添える
  const seen = list.rows[0].更新日時;
  const updated = run.entry.api_update("顧客", "20260916-001", { 状況: "取引中" }, seen);
  assert.equal(updated.updatedAt, "2026-09-16 10:40:00");
  assert.throws(() => run.entry.api_update("顧客", "20260916-001", { 状況: "休眠" }, "2026-01-01 00:00:00"), /ほかの方が先に更新しました/);
  assert.throws(() => run.entry.api_update("顧客", "20260916-001", { 状況: "取引停止" }, seen), /候補から選んでください/);
  assert.equal(run.entry.api_get("顧客", "20260916-001").row.状況, "取引中");
  // CSV は絞り込みと並び順つきで全件
  const csv = run.entry.api_export("顧客", { filters: [{ column: "状況", op: "eq", value: "取引中" }], sort: { column: "会社名", dir: "asc" } });
  const lines = csv.split("\r\n");
  assert.equal(lines[0], "﻿ID,会社名,状況,最終連絡日,年間取引額,メモ,電話,作成日時,更新日時,更新者");
  assert.equal(lines.length, 4);
  assert.ok(lines[1].startsWith("20260916-002,うみかぜ商店,取引中"));
  assert.ok(lines[2].startsWith("20260916-001,みなと工務店,取引中,2026-09-10,1200000"));
  // 削除
  assert.deepEqual(run.entry.api_delete("顧客", "20260916-002"), { ok: true });
  assert.equal(run.entry.api_list("顧客", {}).total, 1);
  assert.equal(run.sheets["_ごみ箱"].rows.length, 2);
  assert.throws(() => run.entry.api_delete("顧客", "20260916-002"), /見つかりません/);
  // 知らないテーブル・予約シート
  assert.throws(() => run.entry.api_list("設定", {}), /テーブル「設定」は定義にありません/);
  assert.throws(() => run.entry.api_list("_ごみ箱", {}), /定義にありません/);
});

test("文字は ' を付けて書くので、電話の先頭 0 も「1-2」も秒つきの更新日時もそのまま残る", () => {
  const run = seeded();
  run.entry.api_create("顧客", { 会社名: "1-2", 電話: "09012345678" });
  const row = run.entry.api_get("顧客", "20260916-001").row;
  assert.equal(row.電話, "09012345678", "先頭の 0 を落とさない");
  assert.equal(row.会社名, "1-2", "日付にしない");
  assert.equal(row.更新日時, "2026-09-16 10:40:00", "秒を落とさない（衝突の検出が分単位に落ちない）");
});

test("ID の出発点はシートの最大値も見る（覚え書きが空でも続きから振る）", () => {
  const run = loadBundle({ sheets: { 設定: SETTINGS, 定義: DEFINITION, 顧客: [["ID", "会社名"], ["20260916-003", "手で足した行"]] } });
  assert.equal(run.entry.api_create("顧客", { 会社名: "みなと工務店" }).id, "20260916-004");
});

test("共有されていない人には、空白の画面ではなく敬体の案内を返す", () => {
  const run = loadBundle({ sheets: {}, noSpreadsheet: true });
  const out = run.entry.doGet();
  assert.ok(out.html.includes("元のスプレッドシートの共有が必要です"));
  assert.ok(out.html.includes('lang="ja"'));
  assert.ok(out.html.includes("複数の Google アカウント"));
  assert.equal(out.title, "業務アプリ");
});

test("閲覧のみの人は書けない（編集できる人の絞り込み／シートの権限）", () => {
  const restricted = loadBundle({ sheets: { 定義: DEFINITION, 設定: [["編集できる人", "hanako@example.com"]] } });
  assert.throws(() => restricted.entry.api_create("顧客", { 会社名: "x" }), /閲覧のみ/);
  assert.throws(() => restricted.entry.api_delete("顧客", "20260916-001"), /閲覧のみ/);
  const denied = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [["ID", "会社名", "状況", "最終連絡日", "年間取引額", "メモ", "作成日時", "更新日時", "更新者"]] }, denyWrite: true });
  assert.throws(() => denied.entry.api_create("顧客", { 会社名: "x" }), /編集権限がありません/);
  assert.equal(denied.entry.api_list("顧客", {}).total, 0, "読むのはできる");
  const busy = seeded({ lockBusy: true });
  assert.throws(() => busy.entry.api_create("顧客", { 会社名: "x" }), /ほかの方の保存が続いています/);
});

test("AI で絞り込み: 鍵があれば Claude を 1 回呼び、答えを query の形にし、回数と usage を貯める。上限と鍵なしは断る", () => {
  const run = seeded({ apiKey: "test-key" });
  const answer = run.entry.api_ai_filter("顧客", "取引中の会社");
  assert.deepEqual(answer.filters, [{ column: "状況", op: "eq", value: "取引中" }]);
  assert.equal(answer.explanation, "状況が取引中の顧客に絞りました");
  assert.equal(run.trace.fetched.length, 1);
  assert.equal(run.trace.fetched[0].headers["x-api-key"], "test-key");
  const body = JSON.parse(run.trace.fetched[0].payload);
  assert.equal(body.model, "claude-sonnet-5");
  assert.equal(body.output_config.format.type, "json_schema");
  assert.ok(body.messages[0].content[0].text.includes("取引中の会社"));
  assert.equal(run.props["ai:2026-09-16"], "1");
  assert.equal(JSON.parse(run.props["usage:2026-09"]).count, 1);
  // 過ぎた日の回数は消え、ほかのプロパティは残る
  const stale = loadBundle({ sheets: { 定義: DEFINITION }, apiKey: "test-key", props: { "ai:2026-09-15": "3", "lastId:顧客": "20260916-002" } });
  stale.entry.api_ai_filter("顧客", "取引中の会社");
  assert.equal(stale.props["ai:2026-09-15"], undefined);
  assert.equal(stale.props["ai:2026-09-16"], "1");
  assert.equal(stale.props["lastId:顧客"], "20260916-002");
  const noKey = seeded();
  assert.throws(() => noKey.entry.api_ai_filter("顧客", "x"), /AI の機能は使えません/);
  const off = loadBundle({ sheets: { 定義: DEFINITION, 設定: [["AI を使う", "FALSE"]] }, apiKey: "test-key" });
  assert.throws(() => off.entry.api_ai_filter("顧客", "x"), /AI の機能は使えません/);
  const limited = loadBundle({ sheets: { 定義: DEFINITION, 設定: [["AI の 1 日の上限", "1"]] }, apiKey: "test-key", props: { "ai:2026-09-16": "1" } });
  assert.throws(() => limited.entry.api_ai_filter("顧客", "x"), /本日の上限/);
  const failing = seeded({ apiKey: "test-key", claudeStatus: 401 });
  assert.throws(() => failing.entry.api_ai_filter("顧客", "x"), /API キーが受け付けられませんでした/);
  assert.throws(() => run.entry.api_ai_filter("顧客", ""), /言葉を入力してください/);
});

test("AI 要約: 記録の値を送り、答えの文を返す", () => {
  const run = seeded({ apiKey: "test-key", claudeBody: { content: [{ type: "text", text: "みなと工務店は取引中です。\n次の一手: 見積もりの返事を確認します。" }], usage: { input_tokens: 500, output_tokens: 60 }, stop_reason: "end_turn" } });
  run.entry.api_create("顧客", { 会社名: "みなと工務店", 状況: "取引中" });
  const out = run.entry.api_ai_summary("顧客", "20260916-001");
  assert.ok(out.text.includes("次の一手"));
  const body = JSON.parse(run.trace.fetched[0].payload);
  assert.ok(body.messages[0].content[0].text.includes("会社名: みなと工務店"));
  assert.equal(body.output_config.effort, "low");
});

test("AI 要約: 上限で打ち切られた答えは出さず、敬体で案内する", () => {
  const run = seeded({ apiKey: "test-key", claudeBody: { content: [{ type: "text", text: "みなと工務店は取引" }], usage: { input_tokens: 500, output_tokens: 4096 }, stop_reason: "max_tokens" } });
  run.entry.api_create("顧客", { 会社名: "みなと工務店" });
  assert.match(run.entry.api_ai_summary("顧客", "20260916-001").text, /記録が長すぎて要約を作れませんでした/);
});

test("メニュー: 初期化・見本・設定の確認・URL・AI 利用", () => {
  const empty = loadBundle({ sheets: {} });
  empty.entry.onOpen();
  empty.entry.initializeSheets();
  assert.ok(empty.sheets["設定"] && empty.sheets["定義"]);
  assert.ok(empty.trace.alerts[0].includes("定義"), "定義が空なら次の手順を案内する");
  empty.entry.loadSampleCustomers();
  assert.equal(empty.sheets["顧客"].rows.length, 21);
  assert.equal(empty.sheets["対応履歴"].rows.length, 31);
  assert.ok(empty.trace.alerts[1].includes("顧客 20 件"));
  empty.entry.loadSampleProjects();
  assert.ok(empty.trace.alerts[2].includes("定義がすでにある"));
  empty.entry.checkSettings();
  assert.ok(empty.trace.alerts[3].includes("問題ありません"));
  assert.ok(empty.trace.alerts[3].includes("顧客（12 列）"));
  empty.entry.showAppUrl();
  assert.ok(empty.trace.alerts[4].includes("https://script.google.com/macros/s/XXX/exec"));
  empty.entry.showAiUsage();
  assert.ok(empty.trace.alerts[5].includes("2026-09 の AI 利用: 0 回"));
  // 初期化は ID の無い行に番号を振る
  const withRows = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [["ID", "会社名"], ["", "手で足した行"]] } });
  withRows.entry.initializeSheets();
  assert.equal(withRows.sheets["顧客"].rows[1][0], "20260916-001");
  assert.ok(withRows.trace.alerts[0].includes("ID を 1 件"));
  // 1.1: 初期化が _LINE友だち・_LINE送信履歴・_通知ログ を見出しつきで作る
  assert.deepEqual(withRows.sheets["_LINE友だち"].rows[0].slice(0, 2), ["ユーザー ID", "表示名"]);
  assert.ok(withRows.sheets["_LINE送信履歴"] && withRows.sheets["_通知ログ"]);
  // 1.1: 1.0 の設定シート（7 行）に、足りない通知・LINE の行を足す。既にある値は変えない
  const upgraded = loadBundle({ sheets: { 定義: DEFINITION, 設定: [["項目", "値"], ["アプリ名", "うちの台帳"], ["1 ページの件数", 25]] } });
  upgraded.entry.initializeSheets();
  const items = upgraded.sheets["設定"].rows.map((r) => r[0]);
  assert.equal(items.filter((k) => k === "アプリ名").length, 1);
  assert.equal(upgraded.sheets["設定"].rows[1][1], "うちの台帳");
  assert.ok(items.includes("通知先") && items.includes("LINE チャネルアクセストークン") && items.includes("画面の URL"));
  assert.ok(upgraded.trace.alerts[0].includes("「設定」に") && upgraded.trace.alerts[0].includes("行（通知・LINE の項目）を足しました"));
  upgraded.entry.initializeSheets();
  assert.equal(upgraded.sheets["設定"].rows.map((r) => r[0]).length, items.length, "2 回目は増えない");
  // 1.1: 1.0 の定義（顧客があって LINE の列が無い）には、初期化が 顧客／LINE／LINE の行を顧客の最後に足す。2 回目は足さない
  const oneZero = loadBundle({ sheets: { 定義: [HEADER, ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""], ["顧客", "電話", "電話", "", "", "", "", "", ""], ["対応履歴", "内容", "長文", "", "", "", "", "", ""]] } });
  oneZero.entry.initializeSheets();
  const defRows = oneZero.sheets["定義"].rows;
  assert.deepEqual(defRows[3].slice(0, 3), ["顧客", "LINE", "LINE"], "顧客の最後（対応履歴の前）に入る");
  assert.equal(defRows.length, 5);
  assert.ok(oneZero.trace.alerts[0].includes("顧客に LINE の列を足しました"));
  assert.ok(oneZero.sheets["顧客"].rows[0].includes("LINE"), "顧客シートの見出しにも LINE が増える");
  oneZero.entry.initializeSheets();
  assert.equal(oneZero.sheets["定義"].rows.length, 5, "2 回目は増えない");
  // 顧客のテーブルが無ければ足さない
  const noCustomer = loadBundle({ sheets: { 定義: [HEADER, ["案件", "案件名", "文字", "TRUE", "", "", "", "", ""]] } });
  noCustomer.entry.initializeSheets();
  assert.equal(noCustomer.sheets["定義"].rows.length, 2);
  const noUrl = loadBundle({ sheets: {}, appUrl: null });
  noUrl.entry.showAppUrl();
  assert.ok(noUrl.trace.alerts[0].includes("まだ公開されていません"));
  const broken = loadBundle({ sheets: { 定義: [HEADER, ["顧客", "x", "整数", "", "", "", "", "", ""]] } });
  broken.entry.checkSettings();
  assert.ok(broken.trace.alerts[0].includes("型「整数」"));
});

test("シートの閲覧者には、画面に編集の操作を出さない（「編集できる人」が空でも）", () => {
  const viewer = loadBundle({ sheets: { 定義: DEFINITION, 設定: SETTINGS }, email: "viewer@example.com", owner: "owner@example.com", editors: ["hanako@example.com"] });
  assert.equal(viewer.entry.api_bootstrap().user.canEdit, false);
  const editor = loadBundle({ sheets: { 定義: DEFINITION, 設定: SETTINGS }, email: "hanako@example.com", owner: "owner@example.com", editors: ["hanako@example.com"] });
  assert.equal(editor.entry.api_bootstrap().user.canEdit, true);
  const owner = loadBundle({ sheets: { 定義: DEFINITION, 設定: SETTINGS }, email: "owner@example.com", owner: "owner@example.com", editors: [] });
  assert.equal(owner.entry.api_bootstrap().user.canEdit, true);
});
