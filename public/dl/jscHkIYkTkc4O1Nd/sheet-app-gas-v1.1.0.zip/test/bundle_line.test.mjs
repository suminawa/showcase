import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle } from "./fakes.mjs";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const C = "U" + "c".repeat(32);
const SLACK = "https://hooks.slack.com/services/T000/B000/XXXX";
const PUSH = "https://api.line.me/v2/bot/message/push";
const APP = "https://script.google.com/macros/s/XXX/exec";
const DEFINITION = [
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "担当者", "文字", "", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "LINE", "LINE", "", "", "FALSE", "", "", ""],
];
const FRIENDS = [["ユーザー ID", "表示名", "追加日時", "状態"], [A, "はるか", "2026-09-10 09:00:00", "友だち"], [B, "けんた", "2026-09-11 09:00:00", "ブロック"], [C, "", "2026-09-12 09:00:00", "友だち"]];
const CUSTOMERS_HEADER = ["ID", "会社名", "担当者", "状況", "LINE", "作成日時", "更新日時", "更新者"];
const LINK = APP + "#" + encodeURIComponent("顧客") + "/20260916-001";

function settingsWith(extra) {
  return [["項目", "値"], ["アプリ名", "みなと台帳"], ["通知先", "slack"], ["Slack Webhook URL", SLACK], ["LINE チャネルアクセストークン", "line-token"]].concat(extra || []);
}

function seeded(options, extraSettings) {
  return loadBundle(Object.assign({ sheets: { 設定: settingsWith(extraSettings), 定義: DEFINITION, "_LINE友だち": FRIENDS } }, options || {}));
}

function sentTo(run, prefix) {
  return run.trace.fetched.filter((item) => item.url.indexOf(prefix) === 0);
}

test("登録: 保存のあとに通知を 1 回だけ送る（文面・変更点・LINE は表示名・詳細を開く URL）", () => {
  const run = seeded();
  assert.deepEqual(run.entry.api_create("顧客", { 会社名: "みなと工務店", 担当者: "山川", LINE: A }), { id: "20260916-001" });
  const slack = sentTo(run, SLACK);
  assert.equal(slack.length, 1);
  assert.equal(JSON.parse(slack[0].payload).text, ["【みなと台帳】顧客を登録しました", "みなと工務店（20260916-001）", "会社名: みなと工務店", "担当者: 山川", "状況: 見込み", "LINE: はるか", "taro@example.com", LINK].join("\n"));
});

test("更新は変わった列だけ、削除は変更点なし。どちらも保存ごとに 1 回", () => {
  const run = seeded();
  run.entry.api_create("顧客", { 会社名: "みなと工務店" });
  const seen = run.entry.api_get("顧客", "20260916-001").row.更新日時;
  run.entry.api_update("顧客", "20260916-001", { 会社名: "みなと工務店", 状況: "取引中" }, seen);
  run.entry.api_delete("顧客", "20260916-001");
  const texts = sentTo(run, SLACK).map((item) => JSON.parse(item.payload).text);
  assert.equal(texts.length, 3);
  assert.deepEqual(texts[1].split("\n").slice(0, 3), ["【みなと台帳】顧客を更新しました", "みなと工務店（20260916-001）", "状況: 見込み → 取引中"]);
  assert.equal(texts[1].includes("会社名:"), false);
  assert.equal(texts[2], "【みなと台帳】顧客を削除しました\nみなと工務店（20260916-001）\ntaro@example.com\n" + LINK);
});

test("通知が失敗しても保存は取り消さず、_通知ログ に 1 行。画面には誤りを返さない", () => {
  const run = seeded({ respond: (url) => (url === SLACK ? { status: 500, body: "x" } : undefined) });
  assert.deepEqual(run.entry.api_create("顧客", { 会社名: "みなと工務店" }), { id: "20260916-001" });
  assert.equal(run.entry.api_get("顧客", "20260916-001").row.会社名, "みなと工務店");
  const log = run.sheets["_通知ログ"].rows;
  assert.equal(log.length, 2);
  assert.deepEqual(log[1], ["2026-09-16 10:40:00", "顧客", "登録", "20260916-001", "slack", "送れませんでした（500 が返りました）"]);
});

test("通知の絞り込み: 通知する操作・通知するテーブル・自分の操作は通知しない（所有者）・通知先が空", () => {
  const onlyDelete = seeded({}, [["通知する操作", "削除"]]);
  onlyDelete.entry.api_create("顧客", { 会社名: "a" });
  assert.equal(sentTo(onlyDelete, SLACK).length, 0);
  const otherTable = seeded({}, [["通知するテーブル", "案件"]]);
  otherTable.entry.api_create("顧客", { 会社名: "a" });
  assert.equal(sentTo(otherTable, SLACK).length, 0);
  const owner = seeded({ email: "owner@example.com" }, [["自分の操作は通知しない", "TRUE"]]);
  owner.entry.api_create("顧客", { 会社名: "a" });
  assert.equal(sentTo(owner, SLACK).length, 0);
  const staff = seeded({ email: "hanako@example.com" }, [["自分の操作は通知しない", "TRUE"]]);
  staff.entry.api_create("顧客", { 会社名: "a" });
  assert.equal(sentTo(staff, SLACK).length, 1);
  const off = loadBundle({ sheets: { 設定: [["通知先", ""]], 定義: DEFINITION } });
  off.entry.api_create("顧客", { 会社名: "a" });
  assert.equal(off.trace.fetched.length, 0);
});

test("api_bootstrap の line: 友だち（未確認は出さない）・定型文・送れるか・今月の送信数・担当者名。トークンは出さない", () => {
  const run = seeded();
  const boot = run.entry.api_bootstrap();
  assert.equal(boot.line.enabled, true);
  assert.equal(boot.line.canSend, true);
  assert.deepEqual(boot.line.friends, [{ id: B, name: "けんた", blocked: true }, { id: A, name: "はるか", blocked: false }]);
  assert.deepEqual(boot.line.templates.map((t) => t.title), ["お礼", "打ち合わせの確認", "資料のご案内"]);
  assert.equal(boot.line.monthCount, 0);
  assert.equal(boot.line.staffName, "taro");
  assert.equal(JSON.stringify(boot).includes("line-token"), false);
  assert.equal(seeded({ email: "viewer@example.com" }).entry.api_bootstrap().line.canSend, false, "シートの閲覧者は送れない");
  assert.equal(seeded({}, [["LINE を送れる人", "hanako@example.com"]]).entry.api_bootstrap().line.canSend, false);
  const noToken = loadBundle({ sheets: { 設定: [["通知先", ""]], 定義: DEFINITION, "_LINE友だち": FRIENDS } }).entry.api_bootstrap().line;
  assert.deepEqual([noToken.enabled, noToken.canSend, noToken.friends.length], [false, false, 2]);
  const noColumn = loadBundle({ sheets: { 定義: [HEADER, ["案件", "案件名", "文字", "", "", "", "", "", ""]] } }).entry.api_bootstrap().line;
  assert.deepEqual(noColumn, { enabled: false, friends: [], templates: [], canSend: false, monthCount: 0, staffName: "taro" });
});

test("api_line_send: push で送り、_LINE送信履歴 に 1 行。履歴と今月の数を返し、詳細（api_get）でも見える", () => {
  const run = seeded();
  run.entry.api_create("顧客", { 会社名: "みなと工務店", LINE: A });
  const result = run.entry.api_line_send("顧客", "20260916-001", "  みなと工務店 様\n\n先日はありがとうございました。  ");
  const push = sentTo(run, PUSH);
  assert.equal(push.length, 1);
  assert.equal(push[0].headers.Authorization, "Bearer line-token");
  assert.deepEqual(JSON.parse(push[0].payload), { to: A, messages: [{ type: "text", text: "みなと工務店 様\n\n先日はありがとうございました。" }] });
  const rows = run.sheets["_LINE送信履歴"].rows;
  assert.deepEqual(rows[0], ["日時", "テーブル", "ID", "送り先ユーザー ID", "送信者", "本文", "結果"]);
  assert.deepEqual(rows[1], ["2026-09-16 10:40:00", "顧客", "20260916-001", A, "taro@example.com", "みなと工務店 様\n\n先日はありがとうございました。", "送信済み"]);
  assert.equal(result.monthCount, 1);
  assert.deepEqual(result.history, [{ at: "2026-09-16 10:40:00", sender: "taro@example.com", text: "みなと工務店 様\n\n先日はありがとうございました。", result: "送信済み" }]);
  assert.equal(run.entry.api_get("顧客", "20260916-001").history.length, 1);
  assert.equal(run.entry.api_bootstrap().line.monthCount, 1);
});

test("api_line_send は敬体で断る: 本文・LINE の列が空・ブロック中・一覧に無い ID・閲覧者・送れる人以外・トークンなし・LINE の列が無いテーブル", () => {
  const sheets = (extra) => ({
    設定: settingsWith(extra),
    定義: DEFINITION,
    "_LINE友だち": FRIENDS,
    顧客: [CUSTOMERS_HEADER, ["20260916-001", "みなと工務店", "", "見込み", A, "", "", ""], ["20260916-002", "うみかぜ商店", "", "見込み", "", "", "", ""], ["20260916-003", "さくら不動産", "", "見込み", B, "", "", ""], ["20260916-004", "ひだまり整体院", "", "見込み", C, "", "", ""]],
  });
  const run = loadBundle({ sheets: sheets() });
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-001", " "), /本文を入力してください/);
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-001", "あ".repeat(5001)), /本文は 5,000 字以内にしてください（いまは 5,001 字）/);
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-002", "こんにちは"), /LINE の友だちが結びついていません/);
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-003", "こんにちは"), /ブロック中のため送れません/);
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-004", "こんにちは"), /友だちの一覧にありません/);
  assert.equal(sentTo(run, PUSH).length, 0);
  assert.throws(() => loadBundle({ sheets: sheets(), email: "viewer@example.com" }).entry.api_line_send("顧客", "20260916-001", "こんにちは"), /閲覧のみ/);
  assert.throws(() => loadBundle({ sheets: sheets([["LINE を送れる人", "hanako@example.com"]]) }).entry.api_line_send("顧客", "20260916-001", "こんにちは"), /「LINE を送れる人」に書かれた方だけ/);
  assert.throws(() => loadBundle({ sheets: Object.assign(sheets(), { 設定: [["通知先", ""]] }) }).entry.api_line_send("顧客", "20260916-001", "こんにちは"), /LINE の送信は使えません/);
  assert.throws(() => loadBundle({ sheets: { 定義: [HEADER, ["案件", "案件名", "文字", "", "", "", "", "", ""]] } }).entry.api_line_send("案件", "1", "こんにちは"), /LINE の列がありません/);
  assert.throws(() => run.entry.api_create("顧客", { 会社名: "x", LINE: C }), /LINE: この LINE のユーザー ID は友だちの一覧にありません/);
  assert.throws(() => run.entry.api_create("顧客", { 会社名: "x", LINE: "U123" }), /LINE の友だちから選んでください/);
});

test("api_line_send: LINE が断ったら敬体に言い換え、履歴には書かない", () => {
  const run = seeded({ respond: (url) => (url === PUSH ? { status: 403, body: { message: "Forbidden" } } : undefined) });
  run.entry.api_create("顧客", { 会社名: "みなと工務店", LINE: A });
  assert.throws(() => run.entry.api_line_send("顧客", "20260916-001", "こんにちは"), (error) => error.message === "送れませんでした（LINE の応答: 403）。ブロックされているか、トークンが失効しています");
  assert.equal(run.sheets["_LINE送信履歴"], undefined);
});

test("api_ai_draft: 用件と記録から下書きを作る。AI の 1 日の回数に数え、閲覧者・空の用件・打ち切りは断る", () => {
  const run = seeded({ apiKey: "test-key", claudeBody: { content: [{ type: "text", text: "みなと工務店 山川 様\n\n先日はありがとうございました。\ntaro" }], usage: { input_tokens: 300, output_tokens: 80 }, stop_reason: "end_turn" } });
  run.entry.api_create("顧客", { 会社名: "みなと工務店", 担当者: "山川", LINE: A });
  assert.deepEqual(run.entry.api_ai_draft("顧客", "20260916-001", "先日の内見のお礼"), { text: "みなと工務店 山川 様\n\n先日はありがとうございました。\ntaro" });
  const claude = sentTo(run, "https://api.anthropic.com/");
  assert.equal(claude.length, 1);
  const body = JSON.parse(claude[0].payload);
  assert.ok(body.system.includes("300 字以内"));
  assert.ok(body.messages[0].content[0].text.includes("<用件>\n先日の内見のお礼\n</用件>"));
  assert.equal(body.messages[0].content[0].text.includes(A), false);
  assert.equal(run.props["ai:2026-09-16"], "1");
  assert.throws(() => run.entry.api_ai_draft("顧客", "20260916-001", " "), /用件を入力してください/);
  assert.throws(() => seeded({ apiKey: "test-key", email: "viewer@example.com" }).entry.api_ai_draft("顧客", "20260916-001", "お礼"), /閲覧のみ/);
  const cut = seeded({ apiKey: "test-key", claudeBody: { content: [{ type: "text", text: "みなと" }], usage: {}, stop_reason: "max_tokens" } });
  cut.entry.api_create("顧客", { 会社名: "みなと工務店" });
  assert.throws(() => cut.entry.api_ai_draft("顧客", "20260916-001", "お礼"), /下書きを作りきれませんでした/);
  const noKey = seeded();
  noKey.entry.api_create("顧客", { 会社名: "みなと工務店" });
  assert.throws(() => noKey.entry.api_ai_draft("顧客", "20260916-001", "お礼"), /AI の機能は使えません/);
});
