import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { mountSheetApp } from "../src/ui/main.js";

// main.js を DOM なしで動かす最小の偽物。root は innerHTML に書かれるだけ、クリックは登録された listener を直接呼ぶ
const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([HEADER, ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""], ["顧客", "LINE", "LINE", "", "", "", "", "", ""]]);
const A = "U" + "a".repeat(32);
const BOOT = {
  appName: "みなと台帳",
  tables: tables,
  errors: [],
  user: { email: "taro@example.com", canEdit: true },
  ai: false,
  pageSize: 50,
  dateFormat: "yyyy-MM-dd",
  today: "2026-09-16",
  line: { enabled: true, friends: [{ id: A, name: "はるか", blocked: false }], templates: [], canSend: true, monthCount: 0, staffName: "taro" },
};
const ROW = { ID: "20260916-001", 会社名: "みなと工務店", LINE: A, 作成日時: "", 更新日時: "", 更新者: "" };

function fakeRoot() {
  const listeners = {};
  return {
    innerHTML: "",
    listeners: listeners,
    addEventListener: (type, fn) => {
      listeners[type] = fn;
    },
    contains: () => true,
    querySelector: () => null,
  };
}

function settle() {
  return new Promise((resolve) => setTimeout(resolve, 0)).then(() => new Promise((resolve) => setTimeout(resolve, 0)));
}

function withGlobals(fn) {
  const saved = { document: globalThis.document, window: globalThis.window };
  globalThis.document = { activeElement: null };
  globalThis.window = { confirm: () => true };
  return Promise.resolve()
    .then(fn)
    .finally(() => {
      globalThis.document = saved.document;
      globalThis.window = saved.window;
    });
}

function stubApi(extra) {
  const hashes = [];
  const api = Object.assign(
    {
      hashes: hashes,
      bootstrap: () => Promise.resolve(BOOT),
      list: () => Promise.resolve({ rows: [], total: 0, refs: {}, page: 1 }),
      get: () => Promise.resolve({ row: ROW, refs: {}, history: [] }),
      readHash: () => Promise.resolve(""),
      writeHash: (hash) => hashes.push(hash),
    },
    extra || {},
  );
  return api;
}

test("ハッシュの ID が見つからなければ、誤りを出してからハッシュを消す（読み直しで同じ誤りを繰り返さない）", () =>
  withGlobals(async () => {
    const api = stubApi({
      readHash: () => Promise.resolve("顧客/20260916-999"),
      get: () => Promise.reject(new Error("ID「20260916-999」の記録が見つかりません。削除された可能性があります")),
    });
    const app = mountSheetApp(fakeRoot(), api);
    await settle();
    assert.equal(app.getState().error, "ID「20260916-999」の記録が見つかりません。削除された可能性があります");
    assert.deepEqual(api.hashes, [""]);
  }));

test("ハッシュの ID があれば詳細を開き、ハッシュは消さない", () =>
  withGlobals(async () => {
    const api = stubApi({ readHash: () => Promise.resolve("顧客/20260916-001") });
    const app = mountSheetApp(fakeRoot(), api);
    await settle();
    assert.equal(app.getState().view.kind, "detail");
    assert.deepEqual(api.hashes, [encodeURIComponent("顧客") + "/20260916-001"], "消さない");
  }));

test("LINE で送る: 送れたが履歴に書けなかったときは、server の注意（note）をお知らせに出す。ふだんは「LINE を送りました」", () =>
  withGlobals(async () => {
    const note = "送りました（履歴には書けませんでした）。もう一度送ると 2 通届くので、送り直さないでください";
    let answer = { history: [], monthCount: 0, note: note };
    const sent = [];
    const api = stubApi({
      lineSend: (table, id, text) => {
        sent.push([table, id, text]);
        return Promise.resolve(answer);
      },
    });
    const root = fakeRoot();
    const app = mountSheetApp(root, api);
    await settle();
    const send = () => {
      app.dispatch({ type: "open-detail", row: ROW, refs: {}, history: [] });
      app.dispatch({ type: "line-text", text: "こんにちは" });
      const el = { dataset: { action: "line-send" } };
      root.listeners.click({ target: { closest: () => el } });
      return settle();
    };
    await send();
    assert.deepEqual(sent, [["顧客", "20260916-001", "こんにちは"]]);
    assert.equal(app.getState().notice, note);
    answer = { history: [], monthCount: 1 };
    await send();
    assert.equal(app.getState().notice, "LINE を送りました");
  }));
