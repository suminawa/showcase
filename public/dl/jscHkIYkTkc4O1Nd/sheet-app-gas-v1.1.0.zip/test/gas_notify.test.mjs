import { test } from "node:test";
import assert from "node:assert/strict";
import { runInContext } from "node:vm";
import { loadBundle, plain } from "./fakes.mjs";

const SLACK = "https://hooks.slack.com/services/T000/B000/XXXX";
const DISCORD = "https://discord.com/api/webhooks/1/abc";
const PUSH = "https://api.line.me/v2/bot/message/push";
const ME = "U" + "f".repeat(32);
const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const SETTINGS = {
  appName: "みなと台帳",
  notifyTargets: ["slack", "discord", "line"],
  slackWebhookUrl: SLACK,
  discordWebhookUrl: DISCORD,
  lineToken: "line-token",
  lineTo: ME,
  notifyTables: [],
  notifyOps: ["登録", "更新", "削除"],
  skipOwn: false,
  notifyTemplate: "【{アプリ名}】{テーブル}を{操作}しました\n{表示名}（{ID}）\n{変更点}\n{更新者}\n{URL}",
};
const EVENT = { appName: "みなと台帳", table: "顧客", op: "登録", id: "20260916-001", label: "みなと工務店", actor: "taro@example.com", changes: { items: [{ column: "会社名", before: "", after: "みなと工務店" }], more: 0 }, url: "https://script.google.com/macros/s/XXX/exec#x", values: { 会社名: "みなと工務店" } };

function evalIn(run, code) {
  return runInContext(code, run.context);
}

function prepared(options) {
  const run = loadBundle(Object.assign({ sheets: {} }, options || {}));
  run.sandbox.__settings = SETTINGS;
  run.sandbox.__event = EVENT;
  return run;
}

test("notifyAll_: 通知先の順に Slack・Discord・LINE へ送り、宛先ごとの結果を返す", () => {
  const run = prepared();
  const results = plain(evalIn(run, "notifyAll_(__settings, 'こんにちは')"));
  assert.deepEqual(results, [
    { target: "slack", ok: true, message: "送りました" },
    { target: "discord", ok: true, message: "送りました" },
    { target: "line", ok: true, message: "送りました" },
  ]);
  const [slack, discord, line] = run.trace.fetched;
  assert.equal(slack.url, SLACK);
  assert.equal(slack.method, "post");
  assert.deepEqual(JSON.parse(slack.payload), { text: "こんにちは" });
  assert.equal(discord.url, DISCORD);
  assert.deepEqual(JSON.parse(discord.payload), { content: "こんにちは", allowed_mentions: { parse: [] } });
  assert.equal(line.url, PUSH);
  assert.equal(line.headers.Authorization, "Bearer line-token");
  assert.deepEqual(JSON.parse(line.payload), { to: ME, messages: [{ type: "text", text: "こんにちは" }] });
});

test("notifyAll_: 1 つが失敗しても残りには送る。失敗の文は状態コードだけ（URL やトークンを出さない）", () => {
  const run = prepared({ respond: (url) => (url === SLACK ? { status: 500, body: "x" } : undefined) });
  const results = plain(evalIn(run, "notifyAll_(__settings, 'こんにちは')"));
  assert.deepEqual(results[0], { target: "slack", ok: false, message: "送れませんでした（500 が返りました）" });
  assert.equal(results[1].ok, true);
  assert.equal(results[2].ok, true);
  assert.equal(run.trace.fetched.length, 3);
  assert.equal(JSON.stringify(results).includes("hooks.slack.com"), false);
});

test("notifyChange_: 文面を作って全宛先に送る。送れた宛先は _通知ログ に書かない", () => {
  const run = prepared();
  const results = plain(evalIn(run, "notifyChange_(__settings, __event, 'owner@example.com')"));
  assert.equal(results.length, 3);
  assert.equal(run.trace.fetched.length, 3);
  assert.equal(JSON.parse(run.trace.fetched[0].payload).text, "【みなと台帳】顧客を登録しました\nみなと工務店（20260916-001）\n会社名: みなと工務店\ntaro@example.com\nhttps://script.google.com/macros/s/XXX/exec#x");
  assert.equal(run.sheets["_通知ログ"], undefined);
});

test("notifyChange_: 送れなかった宛先だけ _通知ログ に 1 行。シートが書けなくても投げない", () => {
  const run = prepared({ respond: (url) => (url === PUSH ? { status: 401, body: {} } : undefined) });
  evalIn(run, "notifyChange_(__settings, __event, 'owner@example.com')");
  const log = run.sheets["_通知ログ"].rows;
  assert.deepEqual(log[0], ["日時", "テーブル", "操作", "ID", "宛先", "結果"]);
  assert.equal(log.length, 2);
  assert.deepEqual(log[1], ["2026-09-16 10:40:00", "顧客", "登録", "20260916-001", "line", "送れませんでした（401 が返りました）"]);
  const denied = prepared({ denyWrite: true, respond: (url) => (url === SLACK ? { status: 500, body: "x" } : undefined) });
  assert.doesNotThrow(() => evalIn(denied, "notifyChange_(__settings, __event, 'owner@example.com')"));
  assert.ok(denied.trace.logs.some((line) => line.includes("_通知ログ")));
});

test("notifyChange_: 通知しない条件（操作・テーブル・通知先が空）なら何も送らず [] を返す", () => {
  const run = prepared();
  run.sandbox.__onlyDelete = Object.assign({}, SETTINGS, { notifyOps: ["削除"] });
  run.sandbox.__none = Object.assign({}, SETTINGS, { notifyTargets: [] });
  assert.deepEqual(plain(evalIn(run, "notifyChange_(__onlyDelete, __event, '')")), []);
  assert.deepEqual(plain(evalIn(run, "notifyChange_(__none, __event, '')")), []);
  assert.equal(run.trace.fetched.length, 0);
});

test("lineProfile_: 表示名を GET で取る。取れなければ空、トークンが空なら呼ばない", () => {
  const run = prepared({ lineProfiles: { [A]: "はるか" } });
  assert.equal(evalIn(run, "lineProfile_('line-token', '" + A + "')"), "はるか");
  assert.equal(run.trace.fetched[0].url, "https://api.line.me/v2/bot/profile/" + A);
  assert.equal(run.trace.fetched[0].method, "get");
  assert.equal(run.trace.fetched[0].headers.Authorization, "Bearer line-token");
  assert.equal(evalIn(run, "lineProfile_('line-token', '" + B + "')"), "", "友だちでない ID は 404");
  assert.equal(evalIn(run, "lineProfile_('', '" + A + "')"), "");
  assert.equal(run.trace.fetched.length, 2);
});

test("pushLine_ は失敗の状態コードを error.status に載せる。webAppUrl_ は Web アプリの URL（無ければ空）", () => {
  const run = prepared({ respond: (url) => (url === PUSH ? { status: 429, body: { message: "limit" } } : undefined) });
  assert.equal(evalIn(run, "(function () { try { pushLine_('line-token', '" + A + "', 'x'); return 0; } catch (error) { return error.status; } })()"), 429);
  assert.equal(evalIn(run, "webAppUrl_()"), "https://script.google.com/macros/s/XXX/exec");
  const noUrl = prepared({ appUrl: null });
  assert.equal(evalIn(noUrl, "webAppUrl_()"), "");
});
