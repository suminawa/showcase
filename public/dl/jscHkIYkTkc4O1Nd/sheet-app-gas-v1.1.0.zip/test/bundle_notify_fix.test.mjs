import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle } from "./fakes.mjs";

// 最終レビューの指摘の直し（通知）: fetch そのものの失敗・競合のときは送らない・設定「画面の URL」・Slack のメンション
const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const A = "U" + "a".repeat(32);
const B = "U" + "b".repeat(32);
const SLACK = "https://hooks.slack.com/services/T000/B000/XXXX";
const SCREEN = "https://script.google.com/macros/s/SCREEN/exec";
const DEFINITION = [
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "LINE", "LINE", "", "", "FALSE", "", "", ""],
  ["案件", "案件名", "文字", "", "", "", "", "", ""],
];
const FRIENDS = [["ユーザー ID", "表示名", "追加日時", "状態"], [A, "はるか", "2026-09-10 09:00:00", "友だち"], [B, "けんた", "2026-09-11 09:00:00", "ブロック"]];
const CUSTOMERS = [["ID", "会社名", "状況", "LINE", "作成日時", "更新日時", "更新者"], ["20260916-001", "みなと工務店", "見込み", A, "2026-09-16 10:00:00", "2026-09-16 10:00:00", "taro@example.com"], ["20260916-002", "さくら不動産", "見込み", B, "2026-09-16 10:00:00", "2026-09-16 10:00:00", "taro@example.com"]];

function settingsWith(extra) {
  return [["項目", "値"], ["通知先", "slack"], ["Slack Webhook URL", SLACK], ["LINE チャネルアクセストークン", "line-token"]].concat(extra || []);
}

function seeded(options, extraSettings) {
  return loadBundle(Object.assign({ sheets: { 設定: settingsWith(extraSettings), 定義: DEFINITION, "_LINE友だち": FRIENDS, 顧客: CUSTOMERS } }, options || {}));
}

function sentTo(run, prefix) {
  return run.trace.fetched.filter((item) => item.url.indexOf(prefix) === 0);
}

test("通知: UrlFetchApp.fetch そのものが投げても保存は済み、_通知ログ に 1 行", () => {
  const run = seeded({
    respond: (url) => {
      if (url === SLACK) throw new Error("Address unavailable");
      return undefined;
    },
  });
  assert.deepEqual(run.entry.api_create("顧客", { 会社名: "みなと商店" }), { id: "20260916-003" });
  assert.equal(run.entry.api_get("顧客", "20260916-003").row.会社名, "みなと商店");
  const log = run.sheets["_通知ログ"].rows;
  assert.equal(log.length, 2);
  assert.deepEqual(log[1], ["2026-09-16 10:40:00", "顧客", "登録", "20260916-003", "slack", "送れませんでした（Address unavailable）"]);
  assert.equal(log[1].join("").includes(SLACK), false, "URL は残さない");
});

test("通知: 更新が先を越されて（競合で）失敗したときは通知しない", () => {
  const run = seeded();
  assert.throws(() => run.entry.api_update("顧客", "20260916-001", { 会社名: "みなと工務店", 状況: "取引中" }, "2026-09-16 09:00:00"), /ほかの方が先に更新しました/);
  assert.equal(sentTo(run, SLACK).length, 0);
  assert.equal(run.sheets["_通知ログ"], undefined);
});

test("設定「画面の URL」があれば、通知の URL とメニュー「Web アプリの URL」はそれを使う（getUrl() は webhook 用を返しうる）", () => {
  const run = seeded({ appUrl: "https://script.google.com/macros/s/HOOK/exec" }, [["画面の URL", SCREEN]]);
  run.entry.api_create("顧客", { 会社名: "みなと商店" });
  const text = JSON.parse(sentTo(run, SLACK)[0].payload).text;
  assert.ok(text.endsWith("\n" + SCREEN + "#" + encodeURIComponent("顧客") + "/20260916-003"), text);
  assert.equal(text.includes("HOOK"), false);
  run.entry.showAppUrl();
  assert.ok(run.trace.alerts[0].includes(SCREEN));
  // 空なら getUrl()
  const plain = seeded({ appUrl: "https://script.google.com/macros/s/XXX/exec" });
  plain.entry.api_create("顧客", { 会社名: "みなと商店" });
  assert.ok(JSON.parse(sentTo(plain, SLACK)[0].payload).text.includes("https://script.google.com/macros/s/XXX/exec#"));
});

test("通知: お客さまの名前は Slack でメンションにならない（& < > を文字参照に）", () => {
  const run = seeded();
  run.entry.api_create("顧客", { 会社名: "<!channel> A&B" });
  const text = JSON.parse(sentTo(run, SLACK)[0].payload).text;
  assert.ok(text.includes("&lt;!channel&gt; A&amp;B"));
  assert.equal(text.includes("<!channel>"), false);
});
