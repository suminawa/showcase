import { test } from "node:test";
import assert from "node:assert/strict";
import { formatId, parseId, nextId, isId, laterId } from "../src/ids.js";

test("ID は日付と 3 桁の連番。日付が変わると 001 から", () => {
  assert.equal(formatId("2026-09-16", 1), "20260916-001");
  assert.equal(formatId("2026-09-16", 1000), "20260916-1000");
  assert.deepEqual(parseId("20260916-003"), { dateKey: "2026-09-16", sequence: 3 });
  assert.equal(parseId("x"), null);
  assert.equal(nextId("", "2026-09-16"), "20260916-001");
  assert.equal(nextId("20260916-003", "2026-09-16"), "20260916-004");
  assert.equal(nextId("20260915-009", "2026-09-16"), "20260916-001");
  assert.equal(isId("20260916-003"), true);
  assert.equal(isId("2026-09-16"), false);
});

test("laterId は後ろの方の ID を返す。読めない方は無視する", () => {
  assert.equal(laterId("20260916-003", "20260916-010"), "20260916-010");
  assert.equal(laterId("20260917-001", "20260916-010"), "20260917-001");
  assert.equal(laterId("", "20260916-002"), "20260916-002");
  assert.equal(laterId("手で書いた", ""), "");
});
