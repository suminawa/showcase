import { test } from "node:test";
import assert from "node:assert/strict";
import { runInContext } from "node:vm";
import { loadBundle, plain } from "./fakes.mjs";
import { TEMPLATES } from "../src/samples.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const DEFINITION = [
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "見込み", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "", ""],
];
const HEADER_ROW = ["ID", "会社名", "状況", "最終連絡日", "年間取引額", "要注意", "作成日時", "更新日時", "更新者"];

/** vm の中の関数を呼ぶ。配列・オブジェクトの deepEqual には plain() を通す（realm が違うため） */
function evalIn(run, code) {
  return runInContext(code, run.context);
}

test("readSettings_ / readDefinition_: シートが無ければ既定値と誤り", () => {
  const run = loadBundle({ sheets: {} });
  const out = plain(evalIn(run, "({ s: readSettings_(), d: readDefinition_() })"));
  assert.equal(out.s.settings.appName, "業務アプリ");
  assert.deepEqual(out.s.errors, []);
  assert.equal(out.d.tables.length, 0);
  assert.ok(out.d.errors[0].includes("「定義」シートがありません"));
});

test("ensureTable_ はシートと見出しを作り、足りない見出しを右端に足す。readTable_ は ID の無い行を飛ばす", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [["ID", "会社名", "状況", "作成日時", "更新日時", "更新者", "備考"], ["20260901-001", "みなと工務店", "取引中", "2026-09-01 10:00:00", "2026-09-01 10:00:00", "a@example.com", "手で足した列"], ["", "ID の無い行", "", "", "", "", ""]] } });
  evalIn(run, "ensureTable_(readDefinition_().tables[0])");
  assert.deepEqual(run.sheets["顧客"].rows[0], ["ID", "会社名", "状況", "作成日時", "更新日時", "更新者", "備考", "最終連絡日", "年間取引額", "要注意"]);
  const read = plain(evalIn(run, "readTable_(readDefinition_().tables[0])"));
  assert.equal(read.records.length, 1);
  assert.deepEqual(read.rowNumbers, { "20260901-001": 2 });
  const record = read.records[0];
  assert.equal(record.会社名, "みなと工務店");
  assert.equal(record.最終連絡日, "");
  assert.equal(record.年間取引額, null);
  assert.equal(record.要注意, false);
  assert.equal(record.更新日時, "2026-09-01 10:00:00");
  assert.equal(record.備考, undefined, "定義に無い列は API に出さない");
  // 新しいシートは見出しつきで作られる
  const made = loadBundle({ sheets: { 定義: DEFINITION } });
  evalIn(made, "ensureTable_(readDefinition_().tables[0])");
  assert.deepEqual(made.sheets["顧客"].rows, [HEADER_ROW]);
});

test("appendRecord_ / updateRecord_ / deleteRecord_: 見出しの名前で書き、手で足した列と数式は壊さず、削除は _ごみ箱 に写す", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [["ID", "備考", "計算", "会社名", "状況", "最終連絡日", "年間取引額", "要注意", "作成日時", "更新日時", "更新者"]] } });
  const record = { ID: "20260916-001", 会社名: "=悪意", 状況: "見込み", 最終連絡日: "2026-09-16", 年間取引額: 1200, 要注意: true, 作成日時: "2026-09-16 10:40:00", 更新日時: "2026-09-16 10:40:00", 更新者: "taro@example.com" };
  run.sandbox.__record = record;
  const rowNumber = evalIn(run, "appendRecord_(readDefinition_().tables[0], __record)");
  assert.equal(rowNumber, 2);
  const row = run.sheets["顧客"].rows[1];
  assert.equal(row[0], "20260916-001");
  assert.equal(row[1], "");
  assert.equal(row[3], "=悪意", "' 付きで書くので、数式ではなく文字として残る");
  assert.equal(row[5].toISOString(), "2026-09-15T15:00:00.000Z");
  assert.equal(row[6], 1200);
  assert.equal(row[7], true);
  assert.equal(row[9], "2026-09-16 10:40:00", "更新日時は秒まで文字のまま");
  // 手で備考を書き、その隣に数式を入れたあとに更新しても、どちらも消えない
  run.sheets["顧客"].rows[1][1] = "0012";
  run.sheets["顧客"].getRange(2, 3, 1, 1).setValues([["=A2"]]);
  run.sandbox.__update = { 会社名: "みなと工務店", 更新日時: "2026-09-16 11:00:00", 更新者: "hanako@example.com" };
  evalIn(run, "updateRecord_(readDefinition_().tables[0], 2, __update)");
  assert.equal(run.sheets["顧客"].rows[1][1], "0012", "触らない文字のセルも数値に解釈されない（' を付け直す）");
  assert.equal(run.sheets["顧客"].rows[1][8], "2026-09-16 10:40:00", "作成日時も秒までの文字のまま");
  assert.equal(run.sheets["顧客"].getRange(2, 3, 1, 1).getFormulas()[0][0], "=A2", "手で足した数式は値に潰さない");
  assert.equal(run.sheets["顧客"].rows[1][3], "みなと工務店");
  assert.equal(run.sheets["顧客"].rows[1][9], "2026-09-16 11:00:00");
  assert.equal(run.sheets["顧客"].rows[1][6], 1200, "触っていない列はそのまま");
  evalIn(run, "deleteRecord_(readDefinition_().tables[0], 2, '20260916-001', __record, 'taro@example.com', '2026-09-16 11:05:00')");
  assert.equal(run.sheets["顧客"].rows.length, 1);
  const trash = run.sheets["_ごみ箱"].rows;
  assert.deepEqual(trash[0], ["元テーブル", "ID", "削除日時", "削除者", "行の内容（JSON）"]);
  assert.equal(trash[1][0], "顧客");
  assert.equal(trash[1][1], "20260916-001");
  assert.equal(trash[1][3], "taro@example.com");
  assert.ok(JSON.parse(trash[1][4]).会社名 === "=悪意");
});

test("assignMissingIds_ は ID の無い行に番号を振る", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [HEADER_ROW, ["", "a", "", "", "", "", "", "", ""], ["20260916-001", "b", "", "", "", "", "", "", ""], ["", "c", "", "", "", "", "", "", ""]] } });
  run.sandbox.__ids = ["20260916-002", "20260916-003"];
  const n = evalIn(run, "assignMissingIds_(readDefinition_().tables[0], function () { return __ids.shift(); })");
  assert.equal(n, 2);
  assert.equal(run.sheets["顧客"].rows[1][0], "20260916-002");
  assert.equal(run.sheets["顧客"].rows[3][0], "20260916-003");
  assert.equal(run.sheets["顧客"].rows[1][6], "2026-09-16 10:40:00", "作成日時が空なら今を入れる");
});

test("assignMissingIds_ は列ごとにまとめて書く（行が増えても書き込みは増えない）", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [HEADER_ROW, ["", "a", "", "", "", "", "", "", ""], ["", "b", "", "", "", "", "", "", ""], ["", "c", "", "", "", "", "", "", ""]] } });
  run.sandbox.__ids = ["20260916-001", "20260916-002", "20260916-003"];
  assert.equal(evalIn(run, "assignMissingIds_(readDefinition_().tables[0], function () { return __ids.shift(); })"), 3);
  assert.ok(run.sheets["顧客"].writes <= 3, "ID・作成日時・更新日時 の 3 回まで（いまは " + run.sheets["顧客"].writes + " 回）");
});

test("loadTemplate_: 定義とテーブルを書く。定義に行があれば断る", () => {
  const run = loadBundle({ sheets: {} });
  run.sandbox.__template = TEMPLATES["顧客管理"];
  const result = plain(evalIn(run, "loadTemplate_(__template)"));
  assert.equal(result.definitionRows, TEMPLATES["顧客管理"].definition.length - 1);
  assert.deepEqual(result.tables, { 顧客: 20, 対応履歴: 30 });
  assert.equal(run.sheets["定義"].rows.length, TEMPLATES["顧客管理"].definition.length);
  assert.equal(run.sheets["顧客"].rows.length, 21);
  assert.equal(run.sheets["顧客"].rows[1][0], "20260901-001");
  assert.equal(run.sheets["対応履歴"].rows.length, 31);
  assert.throws(() => evalIn(run, "loadTemplate_(__template)"), /定義がすでにある/);
});

test("ensureSettingsSheet_ / ensureDefinitionSheet_ と、権限エラーの言い換え", () => {
  const run = loadBundle({ sheets: {} });
  assert.deepEqual(evalIn(run, "ensureSettingsSheet_()"), { made: true, added: 0 });
  assert.deepEqual(evalIn(run, "ensureSettingsSheet_()"), { made: false, added: 0 });
  assert.equal(run.sheets["設定"].rows[1][0], "アプリ名");
  assert.equal(evalIn(run, "ensureDefinitionSheet_()"), true);
  assert.deepEqual(run.sheets["定義"].rows[0], HEADER);
  const translated = evalIn(run, "translatePermissionError_(new Error('You do not have permission to call SpreadsheetApp.Range.setValues'))");
  assert.ok(translated.message.includes("編集権限がありません"));
  const other = evalIn(run, "translatePermissionError_(new Error('boom'))");
  assert.equal(other.message, "boom");
});
