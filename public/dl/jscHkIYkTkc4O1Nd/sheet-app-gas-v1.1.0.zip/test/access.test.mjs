import { test } from "node:test";
import assert from "node:assert/strict";
import { canEdit, parseEmails } from "../src/access.js";

test("編集できる人が空なら誰でも。あれば含まれる人だけ（大文字小文字・空白を無視）。メールが空の人は、空の一覧でも編集できない", () => {
  assert.equal(canEdit("taro@example.com", []), true);
  assert.equal(canEdit("", []), false);
  assert.equal(canEdit("  ", undefined), false);
  assert.equal(canEdit(null, []), false);
  assert.equal(canEdit("Taro@Example.com ", ["taro@example.com"]), true);
  assert.equal(canEdit("taro@example.com", [" TARO@example.com "]), true);
  assert.equal(canEdit("hanako@example.com", ["taro@example.com"]), false);
  assert.equal(canEdit("", ["taro@example.com"]), false);
  assert.deepEqual(parseEmails(" A@x.jp, b@y.jp、"), ["a@x.jp", "b@y.jp"]);
});
