import { test } from "node:test";
import assert from "node:assert/strict";
import { toDateKey, toDateTimeKey, formatStamp, compactDate, toHalfWidth, dateFromKey, dateTimeFromKey } from "../src/dates.js";

test("toDateKey: Date は +9 時間、文字は - / 年月日 を読む。2/30 は null", () => {
  assert.equal(toDateKey(new Date("2026-09-15T15:30:00Z")), "2026-09-16");
  assert.equal(toDateKey("2026/9/6"), "2026-09-06");
  assert.equal(toDateKey("２０２６－０９－０６"), "2026-09-06");
  assert.equal(toDateKey("2026年9月6日"), "2026-09-06");
  assert.equal(toDateKey("2026-02-30"), null);
  assert.equal(toDateKey(""), null);
  assert.equal(toDateKey("きょう"), null);
});

test("toDateTimeKey: Date と 3 つの書き方を読み、秒は落とす", () => {
  assert.equal(toDateTimeKey(new Date("2026-09-16T01:05:09Z")), "2026-09-16 10:05");
  assert.equal(toDateTimeKey("2026-09-16 10:30"), "2026-09-16 10:30");
  assert.equal(toDateTimeKey("2026/9/16T9:05"), "2026-09-16 09:05");
  assert.equal(toDateTimeKey("2026-09-16 10:30:45"), "2026-09-16 10:30");
  assert.equal(toDateTimeKey("2026-09-16 25:00"), null);
  assert.equal(toDateTimeKey("2026-09-16"), null);
});

test("formatStamp・compactDate・toHalfWidth・dateFromKey・dateTimeFromKey", () => {
  assert.equal(formatStamp(new Date("2026-09-16T01:05:09Z")), "2026-09-16 10:05:09");
  assert.throws(() => formatStamp("x"), /日時を読めません/);
  assert.equal(compactDate("2026-09-16"), "20260916");
  assert.equal(toHalfWidth("ＡＢＣ１２３＠　x"), "ABC123@ x");
  assert.equal(dateFromKey("2026-09-16").toISOString(), "2026-09-15T15:00:00.000Z");
  assert.equal(dateFromKey("x"), null);
  assert.equal(dateTimeFromKey("2026-09-16 10:30").toISOString(), "2026-09-16T01:30:00.000Z");
  assert.equal(dateTimeFromKey("x"), null);
});
