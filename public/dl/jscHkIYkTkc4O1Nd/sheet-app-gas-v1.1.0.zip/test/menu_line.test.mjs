import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle } from "./fakes.mjs";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const DEFINITION = [HEADER, ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""], ["顧客", "LINE", "LINE", "", "", "FALSE", "", "", ""]];
const SLACK = "https://hooks.slack.com/services/T000/B000/XXXX";
const ME = "U" + "f".repeat(32);

test("メニュー「業務アプリ」に「通知のテストを送る」がある", () => {
  const run = loadBundle({ sheets: {} });
  run.entry.onOpen();
  assert.ok(run.trace.menu.some((item) => item[0] === "通知のテストを送る" && item[1] === "sendTestNotification"));
  assert.ok(run.trace.menu.some((item) => item[0] === "設定を確かめる" && item[1] === "checkSettings"));
});

test("設定を確かめる: 通知の行の誤りと、定義に無いテーブル名を並べる", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION, 設定: [["通知先", "slak, slack"], ["Slack Webhook URL", SLACK], ["通知するテーブル", "案件"]] } });
  run.entry.checkSettings();
  const text = run.trace.alerts[0];
  assert.ok(text.startsWith("直すところがあります。"));
  assert.ok(text.includes("「通知先」に書けるのは slack / discord / line です: slak"));
  assert.ok(text.includes("設定「通知するテーブル」の「案件」は定義にありません"));
});

test("設定を確かめる: 誤りが無ければ「問題ありません」に、通知と LINE の状態を添える", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION } });
  run.entry.checkSettings();
  const text = run.trace.alerts[0];
  assert.ok(text.includes("問題ありません"));
  assert.ok(text.includes("顧客（2 列）"));
  assert.ok(text.includes("通知: 使っていません（設定「通知先」が空です）"));
  assert.ok(text.includes("「LINE チャネルアクセストークン」が空のため使えません"));
});

test("通知のテストを送る: 通知先が空なら案内。あれば全宛先に送って、宛先ごとの結果を並べる", () => {
  const empty = loadBundle({ sheets: {} });
  empty.entry.sendTestNotification();
  assert.ok(empty.trace.alerts[0].includes("設定「通知先」が空のため、送る先がありません"));
  assert.equal(empty.trace.fetched.length, 0);
  const run = loadBundle({
    sheets: { 設定: [["通知先", "slack, line"], ["Slack Webhook URL", SLACK], ["LINE チャネルアクセストークン", "line-token"], ["LINE 送信先 ID", ME]] },
    respond: (url) => (url.indexOf("https://api.line.me/") === 0 ? { status: 403, body: {} } : undefined),
  });
  run.entry.sendTestNotification();
  assert.equal(run.trace.fetched.length, 2);
  assert.equal(JSON.parse(run.trace.fetched[0].payload).text, "【業務アプリ】これはテストです。通知の設定ができています。");
  assert.equal(run.trace.alerts[0], "通知のテストを送りました。\n\nslack: 送りました\nline: 送れませんでした（403 が返りました）");
});
