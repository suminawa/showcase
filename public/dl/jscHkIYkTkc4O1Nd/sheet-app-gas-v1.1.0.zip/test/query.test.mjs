import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDefinition } from "../src/definition.js";
import { OPS, normalizeQuery, normalizeText, filterRows, sortRows, paginate, applyQuery } from "../src/query.js";

const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const { tables } = parseDefinition([
  HEADER,
  ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""],
  ["顧客", "状況", "選択", "", "見込み, 取引中, 休眠", "", "", "", ""],
  ["顧客", "分野", "複数選択", "", "設計, 施工, 保守", "", "", "", ""],
  ["顧客", "年間取引額", "金額", "", "", "", "", "", ""],
  ["顧客", "最終連絡日", "日付", "", "", "", "", "", ""],
  ["顧客", "要注意", "チェック", "", "", "", "", "", ""],
  ["顧客", "メモ", "長文", "", "", "FALSE", "FALSE", "", ""],
  ["顧客", "担当", "参照:顧客", "", "", "", "", "", ""],
]);
const T = tables[0];
const rows = [
  { ID: "20260901-001", 会社名: "みなと工務店", 状況: "取引中", 分野: ["設計", "施工"], 年間取引額: 1200000, 最終連絡日: "2026-09-10", 要注意: false, メモ: "横浜の現場", 担当: "20260901-002", 更新日時: "2026-09-10 10:00:00" },
  { ID: "20260901-002", 会社名: "うみかぜ商店", 状況: "見込み", 分野: [], 年間取引額: null, 最終連絡日: "", 要注意: true, メモ: "", 担当: "", 更新日時: "2026-09-12 09:00:00" },
  { ID: "20260901-003", 会社名: "さくら不動産 Ｙｏｋｏｈａｍａ", 状況: "休眠", 分野: ["保守"], 年間取引額: 300000, 最終連絡日: "2026-08-01", 要注意: false, メモ: "", 担当: "20260901-001", 更新日時: "2026-09-11 08:00:00" },
];

test("normalizeQuery: 知らない列・op を落とし、page と pageSize を範囲に収める", () => {
  const q = normalizeQuery(T, { q: " 横浜 ", filters: [{ column: "状況", op: "eq", value: "取引中" }, { column: "無い", op: "eq", value: 1 }, { column: "会社名", op: "like", value: "x" }], sort: { column: "年間取引額", dir: "DESC" }, page: 0, pageSize: 1000 });
  assert.equal(q.q, "横浜");
  assert.deepEqual(q.filters, [{ column: "状況", op: "eq", value: "取引中" }]);
  assert.deepEqual(q.sort, { column: "年間取引額", dir: "desc" });
  assert.equal(q.page, 1);
  assert.equal(q.pageSize, 200);
  const empty = normalizeQuery(T, null);
  assert.deepEqual(empty, { q: "", filters: [], sort: null, page: 1, pageSize: 50 });
  assert.equal(normalizeQuery(T, { sort: { column: "ID", dir: "asc" } }).sort.column, "ID");
  assert.equal(normalizeQuery(T, { sort: { column: "無い", dir: "asc" } }).sort, null);
  assert.equal(OPS.length, 11);
});

test("q は 検索 の列の部分一致。全角半角と大文字小文字を同一視。長文の検索 FALSE は見ない", () => {
  assert.equal(normalizeText("Ｙｏｋｏｈａｍａ　ABC"), "yokohama abc");
  assert.deepEqual(filterRows(T, rows, normalizeQuery(T, { q: "yokohama" })).map((r) => r.ID), ["20260901-003"]);
  assert.deepEqual(filterRows(T, rows, normalizeQuery(T, { q: "横浜" })).map((r) => r.ID), []);
  assert.deepEqual(filterRows(T, rows, normalizeQuery(T, { q: "みなと" })).map((r) => r.ID), ["20260901-001"]);
});

test("絞り込み: eq / ne / contains / gt / lt / between / in / empty / notEmpty を型ごとに解く", () => {
  const ids = (filters) => filterRows(T, rows, normalizeQuery(T, { filters: filters })).map((r) => r.ID);
  assert.deepEqual(ids([{ column: "状況", op: "eq", value: "見込み" }]), ["20260901-002"]);
  assert.deepEqual(ids([{ column: "状況", op: "ne", value: "見込み" }]), ["20260901-001", "20260901-003"]);
  assert.deepEqual(ids([{ column: "状況", op: "in", value: ["見込み", "休眠"] }]), ["20260901-002", "20260901-003"]);
  assert.deepEqual(ids([{ column: "会社名", op: "contains", value: "不動産" }]), ["20260901-003"]);
  assert.deepEqual(ids([{ column: "年間取引額", op: "gt", value: "300000" }]), ["20260901-001"]);
  assert.deepEqual(ids([{ column: "年間取引額", op: "gte", value: 300000 }]), ["20260901-001", "20260901-003"]);
  assert.deepEqual(ids([{ column: "年間取引額", op: "lt", value: "1000000" }]), ["20260901-003"]);
  assert.deepEqual(ids([{ column: "年間取引額", op: "between", value: ["200000", "400000"] }]), ["20260901-003"]);
  assert.deepEqual(ids([{ column: "最終連絡日", op: "gte", value: "2026-09-01" }]), ["20260901-001"]);
  assert.deepEqual(ids([{ column: "最終連絡日", op: "between", value: ["2026-08-01", "2026-08-31"] }]), ["20260901-003"]);
  assert.deepEqual(ids([{ column: "最終連絡日", op: "empty", value: "" }]), ["20260901-002"]);
  assert.deepEqual(ids([{ column: "年間取引額", op: "notEmpty", value: "" }]), ["20260901-001", "20260901-003"]);
  assert.deepEqual(ids([{ column: "要注意", op: "eq", value: "true" }]), ["20260901-002"]);
  assert.deepEqual(ids([{ column: "要注意", op: "eq", value: false }]), ["20260901-001", "20260901-003"]);
  assert.deepEqual(ids([{ column: "要注意", op: "eq", value: "はい" }]), ["20260901-002"], "画面の select は はい / いいえ を送る");
  // チェックに in / contains / gt を当てても、誰にも当たらない（黙って eq に読み替えない）
  assert.deepEqual(ids([{ column: "要注意", op: "in", value: ["true", "false"] }]), []);
  assert.deepEqual(ids([{ column: "要注意", op: "contains", value: "t" }]), []);
  assert.deepEqual(ids([{ column: "更新日時", op: "gte", value: "2026-09-11" }]), ["20260901-002", "20260901-003"]);
  assert.deepEqual(ids([{ column: "分野", op: "in", value: ["施工", "保守"] }]), ["20260901-001", "20260901-003"]);
  assert.deepEqual(ids([{ column: "分野", op: "contains", value: "設" }]), ["20260901-001"]);
  assert.deepEqual(ids([{ column: "担当", op: "eq", value: "20260901-001" }]), ["20260901-003"]);
  assert.deepEqual(ids([{ column: "担当", op: "in", value: ["20260901-001", "20260901-002"] }]), ["20260901-001", "20260901-003"]);
  // 数値の絞り込みに数でない値が来たら、その条件は誰にも当たらない
  assert.deepEqual(ids([{ column: "年間取引額", op: "gt", value: "たくさん" }]), []);
  // 2 つの条件は AND
  assert.deepEqual(ids([{ column: "状況", op: "ne", value: "見込み" }, { column: "分野", op: "in", value: ["保守"] }]), ["20260901-003"]);
});

test("並び替え: 金額は数で（空は末尾）、日付は文字で、文字は日本語の照合。既定は更新日時の降順", () => {
  const byAmount = sortRows(T, rows, { column: "年間取引額", dir: "asc" }).map((r) => r.ID);
  assert.deepEqual(byAmount, ["20260901-003", "20260901-001", "20260901-002"]);
  const byAmountDesc = sortRows(T, rows, { column: "年間取引額", dir: "desc" }).map((r) => r.ID);
  assert.deepEqual(byAmountDesc, ["20260901-001", "20260901-003", "20260901-002"]);
  const byDate = sortRows(T, rows, { column: "最終連絡日", dir: "asc" }).map((r) => r.ID);
  assert.deepEqual(byDate, ["20260901-003", "20260901-001", "20260901-002"]);
  const byName = sortRows(T, rows, { column: "会社名", dir: "asc" }).map((r) => r.会社名);
  assert.deepEqual(byName, ["うみかぜ商店", "さくら不動産 Ｙｏｋｏｈａｍａ", "みなと工務店"]);
  const byDefault = sortRows(T, rows, null).map((r) => r.ID);
  assert.deepEqual(byDefault, ["20260901-002", "20260901-003", "20260901-001"]);
  // 元の配列は変えない
  assert.equal(rows[0].ID, "20260901-001");
});

test("paginate と applyQuery", () => {
  assert.deepEqual(paginate([1, 2, 3, 4, 5], 2, 2), [3, 4]);
  assert.deepEqual(paginate([1, 2, 3], 5, 2), []);
  const result = applyQuery(T, rows, normalizeQuery(T, { sort: { column: "ID", dir: "asc" }, page: 2, pageSize: 10 }));
  assert.deepEqual(result, { rows: [], total: 3, page: 2, pageSize: 10 });
  const first = applyQuery(T, rows, normalizeQuery(T, { q: "", sort: { column: "ID", dir: "asc" }, page: 1, pageSize: 2 }));
  assert.equal(first.total, 3);
  assert.deepEqual(first.rows.map((r) => r.ID), ["20260901-001", "20260901-002"]);
});

test("normalizeQuery: q は 200 字、filters は 20 件までに切る", () => {
  const many = [];
  for (let i = 0; i < 25; i += 1) many.push({ column: "会社名", op: "contains", value: "x" + i });
  const q = normalizeQuery(T, { q: "あ".repeat(300), filters: many });
  assert.equal(q.q.length, 200);
  assert.equal(q.filters.length, 20);
  assert.equal(q.filters[19].value, "x19");
});
