/**
 * スプレッドシートのメニュー「業務アプリ」。Web アプリの入口は gas_web.js（doGet と api_*）。
 * dist/Code.gs の先頭に来るファイル。
 */
import { toDateKey } from "./dates.js";
import { laterId, nextId } from "./ids.js";
import { TEMPLATES } from "./samples.js";
import { formatUsage } from "./usage.js";
import { buildTestNotifyText } from "./notify.js";
import { crossCheckSettings, settingsSummary } from "./settings.js";
import { readLastId_, readMonthUsage_, saveLastId_ } from "./gas_store.js";
import { assignMissingIds_, ensureDefinitionSheet_, ensureSettingsSheet_, ensureTable_, loadTemplate_, readDefinition_, readIds_, readSettings_ } from "./gas_sheets.js";
import { ensureNotifyLog_, notifyAll_, webAppUrl_ } from "./gas_notify.js";
import { ensureLineSheets_, receiveLineWebhook_ } from "./gas_line.js";
import { maxIdOf_ } from "./gas_web.js";

const MENU_TITLE = "業務アプリ";

function ui_() {
  return SpreadsheetApp.getUi();
}

function alert_(text) {
  ui_().alert(text);
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

export function onOpen() {
  ui_()
    .createMenu(MENU_TITLE)
    .addItem("初期化（シートと見出しを作る）", "initializeSheets")
    .addSeparator()
    .addItem("見本を読み込む: 顧客管理", "loadSampleCustomers")
    .addItem("見本を読み込む: 案件管理", "loadSampleProjects")
    .addItem("見本を読み込む: 在庫管理", "loadSampleInventory")
    .addSeparator()
    .addItem("設定を確かめる", "checkSettings")
    .addItem("通知のテストを送る", "sendTestNotification")
    .addItem("Web アプリの URL", "showAppUrl")
    .addItem("今月の AI 利用", "showAiUsage")
    .addToUi();
}

/** 設定・定義・各テーブルのシートと、_LINE友だち・_LINE送信履歴・_通知ログ を作り、設定に足りない行を足し、ID の無い行に番号を振る */
export function initializeSheets() {
  try {
    const settingsResult = ensureSettingsSheet_();
    ensureLineSheets_();
    ensureNotifyLog_();
    const madeDefinition = ensureDefinitionSheet_();
    const definition = readDefinition_();
    if (definition.errors.length > 0) {
      alert_((madeDefinition ? "「設定」と「定義」のシートを作りました。" : "") + "定義に直すところがあります。\n\n" + definition.errors.join("\n") + "\n\n定義を直してから、もう一度「初期化」を実行してください。まず試すなら「見本を読み込む」が早いです");
      return;
    }
    const today = toDateKey(new Date());
    let assigned = 0;
    const names = [];
    for (let i = 0; i < definition.tables.length; i += 1) {
      const table = definition.tables[i];
      ensureTable_(table);
      names.push(table.name);
      // 出発点は「覚え書き」と「シートに残っている今日の ID」の後ろの方。連番はメモリで進め、覚え書きは最後に 1 回だけ書く
      let last = laterId(readLastId_(table.name), maxIdOf_(readIds_(table), today));
      assigned += assignMissingIds_(table, () => {
        last = nextId(last, today);
        return last;
      });
      if (last !== "") saveLastId_(table.name, last);
    }
    const settingsNote = settingsResult && settingsResult.added > 0 ? "「設定」に " + settingsResult.added + " 行（通知・LINE の項目）を足しました。値は空のままなので、使うときに入れてください。\n" : "";
    alert_("初期化しました。テーブル: " + names.join("、") + "。ID を " + assigned + " 件振りました。\n" + settingsNote + "次は「デプロイ」→「新しいデプロイ」→「ウェブアプリ」で公開し、「Web アプリの URL」で URL を確かめてください");
  } catch (error) {
    alert_(failureText_(error));
  }
}

function loadSample_(name) {
  try {
    ensureSettingsSheet_();
    const result = loadTemplate_(TEMPLATES[name]);
    const parts = Object.keys(result.tables).map((table) => table + " " + result.tables[table] + " 件");
    alert_("見本「" + name + "」を読み込みました。定義 " + result.definitionRows + " 行、" + parts.join("、") + "。\n次は「初期化」を実行してから、「デプロイ」→「新しいデプロイ」→「ウェブアプリ」で公開してください");
  } catch (error) {
    alert_(failureText_(error));
  }
}

export function loadSampleCustomers() {
  loadSample_("顧客管理");
}

export function loadSampleProjects() {
  loadSample_("案件管理");
}

export function loadSampleInventory() {
  loadSample_("在庫管理");
}

/** 定義・設定の誤り（通知と LINE の行を含む）を並べる。無ければ、通知と LINE の状態を添えて「問題ありません」 */
export function checkSettings() {
  try {
    const settings = readSettings_();
    const definition = readDefinition_();
    const errors = definition.errors.concat(settings.errors, settings.notifyErrors, crossCheckSettings(settings.settings, definition.tables));
    if (errors.length > 0) {
      alert_("直すところがあります。\n\n" + errors.join("\n"));
      return;
    }
    const tables = definition.tables.map((t) => t.name + "（" + t.columns.length + " 列）").join("、");
    alert_("問題ありません。アプリ名「" + settings.settings.appName + "」、テーブル: " + tables + "\n\n" + settingsSummary(settings.settings, definition.tables).join("\n"));
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 設定の通知先すべてに「これはテストです」を送り、宛先ごとの結果を出す */
export function sendTestNotification() {
  try {
    const read = readSettings_();
    const settings = read.settings;
    if (settings.notifyTargets.length === 0) {
      alert_("設定「通知先」が空のため、送る先がありません。slack・discord・line のいずれかを書いてから、もう一度お試しください" + (read.notifyErrors.length > 0 ? "\n\n" + read.notifyErrors.join("\n") : ""));
      return;
    }
    const results = notifyAll_(settings, buildTestNotifyText(settings.appName));
    const lines = results.map((result) => result.target + ": " + result.message);
    const notes = read.notifyErrors.length > 0 ? "\n\n直すところがあります。\n" + read.notifyErrors.join("\n") : "";
    alert_("通知のテストを送りました。\n\n" + lines.join("\n") + notes);
  } catch (error) {
    alert_(failureText_(error));
  }
}

export function showAppUrl() {
  let settings = null;
  try {
    settings = readSettings_().settings;
  } catch (error) {
    settings = null;
  }
  // 設定「画面の URL」があればそれ（webhook 用のデプロイの URL を配ってしまわないように）
  const url = webAppUrl_(settings);
  if (url === "") {
    alert_("まだ公開されていません。「デプロイ」→「新しいデプロイ」→ 種類「ウェブアプリ」→ 次のユーザーとして実行「ウェブアプリにアクセスしているユーザー」・アクセスできるユーザー「Google アカウントを持つ全員」で公開してから、もう一度お試しください");
    return;
  }
  alert_("Web アプリの URL:\n" + url + "\n\nこの URL をスタッフに配ってください。スプレッドシートを共有（閲覧者か編集者）した人だけが使えます");
}

export function showAiUsage() {
  try {
    const settings = readSettings_().settings;
    const month = toDateKey(new Date()).slice(0, 7);
    alert_(formatUsage(readMonthUsage_(month), settings.model, month));
  } catch (error) {
    alert_(failureText_(error));
  }
}

/**
 * LINE の webhook の受け口。webhook 用のデプロイ（次のユーザーとして実行「自分」・アクセス「全員」）の URL に
 * ?hook=line を付けて LINE に登録してもらう。?hook=line の無い要求は断る（Apps Script は状態コードを選べないので、not found の文字だけを返す）。
 * 処理に失敗しても OK を返す（LINE が同じ知らせを送り直し続けないように）。失敗は実行ログに残す
 */
export function doPost(e) {
  const hook = e && e.parameter ? String(e.parameter.hook || "") : "";
  if (hook !== "line") return ContentService.createTextOutput("not found").setMimeType(ContentService.MimeType.TEXT);
  try {
    receiveLineWebhook_(e.postData ? e.postData.contents : "");
  } catch (error) {
    Logger.log("業務アプリ: LINE の webhook を処理できませんでした: " + (error && error.message ? error.message : error));
  }
  return ContentService.createTextOutput("OK").setMimeType(ContentService.MimeType.TEXT);
}
