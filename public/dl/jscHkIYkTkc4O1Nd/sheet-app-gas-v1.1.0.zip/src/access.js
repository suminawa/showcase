/**
 * 誰が編集できるか。シートの共有(閲覧者 / 編集者)は Google が判定するので、ここは「編集できる人」の絞り込みだけ。
 */
import { splitList } from "./definition.js";

export function parseEmails(text) {
  return splitList(text).map((s) => s.toLowerCase());
}

/** 利用者の分からない人（メールが空）は編集できない。editors が空なら誰でも編集できる。あれば、その中に含まれる人だけ */
export function canEdit(email, editors) {
  const me = String(email === null || email === undefined ? "" : email).trim().toLowerCase();
  if (me === "") return false;
  const list = (Array.isArray(editors) ? editors : []).map((e) => String(e === null || e === undefined ? "" : e).trim().toLowerCase()).filter((e) => e !== "");
  if (list.length === 0) return true;
  return list.indexOf(me) >= 0;
}
