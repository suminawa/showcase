/**
 * お客さまへの LINE 送信の純粋な処理: webhook の本文の読み取り、ユーザー ID の形、定型文（題|本文）と置き換え、
 * 友だちの一覧の整え、月の送信数、LINE の応答の言い換え、断りの文。画面（App.html）でも同じものを動かす。
 */
import { textOf } from "./text.js";

/** LINE のユーザー ID は U と 32 桁の 16 進 */
export const LINE_USER_ID = /^U[0-9a-f]{32}$/;
/** LINE のテキストメッセージは 5,000 字まで */
export const LINE_TEXT_LIMIT = 5000;
export const FRIENDS_SHEET = "_LINE友だち";
export const FRIENDS_HEADER = ["ユーザー ID", "表示名", "追加日時", "状態"];
export const FRIEND_STATE = "友だち";
export const BLOCKED_STATE = "ブロック";
export const SEND_LOG_SHEET = "_LINE送信履歴";
export const SEND_LOG_HEADER = ["日時", "テーブル", "ID", "送り先ユーザー ID", "送信者", "本文", "結果"];
export const SENT = "送信済み";
/** 詳細画面に出す送信履歴の件数 */
export const HISTORY_LIMIT = 20;
/** 送信と下書きを断るときの文（サーバーと見本で同じものを使う） */
export const LINE_MESSAGES = {
  noColumn: "このテーブルには LINE の列がありません",
  viewer: "この画面では閲覧のみできます。LINE を送るには、スプレッドシートの編集者である必要があります",
  notSender: "LINE を送れるのは、設定「LINE を送れる人」に書かれた方だけです。送る必要がある場合は、所有者に追加をご依頼ください",
  noToken: "LINE の送信は使えません。設定「LINE チャネルアクセストークン」をご確認ください",
  noFriend: "この記録には LINE の友だちが結びついていません。編集で LINE の欄を選んでから送ってください",
  unknown: "この LINE のユーザー ID は友だちの一覧にありません。友だち追加をしていただいてから、もう一度お試しください",
  blocked: "この方は LINE でブロック中のため送れません",
  blockedChoice: "この方は LINE でブロック中のため選べません。ほかの友だちを選ぶか、空にしてください",
  emptyText: "本文を入力してください",
  emptyIntent: "用件を入力してください（例: 先日の内見のお礼と、次の候補日を 2 つ聞く）",
};
const LINE_MARK = /\{([^{}\n]{1,60})\}/g;

export function isLineUserId(value) {
  return LINE_USER_ID.test(textOf(value));
}

/**
 * LINE の webhook の本文から、友だち追加（follow）とブロック（unfollow）だけを取り出す。
 * ほかの出来事（message など）・グループ・形の違う ID は捨てる。本文が JSON のオブジェクトでなければ error に文
 */
export function parseWebhook(body) {
  const broken = { events: [], error: "LINE からの本文を JSON として読めませんでした" };
  let json;
  try {
    json = JSON.parse(String(body === null || body === undefined ? "" : body));
  } catch (error) {
    return broken;
  }
  if (json === null || typeof json !== "object" || Array.isArray(json)) return broken;
  const list = Array.isArray(json.events) ? json.events : [];
  const events = [];
  for (let i = 0; i < list.length; i += 1) {
    const event = list[i];
    if (event === null || typeof event !== "object") continue;
    if (event.type !== "follow" && event.type !== "unfollow") continue;
    const source = event.source && typeof event.source === "object" ? event.source : {};
    if (source.type !== "user" || !isLineUserId(source.userId)) continue;
    events.push({ type: event.type, userId: String(source.userId).trim() });
  }
  return { events: events, error: "" };
}

/** 「LINE 定型文」の値。1 行 1 本の「題|本文」（全角の｜も可）、本文の \n は改行。空行は飛ばす */
export function parseLineTemplates(text) {
  const lines = String(text === null || text === undefined ? "" : text).split(/\r?\n/);
  const templates = [];
  const errors = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i].trim();
    if (line === "") continue;
    const at = line.search(/[|｜]/);
    if (at < 0) {
      errors.push("設定「LINE 定型文」の " + (i + 1) + " 行目に「|」がありません。「題|本文」の形で書いてください");
      continue;
    }
    const title = line.slice(0, at).trim();
    const body = line.slice(at + 1).trim().replace(/\\n/g, "\n");
    if (title === "" || body === "") {
      errors.push("設定「LINE 定型文」の " + (i + 1) + " 行目は、題と本文の両方を書いてください");
      continue;
    }
    templates.push({ title: title.slice(0, 40), body: body });
  }
  return { templates: templates, errors: errors };
}

/**
 * 定型文の本文の置き換え。{担当者名} と列名そのもの（{会社名} など。values は画面に出ている文字）。
 * 知らない印は残す。値の中に {…} があっても置き換えない（1 回の走査）
 */
export function fillLineTemplate(body, context) {
  const values = context && context.values ? context.values : {};
  const staff = context && context.staffName ? String(context.staffName) : "";
  return String(body === null || body === undefined ? "" : body).replace(LINE_MARK, (whole, key) => {
    if (key === "担当者名") return staff;
    if (Object.prototype.hasOwnProperty.call(values, key)) return String(values[key]);
    return whole;
  });
}

/** 本文に残っている {…} の印（重複なし） */
export function leftoverPlaceholders(text) {
  const found = String(text === null || text === undefined ? "" : text).match(LINE_MARK) || [];
  const out = [];
  for (let i = 0; i < found.length; i += 1) if (out.indexOf(found[i]) < 0) out.push(found[i]);
  return out;
}

/** 定型文の {担当者名}。設定「担当者名」、空ならメールの @ の前 */
export function staffNameFor(settings, email) {
  const name = textOf(settings && settings.staffName);
  if (name !== "") return name;
  return textOf(email).split("@")[0];
}

/**
 * _LINE友だち の行（{ userId, name, state }）を画面の候補の形 [{ id, name, blocked }] にする。
 * 表示名が空（profile が取れなかった「未確認」）の ID と、形の違う ID と、2 回目以降の同じ ID は出さない。表示名の順
 */
export function friendsForScreen(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const seen = {};
  const out = [];
  for (let i = 0; i < list.length; i += 1) {
    const row = list[i] || {};
    const id = textOf(row.userId);
    const name = textOf(row.name);
    if (!isLineUserId(id) || name === "" || seen[id] === true) continue;
    seen[id] = true;
    out.push({ id: id, name: name, blocked: textOf(row.state) === BLOCKED_STATE });
  }
  out.sort((a, b) => a.name.localeCompare(b.name, "ja"));
  return out;
}

export function findFriend(friends, id) {
  const key = textOf(id);
  const list = Array.isArray(friends) ? friends : [];
  for (let i = 0; i < list.length; i += 1) if (list[i].id === key) return list[i];
  return null;
}

/** 一覧・詳細に出す LINE の列の文字。友だちなら表示名（ブロック中は印を添える）、一覧に無い ID はそのまま */
export function friendLabel(friends, id) {
  const key = textOf(id);
  if (key === "") return "";
  const friend = findFriend(friends, key);
  if (friend === null) return key;
  return friend.name + (friend.blocked ? "（ブロック中）" : "");
}

/** _LINE送信履歴 の行（{ at, result }）のうち、monthKey（"2026-09"）の「送信済み」の数 */
export function countMonthSends(rows, monthKey) {
  const prefix = textOf(monthKey) + "-";
  const list = Array.isArray(rows) ? rows : [];
  let count = 0;
  for (let i = 0; i < list.length; i += 1) {
    const row = list[i] || {};
    if (textOf(row.result) === SENT && textOf(row.at).indexOf(prefix) === 0) count += 1;
  }
  return count;
}

/** LINE が送信を断ったときの文。LINE の message はそのまま出さず、状態コードごとに敬体で言い換える */
export function lineSendError(status) {
  const code = Number(status) || 0;
  if (code === 0) return "送れませんでした。LINE につながりませんでした。しばらくしてからもう一度お試しください";
  const head = "送れませんでした（LINE の応答: " + code + "）。";
  if (code === 400) return head + "本文か送り先の形が受け付けられませんでした。本文を短くするか、LINE の欄を選び直してください";
  if (code === 401) return head + "設定「LINE チャネルアクセストークン」が正しくないか、失効しています";
  if (code === 403) return head + "ブロックされているか、トークンが失効しています";
  if (code === 429) return head + "今月の送信数の上限に達したか、短い間に送りすぎています。LINE Official Account Manager でプランと送信数をご確認ください";
  return head + "しばらくしてからもう一度お試しください";
}

/** 送る本文の検査。問題が無ければ "" */
export function lineTextError(text) {
  const body = String(text === null || text === undefined ? "" : text).trim();
  if (body === "") return LINE_MESSAGES.emptyText;
  if (body.length > LINE_TEXT_LIMIT) return "本文は 5,000 字以内にしてください（いまは " + body.length.toLocaleString("en-US") + " 字）";
  return "";
}
