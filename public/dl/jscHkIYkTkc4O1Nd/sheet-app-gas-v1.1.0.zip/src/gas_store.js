/**
 * スクリプト プロパティに置く覚え書き: API キー・テーブルごとの ID の続き・1 日の AI 回数・今月のトークン数。
 * 記録の中身は何も残さない。
 */
import { emptyUsage } from "./usage.js";

/** 同時に走った保存を待たせる時間 */
const LOCK_WAIT_MS = 30000;
const API_KEY_PROPERTY = "ANTHROPIC_API_KEY";

function props_() {
  return PropertiesService.getScriptProperties();
}

/** action を 1 つずつ順番に実行する（ID と行の追加が重ならないように）。待っても取れなければ敬体の誤りを投げる */
export function withLock_(action) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(LOCK_WAIT_MS);
  } catch (error) {
    throw new Error("ほかの方の保存が続いています。少し待ってからもう一度お試しください");
  }
  try {
    return action();
  } finally {
    lock.releaseLock();
  }
}

/** 鍵はここからだけ読む。無ければ空 */
export function readApiKey_() {
  const raw = props_().getProperty(API_KEY_PROPERTY);
  return raw ? String(raw).trim() : "";
}

export function readLastId_(table) {
  const raw = props_().getProperty("lastId:" + table);
  return raw ? String(raw) : "";
}

export function saveLastId_(table, id) {
  props_().setProperty("lastId:" + table, String(id));
}

export function readDailyAiCount_(dateKey) {
  const raw = props_().getProperty("ai:" + dateKey);
  const n = Number(raw);
  return Number.isFinite(n) ? n : 0;
}

export function saveDailyAiCount_(dateKey, count) {
  const props = props_();
  props.setProperty("ai:" + dateKey, String(count));
  // 過ぎた日の数は要らないので消す（プロパティが日ごとに増え続けないように）
  const keys = props.getKeys();
  for (let i = 0; i < keys.length; i += 1) {
    if (keys[i].indexOf("ai:") === 0 && keys[i] !== "ai:" + dateKey) props.deleteProperty(keys[i]);
  }
}

export function readMonthUsage_(monthKey) {
  const raw = props_().getProperty("usage:" + monthKey);
  if (!raw) return emptyUsage();
  try {
    const parsed = JSON.parse(raw);
    return Object.assign(emptyUsage(), parsed);
  } catch (error) {
    return emptyUsage();
  }
}

export function saveMonthUsage_(monthKey, usage) {
  props_().setProperty("usage:" + monthKey, JSON.stringify(usage));
}
