/**
 * 検索・絞り込み・並び替え・ページ送り。rows は API の形の記録の配列。元の配列は変えない。
 */
import { toHalfWidth } from "./dates.js";
import { findColumn } from "./definition.js";
import { boolOf, textOf } from "./text.js";

export const OPS = ["contains", "eq", "ne", "gt", "gte", "lt", "lte", "between", "in", "empty", "notEmpty"];
export const DEFAULT_PAGE_SIZE = 50;
const MIN_PAGE_SIZE = 1;
const MAX_PAGE_SIZE = 200;
/** 検索の言葉と条件の数の上限（画面からもらう値を無制限に受けない） */
const MAX_Q_LENGTH = 200;
const MAX_FILTERS = 20;
const NUMBER_TYPES = ["数値", "金額"];
const DATE_TYPES = ["日付", "日時"];
const SYSTEM_SORTABLE = ["ID", "作成日時", "更新日時", "更新者"];

/** 大文字小文字と全角半角の英数を同一視する(かなの正規化はしない) */
export function normalizeText(text) {
  return toHalfWidth(text).toLowerCase();
}

function toNumber_(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const t = toHalfWidth(textOf(value)).replace(/[,¥￥円]/g, "");
  if (t === "") return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

function isEmptyValue_(value) {
  return value === null || value === undefined || value === "" || (Array.isArray(value) && value.length === 0);
}

function columnOf_(table, name) {
  const column = findColumn(table, name);
  if (column !== null) return column;
  if (SYSTEM_SORTABLE.indexOf(name) >= 0) return { name: name, type: "文字", options: [], searchable: false };
  return null;
}

/** 生の query を、定義に合う形に揃える。知らない列・op は落とす */
export function normalizeQuery(table, raw) {
  const source = raw === null || typeof raw !== "object" ? {} : raw;
  const filters = [];
  const list = Array.isArray(source.filters) ? source.filters : [];
  for (let i = 0; i < list.length; i += 1) {
    const f = list[i] === null || typeof list[i] !== "object" ? {} : list[i];
    const column = columnOf_(table, textOf(f.column));
    const op = textOf(f.op);
    if (column === null || OPS.indexOf(op) < 0) continue;
    let value = f.value;
    if (op === "between") {
      if (!Array.isArray(value) || value.length !== 2) continue;
      value = [textOf(value[0]), textOf(value[1])];
    } else if (op === "in") {
      if (!Array.isArray(value)) value = [value];
      value = value.map(textOf).filter((s) => s !== "");
      if (value.length === 0) continue;
    } else if (op === "empty" || op === "notEmpty") {
      value = "";
    } else {
      value = typeof value === "boolean" ? value : textOf(value);
      if (value === "") continue;
    }
    filters.push({ column: column.name, op: op, value: value });
    if (filters.length >= MAX_FILTERS) break;
  }
  let sort = null;
  if (source.sort && typeof source.sort === "object" && columnOf_(table, textOf(source.sort.column)) !== null) {
    sort = { column: textOf(source.sort.column), dir: textOf(source.sort.dir).toLowerCase() === "desc" ? "desc" : "asc" };
  }
  const page = Math.max(1, Math.floor(Number(source.page)) || 1);
  let pageSize = Math.floor(Number(source.pageSize)) || DEFAULT_PAGE_SIZE;
  pageSize = Math.min(MAX_PAGE_SIZE, Math.max(MIN_PAGE_SIZE, pageSize));
  return { q: textOf(source.q).slice(0, MAX_Q_LENGTH), filters: filters, sort: sort, page: page, pageSize: pageSize };
}

function compareScalar_(column, value, target) {
  if (NUMBER_TYPES.indexOf(column.type) >= 0) {
    const a = toNumber_(value);
    const b = toNumber_(target);
    if (a === null || b === null) return null;
    return a < b ? -1 : a > b ? 1 : 0;
  }
  const a = normalizeText(value);
  const b = normalizeText(target);
  return a < b ? -1 : a > b ? 1 : 0;
}

/** 1 つの条件に当たるか */
export function matchesFilter(column, value, filter) {
  const op = filter.op;
  if (op === "empty") return isEmptyValue_(value);
  if (op === "notEmpty") return !isEmptyValue_(value);
  if (column.type === "チェック") {
    // チェックに使えるのは eq / ne（empty / notEmpty は上で済み）。ほかの op は当たらない
    if (op !== "eq" && op !== "ne") return false;
    // 画面の select は はい / いいえ を送る。TRUE / 1 / ○ も同じに読む
    const want = boolOf(filter.value, false);
    const got = value === true;
    return op === "ne" ? got !== want : got === want;
  }
  if (column.type === "複数選択") {
    const items = Array.isArray(value) ? value : [];
    if (op === "in") return filter.value.some((v) => items.indexOf(v) >= 0);
    if (op === "contains") return items.some((v) => normalizeText(v).indexOf(normalizeText(filter.value)) >= 0);
    if (op === "eq") return items.indexOf(filter.value) >= 0;
    if (op === "ne") return items.indexOf(filter.value) < 0;
    return false;
  }
  if (isEmptyValue_(value)) return false;
  if (op === "in") return filter.value.some((v) => normalizeText(v) === normalizeText(value));
  if (op === "contains") return normalizeText(value).indexOf(normalizeText(filter.value)) >= 0;
  if (op === "eq") return compareScalar_(column, value, filter.value) === 0;
  if (op === "ne") {
    const c = compareScalar_(column, value, filter.value);
    return c === null ? true : c !== 0;
  }
  if (op === "between") {
    const lo = compareScalar_(column, value, filter.value[0]);
    const hi = compareScalar_(column, value, filter.value[1]);
    return lo !== null && hi !== null && lo >= 0 && hi <= 0;
  }
  const c = compareScalar_(column, value, filter.value);
  if (c === null) return false;
  if (op === "gt") return c > 0;
  if (op === "gte") return c >= 0;
  if (op === "lt") return c < 0;
  if (op === "lte") return c <= 0;
  return false;
}

function matchesQ_(table, row, q) {
  if (q === "") return true;
  const needle = normalizeText(q);
  for (let i = 0; i < table.columns.length; i += 1) {
    const column = table.columns[i];
    if (!column.searchable) continue;
    const value = row[column.name];
    const text = Array.isArray(value) ? value.join(" ") : value === null || value === undefined ? "" : String(value);
    if (normalizeText(text).indexOf(needle) >= 0) return true;
  }
  return false;
}

/** q と filters で絞る(ページ送りはしない) */
export function filterRows(table, rows, query) {
  const out = [];
  for (let i = 0; i < rows.length; i += 1) {
    const row = rows[i];
    if (!matchesQ_(table, row, query.q)) continue;
    let ok = true;
    for (let j = 0; j < query.filters.length; j += 1) {
      const filter = query.filters[j];
      const column = columnOf_(table, filter.column);
      if (column === null || !matchesFilter(column, row[filter.column], filter)) {
        ok = false;
        break;
      }
    }
    if (ok) out.push(row);
  }
  return out;
}

function sortKey_(column, value) {
  if (isEmptyValue_(value)) return null;
  if (NUMBER_TYPES.indexOf(column.type) >= 0) return toNumber_(value);
  if (Array.isArray(value)) return value.join(", ");
  return String(value);
}

/** 並び替え。空は末尾。sort が null なら更新日時の降順 */
export function sortRows(table, rows, sort) {
  const s = sort === null || sort === undefined ? { column: "更新日時", dir: "desc" } : sort;
  const column = columnOf_(table, s.column) || { name: s.column, type: "文字" };
  const dir = s.dir === "desc" ? -1 : 1;
  const numeric = NUMBER_TYPES.indexOf(column.type) >= 0;
  const decorated = rows.map((row, index) => ({ row: row, index: index, key: sortKey_(column, row[s.column]) }));
  decorated.sort((a, b) => {
    if (a.key === null && b.key === null) return a.index - b.index;
    if (a.key === null) return 1;
    if (b.key === null) return -1;
    let c;
    if (numeric) c = a.key - b.key;
    else if (DATE_TYPES.indexOf(column.type) >= 0 || SYSTEM_SORTABLE.indexOf(column.name) >= 0) c = a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
    else c = String(a.key).localeCompare(String(b.key), "ja");
    if (c === 0) return a.index - b.index;
    return c * dir;
  });
  return decorated.map((d) => d.row);
}

export function paginate(rows, page, pageSize) {
  const start = (page - 1) * pageSize;
  return rows.slice(start, start + pageSize);
}

export function applyQuery(table, rows, query) {
  const filtered = sortRows(table, filterRows(table, rows, query), query.sort);
  return { rows: paginate(filtered, query.page, query.pageSize), total: filtered.length, page: query.page, pageSize: query.pageSize };
}
