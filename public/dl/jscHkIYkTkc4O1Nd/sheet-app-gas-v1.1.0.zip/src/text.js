/**
 * 束ねた 1 本の中で共有する小さな道具。どのファイルからも import して使う（各ファイルで同名の関数を定義しない）。
 */

/** セルや入力の値を、前後の空白を落とした文字にする。null / undefined は "" */
export function textOf(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

/** TRUE / FALSE のほか、はい・いいえ・1・0・○・× も読む。空や読めない字は fallback */
export function boolOf(value, fallback) {
  if (value === true) return true;
  if (value === false) return false;
  const t = textOf(value).toUpperCase();
  if (t === "") return fallback;
  if (t === "TRUE" || t === "1" || t === "はい" || t === "○") return true;
  if (t === "FALSE" || t === "0" || t === "いいえ" || t === "×") return false;
  return fallback;
}

/** 2 桁に揃える */
export function pad2(value) {
  return value < 10 ? "0" + value : String(value);
}
