/**
 * 登録・更新・削除の通知の純粋な処理: 変更点の整形、テンプレの置き換え、記録の URL、通知するかの判定、
 * Slack / Discord / LINE の送信データ。Node でそのままテストできる。
 * buildPayload と、テンプレを 1 回の走査で置き換える作りは packages/form-intake-gas/src/message.js から写した
 * （build が src/ を 1 本に束ねる作りなので、パッケージをまたいで import しない）。
 */
import { formatCell } from "./format.js";
import { textOf } from "./text.js";

export const NOTIFY_TARGETS = ["slack", "discord", "line"];
export const NOTIFY_OPS = ["登録", "更新", "削除"];
export const NOTIFY_LOG_SHEET = "_通知ログ";
export const NOTIFY_LOG_HEADER = ["日時", "テーブル", "操作", "ID", "宛先", "結果"];
/** 変更点の 1 つの値は 60 字で切る（長文の中身が Slack などに流れすぎないように） */
export const CHANGE_TEXT_LIMIT = 60;
/** 変更点は 10 列まで。超えた分は「ほか n 列」 */
export const CHANGE_COLUMN_LIMIT = 10;
export const DEFAULT_NOTIFY_TEMPLATE = ["【{アプリ名}】{テーブル}を{操作}しました", "{表示名}（{ID}）", "{変更点}", "{更新者}", "{URL}"].join("\n");

/** Slack の text は 40,000 字まで。余裕を見てここで切る */
const SLACK_PAYLOAD_LIMIT = 39000;
/** Discord の content は 2,000 字まで。余裕を見てここで切る */
const DISCORD_PAYLOAD_LIMIT = 1900;
/** LINE のテキストメッセージは 5,000 字まで */
const LINE_PAYLOAD_LIMIT = 5000;
const NOTIFY_MARK = /\{([^{}\n]{1,60})\}/g;

function truncatePayload_(text, limit) {
  if (text.length <= limit) return text;
  // Slack の文字参照（&amp; など）を途中で切らない
  return text.slice(0, limit - 8).replace(/&[a-z]{0,3}$/, "") + "\n…（以下省略）";
}

/** Slack の text では & < > が制御の字（<!channel> や <@U…> のメンション・リンク）なので、文字として送る */
export function escapeSlack(text) {
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/** 1 行にして limit 字（既定 60 字）で切る。切ったら … を付ける */
export function shortText(text, limit) {
  const max = limit === undefined ? CHANGE_TEXT_LIMIT : limit;
  const t = String(text === null || text === undefined ? "" : text).replace(/\s*\r?\n\s*/g, " ").trim();
  return t.length > max ? t.slice(0, max) + "…" : t;
}

function isBlank_(value) {
  return value === null || value === undefined || value === "" || (Array.isArray(value) && value.length === 0);
}

/** 通知に出す 1 つの値（切らない）。チェックは はい / いいえ、labels にある値（参照・LINE）は表示名、ほかは画面と同じ書式 */
function plainValue_(column, value, options) {
  if (isBlank_(value)) return "";
  if (column.type === "チェック") return value === true || String(value).toUpperCase() === "TRUE" ? "はい" : "いいえ";
  const labels = options.labels && options.labels[column.name] ? options.labels[column.name] : null;
  if (labels !== null && Object.prototype.hasOwnProperty.call(labels, String(value))) return String(labels[String(value)]);
  return formatCell(column, value, { dateFormat: options.dateFormat });
}

/** 記録を { 列名: 表示の文字 } にする（テンプレの {列名} と表示名に使う。切らない） */
export function displayValues(table, record, options) {
  const opts = options || {};
  const source = record || {};
  const values = {};
  for (let i = 0; i < table.columns.length; i += 1) {
    const column = table.columns[i];
    values[column.name] = plainValue_(column, source[column.name], opts);
  }
  return values;
}

/**
 * 変更点。op は 登録 / 更新 / 削除、before・after は API の形の記録（無い側は null）。
 * 返り値 { items: [{ column, before, after }], more }。値は画面向けの文字で、60 字で切る。10 列を超えた数は more
 */
export function buildChanges(table, op, before, after, options) {
  const opts = options || {};
  const items = [];
  if (op !== "削除") {
    for (let i = 0; i < table.columns.length; i += 1) {
      const column = table.columns[i];
      const raw = after ? after[column.name] : "";
      const next = shortText(plainValue_(column, raw, opts));
      if (op === "登録") {
        // 登録は空でない列だけ（チェックの いいえ も空とみなす）
        if (next === "" || raw === false) continue;
        items.push({ column: column.name, before: "", after: next });
      } else {
        const prev = shortText(plainValue_(column, before ? before[column.name] : "", opts));
        if (prev !== next) items.push({ column: column.name, before: prev, after: next });
      }
    }
  }
  return { items: items.slice(0, CHANGE_COLUMN_LIMIT), more: Math.max(0, items.length - CHANGE_COLUMN_LIMIT) };
}

/** {変更点} に入る文。1 行 1 列「列名: 前 → 後」（登録は「列名: 値」）。超えた分は「ほか n 列」 */
export function formatChanges(op, changes) {
  const list = changes && Array.isArray(changes.items) ? changes.items : [];
  const lines = [];
  for (let i = 0; i < list.length; i += 1) {
    const item = list[i];
    if (op === "登録") lines.push(item.column + ": " + item.after);
    else lines.push(item.column + ": " + (item.before === "" ? "（空）" : item.before) + " → " + (item.after === "" ? "（空）" : item.after));
  }
  if (changes && changes.more > 0) lines.push("ほか " + changes.more + " 列");
  return lines.join("\n");
}

/**
 * 通知の文面。{アプリ名} {テーブル} {操作} {ID} {表示名} {更新者} {変更点} {URL} と、列名そのもの（event.values）が使える。
 * 知らない印はそのまま残す（書き間違いに気づけるように）。値の中に {…} があっても置き換えない（1 回の走査）。
 * 印のあった行が置き換えの結果で空になったら、その行ごと省く（削除の {変更点}、URL が無いときの {URL} など）
 */
export function buildNotifyText(template, event) {
  const reserved = {
    アプリ名: textOf(event.appName),
    テーブル: textOf(event.table),
    操作: textOf(event.op),
    ID: textOf(event.id),
    表示名: textOf(event.label),
    更新者: textOf(event.actor),
    変更点: formatChanges(event.op, event.changes),
    URL: textOf(event.url),
  };
  const values = event.values || {};
  const lines = String(template).split("\n");
  const out = [];
  for (let i = 0; i < lines.length; i += 1) {
    let used = false;
    const rendered = lines[i].replace(NOTIFY_MARK, (whole, key) => {
      if (Object.prototype.hasOwnProperty.call(reserved, key)) {
        used = true;
        return reserved[key];
      }
      if (Object.prototype.hasOwnProperty.call(values, key)) {
        used = true;
        return String(values[key]);
      }
      return whole;
    });
    if (used && rendered.trim() === "") continue;
    out.push(rendered);
  }
  return out.join("\n");
}

/** メニュー「通知のテストを送る」の本文 */
export function buildTestNotifyText(appName) {
  return "【" + textOf(appName) + "】これはテストです。通知の設定ができています。";
}

/** 通知の URL。画面は #<テーブル>/<ID> で詳細を直接開く。Web アプリの URL が分からなければ "" */
export function recordUrl(appUrl, tableName, id) {
  const base = textOf(appUrl);
  if (base === "") return "";
  return base + "#" + encodeURIComponent(textOf(tableName)) + "/" + encodeURIComponent(textOf(id));
}

/**
 * 通知するか。event は { table, op, actor }。
 * 「自分の操作は通知しない」（skipOwn）は、更新者がスプレッドシートの所有者のときだけ飛ばす（所有者が分からなければ飛ばさない）
 */
export function shouldNotify(settings, event, ownerEmail) {
  if (!Array.isArray(settings.notifyTargets) || settings.notifyTargets.length === 0) return false;
  if (settings.notifyTables.length > 0 && settings.notifyTables.indexOf(event.table) < 0) return false;
  if (settings.notifyOps.indexOf(event.op) < 0) return false;
  const owner = textOf(ownerEmail).toLowerCase();
  if (settings.skipOwn === true && owner !== "" && textOf(event.actor).toLowerCase() === owner) return false;
  return true;
}

/**
 * Slack は text、Discord は content、LINE は push message の中身（form-intake-gas の message.js と同じ形）。
 * 通知にはお客さまが決めた名前（LINE の表示名など）も入るので、@everyone やメンションとして働かせない:
 * Discord は allowed_mentions を空に、Slack は & < > を文字参照にする
 */
export function buildPayload(text, target, options) {
  if (target === "discord") return { content: truncatePayload_(text, DISCORD_PAYLOAD_LIMIT), allowed_mentions: { parse: [] } };
  if (target === "line") {
    const to = options === undefined || options === null || options.lineTo === undefined ? "" : String(options.lineTo);
    return { to: to, messages: [{ type: "text", text: truncatePayload_(text, LINE_PAYLOAD_LIMIT) }] };
  }
  return { text: truncatePayload_(escapeSlack(text), SLACK_PAYLOAD_LIMIT) };
}
