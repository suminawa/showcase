/**
 * 画面の組み立て。state と api をつなぐ。DOM に触るのはこのファイルだけ。
 * mountSheetApp(root, api) → { getState, dispatch, load }
 * 1.1: URL のハッシュ #<テーブル>/<ID> で詳細を直接開く（通知の URL から来たとき）。詳細の「LINE で送る」。
 */
import { detailValues, lineConfirmText, remainingText, renderApp } from "./render.js";
import { currentTable, hashFor, initialState, parseHash, reduce } from "./state.js";
import { findColumn, lineColumn } from "../definition.js";
import { validate } from "../validate.js";
import { normalizeQuery } from "../query.js";
import { LINE_MESSAGES, fillLineTemplate, findFriend } from "../line.js";

const SEARCH_WAIT_MS = 300;

export function mountSheetApp(root, api) {
  let state = initialState();
  let searchTimer = null;
  /** 一覧の要求番号。古い要求の答えが後から届いても捨てる */
  let requestSeq = 0;
  /** 登録・保存の送信中（二重送信を防ぐ） */
  let submitting = false;

  function paint() {
    const active = document.activeElement;
    const keep = active && root.contains(active) && active.dataset && active.dataset.field ? { field: active.dataset.field, start: active.selectionStart, end: active.selectionEnd } : null;
    root.innerHTML = renderApp(state);
    if (keep) {
      const el = root.querySelector('[data-field="' + keep.field + '"]');
      if (el) {
        el.focus();
        try {
          el.setSelectionRange(keep.start, keep.end);
        } catch (error) {
          // type=search や select は setSelectionRange を持たない
        }
      }
    }
  }

  function dispatch(action) {
    state = reduce(state, action);
    paint();
  }

  function messageOf(error) {
    return error && error.message ? error.message : String(error);
  }

  function fail(error) {
    dispatch({ type: "error", message: messageOf(error) });
  }

  function query() {
    return { q: state.q, filters: state.filters, sort: state.sort, page: state.page, pageSize: state.pageSize };
  }

  function load() {
    if (state.current === "") return Promise.resolve();
    const table = state.current;
    requestSeq += 1;
    const seq = requestSeq;
    dispatch({ type: "loading", on: true });
    return api
      .list(table, query())
      .then((result) => {
        if (seq !== requestSeq || state.current !== table) return;
        dispatch({ type: "rows", rows: result.rows, total: result.total, refs: result.refs, page: result.page });
      })
      .catch((error) => {
        if (seq !== requestSeq) return;
        fail(error);
      });
  }

  /** 画面の外の URL のハッシュ（読み書きは api に任せる: 実物は api-gas.js、見本は location）。api に無ければ何もしない */
  function writeHash(hash) {
    if (typeof api.writeHash === "function") api.writeHash(hash);
  }

  function readHash() {
    if (typeof api.readHash !== "function") return Promise.resolve("");
    return Promise.resolve(api.readHash()).catch(() => "");
  }

  /** fromHash: URL のハッシュから開いたとき。記録が無ければ、誤りを出してからハッシュを消す（読み直しで同じ誤りを繰り返さない） */
  function openDetail(id, fromHash) {
    const table = state.current;
    return api
      .get(table, id)
      .then((result) => {
        dispatch({ type: "open-detail", row: result.row, refs: result.refs, history: result.history });
        writeHash(hashFor(table, result.row.ID));
      })
      .catch((error) => {
        fail(error);
        if (fromHash === true) writeHash("");
      });
  }

  function closeView() {
    dispatch({ type: "close" });
    writeHash("");
  }

  /** 参照の列の候補をまとめて取る */
  function optionsFor(table) {
    const refColumns = table.columns.filter((c) => c.type === "参照");
    return Promise.all(refColumns.map((c) => api.options(table.name, c.name))).then((results) => {
      const options = {};
      const truncated = {};
      refColumns.forEach((c, i) => {
        options[c.name] = results[i].options;
        if (results[i].truncated === true) truncated[c.name] = true;
      });
      return { options: options, truncated: truncated };
    });
  }

  function openForm(isNew, row) {
    const table = currentTable(state);
    optionsFor(table)
      .then((got) => {
        const values = isNew ? validate(table, {}, { today: state.today, isNew: true }).values : Object.assign({}, row);
        dispatch({ type: "open-form", isNew: isNew, id: isNew ? "" : row.ID, seenUpdatedAt: isNew ? "" : row.更新日時, values: values, options: got.options, optionsTruncated: got.truncated });
        const first = root.querySelector(".sa-form input, .sa-form select, .sa-form textarea");
        if (first) first.focus();
      })
      .catch(fail);
  }

  /** フォームの欄を { 列名: 値 } に。列名に " があっても壊れないよう、選択子ではなく elements から集める */
  function collect(form, table) {
    const record = {};
    table.columns.forEach((column) => {
      const fields = Array.prototype.filter.call(form.elements, (el) => el.name === column.name);
      if (column.type === "複数選択") {
        record[column.name] = fields.filter((el) => el.checked).map((el) => el.value);
      } else if (column.type === "チェック") {
        record[column.name] = fields.length > 0 && fields[0].checked === true;
      } else {
        let value = fields.length > 0 ? fields[0].value : "";
        if (column.type === "日時") value = String(value).replace("T", " ");
        record[column.name] = value;
      }
    });
    return record;
  }

  function submitRecord(form) {
    if (submitting) return;
    const table = currentTable(state);
    const view = state.view;
    const record = collect(form, table);
    const checked = validate(table, record, { today: state.today, isNew: view.isNew });
    if (!checked.ok) {
      state = reduce(state, { type: "form-values", values: record });
      dispatch({ type: "form-errors", errors: checked.errors });
      const bad = root.querySelector(".sa-field-error input, .sa-field-error select, .sa-field-error textarea");
      if (bad) bad.focus();
      return;
    }
    submitting = true;
    const button = form.querySelector('button[type="submit"]');
    if (button) button.disabled = true;
    const request = view.isNew ? api.create(table.name, checked.values) : api.update(table.name, view.id, checked.values, view.seenUpdatedAt);
    request
      .then(() => {
        submitting = false;
        closeView();
        dispatch({ type: "notice", message: view.isNew ? "登録しました" : "保存しました" });
        return load();
      })
      .catch((error) => {
        submitting = false;
        state = reduce(state, { type: "form-values", values: record });
        fail(error);
      });
  }

  function remove() {
    const view = state.view;
    if (!view || view.kind !== "detail") return;
    if (!window.confirm("この 1 件を削除します。よろしいですか？\n削除した行は _ごみ箱 シートに残ります")) return;
    api
      .remove(state.current, view.id)
      .then(() => {
        closeView();
        dispatch({ type: "notice", message: "削除しました" });
        return load();
      })
      .catch(fail);
  }

  function tryDownload(text, filename) {
    try {
      const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      // サンドボックスで止まる環境では、画面の CSV の箱からコピーしてもらう
    }
  }

  function exportCsv() {
    api
      .exportCsv(state.current, query())
      .then((text) => {
        dispatch({ type: "csv", text: text });
        tryDownload(text, state.current + ".csv");
      })
      .catch(fail);
  }

  function copyCsv() {
    const text = state.csv || "";
    const fallback = () => {
      const area = root.querySelector(".sa-csv textarea");
      if (area) {
        area.select();
        document.execCommand("copy");
        dispatch({ type: "notice", message: "コピーしました" });
      }
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => dispatch({ type: "notice", message: "コピーしました" })).catch(fallback);
    } else fallback();
  }

  function aiFilter() {
    const text = state.aiText.trim();
    if (text === "") return;
    dispatch({ type: "loading", on: true });
    api
      .aiFilter(state.current, text)
      .then((answer) => {
        dispatch({ type: "set-filters", q: answer.q, filters: answer.filters, sort: answer.sort });
        dispatch({ type: "ai-explanation", text: answer.explanation });
        return load();
      })
      .catch(fail);
  }

  function aiSummary() {
    const view = state.view;
    if (!view || view.kind !== "detail") return;
    dispatch({ type: "summary-loading", on: true });
    api
      .aiSummary(state.current, view.id)
      .then((result) => dispatch({ type: "summary", text: result.text }))
      .catch((error) => {
        dispatch({ type: "summary-loading", on: false });
        fail(error);
      });
  }

  function addFilter(form) {
    const table = currentTable(state);
    const column = form.elements.namedItem("column").value;
    const op = form.elements.namedItem("op").value;
    let raw = String(form.elements.namedItem("value").value || "").trim();
    // datetime-local の値は "2026-09-16T10:30" なので、API の形（空白区切り）に直す
    const chosen = table === null ? null : findColumn(table, column);
    if (chosen !== null && chosen.type === "日時" && op !== "between") raw = raw.replace("T", " ");
    let value = raw;
    if (op === "between") value = raw.split(/[,、]/).map((s) => s.trim()).slice(0, 2);
    else if (op === "in") value = raw.split(/[,、]/).map((s) => s.trim()).filter((s) => s !== "");
    else if (op === "empty" || op === "notEmpty") value = "";
    const normalized = normalizeQuery(table, { filters: [{ column: column, op: op, value: value }] });
    if (normalized.filters.length === 0) {
      dispatch({ type: "error", message: "条件を読み取れませんでした。値をご確認ください（範囲は 最小,最大 の形）" });
      return;
    }
    dispatch({ type: "add-filter", filter: normalized.filters[0] });
    load();
  }

  /** 絞り込みの列が変わったら、その型に合う条件と入力欄に描き直す（参照は候補を取ってから） */
  function filterColumn(name) {
    const table = currentTable(state);
    const column = table === null ? null : findColumn(table, name);
    if (column === null || column.type !== "参照") {
      dispatch({ type: "filter-column", column: name, options: null });
      return;
    }
    api
      .options(table.name, name)
      .then((result) => dispatch({ type: "filter-column", column: name, options: result.options }))
      .catch((error) => {
        dispatch({ type: "filter-column", column: name, options: null });
        fail(error);
      });
  }

  /** 範囲（between）は「最小,最大」の 2 つを入れるので、値の欄はそのあいだだけ text にする */
  function swapRangeField(form, op) {
    const field = form.elements.namedItem("value");
    if (!field || field.tagName !== "INPUT") return;
    if (field.dataset.type === undefined) {
      field.dataset.type = field.type;
      field.dataset.placeholder = field.placeholder;
    }
    field.type = op === "between" ? "text" : field.dataset.type;
    field.placeholder = op === "between" ? "最小,最大（例: 2026-08-01,2026-08-31）" : field.dataset.placeholder;
  }

  /** 詳細の記録に結びついた LINE の友だち（無ければ null） */
  function lineFriend() {
    const table = currentTable(state);
    const view = state.view;
    const column = table === null ? null : lineColumn(table);
    if (column === null || !view || view.kind !== "detail") return null;
    return findFriend(state.line.friends, view.row[column.name]);
  }

  /** 定型文を選んだら、詳細に出ている値と担当者名で置き換えて本文の欄に入れる */
  function applyTemplate(value) {
    const view = state.view;
    if (value === "" || !view || view.kind !== "detail") return;
    const template = state.line.templates[Number(value)];
    if (!template) return;
    const values = detailValues(currentTable(state), view.row, view.refs, { dateFormat: state.dateFormat, friends: state.line.friends });
    dispatch({ type: "line-text", template: value, text: fillLineTemplate(template.body, { values: values, staffName: state.line.staffName }) });
  }

  function lineDraft() {
    const view = state.view;
    if (!view || view.kind !== "detail" || view.lineDrafting) return;
    const intent = view.lineIntent.trim();
    if (intent === "") {
      dispatch({ type: "line-error", message: LINE_MESSAGES.emptyIntent });
      return;
    }
    dispatch({ type: "line-drafting", on: true });
    api
      .aiDraft(state.current, view.id, intent)
      .then((result) => {
        dispatch({ type: "line-text", text: result.text });
        dispatch({ type: "line-drafting", on: false });
      })
      .catch((error) => dispatch({ type: "line-error", message: messageOf(error) }));
  }

  function lineSend() {
    const view = state.view;
    if (!view || view.kind !== "detail" || view.lineSending) return;
    if (view.lineText.trim() === "") {
      dispatch({ type: "line-error", message: LINE_MESSAGES.emptyText });
      return;
    }
    const friend = lineFriend();
    if (!window.confirm(lineConfirmText(friend ? friend.name : ""))) return;
    dispatch({ type: "line-sending", on: true });
    api
      .lineSend(state.current, view.id, view.lineText)
      .then((result) => {
        dispatch({ type: "line-sent", history: result.history, monthCount: result.monthCount });
        // 送れたが履歴に書けなかったときは、送り直さないよう server の文（note）を出す
        dispatch({ type: "notice", message: result && result.note ? String(result.note) : "LINE を送りました" });
      })
      .catch((error) => dispatch({ type: "line-error", message: messageOf(error) }));
  }

  /** 友だちが多いときの「表示名で探す」欄: 合わない option を隠す（選んでいるものは隠さない） */
  function filterLineOptions(input) {
    const form = input.form;
    const select = form ? form.elements.namedItem(input.dataset.lineSearch) : null;
    if (!select || !select.options) return;
    const word = input.value.trim().toLowerCase();
    Array.prototype.forEach.call(select.options, (option) => {
      option.hidden = word !== "" && option.value !== "" && !option.selected && option.text.toLowerCase().indexOf(word) < 0;
    });
  }

  root.addEventListener("click", (event) => {
    const el = event.target.closest("[data-action]");
    if (!el || !root.contains(el)) return;
    const action = el.dataset.action;
    if (action === "select-table") {
      clearTimeout(searchTimer);
      dispatch({ type: "select-table", name: el.dataset.table });
      writeHash("");
      load();
    } else if (action === "toggle-filters") dispatch({ type: "toggle-filter-panel" });
    else if (action === "remove-filter") {
      dispatch({ type: "remove-filter", index: Number(el.dataset.index) });
      load();
    } else if (action === "clear-filters") {
      dispatch({ type: "clear-filters" });
      load();
    } else if (action === "sort") {
      dispatch({ type: "toggle-sort", column: el.dataset.column });
      load();
    } else if (action === "page") {
      dispatch({ type: "set-page", page: Number(el.dataset.page) });
      load();
    } else if (action === "open") openDetail(el.dataset.id);
    else if (action === "new") openForm(true, null);
    else if (action === "edit") openForm(false, state.view.row);
    else if (action === "delete") remove();
    else if (action === "close") closeView();
    else if (action === "csv") exportCsv();
    else if (action === "csv-close") dispatch({ type: "csv", text: null });
    else if (action === "copy-csv") copyCsv();
    else if (action === "ai-filter") aiFilter();
    else if (action === "ai-summary") aiSummary();
    else if (action === "line-open") dispatch({ type: "line-toggle" });
    else if (action === "line-draft") lineDraft();
    else if (action === "line-send") lineSend();
    else if (action === "dismiss-error") dispatch({ type: "error", message: "" });
  });

  root.addEventListener("keydown", (event) => {
    const target = event.target;
    const data = target.dataset || {};
    if (event.key === "Enter" && data.field === "ai") {
      event.preventDefault();
      state = reduce(state, { type: "ai-text", text: target.value });
      aiFilter();
    } else if (event.key === "Enter" && data.field === "line-intent") {
      event.preventDefault();
      state = reduce(state, { type: "line-intent", text: target.value });
      lineDraft();
    } else if (event.key === "Enter" && data.lineSearch !== undefined) {
      // 探す欄で Enter を押しても、フォームを送らない
      event.preventDefault();
    } else if (event.key === "Enter" && data.action === "open") {
      openDetail(data.id);
    } else if (event.key === "Escape" && state.view !== null) {
      closeView();
    }
  });

  root.addEventListener("input", (event) => {
    const target = event.target;
    const data = target.dataset || {};
    const field = data.field || "";
    if (field === "q") {
      const value = target.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        dispatch({ type: "set-q", q: value });
        load();
      }, SEARCH_WAIT_MS);
    } else if (field === "ai") {
      state = reduce(state, { type: "ai-text", text: target.value });
    } else if (field === "line-text") {
      // 打つたびに描き直すとカーソルが飛ぶので、状態だけ変えて残り字数の表示を直接直す
      state = reduce(state, { type: "line-text", text: target.value });
      const counter = root.querySelector('[data-role="line-count"]');
      if (counter) counter.textContent = remainingText(target.value);
    } else if (field === "line-intent") {
      state = reduce(state, { type: "line-intent", text: target.value });
    } else if (data.lineSearch !== undefined) {
      filterLineOptions(target);
    }
  });

  root.addEventListener("change", (event) => {
    const el = event.target;
    if (el && el.dataset && el.dataset.field === "line-template") {
      applyTemplate(el.value);
      return;
    }
    const form = el ? el.form : null;
    if (!form || form.dataset.form !== "filter") return;
    if (el.name === "column") filterColumn(el.value);
    else if (el.name === "op") swapRangeField(form, el.value);
  });

  root.addEventListener("submit", (event) => {
    const form = event.target;
    if (form.dataset.form === "record") {
      event.preventDefault();
      submitRecord(form);
    } else if (form.dataset.form === "filter") {
      event.preventDefault();
      addFilter(form);
    }
  });

  paint();
  api
    .bootstrap()
    .then((data) => {
      dispatch({ type: "bootstrap", data: data });
      return readHash();
    })
    .then((hash) => {
      // 通知の URL（#<テーブル>/<ID>）から来たら、そのテーブルに切り替えて詳細を開く
      const target = parseHash(hash);
      if (target !== null && state.bootErrors.length === 0 && state.tables.some((t) => t.name === target.table)) {
        dispatch({ type: "select-table", name: target.table });
        load();
        openDetail(target.id, true);
        return undefined;
      }
      return load();
    })
    .catch(fail);

  return { getState: () => state, dispatch: dispatch, load: load };
}
