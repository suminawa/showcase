/**
 * 見本ページ用の api。GAS に触らず、見本のテンプレをブラウザの中の配列で動かす。ページを閉じれば消える。
 * 1.1: 顧客の先頭 8 件に架空の LINE の友だちを結びつけ（8 人目はブロック中）、「送る」は送ったことにして履歴に足す。
 */
import { TEMPLATES } from "../samples.js";
import { findColumn, findTable, lineColumn, parseDefinition } from "../definition.js";
import { applyQuery, filterRows, normalizeQuery, sortRows } from "../query.js";
import { validate } from "../validate.js";
import { toCsv } from "../csv.js";
import { nextId } from "../ids.js";
import { formatStamp, toDateKey } from "../dates.js";
import { textOf } from "../text.js";
import { DEFAULT_LINE_TEMPLATE_TEXT } from "../settings.js";
import { BLOCKED_STATE, FRIEND_STATE, HISTORY_LIMIT, LINE_MESSAGES, SENT, findFriend, friendsForScreen, lineTextError, parseLineTemplates } from "../line.js";

const DEMO_EMAIL = "demo@example.com";
const DEMO_PAGE_SIZE = 20;
const DELAY_MS = 120;
/** 見本の友だちの表示名（架空）。最後の 1 人はブロック中 */
const DEMO_FRIEND_NAMES = ["はるか", "けんた", "みさき", "ゆうと", "あかり", "そうた", "りな", "だいき"];

function delay_(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), DELAY_MS));
}

/** 見本の友だちのユーザー ID（U と 32 桁の 16 進） */
function demoLineId_(index) {
  const hex = (index + 1).toString(16);
  return "U" + "0".repeat(32 - hex.length) + hex;
}

export function memoryApi(templateName) {
  const name = templateName || "顧客管理";
  const template = TEMPLATES[name];
  const tables = parseDefinition(template.definition).tables;
  const store = {};
  const lastIds = {};
  const friendRows = DEMO_FRIEND_NAMES.map((friendName, i) => ({ userId: demoLineId_(i), name: friendName, state: i === DEMO_FRIEND_NAMES.length - 1 ? BLOCKED_STATE : FRIEND_STATE }));
  const friends = friendsForScreen(friendRows);
  const templates = parseLineTemplates(DEFAULT_LINE_TEMPLATE_TEXT).templates;
  const sendLog = [];
  tables.forEach((t) => {
    store[t.name] = (template.tables[t.name] || []).map((r) => Object.assign({}, r));
    const column = lineColumn(t);
    if (column === null) return;
    store[t.name].slice(0, friendRows.length).forEach((row, i) => {
      row[column.name] = friendRows[i].userId;
    });
  });
  const lineEnabled = tables.some((t) => lineColumn(t) !== null);

  function tableOf(tableName) {
    const table = findTable(tables, textOf(tableName));
    if (table === null) throw new Error("テーブル「" + textOf(tableName) + "」は定義にありません");
    return table;
  }

  function refsFor(table, rows) {
    const refs = {};
    table.columns.forEach((column) => {
      if (column.type !== "参照") return;
      const target = findTable(tables, column.refTable);
      const map = {};
      (store[target.name] || []).forEach((r) => {
        map[r.ID] = textOf(r[target.display]) || r.ID;
      });
      const out = {};
      rows.forEach((row) => {
        const id = textOf(row[column.name]);
        if (id !== "" && map[id] !== undefined) out[id] = map[id];
      });
      refs[column.name] = out;
    });
    return refs;
  }

  function find(table, id) {
    const rows = store[table.name];
    for (let i = 0; i < rows.length; i += 1) if (rows[i].ID === textOf(id)) return { row: rows[i], index: i };
    throw new Error("ID「" + textOf(id) + "」の記録が見つかりません。削除された可能性があります");
  }

  function checkRefs(table, values) {
    table.columns.forEach((column) => {
      if (column.type !== "参照" || !Object.prototype.hasOwnProperty.call(values, column.name)) return;
      const id = textOf(values[column.name]);
      if (id === "") return;
      const target = findTable(tables, column.refTable);
      if (!store[target.name].some((r) => r.ID === id)) throw new Error(column.name + ": 参照先の記録が見つかりません（" + id + "）");
    });
  }

  function errorText(errors) {
    return Object.keys(errors).map((k) => errors[k]).join("\n");
  }

  /** 1 件の記録の送信履歴（新しい順・20 件まで） */
  function historyFor(tableName, id) {
    const out = [];
    for (let i = sendLog.length - 1; i >= 0 && out.length < HISTORY_LIMIT; i -= 1) {
      const entry = sendLog[i];
      if (entry.table === tableName && entry.id === id) out.push({ at: entry.at, sender: entry.sender, text: entry.text, result: entry.result });
    }
    return out;
  }

  function wrap(fn) {
    return function () {
      try {
        return delay_(fn.apply(null, arguments));
      } catch (error) {
        return Promise.reject(error);
      }
    };
  }

  return {
    bootstrap: wrap(() => ({
      appName: "見本: " + name,
      tables: tables,
      errors: [],
      user: { email: DEMO_EMAIL, canEdit: true },
      ai: true,
      pageSize: DEMO_PAGE_SIZE,
      dateFormat: "yyyy-MM-dd",
      today: toDateKey(new Date()),
      line: { enabled: lineEnabled, friends: lineEnabled ? friends : [], templates: lineEnabled ? templates : [], canSend: lineEnabled, monthCount: sendLog.length, staffName: "山田" },
    })),
    list: wrap((tableName, rawQuery) => {
      const table = tableOf(tableName);
      const query = normalizeQuery(table, Object.assign({ pageSize: DEMO_PAGE_SIZE }, rawQuery || {}));
      const result = applyQuery(table, store[table.name], query);
      return { rows: result.rows, total: result.total, page: result.page, pageSize: result.pageSize, refs: refsFor(table, result.rows) };
    }),
    get: wrap((tableName, id) => {
      const table = tableOf(tableName);
      const found = find(table, id);
      const refs = refsFor(table, [found.row]);
      const flat = {};
      Object.keys(refs).forEach((column) => {
        const value = textOf(found.row[column]);
        if (value !== "" && refs[column][value] !== undefined) flat[column] = refs[column][value];
      });
      return { row: Object.assign({}, found.row), refs: flat, history: historyFor(table.name, found.row.ID) };
    }),
    options: wrap((tableName, columnName) => {
      const table = tableOf(tableName);
      const column = findColumn(table, textOf(columnName));
      if (column === null || column.type !== "参照") throw new Error("列「" + textOf(columnName) + "」は参照の列ではありません");
      const target = tableOf(column.refTable);
      const rows = sortRows(target, store[target.name], { column: target.display, dir: "asc" });
      return { options: rows.map((r) => ({ id: r.ID, label: textOf(r[target.display]) || r.ID })), truncated: false };
    }),
    create: wrap((tableName, record) => {
      const table = tableOf(tableName);
      const today = toDateKey(new Date());
      const checked = validate(table, record, { today: today, isNew: true });
      if (!checked.ok) throw new Error(errorText(checked.errors));
      checkRefs(table, checked.values);
      const id = nextId(lastIds[table.name] || "", today);
      lastIds[table.name] = id;
      const stamp = formatStamp(new Date());
      store[table.name].push(Object.assign({ ID: id }, checked.values, { 作成日時: stamp, 更新日時: stamp, 更新者: DEMO_EMAIL }));
      return { id: id };
    }),
    update: wrap((tableName, id, record, seenUpdatedAt) => {
      const table = tableOf(tableName);
      const checked = validate(table, record, { today: toDateKey(new Date()), isNew: false });
      if (!checked.ok) throw new Error(errorText(checked.errors));
      checkRefs(table, checked.values);
      const found = find(table, id);
      if (textOf(found.row.更新日時) !== textOf(seenUpdatedAt)) throw new Error("ほかの方が先に更新しました。いちど閉じて、読み直してください");
      const stamp = formatStamp(new Date(Date.now() + 1000));
      store[table.name][found.index] = Object.assign({}, found.row, checked.values, { 更新日時: stamp, 更新者: DEMO_EMAIL });
      return { updatedAt: stamp };
    }),
    remove: wrap((tableName, id) => {
      const table = tableOf(tableName);
      const found = find(table, id);
      store[table.name].splice(found.index, 1);
      return { ok: true };
    }),
    exportCsv: wrap((tableName, rawQuery) => {
      const table = tableOf(tableName);
      const query = normalizeQuery(table, Object.assign({ pageSize: DEMO_PAGE_SIZE }, rawQuery || {}));
      return toCsv(table, sortRows(table, filterRows(table, store[table.name], query), query.sort));
    }),
    aiFilter: wrap((tableName, text) => {
      const table = tableOf(tableName);
      if (textOf(text) === "") throw new Error("絞り込みの言葉を入力してください");
      const column = table.columns.find((c) => c.type === "選択") || table.columns[0];
      const value = column.type === "選択" ? column.options[Math.min(1, column.options.length - 1)] : "";
      const filter = column.type === "選択" ? { column: column.name, op: "eq", value: value } : { column: column.name, op: "notEmpty", value: "" };
      return { q: "", filters: [filter], sort: null, explanation: "見本のため、決まった条件（" + column.name + " が " + (value || "空でない") + "）に絞りました。実物では入力した言葉から条件を作ります" };
    }),
    aiSummary: wrap((tableName, id) => {
      const table = tableOf(tableName);
      const found = find(table, id);
      const title = textOf(found.row[table.display]) || found.row.ID;
      const filled = table.columns.filter((c) => textOf(found.row[c.name]) !== "" && found.row[c.name] !== false).length;
      return { text: "（見本の要約）" + title + " の記録です。" + table.columns.length + " 項目のうち " + filled + " 項目が入力されています。実物では、記録の内容を AI が敬体で要約します。\n次の一手: 最終連絡日から間が空いていれば、ご連絡の予定を入れます" };
    }),
    lineSend: wrap((tableName, id, text) => {
      const table = tableOf(tableName);
      const column = lineColumn(table);
      if (column === null) throw new Error(LINE_MESSAGES.noColumn);
      const problem = lineTextError(text);
      if (problem !== "") throw new Error(problem);
      const found = find(table, id);
      const userId = textOf(found.row[column.name]);
      if (userId === "") throw new Error(LINE_MESSAGES.noFriend);
      const friend = findFriend(friends, userId);
      if (friend === null) throw new Error(LINE_MESSAGES.unknown);
      if (friend.blocked) throw new Error(LINE_MESSAGES.blocked);
      // 見本は送ったことにするだけ（LINE には何も届かない）
      sendLog.push({ table: table.name, id: found.row.ID, at: formatStamp(new Date()), sender: DEMO_EMAIL, text: String(text).trim(), result: SENT });
      return { history: historyFor(table.name, found.row.ID), monthCount: sendLog.length };
    }),
    aiDraft: wrap((tableName, id, intent) => {
      const table = tableOf(tableName);
      const words = textOf(intent);
      if (words === "") throw new Error(LINE_MESSAGES.emptyIntent);
      const found = find(table, id);
      const title = textOf(found.row[table.display]) || found.row.ID;
      return { text: title + " 様\n\nいつもお世話になっております。見本の担当です。\n（見本の下書き）用件「" + words + "」に沿って、実物では記録の内容から AI が敬体で下書きを作ります。送る前に読み直して整えてください。" };
    }),
    readHash: () => Promise.resolve(typeof window !== "undefined" && window.location ? String(window.location.hash || "").replace(/^#/, "") : ""),
    writeHash: (hash) => {
      try {
        if (typeof window === "undefined" || !window.history || !window.history.replaceState) return;
        const base = window.location.pathname + window.location.search;
        window.history.replaceState(null, "", hash ? base + "#" + hash : base);
      } catch (error) {
        // 見本のページで履歴を書けなくても、動きは変わらない
      }
    },
  };
}
