/**
 * Slack / Discord の Webhook と、LINE の push message・プロフィールを UrlFetchApp で呼ぶ。登録・更新・削除の通知と _通知ログ。
 * postSlack_ / postDiscord_ / pushLine_ / notifyAll_ は packages/form-intake-gas/src/gas_notify.js から写した
 * （build が src/ を 1 本に束ねる作りなので、パッケージをまたいで import しない）。
 * 写したうえで、失敗を実行ログに捨てず { target, ok, message } で返すようにし、LINE のプロフィールと _通知ログ を足した。
 * Webhook の URL とトークンは鍵なので、誤りの文にもログにも出さない（状態コードだけ）。
 */
import { NOTIFY_LOG_HEADER, NOTIFY_LOG_SHEET, buildNotifyText, buildPayload, shouldNotify } from "./notify.js";
import { formatStamp } from "./dates.js";
import { safeCell } from "./format.js";

export const LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push";
export const LINE_PROFILE_URL = "https://api.line.me/v2/bot/profile/";

/** JSON を POST する。2xx 以外は状態コードを error.status に載せて投げる */
function postJson_(url, payload, headers) {
  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  if (headers) options.headers = headers;
  const response = UrlFetchApp.fetch(url, options);
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    const error = new Error(status + " が返りました");
    error.status = status;
    throw error;
  }
}

export function postSlack_(url, text) {
  postJson_(url, buildPayload(text, "slack"));
}

export function postDiscord_(url, text) {
  postJson_(url, buildPayload(text, "discord"));
}

export function pushLine_(token, to, text) {
  postJson_(LINE_PUSH_URL, buildPayload(text, "line", { lineTo: to }), { Authorization: "Bearer " + token });
}

/**
 * 設定の通知先すべてに送る。1 つが失敗しても残りには送る。投げない。
 * 返り値: [{ target, ok, message }]（message は「送りました」か「送れませんでした（…）」）
 */
export function notifyAll_(settings, text) {
  const results = [];
  for (let i = 0; i < settings.notifyTargets.length; i += 1) {
    const target = settings.notifyTargets[i];
    try {
      if (target === "slack") postSlack_(settings.slackWebhookUrl, text);
      else if (target === "discord") postDiscord_(settings.discordWebhookUrl, text);
      else if (target === "line") pushLine_(settings.lineToken, settings.lineTo, text);
      results.push({ target: target, ok: true, message: "送りました" });
    } catch (error) {
      const reason = error && error.status ? error.status + " が返りました" : String(error && error.message ? error.message : error);
      results.push({ target: target, ok: false, message: "送れませんでした（" + reason + "）" });
    }
  }
  return results;
}

/** LINE の表示名。profile API は友だちにしか答えない。取れなければ ""（未確認）。トークンが空なら呼ばない */
export function lineProfile_(token, userId) {
  if (String(token || "") === "") return "";
  try {
    const response = UrlFetchApp.fetch(LINE_PROFILE_URL + encodeURIComponent(String(userId)), {
      method: "get",
      headers: { Authorization: "Bearer " + token },
      muteHttpExceptions: true,
    });
    if (response.getResponseCode() !== 200) return "";
    const json = JSON.parse(response.getContentText());
    return json && typeof json.displayName === "string" ? json.displayName.trim().slice(0, 100) : "";
  } catch (error) {
    return "";
  }
}

/**
 * 画面の URL（通知の {URL} の元）。設定「画面の URL」があればそれを使い、無ければ Apps Script が返すこの Web アプリの URL。
 * まだ公開していなければ ""。デプロイが 2 つ（画面用と webhook 用）あると getUrl() はどちらを返すか決まらないので、設定を先に見る
 */
export function webAppUrl_(settings) {
  if (settings && typeof settings.appUrl === "string" && settings.appUrl !== "") return settings.appUrl;
  try {
    return String(ScriptApp.getService().getUrl() || "");
  } catch (error) {
    return "";
  }
}

/** _通知ログ を見出しつきで作る（初期化から呼ぶ。あれば何もしない） */
export function ensureNotifyLog_() {
  notifyLogSheet_();
}

function notifyLogSheet_() {
  const book = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = book.getSheetByName(NOTIFY_LOG_SHEET);
  if (!sheet) sheet = book.insertSheet(NOTIFY_LOG_SHEET);
  if (sheet.getLastRow() === 0) sheet.getRange(1, 1, 1, NOTIFY_LOG_HEADER.length).setValues([NOTIFY_LOG_HEADER]);
  return sheet;
}

/** _通知ログ に 1 行（日時・テーブル・操作・ID・宛先・結果） */
export function appendNotifyLog_(event, target, result, stamp) {
  notifyLogSheet_().appendRow([safeCell(stamp), safeCell(event.table), safeCell(event.op), safeCell(event.id), safeCell(target), safeCell(result)]);
}

/**
 * 保存のあとに呼ぶ通知。通知しない条件なら [] を返す。送れなかった宛先だけ _通知ログ に書く（送れた分は書かない。行が増えすぎるので）。
 * 何が起きても投げない（保存は済んでいるので、利用者を止めない）
 */
export function notifyChange_(settings, event, ownerEmail) {
  try {
    if (!shouldNotify(settings, event, ownerEmail)) return [];
    const results = notifyAll_(settings, buildNotifyText(settings.notifyTemplate, event));
    const stamp = formatStamp(new Date());
    for (let i = 0; i < results.length; i += 1) {
      if (results[i].ok) continue;
      try {
        appendNotifyLog_(event, results[i].target, results[i].message, stamp);
      } catch (error) {
        Logger.log("業務アプリ: _通知ログ に書けませんでした: " + (error && error.message ? error.message : error));
      }
    }
    return results;
  } catch (error) {
    Logger.log("業務アプリ: 通知を送れませんでした: " + (error && error.message ? error.message : error));
    return [];
  }
}
