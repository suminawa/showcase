/**
 * 1 件の記録を定義に照らして検査し、値を揃える。画面とサーバーの両方で同じものを動かす。
 * 返り値 { ok, errors: { 列名: 敬体の文 }, values: { 列名: 揃えた値 } }。知らない列は無視する。
 */
import { toDateKey, toDateTimeKey, toHalfWidth } from "./dates.js";
import { splitList } from "./definition.js";
import { isLineUserId } from "./line.js";
import { textOf } from "./text.js";

export const TEXT_LIMIT = 200;
export const LONG_TEXT_LIMIT = 5000;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE = /^[0-9+\-() ]+$/;

function isEmpty_(value) {
  return value === null || value === undefined || value === "" || (Array.isArray(value) && value.length === 0);
}

/** 「今日」だけ特別（日付の既定値に書ける） */
function defaultFor_(column, today) {
  if (column.type === "日付" && column.defaultValue === "今日") return today;
  if (column.type === "チェック") return column.defaultValue.toUpperCase() === "TRUE";
  if (column.type === "複数選択") return splitList(column.defaultValue);
  return column.defaultValue;
}

function toBool_(value) {
  if (value === true || value === false) return value;
  const t = textOf(value).toUpperCase();
  if (t === "" || t === "FALSE" || t === "いいえ" || t === "0") return false;
  if (t === "TRUE" || t === "はい" || t === "1" || t === "ON") return true;
  return null;
}

/** 1 列の検査。返り値 { error, value } */
export function checkValue(column, raw) {
  const type = column.type;
  if (type === "チェック") {
    const b = toBool_(raw);
    return b === null ? { error: "はい か いいえ で入力してください", value: false } : { error: "", value: b };
  }
  if (type === "複数選択") {
    const items = Array.isArray(raw) ? raw.map(textOf).filter((s) => s !== "") : splitList(raw);
    const unknown = items.filter((s) => column.options.indexOf(s) < 0);
    if (unknown.length > 0) return { error: "候補にない値が含まれています: " + unknown.join("、"), value: items };
    return { error: "", value: items };
  }
  const t = textOf(Array.isArray(raw) ? raw.join(", ") : raw);
  if (t === "") return { error: "", value: type === "数値" || type === "金額" ? null : "" };
  if (type === "LINE") {
    if (!isLineUserId(t)) return { error: "LINE の友だちから選んでください", value: t };
    return { error: "", value: t };
  }
  if (type === "文字" || type === "参照") {
    if (t.length > TEXT_LIMIT) return { error: TEXT_LIMIT + " 字以内で入力してください", value: t };
    return { error: "", value: t };
  }
  if (type === "長文") {
    if (t.length > LONG_TEXT_LIMIT) return { error: LONG_TEXT_LIMIT.toLocaleString("en-US") + " 字以内で入力してください", value: t };
    return { error: "", value: t };
  }
  if (type === "数値") {
    const n = Number(toHalfWidth(t).replace(/,/g, ""));
    if (!Number.isFinite(n)) return { error: "数値で入力してください", value: t };
    return { error: "", value: n };
  }
  if (type === "金額") {
    const n = Number(toHalfWidth(t).replace(/[,¥￥円]/g, ""));
    if (!Number.isInteger(n)) return { error: "金額は整数（円）で入力してください", value: t };
    return { error: "", value: n };
  }
  if (type === "日付") {
    const key = toDateKey(t);
    if (key === null) return { error: "日付は 2026-09-16 の形で入力してください", value: t };
    return { error: "", value: key };
  }
  if (type === "日時") {
    const key = toDateTimeKey(t);
    if (key === null) return { error: "日時は 2026-09-16 10:30 の形で入力してください", value: t };
    return { error: "", value: key };
  }
  if (type === "選択") {
    if (column.options.indexOf(t) < 0) return { error: "候補から選んでください", value: t };
    return { error: "", value: t };
  }
  if (type === "メール") {
    const v = toHalfWidth(t);
    if (!EMAIL.test(v)) return { error: "メールアドレスの形で入力してください", value: v };
    return { error: "", value: v };
  }
  if (type === "電話") {
    const v = toHalfWidth(t);
    if (!PHONE.test(v)) return { error: "電話番号は数字とハイフンで入力してください", value: v };
    return { error: "", value: v };
  }
  if (type === "URL") {
    const v = toHalfWidth(t);
    if (!/^https?:\/\/\S+$/.test(v)) return { error: "URL は http:// か https:// から書いてください", value: v };
    return { error: "", value: v };
  }
  return { error: "", value: t };
}

/**
 * record は { 列名: 値 }。isNew のときは record に無い列に既定値を入れる。更新のときは record に無い列は values に含めない。
 */
export function validate(table, record, options) {
  const opts = options || {};
  const today = opts.today || "";
  const isNew = opts.isNew === true;
  const source = record === null || typeof record !== "object" ? {} : record;
  const errors = {};
  const values = {};
  for (let i = 0; i < table.columns.length; i += 1) {
    const column = table.columns[i];
    const present = Object.prototype.hasOwnProperty.call(source, column.name);
    if (!present && !isNew) continue;
    const raw = present ? source[column.name] : defaultFor_(column, today);
    const checked = checkValue(column, raw);
    if (checked.error !== "") {
      errors[column.name] = checked.error;
      continue;
    }
    if (column.required && column.type !== "チェック" && isEmpty_(checked.value)) {
      errors[column.name] = column.name + " を入力してください";
      continue;
    }
    values[column.name] = checked.value;
  }
  return { ok: Object.keys(errors).length === 0, errors: errors, values: values };
}
