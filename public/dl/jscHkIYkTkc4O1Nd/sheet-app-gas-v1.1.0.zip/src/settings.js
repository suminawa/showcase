/**
 * 「設定」シート（項目・値の 2 列）を読む。空欄は既定値、知らない行は無視。誤りは敬体の文で集める。
 * errors は画面を止める誤り（1.0 の行）。notifyErrors は通知とお客さまへの LINE 送信の行の誤りで、
 * 画面は止めず、メニュー「設定を確かめる」「通知のテストを送る」で知らせる。
 */
import { toHalfWidth } from "./dates.js";
import { findTable, lineColumn, splitList } from "./definition.js";
import { parseLineTemplates } from "./line.js";
import { DEFAULT_NOTIFY_TEMPLATE, NOTIFY_OPS, NOTIFY_TARGETS } from "./notify.js";
import { boolOf, textOf } from "./text.js";

export const SETTING_KEYS = ["アプリ名", "編集できる人", "1 ページの件数", "日付の書式", "AI を使う", "モデル", "AI の 1 日の上限"];
/** 1.1 で足した行（通知とお客さまへの LINE 送信）。README の表と samples/設定.csv はこの並び */
export const LINE_SETTING_KEYS = ["通知先", "Slack Webhook URL", "Discord Webhook URL", "LINE チャネルアクセストークン", "LINE 送信先 ID", "通知するテーブル", "通知する操作", "自分の操作は通知しない", "通知の文面", "LINE 定型文", "LINE を送れる人", "担当者名", "画面の URL"];
export const DATE_FORMATS = ["yyyy-MM-dd", "yyyy/MM/dd"];
/** 「LINE 定型文」の既定（見本 3 本）。1 行に 1 本の「題|本文」で、本文の改行は \n と書く */
export const DEFAULT_LINE_TEMPLATE_TEXT = [
  "お礼|{会社名} {担当者} 様\\n\\nいつもお世話になっております。{担当者名}です。\\n先日はお時間をいただき、ありがとうございました。\\nご不明な点がございましたら、お気軽にお知らせください。",
  "打ち合わせの確認|{会社名} {担当者} 様\\n\\nいつもお世話になっております。{担当者名}です。\\n次回のお打ち合わせについて、ご都合のよい日時の候補を 2 つほどお知らせいただけますでしょうか。\\nどうぞよろしくお願いいたします。",
  "資料のご案内|{会社名} {担当者} 様\\n\\nいつもお世話になっております。{担当者名}です。\\n先日お話しした資料をご用意しました。メールでお送りしますので、届きましたらご確認をお願いいたします。",
].join("\n");
export const DEFAULT_SETTINGS = {
  appName: "業務アプリ",
  editors: [],
  pageSize: 50,
  dateFormat: "yyyy-MM-dd",
  aiEnabled: true,
  model: "claude-sonnet-5",
  aiDailyLimit: 200,
  notifyTargets: [],
  slackWebhookUrl: "",
  discordWebhookUrl: "",
  lineToken: "",
  lineTo: "",
  notifyTables: [],
  notifyOps: NOTIFY_OPS.slice(),
  skipOwn: false,
  notifyTemplate: DEFAULT_NOTIFY_TEMPLATE,
  lineTemplateText: DEFAULT_LINE_TEMPLATE_TEXT,
  lineSenders: [],
  staffName: "",
  appUrl: "",
};

function normalizeKey_(value) {
  return String(value === null || value === undefined ? "" : value).replace(/\s+/g, "").toLowerCase();
}

function integer_(value, min, max) {
  // 全角で打たれた「１００」も数として読む
  const n = Number(toHalfWidth(textOf(value)));
  if (!Number.isInteger(n) || n < min || n > max) return null;
  return n;
}

/** 通知先に書いた宛先の行が空なら、どの行を埋めればよいかを言う（フォーム受付キットの ConfigError と同じ文） */
function requireFor_(errors, targets, target, value, label) {
  if (targets.indexOf(target) < 0 || value !== "") return;
  errors.push("「通知先」に " + target + " がありますが、「" + label + "」が空です。設定シートのその行を埋めてください。");
}

/** Webhook の URL は https:// から。URL は鍵なので、誤りの文には出さない */
function requireHttps_(errors, targets, target, value, label) {
  if (targets.indexOf(target) < 0 || value === "" || value.indexOf("https://") === 0) return;
  errors.push("「" + label + "」は https:// で始まる URL です。設定シートのその行を確かめてください。");
}

/** rows は「設定」シートの 2 次元配列（1 行目の見出しはあってもなくてもよい） */
export function parseSettings(rows) {
  const settings = {
    appName: DEFAULT_SETTINGS.appName,
    editors: [],
    pageSize: DEFAULT_SETTINGS.pageSize,
    dateFormat: DEFAULT_SETTINGS.dateFormat,
    aiEnabled: DEFAULT_SETTINGS.aiEnabled,
    model: DEFAULT_SETTINGS.model,
    aiDailyLimit: DEFAULT_SETTINGS.aiDailyLimit,
    notifyTargets: [],
    slackWebhookUrl: "",
    discordWebhookUrl: "",
    lineToken: "",
    lineTo: "",
    notifyTables: [],
    notifyOps: DEFAULT_SETTINGS.notifyOps.slice(),
    skipOwn: false,
    notifyTemplate: DEFAULT_SETTINGS.notifyTemplate,
    lineTemplateText: DEFAULT_SETTINGS.lineTemplateText,
    lineSenders: [],
    staffName: "",
    appUrl: "",
  };
  const errors = [];
  const notifyErrors = [];
  const list = Array.isArray(rows) ? rows : [];
  for (let i = 0; i < list.length; i += 1) {
    const key = normalizeKey_(list[i][0]);
    const value = list[i].length > 1 ? list[i][1] : "";
    const raw = textOf(value);
    if (key === "アプリ名") {
      if (raw !== "") settings.appName = raw.slice(0, 40);
    } else if (key === "編集できる人") {
      settings.editors = splitList(raw).map((s) => s.toLowerCase());
    } else if (key === "1ページの件数") {
      if (raw !== "") {
        const n = integer_(raw, 10, 200);
        if (n === null) errors.push("設定「1 ページの件数」は 10〜200 の整数にしてください（いまは「" + raw + "」）");
        else settings.pageSize = n;
      }
    } else if (key === "日付の書式") {
      if (raw !== "") {
        if (DATE_FORMATS.indexOf(raw) < 0) errors.push("設定「日付の書式」は yyyy-MM-dd か yyyy/MM/dd にしてください（いまは「" + raw + "」）");
        else settings.dateFormat = raw;
      }
    } else if (key === "aiを使う") {
      settings.aiEnabled = boolOf(value, DEFAULT_SETTINGS.aiEnabled);
    } else if (key === "モデル") {
      if (raw !== "") settings.model = raw;
    } else if (key === "aiの1日の上限") {
      if (raw !== "") {
        const n = integer_(raw, 1, 10000);
        if (n === null) errors.push("設定「AI の 1 日の上限」は 1〜10000 の整数にしてください（いまは「" + raw + "」）");
        else settings.aiDailyLimit = n;
      }
    } else if (key === "通知先") {
      const wanted = splitList(raw);
      for (let j = 0; j < wanted.length; j += 1) {
        const name = wanted[j].toLowerCase();
        if (NOTIFY_TARGETS.indexOf(name) < 0) notifyErrors.push("「通知先」に書けるのは slack / discord / line です: " + wanted[j]);
        else if (settings.notifyTargets.indexOf(name) < 0) settings.notifyTargets.push(name);
      }
    } else if (key === "slackwebhookurl") {
      settings.slackWebhookUrl = raw;
    } else if (key === "discordwebhookurl") {
      settings.discordWebhookUrl = raw;
    } else if (key === "lineチャネルアクセストークン") {
      settings.lineToken = raw;
    } else if (key === "line送信先id") {
      settings.lineTo = raw;
    } else if (key === "通知するテーブル") {
      settings.notifyTables = splitList(raw);
    } else if (key === "通知する操作") {
      if (raw !== "") {
        const ops = [];
        const wanted = splitList(raw);
        for (let j = 0; j < wanted.length; j += 1) {
          if (NOTIFY_OPS.indexOf(wanted[j]) < 0) notifyErrors.push("「通知する操作」に書けるのは 登録・更新・削除 です: " + wanted[j]);
          else if (ops.indexOf(wanted[j]) < 0) ops.push(wanted[j]);
        }
        settings.notifyOps = ops;
      }
    } else if (key === "自分の操作は通知しない") {
      settings.skipOwn = boolOf(value, false);
    } else if (key === "通知の文面") {
      if (raw !== "") settings.notifyTemplate = raw;
    } else if (key === "line定型文") {
      if (raw !== "") settings.lineTemplateText = raw;
    } else if (key === "lineを送れる人") {
      settings.lineSenders = splitList(raw).map((s) => s.toLowerCase());
    } else if (key === "担当者名") {
      settings.staffName = raw.slice(0, 40);
    } else if (key === "画面のurl") {
      // 通知の {URL} の元。画面用と webhook 用の 2 つのデプロイがあると、Apps Script の getUrl() がどちらを返すか決まらないため
      if (raw === "") settings.appUrl = "";
      else if (raw.indexOf("https://") !== 0) notifyErrors.push("「画面の URL」は https:// で始まる URL です（画面用のデプロイの URL を貼ってください）。いまは使わずに、Apps Script が返す URL で通知します");
      else settings.appUrl = raw.replace(/#.*$/, "");
    }
  }
  const targets = settings.notifyTargets;
  requireFor_(notifyErrors, targets, "slack", settings.slackWebhookUrl, "Slack Webhook URL");
  requireFor_(notifyErrors, targets, "discord", settings.discordWebhookUrl, "Discord Webhook URL");
  requireFor_(notifyErrors, targets, "line", settings.lineToken, "LINE チャネルアクセストークン");
  requireFor_(notifyErrors, targets, "line", settings.lineTo, "LINE 送信先 ID");
  requireHttps_(notifyErrors, targets, "slack", settings.slackWebhookUrl, "Slack Webhook URL");
  requireHttps_(notifyErrors, targets, "discord", settings.discordWebhookUrl, "Discord Webhook URL");
  const templateErrors = parseLineTemplates(settings.lineTemplateText).errors;
  for (let i = 0; i < templateErrors.length; i += 1) notifyErrors.push(templateErrors[i]);
  return { settings: settings, errors: errors, notifyErrors: notifyErrors };
}

/** 定義と突き合わせる誤り（「通知するテーブル」に定義に無い名前） */
export function crossCheckSettings(settings, tables) {
  const errors = [];
  for (let i = 0; i < settings.notifyTables.length; i += 1) {
    const name = settings.notifyTables[i];
    if (findTable(tables, name) === null) errors.push("設定「通知するテーブル」の「" + name + "」は定義にありません。定義のテーブル名と同じに書いてください");
  }
  return errors;
}

/** 「設定を確かめる」で問題が無いときに添える、通知とお客さまへの LINE 送信の状態（2 行） */
export function settingsSummary(settings, tables) {
  const lines = [];
  if (settings.notifyTargets.length === 0) {
    lines.push("通知: 使っていません（設定「通知先」が空です）");
  } else {
    const where = settings.notifyTables.length === 0 ? "すべてのテーブル" : settings.notifyTables.join("・");
    lines.push("通知: " + settings.notifyTargets.join("・") + " に、" + where + "の" + settings.notifyOps.join("・") + "を知らせます");
  }
  const withLine = tables.filter((table) => lineColumn(table) !== null);
  if (withLine.length === 0) {
    lines.push("お客さまへの LINE 送信: 定義に LINE の列がないため使っていません");
  } else if (settings.lineToken === "") {
    lines.push("お客さまへの LINE 送信: 定義に LINE の列がありますが、設定「LINE チャネルアクセストークン」が空のため使えません。使うときは設定シートのその行を埋めてください");
  } else {
    lines.push("お客さまへの LINE 送信: 使えます（" + withLine.map((table) => table.name + "「" + lineColumn(table).name + "」").join("、") + "）");
  }
  return lines;
}
