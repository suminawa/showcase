/**
 * 表示用・シート用・API 用の値の変換。
 * API の形: 日付 "yyyy-MM-dd"、日時 "yyyy-MM-dd HH:mm"、数値・金額は number か null、チェックは boolean、複数選択は配列、ほかは文字。
 */
import { dateFromKey, dateTimeFromKey, toDateKey, toDateTimeKey } from "./dates.js";
import { splitList } from "./definition.js";

export function withCommas(n) {
  const parts = String(n).split(".");
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return parts.join(".");
}

/**
 * 文字は必ず「文字として保存」する印（先頭の '）を付けて書く。見た目は変わらない。
 * Sheets は書いた文字を人の入力と同じように読み直すので、印が無いと 数式（=…）だけでなく
 * 電話の先頭 0 や「1-2」「2026-09-16 10:32:05」まで数や日付に化ける。
 */
export function safeCell(value) {
  const text = String(value === null || value === undefined ? "" : value);
  return text === "" ? "" : "'" + text;
}

/** セル 1 つに入る字数（Google スプレッドシートの上限 50,000 字に、' と余裕を見込む） */
export const TRASH_JSON_LIMIT = 49000;

/**
 * _ごみ箱 に書く JSON。長い値から順に切って上限に収める（収まらなければ ID と注記だけを残す）。
 * 切らずに書くとセルの上限で書き込みが失敗し、削除そのものができなくなる
 */
export function trashJson(record, limit) {
  const max = limit === undefined ? TRASH_JSON_LIMIT : limit;
  const copy = Object.assign({}, record);
  let json = JSON.stringify(copy);
  let guard = 0;
  while (json.length > max && guard < 100) {
    guard += 1;
    const keys = Object.keys(copy).filter((k) => typeof copy[k] === "string" && copy[k].length > 20);
    if (keys.length === 0) break;
    keys.sort((a, b) => copy[b].length - copy[a].length);
    const value = copy[keys[0]];
    const keep = Math.max(0, value.length - (json.length - max) - 8);
    copy[keys[0]] = value.slice(0, keep) + "…（切りました）";
    json = JSON.stringify(copy);
  }
  if (json.length > max) json = JSON.stringify({ ID: copy.ID, 注記: "行が長すぎたため内容を残せませんでした" });
  return json;
}

function applyDateFormat_(key, dateFormat) {
  if (dateFormat === "yyyy/MM/dd") return key.replace(/-/g, "/");
  return key;
}

/** 一覧・詳細に出す文字。空は "" */
export function formatCell(column, value, options) {
  const opts = options || {};
  const dateFormat = opts.dateFormat || "yyyy-MM-dd";
  if (value === null || value === undefined || value === "") return "";
  const type = column.type;
  if (type === "金額") return "¥" + withCommas(value);
  if (type === "数値") return withCommas(value);
  if (type === "日付") return applyDateFormat_(String(value), dateFormat);
  if (type === "日時") return applyDateFormat_(String(value).slice(0, 10), dateFormat) + String(value).slice(10);
  if (type === "チェック") return value === true || String(value).toUpperCase() === "TRUE" ? "✓" : "";
  if (type === "複数選択") return (Array.isArray(value) ? value : splitList(value)).join("、");
  return String(value);
}

/** API の形 → シートのセル */
export function toSheetValue(column, value) {
  if (value === null || value === undefined) return "";
  const type = column.type;
  if (type === "日付") {
    const d = dateFromKey(value);
    return d === null ? "" : d;
  }
  if (type === "日時") {
    const d = dateTimeFromKey(value);
    return d === null ? "" : d;
  }
  if (type === "数値" || type === "金額") return value === "" ? "" : Number(value);
  if (type === "チェック") return value === true || String(value).toUpperCase() === "TRUE";
  if (type === "複数選択") return safeCell((Array.isArray(value) ? value : splitList(value)).join(", "));
  return safeCell(value);
}

/** シートのセル → API の形 */
export function fromSheetValue(column, raw) {
  if (raw === null || raw === undefined || raw === "") return column.type === "数値" || column.type === "金額" ? null : column.type === "チェック" ? false : column.type === "複数選択" ? [] : "";
  const type = column.type;
  if (type === "日付") {
    const key = toDateKey(raw);
    return key === null ? String(raw) : key;
  }
  if (type === "日時") {
    const key = toDateTimeKey(raw);
    return key === null ? String(raw) : key;
  }
  if (type === "数値" || type === "金額") {
    const n = typeof raw === "number" ? raw : Number(String(raw).replace(/[,¥￥円]/g, ""));
    return Number.isFinite(n) ? n : String(raw);
  }
  if (type === "チェック") return raw === true || String(raw).toUpperCase() === "TRUE";
  if (type === "複数選択") return splitList(raw);
  return String(raw);
}

/** システム列の値（ID・作成日時・更新日時・更新者）は文字のまま */
export function fromSystemValue(raw) {
  if (raw === null || raw === undefined) return "";
  if (Object.prototype.toString.call(raw) === "[object Date]") {
    const key = toDateTimeKey(raw);
    return key === null ? "" : key;
  }
  return String(raw);
}
