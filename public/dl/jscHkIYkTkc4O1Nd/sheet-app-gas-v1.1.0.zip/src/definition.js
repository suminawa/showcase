/**
 * 「定義」シートの行から、テーブルと列のスキーマを組む。誤りは敬体の文で集めて返す（投げない）。
 * GAS のグローバルには触らない。
 */
import { boolOf, textOf } from "./text.js";

export const TYPES = ["文字", "長文", "数値", "金額", "日付", "日時", "選択", "複数選択", "チェック", "メール", "電話", "URL"];
export const SYSTEM_COLUMNS = ["ID", "作成日時", "更新日時", "更新者"];
export const RESERVED_SHEETS = ["設定", "定義"];
/** お客さまの LINE のユーザー ID を持つ型。参照 と同じく TYPES の外で読む。1 テーブルに 1 列まで */
export const LINE_TYPE = "LINE";
/** 既定で検索欄の対象にする型 */
const DEFAULT_SEARCHABLE = ["文字", "長文", "メール", "電話"];
/** 定義シートの見出し → 内部の名前 */
const HEADER_KEYS = { テーブル: "table", 列: "column", 型: "type", 必須: "required", 選択肢: "options", 一覧: "inList", 検索: "searchable", 既定値: "defaultValue", 説明: "note" };
const HEADER_LABELS = { table: "テーブル", column: "列", type: "型" };

/** カンマと読点で分け、前後の空白を落とし、空を除く */
export function splitList(text) {
  const parts = textOf(text).split(/[,、]/);
  const out = [];
  for (let i = 0; i < parts.length; i += 1) {
    const p = parts[i].trim();
    if (p !== "") out.push(p);
  }
  return out;
}

export function isReservedSheet(name) {
  const n = textOf(name);
  return RESERVED_SHEETS.indexOf(n) >= 0 || n.charAt(0) === "_";
}

/** 表示名の列: 最初の 文字 型。無ければ ID */
export function displayColumn(table) {
  for (let i = 0; i < table.columns.length; i += 1) {
    if (table.columns[i].type === "文字") return table.columns[i].name;
  }
  return "ID";
}

/** シートの見出し: ID、定義の列、システム列 */
export function headerFor(table) {
  const names = ["ID"];
  for (let i = 0; i < table.columns.length; i += 1) names.push(table.columns[i].name);
  return names.concat(["作成日時", "更新日時", "更新者"]);
}

export function findTable(tables, name) {
  for (let i = 0; i < tables.length; i += 1) {
    if (tables[i].name === name) return tables[i];
  }
  return null;
}

export function findColumn(table, name) {
  for (let i = 0; i < table.columns.length; i += 1) {
    if (table.columns[i].name === name) return table.columns[i];
  }
  return null;
}

/** テーブルの LINE の列。無ければ null */
export function lineColumn(table) {
  for (let i = 0; i < table.columns.length; i += 1) {
    if (table.columns[i].type === LINE_TYPE) return table.columns[i];
  }
  return null;
}

function typeError_(line, typeText) {
  return "sheet-app: 定義の " + line + " 行目: 型「" + typeText + "」は使えません。" + TYPES.join("・") + "・LINE・参照:<テーブル名> のいずれかにしてください";
}

/**
 * rows は「定義」シートの 2 次元配列（1 行目が見出し）。
 * 返り値 { tables, errors }。誤りのある行は落とし、通った行だけでテーブルを組む。
 */
export function parseDefinition(rows) {
  const tables = [];
  const errors = [];
  if (!Array.isArray(rows) || rows.length === 0) {
    return { tables: tables, errors: ["sheet-app: 「定義」シートが空です。README の「定義の書き方」を見て、テーブルと列を書いてください"] };
  }
  const index = {};
  const header = rows[0];
  for (let i = 0; i < header.length; i += 1) {
    const key = HEADER_KEYS[textOf(header[i])];
    if (key !== undefined && index[key] === undefined) index[key] = i;
  }
  const requiredKeys = ["table", "column", "type"];
  for (let i = 0; i < requiredKeys.length; i += 1) {
    if (index[requiredKeys[i]] === undefined) {
      errors.push("sheet-app: 「定義」シートの 1 行目に「" + HEADER_LABELS[requiredKeys[i]] + "」の見出しがありません");
    }
  }
  if (errors.length > 0) return { tables: tables, errors: errors };
  const cell = (row, key) => (index[key] === undefined || index[key] >= row.length ? "" : row[index[key]]);
  const byName = {};
  for (let r = 1; r < rows.length; r += 1) {
    const row = rows[r];
    const line = r + 1;
    const tableName = textOf(cell(row, "table"));
    const columnName = textOf(cell(row, "column"));
    const typeText = textOf(cell(row, "type"));
    if (tableName === "" && columnName === "" && typeText === "") continue;
    if (tableName === "") {
      errors.push("sheet-app: 定義の " + line + " 行目: テーブル名が空です");
      continue;
    }
    if (isReservedSheet(tableName)) {
      errors.push("sheet-app: 定義の " + line + " 行目: テーブル名「" + tableName + "」は使えません（設定・定義・_ で始まる名前は予約されています）");
      continue;
    }
    if (columnName === "") {
      errors.push("sheet-app: 定義の " + line + " 行目: 列名が空です");
      continue;
    }
    if (SYSTEM_COLUMNS.indexOf(columnName) >= 0) {
      errors.push("sheet-app: 定義の " + line + " 行目: 列名「" + columnName + "」はアプリが自動で付ける列なので使えません");
      continue;
    }
    let type = typeText;
    let refTable = null;
    const ref = typeText.match(/^参照[:：]\s*(.+)$/);
    if (ref) {
      type = "参照";
      refTable = ref[1].trim();
    } else if (typeText.toUpperCase() === LINE_TYPE) {
      type = LINE_TYPE;
    } else if (TYPES.indexOf(typeText) < 0) {
      errors.push(typeError_(line, typeText));
      continue;
    }
    const options = splitList(cell(row, "options"));
    if ((type === "選択" || type === "複数選択") && options.length === 0) {
      errors.push("sheet-app: 定義の " + line + " 行目: 「" + columnName + "」は " + type + " なので、選択肢をカンマ区切りで書いてください");
      continue;
    }
    let table = byName[tableName];
    if (table === undefined) {
      table = { name: tableName, display: "ID", columns: [] };
      byName[tableName] = table;
      tables.push(table);
    }
    if (findColumn(table, columnName) !== null) {
      errors.push("sheet-app: 定義の " + line + " 行目: テーブル「" + tableName + "」に列「" + columnName + "」が 2 回あります");
      continue;
    }
    if (type === LINE_TYPE && lineColumn(table) !== null) {
      errors.push("sheet-app: 定義の " + line + " 行目: テーブル「" + tableName + "」の LINE の列は 1 つまでです（すでに「" + lineColumn(table).name + "」があります）");
      continue;
    }
    table.columns.push({
      name: columnName,
      type: type,
      required: boolOf(cell(row, "required"), false),
      options: options,
      inList: boolOf(cell(row, "inList"), true),
      searchable: boolOf(cell(row, "searchable"), DEFAULT_SEARCHABLE.indexOf(type) >= 0),
      defaultValue: textOf(cell(row, "defaultValue")),
      note: textOf(cell(row, "note")),
      refTable: refTable,
    });
  }
  for (let t = 0; t < tables.length; t += 1) {
    const table = tables[t];
    for (let c = 0; c < table.columns.length; c += 1) {
      const column = table.columns[c];
      if (column.type === "参照" && byName[column.refTable] === undefined) {
        errors.push("sheet-app: テーブル「" + table.name + "」の列「" + column.name + "」の参照先「" + column.refTable + "」が定義にありません");
      }
    }
    table.display = displayColumn(table);
  }
  if (tables.length === 0 && errors.length === 0) {
    errors.push("sheet-app: 「定義」シートにテーブルがありません。2 行目から、テーブル・列・型を書いてください");
  }
  return { tables: tables, errors: errors };
}
