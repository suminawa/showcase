/**
 * Web アプリの入口（doGet）と、画面から google.script.run で呼ぶ api_*。
 * 引数を検査 → 純粋な処理 → gas_sheets の順。誤りは敬体の Error を投げる（画面の帯に出る）。
 * 登録・更新・削除は、保存が済んでから（ロックの外で）通知する。通知が失敗しても保存は取り消さず、画面にも出さない。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { findColumn, findTable, lineColumn } from "./definition.js";
import { validate } from "./validate.js";
import { laterId, nextId, parseId } from "./ids.js";
import { applyQuery, filterRows, normalizeQuery, sortRows } from "./query.js";
import { toCsv } from "./csv.js";
import { canEdit } from "./access.js";
import { buildDraftRequest, buildFilterRequest, buildSummaryRequest, parseFilterAnswer } from "./ai_prompt.js";
import { addUsage } from "./usage.js";
import { buildChanges, displayValues, recordUrl, shouldNotify } from "./notify.js";
import { LINE_MESSAGES, SENT, findFriend, friendsForScreen, lineSendError, lineTextError, parseLineTemplates, staffNameFor } from "./line.js";
import { readApiKey_, readDailyAiCount_, readLastId_, readMonthUsage_, saveDailyAiCount_, saveLastId_, saveMonthUsage_, withLock_ } from "./gas_store.js";
import { appendRecord_, deleteRecord_, ownerEmail_, readDefinition_, readIds_, readSettings_, readTable_, sheetEditable_, updateRecord_ } from "./gas_sheets.js";
import { callClaude_ } from "./gas_claude.js";
import { notifyChange_, pushLine_, webAppUrl_ } from "./gas_notify.js";
import { appendSendLog_, monthSendCount_, readFriends_, readSendLog_ } from "./gas_line.js";
import { textOf } from "./text.js";

const OPTIONS_LIMIT = 2000;
const AI_UNAVAILABLE = "AI の機能は使えません。設定「AI を使う」が TRUE で、スクリプト プロパティ ANTHROPIC_API_KEY が入っているかをご確認ください";
const SUMMARY_TOO_LONG = "記録が長すぎて要約を作れませんでした。長文の項目を短くしてからお試しください";
const DRAFT_TOO_LONG = "下書きを作りきれませんでした。用件を短くしてお試しください";
const DRAFT_EMPTY = "下書きを作れませんでした。もう一度お試しください";
/** 送れたが _LINE送信履歴 に書けなかったとき。画面はこの文をお知らせに出す（送り直さないように） */
export const LINE_SENT_NO_LOG = "送りました（履歴には書けませんでした）。もう一度送ると 2 通届くので、送り直さないでください";
/** webhook 用のデプロイの URL をブラウザで開いたとき（と、利用者が分からないとき）に返す文 */
export const LINE_HOOK_TEXT = "この URL は LINE の Webhook 用です。業務アプリの画面は、画面用のデプロイの URL で開いてください（スプレッドシートのメニュー「業務アプリ」→「Web アプリの URL」）。";
/** 利用者が分からない・実行ユーザーと違う（webhook 用のデプロイから呼ばれた）ときに api_* が返す誤り */
export const NOT_SIGNED_IN = "この URL からは業務アプリを使えません。画面用のデプロイの URL を、Google アカウントにログインしたブラウザで開いてください";

/** スプレッドシートを開けないとき（共有されていない・削除された・別のアカウントで開いている）の案内 */
function escapeHtml_(value) {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function noAccessHtml_(email, detail) {
  const who = email === "" ? "" : "<p>いま開いている Google アカウント: <strong>" + escapeHtml_(email) + "</strong></p>";
  const why = textOf(detail) === "" ? "" : '<p style="color:#6b716c">開けなかった理由: ' + escapeHtml_(textOf(detail)) + "</p>";
  return (
    '<!DOCTYPE html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">' +
    '<body style="font-family:system-ui;padding:24px;line-height:1.7"><p>このアプリを使うには、元のスプレッドシートの共有が必要です。' +
    "所有者に「閲覧者」か「編集者」での共有をご依頼ください。</p>" +
    who +
    "<p>共有されているのにこの画面が出るときは、ブラウザに複数の Google アカウントでログインしていて、別のアカウントで開かれていることがあります。" +
    "シークレット ウィンドウで、共有されているアカウントだけでログインしてお試しください。</p>" +
    why +
    "</body></html>"
  );
}

function user_() {
  try {
    return String(Session.getActiveUser().getEmail() || "").trim().toLowerCase();
  } catch (error) {
    return "";
  }
}

function effectiveUser_() {
  try {
    return String(Session.getEffectiveUser().getEmail() || "").trim().toLowerCase();
  } catch (error) {
    return "";
  }
}

/**
 * 画面を出してよい呼び出しか。画面用のデプロイ（アクセスしているユーザーとして実行）では、利用者と実行ユーザーが同じ人になる。
 * webhook 用のデプロイ（実行ユーザー「自分」・アクセス「全員」）では、ログインしていない人の利用者は ""、ほかの人は所有者と食い違う。
 * どちらも所有者の権限でシートに触れてしまうので断る（所有者ご本人のブラウザだけは通るが、所有者の権限は元から持っている）
 */
export function signedInHere_() {
  const active = user_();
  return active !== "" && active === effectiveUser_();
}

/** 設定・定義・利用者をまとめて読む（1 回の API で 1 回だけ）。利用者が確かめられなければ、何も読まずに断る */
function contextOf() {
  if (!signedInHere_()) throw new Error(NOT_SIGNED_IN);
  const settings = readSettings_();
  const definition = readDefinition_();
  return {
    settings: settings.settings,
    tables: definition.tables,
    errors: definition.errors.concat(settings.errors),
    email: user_(),
  };
}

/** 画面に編集の操作を出してよいか。「編集できる人」の絞り込みと、シートの共有（閲覧者には出さない）の両方 */
function canEditHere_(ctx) {
  if (!canEdit(ctx.email, ctx.settings.editors)) return false;
  return sheetEditable_(ctx.email) !== false;
}

function tableOf_(ctx, name) {
  const table = findTable(ctx.tables, textOf(name));
  if (table === null) throw new Error("テーブル「" + textOf(name) + "」は定義にありません");
  return table;
}

function requireEditor_(ctx) {
  if (!canEdit(ctx.email, ctx.settings.editors)) {
    throw new Error("この画面では閲覧のみできます。編集が必要な場合は、設定「編集できる人」への追加を所有者に依頼してください");
  }
}

function aiAvailable_(ctx) {
  return ctx.settings.aiEnabled && readApiKey_() !== "";
}

/** 参照の列の表示名。rows に出てくる ID だけ引く */
function refsFor_(ctx, table, rows) {
  const refs = {};
  const cache = {};
  for (let c = 0; c < table.columns.length; c += 1) {
    const column = table.columns[c];
    if (column.type !== "参照") continue;
    const target = findTable(ctx.tables, column.refTable);
    if (target === null) continue;
    if (cache[target.name] === undefined) {
      const map = {};
      const read = readTable_(target).records;
      for (let i = 0; i < read.length; i += 1) map[read[i].ID] = textOf(read[i][target.display]) || read[i].ID;
      cache[target.name] = map;
    }
    const map = cache[target.name];
    const out = {};
    for (let r = 0; r < rows.length; r += 1) {
      const id = textOf(rows[r][column.name]);
      if (id !== "" && map[id] !== undefined) out[id] = map[id];
    }
    refs[column.name] = out;
  }
  return refs;
}

/** 参照の値が相手のテーブルに実在するか */
function checkRefs_(ctx, table, values) {
  for (let c = 0; c < table.columns.length; c += 1) {
    const column = table.columns[c];
    if (column.type !== "参照" || !Object.prototype.hasOwnProperty.call(values, column.name)) continue;
    const id = textOf(values[column.name]);
    if (id === "") continue;
    const target = findTable(ctx.tables, column.refTable);
    if (target === null || readTable_(target).rowNumbers[id] === undefined) {
      throw new Error(column.name + ": 参照先の記録が見つかりません（" + id + "）");
    }
  }
}

function errorText_(errors) {
  const names = Object.keys(errors);
  return names.map((name) => errors[name]).join("\n");
}

function findRecord_(table, id) {
  const read = readTable_(table);
  const rowNumber = read.rowNumbers[textOf(id)];
  if (rowNumber === undefined) throw new Error("ID「" + textOf(id) + "」の記録が見つかりません。削除された可能性があります");
  let record = null;
  for (let i = 0; i < read.records.length; i += 1) {
    if (read.records[i].ID === textOf(id)) {
      record = read.records[i];
      break;
    }
  }
  return { record: record, rowNumber: rowNumber };
}

function monthKey_() {
  return toDateKey(new Date()).slice(0, 7);
}

/** 画面の候補に出す友だち（表示名の取れた ID だけ） */
function friends_() {
  return friendsForScreen(readFriends_());
}

function hasLineColumn_(ctx) {
  for (let i = 0; i < ctx.tables.length; i += 1) if (lineColumn(ctx.tables[i]) !== null) return true;
  return false;
}

/** 送れる人: 編集できる人（editable）で、「LINE を送れる人」が空かその中の人 */
function canSendLine_(ctx, editable) {
  return editable && canEdit(ctx.email, ctx.settings.lineSenders);
}

function requireLineSender_(ctx) {
  if (!canEditHere_(ctx)) throw new Error(LINE_MESSAGES.viewer);
  if (!canEdit(ctx.email, ctx.settings.lineSenders)) throw new Error(LINE_MESSAGES.notSender);
}

/** bootstrap の line。LINE の列が無ければシートを読まない */
function lineInfo_(ctx, editable) {
  const staffName = staffNameFor(ctx.settings, ctx.email);
  if (!hasLineColumn_(ctx)) return { enabled: false, friends: [], templates: [], canSend: false, monthCount: 0, staffName: staffName };
  const enabled = ctx.settings.lineToken !== "";
  return {
    enabled: enabled,
    friends: friends_(),
    templates: parseLineTemplates(ctx.settings.lineTemplateText).templates,
    canSend: enabled && canSendLine_(ctx, editable),
    monthCount: monthSendCount_(monthKey_()),
    staffName: staffName,
  };
}

/** LINE の列の値が友だちの一覧（表示名の取れた ID）にあり、ブロック中でないか。current と同じ値（変えていない値）は見ない */
function checkLine_(table, values, current) {
  const column = lineColumn(table);
  if (column === null || !Object.prototype.hasOwnProperty.call(values, column.name)) return;
  const id = textOf(values[column.name]);
  if (id === "" || id === textOf(current)) return;
  const friend = findFriend(friends_(), id);
  if (friend === null) throw new Error(column.name + ": " + LINE_MESSAGES.unknown);
  // ブロック中の方を新しく結びつけても送れないので断る（すでに結びついている値はそのまま保存できる）
  if (friend.blocked) throw new Error(column.name + ": " + LINE_MESSAGES.blockedChoice);
}

/** 通知の表示に使う labels: 参照の列は相手の表示名、LINE の列は友だちの表示名 */
function labelsFor_(ctx, table, rows) {
  const labels = refsFor_(ctx, table, rows);
  const column = lineColumn(table);
  if (column !== null) {
    const map = {};
    const friends = friends_();
    for (let i = 0; i < friends.length; i += 1) map[friends[i].id] = friends[i].name;
    labels[column.name] = map;
  }
  return labels;
}

/** 保存のあとに 1 回だけ呼ぶ。投げない（保存は済んでいるので、利用者を止めない） */
function notifyAfterSave_(ctx, table, op, id, before, after) {
  try {
    if (ctx.settings.notifyTargets.length === 0) return;
    const owner = ownerEmail_();
    if (!shouldNotify(ctx.settings, { table: table.name, op: op, actor: ctx.email }, owner)) return;
    const rows = [before, after].filter((row) => row !== null);
    const options = { dateFormat: ctx.settings.dateFormat, labels: labelsFor_(ctx, table, rows) };
    const values = displayValues(table, after !== null ? after : before, options);
    notifyChange_(
      ctx.settings,
      {
        appName: ctx.settings.appName,
        table: table.name,
        op: op,
        id: id,
        label: textOf(values[table.display]) || id,
        actor: ctx.email,
        changes: buildChanges(table, op, before, after, options),
        url: recordUrl(webAppUrl_(ctx.settings), table.name, id),
        values: values,
      },
      owner,
    );
  } catch (error) {
    Logger.log("業務アプリ: 通知の準備ができませんでした: " + (error && error.message ? error.message : error));
  }
}

/** 1 件と、参照の列の表示名（{ 列名: 表示名 }） */
function recordWithRefs_(ctx, table, id) {
  const found = findRecord_(table, id);
  const refs = refsFor_(ctx, table, [found.record]);
  const flat = {};
  Object.keys(refs).forEach((name) => {
    const value = textOf(found.record[name]);
    if (value !== "" && refs[name][value] !== undefined) flat[name] = refs[name][value];
  });
  return { row: found.record, refs: flat };
}

export function doGet(e) {
  // webhook 用のデプロイ（実行ユーザー「自分」・アクセス「全員」）で画面を出さない。
  // デプロイの ID は取れないので、?hook=line か、利用者と実行ユーザーの食い違い（signedInHere_）で見分ける。引数は問わない
  if ((e && e.parameter && e.parameter.hook === "line") || !signedInHere_()) {
    return ContentService.createTextOutput(LINE_HOOK_TEXT).setMimeType(ContentService.MimeType.TEXT);
  }
  try {
    const ctx = contextOf();
    return HtmlService.createHtmlOutputFromFile("App").setTitle(ctx.settings.appName).addMetaTag("viewport", "width=device-width, initial-scale=1");
  } catch (error) {
    // スプレッドシートを開けない人（共有されていない・元のシートが削除された）には、空白の画面ではなく案内を出す
    return HtmlService.createHtmlOutput(noAccessHtml_(user_(), error && error.message ? error.message : error)).setTitle("業務アプリ");
  }
}

export function api_bootstrap() {
  const ctx = contextOf();
  const editable = canEditHere_(ctx);
  return {
    appName: ctx.settings.appName,
    tables: ctx.tables,
    errors: ctx.errors,
    user: { email: ctx.email, canEdit: editable },
    ai: aiAvailable_(ctx),
    pageSize: ctx.settings.pageSize,
    dateFormat: ctx.settings.dateFormat,
    today: toDateKey(new Date()),
    line: lineInfo_(ctx, editable),
  };
}

function queryOf_(ctx, table, raw) {
  const source = raw === null || typeof raw !== "object" ? {} : raw;
  const merged = Object.assign({ pageSize: ctx.settings.pageSize }, source);
  if (source.pageSize === undefined || source.pageSize === null) merged.pageSize = ctx.settings.pageSize;
  return normalizeQuery(table, merged);
}

export function api_list(tableName, rawQuery) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const query = queryOf_(ctx, table, rawQuery);
  const result = applyQuery(table, readTable_(table).records, query);
  return { rows: result.rows, total: result.total, page: result.page, pageSize: result.pageSize, refs: refsFor_(ctx, table, result.rows) };
}

/** 1 件。LINE の列があるテーブルは、送信履歴（新しい順・20 件まで）も返す */
export function api_get(tableName, id) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const got = recordWithRefs_(ctx, table, id);
  return { row: got.row, refs: got.refs, history: lineColumn(table) === null ? [] : readSendLog_(table.name, got.row.ID) };
}

export function api_options(tableName, columnName) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const column = findColumn(table, textOf(columnName));
  if (column === null || column.type !== "参照") throw new Error("列「" + textOf(columnName) + "」は参照の列ではありません");
  const target = tableOf_(ctx, column.refTable);
  const records = sortRows(target, readTable_(target).records, { column: target.display, dir: "asc" });
  const options = [];
  for (let i = 0; i < records.length && i < OPTIONS_LIMIT; i += 1) {
    options.push({ id: records[i].ID, label: textOf(records[i][target.display]) || records[i].ID });
  }
  return { options: options, truncated: records.length > OPTIONS_LIMIT };
}

/** ids のうち、today の日付キーで始まる ID の最大。無ければ "" */
export function maxIdOf_(ids, today) {
  let best = "";
  for (let i = 0; i < ids.length; i += 1) {
    const parsed = parseId(ids[i]);
    if (parsed === null || parsed.dateKey !== today) continue;
    best = laterId(best, ids[i]);
  }
  return best;
}

export function api_create(tableName, record) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  requireEditor_(ctx);
  const now = new Date();
  const today = toDateKey(now);
  const checked = validate(table, record, { today: today, isNew: true });
  if (!checked.ok) throw new Error(errorText_(checked.errors));
  checkRefs_(ctx, table, checked.values);
  checkLine_(table, checked.values, "");
  const saved = withLock_(() => {
    // 覚え書きが消えても（プロパティの削除・シートの複製）、シートに残っている今日の ID の続きから振る
    const id = nextId(laterId(readLastId_(table.name), maxIdOf_(readIds_(table), today)), today);
    const stamp = formatStamp(now);
    const full = Object.assign({ ID: id }, checked.values, { 作成日時: stamp, 更新日時: stamp, 更新者: ctx.email });
    appendRecord_(table, full);
    saveLastId_(table.name, id);
    return full;
  });
  notifyAfterSave_(ctx, table, "登録", saved.ID, null, saved);
  return { id: saved.ID };
}

export function api_update(tableName, id, record, seenUpdatedAt) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  requireEditor_(ctx);
  const now = new Date();
  const checked = validate(table, record, { today: toDateKey(now), isNew: false });
  if (!checked.ok) throw new Error(errorText_(checked.errors));
  checkRefs_(ctx, table, checked.values);
  const saved = withLock_(() => {
    const found = findRecord_(table, id);
    if (textOf(found.record.更新日時) !== textOf(seenUpdatedAt)) {
      throw new Error("ほかの方が先に更新しました。いちど閉じて、読み直してください");
    }
    const column = lineColumn(table);
    checkLine_(table, checked.values, column === null ? "" : found.record[column.name]);
    const stamp = formatStamp(new Date());
    const changes = Object.assign({}, checked.values, { 更新日時: stamp, 更新者: ctx.email });
    updateRecord_(table, found.rowNumber, changes);
    return { before: found.record, after: Object.assign({}, found.record, changes) };
  });
  notifyAfterSave_(ctx, table, "更新", saved.before.ID, saved.before, saved.after);
  return { updatedAt: saved.after.更新日時 };
}

export function api_delete(tableName, id) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  requireEditor_(ctx);
  const removed = withLock_(() => {
    const found = findRecord_(table, id);
    deleteRecord_(table, found.rowNumber, found.record.ID, found.record, ctx.email, formatStamp(new Date()));
    return found.record;
  });
  notifyAfterSave_(ctx, table, "削除", removed.ID, removed, null);
  return { ok: true };
}

export function api_export(tableName, rawQuery) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const query = queryOf_(ctx, table, rawQuery);
  const rows = sortRows(table, filterRows(table, readTable_(table).records, query), query.sort);
  return toCsv(table, rows);
}

/** AI の前置き: 使えるか・1 日の上限。呼べるなら回数を 1 つ進める（同時に呼ばれても上限を越えないよう、ロックの中で数える） */
function beforeAi_(ctx) {
  if (!aiAvailable_(ctx)) throw new Error(AI_UNAVAILABLE);
  const today = toDateKey(new Date());
  return withLock_(() => {
    const count = readDailyAiCount_(today);
    if (count >= ctx.settings.aiDailyLimit) throw new Error("AI の本日の上限（" + ctx.settings.aiDailyLimit + " 回）に達しました。明日またお試しください");
    saveDailyAiCount_(today, count + 1);
    return today;
  });
}

/** API の呼び出しが失敗したら、進めた回数を戻す */
function undoAi_(today) {
  withLock_(() => {
    saveDailyAiCount_(today, Math.max(0, readDailyAiCount_(today) - 1));
  });
}

function afterAi_(today, usage) {
  const month = today.slice(0, 7);
  withLock_(() => {
    saveMonthUsage_(month, addUsage(readMonthUsage_(month), usage));
  });
}

/** 前置き → 呼び出し → 後始末。失敗したら回数を戻してから投げる */
function callAi_(ctx, body) {
  const today = beforeAi_(ctx);
  let answer;
  try {
    answer = callClaude_(readApiKey_(), body);
  } catch (error) {
    undoAi_(today);
    throw error;
  }
  afterAi_(today, answer.usage);
  return answer;
}

export function api_ai_filter(tableName, text) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const words = textOf(text);
  if (words === "") throw new Error("絞り込みの言葉を入力してください");
  const answer = callAi_(ctx, buildFilterRequest(table, words.slice(0, 500), { today: toDateKey(new Date()), model: ctx.settings.model }));
  return parseFilterAnswer(table, answer.text);
}

export function api_ai_summary(tableName, id) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const got = recordWithRefs_(ctx, table, id);
  const answer = callAi_(ctx, buildSummaryRequest(table, got.row, got.refs, { today: toDateKey(new Date()), model: ctx.settings.model, dateFormat: ctx.settings.dateFormat }));
  // 上限まで書いても終わらなかった答えは、途中で切れた文なので出さない
  if (answer.stopReason === "max_tokens") return { text: SUMMARY_TOO_LONG };
  return { text: textOf(answer.text) === "" ? "要約を作れませんでした。もう一度お試しください" : textOf(answer.text) };
}

/**
 * お客さまの LINE に 1 通送る。送れる人・トークン・本文・結びついた友だち（ブロック中でない）を確かめてから push し、
 * 送れたら _LINE送信履歴 に 1 行。LINE が断ったら状態コードを敬体に言い換えて投げる（履歴には書かない）
 */
export function api_line_send(tableName, id, text) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  const column = lineColumn(table);
  if (column === null) throw new Error(LINE_MESSAGES.noColumn);
  requireLineSender_(ctx);
  if (ctx.settings.lineToken === "") throw new Error(LINE_MESSAGES.noToken);
  const problem = lineTextError(text);
  if (problem !== "") throw new Error(problem);
  const body = String(text).trim();
  const found = findRecord_(table, id);
  const userId = textOf(found.record[column.name]);
  if (userId === "") throw new Error(LINE_MESSAGES.noFriend);
  const friend = findFriend(friends_(), userId);
  if (friend === null) throw new Error(LINE_MESSAGES.unknown);
  if (friend.blocked) throw new Error(LINE_MESSAGES.blocked);
  try {
    pushLine_(ctx.settings.lineToken, userId, body);
  } catch (error) {
    throw new Error(lineSendError(error && error.status ? error.status : 0));
  }
  // ここから先は送れたあと。履歴に書けなくても誤りにはしない（誤りを見て送り直すと、お客さまに 2 通届く）
  const stamp = formatStamp(new Date());
  try {
    withLock_(() => appendSendLog_({ at: stamp, table: table.name, id: found.record.ID, to: userId, sender: ctx.email, text: body, result: SENT }));
  } catch (error) {
    Logger.log("業務アプリ: LINE は送れましたが、_LINE送信履歴 に書けませんでした（" + table.name + " " + found.record.ID + "）: " + (error && error.message ? error.message : error));
    let history = [];
    let monthCount = 0;
    try {
      history = readSendLog_(table.name, found.record.ID);
      monthCount = monthSendCount_(monthKey_());
    } catch (readError) {
      // 読めなくても、送れたことは返す
    }
    return { history: history, monthCount: monthCount, note: LINE_SENT_NO_LOG };
  }
  return { history: readSendLog_(table.name, found.record.ID), monthCount: monthSendCount_(monthKey_()) };
}

/** LINE で送る文の下書き。送れる人と同じ権限。呼び出しは「AI の 1 日の上限」に数える */
export function api_ai_draft(tableName, id, intent) {
  const ctx = contextOf();
  const table = tableOf_(ctx, tableName);
  // 送れないところで下書きを作って、AI の 1 日の回数を使わない（api_line_send と同じ順に確かめる）
  if (lineColumn(table) === null) throw new Error(LINE_MESSAGES.noColumn);
  requireLineSender_(ctx);
  if (ctx.settings.lineToken === "") throw new Error(LINE_MESSAGES.noToken);
  const words = textOf(intent);
  if (words === "") throw new Error(LINE_MESSAGES.emptyIntent);
  const got = recordWithRefs_(ctx, table, id);
  const answer = callAi_(
    ctx,
    buildDraftRequest(table, got.row, got.refs, { today: toDateKey(new Date()), model: ctx.settings.model, dateFormat: ctx.settings.dateFormat, intent: words.slice(0, 200), staffName: staffNameFor(ctx.settings, ctx.email) }),
  );
  // 打ち切られた下書きは途中で切れた文なので、本文の欄には入れない
  if (answer.stopReason === "max_tokens") throw new Error(DRAFT_TOO_LONG);
  const text = textOf(answer.text);
  if (text === "") throw new Error(DRAFT_EMPTY);
  return { text: text };
}
