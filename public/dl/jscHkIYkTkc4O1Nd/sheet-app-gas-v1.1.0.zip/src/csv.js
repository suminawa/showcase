/**
 * CSV(UTF-8 BOM 付き、CRLF)。Excel でそのまま開ける。
 */
import { headerFor } from "./definition.js";

export function csvCell(value) {
  const text = value === null || value === undefined ? "" : String(value);
  if (/[",\r\n]/.test(text)) return '"' + text.replace(/"/g, '""') + '"';
  return text;
}

/** Excel が数式として解釈する先頭文字を無力化する（シートに書くときの safeCell と同じ考え。数値はそのまま） */
function guardCsvCell_(value) {
  if (typeof value !== "string") return value;
  return /^[=+\-@\t\r]/.test(value) ? "'" + value : value;
}

function cellValue_(column, value) {
  if (value === null || value === undefined) return "";
  if (column !== null && column.type === "チェック") return value === true ? "TRUE" : "FALSE";
  if (Array.isArray(value)) return guardCsvCell_(value.join(", "));
  return guardCsvCell_(value);
}

/** rows は API の形。列は ID・定義の列・システム列の順 */
export function toCsv(table, rows) {
  const header = headerFor(table);
  const columns = {};
  for (let i = 0; i < table.columns.length; i += 1) columns[table.columns[i].name] = table.columns[i];
  const lines = [header.map(csvCell).join(",")];
  for (let r = 0; r < rows.length; r += 1) {
    const cells = [];
    for (let c = 0; c < header.length; c += 1) {
      const name = header[c];
      const column = Object.prototype.hasOwnProperty.call(columns, name) ? columns[name] : null;
      cells.push(csvCell(cellValue_(column, rows[r][name])));
    }
    lines.push(cells.join(","));
  }
  return "﻿" + lines.join("\r\n") + "\r\n";
}
