/**
 * 記録の ID（その日の連番）。連番は前回の ID だけを覚えておけば足りる（日が変われば 001 に戻る）。
 */
import { compactDate } from "./dates.js";

/** ("2026-09-16", 3) → "20260916-003"。1000 件目からは桁が増える */
export function formatId(dateKey, sequence) {
  const number = Math.max(1, Math.floor(Number(sequence) || 1));
  let text = String(number);
  while (text.length < 3) text = "0" + text;
  return compactDate(dateKey) + "-" + text;
}

/** "20260916-003" → { dateKey: "2026-09-16", sequence: 3 }。読めなければ null */
export function parseId(id) {
  const text = String(id === null || id === undefined ? "" : id).trim();
  const matched = text.match(/^(\d{4})(\d{2})(\d{2})-(\d+)$/);
  if (!matched) return null;
  return { dateKey: matched[1] + "-" + matched[2] + "-" + matched[3], sequence: Number(matched[4]) };
}

export function isId(text) {
  return parseId(text) !== null;
}

/** 2 つの ID のうち後ろの方（日付キー → 連番の順で比べる）。読めない方は無視し、どちらも読めなければ "" */
export function laterId(a, b) {
  const first = parseId(a);
  const second = parseId(b);
  if (first === null) return second === null ? "" : String(b);
  if (second === null) return String(a);
  if (first.dateKey !== second.dateKey) return first.dateKey > second.dateKey ? String(a) : String(b);
  return first.sequence >= second.sequence ? String(a) : String(b);
}

/** 前回の ID と今日の日付キーから、次の ID を作る */
export function nextId(lastId, dateKey) {
  const last = parseId(lastId);
  if (last === null || last.dateKey !== dateKey) return formatId(dateKey, 1);
  return formatId(dateKey, last.sequence + 1);
}
