/**
 * _LINE友だち と _LINE送信履歴 の読み書き。受信は gas_main.js -> gas_relay.js の署名・時刻・再使用検証後に限る。
 * LINE の原文署名は Cloudflare 中継で検証し、GAS は中継の署名を検証する。プロフィール取得は署名検証の代わりではない。
 * follow / message / unfollow に応じて _LINE友だち を更新する。メッセージ本文は保存しない。
 * 表示名が取れなかった新規 ID は空のまま置き、画面の候補には出さない（line.js の friendsForScreen）。
 * 受信後にもプロフィールの取得結果を確認する:
 * unfollow はプロフィールがまだ取れるなら無視し、すでにある行の follow は表示名が新しく取れたときだけ「友だち」に戻す。
 * プロフィールの取得失敗とブロックはこの処理では区別しない。LINE 自身のイベント再送の完全な重複排除も行わない。
 */
import { BLOCKED_STATE, FRIEND_STATE, FRIENDS_HEADER, FRIENDS_SHEET, HISTORY_LIMIT, SEND_LOG_HEADER, SEND_LOG_SHEET, countMonthSends, parseWebhook } from "./line.js";
import { formatStamp } from "./dates.js";
import { fromSystemValue, safeCell } from "./format.js";
import { textOf } from "./text.js";
import { withLock_ } from "./gas_store.js";
import { book_, readSettings_ } from "./gas_sheets.js";
import { lineProfile_ } from "./gas_notify.js";

/** 名前のシート。無ければ作り、空なら見出しを書く */
function lineSheet_(name, header) {
  const book = book_();
  let sheet = book.getSheetByName(name);
  if (!sheet) sheet = book.insertSheet(name);
  if (sheet.getLastRow() === 0) sheet.getRange(1, 1, 1, header.length).setValues([header]);
  return sheet;
}

/** _LINE友だち と _LINE送信履歴 を見出しつきで作る（初期化から呼ぶ。あれば何もしない） */
export function ensureLineSheets_() {
  lineSheet_(FRIENDS_SHEET, FRIENDS_HEADER);
  lineSheet_(SEND_LOG_SHEET, SEND_LOG_HEADER);
}

/** 1 行の値を { 見出し: 値 } に（同じ見出しが 2 つあれば左のもの） */
function cellsOf_(header, values) {
  const cells = {};
  for (let c = 0; c < header.length; c += 1) {
    if (header[c] !== "" && cells[header[c]] === undefined) cells[header[c]] = values[c];
  }
  return cells;
}

/** 見出しの名前で読んだ行 [{ rowNumber, cells: { 見出し: 値 } }]。シートが無ければ []（読むだけでは作らない） */
function readRows_(name) {
  const sheet = book_().getSheetByName(name);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const values = sheet.getDataRange().getValues();
  const header = values[0].map(textOf);
  const rows = [];
  for (let r = 1; r < values.length; r += 1) rows.push({ rowNumber: r + 1, cells: cellsOf_(header, values[r]) });
  return rows;
}

/** _LINE送信履歴 を一度に読む行数 */
const SEND_LOG_CHUNK = 200;

/**
 * _LINE送信履歴 を下（新しい方。追記は下に足す）から SEND_LOG_CHUNK 行ずつ読み、visit(下から並べた行) が true を返したら止める。
 * 履歴は使うほど増えるので、画面を開くたびにシート全体を読まない（1.1.4）
 */
function scanSendLogFromBottom_(visit) {
  const sheet = book_().getSheetByName(SEND_LOG_SHEET);
  if (!sheet || sheet.getLastRow() < 2) return;
  const width = sheet.getLastColumn();
  const header = sheet.getRange(1, 1, 1, width).getValues()[0].map(textOf);
  for (let end = sheet.getLastRow(); end >= 2; end -= SEND_LOG_CHUNK) {
    const start = Math.max(2, end - SEND_LOG_CHUNK + 1);
    const values = sheet.getRange(start, 1, end - start + 1, width).getValues();
    const rows = [];
    for (let r = values.length - 1; r >= 0; r -= 1) rows.push({ rowNumber: start + r, cells: cellsOf_(header, values[r]) });
    if (visit(rows)) return;
  }
}

/** セルを文字に（日時のセルは yyyy-MM-dd HH:mm に） */
function cellText_(row, name) {
  return row.cells[name] === undefined ? "" : fromSystemValue(row.cells[name]).trim();
}

function headerOfSheet_(sheet) {
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(textOf);
}

/** 見出しの並びで 1 行を作る（文字は ' 付き。知らない見出しは空） */
function rowFor_(sheet, cells) {
  return headerOfSheet_(sheet).map((name) => (Object.prototype.hasOwnProperty.call(cells, name) ? safeCell(cells[name]) : ""));
}

function setCell_(sheet, rowNumber, name, value) {
  const at = headerOfSheet_(sheet).indexOf(name);
  if (at >= 0) sheet.getRange(rowNumber, at + 1, 1, 1).setValues([[safeCell(value)]]);
}

export function readFriends_() {
  return readRows_(FRIENDS_SHEET).map((row) => ({
    userId: cellText_(row, "ユーザー ID"),
    name: cellText_(row, "表示名"),
    addedAt: cellText_(row, "追加日時"),
    state: cellText_(row, "状態"),
    rowNumber: row.rowNumber,
  }));
}

/** 1 回の webhook で扱う出来事の上限（LINE は通常数件ずつ送る。偽の大量の出来事で実行時間を使い切らない） */
export const WEBHOOK_EVENT_LIMIT = 100;

function findFriendRow_(userId) {
  const friends = readFriends_();
  for (let i = 0; i < friends.length; i += 1) if (friends[i].userId === userId) return friends[i];
  return null;
}

/**
 * follow / unfollow を 1 つ書く。書いたら true。name は LINE のプロフィールで取れた表示名（取れなければ ""）。
 * 知らない ID の unfollow は何もしない（シートも作らない）。すでにある行の follow は、表示名が取れなければ何もしない
 */
export function saveFriend_(event, name, stamp) {
  const found = findFriendRow_(event.userId);
  if (found === null && event.type !== "follow") return false;
  if (found !== null && event.type === "follow" && name === "") return false;
  const sheet = lineSheet_(FRIENDS_SHEET, FRIENDS_HEADER);
  if (found === null) {
    sheet.appendRow(rowFor_(sheet, { "ユーザー ID": event.userId, 表示名: name, 追加日時: stamp, 状態: FRIEND_STATE }));
    return true;
  }
  setCell_(sheet, found.rowNumber, "状態", event.type === "follow" ? FRIEND_STATE : BLOCKED_STATE);
  if (event.type === "follow") setCell_(sheet, found.rowNumber, "表示名", name);
  return true;
}

/** webhook の本文を読んで _LINE友だち に書く。返り値: 書いた出来事の数。本文が壊れていれば実行ログに残して 0 */
export function receiveLineWebhook_(body) {
  const parsed = parseWebhook(body);
  if (parsed.error !== "") {
    Logger.log("業務アプリ: " + parsed.error);
    return 0;
  }
  if (parsed.events.length === 0) return 0;
  let events = parsed.events;
  if (events.length > WEBHOOK_EVENT_LIMIT) {
    Logger.log("業務アプリ: LINE の webhook の出来事が " + events.length + " 件ありました。先頭の " + WEBHOOK_EVENT_LIMIT + " 件だけ扱い、残りは無視しました");
    events = events.slice(0, WEBHOOK_EVENT_LIMIT);
  }
  const token = readSettings_().settings.lineToken;
  let saved = 0;
  for (let i = 0; i < events.length; i += 1) {
    const event = events[i];
    // 知らない ID の unfollow は、LINE に問い合わせずに捨てる
    if (event.type === "unfollow" && findFriendRow_(event.userId) === null) continue;
    // 表示名は LINE が本物の友だちにしか返さない。取れなければ空（未確認）のまま置き、画面の候補には出さない
    const name = lineProfile_(token, event.userId);
    if (event.type === "unfollow" && name !== "") {
      // ユーザー ID は個人に結びつくので実行ログには出さない。_LINE友だち と照らせるよう末尾 4 文字だけ添える（1.1.4）
      Logger.log("業務アプリ: ブロックの知らせを無視しました（LINE のプロフィールがまだ取れる、友だちのままの ID です。末尾 " + String(event.userId).slice(-4) + "）");
      continue;
    }
    const stamp = formatStamp(new Date());
    if (withLock_(() => saveFriend_(event, name, stamp))) saved += 1;
  }
  return saved;
}

/** _LINE送信履歴 に 1 行。entry = { at, table, id, to, sender, text, result } */
export function appendSendLog_(entry) {
  const sheet = lineSheet_(SEND_LOG_SHEET, SEND_LOG_HEADER);
  sheet.appendRow(rowFor_(sheet, { 日時: entry.at, テーブル: entry.table, ID: entry.id, "送り先ユーザー ID": entry.to, 送信者: entry.sender, 本文: entry.text, 結果: entry.result }));
}

/** 1 件の記録の送信履歴。新しい順（下の行ほど新しい）で 20 件まで。そろったら上の行は読まない */
export function readSendLog_(tableName, id) {
  const out = [];
  scanSendLogFromBottom_((rows) => {
    for (let i = 0; i < rows.length && out.length < HISTORY_LIMIT; i += 1) {
      const row = rows[i];
      if (cellText_(row, "テーブル") !== textOf(tableName) || cellText_(row, "ID") !== textOf(id)) continue;
      const text = row.cells["本文"];
      out.push({ at: cellText_(row, "日時"), sender: cellText_(row, "送信者"), text: text === undefined || text === null ? "" : String(text), result: cellText_(row, "結果") });
    }
    return out.length >= HISTORY_LIMIT;
  });
  return out;
}

/**
 * monthKey（"2026-09"）に送った数。_LINE送信履歴 を下から数え、日時のある行がすべて前の月の塊まで来たら止める
 * （下に追記していくので、それより上は前の月。数秒の前後で月をまたいだ行も、塊ごとに見るので落とさない）
 */
export function monthSendCount_(monthKey) {
  const month = textOf(monthKey);
  let count = 0;
  scanSendLogFromBottom_((rows) => {
    const entries = rows.map((row) => ({ at: cellText_(row, "日時"), result: cellText_(row, "結果") }));
    count += countMonthSends(entries, month);
    const dated = entries.filter((entry) => entry.at !== "");
    return dated.length > 0 && dated.every((entry) => entry.at.slice(0, 7) < month);
  });
  return count;
}
