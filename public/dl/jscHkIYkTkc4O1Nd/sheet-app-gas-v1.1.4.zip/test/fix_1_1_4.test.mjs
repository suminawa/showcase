import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { runInContext } from "node:vm";
import { loadBundle, plain } from "./fakes.mjs";
import { memoryApi } from "../src/ui/api-memory.js";
import { mountSheetApp } from "../src/ui/main.js";
import { parseDefinition } from "../src/definition.js";
import { initialState, reduce } from "../src/ui/state.js";
import { renderApp } from "../src/ui/render.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const VERSION = JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version;
const HEADER = ["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"];
const DEFINITION = [HEADER, ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""]];
const SEND_HEADER = ["日時", "テーブル", "ID", "送り先ユーザー ID", "送信者", "本文", "結果"];
const A = "U" + "a".repeat(28) + "1234";

test("1.1.4 削除: 読んだあとにほかの方が更新した記録は消さず、読み直しを案内する（_ごみ箱 にも書かない）", () => {
  const run = loadBundle({ sheets: { 定義: DEFINITION } });
  const { id } = run.entry.api_create("顧客", { 会社名: "みなと工務店" });
  const seen = run.entry.api_get("顧客", id).row.更新日時;
  run.entry.api_update("顧客", id, { 会社名: "みなと工務店（新）" }, seen);
  assert.throws(() => run.entry.api_delete("顧客", id, seen), /ほかの方が先に更新しました。削除はしていません/);
  // 3 つ目の引数を送らない古い画面からの削除も止める
  assert.throws(() => run.entry.api_delete("顧客", id), /先に更新しました/);
  assert.equal(run.entry.api_get("顧客", id).row.会社名, "みなと工務店（新）");
  assert.equal(run.sheets["_ごみ箱"], undefined, "止めた削除は _ごみ箱 に写さない");
  // 読み直した更新日時なら消せる
  const fresh = run.entry.api_get("顧客", id).row.更新日時;
  assert.deepEqual(run.entry.api_delete("顧客", id, fresh), { ok: true });
  assert.equal(run.sheets["_ごみ箱"].rows.length, 2);
});

test("1.1.4 削除: 見本の画面も同じく、古い更新日時の削除を止める", async () => {
  const api = memoryApi("顧客管理");
  const created = await api.create("顧客", { 会社名: "てすと商会" });
  const seen = (await api.get("顧客", created.id)).row.更新日時;
  await api.update("顧客", created.id, { 会社名: "てすと商会（新）" }, seen);
  await assert.rejects(api.remove("顧客", created.id, seen), /削除はしていません/);
  const fresh = (await api.get("顧客", created.id)).row.更新日時;
  assert.deepEqual(await api.remove("顧客", created.id, fresh), { ok: true });
});

test("1.1.4 削除: 画面は詳細を開いたときの更新日時を添えて削除を呼ぶ", async () => {
  const { tables } = parseDefinition(DEFINITION);
  const ROW = { ID: "20260916-001", 会社名: "みなと工務店", 作成日時: "2026-09-16 10:00:00", 更新日時: "2026-09-16 10:00:00.123", 更新者: "" };
  const calls = [];
  const listeners = {};
  const fakeRoot = { innerHTML: "", addEventListener: (type, fn) => (listeners[type] = fn), contains: () => true, querySelector: () => null };
  const saved = { document: globalThis.document, window: globalThis.window };
  globalThis.document = { activeElement: null };
  globalThis.window = { confirm: () => true };
  try {
    const app = mountSheetApp(fakeRoot, {
      bootstrap: () => Promise.resolve({ appName: "台帳", tables: tables, errors: [], user: { email: "taro@example.com", canEdit: true }, ai: false, pageSize: 50, dateFormat: "yyyy-MM-dd", today: "2026-09-16" }),
      list: () => Promise.resolve({ rows: [], total: 0, refs: {}, page: 1 }),
      remove: (...args) => {
        calls.push(args);
        return Promise.resolve({ ok: true });
      },
      readHash: () => Promise.resolve(""),
      writeHash: () => {},
    });
    await new Promise((resolve) => setTimeout(resolve, 0));
    app.dispatch({ type: "open-detail", row: ROW, refs: {}, history: [] });
    const el = { dataset: { action: "delete" } };
    listeners.click({ target: { closest: () => el } });
    await new Promise((resolve) => setTimeout(resolve, 0));
    assert.deepEqual(calls, [["顧客", "20260916-001", "2026-09-16 10:00:00.123"]]);
  } finally {
    globalThis.document = saved.document;
    globalThis.window = saved.window;
  }
});

test("1.1.4 LINE: ブロックの知らせを無視したログに、ユーザー ID を出さない（末尾 4 文字だけ）", async () => {
  const { loadRelayBundle, signedRelayRequest } = await import("./relay-test-helpers.mjs");
  const FRIENDS = [["ユーザー ID", "表示名", "追加日時", "状態"], [A, "はるか", "2026-09-10 09:00:00", "友だち"]];
  const run = loadRelayBundle({ sheets: { 設定: [["項目", "値"]], "_LINE友だち": FRIENDS }, lineProfiles: { [A]: "はるか" }, props: { SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN: "line-token" } });
  const body = JSON.stringify({ destination: "U" + "0".repeat(32), events: [{ type: "unfollow", timestamp: 2, source: { type: "user", userId: A } }] });
  run.entry.doPost(signedRelayRequest(body));
  const logs = run.trace.logs.join("\n");
  assert.ok(logs.includes("ブロックの知らせを無視しました"), logs);
  assert.equal(logs.includes(A), false, "ユーザー ID をそのまま出さない");
  assert.equal(logs.includes("a".repeat(8)), false);
  assert.ok(logs.includes("1234"), "照合用に末尾 4 文字だけ出す");
});

/** _LINE送信履歴 の読み方を見張る: シート全体（getDataRange）は読まない。読んだ行数を数える */
function watchSendLog(run) {
  const sheet = run.sheets["_LINE送信履歴"];
  const watch = { rows: 0 };
  const getRange = sheet.getRange;
  sheet.getDataRange = () => {
    throw new Error("_LINE送信履歴 を全部読んだ");
  };
  sheet.getRange = (r, c, nr, nc) => {
    watch.rows += nr || 1;
    return getRange(r, c, nr, nc);
  };
  return watch;
}

test("1.1.4 _LINE送信履歴: 月の送信数と記録ごとの履歴は下（新しい方）から読み、全体を読まない", () => {
  const rows = [SEND_HEADER];
  for (let i = 0; i < 1500; i += 1) rows.push(["2026-08-01 09:00:00", "顧客", "20260801-001", A, "taro@example.com", "先月 " + i, "送信済み"]);
  for (let i = 0; i < 5; i += 1) rows.push(["2026-09-16 10:0" + i + ":00", "顧客", "20260916-001", A, "taro@example.com", "今月 " + i, "送信済み"]);
  rows.push(["2026-09-16 10:30:00", "顧客", "20260916-001", A, "taro@example.com", "失敗", "送れませんでした"]);
  const run = loadBundle({ sheets: { _LINE送信履歴: rows } });
  const watch = watchSendLog(run);
  assert.equal(runInContext("monthSendCount_('2026-09')", run.context), 5);
  assert.ok(watch.rows < 600, "前の月の行まで来たら止める（読んだ行: " + watch.rows + "）");
  watch.rows = 0;
  const history = plain(runInContext("readSendLog_('顧客', '20260916-001')", run.context));
  assert.deepEqual(history.map((h) => h.text), ["失敗", "今月 4", "今月 3", "今月 2", "今月 1", "今月 0"]);
  // 先月の記録は 1,500 件あるが、新しい 20 件がそろったら止める
  watch.rows = 0;
  const old = plain(runInContext("readSendLog_('顧客', '20260801-001')", run.context));
  assert.equal(old.length, 20);
  assert.equal(old[0].text, "先月 1499");
  assert.ok(watch.rows < 600, "20 件そろったら止める（読んだ行: " + watch.rows + "）");
  // 上の方にしか無い記録も、最後まで読めば見つかる
  assert.equal(runInContext("monthSendCount_('2026-08')", run.context), 1500);
});

test("1.1.4 設定を確かめる: 同じ ID が 2 行以上あれば、どのテーブルの何行目かを出す（画面の操作は上の行だけに届くため）", () => {
  const run = loadBundle({
    sheets: {
      定義: DEFINITION,
      顧客: [["ID", "会社名"], ["20260916-001", "上の行"], ["20260916-002", "別の行"], ["20260916-001", "下の行"]],
    },
  });
  run.entry.checkSettings();
  const text = run.trace.alerts[0];
  assert.ok(text.startsWith("直すところがあります。"), text);
  assert.ok(text.includes("「顧客」の ID「20260916-001」が 2 行にあります（2 行目・4 行目）"), text);
  const clean = loadBundle({ sheets: { 定義: DEFINITION, 顧客: [["ID", "会社名"], ["20260916-001", "上の行"]] } });
  clean.entry.checkSettings();
  assert.ok(clean.trace.alerts[0].includes("問題ありません"));
});

test("1.1.4 版: Code.gs の 1 行目・「設定を確かめる」・画面に package.json と同じ版が出る", () => {
  const code = readFileSync(join(root, "dist", "Code.gs"), "utf8");
  assert.ok(code.split("\n")[0].includes(" v" + VERSION + " "), code.split("\n")[0]);
  assert.equal(readFileSync(join(root, "src", "gas_web.js"), "utf8").match(/^export const KIT_VERSION = "([^"]+)";$/m)[1], VERSION);
  const ok = loadBundle({ sheets: { 定義: DEFINITION } });
  ok.entry.checkSettings();
  assert.ok(ok.trace.alerts[0].includes("キットの版 " + VERSION), ok.trace.alerts[0]);
  const broken = loadBundle({ sheets: { 定義: [HEADER, ["顧客", "x", "整数", "", "", "", "", "", ""]] } });
  broken.entry.checkSettings();
  assert.ok(broken.trace.alerts[0].includes("キットの版 " + VERSION), broken.trace.alerts[0]);
  assert.equal(ok.entry.api_bootstrap().version, VERSION);
  const { tables } = parseDefinition(DEFINITION);
  const state = reduce(initialState(), { type: "bootstrap", data: { appName: "台帳", tables: tables, errors: [], user: { email: "a@example.com", canEdit: true }, version: VERSION } });
  assert.ok(renderApp(state).includes("v" + VERSION));
  const noVersion = reduce(initialState(), { type: "bootstrap", data: { appName: "台帳", tables: tables, errors: [], user: { email: "a@example.com", canEdit: true } } });
  assert.equal(/sa-foot/.test(renderApp(noVersion)), false, "版が無ければ（見本）出さない");
});

test("1.1.4 README: 確認されていないアプリの警告画面、App の名前違いの症状、列名を変えたときの扱い、12 章の題", () => {
  const readme = readFileSync(join(root, "README.ja.md"), "utf8");
  assert.ok(readme.includes("このアプリは Google で確認されていません"));
  assert.ok(readme.includes("詳細"), "警告画面の進み方");
  assert.ok(readme.includes("No HTML file named App was found"), "App の名前違いの症状");
  assert.equal(readme.includes("列を足す・変えるも、シートを書き直すだけです"), false, "列名の変更は書き直すだけでは済まない");
  assert.ok(readme.includes("列の名前を変えるとき"));
  assert.ok(readme.includes("## 12. 旧版からの上げ方"));
  assert.ok(readme.includes("release/sheet-app-gas-v" + VERSION + ".zip"));
  assert.equal(readFileSync(join(root, "CHANGELOG.md"), "utf8").match(/^## (\d+\.\d+\.\d+)/m)[1], VERSION);
});
