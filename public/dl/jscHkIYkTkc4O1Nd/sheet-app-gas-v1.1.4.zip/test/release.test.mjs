import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("版の表記がそろっている（package.json・CHANGELOG の先頭・README の zip 名）", () => {
  const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
  assert.equal(pkg.version, "1.1.4");
  const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");
  assert.equal(changelog.match(/^## (\d+\.\d+\.\d+)/m)[1], pkg.version);
  const readme = readFileSync(join(root, "README.ja.md"), "utf8");
  const zipNames = [...readme.matchAll(/release\/sheet-app-gas-v([\d.]+)\.zip/g)].map(match => match[1]);
  assert.ok(zipNames.length > 0);
  assert.ok(zipNames.every(version => version === pkg.version), "README の ZIP 名も配布版と完全一致する");
});
