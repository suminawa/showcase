import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle } from "./fakes.mjs";
import { nextUpdateStamp } from "../src/dates.js";

const definition = [["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"], ["顧客", "会社名", "文字", "TRUE", "", "", "", "", ""]];
const bound = { SHEET_APP_SPREADSHEET_ID: "FAKE-SHEET-ID", SHEET_APP_BOUND_SCRIPT_ID: "FAKE-SCRIPT-ID" };
const seeded = (opts = {}) => loadBundle({ sheets: { 定義: definition }, ...opts });

test("Web実行のnull/例外でも初期化済み台帳IDで読み書きできる", () => {
  for (const webContext of ["null", "throw"]) {
    const run = seeded({ webContext, props: bound });
    assert.equal(run.entry.doGet().file, "App");
    assert.equal(run.entry.api_bootstrap().tables[0].name, "顧客");
    const { id } = run.entry.api_create("顧客", { 会社名: "動作確認" });
    const row = run.entry.api_get("顧客", id).row;
    const updated = run.entry.api_update("顧客", id, { 会社名: "変更後" }, row.更新日時);
    assert.match(updated.updatedAt, /\.001$/);
    assert.match(run.entry.api_export("顧客", {}), /変更後/);
  }
});

test("初期化が台帳とスクリプトを結び付け、コピー後の古い参照は拒否する", () => {
  const run = seeded();
  run.entry.initializeSheets();
  assert.equal(run.props.SHEET_APP_SPREADSHEET_ID, bound.SHEET_APP_SPREADSHEET_ID);
  assert.equal(run.props.SHEET_APP_BOUND_SCRIPT_ID, bound.SHEET_APP_BOUND_SCRIPT_ID);
  for (const props of [{}, { ...bound, SHEET_APP_BOUND_SCRIPT_ID: "ORIGINAL-SCRIPT" }]) {
    const copy = seeded({ webContext: "null", props });
    assert.throws(() => copy.entry.api_bootstrap(), /初期化し直して/);
    assert.equal(Object.keys(copy.sheets).length, 1);
  }
  const denied = seeded({ webContext: "null", noSpreadsheet: true, props: bound });
  assert.throws(() => denied.entry.api_bootstrap(), /permission/);
});

test("閲覧者の一覧/詳細/CSVを維持し、登録/更新/削除は保存時の権限で拒否する", () => {
  const initial = seeded();
  initial.entry.api_create("顧客", { 会社名: "閲覧用" });
  const run = seeded({ webContext: "null", props: bound, editors: [], denyWrite: true, sheets: { 定義: definition, 顧客: initial.sheets.顧客.rows } });
  assert.equal(run.entry.api_bootstrap().user.canEdit, false);
  const list = run.entry.api_list("顧客", { q: "閲覧" });
  assert.equal(list.total, 1);
  const row = run.entry.api_get("顧客", list.rows[0].ID).row;
  assert.match(run.entry.api_export("顧客", {}), /閲覧用/);
  assert.throws(() => run.entry.api_create("顧客", { 会社名: "新規" }), /編集権限/);
  assert.throws(() => run.entry.api_update("顧客", row.ID, { 会社名: "変更" }, row.更新日時), /編集権限/);
  assert.throws(() => run.entry.api_delete("顧客", row.ID, row.更新日時), /編集権限/);
  assert.equal(run.entry.api_get("顧客", row.ID).row.会社名, "閲覧用");
});

test("同じ秒・同じミリ秒で2回更新しても古い画面は後勝ちにならない", () => {
  const run = seeded();
  const { id } = run.entry.api_create("顧客", { 会社名: "最初" });
  const seen = run.entry.api_get("顧客", id).row.更新日時;
  const a = run.entry.api_update("顧客", id, { 会社名: "先の更新" }, seen);
  assert.notEqual(a.updatedAt, seen);
  assert.throws(() => run.entry.api_update("顧客", id, { 会社名: "古い画面" }, seen), /先に更新/);
  const b = run.entry.api_update("顧客", id, { 会社名: "再読込後" }, a.updatedAt);
  assert.notEqual(b.updatedAt, a.updatedAt);
  assert.throws(() => run.entry.api_update("顧客", id, { 会社名: "もう一つの古い画面" }, a.updatedAt), /先に更新/);
  assert.equal(run.entry.api_get("顧客", id).row.更新日時, b.updatedAt);
});

test("JSTの旧秒表記・時計後退・日付境界を扱い、日時は単調に増える", () => {
  assert.equal(nextUpdateStamp(new Date("2026-09-16T01:40:00Z"), "2026-09-16 10:40:00"), "2026-09-16 10:40:00.001");
  assert.equal(nextUpdateStamp(new Date("2026-09-15T00:00:00Z"), "2026-09-16 23:59:59.999"), "2026-09-17 00:00:00.000");
  assert.equal(nextUpdateStamp(new Date("2026-10-09T00:00:00Z"), ""), "2026-10-09 09:00:00.000");
});
