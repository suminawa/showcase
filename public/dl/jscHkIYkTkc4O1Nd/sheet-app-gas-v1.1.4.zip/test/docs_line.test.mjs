import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { LINE_SETTING_KEYS } from "../src/settings.js";
import { DEFAULT_NOTIFY_TEMPLATE } from "../src/notify.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const readme = readFileSync(join(root, "README.ja.md"), "utf8");
const settingsCsv = readFileSync(join(root, "samples", "設定.csv"), "utf8");
const changelog = readFileSync(join(root, "CHANGELOG.md"), "utf8");

test("README に通知・LINE 送信・1.1.2 への移行が、9 章の後ろ・ライセンスの前に並ぶ", () => {
  let at = -1;
  for (const heading of ["## 9. 更新履歴", "## 10. 通知（任意）", "## 11. お客さまへの LINE 送信（任意）", "## 12. 旧版からの上げ方", "## ライセンス"]) {
    const found = readme.indexOf(heading);
    assert.ok(found > at, heading);
    at = found;
  }
});

test("設定の追加行が README の表と samples/設定.csv の両方にあり、型 LINE・既定の文面・webhook・シート名・限界が書いてある", () => {
  for (const key of LINE_SETTING_KEYS) {
    assert.ok(readme.includes("| " + key + " |"), "README: " + key);
    assert.ok(settingsCsv.includes("\r\n" + key + ","), "設定.csv: " + key);
  }
  assert.ok(readme.includes("型は次の 14 種類です"));
  assert.ok(readme.includes("`URL` `LINE` `参照:<テーブル名>`"));
  for (const line of DEFAULT_NOTIFY_TEMPLATE.split("\n")) assert.ok(readme.includes(line), line);
  for (const phrase of ["?hook=line", "_LINE友だち", "_LINE送信履歴", "_通知ログ", "次のユーザーとして実行「自分」", "アクセスできるユーザー「全員」", "署名", "未確認", "取り消せません", "通知のテストを送る", "60 字", "ほか n 列", "5,000 字", "LINE を送れる人", "AI で下書き", "画面の URL", "100 件まで", "送り直さないでください", "必ず画面用のデプロイの URL"]) {
    assert.ok(readme.includes(phrase), phrase);
  }
  assert.equal(/[¥￥]\s?\d/.test(readme), false, "価格は README に書かない");
});

test("1.1.0 の変更履歴には当時の無料更新と足した機能が残る", () => {
  const top = changelog.indexOf("## 1.1.0");
  assert.ok(top >= 0 && top < changelog.indexOf("## 1.0.0"));
  const section = changelog.slice(top, changelog.indexOf("## 1.0.0"));
  for (const phrase of ["無料で更新", "_通知ログ", "LINE で送る", "_LINE送信履歴", "`LINE`", "#<テーブル>/<ID>"]) assert.ok(section.includes(phrase), phrase);
});

test("接続情報の移行先と旧セル・履歴・共同利用者の制約を説明する", () => {
  for (const phrase of ["SHEET_APP_SLACK_WEBHOOK_URL", "SHEET_APP_DISCORD_WEBHOOK_URL", "SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN", "接続情報を設定シートから移す", "通常の通知・送信処理は旧セルの値を読みません", "共同利用者から秘密を隔離する保管庫ではありません", "過去の変更履歴・配布済みのコピー"]) {
    assert.ok(readme.includes(phrase), phrase);
  }
  assert.equal(readme.includes("トークンを見せたくない方には、シートを閲覧者として共有"), false);
});

test("中継の両側の鍵・固定先・導入確認・制限を説明し、未署名の直結へ案内しない", () => {
  for (const phrase of ["relay/wrangler.jsonc", "GAS_WEB_APP_URL", "LINE_CHANNEL_SECRET", "RELAY_HMAC_KEY", "SHEET_APP_RELAY_HMAC_KEY", "/line-webhook", "LINE から GAS への直接送信は受け付けません", "64 KiB", "512 件", "前後 5 分", "nonce", "本番接続は未確認"]) {
    assert.ok(readme.includes(phrase), phrase);
  }
  assert.equal(readme.includes("署名まで確かめたい場合は"), false);
  assert.equal(readme.includes("今の友だちの状態は変わりません"), false, "旧版の過大な保証を残さない");
});
