#!/usr/bin/env node
// Node 標準だけで再現可能な ZIP を作る。日本語名は local/central 両ヘッダーに UTF-8 を明示。
import { deflateRawSync } from "node:zlib";
import { randomUUID } from "node:crypto";
import { existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const RELEASE_PATHS = ["dist", "samples", "demo", "src", "test", "scripts", "relay", "README.ja.md", "LICENSE.md", "CHANGELOG.md", "package.json"];
const REQUIRED_FILES = ["dist/Code.gs", "dist/App.html", "dist/appsscript.json", "demo/app.js", "demo/app.css", "demo/index.html", "relay/worker.mjs", "relay/wrangler.jsonc", "README.ja.md", "LICENSE.md", "CHANGELOG.md"];
const ZIP_UTF8 = 0x0800;
const UINT32_MAX = 0xffffffff;
const compareNames = (a, b) => a < b ? -1 : a > b ? 1 : 0;

const CRC_TABLE = Array.from({ length: 256 }, (_, n) => {
  for (let i = 0; i < 8; i++) n = (n >>> 1) ^ ((n & 1) ? 0xedb88320 : 0);
  return n >>> 0;
});

export function crc32(data) {
  let crc = UINT32_MAX;
  for (const byte of data) crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ byte) & 255];
  return (crc ^ UINT32_MAX) >>> 0;
}

function checkName(name) {
  if (typeof name !== "string" || !name || name.includes("\\") || name.includes("\0") || name.split("/").some(part => !part || part === "." || part === "..") || /^[A-Za-z]:/.test(name)) {
    throw new Error(`ZIP 内の相対ファイル名が不正です: ${name}`);
  }
  const encoded = Buffer.from(name, "utf8");
  if (encoded.length > 65535) throw new Error("ZIP 内のファイル名が長すぎます");
  return encoded;
}

// classic ZIP の範囲を超えたら明示的に停止する。ZIP64 は小規模な配布物には不要。
function checkSize(size) {
  if (!Number.isSafeInteger(size) || size < 0 || size >= UINT32_MAX) throw new Error("ZIP64 が必要な大きさです。配布内容を確認してください");
}

export function createZip(entries) {
  if (entries.length >= 65535) throw new Error("ZIP64 が必要なファイル数です");
  const files = [...entries].sort((a, b) => compareNames(a.name, b.name));
  const seen = new Set();
  const localParts = [], centralParts = [];
  let offset = 0, centralSize = 0;
  for (const entry of files) {
    const name = checkName(entry.name);
    if (seen.has(entry.name)) throw new Error(`ZIP 内のファイル名が重複しています: ${entry.name}`);
    seen.add(entry.name);
    const data = Buffer.from(entry.data);
    const compressed = deflateRawSync(data, { level: 9 });
    checkSize(data.length); checkSize(compressed.length); checkSize(offset);
    const crc = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4); // ZIP 2.0 / deflate
    local.writeUInt16LE(ZIP_UTF8, 6);
    local.writeUInt16LE(8, 8);
    // 再ビルドで同一内容になるよう、DOS 日付を 1980-01-01 00:00 に固定する。
    local.writeUInt16LE(0x0021, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(ZIP_UTF8, 8);
    central.writeUInt16LE(8, 10);
    central.writeUInt16LE(0x0021, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE(offset, 42);
    localParts.push(local, name, compressed);
    centralParts.push(central, name);
    offset += local.length + name.length + compressed.length;
    centralSize += central.length + name.length;
  }
  checkSize(offset); checkSize(centralSize); checkSize(offset + centralSize);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...localParts, ...centralParts, end]);
}

function excluded(name) {
  return [".DS_Store", ".git", ".wrangler", "node_modules"].includes(name) || /^\.env(?:\.|$)/.test(name) || /^\.dev\.vars(?:\.|$)/.test(name);
}

export function collectEntries(root, paths = RELEASE_PATHS) {
  const entries = [];
  function visit(name) {
    checkName(name);
    if (name.split("/").some(excluded)) return;
    const path = join(root, name);
    const stat = lstatSync(path);
    if (stat.isSymbolicLink()) throw new Error(`配布物にシンボリックリンクは含められません: ${name}`);
    if (stat.isDirectory()) {
      for (const child of readdirSync(path).sort(compareNames)) visit(`${name}/${child}`);
    } else if (stat.isFile()) {
      entries.push({ name, data: readFileSync(path) });
    } else {
      throw new Error(`通常のファイルではありません: ${name}`);
    }
  }
  for (const name of paths) visit(name);
  return entries;
}

export function writeArchive(path, data, { overwrite = false } = {}) {
  mkdirSync(dirname(path), { recursive: true });
  if (existsSync(path)) {
    if (lstatSync(path).isSymbolicLink()) throw new Error("出力先 ZIP がシンボリックリンクです");
    if (readFileSync(path).equals(data)) return "unchanged";
    if (!overwrite) throw new Error(`${path} は別の内容で存在します。版を上げるか、置換する意図がある場合だけ --overwrite を指定してください`);
    const temporary = `${path}.${randomUUID()}.tmp`;
    try {
      writeFileSync(temporary, data, { flag: "wx" });
      renameSync(temporary, path);
    } finally {
      if (existsSync(temporary)) unlinkSync(temporary);
    }
    return "overwritten";
  }
  // 事前確認後に他の実行が作った ZIP も上書きしない。
  writeFileSync(path, data, { flag: "wx" });
  return "created";
}

export function release(root, options = {}) {
  const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(pkg.version)) throw new Error("package.json の version が不正です");
  for (const file of REQUIRED_FILES) {
    if (!existsSync(join(root, file))) throw new Error(`${file} がありません。配布内容を確認し、先に npm run build を実行してください`);
  }
  const entries = collectEntries(root);
  const out = join(root, "release", `sheet-app-gas-v${pkg.version}.zip`);
  const result = writeArchive(out, createZip(entries), options);
  return { out, result, count: entries.length };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const args = process.argv.slice(2);
    if (args.some(arg => arg !== "--overwrite") || args.length > 1) throw new Error("使い方: node scripts/release.mjs [--overwrite]");
    const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
    const { out, result, count } = release(root, { overwrite: args.includes("--overwrite") });
    console.log(`${out}: ${result} (${count} files, UTF-8)`);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
