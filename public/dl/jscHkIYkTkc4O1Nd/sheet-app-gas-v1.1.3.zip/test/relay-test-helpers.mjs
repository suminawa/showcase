import { createHmac, randomUUID } from "node:crypto";
import { loadBundle, FIXED_NOW } from "./fakes.mjs";

// Fixed, publicly committed test values only. Never use them in a deployment.
export const TEST_RELAY_KEY = "test-only-relay-key-never-use-in-production";
export const TEST_LINE_SECRET = "test-only-line-channel-secret";
export const TEST_GAS_URL = "https://script.google.com/macros/s/TEST_DEPLOYMENT/exec";

export function installCryptoFake(run) {
  Object.assign(run.sandbox.Utilities, {
    Charset: { UTF_8: "UTF-8" },
    base64Decode: (value) => Array.from(Buffer.from(value, "base64"), (byte) => byte > 127 ? byte - 256 : byte),
    base64Encode: (bytes) => Buffer.from(bytes).toString("base64"),
    computeHmacSha256Signature: (value, secret) => Array.from(createHmac("sha256", secret).update(value, "utf8").digest(), (byte) => byte > 127 ? byte - 256 : byte),
    newBlob: (bytes) => ({ getDataAsString: () => Buffer.from(bytes).toString("utf8") }),
  });
  return run;
}

export function loadRelayBundle(options = {}) {
  return installCryptoFake(loadBundle({ ...options, props: { SHEET_APP_RELAY_HMAC_KEY: TEST_RELAY_KEY, ...options.props } }));
}

export function signedEnvelope(body, overrides = {}, key = TEST_RELAY_KEY) {
  const envelope = { version: 1, issuedAt: Math.floor(FIXED_NOW / 1000), nonce: randomUUID(), bodyBase64: Buffer.from(body).toString("base64"), ...overrides };
  const canonical = "v1\n" + envelope.issuedAt + "\n" + envelope.nonce + "\n" + envelope.bodyBase64;
  envelope.signature = createHmac("sha256", key).update(canonical).digest("base64");
  return envelope;
}

export function envelopeRequest(envelope) {
  return { parameter: { hook: "line" }, postData: { contents: JSON.stringify(envelope) } };
}

export function signedRelayRequest(body, overrides, key) {
  return envelopeRequest(signedEnvelope(body, overrides, key));
}

export function lineRequest(body, overrides = {}) {
  return new Request("https://relay.example/line-webhook", {
    method: "POST", body,
    headers: { "x-line-signature": createHmac("sha256", TEST_LINE_SECRET).update(body).digest("base64"), ...overrides },
  });
}
