import { test } from "node:test";
import assert from "node:assert/strict";
import { runInContext } from "node:vm";
import { loadBundle, plain } from "./fakes.mjs";
const evaluate = (run, source) => plain(runInContext(source, run.context));

test("旧セルの接続情報は使わず、明示移行で保存確認後にセルを空にする", () => {
  const url = "https://hooks.slack.com/services/test-only";
  const run = loadBundle({ sheets: { 設定: [["項目", "値"], ["SlackWebhookURL", url], ["通知先", "slack"]] } });
  const before = evaluate(run, "readSettings_()");
  assert.equal(before.settings.slackWebhookUrl, "");
  assert.ok(before.notifyErrors.some((text) => text.includes("移す")));
  assert.equal(evaluate(run, 'migrateConnectionSecrets_(book_().getSheetByName("設定"))'), 1);
  assert.equal(run.props.SHEET_APP_SLACK_WEBHOOK_URL, url);
  assert.equal(run.sheets.設定.rows[1][1], "");
  assert.equal(evaluate(run, "readSettings_()").settings.slackWebhookUrl, url);
  assert.equal(evaluate(run, 'migrateConnectionSecrets_(book_().getSheetByName("設定"))'), 0);
});

test("異なる重複値や既存プロパティとの競合なら何も移さない", () => {
  for (const props of [{}, { SHEET_APP_SLACK_WEBHOOK_URL: "already-set" }]) {
    const rows = [["Slack Webhook URL", "first"], ["SlackWebhookURL", "second"]];
    const run = loadBundle({ sheets: { 設定: rows }, props });
    assert.throws(() => evaluate(run, 'migrateConnectionSecrets_(book_().getSheetByName("設定"))'), /異なる接続情報/);
    assert.deepEqual(run.sheets.設定.rows, rows);
    assert.equal(run.props.SHEET_APP_SLACK_WEBHOOK_URL, props.SHEET_APP_SLACK_WEBHOOK_URL);
  }
});

test("移行時に保存できなければ元セルを残す", () => {
  const run = loadBundle({ sheets: { 設定: [["LINE チャネルアクセストークン", "fake-token"]] } });
  run.sandbox.PropertiesService.getScriptProperties = () => ({ getProperty: () => null, setProperty: () => {} });
  assert.throws(() => evaluate(run, 'migrateConnectionSecrets_(book_().getSheetByName("設定"))'), /保存を確認できません/);
  assert.equal(run.sheets.設定.rows[0][1], "fake-token");
});


test("接続情報の移行はscript lockを取り、別の保存中なら元セルとプロパティを保つ", () => {
  const run = loadBundle({ lockBusy: true, sheets: { 設定: [["LINE チャネルアクセストークン", "fake-token"]] } });
  assert.throws(() => evaluate(run, 'migrateConnectionSecrets_(book_().getSheetByName("設定"))'), /ほかの方の保存/);
  assert.equal(run.sheets.設定.rows[0][1], "fake-token");
  assert.equal(run.props.SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN, undefined);
});


test("接続情報を返す内部関数はApps Scriptのprivate名で、画面応答に秘密を含めない", () => {
  const secrets = { SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN: "fake-line-secret", SHEET_APP_SLACK_WEBHOOK_URL: "https://hooks.slack.com/services/fake-secret", SHEET_APP_DISCORD_WEBHOOK_URL: "https://discord.com/api/webhooks/fake-secret", SHEET_APP_RELAY_HMAC_KEY: "fake-relay-key" };
  const run = loadBundle({ props: secrets, sheets: { 定義: [["テーブル", "列", "型", "必須", "選択肢", "一覧", "検索", "既定値", "説明"], ["顧客", "会社名", "文字", "", "", "", "", "", ""]] } });
  assert.equal(evaluate(run, "typeof contextOf"), "undefined");
  assert.equal(evaluate(run, "typeof contextOf_"), "function");
  const response = JSON.stringify(run.entry.api_bootstrap());
  for (const secret of Object.values(secrets)) assert.equal(response.includes(secret), false);
});


test("Web文脈からメニュー操作を呼んでも通知・見本挿入・設定移行は実行しない", () => {
  const names = ["initializeSheets", "loadSampleCustomers", "loadSampleProjects", "loadSampleInventory", "checkSettings", "migrateConnectionSecrets", "sendTestNotification", "showAppUrl", "showAiUsage"];
  for (const webContext of ["null", "throw"]) {
    const props = { SHEET_APP_SPREADSHEET_ID: "FAKE-SHEET-ID", SHEET_APP_BOUND_SCRIPT_ID: "FAKE-SCRIPT-ID", SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN: "fake-token" };
    const rows = [["通知先", "line"], ["LINE 送信先 ID", "U" + "a".repeat(32)], ["LINE を送れる人", "owner@example.com"]];
    const run = loadBundle({ webContext, props, email: "viewer@example.com", sheets: { 設定: rows } });
    for (const name of names) assert.throws(() => evaluate(run, name + "()"), /メニューから実行/);
    assert.deepEqual(run.trace.fetched, []);
    assert.deepEqual(run.sheets.設定.rows, rows);
    assert.deepEqual(Object.keys(run.sheets), ["設定"]);
    assert.deepEqual(run.props, props);
  }
});
