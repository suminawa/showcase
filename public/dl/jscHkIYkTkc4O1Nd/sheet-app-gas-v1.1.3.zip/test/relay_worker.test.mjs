import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { handleRequest, fixedGasUrl, createEnvelope, MAX_LINE_BODY_BYTES } from "../relay/worker.mjs";
import { lineRequest, TEST_LINE_SECRET, TEST_RELAY_KEY, TEST_GAS_URL, loadRelayBundle, envelopeRequest } from "./relay-test-helpers.mjs";
import { FIXED_NOW } from "./fakes.mjs";

const ENV = { LINE_CHANNEL_SECRET: TEST_LINE_SECRET, RELAY_HMAC_KEY: TEST_RELAY_KEY, GAS_WEB_APP_URL: TEST_GAS_URL };
const BODY = '{"events":[],"destination":"テスト"}';
const ok = () => new Response('{"ok":true}', { status: 200 });

test("Worker: raw UTF-8 bytes are signed without parsing/reformatting, envelope is accepted by GAS", async () => {
  const raw = new TextEncoder().encode(' { "events" : [], "destination":"日本語🌸" }\n');
  const envelope = await createEnvelope(raw, TEST_RELAY_KEY, FIXED_NOW);
  assert.equal(Buffer.from(envelope.bodyBase64, "base64").toString("utf8"), new TextDecoder().decode(raw));
  assert.equal(envelope.signature, createHmac("sha256", TEST_RELAY_KEY).update("v1\n" + envelope.issuedAt + "\n" + envelope.nonce + "\n" + envelope.bodyBase64).digest("base64"));
  const run = loadRelayBundle();
  assert.deepEqual(JSON.parse(run.entry.doPost(envelopeRequest(envelope)).text), { ok: true });
  assert.equal(run.trace.fetched.length, 0);
});

test("Worker: valid LINE signature -> fixed GAS URL, signed envelope, successful acknowledgement", async () => {
  const requests = [];
  const response = await handleRequest(lineRequest(BODY), ENV, async (url, options) => {
    requests.push({ url, options });
    return ok();
  });
  assert.equal(response.status, 200);
  assert.equal(await response.text(), "OK");
  assert.equal(requests.length, 1);
  assert.equal(requests[0].url, TEST_GAS_URL + "?hook=line");
  assert.equal(requests[0].options.redirect, "manual");
  const envelope = JSON.parse(requests[0].options.body);
  assert.equal(Buffer.from(envelope.bodyBase64, "base64").toString(), BODY);
  assert.ok(!requests[0].options.body.includes(TEST_LINE_SECRET));
  assert.ok(!requests[0].options.body.includes(TEST_RELAY_KEY));
  assert.equal(requests[0].options.headers["x-line-signature"], undefined);
});

test("Worker -> GAS bundle: authenticated LINE friend update works through the content redirect", async () => {
  const id = "U" + "a".repeat(32);
  const run = loadRelayBundle({ sheets: { 設定: [["項目", "値"]] }, props: { SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN: "test-token" }, lineProfiles: { [id]: "結合テスト" } });
  run.sandbox.Date = Date;
  let result;
  let requests = 0;
  const body = JSON.stringify({ events: [{ type: "follow", source: { type: "user", userId: id }, timestamp: Date.now() }] });
  const response = await handleRequest(lineRequest(body), ENV, async (_url, options) => {
    requests += 1;
    if (requests === 1) {
      result = run.entry.doPost(envelopeRequest(JSON.parse(options.body)));
      return new Response(null, { status: 302, headers: { location: "https://script.googleusercontent.com/macros/echo?temporary=test" } });
    }
    return new Response(result.text);
  });
  assert.equal(response.status, 200);
  assert.equal(requests, 2);
  assert.equal(run.trace.fetched.length, 1);
  assert.equal(run.sheets["_LINE友だち"].rows[1][1], "結合テスト");
});

test("Worker: no signature, malformed signature, modified bytes, wrong secret make zero network calls", async () => {
  let calls = 0;
  const fetchMock = async () => { calls += 1; return ok(); };
  for (const request of [
    lineRequest(BODY, { "x-line-signature": "" }),
    lineRequest(BODY, { "x-line-signature": "not-base64" }),
    lineRequest(BODY, { "x-line-signature": createHmac("sha256", "wrong").update(BODY).digest("base64") }),
    lineRequest(BODY + " ", { "x-line-signature": createHmac("sha256", TEST_LINE_SECRET).update(BODY).digest("base64") }),
  ]) assert.equal((await handleRequest(request, ENV, fetchMock)).status, 401);
  assert.equal(calls, 0);
});

test("Worker: method/path and missing configuration fail closed with zero network calls", async () => {
  let calls = 0;
  const fetchMock = async () => { calls += 1; return ok(); };
  assert.equal((await handleRequest(new Request("https://relay.example/line-webhook"), ENV, fetchMock)).status, 405);
  assert.equal((await handleRequest(new Request("https://relay.example/other"), ENV, fetchMock)).status, 404);
  for (const env of [{}, { ...ENV, RELAY_HMAC_KEY: "short" }, { ...ENV, LINE_CHANNEL_SECRET: "" }, { ...ENV, GAS_WEB_APP_URL: "https://attacker.example/" }]) {
    assert.equal((await handleRequest(lineRequest(BODY), env, fetchMock)).status, 503);
  }
  assert.equal(calls, 0);
});

test("Worker: content-length and streamed body limits work before forwarding", async () => {
  let calls = 0;
  const fetchMock = async () => { calls += 1; return ok(); };
  assert.equal((await handleRequest(lineRequest(BODY, { "content-length": String(MAX_LINE_BODY_BYTES + 1) }), ENV, fetchMock)).status, 413);
  assert.equal((await handleRequest(lineRequest("x".repeat(MAX_LINE_BODY_BYTES + 1)), ENV, fetchMock)).status, 413);
  assert.equal(calls, 0);
});

test("Worker: only configured HTTPS Apps Script exec URL is accepted", () => {
  assert.equal(fixedGasUrl(TEST_GAS_URL + "?hook=line"), TEST_GAS_URL + "?hook=line");
  for (const url of ["http://script.google.com/macros/s/ID/exec", "https://script.google.com.evil.example/macros/s/ID/exec", "https://user@script.google.com/macros/s/ID/exec", TEST_GAS_URL + "#hash", TEST_GAS_URL + "?target=evil", TEST_GAS_URL.replace("/exec", "/dev"), "https://script.google.com:8443/macros/s/ID/exec"]) assert.throws(() => fixedGasUrl(url));
});

test("Worker: Google content redirect is GET without body or credentials", async () => {
  const requests = [];
  const response = await handleRequest(lineRequest(BODY), ENV, async (url, options) => {
    requests.push({ url, options });
    return requests.length === 1 ? new Response(null, { status: 302, headers: { location: "https://script.googleusercontent.com/macros/echo?temporary=test" } }) : ok();
  });
  assert.equal(response.status, 200);
  assert.equal(requests.length, 2);
  assert.equal(requests[1].options.method, "GET");
  assert.equal(requests[1].options.body, undefined);
  assert.equal(requests[1].options.headers, undefined);
});

test("Worker: external redirect and body-preserving redirect never forward credentials/payload", async () => {
  for (const [status, location] of [[302, "https://attacker.example/"], [302, "https://script.googleusercontent.com.evil.example/"], [307, "https://script.googleusercontent.com/macros/echo"], [302, "https://user@script.googleusercontent.com/macros/echo"]]) {
    let calls = 0;
    const response = await handleRequest(lineRequest(BODY), ENV, async () => { calls += 1; return new Response(null, { status, headers: { location } }); });
    assert.equal(response.status, 502);
    assert.equal(calls, 1);
  }
});

test("Worker: false/legacy OK/non-JSON/oversize/HTTP failure are not acknowledged as success", async () => {
  for (const answer of [() => new Response('{"ok":false,"code":"UNAUTHORIZED"}'), () => new Response("OK"), () => new Response("x".repeat(4097)), () => new Response("denied", { status: 403 })]) {
    const response = await handleRequest(lineRequest(BODY), ENV, answer);
    assert.equal(response.status, 502);
    assert.equal(await response.text(), "Relay delivery failed");
  }
  const response = await handleRequest(lineRequest(BODY), ENV, async () => { throw new Error("token=" + TEST_RELAY_KEY); });
  assert.equal(response.status, 502);
  assert.ok(!(await response.text()).includes(TEST_RELAY_KEY));
});
