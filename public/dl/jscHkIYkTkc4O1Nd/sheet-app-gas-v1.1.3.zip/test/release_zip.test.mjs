import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { inflateRawSync } from "node:zlib";
import { collectEntries, createZip, crc32, writeArchive, RELEASE_PATHS } from "../scripts/release.mjs";

function temporary(t) {
  const dir = mkdtempSync(join(tmpdir(), "sheet-app-zip-test-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  return dir;
}

// writer と独立に central -> local の位置・名前・圧縮データを読む。
function inspectZip(zip) {
  const end = zip.length - 22;
  assert.equal(zip.readUInt32LE(end), 0x06054b50);
  const count = zip.readUInt16LE(end + 10);
  assert.equal(zip.readUInt16LE(end + 8), count);
  const centralStart = zip.readUInt32LE(end + 16);
  assert.equal(centralStart + zip.readUInt32LE(end + 12), end);
  let at = centralStart;
  const files = [];
  for (let i = 0; i < count; i++) {
    assert.equal(zip.readUInt32LE(at), 0x02014b50);
    assert.equal(zip.readUInt16LE(at + 8), 0x0800, "central header は UTF-8");
    assert.equal(zip.readUInt16LE(at + 10), 8);
    const nameLength = zip.readUInt16LE(at + 28);
    const nameBytes = zip.subarray(at + 46, at + 46 + nameLength);
    const name = new TextDecoder("utf-8", { fatal: true }).decode(nameBytes);
    const local = zip.readUInt32LE(at + 42);
    assert.ok(local < centralStart);
    assert.equal(zip.readUInt32LE(local), 0x04034b50);
    assert.equal(zip.readUInt16LE(local + 6), 0x0800, "local header は UTF-8");
    assert.equal(zip.readUInt16LE(local + 8), 8);
    const localNameLength = zip.readUInt16LE(local + 26);
    assert.equal(localNameLength, nameLength);
    assert.deepEqual(zip.subarray(local + 30, local + 30 + localNameLength), nameBytes);
    const compressedLength = zip.readUInt32LE(at + 20);
    assert.equal(zip.readUInt32LE(local + 18), compressedLength);
    const dataStart = local + 30 + localNameLength + zip.readUInt16LE(local + 28);
    const data = inflateRawSync(zip.subarray(dataStart, dataStart + compressedLength));
    assert.equal(data.length, zip.readUInt32LE(at + 24));
    assert.equal(data.length, zip.readUInt32LE(local + 22));
    assert.equal(zip.readUInt32LE(local + 14), zip.readUInt32LE(at + 16));
    assert.equal(crc32(data), zip.readUInt32LE(at + 16));
    files.push({ name, data });
    at += 46 + nameLength + zip.readUInt16LE(at + 30) + zip.readUInt16LE(at + 32);
  }
  assert.equal(at, end);
  return files;
}

test("ZIP の CRC32 は標準の検査値に一致する", () => {
  assert.equal(crc32(Buffer.from("123456789")), 0xcbf43926);
  assert.equal(crc32(Buffer.alloc(0)), 0);
});

test("日本語名は両ヘッダーに UTF-8 として格納され、圧縮後の全内容を復元できる", () => {
  const entries = [
    { name: "samples/設定.csv", data: Buffer.from("項目,値\r\nアプリ名,業務アプリ\r\n") },
    { name: "samples/顧客管理/定義.csv", data: Buffer.from("テーブル,列\r\n顧客,会社名\r\n") },
    { name: "samples/ガイド.txt", data: Buffer.from("結合文字の名前もそのまま") },
    { name: "assets/empty.txt", data: Buffer.alloc(0) },
    { name: "assets/binary.bin", data: Buffer.from(Array.from({ length: 256 }, (_, i) => i)) },
  ];
  const zip = createZip(entries);
  const result = inspectZip(zip);
  assert.equal(result.length, entries.length);
  for (const source of entries) {
    assert.deepEqual(result.find(file => file.name === source.name)?.data, source.data, source.name);
  }
  assert.deepEqual(createZip([...entries].reverse()), zip, "入力順が変わっても同じ ZIP");
});

test("ZIP は重複名・絶対パス・親ディレクトリへのパスを拒否する", () => {
  for (const name of ["/abs", "../outside", "a/../b", "a//b", "a\\b", "C:/outside", "a\0b"]) {
    assert.throws(() => createZip([{ name, data: "x" }]), /不正/);
  }
  assert.throws(() => createZip([{ name: "a", data: "x" }, { name: "a", data: "y" }]), /重複/);
});

test("配布は relay を含み、ローカル秘密・依存物・OS メタデータを除外する", t => {
  assert.ok(RELEASE_PATHS.includes("relay"));
  const dir = temporary(t);
  for (const name of ["relay/worker.mjs", "relay/wrangler.jsonc", "relay/.dev.vars", "relay/.env", "relay/.env.production", "relay/node_modules/a.js", "relay/.wrangler/state", "relay/.DS_Store", "samples/設定.csv"]) {
    const target = join(dir, name);
    mkdirSync(join(target, ".."), { recursive: true });
    writeFileSync(target, name);
  }
  const entries = collectEntries(dir, ["relay", "samples"]);
  assert.deepEqual(entries.map(entry => entry.name), ["relay/worker.mjs", "relay/wrangler.jsonc", "samples/設定.csv"]);
  assert.deepEqual(inspectZip(createZip(entries)), entries);
});

test("配布範囲のシンボリックリンクは外部のファイルを取り込まず停止する", t => {
  const dir = temporary(t);
  mkdirSync(join(dir, "samples"));
  writeFileSync(join(dir, "outside.txt"), "include しない");
  symlinkSync(join(dir, "outside.txt"), join(dir, "samples", "link.txt"));
  assert.throws(() => collectEntries(dir, ["samples"]), /シンボリックリンク/);
});

test("同名 ZIP は同じ内容なら再利用し、異なる内容は既定で保護する", t => {
  const dir = temporary(t);
  const out = join(dir, "release", "product-v1.1.2.zip");
  const before = createZip([{ name: "設定.csv", data: "old" }]);
  const after = createZip([{ name: "設定.csv", data: "new" }]);
  assert.equal(writeArchive(out, before), "created");
  assert.equal(writeArchive(out, before), "unchanged");
  assert.throws(() => writeArchive(out, after), /--overwrite/);
  assert.deepEqual(readFileSync(out), before, "拒否後も元 ZIP の全バイトを保持");
  assert.equal(writeArchive(out, after, { overwrite: true }), "overwritten");
  assert.deepEqual(readFileSync(out), after);
  assert.deepEqual(readdirSync(join(dir, "release")), ["product-v1.1.2.zip"], "一時ファイルは残さない");
});

test("出力先がシンボリックリンクなら --overwrite でも書き換えない", t => {
  const dir = temporary(t);
  const source = join(dir, "source.zip");
  const out = join(dir, "out.zip");
  writeFileSync(source, "original");
  symlinkSync(source, out);
  assert.throws(() => writeArchive(out, Buffer.from("changed"), { overwrite: true }), /シンボリックリンク/);
  assert.equal(readFileSync(source, "utf8"), "original");
});
