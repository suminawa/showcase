import { test } from "node:test";
import assert from "node:assert/strict";
import { runInContext } from "node:vm";
import { FIXED_NOW } from "./fakes.mjs";
import { loadRelayBundle, signedEnvelope, envelopeRequest, signedRelayRequest, TEST_RELAY_KEY } from "./relay-test-helpers.mjs";

const NOW = Math.floor(FIXED_NOW / 1000);
const A = "U" + "a".repeat(32);
const BODY = JSON.stringify({ events: [{ type: "follow", source: { type: "user", userId: A }, timestamp: FIXED_NOW }] });
const EMPTY = '{"events":[]}';
const options = () => ({ sheets: { 設定: [["項目", "値"]] }, props: { SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN: "test-token" }, lineProfiles: { [A]: "テストさん" } });
const result = (run, request) => JSON.parse(run.entry.doPost(request).text);

function untouched(run) {
  assert.equal(run.trace.fetched.length, 0, "unauthenticated input must not call LINE");
  assert.equal(run.sheets["_LINE友だち"], undefined);
  assert.equal(Object.keys(run.props).filter((key) => key.startsWith("relay:v1:")).length, 0);
  // 1.1.3: 拒否は実行ログに 1 行だけ残る（code だけ。本文・鍵は出さない）
  for (const line of run.trace.logs) {
    assert.match(line, /^業務アプリ: LINE 中継を拒否しました（[A-Z_]+）/);
    assert.equal(line.includes(TEST_RELAY_KEY), false);
    assert.equal(line.includes(A), false);
  }
}

test("GAS: 拒否のとき実行ログに理由の code だけを残す（直接の受信でも気づける）", () => {
  const run = loadRelayBundle(options());
  assert.deepEqual(result(run, { parameter: { hook: "line" }, postData: { contents: BODY } }), { ok: false, code: "INVALID_ENVELOPE" });
  assert.equal(run.trace.logs.length, 1);
  assert.match(run.trace.logs[0], /LINE 中継を拒否しました（INVALID_ENVELOPE）/);
  assert.equal(run.trace.logs[0].includes(A), false);
});

test("GAS: valid signed body captures friend; replay makes no second network call", () => {
  const run = loadRelayBundle(options());
  const request = signedRelayRequest(BODY);
  assert.deepEqual(result(run, request), { ok: true });
  assert.equal(run.sheets["_LINE友だち"].rows[1][1], "テストさん");
  assert.equal(run.trace.fetched.length, 1);
  assert.deepEqual(result(run, request), { ok: false, code: "REPLAY" });
  assert.equal(run.trace.fetched.length, 1);
});

test("GAS: raw LINE POST and malformed envelopes are rejected before sheets/network", () => {
  const variants = [BODY, "{bad", JSON.stringify(null), JSON.stringify([]), "x".repeat(90 * 1024 + 1)];
  for (const contents of variants) {
    const run = loadRelayBundle(options());
    assert.deepEqual(result(run, { parameter: { hook: "line" }, postData: { contents } }), { ok: false, code: "INVALID_ENVELOPE" });
    untouched(run);
  }
});

test("GAS: missing key, wrong HMAC, tampering, invalid nonce/version/field fail closed", () => {
  const cases = [
    { props: { SHEET_APP_RELAY_HMAC_KEY: "" }, envelope: signedEnvelope(BODY), code: "NOT_CONFIGURED" },
    { envelope: signedEnvelope(BODY, {}, TEST_RELAY_KEY + "wrong"), code: "UNAUTHORIZED" },
    { envelope: { ...signedEnvelope(BODY), bodyBase64: Buffer.from(EMPTY).toString("base64") }, code: "UNAUTHORIZED" },
    { envelope: signedEnvelope(BODY, { nonce: "../nonce" }), code: "INVALID_ENVELOPE" },
    { envelope: signedEnvelope(BODY, { version: 2 }), code: "INVALID_ENVELOPE" },
    { envelope: { ...signedEnvelope(BODY), url: "https://evil.example" }, code: "INVALID_ENVELOPE" },
    { envelope: signedEnvelope(BODY, { issuedAt: String(NOW) }), code: "INVALID_ENVELOPE" },
    { envelope: { ...signedEnvelope(BODY), signature: "A".repeat(43) + "=" }, code: "UNAUTHORIZED" },
  ];
  for (const check of cases) {
    const run = loadRelayBundle({ ...options(), props: { ...options().props, ...check.props } });
    assert.deepEqual(result(run, envelopeRequest(check.envelope)), { ok: false, code: check.code });
    untouched(run);
  }
});

test("GAS: 5-minute timestamp window checks both past and future, including boundaries", () => {
  for (const delta of [-301, 301]) {
    const run = loadRelayBundle(options());
    assert.deepEqual(result(run, signedRelayRequest(BODY, { issuedAt: NOW + delta })), { ok: false, code: "EXPIRED" });
    untouched(run);
  }
  for (const delta of [-300, 300]) {
    const run = loadRelayBundle(options());
    assert.deepEqual(result(run, signedRelayRequest(EMPTY, { issuedAt: NOW + delta })), { ok: true });
  }
});

test("GAS: Base64 must be canonical and decoded raw bytes are bounded", () => {
  for (const bodyBase64 of ["!!!!", "e30", "e3==", Buffer.alloc(65537, 65).toString("base64")]) {
    const run = loadRelayBundle(options());
    assert.deepEqual(result(run, envelopeRequest(signedEnvelope(BODY, { bodyBase64 }))), { ok: false, code: "INVALID_ENVELOPE" });
    untouched(run);
  }
  const run = loadRelayBundle(options());
  assert.deepEqual(result(run, signedRelayRequest('{"events":[]}' + " ".repeat(65536 - 13))), { ok: true });
});

test("GAS: authenticated malformed JSON and missing events are rejected without claiming nonce", () => {
  for (const body of ["{bad", "null", '{"other":[]}']) {
    const run = loadRelayBundle(options());
    assert.deepEqual(result(run, signedRelayRequest(body)), { ok: false, code: "INVALID_BODY" });
    untouched(run);
  }
});

test("GAS: replay storage is bounded, expired entries are removed, unrelated properties preserved", () => {
  const props = { "relay:v1:expired": String(NOW - 1), "relay:v1:broken": "NaN", unrelated: "keep" };
  for (let i = 0; i < 512; i += 1) props["relay:v1:active-" + i] = String(NOW + 300);
  const run = loadRelayBundle({ ...options(), props: { ...options().props, ...props } });
  assert.deepEqual(result(run, signedRelayRequest(BODY)), { ok: false, code: "BUSY" });
  assert.equal(run.props["relay:v1:expired"], undefined);
  assert.equal(run.props["relay:v1:broken"], undefined);
  assert.equal(run.props.unrelated, "keep");
  assert.equal(run.trace.fetched.length, 0);
  delete run.props["relay:v1:active-0"];
  assert.deepEqual(result(run, signedRelayRequest(BODY)), { ok: true });
});

test("GAS: lock failure does not process; exceptions never echo credentials or body", () => {
  const locked = loadRelayBundle({ ...options(), lockBusy: true });
  assert.deepEqual(result(locked, signedRelayRequest(BODY)), { ok: false, code: "PROCESSING_FAILED" });
  untouched(locked);
  const run = loadRelayBundle(options());
  runInContext('receiveLineWebhook_ = function () { throw new Error("secret=private-value"); };', run.context);
  const request = signedRelayRequest(BODY);
  assert.deepEqual(result(run, request), { ok: false, code: "PROCESSING_FAILED" });
  for (const line of run.trace.logs) assert.match(line, /^業務アプリ: LINE 中継を拒否しました（[A-Z_]+）/, "拒否の理由以外は残さない");
  assert.deepEqual(result(run, request), { ok: false, code: "REPLAY" }, "failed processing still consumes envelope nonce");
  runInContext('receiveLineWebhook_ = function () { return 0; };', run.context);
  assert.deepEqual(result(run, signedRelayRequest(BODY)), { ok: true }, "fresh relay envelope may retry the LINE event");
});

test("GAS: nonce lock is released before the existing friend-save lock is acquired", () => {
  const run = loadRelayBundle(options());
  let locked = false;
  let count = 0;
  run.sandbox.LockService.getScriptLock = () => ({
    waitLock: () => { assert.equal(locked, false); locked = true; count += 1; },
    releaseLock: () => { locked = false; },
  });
  assert.deepEqual(result(run, signedRelayRequest(BODY)), { ok: true });
  assert.equal(count, 2);
  assert.equal(locked, false);
});
