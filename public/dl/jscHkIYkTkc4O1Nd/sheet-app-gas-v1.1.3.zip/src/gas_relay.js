/** LINE の署名を検証した中継からだけ受信する。本文・秘密・例外の詳細はログへ残さない。 */
import { withLock_ } from "./gas_store.js";
import { receiveLineWebhook_ } from "./gas_line.js";

const RELAY_KEY_PROPERTY = "SHEET_APP_RELAY_HMAC_KEY";
const RELAY_NONCE_PREFIX = "relay:v1:";
const RELAY_WINDOW_SECONDS = 300;
const RELAY_MAX_BODY_BYTES = 64 * 1024;
const RELAY_MAX_ENVELOPE_CHARS = 90 * 1024;
const RELAY_MAX_NONCES = 512;

function relaySignatureEqual_(left, right) {
  if (left.length !== right.length) return false;
  let different = 0;
  for (let i = 0; i < left.length; i += 1) different |= (left[i] & 255) ^ (right[i] & 255);
  return different === 0;
}

function relayBase64Bytes_(value, maxLength) {
  if (typeof value !== "string" || value.length > maxLength || value.length % 4 !== 0 ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) return null;
  try {
    const bytes = Utilities.base64Decode(value);
    return Utilities.base64Encode(bytes) === value ? bytes : null;
  } catch (error) {
    return null;
  }
}

/** ロック内で受理を記録し、既存のシート更新ロックを取る前に解放する。 */
function claimRelayNonce_(nonce, expiresAt, now) {
  return withLock_(function () {
    const props = PropertiesService.getScriptProperties();
    const keys = props.getKeys();
    let active = 0;
    for (let i = 0; i < keys.length; i += 1) {
      if (keys[i].indexOf(RELAY_NONCE_PREFIX) !== 0) continue;
      const expiry = Number(props.getProperty(keys[i]));
      if (!Number.isFinite(expiry) || expiry < now) props.deleteProperty(keys[i]);
      else active += 1;
    }
    const key = RELAY_NONCE_PREFIX + nonce;
    if (props.getProperty(key) !== null) return "REPLAY";
    if (active >= RELAY_MAX_NONCES) return "BUSY";
    props.setProperty(key, String(expiresAt));
    return "";
  });
}

/** Apps Script では応答 HTTP ステータスを選べないため、中継は JSON の ok を必ず確認する。 */
export function handleLineRelay_(e) {
  try {
    const contents = e && e.postData ? e.postData.contents : null;
    if (typeof contents !== "string" || contents.length > RELAY_MAX_ENVELOPE_CHARS) return { ok: false, code: "INVALID_ENVELOPE" };
    let envelope;
    try { envelope = JSON.parse(contents); } catch (error) { return { ok: false, code: "INVALID_ENVELOPE" }; }
    if (!envelope || Array.isArray(envelope) || Object.keys(envelope).sort().join(",") !== "bodyBase64,issuedAt,nonce,signature,version" ||
        envelope.version !== 1 || !Number.isSafeInteger(envelope.issuedAt) ||
        typeof envelope.nonce !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(envelope.nonce)) {
      return { ok: false, code: "INVALID_ENVELOPE" };
    }
    const now = Math.floor(Date.now() / 1000);
    if (Math.abs(now - envelope.issuedAt) > RELAY_WINDOW_SECONDS) return { ok: false, code: "EXPIRED" };
    const raw = relayBase64Bytes_(envelope.bodyBase64, Math.ceil(RELAY_MAX_BODY_BYTES / 3) * 4);
    const signature = relayBase64Bytes_(envelope.signature, 44);
    if (!raw || raw.length > RELAY_MAX_BODY_BYTES || !signature || signature.length !== 32) return { ok: false, code: "INVALID_ENVELOPE" };
    const secret = PropertiesService.getScriptProperties().getProperty(RELAY_KEY_PROPERTY);
    if (typeof secret !== "string" || !/^[A-Za-z0-9_-]{32,256}$/.test(secret)) return { ok: false, code: "NOT_CONFIGURED" };
    const canonical = "v1\n" + envelope.issuedAt + "\n" + envelope.nonce + "\n" + envelope.bodyBase64;
    const expected = Utilities.computeHmacSha256Signature(canonical, secret, Utilities.Charset.UTF_8);
    if (!relaySignatureEqual_(expected, signature)) return { ok: false, code: "UNAUTHORIZED" };
    const body = Utilities.newBlob(raw).getDataAsString("UTF-8");
    let eventBody;
    try { eventBody = JSON.parse(body); } catch (error) { return { ok: false, code: "INVALID_BODY" }; }
    if (!eventBody || !Array.isArray(eventBody.events)) return { ok: false, code: "INVALID_BODY" };
    const rejected = claimRelayNonce_(envelope.nonce, envelope.issuedAt + RELAY_WINDOW_SECONDS, now);
    if (rejected) return { ok: false, code: rejected };
    receiveLineWebhook_(body);
    return { ok: true };
  } catch (error) {
    // URL/token/body を含みうる例外を公開応答や Logger に渡さない。
    return { ok: false, code: "PROCESSING_FAILED" };
  }
}
