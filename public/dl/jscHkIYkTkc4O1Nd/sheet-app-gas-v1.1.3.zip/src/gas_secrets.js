/** 接続情報は設定セルに置かずスクリプトプロパティから読む。共同編集者からの隔離には使えない。 */
import { settingKeyOf } from "./settings.js";
import { textOf } from "./text.js";
import { withLock_ } from "./gas_store.js";

export const CONNECTION_SECRET_BINDINGS = [
  ["Slack Webhook URL", "SHEET_APP_SLACK_WEBHOOK_URL"],
  ["Discord Webhook URL", "SHEET_APP_DISCORD_WEBHOOK_URL"],
  ["LINE チャネルアクセストークン", "SHEET_APP_LINE_CHANNEL_ACCESS_TOKEN"],
];

function secretBinding_(label) {
  const key = settingKeyOf(label);
  return CONNECTION_SECRET_BINDINGS.find((entry) => settingKeyOf(entry[0]) === key) || null;
}

/** 通常処理は旧セルに残った秘密へフォールバックしない。秘密の値は診断へ出さない。 */
export function connectionSettingsRows_(rows) {
  const props = PropertiesService.getScriptProperties();
  const clean = rows.filter((row) => secretBinding_(row[0]) === null).map((row) => row.slice());
  CONNECTION_SECRET_BINDINGS.forEach((entry) => clean.push([entry[0], props.getProperty(entry[1]) || ""]));
  const remaining = [];
  rows.forEach((row) => {
    const binding = secretBinding_(row[0]);
    if (binding && textOf(row[1]) !== "" && remaining.indexOf(binding[0]) < 0) remaining.push(binding[0]);
  });
  return { rows: clean, remaining: remaining };
}

/** 明示的なメニュー操作専用。全競合を先に検出し、保存を確認したセルだけ空欄にする。 */
export function migrateConnectionSecrets_(sheet) {
  return withLock_(() => migrateConnectionSecretsLocked_(sheet));
}

function migrateConnectionSecretsLocked_(sheet) {
  if (!sheet || sheet.getLastRow() === 0) return 0;
  const rows = sheet.getDataRange().getValues();
  const props = PropertiesService.getScriptProperties();
  const plan = {};
  rows.forEach((row, index) => {
    const binding = secretBinding_(row[0]);
    const value = textOf(row[1]);
    if (!binding || value === "") return;
    const property = binding[1];
    const existing = textOf(props.getProperty(property));
    if ((existing !== "" && existing !== value) || (plan[property] && plan[property].value !== value)) {
      throw new Error("「" + binding[0] + "」に異なる接続情報があります。プロパティと重複行を確認してから移してください。値は変更していません");
    }
    if (!plan[property]) plan[property] = { value: value, rows: [] };
    plan[property].rows.push(index + 1);
  });
  const keys = Object.keys(plan);
  for (let i = 0; i < keys.length; i += 1) {
    const key = keys[i];
    props.setProperty(key, plan[key].value);
    if (props.getProperty(key) !== plan[key].value) throw new Error("接続情報の保存を確認できませんでした。設定シートの値は残しています");
  }
  let cleared = 0;
  for (let i = 0; i < keys.length; i += 1) {
    const entry = plan[keys[i]];
    for (let j = 0; j < entry.rows.length; j += 1) {
      const cell = sheet.getRange(entry.rows[j], 2, 1, 1);
      // 保存中にセルが書き換えられた場合には消さない。
      if (textOf(cell.getValues()[0][0]) !== entry.value) throw new Error("移行中に設定セルが変わりました。変更された値は消していません。接続情報を確認してください");
      cell.setValues([[""]]);
      cleared += 1;
    }
  }
  return cleared;
}
