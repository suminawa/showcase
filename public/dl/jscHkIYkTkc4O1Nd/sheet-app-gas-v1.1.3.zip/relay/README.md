# LINE 受信の中継

この Worker は、LINE が付けた `x-line-signature` を受信時の本文 bytes とチャネルシークレットで検証します。成功した場合だけ、時刻・nonce・本文を別の共有鍵で署名し、固定の GAS Web アプリへ渡します。GAS は署名・時刻・nonce を確認してから既存の友だち情報処理へ進みます。LINE 本文を GAS に直接送る旧設定は使えません。

## 設置

1. GAS でキットの初期化と LINE チャネルアクセストークンの設定を済ませます。GAS の受信用 Web アプリは「次のユーザーとして実行: 自分」「アクセスできるユーザー: 全員」です。既存の受信用デプロイを使う場合も、この版へバージョンを更新します。スタッフの画面用デプロイとは分けてください。
2. 中継専用の、推測できない共有鍵を用意します。使用可能なのは32〜256文字の英数字・`_`・`-`。この鍵を GAS のスクリプトプロパティ `SHEET_APP_RELAY_HMAC_KEY` に登録します。スプレッドシート、この記事、公開コード、Wrangler の vars へは書きません。プロジェクトごとに別の鍵を使います。
3. `wrangler.jsonc` の `GAS_WEB_APP_URL` を、手順1の受信用 `/exec` URL に置き換えます。`?hook=line` は Worker が付けます。画面用の URL、`/dev`、Google 以外の URL は使えません。
4. Cloudflare アカウントと Node.js を用意し、この `relay` フォルダーで Worker を公開してから次の秘密を登録します。最初の公開直後は秘密が未設定なので受信を拒否します。入力値はコマンド引数や設定ファイルへ書かず、対話入力します。

```sh
npx wrangler login
npx wrangler deploy
npx wrangler secret put LINE_CHANNEL_SECRET
npx wrangler secret put RELAY_HMAC_KEY
```

`LINE_CHANNEL_SECRET` は LINE Developers のチャネルシークレットです。チャネルアクセストークンとは別物です。`RELAY_HMAC_KEY` は手順2と同じ共有鍵です。シークレットの登録・公開は利用者の Cloudflare アカウントで行ってください。

5. 秘密・GAS・Worker の設定を揃えてから、LINE Developers の Webhook URL を `https://公開されたWorkerのホスト/line-webhook` に変更し、「Webhook の利用」をオンにします。更新時にオフにした方も、ここでオンに戻します。既存の GAS 直 URL を置き換えます。`deploy` と `secret put` は Cloudflare 上の Worker を公開・更新する操作です。
6. LINE の Webhook 検証と、テスト用アカウントの友だち追加またはメッセージ1通で、GAS の `_LINE友だち` への反映を確認します。検証の空イベントが成功しても、実際のプロフィール取得まで確認したことにはなりません。

Cloudflare の費用・利用上限、Google / LINE の各サービスの設定と権限は別途確認してください。Worker へは LINE のイベント本文が通ります。このコードは本文、トークン、鍵、転送先 URL をログへ出しません。

## 受け付ける範囲と失敗時

- 受信本文は64 KiBまで。GAS側は中継の署名時刻と現在時刻の差が前後5分以内であることを確認します。
- GASは受理したnonceをスクリプトプロパティへ記録し、同じラッパーを再処理しません。期限内のnonceが512件に達すると、新たな受理を停止し、期限切れが片付くまで待ちます。これは大規模配信向けのキューではありません。
- 処理途中に失敗した場合も、そのラッパーのnonceは消費済みです。LINEが元イベントを再送するとWorkerが新nonceを付けるため再試行できます。LINEのイベントそのものを完全に重複排除する仕組みではありません。
- 中継先は設定済みのGAS URLに固定。Google ContentServiceの応答取得は `script.googleusercontent.com` への302/303リダイレクトのみ追い、GETで取得します。署名ラッパーをリダイレクト先へ再送しません。
- WorkerはGASのJSONで `ok: true` を確認した場合だけ200を返します。GASの拒否や転送失敗では502を返します。LINEの再送設定や回数は別の条件であり、このコードだけで送達は保証しません。
- スクリプトプロパティはプロジェクトから独立した秘密保管庫ではありません。コードを変更できる人を信頼できる管理者に限定してください。利用者の共有範囲についてはキット本体のREADMEも確認してください。

## 確認済みの範囲

標準WebCrypto・Node上のGASモックによる署名互換、改ざん/未署名の拒否、時刻・再使用・容量制限、転送先とリダイレクト制限をテストしています。

2026年10月10日、検証用のLINE → Cloudflare Worker → GAS受信中継を設定し、LINE Developersの「検証」で「成功」を確認しました。WorkerはGASの `ok: true` を確認した場合だけ200を返すため、空イベントの署名検証と中継疎通は実環境で確認済みです。「Webhookの利用」もオンにしています。

続けて、実際のLINEアカウントのチャット画面からテストメッセージを送信し、受信に伴う `_LINE友だち` への1件の自動登録、表示名の取得、追加日時、状態「友だち」を確認しました。

台帳のコピーについては、同じ所有者がコピー先を初期化し、コピー先の台帳ID・スクリプトIDとの一致を確認した後、テスト用Webデプロイ（`/dev`）から架空の顧客1件を更新できることを確認しました。担当者と更新日時だけがコピー先で変わり、元台帳の比較範囲 `顧客!A1:O24` は試験前と完全一致しました。この検証用コピーの接続用秘密は0件で、LINE中継は未設定です。コピー先の公開用 `/exec`、別アカウント利用、外部連携は確認していません。

ブロック・再追加など今回送信していないイベント、キットからLINE・Slack・Discordへの実送信、Anthropicとの実接続は未確認です。空イベントと今回のメッセージ受信の成功を、LINE全機能の確認とは扱いません。導入環境でも手順6の実イベントを確かめてください。

公式資料: [LINEのWebhook署名検証](https://developers.line.biz/en/docs/messaging-api/verify-webhook-signature/) / [Apps Script Webアプリのイベント](https://developers.google.com/apps-script/guides/web) / [ContentServiceのリダイレクト](https://developers.google.com/apps-script/guides/content#redirects) / [Cloudflare Secrets](https://developers.cloudflare.com/workers/configuration/secrets/) / [Cloudflare WebCrypto](https://developers.cloudflare.com/workers/runtime-apis/web-crypto/)
