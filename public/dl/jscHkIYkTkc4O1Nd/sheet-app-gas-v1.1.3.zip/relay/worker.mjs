/** LINE -> Cloudflare Worker -> GAS. No request body, credentials or URLs are logged. */
export const MAX_LINE_BODY_BYTES = 64 * 1024;
const MAX_GAS_RESPONSE_BYTES = 4096;
const TRANSFER_TIMEOUT_MS = 20000;
const encoder = new TextEncoder();

function relayError(code) {
  return Object.assign(new Error(code), { code });
}

export function validRelayKey(value) {
  return typeof value === "string" && /^[A-Za-z0-9_-]{32,256}$/.test(value);
}

export function fixedGasUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.hostname !== "script.google.com" || url.port || url.username || url.password || url.hash ||
      !/^\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(url.pathname) ||
      (url.search !== "" && url.search !== "?hook=line")) throw relayError("CONFIGURATION");
  url.search = "?hook=line";
  return url.href;
}

async function readLimitedBody(message, limit) {
  const length = message.headers.get("content-length");
  if (length && (!/^\d+$/.test(length) || Number(length) > limit)) throw relayError("BODY_TOO_LARGE");
  if (!message.body) return new Uint8Array(0);
  const reader = message.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > limit) {
        await reader.cancel();
        throw relayError("BODY_TOO_LARGE");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const result = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return result;
}

function base64(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function signatureBytes(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9+/]{43}=$/.test(value)) return null;
  try {
    const bytes = Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
    return bytes.length === 32 && base64(bytes) === value ? bytes : null;
  } catch (_) {
    return null;
  }
}

async function hmacKey(secret, usage) {
  return crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, [usage]);
}

export async function verifyLineSignature(raw, signature, channelSecret) {
  const bytes = signatureBytes(signature);
  if (!bytes) return false;
  return crypto.subtle.verify("HMAC", await hmacKey(channelSecret, "verify"), bytes, raw);
}

export function signingText(envelope) {
  return "v1\n" + envelope.issuedAt + "\n" + envelope.nonce + "\n" + envelope.bodyBase64;
}

export async function createEnvelope(raw, relayKey, now = Date.now()) {
  if (!validRelayKey(relayKey)) throw relayError("CONFIGURATION");
  const envelope = { version: 1, issuedAt: Math.floor(now / 1000), nonce: crypto.randomUUID(), bodyBase64: base64(raw) };
  envelope.signature = base64(new Uint8Array(await crypto.subtle.sign("HMAC", await hmacKey(relayKey, "sign"), encoder.encode(signingText(envelope)))));
  return envelope;
}

async function forwardToGas(gasUrl, envelope, fetchImpl) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TRANSFER_TIMEOUT_MS);
  try {
    let response = await fetchImpl(gasUrl, {
      method: "POST", redirect: "manual", signal: controller.signal,
      headers: { "content-type": "application/json; charset=utf-8" }, body: JSON.stringify(envelope),
    });
    // ContentService uses a one-time googleusercontent URL. Never resend the signed payload at a redirect.
    let redirects = 0;
    while (response.status >= 300 && response.status < 400) {
      if (++redirects > 2 || (response.status !== 302 && response.status !== 303)) throw relayError("UPSTREAM");
      const location = response.headers.get("location");
      if (!location) throw relayError("UPSTREAM");
      const url = new URL(location);
      if (url.protocol !== "https:" || url.hostname !== "script.googleusercontent.com" || url.port || url.username || url.password || url.hash) throw relayError("UPSTREAM");
      if (response.body) await response.body.cancel();
      response = await fetchImpl(url.href, { method: "GET", redirect: "manual", signal: controller.signal });
    }
    if (!response.ok) throw relayError("UPSTREAM");
    const result = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await readLimitedBody(response, MAX_GAS_RESPONSE_BYTES)));
    if (!result || result.ok !== true) throw relayError("UPSTREAM");
  } finally {
    clearTimeout(timer);
  }
}

function reply(status, message) {
  return new Response(message, { status, headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" } });
}

export async function handleRequest(request, env, fetchImpl = fetch) {
  if (new URL(request.url).pathname !== "/line-webhook") return reply(404, "Not found");
  if (request.method !== "POST") return reply(405, "Method not allowed");
  let gasUrl;
  try {
    if (!env || !validRelayKey(env.RELAY_HMAC_KEY) || typeof env.LINE_CHANNEL_SECRET !== "string" ||
        !/^[\x21-\x7e]{1,256}$/.test(env.LINE_CHANNEL_SECRET)) throw relayError("CONFIGURATION");
    gasUrl = fixedGasUrl(env.GAS_WEB_APP_URL);
  } catch (_) {
    return reply(503, "Relay is not configured");
  }
  const signature = request.headers.get("x-line-signature");
  if (!signatureBytes(signature)) return reply(401, "Unauthorized");
  let raw;
  try {
    raw = await readLimitedBody(request, MAX_LINE_BODY_BYTES);
    if (!(await verifyLineSignature(raw, signature, env.LINE_CHANNEL_SECRET))) return reply(401, "Unauthorized");
  } catch (error) {
    return reply(error && error.code === "BODY_TOO_LARGE" ? 413 : 400, "Invalid request");
  }
  try {
    const envelope = await createEnvelope(raw, env.RELAY_HMAC_KEY);
    await forwardToGas(gasUrl, envelope, fetchImpl);
    return reply(200, "OK");
  } catch (_) {
    // GAS/authentication/timeout errors stay generic; no body, URL or credential is echoed.
    return reply(502, "Relay delivery failed");
  }
}

export default { fetch: (request, env) => handleRequest(request, env) };
