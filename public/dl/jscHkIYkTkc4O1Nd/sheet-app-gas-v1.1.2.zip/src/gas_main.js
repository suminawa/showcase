/**
 * スプレッドシートのメニュー「業務アプリ」。Web アプリの入口は gas_web.js（doGet と api_*）。
 * dist/Code.gs の先頭に来るファイル。
 */
import { toDateKey } from "./dates.js";
import { laterId, nextId } from "./ids.js";
import { TEMPLATES } from "./samples.js";
import { formatUsage } from "./usage.js";
import { buildTestNotifyText } from "./notify.js";
import { crossCheckSettings, settingsSummary } from "./settings.js";
import { readLastId_, readMonthUsage_, saveLastId_ } from "./gas_store.js";
import { rememberBook_, assignMissingIds_, ensureDefinitionSheet_, ensureLineDefinition_, ensureSettingsSheet_, ensureTable_, loadTemplate_, readDefinition_, readIds_, readSettings_ } from "./gas_sheets.js";
import { ensureNotifyLog_, notifyAll_, webAppUrl_ } from "./gas_notify.js";
import { ensureLineSheets_ } from "./gas_line.js";
import { handleLineRelay_ } from "./gas_relay.js";
import { maxIdOf_ } from "./gas_web.js";
import { migrateConnectionSecrets_ } from "./gas_secrets.js";

const MENU_TITLE = "業務アプリ";

function ui_() {
  return SpreadsheetApp.getUi();
}

/** メニュー専用操作は副作用より先に、シートに結び付いたUI文脈を確かめる。 */
function requireSheetMenu_() {
  let active;
  try { active = SpreadsheetApp.getActiveSpreadsheet(); } catch (error) { active = null; }
  if (!active) throw new Error("対象のスプレッドシートを開き、業務アプリのメニューから実行してください");
  SpreadsheetApp.getUi();
  return active;
}

function alert_(text) {
  ui_().alert(text);
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

export function onOpen() {
  ui_()
    .createMenu(MENU_TITLE)
    .addItem("初期化（足りないシート・見出し・設定を足す。データは消しません）", "initializeSheets")
    .addSeparator()
    .addItem("見本を読み込む: 顧客管理", "loadSampleCustomers")
    .addItem("見本を読み込む: 案件管理", "loadSampleProjects")
    .addItem("見本を読み込む: 在庫管理", "loadSampleInventory")
    .addSeparator()
    .addItem("設定を確かめる", "checkSettings")
    .addItem("接続情報を設定シートから移す", "migrateConnectionSecrets")
    .addItem("通知のテストを送る", "sendTestNotification")
    .addItem("Web アプリの URL", "showAppUrl")
    .addItem("今月の AI 利用", "showAiUsage")
    .addToUi();
}

/** 設定・定義・各テーブルのシートと、_LINE友だち・_LINE送信履歴・_通知ログ を作り、設定に足りない行を足し、ID の無い行に番号を振る */
export function initializeSheets() {
  requireSheetMenu_();
  try {
    rememberBook_();
    const settingsResult = ensureSettingsSheet_();
    ensureLineSheets_();
    ensureNotifyLog_();
    const madeDefinition = ensureDefinitionSheet_();
    let definition = readDefinition_();
    let addedLine = false;
    if (definition.errors.length === 0 && ensureLineDefinition_(definition.tables)) {
      addedLine = true;
      definition = readDefinition_();
    }
    if (definition.errors.length > 0) {
      alert_((madeDefinition ? "「設定」と「定義」のシートを作りました。" : "") + "定義に直すところがあります。\n\n" + definition.errors.join("\n") + "\n\n定義を直してから、もう一度「初期化」を実行してください。まず試すなら「見本を読み込む」が早いです");
      return;
    }
    const today = toDateKey(new Date());
    let assigned = 0;
    const names = [];
    for (let i = 0; i < definition.tables.length; i += 1) {
      const table = definition.tables[i];
      ensureTable_(table);
      names.push(table.name);
      // 出発点は「覚え書き」と「シートに残っている今日の ID」の後ろの方。連番はメモリで進め、覚え書きは最後に 1 回だけ書く
      let last = laterId(readLastId_(table.name), maxIdOf_(readIds_(table), today));
      assigned += assignMissingIds_(table, () => {
        last = nextId(last, today);
        return last;
      });
      if (last !== "") saveLastId_(table.name, last);
    }
    const settingsNote = settingsResult && settingsResult.added > 0 ? "「設定」に " + settingsResult.added + " 行（通知・LINE の項目）を足しました。値は空のままなので、使うときに入れてください。\n" : "";
    const lineNote = addedLine ? "「定義」の顧客に LINE の列を足しました（お客さまへの LINE 送信に使います。使わなければそのままで構いません）。\n" : "";
    alert_("初期化しました。テーブル: " + names.join("、") + "。ID を " + assigned + " 件振りました。\n" + settingsNote + lineNote + "次は「デプロイ」→「新しいデプロイ」→「ウェブアプリ」で公開し、「Web アプリの URL」で URL を確かめてください");
  } catch (error) {
    alert_(failureText_(error));
  }
}

function loadSample_(name) {
  requireSheetMenu_();
  try {
    ensureSettingsSheet_();
    const result = loadTemplate_(TEMPLATES[name]);
    const parts = Object.keys(result.tables).map((table) => table + " " + result.tables[table] + " 件");
    alert_("見本「" + name + "」を読み込みました。定義 " + result.definitionRows + " 行、" + parts.join("、") + "。\n次は「初期化」を実行してから、「デプロイ」→「新しいデプロイ」→「ウェブアプリ」で公開してください");
  } catch (error) {
    alert_(failureText_(error));
  }
}

export function loadSampleCustomers() {
  loadSample_("顧客管理");
}

export function loadSampleProjects() {
  loadSample_("案件管理");
}

export function loadSampleInventory() {
  loadSample_("在庫管理");
}

/** 定義・設定の誤り（通知と LINE の行を含む）を並べる。無ければ、通知と LINE の状態を添えて「問題ありません」 */
export function checkSettings() {
  requireSheetMenu_();
  try {
    const settings = readSettings_();
    const definition = readDefinition_();
    const errors = definition.errors.concat(settings.errors, settings.notifyErrors, crossCheckSettings(settings.settings, definition.tables));
    if (errors.length > 0) {
      alert_("直すところがあります。\n\n" + errors.join("\n"));
      return;
    }
    const tables = definition.tables.map((t) => t.name + "（" + t.columns.length + " 列）").join("、");
    alert_("問題ありません。アプリ名「" + settings.settings.appName + "」、テーブル: " + tables + "\n\n" + settingsSummary(settings.settings, definition.tables).join("\n"));
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** シートのメニューからだけ使う明示的な移行。Web経由ではアクティブなシートがないので行わない。 */
export function migrateConnectionSecrets() {
  requireSheetMenu_();
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet();
    if (!sheet) throw new Error("対象のスプレッドシートを開き、メニューから実行してください");
    const moved = migrateConnectionSecrets_(sheet.getSheetByName("設定"));
    alert_("接続情報を移しました。空欄にした設定セル: " + moved + " 件。次に「設定を確かめる」を実行してください。過去の履歴やコピーに残った値は消えません。必要に応じてサービス側で接続情報を更新してください");
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** 設定の通知先すべてに「これはテストです」を送り、宛先ごとの結果を出す */
export function sendTestNotification() {
  requireSheetMenu_();
  try {
    const read = readSettings_();
    const settings = read.settings;
    if (settings.notifyTargets.length === 0) {
      alert_("設定「通知先」が空のため、送る先がありません。slack・discord・line のいずれかを書いてから、もう一度お試しください" + (read.notifyErrors.length > 0 ? "\n\n" + read.notifyErrors.join("\n") : ""));
      return;
    }
    const results = notifyAll_(settings, buildTestNotifyText(settings.appName));
    const lines = results.map((result) => result.target + ": " + result.message);
    const notes = read.notifyErrors.length > 0 ? "\n\n直すところがあります。\n" + read.notifyErrors.join("\n") : "";
    alert_("通知のテストを送りました。\n\n" + lines.join("\n") + notes);
  } catch (error) {
    alert_(failureText_(error));
  }
}

export function showAppUrl() {
  requireSheetMenu_();
  let settings = null;
  try {
    settings = readSettings_().settings;
  } catch (error) {
    settings = null;
  }
  // 設定「画面の URL」があればそれ（webhook 用のデプロイの URL を配ってしまわないように）
  const url = webAppUrl_(settings);
  if (url === "") {
    alert_("まだ公開されていません。「デプロイ」→「新しいデプロイ」→ 種類「ウェブアプリ」→ 次のユーザーとして実行「ウェブアプリにアクセスしているユーザー」・アクセスできるユーザー「Google アカウントを持つ全員」で公開してから、もう一度お試しください");
    return;
  }
  alert_("Web アプリの URL:\n" + url + "\n\nこの URL をスタッフに配ってください。スプレッドシートを共有（閲覧者か編集者）した人だけが使えます");
}

export function showAiUsage() {
  requireSheetMenu_();
  try {
    const settings = readSettings_().settings;
    const month = toDateKey(new Date()).slice(0, 7);
    alert_(formatUsage(readMonthUsage_(month), settings.model, month));
  } catch (error) {
    alert_(failureText_(error));
  }
}

/** LINE 署名を確認した中継だけを受ける。未署名の LINE 本文を直接送っても処理しない。 */
export function doPost(e) {
  const hook = e && e.parameter ? String(e.parameter.hook || "") : "";
  if (hook !== "line") return ContentService.createTextOutput("not found").setMimeType(ContentService.MimeType.TEXT);
  return ContentService.createTextOutput(JSON.stringify(handleLineRelay_(e))).setMimeType(ContentService.MimeType.JSON);
}
