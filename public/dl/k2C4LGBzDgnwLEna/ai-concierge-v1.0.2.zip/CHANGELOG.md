# Changelog

## 1.0.2 — 2026-09-29

1.0.1 の zip に入れた Next.js のテンプレで、`package.json` がキット本体の 1.0.0 の tgz（`vendor/suminawa-ai-concierge-1.0.0.tgz`）を指したままになっており、`templates/nextjs` で `npm install` を実行すると止まっていました。テンプレが同梱の tgz を指すように直しました。キット本体の動きは 1.0.1 と同じです。

1.0.1 をお使いの方は、1.0.2 の zip に取り替えていただくか、`templates/nextjs/package.json` の `"@suminawa/ai-concierge"` の行を `"file:./vendor/suminawa-ai-concierge-1.0.1.tgz"` に書き替えてから、もう一度 `npm install` を実行してください。

Fixed the bundled Next.js template: in the 1.0.1 zip its `package.json` still pointed at the 1.0.0 tgz, so `npm install` in `templates/nextjs` failed. The template now points at the bundled tgz. The kit itself behaves as in 1.0.1. If you have 1.0.1, either take the 1.0.2 zip or change the `"@suminawa/ai-concierge"` line in `templates/nextjs/package.json` to `"file:./vendor/suminawa-ai-concierge-1.0.1.tgz"` and run `npm install` again.

## 1.0.1 — 2026-09-25

短い節を続けて合わせて 1 片にしたとき、根拠の題が合わせた節のうちの 1 つの見出しになり、答えの出典としてずれることがあった不具合を直しました（例:「AI 案内窓口キット」についての答えの出典に「間取りシミュレーター」が出る）。片の題は「先頭の見出し ほか」を名乗るようにし、合わせたすべての見出しは引き続き検索で拾えるようにしました。

Fixed a bug where a chunk made by merging several short consecutive sections could be labelled with the wrong section's heading as its cited source (e.g. an answer about "AI 案内窓口キット" citing "間取りシミュレーター"). A merged chunk's title now reads "first heading ほか", and every merged heading remains searchable.

## 1.0.0 — 2026-09-21
- 初版。自社の文書だけを根拠に、サイトを訪れた方のご質問へ敬体でお答えする案内窓口です
- サーバー部品 `createConcierge(config)`: Web 標準の `Request → Response`。Next.js・Vercel・Node のどれでも動きます
- 埋め込み部品 `ai-concierge.js`: `<link>` と `<script>` の 2 行で右下に窓が出ます。ページの中に置くこともできます
- 索引づくり `npx ai-concierge index`: `content/` の Markdown と、指定した公開ページから `data/index.json` を作ります
- 答えは流れながら表示され、参照した文書が「根拠」としてリンクで並びます
- 文書が小さいうちは全文を送り、大きくなると BM25 で上位の片だけを送ります（切り替えは自動です）
- 答えられなかったご質問は `/admin` に残ります。Webhook で Slack などへ送ることもできます
- 送信元・回数・1 日の上限・入力の長さを、設定と環境変数で制限できます
- Next.js 16 のテンプレと、見本の文書 8 本、31 問の評価を同梱しています
- 同梱のテンプレの Next.js は 16.3.5 以上（`^16.3.5`）です。16.3.3 より前の Next.js に重大な脆弱性の勧告が出ているため、それより下に落ちない形にしてあります

### 守りと使い勝手の見直し（2026-09-13）

発売前に、ブランチ全体をもう一度見直しました。版は 1.0.0 のままです。

- 回数の上限を、接続元のアドレスで数えるようにしました。`x-forwarded-for` は `TRUST_PROXY=1` を入れたときだけ見ます。覚えておく IP の数にも上限（10,000 件）を付け、窓の時間が過ぎたものから忘れます
- 文書をやり取りのいちばん先に固定し、キャッシュの区切りを 1 時間もつようにしました。2 回目以降のご質問でもキャッシュから読めます。README の費用の目安は、キャッシュへの書き込みぶんも含めて書き直しました
- `concierge.config.json` の `greeting` / `suggestions` / `contactUrl` / `labels` が窓に届くようになりました（窓が起動時に `{endpoint}/config` を読みます）。`data-*` 属性のほうが強いままです
- 「未回答」の見分けを、言い方だけに頼らない形にしました。出典が 1 つも付かなかった答えも未回答として残ります
- `answer.maxTokens` の既定を 2,048 に上げ、`max_tokens` で切れた答えは「…」を添えて「途中で切れた」として記録するようにしました
- 入力欄を textarea にしました。Enter で送信、Shift+Enter で改行できます
- 読み上げソフトへの知らせを 1 回にまとめました。流れてくる字のたびに会話を読み上げ直しません
- `ALLOWED_ORIGINS` は末尾の `/` やスキームの省略を受け取り、オリジンの形にそろえます。`LOG_WEBHOOK_URL` と文書の `url:` も起動時・索引づくりの時点で確かめます
- demo の「ページの中に置く形」に、実際に窓が出るようにしました。テンプレにも見本の文書を 2 本入れ、`npm run index` が初回から通ります
- 答えの途中で窓を閉じられたときに、Anthropic への問い合わせも打ち切るようにしました（続きは課金されません）
- キャッシュの区切りのもち時間を、案内の文（system）と文書で 1 時間にそろえました（前の区切りが短いと、後ろの長い区切りが使えません）
- 窓の設定（`{endpoint}/config`）は、窓を初めて開いたときに 1 回だけ読むようにしました。ページを見ただけではサーバーが動きません。応答は 5 分だけ手元に置けるようにしています
- 「担当者に問い合わせる」は、「資料に載っていません」と伝えたときと失敗したときだけ出すようにしました。出典が付かなかっただけの答えは、そのままお見せします
- `TRUST_PROXY=1` のときに見る `x-forwarded-for` を、先頭ではなく末尾（proxy が足した値）に変えました。訪問者が先頭に名乗っても上限をすり抜けられません

### 発売前の見直し（2026-09-18）

- 1 分の上限で断った要求では、1 時間の枠を減らさないようにしました。連打した相手が 1 時間まるごと締め出されることがなくなります。版は 1.0.0 のままです

### 発売前の見直し（2026-09-19）

- 短い節を合わせて 1 片にしたとき、根拠の題が先頭の節の見出しになっていたのを、文書の題名だけに直しました。後ろの節から答えたときに、根拠の題がずれなくなります（先頭の見出しは片の本文に残ります）。版は 1.0.0 のままです

## 予定
- 索引の差分更新（変わった文書だけ作り直す）
- 窓の多言語切り替え
- 答えの評価を続けて記録する画面
