import { copyFile } from "node:fs/promises";
import { defineConfig } from "tsup";

export default defineConfig([
  // 1) npm と Next.js から使うサーバー部品。SDK は外に出す
  {
    entry: { index: "src/index.ts", "adapters/node": "src/adapters/node.ts" },
    format: ["esm", "cjs"],
    dts: { entry: { index: "src/index.ts" } },
    sourcemap: false,
    clean: true,
    target: "node22",
    platform: "node",
    external: ["@anthropic-ai/sdk"],
    // adapters/node.ts の import.meta.url を cjs 出力でも使えるようにする（cjs 用の import.meta shim を注入）
    shims: true,
    // 窓の CSS は束にせず、そのまま dist へ置く（<link> 1 本で読ませる）
    async onSuccess() {
      await copyFile("src/widget/widget.css", "dist/ai-concierge.css");
    },
  },
  // 2) 索引づくりのコマンド
  {
    entry: { cli: "src/indexer/cli.ts" },
    format: ["esm"],
    sourcemap: false,
    target: "node22",
    platform: "node",
    external: ["@anthropic-ai/sdk"],
    banner: { js: "#!/usr/bin/env node" },
  },
  // 3) 窓。素の HTML から <script> 1 本で読む
  {
    entry: { "ai-concierge": "src/widget/widget.ts" },
    format: ["iife"],
    globalName: "AIConcierge",
    // tsup の iife は既定で .global.js になる。package.json の exports と README のとおり ai-concierge.js にする
    outExtension: () => ({ js: ".js" }),
    minify: true,
    sourcemap: false,
    target: "es2020",
    platform: "browser",
  },
]);
