#!/usr/bin/env node
// dist を含む配布 zip を release/ に作る。「手元で動かす」と改造ができるよう、
// src / test / eval / scripts も入れる。node_modules は入れない。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/ai-concierge-v${pkg.version}.zip`;

for (const file of ["dist/index.js", "dist/cli.js", "dist/ai-concierge.js", "dist/ai-concierge.css", "dist/adapters/node.js"]) {
  if (!existsSync(file)) {
    console.error(`${file} が無い。先に npm run build`);
    process.exit(1);
  }
}
if (!existsSync("samples/content/about.md")) {
  console.error("samples が無い。リポジトリの取り込み漏れ");
  process.exit(1);
}

// テンプレは templates/nextjs/vendor/ の tgz からキット本体を取り込む形にしてある
// （package.json は file:./vendor/suminawa-ai-concierge-<version>.tgz を指す）。
// 配布 zip には、いま作った dist を反映した tgz を入れ直してから固める。
execFileSync("npm", ["pack", "--pack-destination", "templates/nextjs/vendor"], { stdio: "inherit" });
const tgzName = `${pkg.name.replace(/^@/, "").replace(/\//g, "-")}-${pkg.version}.tgz`;
const tgzPath = `templates/nextjs/vendor/${tgzName}`;
if (!existsSync(tgzPath)) {
  console.error(`${tgzPath} が無い。npm pack --pack-destination templates/nextjs/vendor に失敗しています`);
  process.exit(1);
}

mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

execFileSync(
  "zip",
  [
    "-r",
    out,
    "dist",
    "src",
    "test",
    "demo",
    "templates",
    "samples",
    "eval/questions.json",
    "eval/run.ts",
    "scripts",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "tsup.config.ts",
    "vitest.config.ts",
    ".gitignore",
    "README.ja.md",
    "LICENSE.md",
    "CHANGELOG.md",
    "-x",
    "*.DS_Store",
    "-x",
    "*/node_modules/*",
    "-x",
    "eval/results/*",
  ],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
