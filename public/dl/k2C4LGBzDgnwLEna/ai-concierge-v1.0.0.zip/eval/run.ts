// npm run eval で動きます（先に npm run build が走ります）。
// 索引づくりから取り出しまでを見本の文書で通し、recall@k を測ります。
// --judge を付けると、実際に答えさせて「文書だけに基づいているか」も採点します（API キーが必要です）。
import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import Anthropic from "@anthropic-ai/sdk";
import {
  buildIndexFile,
  buildPrompt,
  chunkDocument,
  createAnthropicClient,
  loadConfigFile,
  parseMarkdown,
  recallOf,
  resolveConfig,
  retrieve,
  streamAnswer,
  summarize,
  toLoadedIndex,
  type ConciergeConfig,
  type EvalOutcome,
  type EvalQuestion,
  type EvalSummary,
  type LoadedIndex,
} from "../dist/index.js";

const JUDGE_MODEL = "claude-opus-5";
const SAMPLE_CONFIG_PATH = "samples/concierge.config.json";
/** この数値を下回ると不合格（recall・根拠性とも） */
const PASS_LINE = 0.9;
/** k を変えても取りこぼしが分かるように、既定の topK とは別にいつも測る参考値 */
const REFERENCE_TOP_K = 8;

function argOf(name: string, fallback: string): string {
  const at = process.argv.indexOf(name);
  return at === -1 || process.argv[at + 1] === undefined ? fallback : process.argv[at + 1];
}

/** samples/concierge.config.json を読み、retrieval.topK だけを差し替える */
async function sampleConfig(topK: number): Promise<ConciergeConfig> {
  const file = await loadConfigFile(SAMPLE_CONFIG_PATH);
  const record = (file ?? {}) as Record<string, unknown>;
  const retrievalRaw = (record.retrieval ?? {}) as Record<string, unknown>;
  return resolveConfig({ file: { ...record, retrieval: { ...retrievalRaw, topK } }, env: process.env });
}

async function loadIndex(dir: string): Promise<LoadedIndex> {
  const names = (await readdir(dir)).filter((name) => name.endsWith(".md")).sort();
  const drafts = [];
  for (const name of names) {
    drafts.push(chunkDocument(parseMarkdown(await readFile(`${dir}/${name}`, "utf8"), name.replace(/\.md$/, ""))));
  }
  return toLoadedIndex(buildIndexFile(drafts, new Date().toISOString()));
}

function recallSummaryOf(
  index: LoadedIndex,
  config: ConciergeConfig,
  questions: EvalQuestion[],
): { outcomes: EvalOutcome[]; summary: EvalSummary } {
  const outcomes: EvalOutcome[] = questions.map((question) => {
    const got = retrieve({ index, config, question: question.question, history: [], mode: "bm25" }).entries.map(
      (entry) => entry.doc.id,
    );
    return {
      id: question.id,
      question: question.question,
      expect: question.expect,
      got: [...new Set(got)],
      recall: recallOf(question.expect, got),
    };
  });
  return { outcomes, summary: summarize(outcomes) };
}

/** 答えが添えた文書だけに基づいているかを 0 か 1 で採点させる */
async function judge(apiKey: string, documents: string, question: string, answer: string): Promise<number> {
  const client = new Anthropic({ apiKey });
  const response = await client.messages.create({
    model: JUDGE_MODEL,
    max_tokens: 16,
    output_config: { effort: "low" },
    system:
      "あなたは採点者です。答えが、与えられた資料だけに基づいているかを判定します。資料に無い事実・数字・条件が混じっていれば 0、資料の範囲に収まっていれば 1 とします。資料に無いと断っている答えも 1 です。数字だけを返してください。",
    messages: [
      { role: "user", content: `【資料】\n${documents}\n\n【質問】\n${question}\n\n【答え】\n${answer}\n\n0 か 1 だけを返してください。` },
    ],
  });
  if (response.stop_reason === "refusal") return 0;
  const text = response.content.find((block) => block.type === "text");
  return text !== undefined && text.text.includes("1") ? 1 : 0;
}

async function main(): Promise<void> {
  const topK = Number(argOf("--top-k", "4"));
  const wantsJudge = process.argv.includes("--judge");
  const apiKey = (process.env.ANTHROPIC_API_KEY ?? "").trim();
  const judgeKeyMissing = wantsJudge && apiKey === "";
  if (judgeKeyMissing) {
    console.log("--judge には ANTHROPIC_API_KEY が必要です。根拠性は測っていません。");
  }

  const config = await sampleConfig(topK);
  const config8 = await sampleConfig(REFERENCE_TOP_K);
  const index = await loadIndex(config.content);
  const questions = JSON.parse(await readFile("eval/questions.json", "utf8")) as EvalQuestion[];

  const { outcomes, summary } = recallSummaryOf(index, config, questions);
  const { summary: summaryAt8 } = recallSummaryOf(index, config8, questions);

  // null は「採点しようとして失敗した」印。平均は null を無視して出す
  const grounded: (number | null)[] = [];

  if (wantsJudge && apiKey !== "") {
    for (const question of questions) {
      try {
        const whole = retrieve({ index, config, question: question.question, history: [] });
        const { params, sources } = buildPrompt({ config, entries: whole.entries, question: question.question, history: [] });
        const answer = await streamAnswer({ client: createAnthropicClient(apiKey), params, sources, onEvent: () => {} });
        const documents = whole.entries.map((entry, i) => `[${i + 1}] ${entry.chunk.breadcrumb}\n${entry.chunk.text}`).join("\n\n");
        grounded.push(await judge(apiKey, documents, question.question, answer.text));
        process.stdout.write(".");
      } catch (error) {
        grounded.push(null);
        const message = error instanceof Error ? error.message : String(error);
        console.log(`\n${question.id} の根拠性を測れませんでした: ${message}`);
      }
    }
    process.stdout.write("\n");
  }

  const groundedScores = grounded.filter((score): score is number => score !== null);
  const groundedness = groundedScores.length === 0 ? null : groundedScores.reduce((sum, score) => sum + score, 0) / groundedScores.length;

  console.log("");
  console.log(`索引: 文書 ${index.stats.documents} 本・片 ${index.stats.chunks} 個・概算 ${index.stats.totalTokens} トークン`);
  console.log(
    `recall@${topK}: ${summary.recall.toFixed(3)}（${summary.questions} 問、索引 ${index.stats.chunks} 片、合格線 ${PASS_LINE.toFixed(3)}）`,
  );
  console.log(
    `recall@${REFERENCE_TOP_K}（参考）: ${summaryAt8.recall.toFixed(3)}（${summaryAt8.questions} 問、索引 ${index.stats.chunks} 片）`,
  );
  if (summary.misses.length > 0) {
    console.log(`取りこぼし: ${summary.misses.join(", ")}`);
    for (const outcome of outcomes.filter((item) => item.recall < 1)) {
      console.log(`  ${outcome.id} ${outcome.question}  期待 ${outcome.expect.join("/")}  取れた ${outcome.got.join("/") || "なし"}`);
    }
  }
  if (groundedness === null) {
    console.log(
      judgeKeyMissing
        ? "根拠性: 測っていません（ANTHROPIC_API_KEY が無いためです）"
        : "根拠性: 測っていません（--judge と ANTHROPIC_API_KEY で測れます）",
    );
  } else {
    console.log(`根拠性: ${groundedness.toFixed(3)}（合格線 ${PASS_LINE.toFixed(3)}）`);
  }

  const at = new Date().toISOString().slice(0, 10);
  await mkdir("eval/results", { recursive: true });
  await writeFile(
    `eval/results/${at}.json`,
    `${JSON.stringify(
      { at, topK, corpusChunks: index.stats.chunks, summary, recallAt8: summaryAt8, groundedness, grounded, outcomes },
      null,
      2,
    )}\n`,
    "utf8",
  );
  console.log(`eval/results/${at}.json に残しました。`);

  if (summary.recall < PASS_LINE || (groundedness !== null && groundedness < PASS_LINE) || judgeKeyMissing) {
    process.exitCode = 1;
  }
}

await main();
