import { describe, expect, it } from "vitest";
import type { LogEntry } from "./log";
import {
  ANSWER_HEAD_CHARS,
  createLogRing,
  headOf,
  LOG_RING_SIZE,
  postWebhook,
  redact,
  toCsv,
  webhookPayload,
  WEBHOOK_TIMEOUT_MS,
} from "./log";

function entryOf(patch: Partial<LogEntry> = {}): LogEntry {
  return {
    id: 1,
    at: "2026-09-12T03:00:00.000Z",
    question: "対応エリアはどこまでですか",
    answerHead: "市内と隣の三市にお伺いしております。",
    sources: [1, 2],
    answered: true,
    ms: 1234,
    model: "claude-opus-5",
    inputTokens: 30000,
    outputTokens: 120,
    cacheReadTokens: 29800,
    truncated: false,
    disconnected: false,
    ...patch,
  };
}

describe("redact", () => {
  it("メールアドレスを伏せる", () => {
    expect(redact("連絡先は taro.yamada+test@example.co.jp です")).toBe("連絡先は ***@*** です");
  });

  it("電話番号らしい並びを伏せる", () => {
    expect(redact("090-1234-5678 にかけてください")).toBe("*** にかけてください");
    expect(redact("03-1234-5678")).toBe("***");
    expect(redact("09012345678")).toBe("***");
  });

  it("日付や金額はそのまま", () => {
    expect(redact("2026-09-12 に 800000 円で")).toBe("2026-09-12 に 800000 円で");
  });

  it("0 で始まらない 9 桁以上の数字も伏せる", () => {
    expect(redact("受付番号は 123456789 です")).toBe("受付番号は *** です");
    expect(redact("12345678 は 8 桁なのでそのまま")).toBe("12345678 は 8 桁なのでそのまま");
  });
});

describe("headOf", () => {
  it("先頭 200 字で切る", () => {
    expect(ANSWER_HEAD_CHARS).toBe(200);
    expect(headOf("あ".repeat(250)).length).toBe(200);
    expect(headOf("短い答え")).toBe("短い答え");
    expect(headOf("あいうえお", 3)).toBe("あい…");
  });
});

describe("createLogRing", () => {
  it("新しいものから並べる", () => {
    const ring = createLogRing();
    ring.push(entryOf({ id: 1 }));
    ring.push(entryOf({ id: 2 }));
    expect(ring.list().map((entry) => entry.id)).toEqual([2, 1]);
    expect(ring.size()).toBe(2);
  });

  it("答えられなかったものだけ取り出せる", () => {
    const ring = createLogRing();
    ring.push(entryOf({ id: 1, answered: true }));
    ring.push(entryOf({ id: 2, answered: false }));
    ring.push(entryOf({ id: 3, answered: false }));
    expect(ring.unanswered().map((entry) => entry.id)).toEqual([3, 2]);
  });

  it("上限を超えたら古いものから消える", () => {
    expect(LOG_RING_SIZE).toBe(500);
    const ring = createLogRing(2);
    ring.push(entryOf({ id: 1 }));
    ring.push(entryOf({ id: 2 }));
    ring.push(entryOf({ id: 3 }));
    expect(ring.list().map((entry) => entry.id)).toEqual([3, 2]);
    expect(ring.size()).toBe(2);
  });
});

describe("webhookPayload", () => {
  it("json の形", () => {
    expect(webhookPayload(entryOf(), "json", "みなと工務店")).toEqual({
      site: "みなと工務店",
      at: "2026-09-12T03:00:00.000Z",
      question: "対応エリアはどこまでですか",
      answerHead: "市内と隣の三市にお伺いしております。",
      answered: true,
      sources: [1, 2],
      ms: 1234,
      model: "claude-opus-5",
      tokens: { input: 30000, output: 120, cacheRead: 29800 },
    });
  });

  it("slack は 1 つの text にまとめる", () => {
    expect(webhookPayload(entryOf({ answered: false, sources: [] }), "slack", "みなと工務店")).toEqual({
      text: [
        "［みなと工務店 案内窓口］未回答",
        "質問: 対応エリアはどこまでですか",
        "答え: 市内と隣の三市にお伺いしております。",
        "出典: なし / 1234 ms / claude-opus-5",
      ].join("\n"),
    });
  });

  it("slack の答えられたときの見出し", () => {
    const payload = webhookPayload(entryOf(), "slack", "みなと工務店") as { text: string };
    expect(payload.text.startsWith("［みなと工務店 案内窓口］回答")).toBe(true);
    expect(payload.text).toContain("出典: [1] [2] / 1234 ms / claude-opus-5");
  });
});

describe("postWebhook", () => {
  it("JSON で POST する", async () => {
    const calls: Array<[string, RequestInit | undefined]> = [];
    const fake = (async (url: string, init?: RequestInit) => {
      calls.push([url, init]);
      return new Response("", { status: 200 });
    }) as unknown as typeof fetch;
    expect(await postWebhook("https://hooks.example.com/a", { text: "あ" }, fake)).toBe(true);
    expect(calls[0][0]).toBe("https://hooks.example.com/a");
    expect(calls[0][1]?.method).toBe("POST");
    expect(calls[0][1]?.body).toBe('{"text":"あ"}');
  });

  it("失敗しても例外にしない（答えを止めない）", async () => {
    const fake = (async () => {
      throw new Error("network");
    }) as unknown as typeof fetch;
    expect(await postWebhook("https://hooks.example.com/a", {}, fake)).toBe(false);
  });

  it("応答が返って来なくても、時間切れで待つのをやめる", async () => {
    expect(WEBHOOK_TIMEOUT_MS).toBe(5000);
    // signal を見ない実装でも、こちら側の時間切れで確実に切り上がることを確かめる
    const fake = (async () => new Promise<Response>(() => {})) as unknown as typeof fetch;
    const result = await postWebhook("https://hooks.example.com/a", {}, fake, 20);
    expect(result).toBe(false);
  });
});

describe("toCsv", () => {
  it("見出しと 1 行を書き出す", () => {
    expect(toCsv([entryOf({ question: 'エアコンは"標準"ですか' })])).toBe(
      [
        "受付日時,質問,答えの先頭,出典,答えられたか,所要ms,モデル,入力トークン,出力トークン,キャッシュ読み,途中で切れた,途中で切断",
        '2026-09-12T03:00:00.000Z,"エアコンは""標準""ですか",市内と隣の三市にお伺いしております。,1 2,はい,1234,claude-opus-5,30000,120,29800,いいえ,いいえ',
        "",
      ].join("\n"),
    );
  });

  it("途中で切れた・途中で切断は、それぞれの列に出る", () => {
    expect(toCsv([entryOf({ truncated: true })]).split("\n")[1].endsWith(",29800,はい,いいえ")).toBe(true);
    expect(toCsv([entryOf({ disconnected: true })]).split("\n")[1].endsWith(",29800,いいえ,はい")).toBe(true);
  });

  it("式に見える先頭文字は ' を付けて文字列にする（表計算ソフトでの式の実行を防ぐ）", () => {
    const csv = toCsv([entryOf({ question: '=HYPERLINK("http://example.com","x")' }), entryOf({ question: "+1+1" })]);
    const rows = csv.split("\n");
    expect(rows[1]).toContain(`"'=HYPERLINK(""http://example.com"",""x"")"`);
    expect(rows[2]).toContain(",'+1+1,");
  });
});
