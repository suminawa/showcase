import { streamAnswer, UNAVAILABLE_MESSAGE } from "./answer";
import { createAnthropicClient } from "./client";
import { checkDaily, checkInput, checkOrigin, checkRate, createGuardState, GUARD_MESSAGES, type GuardState } from "./guard";
import { emptyIndex } from "./index-store";
import { createLogRing, headOf, postWebhook, redact, toCsv, webhookPayload, type LogEntry, type LogSink } from "./log";
import { buildPrompt } from "./prompt";
import { retrieve, retrievalMode } from "./retrieve";
import type {
  AnthropicClientLike,
  ChatEvent,
  ChatTurn,
  ConciergeConfig,
  LoadedIndex,
  MessageStreamLike,
  WidgetLabels,
} from "./types";

export type Route = "chat" | "config" | "health" | "admin" | "admin-export" | "none";

export interface ConciergeDeps {
  client?: AnthropicClientLike;
  index?: LoadedIndex;
  now?: () => number;
  fetch?: typeof fetch;
  log?: LogSink;
  guard?: GuardState;
}

export interface Concierge {
  fetch(request: Request): Promise<Response>;
  config: ConciergeConfig;
  index: LoadedIndex;
  log: LogSink;
}

const HISTORY_MAX = 12;
const HISTORY_CHARS = 1000;
/** これを超える本文は読まずに 413。Node アダプタ側の上限と合わせてある */
export const MAX_BODY_BYTES = 64 * 1024;

export function routeOf(pathname: string): Route {
  const path = pathname.replace(/\/+$/, "");
  if (path.endsWith("/admin/export")) return "admin-export";
  if (path.endsWith("/admin")) return "admin";
  if (path.endsWith("/health")) return "health";
  if (path.endsWith("/config")) return "config";
  if (path.endsWith("/chat")) return "chat";
  return "none";
}

/** 窓が起動時に読む、公開してよい文言だけの塊（鍵も上限も入れない） */
export interface WidgetConfigResponse {
  greeting: string;
  suggestions: string[];
  contactUrl: string | null;
  labels: Partial<WidgetLabels>;
}

export function widgetConfigOf(config: ConciergeConfig): WidgetConfigResponse {
  return {
    greeting: config.greeting,
    suggestions: config.suggestions,
    contactUrl: config.contactUrl,
    labels: config.labels,
  };
}

/** Node アダプタが接続元のアドレスを入れるヘッダー。訪問者が名乗った値は必ず上書きされる */
export const REMOTE_ADDR_HEADER = "x-concierge-remote-addr";

/**
 * 回数を数えるための相手の見分け。信じられる材料しか使わない。
 *
 * - `trustProxy` が true のとき（前段の proxy が x-forwarded-for を書き換えている場合）は、
 *   proxy が伝える訪問者のアドレスを使う
 * - そうでなければ、アダプタが入れた接続元のアドレスだけを使う。訪問者が名乗る
 *   x-forwarded-for は見ない（見てしまうと、名前を変えるだけで上限をすり抜けられる）
 * - どちらも無ければ "unknown"。この場合は全員で 1 つの枠を分け合うことになる
 */
export function clientIpOf(request: Request, trustProxy: boolean = false): string {
  if (trustProxy) {
    const forwarded = request.headers.get("x-forwarded-for");
    // 信頼する proxy は末尾に本当の接続元を足す（nginx の $proxy_add_x_forwarded_for も同じ）。先頭は訪問者が書ける
    if (forwarded !== null && forwarded.trim() !== "") {
      const parts = forwarded.split(",").map((part) => part.trim()).filter((part) => part !== "");
      if (parts.length > 0) return parts[parts.length - 1];
    }
    const real = request.headers.get("x-real-ip")?.trim();
    if (real !== undefined && real !== "") return real;
  }
  return request.headers.get(REMOTE_ADDR_HEADER)?.trim() || "unknown";
}

export function parseChatBody(value: unknown, maxInputChars: number): { question: string; history: ChatTurn[] } {
  const raw = (typeof value === "object" && value !== null ? value : {}) as Record<string, unknown>;
  if (typeof raw.question !== "string") throw new Error("question は文字列で送ってください");
  const history: ChatTurn[] = [];
  if (Array.isArray(raw.history)) {
    for (const item of raw.history) {
      const turn = (typeof item === "object" && item !== null ? item : {}) as Record<string, unknown>;
      if (turn.role !== "user" && turn.role !== "assistant") continue;
      if (typeof turn.content !== "string") continue;
      history.push({ role: turn.role, content: turn.content.slice(0, HISTORY_CHARS) });
    }
  }
  return { question: raw.question.slice(0, maxInputChars + 1), history: history.slice(-HISTORY_MAX) };
}

export function sseLine(event: ChatEvent): string {
  return `data: ${JSON.stringify(event)}\n\n`;
}

export function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function adminHtml(
  config: ConciergeConfig,
  entries: LogEntry[],
  unansweredOnly: boolean,
  token: string | null = null,
): string {
  // 合い言葉を先にリンクへ埋め込む。出来上がった HTML に対して差し替えると、
  // ご質問の中に同じ印が入っていた場合にそこまで置き換わってしまう
  const query = token === null ? "" : `token=${encodeURIComponent(token)}`;
  const allHref = query === "" ? "?" : `?${query}`;
  const unansweredHref = query === "" ? "?unanswered=1" : `?${query}&amp;unanswered=1`;
  const exportHref = query === "" ? "export" : `export?${query}`;
  const rows = entries
    .map(
      (entry) => `<tr${entry.answered ? "" : ' class="ng"'}>
<td>${escapeHtml(entry.at)}</td>
<td>${escapeHtml(entry.question)}</td>
<td>${escapeHtml(entry.answerHead)}</td>
<td>${entry.sources.map((index) => `[${index}]`).join(" ")}</td>
<td>${entry.answered ? "回答" : "未回答"}</td>
<td>${entry.ms}</td>
<td>${entry.cacheReadTokens}</td>
<td>${entry.truncated ? "はい" : ""}</td>
</tr>`,
    )
    .join("\n");
  const empty = "<tr><td colspan=\"8\">まだ記録がありません。</td></tr>";
  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>案内窓口の記録（${escapeHtml(config.site.name)}）</title>
<style>
body { font-family: system-ui, sans-serif; margin: 0 auto; max-width: 60rem; padding: 2rem 1rem; color: #1b1b1b; }
h1 { font-size: 1.25rem; }
p { color: #555; }
table { border-collapse: collapse; width: 100%; font-size: 0.875rem; }
th, td { border-bottom: 1px solid #ddd; padding: 0.5rem; text-align: left; vertical-align: top; }
tr.ng { background: #fff7f0; }
nav a { margin-right: 1rem; }
</style>
</head>
<body>
<h1>案内窓口の記録（${escapeHtml(config.site.name)}）</h1>
<p>${unansweredOnly ? "未回答のみ" : "直近の記録"}を新しい順に表示しています。お答えできなかったご質問は、資料を足す目安としてお使いください。「キャッシュ読み」は、資料をキャッシュから読めたトークン数です。ここに数が入っていれば、その回は資料を送り直さずに済んでいます。「途中で切れた」に「はい」が並ぶときは、<code>answer.maxTokens</code> を増やすか <code>answer.style</code> を短くしてください。</p>
<nav>
<a href="${allHref}">すべて</a>
<a href="${unansweredHref}">未回答のみ</a>
<a href="${exportHref}">CSV で書き出す</a>
</nav>
<table>
<thead><tr><th>受付日時</th><th>ご質問</th><th>答えの先頭</th><th>出典</th><th>結果</th><th>所要 ms</th><th>キャッシュ読み</th><th>途中で切れた</th></tr></thead>
<tbody>
${rows === "" ? empty : rows}
</tbody>
</table>
</body>
</html>
`;
}

function jsonResponse(body: unknown, status: number, headers: Record<string, string>): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers },
  });
}

export function createConcierge(config: ConciergeConfig, deps: ConciergeDeps = {}): Concierge {
  const index = deps.index ?? emptyIndex("1970-01-01T00:00:00.000Z");
  const log = deps.log ?? createLogRing();
  const guard = deps.guard ?? createGuardState();
  const now = deps.now ?? (() => Date.now());
  const doFetch = deps.fetch ?? fetch;
  const client = deps.client ?? (config.apiKey === null ? null : createAnthropicClient(config.apiKey));
  let logId = 0;

  const corsOf = (request: Request): Record<string, string> => {
    const origin = request.headers.get("origin");
    if (origin === null) return {};
    if (!checkOrigin(origin, config.allowedOrigins, new URL(request.url).origin).ok) return {};
    return { "access-control-allow-origin": origin, vary: "Origin" };
  };

  const authorized = (request: Request, url: URL): boolean => {
    if (config.adminToken === null) return false;
    const bearer = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
    return url.searchParams.get("token") === config.adminToken || bearer === config.adminToken;
  };

  async function handleChat(request: Request, url: URL): Promise<Response> {
    const cors = corsOf(request);
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          ...cors,
          "access-control-allow-methods": "POST, OPTIONS",
          "access-control-allow-headers": "content-type",
          "access-control-max-age": "86400",
        },
      });
    }
    if (request.method !== "POST") {
      return jsonResponse({ ok: false, code: "unavailable", message: "POST で送ってください。" }, 405, cors);
    }

    const origin = checkOrigin(request.headers.get("origin"), config.allowedOrigins, url.origin);
    if (!origin.ok) return jsonResponse({ ok: false, code: origin.code, message: origin.message }, origin.status, cors);

    // content-length で分かる分は本文を読む前に断る。無い／偽っている場合は実測で後段が拾う
    const contentLengthHeader = request.headers.get("content-length");
    if (contentLengthHeader !== null) {
      const contentLength = Number(contentLengthHeader);
      if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
        return jsonResponse({ ok: false, code: "too_long", message: GUARD_MESSAGES.tooLarge }, 413, cors);
      }
    }

    let bodyText: string;
    try {
      bodyText = await request.text();
    } catch {
      return jsonResponse({ ok: false, code: "unavailable", message: "ご質問を読み取れませんでした。" }, 400, cors);
    }
    if (new TextEncoder().encode(bodyText).length > MAX_BODY_BYTES) {
      return jsonResponse({ ok: false, code: "too_long", message: GUARD_MESSAGES.tooLarge }, 413, cors);
    }

    let body: { question: string; history: ChatTurn[] };
    try {
      body = parseChatBody(JSON.parse(bodyText), config.limits.maxInputChars);
    } catch {
      return jsonResponse({ ok: false, code: "unavailable", message: "ご質問を読み取れませんでした。" }, 400, cors);
    }

    const input = checkInput(body.question, config.limits.maxInputChars);
    if (!input.ok) return jsonResponse({ ok: false, code: input.code, message: input.message }, input.status, cors);

    const at = now();
    const rate = checkRate(guard, clientIpOf(request, config.trustProxy), config.limits, at);
    if (!rate.ok) return jsonResponse({ ok: false, code: rate.code, message: rate.message }, rate.status, cors);
    const daily = checkDaily(guard, config.limits, at);
    if (!daily.ok) return jsonResponse({ ok: false, code: daily.code, message: daily.message }, daily.status, cors);

    const found = retrieve({ index, config, question: body.question, history: body.history });
    const { params, sources } = buildPrompt({ config, entries: found.entries, question: body.question, history: body.history });

    const record = async (
      answered: boolean,
      text: string,
      citations: number[],
      usage: { inputTokens: number; outputTokens: number; cacheReadTokens: number },
      flags: { truncated?: boolean; disconnected?: boolean } = {},
    ): Promise<void> => {
      logId += 1;
      const entry: LogEntry = {
        id: logId,
        at: new Date(at).toISOString(),
        question: redact(body.question),
        answerHead: headOf(redact(text)),
        sources: citations,
        answered,
        ms: now() - at,
        model: config.answer.model,
        inputTokens: usage.inputTokens,
        outputTokens: usage.outputTokens,
        cacheReadTokens: usage.cacheReadTokens,
        truncated: flags.truncated ?? false,
        disconnected: flags.disconnected ?? false,
      };
      log.push(entry);
      if (config.logWebhookUrl !== null) {
        await postWebhook(config.logWebhookUrl, webhookPayload(entry, config.logWebhookFormat, config.site.name), doFetch);
      }
    };

    const encoder = new TextEncoder();
    // 訪問者が窓を閉じた（切断した）かどうか。止まった後は書き込まず、記録にだけ残す
    let disconnected = false;
    let upstream: MessageStreamLike | null = null;
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (event: ChatEvent): void => {
          if (disconnected) return;
          try {
            controller.enqueue(encoder.encode(sseLine(event)));
          } catch {
            // 相手が閉じたあとの書き込み。以降は書かない
            disconnected = true;
          }
        };
        try {
          if (client === null) {
            send({ type: "error", code: "unavailable", message: UNAVAILABLE_MESSAGE });
            send({ type: "done", answered: false });
            await record(false, "", [], { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0 });
            return;
          }
          const result = await streamAnswer({
            client,
            params,
            sources,
            onEvent: send,
            onStream: (upstreamStream) => {
              upstream = upstreamStream;
            },
          });
          await record(result.answered, result.text, result.citations, result.usage, {
            truncated: result.truncated,
            disconnected,
          });
        } finally {
          if (!disconnected) {
            try {
              controller.close();
            } catch {
              // すでに閉じている
            }
          }
        }
      },
      cancel() {
        // 窓を閉じられたら、上流（Anthropic への問い合わせ）も止める。
        // 止めないと、誰も読まない答えの続きが最後まで課金される
        disconnected = true;
        upstream?.abort?.();
      },
    });

    return new Response(stream, {
      status: 200,
      headers: {
        ...cors,
        "content-type": "text/event-stream; charset=utf-8",
        "cache-control": "no-store",
        connection: "keep-alive",
        "x-accel-buffering": "no",
      },
    });
  }

  return {
    config,
    index,
    log,
    async fetch(request: Request): Promise<Response> {
      const url = new URL(request.url);
      const route = routeOf(url.pathname);

      if (route === "chat") return handleChat(request, url);

      if (route === "config") {
        const cors = corsOf(request);
        if (request.method === "OPTIONS") {
          return new Response(null, {
            status: 204,
            headers: {
              ...cors,
              "access-control-allow-methods": "GET, OPTIONS",
              "access-control-allow-headers": "content-type",
              "access-control-max-age": "86400",
            },
          });
        }
        // /chat と同じ送信元の決まりを使う（合い言葉は要りません。窓の文言しか入っていません）
        const origin = checkOrigin(request.headers.get("origin"), config.allowedOrigins, url.origin);
        if (!origin.ok) return jsonResponse({ ok: false, code: origin.code, message: origin.message }, origin.status, cors);
        if (request.method !== "GET") {
          return jsonResponse({ ok: false, code: "unavailable", message: "GET で読み取ってください。" }, 405, cors);
        }
        // 文言は変わらないので、ページを開くたびに関数を起こさない（5 分は手元に置いてよい）
        return jsonResponse(widgetConfigOf(config), 200, { ...cors, "cache-control": "public, max-age=300" });
      }

      if (route === "health") {
        return jsonResponse(
          {
            ok: true,
            documents: index.stats.documents,
            chunks: index.stats.chunks,
            totalTokens: index.stats.totalTokens,
            mode: retrievalMode(index, config.retrieval.wholeCorpusMaxTokens),
            builtAt: index.file.builtAt,
          },
          200,
          corsOf(request),
        );
      }

      if (route === "admin" || route === "admin-export") {
        if (config.adminToken === null) return new Response("Not Found", { status: 404 });
        if (!authorized(request, url)) {
          return jsonResponse({ ok: false, code: "forbidden", message: "合い言葉が違います。" }, 401, {});
        }
        const unansweredOnly = url.searchParams.get("unanswered") === "1";
        const entries = unansweredOnly ? log.unanswered() : log.list();
        if (route === "admin-export") {
          return new Response(toCsv(entries), {
            status: 200,
            headers: {
              "content-type": "text/csv; charset=utf-8",
              "content-disposition": 'attachment; filename="ai-concierge-log.csv"',
              "cache-control": "no-store",
            },
          });
        }
        return new Response(adminHtml(config, entries, unansweredOnly, config.adminToken), {
          status: 200,
          headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
        });
      }

      return new Response("Not Found", { status: 404 });
    },
  };
}
