import type {
  AnswerUsage,
  AnthropicClientLike,
  ChatEvent,
  CitationLike,
  FinalMessageLike,
  MessageParams,
  MessageStreamLike,
  PromptSource,
} from "./types";

export const UNAVAILABLE_MESSAGE = "いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。";
/** system prompt に書く「無いときの言い方」。prompt.ts がこの言い方をお願いする */
export const NOT_IN_DOCUMENTS = "資料に載っていません";
/**
 * 「資料に無い」と伝えた答えの見分け。
 * 敬体で書くモデルは言い方を変えてくるので、お願いした 1 通りだけでは取りこぼす。
 * 言い方に頼りきらないよう、出典が 1 つも付かなかったことも合わせて見ている（下記 answered）。
 */
export const NOT_IN_DOCUMENTS_RE =
  /資料に(は)?(載っていません|見当たりません|記載がございません|ございません)|お答えできかねます/;
/** max_tokens で切れた答えの末尾に足す印 */
export const TRUNCATED_SUFFIX = "…";

export interface AnswerInput {
  client: AnthropicClientLike;
  params: MessageParams;
  sources: PromptSource[];
  onEvent: (event: ChatEvent) => void;
  /**
   * 始まった問い合わせを外から止められるように渡す。
   * 訪問者が窓を閉じたとき、呼び出し側が abort() を呼ぶ。
   */
  onStream?: (stream: MessageStreamLike) => void;
}

export interface AnswerResult {
  answered: boolean;
  text: string;
  citations: number[];
  usage: AnswerUsage;
  stopReason: string | null;
  error: string | null;
  /** max_tokens に当たって途中で切れたか */
  truncated: boolean;
}

export function usageOf(final: FinalMessageLike | null): AnswerUsage {
  const usage = final?.usage;
  return {
    inputTokens: usage?.input_tokens ?? 0,
    outputTokens: usage?.output_tokens ?? 0,
    cacheReadTokens: usage?.cache_read_input_tokens ?? 0,
    cacheCreationTokens: usage?.cache_creation_input_tokens ?? 0,
  };
}

/** document_index は 0 始まり。窓に出す番号は 1 始まり */
export function citationIndexOf(citation: CitationLike): number {
  return citation.document_index + 1;
}

export async function streamAnswer(input: AnswerInput): Promise<AnswerResult> {
  const { client, params, sources, onEvent } = input;
  const byIndex = new Map(sources.map((source) => [source.index, source]));
  const citations: number[] = [];
  let text = "";
  let final: FinalMessageLike | null = null;
  let error: string | null = null;

  const addCitation = (citation: CitationLike): void => {
    const index = citationIndexOf(citation);
    const source = byIndex.get(index);
    // 送っていない番号は捨てる（窓のリンクが迷子にならないように）
    if (source === undefined || citations.includes(index)) return;
    citations.push(index);
    onEvent({ type: "citation", index, title: source.breadcrumb, url: source.url });
  };

  try {
    const stream = client.messages.stream(params);
    input.onStream?.(stream);
    for await (const event of stream) {
      if (event.type !== "content_block_delta" || event.delta === undefined) continue;
      if (event.delta.type === "text_delta" && event.delta.text !== undefined) {
        text += event.delta.text;
        onEvent({ type: "text", text: event.delta.text });
        continue;
      }
      if (event.delta.type === "citations_delta" && event.delta.citation !== undefined) {
        addCitation(event.delta.citation);
      }
    }
    final = await stream.finalMessage();
  } catch (failure) {
    error = failure instanceof Error ? failure.message : String(failure);
  }

  // 流れて来なかった環境のために、最後の返事からも拾う
  if (error === null && citations.length === 0) {
    for (const block of final?.content ?? []) {
      for (const citation of block.citations ?? []) addCitation(citation);
    }
  }

  const stopReason = final?.stop_reason ?? null;
  if (stopReason === "refusal") error = "refusal";

  if (error !== null) {
    // 途中まで出ていた字は消してもらう。断られた答えの言いかけを
    // お客さまに読ませない（お詫びだけが残る）
    onEvent({
      type: "error",
      code: "unavailable",
      message: UNAVAILABLE_MESSAGE,
      ...(text !== "" ? { clear: true } : {}),
    });
    onEvent({ type: "done", answered: false, reason: "error" });
    return { answered: false, text, citations, usage: usageOf(final), stopReason, error, truncated: false };
  }

  // max_tokens に当たった答えは文の途中で終わっている。切れたことが分かるように
  // 「…」を足して流し、記録にも「途中で切れた」として残す
  //（答えられたかどうかは下の条件で決まるので、切れた答えも出典が付いていれば「回答」になる）
  const truncated = stopReason === "max_tokens";
  if (truncated) {
    text += TRUNCATED_SUFFIX;
    onEvent({ type: "text", text: TRUNCATED_SUFFIX });
  }

  /**
   * 答えられたと数える条件。
   * 1. 字が出ている
   * 2. 「資料に無い」と伝えていない
   * 3. 出典が 1 つ以上付いている（資料から答えた印。言い方に頼らない裏づけ）
   */
  const answered = text.trim() !== "" && !NOT_IN_DOCUMENTS_RE.test(text) && citations.length > 0;
  if (answered) {
    onEvent({ type: "done", answered });
  } else {
    // 窓が「問い合わせ先のボタンを出すか」を決められるよう、理由を添える。
    // 出典が付かなかっただけ（no_citations）なら、答えはそのまま見せてボタンは出さない
    onEvent({
      type: "done",
      answered,
      reason: NOT_IN_DOCUMENTS_RE.test(text) ? "not_in_documents" : "no_citations",
    });
  }
  return { answered, text, citations, usage: usageOf(final), stopReason, error: null, truncated };
}
