import type { AnthropicClientLike, FinalMessageLike, MessageParams, MessageStreamLike, StreamEventLike } from "./types";

/** 鍵を使わずに窓の動きを見せるための、決まった答え（ブラウザでの通し確認と demo 用） */
export const FAKE_ANSWER = "市内と、隣接する三つの市までお伺いしております。現地調査とお見積もりは無料です。[1]";

const PIECE = 8;
const DELAY_MS = 40;

function pieces(text: string): string[] {
  const out: string[] = [];
  for (let i = 0; i < text.length; i += PIECE) out.push(text.slice(i, i + PIECE));
  return out;
}

export function createFakeClient(): AnthropicClientLike {
  return {
    messages: {
      stream(_params: MessageParams): MessageStreamLike {
        let stopped = false;
        return {
          async *[Symbol.asyncIterator](): AsyncGenerator<StreamEventLike> {
            for (const text of pieces(FAKE_ANSWER)) {
              await new Promise((done) => setTimeout(done, DELAY_MS));
              if (stopped) return;
              yield { type: "content_block_delta", index: 0, delta: { type: "text_delta", text } };
            }
            yield {
              type: "content_block_delta",
              index: 0,
              delta: {
                type: "citations_delta",
                citation: {
                  type: "char_location",
                  cited_text: "市内と隣の三市にお伺いします。",
                  document_index: 0,
                  start_char_index: 0,
                  end_char_index: 15,
                },
              },
            };
          },
          async finalMessage(): Promise<FinalMessageLike> {
            return {
              stop_reason: "end_turn",
              usage: { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 },
              content: [{ type: "text", text: FAKE_ANSWER }],
            };
          },
          // 本物と同じく、途中で止められる形にしておく（窓を閉じたときの動きを demo でも確かめられる）
          abort(): void {
            stopped = true;
          },
        };
      },
    },
  };
}
