import { describe, expect, it } from "vitest";
import { DEFAULT_GREETING, DEFAULT_INDEX_PATH, DEFAULT_SITE_NAME, normalizeOrigins, resolveConfig } from "./config";

describe("resolveConfig の既定値", () => {
  it("何も渡さなくても動く形になる", () => {
    const config = resolveConfig();
    expect(config.site).toEqual({ name: DEFAULT_SITE_NAME, url: null });
    expect(config.greeting).toBe(DEFAULT_GREETING);
    expect(config.content).toBe("content");
    expect(config.urls).toEqual([]);
    expect(config.alwaysInclude).toEqual([]);
    expect(config.suggestions).toEqual([]);
    expect(config.contactUrl).toBe(null);
    expect(config.answer).toEqual({ model: "claude-opus-5", effort: "low", maxTokens: 2048, style: "敬体。300 字以内。" });
    expect(config.retrieval).toEqual({ wholeCorpusMaxTokens: 60000, topK: 8 });
    expect(config.limits).toEqual({ maxInputChars: 400, perMinute: 10, perHour: 60, dailyQuestions: 500 });
    expect(config.indexPath).toBe(DEFAULT_INDEX_PATH);
    expect(config.allowedOrigins).toEqual([]);
    expect(config.adminToken).toBe(null);
    expect(config.logWebhookUrl).toBe(null);
    expect(config.logWebhookFormat).toBe("json");
    expect(config.trustProxy).toBe(false);
    expect(config.apiKey).toBe(null);
  });

  it("設定ファイルの値で上書きする", () => {
    const config = resolveConfig({
      file: {
        site: { name: "みなと工務店", url: "https://example.com" },
        urls: ["https://example.com/price"],
        alwaysInclude: ["会社概要"],
        suggestions: ["対応エリアはどこまでですか"],
        contactUrl: "https://example.com/contact",
        answer: { model: "claude-sonnet-5", effort: "medium", maxTokens: 512, style: "敬体。200 字以内。" },
        retrieval: { wholeCorpusMaxTokens: 30000, topK: 5 },
        limits: { maxInputChars: 200, perMinute: 5, perHour: 30, dailyQuestions: 100 },
      },
    });
    expect(config.site).toEqual({ name: "みなと工務店", url: "https://example.com" });
    expect(config.urls).toEqual(["https://example.com/price"]);
    expect(config.alwaysInclude).toEqual(["会社概要"]);
    expect(config.answer.model).toBe("claude-sonnet-5");
    expect(config.answer.effort).toBe("medium");
    expect(config.retrieval).toEqual({ wholeCorpusMaxTokens: 30000, topK: 5 });
    expect(config.limits.perMinute).toBe(5);
  });
});

describe("resolveConfig の環境変数", () => {
  it("サーバーの設定は環境変数から入る", () => {
    const config = resolveConfig({
      env: {
        ANTHROPIC_API_KEY: "sk-test",
        ALLOWED_ORIGINS: "https://example.com, https://www.example.com",
        ADMIN_TOKEN: "t0ken",
        LOG_WEBHOOK_URL: "https://hooks.example.com/abc",
        LOG_WEBHOOK_FORMAT: "slack",
        CONCIERGE_INDEX: "public/index.json",
        DAILY_QUESTION_LIMIT: "300",
        MAX_INPUT_CHARS: "250",
      },
    });
    expect(config.apiKey).toBe("sk-test");
    expect(config.allowedOrigins).toEqual(["https://example.com", "https://www.example.com"]);
    expect(config.adminToken).toBe("t0ken");
    expect(config.logWebhookUrl).toBe("https://hooks.example.com/abc");
    expect(config.logWebhookFormat).toBe("slack");
    expect(config.indexPath).toBe("public/index.json");
    expect(config.limits.dailyQuestions).toBe(300);
    expect(config.limits.maxInputChars).toBe(250);
  });

  it("環境変数は設定ファイルより強い", () => {
    const config = resolveConfig({
      file: { site: { name: "みなと工務店" }, limits: { dailyQuestions: 500 } },
      env: { DAILY_QUESTION_LIMIT: "50" },
    });
    expect(config.limits.dailyQuestions).toBe(50);
  });

  it("LOG_WEBHOOK_FORMAT が json/slack 以外なら json に落とす", () => {
    expect(resolveConfig({ env: { LOG_WEBHOOK_FORMAT: "teams" } }).logWebhookFormat).toBe("json");
  });

  it("TRUST_PROXY は 1 で真になり、設定ファイルより強い", () => {
    expect(resolveConfig({ env: { TRUST_PROXY: "1" } }).trustProxy).toBe(true);
    expect(resolveConfig({ env: { TRUST_PROXY: "true" } }).trustProxy).toBe(true);
    expect(resolveConfig({ env: { TRUST_PROXY: "" } }).trustProxy).toBe(false);
    expect(resolveConfig({ file: { site: { name: "A" }, trustProxy: true } }).trustProxy).toBe(true);
    expect(resolveConfig({ file: { site: { name: "A" }, trustProxy: true }, env: { TRUST_PROXY: "0" } }).trustProxy).toBe(false);
  });

  it("ALLOWED_ORIGINS は貼りやすい書き方を受け取って、オリジンの形にそろえる", () => {
    const config = resolveConfig({
      env: {
        ALLOWED_ORIGINS: "https://example.com/, example.org, http://localhost:3000/path, https://example.com:443",
      },
    });
    // 末尾の / と道は落ち、スキームが無ければ https を補い、同じものは 1 つにまとめる
    expect(config.allowedOrigins).toEqual(["https://example.com", "https://example.org", "http://localhost:3000"]);
  });

  it("normalizeOrigins は単体でも同じ結果を返す", () => {
    expect(normalizeOrigins(undefined)).toEqual([]);
    expect(normalizeOrigins(" , ")).toEqual([]);
    expect(normalizeOrigins("www.example.com")).toEqual(["https://www.example.com"]);
    // 港つきの書き方も、: の後が数字なのでスキームと間違えない
    expect(normalizeOrigins("example.com:3000")).toEqual(["https://example.com:3000"]);
  });

  it("ALLOWED_ORIGINS に読めない値が来たら、起動時に止める", () => {
    expect(() => resolveConfig({ env: { ALLOWED_ORIGINS: "https://" } })).toThrow(/ALLOWED_ORIGINS/);
    expect(() => resolveConfig({ env: { ALLOWED_ORIGINS: "javascript:alert(1)" } })).toThrow(
      /ALLOWED_ORIGINS の「javascript:alert\(1\)」は http:\/\/ か https:\/\/ で始めてください/,
    );
  });

  it("LOG_WEBHOOK_URL が http(s) でなければ止める（黙って記録を捨てない）", () => {
    expect(() => resolveConfig({ env: { LOG_WEBHOOK_URL: "hooks.example.com/a" } })).toThrow(/LOG_WEBHOOK_URL/);
    expect(() => resolveConfig({ env: { LOG_WEBHOOK_URL: "ftp://hooks.example.com/a" } })).toThrow(/LOG_WEBHOOK_URL/);
    expect(resolveConfig({ env: { LOG_WEBHOOK_URL: "https://hooks.example.com/a" } }).logWebhookUrl).toBe(
      "https://hooks.example.com/a",
    );
  });

  it("TRUST_PROXY に読めない値が来たら止める", () => {
    expect(() => resolveConfig({ env: { TRUST_PROXY: "maybe" } })).toThrow(/TRUST_PROXY/);
    expect(() => resolveConfig({ file: { site: { name: "A" }, trustProxy: "yes" } })).toThrow(/trustProxy/);
  });
});

describe("resolveConfig の検証", () => {
  it("設定ファイルを渡すなら site.name が要る", () => {
    expect(() => resolveConfig({ file: { site: {} } })).toThrow(/site\.name/);
    expect(() => resolveConfig({ file: { site: { name: "  " } } })).toThrow(/site\.name/);
  });

  it("model は claude- で始まる", () => {
    expect(() => resolveConfig({ file: { site: { name: "A" }, answer: { model: "gpt-4" } } })).toThrow(/answer\.model/);
  });

  it("effort は low / medium / high", () => {
    expect(() => resolveConfig({ file: { site: { name: "A" }, answer: { effort: "max" } } })).toThrow(/answer\.effort/);
  });

  it("数値は範囲の外なら止める", () => {
    expect(() => resolveConfig({ file: { site: { name: "A" }, retrieval: { topK: 0 } } })).toThrow(/retrieval\.topK/);
    expect(() => resolveConfig({ file: { site: { name: "A" }, retrieval: { topK: 51 } } })).toThrow(/retrieval\.topK/);
    expect(() => resolveConfig({ file: { site: { name: "A" }, limits: { maxInputChars: 5 } } })).toThrow(/limits\.maxInputChars/);
  });

  it("URL は http(s) だけ", () => {
    expect(() => resolveConfig({ file: { site: { name: "A" }, contactUrl: "javascript:alert(1)" } })).toThrow(/contactUrl/);
    expect(() => resolveConfig({ file: { site: { name: "A" }, urls: ["ftp://example.com"] } })).toThrow(/urls\[0\]/);
  });

  it("断りは日本語で、何が悪いかを言う", () => {
    expect(() => resolveConfig({ file: { site: { name: "A" }, answer: { model: "gpt-4" } } })).toThrow(
      "concierge.config.json: answer.model は claude- で始まる文字列にしてください（いまの値: gpt-4）",
    );
  });

  it("labels は文字列の入れ物としてそのまま通す", () => {
    const config = resolveConfig({ file: { site: { name: "A" }, labels: { open: "きいてみる", send: 1 } } });
    expect(config.labels).toEqual({ open: "きいてみる" });
  });
});
