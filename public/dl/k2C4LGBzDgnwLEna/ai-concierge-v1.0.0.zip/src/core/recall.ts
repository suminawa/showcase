export interface EvalQuestion {
  id: string;
  question: string;
  /** この質問に答えるために要る文書の id */
  expect: string[];
  /** 答えに入っていてほしい要点（人が読んで確かめるための覚え書き） */
  point: string;
}

export interface EvalOutcome {
  id: string;
  question: string;
  expect: string[];
  got: string[];
  recall: number;
}

export interface EvalSummary {
  questions: number;
  recall: number;
  misses: string[];
}

export function recallOf(expected: string[], got: string[]): number {
  if (expected.length === 0) return 1;
  const found = new Set(got);
  const hit = expected.filter((id) => found.has(id)).length;
  return hit / expected.length;
}

export function summarize(outcomes: EvalOutcome[]): EvalSummary {
  if (outcomes.length === 0) return { questions: 0, recall: 1, misses: [] };
  const total = outcomes.reduce((sum, outcome) => sum + outcome.recall, 0);
  return {
    questions: outcomes.length,
    recall: total / outcomes.length,
    misses: outcomes.filter((outcome) => outcome.recall < 1).map((outcome) => outcome.id),
  };
}
