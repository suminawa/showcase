import { describe, expect, it } from "vitest";
import { recallOf, summarize } from "./recall";

describe("recallOf", () => {
  it("期待した文書のうち、いくつ取れたか", () => {
    expect(recallOf(["about", "price"], ["about", "faq"])).toBe(0.5);
    expect(recallOf(["about"], ["about", "faq"])).toBe(1);
    expect(recallOf(["about", "price"], ["faq"])).toBe(0);
  });

  it("同じ文書が何片も来ても 1 回と数える", () => {
    expect(recallOf(["about"], ["about", "about"])).toBe(1);
  });

  it("期待が無ければ満点", () => {
    expect(recallOf([], ["about"])).toBe(1);
  });
});

describe("summarize", () => {
  it("平均と、取りこぼした質問の id を出す", () => {
    expect(
      summarize([
        { id: "q1", question: "a", expect: ["about"], got: ["about"], recall: 1 },
        { id: "q2", question: "b", expect: ["price", "faq"], got: ["price"], recall: 0.5 },
        { id: "q3", question: "c", expect: ["flow"], got: [], recall: 0 },
      ]),
    ).toEqual({ questions: 3, recall: 0.5, misses: ["q2", "q3"] });
  });

  it("空なら 0 問・recall 1", () => {
    expect(summarize([])).toEqual({ questions: 0, recall: 1, misses: [] });
  });
});
