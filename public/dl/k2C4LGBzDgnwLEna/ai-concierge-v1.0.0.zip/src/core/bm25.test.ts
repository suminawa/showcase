import { describe, expect, it } from "vitest";
import type { Chunk, IndexStats } from "./types";
import { B, chunkTerms, corpusStats, countTerms, HEADING_WEIGHT, idf, K1, scoreChunk, tokenize } from "./bm25";

describe("tokenize", () => {
  it("日本語は 2-gram に割る", () => {
    expect(tokenize("料金は？")).toEqual(["料金", "金は"]);
    expect(tokenize("ラーメン")).toEqual(["ラー", "ーメ", "メン"]);
  });

  it("1 字だけの並びはその字を 1 語にする", () => {
    expect(tokenize("あ")).toEqual(["あ"]);
  });

  it("英数字は小文字の語にする", () => {
    expect(tokenize("Wi-Fi は 5GHz")).toEqual(["wi", "fi", "は", "5ghz"]);
  });

  it("記号と空白は落とす", () => {
    expect(tokenize("！？（）　・")).toEqual([]);
    expect(tokenize("")).toEqual([]);
  });
});

describe("countTerms", () => {
  it("語の出た数を数える", () => {
    expect(countTerms(["あい", "あい", "いう"])).toEqual({ あい: 2, いう: 1 });
    expect(countTerms([])).toEqual({});
  });
});

describe("chunkTerms", () => {
  it("見出しの語を 2 回入れる", () => {
    expect(HEADING_WEIGHT).toBe(2);
    // 見出し「料金」→ ["料金"] を 2 回、本文「料金は 10 万円」→ ["料金","金は","10","万円"]
    // 合わせて 6 語。料金は 3 回出る
    expect(chunkTerms({ id: "a#1", heading: "料金", breadcrumb: "料金", text: "料金は 10 万円", tokens: 6 })).toEqual({
      len: 6,
      tf: { 料金: 3, 金は: 1, "10": 1, 万円: 1 },
    });
  });

  it("見出しが空でも breadcrumb（題名）の語は入る", () => {
    // 見出しは空だが breadcrumb「A」→ ["a"] を 2 回、本文「料金」→ ["料金"]。合わせて 3 語
    expect(chunkTerms({ id: "a#1", heading: "", breadcrumb: "A", text: "料金", tokens: 2 })).toEqual({
      len: 3,
      tf: { a: 2, 料金: 1 },
    });
  });

  it("見出しが空で breadcrumb が題名だけでも、題名の語が重み 2 で入る", () => {
    // breadcrumb「対応エリア」→ 2-gram 対応/応エ/エリ/リア を 2 回。本文は空
    expect(chunkTerms({ id: "a#1", heading: "", breadcrumb: "対応エリア", text: "", tokens: 4 })).toEqual({
      len: 8,
      tf: { 対応: 2, 応エ: 2, エリ: 2, リア: 2 },
    });
  });
});

describe("corpusStats", () => {
  it("平均の長さと、語の出た片の数を出す", () => {
    const chunks: Chunk[] = [
      { id: "a#1", heading: "", breadcrumb: "A", text: "", tokens: 0, len: 6, tf: { 料金: 3, "10": 1 } },
      { id: "b#1", heading: "", breadcrumb: "B", text: "", tokens: 0, len: 4, tf: { 保証: 2, "10": 1 } },
    ];
    expect(corpusStats(chunks)).toEqual({ avgLen: 5, df: { 料金: 1, "10": 2, 保証: 1 } });
  });

  it("空の一覧でも壊れない", () => {
    expect(corpusStats([])).toEqual({ avgLen: 0, df: {} });
  });
});

describe("idf", () => {
  it("ln(1 + (N - df + 0.5) / (df + 0.5))", () => {
    // N = 2, df = 1 → ln(1 + 1.5 / 1.5) = ln 2
    expect(idf(1, 2)).toBeCloseTo(Math.log(2), 12);
    // N = 2, df = 2 → ln(1 + 0.5 / 2.5) = ln 1.2
    expect(idf(2, 2)).toBeCloseTo(Math.log(1.2), 12);
  });
});

describe("scoreChunk", () => {
  // 片は 2 つ、どちらも長さ 10、平均も 10。
  // 長さの補正 1 - b + b * len / avgLen = 1 - 0.75 + 0.75 = 1 になるので、
  // 点は idf * tf * (k1 + 1) / (tf + k1) だけで決まる
  const stats: IndexStats = { documents: 1, chunks: 2, totalTokens: 20, avgLen: 10, df: { 料金: 1, 保証: 2 } };
  const chunk = (tf: Record<string, number>, len = 10): Chunk => ({
    id: "a#1",
    heading: "",
    breadcrumb: "A",
    text: "",
    tokens: 0,
    len,
    tf,
  });

  it("k1 と b は 1.2 と 0.75", () => {
    expect(K1).toBe(1.2);
    expect(B).toBe(0.75);
  });

  it("1 回出た語: idf そのもの（tf * 2.2 / (tf + 1.2) = 1）", () => {
    expect(scoreChunk(["料金"], chunk({ 料金: 1 }), stats)).toBeCloseTo(Math.log(2), 12);
  });

  it("2 回出た語: 2 * 2.2 / (2 + 1.2) = 1.375 倍", () => {
    expect(scoreChunk(["料金"], chunk({ 料金: 2 }), stats)).toBeCloseTo(Math.log(2) * 1.375, 12);
  });

  it("多くの片に出る語ほど点が低い", () => {
    expect(scoreChunk(["保証"], chunk({ 保証: 1 }), stats)).toBeCloseTo(Math.log(1.2), 12);
  });

  it("長い片は点が下がる", () => {
    // len 20、avgLen 10 → 補正 = 0.25 + 0.75 * 2 = 1.75。2.2 / (1 + 1.2 * 1.75) = 2.2 / 3.1
    expect(scoreChunk(["料金"], chunk({ 料金: 1 }, 20), stats)).toBeCloseTo((Math.log(2) * 2.2) / 3.1, 12);
  });

  it("語ごとに足す", () => {
    expect(scoreChunk(["料金", "保証"], chunk({ 料金: 1, 保証: 1 }), stats)).toBeCloseTo(Math.log(2) + Math.log(1.2), 12);
  });

  it("同じ語を 2 回聞かれても 1 回だけ数える", () => {
    expect(scoreChunk(["料金", "料金"], chunk({ 料金: 1 }), stats)).toBeCloseTo(Math.log(2), 12);
  });

  it("無い語は 0", () => {
    expect(scoreChunk(["工期"], chunk({ 料金: 1 }), stats)).toBe(0);
    expect(scoreChunk([], chunk({ 料金: 1 }), stats)).toBe(0);
  });

  it("片が空でも壊れない", () => {
    expect(scoreChunk(["料金"], chunk({}, 0), stats)).toBe(0);
  });
});
