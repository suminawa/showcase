import type { ChatErrorCode, LimitsConfig } from "./types";

export interface Bucket {
  tokens: number;
  updatedAt: number;
}

export interface DayCount {
  key: string;
  count: number;
}

export interface GuardState {
  minute: Map<string, Bucket>;
  hour: Map<string, Bucket>;
  day: DayCount;
}

export type GuardVerdict = { ok: true } | { ok: false; status: number; code: ChatErrorCode; message: string };

export const GUARD_MESSAGES = {
  forbidden: "このページからのご利用は受け付けておりません。",
  rateLimited: "少し時間をおいてからお試しください。",
  dailyLimit: "本日のご質問の受付は終了しました。お手数ですが問い合わせフォームからご連絡ください。",
  empty: "ご質問を入力してください。",
  tooLarge: "送信できる内容の大きさを超えています。",
} as const;

const MINUTE_MS = 60 * 1000;
const HOUR_MS = 60 * MINUTE_MS;
const JST_OFFSET_MS = 9 * HOUR_MS;

/**
 * IP ごとのバケツを覚えておく数の上限（1 分ぶん・1 時間ぶんのそれぞれに効きます）。
 * 上限に達したら、最後に使ったのがいちばん古いものから捨てます。
 * これが無いと、毎回ちがう IP を名乗る相手にメモリを食いつぶされます。
 */
export const MAX_KEYS = 10000;

export function createGuardState(): GuardState {
  return { minute: new Map(), hour: new Map(), day: { key: "", count: 0 } };
}

/** 日本時間の YYYY-MM-DD。夏時間が無いので、UTC に +9 時間して切り出すだけでよい */
export function dayKeyOf(now: number): string {
  return new Date(now + JST_OFFSET_MS).toISOString().slice(0, 10);
}

/**
 * ALLOWED_ORIGINS が空のときは「自分のサイトから」だけを許す既定値にする。
 * 空リストを「誰でも可」にしてしまうと、支払い済みの API を他所のサイトが
 * 訪問者のブラウザ経由でただ乗りできてしまうため。
 */
export function originAllowed(origin: string | null, allowed: string[], selfOrigin: string | null): boolean {
  if (origin === null || origin === "") return true;
  if (selfOrigin !== null && origin === selfOrigin) return true;
  return allowed.includes(origin);
}

export function checkOrigin(origin: string | null, allowed: string[], selfOrigin: string | null): GuardVerdict {
  if (originAllowed(origin, allowed, selfOrigin)) return { ok: true };
  return { ok: false, status: 403, code: "forbidden", message: GUARD_MESSAGES.forbidden };
}

export function checkInput(question: string, maxInputChars: number): GuardVerdict {
  if (question.trim() === "") {
    return { ok: false, status: 400, code: "unavailable", message: GUARD_MESSAGES.empty };
  }
  if (question.length > maxInputChars) {
    return { ok: false, status: 413, code: "too_long", message: `質問は ${maxInputChars} 字以内でお願いします。` };
  }
  return { ok: true };
}

/** トークンバケツ。最初は満タンで、windowMs のあいだに capacity 個ぶん戻る */
export function takeToken(
  bucket: Bucket | undefined,
  capacity: number,
  windowMs: number,
  now: number,
): { bucket: Bucket; ok: boolean } {
  const previous = bucket ?? { tokens: capacity, updatedAt: now };
  const refilled = Math.min(capacity, previous.tokens + ((now - previous.updatedAt) * capacity) / windowMs);
  if (refilled < 1) return { bucket: { tokens: refilled, updatedAt: now }, ok: false };
  return { bucket: { tokens: refilled - 1, updatedAt: now }, ok: true };
}

/**
 * 入れ直すことで、Map の並びを「最後に使った順（古い順）」に保つ。
 * JavaScript の Map は入れた順を覚えているが、既にある鍵へ set しても順番は動かないので、
 * いったん delete してから set する。
 */
function touch(map: Map<string, Bucket>, ip: string, bucket: Bucket): void {
  map.delete(ip);
  map.set(ip, bucket);
}

/**
 * 覚えておく数を抑える。並びが「古い順」なので先頭から見ていけばよく、
 * 新しいものに当たった時点で止められる（毎回すべてを見に行かない）。
 * 1. その窓の時間が過ぎたバケツは、満タンに戻った新品と同じなので捨てる
 * 2. それでも MAX_KEYS を超えていたら、古いものから捨てる
 */
function evict(map: Map<string, Bucket>, windowMs: number, now: number): void {
  for (const [ip, bucket] of map) {
    if (now - bucket.updatedAt < windowMs) break;
    map.delete(ip);
  }
  while (map.size > MAX_KEYS) {
    const oldest = map.keys().next();
    if (oldest.done === true) break;
    map.delete(oldest.value);
  }
}

/**
 * IP ごとの 1 分と 1 時間。1 分を通って 1 時間で断られると 1 分ぶんは減ったままになるが、
 * それで困るのは上限に張り付いている相手だけなので、このままにする。
 */
export function checkRate(state: GuardState, ip: string, limits: LimitsConfig, now: number): GuardVerdict {
  const perMinute = takeToken(state.minute.get(ip), limits.perMinute, MINUTE_MS, now);
  touch(state.minute, ip, perMinute.bucket);
  evict(state.minute, MINUTE_MS, now);
  const perHour = takeToken(state.hour.get(ip), limits.perHour, HOUR_MS, now);
  touch(state.hour, ip, perHour.bucket);
  evict(state.hour, HOUR_MS, now);
  if (perMinute.ok && perHour.ok) return { ok: true };
  return { ok: false, status: 429, code: "rate_limited", message: GUARD_MESSAGES.rateLimited };
}

export function checkDaily(state: GuardState, limits: LimitsConfig, now: number): GuardVerdict {
  const key = dayKeyOf(now);
  if (state.day.key !== key) {
    state.day.key = key;
    state.day.count = 0;
  }
  if (state.day.count >= limits.dailyQuestions) {
    return { ok: false, status: 429, code: "daily_limit", message: GUARD_MESSAGES.dailyLimit };
  }
  state.day.count += 1;
  return { ok: true };
}
