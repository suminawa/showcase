import type { WebhookFormat } from "./types";

export const LOG_RING_SIZE = 500;
export const ANSWER_HEAD_CHARS = 200;
export const WEBHOOK_TIMEOUT_MS = 5000;

export interface LogEntry {
  id: number;
  at: string;
  question: string;
  answerHead: string;
  sources: number[];
  answered: boolean;
  ms: number;
  model: string;
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  /** max_tokens に当たって答えが途中で切れたか */
  truncated: boolean;
  /** 訪問者が答えの途中で窓を閉じたか */
  disconnected: boolean;
}

export interface LogSink {
  push(entry: LogEntry): void;
  /** 新しいものから */
  list(): LogEntry[];
  unanswered(): LogEntry[];
  size(): number;
}

/**
 * お客さまが問い合わせ内容に個人情報を書くことがあるので、記録の前に伏せる。
 * IP と User-Agent はそもそも受け取らない。
 */
export function redact(text: string): string {
  return text
    .replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, "***@***")
    .replace(/0\d{1,3}[-\s]?\d{2,4}[-\s]?\d{3,4}/g, "***")
    .replace(/\d{9,}/g, "***");
}

export function headOf(text: string, max: number = ANSWER_HEAD_CHARS): string {
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

export function createLogRing(size: number = LOG_RING_SIZE): LogSink {
  const entries: LogEntry[] = [];
  return {
    push(entry: LogEntry): void {
      entries.push(entry);
      if (entries.length > size) entries.splice(0, entries.length - size);
    },
    list(): LogEntry[] {
      return [...entries].reverse();
    },
    unanswered(): LogEntry[] {
      return [...entries].reverse().filter((entry) => !entry.answered);
    },
    size(): number {
      return entries.length;
    },
  };
}

export function webhookPayload(entry: LogEntry, format: WebhookFormat, siteName: string): unknown {
  if (format === "slack") {
    const sources = entry.sources.length === 0 ? "なし" : entry.sources.map((index) => `[${index}]`).join(" ");
    return {
      text: [
        `［${siteName} 案内窓口］${entry.answered ? "回答" : "未回答"}`,
        `質問: ${entry.question}`,
        `答え: ${entry.answerHead}`,
        `出典: ${sources} / ${entry.ms} ms / ${entry.model}`,
      ].join("\n"),
    };
  }
  return {
    site: siteName,
    at: entry.at,
    question: entry.question,
    answerHead: entry.answerHead,
    answered: entry.answered,
    sources: entry.sources,
    ms: entry.ms,
    model: entry.model,
    tokens: { input: entry.inputTokens, output: entry.outputTokens, cacheRead: entry.cacheReadTokens },
  };
}

/**
 * 記録の送信でお客さまの答えを止めない。失敗したら false を返すだけ。
 * 送り先が応答しなくても待ち続けないよう、timeoutMs で必ず切り上げる
 * （fetchImpl が signal を見ない実装でも、レースで確実に切り上げる）。
 */
export async function postWebhook(
  url: string,
  payload: unknown,
  fetchImpl: typeof fetch = fetch,
  timeoutMs: number = WEBHOOK_TIMEOUT_MS,
): Promise<boolean> {
  const signal = AbortSignal.timeout(timeoutMs);
  try {
    const response = await Promise.race([
      fetchImpl(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
        signal,
      }),
      new Promise<Response>((_resolve, reject) => {
        signal.addEventListener("abort", () => reject(new Error("webhook timeout")));
      }),
    ]);
    return response.ok;
  } catch {
    return false;
  }
}

const CSV_HEADER =
  "受付日時,質問,答えの先頭,出典,答えられたか,所要ms,モデル,入力トークン,出力トークン,キャッシュ読み,途中で切れた,途中で切断";

function cell(value: string): string {
  // 表計算ソフトが式として評価する先頭文字（= + - @ とタブ・復帰）は、先頭に ' を置いて文字列にする
  const safe = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
}

export function toCsv(entries: LogEntry[]): string {
  const lines = [CSV_HEADER];
  for (const entry of entries) {
    lines.push(
      [
        cell(entry.at),
        cell(entry.question),
        cell(entry.answerHead),
        cell(entry.sources.join(" ")),
        entry.answered ? "はい" : "いいえ",
        String(entry.ms),
        cell(entry.model),
        String(entry.inputTokens),
        String(entry.outputTokens),
        String(entry.cacheReadTokens),
        entry.truncated ? "はい" : "いいえ",
        entry.disconnected ? "はい" : "いいえ",
      ].join(","),
    );
  }
  return `${lines.join("\n")}\n`;
}
