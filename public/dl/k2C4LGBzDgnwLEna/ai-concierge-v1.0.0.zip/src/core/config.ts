import type {
  AnswerConfig,
  ConciergeConfig,
  EffortLevel,
  LimitsConfig,
  RetrievalConfig,
  WebhookFormat,
  WidgetLabels,
} from "./types";

export const DEFAULT_SITE_NAME = "当サイト";
export const DEFAULT_GREETING = "こんにちは。ご質問にお答えします。公開している資料の範囲でご案内いたします。";
export const DEFAULT_INDEX_PATH = "data/index.json";
export const EFFORTS: EffortLevel[] = ["low", "medium", "high"];

export const DEFAULT_ANSWER: AnswerConfig = {
  model: "claude-opus-5",
  effort: "low",
  // claude-opus-5 は thinking を省くと既定の adaptive で動き、その考えるぶんも
  // max_tokens から引かれる。答えが文の途中で切れないよう、余裕を持たせている
  maxTokens: 2048,
  style: "敬体。300 字以内。",
};
export const DEFAULT_RETRIEVAL: RetrievalConfig = { wholeCorpusMaxTokens: 60000, topK: 8 };
export const DEFAULT_LIMITS: LimitsConfig = { maxInputChars: 400, perMinute: 10, perHour: 60, dailyQuestions: 500 };

const LABEL_KEYS: Array<keyof WidgetLabels> = [
  "windowTitle",
  "open",
  "close",
  "placeholder",
  "send",
  "thinking",
  "sources",
  "contact",
  "reset",
  "answerDone",
  "unavailable",
  "tooLong",
  "rateLimited",
  "offline",
  "emptyQuestion",
];

export interface ResolveConfigInput {
  file?: unknown;
  env?: Record<string, string | undefined>;
}

function fail(message: string): never {
  throw new Error(`concierge.config.json: ${message}`);
}

function recordOf(value: unknown, where: string): Record<string, unknown> {
  if (value === undefined) return {};
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    fail(`${where} は入れ物（{ … }）にしてください`);
  }
  return value as Record<string, unknown>;
}

function stringOf(value: unknown, where: string, fallback: string): string {
  if (value === undefined) return fallback;
  if (typeof value !== "string") fail(`${where} は文字列にしてください`);
  return value;
}

function numberOf(value: unknown, where: string, min: number, max: number, fallback: number): number {
  if (value === undefined) return fallback;
  if (typeof value !== "number" || !Number.isFinite(value)) fail(`${where} は数にしてください`);
  if (value < min || value > max) fail(`${where} は ${min} 以上 ${max} 以下にしてください（いまの値: ${value}）`);
  return value;
}

function httpUrlOf(value: unknown, where: string): string {
  if (typeof value !== "string") fail(`${where} は文字列にしてください`);
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    fail(`${where} は http:// か https:// で始まるアドレスにしてください（いまの値: ${value}）`);
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    fail(`${where} は http:// か https:// で始まるアドレスにしてください（いまの値: ${value}）`);
  }
  return value;
}

function stringArrayOf(value: unknown, where: string): string[] {
  if (value === undefined) return [];
  if (!Array.isArray(value)) fail(`${where} は文字列の一覧にしてください`);
  return value.map((item, i) => {
    if (typeof item !== "string") fail(`${where}[${i}] は文字列にしてください`);
    return item;
  });
}

function urlArrayOf(value: unknown, where: string): string[] {
  if (value === undefined) return [];
  if (!Array.isArray(value)) fail(`${where} は文字列の一覧にしてください`);
  return value.map((item, i) => httpUrlOf(item, `${where}[${i}]`));
}

function labelsOf(value: unknown): Partial<WidgetLabels> {
  const raw = recordOf(value, "labels");
  const labels: Partial<WidgetLabels> = {};
  for (const key of LABEL_KEYS) {
    const item = raw[key];
    // 文字列でないものは黙って捨てる（窓は既定の文言に戻る。ここで例外にすると
    // 買い手が 1 つ書き間違えただけでサイト全体が止まる）
    if (typeof item === "string") labels[key] = item;
  }
  return labels;
}

/**
 * ALLOWED_ORIGINS を「オリジン」の形にそろえる。
 * 買い手が Vercel の画面に貼りがちな `https://example.com/`（末尾の / つき）や
 * `example.com`（スキームなし）も受け取り、ブラウザが送ってくる Origin と
 * 同じ書き方（`https://example.com`）に直す。読み取れないものは起動時に止める。
 */
export function normalizeOrigins(raw: string | undefined): string[] {
  const found = new Set<string>();
  const origins: string[] = [];
  for (const item of (raw ?? "").split(",").map((value) => value.trim())) {
    if (item === "") continue;
    const isHttp = /^https?:\/\//i.test(item);
    // http(s) 以外のスキームは断る。`example.com:3000` の : は港なので通す（: の後が数字）
    if (!isHttp && /^[a-z][a-z0-9+.-]*:(?!\d)/i.test(item)) {
      fail(`環境変数 ALLOWED_ORIGINS の「${item}」は http:// か https:// で始めてください`);
    }
    let parsed: URL;
    try {
      parsed = new URL(isHttp ? item : `https://${item}`);
    } catch {
      fail(`環境変数 ALLOWED_ORIGINS の「${item}」を読み取れません。https://example.com のように書いてください`);
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      fail(`環境変数 ALLOWED_ORIGINS の「${item}」は http:// か https:// で始めてください`);
    }
    if (found.has(parsed.origin)) continue;
    found.add(parsed.origin);
    origins.push(parsed.origin);
  }
  return origins;
}

function booleanOf(value: unknown, where: string, fallback: boolean): boolean {
  if (value === undefined) return fallback;
  if (typeof value !== "boolean") fail(`${where} は true か false にしてください`);
  return value;
}

/** 「1」「true」「yes」「on」を真とみなす（大小文字は問いません） */
function envBoolean(env: Record<string, string | undefined>, key: string, fallback: boolean): boolean {
  const raw = env[key];
  if (raw === undefined || raw.trim() === "") return fallback;
  const value = raw.trim().toLowerCase();
  if (["1", "true", "yes", "on"].includes(value)) return true;
  if (["0", "false", "no", "off"].includes(value)) return false;
  fail(`環境変数 ${key} は 1 か 0 にしてください（いまの値: ${raw}）`);
}

function envNumber(env: Record<string, string | undefined>, key: string, where: string, min: number, max: number, fallback: number): number {
  const raw = env[key];
  if (raw === undefined || raw.trim() === "") return fallback;
  const value = Number(raw);
  if (!Number.isFinite(value)) fail(`環境変数 ${key} は数にしてください（いまの値: ${raw}）`);
  return numberOf(value, where, min, max, fallback);
}

export function resolveConfig(input: ResolveConfigInput = {}): ConciergeConfig {
  const env = input.env ?? {};
  const hasFile = input.file !== undefined;
  const file = recordOf(input.file, "設定");

  const site = recordOf(file.site, "site");
  const siteName = hasFile ? stringOf(site.name, "site.name", "") : DEFAULT_SITE_NAME;
  if (hasFile && siteName.trim() === "") {
    fail("site.name に会社名やサイト名を入れてください（窓の案内文と system prompt に使います）");
  }
  const siteUrl = site.url === undefined ? null : httpUrlOf(site.url, "site.url");

  const answerRaw = recordOf(file.answer, "answer");
  const model = stringOf(answerRaw.model, "answer.model", DEFAULT_ANSWER.model);
  if (!model.startsWith("claude-")) {
    fail(`answer.model は claude- で始まる文字列にしてください（いまの値: ${model}）`);
  }
  const effort = stringOf(answerRaw.effort, "answer.effort", DEFAULT_ANSWER.effort) as EffortLevel;
  if (!EFFORTS.includes(effort)) {
    fail(`answer.effort は low / medium / high のどれかにしてください（いまの値: ${effort}）`);
  }

  const retrievalRaw = recordOf(file.retrieval, "retrieval");
  const limitsRaw = recordOf(file.limits, "limits");

  const maxInputChars = envNumber(
    env,
    "MAX_INPUT_CHARS",
    "limits.maxInputChars",
    10,
    4000,
    numberOf(limitsRaw.maxInputChars, "limits.maxInputChars", 10, 4000, DEFAULT_LIMITS.maxInputChars),
  );
  const dailyQuestions = envNumber(
    env,
    "DAILY_QUESTION_LIMIT",
    "limits.dailyQuestions",
    1,
    1000000,
    numberOf(limitsRaw.dailyQuestions, "limits.dailyQuestions", 1, 1000000, DEFAULT_LIMITS.dailyQuestions),
  );

  const format = (env.LOG_WEBHOOK_FORMAT ?? "json").trim();
  const logWebhookFormat: WebhookFormat = format === "slack" ? "slack" : "json";

  // 送り先の書き間違いに気づけるよう、起動時に確かめる
  // （postWebhook は失敗を黙って飲み込むので、ここで見ないと記録が消え続ける）
  const webhook = (env.LOG_WEBHOOK_URL ?? "").trim();
  const logWebhookUrl = webhook === "" ? null : httpUrlOf(webhook, "環境変数 LOG_WEBHOOK_URL");

  return {
    site: { name: siteName, url: siteUrl },
    urls: urlArrayOf(file.urls, "urls"),
    content: stringOf(file.content, "content", "content"),
    alwaysInclude: stringArrayOf(file.alwaysInclude, "alwaysInclude"),
    greeting: stringOf(file.greeting, "greeting", DEFAULT_GREETING),
    suggestions: stringArrayOf(file.suggestions, "suggestions"),
    contactUrl: file.contactUrl === undefined ? null : httpUrlOf(file.contactUrl, "contactUrl"),
    labels: labelsOf(file.labels),
    answer: {
      model,
      effort,
      maxTokens: numberOf(answerRaw.maxTokens, "answer.maxTokens", 128, 8192, DEFAULT_ANSWER.maxTokens),
      style: stringOf(answerRaw.style, "answer.style", DEFAULT_ANSWER.style),
    },
    retrieval: {
      wholeCorpusMaxTokens: numberOf(
        retrievalRaw.wholeCorpusMaxTokens,
        "retrieval.wholeCorpusMaxTokens",
        1000,
        400000,
        DEFAULT_RETRIEVAL.wholeCorpusMaxTokens,
      ),
      topK: numberOf(retrievalRaw.topK, "retrieval.topK", 1, 50, DEFAULT_RETRIEVAL.topK),
    },
    limits: {
      maxInputChars,
      perMinute: numberOf(limitsRaw.perMinute, "limits.perMinute", 1, 1000, DEFAULT_LIMITS.perMinute),
      perHour: numberOf(limitsRaw.perHour, "limits.perHour", 1, 100000, DEFAULT_LIMITS.perHour),
      dailyQuestions,
    },
    indexPath: (env.CONCIERGE_INDEX ?? "").trim() || DEFAULT_INDEX_PATH,
    allowedOrigins: normalizeOrigins(env.ALLOWED_ORIGINS),
    adminToken: (env.ADMIN_TOKEN ?? "").trim() || null,
    logWebhookUrl,
    logWebhookFormat,
    // 既定は false。前に proxy が立っていて、そこが x-forwarded-for を書き換えている
    // ときだけ true にしてください（false のままなら、名乗られた値は見ません）
    trustProxy: envBoolean(env, "TRUST_PROXY", booleanOf(file.trustProxy, "trustProxy", false)),
    apiKey: (env.ANTHROPIC_API_KEY ?? "").trim() || null,
  };
}

/** concierge.config.json を読む。見つからなければ undefined（既定値だけで動かす） */
export async function loadConfigFile(path: string): Promise<unknown> {
  const { readFile } = await import("node:fs/promises");
  try {
    return JSON.parse(await readFile(path, "utf8")) as unknown;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined;
    if (error instanceof SyntaxError) {
      throw new Error(`${path} が JSON として読めません: ${error.message}`);
    }
    throw error;
  }
}
