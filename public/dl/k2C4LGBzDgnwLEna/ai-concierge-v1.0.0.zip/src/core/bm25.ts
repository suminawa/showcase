import type { Chunk, ChunkDraft, IndexStats } from "./types";

export const K1 = 1.2;
export const B = 0.75;
/** 見出しの語は本文の 2 倍の重み（同じ語を 2 回入れる） */
export const HEADING_WEIGHT = 2;

// ひらがな・カタカナ（長音つき）・々〆・漢字の並び、または英数字の並び。記号は拾わない
const TOKEN = /[ぁ-ゖァ-ヺー々〆一-鿿㐀-䶿]+|[0-9A-Za-z]+/g;
const ALNUM = /^[0-9A-Za-z]+$/;

export function tokenize(text: string): string[] {
  const tokens: string[] = [];
  for (const match of text.matchAll(TOKEN)) {
    const run = match[0];
    if (ALNUM.test(run)) {
      tokens.push(run.toLowerCase());
      continue;
    }
    if (run.length === 1) {
      tokens.push(run);
      continue;
    }
    for (let i = 0; i + 1 < run.length; i += 1) tokens.push(run.slice(i, i + 2));
  }
  return tokens;
}

export function countTerms(tokens: string[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const token of tokens) counts[token] = (counts[token] ?? 0) + 1;
  return counts;
}

export function chunkTerms(draft: ChunkDraft): { len: number; tf: Record<string, number> } {
  const tokens: string[] = [];
  // breadcrumb は「題名 › 見出し」（見出しが無ければ題名だけ）。見出しだけだと
  // 見出しが空の節で題名の語が索引に一度も入らない（"›" は tokenize で語にならない）
  const breadcrumb = tokenize(draft.breadcrumb);
  for (let i = 0; i < HEADING_WEIGHT; i += 1) tokens.push(...breadcrumb);
  tokens.push(...tokenize(draft.text));
  return { len: tokens.length, tf: countTerms(tokens) };
}

export function corpusStats(chunks: Chunk[]): { avgLen: number; df: Record<string, number> } {
  if (chunks.length === 0) return { avgLen: 0, df: {} };
  const df: Record<string, number> = {};
  let total = 0;
  for (const chunk of chunks) {
    total += chunk.len;
    for (const term of Object.keys(chunk.tf)) df[term] = (df[term] ?? 0) + 1;
  }
  return { avgLen: total / chunks.length, df };
}

export function idf(df: number, total: number): number {
  return Math.log(1 + (total - df + 0.5) / (df + 0.5));
}

export function scoreChunk(queryTokens: string[], chunk: Chunk, stats: IndexStats): number {
  if (stats.chunks === 0 || chunk.len === 0 || queryTokens.length === 0) return 0;
  const avgLen = stats.avgLen === 0 ? chunk.len : stats.avgLen;
  const norm = 1 - B + (B * chunk.len) / avgLen;
  let score = 0;
  for (const term of new Set(queryTokens)) {
    const tf = chunk.tf[term];
    if (tf === undefined) continue;
    score += idf(stats.df[term] ?? 0, stats.chunks) * ((tf * (K1 + 1)) / (tf + K1 * norm));
  }
  return score;
}
