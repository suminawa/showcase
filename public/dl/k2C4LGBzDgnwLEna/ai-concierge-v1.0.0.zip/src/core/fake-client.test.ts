import { describe, expect, it } from "vitest";
import { streamAnswer } from "./answer";
import { createFakeClient, FAKE_ANSWER } from "./fake-client";
import type { ChatEvent, MessageParams, PromptSource } from "./types";

const PARAMS: MessageParams = {
  model: "claude-opus-5",
  max_tokens: 1024,
  system: [{ type: "text", text: "system" }],
  messages: [{ role: "user", content: [{ type: "text", text: "対応エリアはどこまでですか" }] }],
};

const SOURCES: PromptSource[] = [
  {
    index: 1,
    docId: "kaisha",
    chunkId: "kaisha#1",
    title: "会社概要",
    url: "https://example.com/about",
    breadcrumb: "会社概要 › 対応エリア",
  },
];

describe("createFakeClient", () => {
  it("決まった答えを何回かに分けて流す", async () => {
    const events: ChatEvent[] = [];
    const result = await streamAnswer({
      client: createFakeClient(),
      params: PARAMS,
      sources: SOURCES,
      onEvent: (event) => events.push(event),
    });
    expect(result.text).toBe(FAKE_ANSWER);
    expect(result.answered).toBe(true);
    expect(events.filter((event) => event.type === "text").length).toBeGreaterThan(1);
  });

  it("出典も 1 つ返す", async () => {
    const events: ChatEvent[] = [];
    const result = await streamAnswer({
      client: createFakeClient(),
      params: PARAMS,
      sources: SOURCES,
      onEvent: (event) => events.push(event),
    });
    expect(result.citations).toEqual([1]);
    expect(events).toContainEqual({
      type: "citation",
      index: 1,
      title: "会社概要 › 対応エリア",
      url: "https://example.com/about",
    });
  });

  it("答えの本文は敬体で、根拠の番号が入っている", () => {
    expect(FAKE_ANSWER).toContain("お伺いしております");
    expect(FAKE_ANSWER).toContain("[1]");
  });
});
