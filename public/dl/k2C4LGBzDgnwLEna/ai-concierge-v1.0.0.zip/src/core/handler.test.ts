import { describe, expect, it } from "vitest";
import { citationDelta, fakeClient, finalOf, textDelta } from "../../test/fake-anthropic";
import { resolveConfig } from "./config";
import { clientIpOf, createConcierge, escapeHtml, MAX_BODY_BYTES, parseChatBody, REMOTE_ADDR_HEADER, routeOf, sseLine } from "./handler";
import { buildIndexFile, toLoadedIndex } from "./index-store";
import { toCsv } from "./log";
import type { ChatEvent, ConciergeConfig, DocumentDraft, LoadedIndex } from "./types";

const DRAFTS: DocumentDraft[] = [
  {
    id: "kaisha",
    title: "会社概要",
    url: "https://example.com/about",
    updatedAt: null,
    chunks: [
      { id: "kaisha#1", heading: "対応エリア", breadcrumb: "会社概要 › 対応エリア", text: "市内と隣の三市にお伺いします。", tokens: 15 },
    ],
  },
];
const INDEX: LoadedIndex = toLoadedIndex(buildIndexFile(DRAFTS, "2026-09-12T00:00:00.000Z"));

function configOf(env: Record<string, string> = {}): ConciergeConfig {
  return resolveConfig({
    file: { site: { name: "みなと工務店", url: "https://example.com" }, contactUrl: "https://example.com/contact" },
    env: { ANTHROPIC_API_KEY: "sk-test", ...env },
  });
}

/** SSE の本文を ChatEvent の配列に戻す */
function parseSse(text: string): ChatEvent[] {
  return text
    .split("\n\n")
    .map((block) => block.trim())
    .filter((block) => block.startsWith("data: "))
    .map((block) => JSON.parse(block.slice(6)) as ChatEvent);
}

function chatRequest(body: unknown, init: RequestInit = {}): Request {
  return new Request("https://example.com/api/concierge/chat", {
    method: "POST",
    headers: { "content-type": "application/json", ...(init.headers as Record<string, string> | undefined) },
    body: JSON.stringify(body),
    ...init,
  });
}

describe("routeOf", () => {
  it("末尾で見分ける（どんな階層に置かれても動く）", () => {
    expect(routeOf("/api/concierge/chat")).toBe("chat");
    expect(routeOf("/chat")).toBe("chat");
    expect(routeOf("/api/concierge/health")).toBe("health");
    expect(routeOf("/api/concierge/admin")).toBe("admin");
    expect(routeOf("/api/concierge/admin/")).toBe("admin");
    expect(routeOf("/api/concierge/admin/export")).toBe("admin-export");
    expect(routeOf("/api/concierge/config")).toBe("config");
    expect(routeOf("/config")).toBe("config");
    expect(routeOf("/api/concierge")).toBe("none");
  });
});

describe("clientIpOf", () => {
  const requestWith = (headers: Record<string, string>): Request =>
    new Request("https://example.com/api/concierge/chat", { headers });

  it("既定ではアダプタが入れた接続元のアドレスだけを見る", () => {
    expect(clientIpOf(requestWith({ [REMOTE_ADDR_HEADER]: "203.0.113.9" }))).toBe("203.0.113.9");
  });

  it("trustProxy が false のとき x-forwarded-for は見ない（名乗るだけで枠を増やせないように）", () => {
    expect(clientIpOf(requestWith({ [REMOTE_ADDR_HEADER]: "203.0.113.9", "x-forwarded-for": "9.9.9.9" }))).toBe("203.0.113.9");
    expect(clientIpOf(requestWith({ "x-forwarded-for": "9.9.9.9" }))).toBe("unknown");
    expect(clientIpOf(requestWith({ "x-real-ip": "9.9.9.9" }))).toBe("unknown");
    expect(clientIpOf(requestWith({}))).toBe("unknown");
  });

  it("trustProxy が true のときは x-forwarded-for の末尾を使う（proxy が足した値）", () => {
    // nginx の $proxy_add_x_forwarded_for は、訪問者が名乗った値の後ろに本当の接続元を足す。
    // 先頭は訪問者が書けるので、末尾を見る
    expect(clientIpOf(requestWith({ "x-forwarded-for": "9.9.9.9, 203.0.113.9" }), true)).toBe("203.0.113.9");
    expect(clientIpOf(requestWith({ "x-forwarded-for": "203.0.113.9" }), true)).toBe("203.0.113.9");
    expect(clientIpOf(requestWith({ "x-real-ip": "203.0.113.9" }), true)).toBe("203.0.113.9");
    // proxy のヘッダーが無ければ、接続元のアドレスに戻る
    expect(clientIpOf(requestWith({ [REMOTE_ADDR_HEADER]: "10.0.0.1" }), true)).toBe("10.0.0.1");
  });

  it("trustProxy が true でも、訪問者が先頭に足した値では枠を増やせない", () => {
    // 訪問者が毎回ちがう値を先頭に名乗っても、末尾（proxy が足した値）は同じなので同じ枠になる
    const keys = new Set<string>();
    for (let i = 0; i < 12; i += 1) {
      keys.add(clientIpOf(requestWith({ "x-forwarded-for": `10.13.0.${i}, 203.0.113.9` }), true));
    }
    expect([...keys]).toEqual(["203.0.113.9"]);
  });
});

describe("parseChatBody", () => {
  it("質問と会話を取り出す", () => {
    expect(
      parseChatBody({ question: "料金は", history: [{ role: "user", content: "浴室" }, { role: "assistant", content: "はい。" }] }, 400),
    ).toEqual({ question: "料金は", history: [{ role: "user", content: "浴室" }, { role: "assistant", content: "はい。" }] });
  });

  it("形が違えば断る", () => {
    expect(() => parseChatBody({ question: 1 }, 400)).toThrow(/question/);
    expect(() => parseChatBody(null, 400)).toThrow(/question/);
  });

  it("会話は直近 12 件まで、おかしな行は捨てる", () => {
    const history = Array.from({ length: 20 }, (_, i) => ({ role: i % 2 === 0 ? "user" : "assistant", content: `x${i}` }));
    const parsed = parseChatBody({ question: "料金は", history: [...history, { role: "system", content: "無視" }] }, 400);
    expect(parsed.history).toHaveLength(12);
    expect(parsed.history[0]).toEqual({ role: "user", content: "x8" });
  });

  it("会話の 1 件が長すぎたら切る", () => {
    const parsed = parseChatBody({ question: "料金は", history: [{ role: "user", content: "あ".repeat(3000) }] }, 400);
    expect(parsed.history[0].content.length).toBe(1000);
  });

  it("history が無くてもよい", () => {
    expect(parseChatBody({ question: "料金は" }, 400).history).toEqual([]);
  });
});

describe("sseLine と escapeHtml", () => {
  it("1 件を data: 1 行にする", () => {
    expect(sseLine({ type: "text", text: "あ\nい" })).toBe('data: {"type":"text","text":"あ\\nい"}\n\n');
  });

  it("HTML の記号を逃がす", () => {
    expect(escapeHtml(`<b>"&'</b>`)).toBe("&lt;b&gt;&quot;&amp;&#39;&lt;/b&gt;");
  });
});

describe("/health", () => {
  it("索引の様子を返す", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(new Request("https://example.com/api/concierge/health"));
    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({
      ok: true,
      documents: 1,
      chunks: 1,
      totalTokens: 15,
      mode: "whole",
      builtAt: "2026-09-12T00:00:00.000Z",
    });
  });
});

describe("/config", () => {
  function configWithLabels(): ConciergeConfig {
    return resolveConfig({
      file: {
        site: { name: "みなと工務店", url: "https://example.com" },
        greeting: "こんにちは。みなと工務店の案内窓口です。",
        suggestions: ["対応エリアはどこまでですか", "見積もりは無料ですか"],
        contactUrl: "https://example.com/contact",
        labels: { open: "ご相談はこちら" },
      },
      env: { ANTHROPIC_API_KEY: "sk-test", ALLOWED_ORIGINS: "https://www.example.com" },
    });
  }

  it("窓の文言を合い言葉なしで返す", async () => {
    const concierge = createConcierge(configWithLabels(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(new Request("https://example.com/api/concierge/config"));
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("application/json; charset=utf-8");
    // 文言は変わらないので、ページを開くたびにサーバーを起こさない
    expect(response.headers.get("cache-control")).toBe("public, max-age=300");
    expect(await response.json()).toEqual({
      greeting: "こんにちは。みなと工務店の案内窓口です。",
      suggestions: ["対応エリアはどこまでですか", "見積もりは無料ですか"],
      contactUrl: "https://example.com/contact",
      labels: { open: "ご相談はこちら" },
    });
  });

  it("鍵や合い言葉、上限の設定は入れない", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), { index: INDEX, client: fakeClient() });
    const body = await (await concierge.fetch(new Request("https://example.com/api/concierge/config"))).text();
    expect(Object.keys(JSON.parse(body)).sort()).toEqual(["contactUrl", "greeting", "labels", "suggestions"]);
    expect(body).not.toContain("sk-test");
    expect(body).not.toContain("t0ken");
  });

  it("/chat と同じ送信元の決まりで断る", async () => {
    const concierge = createConcierge(configWithLabels(), { index: INDEX, client: fakeClient() });
    const allowed = await concierge.fetch(
      new Request("https://example.com/api/concierge/config", { headers: { origin: "https://www.example.com" } }),
    );
    expect(allowed.status).toBe(200);
    expect(allowed.headers.get("access-control-allow-origin")).toBe("https://www.example.com");

    const denied = await concierge.fetch(
      new Request("https://example.com/api/concierge/config", { headers: { origin: "https://evil.example" } }),
    );
    expect(denied.status).toBe(403);
    expect(denied.headers.get("access-control-allow-origin")).toBe(null);
  });

  it("OPTIONS には 204、POST には 405", async () => {
    const concierge = createConcierge(configWithLabels(), { index: INDEX, client: fakeClient() });
    const options = await concierge.fetch(
      new Request("https://example.com/api/concierge/config", {
        method: "OPTIONS",
        headers: { origin: "https://www.example.com" },
      }),
    );
    expect(options.status).toBe(204);
    expect(options.headers.get("access-control-allow-methods")).toBe("GET, OPTIONS");
    expect((await concierge.fetch(new Request("https://example.com/api/concierge/config", { method: "POST" }))).status).toBe(405);
  });
});

describe("/chat", () => {
  it("答えを SSE で流す", async () => {
    const client = fakeClient({
      events: [textDelta("市内と隣の三市です。"), citationDelta(0, "市内と隣の三市にお伺いします。")],
    });
    const concierge = createConcierge(configOf(), { index: INDEX, client, now: () => 1000 });
    const response = await concierge.fetch(chatRequest({ question: "対応エリアはどこまでですか" }));
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("text/event-stream; charset=utf-8");
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(parseSse(await response.text())).toEqual([
      { type: "text", text: "市内と隣の三市です。" },
      { type: "citation", index: 1, title: "会社概要 › 対応エリア", url: "https://example.com/about" },
      { type: "done", answered: true },
    ]);
  });

  it("資料は先頭の user に置き、送った質問は最後の user に置く", async () => {
    const client = fakeClient({ events: [textDelta("はい。")] });
    const concierge = createConcierge(configOf(), { index: INDEX, client });
    await (await concierge.fetch(chatRequest({ question: "対応エリアはどこまでですか" }))).text();
    const messages = client.calls[0].messages;
    const first = messages[0].content as unknown as Array<Record<string, unknown>>;
    expect(first[0].type).toBe("document");
    expect(messages[messages.length - 1]).toEqual({
      role: "user",
      content: [{ type: "text", text: "対応エリアはどこまでですか" }],
    });
  });

  it("GET は断る", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(new Request("https://example.com/api/concierge/chat"));
    expect(response.status).toBe(405);
  });

  it("許していない送信元は 403", async () => {
    const concierge = createConcierge(configOf({ ALLOWED_ORIGINS: "https://example.com" }), {
      index: INDEX,
      client: fakeClient(),
    });
    const response = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { origin: "https://evil.example" } }));
    expect(response.status).toBe(403);
    expect(await response.json()).toEqual({
      ok: false,
      code: "forbidden",
      message: "このページからのご利用は受け付けておりません。",
    });
  });

  it("長すぎる質問は 413", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(chatRequest({ question: "あ".repeat(401) }));
    expect(response.status).toBe(413);
    expect((await response.json()).message).toBe("質問は 400 字以内でお願いします。");
  });

  it("content-length が上限を超えていたら本文を読まずに 413", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(
      chatRequest(
        { question: "料金は" },
        { headers: { "content-length": String(MAX_BODY_BYTES + 1) } },
      ),
    );
    expect(response.status).toBe(413);
    expect(await response.json()).toEqual({
      ok: false,
      code: "too_long",
      message: "送信できる内容の大きさを超えています。",
    });
  });

  it("content-length が無くても、大きすぎる本文は 413", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(
      new Request("https://example.com/api/concierge/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: "a".repeat(MAX_BODY_BYTES + 1),
      }),
    );
    expect(response.status).toBe(413);
    expect((await response.json()).code).toBe("too_long");
  });

  it("壊れた JSON は 400 で答える（500 にしない）", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(
      new Request("https://example.com/api/concierge/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: '{"question": ',
      }),
    );
    expect(response.status).toBe(400);
    expect(await response.json()).toEqual({
      ok: false,
      code: "unavailable",
      message: "ご質問を読み取れませんでした。",
    });
  });

  it("回数を超えたら 429", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient({ events: [textDelta("はい。")] }), now: () => 1000 });
    for (let i = 0; i < 10; i += 1) {
      const ok = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { [REMOTE_ADDR_HEADER]: "1.2.3.4" } }));
      await ok.text();
    }
    const response = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { [REMOTE_ADDR_HEADER]: "1.2.3.4" } }));
    expect(response.status).toBe(429);
    expect((await response.json()).code).toBe("rate_limited");
  });

  it("接続元が違えば別に数える", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient({ events: [textDelta("はい。")] }), now: () => 1000 });
    for (let i = 0; i < 10; i += 1) {
      await (await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { [REMOTE_ADDR_HEADER]: "1.2.3.4" } }))).text();
    }
    const other = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { [REMOTE_ADDR_HEADER]: "5.6.7.8" } }));
    expect(other.status).toBe(200);
    await other.text();
  });

  it("TRUST_PROXY が無いときは x-forwarded-for を名乗っても枠が増えない", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient({ events: [textDelta("はい。")] }), now: () => 1000 });
    for (let i = 0; i < 10; i += 1) {
      const ok = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { "x-forwarded-for": `10.0.0.${i}` } }));
      await ok.text();
    }
    const response = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { "x-forwarded-for": "10.0.0.99" } }));
    expect(response.status).toBe(429);
  });

  it("TRUST_PROXY=1 のときは x-forwarded-for ごとに数える", async () => {
    const concierge = createConcierge(configOf({ TRUST_PROXY: "1" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。")] }),
      now: () => 1000,
    });
    for (let i = 0; i < 10; i += 1) {
      const ok = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { "x-forwarded-for": "1.2.3.4" } }));
      expect(ok.status).toBe(200);
      await ok.text();
    }
    expect((await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { "x-forwarded-for": "1.2.3.4" } }))).status).toBe(429);
    // 訪問者が先頭に別の値を名乗っても、末尾が同じなら同じ枠のまま
    const spoofed = await concierge.fetch(
      chatRequest({ question: "料金は" }, { headers: { "x-forwarded-for": "10.13.0.7, 1.2.3.4" } }),
    );
    expect(spoofed.status).toBe(429);
    const other = await concierge.fetch(chatRequest({ question: "料金は" }, { headers: { "x-forwarded-for": "5.6.7.8" } }));
    expect(other.status).toBe(200);
    await other.text();
  });

  it("1 日の上限を超えたら丁寧に断る", async () => {
    const concierge = createConcierge(configOf({ DAILY_QUESTION_LIMIT: "1" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。")] }),
      now: () => 1000,
    });
    await (await concierge.fetch(chatRequest({ question: "料金は" }))).text();
    const response = await concierge.fetch(chatRequest({ question: "料金は" }));
    expect(response.status).toBe(429);
    expect((await response.json()).code).toBe("daily_limit");
  });

  it("鍵が無ければお詫びを流す", async () => {
    const config = resolveConfig({ file: { site: { name: "みなと工務店" } }, env: {} });
    const concierge = createConcierge(config, { index: INDEX });
    const response = await concierge.fetch(chatRequest({ question: "料金は" }));
    expect(response.status).toBe(200);
    expect(parseSse(await response.text())).toEqual([
      { type: "error", code: "unavailable", message: "いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。" },
      { type: "done", answered: false },
    ]);
  });

  it("OPTIONS には 204 で答える", async () => {
    const concierge = createConcierge(configOf({ ALLOWED_ORIGINS: "https://www.example.com" }), {
      index: INDEX,
      client: fakeClient(),
    });
    const response = await concierge.fetch(
      new Request("https://example.com/api/concierge/chat", { method: "OPTIONS", headers: { origin: "https://www.example.com" } }),
    );
    expect(response.status).toBe(204);
    expect(response.headers.get("access-control-allow-origin")).toBe("https://www.example.com");
    expect(response.headers.get("access-control-allow-methods")).toBe("POST, OPTIONS");
  });
});

describe("記録", () => {
  it("答えられた質問を残す（個人情報は伏せる）", async () => {
    const client = fakeClient({
      events: [textDelta("市内と隣の三市です。[1]"), citationDelta(0, "市内と隣の三市にお伺いします。")],
    });
    const concierge = createConcierge(configOf(), { index: INDEX, client, now: () => Date.parse("2026-09-12T03:00:00.000Z") });
    await (await concierge.fetch(chatRequest({ question: "090-1234-5678 です。対応エリアは" }))).text();
    const entries = concierge.log.list();
    expect(entries).toHaveLength(1);
    expect(entries[0].question).toBe("*** です。対応エリアは");
    expect(entries[0].answerHead).toBe("市内と隣の三市です。[1]");
    expect(entries[0].answered).toBe(true);
    expect(entries[0].model).toBe("claude-opus-5");
    expect(entries[0].at).toBe("2026-09-12T03:00:00.000Z");
  });

  it("答えられなかった質問は未回答に入る", async () => {
    const client = fakeClient({ events: [textDelta("その点は資料に載っていません。")] });
    const concierge = createConcierge(configOf(), { index: INDEX, client });
    await (await concierge.fetch(chatRequest({ question: "駐車場はありますか" }))).text();
    expect(concierge.log.unanswered().map((entry) => entry.question)).toEqual(["駐車場はありますか"]);
  });

  it("途中で切れた答えは、そのことも残す", async () => {
    const client = fakeClient({
      events: [textDelta("八十万円から百五十万円が目安です。[1] 内訳は"), citationDelta(0, "八十万円")],
      final: finalOf({ stop_reason: "max_tokens" }),
    });
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), { index: INDEX, client });
    await (await concierge.fetch(chatRequest({ question: "キッチンはいくらですか" }))).text();
    expect(concierge.log.list()[0].truncated).toBe(true);
    const html = await (await concierge.fetch(new Request("https://example.com/api/concierge/admin?token=t0ken"))).text();
    expect(html).toContain("<th>途中で切れた</th>");
    const csv = await (await concierge.fetch(new Request("https://example.com/api/concierge/admin/export?token=t0ken"))).text();
    expect(csv.split("\n")[1].endsWith(",はい,いいえ")).toBe(true);
  });

  it("LOG_WEBHOOK_URL があれば 1 件ごとに送る", async () => {
    const posted: unknown[] = [];
    const fakeFetch = (async (_url: string, init?: RequestInit) => {
      posted.push(JSON.parse(String(init?.body)));
      return new Response("", { status: 200 });
    }) as unknown as typeof fetch;
    const concierge = createConcierge(configOf({ LOG_WEBHOOK_URL: "https://hooks.example.com/a", LOG_WEBHOOK_FORMAT: "slack" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。[1]"), citationDelta(0, "市内と隣の三市にお伺いします。")] }),
      fetch: fakeFetch,
    });
    await (await concierge.fetch(chatRequest({ question: "料金は" }))).text();
    expect(posted).toHaveLength(1);
    expect(String((posted[0] as { text: string }).text)).toContain("［みなと工務店 案内窓口］回答");
  });
});

describe("/admin", () => {
  it("ADMIN_TOKEN が無ければ 404（在ることを知らせない）", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    expect((await concierge.fetch(new Request("https://example.com/api/concierge/admin"))).status).toBe(404);
  });

  it("合い言葉が違えば 401", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), { index: INDEX, client: fakeClient() });
    expect((await concierge.fetch(new Request("https://example.com/api/concierge/admin?token=x"))).status).toBe(401);
  });

  it("合えば一覧を返す", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。")] }),
    });
    await (await concierge.fetch(chatRequest({ question: "<script>料金</script>は" }))).text();
    const response = await concierge.fetch(new Request("https://example.com/api/concierge/admin?token=t0ken"));
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("text/html; charset=utf-8");
    const html = await response.text();
    expect(html).toContain("&lt;script&gt;料金&lt;/script&gt;は");
    expect(html).not.toContain("<script>料金");
  });

  it("キャッシュから読めたトークン数を出す（効いているか買い手が確かめられる）", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。")] }),
    });
    await (await concierge.fetch(chatRequest({ question: "料金は" }))).text();
    const html = await (await concierge.fetch(new Request("https://example.com/api/concierge/admin?token=t0ken"))).text();
    expect(html).toContain("<th>キャッシュ読み</th>");
    expect(html).toContain("<td>29800</td>");
  });

  it("未回答だけに絞れる", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。[1]"), citationDelta(0, "市内と隣の三市にお伺いします。")] }),
    });
    await (await concierge.fetch(chatRequest({ question: "料金は" }))).text();
    const html = await (await concierge.fetch(new Request("https://example.com/api/concierge/admin?token=t0ken&unanswered=1"))).text();
    expect(html).toContain("未回答のみ");
    expect(html).not.toContain("料金は");
  });

  it("ご質問に印のような字が入っていても、それを合い言葉に置き換えない", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。[1]"), citationDelta(0, "市内")] }),
    });
    await (await concierge.fetch(chatRequest({ question: "__TOKEN__ の扱いは" }))).text();
    const html = await (await concierge.fetch(new Request("https://example.com/api/concierge/admin?token=t0ken"))).text();
    // 表のご質問はそのまま
    expect(html).toContain("<td>__TOKEN__ の扱いは</td>");
    // リンクにだけ合い言葉が入る
    expect(html).toContain('<a href="?token=t0ken">すべて</a>');
    expect(html).toContain('<a href="export?token=t0ken">CSV で書き出す</a>');
  });

  it("合い言葉は URL に安全な形でリンクに入る", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "あ い&x" }), { index: INDEX, client: fakeClient() });
    const html = await (
      await concierge.fetch(new Request(`https://example.com/api/concierge/admin?token=${encodeURIComponent("あ い&x")}`))
    ).text();
    expect(html).toContain(`<a href="?token=${encodeURIComponent("あ い&x")}">すべて</a>`);
    expect(html).not.toContain("token=あ い&x");
  });

  it("Bearer でも通る", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), { index: INDEX, client: fakeClient() });
    const response = await concierge.fetch(
      new Request("https://example.com/api/concierge/admin", { headers: { authorization: "Bearer t0ken" } }),
    );
    expect(response.status).toBe(200);
  });
});

describe("/admin/export", () => {
  it("CSV を返す", async () => {
    const concierge = createConcierge(configOf({ ADMIN_TOKEN: "t0ken" }), {
      index: INDEX,
      client: fakeClient({ events: [textDelta("はい。")] }),
    });
    await (await concierge.fetch(chatRequest({ question: "料金は" }))).text();
    const response = await concierge.fetch(new Request("https://example.com/api/concierge/admin/export?token=t0ken"));
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("text/csv; charset=utf-8");
    expect(response.headers.get("content-disposition")).toBe('attachment; filename="ai-concierge-log.csv"');
    const csv = await response.text();
    expect(csv.split("\n")[0]).toBe(
      "受付日時,質問,答えの先頭,出典,答えられたか,所要ms,モデル,入力トークン,出力トークン,キャッシュ読み,途中で切れた,途中で切断",
    );
    expect(csv).toContain("料金は");
  });
});

describe("窓を閉じられたとき", () => {
  it("上流の問い合わせを止め、途中で切断として残す", async () => {
    const client = fakeClient({ events: [textDelta("市内と"), textDelta("隣の三市です。")] });
    const concierge = createConcierge(configOf(), { index: INDEX, client });
    const response = await concierge.fetch(chatRequest({ question: "対応エリアはどこまでですか" }));
    // 1 つ読んだところで窓を閉じる
    const reader = response.body!.getReader();
    await reader.read();
    await reader.cancel();

    // start() が終わって記録が入るまで待つ
    for (let i = 0; i < 50 && concierge.log.size() === 0; i += 1) {
      await new Promise((done) => setTimeout(done, 5));
    }
    expect(client.aborts).toBe(1);
    const entry = concierge.log.list()[0];
    expect(entry.disconnected).toBe(true);
    expect(entry.answered).toBe(false);
    const csv = toCsv([entry]);
    expect(csv.split("\n")[1].endsWith(",いいえ,はい")).toBe(true);
  });

  it("最後まで読まれたときは、切断として残さない", async () => {
    const client = fakeClient({ events: [textDelta("はい。[1]"), citationDelta(0, "市内")] });
    const concierge = createConcierge(configOf(), { index: INDEX, client });
    await (await concierge.fetch(chatRequest({ question: "料金は" }))).text();
    expect(client.aborts).toBe(0);
    expect(concierge.log.list()[0].disconnected).toBe(false);
  });
});

describe("知らない道", () => {
  it("404", async () => {
    const concierge = createConcierge(configOf(), { index: INDEX, client: fakeClient() });
    expect((await concierge.fetch(new Request("https://example.com/api/concierge"))).status).toBe(404);
  });
});
