import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { buildIndexFile, toLoadedIndex } from "./index-store";
import { neighbourOf, retrievalMode, retrieve, searchQuery } from "./retrieve";
import type { ConciergeConfig, DocumentDraft, LoadedIndex } from "./types";

// 概算トークンは手で決める（合計 86）。片の並びは
// kaisha#1(24) kaisha#2(15) price#1(20) price#2(14) faq#1(13)
const DRAFTS: DocumentDraft[] = [
  {
    id: "kaisha",
    title: "会社概要",
    url: "https://example.com/about",
    updatedAt: null,
    chunks: [
      { id: "kaisha#1", heading: "", breadcrumb: "会社概要", text: "わたしたちは住まいの改修を専門とする工務店です。", tokens: 24 },
      { id: "kaisha#2", heading: "対応エリア", breadcrumb: "会社概要 › 対応エリア", text: "市内と隣の三市にお伺いします。", tokens: 15 },
    ],
  },
  {
    id: "price",
    title: "料金",
    url: "https://example.com/price",
    updatedAt: null,
    chunks: [
      { id: "price#1", heading: "目安", breadcrumb: "料金 › 目安", text: "キッチンの入れ替えは八十万円が目安です。", tokens: 20 },
      { id: "price#2", heading: "お支払い", breadcrumb: "料金 › お支払い", text: "着工時に半金をいただきます。", tokens: 14 },
    ],
  },
  {
    id: "faq",
    title: "よくあるご質問",
    url: null,
    updatedAt: null,
    chunks: [
      { id: "faq#1", heading: "工事中の暮らし", breadcrumb: "よくあるご質問 › 工事中の暮らし", text: "工事中も住み続けられます。", tokens: 13 },
    ],
  },
];

const INDEX: LoadedIndex = toLoadedIndex(buildIndexFile(DRAFTS, "2026-09-12T00:00:00.000Z"));
// この質問の 2-gram（エリ・リア・アは・はど・どち・ちら・らま・まで）は
// kaisha#2 の見出し「対応エリア」にしか出てこない
const QUESTION = "エリアはどちらまで";

function configOf(patch: Record<string, unknown> = {}): ConciergeConfig {
  return resolveConfig({ file: { site: { name: "みなと工務店" }, ...patch } });
}

describe("retrievalMode", () => {
  it("総トークンが上限以下なら全文投入", () => {
    expect(INDEX.stats.totalTokens).toBe(86);
    expect(retrievalMode(INDEX, 86)).toBe("whole");
    expect(retrievalMode(INDEX, 60000)).toBe("whole");
  });

  it("超えたら BM25", () => {
    expect(retrievalMode(INDEX, 85)).toBe("bm25");
  });
});

describe("searchQuery", () => {
  it("会話の続きでは、直前の質問とつないで探す", () => {
    expect(
      searchQuery("それはいくらですか", [
        { role: "user", content: "浴室の工事はできますか" },
        { role: "assistant", content: "はい、承っております。" },
      ]),
    ).toBe("浴室の工事はできますか それはいくらですか");
  });

  it("最初の質問はそのまま", () => {
    expect(searchQuery("料金は", [])).toBe("料金は");
  });

  it("直前が答えだけなら、その前の質問を使う", () => {
    expect(
      searchQuery("いくらですか", [
        { role: "user", content: "浴室" },
        { role: "assistant", content: "はい。" },
      ]),
    ).toBe("浴室 いくらですか");
  });
});

describe("neighbourOf", () => {
  it("同じ文書の次の片", () => {
    expect(neighbourOf(INDEX, INDEX.byId.get("kaisha#1")!)?.chunk.id).toBe("kaisha#2");
  });

  it("次が無ければ前の片", () => {
    expect(neighbourOf(INDEX, INDEX.byId.get("kaisha#2")!)?.chunk.id).toBe("kaisha#1");
  });

  it("1 片だけの文書は隣が無い", () => {
    expect(neighbourOf(INDEX, INDEX.byId.get("faq#1")!)).toBe(null);
  });
});

describe("retrieve（全文投入）", () => {
  it("索引の片をすべて、索引の順で返す", () => {
    const result = retrieve({ index: INDEX, config: configOf(), question: QUESTION, history: [] });
    expect(result.mode).toBe("whole");
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["kaisha#1", "kaisha#2", "price#1", "price#2", "faq#1"]);
    expect(result.tokens).toBe(86);
    expect(result.budget).toBe(60000);
  });
});

describe("retrieve（BM25）", () => {
  it("当たった片と、その隣の片を返す", () => {
    const result = retrieve({ index: INDEX, config: configOf(), question: QUESTION, history: [], mode: "bm25" });
    expect(result.mode).toBe("bm25");
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["kaisha#2", "kaisha#1"]);
    expect(result.tokens).toBe(39); // 15 + 24
    expect(result.budget).toBe(20000); // floor(60000 / 3)
  });

  it("alwaysInclude の文書は当たらなくても全部入れ、先に並べる", () => {
    const result = retrieve({
      index: INDEX,
      config: configOf({ alwaysInclude: ["料金"] }),
      question: QUESTION,
      history: [],
      mode: "bm25",
    });
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["price#1", "price#2", "kaisha#2", "kaisha#1"]);
  });

  it("alwaysInclude に使うのは予算の半分まで（答える片を押し出さない）", () => {
    // 予算 = floor(120 / 3) = 40、alwaysInclude の枠 = floor(40 / 2) = 20。
    // 料金は price#1(20) で枠がいっぱいになり、price#2(14) は入らない。
    // そのおかげで、質問に当たった kaisha#2(15) が残る
    //（枠が無いと price#1 + price#2 = 34 で埋まり、当たった片が 1 つも入らなくなる）
    const result = retrieve({
      index: INDEX,
      config: { ...configOf({ alwaysInclude: ["料金"] }), retrieval: { wholeCorpusMaxTokens: 120, topK: 8 } },
      question: QUESTION,
      history: [],
      mode: "bm25",
    });
    expect(result.budget).toBe(40);
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["price#1", "kaisha#2"]);
    expect(result.tokens).toBe(35);

    // 枠が足りれば、これまでどおり先に並ぶ
    const roomy = retrieve({
      index: INDEX,
      config: { ...configOf({ alwaysInclude: ["料金"] }), retrieval: { wholeCorpusMaxTokens: 600, topK: 8 } },
      question: QUESTION,
      history: [],
      mode: "bm25",
    });
    expect(roomy.entries.map((entry) => entry.chunk.id)).toEqual(["price#1", "price#2", "kaisha#2", "kaisha#1"]);
  });

  it("上限（wholeCorpusMaxTokens の 1/3）を超える片は入れない", () => {
    // resolveConfig は wholeCorpusMaxTokens を 1000 以上に検証する（config.ts）。
    // retrieve() 自体はその検証に依存しないので、切り捨てのロジックだけを
    // 直に確かめるためここでは検証を経由しない ConciergeConfig を組み立てる。
    const result = retrieve({
      index: INDEX,
      config: { ...configOf(), retrieval: { wholeCorpusMaxTokens: 60, topK: 8 } },
      question: QUESTION,
      history: [],
      mode: "bm25",
    });
    expect(result.budget).toBe(20); // floor(60 / 3)
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["kaisha#2"]); // 15 は入る、+24 は超える
    expect(result.tokens).toBe(15);
  });

  it("topK で数を絞る", () => {
    // 「工事の目安」は price#1（目安）と faq#1（工事）の 2 片に当たり、price#1 の点がわずかに高い
    const question = "工事の目安";
    const all = retrieve({
      index: INDEX,
      config: configOf({ retrieval: { wholeCorpusMaxTokens: 60000, topK: 8 } }),
      question,
      history: [],
      mode: "bm25",
    });
    expect(all.entries.map((entry) => entry.chunk.id)).toEqual(["price#1", "price#2", "faq#1"]);

    const one = retrieve({
      index: INDEX,
      config: configOf({ retrieval: { wholeCorpusMaxTokens: 60000, topK: 1 } }),
      question,
      history: [],
      mode: "bm25",
    });
    expect(one.entries.map((entry) => entry.chunk.id)).toEqual(["price#1", "price#2"]);
  });

  it("当たった片が隣どうしでも、同じ片を二度は入れない", () => {
    // 「工務店の対応エリア」は kaisha#2（見出しの 対応エリア）と kaisha#1（工務店）の両方に当たる
    const result = retrieve({ index: INDEX, config: configOf(), question: "工務店の対応エリア", history: [], mode: "bm25" });
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["kaisha#2", "kaisha#1"]);
    expect(result.tokens).toBe(39);
  });

  it("どこにも当たらなければ空（alwaysInclude が無いとき）", () => {
    const result = retrieve({ index: INDEX, config: configOf(), question: "xyzzy", history: [], mode: "bm25" });
    expect(result.entries).toEqual([]);
    expect(result.tokens).toBe(0);
  });

  it("総トークンが上限を超えていれば、mode を渡さなくても BM25 になる", () => {
    // 同じ理由（config.ts の 1000 下限）で、86 を下回る上限は resolveConfig を
    // 経由できない。ここも検証を経由しない ConciergeConfig で「超えた」状態を作る。
    const result = retrieve({
      index: INDEX,
      config: { ...configOf(), retrieval: { wholeCorpusMaxTokens: 60, topK: 8 } },
      question: QUESTION,
      history: [],
    });
    expect(result.mode).toBe("bm25");
    // budget = floor(60 / 3) = 20。15 は入るが、+24 で 39 になり上限を超える
    expect(result.entries.map((entry) => entry.chunk.id)).toEqual(["kaisha#2"]);
  });
});
