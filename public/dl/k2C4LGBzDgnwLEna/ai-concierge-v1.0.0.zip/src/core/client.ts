import Anthropic from "@anthropic-ai/sdk";
import type {
  AnthropicClientLike,
  FinalMessageLike,
  MessageParams,
  MessageStreamLike,
  StreamEventLike,
} from "./types";

/**
 * 本物の SDK に触る唯一の場所。ここから先は AnthropicClientLike しか見ない
 * （テストは偽のクライアントを差し込み、窓の束には SDK が混ざらない）。
 *
 * MessageParams はこちらで決めた最小の形なので、SDK の広い引数の型へは
 * そのまま渡せない。渡す中身は streaming.md と citations の資料どおりに
 * 組んであるので、ここで 1 回だけ型を外す。
 */
export function createAnthropicClient(apiKey: string): AnthropicClientLike {
  const client = new Anthropic({ apiKey });
  return {
    messages: {
      stream(params: MessageParams): MessageStreamLike {
        const stream = client.messages.stream(params as never);
        return {
          [Symbol.asyncIterator]: () => stream[Symbol.asyncIterator]() as unknown as AsyncIterator<StreamEventLike>,
          finalMessage: () => stream.finalMessage() as unknown as Promise<FinalMessageLike>,
          // 訪問者が窓を閉じたら、Anthropic への問い合わせも止める。
          // 止めないと、誰も読まない答えの続きが最後まで課金される
          abort: () => {
            if (typeof stream.abort === "function") stream.abort();
            else stream.controller.abort();
          },
        };
      },
    },
  };
}
