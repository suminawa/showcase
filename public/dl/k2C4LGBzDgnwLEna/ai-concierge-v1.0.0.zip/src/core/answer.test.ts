import { describe, expect, it } from "vitest";
import { citationDelta, fakeClient, finalOf, textDelta } from "../../test/fake-anthropic";
import { NOT_IN_DOCUMENTS, NOT_IN_DOCUMENTS_RE, streamAnswer, UNAVAILABLE_MESSAGE, usageOf } from "./answer";
import type { ChatEvent, MessageParams, PromptSource } from "./types";

const PARAMS: MessageParams = {
  model: "claude-opus-5",
  max_tokens: 1024,
  system: [{ type: "text", text: "system", cache_control: { type: "ephemeral" } }],
  messages: [{ role: "user", content: [{ type: "text", text: "対応エリアはどこまでですか" }] }],
  output_config: { effort: "low" },
};

const SOURCES: PromptSource[] = [
  {
    index: 1,
    docId: "kaisha",
    chunkId: "kaisha#1",
    title: "会社概要",
    url: "https://example.com/about",
    breadcrumb: "会社概要 › 対応エリア",
  },
  { index: 2, docId: "price", chunkId: "price#1", title: "料金", url: null, breadcrumb: "料金 › 目安" },
];

function collect(): { events: ChatEvent[]; onEvent: (event: ChatEvent) => void } {
  const events: ChatEvent[] = [];
  return { events, onEvent: (event) => events.push(event) };
}

describe("usageOf", () => {
  it("使った数を拾う", () => {
    expect(usageOf(finalOf())).toEqual({
      inputTokens: 120,
      outputTokens: 80,
      cacheReadTokens: 29800,
      cacheCreationTokens: 0,
    });
  });

  it("無ければ 0", () => {
    expect(usageOf(null)).toEqual({ inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 });
    expect(usageOf({ stop_reason: "end_turn" })).toEqual({
      inputTokens: 0,
      outputTokens: 0,
      cacheReadTokens: 0,
      cacheCreationTokens: 0,
    });
  });
});

describe("streamAnswer", () => {
  it("字の増分をそのまま流し、最後に done を出す", async () => {
    const sink = collect();
    const client = fakeClient({
      events: [textDelta("市内と"), textDelta("隣の三市です。[1]"), citationDelta(0, "市内と隣の三市にお伺いします。")],
    });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(sink.events).toEqual([
      { type: "text", text: "市内と" },
      { type: "text", text: "隣の三市です。[1]" },
      { type: "citation", index: 1, title: "会社概要 › 対応エリア", url: "https://example.com/about" },
      { type: "done", answered: true },
    ]);
    expect(result.text).toBe("市内と隣の三市です。[1]");
    expect(result.answered).toBe(true);
    expect(result.truncated).toBe(false);
    expect(result.stopReason).toBe("end_turn");
    expect(result.error).toBe(null);
  });

  it("送った params をそのままクライアントへ渡す", async () => {
    const sink = collect();
    const client = fakeClient({});
    await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(client.calls).toHaveLength(1);
    expect(client.calls[0]).toBe(PARAMS);
  });

  it("citations_delta を出典の番号・題名・リンクに変える", async () => {
    const sink = collect();
    const client = fakeClient({
      events: [textDelta("市内と隣の三市です。"), citationDelta(0, "市内と隣の三市にお伺いします。")],
    });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(sink.events[1]).toEqual({
      type: "citation",
      index: 1,
      title: "会社概要 › 対応エリア",
      url: "https://example.com/about",
    });
    expect(result.citations).toEqual([1]);
  });

  it("同じ文書の出典は 1 回だけ出す", async () => {
    const sink = collect();
    const client = fakeClient({ events: [citationDelta(1, "あ"), citationDelta(1, "い"), citationDelta(0, "う")] });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.citations).toEqual([2, 1]);
    expect(sink.events.filter((event) => event.type === "citation")).toHaveLength(2);
  });

  it("送っていない文書の番号は捨てる", async () => {
    const sink = collect();
    const client = fakeClient({ events: [citationDelta(9, "あ")] });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.citations).toEqual([]);
    expect(sink.events).toEqual([{ type: "done", answered: false, reason: "no_citations" }]);
  });

  it("流れて来なかったときは finalMessage の citations を拾う", async () => {
    const sink = collect();
    const client = fakeClient({
      events: [textDelta("八十万円が目安です。")],
      final: finalOf({
        content: [
          {
            type: "text",
            text: "八十万円が目安です。",
            citations: [{ type: "char_location", cited_text: "八十万円", document_index: 1, start_char_index: 0, end_char_index: 4 }],
          },
        ],
      }),
    });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.citations).toEqual([2]);
    expect(sink.events).toEqual([
      { type: "text", text: "八十万円が目安です。" },
      { type: "citation", index: 2, title: "料金 › 目安", url: null },
      { type: "done", answered: true },
    ]);
  });

  it("断られたら（refusal）お詫びを出し、未回答にする", async () => {
    const sink = collect();
    const client = fakeClient({
      events: [textDelta("…")],
      final: finalOf({ stop_reason: "refusal", stop_details: { type: "refusal", category: "other", explanation: "" } }),
    });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(sink.events[sink.events.length - 2]).toEqual({
      type: "error",
      code: "unavailable",
      message: UNAVAILABLE_MESSAGE,
      clear: true,
    });
    expect(sink.events[sink.events.length - 1]).toEqual({ type: "done", answered: false, reason: "error" });
    expect(result.answered).toBe(false);
    expect(result.stopReason).toBe("refusal");
    expect(result.error).toBe("refusal");
  });

  it("流れている途中で落ちたらお詫びを出す", async () => {
    const sink = collect();
    const client = fakeClient({ streamError: new Error("boom") });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(sink.events).toEqual([
      { type: "error", code: "unavailable", message: UNAVAILABLE_MESSAGE },
      { type: "done", answered: false, reason: "error" },
    ]);
    expect(result.answered).toBe(false);
    expect(result.error).toBe("boom");
  });

  it("finalMessage で落ちてもお詫びを出す", async () => {
    const sink = collect();
    const client = fakeClient({ events: [textDelta("あ")], finalError: new Error("late") });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.answered).toBe(false);
    expect(result.error).toBe("late");
    expect(sink.events[sink.events.length - 1]).toEqual({ type: "done", answered: false, reason: "error" });
  });

  it("「資料に載っていません」と答えたら未回答として残す", async () => {
    const sink = collect();
    const client = fakeClient({ events: [textDelta(`その点は${NOT_IN_DOCUMENTS}。`)] });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.answered).toBe(false);
    expect(result.error).toBe(null);
    // お詫びは出さない（断りとして正しい答えなので、そのまま見せる）
    expect(sink.events).toEqual([
      { type: "text", text: `その点は${NOT_IN_DOCUMENTS}。` },
      { type: "done", answered: false, reason: "not_in_documents" },
    ]);
  });

  it("言い方が違っても「資料に無い」は未回答にする", async () => {
    for (const text of [
      "その点は資料に載っていません。",
      "その点は資料には見当たりません。",
      "恐れ入りますが、資料に記載がございません。",
      "資料にございませんので、お問い合わせください。",
      "その点はお答えできかねます。",
    ]) {
      const sink = collect();
      const client = fakeClient({ events: [textDelta(text), citationDelta(0, "あ")] });
      const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
      expect(result.answered, text).toBe(false);
      expect(result.error).toBe(null);
    }
    expect(NOT_IN_DOCUMENTS_RE.test("市内と隣の三市にお伺いしております。")).toBe(false);
    // prompt にお願いしている言い方も、当然ひっかかる
    expect(NOT_IN_DOCUMENTS_RE.test(`その点は${NOT_IN_DOCUMENTS}。`)).toBe(true);
  });

  it("出典が 1 つも付かなかった答えは未回答にする（資料から答えた裏づけが無い）", async () => {
    const sink = collect();
    const client = fakeClient({ events: [textDelta("たしか八十万円くらいだと思います。")] });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.answered).toBe(false);
    expect(result.citations).toEqual([]);
    // お詫びは出さない（答えそのものはそのまま見せる）
    expect(sink.events).toEqual([
      { type: "text", text: "たしか八十万円くらいだと思います。" },
      { type: "done", answered: false, reason: "no_citations" },
    ]);
  });

  it("max_tokens で切れたら「…」を足して流し、途中で切れたと記録する", async () => {
    const sink = collect();
    const client = fakeClient({
      events: [textDelta("八十万円から百五十万円が目安です。[1] 内訳は"), citationDelta(0, "八十万円")],
      final: finalOf({ stop_reason: "max_tokens" }),
    });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.truncated).toBe(true);
    expect(result.stopReason).toBe("max_tokens");
    expect(result.text.endsWith("…")).toBe(true);
    expect(sink.events[sink.events.length - 2]).toEqual({ type: "text", text: "…" });
    expect(sink.events[sink.events.length - 1]).toEqual({ type: "done", answered: true });
  });

  it("途中まで出ていた字が無ければ、消す指示は出さない", async () => {
    const sink = collect();
    const client = fakeClient({ streamError: new Error("boom") });
    await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(sink.events[0]).toEqual({ type: "error", code: "unavailable", message: UNAVAILABLE_MESSAGE });
  });

  it("途中まで出ていたら、消す指示を付けてお詫びを出す", async () => {
    const sink = collect();
    const client = fakeClient({ events: [textDelta("八十万円ほ")], finalError: new Error("late") });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.truncated).toBe(false);
    expect(sink.events[sink.events.length - 2]).toEqual({
      type: "error",
      code: "unavailable",
      message: UNAVAILABLE_MESSAGE,
      clear: true,
    });
  });

  it("未回答の理由を done に添える（窓が問い合わせボタンの出し方を決められるように）", async () => {
    const reasonOf = async (script: Parameters<typeof fakeClient>[0]): Promise<string | undefined> => {
      const sink = collect();
      await streamAnswer({ client: fakeClient(script), params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
      const done = sink.events[sink.events.length - 1];
      return done.type === "done" ? done.reason : undefined;
    };
    expect(await reasonOf({ events: [textDelta(`その点は${NOT_IN_DOCUMENTS}。`), citationDelta(0, "あ")] })).toBe("not_in_documents");
    expect(await reasonOf({ events: [textDelta("八十万円ほどです。")] })).toBe("no_citations");
    expect(await reasonOf({ streamError: new Error("boom") })).toBe("error");
    // 答えられたときは理由を付けない
    expect(await reasonOf({ events: [textDelta("八十万円です。[1]"), citationDelta(0, "八十万円")] })).toBe(undefined);
  });

  it("使った数を返す", async () => {
    const sink = collect();
    const client = fakeClient({ events: [textDelta("あ")] });
    const result = await streamAnswer({ client, params: PARAMS, sources: SOURCES, onEvent: sink.onEvent });
    expect(result.usage).toEqual({
      inputTokens: 120,
      outputTokens: 80,
      cacheReadTokens: 29800,
      cacheCreationTokens: 0,
    });
  });
});
