import { scoreChunk, tokenize } from "./bm25";
import type { ChatTurn, ConciergeConfig, IndexEntry, LoadedIndex } from "./types";

export type RetrievalMode = "whole" | "bm25";

export interface RetrieveInput {
  index: LoadedIndex;
  config: ConciergeConfig;
  question: string;
  history: ChatTurn[];
  /** 評価やテストで切り替えを固定したいときだけ渡す */
  mode?: RetrievalMode;
}

export interface RetrieveResult {
  mode: RetrievalMode;
  entries: IndexEntry[];
  budget: number;
  tokens: number;
}

export function retrievalMode(index: LoadedIndex, wholeCorpusMaxTokens: number): RetrievalMode {
  return index.stats.totalTokens <= wholeCorpusMaxTokens ? "whole" : "bm25";
}

/** 会話の続きでは、直前の質問と今回の質問をつないで探す（「それはいくら」に備える） */
export function searchQuery(question: string, history: ChatTurn[]): string {
  for (let i = history.length - 1; i >= 0; i -= 1) {
    if (history[i].role === "user") return `${history[i].content} ${question}`;
  }
  return question;
}

export function alwaysIncludeEntries(index: LoadedIndex, names: string[]): IndexEntry[] {
  if (names.length === 0) return [];
  return index.entries.filter((entry) =>
    names.some((name) => name !== "" && (entry.doc.title === name || entry.doc.title.includes(name))),
  );
}

export function neighbourOf(index: LoadedIndex, entry: IndexEntry): IndexEntry | null {
  const next = entry.doc.chunks[entry.chunkIndex + 1];
  if (next !== undefined) return index.byId.get(next.id) ?? null;
  const previous = entry.doc.chunks[entry.chunkIndex - 1];
  if (previous !== undefined) return index.byId.get(previous.id) ?? null;
  return null;
}

export function retrieve(input: RetrieveInput): RetrieveResult {
  const { index, config } = input;
  const { wholeCorpusMaxTokens, topK } = config.retrieval;
  const mode = input.mode ?? retrievalMode(index, wholeCorpusMaxTokens);

  if (mode === "whole") {
    return { mode, entries: index.entries, budget: wholeCorpusMaxTokens, tokens: index.stats.totalTokens };
  }

  const queryTokens = tokenize(searchQuery(input.question, input.history));
  const hits = index.entries
    .map((entry, order) => ({ entry, order, score: scoreChunk(queryTokens, entry.chunk, index.stats) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => (b.score === a.score ? a.order - b.order : b.score - a.score))
    .slice(0, topK);

  const budget = Math.floor(wholeCorpusMaxTokens / 3);
  // alwaysInclude に使うのは、多くても予算の半分まで。
  // これが無いと、毎回送る文書を厚くしたときに、ご質問に答える片が押し出される
  const alwaysBudget = Math.floor(budget / 2);

  const entries: IndexEntry[] = [];
  const seen = new Set<string>();
  let tokens = 0;
  const add = (entry: IndexEntry | null, limit: number): void => {
    if (entry === null || seen.has(entry.chunk.id)) return;
    // 入らない片は飛ばして次を見る（大きな片 1 つで打ち切らない）
    if (tokens + entry.chunk.tokens > limit) return;
    seen.add(entry.chunk.id);
    entries.push(entry);
    tokens += entry.chunk.tokens;
  };
  for (const entry of alwaysIncludeEntries(index, config.alwaysInclude)) add(entry, alwaysBudget);
  for (const hit of hits) {
    add(hit.entry, budget);
    // 見出しの続きが切れないように、同じ文書の隣の片を 1 つ足す
    add(neighbourOf(index, hit.entry), budget);
  }
  return { mode, entries, budget, tokens };
}
