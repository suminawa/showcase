import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import type { DocumentDraft, IndexFile } from "./types";
import { buildIndexFile, emptyIndex, indexSummary, loadIndex, loadIndexFromJson, toLoadedIndex, validateIndex } from "./index-store";

function chunk(id: string, heading: string, text: string, tokens: number) {
  return { id, heading, breadcrumb: `会社案内 › ${heading}`, text, tokens, len: tokens, tf: { あい: 1 } };
}

const FILE: IndexFile = {
  version: 1,
  builtAt: "2026-09-12T00:00:00.000Z",
  documents: [
    {
      id: "kaisha",
      title: "会社案内",
      url: "https://example.com/about",
      updatedAt: null,
      chunks: [chunk("kaisha#1", "対応エリア", "あいうえお", 5), chunk("kaisha#2", "沿革", "かきくけこ", 5)],
    },
    {
      id: "price",
      title: "料金",
      url: null,
      updatedAt: "2026-09-01",
      chunks: [chunk("price#1", "内訳", "さしすせそ", 5)],
    },
  ],
  stats: { documents: 2, chunks: 3, totalTokens: 15, avgLen: 5, df: { あい: 3 } },
};

describe("validateIndex", () => {
  it("正しい索引はそのまま返す", () => {
    expect(validateIndex(JSON.parse(JSON.stringify(FILE)))).toEqual(FILE);
  });

  it("version が 1 でなければ断る", () => {
    expect(() => validateIndex({ ...FILE, version: 2 })).toThrow(
      "索引: version が 1 ではありません（いまの値: 2）。npx ai-concierge index で作り直してください",
    );
  });

  it("入れ物でなければ断る", () => {
    expect(() => validateIndex([])).toThrow(/入れ物/);
    expect(() => validateIndex(null)).toThrow(/入れ物/);
  });

  it("documents が一覧でなければ断る", () => {
    expect(() => validateIndex({ ...FILE, documents: {} })).toThrow(/documents/);
  });

  it("片に足りない項目があれば、どこが悪いか言う", () => {
    const broken = JSON.parse(JSON.stringify(FILE)) as Record<string, unknown>;
    (broken.documents as Array<{ chunks: Array<Record<string, unknown>> }>)[0].chunks[1].text = 42;
    expect(() => validateIndex(broken)).toThrow("索引: documents[0].chunks[1].text が文字列ではありません");
  });

  it("stats が無ければ断る", () => {
    const broken = JSON.parse(JSON.stringify(FILE)) as Record<string, unknown>;
    delete broken.stats;
    expect(() => validateIndex(broken)).toThrow(/stats/);
  });
});

describe("toLoadedIndex", () => {
  it("片を文書の順に平らに並べる", () => {
    const index = toLoadedIndex(FILE);
    expect(index.entries.map((entry) => entry.chunk.id)).toEqual(["kaisha#1", "kaisha#2", "price#1"]);
    expect(index.entries.map((entry) => [entry.docIndex, entry.chunkIndex])).toEqual([
      [0, 0],
      [0, 1],
      [1, 0],
    ]);
    expect(index.entries[2].doc.title).toBe("料金");
  });

  it("id から片を引ける", () => {
    const index = toLoadedIndex(FILE);
    expect(index.byId.get("kaisha#2")?.chunk.heading).toBe("沿革");
    expect(index.byId.get("ない")).toBe(undefined);
  });

  it("stats をそのまま持つ", () => {
    expect(toLoadedIndex(FILE).stats).toEqual(FILE.stats);
  });
});

describe("loadIndexFromJson", () => {
  it("文字列から読める", () => {
    const index = loadIndexFromJson(JSON.stringify(FILE));
    expect(index.entries).toHaveLength(3);
    expect(index.file.builtAt).toBe("2026-09-12T00:00:00.000Z");
  });

  it("JSON として読めなければ断る", () => {
    expect(() => loadIndexFromJson("{")).toThrow(/索引: JSON として読めません/);
  });
});

describe("loadIndex", () => {
  it("ファイルから読んで、読み込んだ形にする", async () => {
    const dir = await mkdtemp(join(tmpdir(), "ai-concierge-"));
    const path = join(dir, "index.json");
    await writeFile(path, JSON.stringify(FILE), "utf8");
    const index = await loadIndex(path);
    expect(index.stats.chunks).toBe(3);
    expect(index.byId.get("price#1")?.doc.id).toBe("price");
  });

  it("無ければ、作り方を添えて断る", async () => {
    const path = join(tmpdir(), "ai-concierge-none", "index.json");
    await expect(loadIndex(path)).rejects.toThrow(
      `索引: ${path} が見つかりません。npx ai-concierge index で作ってください`,
    );
  });

  it("見つからない以外の読み取りエラーはそのまま投げる", async () => {
    const dir = await mkdtemp(join(tmpdir(), "ai-concierge-"));
    await expect(loadIndex(dir)).rejects.toMatchObject({ code: "EISDIR" });
  });
});

describe("emptyIndex と indexSummary", () => {
  it("空の索引も形は同じ", () => {
    const index = emptyIndex("2026-09-12T00:00:00.000Z");
    expect(index.entries).toEqual([]);
    expect(index.stats).toEqual({ documents: 0, chunks: 0, totalTokens: 0, avgLen: 0, df: {} });
  });

  it("人が読める 1 行にする", () => {
    expect(indexSummary(toLoadedIndex(FILE))).toBe("文書 2 本・片 3 個・概算 15 トークン");
    expect(indexSummary(emptyIndex("2026-09-12T00:00:00.000Z"))).toBe("文書 0 本・片 0 個・概算 0 トークン");
  });
});

describe("buildIndexFile", () => {
  const drafts: DocumentDraft[] = [
    {
      id: "price",
      title: "料金",
      url: null,
      updatedAt: null,
      chunks: [
        { id: "price#1", heading: "料金", breadcrumb: "料金", text: "料金は 10 万円", tokens: 6 },
        { id: "price#2", heading: "保証", breadcrumb: "料金 › 保証", text: "保証は 10 年です", tokens: 8 },
      ],
    },
  ];

  it("片に語の数を足す", () => {
    const file = buildIndexFile(drafts, "2026-09-12T00:00:00.000Z");
    expect(file.documents[0].chunks[0]).toEqual({
      id: "price#1",
      heading: "料金",
      breadcrumb: "料金",
      text: "料金は 10 万円",
      tokens: 6,
      len: 6,
      tf: { 料金: 3, 金は: 1, "10": 1, 万円: 1 },
    });
    // breadcrumb「料金 › 保証」→ tokenize は ["料金","保証"] を 2 回（4 語）
    // + 本文 ["保証","証は","10","年で","です"] = 5 語。合わせて 9 語
    expect(file.documents[0].chunks[1].len).toBe(9);
    expect(file.documents[0].chunks[1].tf).toEqual({ 料金: 2, 保証: 3, 証は: 1, "10": 1, 年で: 1, です: 1 });
  });

  it("stats に df と avgLen を入れる", () => {
    const file = buildIndexFile(drafts, "2026-09-12T00:00:00.000Z");
    expect(file.version).toBe(1);
    expect(file.builtAt).toBe("2026-09-12T00:00:00.000Z");
    expect(file.stats.documents).toBe(1);
    expect(file.stats.chunks).toBe(2);
    expect(file.stats.totalTokens).toBe(14);
    expect(file.stats.avgLen).toBe(7.5); // (6 + 9) / 2
    // 「料金」は breadcrumb 経由で両方の片に入るので df は 2（他は変わらない）
    expect(file.stats.df).toEqual({ 料金: 2, 金は: 1, "10": 2, 万円: 1, 保証: 1, 証は: 1, 年で: 1, です: 1 });
  });

  it("作った索引はそのまま検証を通る", () => {
    const file = buildIndexFile(drafts, "2026-09-12T00:00:00.000Z");
    expect(validateIndex(JSON.parse(JSON.stringify(file)))).toEqual(file);
  });

  it("文書が無ければ空の索引", () => {
    expect(buildIndexFile([], "2026-09-12T00:00:00.000Z").stats).toEqual({
      documents: 0,
      chunks: 0,
      totalTokens: 0,
      avgLen: 0,
      df: {},
    });
  });
});
