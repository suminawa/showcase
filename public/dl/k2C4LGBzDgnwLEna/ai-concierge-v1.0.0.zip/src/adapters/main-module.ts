import { realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";

/**
 * 自分が「直接起動されたファイル」かどうか。npx の bin はシンボリックリンクなので、
 * 文字列の末尾ではなく実体のパスで比べる（`node dist/cli.js` でも `npx ai-concierge` でも true）
 */
export function isMainModule(argv1: string | undefined, selfUrl: string): boolean {
  if (argv1 === undefined) return false;
  try {
    return realpathSync(argv1) === realpathSync(fileURLToPath(selfUrl));
  } catch {
    return false;
  }
}
