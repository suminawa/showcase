import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, normalize, resolve, sep } from "node:path";
import { createAnthropicClient } from "../core/client";
import { loadConfigFile, resolveConfig } from "../core/config";
import { createFakeClient } from "../core/fake-client";
import { GUARD_MESSAGES } from "../core/guard";
import { createConcierge, MAX_BODY_BYTES, REMOTE_ADDR_HEADER, type Concierge } from "../core/handler";
import { indexSummary, loadIndex } from "../core/index-store";
import { isMainModule } from "./main-module";

export interface NodeServerOptions {
  /** 静的配信の根フォルダ。null なら静的配信をしない */
  staticDir?: string | null;
  /**
   * 指定すると、パスの先頭要素がこの一覧にあるものだけを配る（例: ["demo", "dist"]）。
   * "demo" を含む場合、素の "/" は "/demo/index.html" として扱う。
   * 省略時は staticDir 以下をすべて配り、"/" は staticDir 直下の index.html になる
   *（これまでの動作。買い手が自分のサイトを丸ごと staticDir に置く使い方はそのまま動く）。
   */
  staticPrefixes?: string[];
  apiPrefix?: string;
}

/** toWebRequest が本文の上限超えを知らせるための印。ここだけで捕まえて 413 にする */
class BodyTooLargeError extends Error {}

/** "x-forwarded-proto: https, http" のように並ぶことがあるので、先頭だけを見る */
function firstHeaderValue(value: string | string[] | undefined): string | undefined {
  if (value === undefined) return undefined;
  const first = (Array.isArray(value) ? value[0] : value.split(",")[0]).trim();
  return first === "" ? undefined : first;
}

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

export async function toWebRequest(req: IncomingMessage, origin: string): Promise<Request> {
  const url = new URL(req.url ?? "/", origin);
  const headers = new Headers();
  for (const [key, value] of Object.entries(req.headers)) {
    if (value === undefined) continue;
    headers.set(key, Array.isArray(value) ? value.join(", ") : value);
  }
  // 回数の上限は接続元のアドレスで数える。訪問者が同じ名前のヘッダーを送ってきても、
  // ここで必ず上書き（アドレスが取れなければ削除）して、名乗りをそのまま信じない
  const remoteAddress = req.socket.remoteAddress;
  if (remoteAddress !== undefined && remoteAddress !== "") headers.set(REMOTE_ADDR_HEADER, remoteAddress);
  else headers.delete(REMOTE_ADDR_HEADER);
  const method = req.method ?? "GET";
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") {
    return new Request(url, { method, headers });
  }
  const chunks: Uint8Array[] = [];
  let total = 0;
  for await (const chunk of req) {
    const piece = chunk as Uint8Array;
    total += piece.byteLength;
    // 上限を超えたぶんは溜めない。for-await から抜けることで req は自動で破棄される
    if (total > MAX_BODY_BYTES) throw new BodyTooLargeError();
    chunks.push(piece);
  }
  return new Request(url, { method, headers, body: Buffer.concat(chunks) });
}

export async function sendWebResponse(res: ServerResponse, response: Response): Promise<void> {
  // 相手が途中で切断すると書き込みが 'error' を投げることがある。落とさず無視する
  res.on("error", () => {});
  res.statusCode = response.status;
  response.headers.forEach((value, key) => res.setHeader(key, value));
  if (response.body === null) {
    res.end();
    return;
  }
  const reader = response.body.getReader();
  let clientGone = false;
  const onClientGone = (): void => {
    if (clientGone || res.writableEnded) return;
    clientGone = true;
    // 読み出し中の reader.read() を早く終わらせて、上流（Anthropic への問い合わせ）も止める
    reader.cancel().catch(() => {});
  };
  res.once("close", onClientGone);
  res.req.once("close", onClientGone);
  try {
    for (;;) {
      if (clientGone || res.destroyed || res.writableEnded) break;
      const { done, value } = await reader.read();
      if (done) break;
      if (clientGone || res.destroyed || res.writableEnded) break;
      res.write(value);
      // SSE を溜め込まずに送り出す
      if (typeof (res as unknown as { flush?: () => void }).flush === "function") {
        (res as unknown as { flush: () => void }).flush();
      }
    }
  } finally {
    res.removeListener("close", onClientGone);
    res.req.removeListener("close", onClientGone);
  }
  if (!res.writableEnded && !res.destroyed) res.end();
}

async function serveStatic(
  res: ServerResponse,
  staticDir: string,
  pathname: string,
  prefixes?: string[],
): Promise<boolean> {
  const rootFile = prefixes?.includes("demo") ? "/demo/index.html" : "/index.html";
  const target = pathname === "/" ? rootFile : pathname;
  let relative: string;
  try {
    // 「/%ff」のような壊れた % 表記は decodeURIComponent が投げる。
    // 500 ではなく「そんな道は無い」（404）として扱う
    relative = normalize(decodeURIComponent(target)).replace(/^([/\\])+/, "");
  } catch {
    return false;
  }
  // prefixes があるときは、先頭要素がその一覧にある道だけを配る（data/ や package.json などを隠す）
  if (prefixes !== undefined && !prefixes.includes(relative.split(/[/\\]/)[0])) return false;
  const file = resolve(staticDir, relative);
  if (file !== resolve(staticDir) && !file.startsWith(resolve(staticDir) + sep)) return false;
  try {
    const body = await readFile(file);
    res.statusCode = 200;
    res.setHeader("content-type", MIME[extname(file)] ?? "application/octet-stream");
    res.setHeader("cache-control", "no-store");
    res.end(body);
    return true;
  } catch {
    return false;
  }
}

export function createNodeServer(concierge: Concierge, options: NodeServerOptions = {}): Server {
  const staticDir = options.staticDir === undefined ? null : options.staticDir;
  const staticPrefixes = options.staticPrefixes;
  const apiPrefix = options.apiPrefix ?? "/api/concierge";
  return createServer((req, res) => {
    // どの経路の応答でも、相手が先に切断したときの 'error' で落ちないようにする
    res.on("error", () => {});
    void (async () => {
      try {
        const host = req.headers.host ?? "127.0.0.1";
        // TLS を終端する proxy（Vercel・nginx など）の後ろでも自分の URL を正しく組み立てる
        const proto = firstHeaderValue(req.headers["x-forwarded-proto"]) ?? "http";
        const origin = `${proto}://${host}`;
        const pathname = new URL(req.url ?? "/", origin).pathname;
        if (pathname.startsWith(apiPrefix)) {
          let request: Request;
          try {
            request = await toWebRequest(req, origin);
          } catch (error) {
            if (!(error instanceof BodyTooLargeError)) throw error;
            res.statusCode = 413;
            res.setHeader("content-type", "application/json; charset=utf-8");
            res.end(JSON.stringify({ ok: false, code: "too_long", message: GUARD_MESSAGES.tooLarge }));
            return;
          }
          await sendWebResponse(res, await concierge.fetch(request));
          return;
        }
        if (staticDir !== null && (await serveStatic(res, staticDir, pathname, staticPrefixes))) return;
        res.statusCode = 404;
        res.end("Not Found");
      } catch (error) {
        // 中身（ファイルの置き場所など）は外に出さず、手元の記録にだけ残す
        console.error("ai-concierge:", error);
        if (res.headersSent || res.writableEnded) {
          if (!res.writableEnded) res.end();
          return;
        }
        res.statusCode = 500;
        res.end("Server Error");
      }
    })();
  });
}

/** node dist/adapters/node.js で立ち上がる。設定と索引はカレントから読む */
export async function main(): Promise<Server> {
  const config = resolveConfig({ file: await loadConfigFile("concierge.config.json"), env: process.env });
  const index = await loadIndex(config.indexPath);
  // CONCIERGE_FAKE=1 のときは鍵を使わず、決まった答えを返す（画面の確認用）
  const client =
    process.env.CONCIERGE_FAKE === "1"
      ? createFakeClient()
      : config.apiKey === null
        ? undefined
        : createAnthropicClient(config.apiKey);
  const concierge = createConcierge(config, { client, index });
  // 配る根はパッケージの根だが、demo/ と dist/ だけを公開する。
  // data/index.json や concierge.config.json、package.json、node_modules などは配らない
  const server = createNodeServer(concierge, { staticDir: process.cwd(), staticPrefixes: ["demo", "dist"] });
  const port = Number(process.env.PORT ?? 8787);
  server.listen(port, () => {
    console.log(`ai-concierge: http://127.0.0.1:${port}/demo/index.html を開いてください（${indexSummary(index)}）`);
  });
  return server;
}

if (isMainModule(process.argv[1], import.meta.url)) {
  void main();
}
