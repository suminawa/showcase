import { mkdtemp, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { describe, expect, it } from "vitest";
import { isMainModule } from "./main-module";

describe("isMainModule", () => {
  it("シンボリックリンク経由（npx の bin）でも自分だと分かる", async () => {
    const dir = await mkdtemp(join(tmpdir(), "ai-concierge-"));
    const real = join(dir, "cli.js");
    await writeFile(real, "", "utf8");
    const link = join(dir, "ai-concierge");
    await symlink(real, link);
    const self = pathToFileURL(real).href;
    expect(isMainModule(real, self)).toBe(true);
    expect(isMainModule(link, self)).toBe(true);
  });

  it("別のファイルや無いパス、引数なしは false", async () => {
    const dir = await mkdtemp(join(tmpdir(), "ai-concierge-"));
    const real = join(dir, "cli.js");
    const other = join(dir, "node.js");
    await writeFile(real, "", "utf8");
    await writeFile(other, "", "utf8");
    const self = pathToFileURL(real).href;
    expect(isMainModule(other, self)).toBe(false);
    expect(isMainModule(join(dir, "missing.js"), self)).toBe(false);
    expect(isMainModule(undefined, self)).toBe(false);
  });
});
