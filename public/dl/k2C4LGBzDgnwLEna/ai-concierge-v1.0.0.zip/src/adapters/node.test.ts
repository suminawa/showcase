import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { citationDelta, fakeClient, finalOf, textDelta } from "../../test/fake-anthropic";
import { resolveConfig } from "../core/config";
import { createConcierge, MAX_BODY_BYTES, REMOTE_ADDR_HEADER, type Concierge } from "../core/handler";
import { buildIndexFile, toLoadedIndex } from "../core/index-store";
import type { AnthropicClientLike, DocumentDraft, FinalMessageLike, MessageStreamLike, StreamEventLike } from "../core/types";
import { createNodeServer } from "./node";

const DRAFTS: DocumentDraft[] = [
  {
    id: "kaisha",
    title: "会社概要",
    url: null,
    updatedAt: null,
    chunks: [{ id: "kaisha#1", heading: "対応エリア", breadcrumb: "会社概要 › 対応エリア", text: "市内です。", tokens: 6 }],
  },
];

const servers: Array<{ close(): void }> = [];

afterEach(() => {
  for (const server of servers.splice(0)) server.close();
});

async function startWith(client: AnthropicClientLike): Promise<string> {
  const concierge = createConcierge(
    resolveConfig({ file: { site: { name: "みなと工務店" } }, env: { ANTHROPIC_API_KEY: "sk-test" } }),
    { index: toLoadedIndex(buildIndexFile(DRAFTS, "2026-09-12T00:00:00.000Z")), client },
  );
  const server = createNodeServer(concierge, { staticDir: null });
  servers.push(server);
  await new Promise<void>((done) => server.listen(0, "127.0.0.1", done));
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
}

async function start(): Promise<string> {
  return startWith(fakeClient({ events: [textDelta("市内です。[1]"), citationDelta(0, "市内です。")] }));
}

async function startStatic(staticDir: string, staticPrefixes?: string[]): Promise<string> {
  const concierge = createConcierge(
    resolveConfig({ file: { site: { name: "みなと工務店" } }, env: { ANTHROPIC_API_KEY: "sk-test" } }),
    { index: toLoadedIndex(buildIndexFile(DRAFTS, "2026-09-12T00:00:00.000Z")), client: fakeClient({ events: [textDelta("市内です。")] }) },
  );
  const server = createNodeServer(concierge, { staticDir, staticPrefixes });
  servers.push(server);
  await new Promise<void>((done) => server.listen(0, "127.0.0.1", done));
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
}

/** 数回のテキスト差分を、タイマーをはさんでゆっくり流すだけの手作りクライアント */
function slowFakeClient(onStreamClosed: () => void): AnthropicClientLike {
  return {
    messages: {
      stream(): MessageStreamLike {
        return {
          async *[Symbol.asyncIterator](): AsyncGenerator<StreamEventLike> {
            try {
              yield textDelta("いち");
              await new Promise((resolve) => setTimeout(resolve, 150));
              yield textDelta("に");
              await new Promise((resolve) => setTimeout(resolve, 150));
              yield textDelta("さん");
            } finally {
              onStreamClosed();
            }
          },
          async finalMessage(): Promise<FinalMessageLike> {
            return finalOf();
          },
        };
      },
    },
  };
}

describe("createNodeServer", () => {
  it("/api/concierge/health に答える", async () => {
    const base = await start();
    const response = await fetch(`${base}/api/concierge/health`);
    expect(response.status).toBe(200);
    expect((await response.json()).chunks).toBe(1);
  });

  it("/api/concierge/chat が SSE を流す", async () => {
    const base = await start();
    const response = await fetch(`${base}/api/concierge/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question: "対応エリアはどこまでですか" }),
    });
    expect(response.headers.get("content-type")).toBe("text/event-stream; charset=utf-8");
    const text = await response.text();
    expect(text).toContain('data: {"type":"text","text":"市内です。[1]"}');
    expect(text).toContain('data: {"type":"done","answered":true}');
  });

  it("知らない道は 404", async () => {
    const base = await start();
    expect((await fetch(`${base}/nothing`)).status).toBe(404);
  });

  it("大きすぎる本文は読み切る前に 413 にし、その後も応答し続ける", async () => {
    const base = await start();
    const response = await fetch(`${base}/api/concierge/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "a".repeat(MAX_BODY_BYTES + 1),
    });
    expect(response.status).toBe(413);
    expect(await response.json()).toEqual({
      ok: false,
      code: "too_long",
      message: "送信できる内容の大きさを超えています。",
    });

    const health = await fetch(`${base}/api/concierge/health`);
    expect(health.status).toBe(200);
  });

  it("x-forwarded-proto を見て、TLS 終端の後ろでも同一オリジンと判定する", async () => {
    const base = await start();
    const host = new URL(base).host;

    const withProto = await fetch(`${base}/api/concierge/chat`, {
      method: "OPTIONS",
      headers: { origin: `https://${host}`, "x-forwarded-proto": "https" },
    });
    expect(withProto.headers.get("access-control-allow-origin")).toBe(`https://${host}`);

    const withoutProto = await fetch(`${base}/api/concierge/chat`, {
      method: "OPTIONS",
      headers: { origin: `https://${host}` },
    });
    expect(withoutProto.headers.get("access-control-allow-origin")).toBeNull();
  });

  it("接続元のアドレスを入れ、訪問者が名乗った同名のヘッダーは上書きする", async () => {
    const seen: Array<string | null> = [];
    const stub = {
      async fetch(request: Request): Promise<Response> {
        seen.push(request.headers.get(REMOTE_ADDR_HEADER));
        return new Response("ok");
      },
    } as unknown as Concierge;
    const server = createNodeServer(stub, { staticDir: null });
    servers.push(server);
    await new Promise<void>((done) => server.listen(0, "127.0.0.1", done));
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

    await fetch(`${base}/api/concierge/health`, { headers: { [REMOTE_ADDR_HEADER]: "9.9.9.9" } });
    expect(seen[0]).not.toBe("9.9.9.9");
    expect(seen[0]).toMatch(/127\.0\.0\.1|::1|::ffff:127\.0\.0\.1/);

    await fetch(`${base}/api/concierge/chat`, {
      method: "POST",
      headers: { "content-type": "application/json", [REMOTE_ADDR_HEADER]: "9.9.9.9" },
      body: JSON.stringify({ question: "料金は" }),
    });
    expect(seen[1]).not.toBe("9.9.9.9");
    expect(seen[1]).toMatch(/127\.0\.0\.1|::1|::ffff:127\.0\.0\.1/);
  });

  it("クライアントが切断したら上流への問い合わせも打ち切る", async () => {
    let streamClosed = false;
    const base = await startWith(slowFakeClient(() => (streamClosed = true)));

    const controller = new AbortController();
    const response = await fetch(`${base}/api/concierge/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question: "対応エリアはどこまでですか" }),
      signal: controller.signal,
    });
    const reader = response.body!.getReader();
    await reader.read();
    controller.abort();

    // finally が動くまで少し待つ（イベントは 150ms 間隔で流れる）
    await new Promise((resolve) => setTimeout(resolve, 400));
    expect(streamClosed).toBe(true);

    // 打ち切った後もサーバーは生きている
    const health = await fetch(`${base}/api/concierge/health`);
    expect(health.status).toBe(200);
  });
});

describe("createNodeServer の静的配信", () => {
  // パッケージの根と同じ並び: demo/index.html, dist/x.js, data/index.json, concierge.config.json,
  // package.json、そしてこれまでの動作を確かめるための直下 index.html
  let dir: string;

  beforeAll(async () => {
    dir = await mkdtemp(join(tmpdir(), "ai-concierge-static-"));
    await mkdir(join(dir, "demo"), { recursive: true });
    await mkdir(join(dir, "dist"), { recursive: true });
    await mkdir(join(dir, "data"), { recursive: true });
    await writeFile(join(dir, "demo", "index.html"), "<html>demo</html>");
    await writeFile(join(dir, "dist", "x.js"), "console.log('x');");
    await writeFile(join(dir, "data", "index.json"), "{}");
    await writeFile(join(dir, "concierge.config.json"), "{}");
    await writeFile(join(dir, "package.json"), "{}");
    await writeFile(join(dir, "index.html"), "<html>root</html>");
  });

  afterAll(async () => {
    await rm(dir, { recursive: true, force: true });
  });

  it("staticPrefixes を指定すると demo と dist だけを配り、data や設定・package.json は隠す", async () => {
    const base = await startStatic(dir, ["demo", "dist"]);

    const demo = await fetch(`${base}/demo/index.html`);
    expect(demo.status).toBe(200);
    expect(await demo.text()).toBe("<html>demo</html>");

    expect((await fetch(`${base}/dist/x.js`)).status).toBe(200);

    const root = await fetch(`${base}/`);
    expect(root.status).toBe(200);
    expect(await root.text()).toBe("<html>demo</html>");

    expect((await fetch(`${base}/data/index.json`)).status).toBe(404);
    expect((await fetch(`${base}/concierge.config.json`)).status).toBe(404);
    expect((await fetch(`${base}/package.json`)).status).toBe(404);
  });

  it("壊れた % 表記の道は 404（500 にしない）", async () => {
    const base = await startStatic(dir, ["demo", "dist"]);
    for (const path of ["/%ff", "/demo/%e0%a4%a", "/%"]) {
      const response = await fetch(`${base}${path}`);
      expect(response.status, path).toBe(404);
      expect(await response.text()).toBe("Not Found");
    }
  });

  it("思わぬ失敗のときは、中身を外に出さず決まった文だけ返す", async () => {
    // concierge.fetch がいきなり投げる形を作る（ファイルの置き場所などを外に出さないことの確認）
    const stub = {
      async fetch(): Promise<Response> {
        throw new Error("/Users/somebody/secret/path が読めません");
      },
    } as unknown as Concierge;
    const server = createNodeServer(stub, { staticDir: null });
    servers.push(server);
    await new Promise<void>((done) => server.listen(0, "127.0.0.1", done));
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
    const response = await fetch(`${base}/api/concierge/health`);
    expect(response.status).toBe(500);
    const body = await response.text();
    expect(body).toBe("Server Error");
    expect(body).not.toContain("/Users/");
  });

  it("staticPrefixes を省略すると、これまで通り staticDir 直下をすべて配る", async () => {
    const base = await startStatic(dir);

    const root = await fetch(`${base}/`);
    expect(root.status).toBe(200);
    expect(await root.text()).toBe("<html>root</html>");

    // 自分のサイトを丸ごと staticDir に置く既存の使い方は変わらない
    expect((await fetch(`${base}/data/index.json`)).status).toBe(200);
  });
});
