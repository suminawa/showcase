import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";
import { DEFAULT_ANSWER, DEFAULT_LIMITS, DEFAULT_RETRIEVAL } from "./core/config";
import { DEFAULT_LABELS } from "./widget/widget";

const root = new URL("../", import.meta.url);

async function readme(): Promise<string> {
  return await readFile(new URL("README.ja.md", root), "utf8");
}

describe("README と実物がずれていないか", () => {
  it("窓の文言の表が DEFAULT_LABELS と同じ", async () => {
    const text = await readme();
    for (const [key, value] of Object.entries(DEFAULT_LABELS)) {
      expect(text).toContain(`| \`${key}\` | ${value} |`);
    }
  });

  it("既定値の表が config.ts と同じ", async () => {
    const text = await readme();
    expect(text).toContain(`| \`answer.model\` | \`${DEFAULT_ANSWER.model}\``);
    expect(text).toContain(`| \`answer.maxTokens\` | \`${DEFAULT_ANSWER.maxTokens}\``);
    expect(text).toContain(`| \`retrieval.topK\` | \`${DEFAULT_RETRIEVAL.topK}\``);
    expect(text).toContain(`| \`limits.maxInputChars\` | \`${DEFAULT_LIMITS.maxInputChars}\``);
    expect(text).toContain(`| \`limits.dailyQuestions\` | \`${DEFAULT_LIMITS.dailyQuestions}\``);
  });

  it("環境変数の表が resolveConfig の読む名前をすべて載せている", async () => {
    const text = await readme();
    for (const name of [
      "ANTHROPIC_API_KEY",
      "ALLOWED_ORIGINS",
      "ADMIN_TOKEN",
      "LOG_WEBHOOK_URL",
      "LOG_WEBHOOK_FORMAT",
      "CONCIERGE_INDEX",
      "DAILY_QUESTION_LIMIT",
      "MAX_INPUT_CHARS",
      "TRUST_PROXY",
    ]) {
      expect(text).toContain(`| \`${name}\` |`);
    }
  });

  it("大げさな言い方をしていない", async () => {
    const text = await readme();
    for (const word of ["業界初", "圧倒的", "完全に", "何でも答え"]) {
      expect(text).not.toContain(word);
    }
  });
});
