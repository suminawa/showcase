import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";
import { DEFAULT_ANSWER } from "./core/config";

async function text(path: string): Promise<string> {
  return await readFile(new URL(`../${path}`, import.meta.url), "utf8");
}

describe("Next.js テンプレ", () => {
  it("版を固定している", async () => {
    const pkg = JSON.parse(await text("templates/nextjs/package.json")) as {
      dependencies: Record<string, string>;
      scripts: Record<string, string>;
    };
    expect(pkg.dependencies.next).toBe("16.2.11");
    expect(pkg.dependencies.react).toBe("19.2.4");
    expect(pkg.dependencies["react-dom"]).toBe("19.2.4");
    expect(pkg.dependencies["@suminawa/ai-concierge"]).toBe("file:./vendor/suminawa-ai-concierge-1.0.0.tgz");
    expect(pkg.scripts.postinstall).toBe("node scripts/copy-widget.mjs");
    // tgz は npm run pack:template / release が templates/nextjs/vendor に作る（リポジトリには置かない）
    const root = JSON.parse(await text("package.json")) as { scripts: Record<string, string> };
    expect(root.scripts["pack:template"]).toContain("npm pack --pack-destination templates/nextjs/vendor");
    expect(await text("templates/nextjs/vendor/README.md")).toContain("suminawa-ai-concierge-1.0.0.tgz");
  });

  it("route は公開面だけを使う", async () => {
    const route = await text("templates/nextjs/app/api/concierge/[...path]/route.ts");
    expect(route).toContain('from "@suminawa/ai-concierge"');
    expect(route).toContain("createConcierge");
    expect(route).toContain('export const runtime = "nodejs"');
    expect(route).toContain("export const maxDuration = 60");
    expect(route).not.toContain("ANTHROPIC_API_KEY");
  });

  it("設定の見本は既定値と同じモデル", async () => {
    const config = JSON.parse(await text("templates/nextjs/concierge.config.json")) as {
      answer: { model: string; effort: string; maxTokens: number };
    };
    expect(config.answer).toEqual(DEFAULT_ANSWER);
  });

  it("concierge.config.json と data/ を Vercel の束に含める", async () => {
    const config = await text("templates/nextjs/next.config.ts");
    expect(config).toContain("outputFileTracingIncludes");
    expect(config).toContain("./concierge.config.json");
    expect(config).toContain("./data/**/*");
  });

  it("窓の束を写せなかったら postinstall を失敗として扱う", async () => {
    const script = await text("templates/nextjs/scripts/copy-widget.mjs");
    expect(script).toContain("process.exitCode = 1");
  });

  it("content/ に見本の文書が入っている（初回の npm run index が通る）", async () => {
    const { readdir } = await import("node:fs/promises");
    const dir = new URL("../templates/nextjs/content/", import.meta.url);
    const names = (await readdir(dir)).filter((name) => name.endsWith(".md")).sort();
    expect(names).toEqual(["about.md", "faq.md"]);
    for (const name of names) {
      const source = await text(`templates/nextjs/content/${name}`);
      expect(source.startsWith("---")).toBe(true);
      expect(source).toMatch(/^#\s/m);
      // 見本であることを言い添える（実在の会社と取り違えられないように）
      expect(source).toContain("見本");
    }
    expect(await text("templates/nextjs/content/about.md")).toContain("架空の会社");
    expect(await text("templates/nextjs/README.md")).toContain("content/");
  });
});

describe("demo", () => {
  it("束と CSS を読み、鍵は書かない", async () => {
    const html = await text("demo/index.html");
    expect(html).toContain('href="../dist/ai-concierge.css"');
    expect(html).toContain('src="../dist/ai-concierge.js"');
    expect(html).toContain('data-endpoint="/api/concierge"');
    expect(html).not.toContain("sk-ant");
    expect(html).not.toContain("ANTHROPIC_API_KEY");
  });

  it("ページの中に置く形は、約束どおり中身が出る形になっている", async () => {
    const html = await text("demo/index.html");
    expect(html).toContain('<div id="ai-window"></div>');
    expect(html).toContain("AIConcierge.mount({");
    expect(html).toContain('target: "#ai-window"');
    // 右下の窓と会話が混ざらないよう、覚えておく名前を分ける
    expect(html).toContain('storageKey: "demo-inline"');
  });
});

describe("見本の文書", () => {
  it("架空の会社であることを断っている", async () => {
    expect(await text("samples/content/about.md")).toContain("架空の会社");
  });
});
