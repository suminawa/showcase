// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  bootstrap,
  DEFAULT_LABELS,
  fetchRemoteConfig,
  historyOf,
  mount,
  parseSse,
  renderAnswer,
  STORAGE_VERSION,
  type WidgetHandle,
} from "./widget";

const handles: WidgetHandle[] = [];

function sse(...lines: string[]): string {
  return lines.map((line) => `data: ${line}\n\n`).join("");
}

/** fetch を差し替えて、決めた本文を流す */
function fakeFetch(body: string, init: { status?: number; json?: unknown } = {}): ReturnType<typeof vi.fn> {
  const fake = vi.fn(async () => {
    if (init.json !== undefined) {
      return new Response(JSON.stringify(init.json), {
        status: init.status ?? 200,
        headers: { "content-type": "application/json" },
      });
    }
    return new Response(body, { status: init.status ?? 200, headers: { "content-type": "text/event-stream" } });
  });
  vi.stubGlobal("fetch", fake);
  return fake;
}

function open(options: Record<string, unknown> = {}): WidgetHandle {
  const handle = mount({ endpoint: "/api/concierge", ...options } as never);
  handles.push(handle);
  return handle;
}

afterEach(() => {
  for (const handle of handles.splice(0)) handle.destroy();
  document.body.innerHTML = "";
  vi.unstubAllGlobals();
});

describe("DEFAULT_LABELS", () => {
  it("設計書の文言をすべて敬体で持つ", () => {
    expect(DEFAULT_LABELS).toEqual({
      windowTitle: "案内窓口",
      open: "質問する",
      close: "閉じる",
      placeholder: "質問を入力してください",
      send: "送信",
      thinking: "調べています…",
      sources: "根拠",
      contact: "担当者に問い合わせる",
      reset: "最初から",
      answerDone: "答えが届きました",
      unavailable: "いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。",
      tooLong: "質問は 400 字以内でお願いします。",
      rateLimited: "少し時間をおいてからお試しください。",
      offline: "通信できませんでした。少し時間をおいてからお試しください。",
      emptyQuestion: "ご質問を入力してください。",
    });
  });
});

describe("parseSse", () => {
  it("切れ目までを取り出し、残りを返す", () => {
    const parsed = parseSse('data: {"type":"text","text":"あ"}\n\ndata: {"type":"te');
    expect(parsed.events).toEqual([{ type: "text", text: "あ" }]);
    expect(parsed.rest).toBe('data: {"type":"te');
  });

  it("壊れた行は捨てる", () => {
    expect(parseSse("data: {壊れ\n\n").events).toEqual([]);
  });
});

describe("historyOf", () => {
  it("答えられなかったやり取りは送らない", () => {
    expect(
      historyOf([
        { role: "user", text: "浴室", sources: [], failed: false },
        { role: "assistant", text: "はい。", sources: [], failed: false },
        { role: "user", text: "壊れ", sources: [], failed: false },
        { role: "assistant", text: "", sources: [], failed: true },
      ]),
    ).toEqual([
      { role: "user", content: "浴室" },
      { role: "assistant", content: "はい。" },
    ]);
  });

  it("直近 12 件まで", () => {
    const messages = Array.from({ length: 30 }, (_, i) => ({
      role: (i % 2 === 0 ? "user" : "assistant") as "user" | "assistant",
      text: `x${i}`,
      sources: [],
      failed: false,
    }));
    expect(historyOf(messages)).toHaveLength(12);
  });
});

describe("renderAnswer", () => {
  it("HTML を入れずに字として描く", () => {
    const el = document.createElement("div");
    renderAnswer(el, "<script>alert(1)</script>", []);
    expect(el.querySelector("script")).toBe(null);
    expect(el.textContent).toBe("<script>alert(1)</script>");
  });

  it("**太字** と行頭の - だけ変える", () => {
    const el = document.createElement("div");
    renderAnswer(el, "**料金**の目安\n- キッチン\n- 浴室", []);
    expect(el.querySelector("strong")?.textContent).toBe("料金");
    expect(el.querySelectorAll("li")).toHaveLength(2);
    expect(el.querySelectorAll("li")[1].textContent).toBe("浴室");
  });

  it("[1] を出典のリンクに変える", () => {
    const el = document.createElement("div");
    renderAnswer(el, "市内です。[1]", [{ index: 1, title: "会社概要 › 対応エリア", url: "https://example.com/about" }]);
    const link = el.querySelector("a");
    expect(link?.getAttribute("href")).toBe("https://example.com/about");
    expect(link?.getAttribute("rel")).toBe("noopener noreferrer");
    expect(link?.textContent).toBe("[1]");
  });

  it("http(s) 以外の出典はリンクにしない", () => {
    const el = document.createElement("div");
    renderAnswer(el, "市内です。[1]", [{ index: 1, title: "会社概要", url: "javascript:alert(1)" }]);
    expect(el.querySelector("a")).toBe(null);
    expect(el.querySelector("sup")?.textContent).toBe("[1]");
  });

  it("リンクの無い出典は番号のまま", () => {
    const el = document.createElement("div");
    renderAnswer(el, "八十万円です。[2]", [{ index: 2, title: "料金 › 目安", url: null }]);
    expect(el.querySelector("a")).toBe(null);
    expect(el.querySelector("sup")?.textContent).toBe("[2]");
  });

  it("知らない番号はそのままの字", () => {
    const el = document.createElement("div");
    renderAnswer(el, "[9] とは", []);
    expect(el.textContent).toBe("[9] とは");
  });
});

describe("窓の開け閉め", () => {
  it("最初は閉じていて、ボタンで開く", () => {
    const handle = open();
    const launcher = handle.el.querySelector<HTMLButtonElement>(".ac-launcher")!;
    const panel = handle.el.querySelector<HTMLElement>(".ac-panel")!;
    expect(launcher.textContent).toBe("質問する");
    expect(panel.hidden).toBe(true);
    launcher.click();
    expect(panel.hidden).toBe(false);
    expect(panel.getAttribute("role")).toBe("dialog");
    expect(panel.getAttribute("aria-label")).toBe("案内窓口");
  });

  it("閉じるボタンでも、ボタンに焦点を戻す", () => {
    const handle = open();
    const launcher = handle.el.querySelector<HTMLButtonElement>(".ac-launcher")!;
    const panel = handle.el.querySelector<HTMLElement>(".ac-panel")!;
    launcher.click();
    handle.el.querySelector<HTMLButtonElement>(".ac-close")!.click();
    expect(panel.hidden).toBe(true);
    expect(document.activeElement).toBe(launcher);
  });

  it("Esc で閉じる", () => {
    const handle = open();
    handle.open();
    handle.el.querySelector<HTMLElement>(".ac-panel")!.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Escape", bubbles: true }),
    );
    expect(handle.el.querySelector<HTMLElement>(".ac-panel")!.hidden).toBe(true);
  });

  it("あいさつと候補を出す", () => {
    const handle = open({ greeting: "ご案内します。", suggestions: ["料金は", "対応エリアは"] });
    handle.open();
    expect(handle.el.querySelector(".ac-greeting")?.textContent).toBe("ご案内します。");
    expect(handle.el.querySelectorAll(".ac-suggestion")).toHaveLength(2);
  });

  it("inline のときはボタンを出さず、その場に出す", () => {
    const host = document.createElement("div");
    host.id = "ai-window";
    document.body.appendChild(host);
    const handle = open({ target: "#ai-window" });
    expect(handle.el.querySelector(".ac-launcher")).toBe(null);
    expect(handle.el.querySelector<HTMLElement>(".ac-panel")!.hidden).toBe(false);
    expect(host.contains(handle.el)).toBe(true);
  });

  it("会話そのものは読み上げの対象にせず、知らせる場所を 1 つ用意する", () => {
    const handle = open();
    expect(handle.el.querySelector(".ac-log")?.getAttribute("aria-live")).toBe("off");
    const notice = handle.el.querySelector(".ac-notice");
    expect(notice).not.toBe(null);
    expect(notice?.getAttribute("role")).toBe("status");
    expect(notice?.textContent).toBe("");
  });
});

describe("質問を送る", () => {
  it("答えが流れて出て、根拠が並ぶ", async () => {
    const fake = fakeFetch(
      sse(
        '{"type":"text","text":"市内と隣の三市です。[1]"}',
        '{"type":"citation","index":1,"title":"会社概要 › 対応エリア","url":"https://example.com/about"}',
        '{"type":"done","answered":true}',
      ),
    );
    const handle = open();
    handle.open();
    await handle.ask("対応エリアはどこまでですか");
    expect(fake).toHaveBeenCalledWith("/api/concierge/chat", expect.objectContaining({ method: "POST" }));
    const answer = handle.el.querySelector(".ac-message-assistant")!;
    expect(answer.textContent).toContain("市内と隣の三市です。");
    const sources = handle.el.querySelector(".ac-sources")!;
    expect(sources.textContent).toContain("根拠");
    expect(sources.querySelector("a")?.getAttribute("href")).toBe("https://example.com/about");
  });

  it("会話を送る", async () => {
    const fake = fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open();
    await handle.ask("浴室はできますか");
    await handle.ask("いくらですか");
    const body = JSON.parse(String(fake.mock.calls[1][1].body)) as { question: string; history: unknown[] };
    expect(body.question).toBe("いくらですか");
    expect(body.history).toEqual([
      { role: "user", content: "浴室はできますか" },
      { role: "assistant", content: "はい。" },
    ]);
  });

  it("長すぎる質問は送らずに断る", async () => {
    const fake = fakeFetch("");
    const handle = open({ maxInputChars: 10 });
    handle.open();
    await handle.ask("あ".repeat(11));
    expect(fake).not.toHaveBeenCalled();
    // 文言は差し替えできる定文なので、字数を埋め込まない。上限を変える買い手は
    // labels.tooLong も一緒に差し替える（README の文言の表に載せてある）
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("質問は 400 字以内でお願いします。");
  });

  it("空の質問は送らない", async () => {
    const fake = fakeFetch("");
    const handle = open();
    await handle.ask("   ");
    expect(fake).not.toHaveBeenCalled();
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("ご質問を入力してください。");
  });

  it("429 のときはサーバーの言葉を出す", async () => {
    fakeFetch("", { status: 429, json: { ok: false, code: "rate_limited", message: "少し時間をおいてからお試しください。" } });
    const handle = open();
    await handle.ask("料金は");
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("少し時間をおいてからお試しください。");
  });

  it("通信できなければお詫びを出す", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        throw new Error("offline");
      }),
    );
    const handle = open();
    await handle.ask("料金は");
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("通信できませんでした。少し時間をおいてからお試しください。");
  });

  it("答えられなかったら問い合わせボタンを出す", async () => {
    fakeFetch(sse('{"type":"text","text":"その点は資料に載っていません。"}', '{"type":"done","answered":false}'));
    const handle = open({ contactUrl: "https://example.com/contact" });
    await handle.ask("駐車場は");
    const contact = handle.el.querySelector<HTMLAnchorElement>(".ac-contact")!;
    expect(contact.textContent).toBe("担当者に問い合わせる");
    expect(contact.getAttribute("href")).toBe("https://example.com/contact");
  });

  it("出典が付かなかっただけなら、問い合わせボタンは出さない", async () => {
    fakeFetch(
      sse(
        '{"type":"text","text":"八十万円ほどが目安です。"}',
        '{"type":"done","answered":false,"reason":"no_citations"}',
      ),
    );
    const handle = open({ contactUrl: "https://example.com/contact" });
    await handle.ask("キッチンはいくらですか");
    // 答えはそのまま見せる
    expect(handle.el.querySelector(".ac-message-assistant")?.textContent).toContain("八十万円ほどが目安です。");
    expect(handle.el.querySelector(".ac-contact")).toBe(null);
  });

  it("「資料に無い」と断られたときは問い合わせボタンを出す", async () => {
    fakeFetch(
      sse(
        '{"type":"text","text":"その点は資料に載っていません。"}',
        '{"type":"done","answered":false,"reason":"not_in_documents"}',
      ),
    );
    const handle = open({ contactUrl: "https://example.com/contact" });
    await handle.ask("駐車場は");
    expect(handle.el.querySelector(".ac-contact")).not.toBe(null);
  });

  it("失敗したときも問い合わせボタンを出す", async () => {
    fakeFetch(
      sse(
        '{"type":"error","code":"unavailable","message":"いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。"}',
        '{"type":"done","answered":false,"reason":"error"}',
      ),
    );
    const handle = open({ contactUrl: "https://example.com/contact" });
    await handle.ask("料金は");
    expect(handle.el.querySelector(".ac-contact")).not.toBe(null);
  });

  it("通信できなかったときも問い合わせボタンを出す", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        throw new Error("offline");
      }),
    );
    const handle = open({ contactUrl: "https://example.com/contact" });
    await handle.ask("料金は");
    expect(handle.el.querySelector(".ac-contact")).not.toBe(null);
  });

  it("理由を送らないサーバー相手では、未回答ならボタンを出す（これまでの動き）", async () => {
    fakeFetch(sse('{"type":"text","text":"…"}', '{"type":"done","answered":false}'));
    const handle = open({ contactUrl: "https://example.com/contact" });
    await handle.ask("駐車場は");
    expect(handle.el.querySelector(".ac-contact")).not.toBe(null);
  });

  it("問い合わせ先は同じサイトの中の道や mailto: も通す", async () => {
    for (const url of ["/contact", "contact.html", "#form", "mailto:hello@example.com", "https://example.com/contact"]) {
      fakeFetch(sse('{"type":"text","text":"…"}', '{"type":"done","answered":false}'));
      const handle = open({ contactUrl: url, storageKey: `contact-${url}` });
      await handle.ask("駐車場は");
      expect(handle.el.querySelector<HTMLAnchorElement>(".ac-contact")?.getAttribute("href"), url).toBe(url);
    }
  });

  it("開くと何かが動く書き方の問い合わせ先はボタンにしない", async () => {
    for (const url of ["javascript:alert(1)", "java\nscript:alert(1)", "data:text/html,<b>x</b>", "vbscript:msgbox(1)"]) {
      fakeFetch(sse('{"type":"text","text":"…"}', '{"type":"done","answered":false}'));
      const handle = open({ contactUrl: url, storageKey: `bad-${url}` });
      await handle.ask("駐車場は");
      expect(handle.el.querySelector(".ac-contact"), url).toBe(null);
    }
  });

  it("contactUrl が無ければボタンを出さない", async () => {
    fakeFetch(sse('{"type":"text","text":"…"}', '{"type":"done","answered":false}'));
    const handle = open();
    await handle.ask("駐車場は");
    expect(handle.el.querySelector(".ac-contact")).toBe(null);
  });

  it("clear 付きの error なら、言いかけの答えを消す", async () => {
    fakeFetch(
      sse(
        '{"type":"text","text":"八十万円ほ"}',
        '{"type":"citation","index":1,"title":"料金 › 目安","url":"https://example.com/price"}',
        '{"type":"error","code":"unavailable","message":"いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。","clear":true}',
        '{"type":"done","answered":false}',
      ),
    );
    const handle = open();
    await handle.ask("キッチンはいくらですか");
    expect(handle.el.querySelector(".ac-message-assistant")?.textContent).toBe("");
    expect(handle.el.querySelector(".ac-sources")).toBe(null);
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe(
      "いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。",
    );
  });

  it("clear が無い error なら、出ていた答えはそのまま残す", async () => {
    fakeFetch(
      sse(
        '{"type":"text","text":"八十万円が目安です。"}',
        '{"type":"error","code":"unavailable","message":"いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。"}',
        '{"type":"done","answered":false}',
      ),
    );
    const handle = open();
    await handle.ask("キッチンはいくらですか");
    expect(handle.el.querySelector(".ac-message-assistant")?.textContent).toContain("八十万円が目安です。");
  });

  it("error の件は窓の文言に置き換える", async () => {
    fakeFetch(
      sse('{"type":"error","code":"unavailable","message":"いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。"}', '{"type":"done","answered":false}'),
    );
    const handle = open();
    await handle.ask("料金は");
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe(
      "いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。",
    );
  });
});

describe("読み上げへの知らせ方", () => {
  it("答えが出そろったら 1 回だけ知らせる", async () => {
    fakeFetch(
      sse(
        '{"type":"text","text":"市内と"}',
        '{"type":"text","text":"隣の三市です。[1]"}',
        '{"type":"citation","index":1,"title":"会社概要 › 対応エリア","url":"https://example.com/about"}',
        '{"type":"done","answered":true}',
      ),
    );
    const handle = open();
    await handle.ask("対応エリアはどこまでですか");
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("答えが届きました");
    // 知らせる場所は 1 つだけ（増やさない）
    expect(handle.el.querySelectorAll(".ac-notice")).toHaveLength(1);
  });

  it("知らせる文言も差し替えられる", async () => {
    fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open({ labels: { answerDone: "The answer is ready." } });
    await handle.ask("Do you work on Saturdays?");
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("The answer is ready.");
  });

  it("流れている途中は、書かれている 1 件だけを描き直す（前のやり取りの節点は変えない）", async () => {
    fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open();
    await handle.ask("浴室はできますか");

    // 2 件目は、こちらの合図で少しずつ流す
    let push!: (chunk: string) => void;
    let finish!: () => void;
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        const encoder = new TextEncoder();
        push = (chunk) => controller.enqueue(encoder.encode(chunk));
        finish = () => controller.close();
      },
    });
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response(body, { status: 200, headers: { "content-type": "text/event-stream" } })),
    );
    const asking = handle.ask("工期はどれくらいですか");
    const tick = async (): Promise<void> => {
      await new Promise((done) => setTimeout(done, 0));
    };
    await tick();
    // やり取りが増えたところで会話は組み直される。ここから後は同じ節点のまま
    const firstAnswer = handle.el.querySelectorAll(".ac-message-assistant")[0];
    const userTurn = handle.el.querySelectorAll(".ac-message-user")[0];

    push('data: {"type":"text","text":"四日"}\n\n');
    await tick();
    expect(handle.el.querySelectorAll(".ac-message-assistant")[0]).toBe(firstAnswer);
    expect(handle.el.querySelectorAll(".ac-message-user")[0]).toBe(userTurn);

    push('data: {"type":"text","text":"ほどです。"}\n\n');
    await tick();
    expect(handle.el.querySelectorAll(".ac-message-assistant")[0]).toBe(firstAnswer);
    expect(handle.el.querySelectorAll(".ac-message-assistant")[1].textContent).toContain("四日ほどです。");
    // 途中では知らせる文を変えない（読み上げが 1 件の答えで何度も走らないように）
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("調べています…");

    push('data: {"type":"done","answered":true}\n\n');
    finish();
    await asking;
    expect(handle.el.querySelector(".ac-notice")?.textContent).toBe("答えが届きました");
  });

  it("最初からを押したときは会話ごと組み直す", async () => {
    fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open({ greeting: "ご案内します。" });
    await handle.ask("浴室はできますか");
    handle.reset();
    expect(handle.el.querySelectorAll(".ac-message")).toHaveLength(0);
    expect(handle.el.querySelector(".ac-greeting")?.textContent).toBe("ご案内します。");
  });
});

describe("入力欄", () => {
  function inputOf(handle: WidgetHandle): HTMLTextAreaElement {
    return handle.el.querySelector<HTMLTextAreaElement>(".ac-input")!;
  }

  it("textarea で、1 行から始まる", () => {
    const handle = open();
    const input = inputOf(handle);
    expect(input.tagName).toBe("TEXTAREA");
    expect(input.rows).toBe(1);
    expect(input.maxLength).toBe(400);
  });

  it("Enter で送信する", async () => {
    const fake = fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open();
    handle.open();
    const input = inputOf(handle);
    input.value = "工期はどれくらいですか";
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
    await new Promise((done) => setTimeout(done, 0));
    expect(fake).toHaveBeenCalledTimes(1);
    expect(JSON.parse(String(fake.mock.calls[0][1].body)).question).toBe("工期はどれくらいですか");
  });

  it("Shift+Enter では送らない（改行のため）", async () => {
    const fake = fakeFetch(sse('{"type":"done","answered":true}'));
    const handle = open();
    handle.open();
    const input = inputOf(handle);
    input.value = "1 行目";
    const event = new KeyboardEvent("keydown", { key: "Enter", shiftKey: true, bubbles: true, cancelable: true });
    input.dispatchEvent(event);
    await new Promise((done) => setTimeout(done, 0));
    expect(fake).not.toHaveBeenCalled();
    // 既定の動作（改行の入力）を邪魔しない
    expect(event.defaultPrevented).toBe(false);
  });

  it("改行を含む質問もそのまま送れる", async () => {
    const fake = fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open();
    await handle.ask("1 行目\n2 行目");
    expect(JSON.parse(String(fake.mock.calls[0][1].body)).question).toBe("1 行目\n2 行目");
  });

  it("maxInputChars が数でなければ既定の 400 に戻す（1 字も打てない窓にしない）", () => {
    const handle = open({ maxInputChars: Number.NaN });
    const input = inputOf(handle);
    expect(input.maxLength).toBe(400);
  });

  it("Tab の行き先に入力欄も入れる", () => {
    const handle = open();
    handle.open();
    const input = inputOf(handle);
    input.focus();
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", bubbles: true, cancelable: true }));
    // 焦点が窓の外へ出ていない
    expect(handle.el.contains(document.activeElement)).toBe(true);
  });
});

describe("覚えておく", () => {
  it("sessionStorage に残し、開き直しても続きが出る", async () => {
    fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const first = open({ storageKey: "demo" });
    await first.ask("浴室はできますか");
    expect(sessionStorage.getItem(`ai-concierge:${STORAGE_VERSION}:demo`)).toContain("浴室はできますか");
    first.destroy();
    handles.length = 0;
    const second = open({ storageKey: "demo" });
    expect(second.messages().map((message) => message.text)).toEqual(["浴室はできますか", "はい。"]);
  });

  it("最初からで消える", async () => {
    fakeFetch(sse('{"type":"text","text":"はい。"}', '{"type":"done","answered":true}'));
    const handle = open({ storageKey: "demo" });
    await handle.ask("浴室はできますか");
    handle.reset();
    expect(handle.messages()).toEqual([]);
    expect(sessionStorage.getItem(`ai-concierge:${STORAGE_VERSION}:demo`)).toBe(null);
  });
});

describe("bootstrap", () => {
  /** /config には渡した設定を、/chat には空の SSE を返す fetch */
  function fakeConfigFetch(config: unknown, init: { fail?: boolean; status?: number } = {}): ReturnType<typeof vi.fn> {
    const fake = vi.fn(async (url: string) => {
      if (String(url).endsWith("/config")) {
        if (init.fail === true) throw new Error("offline");
        return new Response(JSON.stringify(config), {
          status: init.status ?? 200,
          headers: { "content-type": "application/json" },
        });
      }
      return new Response("", { status: 200, headers: { "content-type": "text/event-stream" } });
    });
    vi.stubGlobal("fetch", fake);
    return fake;
  }

  function scriptTag(data: Record<string, string>): void {
    const tag = document.createElement("script");
    tag.dataset.endpoint = "/api/concierge";
    for (const [key, value] of Object.entries(data)) tag.dataset[key] = value;
    document.body.appendChild(tag);
  }

  it("script の属性で起動し、2 回読み込まれても窓は 1 つ", async () => {
    fakeConfigFetch({});
    scriptTag({ inline: "" });
    const first = await bootstrap(document);
    expect(first).not.toBe(null);
    handles.push(first!);
    expect(document.querySelectorAll(".ac-root")).toHaveLength(1);
    expect(document.querySelector(".ac-launcher")).not.toBe(null);
    expect(await bootstrap(document)).toBe(null);
    expect(document.querySelectorAll(".ac-root")).toHaveLength(1);
  });

  /** 読み込みが済むのを待つ（マイクロタスク 2 周ぶん） */
  async function settle(): Promise<void> {
    await new Promise((done) => setTimeout(done, 0));
    await new Promise((done) => setTimeout(done, 0));
  }
  const configCalls = (fake: ReturnType<typeof vi.fn>): unknown[] =>
    fake.mock.calls.filter((call) => String(call[0]).endsWith("/config"));

  it("ページを見ただけでは設定を読まない。窓を初めて開いたときに 1 回だけ読む", async () => {
    const fake = fakeConfigFetch({
      greeting: "こんにちは。みなと工務店の案内窓口です。",
      suggestions: ["対応エリアはどこまでですか", "見積もりは無料ですか"],
      contactUrl: "https://example.com/contact",
      labels: { open: "ご相談はこちら", send: "送る" },
    });
    scriptTag({});
    const handle = await bootstrap(document);
    handles.push(handle!);
    await settle();
    // 開く前は 1 度も読みに行かない（ページを見ただけでサーバーを起こさない）
    expect(configCalls(fake)).toHaveLength(0);
    expect(handle!.el.querySelector(".ac-launcher")?.textContent).toBe(DEFAULT_LABELS.open);

    handle!.el.querySelector<HTMLButtonElement>(".ac-launcher")!.click();
    await settle();
    expect(fake).toHaveBeenCalledWith("/api/concierge/config", expect.objectContaining({ signal: expect.anything() }));
    expect(configCalls(fake)).toHaveLength(1);
    expect(handle!.el.querySelector(".ac-greeting")?.textContent).toBe("こんにちは。みなと工務店の案内窓口です。");
    expect(handle!.el.querySelectorAll(".ac-suggestion")).toHaveLength(2);
    expect(handle!.el.querySelector(".ac-launcher")?.textContent).toBe("ご相談はこちら");
    expect(handle!.el.querySelector(".ac-send")?.textContent).toBe("送る");
    // 設定に無い文言は既定のまま
    expect(handle!.el.querySelector(".ac-close")?.textContent).toBe(DEFAULT_LABELS.close);

    // 開け閉めを繰り返しても読み直さない
    handle!.close();
    handle!.open();
    await settle();
    expect(configCalls(fake)).toHaveLength(1);
  });

  it("ページの中に置く形は、置いた直後に読む（最初から開いているため）", async () => {
    const fake = fakeConfigFetch({ greeting: "ページの中のあいさつ" });
    const host = document.createElement("div");
    host.id = "ai-window";
    document.body.appendChild(host);
    scriptTag({ inline: "#ai-window" });
    const handle = await bootstrap(document);
    handles.push(handle!);
    await settle();
    expect(configCalls(fake)).toHaveLength(1);
    expect(handle!.el.querySelector(".ac-greeting")?.textContent).toBe("ページの中のあいさつ");
  });

  it("data-* 属性は設定より強い", async () => {
    fakeConfigFetch({
      greeting: "設定のあいさつ",
      suggestions: ["設定の候補"],
      contactUrl: "https://example.com/setting",
      labels: { open: "設定のボタン", send: "設定の送信" },
    });
    scriptTag({
      greeting: "属性のあいさつ",
      suggestions: "属性の候補1|属性の候補2",
      contactUrl: "https://example.com/attribute",
      labels: JSON.stringify({ open: "属性のボタン" }),
    });
    const handle = await bootstrap(document);
    handles.push(handle!);
    handle!.open();
    await settle();
    expect(handle!.el.querySelector(".ac-greeting")?.textContent).toBe("属性のあいさつ");
    expect(handle!.el.querySelectorAll(".ac-suggestion")).toHaveLength(2);
    expect(handle!.el.querySelector(".ac-launcher")?.textContent).toBe("属性のボタン");
    // data-labels に無い鍵は、設定のものが残る
    expect(handle!.el.querySelector(".ac-send")?.textContent).toBe("設定の送信");
  });

  it("設定を読めなくても既定の文言で窓が使える", async () => {
    fakeConfigFetch({}, { fail: true });
    scriptTag({});
    const handle = await bootstrap(document);
    expect(handle).not.toBe(null);
    handles.push(handle!);
    handle!.open();
    await settle();
    expect(handle!.el.querySelector(".ac-launcher")?.textContent).toBe(DEFAULT_LABELS.open);
    expect(handle!.el.querySelector(".ac-greeting")).toBe(null);
    expect(handle!.el.querySelectorAll(".ac-suggestion")).toHaveLength(0);
    // 窓は開いたまま（読めなかったことで閉じたりしない）
    expect(handle!.el.querySelector<HTMLElement>(".ac-panel")!.hidden).toBe(false);
  });

  it("設定が壊れていても（JSON でない・404）既定の文言に戻る", async () => {
    fakeConfigFetch({ greeting: "出ないあいさつ" }, { status: 404 });
    scriptTag({});
    const handle = await bootstrap(document);
    handles.push(handle!);
    handle!.open();
    await settle();
    expect(handle!.el.querySelector(".ac-greeting")).toBe(null);
  });

  it("属性で全部書いてあれば、設定が届いても画面には触らない", async () => {
    fakeConfigFetch({
      greeting: "設定のあいさつ",
      suggestions: ["設定の候補"],
      contactUrl: "https://example.com/setting",
      labels: {},
    });
    scriptTag({ greeting: "属性のあいさつ", suggestions: "候補1|候補2", contactUrl: "/contact" });
    const handle = await bootstrap(document);
    handles.push(handle!);
    handle!.open();
    const before = handle!.el.querySelectorAll(".ac-suggestion")[0];
    await settle();
    // 候補のボタンが作り直されていない（押しかけの指が空を切らない）
    expect(handle!.el.querySelectorAll(".ac-suggestion")[0]).toBe(before);
    expect(handle!.el.querySelector(".ac-greeting")?.textContent).toBe("属性のあいさつ");
  });

  it("bootstrap はサーバーを待たずに返る（窓はすぐ出る）", async () => {
    // /config が永遠に返らない状況でも、窓はその場で出る
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: string) => {
        if (String(url).endsWith("/config")) return new Promise<Response>(() => {});
        return new Response("", { status: 200, headers: { "content-type": "text/event-stream" } });
      }),
    );
    scriptTag({});
    const handle = await bootstrap(document);
    handles.push(handle!);
    expect(handle!.el.querySelector(".ac-launcher")).not.toBe(null);
    handle!.open();
    await settle();
    expect(handle!.el.querySelector<HTMLElement>(".ac-panel")!.hidden).toBe(false);
    expect(handle!.el.querySelector(".ac-launcher")?.textContent).toBe(DEFAULT_LABELS.open);
  });

  it("AIConcierge.mount で置いた窓があっても、属性の窓は出る（demo の 2 つ置き）", async () => {
    fakeConfigFetch({});
    const host = document.createElement("div");
    host.id = "ai-window";
    document.body.appendChild(host);
    // demo/index.html と同じ順番: 先に手ずから置いてから、束の起動が走る
    handles.push(mount({ endpoint: "/api/concierge", target: "#ai-window", storageKey: "inline" }));
    scriptTag({ storageKey: "floating" });
    const auto = await bootstrap(document);
    expect(auto).not.toBe(null);
    handles.push(auto!);
    expect(document.querySelectorAll(".ac-root")).toHaveLength(2);
    expect(host.querySelector(".ac-inline")).not.toBe(null);
    expect(document.querySelector(".ac-launcher")).not.toBe(null);
    // それでも属性から出る窓は 1 つだけ
    expect(await bootstrap(document)).toBe(null);
    expect(document.querySelectorAll(".ac-root")).toHaveLength(2);
  });

  it("data-endpoint が無ければ何もしない", async () => {
    fakeConfigFetch({});
    expect(await bootstrap(document)).toBe(null);
    expect(document.querySelector(".ac-root")).toBe(null);
  });
});

describe("fetchRemoteConfig", () => {
  it("知らない鍵と型の合わない値は捨てる", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(
            JSON.stringify({
              greeting: 1,
              suggestions: ["よい候補", 42],
              contactUrl: null,
              labels: { send: "送る", open: 7, unknownKey: "無視" },
              secret: "見せない",
            }),
            { status: 200, headers: { "content-type": "application/json" } },
          ),
      ),
    );
    expect(await fetchRemoteConfig("/api/concierge")).toEqual({
      suggestions: ["よい候補"],
      labels: { send: "送る" },
    });
  });
});

describe("覚えたものの形", () => {
  it("壊れた保存値は捨てて、空から始める", () => {
    sessionStorage.setItem(`ai-concierge:${STORAGE_VERSION}:broken`, JSON.stringify([{ role: "user" }, 42]));
    const handle = open({ storageKey: "broken" });
    expect(handle.el.querySelectorAll(".ac-message")).toHaveLength(0);
  });
});

describe("widget.css", () => {
  it("hidden 属性の窓を display: none にする規則がある（display: flex に負けない）", async () => {
    const { readFile } = await import("node:fs/promises");
    const css = await readFile("src/widget/widget.css", "utf8"); // jsdom では import.meta.url が http になる
    expect(css).toMatch(/\.ac-root \.ac-panel\[hidden\]\s*\{\s*display:\s*none;/);
  });

  it("入力欄は 5 行ぶんまで伸びて、そこで止まる", async () => {
    const { readFile } = await import("node:fs/promises");
    const css = await readFile("src/widget/widget.css", "utf8");
    expect(css).toContain("field-sizing: content;");
    expect(css).toContain("max-height: calc(1.5em * 5 + 1.25rem + 2px);");
    expect(css).toContain("resize: none;");
  });
});
