import type { ChatEvent, ChatTurn, WidgetLabels } from "../core/types";

export const STORAGE_VERSION = "v1";
const HISTORY_MAX = 12;
/** ご質問の字数の上限の既定。サーバー側の limits.maxInputChars と同じ数 */
export const DEFAULT_MAX_INPUT_CHARS = 400;

export const DEFAULT_LABELS: WidgetLabels = {
  windowTitle: "案内窓口",
  open: "質問する",
  close: "閉じる",
  placeholder: "質問を入力してください",
  send: "送信",
  thinking: "調べています…",
  sources: "根拠",
  contact: "担当者に問い合わせる",
  reset: "最初から",
  answerDone: "答えが届きました",
  unavailable: "いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。",
  tooLong: "質問は 400 字以内でお願いします。",
  rateLimited: "少し時間をおいてからお試しください。",
  offline: "通信できませんでした。少し時間をおいてからお試しください。",
  emptyQuestion: "ご質問を入力してください。",
};

export interface WidgetSource {
  index: number;
  title: string;
  url: string | null;
}

export interface WidgetMessage {
  role: "user" | "assistant";
  text: string;
  sources: WidgetSource[];
  failed: boolean;
  /**
   * 問い合わせ先のボタンを出すか。
   * 「資料に無い」と断られたときと、通信や API が失敗したときだけ true にする。
   * 出典が付かなかっただけの答えでは出さない（答え自体は使えることが多い）。
   */
  needsContact?: boolean;
}

export interface WidgetOptions {
  endpoint: string;
  target?: string | Element | null;
  greeting?: string;
  suggestions?: string[];
  contactUrl?: string | null;
  labels?: Partial<WidgetLabels>;
  storageKey?: string;
  maxInputChars?: number;
  document?: Document;
  /**
   * サーバーの設定（あいさつ・候補・問い合わせ先・文言）を読む手続き。
   * 窓を初めて開いたとき（ページの中に置く形では置いた直後）に 1 回だけ呼ぶ。
   * ページを見ただけでは呼ばないので、開かない訪問者のぶんはサーバーが動かない。
   * ここで渡さなかった値だけを埋め、渡した値（属性）はそのまま残す。
   */
  remoteConfig?: () => Promise<WidgetRemoteConfig>;
}

export interface WidgetHandle {
  el: HTMLElement;
  open(): void;
  close(): void;
  reset(): void;
  ask(question: string): Promise<void>;
  messages(): WidgetMessage[];
  destroy(): void;
}

export function parseSse(buffer: string): { events: ChatEvent[]; rest: string } {
  const parts = buffer.split("\n\n");
  const rest = parts.pop() ?? "";
  const events: ChatEvent[] = [];
  for (const part of parts) {
    for (const line of part.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      try {
        events.push(JSON.parse(trimmed.slice(5).trim()) as ChatEvent);
      } catch {
        // 途中で切れた行は捨てる
      }
    }
  }
  return { events, rest };
}

export function historyOf(messages: WidgetMessage[]): ChatTurn[] {
  // やり取り（質問+答え）は対で積まれる。答えが失敗/空のときは、その対ごと送らない
  const turns: ChatTurn[] = [];
  for (let i = 0; i + 1 < messages.length; i += 2) {
    const question = messages[i];
    const answer = messages[i + 1];
    if (answer.failed || answer.text.trim() === "") continue;
    turns.push({ role: question.role, content: question.text }, { role: answer.role, content: answer.text });
  }
  return turns.slice(-HISTORY_MAX);
}

/** 出典の URL は http(s) だけをリンクにする（javascript: などはリンクにしない） */
function safeUrl(url: string | null): string | null {
  return url !== null && /^https?:\/\//i.test(url) ? url : null;
}

/**
 * 問い合わせ先は買い手が書くものなので、出典より広く受ける。
 * http(s) と mailto: のほか、同じサイトの中の道（`/contact`・`contact.html`・`#form`）も通す。
 * 通さないのは `javascript:` のような、開くと何かが動く書き方だけ。
 * 判定の前に空白と制御文字を落として、`java\nscript:` のような抜け道もふさぐ。
 */
export function safeContactUrl(url: string | null | undefined): string | null {
  if (url === null || url === undefined || url.trim() === "") return null;
  const bare = url.replace(/[\x00-\x20\x7f]/g, "");
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(bare);
  if (scheme === null) return url;
  const name = scheme[1].toLowerCase();
  return name === "http" || name === "https" || name === "mailto" ? url : null;
}

function sourceLink(doc: Document, url: string, text: string, className?: string): HTMLAnchorElement {
  const link = doc.createElement("a");
  if (className !== undefined) link.className = className;
  link.href = url;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  link.textContent = text;
  return link;
}

function inline(doc: Document, parent: Node, text: string, sources: WidgetSource[]): void {
  const pattern = /\*\*(.+?)\*\*|\[(\d{1,2})\]/g;
  let last = 0;
  for (const match of text.matchAll(pattern)) {
    const at = match.index ?? 0;
    if (at > last) parent.appendChild(doc.createTextNode(text.slice(last, at)));
    if (match[1] !== undefined) {
      const strong = doc.createElement("strong");
      strong.textContent = match[1];
      parent.appendChild(strong);
    } else {
      const index = Number(match[2]);
      const source = sources.find((item) => item.index === index);
      if (source === undefined) {
        parent.appendChild(doc.createTextNode(match[0]));
      } else {
        const sup = doc.createElement("sup");
        sup.className = "ac-ref";
        const url = safeUrl(source.url);
        if (url === null) {
          sup.textContent = `[${index}]`;
        } else {
          sup.appendChild(sourceLink(doc, url, `[${index}]`));
        }
        parent.appendChild(sup);
      }
    }
    last = at + match[0].length;
  }
  if (last < text.length) parent.appendChild(doc.createTextNode(text.slice(last)));
}

/** 答えを描く。字は必ず textContent 経由で入れる（HTML は作らない） */
export function renderAnswer(el: HTMLElement, text: string, sources: WidgetSource[]): void {
  const doc = el.ownerDocument;
  el.textContent = "";
  let list: HTMLUListElement | null = null;
  for (const line of text.split("\n")) {
    const item = /^\s*-\s+(.*)$/.exec(line);
    if (item !== null) {
      if (list === null) {
        list = doc.createElement("ul");
        el.appendChild(list);
      }
      const li = doc.createElement("li");
      inline(doc, li, item[1], sources);
      list.appendChild(li);
      continue;
    }
    list = null;
    if (line.trim() === "") continue;
    const p = doc.createElement("p");
    inline(doc, p, line, sources);
    el.appendChild(p);
  }
}

function readStore(key: string): WidgetMessage[] {
  try {
    const raw = sessionStorage.getItem(key);
    if (raw === null) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    // 手で書き換えられた値や古い形が混ざっていても、窓を壊さない
    const valid = parsed.filter(
      (item): item is WidgetMessage =>
        typeof item === "object" &&
        item !== null &&
        ((item as WidgetMessage).role === "user" || (item as WidgetMessage).role === "assistant") &&
        typeof (item as WidgetMessage).text === "string" &&
        Array.isArray((item as WidgetMessage).sources) &&
        typeof (item as WidgetMessage).failed === "boolean",
    );
    return valid.length === parsed.length ? valid : [];
  } catch {
    return [];
  }
}

function writeStore(key: string, messages: WidgetMessage[]): void {
  try {
    if (messages.length === 0) sessionStorage.removeItem(key);
    else sessionStorage.setItem(key, JSON.stringify(messages));
  } catch {
    // プライベートモードなどで書けなくても、その場の会話は続けられる
  }
}

export function mount(options: WidgetOptions): WidgetHandle {
  const doc = options.document ?? document;
  // 呼び出し側（＝ページの属性）が渡した文言。サーバーの設定より強い
  const givenLabels: Partial<WidgetLabels> = options.labels ?? {};
  let labels: WidgetLabels = { ...DEFAULT_LABELS, ...givenLabels };
  // NaN（data-max-input-chars の書き間違いなど）や 0 以下は既定に戻す
  const requestedMax = options.maxInputChars;
  const maxInputChars =
    typeof requestedMax === "number" && Number.isFinite(requestedMax) && requestedMax > 0 ? requestedMax : DEFAULT_MAX_INPUT_CHARS;
  // サーバーの設定で後から埋められるよう、書き換えられる形で持つ
  let greeting = options.greeting;
  let suggestions = options.suggestions;
  let contactUrl = safeContactUrl(options.contactUrl);
  const storeKey = `ai-concierge:${STORAGE_VERSION}:${options.storageKey ?? "default"}`;
  const host =
    typeof options.target === "string"
      ? options.target.trim() === ""
        ? null
        : doc.querySelector(options.target)
      : (options.target ?? null);
  const isInline = host !== null;

  let messages: WidgetMessage[] = readStore(storeKey);
  let streaming = false;
  let aborter: AbortController | null = null;

  const root = doc.createElement("div");
  root.className = isInline ? "ac-root ac-inline" : "ac-root";
  if (typeof doc.defaultView?.matchMedia === "function" && doc.defaultView.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    root.classList.add("ac-no-motion");
  }

  const launcher = doc.createElement("button");
  launcher.type = "button";
  launcher.className = "ac-launcher";
  launcher.textContent = labels.open;
  launcher.setAttribute("aria-expanded", "false");

  const panel = doc.createElement("div");
  panel.className = "ac-panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", labels.windowTitle);
  panel.hidden = !isInline;

  const header = doc.createElement("div");
  header.className = "ac-header";
  const title = doc.createElement("span");
  title.className = "ac-title";
  title.textContent = labels.windowTitle;
  const resetButton = doc.createElement("button");
  resetButton.type = "button";
  resetButton.className = "ac-reset";
  resetButton.textContent = labels.reset;
  const closeButton = doc.createElement("button");
  closeButton.type = "button";
  closeButton.className = "ac-close";
  closeButton.textContent = labels.close;
  header.append(title, resetButton);
  if (!isInline) header.appendChild(closeButton);

  const log = doc.createElement("div");
  log.className = "ac-log";
  // 会話そのものは読み上げの対象にしない。字が届くたびに読み上げ直されて
  // 使えなくなるため、知らせるのは下の ac-notice（role=status）1 か所にまとめる
  log.setAttribute("aria-live", "off");

  const list = doc.createElement("div");
  list.className = "ac-list";
  // 知らせる場所は最初から置いておく（後から作ると読み上げが動かないことがある）。
  // 中身が空のあいだは CSS で場所を取らない
  const noticeEl = doc.createElement("p");
  noticeEl.className = "ac-notice";
  noticeEl.setAttribute("role", "status");
  log.append(list, noticeEl);

  const suggestionBox = doc.createElement("div");
  suggestionBox.className = "ac-suggestions";

  const form = doc.createElement("form");
  form.className = "ac-form";
  // textarea にしてあるので Shift+Enter で改行できる（Enter だけなら送信）。
  // 高さは CSS の field-sizing で 5 行ぶんまで自然に伸びる
  const input = doc.createElement("textarea");
  input.rows = 1;
  input.className = "ac-input";
  input.placeholder = labels.placeholder;
  input.setAttribute("aria-label", labels.placeholder);
  // 数でない値（data-max-input-chars の書き間違いなど）のときは付けない。
  // maxLength = NaN は 0 と同じ扱いになり、1 字も入力できなくなる
  if (Number.isFinite(maxInputChars)) input.maxLength = maxInputChars;
  const send = doc.createElement("button");
  send.type = "submit";
  send.className = "ac-send";
  send.textContent = labels.send;
  form.append(input, send);

  panel.append(header, log, suggestionBox, form);
  root.append(...(isInline ? [panel] : [launcher, panel]));
  (host ?? doc.body).appendChild(root);

  function notice(text: string): void {
    if (noticeEl.textContent === text) return;
    noticeEl.textContent = text;
  }

  function renderSuggestions(): void {
    suggestionBox.textContent = "";
    if (messages.length > 0) return;
    for (const text of suggestions ?? []) {
      const button = doc.createElement("button");
      button.type = "button";
      button.className = "ac-suggestion";
      button.textContent = text;
      button.addEventListener("click", () => {
        void ask(text);
      });
      suggestionBox.appendChild(button);
    }
  }

  /** 1 件ぶん（吹き出し＋根拠＋問い合わせボタン）を入れ物の中に描き直す */
  function fillGroup(group: HTMLElement, message: WidgetMessage): void {
    group.textContent = "";
    const box = doc.createElement("div");
    box.className = `ac-message ac-message-${message.role}`;
    if (message.role === "user") box.textContent = message.text;
    else renderAnswer(box, message.text, message.sources);
    group.appendChild(box);

    if (message.role === "assistant" && message.sources.length > 0) {
      const sources = doc.createElement("div");
      sources.className = "ac-sources";
      const caption = doc.createElement("span");
      caption.className = "ac-sources-caption";
      caption.textContent = labels.sources;
      sources.appendChild(caption);
      for (const source of message.sources.slice(0, 3)) {
        const url = safeUrl(source.url);
        if (url === null) {
          const span = doc.createElement("span");
          span.className = "ac-source";
          span.textContent = `[${source.index}] ${source.title}`;
          sources.appendChild(span);
        } else {
          sources.appendChild(sourceLink(doc, url, `[${source.index}] ${source.title}`, "ac-source"));
        }
      }
      group.appendChild(sources);
    }

    if (message.role === "assistant" && message.needsContact === true && contactUrl !== null) {
      const contact = doc.createElement("a");
      contact.className = "ac-contact";
      contact.href = contactUrl;
      contact.textContent = labels.contact;
      group.appendChild(contact);
    }
  }

  function groupOf(message: WidgetMessage): HTMLElement {
    const group = doc.createElement("div");
    group.className = `ac-group ac-group-${message.role}`;
    fillGroup(group, message);
    return group;
  }

  /** やり取りが増えた・消えたときだけ、会話の全部を組み直す */
  function render(): void {
    list.textContent = "";
    if (messages.length === 0 && (greeting ?? "") !== "") {
      const el = doc.createElement("p");
      el.className = "ac-greeting";
      el.textContent = greeting ?? "";
      list.appendChild(el);
    }
    for (const message of messages) list.appendChild(groupOf(message));
    renderSuggestions();
    log.scrollTop = log.scrollHeight;
  }

  /**
   * 流れてくる途中は、いま書かれている 1 件だけを描き直す。
   * 会話の全部を組み直さないので、読み上げも画面も落ち着いたまま増えていく。
   */
  function renderStreaming(message: WidgetMessage): void {
    const group = list.lastElementChild;
    if (group === null) {
      render();
      return;
    }
    fillGroup(group as HTMLElement, message);
    log.scrollTop = log.scrollHeight;
  }

  function save(): void {
    writeStore(storeKey, messages);
  }

  /** すでに画面に出ている文言を、新しい labels に合わせて書き換える */
  function applyLabels(): void {
    launcher.textContent = labels.open;
    panel.setAttribute("aria-label", labels.windowTitle);
    title.textContent = labels.windowTitle;
    resetButton.textContent = labels.reset;
    closeButton.textContent = labels.close;
    input.placeholder = labels.placeholder;
    input.setAttribute("aria-label", labels.placeholder);
    send.textContent = labels.send;
  }

  /**
   * サーバーの設定を、いまの窓に当てはめる。
   * 渡されていなかった値だけを埋め、文言は 既定 → サーバー → 属性 の順に重ねる
   *（属性がいちばん強い）。
   *
   * 変わったものが無ければ画面には触らない。属性で全部書いてあるページでは
   * ここが何もしないので、開いた直後に候補のボタンが作り直されて
   * 押しかけの指が空を切る、ということが起きない。
   */
  function applyRemote(remote: WidgetRemoteConfig): void {
    let changed = false;
    if (greeting === undefined && remote.greeting !== undefined) {
      greeting = remote.greeting;
      changed = true;
    }
    if (suggestions === undefined && remote.suggestions !== undefined) {
      suggestions = remote.suggestions;
      changed = true;
    }
    if (options.contactUrl === undefined && remote.contactUrl !== undefined && remote.contactUrl !== null) {
      const next = safeContactUrl(remote.contactUrl);
      if (next !== contactUrl) {
        contactUrl = next;
        changed = true;
      }
    }
    if (remote.labels !== undefined) {
      const next: WidgetLabels = { ...DEFAULT_LABELS, ...remote.labels, ...givenLabels };
      if ((Object.keys(DEFAULT_LABELS) as Array<keyof WidgetLabels>).some((key) => next[key] !== labels[key])) {
        labels = next;
        applyLabels();
        changed = true;
      }
    }
    if (changed) render();
  }

  let remoteAsked = false;
  /** 窓を初めて開いたときに 1 回だけ読む（ページを見ただけでは読まない） */
  function loadRemote(): void {
    if (remoteAsked || options.remoteConfig === undefined) return;
    remoteAsked = true;
    void options.remoteConfig().then(applyRemote, () => {
      // 読めなくても既定の文言のまま使える
    });
  }

  async function ask(raw: string): Promise<void> {
    if (streaming) return;
    const question = raw.trim();
    if (question === "") {
      notice(labels.emptyQuestion);
      return;
    }
    if (question.length > maxInputChars) {
      notice(labels.tooLong);
      return;
    }

    const history = historyOf(messages);
    messages = [...messages, { role: "user", text: question, sources: [], failed: false }];
    const answer: WidgetMessage = { role: "assistant", text: "", sources: [], failed: false, needsContact: false };
    messages = [...messages, answer];
    streaming = true;
    input.value = "";
    send.disabled = true;
    render();
    notice(labels.thinking);

    aborter = new AbortController();
    try {
      const response = await fetch(`${options.endpoint}/chat`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ question, history }),
        signal: aborter.signal,
      });

      if (!response.ok) {
        const body = (await response.json().catch(() => ({}))) as { message?: string };
        answer.failed = true;
        answer.needsContact = true;
        renderStreaming(answer);
        notice(typeof body.message === "string" && body.message !== "" ? body.message : labels.unavailable);
        return;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let failure: string | null = null;
      while (reader !== undefined) {
        const chunk = await reader.read();
        if (chunk.done) break;
        buffer += decoder.decode(chunk.value, { stream: true });
        const parsed = parseSse(buffer);
        buffer = parsed.rest;
        for (const event of parsed.events) {
          if (event.type === "text") answer.text += event.text;
          else if (event.type === "citation") {
            if (!answer.sources.some((source) => source.index === event.index)) {
              answer.sources.push({ index: event.index, title: event.title, url: event.url });
            }
          } else if (event.type === "error") {
            failure = event.message;
            answer.failed = true;
            answer.needsContact = true;
            // 言いかけの答えは消す（お詫びの下に半分の文を残さない）
            if (event.clear === true) {
              answer.text = "";
              answer.sources = [];
            }
          } else if (event.type === "done") {
            answer.failed = answer.failed || !event.answered;
            if (!event.answered) {
              // 問い合わせ先のボタンは「資料に無い」と断られたときと、失敗したときだけ出す。
              // 出典が付かなかっただけ（no_citations）なら、答えはそのまま見せる。
              // reason を送らない古いサーバー相手では、これまでどおり未回答なら出す
              answer.needsContact = event.reason === undefined ? true : event.reason !== "no_citations";
            }
          }
        }
        // 流れている途中は、書かれている 1 件だけを描き直す。
        // 知らせる文はここでは変えない（1 件の答えで読み上げが何度も走らないように）
        renderStreaming(answer);
      }
      renderStreaming(answer);
      // 終わったところで 1 回だけ知らせる
      notice(failure !== null ? failure : labels.answerDone);
    } catch (error) {
      if ((error as Error).name === "AbortError") return;
      answer.failed = true;
      answer.needsContact = true;
      renderStreaming(answer);
      notice(labels.offline);
    } finally {
      streaming = false;
      send.disabled = false;
      aborter = null;
      save();
    }
  }

  function setOpen(next: boolean): void {
    panel.hidden = !next;
    launcher.setAttribute("aria-expanded", String(next));
    if (next) {
      loadRemote();
      input.focus();
    }
  }

  function onSubmit(event: Event): void {
    event.preventDefault();
    void ask(input.value);
  }

  /** Enter で送信、Shift+Enter で改行。日本語の変換中（isComposing）は送らない */
  function onInputKeydown(event: KeyboardEvent): void {
    if (event.key !== "Enter" || event.shiftKey || event.isComposing) return;
    event.preventDefault();
    void ask(input.value);
  }

  function onKeydown(event: KeyboardEvent): void {
    if (event.key === "Escape" && !isInline) {
      setOpen(false);
      launcher.focus();
      return;
    }
    if (event.key !== "Tab" || isInline) return;
    const focusable = Array.from(
      panel.querySelectorAll<HTMLElement>("button:not([disabled]), a[href], input:not([disabled]), textarea:not([disabled])"),
    );
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    const active = doc.activeElement;
    if (event.shiftKey && active === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  }

  function doReset(): void {
    aborter?.abort();
    messages = [];
    save();
    render();
  }

  form.addEventListener("submit", onSubmit);
  input.addEventListener("keydown", onInputKeydown);
  panel.addEventListener("keydown", onKeydown);
  launcher.addEventListener("click", () => setOpen(panel.hidden));
  closeButton.addEventListener("click", () => {
    setOpen(false);
    launcher.focus();
  });
  resetButton.addEventListener("click", doReset);
  render();
  // ページの中に置く形は最初から開いているので、その場で読む
  if (isInline) loadRemote();

  return {
    el: root,
    open: () => setOpen(true),
    close: () => setOpen(false),
    reset: doReset,
    ask,
    messages: () => messages.map((message) => ({ ...message })),
    destroy(): void {
      aborter?.abort();
      form.removeEventListener("submit", onSubmit);
      input.removeEventListener("keydown", onInputKeydown);
      panel.removeEventListener("keydown", onKeydown);
      root.remove();
    },
  };
}

/** 起動時に {endpoint}/config を待つ上限。これを過ぎたら待たずに窓を出す */
export const CONFIG_TIMEOUT_MS = 2000;

/** 知っている鍵の、文字列の値だけを残す（書き間違いで窓が壊れないように） */
function labelsOf(raw: Record<string, unknown>): Partial<WidgetLabels> {
  const labels: Partial<WidgetLabels> = {};
  for (const key of Object.keys(DEFAULT_LABELS) as Array<keyof WidgetLabels>) {
    const value = raw[key];
    if (typeof value === "string") labels[key] = value;
  }
  return labels;
}

/** data-labels='{"send":"Send"}' を読む。JSON でなければ何も足さない */
function labelsFromJson(value: string | undefined): Partial<WidgetLabels> {
  if (value === undefined || value.trim() === "") return {};
  try {
    const parsed = JSON.parse(value) as unknown;
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return {};
    return labelsOf(parsed as Record<string, unknown>);
  } catch {
    return {};
  }
}

/** サーバーの {endpoint}/config が返す形。読めなくても窓は既定の文言で動く */
export interface WidgetRemoteConfig {
  greeting?: string;
  suggestions?: string[];
  contactUrl?: string | null;
  labels?: Partial<WidgetLabels>;
}

/** 起動時に 1 回だけ読む。2 秒で切り上げ、読めなければ黙って既定の文言に戻る */
export async function fetchRemoteConfig(endpoint: string, timeoutMs: number = CONFIG_TIMEOUT_MS): Promise<WidgetRemoteConfig> {
  try {
    const response = await fetch(`${endpoint}/config`, { signal: AbortSignal.timeout(timeoutMs) });
    if (!response.ok) return {};
    const parsed = (await response.json()) as unknown;
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return {};
    const raw = parsed as Record<string, unknown>;
    const config: WidgetRemoteConfig = {};
    if (typeof raw.greeting === "string") config.greeting = raw.greeting;
    if (Array.isArray(raw.suggestions)) {
      config.suggestions = raw.suggestions.filter((item): item is string => typeof item === "string");
    }
    if (typeof raw.contactUrl === "string") config.contactUrl = raw.contactUrl;
    if (typeof raw.labels === "object" && raw.labels !== null && !Array.isArray(raw.labels)) {
      config.labels = labelsOf(raw.labels as Record<string, unknown>);
    }
    return config;
  } catch {
    // 応答が無い・遅い・形が違う——どれでも窓は開けるようにする
    return {};
  }
}

function listOf(value: string | undefined): string[] {
  if (value === undefined || value.trim() === "") return [];
  const trimmed = value.trim();
  if (trimmed.startsWith("[")) {
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      if (Array.isArray(parsed)) return parsed.filter((item): item is string => typeof item === "string");
    } catch {
      // JSON でなければ | 区切りとして読む
    }
  }
  return trimmed.split("|").map((item) => item.trim()).filter((item) => item !== "");
}

/**
 * <script src="ai-concierge.js" data-endpoint="/api/concierge"> の属性だけで起動する。
 * 窓はすぐ出す（サーバーを待たない）。`concierge.config.json` の
 * greeting / suggestions / contactUrl / labels は、窓を初めて開いたときに
 * {endpoint}/config から 1 回だけ読み込んで当てはめる。
 * 同じ名前の data-* 属性があれば、そちらを優先する（ページ側で上書きできる）。
 */
export async function bootstrap(doc: Document = document): Promise<WidgetHandle | null> {
  // 同じページに 2 回読み込まれても、属性から出す窓は 1 つだけ。
  // AIConcierge.mount で手ずから置いた窓は数に入れない（両方を置けるようにする）
  const tag = doc.querySelector<HTMLScriptElement>("script[data-endpoint]:not([data-ac-started])");
  if (tag === null) return null;
  if (doc.querySelector(".ac-root[data-ac-auto]") !== null) return null;
  tag.dataset.acStarted = "1";
  const data = tag.dataset;
  const endpoint = data.endpoint ?? "/api/concierge";

  const handle = mount({
    endpoint,
    target: data.inline ? data.inline : null,
    // 属性が無いところは undefined のまま渡す（サーバーの設定で埋める場所の目印になる）
    greeting: data.greeting,
    suggestions: data.suggestions === undefined ? undefined : listOf(data.suggestions),
    contactUrl: data.contactUrl,
    labels: labelsFromJson(data.labels),
    storageKey: data.storageKey,
    maxInputChars: data.maxInputChars === undefined ? undefined : Number(data.maxInputChars),
    document: doc,
    remoteConfig: () => fetchRemoteConfig(endpoint),
  });
  handle.el.dataset.acAuto = "1";
  return handle;
}

if (typeof document !== "undefined") {
  const run = (): void => {
    // 起動できなくても、置かれたページ自体は壊さない
    void bootstrap(document).catch(() => null);
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run, { once: true });
  else run();
}
