import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { dirname, extname, join } from "node:path";
import { loadConfigFile, resolveConfig } from "../core/config";
import { buildIndexFile, indexSummary, toLoadedIndex } from "../core/index-store";
import type { ConciergeConfig, DocumentDraft, IndexFile } from "../core/types";
import { chunkDocument, type DocumentSource } from "./chunk";
import { fetchPage, pageToDocument } from "./fetch-page";
import { parseMarkdown } from "./markdown";
import { isMainModule } from "../adapters/main-module";

export const USAGE = `ai-concierge — 自社の文書から案内窓口の索引を作ります。

使い方:
  npx ai-concierge index                     content/ と urls を読んで data/index.json を作ります
  npx ai-concierge index --check             書き込まずに、何本・何片になるかだけ表示します
  npx ai-concierge index --count-tokens      正確なトークン数を数えます（ANTHROPIC_API_KEY が必要です）
  npx ai-concierge index --config <パス>     設定ファイルの場所を変えます（既定 concierge.config.json）
  npx ai-concierge index --out <パス>        書き出し先を変えます（既定 data/index.json）
  npx ai-concierge --help                    この説明を表示します`;

export interface CliOptions {
  command: "index" | "help";
  check: boolean;
  countTokens: boolean;
  configPath: string;
  out: string | null;
}

export interface CliIo {
  log: (message: string) => void;
  error: (message: string) => void;
  fetchImpl?: typeof fetch;
  builtAt?: () => string;
}

export function parseArgs(argv: string[]): CliOptions {
  const options: CliOptions = {
    command: argv[0] === "index" ? "index" : "help",
    check: false,
    countTokens: false,
    configPath: "concierge.config.json",
    out: null,
  };
  for (let i = 1; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--check") options.check = true;
    else if (arg === "--count-tokens") options.countTokens = true;
    else if (arg === "--config" && argv[i + 1] !== undefined) options.configPath = argv[(i += 1)];
    else if (arg === "--out" && argv[i + 1] !== undefined) options.out = argv[(i += 1)];
    else if (arg === "--help" || arg === "-h") options.command = "help";
    else if (arg === "--config" || arg === "--out") throw new Error(`${arg} には値が要ります（例: ${arg} data/index.json）`);
    else throw new Error(`知らない引数です: ${arg}。--help で使い方を出せます`);
  }
  return options;
}

export function idOf(file: string): string {
  return file.slice(0, file.length - extname(file).length);
}

export async function collectMarkdown(dir: string): Promise<DocumentSource[]> {
  let names: string[];
  try {
    names = await readdir(dir);
  } catch {
    throw new Error(`content のフォルダ ${dir} が見つかりません。concierge.config.json の content を確かめてください`);
  }
  const files = names.filter((name) => name.endsWith(".md") || name.endsWith(".markdown")).sort();
  const documents: DocumentSource[] = [];
  const seen = new Map<string, string>();
  for (const name of files) {
    const id = idOf(name);
    const other = seen.get(id);
    if (other !== undefined) {
      // 同じ id の文書が 2 つあると、片の番号が重なって出典が別の文書を指してしまう
      throw new Error(`${other} と ${name} は同じ id（${id}）になります。ファイル名を変えてください`);
    }
    seen.set(id, name);
    documents.push(parseMarkdown(await readFile(join(dir, name), "utf8"), id));
  }
  return documents;
}

export async function collectPages(urls: string[], fetchImpl: typeof fetch = fetch): Promise<DocumentSource[]> {
  const documents: DocumentSource[] = [];
  for (const [i, url] of urls.entries()) {
    documents.push(pageToDocument(await fetchPage(url, fetchImpl), url, `page-${i + 1}`));
  }
  return documents;
}

export async function buildIndex(config: ConciergeConfig, io: CliIo): Promise<IndexFile> {
  const sources = [...(await collectMarkdown(config.content)), ...(await collectPages(config.urls, io.fetchImpl ?? fetch))];
  const drafts: DocumentDraft[] = sources.map((source) => chunkDocument(source));
  return buildIndexFile(drafts, (io.builtAt ?? (() => new Date().toISOString()))());
}

/** 正確なトークン数。片の tokens は概算のまま残し、合計だけ差し替える */
async function countTotalTokens(model: string, apiKey: string, texts: string[]): Promise<number> {
  const { default: Anthropic } = await import("@anthropic-ai/sdk");
  const client = new Anthropic({ apiKey });
  const result = await client.messages.countTokens({
    model,
    messages: [{ role: "user", content: texts.join("\n\n") }],
  });
  return result.input_tokens;
}

const defaultIo: CliIo = {
  log: (message: string) => console.log(message),
  error: (message: string) => console.error(message),
};

export async function run(argv: string[], io: CliIo = defaultIo): Promise<number> {
  let options: CliOptions;
  try {
    options = parseArgs(argv);
  } catch (error) {
    io.error((error as Error).message);
    return 1;
  }
  if (options.command === "help") {
    io.log(USAGE);
    return 0;
  }

  try {
    const config = resolveConfig({ file: await loadConfigFile(options.configPath), env: process.env });
    const file = await buildIndex(config, io);

    if (options.countTokens) {
      if (config.apiKey === null) {
        io.error("--count-tokens には ANTHROPIC_API_KEY が必要です。環境変数に入れてからもう一度お試しください");
        return 1;
      }
      const texts = file.documents.flatMap((doc) => doc.chunks.map((chunk) => chunk.text));
      const counted = await countTotalTokens(config.answer.model, config.apiKey, texts);
      io.log(`概算 ${file.stats.totalTokens} トークン → 実測 ${counted} トークン`);
      file.stats.totalTokens = counted;
    }

    io.log(indexSummary(toLoadedIndex(file)));
    for (const doc of file.documents) io.log(`  ${doc.id}  ${doc.title}  片 ${doc.chunks.length} 個`);

    if (options.check) {
      io.log("--check なので書き込みませんでした。");
      return 0;
    }

    const out = options.out ?? config.indexPath;
    await mkdir(dirname(out), { recursive: true });
    await writeFile(out, `${JSON.stringify(file)}\n`, "utf8");
    io.log(`${out} に書きました。`);
    return 0;
  } catch (error) {
    io.error((error as Error).message);
    return 1;
  }
}

if (isMainModule(process.argv[1], import.meta.url)) {
  void run(process.argv.slice(2)).then((code) => {
    process.exitCode = code;
  });
}
