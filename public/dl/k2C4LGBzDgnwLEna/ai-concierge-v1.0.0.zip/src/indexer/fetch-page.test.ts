import { describe, expect, it } from "vitest";
import { decodeEntities, extractMainHtml, extractTitle, fetchPage, htmlToText, pageToDocument, stripBlocks } from "./fetch-page";

const PAGE = `<!doctype html>
<html lang="ja">
<head><title>料金について | みなと工務店</title><style>body{color:red}</style></head>
<body>
<nav><a href="/">ホーム</a><a href="/price">料金</a></nav>
<main>
<h1>料金について</h1>
<p>工事の費用は、内容によって変わります。</p>
<h2>目安</h2>
<p>キッチンの入れ替えは 80 万円 &amp; 工期 5 日が目安です。</p>
<ul><li>キッチン: 80 万円</li><li>浴室: 120 万円</li></ul>
<h2>お支払い</h2>
<p>着工時に半金、引き渡し時に残金をいただきます。</p>
</main>
<footer><p>&copy; みなと工務店</p></footer>
<script>console.log("tracking")</script>
</body>
</html>`;

describe("stripBlocks", () => {
  it("script・style・nav・footer・コメントを落とす", () => {
    const cleaned = stripBlocks(PAGE);
    expect(cleaned).not.toContain("tracking");
    expect(cleaned).not.toContain("color:red");
    expect(cleaned).not.toContain("ホーム");
    expect(cleaned).not.toContain("&copy;");
    expect(cleaned).toContain("料金について");
  });

  it("コメントも落とす", () => {
    expect(stripBlocks("<p>あ<!-- 内緒 -->い</p>")).toBe("<p>あい</p>");
  });
});

describe("extractMainHtml", () => {
  it("main → article → body の順に探す", () => {
    expect(extractMainHtml("<body><main><p>A</p></main></body>")).toBe("<p>A</p>");
    expect(extractMainHtml("<body><article><p>B</p></article></body>")).toBe("<p>B</p>");
    expect(extractMainHtml("<html><body><p>C</p></body></html>")).toBe("<p>C</p>");
    expect(extractMainHtml("<p>D</p>")).toBe("<p>D</p>");
  });
});

describe("decodeEntities", () => {
  it("よく出る実体参照を戻す", () => {
    expect(decodeEntities("A &amp; B &lt;C&gt; &quot;D&quot; &#39;E&#39; F&nbsp;G")).toBe(`A & B <C> "D" 'E' F G`);
  });

  it("数値参照も戻す", () => {
    expect(decodeEntities("&#12354;&#x3044;")).toBe("あい");
  });

  it("知らない参照はそのまま", () => {
    expect(decodeEntities("&unknown; &#xZZ;")).toBe("&unknown; &#xZZ;");
  });
});

describe("htmlToText", () => {
  it("タグを落とし、段落で改行し、空白をまとめる", () => {
    expect(htmlToText("<p>あ  い</p><p>う</p>")).toBe("あ い\n\nう");
    expect(htmlToText("一<br>二")).toBe("一\n二");
    expect(htmlToText("<p>  </p>")).toBe("");
  });
});

describe("extractTitle", () => {
  it("title → h1 の順に探す", () => {
    expect(extractTitle(PAGE)).toBe("料金について | みなと工務店");
    expect(extractTitle("<body><h1>料金</h1></body>")).toBe("料金");
    expect(extractTitle("<body><p>本文</p></body>")).toBe(null);
  });
});

describe("pageToDocument", () => {
  const doc = pageToDocument(PAGE, "https://example.com/price", "price");

  it("題名と URL を持つ", () => {
    expect(doc.id).toBe("price");
    expect(doc.title).toBe("料金について | みなと工務店");
    expect(doc.url).toBe("https://example.com/price");
    expect(doc.updatedAt).toBe(null);
  });

  it("h2 で節に割る", () => {
    expect(doc.sections).toEqual([
      { heading: "", text: "料金について\n\n工事の費用は、内容によって変わります。" },
      { heading: "目安", text: "キッチンの入れ替えは 80 万円 & 工期 5 日が目安です。\n\nキッチン: 80 万円\n\n浴室: 120 万円" },
      { heading: "お支払い", text: "着工時に半金、引き渡し時に残金をいただきます。" },
    ]);
  });

  it("nav と footer と script の字は入らない", () => {
    const all = doc.sections.map((section) => section.text).join("\n");
    expect(all).not.toContain("ホーム");
    expect(all).not.toContain("みなと工務店\n");
    expect(all).not.toContain("tracking");
  });
});

describe("fetchPage", () => {
  it("本文の字を返す", async () => {
    const calls: Array<{ url: string; init?: RequestInit }> = [];
    const fake = (async (url: string, init?: RequestInit) => {
      calls.push({ url, init });
      return new Response("<p>あ</p>", { status: 200 });
    }) as unknown as typeof fetch;
    expect(await fetchPage("https://example.com/", fake)).toBe("<p>あ</p>");
    expect(calls[0].url).toBe("https://example.com/");
  });

  it("HTTP が 200 でなければ断る", async () => {
    const fake = (async () => new Response("", { status: 404 })) as unknown as typeof fetch;
    await expect(fetchPage("https://example.com/none", fake)).rejects.toThrow(
      "https://example.com/none を取得できませんでした（HTTP 404）",
    );
  });
});
