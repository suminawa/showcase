import type { ChunkDraft, DocumentDraft } from "../core/types";

/** 1 片の目安。下限に満たない節は次の見出しと合わせ、上限を超える節は段落で割る */
export const CHUNK_MIN = 600;
export const CHUNK_MAX = 1200;

export interface Section {
  heading: string;
  text: string;
}

export interface DocumentSource {
  id: string;
  title: string;
  url: string | null;
  updatedAt: string | null;
  sections: Section[];
}

/** 概算のトークン数。日本語 1 字 ≈ 1、英数字 4 字 ≈ 1（正確な数は CLI の --count-tokens で） */
export function estimateTokens(text: string): number {
  let ascii = 0;
  let wide = 0;
  for (const char of text) {
    if ((char.codePointAt(0) ?? 0) < 128) ascii += 1;
    else wide += 1;
  }
  return Math.ceil(ascii / 4) + wide;
}

export function breadcrumbOf(title: string, heading: string): string {
  const trimmed = heading.trim();
  return trimmed === "" ? title : `${title} › ${trimmed}`;
}

function joinSection(base: string, heading: string, text: string): string {
  const parts = [base];
  if (heading.trim() !== "") parts.push(heading.trim());
  if (text !== "") parts.push(text);
  return parts.join("\n\n");
}

export function mergeSections(sections: Section[]): Section[] {
  const out: Section[] = [];
  let current: Section | null = null;
  for (const section of sections) {
    const text = section.text.trim();
    if (text === "" && section.heading.trim() === "") continue;
    if (current === null) {
      current = { heading: section.heading, text };
      continue;
    }
    if (current.text.length < CHUNK_MIN) {
      current = { heading: current.heading, text: joinSection(current.text, section.heading, text) };
      continue;
    }
    out.push(current);
    current = { heading: section.heading, text };
  }
  if (current !== null) out.push(current);
  return out;
}

export function splitLongText(text: string, max: number = CHUNK_MAX): string[] {
  if (text.length <= max) return [text];
  const pieces: string[] = [];
  let current = "";
  for (const paragraph of text.split(/\n{2,}/)) {
    const part = paragraph.trim();
    if (part === "") continue;
    if (part.length > max) {
      if (current !== "") {
        pieces.push(current);
        current = "";
      }
      for (let i = 0; i < part.length; i += max) pieces.push(part.slice(i, i + max));
      continue;
    }
    const next = current === "" ? part : `${current}\n\n${part}`;
    if (next.length > max) {
      pieces.push(current);
      current = part;
    } else {
      current = next;
    }
  }
  if (current !== "") pieces.push(current);
  return pieces;
}

export function chunkDocument(source: DocumentSource): DocumentDraft {
  const chunks: ChunkDraft[] = [];
  let seq = 0;
  for (const section of mergeSections(source.sections)) {
    for (const text of splitLongText(section.text)) {
      seq += 1;
      chunks.push({
        id: `${source.id}#${seq}`,
        heading: section.heading.trim(),
        breadcrumb: breadcrumbOf(source.title, section.heading),
        text,
        tokens: estimateTokens(text),
      });
    }
  }
  return { id: source.id, title: source.title, url: source.url, updatedAt: source.updatedAt, chunks };
}
