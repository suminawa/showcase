import type { DocumentSource, Section } from "./chunk";

export interface FrontMatter {
  data: Record<string, string>;
  body: string;
}

function unquote(value: string): string {
  const trimmed = value.trim();
  if (trimmed.length >= 2 && ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")))) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

export function parseFrontMatter(source: string): FrontMatter {
  const lines = source.split(/\r?\n/);
  if (lines[0]?.trim() !== "---") return { data: {}, body: source };
  const end = lines.findIndex((line, i) => i > 0 && line.trim() === "---");
  if (end === -1) return { data: {}, body: source };

  const data: Record<string, string> = {};
  for (const line of lines.slice(1, end)) {
    const at = line.indexOf(":");
    if (at === -1) continue;
    const key = line.slice(0, at).trim();
    if (key === "") continue;
    data[key] = unquote(line.slice(at + 1));
  }
  return { data, body: lines.slice(end + 1).join("\n") };
}

export function splitSections(body: string): { title: string | null; sections: Section[] } {
  const lines = body.split(/\r?\n/);
  let title: string | null = null;
  let start = 0;
  for (let i = 0; i < lines.length; i += 1) {
    if (lines[i].trim() === "") continue;
    const h1 = /^#\s+(.+?)\s*$/.exec(lines[i]);
    if (h1 !== null) {
      title = h1[1];
      start = i + 1;
    }
    break;
  }

  const sections: Section[] = [];
  let heading = "";
  let buffer: string[] = [];
  const flush = (): void => {
    const text = buffer.join("\n").trim();
    if (text !== "" || heading !== "") sections.push({ heading, text });
    buffer = [];
  };
  for (let i = start; i < lines.length; i += 1) {
    const found = /^(#{2,6})\s+(.+?)\s*$/.exec(lines[i]);
    if (found !== null) {
      flush();
      heading = found[2];
      continue;
    }
    buffer.push(lines[i]);
  }
  flush();
  return { title, sections };
}

/**
 * front matter の url を索引に入れる前に確かめる。
 * ここを通った値が「根拠」のリンクになるので、http(s) 以外は索引づくりの時点で止める
 * （窓の側でもリンクにしない作りだが、書き間違いはその場で気づけるほうが直しやすい）。
 */
export function frontMatterUrl(value: string, id: string): string {
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error(`${id} の url「${value}」を読み取れません。http:// か https:// で始めてください`);
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error(`${id} の url「${value}」は http:// か https:// で始めてください`);
  }
  return value;
}

export function parseMarkdown(source: string, id: string): DocumentSource {
  const { data, body } = parseFrontMatter(source);
  const { title, sections } = splitSections(body);
  return {
    id,
    title: data.title ?? title ?? id,
    url: data.url === undefined || data.url === "" ? null : frontMatterUrl(data.url, id),
    updatedAt: data.updatedAt ?? null,
    sections,
  };
}
