import { describe, expect, it } from "vitest";
import { parseFrontMatter, parseMarkdown, splitSections } from "./markdown";

const WITH_FRONT_MATTER = `---
title: 会社案内
url: https://example.com/about
updatedAt: 2026-09-01
---

# 会社案内

わたしたちは、住まいの改修を専門とする工務店です。

## 対応エリア

市内および隣接する 3 市にお伺いします。

## 沿革

2005 年に創業しました。
`;

describe("parseFrontMatter", () => {
  it("先頭の --- で挟まれた項目を読む", () => {
    const { data, body } = parseFrontMatter(WITH_FRONT_MATTER);
    expect(data).toEqual({ title: "会社案内", url: "https://example.com/about", updatedAt: "2026-09-01" });
    expect(body.startsWith("\n# 会社案内")).toBe(true);
  });

  it("引用符は外す", () => {
    expect(parseFrontMatter(`---\ntitle: "料金 について"\n---\n本文`).data).toEqual({ title: "料金 について" });
    expect(parseFrontMatter(`---\ntitle: '料金'\n---\n本文`).data).toEqual({ title: "料金" });
  });

  it("値に : が入っていても最初の : だけで割る", () => {
    expect(parseFrontMatter(`---\nurl: https://example.com/a\n---\n本文`).data.url).toBe("https://example.com/a");
  });

  it("front matter が無ければ全部が本文", () => {
    expect(parseFrontMatter("# 料金\n\n本文")).toEqual({ data: {}, body: "# 料金\n\n本文" });
  });

  it("閉じの --- が無ければ全部が本文", () => {
    expect(parseFrontMatter("---\ntitle: 料金\n\n本文")).toEqual({ data: {}, body: "---\ntitle: 料金\n\n本文" });
  });
});

describe("splitSections", () => {
  it("先頭の # を題名として食べ、## 以下で節を割る", () => {
    const { title, sections } = splitSections(parseFrontMatter(WITH_FRONT_MATTER).body);
    expect(title).toBe("会社案内");
    expect(sections).toEqual([
      { heading: "", text: "わたしたちは、住まいの改修を専門とする工務店です。" },
      { heading: "対応エリア", text: "市内および隣接する 3 市にお伺いします。" },
      { heading: "沿革", text: "2005 年に創業しました。" },
    ]);
  });

  it("# が無ければ題名は null", () => {
    expect(splitSections("## 料金\n\n本文")).toEqual({
      title: null,
      sections: [{ heading: "料金", text: "本文" }],
    });
  });

  it("### も節の切れ目になる", () => {
    expect(splitSections("### 細目\n\n本文").sections).toEqual([{ heading: "細目", text: "本文" }]);
  });

  it("見出しの前の文は見出し無しの節になる", () => {
    expect(splitSections("まえがき\n\n## 料金\n\n本文").sections).toEqual([
      { heading: "", text: "まえがき" },
      { heading: "料金", text: "本文" },
    ]);
  });
});

describe("parseMarkdown", () => {
  it("front matter・題名・節をまとめて返す", () => {
    const doc = parseMarkdown(WITH_FRONT_MATTER, "about");
    expect(doc.id).toBe("about");
    expect(doc.title).toBe("会社案内");
    expect(doc.url).toBe("https://example.com/about");
    expect(doc.updatedAt).toBe("2026-09-01");
    expect(doc.sections).toHaveLength(3);
    expect(doc.sections[1].heading).toBe("対応エリア");
  });

  it("url が http(s) でなければ、索引づくりの時点で止める", () => {
    expect(() => parseMarkdown("---\nurl: javascript:alert(1)\n---\n# 料金\n\n本文", "price")).toThrow(
      "price の url「javascript:alert(1)」は http:// か https:// で始めてください",
    );
    expect(() => parseMarkdown("---\nurl: example.com/price\n---\n# 料金\n\n本文", "price")).toThrow(
      "price の url「example.com/price」を読み取れません。http:// か https:// で始めてください",
    );
    // 空の url は「無し」として扱う（書きかけで止めない）
    expect(parseMarkdown("---\nurl:\n---\n# 料金\n\n本文", "price").url).toBe(null);
  });

  it("front matter が無ければ # 見出しが題名になる", () => {
    const doc = parseMarkdown("# 料金\n\n工事の費用は内容によって変わります。", "price");
    expect(doc.title).toBe("料金");
    expect(doc.url).toBe(null);
    expect(doc.updatedAt).toBe(null);
    expect(doc.sections).toEqual([{ heading: "", text: "工事の費用は内容によって変わります。" }]);
  });

  it("題名が見つからなければ id を題名にする", () => {
    expect(parseMarkdown("本文だけ", "faq").title).toBe("faq");
  });

  it("front matter の title は # 見出しより強い", () => {
    expect(parseMarkdown("---\ntitle: よくあるご質問\n---\n# FAQ\n\n本文", "faq").title).toBe("よくあるご質問");
  });
});
