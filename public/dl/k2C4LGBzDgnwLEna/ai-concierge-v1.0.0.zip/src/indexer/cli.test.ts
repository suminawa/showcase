import { mkdtemp, readFile, mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import type { IndexFile } from "../core/types";
import { idOf, parseArgs, run, USAGE } from "./cli";

async function workspace(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "ai-concierge-"));
  await mkdir(join(root, "content"), { recursive: true });
  await writeFile(
    join(root, "content", "about.md"),
    "---\nurl: https://example.com/about\n---\n# 会社概要\n\nわたしたちは住まいの改修を専門とする工務店です。\n\n## 対応エリア\n\n市内と隣の三市にお伺いします。\n",
    "utf8",
  );
  await writeFile(join(root, "content", "price.md"), "# 料金\n\n八十万円が目安です。\n", "utf8");
  await writeFile(
    join(root, "concierge.config.json"),
    JSON.stringify({ site: { name: "みなと工務店" }, content: join(root, "content") }),
    "utf8",
  );
  return root;
}

function sink(): { lines: string[]; errors: string[]; log: (m: string) => void; error: (m: string) => void } {
  const lines: string[] = [];
  const errors: string[] = [];
  return { lines, errors, log: (m) => lines.push(m), error: (m) => errors.push(m) };
}

describe("parseArgs", () => {
  it("index が既定の仕事", () => {
    expect(parseArgs(["index"])).toEqual({
      command: "index",
      check: false,
      countTokens: false,
      configPath: "concierge.config.json",
      out: null,
    });
  });

  it("--check と --count-tokens", () => {
    expect(parseArgs(["index", "--check"]).check).toBe(true);
    expect(parseArgs(["index", "--count-tokens"]).countTokens).toBe(true);
  });

  it("--config と --out", () => {
    const options = parseArgs(["index", "--config", "a/b.json", "--out", "public/index.json"]);
    expect(options.configPath).toBe("a/b.json");
    expect(options.out).toBe("public/index.json");
  });

  it("知らない引数と値の無い --out は断る", () => {
    expect(() => parseArgs(["index", "--ceck"])).toThrow(/知らない引数です: --ceck/);
    expect(() => parseArgs(["index", "--out"])).toThrow(/--out には値が要ります/);
  });

  it("引数が無ければ使い方を出す", () => {
    expect(parseArgs([]).command).toBe("help");
    expect(parseArgs(["--help"]).command).toBe("help");
    expect(parseArgs(["いきなり変な語"]).command).toBe("help");
  });
});

describe("idOf", () => {
  it("ファイル名から拡張子を落として id にする", () => {
    expect(idOf("about.md")).toBe("about");
    expect(idOf("faq.markdown")).toBe("faq");
  });
});

describe("run", () => {
  it("--help は使い方を出して 0", async () => {
    const io = sink();
    expect(await run(["--help"], io)).toBe(0);
    expect(io.lines.join("\n")).toBe(USAGE);
  });

  it("content から索引を作って書き出す", async () => {
    const root = await workspace();
    const io = sink();
    const code = await run(
      ["index", "--config", join(root, "concierge.config.json"), "--out", join(root, "data", "index.json")],
      { ...io, builtAt: () => "2026-09-12T00:00:00.000Z" },
    );
    expect(code).toBe(0);
    const file = JSON.parse(await readFile(join(root, "data", "index.json"), "utf8")) as IndexFile;
    expect(file.version).toBe(1);
    expect(file.builtAt).toBe("2026-09-12T00:00:00.000Z");
    expect(file.documents.map((doc) => doc.id).sort()).toEqual(["about", "price"]);
    const about = file.documents.find((doc) => doc.id === "about")!;
    expect(about.title).toBe("会社概要");
    expect(about.url).toBe("https://example.com/about");
    expect(about.chunks[0].breadcrumb.startsWith("会社概要")).toBe(true);
    expect(file.stats.documents).toBe(2);
    expect(io.lines.some((line) => line.startsWith("文書 2 本・片"))).toBe(true);
  });

  it("--check なら書かない", async () => {
    const root = await workspace();
    const io = sink();
    const code = await run(["index", "--config", join(root, "concierge.config.json"), "--check"], io);
    expect(code).toBe(0);
    expect(io.lines.some((line) => line.includes("--check"))).toBe(true);
    await expect(readFile(join(root, "data", "index.json"), "utf8")).rejects.toThrow();
  });

  it("urls のページも取り込む", async () => {
    const root = await workspace();
    await writeFile(
      join(root, "concierge.config.json"),
      JSON.stringify({ site: { name: "みなと工務店" }, content: join(root, "content"), urls: ["https://example.com/faq"] }),
      "utf8",
    );
    const io = sink();
    const fakeFetch = (async () =>
      new Response("<html><head><title>よくあるご質問</title></head><body><main><h2>工事中の暮らし</h2><p>住み続けられます。</p></main></body></html>", {
        status: 200,
      })) as unknown as typeof fetch;
    const code = await run(["index", "--config", join(root, "concierge.config.json"), "--out", join(root, "data", "index.json")], {
      ...io,
      fetchImpl: fakeFetch,
      builtAt: () => "2026-09-12T00:00:00.000Z",
    });
    expect(code).toBe(0);
    const file = JSON.parse(await readFile(join(root, "data", "index.json"), "utf8")) as IndexFile;
    const page = file.documents.find((doc) => doc.url === "https://example.com/faq")!;
    expect(page.title).toBe("よくあるご質問");
    expect(page.chunks[0].text).toContain("住み続けられます。");
  });

  it("知らない引数なら何が悪いか言って 1 を返す", async () => {
    const errors: string[] = [];
    const code = await run(["index", "--ceck"], { log: () => {}, error: (message) => errors.push(message) });
    expect(code).toBe(1);
    expect(errors[0]).toContain("知らない引数です: --ceck");
  });

  it("同じ id になるファイルが 2 つあれば止める", async () => {
    const root = await workspace();
    await writeFile(join(root, "content", "about.markdown"), "# 会社概要（別）\n\n別の本文です。\n", "utf8");
    const errors: string[] = [];
    const code = await run(["index", "--config", join(root, "concierge.config.json"), "--check"], {
      log: () => {},
      error: (message) => errors.push(message),
      builtAt: () => "2026-09-12T00:00:00.000Z",
    });
    expect(code).toBe(1);
    expect(errors.join("\n")).toContain("about.markdown と about.md は同じ id（about）になります");
  });

  it("content が無ければ何が悪いか言って 1 を返す", async () => {
    const root = await mkdtemp(join(tmpdir(), "ai-concierge-"));
    await writeFile(
      join(root, "concierge.config.json"),
      JSON.stringify({ site: { name: "みなと工務店" }, content: join(root, "ない") }),
      "utf8",
    );
    const io = sink();
    expect(await run(["index", "--config", join(root, "concierge.config.json")], io)).toBe(1);
    expect(io.errors.join("\n")).toContain("見つかりません");
  });

  it("--count-tokens は API キーが無ければ断る", async () => {
    const root = await workspace();
    const io = sink();
    const saved = process.env.ANTHROPIC_API_KEY;
    delete process.env.ANTHROPIC_API_KEY;
    try {
      expect(await run(["index", "--config", join(root, "concierge.config.json"), "--count-tokens", "--check"], io)).toBe(1);
      expect(io.errors.join("\n")).toContain("ANTHROPIC_API_KEY");
    } finally {
      if (saved !== undefined) process.env.ANTHROPIC_API_KEY = saved;
    }
  });
});
