import type { DocumentSource, Section } from "./chunk";

export const USER_AGENT = "ai-concierge-indexer/1.0";

/** 本文でないところを先に落とす。中に入れ子があっても、非貪欲で外側から順に消える */
export function stripBlocks(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, "")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, "")
    .replace(/<nav\b[^>]*>[\s\S]*?<\/nav\s*>/gi, "")
    .replace(/<footer\b[^>]*>[\s\S]*?<\/footer\s*>/gi, "");
}

export function extractMainHtml(html: string): string {
  for (const tag of ["main", "article", "body"]) {
    const found = new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}\\s*>`, "i").exec(html);
    if (found !== null) return found[1];
  }
  return html;
}

const NAMED: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
};

export function decodeEntities(text: string): string {
  return text.replace(/&(#[Xx]?[0-9A-Fa-f]+|[A-Za-z]+);/g, (whole: string, body: string) => {
    if (body.startsWith("#")) {
      const hex = body[1] === "x" || body[1] === "X";
      const code = Number.parseInt(hex ? body.slice(2) : body.slice(1), hex ? 16 : 10);
      if (!Number.isInteger(code) || code < 0 || code > 0x10ffff) return whole;
      return String.fromCodePoint(code);
    }
    const named = NAMED[body.toLowerCase()];
    return named === undefined ? whole : named;
  });
}

const BLOCK_END = /<\/(p|div|li|ul|ol|h[1-6]|section|article|main|table|tr|blockquote|pre|dd|dt)\s*>/gi;

export function htmlToText(html: string): string {
  const withBreaks = html.replace(/<br\s*\/?>/gi, "\n").replace(BLOCK_END, "\n\n");
  const text = decodeEntities(withBreaks.replace(/<[^>]*>/g, ""));
  return text
    .split("\n")
    .map((line) => line.replace(/[ \t ]+/g, " ").trim())
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function extractTitle(html: string): string | null {
  const title = /<title\b[^>]*>([\s\S]*?)<\/title\s*>/i.exec(html);
  if (title !== null) {
    const text = htmlToText(title[1]);
    if (text !== "") return text;
  }
  const h1 = /<h1\b[^>]*>([\s\S]*?)<\/h1\s*>/i.exec(html);
  if (h1 !== null) {
    const text = htmlToText(h1[1]);
    if (text !== "") return text;
  }
  return null;
}

export function pageToDocument(html: string, url: string, id: string): DocumentSource {
  const cleaned = stripBlocks(html);
  const title = extractTitle(cleaned) ?? url;
  const main = extractMainHtml(cleaned);

  const sections: Section[] = [];
  const heading = /<h([23])\b[^>]*>([\s\S]*?)<\/h\1\s*>/gi;
  let cursor = 0;
  let current = "";
  let found: RegExpExecArray | null = heading.exec(main);
  while (found !== null) {
    sections.push({ heading: current, text: htmlToText(main.slice(cursor, found.index)) });
    current = htmlToText(found[2]);
    cursor = found.index + found[0].length;
    found = heading.exec(main);
  }
  sections.push({ heading: current, text: htmlToText(main.slice(cursor)) });

  return {
    id,
    title,
    url,
    updatedAt: null,
    sections: sections.filter((section) => section.text !== "" || section.heading !== ""),
  };
}

export async function fetchPage(url: string, fetchImpl: typeof fetch = fetch): Promise<string> {
  const response = await fetchImpl(url, {
    headers: { accept: "text/html,application/xhtml+xml", "user-agent": USER_AGENT },
    redirect: "follow",
  });
  if (!response.ok) throw new Error(`${url} を取得できませんでした（HTTP ${response.status}）`);
  return await response.text();
}
