import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    // 既定は node。DOM が要るのは窓のテストだけで、そこは
    // ファイルの先頭の `// @vitest-environment jsdom` で切り替える
    environment: "node",
    globals: true,
    setupFiles: ["./test/setup.ts"],
    include: ["src/**/*.test.ts", "eval/**/*.test.ts"],
  },
});
