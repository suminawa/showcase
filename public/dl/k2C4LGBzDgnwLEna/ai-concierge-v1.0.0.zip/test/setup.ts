/**
 * テストの下ごしらえ。Node 22 以降は globalThis に実験的な localStorage /
 * sessionStorage を持っていて、--localstorage-file を渡さないと読み書きで失敗する。
 * jsdom 環境はすでにある鍵を上書きしないため、jsdom の Storage が隠れてしまう。
 * ここで記憶だけの Storage に差し替える。
 */
import { beforeEach } from "vitest";

class MemoryStorage implements Storage {
  private map = new Map<string, string>();
  get length(): number {
    return this.map.size;
  }
  clear(): void {
    this.map.clear();
  }
  getItem(key: string): string | null {
    return this.map.has(key) ? (this.map.get(key) as string) : null;
  }
  key(index: number): string | null {
    return Array.from(this.map.keys())[index] ?? null;
  }
  removeItem(key: string): void {
    this.map.delete(key);
  }
  setItem(key: string, value: string): void {
    this.map.set(key, String(value));
  }
}

const session = new MemoryStorage();
const local = new MemoryStorage();

Object.defineProperty(globalThis, "sessionStorage", { value: session, configurable: true, writable: true });
Object.defineProperty(globalThis, "localStorage", { value: local, configurable: true, writable: true });

beforeEach(() => {
  session.clear();
  local.clear();
});
