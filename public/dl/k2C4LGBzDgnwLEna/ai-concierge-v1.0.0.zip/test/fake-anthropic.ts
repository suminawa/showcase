import type {
  AnthropicClientLike,
  FinalMessageLike,
  MessageParams,
  MessageStreamLike,
  StreamEventLike,
} from "../src/core/types";

export interface FakeScript {
  events?: StreamEventLike[];
  final?: FinalMessageLike;
  streamError?: Error;
  finalError?: Error;
}

export interface FakeClient extends AnthropicClientLike {
  calls: MessageParams[];
  /** abort() が呼ばれた回数。切断で上流を止めているかを確かめる */
  aborts: number;
}

export function textDelta(text: string): StreamEventLike {
  return { type: "content_block_delta", index: 0, delta: { type: "text_delta", text } };
}

export function citationDelta(documentIndex: number, citedText: string): StreamEventLike {
  return {
    type: "content_block_delta",
    index: 0,
    delta: {
      type: "citations_delta",
      citation: {
        type: "char_location",
        cited_text: citedText,
        document_index: documentIndex,
        document_title: `[${documentIndex + 1}] 見本`,
        start_char_index: 0,
        end_char_index: citedText.length,
      },
    },
  };
}

export function finalOf(patch: Partial<FinalMessageLike> = {}): FinalMessageLike {
  return {
    stop_reason: "end_turn",
    usage: { input_tokens: 120, output_tokens: 80, cache_read_input_tokens: 29800, cache_creation_input_tokens: 0 },
    content: [{ type: "text", text: "" }],
    ...patch,
  };
}

export function fakeClient(script: FakeScript = {}): FakeClient {
  const calls: MessageParams[] = [];
  const client: FakeClient = {
    calls,
    aborts: 0,
    messages: {
      stream(params: MessageParams): MessageStreamLike {
        calls.push(params);
        const events = script.events ?? [];
        return {
          async *[Symbol.asyncIterator](): AsyncGenerator<StreamEventLike> {
            if (script.streamError !== undefined) throw script.streamError;
            for (const event of events) yield event;
          },
          async finalMessage(): Promise<FinalMessageLike> {
            if (script.finalError !== undefined) throw script.finalError;
            return script.final ?? finalOf();
          },
          abort(): void {
            client.aborts += 1;
          },
        };
      },
    },
  };
  return client;
}
