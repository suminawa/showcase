import type { ReactNode } from "react";

export const metadata = {
  title: "みなと工務店",
  description: "AI 案内窓口を置いた見本のサイトです。",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ja">
      <head>
        <link rel="stylesheet" href="/ai-concierge.css" />
      </head>
      <body style={{ fontFamily: "system-ui, sans-serif", margin: "0 auto", maxWidth: "44rem", padding: "3rem 1rem 8rem", lineHeight: 1.8 }}>
        {children}
        {/* あいさつ・質問の候補・窓の文言は concierge.config.json から読み込みます。
            書き換える場所を 1 つにするため、ここには書きません。
            問い合わせ先だけは、このアプリの中のページを指すので属性で渡します */}
        <script src="/ai-concierge.js" data-endpoint="/api/concierge" data-contact-url="/contact" />
      </body>
    </html>
  );
}
