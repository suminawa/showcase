import { createConcierge, loadConfigFile, loadIndex, resolveConfig, type Concierge } from "@suminawa/ai-concierge";

// 索引を読むのでサーバー側で動かす。答えは流しながら返すので、長めの持ち時間を取る
export const runtime = "nodejs";
export const maxDuration = 60;
export const dynamic = "force-dynamic";

let ready: Promise<Concierge> | null = null;

// 1 つのインスタンスで 1 回だけ作る（索引の読み込みと BM25 の下ごしらえを毎回やらない）
function concierge(): Promise<Concierge> {
  if (ready === null) {
    ready = (async () => {
      const config = resolveConfig({ file: await loadConfigFile("concierge.config.json"), env: process.env });
      const index = await loadIndex(config.indexPath);
      return createConcierge(config, { index });
    })();
  }
  return ready;
}

export async function POST(request: Request): Promise<Response> {
  return (await concierge()).fetch(request);
}

export async function GET(request: Request): Promise<Response> {
  return (await concierge()).fetch(request);
}

export async function OPTIONS(request: Request): Promise<Response> {
  return (await concierge()).fetch(request);
}
