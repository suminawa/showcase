export const metadata = {
  title: "お問い合わせ",
};

export default function ContactPage() {
  return (
    <main>
      <h1>お問い合わせ</h1>
      <p>
        お問い合わせは、下記のメールアドレスまでお願いいたします。
        <br />
        info@example.com
      </p>
      <p>こちらは見本のページです。実際の連絡先は、貴社にてこのアドレスを書き換えてご利用ください。</p>
    </main>
  );
}
