export default function Page() {
  return (
    <main>
      <h1>みなと工務店</h1>
      <p>
        住まいの改修を承っております。ご不明な点は、右下の「質問する」からお気軽にお尋ねください。
        公開している資料の範囲でご案内いたします。
      </p>
      <h2>置き方</h2>
      <ol>
        <li>
          <code>content/</code> に自社の文書を Markdown で置きます。
        </li>
        <li>
          <code>npm run index</code> で <code>data/index.json</code> を作ります。
        </li>
        <li>
          環境変数 <code>ANTHROPIC_API_KEY</code> を入れて <code>npm run dev</code> を実行します。
        </li>
      </ol>
    </main>
  );
}
