#!/usr/bin/env node
// 窓の束と CSS を public/ に写す。npm install のたびに走るので、
// キットを新しくしたら自動で入れ替わる。
import { copyFile, mkdir } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";

const require = createRequire(import.meta.url);

try {
  const entry = require.resolve("@suminawa/ai-concierge");
  const dist = dirname(entry);
  await mkdir("public", { recursive: true });
  for (const name of ["ai-concierge.js", "ai-concierge.css"]) {
    await copyFile(join(dist, name), join("public", name));
    console.log(`public/${name} を用意しました`);
  }
} catch (error) {
  console.warn(`窓の束を写せませんでした: ${error.message}`);
  console.warn("キットの中で npm run build を実行してから、もう一度 npm install をお試しください。");
  process.exitCode = 1;
}
