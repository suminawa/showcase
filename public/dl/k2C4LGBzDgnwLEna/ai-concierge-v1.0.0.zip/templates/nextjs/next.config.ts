import type { NextConfig } from "next";

const config: NextConfig = {
  // data/index.json は実行時に読むので、束に取り込ませない
  serverExternalPackages: ["@anthropic-ai/sdk"],
  // Route Handler（app/api/concierge/[...path]/route.ts）は concierge.config.json と
  // data/ 以下を「実行時」に readFile で読む。Next.js の自動追跡はこの読み込みを見つけられないため、
  // ここで明示しないと Vercel に上げる束から漏れて、本番でだけ「見つかりません」になる
  // 鍵は route の glob。角かっこ付きの経路名はエスケープが要るので、公式の書き方どおり「全経路」に付ける
  outputFileTracingIncludes: {
    "/*": ["./concierge.config.json", "./data/**/*"],
  },
};

export default config;
