/** このファイルは型だけを持つ。実行するコードを置かない（窓の束にも安全に import できるように） */

export type EffortLevel = "low" | "medium" | "high";
export type WebhookFormat = "json" | "slack";

export interface SiteInfo {
  name: string;
  url: string | null;
}

export interface AnswerConfig {
  model: string;
  effort: EffortLevel;
  maxTokens: number;
  style: string;
}

export interface RetrievalConfig {
  wholeCorpusMaxTokens: number;
  topK: number;
}

export interface LimitsConfig {
  maxInputChars: number;
  perMinute: number;
  perHour: number;
  dailyQuestions: number;
}

/** 窓の文言。すべて敬体。買い手が差し替えられる（英語化もできる） */
export interface WidgetLabels {
  windowTitle: string;
  open: string;
  close: string;
  placeholder: string;
  send: string;
  thinking: string;
  sources: string;
  contact: string;
  reset: string;
  /** 答えが出そろったときに、読み上げへ 1 回だけ知らせる文 */
  answerDone: string;
  unavailable: string;
  tooLong: string;
  rateLimited: string;
  offline: string;
  emptyQuestion: string;
}

export interface ConciergeConfig {
  site: SiteInfo;
  urls: string[];
  content: string;
  alwaysInclude: string[];
  greeting: string;
  suggestions: string[];
  contactUrl: string | null;
  labels: Partial<WidgetLabels>;
  answer: AnswerConfig;
  retrieval: RetrievalConfig;
  limits: LimitsConfig;
  indexPath: string;
  allowedOrigins: string[];
  adminToken: string | null;
  logWebhookUrl: string | null;
  logWebhookFormat: WebhookFormat;
  /** 前段の proxy が付ける x-forwarded-for を信じるか（既定 false） */
  trustProxy: boolean;
  apiKey: string | null;
}

/** 切ったばかりの片。BM25 の語はまだ数えていない */
export interface ChunkDraft {
  id: string;
  heading: string;
  breadcrumb: string;
  text: string;
  tokens: number;
  /**
   * 節を合わせた片で、先頭以外の見出し。表示の題（heading・breadcrumb）には出ないが、
   * BM25 の索引づくりでは見出しと同じ重みで拾う（索引には残さない。buildIndexFile で外す）
   */
  extraHeadings?: string[];
}

/** 索引に入る片。len は BM25 の語の総数、tf は語ごとの出方 */
export interface Chunk extends ChunkDraft {
  len: number;
  tf: Record<string, number>;
}

export interface DocumentDraft {
  id: string;
  title: string;
  url: string | null;
  updatedAt: string | null;
  chunks: ChunkDraft[];
}

export interface IndexDocument {
  id: string;
  title: string;
  url: string | null;
  updatedAt: string | null;
  chunks: Chunk[];
}

export interface IndexStats {
  documents: number;
  chunks: number;
  totalTokens: number;
  avgLen: number;
  df: Record<string, number>;
}

export interface IndexFile {
  version: 1;
  builtAt: string;
  documents: IndexDocument[];
  stats: IndexStats;
}

export interface IndexEntry {
  doc: IndexDocument;
  chunk: Chunk;
  docIndex: number;
  chunkIndex: number;
}

export interface LoadedIndex {
  file: IndexFile;
  entries: IndexEntry[];
  byId: Map<string, IndexEntry>;
  stats: IndexStats;
}

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

export interface ChatRequest {
  question: string;
  history: ChatTurn[];
}

export type ChatErrorCode = "unavailable" | "rate_limited" | "too_long" | "forbidden" | "daily_limit";

export type ChatEvent =
  | { type: "text"; text: string }
  | { type: "citation"; index: number; title: string; url: string | null }
  /**
   * reason は answered が false のときだけ付く。窓はこれを見て
   * 問い合わせ先のボタンを出すかどうかを決める。
   * - not_in_documents: 「資料に載っていません」と伝えた（ボタンを出す）
   * - no_citations: 答えは出たが出典が付かなかった（ボタンは出さない）
   * - error: 断られた・失敗した（ボタンを出す）
   */
  | { type: "done"; answered: boolean; reason?: "no_citations" | "not_in_documents" | "error" }
  /** clear が true のときは、途中まで出ていた答えを窓から消す */
  | { type: "error"; code: ChatErrorCode; message: string; clear?: boolean };

/* ── Anthropic の受け渡しに使う最小の形。SDK の型そのものは client.ts でだけ触る ── */

export interface CitationLike {
  type: string;
  cited_text?: string;
  document_index: number;
  document_title?: string | null;
  start_char_index?: number;
  end_char_index?: number;
}

export interface StreamEventLike {
  type: string;
  index?: number;
  delta?: { type: string; text?: string; citation?: CitationLike };
}

export interface AnswerUsage {
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  cacheCreationTokens: number;
}

export interface FinalMessageLike {
  stop_reason: string | null;
  stop_details?: { type?: string; category?: string | null; explanation?: string } | null;
  usage?: {
    input_tokens?: number;
    output_tokens?: number;
    cache_read_input_tokens?: number;
    cache_creation_input_tokens?: number;
  };
  content?: Array<{ type: string; text?: string; citations?: CitationLike[] | null }>;
}

export interface MessageStreamLike extends AsyncIterable<StreamEventLike> {
  finalMessage(): Promise<FinalMessageLike>;
  /**
   * 途中で問い合わせを打ち切る（SDK の MessageStream.abort()）。
   * 訪問者が窓を閉じたときに、誰も読まない答えの続きを課金されないようにする。
   * 持っていない実装もあるので省略できる形にしてある。
   */
  abort?(): void;
}

export interface AnthropicClientLike {
  messages: { stream(params: MessageParams): MessageStreamLike };
}

/**
 * キャッシュの区切り。ttl を省くと 5 分、"1h" で 1 時間もちます
 * （SDK 0.125.0 の CacheControlEphemeral と同じ形）。
 */
export interface CacheControlEphemeral {
  type: "ephemeral";
  ttl?: "5m" | "1h";
}

export interface TextBlockParam {
  type: "text";
  text: string;
  cache_control?: CacheControlEphemeral;
}

export interface DocumentBlockParam {
  type: "document";
  source: { type: "text"; media_type: "text/plain"; data: string };
  title: string;
  citations: { enabled: true };
  cache_control?: CacheControlEphemeral;
}

export type UserContentBlock = DocumentBlockParam | TextBlockParam;

export interface MessageParamLike {
  role: "user" | "assistant";
  content: string | UserContentBlock[];
}

export interface MessageParams {
  model: string;
  max_tokens: number;
  system: TextBlockParam[];
  messages: MessageParamLike[];
  output_config?: { effort: EffortLevel };
}

/** document ブロック 1 つ = 出典 1 つ。index は 1 始まり（document_index + 1） */
export interface PromptSource {
  index: number;
  docId: string;
  chunkId: string;
  title: string;
  url: string | null;
  breadcrumb: string;
}
