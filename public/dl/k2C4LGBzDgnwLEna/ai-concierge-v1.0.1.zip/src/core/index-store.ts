import { chunkTerms, corpusStats } from "./bm25";
import type { Chunk, DocumentDraft, IndexDocument, IndexEntry, IndexFile, IndexStats, LoadedIndex } from "./types";

function bad(message: string): never {
  throw new Error(`索引: ${message}`);
}

function recordOf(value: unknown, where: string): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) bad(`${where} が入れ物（{ … }）ではありません`);
  return value as Record<string, unknown>;
}

function stringOf(value: unknown, where: string): string {
  if (typeof value !== "string") bad(`${where} が文字列ではありません`);
  return value;
}

function nullableStringOf(value: unknown, where: string): string | null {
  if (value === null || value === undefined) return null;
  return stringOf(value, where);
}

function numberOf(value: unknown, where: string): number {
  if (typeof value !== "number" || !Number.isFinite(value)) bad(`${where} が数ではありません`);
  return value;
}

function countsOf(value: unknown, where: string): Record<string, number> {
  const raw = recordOf(value, where);
  const out: Record<string, number> = {};
  for (const [key, item] of Object.entries(raw)) out[key] = numberOf(item, `${where}.${key}`);
  return out;
}

function validateChunk(value: unknown, where: string): Chunk {
  const raw = recordOf(value, where);
  return {
    id: stringOf(raw.id, `${where}.id`),
    heading: stringOf(raw.heading, `${where}.heading`),
    breadcrumb: stringOf(raw.breadcrumb, `${where}.breadcrumb`),
    text: stringOf(raw.text, `${where}.text`),
    tokens: numberOf(raw.tokens, `${where}.tokens`),
    len: numberOf(raw.len, `${where}.len`),
    tf: countsOf(raw.tf, `${where}.tf`),
  };
}

function validateDocument(value: unknown, i: number): IndexDocument {
  const where = `documents[${i}]`;
  const raw = recordOf(value, where);
  if (!Array.isArray(raw.chunks)) bad(`${where}.chunks が一覧ではありません`);
  return {
    id: stringOf(raw.id, `${where}.id`),
    title: stringOf(raw.title, `${where}.title`),
    url: nullableStringOf(raw.url, `${where}.url`),
    updatedAt: nullableStringOf(raw.updatedAt, `${where}.updatedAt`),
    chunks: raw.chunks.map((chunk, j) => validateChunk(chunk, `${where}.chunks[${j}]`)),
  };
}

function validateStats(value: unknown): IndexStats {
  const raw = recordOf(value, "stats");
  return {
    documents: numberOf(raw.documents, "stats.documents"),
    chunks: numberOf(raw.chunks, "stats.chunks"),
    totalTokens: numberOf(raw.totalTokens, "stats.totalTokens"),
    avgLen: numberOf(raw.avgLen, "stats.avgLen"),
    df: countsOf(raw.df, "stats.df"),
  };
}

export function validateIndex(value: unknown): IndexFile {
  const raw = recordOf(value, "索引の中身");
  if (raw.version !== 1) {
    bad(`version が 1 ではありません（いまの値: ${String(raw.version)}）。npx ai-concierge index で作り直してください`);
  }
  if (!Array.isArray(raw.documents)) bad("documents が一覧ではありません");
  return {
    version: 1,
    builtAt: stringOf(raw.builtAt, "builtAt"),
    documents: raw.documents.map((doc, i) => validateDocument(doc, i)),
    stats: validateStats(raw.stats),
  };
}

export function toLoadedIndex(file: IndexFile): LoadedIndex {
  const entries: IndexEntry[] = [];
  const byId = new Map<string, IndexEntry>();
  file.documents.forEach((doc, docIndex) => {
    doc.chunks.forEach((chunk, chunkIndex) => {
      const entry: IndexEntry = { doc, chunk, docIndex, chunkIndex };
      entries.push(entry);
      byId.set(chunk.id, entry);
    });
  });
  return { file, entries, byId, stats: file.stats };
}

export function loadIndexFromJson(json: string): LoadedIndex {
  let parsed: unknown;
  try {
    parsed = JSON.parse(json) as unknown;
  } catch (error) {
    bad(`JSON として読めません: ${(error as Error).message}`);
  }
  return toLoadedIndex(validateIndex(parsed));
}

export async function loadIndex(path: string): Promise<LoadedIndex> {
  const { readFile } = await import("node:fs/promises");
  let json: string;
  try {
    json = await readFile(path, "utf8");
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      bad(`${path} が見つかりません。npx ai-concierge index で作ってください`);
    }
    throw error;
  }
  return loadIndexFromJson(json);
}

export function emptyIndex(builtAt: string): LoadedIndex {
  return toLoadedIndex({
    version: 1,
    builtAt,
    documents: [],
    stats: { documents: 0, chunks: 0, totalTokens: 0, avgLen: 0, df: {} },
  });
}

export function indexSummary(index: LoadedIndex): string {
  const { documents, chunks, totalTokens } = index.stats;
  return `文書 ${documents} 本・片 ${chunks} 個・概算 ${totalTokens} トークン`;
}

/** 切ったばかりの文書に BM25 の語を数えて入れ、索引 1 枚に仕上げる */
export function buildIndexFile(documents: DocumentDraft[], builtAt: string): IndexFile {
  const filled: IndexDocument[] = documents.map((doc) => ({
    id: doc.id,
    title: doc.title,
    url: doc.url,
    updatedAt: doc.updatedAt,
    // extraHeadings は語を数えるためだけの下書き情報なので、索引には残さない
    chunks: doc.chunks.map((draft) => {
      const filled: Chunk & { extraHeadings?: string[] } = { ...draft, ...chunkTerms(draft) };
      delete filled.extraHeadings;
      return filled;
    }),
  }));
  const chunks = filled.flatMap((doc) => doc.chunks);
  const { avgLen, df } = corpusStats(chunks);
  return {
    version: 1,
    builtAt,
    documents: filled,
    stats: {
      documents: filled.length,
      chunks: chunks.length,
      totalTokens: chunks.reduce((sum, chunk) => sum + chunk.tokens, 0),
      avgLen,
      df,
    },
  };
}
