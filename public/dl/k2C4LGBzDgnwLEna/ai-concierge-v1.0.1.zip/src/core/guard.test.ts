import { describe, expect, it } from "vitest";
import { DEFAULT_LIMITS } from "./config";
import {
  checkDaily,
  checkInput,
  checkOrigin,
  checkRate,
  createGuardState,
  dayKeyOf,
  GUARD_MESSAGES,
  MAX_KEYS,
  originAllowed,
  takeToken,
} from "./guard";

const SELF = "https://example.com";

describe("originAllowed", () => {
  it("Origin が無いとき（同一オリジン）は通す", () => {
    expect(originAllowed(null, ["https://example.com"], SELF)).toBe(true);
  });

  it("同じオリジンはいつでも通す", () => {
    expect(originAllowed(SELF, ["https://other.example"], SELF)).toBe(true);
  });

  it("ALLOWED_ORIGINS が空なら同一オリジンだけを許す（他所からの呼び出しは断る）", () => {
    expect(originAllowed("https://anywhere.example", [], SELF)).toBe(false);
    expect(originAllowed(SELF, [], SELF)).toBe(true);
  });

  it("一覧にあれば通し、無ければ止める", () => {
    expect(originAllowed("https://www.example.com", ["https://www.example.com"], SELF)).toBe(true);
    expect(originAllowed("https://evil.example", ["https://www.example.com"], SELF)).toBe(false);
  });
});

describe("checkOrigin", () => {
  it("止めるときは 403 と丁寧な断り", () => {
    expect(checkOrigin("https://evil.example", ["https://example.com"], SELF)).toEqual({
      ok: false,
      status: 403,
      code: "forbidden",
      message: GUARD_MESSAGES.forbidden,
    });
    expect(GUARD_MESSAGES.forbidden).toBe("このページからのご利用は受け付けておりません。");
  });

  it("通すときは ok だけ", () => {
    expect(checkOrigin(null, [], SELF)).toEqual({ ok: true });
  });
});

describe("checkInput", () => {
  it("長すぎたら 413", () => {
    expect(checkInput("あ".repeat(401), 400)).toEqual({
      ok: false,
      status: 413,
      code: "too_long",
      message: "質問は 400 字以内でお願いします。",
    });
  });

  it("ちょうどは通す", () => {
    expect(checkInput("あ".repeat(400), 400)).toEqual({ ok: true });
  });

  it("空なら 400", () => {
    expect(checkInput("   ", 400)).toEqual({
      ok: false,
      status: 400,
      code: "unavailable",
      message: "ご質問を入力してください。",
    });
  });
});

describe("takeToken", () => {
  it("最初は満タンで、1 回ごとに 1 つ減る", () => {
    const first = takeToken(undefined, 10, 60000, 1000);
    expect(first.ok).toBe(true);
    expect(first.bucket.tokens).toBe(9);
    const second = takeToken(first.bucket, 10, 60000, 1000);
    expect(second.bucket.tokens).toBe(8);
  });

  it("使い切ったら断る", () => {
    let bucket = takeToken(undefined, 2, 60000, 0).bucket;
    bucket = takeToken(bucket, 2, 60000, 0).bucket;
    expect(takeToken(bucket, 2, 60000, 0).ok).toBe(false);
  });

  it("時間が経つと戻る（10 回 / 60 秒なら 6 秒で 1 つ）", () => {
    let bucket = takeToken(undefined, 10, 60000, 0).bucket;
    for (let i = 0; i < 9; i += 1) bucket = takeToken(bucket, 10, 60000, 0).bucket;
    expect(bucket.tokens).toBe(0);
    expect(takeToken(bucket, 10, 60000, 5999).ok).toBe(false);
    const back = takeToken(bucket, 10, 60000, 6000);
    expect(back.ok).toBe(true);
    expect(back.bucket.tokens).toBe(0);
  });

  it("満タンを超えて貯まらない", () => {
    const bucket = takeToken(undefined, 10, 60000, 0).bucket;
    const later = takeToken(bucket, 10, 60000, 600000);
    expect(later.bucket.tokens).toBe(9);
  });
});

describe("checkRate", () => {
  it("1 分の上限を超えたら 429", () => {
    const state = createGuardState();
    for (let i = 0; i < DEFAULT_LIMITS.perMinute; i += 1) {
      expect(checkRate(state, "1.2.3.4", DEFAULT_LIMITS, 1000)).toEqual({ ok: true });
    }
    expect(checkRate(state, "1.2.3.4", DEFAULT_LIMITS, 1000)).toEqual({
      ok: false,
      status: 429,
      code: "rate_limited",
      message: GUARD_MESSAGES.rateLimited,
    });
    expect(GUARD_MESSAGES.rateLimited).toBe("少し時間をおいてからお試しください。");
  });

  it("IP ごとに数える", () => {
    const state = createGuardState();
    for (let i = 0; i < DEFAULT_LIMITS.perMinute; i += 1) checkRate(state, "1.2.3.4", DEFAULT_LIMITS, 1000);
    expect(checkRate(state, "5.6.7.8", DEFAULT_LIMITS, 1000)).toEqual({ ok: true });
  });

  it("1 時間の上限も見る", () => {
    const state = createGuardState();
    const limits = { ...DEFAULT_LIMITS, perMinute: 1000, perHour: 3 };
    for (let i = 0; i < 3; i += 1) expect(checkRate(state, "1.2.3.4", limits, 1000)).toEqual({ ok: true });
    expect(checkRate(state, "1.2.3.4", limits, 1000).ok).toBe(false);
  });

  it("1 分で断った要求は 1 時間の枠を減らさない", () => {
    const state = createGuardState();
    const limits = { ...DEFAULT_LIMITS, perMinute: 1, perHour: 3 };
    expect(checkRate(state, "1.2.3.4", limits, 0).ok).toBe(true);
    // 同じ分の連打は 1 分の上限で断る（1 時間の枠は 1 つ使ったまま）
    expect(checkRate(state, "1.2.3.4", limits, 1000).ok).toBe(false);
    expect(checkRate(state, "1.2.3.4", limits, 2000).ok).toBe(false);
    // 1 分ごとに 1 回なら、1 時間の枠 3 つぶんは通る
    expect(checkRate(state, "1.2.3.4", limits, 61 * 1000).ok).toBe(true);
    expect(checkRate(state, "1.2.3.4", limits, 122 * 1000).ok).toBe(true);
    // 4 回目は 1 時間の上限
    expect(checkRate(state, "1.2.3.4", limits, 183 * 1000).ok).toBe(false);
  });

  it("窓の時間が過ぎたバケツは捨てる", () => {
    const state = createGuardState();
    checkRate(state, "1.2.3.4", DEFAULT_LIMITS, 0);
    expect(state.minute.size).toBe(1);

    // 1 分ちょうど過ぎたところで別の相手が来ると、前の相手の 1 分ぶんは消える
    // （満タンに戻っているので、覚えていても覚えていなくても同じ）
    checkRate(state, "5.6.7.8", DEFAULT_LIMITS, 60 * 1000);
    expect([...state.minute.keys()]).toEqual(["5.6.7.8"]);
    // 1 時間ぶんはまだ過ぎていないので、両方残る
    expect([...state.hour.keys()]).toEqual(["1.2.3.4", "5.6.7.8"]);

    // 1 時間ぶんも、両方の最後の利用から 1 時間が過ぎたところで消える
    checkRate(state, "9.9.9.9", DEFAULT_LIMITS, 60 * 60 * 1000 + 60 * 1000);
    expect([...state.hour.keys()]).toEqual(["9.9.9.9"]);
  });

  it("毎回ちがう IP から来ても、覚える数は MAX_KEYS を超えない", () => {
    const state = createGuardState();
    // 時間は止めておく（窓の時間による掃除では減らないことを確かめる）
    for (let i = 0; i < MAX_KEYS + 500; i += 1) checkRate(state, `10.0.${i >> 8}.${i & 255}`, DEFAULT_LIMITS, 1000);
    expect(MAX_KEYS).toBe(10000);
    expect(state.minute.size).toBe(MAX_KEYS);
    expect(state.hour.size).toBe(MAX_KEYS);
    // 捨てられるのは古いものから。いちばん最後に来た相手は残っている
    expect(state.minute.has(`10.0.${(MAX_KEYS + 499) >> 8}.${(MAX_KEYS + 499) & 255}`)).toBe(true);
    expect(state.minute.has("10.0.0.0")).toBe(false);
  });

  it("同じ相手が続けて来るぶんには、覚える数が増えない", () => {
    const state = createGuardState();
    for (let i = 0; i < 100; i += 1) checkRate(state, "1.2.3.4", DEFAULT_LIMITS, 1000);
    expect(state.minute.size).toBe(1);
    expect(state.hour.size).toBe(1);
  });
});

describe("dayKeyOf", () => {
  it("日本時間の日付で区切る", () => {
    expect(dayKeyOf(Date.parse("2026-09-12T14:59:59.000Z"))).toBe("2026-09-12");
    expect(dayKeyOf(Date.parse("2026-09-12T15:00:00.000Z"))).toBe("2026-09-13");
  });
});

describe("checkDaily", () => {
  const noon = Date.parse("2026-09-12T03:00:00.000Z");

  it("1 日の上限まで通し、超えたら断る", () => {
    const state = createGuardState();
    const limits = { ...DEFAULT_LIMITS, dailyQuestions: 2 };
    expect(checkDaily(state, limits, noon)).toEqual({ ok: true });
    expect(checkDaily(state, limits, noon)).toEqual({ ok: true });
    expect(checkDaily(state, limits, noon)).toEqual({
      ok: false,
      status: 429,
      code: "daily_limit",
      message: GUARD_MESSAGES.dailyLimit,
    });
  });

  it("日が変わったら数え直す", () => {
    const state = createGuardState();
    const limits = { ...DEFAULT_LIMITS, dailyQuestions: 1 };
    expect(checkDaily(state, limits, noon)).toEqual({ ok: true });
    expect(checkDaily(state, limits, noon).ok).toBe(false);
    expect(checkDaily(state, limits, noon + 24 * 60 * 60 * 1000)).toEqual({ ok: true });
  });
});
