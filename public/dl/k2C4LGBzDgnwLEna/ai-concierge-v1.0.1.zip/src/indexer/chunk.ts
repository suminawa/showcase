import type { ChunkDraft, DocumentDraft } from "../core/types";

/** 1 片の目安。下限に満たない節は次の見出しと合わせ（題は「先頭の見出し ほか」になる）、上限を超える節は段落で割る */
export const CHUNK_MIN = 600;
export const CHUNK_MAX = 1200;

export interface Section {
  heading: string;
  text: string;
  /**
   * 節を合わせたとき、先頭以外の見出し（表示の題には出さないが、検索では見出しと同じ重みで拾う）。
   * 合わせていない片・見出しが 1 つしか無い片には付かない
   */
  extraHeadings?: string[];
}

export interface DocumentSource {
  id: string;
  title: string;
  url: string | null;
  updatedAt: string | null;
  sections: Section[];
}

/** 概算のトークン数。日本語 1 字 ≈ 1、英数字 4 字 ≈ 1（正確な数は CLI の --count-tokens で） */
export function estimateTokens(text: string): number {
  let ascii = 0;
  let wide = 0;
  for (const char of text) {
    if ((char.codePointAt(0) ?? 0) < 128) ascii += 1;
    else wide += 1;
  }
  return Math.ceil(ascii / 4) + wide;
}

export function breadcrumbOf(title: string, heading: string): string {
  const trimmed = heading.trim();
  return trimmed === "" ? title : `${title} › ${trimmed}`;
}

function joinSection(base: string, heading: string, text: string): string {
  const parts = [base];
  if (heading.trim() !== "") parts.push(heading.trim());
  if (text !== "") parts.push(text);
  return parts.join("\n\n");
}

interface Run {
  /** 本文の組み立てにだけ使う。先頭の見出しを本文へ移したら空にする（2 回移さないため） */
  bodyHeading: string;
  text: string;
  /** この片に入っている見出し（空でないもの）を出た順に並べる。題の組み立てと検索の両方に使う */
  headings: string[];
}

function startRun(section: Section, text: string): Run {
  const heading = section.heading.trim();
  return { bodyHeading: section.heading, text, headings: heading === "" ? [] : [heading] };
}

function finishRun(run: Run): Section {
  const [first, ...rest] = run.headings;
  if (first === undefined) return { heading: "", text: run.text };
  if (rest.length === 0) return { heading: first, text: run.text };
  // 2 つ以上の見出しを合わせた片は、先頭の見出し＋「ほか」を名乗る。出典の題が
  // 先頭の見出しだけだと、後ろの見出しから答えたときに題がずれる（「更新」の答えの
  // 出典が「支払い方法」になる）。残りの見出しは検索でだけ拾えるようにする
  return { heading: `${first} ほか`, text: run.text, extraHeadings: rest };
}

export function mergeSections(sections: Section[]): Section[] {
  const out: Section[] = [];
  let current: Run | null = null;
  for (const section of sections) {
    const text = section.text.trim();
    if (text === "" && section.heading.trim() === "") continue;
    if (current === null) {
      current = startRun(section, text);
      continue;
    }
    if (current.text.length < CHUNK_MIN) {
      // 合わせた片の本文には、先頭の見出しを 1 回だけ移す（3 つ以上合わせても 2 回目以降は移さない）
      const own: string = current.bodyHeading.trim();
      const base: string = own === "" ? current.text : `${own}\n\n${current.text}`;
      const heading = section.heading.trim();
      current = {
        bodyHeading: "",
        text: joinSection(base, section.heading, text),
        headings: heading === "" ? current.headings : [...current.headings, heading],
      };
      continue;
    }
    out.push(finishRun(current));
    current = startRun(section, text);
  }
  if (current !== null) out.push(finishRun(current));
  return out;
}

export function splitLongText(text: string, max: number = CHUNK_MAX): string[] {
  if (text.length <= max) return [text];
  const pieces: string[] = [];
  let current = "";
  for (const paragraph of text.split(/\n{2,}/)) {
    const part = paragraph.trim();
    if (part === "") continue;
    if (part.length > max) {
      if (current !== "") {
        pieces.push(current);
        current = "";
      }
      for (let i = 0; i < part.length; i += max) pieces.push(part.slice(i, i + max));
      continue;
    }
    const next = current === "" ? part : `${current}\n\n${part}`;
    if (next.length > max) {
      pieces.push(current);
      current = part;
    } else {
      current = next;
    }
  }
  if (current !== "") pieces.push(current);
  return pieces;
}

export function chunkDocument(source: DocumentSource): DocumentDraft {
  const chunks: ChunkDraft[] = [];
  let seq = 0;
  for (const section of mergeSections(source.sections)) {
    for (const text of splitLongText(section.text)) {
      seq += 1;
      const draft: ChunkDraft = {
        id: `${source.id}#${seq}`,
        heading: section.heading.trim(),
        breadcrumb: breadcrumbOf(source.title, section.heading),
        text,
        tokens: estimateTokens(text),
      };
      if (section.extraHeadings !== undefined && section.extraHeadings.length > 0) {
        draft.extraHeadings = section.extraHeadings;
      }
      chunks.push(draft);
    }
  }
  return { id: source.id, title: source.title, url: source.url, updatedAt: source.updatedAt, chunks };
}
