import { describe, expect, it } from "vitest";
import { breadcrumbOf, CHUNK_MAX, CHUNK_MIN, chunkDocument, estimateTokens, mergeSections, splitLongText } from "./chunk";

describe("estimateTokens", () => {
  it("日本語は 1 字 1 トークン、英数字は 4 字 1 トークン", () => {
    // 「料金は 100 万円です」= 英数字と空白が 5 字（空白 2 + 数字 3）→ ceil(5 / 4) = 2、
    // 日本語が 7 字（料金は・万円です）→ 7。合わせて 9
    expect(estimateTokens("料金は 100 万円です")).toBe(9);
    expect(estimateTokens("")).toBe(0);
    expect(estimateTokens("abcd")).toBe(1);
    expect(estimateTokens("abcde")).toBe(2);
    expect(estimateTokens("あ".repeat(700))).toBe(700);
  });
});

describe("breadcrumbOf", () => {
  it("題名と見出しを › でつなぐ", () => {
    expect(breadcrumbOf("会社案内", "対応エリア")).toBe("会社案内 › 対応エリア");
  });

  it("見出しが無ければ題名だけ", () => {
    expect(breadcrumbOf("会社案内", "")).toBe("会社案内");
    expect(breadcrumbOf("会社案内", "   ")).toBe("会社案内");
  });
});

describe("mergeSections", () => {
  it("600 字に満たない節は、次の見出しと合わせる", () => {
    const a = "あ".repeat(100);
    const b = "い".repeat(700);
    const c = "う".repeat(700);
    const merged = mergeSections([
      { heading: "あいさつ", text: a },
      { heading: "料金", text: b },
      { heading: "工事の流れ", text: c },
    ]);
    // 100 + "\n\n"(2) + "料金"(2) + "\n\n"(2) + 700 = 806 字。806 >= 600 なのでここで閉じる
    expect(merged).toHaveLength(2);
    // 合わせた片は、先頭の節の見出し＋「ほか」を名乗る（出典の題が「あいさつ」だけだと、
    // 料金の答えの出典としてずれる）。合わせた見出し（料金）は検索でだけ拾えるようにする。
    // 見出しは本文の頭へも移す: "あいさつ"(4) + "\n\n"(2) + 806 = 812 字
    expect(merged[0].heading).toBe("あいさつ ほか");
    expect(merged[0].extraHeadings).toEqual(["料金"]);
    expect(merged[0].text.startsWith("あいさつ\n\n")).toBe(true);
    expect(merged[0].text.length).toBe(812);
    expect(merged[0].text).toContain("\n\n料金\n\n");
    expect(merged[1]).toEqual({ heading: "工事の流れ", text: c });
  });

  it("3 つ以上を合わせても、先頭の見出しを本文へ移すのは 1 回だけ", () => {
    const merged = mergeSections([
      { heading: "支払い", text: "あ".repeat(100) },
      { heading: "更新", text: "い".repeat(100) },
      { heading: "返金", text: "う".repeat(700) },
    ]);
    expect(merged).toHaveLength(1);
    expect(merged[0].heading).toBe("支払い ほか");
    expect(merged[0].extraHeadings).toEqual(["更新", "返金"]);
    expect(merged[0].text.match(/支払い/g)).toHaveLength(1);
    expect(merged[0].text).toContain("\n\n更新\n\n");
    expect(merged[0].text).toContain("\n\n返金\n\n");
  });

  it("見出しのない前書きに次の節を合わせても、本文の頭に空行を作らない", () => {
    const merged = mergeSections([
      { heading: "", text: "前書き" },
      { heading: "料金", text: "あ".repeat(700) },
    ]);
    expect(merged).toHaveLength(1);
    // 実際に付いている見出しが「料金」だけなので、「ほか」は付けず、そのまま名乗る
    expect(merged[0].heading).toBe("料金");
    expect(merged[0].extraHeadings).toBeUndefined();
    expect(merged[0].text.startsWith("前書き\n\n料金\n\n")).toBe(true);
  });

  it("合わせて 1 片になっても、見出しが 1 つしか無ければ「ほか」は付けない", () => {
    const merged = mergeSections([
      { heading: "工期", text: "あ".repeat(100) },
      { heading: "", text: "い".repeat(700) },
    ]);
    expect(merged).toHaveLength(1);
    expect(merged[0].heading).toBe("工期");
    expect(merged[0].extraHeadings).toBeUndefined();
  });

  it("十分な長さの節はそのまま", () => {
    const a = "あ".repeat(700);
    const b = "い".repeat(700);
    expect(mergeSections([{ heading: "料金", text: a }, { heading: "保証", text: b }])).toEqual([
      { heading: "料金", text: a },
      { heading: "保証", text: b },
    ]);
  });

  it("最後の節は短くてもそのまま残す（合わせる先が無い）", () => {
    const a = "あ".repeat(700);
    const b = "い".repeat(50);
    const merged = mergeSections([{ heading: "料金", text: a }, { heading: "備考", text: b }]);
    expect(merged).toHaveLength(2);
    expect(merged[1]).toEqual({ heading: "備考", text: b });
  });

  it("空の節は落とす", () => {
    expect(mergeSections([{ heading: "", text: "   " }, { heading: "料金", text: "あ".repeat(700) }])).toEqual([
      { heading: "料金", text: "あ".repeat(700) },
    ]);
  });
});

describe("splitLongText", () => {
  it("1,200 字以内ならそのまま", () => {
    const text = "あ".repeat(CHUNK_MAX);
    expect(splitLongText(text)).toEqual([text]);
  });

  it("段落の切れ目で割る", () => {
    const p1 = "あ".repeat(500);
    const p2 = "い".repeat(500);
    const p3 = "う".repeat(500);
    const pieces = splitLongText([p1, p2, p3].join("\n\n"));
    // p1 + "\n\n" + p2 = 1002 字。p3 を足すと 1504 字で 1,200 を超えるのでここで割る
    expect(pieces.map((piece) => piece.length)).toEqual([1002, 500]);
    expect(pieces[0]).toBe(`${p1}\n\n${p2}`);
    expect(pieces[1]).toBe(p3);
  });

  it("1 段落が長すぎるときは字数で割る", () => {
    expect(splitLongText("あ".repeat(2500)).map((piece) => piece.length)).toEqual([1200, 1200, 100]);
  });

  it("上限を渡せる", () => {
    expect(splitLongText("あ".repeat(10), 4).map((piece) => piece.length)).toEqual([4, 4, 2]);
  });
});

describe("chunkDocument", () => {
  it("片に id・見出し・パンくず・概算トークンを付ける", () => {
    const doc = chunkDocument({
      id: "kaisha",
      title: "会社案内",
      url: "https://example.com/about",
      updatedAt: "2026-09-01",
      sections: [
        { heading: "", text: "あ".repeat(700) },
        { heading: "対応エリア", text: "い".repeat(700) },
      ],
    });
    expect(doc.id).toBe("kaisha");
    expect(doc.title).toBe("会社案内");
    expect(doc.url).toBe("https://example.com/about");
    expect(doc.updatedAt).toBe("2026-09-01");
    expect(doc.chunks).toHaveLength(2);
    expect(doc.chunks[0]).toEqual({
      id: "kaisha#1",
      heading: "",
      breadcrumb: "会社案内",
      text: "あ".repeat(700),
      tokens: 700,
    });
    expect(doc.chunks[1]).toEqual({
      id: "kaisha#2",
      heading: "対応エリア",
      breadcrumb: "会社案内 › 対応エリア",
      text: "い".repeat(700),
      tokens: 700,
    });
  });

  it("長い節は割られ、番号が続く", () => {
    const doc = chunkDocument({
      id: "price",
      title: "料金",
      url: null,
      updatedAt: null,
      sections: [{ heading: "内訳", text: "あ".repeat(2500) }],
    });
    expect(doc.chunks.map((chunk) => chunk.id)).toEqual(["price#1", "price#2", "price#3"]);
    expect(doc.chunks.every((chunk) => chunk.breadcrumb === "料金 › 内訳")).toBe(true);
    expect(doc.chunks.map((chunk) => chunk.text.length)).toEqual([1200, 1200, 100]);
  });

  it("CHUNK_MIN と CHUNK_MAX は設計どおり", () => {
    expect(CHUNK_MIN).toBe(600);
    expect(CHUNK_MAX).toBe(1200);
  });

  it("節を合わせた片は「先頭の見出し ほか」を名乗り、合わせた見出しは片に残る（検索で拾うため）", () => {
    const doc = chunkDocument({
      id: "faq",
      title: "よくあるご質問",
      url: null,
      updatedAt: null,
      sections: [
        { heading: "支払い方法", text: "あ".repeat(100) },
        { heading: "更新", text: "い".repeat(700) },
      ],
    });
    expect(doc.chunks).toHaveLength(1);
    expect(doc.chunks[0].heading).toBe("支払い方法 ほか");
    expect(doc.chunks[0].breadcrumb).toBe("よくあるご質問 › 支払い方法 ほか");
    expect(doc.chunks[0].extraHeadings).toEqual(["更新"]);
    // 合わせた見出し（更新）は本文にも残るので、答えの根拠には引き続き出せる
    expect(doc.chunks[0].text).toContain("更新");
  });

  it("合わせていない片（見出しが 1 つだけの片）には extraHeadings が付かない", () => {
    const doc = chunkDocument({
      id: "kaisha",
      title: "会社案内",
      url: null,
      updatedAt: null,
      sections: [{ heading: "対応エリア", text: "あ".repeat(700) }],
    });
    expect(doc.chunks[0].heading).toBe("対応エリア");
    expect(doc.chunks[0].extraHeadings).toBeUndefined();
  });
});
