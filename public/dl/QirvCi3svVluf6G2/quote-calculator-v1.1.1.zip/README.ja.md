# 見積もり電卓テンプレ v1.1.1

自分のサイトに置ける見積もり電卓です。時間単価・一式・明細・税込からの逆算の 4 通りで見積もりを作り、内訳と合計をその場で出します。内訳は 1 押しでコピーでき、印刷から PDF の見積書にもできます。

## 何ができるか
- **税込から逆算**: 「税込 11 万でお願いします」と言われたときに、税抜と消費税を出します。合計は入力した税込額と 1 円もずれません
- **税率 10% / 8% の切替**: 軽減税率の品目や、税率を変えた比較に使えます
- **源泉徴収**: 原稿料・デザイン料・講演料のように源泉徴収がある仕事で、振込額（差引お支払額）を先に出します。100 万円を超えた分は 20.42% で計算します
- **値引き**: 円でも % でも入れられて、内訳に 1 行で載ります
- **明細**: 「LP 1 式 + 撮影 2 回 + 修正 3 回」のように、項目 × 数量 × 単価で積み上げられます
- **印刷用の見積書**: 宛名と件名を入れて印刷すると、A4 1 枚の見積書になります（ブラウザの印刷画面から PDF 保存）
- **内訳のコピー**: Slack・メール・チャットにそのまま貼れる文章になります
- **この内容で問い合わせる**: サイトに置いたとき、訪問者が概算を添えてメールを送れます

デモ: suminawa.dev/projects/quote-simulator（無料デモは基本の計算だけです。上の 8 つはこのテンプレに入っています）

## コピペで置く
```html
<link rel="stylesheet" href="./quote-calculator.css">
<div id="quote"></div>
<script src="./quote-calculator.global.js"></script>
<script>QuoteCalculator.mount(document.getElementById("quote"));</script>
```

zip の `embed/` フォルダに、上のコード（`embed-snippet.html`）と `quote-calculator.global.js`・`quote-calculator.css`、iframe 用の `standalone.html` が入っています。上のコードは同じ階層のファイルを読むので、JS と CSS はまとめて置いてください。静的 HTML・Webflow など、script タグが書ける場所ならそのまま動きます。

### WordPress に置く
1. `quote-calculator.global.js` と `quote-calculator.css` を、FTP かレンタルサーバーのファイルマネージャーで `wp-content/uploads/quote-calculator/` などに置きます（メディアライブラリは既定で .js と .css を受け付けません）
2. 固定ページや投稿の編集画面で「カスタム HTML」ブロックを足し、上のコードを貼ります。2 つのファイルの場所は `https://あなたのサイト/wp-content/uploads/quote-calculator/quote-calculator.css` のように `https://` から書きます
3. 管理者のアカウントで保存します（編集者などの権限では script タグが消えることがあります）

テーマの CSS（箇条書きの点・見出しの帯・入力欄の枠など）は、電卓の中では外れるようにしてあります。それでも崩れるときは、次の iframe の置き方を使ってください。

### STUDIO・Wix・ペライチに置く（iframe）
JS ファイルを置けないサイトでは、`embed/` の `standalone.html`・`quote-calculator.global.js`・`quote-calculator.css` の 3 つを、自社のサーバーなど公開できる場所に同じフォルダで置き、サイトの「埋め込み」や「HTML」の部品に次の 1 行を貼ります。設定は `standalone.html` の中の `mount(…)` に書きます。
```html
<iframe src="https://example.com/quote-calculator/standalone.html" title="お見積もり" style="width:100%;height:1700px;border:0"></iframe>
```
高さは、スマホで全部が収まる 1,700px 前後が目安です（PC だけなら 1,300px 前後）。

### 更新を受け取る
1.x の更新は無料です。新しい zip の `embed/` から `quote-calculator.global.js` と `quote-calculator.css` の 2 ファイルを取り出して、置いてあるものと差し替えてください。設定を書いた HTML（貼ったコードや `standalone.html`）はそのまま使えます。

## 設定を変える
`mount(要素, 設定)` の第 2 引数に、変えたい項目だけ渡します。

| 項目 | 既定値 | 意味 |
|---|---|---|
| `currency.symbol` / `currency.locale` | `"¥"` / `"ja-JP"` | 通貨記号と桁区切り |
| `hoursPerDay` | `8` | 「日」で入力したときの換算 |
| `tax.rate` / `tax.label` | `0.1` / `"消費税"` | 税率と表示名。画面には率を添えて「消費税（10%）」と出ます |
| `tax.choices` | 10% と 8%（軽減税率） | 税率の選択肢。1 つだけにすると切替を出しません。`tax.rate` はこの中のどれかにします |
| `tax.rounding` | `"floor"` | 税額の丸め: `floor` 切り捨て / `round` 四捨五入 / `ceil` 切り上げ |
| `tax.defaultIncluded` | `true` | 最初から税込で表示するか |
| `withholding.show` | `true` | 「源泉徴収あり」のチェックを出すか |
| `withholding.rate` / `highRate` / `threshold` | `0.1021` / `0.2042` / `1000000` | 源泉徴収の率と、率が変わる境目 |
| `discount.show` | `true` | 値引きの欄を出すか |
| `defaults` | 時間単価 5,000 円・10 時間・一式 300,000 円 | 初期値 |
| `defaults.mode` | `"hourly"` | 単価方式の初期値: `"hourly"` 時間単価 / `"fixed"` 固定単価 / `"items"` 明細 / `"reverse"` 税込から逆算 |
| `defaults.effortUnit` | `"hours"` | 工数の単位の初期値: `"hours"` 時間 / `"days"` 日 |
| `defaults.items` | デザイン 1 × 50,000 円 | 明細の初期値。配列ごと差し替え |
| `defaults.taxIncludedPrice` | `110000` | 逆算の税込金額の初期値 |
| `defaults.subject` | `"お見積もり"` | 見積書の件名の初期値 |
| `sheet.show` | `true` | 見積書の欄を出すか |
| `sheet.issuer` | 空 | 見積書に出す発行者（`name` / `address` / `email`）。空の項目はその行ごと出ません |
| `sheet.validDays` | `30` | 有効期限 = 発行日 + この日数 |
| `sheet.notes` | 空 | 見積書の備考。空なら出ません |
| `contact.email` / `contact.subject` | 空 / `"見積もりの相談"` | 「この内容で問い合わせる」の宛先と件名。`email` が空ならボタンを出しません |
| `options` | 急ぎ +20% / 修正無制限 +15% / 土日祝 +10% | 追加オプション。配列ごと差し替え |
| `labels.*` | 日本語 | 画面の文言。英語化もここで |

設定を書き換えた例は demo/index.html にあります（デザイナー向けの単価・オプション・発行者・問い合わせ先）。

### 電卓が出ないとき
- 設定の値が正しくないときは、電卓の場所に赤い文で「設定の tax.rate が正しくありません。0 以上 1 未満の小数で書いてください（10% なら 0.1）。いまの値: 10」のように、直す項目と書き方が出ます。その項目を直して、ページを読み込み直してください
- 何も出ないときは、設定の書き方そのもの（`,` の付け忘れ、`"` の閉じ忘れ、`{ }` の数）か、JS・CSS の場所の書き間違いが考えられます。ブラウザの開発者ツールの Console に、何行目が読めないかが出ます

## 見積書と問い合わせ
「宛名」と「件名」を入れて **見積書を印刷（PDF 保存）** を押すと、別のタブに A4 1 枚の見積書が開いて印刷画面が出ます。そこで「PDF に保存」を選べば、そのまま送れる見積書になります。

発行者（名前・住所・メール）は `sheet.issuer` に書きます。空にした項目はその行ごと出ません。有効期限は発行日 + `sheet.validDays`（既定 30 日）、備考は `sheet.notes` です。ポップアップを塞ぐ設定のブラウザでは別タブが開けないので、「ポップアップを許可してください」と出ます。

**この内容で問い合わせる** は `contact.email` を書いたときだけ出ます。押すとメールソフトが開き、本文に内訳がそのまま入ります。書いていなければボタンは出ません。

**内訳をコピー** は内訳の文章をクリップボードに入れます。`https` でないページなど、ブラウザがクリップボードを使わせない場合は、選択済みの入力欄が下に出るので、そこから複製してください。

## React で使う
```tsx
import { QuoteCalculator } from "@suminawa/quote-calculator/react";
import "@suminawa/quote-calculator/styles.css";
const config = { defaults: { hourlyRate: 6000 } }; // コンポーネントの外か useMemo で
<QuoteCalculator config={config} onChange={(input, breakdown) => console.log(breakdown.payable)} />
```
このパッケージは npm に公開していません。zip を展開したフォルダを `npm install ./quote-calculator` のようにパスで指定して入れてください。

`config` は参照が変わるたびに電卓を作り直すので、定数か `useMemo` で渡します。開発中の StrictMode では初回の onChange が 2 回呼ばれますが、これは React の仕様で、本番ビルドでは 1 回です。

## 計算の仕様
- 小計 = 時間単価 × 工数（日は `hoursPerDay` 倍）。一式なら一式金額。明細なら行ごとに `数量 × 単価` を四捨五入してから足します
- オプション = 小計 × 率（四捨五入）
- 値引き = 円ならその額（小計 + オプションが上限）、% なら（小計 + オプション）× 率（100% が上限）
- 税抜合計 = 小計 + オプション − 値引き
- 税 = 税抜合計 × 税率。既定は切り捨て
- 逆算 = 税 =（税込金額 × 税率 ÷（1 + 税率））を丸め、税抜 = 税込金額 − 税。合計は入力した税込金額のままです。オプションと値引きは使いません
- 源泉徴収 = 税抜合計 × 10.21%（1 円未満切り捨て）。100 万円を超える分は 20.42%。消費税を分けて書いているので、税抜が基準です
- 差引お支払額 = 合計（税込）− 源泉徴収
- 負数・空欄は 0 として扱います
- 金額は整数に丸めます。円ならそのまま 1 円単位ですが、ドルやユーロのようにセントのある通貨では小数点以下が四捨五入されます（小数対応は今後のバージョンで）

## 見た目を変える
色と間隔は `.qc { --qc-ink; --qc-muted; --qc-line; --qc-accent; --qc-bg; --qc-gap; --qc-font }` の上書きで変えられます。`--qc-bg` はスマホで画面の下に出る合計の帯の背景で、サイトの背景色に合わせてください（既定は白）。個別の部品を上書きするときは、`.qc .qc-total { font-size: 2.5rem; }` のように `.qc` から書きます（同梱の CSS はテーマに負けないよう、この強さで書いてあります）。同梱の CSS を読み込まずに、`qc-*` クラスへ自分でスタイルを当てても構いません（クラス名の一覧は `styles/quote-calculator.css`）。印刷用の見積書は別タブに開く独立した HTML なので、この CSS の影響を受けません。

## 手元で動かす
zip を展開したフォルダで実行します。
```bash
npm install && npm test && npm run build
```
TypeScript は 5 系が必要です（7 系は tsup の型出力に未対応）。

## ライセンス
全文は LICENSE.md にあります。要約すると、購入したご本人（購入が組織なら、その組織の案件）で自由に使えます。禁止しているのは、このファイル一式の再配布・転売・共有と、同種の商品としての販売です。

## 困ったら
hello@suminawa.dev（購入者の質問には 3 営業日以内に返信します）
