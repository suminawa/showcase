export type PricingMode = "hourly" | "fixed" | "items" | "reverse";
export type EffortUnit = "hours" | "days";
export type TaxRounding = "floor" | "round" | "ceil";

/** 明細の 1 行 */
export type LineItem = { label: string; qty: number; unitPrice: number };
/** 値引きの単位。amount は円、percent は % */
export type DiscountKind = "amount" | "percent";
/** 税率の選択肢。2 つ以上あるとき画面に切替が出る */
export type TaxChoice = { label: string; rate: number };

export type QuoteOptionConfig = {
  id: string;
  label: string;
  /** 小計に対する加算率（0.2 = +20%） */
  rate: number;
};

export type QuoteLabels = {
  mode: string;
  hourly: string;
  fixed: string;
  hourlyRate: string;
  perHour: string;
  effort: string;
  hours: string;
  days: string;
  /** {hoursPerDay} が置換される */
  daysNote: string;
  fixedPrice: string;
  options: string;
  /** {taxLabel} が置換される */
  includeTax: string;
  breakdown: string;
  subtotal: string;
  totalTaxIncluded: string;
  totalTaxExcluded: string;
  // ---- v1.1 ----
  items: string;
  itemLabel: string;
  itemQty: string;
  itemUnitPrice: string;
  itemAmount: string;
  addItem: string;
  removeItem: string;
  reverse: string;
  taxIncludedPrice: string;
  taxExcluded: string;
  discount: string;
  discountAmount: string;
  discountPercent: string;
  taxRate: string;
  withholding: string;
  /** {rate} が置換される（"10.21%"） */
  withholdingRow: string;
  /** {rate}・{threshold}・{highRate} が置換される */
  withholdingRowHigh: string;
  payable: string;
  sheet: string;
  client: string;
  subject: string;
  printSheet: string;
  popupBlocked: string;
  copy: string;
  copied: string;
  contact: string;
  sheetIssueDate: string;
  sheetValidUntil: string;
  sheetNotes: string;
  sheetHonorific: string;
};

export type QuoteConfig = {
  currency: { code: string; locale: string; symbol: string };
  hoursPerDay: number;
  tax: { rate: number; choices: TaxChoice[]; label: string; rounding: TaxRounding; defaultIncluded: boolean };
  /** 源泉徴収。show は画面にチェックを出すかどうかで、計算そのものは input.withholding が決める */
  withholding: { show: boolean; rate: number; highRate: number; threshold: number };
  /** 値引き。show は画面に欄を出すかどうか */
  discount: { show: boolean };
  defaults: {
    mode: PricingMode;
    hourlyRate: number;
    effort: number;
    effortUnit: EffortUnit;
    fixedPrice: number;
    items: LineItem[];
    taxIncludedPrice: number;
    subject: string;
  };
  /** 印刷用の見積書。issuer の空の項目は行ごと出さない */
  sheet: { show: boolean; issuer: { name: string; address: string; email: string }; validDays: number; notes: string };
  /** 「この内容で問い合わせる」の宛先。email が空ならボタンを出さない */
  contact: { email: string; subject: string };
  options: QuoteOptionConfig[];
  labels: QuoteLabels;
};

/** オブジェクトは再帰的に任意、配列は丸ごと置き換え */
export type DeepPartial<T> = {
  [K in keyof T]?: T[K] extends unknown[] ? T[K] : T[K] extends object ? DeepPartial<T[K]> : T[K];
};

/** 既定値を深く凍結する。配列の要素と入れ子のオブジェクトも変更できなくする */
function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const key of Object.keys(value as object)) {
      deepFreeze((value as Record<string, unknown>)[key]);
    }
  }
  return value;
}

export const DEFAULT_CONFIG: QuoteConfig = deepFreeze({
  currency: { code: "JPY", locale: "ja-JP", symbol: "¥" },
  hoursPerDay: 8,
  tax: {
    rate: 0.1,
    choices: [{ label: "10%", rate: 0.1 }, { label: "8%（軽減税率）", rate: 0.08 }],
    label: "消費税",
    rounding: "floor",
    defaultIncluded: true,
  },
  withholding: { show: true, rate: 0.1021, highRate: 0.2042, threshold: 1000000 },
  discount: { show: true },
  defaults: {
    mode: "hourly",
    hourlyRate: 5000,
    effort: 10,
    effortUnit: "hours",
    fixedPrice: 300000,
    items: [{ label: "デザイン", qty: 1, unitPrice: 50000 }],
    taxIncludedPrice: 110000,
    subject: "お見積もり",
  },
  sheet: { show: true, issuer: { name: "", address: "", email: "" }, validDays: 30, notes: "" },
  contact: { email: "", subject: "見積もりの相談" },
  options: [
    { id: "rush", label: "急ぎ対応", rate: 0.2 },
    { id: "unlimited-revisions", label: "修正回数無制限", rate: 0.15 },
    { id: "weekend", label: "土日祝対応", rate: 0.1 },
  ],
  labels: {
    mode: "単価方式",
    hourly: "時間単価",
    fixed: "固定単価",
    hourlyRate: "時間単価",
    perHour: "円 / 時",
    effort: "想定工数",
    hours: "時間",
    days: "日",
    daysNote: "1 日 = {hoursPerDay} 時間で換算します",
    fixedPrice: "一式金額",
    options: "追加オプション",
    includeTax: "{taxLabel}を含める",
    breakdown: "内訳",
    subtotal: "小計",
    totalTaxIncluded: "合計（税込）",
    totalTaxExcluded: "合計（税抜）",
    items: "明細",
    itemLabel: "項目",
    itemQty: "数量",
    itemUnitPrice: "単価",
    itemAmount: "金額",
    addItem: "行を足す",
    removeItem: "消す",
    reverse: "税込から逆算",
    taxIncludedPrice: "税込金額",
    taxExcluded: "税抜金額",
    discount: "値引き",
    discountAmount: "円",
    discountPercent: "%",
    taxRate: "税率",
    withholding: "源泉徴収あり",
    withholdingRow: "源泉徴収（{rate}）",
    withholdingRowHigh: "源泉徴収（{rate}、{threshold} を超える分は {highRate}）",
    payable: "差引お支払額",
    sheet: "見積書",
    client: "宛名",
    subject: "件名",
    printSheet: "見積書を印刷（PDF 保存）",
    popupBlocked: "ポップアップを許可してください",
    copy: "内訳をコピー",
    copied: "コピーしました",
    contact: "この内容で問い合わせる",
    sheetIssueDate: "発行日",
    sheetValidUntil: "有効期限",
    sheetNotes: "備考",
    sheetHonorific: "御中",
  },
});

/**
 * 設定の誤り。message は画面にそのまま出せる日本語で、path は誤った項目（"tax.rate"・"options[1].id" など）
 */
export class QuoteConfigError extends Error {
  readonly path: string;
  constructor(message: string, path = "") {
    super(message);
    this.name = "QuoteConfigError";
    this.path = path;
  }
}

/** 「設定の tax.rate が正しくありません。〜。いまの値: 10」 */
function fail(path: string, rule: string, got: unknown): QuoteConfigError {
  const shown = typeof got === "string" || (typeof got === "object" && got !== null) ? JSON.stringify(got) : String(got);
  return new QuoteConfigError(`設定の ${path} が正しくありません。${rule}。いまの値: ${shown}`, path);
}

const PRICING_MODES: readonly PricingMode[] = ["hourly", "fixed", "items", "reverse"];
const EFFORT_UNITS: readonly EffortUnit[] = ["hours", "days"];
const TAX_ROUNDINGS: readonly TaxRounding[] = ["floor", "round", "ceil"];

/** 浮動小数で書いた税率（0.1 と 0.1 + 1e-12）を同じものとみなす幅 */
export const RATE_EPSILON = 1e-9;

export function resolveConfig(partial: DeepPartial<QuoteConfig> = {}): QuoteConfig {
  const mergedDefaults = { ...DEFAULT_CONFIG.defaults, ...partial.defaults };
  const rawItems = mergedDefaults.items;
  // フォームや JSON 設定から文字列で来ても計算できるよう、ここで数値に変換しておく
  const defaults = {
    ...mergedDefaults,
    hourlyRate: Number(mergedDefaults.hourlyRate),
    effort: Number(mergedDefaults.effort),
    fixedPrice: Number(mergedDefaults.fixedPrice),
    taxIncludedPrice: Number(mergedDefaults.taxIncludedPrice),
    // 凍結された既定値を共有しないよう、行ごと複製する。JSON 設定は型がずれて来ることがあるので、
    // ここでフィールドごと変換しておく（変換できない数値は validate() が拾う）
    items: Array.isArray(rawItems)
      ? rawItems.map((item) => ({
          label: String(item.label ?? ""),
          qty: Number(item.qty),
          unitPrice: Number(item.unitPrice),
        }))
      : rawItems,
  };
  // 配列でない値が来ても validate() が拾えるよう、ここでは検証前に .map しない
  const rawOptions = partial.options ?? DEFAULT_CONFIG.options;
  const rawChoices = partial.tax?.choices ?? DEFAULT_CONFIG.tax.choices;
  const config: QuoteConfig = {
    currency: { ...DEFAULT_CONFIG.currency, ...partial.currency },
    hoursPerDay: partial.hoursPerDay ?? DEFAULT_CONFIG.hoursPerDay,
    tax: {
      ...DEFAULT_CONFIG.tax,
      ...partial.tax,
      choices: Array.isArray(rawChoices) ? rawChoices.map((choice) => ({ ...choice })) : rawChoices,
    },
    withholding: { ...DEFAULT_CONFIG.withholding, ...partial.withholding },
    discount: { ...DEFAULT_CONFIG.discount, ...partial.discount },
    defaults,
    sheet: {
      ...DEFAULT_CONFIG.sheet,
      ...partial.sheet,
      issuer: { ...DEFAULT_CONFIG.sheet.issuer, ...partial.sheet?.issuer },
    },
    contact: { ...DEFAULT_CONFIG.contact, ...partial.contact },
    options: Array.isArray(rawOptions) ? rawOptions.map((o) => ({ ...o })) : rawOptions,
    labels: { ...DEFAULT_CONFIG.labels, ...partial.labels },
  };
  validate(config);
  return config;
}

function validate(c: QuoteConfig): void {
  const rate = (example: string) => `0 以上 1 未満の小数で書いてください（${example}）`;
  const finite = "数で書いてください";
  const oneOf = (list: readonly string[]) => `${list.join("・")} のどれかにしてください`;
  const isRate = (n: number) => n >= 0 && n < 1;

  if (!(c.hoursPerDay > 0)) throw fail("hoursPerDay", "0 より大きい数にしてください（例: 8）", c.hoursPerDay);
  if (!isRate(c.tax.rate)) throw fail("tax.rate", rate("10% なら 0.1"), c.tax.rate);
  if (!TAX_ROUNDINGS.includes(c.tax.rounding)) throw fail("tax.rounding", oneOf(TAX_ROUNDINGS), c.tax.rounding);
  if (!Array.isArray(c.tax.choices) || c.tax.choices.length === 0) {
    throw fail("tax.choices", "選択肢を 1 つ以上、[ ] の中に並べてください", c.tax.choices);
  }
  c.tax.choices.forEach((choice, i) => {
    if (!isRate(choice.rate)) throw fail(`tax.choices[${i}].rate`, rate("8% なら 0.08"), choice.rate);
  });
  if (!c.tax.choices.some((choice) => Math.abs(choice.rate - c.tax.rate) < RATE_EPSILON)) {
    const rates = c.tax.choices.map((choice) => choice.rate).join("、");
    throw fail("tax.rate", `tax.choices の率（${rates}）のどれかと同じ値にしてください`, c.tax.rate);
  }
  if (!isRate(c.withholding.rate)) throw fail("withholding.rate", rate("10.21% なら 0.1021"), c.withholding.rate);
  if (!isRate(c.withholding.highRate)) {
    throw fail("withholding.highRate", rate("20.42% なら 0.2042"), c.withholding.highRate);
  }
  if (!(c.withholding.threshold >= 0)) {
    throw fail("withholding.threshold", "0 以上の金額にしてください（例: 1000000）", c.withholding.threshold);
  }
  if (!(c.sheet.validDays >= 0)) throw fail("sheet.validDays", "0 以上の日数にしてください（例: 30）", c.sheet.validDays);
  if (!PRICING_MODES.includes(c.defaults.mode)) throw fail("defaults.mode", oneOf(PRICING_MODES), c.defaults.mode);
  if (!EFFORT_UNITS.includes(c.defaults.effortUnit)) {
    throw fail("defaults.effortUnit", oneOf(EFFORT_UNITS), c.defaults.effortUnit);
  }
  for (const key of ["hourlyRate", "effort", "fixedPrice", "taxIncludedPrice"] as const) {
    if (!Number.isFinite(c.defaults[key])) throw fail(`defaults.${key}`, finite, c.defaults[key]);
  }
  if (!Array.isArray(c.defaults.items)) {
    throw fail("defaults.items", "明細の行を [ ] の中に並べてください", c.defaults.items);
  }
  c.defaults.items.forEach((item, i) => {
    if (!Number.isFinite(item.qty)) throw fail(`defaults.items[${i}].qty`, finite, item.qty);
    if (!Number.isFinite(item.unitPrice)) throw fail(`defaults.items[${i}].unitPrice`, finite, item.unitPrice);
  });
  if (!Array.isArray(c.options)) throw fail("options", "オプションを [ ] の中に並べてください", c.options);
  const ids = new Set<string>();
  c.options.forEach((option, i) => {
    if (!option.id) throw fail(`options[${i}].id`, "空にはできません。英数字の名前を付けてください", option.id);
    if (ids.has(option.id)) throw fail(`options[${i}].id`, "ほかのオプションと同じです。別の名前にしてください", option.id);
    ids.add(option.id);
    if (!Number.isFinite(option.rate) || option.rate < 0) {
      throw fail(`options[${i}].rate`, "0 以上の小数で書いてください（+20% なら 0.2）", option.rate);
    }
  });
}
