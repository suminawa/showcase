/// <reference types="vite/client" />
import { describe, expect, it } from "vitest";
import css from "../styles/quote-calculator.css?raw";

/** コメントと @media の行を除いた、各ルールのセレクタ（カンマで分けたもの） */
function selectors(source: string): string[] {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .split("}")
    .map((chunk) => chunk.split("{").slice(-2, -1)[0] ?? "")
    // :is(a, b) の中のカンマでは分けない
    .flatMap((head) => head.split(/,(?![^(]*\))/))
    .map((s) => s.trim())
    .filter((s) => s !== "" && !s.startsWith("@"));
}

describe("styles/quote-calculator.css", () => {
  it("すべてのセレクタが .qc の中に閉じていて、単一クラスのまま（テーマに負ける詳細度）のものが無い", () => {
    const list = selectors(css);
    expect(list.length).toBeGreaterThan(30);
    for (const selector of list) {
      expect(selector, selector).toMatch(/^\.qc(\s|$|\[|:|\.)/);
      expect(selector, selector).not.toMatch(/^\.qc-[\w-]+$/);
    }
  });

  it("テーマの ul・h2・label・input・button の装飾を .qc の中で外す", () => {
    const reset = css.match(/\.qc :is\(([^)]*)\)\s*\{\s*all: revert;/);
    const tags = reset?.[1].split(",").map((tag) => tag.trim());
    expect(tags).toEqual(expect.arrayContaining(["ul", "li", "h2", "label", "input", "button"]));
  });
});
