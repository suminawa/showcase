import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "jsdom",
    include: ["src/**/*.test.{ts,tsx}"],
    // styles.test.ts が CSS を文字列（?raw）で読む。既定では CSS の中身が空になる
    css: { include: [/quote-calculator\.css/] },
  },
});
