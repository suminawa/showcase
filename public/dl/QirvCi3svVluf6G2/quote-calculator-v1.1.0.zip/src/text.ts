import type { QuoteConfig } from "./config";
import { formatMoney, formatPercent, labelWithRate } from "./format";
import { isTaxOn, lineItemAmount, sanitizeAmount, type QuoteBreakdown, type QuoteInput } from "./quote";

/** U+2212。ハイフンだと金額の横で見分けがつかない */
const MINUS = "−";

/**
 * 源泉徴収の行ラベル。税抜合計が withholding.threshold を超えたら、超過分の税率も添えた文言にする。
 * quoteText・quoteSheetHtml・mount の内訳表示はすべてここを通す（ラベルの組み立てを 1 か所にする）。
 */
export function withholdingRowLabel(breakdown: QuoteBreakdown, config: QuoteConfig): string {
  if (breakdown.taxableTotal > config.withholding.threshold) {
    return config.labels.withholdingRowHigh
      .replace("{rate}", formatPercent(config.withholding.rate))
      .replace("{threshold}", formatMoney(config.withholding.threshold, config.currency))
      .replace("{highRate}", formatPercent(config.withholding.highRate));
  }
  return config.labels.withholdingRow.replace("{rate}", formatPercent(config.withholding.rate));
}

/**
 * Slack・メール・チャットにそのまま貼れる内訳。1 行 1 項目。
 * 無い行（値引き 0・税なし・源泉なし）は出さない。
 */
export function quoteText(input: QuoteInput, breakdown: QuoteBreakdown, config: QuoteConfig): string {
  const money = (amount: number) => formatMoney(amount, config.currency);
  const taxOn = isTaxOn(input);
  const lines: string[] = [input.sheet.subject.trim() || config.labels.sheet];

  if (input.mode === "hourly") {
    const unit = input.effortUnit === "days" ? config.labels.days : config.labels.hours;
    lines.push(`${config.labels.hourlyRate} ${money(sanitizeAmount(input.hourlyRate))} × ${sanitizeAmount(input.effort)} ${unit}`);
  }
  if (input.mode === "items") {
    for (const item of input.items) {
      const label = item.label.trim() || config.labels.itemLabel;
      lines.push(`${label} × ${sanitizeAmount(item.qty)} = ${money(lineItemAmount(item))}`);
    }
  }

  if (input.mode === "reverse") {
    // 税抜金額が小計そのものなので、小計の行は出さない
    lines.push(`${config.labels.taxIncludedPrice} ${money(breakdown.total)}`);
    lines.push(`${config.labels.taxExcluded} ${money(breakdown.taxableTotal)}`);
  } else {
    lines.push(`${config.labels.subtotal}: ${money(breakdown.subtotal)}`);
    for (const line of breakdown.optionLines) lines.push(`${line.label}: +${money(line.amount)}`);
    if (breakdown.discount > 0) lines.push(`${config.labels.discount}: ${MINUS}${money(breakdown.discount)}`);
  }

  if (taxOn) lines.push(`${labelWithRate(config.tax.label, breakdown.taxRate)}: ${money(breakdown.tax)}`);
  const totalLabel = taxOn ? config.labels.totalTaxIncluded : config.labels.totalTaxExcluded;
  lines.push(`${totalLabel}: ${money(breakdown.total)}`);

  if (breakdown.withholding > 0) {
    lines.push(`${withholdingRowLabel(breakdown, config)}: ${MINUS}${money(breakdown.withholding)}`);
    lines.push(`${config.labels.payable}: ${money(breakdown.payable)}`);
  }

  return lines.join("\n");
}

/** 「この内容で問い合わせる」のリンク先。contact.email が空のときは呼び出し側がボタンを出さない */
export function mailtoHref(text: string, config: QuoteConfig): string {
  const subject = encodeURIComponent(config.contact.subject);
  return `mailto:${config.contact.email}?subject=${subject}&body=${encodeURIComponent(text)}`;
}
