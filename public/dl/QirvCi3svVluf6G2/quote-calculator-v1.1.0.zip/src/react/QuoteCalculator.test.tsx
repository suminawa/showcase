import { act } from "react";
import { createRoot } from "react-dom/client";
import { describe, expect, it, vi } from "vitest";
import { QuoteCalculator } from "./QuoteCalculator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

describe("QuoteCalculator (React)", () => {
  it("マウントすると電卓が描画され、初期値で onChange が呼ばれ、unmount で消える", async () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const onChange = vi.fn();

    await act(async () => {
      root.render(<QuoteCalculator onChange={onChange} className="mine" />);
    });
    expect(container.querySelector(".qc-form")).not.toBeNull();
    expect(container.querySelector(".mine.qc")).not.toBeNull();
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange.mock.calls[0][1].total).toBe(55000);

    await act(async () => {
      root.unmount();
    });
    expect(container.querySelector(".qc-form")).toBeNull();
  });

  it("config を渡すと反映される", async () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    await act(async () => {
      root.render(<QuoteCalculator config={{ defaults: { hourlyRate: 1000, effort: 1 }, tax: { defaultIncluded: false } }} />);
    });
    expect(container.querySelector(".qc-total")?.textContent).toBe("¥1,000");
    await act(async () => {
      root.unmount();
    });
  });
});
