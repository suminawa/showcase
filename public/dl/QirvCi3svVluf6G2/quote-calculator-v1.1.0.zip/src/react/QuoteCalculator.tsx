import { useEffect, useRef } from "react";
import type { DeepPartial, QuoteConfig } from "../config";
import type { QuoteBreakdown, QuoteInput } from "../quote";
import { mountQuoteCalculator } from "../vanilla/mount";

export type QuoteCalculatorProps = {
  /** 参照が変わると作り直す。useMemo か定数で渡すこと */
  config?: DeepPartial<QuoteConfig>;
  onChange?: (input: QuoteInput, breakdown: QuoteBreakdown) => void;
  className?: string;
};

/** vanilla の mount を ref に当てるだけの薄いラッパー。描画は vanilla/mount.ts が持つ */
export function QuoteCalculator({ config, onChange, className }: QuoteCalculatorProps) {
  const ref = useRef<HTMLDivElement>(null);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const handle = mountQuoteCalculator(root, config);
    const unsubscribe = handle.subscribe((input, breakdown) => onChangeRef.current?.(input, breakdown));
    onChangeRef.current?.(handle.getInput(), handle.getBreakdown());
    return () => {
      unsubscribe();
      handle.destroy();
    };
  }, [config]);

  return <div ref={ref} className={className} />;
}
