import { describe, expect, it, vi } from "vitest";
import { resolveConfig } from "./config";
import { calculateQuote, initialInput, type QuoteInput } from "./quote";
import { escapeHtml, openQuoteSheet, quoteSheetHtml } from "./sheet";

const config = resolveConfig();
const ISSUED_ON = new Date(2026, 8, 11); // 2026-09-11

function htmlOf(patch: Partial<QuoteInput>, c = config, issuedOn = ISSUED_ON) {
  const input: QuoteInput = { ...initialInput(c), mode: "fixed", fixedPrice: 100000, includeTax: true, ...patch };
  return quoteSheetHtml(input, calculateQuote(input, c), c, issuedOn);
}

describe("escapeHtml", () => {
  it("HTML の記号を実体参照にする", () => {
    expect(escapeHtml('<b>"A & B"</b>')).toBe("&lt;b&gt;&quot;A &amp; B&quot;&lt;/b&gt;");
    expect(escapeHtml("it's")).toBe("it&#39;s");
  });
});

describe("quoteSheetHtml", () => {
  it("件名・宛名・発行日・有効期限・合計が入る", () => {
    const html = htmlOf({ sheet: { client: "株式会社れい", subject: "LP 制作のお見積もり" } });
    expect(html).toContain("<h1 class=\"qc-sheet-subject\">LP 制作のお見積もり</h1>");
    expect(html).toContain("株式会社れい 御中");
    expect(html).toContain("<dt>発行日</dt><dd>2026年9月11日</dd>");
    expect(html).toContain("<dt>有効期限</dt><dd>2026年10月11日</dd>");
    expect(html).toContain("<dt>合計（税込）</dt><dd>¥110,000</dd>");
    expect(html).toContain("<dt>消費税（10%）</dt><dd>¥10,000</dd>");
    expect(html.startsWith("<!doctype html>")).toBe(true);
    expect(html).toContain("@page { size: A4; margin: 18mm }");
    expect(html).toContain("@media print");
  });

  it("件名が空なら「見積書」、宛名が空なら宛名の行を出さない", () => {
    const html = htmlOf({ sheet: { client: "", subject: "" } });
    expect(html).toContain("<h1 class=\"qc-sheet-subject\">見積書</h1>");
    expect(html).not.toContain("御中");
  });

  it("< と & はエスケープされる", () => {
    const html = htmlOf({ sheet: { client: "A & <b>B</b>", subject: "<script>x</script>" } });
    expect(html).toContain("A &amp; &lt;b&gt;B&lt;/b&gt;");
    expect(html).toContain("&lt;script&gt;x&lt;/script&gt;");
    expect(html).not.toContain("<script>");
  });

  it("発行者が空なら行が無い。書けば空でない項目だけ出る", () => {
    expect(htmlOf({})).not.toContain("qc-sheet-issuer");
    const c = resolveConfig({ sheet: { issuer: { name: "スタジオ example", email: "hello@example.com" } } });
    const html = htmlOf({}, c);
    expect(html).toContain("qc-sheet-issuer");
    expect(html).toContain("<span>スタジオ example</span>");
    expect(html).toContain("<span>hello@example.com</span>");
    expect(html.match(/<span>/g)!.length).toBe(2);
  });

  it("備考は sheet.notes があるときだけ出る", () => {
    expect(htmlOf({})).not.toContain("qc-sheet-notes");
    const c = resolveConfig({ sheet: { notes: "着手金として半額を前払いでお願いしています。" } });
    expect(htmlOf({}, c)).toContain("備考: 着手金として半額を前払いでお願いしています。");
  });

  it("明細は行ごとに 項目・数量・単価・金額で並ぶ", () => {
    const html = htmlOf({
      mode: "items",
      items: [
        { label: "デザイン", qty: 1, unitPrice: 50000 },
        { label: "撮影", qty: 2, unitPrice: 30000 },
      ],
    });
    expect(html).toContain("<th>項目</th>");
    expect(html).toContain("<th>数量</th>");
    expect(html).toContain("<th>単価</th>");
    expect(html).toContain("<th>金額</th>");
    expect(html).toContain("<td>デザイン</td>");
    expect(html).toContain("<td>撮影</td>");
    expect(html.match(/<tbody>[\s\S]*?<\/tbody>/)![0].match(/<tr>/g)!.length).toBe(2);
  });

  it("hourly / fixed / reverse は明細を 1 行にまとめる", () => {
    const hourly = htmlOf({ mode: "hourly", hourlyRate: 5000, effort: 10, effortUnit: "hours" });
    expect(hourly).toContain("<td>時間単価</td>");
    expect(hourly).toContain("10 時間");
    expect(hourly.match(/<tbody>[\s\S]*?<\/tbody>/)![0].match(/<tr>/g)!.length).toBe(1);

    expect(htmlOf({})).toContain("<td>一式金額</td>");

    const reverse = htmlOf({ mode: "reverse", taxIncludedPrice: 110000 });
    expect(reverse).toContain("<td>税抜金額</td>");
    expect(reverse).toContain("<dt>合計（税込）</dt><dd>¥110,000</dd>");
    // 税抜金額は明細の表にすでに出ているので、内訳側の「小計」は出さない（重複表示の防止）
    expect(reverse).not.toContain("<dt>小計</dt>");
    expect(reverse.match(/税抜金額/g)!.length).toBe(1);
  });

  it("値引きと源泉徴収の行は、あるときだけ − つきで出る", () => {
    const plain = htmlOf({});
    expect(plain).not.toContain("値引き");
    expect(plain).not.toContain("源泉徴収");

    const html = htmlOf({
      selectedOptionIds: ["rush"],
      discount: { kind: "amount", value: 5000 },
      withholding: true,
    });
    expect(html).toContain("<dt>急ぎ対応</dt><dd>+¥20,000</dd>");
    expect(html).toContain('<div class="qc-row-minus"><dt>値引き</dt><dd>−¥5,000</dd></div>');
    expect(html).toContain("<dt>小計</dt><dd>¥115,000</dd>");
    expect(html).toContain('<div class="qc-row-minus"><dt>源泉徴収（10.21%）</dt><dd>−¥11,741</dd></div>');
    expect(html).toContain("<dt>差引お支払額</dt><dd>¥114,759</dd>");
  });

  it("源泉徴収が 100 万円を超えたら、行のラベルに超過分の税率も添える", () => {
    const html = htmlOf({ fixedPrice: 1500000, withholding: true });
    expect(html).toContain(
      '<div class="qc-row-minus"><dt>源泉徴収（10.21%、¥1,000,000 を超える分は 20.42%）</dt><dd>−¥204,200</dd></div>',
    );
    expect(html).toContain("<dt>差引お支払額</dt><dd>¥1,445,800</dd>");
  });

  it(".qc-row-minus は控除だとわかる色で出る", () => {
    expect(htmlOf({})).toContain(".qc-row-minus dd { color: var(--qc-muted) }");
  });

  it("有効期限は sheet.validDays で変わる", () => {
    const c = resolveConfig({ sheet: { validDays: 0 } });
    expect(htmlOf({}, c)).toContain("<dt>有効期限</dt><dd>2026年9月11日</dd>");
  });
});

describe("openQuoteSheet", () => {
  function fakeWindow(readyState: string) {
    const print = vi.fn();
    const written: string[] = [];
    const listeners: (() => void)[] = [];
    const opened = {
      document: {
        open: vi.fn(),
        write: (html: string) => written.push(html),
        close: vi.fn(),
        readyState,
      },
      print,
      addEventListener: (_type: string, fn: () => void) => listeners.push(fn),
    };
    return { opened, print, written, listeners, win: { open: vi.fn(() => opened) } };
  }

  it("新しいタブに書き込んで印刷を呼ぶ", () => {
    const f = fakeWindow("complete");
    const ok = openQuoteSheet("<!doctype html><p>見積書</p>", f.win as unknown as Window);
    expect(ok).toBe(true);
    expect(f.win.open).toHaveBeenCalledWith("", "_blank");
    expect(f.written.join("")).toContain("見積書");
    expect(f.print).toHaveBeenCalledTimes(1);
  });

  it("まだ読み込み中なら load のあとに印刷する", () => {
    const f = fakeWindow("loading");
    expect(openQuoteSheet("<p>x</p>", f.win as unknown as Window)).toBe(true);
    expect(f.print).not.toHaveBeenCalled();
    f.listeners.forEach((fn) => fn());
    expect(f.print).toHaveBeenCalledTimes(1);
  });

  it("ポップアップが塞がれていたら false", () => {
    const win = { open: vi.fn(() => null) };
    expect(openQuoteSheet("<p>x</p>", win as unknown as Window)).toBe(false);
    expect(openQuoteSheet("<p>x</p>", null)).toBe(false);
  });

  it("document.write が例外を投げたら、外に投げずに false を返す", () => {
    const opened = {
      document: {
        open: vi.fn(),
        write: vi.fn(() => {
          throw new Error("boom");
        }),
        close: vi.fn(),
        readyState: "complete",
      },
      print: vi.fn(),
      addEventListener: vi.fn(),
    };
    const win = { open: vi.fn(() => opened) };
    let result: boolean | undefined;
    expect(() => {
      result = openQuoteSheet("<p>x</p>", win as unknown as Window);
    }).not.toThrow();
    expect(result).toBe(false);
    expect(opened.print).not.toHaveBeenCalled();
  });

  it("読み込み済みで print が例外を投げても、外に投げずに true を返す（書き込みは済んでいる）", () => {
    const f = fakeWindow("complete");
    f.print.mockImplementation(() => {
      throw new Error("boom");
    });
    let result: boolean | undefined;
    expect(() => {
      result = openQuoteSheet("<p>x</p>", f.win as unknown as Window);
    }).not.toThrow();
    expect(result).toBe(true);
    expect(f.print).toHaveBeenCalledTimes(1);
  });

  it("load のあとの print が例外を投げても、外に投げない", () => {
    const f = fakeWindow("loading");
    f.print.mockImplementation(() => {
      throw new Error("boom");
    });
    expect(openQuoteSheet("<p>x</p>", f.win as unknown as Window)).toBe(true);
    expect(f.print).not.toHaveBeenCalled();
    expect(() => f.listeners.forEach((fn) => fn())).not.toThrow();
    expect(f.print).toHaveBeenCalledTimes(1);
  });
});
