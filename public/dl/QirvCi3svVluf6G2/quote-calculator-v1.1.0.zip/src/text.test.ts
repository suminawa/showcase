import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { calculateQuote, initialInput, type QuoteInput } from "./quote";
import { mailtoHref, quoteText } from "./text";

const config = resolveConfig();
const base: QuoteInput = {
  ...initialInput(config),
  mode: "fixed",
  fixedPrice: 100000,
  includeTax: true,
};

function textOf(patch: Partial<QuoteInput>, c = config) {
  const input = { ...base, ...patch };
  return quoteText(input, calculateQuote(input, c), c);
}

describe("quoteText", () => {
  it("設計書 §5 の例のとおりに並ぶ", () => {
    const text = textOf({
      selectedOptionIds: ["rush"],
      discount: { kind: "amount", value: 5000 },
      withholding: true,
    });
    expect(text).toBe(
      [
        "お見積もり",
        "小計: ¥100,000",
        "急ぎ対応: +¥20,000",
        "値引き: −¥5,000",
        "消費税（10%）: ¥11,500",
        "合計（税込）: ¥126,500",
        "源泉徴収（10.21%）: −¥11,741",
        "差引お支払額: ¥114,759",
      ].join("\n"),
    );
  });

  it("無い行（値引き 0・税なし・源泉なし）は出さない", () => {
    expect(textOf({ includeTax: false })).toBe(["お見積もり", "小計: ¥100,000", "合計（税抜）: ¥100,000"].join("\n"));
  });

  it("先頭は件名。空なら「見積書」", () => {
    expect(textOf({ sheet: { client: "", subject: "LP 制作" } }).split("\n")[0]).toBe("LP 制作");
    expect(textOf({ sheet: { client: "", subject: "   " } }).split("\n")[0]).toBe("見積書");
  });

  it("hourly は 2 行目に時間単価 × 工数", () => {
    const text = textOf({ mode: "hourly", hourlyRate: 5000, effort: 10, effortUnit: "hours" });
    expect(text.split("\n").slice(0, 3)).toEqual(["お見積もり", "時間単価 ¥5,000 × 10 時間", "小計: ¥50,000"]);
    const days = textOf({ mode: "hourly", hourlyRate: 5000, effort: 2, effortUnit: "days" });
    expect(days.split("\n")[1]).toBe("時間単価 ¥5,000 × 2 日");
  });

  it("items は行ごとに 項目 × 数量 = 金額", () => {
    const text = textOf({
      mode: "items",
      items: [
        { label: "デザイン", qty: 1, unitPrice: 50000 },
        { label: "撮影", qty: 2, unitPrice: 30000 },
        { label: "", qty: 3, unitPrice: 1000 },
      ],
    });
    expect(text.split("\n").slice(0, 5)).toEqual([
      "お見積もり",
      "デザイン × 1 = ¥50,000",
      "撮影 × 2 = ¥60,000",
      "項目 × 3 = ¥3,000",
      "小計: ¥113,000",
    ]);
  });

  it("reverse は税込と税抜を並べ、小計を出さない", () => {
    const text = textOf({ mode: "reverse", taxIncludedPrice: 110000 });
    expect(text).toBe(
      ["お見積もり", "税込金額 ¥110,000", "税抜金額 ¥100,000", "消費税（10%）: ¥10,000", "合計（税込）: ¥110,000"].join(
        "\n",
      ),
    );
  });

  it("税率 8% を選ぶと行のラベルも変わる", () => {
    const text = textOf({ taxRate: 0.08 });
    expect(text).toContain("消費税（8%）: ¥8,000");
  });

  it("源泉徴収が 100 万円を超えたら、超過分の税率も添えたラベルになる", () => {
    const text = textOf({ fixedPrice: 1500000, withholding: true });
    expect(text).toContain("源泉徴収（10.21%、¥1,000,000 を超える分は 20.42%）: −¥204,200");
    expect(text).toContain("差引お支払額: ¥1,445,800");
  });
});

describe("mailtoHref", () => {
  it("宛先・件名・本文をエンコードして並べる", () => {
    const c = resolveConfig({ contact: { email: "hello@example.com" } });
    const href = mailtoHref("小計: ¥100,000\n合計（税込）: ¥110,000", c);
    expect(href).toBe(
      "mailto:hello@example.com?subject=" +
        encodeURIComponent("見積もりの相談") +
        "&body=" +
        encodeURIComponent("小計: ¥100,000\n合計（税込）: ¥110,000"),
    );
    expect(href).toContain("%0A");
  });

  it("件名も設定で変えられる", () => {
    const c = resolveConfig({ contact: { email: "hello@example.com", subject: "お仕事のご相談" } });
    expect(mailtoHref("x", c)).toContain(`subject=${encodeURIComponent("お仕事のご相談")}`);
  });
});
