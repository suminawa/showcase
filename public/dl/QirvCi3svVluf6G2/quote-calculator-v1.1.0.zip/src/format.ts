const formatters = new Map<string, Intl.NumberFormat>();

/** 12345 → "¥12,345"。小数は出さない */
export function formatMoney(amount: number, currency: { locale: string; symbol: string }): string {
  let formatter = formatters.get(currency.locale);
  if (!formatter) {
    formatter = new Intl.NumberFormat(currency.locale, { maximumFractionDigits: 0 });
    formatters.set(currency.locale, formatter);
  }
  return `${currency.symbol}${formatter.format(amount)}`;
}

/** 0.1 → "10%"、0.08 → "8%"、0.1021 → "10.21%"。0.1 × 100 = 10.000000000000002 を先に潰す */
export function formatPercent(rate: number): string {
  return `${Math.round(Number(rate) * 1e6) / 1e4}%`;
}

/** ("消費税", 0.1) → "消費税（10%）"。設定の tax.label には率を書かず、表示のときに添える */
export function labelWithRate(label: string, rate: number): string {
  return `${label}（${formatPercent(rate)}）`;
}
