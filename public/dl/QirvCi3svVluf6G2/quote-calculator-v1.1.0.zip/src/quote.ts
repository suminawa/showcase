import {
  RATE_EPSILON,
  type DiscountKind,
  type EffortUnit,
  type LineItem,
  type PricingMode,
  type QuoteConfig,
  type TaxRounding,
} from "./config";

export type QuoteInput = {
  mode: PricingMode;
  /** 時間単価（通貨単位/時）。hourly モードで使用 */
  hourlyRate: number;
  /** 想定工数。単位は effortUnit に従う。hourly モードで使用 */
  effort: number;
  effortUnit: EffortUnit;
  /** 一式金額。fixed モードで使用 */
  fixedPrice: number;
  /** mode = items のとき使う。空配列なら小計 0 */
  items: LineItem[];
  /** mode = reverse のとき使う。税込の金額 */
  taxIncludedPrice: number;
  selectedOptionIds: string[];
  discount: { kind: DiscountKind; value: number };
  includeTax: boolean;
  /** config.tax.choices のどれか。choices に無い値が来たら config.tax.rate に戻す */
  taxRate: number;
  withholding: boolean;
  /** 見積書の宛名と件名。計算には使わない */
  sheet: { client: string; subject: string };
};

export type QuoteOptionLine = { id: string; label: string; amount: number };

export type QuoteBreakdown = {
  subtotal: number;
  optionLines: QuoteOptionLine[];
  optionsTotal: number;
  /** 値引き額（正の数。無ければ 0） */
  discount: number;
  /** 小計 + オプション − 値引き（税抜合計） */
  taxableTotal: number;
  /** 実際に使った税率（input.taxRate が choices に無ければ config.tax.rate） */
  taxRate: number;
  tax: number;
  total: number;
  /** 源泉徴収額（正の数。無ければ 0） */
  withholding: number;
  /** total − withholding。振込される額 */
  payable: number;
};

const ROUND: Record<TaxRounding, (n: number) => number> = {
  floor: Math.floor,
  round: Math.round,
  ceil: Math.ceil,
};

/** 負数・NaN・Infinity は 0 として扱う（未入力時は 0 表示の仕様）。文字列で来ても数値として計算する */
export function sanitizeAmount(value: number): number {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/** 100 × 0.29 = 28.999999999999996 のような二進小数の誤差を、丸める前に 1e-6 の桁で潰す */
function snap(value: number): number {
  return Math.round(value * 1e6) / 1e6;
}

/** 明細 1 行の金額。行ごとに丸めてから足す（内訳の文章と見積書も同じ関数を使う） */
export function lineItemAmount(item: LineItem): number {
  return Math.round(sanitizeAmount(item.qty) * sanitizeAmount(item.unitPrice));
}

/** reverse は税込の金額から割り戻すので、includeTax のチェックによらず常に税込で扱う */
export function isTaxOn(input: QuoteInput): boolean {
  return input.mode === "reverse" || input.includeTax;
}

/** input.taxRate が config.tax.choices に無ければ config.tax.rate に戻す */
function resolveTaxRate(input: QuoteInput, config: QuoteConfig): number {
  const rate = Number(input.taxRate);
  if (!Number.isFinite(rate)) return config.tax.rate;
  const choice = config.tax.choices.find((c) => Math.abs(c.rate - rate) < RATE_EPSILON);
  return choice ? choice.rate : config.tax.rate;
}

/** 値引き。円は小計 + オプションで止まり、% は 100% で止まる。0・負数・空欄は 0 */
function discountOf(discount: { kind: DiscountKind; value: number }, gross: number): number {
  const value = sanitizeAmount(discount.value);
  if (value <= 0) return 0;
  if (discount.kind === "percent") return Math.round(snap((gross * Math.min(value, 100)) / 100));
  return Math.min(Math.round(value), gross);
}

/**
 * 源泉徴収。基準は税抜合計（消費税を区分して表示しているので、国税庁の扱いに合わせる）。
 * threshold まで rate、超えた分は highRate。1 円未満は切り捨て。
 */
function withholdingOf(base: number, config: QuoteConfig): number {
  const amount = sanitizeAmount(base);
  const { rate, highRate, threshold } = config.withholding;
  if (amount <= threshold) return Math.floor(snap(amount * rate));
  return Math.floor(snap((amount - threshold) * highRate + threshold * rate));
}

export function initialInput(config: QuoteConfig): QuoteInput {
  const { subject, items, ...rest } = config.defaults;
  return {
    ...rest,
    items: items.map((item) => ({ ...item })),
    selectedOptionIds: [],
    discount: { kind: "amount", value: 0 },
    includeTax: config.tax.defaultIncluded,
    taxRate: config.tax.rate,
    withholding: false,
    sheet: { client: "", subject },
  };
}

export function calculateQuote(input: QuoteInput, config: QuoteConfig): QuoteBreakdown {
  const taxRate = resolveTaxRate(input, config);
  const round = ROUND[config.tax.rounding];

  // 逆算: 合計が入力した税込額と 1 円もずれないよう、税を先に出して引く
  if (input.mode === "reverse") {
    const taxIncludedPrice = Math.round(sanitizeAmount(input.taxIncludedPrice));
    const tax = round(snap((taxIncludedPrice * taxRate) / (1 + taxRate)));
    const taxableTotal = taxIncludedPrice - tax;
    const withholding = input.withholding ? withholdingOf(taxableTotal, config) : 0;
    return {
      subtotal: taxableTotal,
      optionLines: [],
      optionsTotal: 0,
      discount: 0,
      taxableTotal,
      taxRate,
      tax,
      total: taxIncludedPrice,
      withholding,
      payable: taxIncludedPrice - withholding,
    };
  }

  const subtotal =
    input.mode === "hourly"
      ? Math.round(
          sanitizeAmount(input.hourlyRate) *
            sanitizeAmount(input.effort) *
            (input.effortUnit === "days" ? config.hoursPerDay : 1),
        )
      : input.mode === "items"
        ? (Array.isArray(input.items) ? input.items : []).reduce((sum, item) => sum + lineItemAmount(item), 0)
        : Math.round(sanitizeAmount(input.fixedPrice));

  const optionLines: QuoteOptionLine[] = config.options
    .filter((option) => input.selectedOptionIds.includes(option.id))
    .map((option) => ({ id: option.id, label: option.label, amount: Math.round(subtotal * option.rate) }));

  const optionsTotal = optionLines.reduce((sum, line) => sum + line.amount, 0);
  const discount = discountOf(input.discount, subtotal + optionsTotal);
  const taxableTotal = subtotal + optionsTotal - discount;
  const tax = isTaxOn(input) ? round(snap(taxableTotal * taxRate)) : 0;
  const total = taxableTotal + tax;
  const withholding = input.withholding ? withholdingOf(taxableTotal, config) : 0;

  return {
    subtotal,
    optionLines,
    optionsTotal,
    discount,
    taxableTotal,
    taxRate,
    tax,
    total,
    withholding,
    payable: total - withholding,
  };
}
