import { describe, expect, it } from "vitest";
import { DEFAULT_CONFIG, QuoteConfigError, resolveConfig, type DeepPartial, type QuoteConfig } from "./config";

describe("resolveConfig", () => {
  it("何も渡さなければ既定値（1 日 8 時間・消費税 10% 切り捨て・オプション 3 種）", () => {
    const c = resolveConfig();
    expect(c).toEqual(DEFAULT_CONFIG);
    expect(c.hoursPerDay).toBe(8);
    expect(c.tax).toEqual({
      rate: 0.1,
      choices: [{ label: "10%", rate: 0.1 }, { label: "8%（軽減税率）", rate: 0.08 }],
      label: "消費税",
      rounding: "floor",
      defaultIncluded: true,
    });
    expect(c.options.map((o) => o.id)).toEqual(["rush", "unlimited-revisions", "weekend"]);
  });

  it("v1.1 の既定値（源泉徴収・値引き・明細・見積書・問い合わせ）", () => {
    const c = resolveConfig();
    expect(c.withholding).toEqual({ show: true, rate: 0.1021, highRate: 0.2042, threshold: 1000000 });
    expect(c.discount).toEqual({ show: true });
    expect(c.defaults.items).toEqual([{ label: "デザイン", qty: 1, unitPrice: 50000 }]);
    expect(c.defaults.taxIncludedPrice).toBe(110000);
    expect(c.defaults.subject).toBe("お見積もり");
    expect(c.sheet).toEqual({
      show: true,
      issuer: { name: "", address: "", email: "" },
      validDays: 30,
      notes: "",
    });
    expect(c.contact).toEqual({ email: "", subject: "見積もりの相談" });
  });

  it("v1.1 の文言の既定値", () => {
    const l = resolveConfig().labels;
    expect(l.items).toBe("明細");
    expect(l.itemLabel).toBe("項目");
    expect(l.itemQty).toBe("数量");
    expect(l.itemUnitPrice).toBe("単価");
    expect(l.itemAmount).toBe("金額");
    expect(l.addItem).toBe("行を足す");
    expect(l.removeItem).toBe("消す");
    expect(l.reverse).toBe("税込から逆算");
    expect(l.taxIncludedPrice).toBe("税込金額");
    expect(l.taxExcluded).toBe("税抜金額");
    expect(l.discount).toBe("値引き");
    expect(l.discountAmount).toBe("円");
    expect(l.discountPercent).toBe("%");
    expect(l.taxRate).toBe("税率");
    expect(l.withholding).toBe("源泉徴収あり");
    expect(l.withholdingRow).toBe("源泉徴収（{rate}）");
    expect(l.withholdingRowHigh).toBe("源泉徴収（{rate}、{threshold} を超える分は {highRate}）");
    expect(l.payable).toBe("差引お支払額");
    expect(l.sheet).toBe("見積書");
    expect(l.client).toBe("宛名");
    expect(l.subject).toBe("件名");
    expect(l.printSheet).toBe("見積書を印刷（PDF 保存）");
    expect(l.popupBlocked).toBe("ポップアップを許可してください");
    expect(l.copy).toBe("内訳をコピー");
    expect(l.copied).toBe("コピーしました");
    expect(l.contact).toBe("この内容で問い合わせる");
    expect(l.sheetIssueDate).toBe("発行日");
    expect(l.sheetValidUntil).toBe("有効期限");
    expect(l.sheetNotes).toBe("備考");
    expect(l.sheetHonorific).toBe("御中");
  });

  it("部分指定は深く合成される", () => {
    const c = resolveConfig({ hoursPerDay: 6, tax: { rate: 0.08 }, labels: { subtotal: "Subtotal" } });
    expect(c.hoursPerDay).toBe(6);
    expect(c.tax.rate).toBe(0.08);
    expect(c.tax.rounding).toBe("floor");
    expect(c.labels.subtotal).toBe("Subtotal");
    expect(c.labels.breakdown).toBe("内訳");
  });

  it("sheet.issuer と contact も深く合成される", () => {
    const c = resolveConfig({ sheet: { issuer: { name: "スタジオ example" } }, contact: { email: "hello@example.com" } });
    expect(c.sheet.issuer).toEqual({ name: "スタジオ example", address: "", email: "" });
    expect(c.sheet.validDays).toBe(30);
    expect(c.contact).toEqual({ email: "hello@example.com", subject: "見積もりの相談" });
  });

  it("options は配列ごと置き換える", () => {
    const c = resolveConfig({ options: [{ id: "logo", label: "ロゴ追加", rate: 0.1 }] });
    expect(c.options).toEqual([{ id: "logo", label: "ロゴ追加", rate: 0.1 }]);
  });

  it("tax.choices と defaults.items も配列ごと置き換える", () => {
    const c = resolveConfig({
      tax: { rate: 0, choices: [{ label: "なし", rate: 0 }] },
      defaults: { items: [{ label: "撮影", qty: 2, unitPrice: 30000 }] },
    });
    expect(c.tax.choices).toEqual([{ label: "なし", rate: 0 }]);
    expect(c.defaults.items).toEqual([{ label: "撮影", qty: 2, unitPrice: 30000 }]);
  });

  it("不正な値は QuoteConfigError", () => {
    expect(() => resolveConfig({ hoursPerDay: 0 })).toThrow(QuoteConfigError);
    expect(() => resolveConfig({ tax: { rate: 1 } })).toThrow(QuoteConfigError);
    expect(() =>
      resolveConfig({ options: [{ id: "a", label: "A", rate: 0.1 }, { id: "a", label: "B", rate: 0.2 }] }),
    ).toThrow(/duplicate/);
    expect(() => resolveConfig({ options: [{ id: "a", label: "A", rate: -1 }] })).toThrow(QuoteConfigError);
  });

  it("tax.rate が tax.choices に無ければ QuoteConfigError", () => {
    expect(() => resolveConfig({ tax: { rate: 0.05 } })).toThrow(QuoteConfigError);
    expect(() => resolveConfig({ tax: { rate: 0.05 } })).toThrow(/tax.rate/);
    // 1e-9 のずれは同じ税率とみなす
    expect(() => resolveConfig({ tax: { rate: 0.1 + 1e-12 } })).not.toThrow();
  });

  it("tax.choices が空・配列でない・率が範囲外なら QuoteConfigError", () => {
    expect(() => resolveConfig({ tax: { choices: [] } })).toThrow(/tax.choices/);
    expect(() => resolveConfig({ tax: { choices: "x" } } as unknown as DeepPartial<QuoteConfig>)).toThrow(/tax.choices/);
    expect(() => resolveConfig({ tax: { rate: 0.1, choices: [{ label: "10%", rate: 0.1 }, { label: "x", rate: 1 }] } })).toThrow(
      /tax.choices/,
    );
  });

  it("withholding の率としきい値を検証する", () => {
    expect(() => resolveConfig({ withholding: { rate: 1 } })).toThrow(/withholding.rate/);
    expect(() => resolveConfig({ withholding: { highRate: -0.1 } })).toThrow(/withholding.highRate/);
    expect(() => resolveConfig({ withholding: { threshold: -1 } })).toThrow(/withholding.threshold/);
    expect(resolveConfig({ withholding: { threshold: 0 } }).withholding.threshold).toBe(0);
  });

  it("sheet.validDays が負なら QuoteConfigError", () => {
    expect(() => resolveConfig({ sheet: { validDays: -1 } })).toThrow(/sheet.validDays/);
    expect(resolveConfig({ sheet: { validDays: 0 } }).sheet.validDays).toBe(0);
  });

  it("defaults.items が配列でなければ QuoteConfigError", () => {
    const bad = { defaults: { items: "x" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(bad)).toThrow(QuoteConfigError);
    expect(() => resolveConfig(bad)).toThrow(/defaults.items/);
  });

  it("defaults.taxIncludedPrice が数値に変換できなければ QuoteConfigError", () => {
    const bad = { defaults: { taxIncludedPrice: "abc" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(bad)).toThrow(/taxIncludedPrice/);
    const c = resolveConfig({ defaults: { taxIncludedPrice: "220000" } } as unknown as DeepPartial<QuoteConfig>);
    expect(c.defaults.taxIncludedPrice).toBe(220000);
  });

  it("既定値そのものは書き換わらない", () => {
    const c = resolveConfig({ labels: { subtotal: "x" } });
    expect(DEFAULT_CONFIG.labels.subtotal).toBe("小計");
    expect(c).not.toBe(DEFAULT_CONFIG);
  });

  it("tax.choices と defaults.items は複製されて既定値を汚さない", () => {
    const c = resolveConfig();
    expect(c.tax.choices[0]).not.toBe(DEFAULT_CONFIG.tax.choices[0]);
    expect(c.defaults.items[0]).not.toBe(DEFAULT_CONFIG.defaults.items[0]);
    c.defaults.items[0].qty = 9;
    expect(DEFAULT_CONFIG.defaults.items[0].qty).toBe(1);
  });

  it("既定値は入れ子まで凍結されていて、書き換えると TypeError", () => {
    expect(Object.isFrozen(DEFAULT_CONFIG.tax)).toBe(true);
    expect(Object.isFrozen(DEFAULT_CONFIG.tax.choices)).toBe(true);
    expect(Object.isFrozen(DEFAULT_CONFIG.options)).toBe(true);
    expect(Object.isFrozen(DEFAULT_CONFIG.options[0])).toBe(true);
    expect(Object.isFrozen(DEFAULT_CONFIG.defaults.items[0])).toBe(true);
    expect(() => {
      (DEFAULT_CONFIG.tax as { rate: number }).rate = 0.5;
    }).toThrow(TypeError);
    expect(() => {
      (DEFAULT_CONFIG.options as { id: string; label: string; rate: number }[]).push({ id: "x", label: "x", rate: 0 });
    }).toThrow(TypeError);
  });

  it("option id が空なら QuoteConfigError", () => {
    expect(() => resolveConfig({ options: [{ id: "", label: "x", rate: 0.1 }] })).toThrow(/id is required/);
  });

  it("tax.rounding が floor/round/ceil 以外なら QuoteConfigError", () => {
    const bad = { tax: { rounding: "nearest" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(bad)).toThrow(QuoteConfigError);
    expect(() => resolveConfig(bad)).toThrow(/rounding/);
  });

  it("defaults.mode は hourly/fixed/items/reverse のどれか", () => {
    expect(resolveConfig({ defaults: { mode: "items" } }).defaults.mode).toBe("items");
    expect(resolveConfig({ defaults: { mode: "reverse" } }).defaults.mode).toBe("reverse");
    const bad = { defaults: { mode: "Hourly" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(bad)).toThrow(QuoteConfigError);
    expect(() => resolveConfig(bad)).toThrow(/mode/);
  });

  it("defaults.effortUnit が hours/days 以外なら QuoteConfigError", () => {
    const bad = { defaults: { effortUnit: "weeks" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(bad)).toThrow(QuoteConfigError);
    expect(() => resolveConfig(bad)).toThrow(/effortUnit/);
  });

  it("options が配列でなければ QuoteConfigError", () => {
    expect(() => resolveConfig({ options: "x" } as unknown as DeepPartial<QuoteConfig>)).toThrow(QuoteConfigError);
    expect(() => resolveConfig({ options: "x" } as unknown as DeepPartial<QuoteConfig>)).toThrow(/options/);
  });

  it("defaults の数値が数値に変換できなければ QuoteConfigError", () => {
    const badRate = { defaults: { hourlyRate: "abc" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(badRate)).toThrow(QuoteConfigError);
    expect(() => resolveConfig(badRate)).toThrow(/hourlyRate/);

    const badEffort = { defaults: { effort: "abc" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(badEffort)).toThrow(/effort/);

    const badFixed = { defaults: { fixedPrice: "abc" } } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(badFixed)).toThrow(/fixedPrice/);
  });

  it('defaults の数値は文字列で渡されても変換される（"6000" → 6000）', () => {
    const c = resolveConfig({ defaults: { hourlyRate: "6000" } } as unknown as DeepPartial<QuoteConfig>);
    expect(c.defaults.hourlyRate).toBe(6000);
  });

  it("defaults.items の各フィールドも文字列・数値に変換される（JSON 設定で型がずれても計算できる）", () => {
    const raw = {
      defaults: { items: [{ label: 123, qty: "2", unitPrice: "5000" }] },
    } as unknown as DeepPartial<QuoteConfig>;
    const c = resolveConfig(raw);
    expect(c.defaults.items).toEqual([{ label: "123", qty: 2, unitPrice: 5000 }]);
  });

  it("defaults.items の label が無ければ空文字になる", () => {
    const raw = { defaults: { items: [{ qty: 1, unitPrice: 100 }] } } as unknown as DeepPartial<QuoteConfig>;
    const c = resolveConfig(raw);
    expect(c.defaults.items[0].label).toBe("");
  });

  it("defaults.items の qty / unitPrice が数値に変換できなければ QuoteConfigError", () => {
    const badQty = {
      defaults: { items: [{ label: "x", qty: "abc", unitPrice: 100 }] },
    } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(badQty)).toThrow(QuoteConfigError);
    expect(() => resolveConfig(badQty)).toThrow(/qty/);

    const badPrice = {
      defaults: { items: [{ label: "x", qty: 1, unitPrice: "abc" }] },
    } as unknown as DeepPartial<QuoteConfig>;
    expect(() => resolveConfig(badPrice)).toThrow(/unitPrice/);
  });
});
