import { describe, expect, it } from "vitest";
import { DEFAULT_CONFIG } from "./config";
import { formatMoney, formatPercent, labelWithRate } from "./format";

describe("formatMoney", () => {
  it("JPY は ¥ と 3 桁区切り", () => {
    expect(formatMoney(12345, DEFAULT_CONFIG.currency)).toBe("¥12,345");
  });
  it("通貨記号とロケールは設定に従う", () => {
    expect(formatMoney(12345, { locale: "en-US", symbol: "$" })).toBe("$12,345");
  });
  it("小数は出さない", () => {
    expect(formatMoney(12.7, DEFAULT_CONFIG.currency)).toBe("¥13");
  });
});

describe("formatPercent", () => {
  it("二進小数の誤差を落として % にする", () => {
    expect(formatPercent(0.1)).toBe("10%");
    expect(formatPercent(0.08)).toBe("8%");
    expect(formatPercent(0.1021)).toBe("10.21%");
    expect(formatPercent(0.2042)).toBe("20.42%");
    expect(formatPercent(0)).toBe("0%");
  });
});

describe("labelWithRate", () => {
  it("表示名に率を添える", () => {
    expect(labelWithRate("消費税", 0.1)).toBe("消費税（10%）");
    expect(labelWithRate("消費税", 0.08)).toBe("消費税（8%）");
  });
});
