import type { QuoteConfig } from "./config";
import { formatMoney, labelWithRate } from "./format";
import { isTaxOn, lineItemAmount, sanitizeAmount, type QuoteBreakdown, type QuoteInput } from "./quote";
import { withholdingRowLabel } from "./text";

/** U+2212 */
const MINUS = "−";

/** 見積書に入る文字はすべてここを通す。設定も入力も買い手が書いた文字列なので、そのまま HTML にしない */
export function escapeHtml(text: string): string {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * A4 縦 1 枚に収める。外部ファイルは読まない（別タブに書き込むだけなので相対パスが効かない）。
 * hasIssuer / hasNotes が false のときはその要素向けのルールを丸ごと省く。
 * escapeHtml を通らない固定 CSS とはいえ、"qc-sheet-issuer" / "qc-sheet-notes" という文字列が
 * 発行者・備考の有無に関わらず出力に残ると「無ければ出さない」を文字列検査するテストと食い違うため。
 */
function sheetStyle(hasIssuer: boolean, hasNotes: boolean): string {
  const printSelectors = [".qc-sheet-client", ".qc-sheet-meta", ...(hasIssuer ? [".qc-sheet-issuer"] : []), ".qc-sheet-table"].join(
    ", ",
  );
  return [
    ":root { --qc-ink: #1c1a15; --qc-muted: #6a665d; --qc-line: rgba(28, 26, 21, 0.3) }",
    "@page { size: A4; margin: 18mm }",
    "* { box-sizing: border-box }",
    'body { margin: 0; color: var(--qc-ink); font-family: system-ui, "Hiragino Sans", "Noto Sans JP", sans-serif; font-size: 11pt; line-height: 1.7 }',
    "h1 { margin: 0 0 1.5rem; font-size: 1.5rem; font-weight: normal; letter-spacing: 0.1em }",
    ".qc-sheet-client { margin: 0 0 1.5rem; font-size: 1.125rem }",
    ".qc-sheet-meta { margin: 0 0 1.5rem; display: grid; gap: 0.25rem }",
    ".qc-sheet-meta div, .qc-sheet-rows div { display: flex; gap: 1rem }",
    ".qc-sheet-meta dt, .qc-sheet-rows dt { color: var(--qc-muted); min-width: 8rem }",
    ".qc-sheet-meta dd, .qc-sheet-rows dd { margin: 0 }",
    ...(hasIssuer
      ? [".qc-sheet-issuer { margin: 0 0 1.5rem; display: grid; gap: 0.125rem; font-style: normal; color: var(--qc-muted) }"]
      : []),
    ".qc-sheet-table { width: 100%; border-collapse: collapse; margin: 0 0 1.5rem }",
    ".qc-sheet-table th, .qc-sheet-table td { padding: 0.5rem 0.25rem; border-bottom: 1px solid var(--qc-line); text-align: left }",
    ".qc-sheet-table th { color: var(--qc-muted); font-weight: normal; font-size: 0.875rem }",
    ".qc-sheet-num { text-align: right; font-variant-numeric: tabular-nums }",
    ".qc-sheet-rows { margin: 0; display: grid; gap: 0.25rem; justify-content: end }",
    ".qc-sheet-rows dd { min-width: 8rem; text-align: right; font-variant-numeric: tabular-nums }",
    ".qc-row-minus dd { color: var(--qc-muted) }",
    ...(hasNotes ? [".qc-sheet-notes { margin: 2rem 0 0; color: var(--qc-muted); white-space: pre-wrap }"] : []),
    `@media print { body { font-size: 10pt } h1 { margin-bottom: 1rem } ${printSelectors} { margin-bottom: 1rem } }`,
  ].join("\n");
}

type DetailRow = { label: string; qty: string; unitPrice: string; amount: string };
type SheetRow = { label: string; value: string; minus?: boolean };

/** ロケールに左右されないよう、年月日を自分で組み立てる */
function formatDate(date: Date): string {
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`;
}

/** 夏時間のある地域で時計を足すとずれるので、日付の部品で足す */
function addDays(date: Date, days: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

/** 印刷用の見積書 1 枚。issuedOn は発行日 */
export function quoteSheetHtml(
  input: QuoteInput,
  breakdown: QuoteBreakdown,
  config: QuoteConfig,
  issuedOn: Date,
): string {
  const money = (amount: number) => formatMoney(amount, config.currency);
  const subject = input.sheet.subject.trim() || config.labels.sheet;
  const client = input.sheet.client.trim();
  const taxOn = isTaxOn(input);

  const details: DetailRow[] = [];
  if (input.mode === "items") {
    for (const item of input.items) {
      details.push({
        label: item.label.trim() || config.labels.itemLabel,
        qty: String(sanitizeAmount(item.qty)),
        unitPrice: money(sanitizeAmount(item.unitPrice)),
        amount: money(lineItemAmount(item)),
      });
    }
  } else if (input.mode === "hourly") {
    const unit = input.effortUnit === "days" ? config.labels.days : config.labels.hours;
    details.push({
      label: config.labels.hourlyRate,
      qty: `${sanitizeAmount(input.effort)} ${unit}`,
      unitPrice: money(sanitizeAmount(input.hourlyRate)),
      amount: money(breakdown.subtotal),
    });
  } else if (input.mode === "reverse") {
    details.push({
      label: config.labels.taxExcluded,
      qty: "1",
      unitPrice: money(breakdown.taxableTotal),
      amount: money(breakdown.taxableTotal),
    });
  } else {
    details.push({
      label: config.labels.fixedPrice,
      qty: "1",
      unitPrice: money(breakdown.subtotal),
      amount: money(breakdown.subtotal),
    });
  }

  // 見積書の並びは オプション → 値引き → 小計 → 消費税 → 合計 → 源泉 → 差引。
  // 明細の表に各行の金額が出ているので、ここの「小計」は値引きまで引いたあとの税抜合計にする。
  // reverse は明細の行がすでに税抜金額そのものなので、小計は出さない（quoteText と同じ扱い）
  const rows: SheetRow[] = [];
  if (input.mode !== "reverse") {
    for (const line of breakdown.optionLines) rows.push({ label: line.label, value: `+${money(line.amount)}` });
    if (breakdown.discount > 0) {
      rows.push({ label: config.labels.discount, value: `${MINUS}${money(breakdown.discount)}`, minus: true });
    }
    rows.push({ label: config.labels.subtotal, value: money(breakdown.taxableTotal) });
  }
  if (taxOn) rows.push({ label: labelWithRate(config.tax.label, breakdown.taxRate), value: money(breakdown.tax) });
  rows.push({
    label: taxOn ? config.labels.totalTaxIncluded : config.labels.totalTaxExcluded,
    value: money(breakdown.total),
  });
  if (breakdown.withholding > 0) {
    rows.push({
      label: withholdingRowLabel(breakdown, config),
      value: `${MINUS}${money(breakdown.withholding)}`,
      minus: true,
    });
    rows.push({ label: config.labels.payable, value: money(breakdown.payable) });
  }

  const meta: [string, string][] = [
    [config.labels.sheetIssueDate, formatDate(issuedOn)],
    [config.labels.sheetValidUntil, formatDate(addDays(issuedOn, config.sheet.validDays))],
  ];
  const issuer = [config.sheet.issuer.name, config.sheet.issuer.address, config.sheet.issuer.email].filter(
    (value) => value.trim() !== "",
  );
  const notes = config.sheet.notes.trim();

  return [
    "<!doctype html>",
    '<html lang="ja">',
    "<head>",
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    `<title>${escapeHtml(subject)}</title>`,
    `<style>${sheetStyle(issuer.length > 0, notes !== "")}</style>`,
    "</head>",
    "<body>",
    `<h1 class="qc-sheet-subject">${escapeHtml(subject)}</h1>`,
    client === ""
      ? ""
      : `<p class="qc-sheet-client">${escapeHtml(client)} ${escapeHtml(config.labels.sheetHonorific)}</p>`,
    '<dl class="qc-sheet-meta">',
    ...meta.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`),
    "</dl>",
    issuer.length === 0
      ? ""
      : `<address class="qc-sheet-issuer">${issuer.map((v) => `<span>${escapeHtml(v)}</span>`).join("")}</address>`,
    '<table class="qc-sheet-table">',
    "<thead><tr>" +
      `<th>${escapeHtml(config.labels.itemLabel)}</th>` +
      `<th>${escapeHtml(config.labels.itemQty)}</th>` +
      `<th>${escapeHtml(config.labels.itemUnitPrice)}</th>` +
      `<th>${escapeHtml(config.labels.itemAmount)}</th>` +
      "</tr></thead>",
    "<tbody>",
    ...details.map(
      (row) =>
        `<tr><td>${escapeHtml(row.label)}</td>` +
        `<td class="qc-sheet-num">${escapeHtml(row.qty)}</td>` +
        `<td class="qc-sheet-num">${escapeHtml(row.unitPrice)}</td>` +
        `<td class="qc-sheet-num">${escapeHtml(row.amount)}</td></tr>`,
    ),
    "</tbody>",
    "</table>",
    '<dl class="qc-sheet-rows">',
    ...rows.map(
      (row) =>
        `<div${row.minus ? ' class="qc-row-minus"' : ""}>` +
        `<dt>${escapeHtml(row.label)}</dt><dd>${escapeHtml(row.value)}</dd></div>`,
    ),
    "</dl>",
    notes === ""
      ? ""
      : `<p class="qc-sheet-notes">${escapeHtml(config.labels.sheetNotes)}: ${escapeHtml(notes)}</p>`,
    "</body>",
    "</html>",
  ]
    .filter((line) => line !== "")
    .join("\n");
}

/**
 * 見積書を別のタブに開いて印刷画面を出す。
 * ポップアップを塞がれていたら false（呼び出し側が「ポップアップを許可してください」を出す）。
 */
export function openQuoteSheet(
  html: string,
  win: Window | null = typeof window === "undefined" ? null : window,
): boolean {
  const opened = win ? win.open("", "_blank") : null;
  if (!opened) return false;
  try {
    opened.document.open();
    opened.document.write(html);
    opened.document.close();
  } catch {
    // 書き込みに失敗したタブは中身が無い。呼び出し側には「開けなかった」として返す
    return false;
  }
  // print は読み込みが終わってから。閉じた直後に complete のこともある。
  // print() 自体が例外を投げても（ブロックされている等）見積書は書けているので、ここで揉み消す
  const safePrint = () => {
    try {
      opened.print();
    } catch {
      // 何もしない。タブは開いたままにする
    }
  };
  if (opened.document.readyState === "complete") safePrint();
  else opened.addEventListener("load", safePrint, { once: true });
  return true;
}
