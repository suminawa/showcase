import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { calculateQuote, initialInput, isTaxOn, lineItemAmount, type QuoteInput } from "./quote";

const config = resolveConfig();
const base: QuoteInput = {
  mode: "hourly",
  hourlyRate: 5000,
  effort: 10,
  effortUnit: "hours",
  fixedPrice: 0,
  items: [],
  taxIncludedPrice: 0,
  selectedOptionIds: [],
  discount: { kind: "amount", value: 0 },
  includeTax: false,
  taxRate: 0.1,
  withholding: false,
  sheet: { client: "", subject: "" },
};

describe("calculateQuote（既定設定）", () => {
  it("時間単価 × 時間で小計を出す", () => {
    const r = calculateQuote(base, config);
    expect(r.subtotal).toBe(50000);
    expect(r.total).toBe(50000);
  });

  it("日数入力は 1 日 = 8 時間で換算する", () => {
    expect(calculateQuote({ ...base, effort: 2, effortUnit: "days" }, config).subtotal).toBe(80000);
  });

  it("固定単価モードは一式金額をそのまま小計にし、工数を無視する", () => {
    const r = calculateQuote({ ...base, mode: "fixed", fixedPrice: 120000, hourlyRate: 99999, effort: 99 }, config);
    expect(r.subtotal).toBe(120000);
  });

  it("オプションは小計への割合で加算される", () => {
    const r = calculateQuote(
      { ...base, hourlyRate: 10000, effort: 10, selectedOptionIds: ["rush", "unlimited-revisions"] },
      config,
    );
    expect(r.optionLines).toEqual([
      { id: "rush", label: "急ぎ対応", amount: 20000 },
      { id: "unlimited-revisions", label: "修正回数無制限", amount: 15000 },
    ]);
    expect(r.optionsTotal).toBe(35000);
    expect(r.taxableTotal).toBe(135000);
  });

  it("存在しないオプション ID は無視する", () => {
    const r = calculateQuote({ ...base, selectedOptionIds: ["nope"] }, config);
    expect(r.optionLines).toEqual([]);
    expect(r.total).toBe(50000);
  });

  it("消費税は税抜合計（小計 + オプション）の 10% を切り捨てで加算する", () => {
    const r = calculateQuote(
      { ...base, hourlyRate: 3333, effort: 3, selectedOptionIds: ["rush", "unlimited-revisions", "weekend"], includeTax: true },
      config,
    );
    expect(r.subtotal).toBe(9999);
    expect(r.optionsTotal).toBe(4500);
    expect(r.taxableTotal).toBe(14499);
    expect(r.tax).toBe(1449);
    expect(r.total).toBe(15948);
  });

  it("includeTax が false なら税額 0", () => {
    expect(calculateQuote({ ...base, includeTax: true }, config).tax).toBe(5000);
    const r = calculateQuote({ ...base, includeTax: false }, config);
    expect(r.tax).toBe(0);
    expect(r.total).toBe(r.taxableTotal);
  });

  it("負数・NaN は 0 として扱う", () => {
    const r = calculateQuote({ ...base, hourlyRate: NaN, effort: -5 }, config);
    expect(r.subtotal).toBe(0);
    expect(r.total).toBe(0);
  });

  it("文字列で渡された数値も計算できる（フォームの値が文字列で来ても ¥0 にならない）", () => {
    const r = calculateQuote(
      { ...base, hourlyRate: "6000" as unknown as number, effort: "8" as unknown as number },
      config,
    );
    expect(r.subtotal).toBe(48000);
  });

  it("Infinity は 0 として扱う", () => {
    const r = calculateQuote({ ...base, hourlyRate: Infinity }, config);
    expect(r.subtotal).toBe(0);
  });

  it("小数の単価 × 工数は四捨五入する（37.5 × 3 = 112.5 → 113。JS の Math.round は 0.5 を +Infinity 側に丸める）", () => {
    const r = calculateQuote({ ...base, hourlyRate: 37.5, effort: 3 }, config);
    expect(r.subtotal).toBe(113);
  });
});

describe("calculateQuote（明細 items）", () => {
  it("行ごとに丸めてから足す", () => {
    const r = calculateQuote(
      {
        ...base,
        mode: "items",
        items: [
          { label: "デザイン", qty: 3, unitPrice: 33.3 },
          { label: "修正", qty: 1, unitPrice: 0.5 },
        ],
      },
      config,
    );
    // 3 × 33.3 = 99.9 → 100、1 × 0.5 → 1。先に足すと 100.4 → 100 になってしまう
    expect(r.subtotal).toBe(101);
  });

  it("空配列は小計 0、負数・NaN の行は 0 として数える", () => {
    expect(calculateQuote({ ...base, mode: "items", items: [] }, config).subtotal).toBe(0);
    const r = calculateQuote(
      {
        ...base,
        mode: "items",
        items: [
          { label: "A", qty: -2, unitPrice: 1000 },
          { label: "B", qty: 2, unitPrice: NaN },
          { label: "C", qty: 2, unitPrice: 1500 },
        ],
      },
      config,
    );
    expect(r.subtotal).toBe(3000);
  });

  it("明細にもオプション・値引き・税がかかる", () => {
    const r = calculateQuote(
      {
        ...base,
        mode: "items",
        items: [{ label: "LP", qty: 1, unitPrice: 100000 }],
        selectedOptionIds: ["rush"],
        includeTax: true,
      },
      config,
    );
    expect(r.subtotal).toBe(100000);
    expect(r.optionsTotal).toBe(20000);
    expect(r.taxableTotal).toBe(120000);
    expect(r.tax).toBe(12000);
    expect(r.total).toBe(132000);
  });

  it("lineItemAmount は 1 行分の金額", () => {
    expect(lineItemAmount({ label: "A", qty: 3, unitPrice: 33.3 })).toBe(100);
    expect(lineItemAmount({ label: "A", qty: -1, unitPrice: 1000 })).toBe(0);
  });
});

describe("calculateQuote（税込から逆算 reverse）", () => {
  it("税込金額から税を割り戻し、合計が入力と 1 円もずれない", () => {
    const r = calculateQuote({ ...base, mode: "reverse", taxIncludedPrice: 110000 }, config);
    expect(r.tax).toBe(10000);
    expect(r.subtotal).toBe(100000);
    expect(r.taxableTotal).toBe(100000);
    expect(r.total).toBe(110000);
    expect(r.subtotal + r.tax).toBe(r.total);
  });

  it("オプションと値引きは使わない", () => {
    const r = calculateQuote(
      {
        ...base,
        mode: "reverse",
        taxIncludedPrice: 110000,
        selectedOptionIds: ["rush"],
        discount: { kind: "amount", value: 5000 },
      },
      config,
    );
    expect(r.optionLines).toEqual([]);
    expect(r.optionsTotal).toBe(0);
    expect(r.discount).toBe(0);
    expect(r.total).toBe(110000);
  });

  it("includeTax が false でも税込で計算する", () => {
    const r = calculateQuote({ ...base, mode: "reverse", taxIncludedPrice: 110000, includeTax: false }, config);
    expect(r.tax).toBe(10000);
    expect(r.total).toBe(110000);
  });

  it("3 種の丸めで検算できて、どれでも合計は入力どおり", () => {
    const floorConfig = resolveConfig({ tax: { rounding: "floor" } });
    const roundConfig = resolveConfig({ tax: { rounding: "round" } });
    const ceilConfig = resolveConfig({ tax: { rounding: "ceil" } });
    // 10,005 → 909.5454…
    const a: QuoteInput = { ...base, mode: "reverse", taxIncludedPrice: 10005 };
    expect(calculateQuote(a, floorConfig).tax).toBe(909);
    expect(calculateQuote(a, roundConfig).tax).toBe(910);
    expect(calculateQuote(a, ceilConfig).tax).toBe(910);
    // 10,000 → 909.0909…
    const b: QuoteInput = { ...base, mode: "reverse", taxIncludedPrice: 10000 };
    expect(calculateQuote(b, floorConfig).tax).toBe(909);
    expect(calculateQuote(b, roundConfig).tax).toBe(909);
    expect(calculateQuote(b, ceilConfig).tax).toBe(910);
    for (const c of [floorConfig, roundConfig, ceilConfig]) {
      const r = calculateQuote(a, c);
      expect(r.total).toBe(10005);
      expect(r.subtotal + r.tax).toBe(10005);
    }
  });

  it("割り戻しは浮動小数の誤差で 1 円ずれない（8% の 108,000 は 8,000）", () => {
    // 108000 × 0.08 / 1.08 = 7999.999999999999。snap しないと切り捨てで 7,999 になる
    const c = resolveConfig({ tax: { rate: 0.08 } });
    const r = calculateQuote({ ...base, mode: "reverse", taxIncludedPrice: 108000, taxRate: 0.08 }, c);
    expect(r.tax).toBe(8000);
    expect(r.subtotal).toBe(100000);
  });

  it("税込金額の負数・空欄は 0", () => {
    const r = calculateQuote({ ...base, mode: "reverse", taxIncludedPrice: -5000 }, config);
    expect(r.total).toBe(0);
    expect(r.tax).toBe(0);
  });
});

describe("calculateQuote（税率の選択）", () => {
  it("税率 8% を選ぶと税額が変わる", () => {
    const r = calculateQuote({ ...base, mode: "fixed", fixedPrice: 100000, includeTax: true, taxRate: 0.08 }, config);
    expect(r.taxRate).toBe(0.08);
    expect(r.tax).toBe(8000);
    expect(r.total).toBe(108000);
  });

  it("choices に無い税率は config.tax.rate に戻る", () => {
    const r = calculateQuote({ ...base, mode: "fixed", fixedPrice: 100000, includeTax: true, taxRate: 0.05 }, config);
    expect(r.taxRate).toBe(0.1);
    expect(r.tax).toBe(10000);
    const broken = calculateQuote(
      { ...base, mode: "fixed", fixedPrice: 100000, includeTax: true, taxRate: NaN },
      config,
    );
    expect(broken.taxRate).toBe(0.1);
    expect(broken.tax).toBe(10000);
  });
});

describe("calculateQuote（値引き）", () => {
  it("円の値引きは小計 + オプションで止まる", () => {
    const r = calculateQuote(
      { ...base, mode: "fixed", fixedPrice: 100000, discount: { kind: "amount", value: 30000 } },
      config,
    );
    expect(r.discount).toBe(30000);
    expect(r.taxableTotal).toBe(70000);
    const over = calculateQuote(
      { ...base, mode: "fixed", fixedPrice: 100000, discount: { kind: "amount", value: 500000 } },
      config,
    );
    expect(over.discount).toBe(100000);
    expect(over.taxableTotal).toBe(0);
    expect(over.total).toBe(0);
  });

  it("% の値引きは小計 + オプションにかかり、100% で止まる", () => {
    const r = calculateQuote(
      {
        ...base,
        mode: "fixed",
        fixedPrice: 100000,
        selectedOptionIds: ["rush"],
        discount: { kind: "percent", value: 10 },
      },
      config,
    );
    expect(r.discount).toBe(12000);
    expect(r.taxableTotal).toBe(108000);
    const over = calculateQuote(
      { ...base, mode: "fixed", fixedPrice: 100000, discount: { kind: "percent", value: 250 } },
      config,
    );
    expect(over.discount).toBe(100000);
  });

  it("値引きの 0・負数・NaN は 0", () => {
    for (const value of [0, -5000, NaN]) {
      expect(
        calculateQuote({ ...base, mode: "fixed", fixedPrice: 100000, discount: { kind: "amount", value } }, config)
          .discount,
      ).toBe(0);
      expect(
        calculateQuote({ ...base, mode: "fixed", fixedPrice: 100000, discount: { kind: "percent", value } }, config)
          .discount,
      ).toBe(0);
    }
  });

  it("税は値引きのあとの税抜合計にかかる", () => {
    const r = calculateQuote(
      {
        ...base,
        mode: "fixed",
        fixedPrice: 100000,
        discount: { kind: "amount", value: 10000 },
        includeTax: true,
      },
      config,
    );
    expect(r.taxableTotal).toBe(90000);
    expect(r.tax).toBe(9000);
    expect(r.total).toBe(99000);
  });
});

describe("calculateQuote（源泉徴収）", () => {
  it("税抜合計を基準に 10.21%（1 円未満切り捨て）", () => {
    const r = calculateQuote(
      { ...base, mode: "fixed", fixedPrice: 100000, includeTax: true, withholding: true },
      config,
    );
    expect(r.taxableTotal).toBe(100000);
    // 税込 110,000 ではなく税抜 100,000 が基準
    expect(r.withholding).toBe(10210);
    expect(r.total).toBe(110000);
    expect(r.payable).toBe(99790);
  });

  it("100 万円までが 10.21%、超えた分が 20.42%", () => {
    const at = calculateQuote({ ...base, mode: "fixed", fixedPrice: 1000000, withholding: true }, config);
    expect(at.withholding).toBe(102100);
    // 1 円超えても、超過分 0.2042 円は切り捨てられて同じ額
    const over = calculateQuote({ ...base, mode: "fixed", fixedPrice: 1000001, withholding: true }, config);
    expect(over.withholding).toBe(102100);
    // 1,000,000 × 10.21% + 1,000,000 × 20.42%
    const far = calculateQuote({ ...base, mode: "fixed", fixedPrice: 2000000, withholding: true }, config);
    expect(far.withholding).toBe(306300);
  });

  it("チェックしていない・0 円なら 0 で、payable は合計と同じ", () => {
    const off = calculateQuote({ ...base, mode: "fixed", fixedPrice: 100000, includeTax: true }, config);
    expect(off.withholding).toBe(0);
    expect(off.payable).toBe(off.total);
    const zero = calculateQuote({ ...base, mode: "fixed", fixedPrice: 0, withholding: true }, config);
    expect(zero.withholding).toBe(0);
    expect(zero.payable).toBe(0);
  });

  it("値引きのあとの税抜合計にかかる（設計書 §5 の例）", () => {
    const r = calculateQuote(
      {
        ...base,
        mode: "fixed",
        fixedPrice: 100000,
        selectedOptionIds: ["rush"],
        discount: { kind: "amount", value: 5000 },
        includeTax: true,
        withholding: true,
      },
      config,
    );
    expect(r.taxableTotal).toBe(115000);
    expect(r.tax).toBe(11500);
    expect(r.total).toBe(126500);
    expect(r.withholding).toBe(11741);
    expect(r.payable).toBe(114759);
  });

  it("reverse でも割り戻したあとの税抜が基準", () => {
    const r = calculateQuote({ ...base, mode: "reverse", taxIncludedPrice: 110000, withholding: true }, config);
    expect(r.taxableTotal).toBe(100000);
    expect(r.withholding).toBe(10210);
    expect(r.payable).toBe(99790);
  });

  it("率としきい値は設定で変えられる", () => {
    const c = resolveConfig({ withholding: { rate: 0.2, highRate: 0.3, threshold: 100000 } });
    const r = calculateQuote({ ...base, mode: "fixed", fixedPrice: 200000, withholding: true }, c);
    expect(r.withholding).toBe(50000);
  });
});

describe("calculateQuote（設定で変わる）", () => {
  it("hoursPerDay を 6 にすると日数換算が変わる", () => {
    const c = resolveConfig({ hoursPerDay: 6 });
    expect(calculateQuote({ ...base, effort: 2, effortUnit: "days" }, c).subtotal).toBe(60000);
  });

  it("税率 0.29 で 100 円の税は 29 円（浮動小数の誤差で 28 にならない）", () => {
    const c = resolveConfig({ tax: { rate: 0.29, choices: [{ label: "29%", rate: 0.29 }] } });
    const r = calculateQuote({ ...base, mode: "fixed", fixedPrice: 100, includeTax: true, taxRate: 0.29 }, c);
    expect(r.tax).toBe(29);
  });

  it("丸めは round / ceil にも切り替えられる", () => {
    const input: QuoteInput = { ...base, mode: "fixed", fixedPrice: 3333, includeTax: true };
    expect(calculateQuote(input, resolveConfig({ tax: { rounding: "round" } })).tax).toBe(333);
    expect(calculateQuote(input, resolveConfig({ tax: { rounding: "ceil" } })).tax).toBe(334);
  });

  it("独自オプションが効く", () => {
    const c = resolveConfig({ options: [{ id: "logo", label: "ロゴ", rate: 0.1 }] });
    const r = calculateQuote({ ...base, mode: "fixed", fixedPrice: 100000, selectedOptionIds: ["logo", "rush"] }, c);
    expect(r.optionLines).toEqual([{ id: "logo", label: "ロゴ", amount: 10000 }]);
  });
});

describe("isTaxOn", () => {
  it("reverse は includeTax によらず常に税込", () => {
    expect(isTaxOn({ ...base, includeTax: false })).toBe(false);
    expect(isTaxOn({ ...base, includeTax: true })).toBe(true);
    expect(isTaxOn({ ...base, mode: "reverse", includeTax: false })).toBe(true);
  });
});

describe("initialInput", () => {
  it("設定の defaults と tax から作る", () => {
    expect(initialInput(config)).toEqual({
      mode: "hourly",
      hourlyRate: 5000,
      effort: 10,
      effortUnit: "hours",
      fixedPrice: 300000,
      items: [{ label: "デザイン", qty: 1, unitPrice: 50000 }],
      taxIncludedPrice: 110000,
      selectedOptionIds: [],
      discount: { kind: "amount", value: 0 },
      includeTax: true,
      taxRate: 0.1,
      withholding: false,
      sheet: { client: "", subject: "お見積もり" },
    });
    expect(initialInput(resolveConfig({ tax: { defaultIncluded: false } })).includeTax).toBe(false);
  });

  it("items は毎回複製する（設定の配列を書き換えない）", () => {
    const first = initialInput(config);
    first.items[0].qty = 5;
    expect(initialInput(config).items[0].qty).toBe(1);
    expect(config.defaults.items[0].qty).toBe(1);
  });
});
