// IIFE の入口。<script src="quote-calculator.global.js"> で window.QuoteCalculator になる
export { DEFAULT_CONFIG, QuoteConfigError, resolveConfig } from "../config";
export { formatMoney, formatPercent, labelWithRate } from "../format";
export { calculateQuote, initialInput, isTaxOn, lineItemAmount } from "../quote";
export { escapeHtml, openQuoteSheet, quoteSheetHtml } from "../sheet";
export { mailtoHref, quoteText } from "../text";
export { mountQuoteCalculator as mount } from "./mount";
