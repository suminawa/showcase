import { describe, expect, it, vi } from "vitest";
import { resolveConfig } from "../config";
import { mailtoHref, quoteText } from "../text";
import { mountQuoteCalculator } from "./mount";

function mount(config = {}) {
  const root = document.createElement("div");
  document.body.append(root);
  return { root, handle: mountQuoteCalculator(root, config) };
}

const text = (root: HTMLElement, selector: string) => root.querySelector(selector)?.textContent;

describe("mountQuoteCalculator", () => {
  it("既定で 5000 円 × 10 時間 + 税 = ¥55,000 を表示する", () => {
    const { root } = mount();
    expect(text(root, ".qc-total")).toBe("¥55,000");
    expect(text(root, ".qc-total-label")).toBe("合計（税込）");
    expect([...root.querySelectorAll(".qc-row-label")].map((e) => e.textContent)).toEqual(["小計", "消費税（10%）"]);
  });

  it("入力を変えると内訳と合計が更新される", () => {
    const { root, handle } = mount();
    const rate = root.querySelector<HTMLInputElement>("input[id$='-rate']")!;
    rate.value = "10000";
    rate.dispatchEvent(new Event("input"));
    expect(handle.getBreakdown().subtotal).toBe(100000);
    expect(text(root, ".qc-total")).toBe("¥110,000");
  });

  it("オプションのチェックで行が増える", () => {
    const { root } = mount();
    const box = root.querySelector<HTMLInputElement>("input[value='rush']")!;
    box.checked = true;
    box.dispatchEvent(new Event("change"));
    expect([...root.querySelectorAll(".qc-row-label")].map((e) => e.textContent)).toEqual([
      "小計", "急ぎ対応", "消費税（10%）",
    ]);
    expect(text(root, ".qc-total")).toBe("¥66,000");
  });

  it("固定単価に切り替えると工数欄が隠れ、一式金額で計算する", () => {
    const { root, handle } = mount();
    handle.setInput({ mode: "fixed", fixedPrice: 120000 });
    expect(root.querySelector<HTMLElement>(".qc-block-hourly")!.hidden).toBe(true);
    expect(root.querySelector<HTMLElement>(".qc-block-fixed")!.hidden).toBe(false);
    expect(text(root, ".qc-total")).toBe("¥132,000");
  });

  it("日数に切り替えると単位と換算の注記が出る", () => {
    const { root, handle } = mount();
    handle.setInput({ effortUnit: "days", effort: 2 });
    expect(root.querySelector<HTMLElement>(".qc-note")!.hidden).toBe(false);
    expect(text(root, ".qc-note")).toBe("1 日 = 8 時間で換算します");
    expect(handle.getBreakdown().subtotal).toBe(80000);
  });

  it("subscribe は変更のたびに呼ばれ、解除できる", () => {
    const { handle } = mount();
    const spy = vi.fn();
    const off = handle.subscribe(spy);
    handle.setInput({ effort: 20 });
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy.mock.calls[0][1].subtotal).toBe(100000);
    off();
    handle.setInput({ effort: 30 });
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it("設定で通貨・ラベル・オプションを差し替えられる", () => {
    const { root } = mount({
      currency: { code: "USD", locale: "en-US", symbol: "$" },
      defaults: { hourlyRate: 80, effort: 5 },
      tax: { rate: 0, choices: [{ label: "0%", rate: 0 }], label: "Tax", defaultIncluded: false },
      labels: { subtotal: "Subtotal", totalTaxExcluded: "Total" },
      options: [{ id: "logo", label: "Logo", rate: 0.25 }],
    });
    expect(text(root, ".qc-total")).toBe("$400");
    expect(text(root, ".qc-total-label")).toBe("Total");
    expect(root.querySelector("input[value='logo']")).not.toBeNull();
    expect(root.querySelector("input[value='rush']")).toBeNull();
  });

  it("destroy で DOM が消える", () => {
    const { root, handle } = mount();
    handle.destroy();
    expect(root.children.length).toBe(0);
    expect(root.classList.contains("qc")).toBe(false);
  });

  it("入力中の欄は書き換えない（0 を打っても消えない）", () => {
    const { root, handle } = mount();
    const rate = root.querySelector<HTMLInputElement>("input[id$='-rate']")!;
    rate.focus();
    rate.value = "0";
    rate.dispatchEvent(new Event("input"));
    expect(rate.value).toBe("0");
    expect(handle.getBreakdown().subtotal).toBe(0);
    expect(text(root, ".qc-total")).toBe("¥0");
  });

  it("フォーカスが無い欄は setInput で同期される", () => {
    const { root, handle } = mount();
    const rate = root.querySelector<HTMLInputElement>("input[id$='-rate']")!;
    rate.blur();
    handle.setInput({ hourlyRate: 7000 });
    expect(rate.value).toBe("7000");
  });
  it("0 を打った欄は、別の操作で再描画されても消えない", () => {
    const { root, handle } = mount();
    const rate = root.querySelector<HTMLInputElement>("input[id$='-rate']")!;
    rate.focus();
    rate.value = "0";
    rate.dispatchEvent(new Event("input"));
    rate.blur();
    const box = root.querySelector<HTMLInputElement>("input[value='rush']")!;
    box.checked = true;
    box.dispatchEvent(new Event("change"));
    expect(rate.value).toBe("0");
    expect(handle.getInput().hourlyRate).toBe(0);
  });

  it("打ち込んだ末尾の 0（2.0）は、再描画で 2 に削られない", () => {
    const { root, handle } = mount();
    const effort = root.querySelector<HTMLInputElement>("input[id$='-effort']")!;
    effort.focus();
    effort.value = "2.0";
    effort.dispatchEvent(new Event("input"));
    effort.blur();
    handle.setInput({ includeTax: false });
    expect(effort.value).toBe("2.0");
    expect(handle.getInput().effort).toBe(2);
  });

  it("小数を一文字ずつ打てる（2 → 2. → 2.0 → 2.05）", () => {
    const { root, handle } = mount();
    const effort = root.querySelector<HTMLInputElement>("input[id$='-effort']")!;
    effort.focus();
    effort.value = "2";
    effort.dispatchEvent(new Event("input"));
    // type=number は Chrome / Firefox / Safari / jsdom のいずれも "2." を不正な浮動小数として
    // value = ""（badInput）と報告する。表示は "2." のまま残る
    effort.value = "2.";
    expect(effort.value).toBe("");
    effort.dispatchEvent(new Event("input"));
    effort.value = "2.0";
    effort.dispatchEvent(new Event("input"));
    expect(effort.value).toBe("2.0");
    expect(handle.getInput().effort).toBe(2);
    effort.value = "2.05";
    effort.dispatchEvent(new Event("input"));
    expect(handle.getInput().effort).toBe(2.05);
    expect(text(root, ".qc-total")).toBe("¥11,275");
  });

  it("shadow root の中でも、打った 0 は消えない", () => {
    const host = document.createElement("div");
    document.body.append(host);
    const root = document.createElement("div");
    host.attachShadow({ mode: "open" }).append(root);
    const handle = mountQuoteCalculator(root);
    const rate = root.querySelector<HTMLInputElement>("input[id$='-rate']")!;
    rate.focus();
    rate.value = "0";
    rate.dispatchEvent(new Event("input"));
    expect(rate.value).toBe("0");
    expect(handle.getBreakdown().subtotal).toBe(0);
  });

  it("明細に切り替えると明細ブロックだけ見える", () => {
    const { root, handle } = mount();
    handle.setInput({ mode: "items" });
    expect(root.querySelector<HTMLElement>(".qc-block-hourly")!.hidden).toBe(true);
    expect(root.querySelector<HTMLElement>(".qc-block-fixed")!.hidden).toBe(true);
    expect(root.querySelector<HTMLElement>(".qc-block-items")!.hidden).toBe(false);
    expect(root.querySelector<HTMLElement>(".qc-block-reverse")!.hidden).toBe(true);
    // 既定の明細 1 行（デザイン 1 × 50,000）+ 税
    expect(text(root, ".qc-total")).toBe("¥55,000");
  });

  it("税込から逆算に切り替えるとオプション・値引き・税のチェックが隠れる", () => {
    const { root, handle } = mount();
    handle.setInput({ mode: "reverse" });
    expect(root.querySelector<HTMLElement>(".qc-block-reverse")!.hidden).toBe(false);
    expect(root.querySelector<HTMLElement>(".qc-options")!.parentElement!.hidden).toBe(true);
    expect(root.querySelector<HTMLElement>(".qc-discount")!.hidden).toBe(true);
    expect(root.querySelector<HTMLElement>(".qc-tax")!.hidden).toBe(true);
    expect([...root.querySelectorAll(".qc-row-label")].map((e) => e.textContent)).toEqual([
      "税込金額",
      "消費税（10%）",
      "税抜金額",
    ]);
    expect(text(root, ".qc-total")).toBe("¥110,000");
    expect(text(root, ".qc-total-label")).toBe("合計（税込）");
  });

  it("逆算の税込金額を打ち替えると税抜が変わる", () => {
    const { root, handle } = mount();
    handle.setInput({ mode: "reverse" });
    const field = root.querySelector<HTMLInputElement>("input[id$='-taxincluded']")!;
    field.value = "220000";
    field.dispatchEvent(new Event("input"));
    expect(handle.getBreakdown().taxableTotal).toBe(200000);
    expect(text(root, ".qc-total")).toBe("¥220,000");
  });

  it("明細は行を足せて消せる", () => {
    const { root, handle } = mount();
    handle.setInput({ mode: "items" });
    expect(root.querySelectorAll(".qc-item").length).toBe(1);

    root.querySelector<HTMLButtonElement>(".qc-add-item")!.click();
    expect(root.querySelectorAll(".qc-item").length).toBe(2);
    expect(handle.getInput().items.length).toBe(2);

    const rows = [...root.querySelectorAll<HTMLElement>(".qc-item")];
    const label = rows[1].querySelector<HTMLInputElement>(".qc-item-label")!;
    const qty = rows[1].querySelector<HTMLInputElement>(".qc-item-qty")!;
    const price = rows[1].querySelector<HTMLInputElement>(".qc-item-price")!;
    label.value = "撮影";
    label.dispatchEvent(new Event("input"));
    qty.value = "2";
    qty.dispatchEvent(new Event("input"));
    price.value = "30000";
    price.dispatchEvent(new Event("input"));
    expect(handle.getBreakdown().subtotal).toBe(110000);
    expect(text(root, ".qc-total")).toBe("¥121,000");

    // 1 行目を消すと、残った行の値が繰り上がって表示される
    rows[0].querySelector<HTMLButtonElement>(".qc-item-remove")!.click();
    expect(root.querySelectorAll(".qc-item").length).toBe(1);
    expect(handle.getInput().items).toEqual([{ label: "撮影", qty: 2, unitPrice: 30000 }]);
    expect(root.querySelector<HTMLInputElement>(".qc-item-label")!.value).toBe("撮影");
    expect(handle.getBreakdown().subtotal).toBe(60000);
  });

  it("値引きは内訳に − の行で出て、単位を % に変えられる", () => {
    const { root, handle } = mount();
    const field = root.querySelector<HTMLInputElement>("input[id$='-discount']")!;
    field.value = "5000";
    field.dispatchEvent(new Event("input"));
    expect([...root.querySelectorAll(".qc-row-label")].map((e) => e.textContent)).toEqual([
      "小計",
      "値引き",
      "消費税（10%）",
    ]);
    expect(root.querySelector(".qc-row-minus .qc-row-value")!.textContent).toBe("−¥5,000");
    expect(text(root, ".qc-total")).toBe("¥49,500");

    const percent = root.querySelector<HTMLInputElement>(".qc-discount-kind input[value='percent']")!;
    percent.checked = true;
    percent.dispatchEvent(new Event("change"));
    // 5,000% は 100% で止まる
    expect(handle.getBreakdown().discount).toBe(50000);
    expect(root.querySelector<HTMLElement>(".qc-discount .qc-suffix")!.textContent).toBe("%");
  });

  it("discount.show が false なら値引きの欄を出さない", () => {
    const { root } = mount({ discount: { show: false } });
    expect(root.querySelector(".qc-discount")).toBeNull();
  });

  it("税率 8% に切り替えると税額とラベルが変わる", () => {
    const { root, handle } = mount();
    const eight = root.querySelector<HTMLInputElement>(".qc-tax-rate input[value='1']")!;
    eight.checked = true;
    eight.dispatchEvent(new Event("change"));
    expect(handle.getInput().taxRate).toBe(0.08);
    expect([...root.querySelectorAll(".qc-row-label")].map((e) => e.textContent)).toEqual(["小計", "消費税（8%）"]);
    expect(text(root, ".qc-total")).toBe("¥54,000");
  });

  it("税率の選択肢が 1 つなら切替を出さない", () => {
    const { root } = mount({ tax: { choices: [{ label: "10%", rate: 0.1 }] } });
    expect(root.querySelector(".qc-tax-rate")).toBeNull();
  });

  it("源泉徴収にチェックを入れると合計の下に 2 行出る", () => {
    const { root, handle } = mount();
    const box = root.querySelector<HTMLInputElement>(".qc-withholding input")!;
    box.checked = true;
    box.dispatchEvent(new Event("change"));
    expect(handle.getBreakdown().withholding).toBe(5105);
    expect([...root.querySelectorAll(".qc-rows-after .qc-row-label")].map((e) => e.textContent)).toEqual([
      "源泉徴収（10.21%）",
      "差引お支払額",
    ]);
    expect([...root.querySelectorAll(".qc-rows-after .qc-row-value")].map((e) => e.textContent)).toEqual([
      "−¥5,105",
      "¥49,895",
    ]);
    expect(text(root, ".qc-total")).toBe("¥55,000");
  });

  it("源泉徴収の行ラベルは、税抜合計が 100 万円を超えると切り替わる", () => {
    const { root, handle } = mount();
    const box = root.querySelector<HTMLInputElement>(".qc-withholding input")!;
    box.checked = true;
    box.dispatchEvent(new Event("change"));
    expect([...root.querySelectorAll(".qc-rows-after .qc-row-label")].map((e) => e.textContent)).toEqual([
      "源泉徴収（10.21%）",
      "差引お支払額",
    ]);

    handle.setInput({ mode: "fixed", fixedPrice: 1500000 });
    expect(handle.getBreakdown().withholding).toBe(204200);
    expect([...root.querySelectorAll(".qc-rows-after .qc-row-label")].map((e) => e.textContent)).toEqual([
      "源泉徴収（10.21%、¥1,000,000 を超える分は 20.42%）",
      "差引お支払額",
    ]);
  });

  it("源泉徴収の行は aria-live=\"polite\" で、切り替えたことがスクリーンリーダーに伝わる", () => {
    const { root } = mount();
    expect(root.querySelector(".qc-rows-after")?.getAttribute("aria-live")).toBe("polite");
  });

  it("見積書の宛名と件名を打てて、印刷ボタンがある", () => {
    const { root, handle } = mount();
    const client = root.querySelector<HTMLInputElement>("input[id$='-client']")!;
    client.value = "株式会社れい";
    client.dispatchEvent(new Event("input"));
    expect(handle.getInput().sheet.client).toBe("株式会社れい");
    expect(root.querySelector<HTMLInputElement>("input[id$='-subject']")!.value).toBe("お見積もり");
    expect(root.querySelector(".qc-print")!.textContent).toBe("見積書を印刷（PDF 保存）");
  });

  it("ポップアップが開けないと注意書きが出る", () => {
    const spy = vi.spyOn(window, "open").mockReturnValue(null);
    try {
      const { root, handle } = mount();
      const note = root.querySelector<HTMLElement>(".qc-sheet .qc-note")!;
      expect(note.hidden).toBe(true);
      root.querySelector<HTMLButtonElement>(".qc-print")!.click();
      expect(note.hidden).toBe(false);
      expect(note.textContent).toBe("ポップアップを許可してください");
      expect(handle.openSheet()).toBe(false);
    } finally {
      spy.mockRestore();
    }
  });

  it("コピーで clipboard に内訳が渡り、1.5 秒で文言が戻る", () => {
    vi.useFakeTimers();
    const writeText = vi.fn(() => Promise.resolve());
    Object.defineProperty(navigator, "clipboard", { value: { writeText }, configurable: true });
    try {
      const { root, handle } = mount();
      const button = root.querySelector<HTMLButtonElement>(".qc-copy")!;
      expect(button.textContent).toBe("内訳をコピー");
      button.click();
      expect(writeText).toHaveBeenCalledWith(handle.getText());
      expect(button.textContent).toBe("コピーしました");
      vi.advanceTimersByTime(1499);
      expect(button.textContent).toBe("コピーしました");
      vi.advanceTimersByTime(1);
      expect(button.textContent).toBe("内訳をコピー");
      expect(root.querySelector<HTMLElement>(".qc-copy-fallback")!.hidden).toBe(true);
    } finally {
      vi.useRealTimers();
      delete (navigator as { clipboard?: unknown }).clipboard;
    }
  });

  it("clipboard が無ければ textarea に出して選択する", () => {
    const { root, handle } = mount();
    const fallback = root.querySelector<HTMLTextAreaElement>(".qc-copy-fallback")!;
    expect(fallback.hidden).toBe(true);
    root.querySelector<HTMLButtonElement>(".qc-copy")!.click();
    expect(fallback.hidden).toBe(false);
    expect(fallback.value).toBe(handle.getText());
  });

  it("contact.email があるときだけ問い合わせのリンクが出る", () => {
    expect(mount().root.querySelector(".qc-contact")).toBeNull();

    const c = { contact: { email: "hello@example.com" } };
    const { root, handle } = mount(c);
    const link = root.querySelector<HTMLAnchorElement>(".qc-contact")!;
    expect(link.textContent).toBe("この内容で問い合わせる");
    expect(link.getAttribute("href")).toBe(mailtoHref(handle.getText(), resolveConfig(c)));
    // 入力が変わると href も更新される
    handle.setInput({ hourlyRate: 8000 });
    expect(link.getAttribute("href")).toBe(mailtoHref(handle.getText(), resolveConfig(c)));
  });

  it("getText() は quoteText と同じ", () => {
    const { handle } = mount();
    expect(handle.getText()).toBe(quoteText(handle.getInput(), handle.getBreakdown(), resolveConfig()));
    expect(handle.getText().startsWith("お見積もり\n時間単価 ¥5,000 × 10 時間\n小計: ¥50,000\n")).toBe(true);
  });
});
