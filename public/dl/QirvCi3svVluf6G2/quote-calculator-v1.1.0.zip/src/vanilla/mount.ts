import {
  resolveConfig,
  type DeepPartial,
  type DiscountKind,
  type EffortUnit,
  type LineItem,
  type PricingMode,
  type QuoteConfig,
} from "../config";
import { formatMoney, labelWithRate } from "../format";
import { calculateQuote, initialInput, isTaxOn, type QuoteBreakdown, type QuoteInput } from "../quote";
import { openQuoteSheet, quoteSheetHtml } from "../sheet";
import { mailtoHref, quoteText, withholdingRowLabel } from "../text";

export type QuoteCalculatorListener = (input: QuoteInput, breakdown: QuoteBreakdown) => void;

export type QuoteCalculatorHandle = {
  getInput(): QuoteInput;
  getBreakdown(): QuoteBreakdown;
  setInput(patch: Partial<QuoteInput>): void;
  /** 「内訳をコピー」と同じ文章 */
  getText(): string;
  /** 印刷用の見積書を別タブで開く。ポップアップを塞がれていたら false */
  openSheet(): boolean;
  subscribe(listener: QuoteCalculatorListener): () => void;
  destroy(): void;
};

/** U+2212 */
const MINUS = "−";
/** 「コピーしました」を出しておく長さ */
const COPIED_MS = 1500;

/**
 * 見積もり電卓を root の中に描く。描画実装はここ一つだけで、React ラッパーもこれを呼ぶ。
 * DOM の生成は一度だけ。入力が変わるたびに内訳（右側）だけを描き直す。
 * 例外は明細の行で、行数が変わったときだけ行の DOM を足し引きする。
 */
export function mountQuoteCalculator(
  root: HTMLElement,
  partialConfig: DeepPartial<QuoteConfig> = {},
): QuoteCalculatorHandle {
  const config = resolveConfig(partialConfig);
  const doc = root.ownerDocument;
  const prefix = `qc${Math.random().toString(36).slice(2, 8)}`;
  const listeners = new Set<QuoteCalculatorListener>();
  let input = initialInput(config);
  let breakdown = calculateQuote(input, config);
  let copyTimer: ReturnType<typeof setTimeout> | undefined;

  const h = <K extends keyof HTMLElementTagNameMap>(
    tag: K,
    className?: string,
    textContent?: string,
  ): HTMLElementTagNameMap[K] => {
    const el = doc.createElement(tag);
    if (className) el.className = className;
    if (textContent !== undefined) el.textContent = textContent;
    return el;
  };

  const fieldset = (legend: string) => {
    const el = h("fieldset", "qc-group");
    el.append(h("legend", "qc-legend", legend));
    return el;
  };

  /**
   * 表示と値が数値として同じなら触らない。文字列で比べると "0" → ""、"2.0" → "2" のように
   * 打った文字を消してしまう。入力途中の "2." は各エンジンとも value を "" と報告するので 0 と一致する。
   * フォーカス判定に頼ると blur 後の再描画や shadow root 内（activeElement がホストになる）で再発する
   */
  const setNumber = (el: HTMLInputElement, value: number) => {
    if (Number(el.value) === value) return;
    el.value = value > 0 ? String(value) : "";
  };

  const numberInput = (onChange: (value: number) => void) => {
    const el = h("input", "qc-input");
    el.type = "number";
    el.min = "0";
    el.inputMode = "numeric";
    el.addEventListener("input", () => onChange(el.value === "" ? 0 : Number(el.value)));
    return el;
  };

  const radioGroup = <T extends string>(
    name: string,
    choices: [T, string][],
    onChange: (value: T) => void,
    ariaLabel: string,
  ) => {
    const el = h("div", "qc-segments");
    el.setAttribute("role", "radiogroup");
    el.setAttribute("aria-label", ariaLabel);
    const inputs = new Map<T, HTMLInputElement>();
    choices.forEach(([value, label], index) => {
      const id = `${name}-${index}`;
      const wrap = h("label", "qc-segment");
      wrap.htmlFor = id;
      const radio = h("input");
      radio.type = "radio";
      radio.name = name;
      radio.id = id;
      radio.value = value;
      radio.addEventListener("change", () => {
        if (radio.checked) onChange(value);
      });
      wrap.append(radio, h("span", undefined, label));
      el.append(wrap);
      inputs.set(value, radio);
    });
    return {
      el,
      set(value: T) {
        inputs.forEach((radio, key) => {
          radio.checked = key === value;
        });
      },
    };
  };

  const numberField = (id: string, label: string, suffix: string, onChange: (value: number) => void) => {
    const el = h("div", "qc-field");
    const labelEl = h("label", "qc-field-label", label);
    labelEl.htmlFor = id;
    const row = h("div", "qc-field-row");
    const inputEl = numberInput(onChange);
    inputEl.id = id;
    const suffixEl = h("span", "qc-suffix", suffix);
    row.append(inputEl, suffixEl);
    el.append(labelEl, row);
    return {
      el,
      suffix: suffixEl,
      set(value: number) {
        setNumber(inputEl, value);
      },
    };
  };

  const textField = (id: string, label: string, onChange: (value: string) => void) => {
    const el = h("div", "qc-field");
    const labelEl = h("label", "qc-field-label", label);
    labelEl.htmlFor = id;
    const inputEl = h("input", "qc-input");
    inputEl.type = "text";
    inputEl.id = id;
    inputEl.addEventListener("input", () => onChange(inputEl.value));
    el.append(labelEl, inputEl);
    return {
      el,
      set(value: string) {
        // 文字列はそのまま比べてよい（数値欄のような "0" → "" の消え方をしない）
        if (inputEl.value === value) return;
        inputEl.value = value;
      },
    };
  };

  // ---- 入力側 -------------------------------------------------------------
  const form = h("form", "qc-form");
  form.addEventListener("submit", (event) => event.preventDefault());

  const modeGroup = fieldset(config.labels.mode);
  const modeRadios = radioGroup<PricingMode>(
    `${prefix}-mode`,
    [
      ["hourly", config.labels.hourly],
      ["fixed", config.labels.fixed],
      ["items", config.labels.items],
      ["reverse", config.labels.reverse],
    ],
    (mode) => update({ mode }),
    config.labels.mode,
  );
  modeGroup.append(modeRadios.el);

  const hourlyBlock = h("div", "qc-block qc-block-hourly");
  const rateField = numberField(`${prefix}-rate`, config.labels.hourlyRate, config.labels.perHour, (v) =>
    update({ hourlyRate: v }),
  );
  const effortField = numberField(`${prefix}-effort`, config.labels.effort, config.labels.hours, (v) =>
    update({ effort: v }),
  );
  const unitRadios = radioGroup<EffortUnit>(
    `${prefix}-unit`,
    [["hours", config.labels.hours], ["days", config.labels.days]],
    (effortUnit) => update({ effortUnit }),
    config.labels.effort,
  );
  const daysNote = h("p", "qc-note", config.labels.daysNote.replace("{hoursPerDay}", String(config.hoursPerDay)));
  hourlyBlock.append(rateField.el, effortField.el, unitRadios.el, daysNote);

  const fixedBlock = h("div", "qc-block qc-block-fixed");
  const fixedField = numberField(`${prefix}-fixed`, config.labels.fixedPrice, config.currency.symbol, (v) =>
    update({ fixedPrice: v }),
  );
  fixedBlock.append(fixedField.el);

  // ---- 明細 ---------------------------------------------------------------
  type ItemRow = { el: HTMLLIElement; label: HTMLInputElement; qty: HTMLInputElement; unitPrice: HTMLInputElement };
  const itemRows: ItemRow[] = [];

  const itemsBlock = h("div", "qc-block qc-block-items");
  const itemList = h("ul", "qc-items");
  const addItemButton = h("button", "qc-add-item", config.labels.addItem);
  addItemButton.type = "button";
  addItemButton.addEventListener("click", () => {
    update({ items: [...input.items, { label: "", qty: 1, unitPrice: 0 }] });
  });
  itemsBlock.append(h("p", "qc-field-label", config.labels.items), itemList, addItemButton);

  // 行は末尾からしか足し引きしないので、位置は毎回 itemRows の並びから引き直す
  function patchItem(row: ItemRow, patch: Partial<LineItem>) {
    const index = itemRows.indexOf(row);
    if (index < 0) return;
    update({ items: input.items.map((item, i) => (i === index ? { ...item, ...patch } : item)) });
  }

  function removeItem(row: ItemRow) {
    const index = itemRows.indexOf(row);
    if (index < 0) return;
    update({ items: input.items.filter((_, i) => i !== index) });
  }

  function buildItemRow(): ItemRow {
    const el = h("li", "qc-item");
    const label = h("input", "qc-input qc-item-label");
    label.type = "text";
    label.setAttribute("aria-label", config.labels.itemLabel);
    const row = { el } as ItemRow;
    const qty = numberInput((value) => patchItem(row, { qty: value }));
    qty.classList.add("qc-item-qty");
    qty.setAttribute("aria-label", config.labels.itemQty);
    const unitPrice = numberInput((value) => patchItem(row, { unitPrice: value }));
    unitPrice.classList.add("qc-item-price");
    unitPrice.setAttribute("aria-label", config.labels.itemUnitPrice);
    const remove = h("button", "qc-item-remove", config.labels.removeItem);
    remove.type = "button";
    label.addEventListener("input", () => patchItem(row, { label: label.value }));
    remove.addEventListener("click", () => removeItem(row));
    row.label = label;
    row.qty = qty;
    row.unitPrice = unitPrice;
    el.append(label, qty, unitPrice, remove);
    return row;
  }

  /** 行数が変わったときだけ DOM を足し引きし、値は毎回入れ直す（入力中の文字は setNumber が守る） */
  function syncItemRows() {
    while (itemRows.length > input.items.length) {
      const row = itemRows.pop();
      row?.el.remove();
    }
    while (itemRows.length < input.items.length) {
      const row = buildItemRow();
      itemRows.push(row);
      itemList.append(row.el);
    }
    itemRows.forEach((row, index) => {
      const item = input.items[index];
      if (row.label.value !== item.label) row.label.value = item.label;
      setNumber(row.qty, item.qty);
      setNumber(row.unitPrice, item.unitPrice);
    });
  }

  // ---- 税込から逆算 -------------------------------------------------------
  const reverseBlock = h("div", "qc-block qc-block-reverse");
  const taxIncludedField = numberField(
    `${prefix}-taxincluded`,
    config.labels.taxIncludedPrice,
    config.currency.symbol,
    (v) => update({ taxIncludedPrice: v }),
  );
  reverseBlock.append(taxIncludedField.el);

  // ---- 追加オプション -----------------------------------------------------
  const optionsGroup = fieldset(config.labels.options);
  const optionList = h("ul", "qc-options");
  const optionBoxes = new Map<string, HTMLInputElement>();
  for (const option of config.options) {
    const item = h("li");
    const wrap = h("label", "qc-option");
    const box = h("input");
    box.type = "checkbox";
    box.value = option.id;
    box.addEventListener("change", () => toggleOption(option.id, box.checked));
    wrap.append(
      box,
      h("span", "qc-option-label", option.label),
      h("span", "qc-option-rate", `+${Math.round(option.rate * 100)}%`),
    );
    item.append(wrap);
    optionList.append(item);
    optionBoxes.set(option.id, box);
  }
  optionsGroup.append(optionList);

  // ---- 値引き -------------------------------------------------------------
  const discountBlock = h("div", "qc-discount");
  const discountField = numberField(`${prefix}-discount`, config.labels.discount, config.labels.discountAmount, (v) =>
    update({ discount: { ...input.discount, value: v } }),
  );
  const discountKindRadios = radioGroup<DiscountKind>(
    `${prefix}-discountkind`,
    [["amount", config.labels.discountAmount], ["percent", config.labels.discountPercent]],
    (kind) => update({ discount: { ...input.discount, kind } }),
    config.labels.discount,
  );
  discountKindRadios.el.classList.add("qc-discount-kind");
  discountBlock.append(discountField.el, discountKindRadios.el);

  // ---- 税 -----------------------------------------------------------------
  const taxWrap = h("label", "qc-tax");
  const taxBox = h("input");
  taxBox.type = "checkbox";
  taxBox.addEventListener("change", () => update({ includeTax: taxBox.checked }));
  taxWrap.append(taxBox, h("span", undefined, config.labels.includeTax.replace("{taxLabel}", config.tax.label)));

  const taxRateGroup = fieldset(config.labels.taxRate);
  const taxRateRadios = radioGroup<string>(
    `${prefix}-taxrate`,
    config.tax.choices.map((choice, index) => [String(index), choice.label] as [string, string]),
    (value) => update({ taxRate: config.tax.choices[Number(value)].rate }),
    config.labels.taxRate,
  );
  taxRateRadios.el.classList.add("qc-tax-rate");
  taxRateGroup.append(taxRateRadios.el);

  // ---- 源泉徴収 -----------------------------------------------------------
  const withholdingWrap = h("label", "qc-withholding");
  const withholdingBox = h("input");
  withholdingBox.type = "checkbox";
  withholdingBox.addEventListener("change", () => update({ withholding: withholdingBox.checked }));
  withholdingWrap.append(withholdingBox, h("span", undefined, config.labels.withholding));

  // ---- 見積書 -------------------------------------------------------------
  const sheetGroup = fieldset(config.labels.sheet);
  sheetGroup.classList.add("qc-sheet");
  const clientField = textField(`${prefix}-client`, config.labels.client, (value) =>
    update({ sheet: { ...input.sheet, client: value } }),
  );
  const subjectField = textField(`${prefix}-subject`, config.labels.subject, (value) =>
    update({ sheet: { ...input.sheet, subject: value } }),
  );
  const printButton = h("button", "qc-button qc-print", config.labels.printSheet);
  printButton.type = "button";
  const popupNote = h("p", "qc-note", config.labels.popupBlocked);
  popupNote.hidden = true;
  printButton.addEventListener("click", () => {
    popupNote.hidden = openSheet();
  });
  sheetGroup.append(clientField.el, subjectField.el, printButton, popupNote);

  // ---- 操作 ---------------------------------------------------------------
  const actions = h("div", "qc-actions");
  const copyButton = h("button", "qc-button qc-copy", config.labels.copy);
  copyButton.type = "button";
  copyButton.addEventListener("click", onCopy);
  const copyFallback = h("textarea", "qc-copy-fallback");
  copyFallback.readOnly = true;
  copyFallback.rows = 8;
  copyFallback.hidden = true;
  const contactLink =
    config.contact.email.trim() === "" ? null : h("a", "qc-button qc-contact", config.labels.contact);
  actions.append(copyButton);
  if (contactLink) actions.append(contactLink);
  actions.append(copyFallback);

  form.append(modeGroup, hourlyBlock, fixedBlock, itemsBlock, reverseBlock, optionsGroup);
  if (config.discount.show) form.append(discountBlock);
  form.append(taxWrap);
  if (config.tax.choices.length > 1) form.append(taxRateGroup);
  if (config.withholding.show) form.append(withholdingWrap);
  if (config.sheet.show) form.append(sheetGroup);
  form.append(actions);

  // ---- 内訳側 -------------------------------------------------------------
  const summary = h("aside", "qc-summary");
  summary.setAttribute("aria-label", config.labels.breakdown);
  const rows = h("dl", "qc-rows");
  const totalLabel = h("p", "qc-total-label");
  const total = h("p", "qc-total");
  total.setAttribute("aria-live", "polite");
  // 源泉徴収と差引お支払額は合計の下に置く。源泉徴収ありの切り替えで行が増減するので読み上げさせる
  const afterRows = h("dl", "qc-rows qc-rows-after");
  afterRows.setAttribute("aria-live", "polite");
  summary.append(h("h2", "qc-summary-head", config.labels.breakdown), rows, totalLabel, total, afterRows);

  root.classList.add("qc");
  root.append(form, summary);

  // ---- 状態 ---------------------------------------------------------------
  function toggleOption(id: string, on: boolean) {
    const others = input.selectedOptionIds.filter((value) => value !== id);
    update({ selectedOptionIds: on ? [...others, id] : others });
  }

  function update(patch: Partial<QuoteInput>) {
    input = { ...input, ...patch };
    render();
    listeners.forEach((listener) => listener(input, breakdown));
  }

  function currentText() {
    return quoteText(input, breakdown, config);
  }

  function openSheet(): boolean {
    return openQuoteSheet(quoteSheetHtml(input, breakdown, config, new Date()), doc.defaultView);
  }

  function onCopy() {
    const text = currentText();
    const clipboard = doc.defaultView?.navigator?.clipboard;
    if (clipboard && typeof clipboard.writeText === "function") {
      // 権限が無くて失敗しても画面は壊さない
      clipboard.writeText(text).catch(() => undefined);
      copyFallback.hidden = true;
      copyButton.textContent = config.labels.copied;
      if (copyTimer !== undefined) clearTimeout(copyTimer);
      copyTimer = setTimeout(() => {
        copyButton.textContent = config.labels.copy;
        copyTimer = undefined;
      }, COPIED_MS);
      return;
    }
    // http や古いブラウザでは clipboard が無い。選択済みの textarea を出して手で複製してもらう
    copyFallback.value = text;
    copyFallback.hidden = false;
    copyFallback.select();
  }

  function addRow(list: HTMLElement, label: string, value: string, minus = false) {
    const row = h("div", minus ? "qc-row qc-row-minus" : "qc-row");
    row.append(h("dt", "qc-row-label", label), h("dd", "qc-row-value", value));
    list.append(row);
  }

  function render() {
    breakdown = calculateQuote(input, config);
    const reverse = input.mode === "reverse";
    const taxOn = isTaxOn(input);
    const money = (amount: number) => formatMoney(amount, config.currency);

    modeRadios.set(input.mode);
    hourlyBlock.hidden = input.mode !== "hourly";
    fixedBlock.hidden = input.mode !== "fixed";
    itemsBlock.hidden = input.mode !== "items";
    reverseBlock.hidden = !reverse;
    rateField.set(input.hourlyRate);
    effortField.set(input.effort);
    effortField.suffix.textContent = input.effortUnit === "days" ? config.labels.days : config.labels.hours;
    unitRadios.set(input.effortUnit);
    daysNote.hidden = input.effortUnit !== "days";
    fixedField.set(input.fixedPrice);
    taxIncludedField.set(input.taxIncludedPrice);
    syncItemRows();

    optionsGroup.hidden = reverse;
    optionBoxes.forEach((box, id) => {
      box.checked = input.selectedOptionIds.includes(id);
    });

    discountBlock.hidden = reverse;
    discountField.set(input.discount.value);
    discountField.suffix.textContent =
      input.discount.kind === "percent" ? config.labels.discountPercent : config.labels.discountAmount;
    discountKindRadios.set(input.discount.kind);

    taxWrap.hidden = reverse;
    taxBox.checked = input.includeTax;
    // 浮動小数で書いた税率（0.1 と 0.1 + 1e-12）を取り違えないよう、幅を持たせて突き合わせる
    const activeRate = config.tax.choices.findIndex((choice) => Math.abs(choice.rate - breakdown.taxRate) < 1e-9);
    taxRateRadios.set(String(activeRate));

    withholdingBox.checked = input.withholding;
    clientField.set(input.sheet.client);
    subjectField.set(input.sheet.subject);
    if (contactLink) contactLink.href = mailtoHref(currentText(), config);

    rows.replaceChildren();
    afterRows.replaceChildren();
    const taxRowLabel = labelWithRate(config.tax.label, breakdown.taxRate);
    if (reverse) {
      addRow(rows, config.labels.taxIncludedPrice, money(breakdown.total));
      addRow(rows, taxRowLabel, money(breakdown.tax));
      addRow(rows, config.labels.taxExcluded, money(breakdown.taxableTotal));
    } else {
      addRow(rows, config.labels.subtotal, money(breakdown.subtotal));
      for (const line of breakdown.optionLines) addRow(rows, line.label, `+${money(line.amount)}`);
      if (breakdown.discount > 0) {
        addRow(rows, config.labels.discount, `${MINUS}${money(breakdown.discount)}`, true);
      }
      if (taxOn) addRow(rows, taxRowLabel, money(breakdown.tax));
    }
    totalLabel.textContent = taxOn ? config.labels.totalTaxIncluded : config.labels.totalTaxExcluded;
    total.textContent = money(breakdown.total);
    // 0 の行は出さない（源泉なし、または基準が 0 円）
    if (breakdown.withholding > 0) {
      addRow(afterRows, withholdingRowLabel(breakdown, config), `${MINUS}${money(breakdown.withholding)}`, true);
      addRow(afterRows, config.labels.payable, money(breakdown.payable));
    }
  }

  render();

  return {
    getInput: () => ({
      ...input,
      items: input.items.map((item) => ({ ...item })),
      selectedOptionIds: [...input.selectedOptionIds],
      discount: { ...input.discount },
      sheet: { ...input.sheet },
    }),
    getBreakdown: () => breakdown,
    setInput: (patch) => update(patch),
    getText: () => currentText(),
    openSheet,
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    destroy() {
      listeners.clear();
      if (copyTimer !== undefined) clearTimeout(copyTimer);
      copyTimer = undefined;
      form.remove();
      summary.remove();
      root.classList.remove("qc");
    },
  };
}
