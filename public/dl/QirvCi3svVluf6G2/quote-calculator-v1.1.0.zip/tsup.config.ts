import { defineConfig } from "tsup";

export default defineConfig([
  {
    entry: { index: "src/index.ts", react: "src/react/index.ts" },
    format: ["esm", "cjs"],
    dts: true,
    sourcemap: false,
    clean: true,
    external: ["react", "react/jsx-runtime"],
  },
  {
    entry: { "quote-calculator": "src/vanilla/global.ts" },
    format: ["iife"],
    globalName: "QuoteCalculator",
    minify: true,
    sourcemap: false,
  },
]);
