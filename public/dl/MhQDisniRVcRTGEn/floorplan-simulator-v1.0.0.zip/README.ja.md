# 間取りシミュレーター v1.0.0

自分のサイトに置ける間取りシミュレーターです。マス目を塗って間取りを描き、建具と家具を置くと、そのまま 3D に映ります。作った間取りはお使いのブラウザにだけ保存され、サーバーには送られません。

## 1. 何ができるか

- **間取りを描く**: 0.5 m のマス目をなぞると部屋になります。廊下も L 字も飛び地も描けます
- **外皮の寸法**: 間口と奥行きを 4〜16 m のあいだで決められます。平屋と 2 階建てのどちらにも
- **建具**: 3 種類（ドア・引き戸・窓）を 4 つの標準寸法（ドア・引き戸・腰窓・掃き出し窓）で。2D には記号が、3D には実際の開口が出ます。幅・高さ・窓の下端は数値で、吊元と開く側はボタンで決められます
- **設備**: クローゼット・押入・玄関収納・階段。階段は段数も変えられます
- **外周**: バルコニー・テラス・玄関ポーチ。長さと奥行きは数値で、手すりはボタンで入り切りできます
- **家具の実寸**: 18 種に標準寸法つき。幅・奥行き・高さを直に入れても構いません。テレビはインチを入れると画面の大きさになり、テレビ台の幅の目安も出ます
- **寸法の表示**: 部屋は面積と帖、選んだものは 幅 × 奥行き × 高さ。「寸法」を選んでから家具・設備・建具・外周をタップすると、その場で数値を直せます（幅・奥行きは 0.25 m、高さは 0.05 m の刻み。範囲の外は端で止まります）
- **スマホ**: 幅 960 px 未満では 3D をたたみ、「3D で見る」を押したときに開きます。間取り図は 2 本指のピンチでも拡大縮小できます
- **複数案**: 1 つの保存データに案を 10 件まで持てます
- **書き出し**: PNG（間取り図 / 3D / 両方を 1 枚）と、印刷から PDF 保存

**作っていないもの**: 家具の当たり判定と通路幅の判定、斜めの壁、3 階以上、屋根形状の選択、日影・採光のシミュレーション、共有 URL、取り消し（undo）、glTF の読み書き、AR、サーバー保存、ログイン。

## 2. コピペで置く

```html
<link rel="stylesheet" href="./floorplan-simulator.css">
<div id="floorplan"></div>
<script src="./floorplan.global.js"></script>
<script defer src="./floorplan-3d.global.js"></script>
<script>FloorplanSimulator.mount(document.getElementById("floorplan"));</script>
```

zip の `embed/` フォルダに、この 4 ファイル（`embed-snippet.html`・`floorplan.global.js`・`floorplan-3d.global.js`・`floorplan-simulator.css`）が入っています。上のコードは同じ階層のファイルを読むので、4 つはまとめて置いてください。WordPress・Webflow・静的 HTML など、script タグが書ける場所ならどこでも動きます。

**3D を外して軽くする**: `floorplan-3d.global.js` を読み込まず、`features: { scene: false }` を渡すと、間取り図だけになります。3D の部品（およそ 950 KB、gzip 転送でおよそ 250 KB）はいっさい読み込みません。間取り図だけの `floorplan.global.js` は、およそ 275 KB（gzip 転送でおよそ 86 KB）です。

```html
<script>FloorplanSimulator.mount(el, { features: { scene: false } });</script>
```

**3D は見るときだけ読み込む**: 3D は残したまま、ページの読み込みと一緒に取りに行かせたくないときは、`<script defer src="./floorplan-3d.global.js">` を書かずに置き場所だけ渡します。3D の枠を出すときに初めて読み込むので、最初の表示が軽くなります。幅 960 px 未満のスマホでは、「3D で見る」を押したときが読み込みのときです。

```html
<link rel="stylesheet" href="./floorplan-simulator.css">
<div id="floorplan"></div>
<script src="./floorplan.global.js"></script>
<script>
  FloorplanSimulator.mount(document.getElementById("floorplan"), {
    scene: { src: "./floorplan-3d.global.js" },
  });
</script>
```

どちらの置き方でも 4 ファイルは同じ階層に置いてください。`embed/embed-snippet.html` に両方の書き方を入れてあります。

## 3. 単体ページとして使う

`page/index.html` をブラウザで開くだけで使えます。サーバーも Node.js も要りません。社内で配るときは `page/` フォルダごとコピーしてください（同じ階層の 3 ファイルを読みます）。サーバーに置く場合も、`page/` をそのままアップロードするだけです。

3D の部品は最初に読み込まず、3D の枠を出すときに読み込みます（スマホでは「3D で見る」を押したときです）。間取り図が先に出ますので、電波の弱い場所でもお待たせしません。

## 4. 設定を変える

`mount(要素, 設定)` の第 2 引数に、変えたい項目だけ渡します。

| 項目 | 既定値 | 意味 |
|---|---|---|
| `plan` | なし | 初期の間取り。`PlanFile` か `PlanDoc`、その JSON 文字列 |
| `readonly` | `false` | 見せるだけにする。編集の操作列・保存・複数案を出しません |
| `storage.key` | `"suminawa-floorplan:v3"` | 保存の鍵。1 つのサイトに 2 つ置くときは分けてください |
| `storage.enabled` | `true`（`readonly` のとき、また `plan` を渡して `storage.key` を渡さないときは `false`） | `false` なら localStorage を触りません。`plan` で決まった間取りを見せる置き方では、既定の鍵に書き込まないようにしています（`storage.key` を分けて渡せば保存します） |
| `features.plans` | `true` | 複数案の操作列を出すか |
| `features.export` | `true` | PNG の書き出しを出すか |
| `features.print` | `true` | 印刷のボタンを出すか |
| `features.scene` | `true` | 3D を出すか。`false` なら 3D の部品を読み込みません |
| `features.floors` | `2` | 出す階数の上限 |
| `features.collapseBelow` | `960` | この幅（px）より狭いときは 3D をたたみ、「3D で見る」を押したときに開きます。`0` なら常に開いたまま |
| `catalog.rooms` | 19 種 | 部屋名の一覧を差し替え |
| `catalog.furniture` | 18 種 | 種類を隠す（`hidden`）・標準寸法を足す（`presets`） |
| `catalog.openings` | 4 プリセット | 建具の標準寸法を差し替え。範囲の外の値（幅 0.5〜3.5 m、下端 + 高さが天井まで）は受け取らず、元の値のままにします |
| `catalog.sizes` | 5 種 | 外皮の寸法のプリセットを差し替え |
| `scene.autoRotate` | `false` | 3D をゆっくり回すか |
| `scene.src` | なし | 3D の部品（`floorplan-3d.global.js`）の置き場所。渡すと、3D を出すときに初めて読み込みます。相対パスか `http(s)` の URL だけ受け取ります。この値はそのまま `<script src>` になります。サイト側で決めた置き場所を渡してください（来訪者が打ち込んだ文字列をそのまま渡さないでください） |
| `scene.wall` / `trim` / `roof` / `floorTone` / `interior` | 白い塗り壁の組 | 3D の中の色（`#rrggbb`） |
| `labels.*` | 日本語 | 画面の文言。英語化もここで |
| `onChange(file)` | なし | 間取りが変わるたびに呼ばれます |
| `onSelect(target)` | なし | 選んだものが変わるたびに呼ばれます |
| `onExport(result)` | なし | PNG を書き出したときに呼ばれます |

`mount` は取っ手を返します。

```js
const handle = FloorplanSimulator.mount(el);
handle.getFile();              // いまの保存データ（PlanFile）
handle.setFile(json);          // 差し替える
handle.getActivePlan();        // 表示中の案（PlanDoc）
handle.setActivePlan("plan-2");
await handle.exportPng("both");
handle.print();
const stop = handle.subscribe((file) => console.log(file));
handle.destroy();
```

## 5. 物件の間取りを見せるだけにする

物件ページには `readonly: true` と `plan` を渡します。操作列は階の切替・視点・昼夜・寸法・書き出しだけになり、間取りも家具も触れません。

```js
FloorplanSimulator.mount(el, { readonly: true, plan: 物件の JSON });
```

## 6. 間取りの JSON

保存データは次の形です（`samples/` に 3 つ入れてあります）。

```ts
type PlanFile = { version: 3; plans: PlanDoc[]; activeId: string };
type PlanDoc = {
  id: string;                    // "plan-1" の連番
  name: string;                  // 1〜30 字
  size: { width: number; depth: number; floors: 1 | 2 };  // m。0.5 の倍数、4〜16
  floors: { 1: FloorPlan; 2: FloorPlan };
};
type FloorPlan = {
  layout: { rooms: { id: string; label: string }[]; cells: string[] };  // cells は 間口÷0.5 × 奥行き÷0.5 個
  openings: Opening[];   // ドア・引き戸・窓
  fixtures: Fixture[];   // クローゼット・押入・玄関収納・階段
  exterior: ExteriorPart[];  // バルコニー・テラス・玄関ポーチ
  furniture: PlacedFurniture[];
};
```

自分で書くより、いちど画面で作って `handle.getFile()` を保存するほうが確実です。読めない JSON を渡したときは既定の間取りに戻ります（画面は落ちません）。

`samples/` の間取りはすべて架空のもので、3 つとも別の間取りです。

| ファイル | 外皮 | 間取り |
|---|---|---|
| `house-72.json` | 9 × 8 m・2 階建て | 1F: LDK・和室・玄関ホール・浴室・洗面・廊下・階段 / 2F: 主寝室・子ども部屋・書斎・ホール・階段 |
| `apartment-3ldk.json` | 12 × 6 m・1 階 | LDK + 和室・主寝室・子ども部屋 + 浴室・洗面 + 玄関ホール |
| `flat-56.json` | 8 × 7 m・平屋 | LDK + 主寝室 + 和室 + 浴室・洗面 + 玄関ホール |

平屋と 1 階だけの間取りには階段を置いていません。`npm run samples` で作り直せます。

## 7. 家具・建具のカタログを足す

```js
FloorplanSimulator.mount(el, {
  catalog: {
    furniture: {
      piano: { hidden: true },
      sofa: { presets: [{ id: "sofa-xl", name: "特大", size: { w: 2.5, d: 1, h: 0.8 } }] },
    },
    openings: { door: { kind: "door", style: null, name: "玄関ドア", width: 1, sill: 0, height: 2.2 } },
    sizes: [{ id: "own", name: "12 × 10 m", size: { width: 12, depth: 10, floors: 2 } }],
  },
});
```

## 8. React で使う

```tsx
import { FloorplanSimulator } from "@suminawa/floorplan-simulator/react";
import "@suminawa/floorplan-simulator/styles.css";

const config = { readonly: true, plan: 物件の JSON };  // 部品の外か useMemo で
<FloorplanSimulator config={config} onChange={(file) => console.log(file.plans.length)} />;
```

このパッケージは npm に公開していません。zip を展開したフォルダを `npm install ./floorplan-simulator` のようにパスで指定して入れてください。`config` は参照が変わるたびに作り直すので、定数か `useMemo` で渡します。

## 9. 見た目を変える

画面と操作列の色は CSS の変数だけで決まります。`.fp` でも、その祖先（`:root` や `body`）でも上書きできます。既定値は使う場所ごとに `var(--fp-bg, #faf8f3)` の形で持たせてあるので、祖先で決めた値がそのまま効きます。

```css
/* 例: サイトの配色に合わせる。:root でも .fp でも構いません */
:root {
  --fp-bg: #faf8f3;
  --fp-fg: #1c1a15;
  --fp-muted: #6a665d;
  --fp-brand: #4a6b7d;
  --fp-brand-ink: #2f4855;
  --fp-on-brand: #ffffff;
  --fp-line: rgba(28, 26, 21, 0.18);
  --fp-line-strong: #1c1a15;
  --fp-soft: #efece4;
  --fp-surface: #ffffff;
  --fp-input-line: rgba(28, 26, 21, 0.35);
  --fp-room: #efece4;
  --fp-room-selected: #4a6b7d;
  --fp-glyph: #6a665d;
  --fp-glyph-selected: #4a6b7d;
  --fp-dim: #6a665d;
  --fp-radius: 1rem;
  --fp-font: inherit;
}
```

上の値がそのまま既定値です。書き出した PNG と印刷用の 1 枚にも、このとき効いている色がそのまま入ります。

**3D の中の色は CSS では変わりません**（描画の仕組みが違うため）。`scene` の設定で `#rrggbb` を渡してください。

## 10. 書き出しと印刷

- **PNG**: 「間取り図」「3D」「両方を 1 枚」の 3 通り。横 2000px 相当で、ファイル名はそれぞれ `間取り-<案の名前>.png`・`間取り-<案の名前>-3D.png`・`間取り-<案の名前>-両方.png` です。案の名前はファイル名に使えない記号を `-` に置き換え、40 字までに切り詰めます（記号だけの名前は「案」になります）
- **印刷（PDF 保存）**: A4 横 1 枚を別のタブに開いて印刷画面を出します。そこで「PDF に保存」を選ぶと、そのまま送れる 1 枚になります。載るのは 案の名前・間取り図・部屋の一覧（名前・面積・帖）・家具の一覧・外皮の寸法です。2 階建てなら、画面に出していないほうの階の間取り図も一緒に載ります
- ポップアップを塞ぐ設定のブラウザでは別タブが開けないので、「ポップアップを許可してください」と出ます

## 11. 手元で動かす

Node.js 20.9 以上が要ります。

```bash
npm install
npm test          # 純粋な関数と画面のテスト
npm run typecheck # 型の検査
npm run build     # dist/ に 3 つの出口を作る
npm run release   # 配布 zip を release/ に作る
```

デモは `demo/index.html` です。`npm run build` のあと、`npx serve .` などで開いてください（`file://` では読み込みが止まる場合があります）。

## 12. ライセンス

`LICENSE.md` をご覧ください。改変は自由で、クライアントのサイトへの組み込み納品もできます。再配布・転売はできません。

## 13. 困ったら

hello@suminawa.dev までご連絡ください。3 営業日以内にお返事します。
