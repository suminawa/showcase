import { defineConfig } from "tsup";
import type { Plugin } from "esbuild";

const R3F = ["three", "@react-three/fiber", "@react-three/drei"];

// 素の HTML 用の束はブラウザで動くので、process.env.NODE_ENV を本番に固定する
// （React と three の開発用の分岐が残ると process が無いブラウザで落ちる）
const BROWSER_DEFINE = { "process.env.NODE_ENV": '"production"' };

// 3D の束（3 本目）は React を積まない。1 本目が window.FloorplanSimulator に置いた
// React をそのまま使う ── React が 2 つあると hooks と context が壊れる
const REACT_GLOBALS: Record<string, string> = {
  react: "React",
  "react/jsx-runtime": "ReactJsxRuntime",
  "react/jsx-dev-runtime": "ReactJsxRuntime",
  "react-dom": "ReactDOM",
  "react-dom/client": "ReactDOMClient",
};
const reactFromGlobal: Plugin = {
  name: "react-from-global",
  setup(build) {
    build.onResolve({ filter: /^react(-dom)?(\/(jsx-runtime|jsx-dev-runtime|client))?$/ }, (args) => ({
      path: args.path,
      namespace: "react-global",
    }));
    // 読み込みの順が逆だと window.FloorplanSimulator がまだ無い。
    // "undefined の React が読めない" ではなく、何をすればよいか分かる断りを出す
    build.onLoad({ filter: /.*/, namespace: "react-global" }, (args) => ({
      contents: [
        "var host = window.FloorplanSimulator;",
        'if (!host) throw new Error("[floorplan-simulator] floorplan.global.js を先に読み込んでください（floorplan-3d.global.js はそのあとです）");',
        `module.exports = host.${REACT_GLOBALS[args.path]};`,
      ].join("\n"),
      loader: "js",
    }));
  },
};

export default defineConfig([
  // 1) npm 用。react も three も外に出す
  {
    entry: { index: "src/index.ts", react: "src/react/index.ts" },
    format: ["esm", "cjs"],
    dts: true,
    sourcemap: false,
    clean: true,
    define: { __FP_DYNAMIC_SCENE__: "true" },
    external: ["react", "react-dom", "react/jsx-runtime", ...R3F],
  },
  // 2) 素の HTML 用（2D + 操作列 + 状態）。react を中に積み、three は積まない
  {
    entry: { floorplan: "src/vanilla/global.ts" },
    format: ["iife"],
    globalName: "FloorplanSimulator",
    minify: true,
    sourcemap: false,
    define: { __FP_DYNAMIC_SCENE__: "false", ...BROWSER_DEFINE },
    external: R3F,
  },
  // 3) 素の HTML 用の 3D。1 本目を読んだあと、3D を出すときだけ読む
  {
    entry: { "floorplan-3d": "src/scene/entry.ts" },
    format: ["iife"],
    globalName: "FloorplanSimulator3D",
    minify: true,
    sourcemap: false,
    define: { __FP_DYNAMIC_SCENE__: "false", ...BROWSER_DEFINE },
    esbuildPlugins: [reactFromGlobal],
  },
]);
