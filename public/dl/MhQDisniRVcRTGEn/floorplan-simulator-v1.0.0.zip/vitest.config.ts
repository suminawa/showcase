import { defineConfig } from "vitest/config";

export default defineConfig({
  // テストでは three の束を動的に読まない（読むと Canvas が要る）。
  // 本番のビルドでは tsup の define が true を入れる
  define: { __FP_DYNAMIC_SCENE__: "false" },
  test: {
    environment: "jsdom",
    // Node 22 以降が globalThis に置く実験的な localStorage（--localstorage-file が無いと
    // 使えない）が jsdom のものを隠すので、テストでは記憶だけの Storage に差し替える
    setupFiles: ["./test/setup.ts"],
    include: ["src/**/*.test.{ts,tsx}"],
  },
});
