#!/usr/bin/env node
// dist を含む配布 zip を release/ に作る。「手元で動かす」ができるようテストファイルも含める。
import { execFileSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/floorplan-simulator-v${pkg.version}.zip`;

for (const file of ["dist/floorplan.global.js", "dist/floorplan-3d.global.js", "dist/index.js"]) {
  if (!existsSync(file)) {
    console.error(`${file} が無い。先に npm run build`);
    process.exit(1);
  }
}
if (!existsSync("samples/house-72.json")) {
  console.error("samples が無い。先に npm run samples");
  process.exit(1);
}
mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

// embed/ と page/: コピペで置ける平らな置き方。embed/embed-snippet.html と page/index.html は
// ./floorplan.global.js のように同じ階層から読むが、zip の中では styles/ と dist/ に分かれていて
// そのままでは動かないので、ここでコピーして平らに揃える。
// demo/ の中の embed-snippet.html は同じ階層に束が無く、そのままでは開けないので zip には入れない
// （demo/index.html と demo/scene-off.html は ../dist/ を読むのでそのまま動く）
const runtime = [
  ["dist/floorplan.global.js", "floorplan.global.js"],
  ["dist/floorplan-3d.global.js", "floorplan-3d.global.js"],
  ["styles/floorplan-simulator.css", "floorplan-simulator.css"],
];
rmSync("embed", { recursive: true, force: true });
mkdirSync("embed", { recursive: true });
for (const [from, to] of runtime) {
  copyFileSync(from, `embed/${to}`);
  copyFileSync(from, `page/${to}`);
}
copyFileSync("demo/embed-snippet.html", "embed/embed-snippet.html");

execFileSync(
  "zip",
  [
    "-r",
    out,
    "dist",
    "demo",
    "page",
    "embed",
    "styles",
    "src",
    "samples",
    "scripts",
    "test",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "tsup.config.ts",
    "vitest.config.ts",
    ".gitignore",
    "README.ja.md",
    "LICENSE.md",
    "CHANGELOG.md",
    "-x",
    "*.DS_Store",
    "demo/embed-snippet.html",
  ],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
