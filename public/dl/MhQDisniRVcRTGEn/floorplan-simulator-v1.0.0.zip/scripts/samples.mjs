#!/usr/bin/env node
// samples/ の間取り JSON を、パッケージ自身の関数から作る。
// 手で書くと 288 マスの表がずれるので、必ずこのスクリプトから作ること。
// 名前はすべて架空のもので、実在の会社名・地名・物件名は入れない。
//
// 3 件はそれぞれ別の間取りにする:
//   house-72        9 × 8 m の 2 階建て。既定の間取り（1F: LDK・和室ほか / 2F: 主寝室ほか）
//   apartment-3ldk  12 × 6 m の 1 階。LDK + 和室・主寝室・子ども部屋 + 浴室・洗面 + 玄関ホール
//   flat-56         8 × 7 m の平屋。LDK + 主寝室 + 和室 + 浴室・洗面 + 玄関ホール
// 平屋には階段を置かない（defaultFloorPlan がそう組む）。
import { mkdirSync, writeFileSync } from "node:fs";
import {
  colsOf,
  defaultFloorPlan,
  parsePlanFile,
  rowsOf,
  serializePlanFile,
} from "../dist/index.js";

/**
 * 長方形の並びからマス目を組む。1 つ目の部屋で全体を埋めてから塗り重ねるので、
 * 塗り残しのマスは出ない（cells はかならず全部どれかの部屋になる）。
 * rect は [col, row, cols, rows]（マス単位）。省くとその部屋が下敷きになる。
 */
function paint(size, plans) {
  const cols = colsOf(size);
  const rows = rowsOf(size);
  const rooms = plans.map((plan, index) => ({ id: `room-${index + 1}`, label: plan.label }));
  const cells = Array.from({ length: cols * rows }, () => rooms[0].id);
  plans.forEach((plan, index) => {
    if (!plan.rect) return;
    const [col0, row0, w, d] = plan.rect;
    for (let row = row0; row < row0 + d; row++) {
      for (let col = col0; col < col0 + w; col++) cells[row * cols + col] = rooms[index].id;
    }
  });
  return { rooms, cells };
}

const SAMPLES = [
  {
    file: "house-72.json",
    name: "見本の家（72 m²）",
    size: { width: 9, depth: 8, floors: 2 },
    layouts: {},
  },
  {
    file: "apartment-3ldk.json",
    name: "集合住宅の 3LDK（72 m²）",
    size: { width: 12, depth: 6, floors: 1 },
    layouts: {
      1: [
        { label: "LDK" },
        { label: "玄関ホール", rect: [0, 0, 4, 6] },
        { label: "浴室・洗面", rect: [0, 6, 4, 6] },
        { label: "和室", rect: [4, 0, 6, 6] },
        { label: "主寝室", rect: [4, 6, 6, 6] },
        { label: "子ども部屋", rect: [10, 0, 6, 6] },
      ],
    },
  },
  {
    file: "flat-56.json",
    name: "平屋（56 m²）",
    size: { width: 8, depth: 7, floors: 1 },
    layouts: {
      1: [
        { label: "LDK", rect: [0, 0, 10, 8] },
        { label: "主寝室", rect: [0, 8, 10, 6] },
        { label: "玄関ホール", rect: [10, 0, 6, 4] },
        { label: "浴室・洗面", rect: [10, 4, 6, 5] },
        { label: "和室", rect: [10, 9, 6, 5] },
      ],
    },
  },
];

function buildDoc(sample) {
  const floors = {};
  for (const floor of [1, 2]) {
    const plans = sample.layouts[floor];
    floors[floor] = defaultFloorPlan(sample.size, floor, plans ? paint(sample.size, plans) : undefined);
  }
  return { id: "plan-1", name: sample.name, size: sample.size, floors };
}

/** 検証を通し、落ちたものがあれば作り直しを促して止める */
function check(file, doc) {
  const parsed = parsePlanFile(file);
  if (!parsed) throw new Error(`${doc.name}: parsePlanFile が受け取らなかった`);
  for (const floor of [1, 2]) {
    for (const field of ["openings", "fixtures", "exterior", "furniture"]) {
      const before = doc.floors[floor][field].length;
      const after = parsed.plans[0].floors[floor][field].length;
      if (before !== after) {
        throw new Error(`${doc.name}: ${floor}F の ${field} が ${before} → ${after} に減った`);
      }
    }
  }
  return parsed;
}

mkdirSync("samples", { recursive: true });
for (const sample of SAMPLES) {
  const doc = buildDoc(sample);
  const file = { version: 3, plans: [doc], activeId: doc.id };
  const parsed = check(file, doc);
  writeFileSync(
    `samples/${sample.file}`,
    `${JSON.stringify(JSON.parse(serializePlanFile(parsed)), null, 2)}\n`,
  );
  const rooms = parsed.plans[0].floors[1].layout.rooms.map((room) => room.label).join("・");
  console.log(`wrote samples/${sample.file}  1F: ${rooms}`);
}
