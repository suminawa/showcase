import { describe, expect, it } from "vitest";
import { defaultLayout, paintCells, type GridLayout } from "./grid";
import { ceilingOf, DEFAULT_SIZE, type PlanSize } from "./house";
import {
  addOpening,
  cycleSwing,
  moveOpening,
  nearestWallLine,
  openingFits,
  openingsOnRun,
  OPENING_MAX_WIDTH,
  OPENING_MIN_WIDTH,
  OPENING_PRESETS,
  placeOpening,
  pruneOpenings,
  removeOpening,
  resizeOpening,
  runLengthOf,
  wallAt,
  type Opening,
} from "./openings";

const SIZE: PlanSize = DEFAULT_SIZE;
const CEILING = ceilingOf(SIZE, 1);
const layout = defaultLayout(SIZE, 1);

function door(patch: Partial<Opening> = {}): Opening {
  return {
    id: "o-1",
    kind: "door",
    style: null,
    axis: "x",
    at: 5.5,
    start: 2,
    width: 0.75,
    sill: 0,
    height: 2,
    hinge: "start",
    swing: "plus",
    ...patch,
  };
}

describe("標準の建具", () => {
  it("4 種あり、寸法は決めたとおり", () => {
    expect(OPENING_PRESETS.door).toMatchObject({ kind: "door", width: 0.75, sill: 0, height: 2 });
    expect(OPENING_PRESETS.sliding).toMatchObject({ kind: "sliding", width: 1.5, sill: 0, height: 2 });
    expect(OPENING_PRESETS.koshi).toMatchObject({ kind: "window", style: "koshi", width: 1.5, sill: 0.9, height: 1.2 });
    expect(OPENING_PRESETS.hakidashi).toMatchObject({ kind: "window", style: "hakidashi", width: 1.75, sill: 0, height: 2 });
    expect(OPENING_MIN_WIDTH).toBe(0.5);
    expect(OPENING_MAX_WIDTH).toBe(3.5);
  });
});

describe("wallAt", () => {
  it("外壁はいつでも壁", () => {
    expect(wallAt(layout, SIZE, "x", 0, 0)).toBe(true);
    expect(wallAt(layout, SIZE, "x", 9, 5)).toBe(true);
    expect(wallAt(layout, SIZE, "z", 0, 3)).toBe(true);
    expect(wallAt(layout, SIZE, "z", 8, 3)).toBe(true);
  });

  it("部屋の境目は壁、同じ部屋の中は壁でない", () => {
    expect(wallAt(layout, SIZE, "x", 5.5, 0)).toBe(true);
    expect(wallAt(layout, SIZE, "x", 2, 0)).toBe(false);
    expect(wallAt(layout, SIZE, "z", 6, 0)).toBe(true);
    expect(wallAt(layout, SIZE, "z", 2, 0)).toBe(false);
  });

  it("線の外は壁でない", () => {
    expect(wallAt(layout, SIZE, "x", 5.5, 99)).toBe(false);
    expect(wallAt(layout, SIZE, "x", 5.5, -1)).toBe(false);
  });
});

describe("openingFits", () => {
  it("壁の上にあれば入る", () => {
    expect(openingFits(layout, SIZE, CEILING, [], door())).toBe(true);
  });

  it("壁の無い線には入らない", () => {
    expect(openingFits(layout, SIZE, CEILING, [], door({ at: 2 }))).toBe(false);
  });

  it("線からはみ出したら入らない", () => {
    expect(openingFits(layout, SIZE, CEILING, [], door({ start: 7.75 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ start: -0.25 }))).toBe(false);
  });

  it("ほかの建具と重なったら入らない。ignoreId で自分は外せる", () => {
    const existing = [door({ id: "o-9", start: 2 })];
    expect(openingFits(layout, SIZE, CEILING, existing, door({ id: "o-1", start: 2.5 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, existing, door({ id: "o-9", start: 2.5 }), "o-9")).toBe(true);
    // 端が触れるだけなら重なっていない
    expect(openingFits(layout, SIZE, CEILING, existing, door({ id: "o-1", start: 2.75 }))).toBe(true);
  });

  it("天井を超える建具は入らない", () => {
    expect(openingFits(layout, SIZE, CEILING, [], door({ sill: 0.9, height: 2 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ sill: 0.9, height: 1.2 }))).toBe(true);
  });

  it("幅が 0.5 未満 / 3.5 超は入らない", () => {
    expect(openingFits(layout, SIZE, CEILING, [], door({ width: 0.25 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ width: 3.75 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ start: 0, width: 3.5 }))).toBe(true);
  });

  it("刻みに乗っていない位置・寸法は入らない", () => {
    expect(openingFits(layout, SIZE, CEILING, [], door({ start: 2.1 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ width: 0.8 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ at: 5.25 }))).toBe(false);
    expect(openingFits(layout, SIZE, CEILING, [], door({ height: 2.03 }))).toBe(false);
  });

  it("走りの長さは軸で変わる", () => {
    expect(runLengthOf(SIZE, "x")).toBe(8);
    expect(runLengthOf(SIZE, "z")).toBe(9);
  });
});

describe("置く・動かす・大きさを変える・消す", () => {
  it("addOpening は入るときだけ足し、id を連番で付ける", () => {
    const first = addOpening(layout, SIZE, CEILING, [], door({ id: "" }));
    expect(first).toHaveLength(1);
    expect(first[0].id).toBe("o-1");
    const bad = addOpening(layout, SIZE, CEILING, first, door({ id: "", at: 2 }));
    expect(bad).toBe(first);
  });

  it("moveOpening は 0.25 に丸め、入らない位置では同じ参照を返す", () => {
    // x = 5.5 の壁は 1F の奥行き全長にわたって壁なので、動かす先を塞ぐ建具を
    // 反対の端に置いて初めて「入らない」を再現できる。
    const list = addOpening(
      layout,
      SIZE,
      CEILING,
      addOpening(layout, SIZE, CEILING, [], door({ id: "" })),
      door({ id: "", start: 7.25 }),
    );
    const moved = moveOpening(layout, SIZE, CEILING, list, "o-1", 3.13);
    expect(moved[0].start).toBe(3.25);
    expect(moveOpening(layout, SIZE, CEILING, list, "o-1", 99)).toBe(list);
  });

  it("resizeOpening は幅・高さ・下端・開き勝手を変える", () => {
    const list = addOpening(layout, SIZE, CEILING, [], door({ id: "" }));
    const wider = resizeOpening(layout, SIZE, CEILING, list, "o-1", { width: 1.5 });
    expect(wider[0].width).toBe(1.5);
    // sill の上限は天井高 − OPENING_MIN_HEIGHT を超えないので、height はどんな値でも
    // 天井までクランプされて必ず入る（拒否されて同じ参照になることはない）。
    expect(resizeOpening(layout, SIZE, CEILING, list, "o-1", { height: 9 })[0].height).toBe(2.7);
    const swung = resizeOpening(layout, SIZE, CEILING, list, "o-1", { hinge: "end", swing: "minus" });
    expect(swung[0]).toMatchObject({ hinge: "end", swing: "minus" });
  });

  it("removeOpening は消す", () => {
    const list = addOpening(layout, SIZE, CEILING, [], door({ id: "" }));
    expect(removeOpening(list, "o-1")).toEqual([]);
    expect(removeOpening(list, "o-9")).toHaveLength(1);
  });
});

describe("pruneOpenings", () => {
  it("塗り替えで壁が消えた建具だけを落とす", () => {
    const list: Opening[] = [
      door({ id: "o-1", axis: "x", at: 5.5, start: 2 }),
      door({ id: "o-2", axis: "z", at: 0, start: 2 }),
    ];
    expect(pruneOpenings(layout, SIZE, CEILING, list)).toBe(list);
    // 東側をすべて LDK にすると、x = 5.5 の壁が消える
    const merged: GridLayout = paintCells(
      SIZE,
      layout,
      layout.cells.map((_, index) => index),
      layout.rooms[0].id,
    );
    const pruned = pruneOpenings(merged, SIZE, CEILING, list);
    expect(pruned.map((o) => o.id)).toEqual(["o-2"]);
  });

  it("外皮を狭めて線の外へ出た建具も落とす", () => {
    const list: Opening[] = [door({ id: "o-1", axis: "x", at: 5.5, start: 7 })];
    const small: PlanSize = { width: 9, depth: 5, floors: 2 };
    expect(pruneOpenings(layout, small, CEILING, list)).toEqual([]);
  });
});

describe("openingsOnRun", () => {
  it("その走りに乗っているものを start の昇順で返す", () => {
    const list: Opening[] = [
      door({ id: "o-1", start: 5 }),
      door({ id: "o-2", start: 1 }),
      door({ id: "o-3", axis: "z", at: 6, start: 1 }),
      door({ id: "o-4", start: 7.5 }),
    ];
    const found = openingsOnRun(list, "x", 5.5, 0, 6);
    expect(found.map((o) => o.id)).toEqual(["o-2", "o-1"]);
  });
});

describe("タップから置く", () => {
  it("いちばん近いマス目の線に乗せる", () => {
    // (5.4, 3) は z がちょうど線上（誤差 0）で x の誤差（0.1）より小さいので z 側の線を選ぶ。
    // (3, 5.9) は逆に x がちょうど線上で z の誤差（0.1）より小さいので x 側の線を選ぶ。
    expect(nearestWallLine(SIZE, 5.4, 3)).toEqual({ axis: "z", at: 3, along: 5.4 });
    expect(nearestWallLine(SIZE, 3, 5.9)).toEqual({ axis: "x", at: 3, along: 5.9 });
  });

  it("placeOpening はタップした点を中心にして、入らなければ null", () => {
    // z を 3 きっかりにすると誤差 0 で z 側の線（壁の無い z = 3 の通り）が選ばれてしまうので、
    // x 側の誤差（0.05）と同点かそれ以上になる 3.05 にして x = 5.5 の壁を選ばせる。
    const placed = placeOpening(layout, SIZE, CEILING, [], "door", 5.45, 3.05);
    expect(placed).toMatchObject({ axis: "x", at: 5.5, width: 0.75, kind: "door" });
    expect(placed?.start).toBe(2.75);
    expect(placeOpening(layout, SIZE, CEILING, [], "door", 2.05, 3)).toBeNull();
  });
});

describe("cycleSwing", () => {
  it("ドアは 4 通りを送り、4 回で元に戻る", () => {
    let o = door();
    const seen: string[] = [];
    for (let i = 0; i < 4; i++) {
      o = cycleSwing(o);
      seen.push(`${o.hinge}/${o.swing}`);
    }
    expect(new Set(seen).size).toBe(4);
    expect(seen[3]).toBe("start/plus");
  });

  it("引き戸は引き込む側だけ、窓は変わらない", () => {
    const sliding = cycleSwing(door({ kind: "sliding" }));
    expect(sliding.hinge).toBe("end");
    expect(sliding.swing).toBe("plus");
    const window = door({ kind: "window", style: "koshi", sill: 0.9, height: 1.2 });
    expect(cycleSwing(window)).toBe(window);
  });
});
