/**
 * 売り物: 間取り。部屋は「マス目を塗る」形で持つ。
 * 1 マス 0.5m の格子に、どの部屋のものかを 1 つずつ書く。
 * すべてのマスがどれかの部屋に属するので、隙間も重なりも出ず、面積の合計はいつでも外皮ぶん。
 * 分割木（縦か横に半分ずつ切る木）と違い、廊下も L 字も飛び地も描ける。
 *
 * 座標は床の輪郭の北西の角を原点にしたメートル。x は東へ、z は南へ。
 * col は東へ、row は南へ。マスの番号は index = row * cols + col。
 * 見本と違い、マス数は案ごとに変わるので、どの関数も第 1 引数に size を取る。
 * 乱数と Date は使わない（テストを決定的にするため）。
 */
import {
  CELL,
  cellCountOf,
  colsOf,
  HEIGHT_SNAP,
  rowsOf,
  SNAP,
  type Floor,
  type PlanSize,
} from "./house";

/** 部屋名は固定の一覧から選ぶ（自由入力にはしない） */
export const ROOM_LABELS = [
  "LDK",
  "リビング",
  "キッチン",
  "和室",
  "主寝室",
  "子ども部屋",
  "書斎",
  "浴室・洗面",
  "洗面・脱衣",
  "トイレ",
  "玄関ホール",
  "玄関土間",
  "廊下・階段",
  "ホール・階段",
  "収納",
  "ウォークインクローゼット",
  "パントリー",
  "ワークスペース",
  "バルコニー",
] as const;

export type RoomLabel = (typeof ROOM_LABELS)[number];

/** "room-<n>" の連番 */
export type RoomId = string;

export type Room = { id: RoomId; label: RoomLabel };

/** cells.length === cellCountOf(size)。空きマスは無く、どのマスもどれかの部屋の id を持つ */
export type GridLayout = { rooms: Room[]; cells: RoomId[] };

/** 床の上の矩形。x, z は北西の角 */
export type Rect = { x: number; z: number; w: number; d: number };

/** 部屋のマスを長方形に分解した 1 つ。id は "<roomId>-<k>" */
export type RoomRect = Rect & { id: string; roomId: RoomId; label: RoomLabel };

/** 部屋の境目の壁。axis が x なら南北に走る線で、from/to は z の範囲 */
export type Divider = {
  id: string;
  axis: "x" | "z";
  at: number;
  from: number;
  to: number;
};

/** なぞる線を補間するときの刻み幅（m） */
export const PAINT_STEP = CELL / 4;

/** 家具の格子に丸める。数でない値は 0 に落とす（NaN を座標に流さない） */
export function snap(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round(value / SNAP) * SNAP;
}

/** 高さの刻みに丸める。0.05 は 2 進で割り切れないので、小数 2 桁に整える */
export function snapHeight(value: number): number {
  return Math.round((Math.round(value / HEIGHT_SNAP) * HEIGHT_SNAP) * 100) / 100;
}

/** 床座標 → 3D の中心座標 */
export function toScene(size: PlanSize, x: number, z: number): [number, number] {
  return [x - size.width / 2, z - size.depth / 2];
}

export function cellAt(size: PlanSize, col: number, row: number): number {
  return row * colsOf(size) + col;
}

export function colRowOf(size: PlanSize, index: number): [number, number] {
  const cols = colsOf(size);
  return [index % cols, Math.floor(index / cols)];
}

/** マスの中心（床座標 m） */
function cellCenter(size: PlanSize, index: number): [number, number] {
  const [col, row] = colRowOf(size, index);
  return [(col + 0.5) * CELL, (row + 0.5) * CELL];
}

/** 床座標（m）→ マス番号。輪郭の外と、数でない値は null */
export function cellFromPoint(size: PlanSize, x: number, z: number): number | null {
  // NaN は比較がすべて false になるので、範囲の判定だけでは素通りしてしまう
  if (!Number.isFinite(x) || !Number.isFinite(z)) return null;
  if (x < 0 || z < 0 || x >= size.width || z >= size.depth) return null;
  return cellAt(size, Math.floor(x / CELL), Math.floor(z / CELL));
}

/** そのマスがどの部屋か */
export function roomOfCell(layout: GridLayout, index: number): RoomId {
  return layout.cells[index];
}

/**
 * from から to（床座標 m）までを PAINT_STEP ごとに刻んで、通ったマスを順に返す。
 * 斜めにマス目をまたいだ刻みでは、角を挟む両側のマスも足す（supercover）。
 * 塗り残しより塗りすぎを取る。同じマスが何度も出るので、呼ぶ側で重複を落とすこと。
 */
export function cellsAlong(
  size: PlanSize,
  from: { x: number; z: number },
  to: { x: number; z: number },
): number[] {
  const dx = to.x - from.x;
  const dz = to.z - from.z;
  const steps = Math.max(1, Math.ceil(Math.hypot(dx, dz) / PAINT_STEP));
  const found: number[] = [];
  const start = cellFromPoint(size, from.x, from.z);
  let prev = start === null ? null : colRowOf(size, start);
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const index = cellFromPoint(size, from.x + dx * t, from.z + dz * t);
    if (index === null) {
      prev = null;
      continue;
    }
    const [col, row] = colRowOf(size, index);
    if (prev && prev[0] !== col && prev[1] !== row) {
      found.push(cellAt(size, prev[0], row), cellAt(size, col, prev[1]));
    }
    found.push(index);
    prev = [col, row];
  }
  return found;
}

/** マスを 1 つも持たない部屋を消す。部屋が 1 つも無くなるなら消さない */
export function prune(layout: GridLayout): GridLayout {
  const used = new Set(layout.cells);
  const rooms = layout.rooms.filter((room) => used.has(room.id));
  if (rooms.length === 0 || rooms.length === layout.rooms.length) return layout;
  return { rooms, cells: layout.cells };
}

/** 通ったマスをまとめて roomId のものにする。1 マスも変わらないときは同じ layout を返す */
export function paintCells(
  size: PlanSize,
  layout: GridLayout,
  indexes: readonly number[],
  roomId: RoomId,
): GridLayout {
  if (!layout.rooms.some((room) => room.id === roomId)) return layout;
  const count = cellCountOf(size);
  let cells: RoomId[] | null = null;
  for (const index of indexes) {
    if (index < 0 || index >= count) continue;
    const current = cells ?? layout.cells;
    if (current[index] === roomId) continue;
    if (!cells) cells = layout.cells.slice();
    cells[index] = roomId;
  }
  if (!cells) return layout;
  return prune({ rooms: layout.rooms, cells });
}

export function paintCell(
  size: PlanSize,
  layout: GridLayout,
  index: number,
  roomId: RoomId,
): GridLayout {
  return paintCells(size, layout, [index], roomId);
}

/** 新しい id。部屋の表の中の最大番号 + 1 */
export function nextRoomId(layout: GridLayout): RoomId {
  let max = 0;
  for (const room of layout.rooms) {
    const match = /^room-(\d+)$/.exec(room.id);
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `room-${max + 1}`;
}

/** マスを持たない部屋を足す。塗られないまま次の変更が来たら prune が消す */
export function addRoom(
  layout: GridLayout,
  label: RoomLabel,
): { layout: GridLayout; id: RoomId } {
  const id = nextRoomId(layout);
  return {
    layout: { rooms: [...layout.rooms, { id, label }], cells: layout.cells },
    id,
  };
}

export function renameRoom(layout: GridLayout, id: RoomId, label: RoomLabel): GridLayout {
  const found = layout.rooms.find((room) => room.id === id);
  if (!found || found.label === label) return layout;
  return {
    rooms: layout.rooms.map((room) => (room.id === id ? { ...room, label } : room)),
    cells: layout.cells,
  };
}

/** 広さ（m²）。マス数 × 0.25 */
export function roomArea(layout: GridLayout, id: RoomId): number {
  let count = 0;
  for (const cell of layout.cells) if (cell === id) count++;
  return count * CELL * CELL;
}

function rowMatches(
  size: PlanSize,
  layout: GridLayout,
  used: readonly boolean[],
  row: number,
  col: number,
  w: number,
  id: RoomId,
): boolean {
  for (let c = col; c < col + w; c++) {
    const index = cellAt(size, c, row);
    if (used[index] || layout.cells[index] !== id) return false;
  }
  return true;
}

/**
 * 部屋ごとに、マスを長方形に分解する。
 * 行ごとの連なりを取り、同じ連なりが続く限り下へ伸ばす貪欲法。
 */
export function roomRects(size: PlanSize, layout: GridLayout): RoomRect[] {
  const cols = colsOf(size);
  const rows = rowsOf(size);
  const labels = new Map(layout.rooms.map((room) => [room.id, room.label]));
  const used: boolean[] = Array.from({ length: cols * rows }, () => false);
  const counts = new Map<RoomId, number>();
  const out: RoomRect[] = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const index = cellAt(size, col, row);
      if (used[index]) continue;
      const id = layout.cells[index];
      const label = labels.get(id);
      // 表に無い部屋のマスは描かない（保存データを壊したときだけ起きる）
      if (label === undefined) {
        used[index] = true;
        continue;
      }
      let w = 1;
      while (
        col + w < cols &&
        !used[cellAt(size, col + w, row)] &&
        layout.cells[cellAt(size, col + w, row)] === id
      ) {
        w++;
      }
      let d = 1;
      while (row + d < rows && rowMatches(size, layout, used, row + d, col, w, id)) d++;
      for (let r = row; r < row + d; r++) {
        for (let c = col; c < col + w; c++) used[cellAt(size, c, r)] = true;
      }
      const k = (counts.get(id) ?? 0) + 1;
      counts.set(id, k);
      out.push({
        id: `${id}-${k}`,
        roomId: id,
        label,
        x: col * CELL,
        z: row * CELL,
        w: w * CELL,
        d: d * CELL,
      });
    }
  }
  return out;
}

/**
 * 部屋の境目の壁。横に隣り合う 2 マスの部屋が違えば南北に走る壁（axis: "x"）、
 * 縦に隣り合えば東西に走る壁（axis: "z"）。続く区間は 1 本にまとめる。
 * 外周は外壁が受け持つので出さない。
 */
export function wallSegments(size: PlanSize, layout: GridLayout): Divider[] {
  const cols = colsOf(size);
  const rows = rowsOf(size);
  const out: Divider[] = [];
  for (let col = 1; col < cols; col++) {
    let start: number | null = null;
    for (let row = 0; row <= rows; row++) {
      const differs =
        row < rows &&
        layout.cells[cellAt(size, col - 1, row)] !== layout.cells[cellAt(size, col, row)];
      if (differs && start === null) start = row;
      if (!differs && start !== null) {
        out.push({
          id: `wx-${col}-${start}`,
          axis: "x",
          at: col * CELL,
          from: start * CELL,
          to: row * CELL,
        });
        start = null;
      }
    }
  }
  for (let row = 1; row < rows; row++) {
    let start: number | null = null;
    for (let col = 0; col <= cols; col++) {
      const differs =
        col < cols &&
        layout.cells[cellAt(size, col, row - 1)] !== layout.cells[cellAt(size, col, row)];
      if (differs && start === null) start = col;
      if (!differs && start !== null) {
        out.push({
          id: `wz-${row}-${start}`,
          axis: "z",
          at: row * CELL,
          from: start * CELL,
          to: col * CELL,
        });
        start = null;
      }
    }
  }
  return out;
}

/**
 * 注記と部屋名の位置。部屋のマスの重心にいちばん近い「その部屋のマス」の中心。
 * L 字の部屋でも名前が部屋の中に出る。
 */
export function labelAnchor(size: PlanSize, layout: GridLayout, id: RoomId): [number, number] {
  const count = cellCountOf(size);
  let sumX = 0;
  let sumZ = 0;
  let found = 0;
  for (let index = 0; index < count; index++) {
    if (layout.cells[index] !== id) continue;
    const [x, z] = cellCenter(size, index);
    sumX += x;
    sumZ += z;
    found++;
  }
  if (found === 0) return [size.width / 2, size.depth / 2];
  const cx = sumX / found;
  const cz = sumZ / found;
  let best = 0;
  let bestDistance = Number.POSITIVE_INFINITY;
  for (let index = 0; index < count; index++) {
    if (layout.cells[index] !== id) continue;
    const [x, z] = cellCenter(size, index);
    const distance = (x - cx) ** 2 + (z - cz) ** 2;
    if (distance < bestDistance) {
      bestDistance = distance;
      best = index;
    }
  }
  return cellCenter(size, best);
}

/** 部屋のマスの外接長方形。1 マスも持たない部屋は null */
export function roomBounds(size: PlanSize, layout: GridLayout, id: RoomId): Rect | null {
  const cols = colsOf(size);
  const rows = rowsOf(size);
  let minCol = cols;
  let minRow = rows;
  let maxCol = -1;
  let maxRow = -1;
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      if (layout.cells[cellAt(size, col, row)] !== id) continue;
      if (col < minCol) minCol = col;
      if (row < minRow) minRow = row;
      if (col > maxCol) maxCol = col;
      if (row > maxRow) maxRow = row;
    }
  }
  if (maxCol < 0) return null;
  return {
    x: minCol * CELL,
    z: minRow * CELL,
    w: (maxCol - minCol + 1) * CELL,
    d: (maxRow - minRow + 1) * CELL,
  };
}

/** 部屋が 1 枚の長方形か。外接長方形の面積と実際の面積が同じなら長方形 */
export function isRectangularRoom(size: PlanSize, layout: GridLayout, id: RoomId): boolean {
  const bounds = roomBounds(size, layout, id);
  if (!bounds) return false;
  return Math.abs(bounds.w * bounds.d - roomArea(layout, id)) < 1e-9;
}

type RoomPlan = { label: RoomLabel; col: number; row: number; cols: number; rows: number };

/** 割合をマス数に直す。最低でも 1 マスは残す */
function cut(total: number, ratio: number): number {
  return Math.min(Math.max(1, Math.round(total * ratio)), total - 1);
}

/**
 * 既定の間取り。見本と同じ割り方を、外皮の比で作り直す。
 * 9 × 8 m のときは見本とまったく同じ寸法になる（1F: LDK 5.5 × 6 ほか、2F: 主寝室 5 × 4 ほか）。
 */
function defaultRooms(size: PlanSize, floor: Floor): RoomPlan[] {
  const cols = colsOf(size);
  const rows = rowsOf(size);
  if (floor === 1) {
    const a = cut(cols, 0.61);
    const b = cut(rows, 0.75);
    const c = cut(rows, 0.4375);
    return [
      { label: "LDK", col: 0, row: 0, cols: a, rows: b },
      { label: "和室", col: 0, row: b, cols: a, rows: rows - b },
      { label: "玄関ホール", col: a, row: 0, cols: cols - a, rows: c },
      { label: "浴室・洗面", col: a, row: c, cols: cols - a, rows: b - c },
      { label: "廊下・階段", col: a, row: b, cols: cols - a, rows: rows - b },
    ];
  }
  const a = cut(cols, 0.5556);
  const b = cut(rows, 0.5);
  const c = cut(cols, 0.4444);
  return [
    { label: "主寝室", col: 0, row: 0, cols: a, rows: b },
    { label: "子ども部屋", col: a, row: 0, cols: cols - a, rows: b },
    { label: "書斎", col: 0, row: b, cols: c, rows: rows - b },
    { label: "ホール・階段", col: c, row: b, cols: cols - c, rows: rows - b },
  ];
}

export function defaultLayout(size: PlanSize, floor: Floor): GridLayout {
  const plans = defaultRooms(size, floor);
  const rooms: Room[] = plans.map((plan, index) => ({
    id: `room-${index + 1}`,
    label: plan.label,
  }));
  // どのマスも必ずどれかの部屋になるよう、まず先頭の部屋で埋めてから塗り重ねる
  const cells: RoomId[] = Array.from({ length: cellCountOf(size) }, () => rooms[0].id);
  plans.forEach((plan, index) => {
    const id = rooms[index].id;
    for (let row = plan.row; row < plan.row + plan.rows; row++) {
      for (let col = plan.col; col < plan.col + plan.cols; col++) {
        cells[cellAt(size, col, row)] = id;
      }
    }
  });
  return { rooms, cells };
}

/**
 * 外皮を変えたときの間取り。広げた分は先頭の部屋で埋め、狭めた分のマスは捨てる。
 * 捨てたことでマス 0 になった部屋は prune が消す。
 */
export function resizeLayout(from: PlanSize, to: PlanSize, layout: GridLayout): GridLayout {
  if (from.width === to.width && from.depth === to.depth) return layout;
  const fromCols = colsOf(from);
  const fromRows = rowsOf(from);
  const toCols = colsOf(to);
  const toRows = rowsOf(to);
  const fill = layout.rooms[0]?.id ?? "room-1";
  const cells: RoomId[] = [];
  for (let row = 0; row < toRows; row++) {
    for (let col = 0; col < toCols; col++) {
      const inside = col < fromCols && row < fromRows;
      cells.push(inside ? layout.cells[cellAt(from, col, row)] : fill);
    }
  }
  return prune({ rooms: layout.rooms, cells });
}
