/**
 * 売り物: 保存の形（v3）。1 つの保存データの中に案を最大 10 件持つ。
 * 案ごとに外皮の寸法・階数・間取り・建具・設備・外周・家具をまるごと持ち、案をまたいだ持ち込みはしない。
 * 保存先は localStorage だけで、サーバーへは送らない（読み書きの try/catch は Simulator.tsx）。
 * 古い保存データや壊れたデータで画面が落ちないよう、読み込みは必ず parsePlanFile を通す。
 */
import { FURNITURE, presetSeed } from "./catalog";
import { snapValue } from "./dimensions";
import {
  addExterior,
  clampExterior,
  pruneExterior,
  sideLength,
  type ExteriorKind,
  type ExteriorPart,
  type ExteriorSide,
} from "./exterior";
import {
  clampInside,
  pruneFurniture,
  round2,
  type PlacedFurniture,
  type Rotation,
  type Size3,
} from "./furniture";
import {
  defaultLayout,
  labelAnchor,
  prune,
  resizeLayout,
  ROOM_LABELS,
  wallSegments,
  type GridLayout,
  type Room,
  type RoomId,
  type RoomLabel,
} from "./grid";
import {
  addFixture,
  clampSteps,
  pruneFixtures,
  type Fixture,
  type FixtureDoor,
  type FixtureKind,
} from "./fixtures";
import {
  addOpening,
  OPENING_PRESETS,
  pruneOpenings,
  runLengthOf,
  type Opening,
  type OpeningPresetId,
} from "./openings";
import {
  ceilingOf,
  cellCountOf,
  DEFAULT_SIZE,
  isPlanSize,
  SNAP,
  type Floor,
  type PlanSize,
} from "./house";

export const PLAN_VERSION = 3;
export const STORAGE_KEY = "suminawa-floorplan:v3";
export const MAX_PLANS = 10;
export const MAX_NAME = 30;

export type FloorPlan = {
  /** cells.length === cellCountOf(size) */
  layout: GridLayout;
  openings: Opening[];
  fixtures: Fixture[];
  exterior: ExteriorPart[];
  furniture: PlacedFurniture[];
};

export type PlanDoc = {
  /** "plan-<n>" の連番 */
  id: string;
  /** 1〜30 字 */
  name: string;
  size: PlanSize;
  /** size.floors が 1 のとき、2 の中身は空（読み書きはするが表に出さない） */
  floors: Record<Floor, FloorPlan>;
};

export type PlanFile = {
  version: 3;
  /** 1 件以上、10 件まで */
  plans: PlanDoc[];
  /** 表示中の案。plans に無ければ先頭を使う */
  activeId: string;
};

export function autoPlanName(index: number): string {
  return `案 ${index + 1}`;
}

export function emptyFloorPlan(size: PlanSize, floor: Floor): FloorPlan {
  return {
    layout: defaultLayout(size, floor),
    openings: [],
    fixtures: [],
    exterior: [],
    furniture: [],
  };
}

/** その階の中で、名前にその語を含む最初の部屋の名前の位置。無ければ床の真ん中 */
function anchorOf(size: PlanSize, layout: GridLayout, needles: readonly string[]): [number, number] {
  for (const needle of needles) {
    const room = layout.rooms.find((item) => item.label.includes(needle));
    if (room) return labelAnchor(size, layout, room.id);
  }
  return [size.width / 2, size.depth / 2];
}

/** 境目の壁の真ん中にドアを 1 つずつ、外壁の 4 面に窓を 1 つずつ */
function seedOpenings(size: PlanSize, layout: GridLayout, ceiling: number): Opening[] {
  let list: Opening[] = [];
  const put = (
    presetId: OpeningPresetId,
    axis: "x" | "z",
    at: number,
    center: number,
  ) => {
    const preset = OPENING_PRESETS[presetId];
    const length = runLengthOf(size, axis);
    const width = Math.min(preset.width, length);
    const height = Math.min(preset.height, round2(ceiling - preset.sill));
    list = addOpening(layout, size, ceiling, list, {
      id: "",
      kind: preset.kind,
      style: preset.style,
      axis,
      at,
      start: snapValue(center - width / 2, SNAP, 0, round2(length - width)),
      width,
      sill: preset.sill,
      height,
      hinge: "start",
      swing: "plus",
    });
  };
  for (const line of wallSegments(size, layout)) {
    put("door", line.axis, line.at, (line.from + line.to) / 2);
  }
  put("hakidashi", "z", size.depth, size.width / 2);
  put("koshi", "z", 0, size.width / 2);
  put("koshi", "x", 0, size.depth / 2);
  put("koshi", "x", size.width, size.depth / 2);
  return list;
}

function seedFixtures(size: PlanSize, layout: GridLayout, floor: Floor): Fixture[] {
  let list: Fixture[] = [];
  // 平屋には階段を置かない
  if (size.floors === 2) {
    list = addFixture(size, list, "stairs", anchorOf(size, layout, ["階段", "ホール"]));
  }
  if (floor === 2) {
    list = addFixture(size, list, "closet", anchorOf(size, layout, ["主寝室", "寝室"]));
  } else {
    list = addFixture(size, list, "genkan", anchorOf(size, layout, ["玄関"]));
  }
  return list;
}

type Seed = { type: Parameters<typeof presetSeed>[0]; preset: string; rooms: string[]; shift: number };

const SEED_FURNITURE: Record<Floor, readonly Seed[]> = {
  1: [
    { type: "sofa", preset: "sofa-3", rooms: ["LDK", "リビング"], shift: 0 },
    { type: "tvstand", preset: "tvstand-150", rooms: ["LDK", "リビング"], shift: 1.25 },
    { type: "dining", preset: "dining-4", rooms: ["LDK", "リビング"], shift: -1.75 },
    { type: "kitchen", preset: "kitchen-i", rooms: ["キッチン", "LDK"], shift: -3 },
    { type: "bath", preset: "bath-160", rooms: ["浴室", "洗面"], shift: 0 },
  ],
  2: [
    { type: "bed", preset: "bed-d", rooms: ["主寝室", "寝室"], shift: 0 },
    { type: "bed", preset: "bed-s", rooms: ["子ども部屋"], shift: 0 },
    { type: "desk", preset: "desk-120", rooms: ["書斎", "ワークスペース"], shift: -1 },
    { type: "shelf", preset: "shelf-90", rooms: ["書斎", "ワークスペース"], shift: 1 },
  ],
};

function seedFurniture(size: PlanSize, layout: GridLayout, floor: Floor): PlacedFurniture[] {
  return SEED_FURNITURE[floor].map((seed, index) => {
    const [x, z] = anchorOf(size, layout, seed.rooms);
    return clampInside(size, {
      ...presetSeed(seed.type, seed.preset),
      id: `f-${index + 1}`,
      x: snapValue(x, SNAP, 0, size.width),
      z: snapValue(z + seed.shift, SNAP, 0, size.depth),
      rotation: 0 as Rotation,
    });
  });
}

/**
 * 既定の階。間取り・建具・設備・家具が入っていて、そのまま検討を始められる。
 * 間取り（layout）を渡すと、その割り方に合わせて建具・設備・家具を置く
 * （見本の JSON を作る scripts/samples.mjs が使う）。
 */
export function defaultFloorPlan(size: PlanSize, floor: Floor, plan?: GridLayout): FloorPlan {
  if (floor > size.floors) return { ...emptyFloorPlan(size, floor), layout: defaultLayout(size, floor) };
  const layout = plan ?? defaultLayout(size, floor);
  const ceiling = ceilingOf(size, floor);
  const exterior: ExteriorPart[] =
    floor === 2 ? addExterior(size, [], "balcony", "s", size.width / 2) : [];
  return {
    layout,
    openings: seedOpenings(size, layout, ceiling),
    fixtures: seedFixtures(size, layout, floor),
    exterior,
    furniture: seedFurniture(size, layout, floor),
  };
}

export function defaultPlanDoc(id: string, name: string, size: PlanSize): PlanDoc {
  return {
    id,
    name,
    size,
    floors: { 1: defaultFloorPlan(size, 1), 2: defaultFloorPlan(size, 2) },
  };
}

export function defaultPlanFile(): PlanFile {
  return { version: 3, plans: [defaultPlanDoc("plan-1", autoPlanName(0), DEFAULT_SIZE)], activeId: "plan-1" };
}

export function planById(file: PlanFile, id: string): PlanDoc | null {
  return file.plans.find((plan) => plan.id === id) ?? null;
}

export function activePlan(file: PlanFile): PlanDoc {
  return planById(file, file.activeId) ?? file.plans[0];
}

export function updateFloor(doc: PlanDoc, floor: Floor, next: FloorPlan): PlanDoc {
  if (doc.floors[floor] === next) return doc;
  return {
    ...doc,
    floors: floor === 1 ? { 1: next, 2: doc.floors[2] } : { 1: doc.floors[1], 2: next },
  };
}

export function updatePlan(file: PlanFile, id: string, next: PlanDoc): PlanFile {
  if (!file.plans.some((plan) => plan.id === id)) return file;
  return { ...file, plans: file.plans.map((plan) => (plan.id === id ? next : plan)) };
}

function nextPlanId(file: PlanFile): string {
  let max = 0;
  for (const plan of file.plans) {
    const match = /^plan-(\d+)$/.exec(plan.id);
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `plan-${max + 1}`;
}

/** いま見ている案と同じ外皮で、新しい案を足す。10 件を超えるなら同じ参照を返す */
export function addPlan(file: PlanFile): PlanFile {
  if (file.plans.length >= MAX_PLANS) return file;
  const id = nextPlanId(file);
  const doc = defaultPlanDoc(id, autoPlanName(file.plans.length), activePlan(file).size);
  return { ...file, plans: [...file.plans, doc], activeId: id };
}

export function duplicatePlan(file: PlanFile, id: string): PlanFile {
  if (file.plans.length >= MAX_PLANS) return file;
  const source = planById(file, id);
  if (!source) return file;
  const newId = nextPlanId(file);
  const copy: PlanDoc = {
    ...structuredClone(source),
    id: newId,
    name: `${source.name} の複製`.slice(0, MAX_NAME),
  };
  return { ...file, plans: [...file.plans, copy], activeId: newId };
}

export function renamePlan(file: PlanFile, id: string, name: string): PlanFile {
  const index = file.plans.findIndex((plan) => plan.id === id);
  if (index < 0) return file;
  const trimmed = name.trim().slice(0, MAX_NAME);
  const next = trimmed === "" ? autoPlanName(index) : trimmed;
  if (file.plans[index].name === next) return file;
  return {
    ...file,
    plans: file.plans.map((plan) => (plan.id === id ? { ...plan, name: next } : plan)),
  };
}

/** 最後の 1 件は消さない */
export function removePlan(file: PlanFile, id: string): PlanFile {
  if (file.plans.length <= 1) return file;
  const index = file.plans.findIndex((plan) => plan.id === id);
  if (index < 0) return file;
  const plans = file.plans.filter((plan) => plan.id !== id);
  const activeId = file.activeId === id ? plans[Math.min(index, plans.length - 1)].id : file.activeId;
  return { ...file, plans, activeId };
}

export function selectPlan(file: PlanFile, id: string): PlanFile {
  if (file.activeId === id || !file.plans.some((plan) => plan.id === id)) return file;
  return { ...file, activeId: id };
}

/**
 * 外皮を変える。広げた分は先頭の部屋で埋め、狭めた分のマスは捨てる。
 * 輪郭の外へ出た家具・設備は中へ寄せ、壁の無くなった建具と面からはみ出した外周は落とす。
 * 平屋にしたときは 2F の中身を空にする（間取りだけは残して、2 階建てに戻したときに使う）。
 */
export function resizePlan(doc: PlanDoc, size: PlanSize): PlanDoc {
  const floors = {} as Record<Floor, FloorPlan>;
  for (const floor of [1, 2] as const) {
    const before = doc.floors[floor];
    const layout = resizeLayout(doc.size, size, before.layout);
    if (floor > size.floors) {
      floors[floor] = { layout, openings: [], fixtures: [], exterior: [], furniture: [] };
      continue;
    }
    floors[floor] = {
      layout,
      openings: pruneOpenings(layout, size, ceilingOf(size, floor), before.openings),
      fixtures: pruneFixtures(size, before.fixtures),
      exterior: pruneExterior(size, before.exterior),
      furniture: pruneFurniture(size, before.furniture),
    };
  }
  return { ...doc, size, floors };
}

export function serializePlanFile(file: PlanFile): string {
  return JSON.stringify(file);
}

/* ---- 検証 ---------------------------------------------------------------- */

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isNum(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isRotation(value: unknown): value is Rotation {
  return value === 0 || value === 90 || value === 180 || value === 270;
}

function parseSize3(value: unknown): Size3 | null {
  if (!isObject(value)) return null;
  if (!isNum(value.w) || !isNum(value.d) || !isNum(value.h)) return null;
  if (value.w <= 0 || value.d <= 0 || value.h <= 0) return null;
  return { w: value.w, d: value.d, h: value.h };
}

/** 部屋の表とマスの表。数が違う・知らない id・知らない部屋名・id の重複があれば null */
function parseLayout(value: unknown, size: PlanSize): GridLayout | null {
  if (!isObject(value)) return null;
  if (!Array.isArray(value.rooms) || !Array.isArray(value.cells)) return null;
  if (value.cells.length !== cellCountOf(size)) return null;
  const rooms: Room[] = [];
  const ids = new Set<RoomId>();
  for (const entry of value.rooms) {
    if (!isObject(entry)) return null;
    if (typeof entry.id !== "string" || entry.id === "") return null;
    if (ids.has(entry.id)) return null;
    if (typeof entry.label !== "string") return null;
    if (!(ROOM_LABELS as readonly string[]).includes(entry.label)) return null;
    ids.add(entry.id);
    rooms.push({ id: entry.id, label: entry.label as RoomLabel });
  }
  if (rooms.length === 0) return null;
  const cells: RoomId[] = [];
  for (const cell of value.cells) {
    if (typeof cell !== "string" || !ids.has(cell)) return null;
    cells.push(cell);
  }
  return prune({ rooms, cells });
}

function parseOpening(value: unknown): Opening | null {
  if (!isObject(value)) return null;
  if (typeof value.id !== "string" || value.id === "") return null;
  if (value.kind !== "door" && value.kind !== "sliding" && value.kind !== "window") return null;
  if (value.style !== null && value.style !== "koshi" && value.style !== "hakidashi") return null;
  if (value.axis !== "x" && value.axis !== "z") return null;
  if (!isNum(value.at) || !isNum(value.start) || !isNum(value.width)) return null;
  if (!isNum(value.sill) || !isNum(value.height)) return null;
  if (value.hinge !== "start" && value.hinge !== "end") return null;
  if (value.swing !== "plus" && value.swing !== "minus") return null;
  return {
    id: value.id,
    kind: value.kind,
    style: value.style,
    axis: value.axis,
    at: value.at,
    start: value.start,
    width: value.width,
    sill: value.sill,
    height: value.height,
    hinge: value.hinge,
    swing: value.swing,
  };
}

const FIXTURE_KINDS: readonly FixtureKind[] = ["closet", "oshiire", "genkan", "stairs"];
const FIXTURE_DOORS: readonly FixtureDoor[] = ["folding", "sliding", "hinged", "none"];

function parseFixture(value: unknown, size: PlanSize): Fixture | null {
  if (!isObject(value)) return null;
  if (typeof value.id !== "string" || value.id === "") return null;
  if (!FIXTURE_KINDS.includes(value.kind as FixtureKind)) return null;
  if (!FIXTURE_DOORS.includes(value.door as FixtureDoor)) return null;
  const parsed = parseSize3(value.size);
  if (!parsed) return null;
  if (!isNum(value.x) || !isNum(value.z) || !isRotation(value.rotation)) return null;
  if (value.steps !== null && !isNum(value.steps)) return null;
  if (value.preset !== null && typeof value.preset !== "string") return null;
  return clampInside(size, {
    id: value.id,
    kind: value.kind as FixtureKind,
    preset: value.preset as string | null,
    size: parsed,
    door: value.door as FixtureDoor,
    x: value.x,
    z: value.z,
    rotation: value.rotation,
    // 段数は 8〜20 の整数に収める（大きい値がそのまま通ると段板が何万個も並ぶ）
    steps: clampSteps(value.steps as number | null),
  });
}

const EXTERIOR_KINDS: readonly ExteriorKind[] = ["balcony", "terrace", "porch"];
const EXTERIOR_SIDES: readonly ExteriorSide[] = ["n", "e", "s", "w"];

function parseExterior(value: unknown, size: PlanSize): ExteriorPart | null {
  if (!isObject(value)) return null;
  if (typeof value.id !== "string" || value.id === "") return null;
  if (!EXTERIOR_KINDS.includes(value.kind as ExteriorKind)) return null;
  if (!EXTERIOR_SIDES.includes(value.side as ExteriorSide)) return null;
  if (!isNum(value.start) || !isNum(value.length) || !isNum(value.depth)) return null;
  if (typeof value.railing !== "boolean") return null;
  if (value.start >= sideLength(size, value.side as ExteriorSide)) return null;
  return clampExterior(size, {
    id: value.id,
    kind: value.kind as ExteriorKind,
    side: value.side as ExteriorSide,
    start: value.start,
    length: value.length,
    depth: value.depth,
    railing: value.railing,
  });
}

function parseFurniture(value: unknown, size: PlanSize): PlacedFurniture | null {
  if (!isObject(value)) return null;
  if (typeof value.id !== "string" || value.id === "") return null;
  const typeId = value.type;
  if (typeof typeId !== "string") return null;
  if (!FURNITURE.some((type) => type.id === typeId)) return null;
  const parsed = parseSize3(value.size);
  if (!parsed) return null;
  if (!isNum(value.x) || !isNum(value.z) || !isRotation(value.rotation)) return null;
  if (value.preset !== null && typeof value.preset !== "string") return null;
  if (value.inch !== null && !isNum(value.inch)) return null;
  // 輪郭の外に出ている保存データは、弾かずに中へ寄せて受け取る
  return clampInside(size, {
    id: value.id,
    type: typeId as PlacedFurniture["type"],
    preset: value.preset as string | null,
    size: parsed,
    inch: value.inch as number | null,
    x: value.x,
    z: value.z,
    rotation: value.rotation,
  });
}

function parseFloorPlan(value: unknown, size: PlanSize, floor: Floor): FloorPlan | null {
  if (!isObject(value)) return null;
  const layout = parseLayout(value.layout, size);
  if (!layout) return null;
  if (
    !Array.isArray(value.openings) ||
    !Array.isArray(value.fixtures) ||
    !Array.isArray(value.exterior) ||
    !Array.isArray(value.furniture)
  ) {
    return null;
  }
  const openings: Opening[] = [];
  for (const entry of value.openings) {
    const parsed = parseOpening(entry);
    if (!parsed) return null;
    openings.push(parsed);
  }
  const fixtures: Fixture[] = [];
  for (const entry of value.fixtures) {
    const parsed = parseFixture(entry, size);
    if (!parsed) return null;
    fixtures.push(parsed);
  }
  const exterior: ExteriorPart[] = [];
  for (const entry of value.exterior) {
    const parsed = parseExterior(entry, size);
    if (!parsed) return null;
    exterior.push(parsed);
  }
  const furniture: PlacedFurniture[] = [];
  for (const entry of value.furniture) {
    const parsed = parseFurniture(entry, size);
    if (!parsed) return null;
    furniture.push(parsed);
  }
  return {
    layout,
    // 壁の無い建具・刻みに乗っていない建具はここで落ちる
    openings: pruneOpenings(layout, size, ceilingOf(size, floor), openings),
    fixtures,
    exterior,
    furniture,
  };
}

function parsePlanDoc(value: unknown): PlanDoc | null {
  if (!isObject(value)) return null;
  if (typeof value.id !== "string" || value.id === "") return null;
  if (typeof value.name !== "string") return null;
  if (!isPlanSize(value.size)) return null;
  if (!isObject(value.floors)) return null;
  const size = value.size;
  const first = parseFloorPlan(value.floors[1], size, 1);
  const second = parseFloorPlan(value.floors[2], size, 2);
  if (!first || !second) return null;
  return {
    id: value.id,
    name: value.name.slice(0, MAX_NAME),
    size,
    floors: { 1: first, 2: second },
  };
}

/** 形が違えば null。案は先頭 10 件まで。activeId が無ければ先頭 */
export function parsePlanFile(raw: unknown): PlanFile | null {
  if (!isObject(raw)) return null;
  if (raw.version !== PLAN_VERSION) return null;
  if (!Array.isArray(raw.plans) || raw.plans.length === 0) return null;
  const plans: PlanDoc[] = [];
  const ids = new Set<string>();
  for (const entry of raw.plans.slice(0, MAX_PLANS)) {
    const parsed = parsePlanDoc(entry);
    if (!parsed || ids.has(parsed.id)) return null;
    ids.add(parsed.id);
    plans.push(parsed);
  }
  const activeId = typeof raw.activeId === "string" && ids.has(raw.activeId) ? raw.activeId : plans[0].id;
  return { version: 3, plans, activeId };
}

export function parsePlanJson(raw: string | null): PlanFile | null {
  if (!raw) return null;
  try {
    return parsePlanFile(JSON.parse(raw));
  } catch {
    return null;
  }
}
