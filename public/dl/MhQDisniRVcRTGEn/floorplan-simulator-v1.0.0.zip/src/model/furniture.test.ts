import { describe, expect, it } from "vitest";
import { DEFAULT_SIZE, SNAP, type PlanSize } from "./house";
import {
  addFurniture,
  clampInside,
  footprintOf,
  lighten,
  moveFurniture,
  nextSeqId,
  partsInScene,
  pruneFurniture,
  removeFurniture,
  resizeFurniture,
  rotateFurniture,
  round2,
  TONE,
  turn,
  turnPoint,
  type FurnitureSeed,
  type PlacedFurniture,
} from "./furniture";

const SIZE = DEFAULT_SIZE;

const SOFA: FurnitureSeed = {
  type: "sofa",
  preset: "sofa-3",
  size: { w: 1.9, d: 0.85, h: 0.8 },
  inch: null,
};

function placed(patch: Partial<PlacedFurniture> = {}): PlacedFurniture {
  return {
    id: "f-1",
    type: "sofa",
    preset: "sofa-3",
    size: { w: 1.9, d: 0.85, h: 0.8 },
    inch: null,
    x: 4.5,
    z: 4,
    rotation: 0,
    ...patch,
  };
}

describe("丸めと回転", () => {
  it("round2 は小数 2 桁に整える", () => {
    expect(round2(1.005)).toBe(1.01);
    expect(round2(0.1 + 0.2)).toBe(0.3);
  });

  it("turn は 4 回で元に戻る", () => {
    expect(turn(turn(turn(turn(0))))).toBe(0);
    expect(turn(0)).toBe(90);
    expect(turn(270)).toBe(0);
  });

  it("turnPoint は床座標を回す", () => {
    expect(turnPoint(1, 0, 0)).toEqual([1, 0]);
    expect(turnPoint(1, 0, 90)).toEqual([-0, 1]);
    expect(turnPoint(1, 0, 180)).toEqual([-1, -0]);
    expect(turnPoint(1, 0, 270)).toEqual([0, -1]);
  });

  it("footprintOf は 90 / 270 で幅と奥行きを入れ替える", () => {
    expect(footprintOf(placed())).toEqual([1.9, 0.85]);
    expect(footprintOf(placed({ rotation: 90 }))).toEqual([0.85, 1.9]);
    expect(footprintOf(placed({ rotation: 180 }))).toEqual([1.9, 0.85]);
    expect(footprintOf(placed({ rotation: 270 }))).toEqual([0.85, 1.9]);
  });
});

/** 中心が SNAP（0.25 m）の倍数か */
const onSnap = (value: number) => Math.abs(value / SNAP - Math.round(value / SNAP)) < 1e-9;

/** 回転後の footprint が輪郭からはみ出していないか */
function inside(size: PlanSize, item: PlacedFurniture): boolean {
  const [w, d] = footprintOf(item);
  return (
    item.x - w / 2 >= -1e-9 &&
    item.x + w / 2 <= size.width + 1e-9 &&
    item.z - d / 2 >= -1e-9 &&
    item.z + d / 2 <= size.depth + 1e-9
  );
}

describe("clampInside", () => {
  // ソファ 1.9 × 0.85 を 9 × 8 m に収めると、端は幅の半分を 0.25 に切り上げた値になる:
  // x は ceil(0.95 / 0.25) × 0.25 = 1.00 〜 9 − 1.00 = 8.00、
  // z は ceil(0.425 / 0.25) × 0.25 = 0.50 〜 8 − 0.50 = 7.50
  it("輪郭の外に出さず、中心を 0.25 の倍数に保つ", () => {
    expect(clampInside(SIZE, placed({ x: 0, z: 0 }))).toMatchObject({ x: 1, z: 0.5 });
    expect(clampInside(SIZE, placed({ x: 99, z: 99 }))).toMatchObject({ x: 8, z: 7.5 });
    // 90 度では幅と奥行きが入れ替わるので、端も入れ替わる
    expect(clampInside(SIZE, placed({ x: 0, z: 0, rotation: 90 }))).toMatchObject({
      x: 0.5,
      z: 1,
    });
  });

  it("寄せたあとの輪郭からのはみ出しは 0（丸めで外へ広がらない）", () => {
    for (const rotation of [0, 90, 180, 270] as const) {
      for (const [x, z] of [[0, 0], [99, 99], [-99, 4], [4.5, 99]] as const) {
        const item = clampInside(SIZE, placed({ x, z, rotation }));
        expect(inside(SIZE, item)).toBe(true);
        expect(onSnap(item.x)).toBe(true);
        expect(onSnap(item.z)).toBe(true);
      }
    }
  });

  it("外皮が変われば寄せる先も変わる", () => {
    const small: PlanSize = { width: 5, depth: 5, floors: 1 };
    // x は 5 − 1.00 = 4.00、z は 5 − 0.50 = 4.50
    expect(clampInside(small, placed({ x: 99, z: 99 }))).toMatchObject({ x: 4, z: 4.5 });
  });

  it("外皮より大きい家具は真ん中に置く", () => {
    const small: PlanSize = { width: 4, depth: 4, floors: 1 };
    const big = clampInside(small, placed({ size: { w: 5, d: 5, h: 0.8 }, x: 99, z: -99 }));
    expect(big).toMatchObject({ x: 2, z: 2 });
  });

  it("数でない座標は内側の端に落とす", () => {
    const broken = clampInside(SIZE, placed({ x: Number.NaN, z: Number.POSITIVE_INFINITY }));
    expect(broken.x).toBe(1);
    expect(broken.z).toBe(0.5);
  });
});

describe("置く・動かす・回す・大きさを変える・消す", () => {
  it("addFurniture は格子に丸め、id を連番で付ける", () => {
    const first = addFurniture(SIZE, [], SOFA, [2.13, 3.4]);
    expect(first).toHaveLength(1);
    expect(first[0].id).toBe("f-1");
    expect(first[0].x).toBe(2.25);
    expect(first[0].z).toBe(3.5);
    expect(first[0].preset).toBe("sofa-3");
    const second = addFurniture(SIZE, first, SOFA, [4, 4]);
    expect(second[1].id).toBe("f-2");
  });

  it("nextSeqId は最大の番号 + 1", () => {
    expect(nextSeqId([{ id: "f-3" }, { id: "f-1" }], "f")).toBe("f-4");
    expect(nextSeqId([], "o")).toBe("o-1");
  });

  it("moveFurniture は格子に丸めて輪郭に収める", () => {
    const list = addFurniture(SIZE, [], SOFA, [4, 4]);
    const moved = moveFurniture(SIZE, list, "f-1", 99, -99);
    expect(moved[0].x).toBe(8);
    expect(moved[0].z).toBe(0.5);
  });

  it("数でない座標を渡しても NaN にならない", () => {
    const list = addFurniture(SIZE, [], SOFA, [Number.NaN, Number.NaN]);
    expect(list[0].x).toBe(1);
    expect(list[0].z).toBe(0.5);
    const moved = moveFurniture(SIZE, list, "f-1", Number.NaN, Number.POSITIVE_INFINITY);
    expect(Number.isFinite(moved[0].x)).toBe(true);
    expect(Number.isFinite(moved[0].z)).toBe(true);
  });

  it("rotateFurniture は 4 回で元に戻る", () => {
    let list = addFurniture(SIZE, [], SOFA, [4, 4]);
    for (let i = 0; i < 4; i++) list = rotateFurniture(SIZE, list, "f-1");
    expect(list[0].rotation).toBe(0);
  });

  it("壁ぎわで回すと中へ寄り、4 回まわしても輪郭からはみ出さない", () => {
    // 南東の角に寄せたソファ（x は上限 8.00、z は上限 7.50）
    let list = moveFurniture(SIZE, addFurniture(SIZE, [], SOFA, [4, 4]), "f-1", 99, 99);
    expect(list[0]).toMatchObject({ x: 8, z: 7.5 });
    const seen: { x: number; z: number; rotation: number }[] = [];
    for (let i = 0; i < 4; i++) {
      list = rotateFurniture(SIZE, list, "f-1");
      expect(inside(SIZE, list[0])).toBe(true);
      seen.push({ x: list[0].x, z: list[0].z, rotation: list[0].rotation });
    }
    // 90 度では奥行き 1.9 が南北を向くので z が 7.50 → 7.00 へ寄る。
    // 4 回まわしても寄せたぶんは戻らない（0 度に帰っても z は 7.00 のまま）
    expect(seen[0]).toEqual({ x: 8, z: 7, rotation: 90 });
    expect(seen[3]).toEqual({ x: 8, z: 7, rotation: 0 });
    // 向きだけは 4 回で元どおり
    expect(list[0].rotation).toBe(0);
  });

  it("resizeFurniture は寸法を入れ替え、preset を外す", () => {
    const list = addFurniture(SIZE, [], SOFA, [4, 4]);
    const resized = resizeFurniture(SIZE, list, "f-1", { w: 2.25 });
    expect(resized[0].size).toEqual({ w: 2.25, d: 0.85, h: 0.8 });
    expect(resized[0].preset).toBeNull();
    // preset を渡したときは preset を残す
    const back = resizeFurniture(SIZE, resized, "f-1", {
      w: 1.9,
      d: 0.85,
      h: 0.8,
      preset: "sofa-3",
    });
    expect(back[0].preset).toBe("sofa-3");
  });

  it("removeFurniture は消す", () => {
    const list = addFurniture(SIZE, [], SOFA, [4, 4]);
    expect(removeFurniture(list, "f-1")).toEqual([]);
    expect(removeFurniture(list, "f-9")).toHaveLength(1);
  });

  it("pruneFurniture は外皮からはみ出した家具を中へ寄せる", () => {
    const list: PlacedFurniture[] = [placed({ x: 8.5, z: 7.5 })];
    const small: PlanSize = { width: 5, depth: 5, floors: 1 };
    const pruned = pruneFurniture(small, list);
    expect(pruned[0].x).toBe(4);
    expect(pruned[0].z).toBe(4.5);
    // 1 つも動かないときは、配列も中身も同じ参照のまま返す
    const staying: PlacedFurniture[] = [placed()];
    expect(pruneFurniture(SIZE, staying)).toBe(staying);
    expect(pruneFurniture(SIZE, staying)[0]).toBe(staying[0]);
  });
});

describe("partsInScene", () => {
  const PARTS = [
    { offset: [0, 0.2, 0.05] as [number, number, number], size: [1.9, 0.4, 0.8] as [number, number, number], color: TONE.fabric },
  ];

  it("床座標を 3D の中心座標に写し、階の床の高さを足す", () => {
    const scene = partsInScene(SIZE, placed({ x: 4.5, z: 4 }), PARTS, 2.95);
    expect(scene[0].id).toBe("f-1-0");
    expect(scene[0].position[0]).toBeCloseTo(0, 9);
    expect(scene[0].position[1]).toBeCloseTo(3.15, 9);
    expect(scene[0].position[2]).toBeCloseTo(0.05, 9);
    expect(scene[0].size).toEqual([1.9, 0.4, 0.8]);
  });

  it("90 度で x と z が入れ替わる", () => {
    const scene = partsInScene(SIZE, placed({ x: 4.5, z: 4, rotation: 90 }), PARTS, 0);
    expect(scene[0].position[0]).toBeCloseTo(-0.05, 9);
    expect(scene[0].position[2]).toBeCloseTo(0, 9);
    expect(scene[0].size).toEqual([0.8, 0.4, 1.9]);
  });
});

describe("lighten", () => {
  it("明度だけを上げる", () => {
    expect(lighten("#000000", 0.5)).toBe("#808080");
    expect(lighten("#ffffff", 0.2)).toBe("#ffffff");
    expect(lighten(TONE.wood, 0.12)).toMatch(/^#[0-9a-f]{6}$/);
  });
});

describe("色の表", () => {
  it("すべて #rrggbb", () => {
    for (const value of Object.values(TONE)) expect(value).toMatch(/^#[0-9a-f]{6}$/);
  });
});
