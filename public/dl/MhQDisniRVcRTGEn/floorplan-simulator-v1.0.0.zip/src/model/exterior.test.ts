import { describe, expect, it } from "vitest";
import { DEFAULT_SIZE, type PlanSize } from "./house";
import {
  addExterior,
  clampExterior,
  EXTERIOR_MAX_DEPTH,
  EXTERIOR_MIN_DEPTH,
  EXTERIOR_PRESETS,
  exteriorName,
  exteriorParts,
  exteriorRect,
  moveExterior,
  pruneExterior,
  removeExterior,
  resizeExterior,
  sideLength,
  type ExteriorPart,
} from "./exterior";

const SIZE = DEFAULT_SIZE;

/** 位置の見比べ用。小数 3 桁に整える（0.625 や −0.075 をそのまま見たい） */
const round3 = (value: number) => Math.round(value * 1000) / 1000;

function balcony(patch: Partial<ExteriorPart> = {}): ExteriorPart {
  return {
    id: "e-1",
    kind: "balcony",
    side: "s",
    start: 2,
    length: 3,
    depth: 1.25,
    railing: true,
    ...patch,
  };
}

describe("外周の表", () => {
  it("3 種あり、手すりの既定は決めたとおり", () => {
    expect(Object.keys(EXTERIOR_PRESETS)).toEqual(["balcony", "terrace", "porch"]);
    expect(EXTERIOR_PRESETS.balcony).toMatchObject({ name: "バルコニー", railing: true });
    expect(EXTERIOR_PRESETS.terrace).toMatchObject({ name: "テラス", railing: true });
    expect(EXTERIOR_PRESETS.porch).toMatchObject({ name: "玄関ポーチ", railing: false });
    expect(exteriorName("porch")).toBe("玄関ポーチ");
    expect(EXTERIOR_MIN_DEPTH).toBe(0.5);
    expect(EXTERIOR_MAX_DEPTH).toBe(3);
  });

  it("面の長さは南北なら間口、東西なら奥行き", () => {
    expect(sideLength(SIZE, "n")).toBe(9);
    expect(sideLength(SIZE, "s")).toBe(9);
    expect(sideLength(SIZE, "e")).toBe(8);
    expect(sideLength(SIZE, "w")).toBe(8);
  });
});

describe("収める", () => {
  it("start + length が面の長さを超えたら端で止める", () => {
    expect(clampExterior(SIZE, balcony({ start: 8, length: 3 }))).toMatchObject({
      start: 8,
      length: 1,
    });
    expect(clampExterior(SIZE, balcony({ start: 99, length: 3 }))).toMatchObject({
      start: 8.5,
      length: 0.5,
    });
  });

  it("奥行きは 0.5〜3.0 m に収める", () => {
    expect(clampExterior(SIZE, balcony({ depth: 0.1 })).depth).toBe(0.5);
    expect(clampExterior(SIZE, balcony({ depth: 9 })).depth).toBe(3);
    expect(clampExterior(SIZE, balcony({ depth: 1.3 })).depth).toBe(1.25);
  });
});

describe("置く・動かす・大きさを変える・消す", () => {
  it("addExterior は id を連番で付け、面に収める", () => {
    const list = addExterior(SIZE, [], "balcony", "s", 2.1);
    expect(list[0].id).toBe("e-1");
    expect(list[0].side).toBe("s");
    expect(list[0].railing).toBe(true);
    expect(addExterior(SIZE, list, "porch", "n", 1)[1].id).toBe("e-2");
  });

  it("同じ面で重なってもよい", () => {
    let list = addExterior(SIZE, [], "balcony", "s", 2);
    list = addExterior(SIZE, list, "porch", "s", 2);
    expect(list).toHaveLength(2);
  });

  it("moveExterior / resizeExterior / removeExterior", () => {
    const list = addExterior(SIZE, [], "balcony", "s", 2);
    // 南の面は 9 m。0.5 m ぶんは残るので start は 8.5 で止まり、長さもその 0.5 に詰まる
    expect(moveExterior(SIZE, list, "e-1", 99)[0]).toMatchObject({ start: 8.5, length: 0.5 });
    const resized = resizeExterior(SIZE, list, "e-1", { length: 4, depth: 2, railing: false });
    expect(resized[0]).toMatchObject({ length: 4, depth: 2, railing: false });
    expect(removeExterior(list, "e-1")).toEqual([]);
  });

  it("外皮を狭めると面からはみ出した外周が落ちる", () => {
    const list = addExterior(SIZE, [], "balcony", "s", 8);
    const small: PlanSize = { width: 5, depth: 5, floors: 1 };
    expect(pruneExterior(small, list)).toEqual([]);
    expect(pruneExterior(SIZE, list)).toBe(list);
  });
});

describe("矩形と 3D", () => {
  it("南の面は輪郭の外（z > depth）へ出る", () => {
    expect(exteriorRect(SIZE, balcony({ side: "s", start: 2, length: 3, depth: 1.25 }))).toEqual({
      x: 2,
      z: 8,
      w: 3,
      d: 1.25,
    });
    expect(exteriorRect(SIZE, balcony({ side: "n", start: 2, length: 3, depth: 1 }))).toEqual({
      x: 2,
      z: -1,
      w: 3,
      d: 1,
    });
    expect(exteriorRect(SIZE, balcony({ side: "e", start: 1, length: 2, depth: 1 }))).toEqual({
      x: 9,
      z: 1,
      w: 1,
      d: 2,
    });
    expect(exteriorRect(SIZE, balcony({ side: "w", start: 1, length: 2, depth: 1 }))).toEqual({
      x: -1,
      z: 1,
      w: 1,
      d: 2,
    });
  });

  it("手すりありはスラブ + 3 枚、なしはスラブだけ", () => {
    const withRail = exteriorParts(SIZE, balcony(), 2);
    expect(withRail).toHaveLength(4);
    expect(withRail[0].size[1]).toBeCloseTo(0.15, 9);
    expect(withRail[0].position[1]).toBeCloseTo(2.95 - 0.075, 9);
    expect(withRail.slice(1).every((p) => Math.abs(p.size[1] - 1.1) < 1e-9)).toBe(true);
    const noRail = exteriorParts(SIZE, balcony({ kind: "porch", railing: false }), 1);
    expect(noRail).toHaveLength(1);
  });

  it("南の面では、手すりが外の 1 辺と左右の 2 辺に立つ", () => {
    // 南に start 2・長さ 3・奥行き 1.25 → 床座標 x 2〜5・z 8〜9.25。
    // 3D の中心は toScene で (3.5 − 4.5, 8.625 − 4) = (−1, 4.625)
    const parts = exteriorParts(SIZE, balcony(), 2);
    expect(parts.map((part) => part.position.map(round3))).toEqual([
      [-1, 2.875, 4.625], // スラブ（上面が 2 階の床）
      [-1, 3.5, 5.25], // 外側（南）の 1 辺
      [-2.5, 3.5, 4.625], // 西の端
      [0.5, 3.5, 4.625], // 東の端
    ]);
    expect(parts[1].size).toEqual([3, 1.1, 0.06]);
    expect(parts[2].size).toEqual([0.06, 1.1, 1.25]);
  });

  it("東西の面では、外へ出る向きと手すりの並びが入れ替わる", () => {
    const east = exteriorParts(SIZE, balcony({ side: "e", start: 1, length: 2, depth: 1 }), 1);
    // 床座標 x 9〜10・z 1〜3 → 中心 (5, −2)。外側は東（+x）
    expect(east.map((part) => part.position.map(round3))).toEqual([
      [5, -0.075, -2],
      [5.5, 0.55, -2],
      [5, 0.55, -3],
      [5, 0.55, -1],
    ]);
    expect(east[1].size).toEqual([0.06, 1.1, 2]);
    expect(east[2].size).toEqual([1, 1.1, 0.06]);
    // 西の面は外側が −x
    const west = exteriorParts(SIZE, balcony({ side: "w", start: 1, length: 2, depth: 1 }), 1);
    expect(west[0].position.map(round3)).toEqual([-5, -0.075, -2]);
    expect(west[1].position.map(round3)).toEqual([-5.5, 0.55, -2]);
  });

  it("id は重複しない", () => {
    const ids = exteriorParts(SIZE, balcony(), 2).map((p) => p.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});
