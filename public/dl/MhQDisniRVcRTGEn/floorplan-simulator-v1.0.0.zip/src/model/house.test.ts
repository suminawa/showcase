import { describe, expect, it } from "vitest";
import {
  baseOf,
  cameraPose,
  CELL,
  ceilingOf,
  cellCountOf,
  clampPlanSize,
  colsOf,
  DEFAULT_SCENE_COLORS,
  DEFAULT_SIZE,
  FLOOR_TONE,
  floorsOf,
  houseOf,
  isCutaway,
  isPlanSize,
  lightingPreset,
  rowsOf,
  SELECTED_FLOOR_TONE,
  showsRoof,
  SIZE_MAX,
  SIZE_MIN,
  SIZE_PRESETS,
  SNAP,
  topOf,
  visibleFloors,
  WINDOW_TONE,
  type PlanSize,
} from "./house";

const HEX = /^#[0-9a-f]{6}$/;

describe("外皮の寸法", () => {
  it("既定は見本と同じ 9 × 8 m の 2 階建て", () => {
    expect(DEFAULT_SIZE).toEqual({ width: 9, depth: 8, floors: 2 });
    expect(CELL).toBe(0.5);
    expect(SNAP).toBe(0.25);
  });

  it("マス数は間口・奥行き ÷ 0.5", () => {
    expect(colsOf(DEFAULT_SIZE)).toBe(18);
    expect(rowsOf(DEFAULT_SIZE)).toBe(16);
    expect(cellCountOf(DEFAULT_SIZE)).toBe(288);
    const big: PlanSize = { width: 16, depth: 12, floors: 2 };
    expect(cellCountOf(big)).toBe(32 * 24);
  });

  it("houseOf は size から寸法を作り、階の高さは固定", () => {
    const h = houseOf({ width: 12, depth: 10, floors: 2 });
    expect(h.width).toBe(12);
    expect(h.depth).toBe(10);
    expect(h.floors[1]).toEqual({ base: 0, height: 2.7 });
    expect(h.floors[2]).toEqual({ base: 2.95, height: 2.5 });
    expect(h.wallThickness).toBe(0.2);
    expect(h.slabThickness).toBe(0.25);
    expect(h.cutawayWallHeight).toBe(1.1);
    expect(h.eaves).toBe(0.5);
    expect(h.roofRise).toBe(1.6);
  });

  it("baseOf / ceilingOf / topOf", () => {
    expect(baseOf(DEFAULT_SIZE, 1)).toBe(0);
    expect(baseOf(DEFAULT_SIZE, 2)).toBe(2.95);
    expect(ceilingOf(DEFAULT_SIZE, 1)).toBe(2.7);
    expect(ceilingOf(DEFAULT_SIZE, 2)).toBe(2.5);
    expect(topOf(DEFAULT_SIZE)).toBe(5.45);
    // 平屋は 1 階の天井が最上
    expect(topOf({ width: 9, depth: 8, floors: 1 })).toBe(2.7);
  });

  it("floorsOf は平屋なら 1 階だけ", () => {
    expect(floorsOf(DEFAULT_SIZE)).toEqual([1, 2]);
    expect(floorsOf({ width: 9, depth: 8, floors: 1 })).toEqual([1]);
  });

  it("isPlanSize は 0.5 の倍数で 4〜16 m のものだけ通す", () => {
    expect(isPlanSize({ width: 9, depth: 8, floors: 2 })).toBe(true);
    expect(isPlanSize({ width: 9.25, depth: 8, floors: 2 })).toBe(false);
    expect(isPlanSize({ width: 3.5, depth: 8, floors: 2 })).toBe(false);
    expect(isPlanSize({ width: 16.5, depth: 8, floors: 2 })).toBe(false);
    expect(isPlanSize({ width: 9, depth: 8, floors: 3 })).toBe(false);
    expect(isPlanSize({ width: 9, depth: 8 })).toBe(false);
    expect(isPlanSize(null)).toBe(false);
  });

  it("clampPlanSize は刻みと範囲に寄せる", () => {
    expect(clampPlanSize({ width: 9.3, depth: 2, floors: 2 })).toEqual({
      width: 9.5,
      depth: SIZE_MIN,
      floors: 2,
    });
    expect(clampPlanSize({ width: 99, depth: 99, floors: 1 })).toEqual({
      width: SIZE_MAX,
      depth: SIZE_MAX,
      floors: 1,
    });
  });

  it("プリセットは 5 種あり、すべて範囲の中", () => {
    expect(SIZE_PRESETS).toHaveLength(5);
    const ids = SIZE_PRESETS.map((p) => p.id);
    expect(new Set(ids).size).toBe(5);
    for (const preset of SIZE_PRESETS) {
      expect(isPlanSize(preset.size)).toBe(true);
      expect(preset.name.length).toBeGreaterThan(0);
    }
  });
});

describe("3D の中の色", () => {
  it("既定の色はすべて #rrggbb", () => {
    for (const value of Object.values(DEFAULT_SCENE_COLORS)) {
      expect(value).toMatch(HEX);
    }
    expect(FLOOR_TONE[1]).toMatch(HEX);
    expect(FLOOR_TONE[2]).toMatch(HEX);
    expect(SELECTED_FLOOR_TONE).toMatch(HEX);
    expect(WINDOW_TONE.day).toMatch(HEX);
    expect(WINDOW_TONE.night).toMatch(HEX);
    expect(WINDOW_TONE.emissive).toMatch(HEX);
  });
});

describe("昼夜の明かり", () => {
  it("昼のほうが日射しが強く、夜は窓が光る", () => {
    const day = lightingPreset("day");
    const night = lightingPreset("night");
    expect(day.key.intensity).toBeGreaterThan(night.key.intensity);
    expect(night.windowEmissive).toBeGreaterThan(day.windowEmissive);
    expect(day.background).not.toBe(night.background);
    expect(day.key.position[0]).toBeGreaterThan(0);
    expect(night.key.position[0]).toBeLessThan(0);
  });
});

describe("表示の切替", () => {
  it("全体のときだけ屋根を載せ、階を選んだときは腰で切る", () => {
    expect(showsRoof("all")).toBe(true);
    expect(isCutaway("all")).toBe(false);
    expect(showsRoof("1f")).toBe(false);
    expect(isCutaway("1f")).toBe(true);
  });

  it("visibleFloors は平屋のとき 2F を出さない", () => {
    expect(visibleFloors(DEFAULT_SIZE, "all")).toEqual([1, 2]);
    expect(visibleFloors(DEFAULT_SIZE, "2f")).toEqual([2]);
    const flat: PlanSize = { width: 9, depth: 8, floors: 1 };
    expect(visibleFloors(flat, "all")).toEqual([1]);
    expect(visibleFloors(flat, "2f")).toEqual([1]);
  });
});

describe("cameraPose", () => {
  it("外皮が大きいほど遠くから見る", () => {
    const small = cameraPose({ width: 9, depth: 8, floors: 2 }, "all", "orbit");
    const big = cameraPose({ width: 16, depth: 16, floors: 2 }, "all", "orbit");
    // 見本と同じ 9 m 幅なら k = 1、「全体」の引きは 1.3 倍。9.75 / 7.5 / 10.5 × 1.3
    expect(small.position).toEqual([12.675, 9.75, 13.65]);
    expect(big.position[0]).toBeGreaterThan(small.position[0]);
    expect(big.position[1]).toBeGreaterThan(small.position[1]);
  });

  it("「全体」は小さい家でも 1.3 倍まで引き、土台を枠の中に納める", () => {
    // 長辺 9 m 未満は k < 1。ここで寄せると屋根か土台が 16:9 の枠から出る
    const small = cameraPose({ width: 8, depth: 7, floors: 2 }, "all", "orbit");
    expect(small.position).toEqual([12.675, 9.75, 13.65]);
    expect(small.target).toEqual([0, 2.6, 0]);
    // 長辺 16 m なら k = 16 / 9、引きは k + 0.3
    const big = cameraPose({ width: 16, depth: 16, floors: 2 }, "all", "orbit");
    const m = 16 / 9 + 0.3;
    expect(big.position[0]).toBeCloseTo(9.75 * m, 9);
    expect(big.position[1]).toBeCloseTo(7.5 * m, 9);
    expect(big.position[2]).toBeCloseTo(10.5 * m, 9);
    // OrbitControls の minDistance 5 / maxDistance 60 の中に入る
    for (const pose of [small, big]) {
      const d = Math.hypot(pose.position[0], pose.position[1] - pose.target[1], pose.position[2]);
      expect(d).toBeGreaterThan(5);
      expect(d).toBeLessThan(60);
    }
  });

  it("斜めからの 3 つは、家が枠いっぱいに映る距離（0.75 倍）", () => {
    const size: PlanSize = { width: 9, depth: 8, floors: 2 };
    // 11 / 8 / 12 → 8.25 / 6 / 9
    expect(cameraPose(size, "1f", "orbit").position).toEqual([8.25, 6, 9]);
    // 11 / 11 / 12 → 8.25 / 8.25 / 9
    expect(cameraPose(size, "2f", "orbit").position).toEqual([8.25, 8.25, 9]);
    // 注視点は前のまま（高さだけで家を見上げる／見下ろす角度が決まる）
    expect(cameraPose(size, "1f", "orbit").target).toEqual([0, 1.4, 0]);
    expect(cameraPose(size, "2f", "orbit").target).toEqual([0, 2.95 + 1.25, 0]);
    expect(cameraPose(size, "all", "orbit").target).toEqual([0, 2.6, 0]);
    // 長辺 16 m なら k = 16 / 9
    const wide = cameraPose({ width: 16, depth: 8, floors: 2 }, "1f", "orbit");
    expect(wide.position[0]).toBeCloseTo((8.25 * 16) / 9, 9);
  });

  it("真上からは z をわずかにずらす", () => {
    const top = cameraPose(DEFAULT_SIZE, "all", "top");
    expect(top.position[0]).toBe(0);
    expect(top.position[2]).toBe(0.01);
    expect(top.target).toEqual([0, 0, 0]);
  });

  it("真上から階を選ぶと、その階の床の上から見下ろす", () => {
    const second = cameraPose(DEFAULT_SIZE, "2f", "top");
    expect(second.position[1]).toBeGreaterThan(2.95);
    expect(second.target[1]).toBe(2.95);
  });
});
