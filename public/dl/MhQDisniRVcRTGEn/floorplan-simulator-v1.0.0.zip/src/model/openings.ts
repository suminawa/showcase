/**
 * 売り物: 建具（ドア・引き戸・窓）。
 * 壁は wallSegments が毎回マス目から作り直すので、区間の id は塗り替えで変わる。
 * そこで建具は「区間」ではなく「マス目の線」に直に乗せる（塗り替えても位置がずれない）。
 * 2D には記号（弧・平行線・窓線）で描き、3D には開口が空く（shell.ts の wallPieces）。
 */
import { snapValue } from "./dimensions";
import { nextSeqId, round2 } from "./furniture";
import { cellAt, type GridLayout } from "./grid";
import { CELL, HEIGHT_SNAP, SNAP, type PlanSize } from "./house";

export type OpeningKind = "door" | "sliding" | "window";

/** 窓だけ持つ。腰窓 / 掃き出し窓 */
export type WindowStyle = "koshi" | "hakidashi";

/** 壁に沿ってどちら側か。start = 壁の始まり側（座標の小さいほう） */
export type Side = "start" | "end";

/** 壁の法線のどちら側か。axis "x" の壁なら plus = +x（東）、axis "z" なら plus = +z（南） */
export type Face = "plus" | "minus";

export type Opening = {
  /** "o-<n>" の連番 */
  id: string;
  kind: OpeningKind;
  /** 窓のときだけ使う */
  style: WindowStyle | null;
  /** "x" = x = at に立つ南北の壁、"z" = z = at に立つ東西の壁 */
  axis: "x" | "z";
  /** 壁の線の位置（m）。CELL の倍数。0 と間口 / 奥行きは外壁 */
  at: number;
  /** 壁に沿った開口の始まり（m）。SNAP の倍数 */
  start: number;
  /** 開口の幅（m）。SNAP の倍数、0.5 以上 3.5 以下 */
  width: number;
  /** 下端の高さ（m）。0.05 刻み */
  sill: number;
  /** 開口の高さ（m）。0.05 刻み。sill + height ≤ 階の天井高 */
  height: number;
  /** ドア: 吊元。引き戸: 引き込む側。窓: 使わない（"start" で保存） */
  hinge: Side;
  /** ドア: 開く側。引き戸・窓: 使わない（"plus" で保存） */
  swing: Face;
};

export type OpeningPresetId = "door" | "sliding" | "koshi" | "hakidashi";

export const OPENING_PRESETS: Record<
  OpeningPresetId,
  { kind: OpeningKind; style: WindowStyle | null; name: string; width: number; sill: number; height: number }
> = {
  door: { kind: "door", style: null, name: "ドア", width: 0.75, sill: 0, height: 2 },
  sliding: { kind: "sliding", style: null, name: "引き戸", width: 1.5, sill: 0, height: 2 },
  koshi: { kind: "window", style: "koshi", name: "腰窓", width: 1.5, sill: 0.9, height: 1.2 },
  hakidashi: { kind: "window", style: "hakidashi", name: "掃き出し窓", width: 1.75, sill: 0, height: 2 },
};

export const OPENING_MIN_WIDTH = 0.5;
export const OPENING_MAX_WIDTH = 3.5;
/** 建具の高さの下限 */
export const OPENING_MIN_HEIGHT = 0.3;

/** その軸の線の長さ。axis "x" の線は南北に走るので奥行きぶん */
export function runLengthOf(size: PlanSize, axis: "x" | "z"): number {
  return axis === "x" ? size.depth : size.width;
}

/** value が step の倍数か（浮動小数の誤差を見込む） */
function onStep(value: number, step: number): boolean {
  if (!Number.isFinite(value)) return false;
  return Math.abs(value / step - Math.round(value / step)) < 1e-6;
}

/**
 * その線のその 1 マス分が壁か。
 * at が 0 または間口 / 奥行きなら外壁で常に true。内側なら両隣のマスの部屋 id が違えば true。
 * index は線に沿ったマスの番号（axis "x" なら row、"z" なら col）。
 */
export function wallAt(
  layout: GridLayout,
  size: PlanSize,
  axis: "x" | "z",
  at: number,
  index: number,
): boolean {
  const length = runLengthOf(size, axis);
  const across = axis === "x" ? size.width : size.depth;
  const cells = Math.round(length / CELL);
  if (index < 0 || index >= cells) return false;
  if (at <= 0 || at >= across) return at === 0 || Math.abs(at - across) < 1e-9;
  const line = Math.round(at / CELL);
  if (axis === "x") {
    return layout.cells[cellAt(size, line - 1, index)] !== layout.cells[cellAt(size, line, index)];
  }
  return layout.cells[cellAt(size, index, line - 1)] !== layout.cells[cellAt(size, index, line)];
}

/** [start, start + width) に重なるマスの番号 */
function cellsUnder(start: number, width: number): number[] {
  const first = Math.floor(start / CELL + 1e-9);
  const last = Math.ceil((start + width) / CELL - 1e-9) - 1;
  const out: number[] = [];
  for (let index = first; index <= last; index++) out.push(index);
  return out;
}

function overlaps(a: Opening, b: Opening): boolean {
  if (a.axis !== b.axis || Math.abs(a.at - b.at) > 1e-9) return false;
  return !(a.start + a.width <= b.start + 1e-9 || b.start + b.width <= a.start + 1e-9);
}

/**
 * 開口が壁の上にあり、線の外へ出ず、天井を超えず、幅が範囲内で、
 * 同じ線のほかの建具と重なっていないか。
 */
export function openingFits(
  layout: GridLayout,
  size: PlanSize,
  ceiling: number,
  openings: readonly Opening[],
  o: Opening,
  ignoreId?: string,
): boolean {
  const across = o.axis === "x" ? size.width : size.depth;
  if (!onStep(o.at, CELL) || o.at < 0 || o.at > across + 1e-9) return false;
  if (!onStep(o.start, SNAP) || !onStep(o.width, SNAP)) return false;
  if (!onStep(o.sill, HEIGHT_SNAP) || !onStep(o.height, HEIGHT_SNAP)) return false;
  if (o.width < OPENING_MIN_WIDTH - 1e-9 || o.width > OPENING_MAX_WIDTH + 1e-9) return false;
  if (o.height < OPENING_MIN_HEIGHT - 1e-9 || o.sill < -1e-9) return false;
  if (o.sill + o.height > ceiling + 1e-9) return false;
  const length = runLengthOf(size, o.axis);
  if (o.start < -1e-9 || o.start + o.width > length + 1e-9) return false;
  for (const index of cellsUnder(o.start, o.width)) {
    if (!wallAt(layout, size, o.axis, o.at, index)) return false;
  }
  for (const other of openings) {
    if (other.id === o.id || other.id === ignoreId) continue;
    if (overlaps(other, o)) return false;
  }
  return true;
}

/** その壁の走りに乗っている建具（start の昇順） */
export function openingsOnRun(
  openings: readonly Opening[],
  axis: "x" | "z",
  at: number,
  from: number,
  to: number,
): Opening[] {
  return openings
    .filter(
      (o) =>
        o.axis === axis &&
        Math.abs(o.at - at) < 1e-9 &&
        o.start + o.width > from + 1e-9 &&
        o.start < to - 1e-9,
    )
    .slice()
    .sort((a, b) => a.start - b.start);
}

/** 床の点にいちばん近いマス目の線。along はその線に沿った座標 */
export function nearestWallLine(
  size: PlanSize,
  x: number,
  z: number,
): { axis: "x" | "z"; at: number; along: number } {
  const atX = Math.min(Math.max(Math.round(x / CELL) * CELL, 0), size.width);
  const atZ = Math.min(Math.max(Math.round(z / CELL) * CELL, 0), size.depth);
  if (Math.abs(x - atX) <= Math.abs(z - atZ)) {
    return { axis: "x", at: round2(atX), along: round2(z) };
  }
  return { axis: "z", at: round2(atZ), along: round2(x) };
}

/** タップした点を中心にして建具を作る。入らなければ null */
export function placeOpening(
  layout: GridLayout,
  size: PlanSize,
  ceiling: number,
  openings: readonly Opening[],
  presetId: OpeningPresetId,
  x: number,
  z: number,
): Opening | null {
  const preset = OPENING_PRESETS[presetId];
  const line = nearestWallLine(size, x, z);
  const length = runLengthOf(size, line.axis);
  const width = Math.min(preset.width, length);
  const start = snapValue(line.along - width / 2, SNAP, 0, round2(length - width));
  const height = Math.min(preset.height, round2(ceiling - preset.sill));
  const opening: Opening = {
    id: nextSeqId(openings, "o"),
    kind: preset.kind,
    style: preset.style,
    axis: line.axis,
    at: line.at,
    start,
    width,
    sill: preset.sill,
    height,
    hinge: "start",
    swing: "plus",
  };
  return openingFits(layout, size, ceiling, openings, opening) ? opening : null;
}

/** 入らなければ同じ参照を返す */
export function addOpening(
  layout: GridLayout,
  size: PlanSize,
  ceiling: number,
  openings: readonly Opening[],
  o: Opening,
): Opening[] {
  const next: Opening = { ...o, id: o.id === "" ? nextSeqId(openings, "o") : o.id };
  if (!openingFits(layout, size, ceiling, openings, next)) return openings as Opening[];
  return [...openings, next];
}

export function moveOpening(
  layout: GridLayout,
  size: PlanSize,
  ceiling: number,
  openings: readonly Opening[],
  id: string,
  start: number,
): Opening[] {
  const current = openings.find((o) => o.id === id);
  if (!current) return openings as Opening[];
  const length = runLengthOf(size, current.axis);
  const next: Opening = {
    ...current,
    start: snapValue(start, SNAP, 0, round2(length - current.width)),
  };
  if (!openingFits(layout, size, ceiling, openings, next, id)) return openings as Opening[];
  return openings.map((o) => (o.id === id ? next : o));
}

export type OpeningPatch = Partial<Pick<Opening, "width" | "sill" | "height" | "hinge" | "swing" | "start">>;

/** 幅・高さ・下端・開き勝手を変える。入らなければ同じ参照 */
export function resizeOpening(
  layout: GridLayout,
  size: PlanSize,
  ceiling: number,
  openings: readonly Opening[],
  id: string,
  patch: OpeningPatch,
): Opening[] {
  const current = openings.find((o) => o.id === id);
  if (!current) return openings as Opening[];
  const length = runLengthOf(size, current.axis);
  const width = patch.width === undefined
    ? current.width
    : snapValue(patch.width, SNAP, OPENING_MIN_WIDTH, Math.min(OPENING_MAX_WIDTH, length));
  const sill = patch.sill === undefined
    ? current.sill
    : snapValue(patch.sill, HEIGHT_SNAP, 0, Math.max(0, round2(ceiling - OPENING_MIN_HEIGHT)));
  const height = patch.height === undefined
    ? current.height
    : snapValue(patch.height, HEIGHT_SNAP, OPENING_MIN_HEIGHT, round2(ceiling - sill));
  const start = patch.start === undefined
    ? snapValue(current.start, SNAP, 0, round2(length - width))
    : snapValue(patch.start, SNAP, 0, round2(length - width));
  const next: Opening = {
    ...current,
    width,
    sill,
    height,
    start,
    hinge: patch.hinge ?? current.hinge,
    swing: patch.swing ?? current.swing,
  };
  if (!openingFits(layout, size, ceiling, openings, next, id)) return openings as Opening[];
  return openings.map((o) => (o.id === id ? next : o));
}

export function removeOpening(openings: readonly Opening[], id: string): Opening[] {
  return openings.filter((o) => o.id !== id);
}

/**
 * 塗り替え・外皮の変更で壁が無くなった建具を落とす。部屋の prune と同じ考え方。
 * マス目や外皮を変える操作のあと必ず通す。1 つも落ちないときは同じ参照を返す。
 */
export function pruneOpenings(
  layout: GridLayout,
  size: PlanSize,
  ceiling: number,
  openings: readonly Opening[],
): Opening[] {
  const kept = openings.filter((o) => openingFits(layout, size, ceiling, openings, o, o.id));
  return kept.length === openings.length ? (openings as Opening[]) : kept;
}

/**
 * 開き勝手を送る。ドアは 吊元 × 開く側 の 4 通り、引き戸は引き込む側の 2 通り、窓は変わらない。
 */
export function cycleSwing(o: Opening): Opening {
  if (o.kind === "window") return o;
  if (o.kind === "sliding") {
    return { ...o, hinge: o.hinge === "start" ? "end" : "start" };
  }
  if (o.hinge === "start" && o.swing === "plus") return { ...o, hinge: "start", swing: "minus" };
  if (o.hinge === "start" && o.swing === "minus") return { ...o, hinge: "end", swing: "plus" };
  if (o.hinge === "end" && o.swing === "plus") return { ...o, hinge: "end", swing: "minus" };
  return { ...o, hinge: "start", swing: "plus" };
}
