import { describe, expect, it } from "vitest";
import {
  buildGlyph,
  buildParts,
  clampSize,
  defaultSeed,
  findPreset,
  FURNITURE,
  furnitureType,
  presetSeed,
  screenHeight,
  screenWidth,
  tvSeed,
  tvSize,
  tvStandHint,
  TV_DIAGONAL,
} from "./catalog";
import { addFurniture, resizeFurniture, type PlacedFurniture, type Size3 } from "./furniture";
import { DEFAULT_SIZE } from "./house";

const HEX = /^#[0-9a-f]{6}$/;

function place(type: PlacedFurniture["type"], size: Size3, preset: string | null = null): PlacedFurniture {
  return { id: "f-1", type, preset, size, inch: null, x: 2, z: 2, rotation: 0 };
}

describe("家具の表", () => {
  it("18 種あり、id と名前は重複しない", () => {
    expect(FURNITURE).toHaveLength(18);
    expect(new Set(FURNITURE.map((type) => type.id)).size).toBe(18);
    expect(new Set(FURNITURE.map((type) => type.name)).size).toBe(18);
  });

  it("標準寸法の id はすべて重複せず、limits の中にある", () => {
    const ids = new Set<string>();
    for (const type of FURNITURE) {
      expect(type.presets.length).toBeGreaterThan(0);
      for (const preset of type.presets) {
        expect(ids.has(preset.id)).toBe(false);
        ids.add(preset.id);
        expect(preset.size.w).toBeGreaterThanOrEqual(type.limits.w[0]);
        expect(preset.size.w).toBeLessThanOrEqual(type.limits.w[1]);
        expect(preset.size.d).toBeGreaterThanOrEqual(type.limits.d[0]);
        expect(preset.size.d).toBeLessThanOrEqual(type.limits.d[1]);
        expect(preset.size.h).toBeGreaterThanOrEqual(type.limits.h[0]);
        expect(preset.size.h).toBeLessThanOrEqual(type.limits.h[1]);
      }
    }
  });

  it("決めた寸法がそのまま入っている", () => {
    expect(findPreset("bed", "bed-d")?.size).toEqual({ w: 1.4, d: 1.95, h: 0.5 });
    expect(findPreset("sofa", "sofa-3")?.size).toEqual({ w: 1.9, d: 0.85, h: 0.8 });
    expect(findPreset("dining", "dining-6")?.size).toEqual({ w: 2.2, d: 1.5, h: 0.72 });
    expect(findPreset("dining", "dining-6")?.top).toEqual({ w: 1.8, d: 0.9 });
    expect(findPreset("kitchen", "kitchen-i")?.size).toEqual({ w: 2.55, d: 0.65, h: 0.85 });
    expect(findPreset("kitchen", "kitchen-l")?.size).toEqual({ w: 2.55, d: 1.65, h: 0.85 });
    expect(findPreset("toilet", "toilet-tankless")?.size).toEqual({ w: 0.4, d: 0.7, h: 0.45 });
    expect(findPreset("piano", "piano-grand")?.size).toEqual({ w: 1.5, d: 1.9, h: 1 });
    expect(findPreset("fridge", "fridge-500")?.size).toEqual({ w: 0.7, d: 0.7, h: 1.85 });
  });

  it("未知の家具は投げる", () => {
    expect(() => furnitureType("nope" as never)).toThrow();
    expect(findPreset("bed", "nope")).toBeNull();
  });

  it("どの箱も size の中に収まり、色は #rrggbb", () => {
    for (const type of FURNITURE) {
      for (const preset of type.presets) {
        const parts = type.build(preset.size, preset);
        expect(parts.length).toBeGreaterThan(0);
        for (const part of parts) {
          expect(part.color).toMatch(HEX);
          expect(Math.abs(part.offset[0]) + part.size[0] / 2).toBeLessThanOrEqual(preset.size.w / 2 + 1e-9);
          expect(Math.abs(part.offset[2]) + part.size[2] / 2).toBeLessThanOrEqual(preset.size.d / 2 + 1e-9);
          expect(part.offset[1] + part.size[1] / 2).toBeLessThanOrEqual(preset.size.h + 1e-9);
          expect(part.offset[1] - part.size[1] / 2).toBeGreaterThanOrEqual(-1e-9);
          expect(part.size[0]).toBeGreaterThan(0);
          expect(part.size[1]).toBeGreaterThan(0);
          expect(part.size[2]).toBeGreaterThan(0);
        }
      }
    }
  });

  it("平面図の記号も size の中に収まる", () => {
    for (const type of FURNITURE) {
      for (const preset of type.presets) {
        const glyph = type.glyph(preset.size, preset);
        expect(glyph.rects.length).toBeGreaterThan(0);
        for (const rect of glyph.rects) {
          expect(Math.abs(rect.x) + rect.w / 2).toBeLessThanOrEqual(preset.size.w / 2 + 1e-9);
          expect(Math.abs(rect.z) + rect.d / 2).toBeLessThanOrEqual(preset.size.d / 2 + 1e-9);
        }
        for (const line of glyph.lines ?? []) {
          expect(Math.abs(line.x1)).toBeLessThanOrEqual(preset.size.w / 2 + 1e-9);
          expect(Math.abs(line.x2)).toBeLessThanOrEqual(preset.size.w / 2 + 1e-9);
          expect(Math.abs(line.z1)).toBeLessThanOrEqual(preset.size.d / 2 + 1e-9);
          expect(Math.abs(line.z2)).toBeLessThanOrEqual(preset.size.d / 2 + 1e-9);
        }
      }
    }
  });

  it("任意寸法でも箱と記号が size の中に収まる", () => {
    for (const type of FURNITURE) {
      const size: Size3 = {
        w: type.limits.w[1],
        d: type.limits.d[0],
        h: type.limits.h[0],
      };
      for (const part of type.build(size, null)) {
        expect(Math.abs(part.offset[0]) + part.size[0] / 2).toBeLessThanOrEqual(size.w / 2 + 1e-9);
        expect(part.offset[1] + part.size[1] / 2).toBeLessThanOrEqual(size.h + 1e-9);
      }
      for (const rect of type.glyph(size, null).rects) {
        expect(Math.abs(rect.x) + rect.w / 2).toBeLessThanOrEqual(size.w / 2 + 1e-9);
      }
    }
  });
});

describe("標準寸法と任意寸法", () => {
  it("presetSeed は標準寸法を入れ、defaultSeed は 1 つ目", () => {
    const seed = presetSeed("bed", "bed-q");
    expect(seed).toEqual({ type: "bed", preset: "bed-q", size: { w: 1.6, d: 1.95, h: 0.5 }, inch: null });
    expect(defaultSeed("bed").preset).toBe(FURNITURE.find((t) => t.id === "bed")!.presets[0].id);
    // 未知の標準寸法は 1 つ目に落とす
    expect(presetSeed("bed", "nope").preset).toBe("bed-s");
  });

  it("clampSize は刻みに丸めて範囲に収める", () => {
    expect(clampSize("sofa", { w: 1.83, d: 0.9, h: 0.83 })).toEqual({ w: 1.75, d: 1, h: 0.85 });
    expect(clampSize("sofa", { w: 99, d: 0, h: 0 })).toEqual({ w: 3, d: 0.5, h: 0.4 });
    // テレビだけは 0.01 刻み（インチから作るため）
    expect(clampSize("tv", { w: 1.24, d: 0.06, h: 0.7 })).toEqual({ w: 1.24, d: 0.06, h: 0.7 });
  });

  it("打ち込んだ寸法は 幅・奥行き 0.25 m、高さ 0.05 m の刻みに乗り、範囲の中に収まる", () => {
    for (const type of FURNITURE) {
      // 刻みからわざと外した値を打ち込む
      const typed = clampSize(type.id, { w: 1.23, d: 0.77, h: 1.11 });
      for (const axis of ["w", "d", "h"] as const) {
        const step = type.step[axis];
        expect(Math.abs(typed[axis] / step - Math.round(typed[axis] / step))).toBeLessThan(1e-9);
        expect(typed[axis]).toBeGreaterThanOrEqual(type.limits[axis][0]);
        expect(typed[axis]).toBeLessThanOrEqual(type.limits[axis][1]);
      }
    }
  });

  it("標準寸法は clampSize を通さない（通すと表の寸法と食い違う）", () => {
    // presetSeed → resizeFurniture のひとまわりで、表の寸法がそのまま残る
    for (const type of FURNITURE) {
      for (const preset of type.presets) {
        const seed = presetSeed(type.id, preset.id);
        expect(seed.size).toEqual(preset.size);
        const list = addFurniture(DEFAULT_SIZE, [], seed, [4.5, 4]);
        expect(list[0].size).toEqual(preset.size);
        const back = resizeFurniture(DEFAULT_SIZE, list, "f-1", { ...preset.size, preset: preset.id });
        expect(back[0].size).toEqual(preset.size);
        expect(back[0].preset).toBe(preset.id);
      }
    }
    // 実際、43 件のうち大半は 0.25 / 0.05 の刻みに乗っていない
    const offGrid = FURNITURE.flatMap((type) =>
      type.presets.filter((preset) => {
        const snapped = clampSize(type.id, preset.size);
        return snapped.w !== preset.size.w || snapped.d !== preset.size.d || snapped.h !== preset.size.h;
      }),
    );
    expect(offGrid.length).toBeGreaterThan(30);
    // 例: ベッドの奥行き 1.95 m、キッチンの奥行き 0.65 m
    expect(clampSize("bed", { w: 1.6, d: 1.95, h: 0.5 })).toEqual({ w: 1.5, d: 2, h: 0.5 });
    expect(clampSize("kitchen", { w: 2.55, d: 0.65, h: 0.85 })).toEqual({ w: 2.5, d: 0.75, h: 0.85 });
  });
});

describe("組み立てに癖のある種類", () => {
  it("ダイニングは天板 + 脚 4 本 + 椅子 4 脚", () => {
    const preset = findPreset("dining", "dining-4")!;
    const parts = furnitureType("dining").build(preset.size, preset);
    // legged が 天板 1 + 脚 4、そのあとに椅子 4
    expect(parts).toHaveLength(9);
    const chairs = parts.slice(5);
    // 椅子の 1 辺は min(0.4, 天板の幅/2, (奥行き − 天板の奥行き)/2) = (1.4 − 0.8)/2 = 0.3
    // 位置は 天板の幅/2 − 0.15 = 0.45 と 奥行き/2 − 0.15 = 0.55
    expect(chairs.map((part) => [part.offset[0], part.offset[2]])).toEqual([
      [-0.45, -0.55],
      [0.45, -0.55],
      [-0.45, 0.55],
      [0.45, 0.55],
    ]);
    expect(chairs.every((part) => Math.abs(part.size[0] - 0.3) < 1e-9 && part.size[0] === part.size[2])).toBe(true);
  });

  it("キッチンは L 型だけ短い腕が付く", () => {
    const i = furnitureType("kitchen");
    expect(i.build(findPreset("kitchen", "kitchen-i")!.size, findPreset("kitchen", "kitchen-i"))).toHaveLength(2);
    const arm = i.build(findPreset("kitchen", "kitchen-l")!.size, findPreset("kitchen", "kitchen-l"));
    expect(arm).toHaveLength(4);
    // 腕は西側（−x）に寄り、南（+z）へ 1 m ぶん出る
    expect(arm[2].offset[0]).toBeCloseTo(-0.95, 9);
    expect(arm[2].size[2]).toBeCloseTo(1, 9);
    expect(i.glyph(findPreset("kitchen", "kitchen-l")!.size, findPreset("kitchen", "kitchen-l")).rects).toHaveLength(3);
  });

  it("トイレはタンクありだけ 2 つの箱になる", () => {
    const toilet = furnitureType("toilet");
    const tank = findPreset("toilet", "toilet-tank")!;
    const tankless = findPreset("toilet", "toilet-tankless")!;
    expect(toilet.build(tank.size, tank)).toHaveLength(2);
    expect(toilet.build(tankless.size, tankless)).toHaveLength(1);
    // タンクは北（−z）の端に立つ
    expect(toilet.build(tank.size, tank)[1].offset[2]).toBeCloseTo(-(0.8 / 2 - 0.2 / 2), 9);
  });

  it("洗面台は背が高いときだけ鏡が付く", () => {
    const vanity = furnitureType("vanity");
    const tall = findPreset("vanity", "vanity-75")!;
    expect(vanity.build(tall.size, tall)).toHaveLength(3);
    // 鏡は北（−z）の壁面に、キャビネットの上から
    const mirror = vanity.build(tall.size, tall)[2];
    expect(mirror.offset[2]).toBeCloseTo(-(0.55 / 2 - 0.05), 9);
    expect(mirror.offset[1]).toBeGreaterThan(0.8);
    // 低い洗面台には鏡を付けない
    expect(vanity.build({ w: 0.75, d: 0.55, h: 0.85 }, null)).toHaveLength(2);
  });
});

describe("テレビのインチ", () => {
  it("16:9 の対角から画面の幅と高さを出す", () => {
    expect(TV_DIAGONAL).toBeCloseTo(18.357559750685819, 12);
    expect(screenWidth(43)).toBe(0.95);
    expect(screenWidth(55)).toBe(1.22);
    expect(screenWidth(65)).toBe(1.44);
    expect(screenWidth(75)).toBe(1.66);
    expect(screenHeight(43)).toBe(0.54);
    expect(screenHeight(55)).toBe(0.68);
    expect(screenHeight(65)).toBe(0.81);
    expect(screenHeight(75)).toBe(0.93);
  });

  it("任意のインチも式どおり", () => {
    expect(screenWidth(32)).toBe(0.71);
    expect(screenHeight(32)).toBe(0.4);
    expect(screenWidth(85)).toBe(1.88);
    expect(screenHeight(85)).toBe(1.06);
  });

  it("本体は画面の幅 + 0.02、奥行き 0.06", () => {
    expect(tvSize(55)).toEqual({ w: 1.24, d: 0.06, h: 0.7 });
    expect(tvSeed(55)).toEqual({ type: "tv", preset: "tv-55", size: { w: 1.24, d: 0.06, h: 0.7 }, inch: 55 });
    // 標準に無いインチは preset を持たない
    expect(tvSeed(50).preset).toBeNull();
    expect(tvSeed(50).inch).toBe(50);
  });

  it("テレビ台の目安は 画面幅 + 0.2 を 0.1 刻みで切り上げ", () => {
    expect(tvStandHint(43)).toBe(1.2);
    expect(tvStandHint(55)).toBe(1.5);
    expect(tvStandHint(65)).toBe(1.7);
    expect(tvStandHint(75)).toBe(1.9);
  });
});

describe("buildParts / buildGlyph", () => {
  it("置いた家具から箱と記号を作る", () => {
    const item = place("sofa", { w: 1.9, d: 0.85, h: 0.8 }, "sofa-3");
    expect(buildParts(item).length).toBeGreaterThan(0);
    expect(buildGlyph(item).rects.length).toBeGreaterThan(0);
  });

  it("寸法を変えると箱の大きさも変わる", () => {
    const small = buildParts(place("shelf", { w: 0.6, d: 0.3, h: 1.8 }, "shelf-60"));
    const large = buildParts(place("shelf", { w: 2, d: 0.3, h: 1.8 }, null));
    // [0]/[1] は側板で、幅は d 由来の板厚（今回は d が同じなので変わらない）。
    // [2] は天板で幅が size.w そのものなので、これで比べる。
    expect(large[2].size[0]).toBeGreaterThan(small[2].size[0]);
  });
});
