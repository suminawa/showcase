import { describe, expect, it } from "vitest";
import { DEFAULT_SIZE, type PlanSize } from "./house";
import {
  activePlan,
  addPlan,
  defaultFloorPlan,
  defaultPlanDoc,
  defaultPlanFile,
  duplicatePlan,
  MAX_PLANS,
  parsePlanFile,
  parsePlanJson,
  planById,
  removePlan,
  renamePlan,
  resizePlan,
  selectPlan,
  serializePlanFile,
  STORAGE_KEY,
  updateFloor,
  updatePlan,
  type PlanFile,
} from "./plan";

describe("既定の案", () => {
  it("鍵は v3、案は 1 件、1F と 2F を持つ", () => {
    expect(STORAGE_KEY).toBe("suminawa-floorplan:v3");
    const file = defaultPlanFile();
    expect(file.version).toBe(3);
    expect(file.plans).toHaveLength(1);
    expect(file.activeId).toBe(file.plans[0].id);
    expect(file.plans[0].name).toBe("案 1");
    expect(file.plans[0].size).toEqual(DEFAULT_SIZE);
    expect(Object.keys(file.plans[0].floors)).toEqual(["1", "2"]);
  });

  it("1F には家具・建具・設備が入っていて、2F にはバルコニーが付く", () => {
    const doc = defaultPlanFile().plans[0];
    expect(doc.floors[1].furniture.length).toBeGreaterThanOrEqual(4);
    expect(doc.floors[1].openings.length).toBeGreaterThanOrEqual(3);
    expect(doc.floors[1].fixtures.length).toBeGreaterThanOrEqual(1);
    expect(doc.floors[2].exterior).toHaveLength(1);
    expect(doc.floors[2].exterior[0].kind).toBe("balcony");
  });

  it("呼ぶたびに別の値を返す（書き換えが漏れない）", () => {
    const a = defaultPlanFile();
    const b = defaultPlanFile();
    expect(a).toEqual(b);
    a.plans[0].floors[1].furniture.pop();
    expect(a.plans[0].floors[1].furniture.length).not.toBe(b.plans[0].floors[1].furniture.length);
  });
});

describe("保存と読み込み", () => {
  it("書き出して読み直すと同じ値になる", () => {
    const file = defaultPlanFile();
    expect(parsePlanJson(serializePlanFile(file))).toEqual(file);
  });

  it("JSON でない・version が 3 でない・形が違うものは受け取らない", () => {
    expect(parsePlanJson(null)).toBeNull();
    expect(parsePlanJson("{")).toBeNull();
    expect(parsePlanFile({ version: 2, floors: {}, furniture: [] })).toBeNull();
    expect(parsePlanFile({ version: 3, plans: [], activeId: "plan-1" })).toBeNull();
    expect(parsePlanFile({ version: 3, plans: "x", activeId: "plan-1" })).toBeNull();
    expect(parsePlanFile(null)).toBeNull();
  });

  it("マスの数が違う・知らない部屋名・知らない家具の種類は受け取らない", () => {
    const base = defaultPlanFile();
    const shortCells = structuredClone(base);
    shortCells.plans[0].floors[1].layout.cells.pop();
    expect(parsePlanFile(shortCells)).toBeNull();

    const badLabel = structuredClone(base) as unknown as Record<string, never>;
    (badLabel as unknown as PlanFile).plans[0].floors[1].layout.rooms[0].label = "屋上" as never;
    expect(parsePlanFile(badLabel)).toBeNull();

    const badType = structuredClone(base);
    badType.plans[0].floors[1].furniture[0].type = "hovercraft" as never;
    expect(parsePlanFile(badType)).toBeNull();

    const badSize = structuredClone(base);
    badSize.plans[0].size = { width: 9.25, depth: 8, floors: 2 };
    expect(parsePlanFile(badSize)).toBeNull();
  });

  it("輪郭の外にある家具は中に寄せて受け取る", () => {
    const file = structuredClone(defaultPlanFile());
    file.plans[0].floors[1].furniture[0].x = 99;
    const parsed = parsePlanFile(file);
    expect(parsed).not.toBeNull();
    expect(parsed!.plans[0].floors[1].furniture[0].x).toBeLessThan(9);
  });

  it("壁の無い建具は読み込んだ時点で落ちる", () => {
    const file = structuredClone(defaultPlanFile());
    file.plans[0].floors[1].openings.push({
      id: "o-99",
      kind: "door",
      style: null,
      axis: "x",
      at: 2,
      start: 2,
      width: 0.75,
      sill: 0,
      height: 2,
      hinge: "start",
      swing: "plus",
    });
    const parsed = parsePlanFile(file);
    expect(parsed!.plans[0].floors[1].openings.some((o) => o.id === "o-99")).toBe(false);
  });

  it("階段の段数が範囲の外なら 8〜20 に収めて受け取る", () => {
    const file = structuredClone(defaultPlanFile());
    const stairs = file.plans[0].floors[1].fixtures.find((item) => item.kind === "stairs")!;
    stairs.steps = 200000;
    expect(parsePlanFile(file)!.plans[0].floors[1].fixtures[0].steps).toBe(20);
    stairs.steps = 0;
    expect(parsePlanFile(file)!.plans[0].floors[1].fixtures[0].steps).toBe(8);
    stairs.steps = null;
    expect(parsePlanFile(file)!.plans[0].floors[1].fixtures[0].steps).toBeNull();
  });

  it("activeId が plans に無ければ先頭を使う", () => {
    const file = structuredClone(defaultPlanFile());
    file.activeId = "plan-99";
    expect(parsePlanFile(file)!.activeId).toBe(file.plans[0].id);
  });

  it("案が 11 件あるものは 10 件に切る", () => {
    const base = defaultPlanFile();
    const many = structuredClone(base);
    for (let i = 2; i <= 12; i++) {
      const copy = structuredClone(base.plans[0]);
      copy.id = `plan-${i}`;
      copy.name = `案 ${i}`;
      many.plans.push(copy);
    }
    expect(parsePlanFile(many)!.plans).toHaveLength(MAX_PLANS);
  });
});

describe("案の操作", () => {
  it("addPlan は新しい id と自動の名前を付け、11 件目は足さない", () => {
    let file = defaultPlanFile();
    file = addPlan(file);
    expect(file.plans).toHaveLength(2);
    expect(file.plans[1].id).toBe("plan-2");
    expect(file.plans[1].name).toBe("案 2");
    expect(file.activeId).toBe("plan-2");
    while (file.plans.length < MAX_PLANS) file = addPlan(file);
    const full = file;
    expect(addPlan(full)).toBe(full);
  });

  it("duplicatePlan は id を新しくして中身をそのまま写す", () => {
    const file = defaultPlanFile();
    const copied = duplicatePlan(file, file.plans[0].id);
    expect(copied.plans).toHaveLength(2);
    expect(copied.plans[1].id).toBe("plan-2");
    expect(copied.plans[1].name).toBe("案 1 の複製");
    expect(copied.plans[1].floors).toEqual(file.plans[0].floors);
    // 写したものを触っても元に響かない
    copied.plans[1].floors[1].furniture.pop();
    expect(copied.plans[0].floors[1].furniture.length).not.toBe(
      copied.plans[1].floors[1].furniture.length,
    );
  });

  it("renamePlan は 30 字まで。空なら自動の名前に戻す", () => {
    const file = defaultPlanFile();
    expect(renamePlan(file, "plan-1", "南入りの案").plans[0].name).toBe("南入りの案");
    expect(renamePlan(file, "plan-1", "あ".repeat(40)).plans[0].name).toHaveLength(30);
    expect(renamePlan(file, "plan-1", "   ").plans[0].name).toBe("案 1");
  });

  it("removePlan は最後の 1 件を消さない。消したら隣を選ぶ", () => {
    const file = addPlan(defaultPlanFile());
    const removed = removePlan(file, "plan-2");
    expect(removed.plans).toHaveLength(1);
    expect(removed.activeId).toBe("plan-1");
    expect(removePlan(removed, "plan-1")).toBe(removed);
  });

  it("selectPlan / activePlan / planById", () => {
    const file = addPlan(defaultPlanFile());
    expect(activePlan(file).id).toBe("plan-2");
    expect(activePlan(selectPlan(file, "plan-1")).id).toBe("plan-1");
    expect(selectPlan(file, "plan-9")).toBe(file);
    expect(planById(file, "plan-1")?.id).toBe("plan-1");
    expect(planById(file, "plan-9")).toBeNull();
  });

  it("updateFloor / updatePlan は 1 つの階・1 つの案だけ差し替える", () => {
    const file = defaultPlanFile();
    const doc = file.plans[0];
    const next = updateFloor(doc, 1, { ...doc.floors[1], furniture: [] });
    expect(next.floors[1].furniture).toEqual([]);
    expect(next.floors[2]).toBe(doc.floors[2]);
    const updated = updatePlan(file, doc.id, next);
    expect(updated.plans[0].floors[1].furniture).toEqual([]);
    expect(updatePlan(file, "plan-9", next)).toBe(file);
  });
});

describe("外皮を変える", () => {
  it("広げた分は先頭の部屋で埋まり、はみ出した家具は中へ寄る", () => {
    const doc = defaultPlanFile().plans[0];
    const bigger: PlanSize = { width: 12, depth: 10, floors: 2 };
    const next = resizePlan(doc, bigger);
    expect(next.size).toEqual(bigger);
    expect(next.floors[1].layout.cells).toHaveLength(24 * 20);
    for (const item of next.floors[1].furniture) {
      expect(item.x).toBeLessThanOrEqual(12);
      expect(item.z).toBeLessThanOrEqual(10);
    }
  });

  it("平屋にすると 2F は空になる", () => {
    const doc = defaultPlanFile().plans[0];
    const flat = resizePlan(doc, { width: 9, depth: 8, floors: 1 });
    expect(flat.size.floors).toBe(1);
    expect(flat.floors[2].furniture).toEqual([]);
    expect(flat.floors[2].openings).toEqual([]);
    expect(flat.floors[2].exterior).toEqual([]);
  });

  it("平屋の既定には階段を置かない", () => {
    const flat = defaultPlanDoc("plan-1", "平屋", { width: 9, depth: 8, floors: 1 });
    expect(flat.floors[1].fixtures.some((item) => item.kind === "stairs")).toBe(false);
    expect(flat.floors[1].fixtures.some((item) => item.kind === "genkan")).toBe(true);
    // 2 階建てには今までどおり階段が入る
    const two = defaultPlanDoc("plan-1", "2 階建て", DEFAULT_SIZE);
    expect(two.floors[1].fixtures.some((item) => item.kind === "stairs")).toBe(true);
  });

  it("間取りを渡すと、その割り方に合わせて建具と家具を置く", () => {
    const size: PlanSize = { width: 8, depth: 6, floors: 1 };
    // 西半分が LDK、東半分が主寝室の 2 部屋だけの平屋
    const cols = 16;
    const cells = Array.from({ length: cols * 12 }, (_, index) => (index % cols < 8 ? "room-1" : "room-2"));
    const layout = {
      rooms: [
        { id: "room-1", label: "LDK" as const },
        { id: "room-2", label: "主寝室" as const },
      ],
      cells,
    };
    const plan = defaultFloorPlan(size, 1, layout);
    expect(plan.layout).toBe(layout);
    // 境目の壁は 1 本なので、内側のドアも 1 つ。x = 4 の線に乗る
    const doors = plan.openings.filter((o) => o.kind === "door");
    expect(doors).toHaveLength(1);
    expect(doors[0]).toMatchObject({ axis: "x", at: 4 });
    // ソファは LDK（西半分）に入る
    const sofa = plan.furniture.find((item) => item.type === "sofa")!;
    expect(sofa.x).toBeLessThan(4);
  });
});
