/**
 * 売り物: 見本（suminawa-demo-3d-viewer:v2）から書き出した JSON を読めるようにする。
 * v3 はそのまま検証して返し、v2 は案 1 件に写し、それ以外（v1 の分割木・version 無し・
 * JSON でない）は null。呼ぶ側は null のとき既定値に戻す。
 */
import { type FurnitureId, type Rotation, type Size3 } from "./furniture";
import { type GridLayout } from "./grid";
import { DEFAULT_SIZE, type Floor } from "./house";
import { autoPlanName, parsePlanFile, type FloorPlan, type PlanDoc, type PlanFile } from "./plan";

/**
 * 見本の 8 種 → 売り物の種類と、いちばん近い標準寸法。
 * size は見本の footprint と height をそのまま持ち込む（標準寸法とは少しずれる）。
 * 見本の "tv" はテレビ台なので tvstand に写す。テレビそのものは見本に無いので inch は付かない。
 */
export const V2_FURNITURE_MAP: Record<string, { type: FurnitureId; preset: string; size: Size3 }> = {
  bed: { type: "bed", preset: "bed-d", size: { w: 1.4, d: 2, h: 0.5 } },
  sofa: { type: "sofa", preset: "sofa-3", size: { w: 1.8, d: 0.9, h: 0.8 } },
  dining: { type: "dining", preset: "dining-4", size: { w: 1.6, d: 0.9, h: 0.72 } },
  desk: { type: "desk", preset: "desk-120", size: { w: 1.2, d: 0.6, h: 0.72 } },
  shelf: { type: "shelf", preset: "shelf-90", size: { w: 0.9, d: 0.35, h: 1.8 } },
  kitchen: { type: "kitchen", preset: "kitchen-i", size: { w: 2.4, d: 0.65, h: 0.85 } },
  bath: { type: "bath", preset: "bath-160", size: { w: 1.6, d: 0.8, h: 0.55 } },
  tv: { type: "tvstand", preset: "tvstand-150", size: { w: 1.5, d: 0.45, h: 0.45 } },
};

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isRotation(value: unknown): value is Rotation {
  return value === 0 || value === 90 || value === 180 || value === 270;
}

function migrateV2(data: Record<string, unknown>): PlanFile | null {
  if (!isObject(data.floors)) return null;
  if (!Array.isArray(data.furniture)) return null;
  const size = DEFAULT_SIZE;
  const floors = {} as Record<Floor, FloorPlan>;
  for (const floor of [1, 2] as const) {
    const layout = data.floors[floor];
    if (!isObject(layout) || !Array.isArray(layout.cells)) return null;
    // 見本の外皮（9 × 8 m）は 288 マス。違う形のものは受け取らない
    if (layout.cells.length !== 288) return null;
    floors[floor] = {
      // 部屋名と id の検証は下の parsePlanFile がまとめて行う
      layout: layout as unknown as GridLayout,
      openings: [],
      fixtures: [],
      exterior: [],
      furniture: [],
    };
  }
  for (const entry of data.furniture) {
    if (!isObject(entry)) return null;
    if (typeof entry.id !== "string" || entry.id === "") return null;
    if (typeof entry.type !== "string") return null;
    const mapped = V2_FURNITURE_MAP[entry.type];
    if (!mapped) return null;
    if (entry.floor !== 1 && entry.floor !== 2) return null;
    if (typeof entry.x !== "number" || typeof entry.z !== "number") return null;
    if (!isRotation(entry.rotation)) return null;
    floors[entry.floor].furniture.push({
      id: entry.id,
      type: mapped.type,
      preset: mapped.preset,
      size: { ...mapped.size },
      inch: null,
      x: entry.x,
      z: entry.z,
      rotation: entry.rotation,
    });
  }
  const doc: PlanDoc = { id: "plan-1", name: autoPlanName(0), size, floors };
  // 検証（マスの表・部屋名・輪郭の外の家具）はここでまとめて通す
  return parsePlanFile({ version: 3, plans: [doc], activeId: doc.id });
}

export function migrate(raw: unknown): PlanFile | null {
  let data: unknown = raw;
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return null;
    }
  }
  if (!isObject(data)) return null;
  if (data.version === 3) return parsePlanFile(data);
  if (data.version === 2) return migrateV2(data);
  return null;
}
