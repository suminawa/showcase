/**
 * 売り物: 家の寸法・色・明かり・視点。glTF も外部の 3D データも読まず、この表だけから組み立てる。
 * 単位はメートル。three.js の座標系（y が高さ）で、原点は 1 階の床の中心。
 * 見本と違い、間口・奥行き・階数は案ごとに変わるので、定数ではなく houseOf(size) が返す。
 */

export type Vec3 = [number, number, number];

/** 1 階だけ / 2 階だけ / 全体 */
export type FloorMode = "1f" | "2f" | "all";

/** 斜めから見る / 真上から見る */
export type ViewMode = "orbit" | "top";

export type LightingMode = "day" | "night";

export type Floor = 1 | 2;

/** 1 マスの辺（m） */
export const CELL = 0.5;

/** 家具・建具・設備・外周の刻み（m） */
export const SNAP = 0.25;

/** 高さの刻み（m） */
export const HEIGHT_SNAP = 0.05;

/** 外皮の寸法の下限・上限（m） */
export const SIZE_MIN = 4;
export const SIZE_MAX = 16;

export type PlanSize = {
  /** 間口（東西、m）。CELL の倍数、4〜16 */
  width: number;
  /** 奥行き（南北、m）。CELL の倍数、4〜16 */
  depth: number;
  floors: 1 | 2;
};

/** 見本と同じ外皮。既定値であり、移行（v2 → v3）の外皮でもある */
export const DEFAULT_SIZE: PlanSize = { width: 9, depth: 8, floors: 2 };

export const SIZE_PRESETS: readonly { id: string; name: string; size: PlanSize }[] = [
  { id: "s-8x7", name: "8 × 7 m（56 m² / 階）", size: { width: 8, depth: 7, floors: 2 } },
  { id: "s-9x8", name: "9 × 8 m（72 m² / 階）", size: { width: 9, depth: 8, floors: 2 } },
  { id: "s-10x8", name: "10 × 8 m（80 m² / 階）", size: { width: 10, depth: 8, floors: 2 } },
  { id: "s-11x9", name: "11 × 9 m（99 m² / 階）", size: { width: 11, depth: 9, floors: 2 } },
  { id: "s-9x8f", name: "平屋 9 × 8 m", size: { width: 9, depth: 8, floors: 1 } },
];

export function colsOf(size: PlanSize): number {
  return Math.round(size.width / CELL);
}

export function rowsOf(size: PlanSize): number {
  return Math.round(size.depth / CELL);
}

export function cellCountOf(size: PlanSize): number {
  return colsOf(size) * rowsOf(size);
}

/** 0.5 の倍数か。浮動小数の誤差を見込んで幅を持たせる */
function isCellMultiple(value: number): boolean {
  if (!Number.isFinite(value)) return false;
  return Math.abs(value / CELL - Math.round(value / CELL)) < 1e-9;
}

export function isPlanSize(value: unknown): value is PlanSize {
  if (typeof value !== "object" || value === null) return false;
  const size = value as Record<string, unknown>;
  if (typeof size.width !== "number" || typeof size.depth !== "number") return false;
  if (size.floors !== 1 && size.floors !== 2) return false;
  if (!isCellMultiple(size.width) || !isCellMultiple(size.depth)) return false;
  if (size.width < SIZE_MIN || size.width > SIZE_MAX) return false;
  if (size.depth < SIZE_MIN || size.depth > SIZE_MAX) return false;
  return true;
}

function clampLength(value: number): number {
  if (!Number.isFinite(value)) return SIZE_MIN;
  const stepped = Math.round(value / CELL) * CELL;
  return Math.min(Math.max(stepped, SIZE_MIN), SIZE_MAX);
}

export function clampPlanSize(size: PlanSize): PlanSize {
  return {
    width: clampLength(size.width),
    depth: clampLength(size.depth),
    floors: size.floors === 1 ? 1 : 2,
  };
}

export type HouseDims = {
  width: number;
  depth: number;
  /** 階ごとの床の高さ（base）と天井までの高さ（height） */
  floors: Record<Floor, { base: number; height: number }>;
  /** 外壁の厚み */
  wallThickness: number;
  /** 切って見るときの外壁の高さ。腰の高さまで残して中をのぞく */
  cutawayWallHeight: number;
  /** 床スラブの厚み */
  slabThickness: number;
  /** 軒から棟までの立ち上がり */
  roofRise: number;
  /** 軒の出 */
  eaves: number;
};

/** 階の高さは外皮の広さで変えない（2 階の base は 1 階の天井 2.7 + スラブ 0.25） */
const FLOOR_HEIGHTS: Record<Floor, { base: number; height: number }> = {
  1: { base: 0, height: 2.7 },
  2: { base: 2.95, height: 2.5 },
};

export function houseOf(size: PlanSize): HouseDims {
  return {
    width: size.width,
    depth: size.depth,
    floors: { 1: { ...FLOOR_HEIGHTS[1] }, 2: { ...FLOOR_HEIGHTS[2] } },
    wallThickness: 0.2,
    cutawayWallHeight: 1.1,
    slabThickness: 0.25,
    roofRise: 1.6,
    eaves: 0.5,
  };
}

export function baseOf(_size: PlanSize, floor: Floor): number {
  return FLOOR_HEIGHTS[floor].base;
}

export function ceilingOf(_size: PlanSize, floor: Floor): number {
  return FLOOR_HEIGHTS[floor].height;
}

/** 最上階の天井の高さ（屋根を載せる高さ） */
export function topOf(size: PlanSize): number {
  const floor: Floor = size.floors === 1 ? 1 : 2;
  return FLOOR_HEIGHTS[floor].base + FLOOR_HEIGHTS[floor].height;
}

/** その案が持つ階。平屋なら 1 階だけ */
export function floorsOf(size: PlanSize): Floor[] {
  return size.floors === 1 ? [1] : [1, 2];
}

/** 3D の中の色。CSS のカスケードに乗らないので、CSS ではなくここに持つ */
export type SceneColors = {
  /** 外壁 */
  wall: string;
  /** 床スラブの小口や軒 */
  trim: string;
  /** 屋根 */
  roof: string;
  /** 部屋の床 */
  floorTone: string;
  /** 内壁 */
  interior: string;
};

export const DEFAULT_SCENE_COLORS: SceneColors = {
  wall: "#e8e4dc",
  trim: "#7d7568",
  roof: "#4a4f57",
  floorTone: "#d8d2c6",
  interior: "#e4dfd5",
};

/** 階ごとの床の色。2 階を少し落として、全体を見たとき階が見分けられるようにする */
export const FLOOR_TONE: Record<Floor, string> = {
  1: "#d8d2c6",
  2: "#cec7b9",
};

/** 選択中の部屋の床 */
export const SELECTED_FLOOR_TONE = "#f0e9d8";

/** 窓の色。昼は空を映した水色、夜は室内の明かりが漏れた暖色 */
export const WINDOW_TONE = {
  day: "#8fb6d8",
  night: "#ffe3ac",
  emissive: "#ffd79a",
} as const;

export type LightingPreset = {
  background: string;
  ground: string;
  ambient: { color: string; intensity: number };
  key: { color: string; intensity: number; position: Vec3 };
  hemisphere: { sky: string; ground: string; intensity: number };
  windowEmissive: number;
};

/** 月は太陽と反対側（−x）から差して、切り替わったことが形で分かるようにする */
export function lightingPreset(mode: LightingMode): LightingPreset {
  if (mode === "night") {
    return {
      background: "#11151d",
      ground: "#181d26",
      ambient: { color: "#3a4a6b", intensity: 0.55 },
      key: { color: "#aebde6", intensity: 0.9, position: [-11, 15, -9] },
      hemisphere: { sky: "#27334d", ground: "#0d1017", intensity: 0.6 },
      windowEmissive: 1.6,
    };
  }
  return {
    background: "#cadcf0",
    ground: "#c9c4b6",
    ambient: { color: "#ffffff", intensity: 0.8 },
    key: { color: "#fff3df", intensity: 2.4, position: [11, 16, 9] },
    hemisphere: { sky: "#dbe9fb", ground: "#b6afa1", intensity: 1.1 },
    windowEmissive: 0.05,
  };
}

/** 見せる階。平屋では 2F を選んでも 1 階を見せる */
export function visibleFloors(size: PlanSize, mode: FloorMode): Floor[] {
  const available = floorsOf(size);
  if (mode === "all") return available;
  const wanted: Floor = mode === "2f" ? 2 : 1;
  return available.includes(wanted) ? [wanted] : [available[0]];
}

export function isCutaway(mode: FloorMode): boolean {
  return mode !== "all";
}

export function showsRoof(mode: FloorMode): boolean {
  return !isCutaway(mode);
}

export type CameraPose = { position: Vec3; target: Vec3 };

/**
 * 視点。見本（9m 角）を 1 として、外皮の長辺の比で遠近を伸ばす。
 * 真上のとき z をわずかにずらすのは、視線と上方向が重なって回転が定まらなくなるのを避けるため。
 * 斜めからの 3 つは 0.75 倍（= 25% 寄り）にしてある ── 画角 42 度のままだと、
 * 9 × 8 m の家が枠の 1/3 ほどにしか映らず、部屋の様子が読み取れなかった。
 */
export function cameraPose(size: PlanSize, mode: FloorMode, view: ViewMode): CameraPose {
  const span = Math.max(size.width, size.depth);
  const k = span / 9;
  const floors = visibleFloors(size, mode);
  const floor = floors[floors.length - 1];
  const base = FLOOR_HEIGHTS[floor].base;
  if (view === "top") {
    if (mode === "all") return { position: [0, 22 * k, 0.01], target: [0, 0, 0] };
    return { position: [0, base + 18 * k, 0.01], target: [0, base, 0] };
  }
  // 11 / 8 / 12 → 8.25 / 6 / 9、13 / 10 / 14 → 9.75 / 7.5 / 10.5（いずれも 0.75 倍）
  if (mode === "1f") return { position: [8.25 * k, 6 * k, 9 * k], target: [0, 1.4, 0] };
  if (mode === "2f") return { position: [8.25 * k, 8.25 * k, 9 * k], target: [0, base + 1.25, 0] };
  // 「全体」は屋根も軒も入るので、寄せすぎると 16:9 の枠で土台が切れる。
  // 小さい家でも 1.3 倍までは引き、注視点も 2.6 m へ下げて家を枠の中に納める
  const m = Math.max(k, 1) + 0.3;
  return { position: [9.75 * m, 7.5 * m, 10.5 * m], target: [0, 2.6, 0] };
}
