/**
 * 売り物: 寸法の言い換え。画面にも印刷にも同じ関数を通して、表記を 1 つに揃える。
 * 長さと面積は小数 2 桁（0.25 刻みなので 2 桁で足りる）、帖だけ小数 1 桁。
 */
import { isRectangularRoom, roomArea, roomBounds, type GridLayout, type RoomId } from "./grid";
import { type PlanSize } from "./house";
import { round2, type Size3 } from "./furniture";

/** 1 帖 = 1.62 m²（不動産公正競争規約の下限）。小数 1 桁で丸める */
export function jo(area: number): number {
  return Math.round((area / 1.62) * 10) / 10;
}

export function formatLength(value: number): string {
  return value.toFixed(2);
}

export function formatArea(value: number): string {
  return value.toFixed(2);
}

export function formatJo(value: number): string {
  return value.toFixed(1);
}

export function formatSize3(size: Size3): string {
  return `${formatLength(size.w)} × ${formatLength(size.d)} × ${formatLength(size.h)} m`;
}

export type RoomDimension = {
  /** 広さ（m²） */
  area: number;
  jo: number;
  /** 外接長方形の 幅 × 奥行き */
  w: number;
  d: number;
  /** 部屋が 1 枚の長方形なら true。false のときは「最大」を添えて出す */
  exact: boolean;
};

export function roomDimension(
  size: PlanSize,
  layout: GridLayout,
  roomId: RoomId,
): RoomDimension | null {
  const bounds = roomBounds(size, layout, roomId);
  if (!bounds) return null;
  const area = roomArea(layout, roomId);
  return {
    area,
    jo: jo(area),
    w: bounds.w,
    d: bounds.d,
    exact: isRectangularRoom(size, layout, roomId),
  };
}

/** 刻みの倍数に丸め、範囲外は端で止める。数でないものは下限に落とす */
export function snapValue(value: number, step: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  const stepped = Math.round(value / step) * step;
  return round2(Math.min(Math.max(stepped, min), max));
}
