import { describe, expect, it } from "vitest";
import { defaultLayout, type GridLayout } from "./grid";
import { colsOf, DEFAULT_SIZE, rowsOf } from "./house";
import {
  formatArea,
  formatJo,
  formatLength,
  formatSize3,
  jo,
  roomDimension,
  snapValue,
} from "./dimensions";

const SIZE = DEFAULT_SIZE;

function lShaped(): GridLayout {
  const cols = colsOf(SIZE);
  const rows = rowsOf(SIZE);
  const cells: string[] = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      cells.push(col < 4 || row >= rows - 4 ? "room-1" : "room-2");
    }
  }
  return {
    rooms: [
      { id: "room-1", label: "LDK" },
      { id: "room-2", label: "和室" },
    ],
    cells,
  };
}

describe("帖", () => {
  it("面積 ÷ 1.62 を小数 1 桁で", () => {
    expect(jo(33)).toBe(20.4);
    expect(jo(16.2)).toBe(10);
    expect(jo(0)).toBe(0);
    expect(formatJo(jo(16.2))).toBe("10.0");
  });
});

describe("数値の言い換え", () => {
  it("長さと面積は小数 2 桁、帖だけ 1 桁", () => {
    expect(formatLength(1.5)).toBe("1.50");
    expect(formatLength(0.25)).toBe("0.25");
    expect(formatArea(5.25)).toBe("5.25");
    expect(formatSize3({ w: 1.9, d: 0.85, h: 0.8 })).toBe("1.90 × 0.85 × 0.80 m");
  });
});

describe("部屋の寸法", () => {
  it("長方形の部屋は 幅 × 奥行き をそのまま出す", () => {
    const layout = defaultLayout(SIZE, 1);
    const dim = roomDimension(SIZE, layout, layout.rooms[0].id);
    expect(dim).toEqual({ area: 33, jo: 20.4, w: 5.5, d: 6, exact: true });
  });

  it("L 字は外接長方形で、exact が false", () => {
    // room-1 は西の 4 列（2 m）と南の 4 行（2 m）の L 字。
    // 面積は 72 − 42 = 30 m²、外接長方形は外皮いっぱいの 9 × 8 m
    const dim = roomDimension(SIZE, lShaped(), "room-1");
    expect(dim).toEqual({ area: 30, jo: 18.5, w: 9, d: 8, exact: false });
  });

  it("長方形に収まっている側は exact が true のまま", () => {
    // room-2 は東の 14 列 × 北の 12 行（7 × 6 m）で、L 字にはならない
    const dim = roomDimension(SIZE, lShaped(), "room-2");
    expect(dim).toEqual({ area: 42, jo: 25.9, w: 7, d: 6, exact: true });
  });

  it("マスを 1 つも持たない部屋は null", () => {
    const layout = defaultLayout(SIZE, 1);
    expect(roomDimension(SIZE, layout, "room-999")).toBeNull();
  });
});

describe("snapValue", () => {
  it("刻みの倍数に丸め、範囲外は端で止める", () => {
    expect(snapValue(1.3, 0.25, 0.5, 3)).toBe(1.25);
    expect(snapValue(0.1, 0.25, 0.5, 3)).toBe(0.5);
    expect(snapValue(99, 0.25, 0.5, 3)).toBe(3);
    expect(snapValue(2.03, 0.05, 0.5, 3)).toBe(2.05);
    expect(snapValue(Number.NaN, 0.25, 0.5, 3)).toBe(0.5);
  });
});
