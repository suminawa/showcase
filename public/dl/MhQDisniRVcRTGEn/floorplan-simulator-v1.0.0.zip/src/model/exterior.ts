/**
 * 売り物: 外周（バルコニー・テラス・玄関ポーチ）。
 * マス目は広げず、外壁の面に付く長方形として別に持つ。
 * 2D は輪郭の外側に破線の矩形と名前、3D はスラブと手すり。屋根は載せない。
 */
import { snapValue } from "./dimensions";
import { nextSeqId, round2, TONE, type ScenePart } from "./furniture";
import { toScene } from "./grid";
import { baseOf, SNAP, type Floor, type PlanSize, type Vec3 } from "./house";

export type ExteriorKind = "balcony" | "terrace" | "porch";
export type ExteriorSide = "n" | "e" | "s" | "w";

export type ExteriorPart = {
  /** "e-<n>" の連番 */
  id: string;
  kind: ExteriorKind;
  /** 取り付く外壁の面 */
  side: ExteriorSide;
  /** その面に沿った始まり（m）。SNAP の倍数、0 以上 */
  start: number;
  /** その面に沿った長さ（m）。SNAP の倍数、0.5 以上 */
  length: number;
  /** 外へ出る奥行き（m）。SNAP の倍数、0.5〜3.0 */
  depth: number;
  railing: boolean;
};

export const EXTERIOR_PRESETS: Record<
  ExteriorKind,
  { name: string; length: number; depth: number; railing: boolean }
> = {
  balcony: { name: "バルコニー", length: 3, depth: 1.25, railing: true },
  terrace: { name: "テラス", length: 3, depth: 1.5, railing: true },
  porch: { name: "玄関ポーチ", length: 1.5, depth: 1, railing: false },
};

export const EXTERIOR_MIN_LENGTH = 0.5;
export const EXTERIOR_MIN_DEPTH = 0.5;
export const EXTERIOR_MAX_DEPTH = 3;

/** スラブの厚み */
export const EXTERIOR_SLAB = 0.15;
/** 手すりの高さと厚み */
export const RAILING_HEIGHT = 1.1;
export const RAILING_THICKNESS = 0.06;

export function exteriorName(kind: ExteriorKind): string {
  return EXTERIOR_PRESETS[kind].name;
}

/** その面の長さ。南北の面は間口、東西の面は奥行き */
export function sideLength(size: PlanSize, side: ExteriorSide): number {
  return side === "n" || side === "s" ? size.width : size.depth;
}

/** 面に収める。start + length が面を超えたら端で止める */
export function clampExterior(size: PlanSize, part: ExteriorPart): ExteriorPart {
  const span = sideLength(size, part.side);
  const start = snapValue(part.start, SNAP, 0, Math.max(0, round2(span - EXTERIOR_MIN_LENGTH)));
  const length = snapValue(part.length, SNAP, EXTERIOR_MIN_LENGTH, round2(span - start));
  const depth = snapValue(part.depth, SNAP, EXTERIOR_MIN_DEPTH, EXTERIOR_MAX_DEPTH);
  return { ...part, start, length, depth };
}

export function exteriorSeed(
  size: PlanSize,
  kind: ExteriorKind,
  side: ExteriorSide,
  along: number,
): Omit<ExteriorPart, "id"> {
  const preset = EXTERIOR_PRESETS[kind];
  const span = sideLength(size, side);
  const length = Math.min(preset.length, span);
  const draft: ExteriorPart = {
    id: "",
    kind,
    side,
    start: snapValue(along - length / 2, SNAP, 0, round2(span - length)),
    length,
    depth: preset.depth,
    railing: preset.railing,
  };
  const { id: _drop, ...rest } = clampExterior(size, draft);
  return rest;
}

export function addExterior(
  size: PlanSize,
  list: readonly ExteriorPart[],
  kind: ExteriorKind,
  side: ExteriorSide,
  along: number,
): ExteriorPart[] {
  return [...list, { ...exteriorSeed(size, kind, side, along), id: nextSeqId(list, "e") }];
}

export function moveExterior(
  size: PlanSize,
  list: readonly ExteriorPart[],
  id: string,
  start: number,
): ExteriorPart[] {
  return list.map((part) => (part.id === id ? clampExterior(size, { ...part, start }) : part));
}

export type ExteriorPatch = Partial<Pick<ExteriorPart, "length" | "depth" | "railing" | "side" | "start">>;

export function resizeExterior(
  size: PlanSize,
  list: readonly ExteriorPart[],
  id: string,
  patch: ExteriorPatch,
): ExteriorPart[] {
  return list.map((part) => (part.id === id ? clampExterior(size, { ...part, ...patch }) : part));
}

export function removeExterior(list: readonly ExteriorPart[], id: string): ExteriorPart[] {
  return list.filter((part) => part.id !== id);
}

/**
 * 外皮を変えたあと、面からはみ出した外周を落とす。
 * 1 つも落ちないときは同じ参照を返す（無駄な描き直しを避けるため）。
 */
export function pruneExterior(size: PlanSize, list: readonly ExteriorPart[]): ExteriorPart[] {
  const kept = list.filter((part) => part.start + EXTERIOR_MIN_LENGTH <= sideLength(size, part.side) + 1e-9);
  const fitted = kept.map((part) => clampExterior(size, part));
  const same =
    fitted.length === list.length &&
    fitted.every((part, index) => {
      const before = list[index];
      return part.start === before.start && part.length === before.length && part.depth === before.depth;
    });
  return same ? (list as ExteriorPart[]) : fitted;
}

/** 床座標での矩形。輪郭の外へ出る（x や z が負になったり、間口・奥行きを超えたりする） */
export function exteriorRect(
  size: PlanSize,
  part: ExteriorPart,
): { x: number; z: number; w: number; d: number } {
  if (part.side === "n") return { x: part.start, z: -part.depth, w: part.length, d: part.depth };
  if (part.side === "s") return { x: part.start, z: size.depth, w: part.length, d: part.depth };
  if (part.side === "w") return { x: -part.depth, z: part.start, w: part.depth, d: part.length };
  return { x: size.width, z: part.start, w: part.depth, d: part.length };
}

/**
 * 3D の箱。スラブ（上面がその階の床と同じ高さ）と、手すり 3 枚（外側の 3 辺）。
 * 玄関ポーチのように手すりが無いものはスラブだけ。屋根は載せない。
 */
export function exteriorParts(size: PlanSize, part: ExteriorPart, floor: Floor): ScenePart[] {
  const rect = exteriorRect(size, part);
  const base = baseOf(size, floor);
  const [cx, cz] = toScene(size, rect.x + rect.w / 2, rect.z + rect.d / 2);
  const t = RAILING_THICKNESS;
  const out: ScenePart[] = [
    {
      id: `${part.id}-slab`,
      position: [cx, base - EXTERIOR_SLAB / 2, cz] as Vec3,
      size: [rect.w, EXTERIOR_SLAB, rect.d] as Vec3,
      color: TONE.white,
    },
  ];
  if (!part.railing) return out;
  const y = base + RAILING_HEIGHT / 2;
  // 建物に付く 1 辺を除いた 3 辺。面ごとに「外へ出る向き」が違う
  const long: [number, number] = part.side === "n" || part.side === "s" ? [rect.w, t] : [t, rect.d];
  const short: [number, number] = part.side === "n" || part.side === "s" ? [t, rect.d] : [rect.w, t];
  const outerZ = part.side === "n" ? -rect.d / 2 : part.side === "s" ? rect.d / 2 : 0;
  const outerX = part.side === "w" ? -rect.w / 2 : part.side === "e" ? rect.w / 2 : 0;
  out.push({
    id: `${part.id}-rail-0`,
    position: [cx + outerX, y, cz + outerZ] as Vec3,
    size: [long[0], RAILING_HEIGHT, long[1]] as Vec3,
    color: TONE.metal,
  });
  const sideOffset: [number, number][] =
    part.side === "n" || part.side === "s"
      ? [
          [-rect.w / 2, 0],
          [rect.w / 2, 0],
        ]
      : [
          [0, -rect.d / 2],
          [0, rect.d / 2],
        ];
  sideOffset.forEach(([dx, dz], index) => {
    out.push({
      id: `${part.id}-rail-${index + 1}`,
      position: [cx + dx, y, cz + dz] as Vec3,
      size: [short[0], RAILING_HEIGHT, short[1]] as Vec3,
      color: TONE.metal,
    });
  });
  return out;
}
