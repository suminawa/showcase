/**
 * 売り物: 家具 18 種の表。見本は種類ごとに箱と記号を直書きしていたが、
 * 実寸を選べるようにしたので「寸法から箱と記号を組み立てる関数」に変えてある。
 * 色は three.js の材質に渡す値なので、CSS のトークンではなく furniture.ts の TONE を使う。
 * 箱の位置は「家具の中心を原点、y は床から」。回転と階の高さは partsInScene が掛ける。
 */
import { HEIGHT_SNAP, SNAP, type Vec3 } from "./house";
import {
  round2,
  TONE,
  type FurnitureId,
  type FurnitureSeed,
  type Glyph,
  type GlyphLine,
  type GlyphRect,
  type Part,
  type PlacedFurniture,
  type Size3,
} from "./furniture";

export type FurniturePreset = {
  /** "bed-d" のような、種類 + 記号 */
  id: string;
  name: string;
  size: Size3;
  /** テレビだけ持つ */
  inch?: number;
  /** キッチンだけ持つ */
  shape?: "I" | "L" | "island";
  /** ダイニングだけ持つ。天板の大きさ（size は椅子を含めた外形） */
  top?: { w: number; d: number };
};

export type FurnitureLimits = {
  w: [number, number];
  d: [number, number];
  h: [number, number];
};

export type FurnitureType = {
  id: FurnitureId;
  name: string;
  presets: readonly FurniturePreset[];
  /** 任意寸法の範囲（m） */
  limits: FurnitureLimits;
  /** 任意寸法の刻み（m）。テレビだけインチから作るので細かい */
  step: { w: number; d: number; h: number };
  build(size: Size3, preset: FurniturePreset | null): readonly Part[];
  glyph(size: Size3, preset: FurniturePreset | null): Glyph;
};

const STEP = { w: SNAP, d: SNAP, h: HEIGHT_SNAP };

/* ---- 組み立ての下ごしらえ ------------------------------------------------ */

function part(
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  color: string,
): Part {
  return { offset: [x, y, z] as Vec3, size: [w, h, d] as Vec3, color };
}

/** 本体 + 天板。t は天板の厚み */
function withTop(size: Size3, body: string, top: string, t = 0.05): Part[] {
  const bodyH = Math.max(size.h - t, 0.02);
  return [
    part(0, bodyH / 2, 0, size.w, bodyH, size.d, body),
    part(0, bodyH + t / 2, 0, size.w, t, size.d, top),
  ];
}

/** 天板 + 4 本の脚 */
function legged(size: Size3, topW: number, topD: number, top: string, leg: string): Part[] {
  const t = 0.06;
  const legH = Math.max(size.h - t, 0.08);
  const inset = Math.min(0.08, topW / 4, topD / 4);
  const lx = topW / 2 - inset;
  const lz = topD / 2 - inset;
  const s = Math.min(0.06, topW / 6, topD / 6);
  return [
    part(0, legH + t / 2, 0, topW, t, topD, top),
    part(-lx, legH / 2, -lz, s, legH, s, leg),
    part(lx, legH / 2, -lz, s, legH, s, leg),
    part(-lx, legH / 2, lz, s, legH, s, leg),
    part(lx, legH / 2, lz, s, legH, s, leg),
  ];
}

/** 側板 2 + 天板 + 背板 + 棚板 3。収納家具はこれ 1 つで足りる */
function cased(size: Size3, body: string, board: string): Part[] {
  const t = Math.min(0.03, size.d / 4);
  const inner = Math.max(size.w - t * 2, 0.05);
  const out: Part[] = [
    part(-(size.w - t) / 2, size.h / 2, 0, t, size.h, size.d, body),
    part((size.w - t) / 2, size.h / 2, 0, t, size.h, size.d, body),
    part(0, size.h - t / 2, 0, size.w, t, size.d, body),
    part(0, size.h / 2, -(size.d - t) / 2, size.w, size.h, t, body),
    part(0, t / 2, 0, size.w, t, size.d, body),
  ];
  for (let i = 1; i <= 3; i++) {
    const y = (size.h * i) / 4;
    out.push(part(0, y, 0, inner, 0.02, Math.max(size.d - t, 0.05), board));
  }
  return out;
}

function rect(x: number, z: number, w: number, d: number): GlyphRect {
  return { x, z, w, d };
}

function line(x1: number, z1: number, x2: number, z2: number): GlyphLine {
  return { x1, z1, x2, z2 };
}

/** 外形だけの記号 */
function outline(size: Size3): Glyph {
  return { rects: [rect(0, 0, size.w, size.d)] };
}

/* ---- テレビのインチ ------------------------------------------------------ */

export const TV_DIAGONAL = Math.sqrt(16 ** 2 + 9 ** 2);

/** 16:9 の画面幅（m、小数 2 桁） */
export function screenWidth(inch: number): number {
  return round2((inch * 0.0254 * 16) / TV_DIAGONAL);
}

export function screenHeight(inch: number): number {
  return round2((inch * 0.0254 * 9) / TV_DIAGONAL);
}

/** 本体の大きさ。幅は画面幅 + 0.02（枠）、奥行きは 0.06、高さは画面高 + 0.02 */
export function tvSize(inch: number): Size3 {
  return {
    w: round2(screenWidth(inch) + 0.02),
    d: 0.06,
    h: round2(screenHeight(inch) + 0.02),
  };
}

/** テレビ台の幅の目安。画面幅 + 0.2 m を 0.1 刻みで切り上げる */
export function tvStandHint(inch: number): number {
  const wanted = round2(screenWidth(inch) + 0.2);
  // 1.2 のような「ちょうど」の値が浮動小数で 12.000000000000002 になり、1 段上がるのを防ぐ
  return round2(Math.ceil(wanted * 10 - 1e-9) / 10);
}

const TV_INCHES = [43, 55, 65, 75] as const;

/* ---- 18 種の表 ----------------------------------------------------------- */

export const FURNITURE: readonly FurnitureType[] = [
  {
    id: "bed",
    name: "ベッド",
    presets: [
      { id: "bed-s", name: "シングル", size: { w: 0.95, d: 1.95, h: 0.5 } },
      { id: "bed-sd", name: "セミダブル", size: { w: 1.2, d: 1.95, h: 0.5 } },
      { id: "bed-d", name: "ダブル", size: { w: 1.4, d: 1.95, h: 0.5 } },
      { id: "bed-q", name: "クイーン", size: { w: 1.6, d: 1.95, h: 0.5 } },
    ],
    limits: { w: [0.75, 2], d: [1.75, 2.25], h: [0.2, 1.2] },
    step: STEP,
    build: (size) => {
      const baseH = Math.min(size.h * 0.6, size.h - 0.04);
      const duvetD = size.d * 0.72;
      // 枕は残りの高さに収める（高さを低く取った任意寸法でも外へ出ないように）
      const pillowH = Math.min(0.12, Math.max(size.h - baseH, 0.02));
      return [
        part(0, baseH / 2, 0, size.w, baseH, size.d, TONE.wood),
        part(0, baseH + (size.h - baseH) / 2, size.d / 2 - duvetD / 2 - 0.02, size.w - 0.08, size.h - baseH, duvetD, TONE.fabric),
        part(0, baseH + pillowH / 2, -(size.d / 2 - 0.22), size.w - 0.2, pillowH, 0.4, TONE.white),
      ];
    },
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d), rect(0, -(size.d / 2 - 0.22), size.w - 0.2, 0.4)],
      lines: [line(-size.w / 2, -(size.d / 2 - 0.46), size.w / 2, -(size.d / 2 - 0.46))],
    }),
  },
  {
    id: "sofa",
    name: "ソファ",
    presets: [
      { id: "sofa-2", name: "2 人掛け", size: { w: 1.5, d: 0.85, h: 0.8 } },
      { id: "sofa-3", name: "3 人掛け", size: { w: 1.9, d: 0.85, h: 0.8 } },
    ],
    limits: { w: [1, 3], d: [0.5, 1.25], h: [0.4, 1.2] },
    step: STEP,
    build: (size) => {
      const backD = Math.min(0.16, size.d / 3);
      const seatD = size.d - backD;
      return [
        part(0, size.h * 0.25, size.d / 2 - seatD / 2, size.w, size.h * 0.5, seatD, TONE.fabric),
        part(0, size.h * 0.6, -(size.d / 2 - backD / 2), size.w, size.h * 0.8, backD, TONE.fabric),
      ];
    },
    glyph: (size) => {
      const backD = Math.min(0.16, size.d / 3);
      const seatD = size.d - backD;
      return {
        rects: [
          rect(0, size.d / 2 - seatD / 2, size.w, seatD),
          rect(0, -(size.d / 2 - backD / 2), size.w, backD),
        ],
      };
    },
  },
  {
    id: "dining",
    name: "ダイニングセット",
    presets: [
      { id: "dining-4", name: "4 人", size: { w: 1.6, d: 1.4, h: 0.72 }, top: { w: 1.2, d: 0.8 } },
      { id: "dining-6", name: "6 人", size: { w: 2.2, d: 1.5, h: 0.72 }, top: { w: 1.8, d: 0.9 } },
    ],
    limits: { w: [1, 3], d: [0.75, 2], h: [0.6, 1] },
    step: STEP,
    build: (size, preset) => {
      const top = preset?.top ?? { w: round2(size.w * 0.75), d: round2(size.d * 0.6) };
      const topW = Math.min(top.w, size.w);
      const topD = Math.min(top.d, size.d);
      const chair = Math.min(0.4, topW / 2, (size.d - topD) / 2);
      const chairZ = size.d / 2 - chair / 2;
      const chairX = Math.min(topW / 2 - chair / 2, size.w / 2 - chair / 2);
      return [
        ...legged(size, topW, topD, TONE.wood, TONE.woodDark),
        part(-chairX, 0.225, -chairZ, chair, 0.45, chair, TONE.woodDark),
        part(chairX, 0.225, -chairZ, chair, 0.45, chair, TONE.woodDark),
        part(-chairX, 0.225, chairZ, chair, 0.45, chair, TONE.woodDark),
        part(chairX, 0.225, chairZ, chair, 0.45, chair, TONE.woodDark),
      ];
    },
    glyph: (size, preset) => {
      const top = preset?.top ?? { w: round2(size.w * 0.75), d: round2(size.d * 0.6) };
      const topW = Math.min(top.w, size.w);
      const topD = Math.min(top.d, size.d);
      const chair = Math.min(0.4, topW / 2, (size.d - topD) / 2);
      const chairZ = size.d / 2 - chair / 2;
      const chairX = Math.min(topW / 2 - chair / 2, size.w / 2 - chair / 2);
      return {
        rects: [
          rect(0, 0, topW, topD),
          rect(-chairX, -chairZ, chair, chair),
          rect(chairX, -chairZ, chair, chair),
          rect(-chairX, chairZ, chair, chair),
          rect(chairX, chairZ, chair, chair),
        ],
      };
    },
  },
  {
    id: "table",
    name: "ローテーブル",
    presets: [
      { id: "table-90", name: "0.9 m", size: { w: 0.9, d: 0.5, h: 0.4 } },
      { id: "table-120", name: "1.2 m", size: { w: 1.2, d: 0.6, h: 0.4 } },
    ],
    limits: { w: [0.5, 2], d: [0.25, 1], h: [0.2, 0.6] },
    step: STEP,
    build: (size) => legged(size, size.w, size.d, TONE.wood, TONE.woodDark),
    glyph: (size) => outline(size),
  },
  {
    id: "desk",
    name: "デスク",
    presets: [
      { id: "desk-100", name: "1.0 m", size: { w: 1, d: 0.6, h: 0.72 } },
      { id: "desk-120", name: "1.2 m", size: { w: 1.2, d: 0.6, h: 0.72 } },
      { id: "desk-140", name: "1.4 m", size: { w: 1.4, d: 0.7, h: 0.72 } },
    ],
    limits: { w: [0.5, 2], d: [0.25, 1], h: [0.6, 1.1] },
    step: STEP,
    build: (size) => {
      const t = 0.05;
      const legH = size.h - t;
      const side = Math.min(0.05, size.w / 6);
      return [
        part(0, legH + t / 2, 0, size.w, t, size.d, TONE.wood),
        part(-(size.w - side) / 2, legH / 2, 0, side, legH, size.d, TONE.woodDark),
        part((size.w - side) / 2, legH / 2, 0, side, legH, size.d, TONE.woodDark),
      ];
    },
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
      lines: [line(-size.w / 2, size.d / 2 - 0.02, size.w / 2, size.d / 2 - 0.02)],
    }),
  },
  {
    id: "shelf",
    name: "本棚",
    presets: [
      { id: "shelf-60", name: "0.6 m", size: { w: 0.6, d: 0.3, h: 1.8 } },
      { id: "shelf-90", name: "0.9 m", size: { w: 0.9, d: 0.3, h: 1.8 } },
    ],
    limits: { w: [0.25, 2], d: [0.25, 0.75], h: [0.6, 2.4] },
    step: STEP,
    build: (size) => cased(size, TONE.wood, TONE.fabric),
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
      lines: [line(-size.w / 2, -size.d / 2 + 0.03, size.w / 2, -size.d / 2 + 0.03)],
    }),
  },
  {
    id: "cupboard",
    name: "食器棚",
    presets: [
      { id: "cupboard-90", name: "0.9 m", size: { w: 0.9, d: 0.45, h: 1.8 } },
      { id: "cupboard-120", name: "1.2 m", size: { w: 1.2, d: 0.45, h: 1.8 } },
    ],
    limits: { w: [0.5, 2], d: [0.25, 0.75], h: [0.6, 2.4] },
    step: STEP,
    build: (size) => cased(size, TONE.white, TONE.woodDark),
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
      lines: [line(0, -size.d / 2, 0, size.d / 2)],
    }),
  },
  {
    id: "chest",
    name: "チェスト",
    presets: [
      { id: "chest-80", name: "0.8 m", size: { w: 0.8, d: 0.45, h: 0.9 } },
      { id: "chest-100", name: "1.0 m", size: { w: 1, d: 0.45, h: 0.9 } },
    ],
    limits: { w: [0.25, 2], d: [0.25, 0.75], h: [0.4, 1.8] },
    step: STEP,
    build: (size) => withTop(size, TONE.wood, TONE.woodDark, 0.04),
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
      lines: [
        line(-size.w / 2, -size.d / 6, size.w / 2, -size.d / 6),
        line(-size.w / 2, size.d / 6, size.w / 2, size.d / 6),
      ],
    }),
  },
  {
    id: "fridge",
    name: "冷蔵庫",
    presets: [
      { id: "fridge-400", name: "400 L", size: { w: 0.6, d: 0.7, h: 1.8 } },
      { id: "fridge-500", name: "500 L", size: { w: 0.7, d: 0.7, h: 1.85 } },
    ],
    limits: { w: [0.5, 1], d: [0.5, 1], h: [1, 2] },
    step: STEP,
    build: (size) => [
      part(0, size.h / 2, 0, size.w, size.h, size.d, TONE.white),
      part(0, size.h * 0.72, size.d / 2 - 0.01, size.w * 0.8, 0.03, 0.02, TONE.metal),
    ],
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
      lines: [line(-size.w / 2, size.d / 2 - 0.04, size.w / 2, size.d / 2 - 0.04)],
    }),
  },
  {
    id: "washer",
    name: "洗濯機",
    presets: [
      { id: "washer-top", name: "縦型", size: { w: 0.6, d: 0.6, h: 1 } },
      { id: "washer-drum", name: "ドラム", size: { w: 0.65, d: 0.75, h: 1.05 } },
    ],
    limits: { w: [0.5, 1], d: [0.5, 1], h: [0.8, 1.4] },
    step: STEP,
    build: (size) => [
      part(0, size.h / 2, 0, size.w, size.h, size.d, TONE.white),
      part(0, size.h - 0.02, 0, size.w * 0.7, 0.04, size.d * 0.7, TONE.metal),
    ],
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d), rect(0, 0, size.w * 0.6, size.d * 0.6)],
    }),
  },
  {
    id: "kitchen",
    name: "キッチン",
    presets: [
      { id: "kitchen-i", name: "I 型", size: { w: 2.55, d: 0.65, h: 0.85 }, shape: "I" },
      { id: "kitchen-l", name: "L 型", size: { w: 2.55, d: 1.65, h: 0.85 }, shape: "L" },
      { id: "kitchen-island", name: "対面", size: { w: 2.55, d: 0.95, h: 0.85 }, shape: "island" },
    ],
    limits: { w: [1.5, 3.5], d: [0.5, 1.75], h: [0.75, 1] },
    step: STEP,
    build: (size, preset) => {
      const t = 0.05;
      const bodyH = size.h - t;
      const legD = preset?.shape === "L" ? Math.min(0.65, size.d) : size.d;
      const out: Part[] = [
        part(0, bodyH / 2, -(size.d / 2 - legD / 2), size.w, bodyH, legD, TONE.white),
        part(0, bodyH + t / 2, -(size.d / 2 - legD / 2), size.w, t, legD, TONE.woodDark),
      ];
      if (preset?.shape === "L" && size.d > legD) {
        const armD = size.d - legD;
        const armW = Math.min(0.65, size.w);
        out.push(
          part(-(size.w / 2 - armW / 2), bodyH / 2, size.d / 2 - armD / 2, armW, bodyH, armD, TONE.white),
          part(-(size.w / 2 - armW / 2), bodyH + t / 2, size.d / 2 - armD / 2, armW, t, armD, TONE.woodDark),
        );
      }
      return out;
    },
    glyph: (size, preset) => {
      const legD = preset?.shape === "L" ? Math.min(0.65, size.d) : size.d;
      const rects = [rect(0, -(size.d / 2 - legD / 2), size.w, legD)];
      if (preset?.shape === "L" && size.d > legD) {
        const armD = size.d - legD;
        const armW = Math.min(0.65, size.w);
        rects.push(rect(-(size.w / 2 - armW / 2), size.d / 2 - armD / 2, armW, armD));
      }
      // シンク
      rects.push(rect(-size.w / 4, -(size.d / 2 - legD / 2), Math.min(0.6, size.w / 3), legD * 0.7));
      return { rects };
    },
  },
  {
    id: "bath",
    name: "浴槽",
    presets: [
      { id: "bath-160", name: "1.6 m", size: { w: 1.6, d: 0.8, h: 0.55 } },
      { id: "bath-140", name: "1.4 m", size: { w: 1.4, d: 0.75, h: 0.55 } },
    ],
    limits: { w: [1, 2], d: [0.5, 1.25], h: [0.4, 0.8] },
    step: STEP,
    build: (size) => [
      part(0, size.h / 2, 0, size.w, size.h, size.d, TONE.white),
      part(0, size.h - 0.02, 0, size.w - 0.2, 0.04, size.d - 0.2, TONE.glass),
    ],
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d), rect(0, 0, size.w - 0.2, size.d - 0.2)],
    }),
  },
  {
    id: "vanity",
    name: "洗面台",
    presets: [
      { id: "vanity-75", name: "0.75 m", size: { w: 0.75, d: 0.55, h: 1.9 } },
      { id: "vanity-90", name: "0.9 m", size: { w: 0.9, d: 0.55, h: 1.9 } },
    ],
    limits: { w: [0.5, 1.5], d: [0.25, 0.75], h: [0.8, 2.1] },
    step: STEP,
    build: (size) => {
      // 洗面ボウル（厚み 0.04）のぶんを残して、キャビネットの高さを決める
      const cabinetH = Math.min(0.8, Math.max(size.h - 0.04, 0.1));
      const out: Part[] = [
        part(0, cabinetH / 2, 0, size.w, cabinetH, size.d, TONE.white),
        part(0, cabinetH + 0.02, 0, size.w, 0.04, size.d, TONE.glass),
      ];
      if (size.h > cabinetH + 0.2) {
        const mirrorH = size.h - cabinetH - 0.1;
        out.push(
          part(0, cabinetH + 0.1 + mirrorH / 2, -(size.d / 2 - 0.05), size.w, mirrorH, 0.1, TONE.glass),
        );
      }
      return out;
    },
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d), rect(0, 0.02, size.w * 0.6, size.d * 0.6)],
    }),
  },
  {
    id: "toilet",
    name: "便器",
    presets: [
      { id: "toilet-tank", name: "タンクあり", size: { w: 0.45, d: 0.8, h: 0.8 } },
      { id: "toilet-tankless", name: "タンクレス", size: { w: 0.4, d: 0.7, h: 0.45 } },
    ],
    limits: { w: [0.25, 0.75], d: [0.5, 1.25], h: [0.4, 1.2] },
    step: STEP,
    build: (size) => {
      const bowlH = Math.min(0.45, size.h);
      const tankD = Math.min(0.2, size.d / 3);
      const out: Part[] = [
        part(0, bowlH / 2, tankD / 2, size.w, bowlH, size.d - tankD, TONE.white),
      ];
      if (size.h > 0.6) {
        out.push(part(0, size.h / 2, -(size.d / 2 - tankD / 2), size.w, size.h, tankD, TONE.white));
      }
      return out;
    },
    glyph: (size) => ({
      rects: [rect(0, 0.05, size.w, size.d - 0.1), rect(0, -(size.d / 2 - 0.08), size.w, 0.16)],
    }),
  },
  {
    id: "tv",
    name: "テレビ",
    presets: TV_INCHES.map((inch) => ({
      id: `tv-${inch}`,
      name: `${inch} インチ`,
      size: tvSize(inch),
      inch,
    })),
    limits: { w: [0.5, 2.5], d: [0.05, 0.2], h: [0.3, 1.5] },
    // インチから作るので、刻みは 0.01（丸めで寸法が崩れないように）
    step: { w: 0.01, d: 0.01, h: 0.01 },
    build: (size) => [
      part(0, 0.01, 0, size.w * 0.4, 0.02, size.d, TONE.dark),
      part(0, 0.02 + (size.h - 0.02) / 2, 0, size.w, size.h - 0.02, size.d * 0.5, TONE.dark),
    ],
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
    }),
  },
  {
    id: "tvstand",
    name: "テレビ台",
    presets: [
      { id: "tvstand-120", name: "1.2 m", size: { w: 1.2, d: 0.4, h: 0.45 } },
      { id: "tvstand-150", name: "1.5 m", size: { w: 1.5, d: 0.4, h: 0.45 } },
      { id: "tvstand-180", name: "1.8 m", size: { w: 1.8, d: 0.4, h: 0.45 } },
    ],
    limits: { w: [0.5, 2.5], d: [0.25, 0.75], h: [0.3, 0.8] },
    step: STEP,
    build: (size) => withTop(size, TONE.wood, TONE.woodDark, 0.04),
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d)],
      lines: [line(-size.w / 2, 0, size.w / 2, 0)],
    }),
  },
  {
    id: "piano",
    name: "ピアノ",
    presets: [
      { id: "piano-upright", name: "アップライト", size: { w: 1.5, d: 0.65, h: 1.25 } },
      { id: "piano-grand", name: "グランド", size: { w: 1.5, d: 1.9, h: 1 } },
    ],
    limits: { w: [1.25, 2], d: [0.5, 2.5], h: [0.8, 1.5] },
    step: STEP,
    build: (size) => {
      const keyD = Math.min(0.25, size.d / 3);
      return [
        part(0, size.h / 2, -(size.d / 2 - (size.d - keyD) / 2), size.w, size.h, size.d - keyD, TONE.dark),
        part(0, Math.min(0.7, size.h - 0.05), size.d / 2 - keyD / 2, size.w * 0.9, 0.08, keyD, TONE.white),
      ];
    },
    glyph: (size) => {
      const keyD = Math.min(0.25, size.d / 3);
      return {
        rects: [
          rect(0, -(size.d / 2 - (size.d - keyD) / 2), size.w, size.d - keyD),
          rect(0, size.d / 2 - keyD / 2, size.w * 0.9, keyD),
        ],
      };
    },
  },
  {
    id: "plant",
    name: "観葉植物",
    presets: [
      { id: "plant-s", name: "小", size: { w: 0.4, d: 0.4, h: 0.8 } },
      { id: "plant-l", name: "大", size: { w: 0.6, d: 0.6, h: 1.6 } },
    ],
    limits: { w: [0.25, 1.25], d: [0.25, 1.25], h: [0.3, 2.4] },
    step: STEP,
    build: (size) => {
      const potH = size.h * 0.25;
      return [
        part(0, potH / 2, 0, size.w * 0.6, potH, size.d * 0.6, TONE.woodDark),
        part(0, potH + (size.h - potH) / 2, 0, size.w, size.h - potH, size.d, TONE.green),
      ];
    },
    glyph: (size) => ({
      rects: [rect(0, 0, size.w, size.d), rect(0, 0, size.w * 0.6, size.d * 0.6)],
    }),
  },
];

export function furnitureType(id: FurnitureId): FurnitureType {
  const found = FURNITURE.find((type) => type.id === id);
  // 型で 18 種に絞っているので通常は必ず見つかる。落ちるのは表を壊したときだけ
  if (!found) throw new Error(`未知の家具: ${id}`);
  return found;
}

export function findPreset(id: FurnitureId, presetId: string | null): FurniturePreset | null {
  if (presetId === null) return null;
  return furnitureType(id).presets.find((preset) => preset.id === presetId) ?? null;
}

/** 標準寸法から置くときの元。未知の id は 1 つ目に落とす */
export function presetSeed(id: FurnitureId, presetId: string): FurnitureSeed {
  const type = furnitureType(id);
  const preset = type.presets.find((item) => item.id === presetId) ?? type.presets[0];
  return {
    type: id,
    preset: preset.id,
    size: { ...preset.size },
    inch: preset.inch ?? null,
  };
}

/** その種類の既定（標準寸法の 1 つ目） */
export function defaultSeed(id: FurnitureId): FurnitureSeed {
  return presetSeed(id, furnitureType(id).presets[0].id);
}

/** 任意のインチのテレビ。標準に無いインチなら preset は null */
export function tvSeed(inch: number): FurnitureSeed {
  const known = (TV_INCHES as readonly number[]).includes(inch);
  return {
    type: "tv",
    preset: known ? `tv-${inch}` : null,
    size: tvSize(inch),
    inch,
  };
}

/**
 * 打ち込まれた任意寸法を、その種類の刻みと範囲に収める（幅・奥行きは 0.25 m、高さは 0.05 m）。
 *
 * **標準寸法（presets）には通さない。** 表の寸法は実物に合わせてあり、
 * ベッドの奥行き 1.95 m・キッチンの奥行き 0.65 m のように刻みに乗っていないものが多い。
 * ここを通すと 43 件のうち 39 件が別の寸法になってしまうので、presetSeed と
 * resizeFurniture は表の寸法をそのまま受け取る。
 */
export function clampSize(id: FurnitureId, size: Size3): Size3 {
  const type = furnitureType(id);
  const fit = (value: number, step: number, range: [number, number]) => {
    if (!Number.isFinite(value)) return range[0];
    const stepped = Math.round(value / step) * step;
    return round2(Math.min(Math.max(stepped, range[0]), range[1]));
  };
  return {
    w: fit(size.w, type.step.w, type.limits.w),
    d: fit(size.d, type.step.d, type.limits.d),
    h: fit(size.h, type.step.h, type.limits.h),
  };
}

/** 置いた家具から 3D の箱を組む */
export function buildParts(item: PlacedFurniture): readonly Part[] {
  const type = furnitureType(item.type);
  return type.build(item.size, findPreset(item.type, item.preset));
}

/** 置いた家具から平面図の記号を組む */
export function buildGlyph(item: PlacedFurniture): Glyph {
  const type = furnitureType(item.type);
  return type.glyph(item.size, findPreset(item.type, item.preset));
}
