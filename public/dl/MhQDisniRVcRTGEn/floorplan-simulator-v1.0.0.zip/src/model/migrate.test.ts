import { describe, expect, it } from "vitest";
import { defaultLayout } from "./grid";
import { DEFAULT_SIZE } from "./house";
import { migrate, V2_FURNITURE_MAP } from "./migrate";
import { defaultPlanFile, serializePlanFile } from "./plan";

function v2(): unknown {
  return {
    version: 2,
    floors: { 1: defaultLayout(DEFAULT_SIZE, 1), 2: defaultLayout(DEFAULT_SIZE, 2) },
    furniture: [
      { id: "f-1", type: "sofa", floor: 1, x: 2, z: 4.25, rotation: 0 },
      { id: "f-2", type: "tv", floor: 1, x: 2, z: 5.5, rotation: 0 },
      { id: "f-3", type: "bed", floor: 2, x: 1.25, z: 2, rotation: 0 },
      { id: "f-4", type: "desk", floor: 2, x: 8, z: 1, rotation: 90 },
    ],
  };
}

describe("v2 → v3", () => {
  it("案 1 件になり、外皮は 9 × 8 m の 2 階建て", () => {
    const file = migrate(v2());
    expect(file).not.toBeNull();
    expect(file!.version).toBe(3);
    expect(file!.plans).toHaveLength(1);
    expect(file!.plans[0].name).toBe("案 1");
    expect(file!.plans[0].id).toBe("plan-1");
    expect(file!.plans[0].size).toEqual(DEFAULT_SIZE);
  });

  it("家具は floor の欄で 2 つに振り分けられる", () => {
    const file = migrate(v2())!;
    expect(file.plans[0].floors[1].furniture.map((item) => item.type)).toEqual(["sofa", "tvstand"]);
    expect(file.plans[0].floors[2].furniture.map((item) => item.type)).toEqual(["bed", "desk"]);
    expect(file.plans[0].floors[2].furniture[1].rotation).toBe(90);
  });

  it("見本の寸法がそのまま入り、いちばん近い標準寸法の id が付く", () => {
    const file = migrate(v2())!;
    const sofa = file.plans[0].floors[1].furniture[0];
    expect(sofa.preset).toBe(V2_FURNITURE_MAP.sofa.preset);
    expect(sofa.size).toEqual({ w: 1.8, d: 0.9, h: 0.8 });
    const stand = file.plans[0].floors[1].furniture[1];
    expect(stand.type).toBe("tvstand");
    expect(stand.size).toEqual({ w: 1.5, d: 0.45, h: 0.45 });
    expect(stand.inch).toBeNull();
  });

  it("建具・設備・外周は空", () => {
    const file = migrate(v2())!;
    expect(file.plans[0].floors[1].openings).toEqual([]);
    expect(file.plans[0].floors[1].fixtures).toEqual([]);
    expect(file.plans[0].floors[2].exterior).toEqual([]);
  });

  it("見本の 8 種はすべて写せる", () => {
    expect(Object.keys(V2_FURNITURE_MAP).sort()).toEqual(
      ["bath", "bed", "desk", "dining", "kitchen", "shelf", "sofa", "tv"].sort(),
    );
  });
});

describe("そのほか", () => {
  it("v3 はそのまま検証して返す", () => {
    const file = defaultPlanFile();
    expect(migrate(file)).toEqual(file);
    expect(migrate(serializePlanFile(file))).toEqual(file);
  });

  it("v1・version 無し・壊れた JSON は null", () => {
    expect(migrate({ version: 1, tree: {} })).toBeNull();
    expect(migrate({ floors: {} })).toBeNull();
    expect(migrate("{")).toBeNull();
    expect(migrate(null)).toBeNull();
    expect(migrate(42)).toBeNull();
  });

  it("マスの数が 288 でない v2 は受け取らない", () => {
    const broken = v2() as { floors: { 1: { cells: string[] } } };
    broken.floors[1].cells.pop();
    expect(migrate(broken)).toBeNull();
  });

  it("見本に無い家具の種類がある v2 は受け取らない", () => {
    const broken = v2() as { furniture: { type: string }[] };
    broken.furniture[0].type = "hovercraft";
    expect(migrate(broken)).toBeNull();
  });
});
