import { describe, expect, it } from "vitest";
import { defaultLayout, roomRects, wallSegments } from "./grid";
import { DEFAULT_SIZE, houseOf, type PlanSize } from "./house";
import { type Opening } from "./openings";
import { defaultPlanFile, resizePlan } from "./plan";
import {
  annotationPositions,
  BOX_BUDGET,
  countBoxes,
  exteriorRuns,
  floorBoxes,
  FRAME_WIDTH,
  INTERIOR_WALL,
  interiorRuns,
  openingFloorMark,
  openingFrames,
  openingGlass,
  roofShape,
  roomSlab,
  slabPanel,
  wallPieces,
  type WallRun,
} from "./shell";

const SIZE = DEFAULT_SIZE;
const H = houseOf(SIZE);

describe("床", () => {
  it("スラブの上面が各階の床の高さと合う", () => {
    const first = slabPanel(SIZE, 1);
    expect(first.position[1] + first.size[1] / 2).toBeCloseTo(0, 9);
    expect(first.size).toEqual([9, 0.25, 8]);
    const second = slabPanel(SIZE, 2);
    expect(second.position[1] + second.size[1] / 2).toBeCloseTo(2.95, 9);
    expect(first.id).not.toBe(second.id);
  });

  it("部屋の床は部屋の矩形ちょうどの大きさで、床の高さに置く", () => {
    const layout = defaultLayout(SIZE, 1);
    const rect = roomRects(SIZE, layout)[0];
    const panel = roomSlab(SIZE, rect, 1);
    expect(panel.size[0]).toBe(rect.w);
    expect(panel.size[2]).toBe(rect.d);
    expect(panel.position[1] - panel.size[1] / 2).toBeCloseTo(0, 9);
    expect(panel.position[0]).toBeCloseTo(rect.x + rect.w / 2 - 4.5, 9);
  });

  it("部屋の床の id は階をまたいでも重複しない", () => {
    const layout = defaultLayout(SIZE, 1);
    const ids = [1, 2].flatMap((floor) =>
      roomRects(SIZE, layout).map((rect) => roomSlab(SIZE, rect, floor as 1 | 2).id),
    );
    expect(new Set(ids).size).toBe(ids.length);
  });
});

describe("壁の走り", () => {
  it("外壁は 4 本。南北は間口いっぱい、東西は角のぶん詰める", () => {
    const runs = exteriorRuns(SIZE, 1);
    expect(runs).toHaveLength(4);
    const north = runs.find((run) => run.id.endsWith("-n"))!;
    expect(north).toMatchObject({ axis: "z", at: 0, from: 0, to: 9, thickness: H.wallThickness });
    const south = runs.find((run) => run.id.endsWith("-s"))!;
    expect(south).toMatchObject({ axis: "z", at: 8, from: 0, to: 9 });
    const west = runs.find((run) => run.id.endsWith("-w"))!;
    expect(west).toMatchObject({ axis: "x", at: 0, from: 0.2, to: 7.8 });
    const east = runs.find((run) => run.id.endsWith("-e"))!;
    expect(east).toMatchObject({ axis: "x", at: 9, from: 0.2, to: 7.8 });
  });

  it("外壁の走りの id は階をまたいでも重複しない", () => {
    const ids = [...exteriorRuns(SIZE, 1), ...exteriorRuns(SIZE, 2)].map((run) => run.id);
    expect(new Set(ids).size).toBe(8);
  });

  it("内壁の走りは境目の数だけ、厚みは 0.12 m", () => {
    const lines = wallSegments(SIZE, defaultLayout(SIZE, 1));
    const runs = interiorRuns(lines, 1);
    expect(runs).toHaveLength(lines.length);
    expect(runs.every((run) => run.thickness === INTERIOR_WALL)).toBe(true);
    expect(runs[0]).toMatchObject({
      axis: lines[0].axis,
      at: lines[0].at,
      from: lines[0].from,
      to: lines[0].to,
    });
    const second = interiorRuns(lines, 2);
    expect(new Set([...runs, ...second].map((run) => run.id)).size).toBe(lines.length * 2);
  });
});

describe("屋根", () => {
  it("四角錐の底面が軒の出まで届き、最上階の天井に載る", () => {
    const roof = roofShape(SIZE);
    expect(roof.radius).toBeCloseTo(((9 + 1) / 2) * Math.SQRT2, 9);
    expect(roof.scaleZ).toBeCloseTo((8 + 1) / (9 + 1), 9);
    expect(roof.height).toBe(1.6);
    expect(roof.position[1]).toBeCloseTo(5.45 + 0.8, 9);
    expect(roof.rotationY).toBeCloseTo(Math.PI / 4, 9);
  });

  it("平屋は 1 階の天井に載る", () => {
    const flat: PlanSize = { width: 9, depth: 8, floors: 1 };
    expect(roofShape(flat).position[1]).toBeCloseTo(2.7 + 0.8, 9);
  });
});

describe("注記", () => {
  it("部屋ごとに 1 つ、天井の 0.35 m 下に置く", () => {
    const layout = defaultLayout(SIZE, 1);
    const notes = annotationPositions(SIZE, layout, 1);
    expect(notes).toHaveLength(layout.rooms.length);
    expect(notes[0].position[1]).toBeCloseTo(2.7 - 0.35, 9);
    expect(notes[0].label).toBe(layout.rooms[0].label);
    expect(notes[0].area).toBe(33);
  });

  it("まだ 1 マスも塗られていない部屋には吹き出しを出さない", () => {
    const layout = defaultLayout(SIZE, 1);
    const withEmpty = {
      rooms: [...layout.rooms, { id: "room-9", label: "書斎" as const }],
      cells: layout.cells,
    };
    expect(annotationPositions(SIZE, withEmpty, 1)).toHaveLength(layout.rooms.length);
  });

  it("id は階をまたいでも重複しない", () => {
    const layout = defaultLayout(SIZE, 1);
    const ids = [1, 2].flatMap((floor) =>
      annotationPositions(SIZE, layout, floor as 1 | 2).map((note) => note.id),
    );
    expect(new Set(ids).size).toBe(ids.length);
  });
});

const RUN: WallRun = { id: "f1-test", axis: "x", at: 4, from: 0, to: 8, thickness: 0.12 };
const CEIL = 2.7;

function op(patch: Partial<Opening> = {}): Opening {
  return {
    id: "o-1",
    kind: "door",
    style: null,
    axis: "x",
    at: 4,
    start: 3.5,
    width: 0.75,
    sill: 0,
    height: 2,
    hinge: "start",
    swing: "plus",
    ...patch,
  };
}

/** 全高の箱（id の末尾が -p<k>）。T を保つのは filter の戻り値が引数と同じ型に絞られず
 * `{ id: string }[]` に落ちて呼び出し側で size 等が読めなくなるのを防ぐため */
const fullPieces = <T extends { id: string }>(panels: T[]): T[] =>
  panels.filter((p) => /-p\d+$/.test(p.id));

describe("wallPieces", () => {
  it("建具の無い走りは箱 1 つで、走りの長さぶん", () => {
    const pieces = wallPieces(SIZE, RUN, [], 0, CEIL);
    expect(pieces).toHaveLength(1);
    expect(pieces[0].size[2]).toBeCloseTo(8, 9);
    expect(pieces[0].size[0]).toBeCloseTo(0.12, 9);
    expect(pieces[0].size[1]).toBeCloseTo(2.7, 9);
  });

  it("中央にドア 1 つで箱 3 つ（左・右・垂れ壁）", () => {
    const pieces = wallPieces(SIZE, RUN, [op()], 0, CEIL);
    expect(pieces).toHaveLength(3);
    expect(fullPieces(pieces)).toHaveLength(2);
    const head = pieces.find((p) => p.id.includes("-h"))!;
    expect(head.size[1]).toBeCloseTo(0.7, 9);
    expect(head.position[1]).toBeCloseTo(2.35, 9);
  });

  it("sill > 0 の窓で箱 4 つ（左・右・腰壁・垂れ壁）", () => {
    const pieces = wallPieces(SIZE, RUN, [op({ kind: "window", style: "koshi", sill: 0.9, height: 1.2 })], 0, CEIL);
    expect(pieces).toHaveLength(4);
    const sill = pieces.find((p) => p.id.includes("-s"))!;
    expect(sill.size[1]).toBeCloseTo(0.9, 9);
    expect(sill.position[1]).toBeCloseTo(0.45, 9);
  });

  it("建具が走りの端に接していれば端の箱が出ない", () => {
    const left = wallPieces(SIZE, RUN, [op({ start: 0 })], 0, CEIL);
    expect(fullPieces(left)).toHaveLength(1);
    const both = wallPieces(SIZE, RUN, [op({ start: 0, width: 3.5 }), op({ id: "o-2", start: 4.5, width: 3.5 })], 0, CEIL);
    expect(fullPieces(both)).toHaveLength(1);
  });

  it("建具 2 つで箱が 5 つ", () => {
    const pieces = wallPieces(SIZE, RUN, [op({ start: 1 }), op({ id: "o-2", start: 5 })], 0, CEIL);
    expect(pieces).toHaveLength(5);
    expect(fullPieces(pieces)).toHaveLength(3);
  });

  it("sill + height が天井と同じなら垂れ壁が出ない", () => {
    const pieces = wallPieces(SIZE, RUN, [op({ height: 2.7 })], 0, CEIL);
    expect(pieces).toHaveLength(2);
    expect(pieces.every((p) => /-p\d+$/.test(p.id))).toBe(true);
  });

  it("全高の箱の長さの合計 + 開口の幅の合計 = 走りの長さ", () => {
    const openings = [op({ start: 1 }), op({ id: "o-2", start: 5, width: 1.5 })];
    const pieces = wallPieces(SIZE, RUN, openings, 0, CEIL);
    const solid = fullPieces(pieces).reduce((sum, p) => sum + p.size[2], 0);
    const holes = openings.reduce((sum, o) => sum + o.width, 0);
    expect(solid + holes).toBeCloseTo(RUN.to - RUN.from, 9);
  });

  it("断面（天井 1.1 m）では、腰より上の建具は壁を割らない", () => {
    const koshi = op({ kind: "window", style: "koshi", sill: 0.9, height: 1.2 });
    const cut = wallPieces(SIZE, RUN, [koshi], 0, 1.1);
    // sill 0.9 < 1.1 なので腰壁だけが出て、垂れ壁は天井を超えるので出ない
    expect(cut.map((p) => p.id.replace(/\d+$/, ""))).toEqual(["f1-test-p", "f1-test-s", "f1-test-p"]);
    const high = wallPieces(SIZE, RUN, [op({ sill: 1.5, height: 1 })], 0, 1.1);
    expect(high).toHaveLength(1);
  });

  it("外壁の走りは外側の面が線に乗る", () => {
    const north = exteriorRuns(SIZE, 1).find((run) => run.id.endsWith("-n"))!;
    const [piece] = wallPieces(SIZE, north, [], 0, CEIL);
    expect(piece.position[2]).toBeCloseTo(-4 + 0.1, 9);
    const east = exteriorRuns(SIZE, 1).find((run) => run.id.endsWith("-e"))!;
    const [eastPiece] = wallPieces(SIZE, east, [], 0, CEIL);
    expect(eastPiece.position[0]).toBeCloseTo(4.5 - 0.1, 9);
  });
});

describe("枠・ガラス・断面の床線", () => {
  it("ドアは枠 3 本（縦 2 + 上）、腰窓は 4 本", () => {
    expect(openingFrames(SIZE, RUN, op(), 0)).toHaveLength(3);
    const koshi = op({ kind: "window", style: "koshi", sill: 0.9, height: 1.2 });
    expect(openingFrames(SIZE, RUN, koshi, 0)).toHaveLength(4);
    expect(FRAME_WIDTH).toBe(0.06);
  });

  it("枠は開口の中に収まり、壁より 2 cm 厚い", () => {
    for (const frame of openingFrames(SIZE, RUN, op(), 0)) {
      expect(frame.size[0]).toBeCloseTo(RUN.thickness + 0.02, 9);
      expect(frame.size[2]).toBeLessThanOrEqual(0.75 + 1e-9);
    }
  });

  it("ガラスは窓だけ、開口とちょうど同じ大きさで壁より 4 cm 厚い", () => {
    expect(openingGlass(SIZE, RUN, op(), 0)).toBeNull();
    const koshi = op({ kind: "window", style: "koshi", sill: 0.9, height: 1.2 });
    const glass = openingGlass(SIZE, RUN, koshi, 0)!;
    expect(glass.size[0]).toBeCloseTo(RUN.thickness + 0.04, 9);
    expect(glass.size[1]).toBeCloseTo(1.2, 9);
    expect(glass.size[2]).toBeCloseTo(koshi.width, 9);
    expect(glass.position[1]).toBeCloseTo(1.5, 9);
  });

  it("断面の床線は薄い箱", () => {
    const mark = openingFloorMark(SIZE, RUN, op(), 0);
    expect(mark.size[1]).toBeCloseTo(0.02, 9);
    expect(mark.size[0]).toBeCloseTo(0.04, 9);
    expect(mark.size[2]).toBeCloseTo(0.75, 9);
    expect(mark.position[1]).toBeCloseTo(0.01, 9);
  });
});

describe("floorBoxes", () => {
  it("既定の案の 1F を組み立てると、箱の数が上限を下回る", () => {
    const doc = defaultPlanFile().plans[0];
    const boxes = floorBoxes(doc, 1, false);
    expect(boxes.rooms.length).toBe(roomRects(doc.size, doc.floors[1].layout).length);
    expect(boxes.walls.length).toBeGreaterThan(4);
    expect(boxes.glass.length).toBeGreaterThan(0);
    expect(boxes.marks).toHaveLength(0);
    expect(countBoxes(boxes)).toBeLessThan(BOX_BUDGET);
  });

  it("断面では枠もガラスも出ず、床線だけが出る", () => {
    const doc = defaultPlanFile().plans[0];
    const boxes = floorBoxes(doc, 1, true);
    expect(boxes.frames).toHaveLength(0);
    expect(boxes.glass).toHaveLength(0);
    expect(boxes.marks.length).toBe(doc.floors[1].openings.length);
  });

  it("大きい外皮でも上限を下回る", () => {
    const doc = resizePlan(defaultPlanFile().plans[0], { width: 16, depth: 16, floors: 2 });
    expect(countBoxes(floorBoxes(doc, 1, false))).toBeLessThan(BOX_BUDGET);
  });

  it("家具の箱には持ち主の id が付く（選択の強調に使う）", () => {
    const doc = defaultPlanFile().plans[0];
    const boxes = floorBoxes(doc, 1, false);
    expect(boxes.furniture[0].itemId).toBe(doc.floors[1].furniture[0].id);
    expect(new Set(boxes.furniture.map((entry) => entry.part.id)).size).toBe(boxes.furniture.length);
  });
});
