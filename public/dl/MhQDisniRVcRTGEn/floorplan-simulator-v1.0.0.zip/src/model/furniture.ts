/**
 * 売り物: 家具の置き方。見本と違い「種類ごとの箱の表」は持たない ──
 * 実寸を選べるようにしたので、寸法から箱と記号を組むのは catalog.ts の役目。
 * ここにあるのは、床の上のどこに・どの向きで・どれだけの大きさで置くか だけ。
 * 箱の位置は「家具の中心を原点、y は床から」で書く。回転と階の高さは partsInScene が掛ける。
 */
import { snap, toScene } from "./grid";
import { SNAP, type PlanSize, type Vec3 } from "./house";

export type Rotation = 0 | 90 | 180 | 270;

/** 幅(x) × 奥行き(z) × 高さ(y)。回していないときの向き */
export type Size3 = { w: number; d: number; h: number };

/** 家具の中心を原点にした箱の 1 つ（3D 用）。y は床から測った高さ */
export type Part = { offset: Vec3; size: Vec3; color: string };

/** 平面図の記号。footprint に対する相対座標（中心原点） */
export type GlyphRect = { x: number; z: number; w: number; d: number };
export type GlyphLine = { x1: number; z1: number; x2: number; z2: number };
export type Glyph = { rects: readonly GlyphRect[]; lines?: readonly GlyphLine[] };

/** 3D に置く箱。Scene はこれを並べるだけ */
export type ScenePart = { id: string; position: Vec3; size: Vec3; color: string };

export type FurnitureId =
  | "bed"
  | "sofa"
  | "dining"
  | "table"
  | "desk"
  | "shelf"
  | "cupboard"
  | "chest"
  | "fridge"
  | "washer"
  | "kitchen"
  | "bath"
  | "vanity"
  | "toilet"
  | "tv"
  | "tvstand"
  | "piano"
  | "plant";

/** 家具・設備の色。three.js の材質に渡す値なので、CSS のトークンではなくここに直に持つ */
export const TONE = {
  wood: "#a9825a",
  woodDark: "#6f5334",
  fabric: "#7d8a99",
  white: "#e6e3dc",
  metal: "#b9bcc0",
  glass: "#9fb6c4",
  dark: "#2f3237",
  green: "#6f8f5f",
} as const;

export type PlacedFurniture = {
  /** "f-<n>" の連番 */
  id: string;
  type: FurnitureId;
  /** 標準寸法の id。任意寸法にしたら null */
  preset: string | null;
  size: Size3;
  /** テレビだけ持つ。画面の対角（インチ） */
  inch: number | null;
  /** 中心（床座標 m）。SNAP の倍数 */
  x: number;
  z: number;
  rotation: Rotation;
};

/** 家具・設備に共通する「床の上に置いたもの」 */
export type Placed = { x: number; z: number; rotation: Rotation; size: Size3 };

/** 置くときの元。catalog.ts の defaultSeed が作る */
export type FurnitureSeed = {
  type: FurnitureId;
  preset: string | null;
  size: Size3;
  inch: number | null;
};

/** 小数 2 桁に整える。0.25 刻みの寸法を足し引きした端数を落とす */
export function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function turn(rotation: Rotation): Rotation {
  if (rotation === 0) return 90;
  if (rotation === 90) return 180;
  if (rotation === 180) return 270;
  return 0;
}

/** 床座標の点を回す。x は東・z は南なので、3D も平面図（SVG の rotate）も同じ向きに回る */
export function turnPoint(x: number, z: number, rotation: Rotation): [number, number] {
  if (rotation === 90) return [-z, x];
  if (rotation === 180) return [-x, -z];
  if (rotation === 270) return [z, -x];
  return [x, z];
}

/** 回転を掛けたあとの 幅 × 奥行き */
export function footprintOf(item: Placed): [number, number] {
  const turned = item.rotation === 90 || item.rotation === 270;
  return turned ? [item.size.d, item.size.w] : [item.size.w, item.size.d];
}

/**
 * 中心を 1 辺の内側に寄せる。端の値（幅の半分）は先に SNAP の倍数へ切り上げてから寄せるので、
 * 寄せたあとの中心も SNAP の倍数のまま ── 丸めてから寄せると、外皮が 0.5 の倍数でも
 * 端が 0.005 ぶん外へ出てしまう（8 − 1.95/2 = 7.025 → 7.03 で、輪郭を 0.005 はみ出す）。
 * 数でない値は内側の端に落とす（snapValue と同じ扱い）。
 */
function fitCenter(value: number, span: number, foot: number): number {
  // 外皮より大きいものは中心に置く（下限が上限を追い越さないように）
  if (foot >= span) return round2(span / 2);
  // 浮動小数の誤差で 1 段ぶん外へ広がらないよう、切り上げの手前で幅を持たせる
  const min = round2(Math.ceil(foot / 2 / SNAP - 1e-9) * SNAP);
  // span は CELL（= SNAP × 2）の倍数なので、上限は下限の鏡写しで SNAP の倍数になる
  const max = round2(span - min);
  if (!Number.isFinite(value)) return min;
  return round2(Math.min(Math.max(value, min), max));
}

/** 回転後の footprint が床の輪郭に収まるよう中心を寄せる。寄せたあとも中心は SNAP の倍数 */
export function clampInside<T extends Placed>(size: PlanSize, item: T): T {
  const [w, d] = footprintOf(item);
  return { ...item, x: fitCenter(item.x, size.width, w), z: fitCenter(item.z, size.depth, d) };
}

/**
 * 輪郭の外に出たものを中へ寄せる。1 つも動かないときは同じ参照を返す
 * （動いていない配列で再描画を起こさないため。pruneExterior と揃える）。
 */
export function pruneInside<T extends Placed>(size: PlanSize, list: readonly T[]): T[] {
  let moved = false;
  const next = list.map((item) => {
    const fitted = clampInside(size, item);
    if (fitted.x === item.x && fitted.z === item.z) return item;
    moved = true;
    return fitted;
  });
  return moved ? next : (list as T[]);
}

/** 回転を掛けて 3D の座標にした箱の一覧。y は階の床の高さ（base）を足す */
export function partsInScene(
  size: PlanSize,
  item: Placed & { id: string },
  parts: readonly Part[],
  base: number,
): ScenePart[] {
  const [sx, sz] = toScene(size, item.x, item.z);
  const turned = item.rotation === 90 || item.rotation === 270;
  return parts.map((part, index) => {
    const [px, pz] = turnPoint(part.offset[0], part.offset[2], item.rotation);
    const [w, h, d] = part.size;
    return {
      id: `${item.id}-${index}`,
      position: [sx + px, base + part.offset[1], sz + pz] as Vec3,
      size: (turned ? [d, h, w] : [w, h, d]) as Vec3,
      color: part.color,
    };
  });
}

/** 新しい id。"<prefix>-<n>" の最大 + 1 */
export function nextSeqId(list: readonly { id: string }[], prefix: string): string {
  const pattern = new RegExp(`^${prefix}-(\\d+)$`);
  let max = 0;
  for (const item of list) {
    const match = pattern.exec(item.id);
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `${prefix}-${max + 1}`;
}

export function addFurniture(
  size: PlanSize,
  list: readonly PlacedFurniture[],
  seed: FurnitureSeed,
  at: [number, number],
): PlacedFurniture[] {
  return [
    ...list,
    clampInside(size, {
      id: nextSeqId(list, "f"),
      type: seed.type,
      preset: seed.preset,
      size: { ...seed.size },
      inch: seed.inch,
      x: snap(at[0]),
      z: snap(at[1]),
      rotation: 0 as Rotation,
    }),
  ];
}

export function moveFurniture(
  size: PlanSize,
  list: readonly PlacedFurniture[],
  id: string,
  x: number,
  z: number,
): PlacedFurniture[] {
  return list.map((item) =>
    item.id === id ? clampInside(size, { ...item, x: snap(x), z: snap(z) }) : item,
  );
}

export function rotateFurniture(
  size: PlanSize,
  list: readonly PlacedFurniture[],
  id: string,
): PlacedFurniture[] {
  return list.map((item) =>
    item.id === id ? clampInside(size, { ...item, rotation: turn(item.rotation) }) : item,
  );
}

/**
 * 寸法を変える。preset を渡さなければ「任意寸法にした」とみなして preset を外す。
 * 寸法はそのまま受け取る ── 打ち込まれた任意寸法だけ、呼ぶ側が先に catalog.ts の
 * clampSize を通す。標準寸法（ベッド 1.95 m、キッチン 0.65 m など）は 0.25 m 刻みに
 * 乗っていないので、ここで丸めると表の寸法と食い違う。
 */
export function resizeFurniture(
  size: PlanSize,
  list: readonly PlacedFurniture[],
  id: string,
  patch: Partial<Size3> & { preset?: string | null; inch?: number | null },
): PlacedFurniture[] {
  return list.map((item) => {
    if (item.id !== id) return item;
    const next: PlacedFurniture = {
      ...item,
      size: {
        w: patch.w ?? item.size.w,
        d: patch.d ?? item.size.d,
        h: patch.h ?? item.size.h,
      },
      preset: patch.preset === undefined ? null : patch.preset,
      inch: patch.inch === undefined ? item.inch : patch.inch,
    };
    return clampInside(size, next);
  });
}

export function removeFurniture(
  list: readonly PlacedFurniture[],
  id: string,
): PlacedFurniture[] {
  return list.filter((item) => item.id !== id);
}

/** 外皮を変えたあと、輪郭の外に出た家具を中へ寄せる。1 つも動かなければ同じ参照 */
export function pruneFurniture(
  size: PlanSize,
  list: readonly PlacedFurniture[],
): PlacedFurniture[] {
  return pruneInside(size, list);
}

function hueToRgb(p: number, q: number, t: number): number {
  let u = t;
  if (u < 0) u += 1;
  if (u > 1) u -= 1;
  if (u < 1 / 6) return p + (q - p) * 6 * u;
  if (u < 1 / 2) return q;
  if (u < 2 / 3) return p + (q - p) * (2 / 3 - u) * 6;
  return p;
}

/**
 * #rrggbb を HSL に直し、明度（L）を amount だけ上げて #rrggbb に戻す。
 * 選択中のものを「同じ色のまま少し明るく」見せるために使う。
 */
export function lighten(hex: string, amount: number): string {
  const value = hex.replace("#", "");
  const r = Number.parseInt(value.slice(0, 2), 16) / 255;
  const g = Number.parseInt(value.slice(2, 4), 16) / 255;
  const b = Number.parseInt(value.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const delta = max - min;
    s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);
    if (max === r) h = (g - b) / delta + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / delta + 2;
    else h = (r - g) / delta + 4;
    h /= 6;
  }
  const light = Math.min(1, l + amount);
  const q = light < 0.5 ? light * (1 + s) : light + s - light * s;
  const p = 2 * light - q;
  const channel = (t: number) =>
    Math.round(hueToRgb(p, q, t) * 255)
      .toString(16)
      .padStart(2, "0");
  return `#${channel(h + 1 / 3)}${channel(h)}${channel(h - 1 / 3)}`;
}
