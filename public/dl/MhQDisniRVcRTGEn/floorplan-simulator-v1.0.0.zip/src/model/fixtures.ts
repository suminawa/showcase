/**
 * 売り物: 設備。クローゼット・押入・玄関収納・階段の 4 種。
 * 置き方は家具と同じ（中心 0.25 m 刻み、4 方向の回転、ドラッグで移動）。
 * 家具と違うのは、扉の記号と、3D の側板・棚板（階段は段板）を持つこと。
 */
import { snapValue } from "./dimensions";
import {
  clampInside,
  nextSeqId,
  pruneInside,
  TONE,
  turn,
  type Glyph,
  type GlyphLine,
  type GlyphRect,
  type Part,
  type Rotation,
  type Size3,
} from "./furniture";
import { snap } from "./grid";
import { HEIGHT_SNAP, SNAP, type PlanSize, type Vec3 } from "./house";

export type FixtureKind = "closet" | "oshiire" | "genkan" | "stairs";
export type FixtureDoor = "folding" | "sliding" | "hinged" | "none";

export type Fixture = {
  /** "x-<n>" の連番 */
  id: string;
  kind: FixtureKind;
  /** 標準寸法を使っていれば kind と同じ id。任意寸法にしたら null */
  preset: string | null;
  size: Size3;
  door: FixtureDoor;
  /** 中心（床座標 m）。SNAP の倍数 */
  x: number;
  z: number;
  /** 扉の面が向く向き。0 = 北（−z）、90 = 東、180 = 南、270 = 西 */
  rotation: Rotation;
  /** 階段だけ使う。段数 */
  steps: number | null;
};

export const STAIRS_MIN_STEPS = 8;
export const STAIRS_MAX_STEPS = 20;
/** 階段の既定の段数 */
export const STAIRS_STEPS = 13;

export const FIXTURE_PRESETS: Record<
  FixtureKind,
  { name: string; size: Size3; door: FixtureDoor; steps: number | null }
> = {
  closet: { name: "クローゼット", size: { w: 1.65, d: 0.75, h: 2.3 }, door: "folding", steps: null },
  oshiire: { name: "押入", size: { w: 1.75, d: 0.85, h: 2.3 }, door: "sliding", steps: null },
  genkan: { name: "玄関収納", size: { w: 0.9, d: 0.4, h: 2 }, door: "hinged", steps: null },
  stairs: { name: "階段", size: { w: 0.95, d: 2.6, h: 2.7 }, door: "none", steps: STAIRS_STEPS },
};

export const FIXTURE_LIMITS: Record<
  FixtureKind,
  { w: [number, number]; d: [number, number]; h: [number, number] }
> = {
  closet: { w: [0.5, 3], d: [0.5, 1.5], h: [1, 2.5] },
  oshiire: { w: [0.5, 3], d: [0.5, 1.5], h: [1, 2.5] },
  genkan: { w: [0.5, 2], d: [0.25, 1], h: [0.5, 2.5] },
  stairs: { w: [0.75, 1.5], d: [1.5, 4], h: [2, 3] },
};

export function fixtureName(kind: FixtureKind): string {
  return FIXTURE_PRESETS[kind].name;
}

/**
 * 段数を 8〜20 の整数に収める。null（階段でないもの）はそのまま。
 * 段数は 3D の段板と 2D の線の本数になるので、大きい値がそのまま通ると
 * 箱が何万個も並んで画面が止まる（保存データを手で書き換えたときに起きる）。
 */
export function clampSteps(steps: number | null): number | null {
  if (steps === null) return null;
  if (!Number.isFinite(steps)) return STAIRS_STEPS;
  return Math.round(Math.min(Math.max(steps, STAIRS_MIN_STEPS), STAIRS_MAX_STEPS));
}

/** 階段の段板の枚数。欄が空いていれば既定の段数 */
export function stepsOf(item: Fixture): number {
  return clampSteps(item.steps) ?? STAIRS_STEPS;
}

/** 置くときの元。id と位置は呼ぶ側が入れる */
export function fixtureSeed(kind: FixtureKind): Omit<Fixture, "id" | "x" | "z" | "rotation"> {
  const preset = FIXTURE_PRESETS[kind];
  return {
    kind,
    preset: kind,
    size: { ...preset.size },
    door: preset.door,
    steps: clampSteps(preset.steps),
  };
}

export function addFixture(
  size: PlanSize,
  list: readonly Fixture[],
  kind: FixtureKind,
  at: [number, number],
): Fixture[] {
  return [
    ...list,
    clampInside(size, {
      ...fixtureSeed(kind),
      id: nextSeqId(list, "x"),
      x: snap(at[0]),
      z: snap(at[1]),
      rotation: 0 as Rotation,
    }),
  ];
}

export function moveFixture(
  size: PlanSize,
  list: readonly Fixture[],
  id: string,
  x: number,
  z: number,
): Fixture[] {
  return list.map((item) =>
    item.id === id ? clampInside(size, { ...item, x: snap(x), z: snap(z) }) : item,
  );
}

export function rotateFixture(size: PlanSize, list: readonly Fixture[], id: string): Fixture[] {
  return list.map((item) =>
    item.id === id ? clampInside(size, { ...item, rotation: turn(item.rotation) }) : item,
  );
}

export type FixturePatch = Partial<Size3> & { steps?: number; door?: FixtureDoor };

export function resizeFixture(
  size: PlanSize,
  list: readonly Fixture[],
  id: string,
  patch: FixturePatch,
): Fixture[] {
  return list.map((item) => {
    if (item.id !== id) return item;
    const limits = FIXTURE_LIMITS[item.kind];
    const touched = patch.w !== undefined || patch.d !== undefined || patch.h !== undefined;
    const next: Fixture = {
      ...item,
      size: {
        w: patch.w === undefined ? item.size.w : snapValue(patch.w, SNAP, limits.w[0], limits.w[1]),
        d: patch.d === undefined ? item.size.d : snapValue(patch.d, SNAP, limits.d[0], limits.d[1]),
        h: patch.h === undefined ? item.size.h : snapValue(patch.h, HEIGHT_SNAP, limits.h[0], limits.h[1]),
      },
      door: patch.door ?? item.door,
      steps: clampSteps(
        patch.steps === undefined
          ? item.steps
          : snapValue(patch.steps, 1, STAIRS_MIN_STEPS, STAIRS_MAX_STEPS),
      ),
      preset: touched ? null : item.preset,
    };
    return clampInside(size, next);
  });
}

export function removeFixture(list: readonly Fixture[], id: string): Fixture[] {
  return list.filter((item) => item.id !== id);
}

/** 外皮を変えたあと、輪郭の外に出た設備を中へ寄せる。1 つも動かなければ同じ参照 */
export function pruneFixtures(size: PlanSize, list: readonly Fixture[]): Fixture[] {
  return pruneInside(size, list);
}

function part(x: number, y: number, z: number, w: number, h: number, d: number, color: string): Part {
  return { offset: [x, y, z] as Vec3, size: [w, h, d] as Vec3, color };
}

/**
 * 3D の箱。収納は側板 2 + 天板 + 地板 + 背板 + 棚板 2〜3（扉は出さない ──
 * 中が見えるほうが検討に使える）。階段は段板を steps 枚。
 */
export function fixtureParts(item: Fixture): Part[] {
  const { w, d, h } = item.size;
  if (item.kind === "stairs") {
    const steps = stepsOf(item);
    const tread = d / steps;
    const rise = h / steps;
    const out: Part[] = [];
    for (let i = 0; i < steps; i++) {
      const y = (i + 1) * rise;
      out.push(
        part(0, y - 0.03, d / 2 - tread * (i + 0.5), w, 0.06, tread, i % 2 === 0 ? TONE.wood : TONE.woodDark),
      );
    }
    return out;
  }
  const t = Math.min(0.03, d / 4);
  const inner = Math.max(w - t * 2, 0.05);
  const out: Part[] = [
    part(-(w - t) / 2, h / 2, 0, t, h, d, TONE.white),
    part((w - t) / 2, h / 2, 0, t, h, d, TONE.white),
    part(0, h - t / 2, 0, w, t, d, TONE.white),
    part(0, t / 2, 0, w, t, d, TONE.white),
    part(0, h / 2, -(d - t) / 2, w, h, t, TONE.white),
  ];
  const shelves = item.kind === "genkan" ? 3 : 2;
  for (let i = 1; i <= shelves; i++) {
    out.push(part(0, (h * i) / (shelves + 1), 0, inner, 0.02, Math.max(d - t, 0.05), TONE.wood));
  }
  return out;
}

function rect(x: number, z: number, w: number, d: number): GlyphRect {
  return { x, z, w, d };
}

function line(x1: number, z1: number, x2: number, z2: number): GlyphLine {
  return { x1, z1, x2, z2 };
}

/**
 * 平面図の記号。外形の矩形 + 内側に棚板の線。扉の記号（折れ戸・引き戸・開き戸）は
 * ui/glyphs.ts が door の欄を見て足す。階段は段板の線と上り方向の三角。
 */
export function fixtureGlyph(item: Fixture): Glyph {
  const { w, d } = item.size;
  if (item.kind === "stairs") {
    const steps = stepsOf(item);
    const tread = d / steps;
    const lines: GlyphLine[] = [];
    for (let i = 1; i < steps; i++) {
      const z = d / 2 - tread * i;
      lines.push(line(-w / 2, z, w / 2, z));
    }
    return { rects: [rect(0, 0, w, d)], lines };
  }
  const t = Math.min(0.03, d / 4);
  return {
    rects: [rect(0, 0, w, d)],
    lines: [line(-w / 2 + t, -d / 2 + t, w / 2 - t, -d / 2 + t)],
  };
}
