/**
 * 売り物: 家の外皮と中身を「どこに、どの大きさの箱を置くか」に直す。
 * 3D の部品（Scene.tsx）はこれを並べるだけ。three も React もここには出てこない。
 * 壁の開口（建具のぶんを抜いた箱の一覧）は wallPieces が受け持つ。
 */
import { buildParts } from "./catalog";
import { exteriorParts } from "./exterior";
import { fixtureParts } from "./fixtures";
import { partsInScene, type ScenePart } from "./furniture";
import {
  labelAnchor,
  roomArea,
  roomRects,
  toScene,
  wallSegments,
  type Divider,
  type GridLayout,
  type RoomRect,
} from "./grid";
import {
  baseOf,
  ceilingOf,
  FLOOR_TONE,
  houseOf,
  SELECTED_FLOOR_TONE,
  topOf,
  type Floor,
  type PlanSize,
  type Vec3,
} from "./house";
import { openingsOnRun, type Opening } from "./openings";
import { type PlanDoc } from "./plan";

export type Panel = {
  id: string;
  position: Vec3;
  /** 幅(x)・高さ(y)・奥行き(z) */
  size: Vec3;
};

/** 内壁の厚み */
export const INTERIOR_WALL = 0.12;

/**
 * 壁の 1 本の走り。内壁の 1 区間か、外壁の 1 面。
 * axis "x" なら x = at に立つ南北の壁で、from/to は z の範囲。
 */
export type WallRun = {
  id: string;
  axis: "x" | "z";
  at: number;
  from: number;
  to: number;
  thickness: number;
};

/** その階の床スラブ。上面がちょうどその階の床の高さに来る */
export function slabPanel(size: PlanSize, floor: Floor): Panel {
  const h = houseOf(size);
  const base = baseOf(size, floor);
  const t = h.slabThickness;
  return {
    id: `f${floor}-slab`,
    position: [0, base - t / 2, 0],
    size: [size.width, t, size.depth],
  };
}

/** 部屋ごとの床。同じ部屋の矩形どうしが継ぎ目なく並ぶよう、隙間は空けない */
export function roomSlab(size: PlanSize, room: RoomRect, floor: Floor): Panel {
  const t = 0.06;
  const base = baseOf(size, floor);
  const [sx, sz] = toScene(size, room.x + room.w / 2, room.z + room.d / 2);
  return {
    id: `f${floor}-${room.id}-floor`,
    position: [sx, base + t / 2, sz],
    size: [room.w, t, room.d],
  };
}

/**
 * その階の外壁 4 面の走り。東西の走りは、南北の走りと角で面が重ならないよう
 * 両端を厚みぶん詰める（重なると同じ平面が 2 枚できて、ちらつく）。
 */
export function exteriorRuns(size: PlanSize, floor: Floor): WallRun[] {
  const t = houseOf(size).wallThickness;
  return [
    { id: `f${floor}-ext-n`, axis: "z", at: 0, from: 0, to: size.width, thickness: t },
    { id: `f${floor}-ext-s`, axis: "z", at: size.depth, from: 0, to: size.width, thickness: t },
    { id: `f${floor}-ext-w`, axis: "x", at: 0, from: t, to: size.depth - t, thickness: t },
    { id: `f${floor}-ext-e`, axis: "x", at: size.width, from: t, to: size.depth - t, thickness: t },
  ];
}

/** 部屋の境目の壁（grid.ts の wallSegments）を、厚み 0.12 m の走りにする */
export function interiorRuns(lines: readonly Divider[], floor: Floor): WallRun[] {
  return lines.map((line) => ({
    id: `f${floor}-${line.id}`,
    axis: line.axis,
    at: line.at,
    from: line.from,
    to: line.to,
    thickness: INTERIOR_WALL,
  }));
}

/** 使う側は rotationY を内側の mesh に、scaleZ を外側の group に掛けること（回転 → z 方向拡大の順） */
export type Roof = {
  /** 四角錐の外接円の半径（coneGeometry の radius） */
  radius: number;
  height: number;
  /** 底面を長方形にするための奥行き方向の縮み */
  scaleZ: number;
  position: Vec3;
  /** 稜線を間口・奥行きの向きに合わせるための回転（ラジアン） */
  rotationY: number;
};

/**
 * 屋根は四角錐（方形屋根）。角を 4 つにした円錐を 45 度回すと四角い屋根になる。
 * 板 2 枚の切妻と違って妻側に穴が開かないので、手数が少なく破綻もしない。
 */
export function roofShape(size: PlanSize): Roof {
  const h = houseOf(size);
  const top = topOf(size);
  const width = size.width + h.eaves * 2;
  const depth = size.depth + h.eaves * 2;
  return {
    radius: (width / 2) * Math.SQRT2,
    height: h.roofRise,
    scaleZ: depth / width,
    position: [0, top + h.roofRise / 2, 0],
    rotationY: Math.PI / 4,
  };
}

export type Annotation = {
  id: string;
  label: string;
  /** 広さ（m²） */
  area: number;
  /** 吹き出しを置く位置。部屋の天井の少し下 */
  position: Vec3;
};

/**
 * 注記は部屋ごとに 1 つ。位置は labelAnchor で、L 字の部屋でも名前が部屋の中に出る。
 * まだ 1 マスも塗られていない部屋には出さない（置く場所が無いため）。
 */
export function annotationPositions(
  size: PlanSize,
  layout: GridLayout,
  floor: Floor,
): Annotation[] {
  const base = baseOf(size, floor);
  const height = ceilingOf(size, floor);
  const out: Annotation[] = [];
  for (const room of layout.rooms) {
    const area = roomArea(layout, room.id);
    if (area === 0) continue;
    const [ax, az] = labelAnchor(size, layout, room.id);
    const [sx, sz] = toScene(size, ax, az);
    out.push({
      id: `f${floor}-${room.id}`,
      label: room.label,
      area,
      position: [sx, base + height - 0.35, sz] as Vec3,
    });
  }
  return out;
}

/** 枠の見付（m） */
export const FRAME_WIDTH = 0.06;

/** 走りの向きに応じて、線からの寄せ量を返す。外壁は外側の面が線に乗るよう半分だけ内へ */
function runShift(size: PlanSize, run: WallRun): number {
  const across = run.axis === "x" ? size.width : size.depth;
  if (run.at <= 1e-9) return run.thickness / 2;
  if (Math.abs(run.at - across) < 1e-9) return -run.thickness / 2;
  return 0;
}

/** 走りの [from, to] × [y0, y1] を、壁の厚みの箱にする（overlayBox に委ねる） */
function wallBox(
  size: PlanSize,
  run: WallRun,
  from: number,
  to: number,
  y0: number,
  y1: number,
  id: string,
): Panel {
  return overlayBox(size, run, from, to, y0, y1, run.thickness, id);
}

/**
 * 壁の走りから、開口を抜いた箱の一覧を作る。CSG も Shape の holes も使わない。
 * 建具ごとに「前の建具の終わり〜この建具の始まり（全高）」「腰壁」「垂れ壁」に切り、
 * 最後に「最後の建具の終わり〜走りの終わり（全高）」を足す。幅 0 の箱は出さない。
 * ceiling に断面の高さ（1.1 m）を渡せば、腰より上の建具は壁を割らない。
 */
export function wallPieces(
  size: PlanSize,
  run: WallRun,
  openings: readonly Opening[],
  base: number,
  ceiling: number,
): Panel[] {
  const top = base + ceiling;
  const visible = openingsOnRun(openings, run.axis, run.at, run.from, run.to).filter(
    (o) => o.sill < ceiling - 1e-9,
  );
  const out: Panel[] = [];
  let cursor = run.from;
  let solids = 0;
  visible.forEach((o, index) => {
    const start = Math.max(o.start, run.from);
    const end = Math.min(o.start + o.width, run.to);
    if (end - start < 1e-9) return;
    if (start - cursor > 1e-9) {
      out.push(wallBox(size, run, cursor, start, base, top, `${run.id}-p${solids++}`));
    }
    if (o.sill > 1e-9) {
      const sillTop = base + Math.min(o.sill, ceiling);
      out.push(wallBox(size, run, start, end, base, sillTop, `${run.id}-s${index}`));
    }
    const head = o.sill + o.height;
    if (ceiling - head > 1e-9) {
      out.push(wallBox(size, run, start, end, base + head, top, `${run.id}-h${index}`));
    }
    cursor = Math.max(cursor, end);
  });
  if (run.to - cursor > 1e-9) {
    out.push(wallBox(size, run, cursor, run.to, base, top, `${run.id}-p${solids++}`));
  }
  return out;
}

/** 走りの [from, to] × [y0, y1] を、厚み thickness の箱にする（枠とガラス用） */
function overlayBox(
  size: PlanSize,
  run: WallRun,
  from: number,
  to: number,
  y0: number,
  y1: number,
  thickness: number,
  id: string,
): Panel {
  const middle = (from + to) / 2;
  const shift = runShift(size, run);
  if (run.axis === "x") {
    const [sx, sz] = toScene(size, run.at + shift, middle);
    return { id, position: [sx, (y0 + y1) / 2, sz], size: [thickness, y1 - y0, to - from] };
  }
  const [sx, sz] = toScene(size, middle, run.at + shift);
  return { id, position: [sx, (y0 + y1) / 2, sz], size: [to - from, y1 - y0, thickness] };
}

/**
 * 開口の四周の枠。開口の中に収める（壁の箱と重ならない）。
 * 縦 2 本 + 上 1 本、下端が床から浮いていれば下 1 本。扉の板は 3D には出さない ──
 * 開き勝手は 2D の弧で分かるので、半開きの板は視界を塞ぐだけ。
 */
export function openingFrames(size: PlanSize, run: WallRun, o: Opening, base: number): Panel[] {
  const t = run.thickness + 0.02;
  const from = o.start;
  const to = o.start + o.width;
  const low = base + o.sill;
  const high = base + o.sill + o.height;
  const w = Math.min(FRAME_WIDTH, o.width / 3);
  const out: Panel[] = [
    overlayBox(size, run, from, from + w, low, high, t, `${o.id}-frame-a`),
    overlayBox(size, run, to - w, to, low, high, t, `${o.id}-frame-b`),
    overlayBox(size, run, from, to, high - w, high, t, `${o.id}-frame-top`),
  ];
  if (o.sill > 1e-9) {
    out.push(overlayBox(size, run, from, to, low, low + w, t, `${o.id}-frame-sill`));
  }
  return out;
}

/** 窓のガラス。開口とちょうど同じ大きさで、壁より 4 cm 厚い（外からも中からも面が見える） */
export function openingGlass(
  size: PlanSize,
  run: WallRun,
  o: Opening,
  base: number,
): Panel | null {
  if (o.kind !== "window") return null;
  return overlayBox(
    size,
    run,
    o.start,
    o.start + o.width,
    base + o.sill,
    base + o.sill + o.height,
    run.thickness + 0.04,
    `${o.id}-glass`,
  );
}

/** 断面のときに床へ置く、開口の位置を示す線。上から見てドアの位置が分かる */
export function openingFloorMark(
  size: PlanSize,
  run: WallRun,
  o: Opening,
  base: number,
): Panel {
  return overlayBox(size, run, o.start, o.start + o.width, base, base + 0.02, 0.04, `${o.id}-mark`);
}

/** 3D に並べる箱を、階ごとにまとめたもの。Scene.tsx はこれを並べるだけ */
export type FloorBoxes = {
  slab: Panel;
  rooms: { panel: Panel; roomId: string }[];
  walls: Panel[];
  interiorWalls: Panel[];
  frames: Panel[];
  glass: Panel[];
  marks: Panel[];
  fixtures: ScenePart[];
  exterior: ScenePart[];
  furniture: { part: ScenePart; itemId: string }[];
};

/** 箱の数の上限。超えたら家具か建具が多すぎるので、呼ぶ側が警告を出す */
export const BOX_BUDGET = 800;

export function countBoxes(boxes: FloorBoxes): number {
  return (
    1 +
    boxes.rooms.length +
    boxes.walls.length +
    boxes.interiorWalls.length +
    boxes.frames.length +
    boxes.glass.length +
    boxes.marks.length +
    boxes.fixtures.length +
    boxes.exterior.length +
    boxes.furniture.length
  );
}

export function floorBoxes(doc: PlanDoc, floor: Floor, cutaway: boolean): FloorBoxes {
  const size = doc.size;
  const plan = doc.floors[floor];
  const base = baseOf(size, floor);
  const full = ceilingOf(size, floor);
  const ceiling = cutaway ? Math.min(full, houseOf(size).cutawayWallHeight) : full;
  const outer = exteriorRuns(size, floor);
  const inner = interiorRuns(wallSegments(size, plan.layout), floor);
  const walls: Panel[] = [];
  const interiorWalls: Panel[] = [];
  const frames: Panel[] = [];
  const glass: Panel[] = [];
  const marks: Panel[] = [];
  for (const run of [...outer, ...inner]) {
    const pieces = wallPieces(size, run, plan.openings, base, ceiling);
    if (run.thickness === INTERIOR_WALL) interiorWalls.push(...pieces);
    else walls.push(...pieces);
    for (const o of openingsOnRun(plan.openings, run.axis, run.at, run.from, run.to)) {
      if (cutaway) {
        marks.push(openingFloorMark(size, run, o, base));
        continue;
      }
      frames.push(...openingFrames(size, run, o, base));
      const pane = openingGlass(size, run, o, base);
      if (pane) glass.push(pane);
    }
  }
  return {
    slab: slabPanel(size, floor),
    rooms: roomRects(size, plan.layout).map((room) => ({
      panel: roomSlab(size, room, floor),
      roomId: room.roomId,
    })),
    walls,
    interiorWalls,
    frames,
    glass,
    marks,
    fixtures: plan.fixtures.flatMap((item) =>
      partsInScene(size, item, fixtureParts(item), base),
    ),
    exterior: plan.exterior.flatMap((part) => exteriorParts(size, part, floor)),
    furniture: plan.furniture.flatMap((item) =>
      partsInScene(size, item, buildParts(item), base).map((part) => ({ part, itemId: item.id })),
    ),
  };
}

/** 部屋の床の色。選択中の部屋だけ少し明るくする */
export function roomToneOf(floor: Floor, selected: boolean, override?: string): string {
  if (selected) return SELECTED_FLOOR_TONE;
  return override ?? FLOOR_TONE[floor];
}
