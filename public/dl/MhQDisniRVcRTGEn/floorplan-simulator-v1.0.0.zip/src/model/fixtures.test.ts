import { describe, expect, it } from "vitest";
import { DEFAULT_SIZE, type PlanSize } from "./house";
import {
  addFixture,
  clampSteps,
  FIXTURE_LIMITS,
  FIXTURE_PRESETS,
  fixtureGlyph,
  fixtureName,
  fixtureParts,
  fixtureSeed,
  moveFixture,
  pruneFixtures,
  removeFixture,
  resizeFixture,
  rotateFixture,
  STAIRS_MAX_STEPS,
  STAIRS_MIN_STEPS,
  STAIRS_STEPS,
  type Fixture,
} from "./fixtures";

const SIZE = DEFAULT_SIZE;
const HEX = /^#[0-9a-f]{6}$/;

describe("設備の表", () => {
  it("4 種あり、寸法と扉は決めたとおり", () => {
    expect(Object.keys(FIXTURE_PRESETS)).toEqual(["closet", "oshiire", "genkan", "stairs"]);
    expect(FIXTURE_PRESETS.closet).toMatchObject({
      size: { w: 1.65, d: 0.75, h: 2.3 },
      door: "folding",
      steps: null,
    });
    expect(FIXTURE_PRESETS.oshiire).toMatchObject({ size: { w: 1.75, d: 0.85, h: 2.3 }, door: "sliding" });
    expect(FIXTURE_PRESETS.genkan).toMatchObject({ size: { w: 0.9, d: 0.4, h: 2 }, door: "hinged" });
    expect(FIXTURE_PRESETS.stairs).toMatchObject({
      size: { w: 0.95, d: 2.6, h: 2.7 },
      door: "none",
      steps: 13,
    });
    expect(fixtureName("closet")).toBe("クローゼット");
  });

  it("既定の寸法はすべて範囲の中", () => {
    for (const kind of ["closet", "oshiire", "genkan", "stairs"] as const) {
      const { size } = FIXTURE_PRESETS[kind];
      const limits = FIXTURE_LIMITS[kind];
      expect(size.w).toBeGreaterThanOrEqual(limits.w[0]);
      expect(size.w).toBeLessThanOrEqual(limits.w[1]);
      expect(size.d).toBeGreaterThanOrEqual(limits.d[0]);
      expect(size.d).toBeLessThanOrEqual(limits.d[1]);
      expect(size.h).toBeGreaterThanOrEqual(limits.h[0]);
      expect(size.h).toBeLessThanOrEqual(limits.h[1]);
    }
  });
});

describe("置く・動かす・回す・消す", () => {
  it("addFixture は 0.25 に丸め、輪郭に収め、id を連番で付ける", () => {
    const list = addFixture(SIZE, [], "closet", [1.13, 0.1]);
    expect(list[0].id).toBe("x-1");
    expect(list[0].kind).toBe("closet");
    expect(list[0].x).toBe(1.25);
    // 下限は d/2 = 0.375 を 0.25 刻みへ切り上げた 0.50（外へはみ出さない、いちばん壁寄りの位置）
    expect(list[0].z).toBe(0.5);
    expect(addFixture(SIZE, list, "stairs", [4, 4])[1].id).toBe("x-2");
  });

  it("moveFixture / rotateFixture / removeFixture", () => {
    const list = addFixture(SIZE, [], "closet", [4, 4]);
    // 上限は 9 − ceil(1.65/2 / 0.25) × 0.25 = 9 − 1.00 = 8.00
    expect(moveFixture(SIZE, list, "x-1", 99, 99)[0].x).toBe(8);
    let turned = list;
    for (let i = 0; i < 4; i++) turned = rotateFixture(SIZE, turned, "x-1");
    expect(turned[0].rotation).toBe(0);
    expect(rotateFixture(SIZE, list, "x-1")[0].rotation).toBe(90);
    expect(removeFixture(list, "x-1")).toEqual([]);
  });

  it("壁ぎわの階段を回すと、向きに合わせて中へ寄る", () => {
    // 階段 0.95 × 2.6 を北東の角へ寄せる。x は 9 − 0.5 = 8.50、z は 1.50（2.6/2 = 1.3 の切り上げ）
    const list = moveFixture(SIZE, addFixture(SIZE, [], "stairs", [4, 4]), "x-1", 99, 0);
    expect(list[0]).toMatchObject({ x: 8.5, z: 1.5 });
    // 90 度では 2.6 が東西を向くので、x は 1.50〜7.50 に収まる（z は 1.50 のまま）
    const turned = rotateFixture(SIZE, list, "x-1");
    expect(turned[0]).toMatchObject({ x: 7.5, z: 1.5, rotation: 90 });
    for (const item of [list[0], turned[0]]) {
      const [w, d] = item.rotation === 90 || item.rotation === 270
        ? [item.size.d, item.size.w]
        : [item.size.w, item.size.d];
      expect(item.x - w / 2).toBeGreaterThanOrEqual(0);
      expect(item.x + w / 2).toBeLessThanOrEqual(SIZE.width);
      expect(item.z - d / 2).toBeGreaterThanOrEqual(0);
      expect(item.z + d / 2).toBeLessThanOrEqual(SIZE.depth);
    }
  });

  it("resizeFixture は刻みと範囲に収め、preset を外す", () => {
    const list = addFixture(SIZE, [], "closet", [4, 4]);
    const next = resizeFixture(SIZE, list, "x-1", { w: 2.03 });
    expect(next[0].size.w).toBe(2);
    expect(next[0].preset).toBeNull();
    expect(resizeFixture(SIZE, list, "x-1", { h: 99 })[0].size.h).toBe(FIXTURE_LIMITS.closet.h[1]);
    // 階段の段数も変えられる
    const stairs = addFixture(SIZE, [], "stairs", [4, 4]);
    expect(resizeFixture(SIZE, stairs, "x-1", { steps: 15 })[0].steps).toBe(15);
    expect(resizeFixture(SIZE, stairs, "x-1", { steps: 99 })[0].steps).toBe(20);
  });

  it("段数は 8〜20 の整数に収める", () => {
    expect(clampSteps(null)).toBeNull();
    expect(clampSteps(200000)).toBe(STAIRS_MAX_STEPS);
    expect(clampSteps(0)).toBe(STAIRS_MIN_STEPS);
    expect(clampSteps(-5)).toBe(STAIRS_MIN_STEPS);
    expect(clampSteps(13.6)).toBe(14);
    expect(clampSteps(Number.NaN)).toBe(STAIRS_STEPS);
    // 壊れた段数のまま持っていても、段板の数は 8〜20 枚で止まる
    const broken: Fixture = { ...fixtureSeed("stairs"), id: "x-1", x: 4, z: 4, rotation: 0, steps: 200000 };
    expect(fixtureParts(broken)).toHaveLength(STAIRS_MAX_STEPS);
    expect(fixtureGlyph(broken).lines).toHaveLength(STAIRS_MAX_STEPS - 1);
    const none: Fixture = { ...broken, steps: 0 };
    expect(fixtureParts(none)).toHaveLength(STAIRS_MIN_STEPS);
    // 段数を直したあとも、段板は size の中に収まる
    for (const part of fixtureParts(none)) {
      expect(part.offset[1] + part.size[1] / 2).toBeLessThanOrEqual(none.size.h + 1e-9);
    }
  });

  it("pruneFixtures は外皮からはみ出した設備を中へ寄せる", () => {
    const list = addFixture(SIZE, [], "oshiire", [8, 7]);
    const small: PlanSize = { width: 5, depth: 5, floors: 1 };
    const pruned = pruneFixtures(small, list);
    // 端は 5 − ceil(1.75/2 / 0.25) × 0.25 = 4.00、5 − ceil(0.85/2 / 0.25) × 0.25 = 4.50
    expect(pruned[0].x).toBe(4);
    expect(pruned[0].z).toBe(4.5);
    // 1 つも動かないときは同じ参照のまま返す
    expect(pruneFixtures(SIZE, list)).toBe(list);
  });
});

describe("3D と 2D", () => {
  it("収納は側板・天板・背板・棚板の箱になり、size に収まる", () => {
    const item: Fixture = { ...fixtureSeed("closet"), id: "x-1", x: 4, z: 4, rotation: 0 };
    const parts = fixtureParts(item);
    expect(parts.length).toBeGreaterThanOrEqual(5);
    for (const part of parts) {
      expect(part.color).toMatch(HEX);
      expect(Math.abs(part.offset[0]) + part.size[0] / 2).toBeLessThanOrEqual(item.size.w / 2 + 1e-9);
      expect(part.offset[1] + part.size[1] / 2).toBeLessThanOrEqual(item.size.h + 1e-9);
    }
  });

  it("階段は段板が steps 枚で、最上段が天井の高さに届く", () => {
    const item: Fixture = { ...fixtureSeed("stairs"), id: "x-1", x: 4, z: 4, rotation: 0 };
    const parts = fixtureParts(item);
    expect(parts).toHaveLength(13);
    const top = parts[parts.length - 1];
    expect(top.offset[1] + top.size[1] / 2).toBeCloseTo(item.size.h, 6);
  });

  it("玄関収納だけ棚板が 3 枚（ほかの収納は 2 枚）", () => {
    const shelvesOf = (kind: "closet" | "oshiire" | "genkan") => {
      const item: Fixture = { ...fixtureSeed(kind), id: "x-1", x: 4, z: 4, rotation: 0 };
      // 側板 2 + 天板 + 地板 + 背板 のあとに棚板が続く
      return fixtureParts(item).slice(5);
    };
    expect(shelvesOf("genkan")).toHaveLength(3);
    expect(shelvesOf("closet")).toHaveLength(2);
    expect(shelvesOf("oshiire")).toHaveLength(2);
    // 棚板は高さ 2 m を 4 等分した 0.5 / 1.0 / 1.5 m に入る
    expect(shelvesOf("genkan").map((part) => part.offset[1])).toEqual([0.5, 1, 1.5]);
  });

  it("記号は size に収まる", () => {
    for (const kind of ["closet", "oshiire", "genkan", "stairs"] as const) {
      const item: Fixture = { ...fixtureSeed(kind), id: "x-1", x: 4, z: 4, rotation: 0 };
      const glyph = fixtureGlyph(item);
      expect(glyph.rects.length).toBeGreaterThan(0);
      for (const rect of glyph.rects) {
        expect(Math.abs(rect.x) + rect.w / 2).toBeLessThanOrEqual(item.size.w / 2 + 1e-9);
        expect(Math.abs(rect.z) + rect.d / 2).toBeLessThanOrEqual(item.size.d / 2 + 1e-9);
      }
    }
  });
});
