import { describe, expect, it } from "vitest";
import { CELL, DEFAULT_SIZE, cellCountOf, colsOf, rowsOf, SNAP, type PlanSize } from "./house";
import {
  addRoom,
  cellAt,
  cellFromPoint,
  cellsAlong,
  colRowOf,
  defaultLayout,
  isRectangularRoom,
  labelAnchor,
  nextRoomId,
  PAINT_STEP,
  paintCell,
  paintCells,
  prune,
  renameRoom,
  resizeLayout,
  ROOM_LABELS,
  roomArea,
  roomBounds,
  roomOfCell,
  roomRects,
  snap,
  snapHeight,
  toScene,
  wallSegments,
  type GridLayout,
} from "./grid";

const SIZE = DEFAULT_SIZE;
const COLS = colsOf(SIZE);
const ROWS = rowsOf(SIZE);

/** 長方形（マス単位）の中のマス番号を並べる */
function cellsOf(col0: number, row0: number, cols: number, rows: number): number[] {
  const out: number[] = [];
  for (let row = row0; row < row0 + rows; row++) {
    for (let col = col0; col < col0 + cols; col++) out.push(cellAt(SIZE, col, row));
  }
  return out;
}

/** L 字の間取り。room-1 は西の 4 列と南の 4 行、room-2 が残り */
function lShaped(): GridLayout {
  const cells: string[] = [];
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      cells.push(col < 4 || row >= ROWS - 4 ? "room-1" : "room-2");
    }
  }
  return {
    rooms: [
      { id: "room-1", label: "LDK" },
      { id: "room-2", label: "和室" },
    ],
    cells,
  };
}

describe("マス目", () => {
  it("部屋名は 19 種、重複なし", () => {
    expect(ROOM_LABELS).toHaveLength(19);
    expect(new Set(ROOM_LABELS).size).toBe(19);
    expect(ROOM_LABELS).toContain("ウォークインクローゼット");
    expect(ROOM_LABELS).toContain("洗面・脱衣");
  });

  it("番号と (col, row) は行き来できる", () => {
    expect(cellAt(SIZE, 0, 0)).toBe(0);
    expect(cellAt(SIZE, 17, 15)).toBe(287);
    expect(colRowOf(SIZE, 0)).toEqual([0, 0]);
    expect(colRowOf(SIZE, 287)).toEqual([17, 15]);
    const big: PlanSize = { width: 16, depth: 4, floors: 1 };
    expect(cellAt(big, 31, 7)).toBe(7 * 32 + 31);
    expect(colRowOf(big, 7 * 32 + 31)).toEqual([31, 7]);
  });

  it("床座標からマスを引く。輪郭の外は null", () => {
    expect(cellFromPoint(SIZE, 0, 0)).toBe(0);
    expect(cellFromPoint(SIZE, 8.9, 7.9)).toBe(287);
    expect(cellFromPoint(SIZE, 9, 4)).toBeNull();
    expect(cellFromPoint(SIZE, 4, 8)).toBeNull();
    expect(cellFromPoint(SIZE, -0.1, 4)).toBeNull();
    // 数でない座標も外扱い（NaN の比較はすべて false になるので、明示して落とす）
    expect(cellFromPoint(SIZE, Number.NaN, 4)).toBeNull();
    expect(cellFromPoint(SIZE, 4, Number.NaN)).toBeNull();
    expect(cellFromPoint(SIZE, Number.POSITIVE_INFINITY, 4)).toBeNull();
  });

  it("snap と snapHeight と toScene", () => {
    expect(snap(1.3)).toBe(1.25);
    expect(snap(-0.1)).toBe(-0);
    expect(snap(Number.NaN)).toBe(0);
    expect(snap(Number.POSITIVE_INFINITY)).toBe(0);
    expect(snapHeight(2.03)).toBe(2.05);
    expect(toScene(SIZE, 0, 0)).toEqual([-4.5, -4]);
    expect(toScene(SIZE, 9, 8)).toEqual([4.5, 4]);
    expect(toScene({ width: 12, depth: 12, floors: 1 }, 6, 6)).toEqual([0, 0]);
  });

  it("PAINT_STEP はマスより十分細かい", () => {
    expect(PAINT_STEP).toBe(0.125);
    expect(PAINT_STEP).toBeLessThanOrEqual(CELL / 4);
    expect(SNAP).toBe(0.25);
  });
});

describe("既定の間取り", () => {
  it("既定の外皮の 1F は 5 部屋、288 マスすべてが埋まり、面積の合計は 72 m²", () => {
    const layout = defaultLayout(SIZE, 1);
    expect(layout.rooms).toHaveLength(5);
    expect(layout.cells).toHaveLength(288);
    expect(layout.cells.every((id) => layout.rooms.some((room) => room.id === id))).toBe(true);
    const total = layout.rooms.reduce((sum, room) => sum + roomArea(layout, room.id), 0);
    expect(total).toBe(72);
  });

  it("既定の外皮の 1F は見本と同じ寸法（LDK 5.5 × 6）", () => {
    const layout = defaultLayout(SIZE, 1);
    const ldk = layout.rooms[0];
    expect(ldk.label).toBe("LDK");
    expect(roomArea(layout, ldk.id)).toBe(33);
    expect(roomBounds(SIZE, layout, ldk.id)).toEqual({ x: 0, z: 0, w: 5.5, d: 6 });
  });

  it("2F は 4 部屋、面積の合計は 72 m²", () => {
    const layout = defaultLayout(SIZE, 2);
    expect(layout.rooms).toHaveLength(4);
    const total = layout.rooms.reduce((sum, room) => sum + roomArea(layout, room.id), 0);
    expect(total).toBe(72);
  });

  it("外皮を変えても部屋数は同じで、面積の合計は外皮ぶん", () => {
    const small: PlanSize = { width: 6, depth: 5, floors: 1 };
    const layout = defaultLayout(small, 1);
    expect(layout.rooms).toHaveLength(5);
    expect(layout.cells).toHaveLength(cellCountOf(small));
    const total = layout.rooms.reduce((sum, room) => sum + roomArea(layout, room.id), 0);
    expect(total).toBe(30);
  });

  it("部屋名は一覧の中から選ばれている", () => {
    for (const floor of [1, 2] as const) {
      for (const room of defaultLayout(SIZE, floor).rooms) {
        expect(ROOM_LABELS).toContain(room.label);
      }
    }
  });
});

describe("roomRects", () => {
  it("既定の 1F は部屋ごとに 1 枚の長方形になる", () => {
    const layout = defaultLayout(SIZE, 1);
    expect(roomRects(SIZE, layout)).toHaveLength(5);
  });

  it("矩形は床座標（m）で、北西から行ごとに並ぶ", () => {
    const layout = defaultLayout(SIZE, 1);
    const rects = roomRects(SIZE, layout).map(({ label, x, z, w, d }) => ({ label, x, z, w, d }));
    expect(rects).toEqual([
      { label: "LDK", x: 0, z: 0, w: 5.5, d: 6 },
      { label: "玄関ホール", x: 5.5, z: 0, w: 3.5, d: 3.5 },
      { label: "浴室・洗面", x: 5.5, z: 3.5, w: 3.5, d: 2.5 },
      { label: "和室", x: 0, z: 6, w: 5.5, d: 2 },
      { label: "廊下・階段", x: 5.5, z: 6, w: 3.5, d: 2 },
    ]);
  });

  it("重ならず、隙間なく、同じ部屋のマスだけを覆う", () => {
    const layout = lShaped();
    const covered = new Set<number>();
    for (const rect of roomRects(SIZE, layout)) {
      for (let row = Math.round(rect.z / CELL); row < Math.round((rect.z + rect.d) / CELL); row++) {
        for (let col = Math.round(rect.x / CELL); col < Math.round((rect.x + rect.w) / CELL); col++) {
          const index = cellAt(SIZE, col, row);
          expect(covered.has(index)).toBe(false);
          expect(layout.cells[index]).toBe(rect.roomId);
          covered.add(index);
        }
      }
    }
    expect(covered.size).toBe(288);
  });

  it("矩形の面積の合計は部屋の広さと合う", () => {
    const layout = lShaped();
    for (const room of layout.rooms) {
      const sum = roomRects(SIZE, layout)
        .filter((rect) => rect.roomId === room.id)
        .reduce((total, rect) => total + rect.w * rect.d, 0);
      expect(sum).toBeCloseTo(roomArea(layout, room.id), 9);
    }
  });
});

describe("wallSegments", () => {
  it("既定の 1F は 3 本。同じ線の上で続く区間は 1 本にまとまる", () => {
    expect(wallSegments(SIZE, defaultLayout(SIZE, 1))).toHaveLength(3);
  });

  it("境目の位置（at）と区間（from・to）は床座標（m）", () => {
    const walls = wallSegments(SIZE, defaultLayout(SIZE, 1));
    expect(walls.map(({ axis, at, from, to }) => ({ axis, at, from, to }))).toEqual([
      // 南北に走る壁。LDK・和室 と 玄関ホール・浴室・廊下 の境目で、北の端から南の端まで
      { axis: "x", at: 5.5, from: 0, to: 8 },
      // 東西に走る壁。玄関ホール と 浴室・洗面 の境目（東の 3.5 m ぶんだけ）
      { axis: "z", at: 3.5, from: 5.5, to: 9 },
      // 東西に走る壁。LDK・浴室 と 和室・廊下 の境目で、西の端から東の端まで
      { axis: "z", at: 6, from: 0, to: 9 },
    ]);
  });

  it("L 字の境目は 2 本になる", () => {
    const walls = wallSegments(SIZE, lShaped());
    expect(walls).toHaveLength(2);
    expect(walls.filter((w) => w.axis === "x")).toHaveLength(1);
    expect(walls.filter((w) => w.axis === "z")).toHaveLength(1);
  });

  it("部屋が 1 つだけなら壁は無い", () => {
    const layout: GridLayout = {
      rooms: [{ id: "room-1", label: "LDK" }],
      cells: Array.from({ length: 288 }, () => "room-1"),
    };
    expect(wallSegments(SIZE, layout)).toHaveLength(0);
  });
});

describe("cellsAlong", () => {
  it("横になぞると、通った列のマスを順に拾う", () => {
    const along = cellsAlong(SIZE, { x: 0.25, z: 0.25 }, { x: 1.75, z: 0.25 });
    expect([...new Set(along)]).toEqual([
      cellAt(SIZE, 0, 0),
      cellAt(SIZE, 1, 0),
      cellAt(SIZE, 2, 0),
      cellAt(SIZE, 3, 0),
    ]);
  });

  it("マスの角を斜めに越えたら、角を挟む両側のマスも足す", () => {
    const along = new Set(cellsAlong(SIZE, { x: 0.4, z: 0.4 }, { x: 0.6, z: 0.6 }));
    expect(along.has(cellAt(SIZE, 1, 0))).toBe(true);
    expect(along.has(cellAt(SIZE, 0, 1))).toBe(true);
  });

  it("輪郭の外から入る線は、中のマスだけを返す", () => {
    const along = cellsAlong(SIZE, { x: -1, z: 0.25 }, { x: 0.75, z: 0.25 });
    // 0 列目と 1 列目（x = 0〜0.75）だけを通る
    expect([...new Set(along)]).toEqual([cellAt(SIZE, 0, 0), cellAt(SIZE, 1, 0)]);
  });

  it("いちど輪郭の外へ出て入り直しても、角の足し込みが飛び火しない", () => {
    // 東の外へ抜けてから北西へ戻る線。外に出た時点で「直前のマス」を忘れるので、
    // 入り直した最初のマスでは斜めの補いを足さない
    const along = cellsAlong(SIZE, { x: 8.75, z: 4.25 }, { x: 9.75, z: 4.25 });
    const back = cellsAlong(SIZE, { x: 9.75, z: 4.25 }, { x: 8.25, z: 3.25 });
    expect([...new Set(along)]).toEqual([cellAt(SIZE, 17, 8)]);
    // 戻ってきた線は通った 2 列 × 2 行ぶんだけ（外を挟んだ向こう側のマスは混ざらない）
    for (const index of back) {
      const [col, row] = colRowOf(SIZE, index);
      expect(col).toBeGreaterThanOrEqual(16);
      expect(row).toBeGreaterThanOrEqual(6);
      expect(row).toBeLessThanOrEqual(8);
    }
    expect(back.length).toBeGreaterThan(0);
  });

  it("両端とも外なら何も返さない", () => {
    expect(cellsAlong(SIZE, { x: -2, z: -2 }, { x: -1, z: -1 })).toEqual([]);
  });
});

describe("塗る", () => {
  it("塗ったマスは新しい部屋のものになり、元の配列は書き換えない", () => {
    const layout = defaultLayout(SIZE, 1);
    const before = layout.cells.slice();
    const target = layout.rooms[1].id;
    const next = paintCell(SIZE, layout, 0, target);
    expect(next.cells[0]).toBe(target);
    expect(layout.cells).toEqual(before);
  });

  it("変わらないときは同じ参照を返す", () => {
    const layout = defaultLayout(SIZE, 1);
    expect(paintCell(SIZE, layout, 0, layout.cells[0])).toBe(layout);
    expect(paintCell(SIZE, layout, 0, "room-999")).toBe(layout);
  });

  it("最後のマスを塗られた部屋は消える", () => {
    const layout = defaultLayout(SIZE, 1);
    const victim = layout.rooms[4].id;
    const survivor = layout.rooms[0].id;
    const indexes = layout.cells
      .map((id, index) => (id === victim ? index : -1))
      .filter((index) => index >= 0);
    const next = paintCells(SIZE, layout, indexes, survivor);
    expect(next.rooms.some((room) => room.id === victim)).toBe(false);
    expect(next.rooms).toHaveLength(4);
  });
});

describe("部屋を足す・名前を変える・消す", () => {
  it("新しい部屋はマスを持たずに足され、塗って形ができる", () => {
    const layout = defaultLayout(SIZE, 1);
    const added = addRoom(layout, "書斎");
    expect(added.id).toBe("room-6");
    expect(roomArea(added.layout, added.id)).toBe(0);
    const painted = paintCells(SIZE, added.layout, cellsOf(0, 0, 2, 2), added.id);
    expect(roomArea(painted, added.id)).toBe(1);
  });

  it("nextRoomId は最大の番号 + 1", () => {
    expect(nextRoomId({ rooms: [{ id: "room-3", label: "LDK" }], cells: [] })).toBe("room-4");
  });

  it("renameRoom は選んだ部屋の名前だけを変える", () => {
    const layout = defaultLayout(SIZE, 1);
    const next = renameRoom(layout, layout.rooms[0].id, "リビング");
    expect(next.rooms[0].label).toBe("リビング");
    expect(next.rooms[1].label).toBe(layout.rooms[1].label);
    expect(renameRoom(layout, "room-999", "リビング")).toBe(layout);
  });

  it("prune はマス 0 の部屋を消すが、部屋が 1 つも無くなるなら消さない", () => {
    const layout: GridLayout = {
      rooms: [
        { id: "room-1", label: "LDK" },
        { id: "room-2", label: "和室" },
      ],
      cells: Array.from({ length: 288 }, () => "room-1"),
    };
    expect(prune(layout).rooms).toHaveLength(1);
    const empty: GridLayout = { rooms: [{ id: "room-1", label: "LDK" }], cells: [] };
    expect(prune(empty)).toBe(empty);
  });
});

describe("labelAnchor と roomBounds", () => {
  it("L 字の部屋でも名前の位置が部屋のマスに乗る", () => {
    const layout = lShaped();
    const [x, z] = labelAnchor(SIZE, layout, "room-1");
    const index = cellFromPoint(SIZE, x, z);
    expect(index).not.toBeNull();
    expect(roomOfCell(layout, index as number)).toBe("room-1");
  });

  it("まだ塗られていない部屋は床の真ん中に出す", () => {
    const layout = defaultLayout(SIZE, 1);
    const added = addRoom(layout, "書斎");
    expect(labelAnchor(SIZE, added.layout, added.id)).toEqual([4.5, 4]);
  });

  it("roomBounds は外接長方形、isRectangularRoom は長方形かどうか", () => {
    const layout = lShaped();
    expect(roomBounds(SIZE, layout, "room-2")).toEqual({ x: 2, z: 0, w: 7, d: 6 });
    // room-2 は西 4 列・南 4 行を room-1 に取られた残り＝欠けの無い矩形なので、
    // 長方形でない例には L 字である room-1 を使う（room-2 だと外接長方形＝実面積で true になってしまう）。
    expect(isRectangularRoom(SIZE, layout, "room-1")).toBe(false);
    const flat = defaultLayout(SIZE, 1);
    expect(isRectangularRoom(SIZE, flat, flat.rooms[0].id)).toBe(true);
    expect(roomBounds(SIZE, layout, "room-999")).toBeNull();
  });
});

describe("resizeLayout", () => {
  it("広げた分は先頭の部屋で埋まり、元のマスはそのまま", () => {
    const from: PlanSize = { width: 9, depth: 8, floors: 2 };
    const to: PlanSize = { width: 10, depth: 9, floors: 2 };
    const layout = defaultLayout(from, 1);
    const next = resizeLayout(from, to, layout);
    expect(next.cells).toHaveLength(cellCountOf(to));
    expect(next.cells[cellAt(to, 0, 0)]).toBe(layout.cells[cellAt(from, 0, 0)]);
    expect(next.cells[cellAt(to, 19, 17)]).toBe(layout.rooms[0].id);
  });

  it("狭めるとはみ出したマスは捨て、マス 0 になった部屋は消える", () => {
    const from: PlanSize = { width: 9, depth: 8, floors: 2 };
    const to: PlanSize = { width: 5, depth: 5, floors: 2 };
    const layout = defaultLayout(from, 1);
    const next = resizeLayout(from, to, layout);
    expect(next.cells).toHaveLength(cellCountOf(to));
    // 東側（玄関ホール・浴室・廊下）は落ちるので、残るのは LDK だけ
    expect(next.rooms.map((room) => room.label)).toEqual(["LDK"]);
  });
});
