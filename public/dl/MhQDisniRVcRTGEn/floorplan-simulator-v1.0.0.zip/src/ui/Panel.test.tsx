/*
 * 「寸法」モードで開く入力欄。選んだものをタップして欄を出し、打ち終わりに 1 回だけ
 * 間取りへ渡るところまでを、画面ごと動かして確かめる。
 * jsdom には SVG の座標変換も指の捕まえ方も無いので、そこだけ差し替える。
 */
import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { SCALE } from "./glyphs";
import { Simulator, type SimulatorApi } from "./Simulator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

function mount(props: Parameters<typeof Simulator>[0] = {}) {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  let handle: SimulatorApi | null = null;
  act(() => {
    root.render(<Simulator {...props} handleRef={(api) => (handle = api)} />);
  });
  return { container, root, get handle() { return handle as unknown as SimulatorApi; } };
}

const click = (el: Element) =>
  act(() => {
    el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  });

const press = (el: Element, key: string) =>
  act(() => {
    el.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));
  });

const buttonNamed = (root: ParentNode, text: string) =>
  [...root.querySelectorAll("button")].find((button) => button.textContent?.trim() === text)!;

/** 欄のラベルの文言で input を引く。同じ文言がほかの group にもあるので範囲を絞って呼ぶ */
const fieldIn = (root: ParentNode, text: string) =>
  [...root.querySelectorAll("label.fp-field")]
    .find((label) => label.textContent?.startsWith(text))!
    .querySelector("input")!;

const selectIn = (root: ParentNode, text: string) =>
  [...root.querySelectorAll("label.fp-field")]
    .find((label) => label.textContent?.startsWith(text))!
    .querySelector("select")!;

/** 制御された input に値を入れる（React の tracker を通さずネイティブの setter を呼ぶ） */
function typeInto(input: HTMLInputElement, value: string) {
  act(() => {
    const setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")!.set!;
    setValue.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

function pick(select: HTMLSelectElement, value: string) {
  act(() => {
    const setValue = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")!.set!;
    setValue.call(select, value);
    select.dispatchEvent(new Event("change", { bubbles: true }));
  });
}

/** 間取り図の (x, z) m を指でつつく。1 m = SCALE で画面に写す取り決めにしてある */
function tapAt(container: HTMLElement, x: number, z: number) {
  const svg = container.querySelector("svg.fp-plan")!;
  const at = { clientX: x * SCALE, clientY: z * SCALE, bubbles: true, pointerId: 1, pointerType: "mouse" };
  act(() => {
    svg.dispatchEvent(new PointerEvent("pointerdown", at));
    svg.dispatchEvent(new PointerEvent("pointerup", at));
  });
}

const form = (container: HTMLElement) => container.querySelector<HTMLFormElement>("form.fp-size-form");

type PatchedSvg = { getScreenCTM?: () => unknown };
type PatchedElement = { hasPointerCapture?: (id: number) => boolean };

beforeEach(() => {
  window.localStorage.clear();
  vi.useFakeTimers();
  // jsdom には getScreenCTM も DOMPoint も無い。1 m = SCALE の素直な写し取りで代える
  (window.SVGSVGElement.prototype as PatchedSvg).getScreenCTM = () => ({ inverse: () => ({}) });
  (window.Element.prototype as PatchedElement).hasPointerCapture = () => false;
  vi.stubGlobal(
    "DOMPoint",
    class {
      x: number;
      y: number;
      constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
      }
      matrixTransform() {
        return { x: this.x, y: this.y };
      }
    },
  );
});

afterEach(() => {
  act(() => {
    vi.runOnlyPendingTimers();
  });
  vi.useRealTimers();
  vi.unstubAllGlobals();
  delete (window.SVGSVGElement.prototype as PatchedSvg).getScreenCTM;
  delete (window.Element.prototype as PatchedElement).hasPointerCapture;
  document.body.replaceChildren();
});

/** 「寸法」モードにして、その階のものをつつく */
function openForm(container: HTMLElement, at: { x: number; z: number }) {
  click(buttonNamed(container, "寸法"));
  tapAt(container, at.x, at.z);
  return form(container)!;
}

describe("家具の寸法", () => {
  const sofaOf = (handle: SimulatorApi) =>
    handle.getActivePlan().floors[1].furniture.find((item) => item.type === "sofa")!;

  it("「寸法」モードで家具をタップすると、その名前の欄が開く", () => {
    const { container, handle } = mount();
    const sofa = sofaOf(handle);
    const opened = openForm(container, sofa);
    expect(opened.getAttribute("aria-label")).toBe("ソファ の寸法");
    expect(fieldIn(opened, "幅").value).toBe("1.90");
    expect(fieldIn(opened, "奥行き").value).toBe("0.85");
    expect(fieldIn(opened, "高さ").value).toBe("0.80");
    expect(fieldIn(opened, "幅").getAttribute("inputmode")).toBe("decimal");
  });

  it("「選ぶ」モードでは欄を出さず、寸法の読み出しだけ出す", () => {
    const { container, handle } = mount();
    tapAt(container, sofaOf(handle).x, sofaOf(handle).z);
    expect(form(container)).toBeNull();
    expect([...container.querySelectorAll(".fp-note")].map((note) => note.textContent)).toContain(
      "1.90 × 0.85 × 0.80 m",
    );
  });

  it("幅を打って Enter すると 0.25 刻みに丸めて入り、標準寸法から外れる", () => {
    const { container, handle } = mount();
    const opened = openForm(container, sofaOf(handle));
    const width = fieldIn(opened, "幅");
    typeInto(width, "1.63");
    // 打っている間は動かさない
    expect(sofaOf(handle).size.w).toBe(1.9);
    press(width, "Enter");
    expect(sofaOf(handle).size.w).toBe(1.75);
    // 奥行きは触っていないので、表の寸法のまま
    expect(sofaOf(handle).size.d).toBe(0.85);
    expect(sofaOf(handle).preset).toBeNull();
  });

  it("範囲の外は端で止める", () => {
    const { container, handle } = mount();
    const opened = openForm(container, sofaOf(handle));
    const width = fieldIn(opened, "幅");
    typeInto(width, "99");
    press(width, "Enter");
    expect(sofaOf(handle).size.w).toBe(3);
  });

  it("標準寸法を選び直すと、表の寸法をそのまま使う", () => {
    const { container, handle } = mount();
    const opened = openForm(container, sofaOf(handle));
    pick(selectIn(opened, "大きさ"), "sofa-2");
    expect(sofaOf(handle).size).toEqual({ w: 1.5, d: 0.85, h: 0.8 });
    expect(sofaOf(handle).preset).toBe("sofa-2");
  });

  it("「—」は選べず、選ばれても寸法を動かさない", () => {
    const { container, handle } = mount();
    const opened = openForm(container, sofaOf(handle));
    // まず表に無い寸法にして、「—」が選ばれている状態にする
    const width = fieldIn(opened, "幅");
    typeInto(width, "1.63");
    press(width, "Enter");
    expect(sofaOf(handle).preset).toBeNull();
    const select = selectIn(form(container)!, "大きさ");
    expect(select.value).toBe("");
    const blank = select.querySelector<HTMLOptionElement>('option[value=""]')!;
    expect(blank.disabled).toBe(true);
    // 万一選ばれても、いちばん上の標準寸法へ勝手に戻さない
    pick(select, "");
    expect(sofaOf(handle).size.w).toBe(1.75);
    expect(sofaOf(handle).preset).toBeNull();
  });

  it("テレビはインチで決め、テレビ台の目安を 1 行出す", () => {
    const { container, handle } = mount();
    const tvOf = () => handle.getActivePlan().floors[1].furniture.find((item) => item.type === "tv")!;
    pick(selectIn(container, "家具"), "tv");
    click(buttonNamed(container, "テレビ"));
    click(buttonNamed(container, "寸法"));
    const opened = form(container)!;
    expect(opened.getAttribute("aria-label")).toBe("テレビ の寸法");
    const inch = fieldIn(opened, "インチ");
    typeInto(inch, "65");
    press(inch, "Enter");
    expect(tvOf().inch).toBe(65);
    // 画面幅 1.44 m + 枠 0.02 m
    expect(tvOf().size.w).toBe(1.46);
    expect(form(container)!.querySelector(".fp-size-hint")?.textContent).toBe(
      "テレビ台は幅 1.70 m 以上が目安です。",
    );
  });
});

describe("設備の寸法", () => {
  it("階段は段数も変えられ、範囲の外は端で止める", () => {
    const { container, handle } = mount();
    const stairsOf = () => handle.getActivePlan().floors[1].fixtures.find((item) => item.kind === "stairs")!;
    const opened = openForm(container, stairsOf());
    expect(opened.getAttribute("aria-label")).toBe("階段 の寸法");
    const steps = fieldIn(opened, "段数");
    expect(steps.value).toBe("13");
    typeInto(steps, "25");
    press(steps, "Enter");
    expect(stairsOf().steps).toBe(20);
  });

  it("幅を打つと刻みに丸めて入る", () => {
    const { container, handle } = mount();
    const stairsOf = () => handle.getActivePlan().floors[1].fixtures.find((item) => item.kind === "stairs")!;
    const opened = openForm(container, stairsOf());
    const width = fieldIn(opened, "幅");
    typeInto(width, "1.3");
    press(width, "Enter");
    expect(stairsOf().size.w).toBe(1.25);
    expect(stairsOf().preset).toBeNull();
  });
});

describe("建具の寸法", () => {
  const openingOf = (handle: SimulatorApi) => handle.getActivePlan().floors[1].openings[0];
  const centerOf = (o: { axis: string; at: number; start: number; width: number }) =>
    o.axis === "x"
      ? { x: o.at, z: o.start + o.width / 2 }
      : { x: o.start + o.width / 2, z: o.at };

  it("幅を打ち込むと 0.25 刻みで入る", () => {
    const { container, handle } = mount();
    const before = openingOf(handle);
    const opened = openForm(container, centerOf(before));
    expect(opened.getAttribute("aria-label")).toBe("ドア の寸法");
    const width = fieldIn(opened, "幅");
    typeInto(width, "1.1");
    press(width, "Enter");
    expect(openingOf(handle).width).toBe(1);
  });

  it("入らない幅は受け取らず、断りを出して欄の値も戻す", () => {
    const { container, handle } = mount();
    // 西の外壁の窓（start 3.25・幅 1.5）の手前にドアを 1 つ置く。
    // そのドアを広げると窓と重なるので、入らない
    click(buttonNamed(container, "ドア"));
    tapAt(container, 0, 1);
    const placed = () => {
      const list = handle.getActivePlan().floors[1].openings;
      return list[list.length - 1];
    };
    const before = placed();
    expect(before.axis).toBe("x");
    click(buttonNamed(container, "寸法"));
    const width = fieldIn(form(container)!, "幅");
    typeInto(width, "9");
    press(width, "Enter");
    expect(placed().width).toBe(before.width);
    expect(container.querySelector(".fp-hint")?.textContent).toBe("そこには入りません。");
    // 欄は打ち込む前の値に戻る
    expect(fieldIn(form(container)!, "幅").value).toBe(before.width.toFixed(2));
  });

  it("ドアは吊元と開く側をトグルで持ち、窓は下端を持つ", () => {
    const { container, handle } = mount();
    const door = handle.getActivePlan().floors[1].openings.find((o) => o.kind === "door")!;
    const opened = openForm(container, centerOf(door));
    const hingeEnd = buttonNamed(opened, "吊元 奥");
    expect(buttonNamed(opened, "吊元 手前").getAttribute("aria-pressed")).toBe("true");
    expect(hingeEnd.getAttribute("aria-pressed")).toBe("false");
    click(hingeEnd);
    const after = handle.getActivePlan().floors[1].openings.find((o) => o.id === door.id)!;
    expect(after.hinge).toBe("end");
    expect(buttonNamed(form(container)!, "吊元 奥").getAttribute("aria-pressed")).toBe("true");
    expect(buttonNamed(form(container)!, "外へ開く")).toBeTruthy();
    // 窓は開き勝手を持たず、下端を持つ
    const window_ = handle.getActivePlan().floors[1].openings.find((o) => o.kind === "window")!;
    tapAt(container, centerOf(window_).x, centerOf(window_).z);
    const opened2 = form(container)!;
    expect(fieldIn(opened2, "下端")).toBeTruthy();
    expect([...opened2.querySelectorAll("button")].map((b) => b.textContent)).not.toContain("外へ開く");
  });

  it("「選ぶ」モードでは 幅 と 高さ（窓は下端も）を読み出す", () => {
    const { container, handle } = mount();
    const window_ = handle.getActivePlan().floors[1].openings.find((o) => o.kind === "window")!;
    tapAt(container, centerOf(window_).x, centerOf(window_).z);
    const note = [...container.querySelectorAll(".fp-note")].map((item) => item.textContent);
    expect(note).toContain(
      `幅 ${window_.width.toFixed(2)} / 高さ ${window_.height.toFixed(2)} / 下端 ${window_.sill.toFixed(2)} m`,
    );
  });
});

describe("外周の寸法", () => {
  /** 外周はバルコニーが 2F に付いている */
  function openBalcony() {
    const mounted = mount();
    click(buttonNamed(mounted.container, "2F"));
    const part = mounted.handle.getActivePlan().floors[2].exterior[0];
    const at = { x: part.start + part.length / 2, z: mounted.handle.getActivePlan().size.depth + 0.5 };
    return { ...mounted, part, opened: openForm(mounted.container, at) };
  }

  it("長さ・奥行きを打ち込め、手すりのトグルが入り切りする", () => {
    const { container, handle, part, opened } = openBalcony();
    expect(opened.getAttribute("aria-label")).toBe("バルコニー の寸法");
    const railing = buttonNamed(opened, "手すり");
    expect(railing.getAttribute("aria-pressed")).toBe("true");
    click(railing);
    const after = () => handle.getActivePlan().floors[2].exterior[0];
    expect(after().railing).toBe(false);
    expect(buttonNamed(form(container)!, "手すり").getAttribute("aria-pressed")).toBe("false");

    const depth = fieldIn(form(container)!, "奥行き");
    typeInto(depth, "2.1");
    press(depth, "Enter");
    expect(after().depth).toBe(2);
    expect(after().length).toBe(part.length);
  });

  it("「選ぶ」モードでは 長さ と 奥行き を読み出す", () => {
    const { container, handle } = openBalcony();
    click(buttonNamed(container, "選ぶ"));
    const part = handle.getActivePlan().floors[2].exterior[0];
    expect([...container.querySelectorAll(".fp-note")].map((item) => item.textContent)).toContain(
      `長さ ${part.length.toFixed(2)} / 奥行き ${part.depth.toFixed(2)} m`,
    );
  });
});

describe("readonly", () => {
  it("見せるだけの埋め込みでは、欄を出さない", () => {
    const { container, handle } = mount({ config: { readonly: true } });
    const sofa = handle.getActivePlan().floors[1].furniture.find((item) => item.type === "sofa")!;
    tapAt(container, sofa.x, sofa.z);
    expect(form(container)).toBeNull();
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "寸法")).toBe(false);
  });
});
