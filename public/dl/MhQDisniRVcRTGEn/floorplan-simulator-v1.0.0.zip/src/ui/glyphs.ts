/**
 * 売り物: 平面図の記号を「SVG の図形の一覧」で返す純粋な関数。
 * ここでは <svg> を作らない ── 形だけを数で決めておけば、DOM なしで試せる。
 * 座標は床座標（m）× SCALE。建具・外周は絶対座標、家具・設備は中心を原点とした相対座標で返す
 * （回転は Editor.tsx の <g transform> が掛ける）。
 */
import { buildGlyph } from "../model/catalog";
import { exteriorName, exteriorRect, type ExteriorPart } from "../model/exterior";
import { fixtureGlyph, type Fixture } from "../model/fixtures";
import { type Glyph, type PlacedFurniture } from "../model/furniture";
import { type Rect } from "../model/grid";
import { type PlanSize } from "../model/house";
import { type Opening } from "../model/openings";

/** 1 m を何単位で描くか */
export const SCALE = 100;

/** 図形の役割。Editor.tsx がこの表を引いて class を付ける */
export type GlyphRole = "fill" | "stroke" | "thin" | "dash" | "cut" | "dim" | "label";

export const ROLE_CLASS: Record<GlyphRole, string> = {
  fill: "fp-glyph",
  stroke: "fp-opening",
  thin: "fp-glyph-thin",
  dash: "fp-glyph-dash",
  cut: "fp-opening-cut",
  dim: "fp-dim-line",
  label: "fp-dim-text",
};

export type Shape =
  | { kind: "rect"; x: number; y: number; w: number; h: number; role: GlyphRole }
  | { kind: "line"; x1: number; y1: number; x2: number; y2: number; role: GlyphRole }
  | { kind: "path"; d: string; role: GlyphRole }
  | { kind: "text"; x: number; y: number; text: string; role: GlyphRole };

const rect = (x: number, y: number, w: number, h: number, role: GlyphRole): Shape => ({
  kind: "rect",
  x,
  y,
  w,
  h,
  role,
});

const line = (x1: number, y1: number, x2: number, y2: number, role: GlyphRole): Shape => ({
  kind: "line",
  x1,
  y1,
  x2,
  y2,
  role,
});

const path = (d: string, role: GlyphRole): Shape => ({ kind: "path", d, role });

const text = (x: number, y: number, value: string, role: GlyphRole): Shape => ({
  kind: "text",
  x,
  y,
  text: value,
  role,
});

/** 輪郭の外へ出る量（m）。面ごとに一番深いもの */
export type PlanOverhang = { n: number; e: number; s: number; w: number };

export const NO_OVERHANG: PlanOverhang = Object.freeze({ n: 0, e: 0, s: 0, w: 0 });

/**
 * 外周（バルコニー・テラス・玄関ポーチ）が輪郭からはみ出す量を、面ごとに一番深いもので返す。
 * これを枠に足さないと、南のバルコニーのように外へ出るものが図面から切れてしまう。
 */
export function planOverhang(size: PlanSize, parts: readonly ExteriorPart[]): PlanOverhang {
  const out: PlanOverhang = { n: 0, e: 0, s: 0, w: 0 };
  for (const part of parts) {
    const r = exteriorRect(size, part);
    out.n = Math.max(out.n, -r.z);
    out.w = Math.max(out.w, -r.x);
    out.s = Math.max(out.s, r.z + r.d - size.depth);
    out.e = Math.max(out.e, r.x + r.w - size.width);
  }
  return out;
}

/**
 * 図面の枠。外皮の外に 12 単位の余白を取り、zoom で内側へ詰める。
 * 外へ出る外周があれば、その深さぶん余白を広げる ──
 * 広げないと、画面でつつけないだけでなく、書き出した PNG と印刷の 1 枚からも外周が切れる。
 */
export function planViewBox(size: PlanSize, zoom: number, overhang: PlanOverhang = NO_OVERHANG): string {
  const pad = 12;
  const left = pad + overhang.w * SCALE;
  const right = pad + overhang.e * SCALE;
  const top = pad + overhang.n * SCALE;
  const bottom = pad + overhang.s * SCALE;
  const fullW = size.width * SCALE + left + right;
  const fullH = size.depth * SCALE + top + bottom;
  const w = fullW / zoom;
  const h = fullH / zoom;
  // 余白が偏るぶん、中心も外周の側へずらす（zoom はその中心のまわりで詰める）
  const x = (size.width * SCALE) / 2 + (right - left) / 2 - w / 2;
  const y = (size.depth * SCALE) / 2 + (bottom - top) / 2 - h / 2;
  const round = (value: number) => Math.round(value * 100) / 100;
  return `${round(x)} ${round(y)} ${round(w)} ${round(h)}`;
}

/**
 * 壁に沿った位置 u（m、線の始まりから）と、壁の法線方向 v（m、plus が正）を
 * 平面図の座標に写す。axis "x" の壁は南北に走るので u は z、v は x。
 */
function toXY(o: Opening, u: number, v: number): { x: number; y: number } {
  if (o.axis === "x") return { x: (o.at + v) * SCALE, y: u * SCALE };
  return { x: u * SCALE, y: (o.at + v) * SCALE };
}

/** 枠の短線の長さ（壁の厚みぶん、片側 m） */
const JAMB = 0.08;

/**
 * 建具の記号。
 * 共通: 開口ぶんの壁を背景色で塗りつぶして線を切り（cut）、両端に枠の短線（stroke）。
 * ドア: 吊元から扉の板を開く側へ 90 度出し、その先端と閉じた位置を弧で結ぶ。
 * 引き戸: 中央の細い線 1 本と、引き込む側の平行線 2 本。
 * 窓: 開口の中に壁と平行な線 3 本。掃き出し窓は外側に短い破線を 2 本足す。
 */
export function openingShapes(o: Opening): Shape[] {
  const from = o.start;
  const to = o.start + o.width;
  const a = toXY(o, from, 0);
  const b = toXY(o, to, 0);
  const out: Shape[] = [line(a.x, a.y, b.x, b.y, "cut")];
  for (const u of [from, to]) {
    const p = toXY(o, u, -JAMB);
    const q = toXY(o, u, JAMB);
    out.push(line(p.x, p.y, q.x, q.y, "stroke"));
  }

  if (o.kind === "door") {
    const hingeU = o.hinge === "start" ? from : to;
    const otherU = o.hinge === "start" ? to : from;
    const sign = o.swing === "plus" ? 1 : -1;
    const hinge = toXY(o, hingeU, 0);
    const leaf = toXY(o, hingeU, sign * o.width);
    const closed = toXY(o, otherU, 0);
    const r = o.width * SCALE;
    // 弧の向き。SVG は y が下向きなので、外積の符号がそのまま sweep になる
    const cross = (leaf.x - hinge.x) * (closed.y - hinge.y) - (leaf.y - hinge.y) * (closed.x - hinge.x);
    const sweep = cross > 0 ? 1 : 0;
    out.push(path(`M ${leaf.x} ${leaf.y} A ${r} ${r} 0 0 ${sweep} ${closed.x} ${closed.y}`, "thin"));
    out.push(line(hinge.x, hinge.y, leaf.x, leaf.y, "stroke"));
    return out;
  }

  if (o.kind === "sliding") {
    const mid0 = toXY(o, from, 0);
    const mid1 = toXY(o, to, 0);
    out.push(line(mid0.x, mid0.y, mid1.x, mid1.y, "thin"));
    // 引き込む側の壁に重なる平行線 2 本（開口の幅ぶん）
    const pocketFrom = o.hinge === "start" ? from - o.width : to;
    const pocketTo = pocketFrom + o.width;
    for (const v of [-0.04, 0.04]) {
      const p = toXY(o, pocketFrom, v);
      const q = toXY(o, pocketTo, v);
      out.push(line(p.x, p.y, q.x, q.y, "thin"));
    }
    return out;
  }

  for (const v of [-0.06, 0, 0.06]) {
    const p = toXY(o, from, v);
    const q = toXY(o, to, v);
    out.push(line(p.x, p.y, q.x, q.y, "thin"));
  }
  if (o.style === "hakidashi") {
    for (const u of [from + 0.15, to - 0.15]) {
      const p = toXY(o, u, 0.06);
      const q = toXY(o, u, 0.36);
      out.push(line(p.x, p.y, q.x, q.y, "dash"));
    }
  }
  return out;
}

/** 建具の当たり判定の箱（平面図の単位）。pad は指の太さぶんの広げ（m） */
export function openingHitBox(
  o: Opening,
  pad = 0,
): { x: number; y: number; w: number; h: number } {
  const a = toXY(o, o.start, 0);
  const b = toXY(o, o.start + o.width, 0);
  const p = pad * SCALE;
  return {
    x: Math.min(a.x, b.x) - p,
    y: Math.min(a.y, b.y) - p,
    w: Math.abs(b.x - a.x) + p * 2,
    h: Math.abs(b.y - a.y) + p * 2,
  };
}

/** model の Glyph（矩形 + 線）を、中心を原点にした図形にする。矩形は塗り、線は細線 */
function glyphToShapes(glyph: Glyph): Shape[] {
  const out: Shape[] = glyph.rects.map((r) =>
    rect((r.x - r.w / 2) * SCALE, (r.z - r.d / 2) * SCALE, r.w * SCALE, r.d * SCALE, "fill"),
  );
  for (const l of glyph.lines ?? []) {
    out.push(line(l.x1 * SCALE, l.z1 * SCALE, l.x2 * SCALE, l.z2 * SCALE, "thin"));
  }
  return out;
}

/**
 * 設備の記号。中心を原点にした相対座標。
 * 外形の矩形 + 棚板の線 + 扉の記号（折れ戸 / 引き戸 / 開き戸）。
 * 階段は段板の線と上り方向の三角。扉の面は −y（北）を向く。
 */
export function fixtureShapes(item: Fixture): Shape[] {
  const out = glyphToShapes(fixtureGlyph(item));
  const halfW = (item.size.w / 2) * SCALE;
  const halfD = (item.size.d / 2) * SCALE;

  if (item.kind === "stairs") {
    // 上り方向の三角（南から北へ上がる）
    const tip = -halfD + 12;
    const back = tip + 26;
    out.push(path(`M 0 ${tip} L -13 ${back} L 13 ${back} Z`, "fill"));
    return out;
  }

  const faceY = -halfD;
  if (item.door === "folding") {
    // への字 2 本
    const mid = 0;
    out.push(line(-halfW, faceY, mid - halfW / 2, faceY + halfD, "stroke"));
    out.push(line(mid - halfW / 2, faceY + halfD, mid, faceY, "stroke"));
    out.push(line(mid, faceY, mid + halfW / 2, faceY + halfD, "stroke"));
    out.push(line(mid + halfW / 2, faceY + halfD, halfW, faceY, "stroke"));
    return out;
  }
  if (item.door === "sliding") {
    out.push(line(-halfW, faceY + 5, 0, faceY + 5, "stroke"));
    out.push(line(0, faceY + 11, halfW, faceY + 11, "stroke"));
    return out;
  }
  if (item.door === "hinged") {
    const r = Math.min(halfW * 2, halfD * 2);
    out.push(line(-halfW, faceY, -halfW, faceY - r, "stroke"));
    out.push(path(`M ${-halfW} ${faceY - r} A ${r} ${r} 0 0 1 ${-halfW + r} ${faceY}`, "thin"));
    return out;
  }
  return out;
}

/** 家具の記号。catalog の Glyph をそのまま図形にする。中心を原点にした相対座標 */
export function furnitureShapes(item: PlacedFurniture): Shape[] {
  return glyphToShapes(buildGlyph(item));
}

/** 外周の記号。破線の矩形 + 手すりの細い線 3 本 + 中央に名前。絶対座標 */
export function exteriorShapes(size: PlanSize, part: ExteriorPart): Shape[] {
  const r = exteriorRect(size, part);
  const x = r.x * SCALE;
  const y = r.z * SCALE;
  const w = r.w * SCALE;
  const h = r.d * SCALE;
  const out: Shape[] = [rect(x, y, w, h, "dash")];
  if (part.railing) {
    const inset = 6;
    // 建物に付く 1 辺を除いた 3 辺
    const edges: [number, number, number, number][] =
      part.side === "s"
        ? [
            [x + inset, y + h - inset, x + w - inset, y + h - inset],
            [x + inset, y, x + inset, y + h - inset],
            [x + w - inset, y, x + w - inset, y + h - inset],
          ]
        : part.side === "n"
          ? [
              [x + inset, y + inset, x + w - inset, y + inset],
              [x + inset, y + inset, x + inset, y + h],
              [x + w - inset, y + inset, x + w - inset, y + h],
            ]
          : part.side === "w"
            ? [
                [x + inset, y + inset, x + inset, y + h - inset],
                [x + inset, y + inset, x + w, y + inset],
                [x + inset, y + h - inset, x + w, y + h - inset],
              ]
            : [
                [x + w - inset, y + inset, x + w - inset, y + h - inset],
                [x, y + inset, x + w - inset, y + inset],
                [x, y + h - inset, x + w - inset, y + h - inset],
              ];
    for (const [x1, y1, x2, y2] of edges) out.push(line(x1, y1, x2, y2, "thin"));
  }
  out.push(text(x + w / 2, y + h / 2 + 10, exteriorName(part.kind), "label"));
  return out;
}

/**
 * 寸法線。外接長方形の上辺と左辺に引き、両端に 45 度の短い斜線、中央に数値。
 * offset は輪郭からの離れ（m）。null を渡した辺は描かない。
 */
export function dimensionShapes(
  box: Rect,
  top: string | null,
  left: string | null,
  offset = 0.1,
): Shape[] {
  const out: Shape[] = [];
  const x0 = box.x * SCALE;
  const x1 = (box.x + box.w) * SCALE;
  const y0 = box.z * SCALE;
  const y1 = (box.z + box.d) * SCALE;
  const gap = offset * SCALE;
  const tick = 8;
  if (top !== null) {
    const y = y0 - gap;
    out.push(line(x0, y, x1, y, "dim"));
    out.push(line(x0 - tick, y + tick, x0 + tick, y - tick, "dim"));
    out.push(line(x1 - tick, y + tick, x1 + tick, y - tick, "dim"));
    out.push(text((x0 + x1) / 2, y - 10, top, "label"));
  }
  if (left !== null) {
    const x = x0 - gap;
    out.push(line(x, y0, x, y1, "dim"));
    out.push(line(x - tick, y0 + tick, x + tick, y0 - tick, "dim"));
    out.push(line(x - tick, y1 + tick, x + tick, y1 - tick, "dim"));
    out.push(text(x - 10, (y0 + y1) / 2, left, "label"));
  }
  return out;
}
