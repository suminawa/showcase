/*
 * 売り物: 編集できる間取り図。SVG で 1 m = 100 単位、マスは 0.5 m。
 * 間取りは自分では持たない（なぞっている途中の覚え書きと、つかんでいるものだけ持つ）。
 * 変更はすべて props のコールバックで親（Simulator）へ返す。
 * 3D と同じ 1 つの状態を親が持っているので、なぞっている最中も 3D がそのまま追いつく。
 */
import {
  useMemo,
  useRef,
  type PointerEvent as ReactPointerEvent,
  type RefObject,
} from "react";

import { formatArea, formatJo, formatLength, roomDimension } from "../model/dimensions";
import { exteriorRect, moveExterior, removeExterior, type ExteriorPart } from "../model/exterior";
import {
  addFixture,
  moveFixture,
  removeFixture,
  rotateFixture,
  type Fixture,
  type FixtureKind,
} from "../model/fixtures";
import {
  footprintOf,
  moveFurniture,
  removeFurniture,
  rotateFurniture,
  type PlacedFurniture,
} from "../model/furniture";
import {
  cellFromPoint,
  cellsAlong,
  paintCells,
  roomRects,
  wallSegments,
  type RoomId,
  type RoomRect,
} from "../model/grid";
import { CELL, ceilingOf, colsOf, rowsOf, type Floor } from "../model/house";
import {
  cycleSwing,
  moveOpening,
  placeOpening,
  pruneOpenings,
  removeOpening,
  resizeOpening,
  type Opening,
  type OpeningPresetId,
} from "../model/openings";
import { type FloorPlan, type PlanDoc } from "../model/plan";
import { type SelectionTarget } from "./config";
import {
  dimensionShapes,
  exteriorShapes,
  fixtureShapes,
  furnitureShapes,
  openingHitBox,
  openingShapes,
  planOverhang,
  planViewBox,
  ROLE_CLASS,
  SCALE,
  type Shape,
} from "./glyphs";
import { type FloorplanLabels } from "./labels";

export type EditorMode = "select" | "paint" | "opening" | "fixture" | "dimension";

export const ZOOM_MIN = 0.5;
export const ZOOM_MAX = 4;
export const ZOOM_STEP = 1.25;

/** 指で触ったときに当たり判定を広げる量（m） */
const TOUCH_PAD = 0.12;

export type EditorProps = {
  doc: PlanDoc;
  floor: Floor;
  mode: EditorMode;
  zoom: number;
  selection: SelectionTarget;
  showDimensions: boolean;
  readonly: boolean;
  labels: FloorplanLabels;
  /** 「塗る」で塗り込む部屋。null なら最初に触ったマスの部屋 */
  activeRoomId: RoomId | null;
  openingPreset: OpeningPresetId;
  fixtureKind: FixtureKind;
  onSelect: (target: SelectionTarget) => void;
  onFloorChange: (next: FloorPlan) => void;
  onNotice: (message: string) => void;
  onZoom?: (zoom: number) => void;
  svgRef?: RefObject<SVGSVGElement | null>;
};

/* ---- 純粋な部分（テストはここに厚く置く） ------------------------------- */

function insideBox(x: number, z: number, cx: number, cz: number, w: number, d: number, pad: number) {
  return Math.abs(x - cx) <= w / 2 + pad && Math.abs(z - cz) <= d / 2 + pad;
}

/** 点の下にあるものを、上に描かれている順（建具 → 家具 → 設備 → 外周 → 部屋）で拾う */
export function pickAt(
  doc: PlanDoc,
  floor: Floor,
  x: number,
  z: number,
  pad: number,
): SelectionTarget {
  const plan = doc.floors[floor];
  for (const o of plan.openings) {
    const box = openingHitBox(o, Math.max(pad, 0.06));
    if (
      x * SCALE >= box.x &&
      x * SCALE <= box.x + box.w &&
      z * SCALE >= box.y &&
      z * SCALE <= box.y + box.h
    ) {
      return { kind: "opening", id: o.id };
    }
  }
  for (const item of [...plan.furniture].reverse()) {
    const [w, d] = footprintOf(item);
    if (insideBox(x, z, item.x, item.z, w, d, pad)) return { kind: "furniture", id: item.id };
  }
  for (const item of [...plan.fixtures].reverse()) {
    const [w, d] = footprintOf(item);
    if (insideBox(x, z, item.x, item.z, w, d, pad)) return { kind: "fixture", id: item.id };
  }
  for (const part of plan.exterior) {
    const r = exteriorRect(doc.size, part);
    if (x >= r.x - pad && x <= r.x + r.w + pad && z >= r.z - pad && z <= r.z + r.d + pad) {
      return { kind: "exterior", id: part.id };
    }
  }
  const index = cellFromPoint(doc.size, x, z);
  if (index === null) return null;
  return { kind: "room", id: plan.layout.cells[index] };
}

/** 矢印キーで 0.25 m 動かす。部屋は動かさない */
export function nudge(
  doc: PlanDoc,
  floor: Floor,
  target: SelectionTarget,
  dx: number,
  dz: number,
): FloorPlan {
  const plan = doc.floors[floor];
  if (!target) return plan;
  if (target.kind === "furniture") {
    const item = plan.furniture.find((entry) => entry.id === target.id);
    if (!item) return plan;
    return { ...plan, furniture: moveFurniture(doc.size, plan.furniture, target.id, item.x + dx, item.z + dz) };
  }
  if (target.kind === "fixture") {
    const item = plan.fixtures.find((entry) => entry.id === target.id);
    if (!item) return plan;
    return { ...plan, fixtures: moveFixture(doc.size, plan.fixtures, target.id, item.x + dx, item.z + dz) };
  }
  if (target.kind === "opening") {
    const o = plan.openings.find((entry) => entry.id === target.id);
    if (!o) return plan;
    const along = o.axis === "x" ? dz : dx;
    if (along === 0) return plan;
    const next = moveOpening(
      plan.layout,
      doc.size,
      ceilingOf(doc.size, floor),
      plan.openings,
      target.id,
      o.start + along,
    );
    return next === plan.openings ? plan : { ...plan, openings: next };
  }
  if (target.kind === "exterior") {
    const part = plan.exterior.find((entry) => entry.id === target.id);
    if (!part) return plan;
    const along = part.side === "n" || part.side === "s" ? dx : dz;
    if (along === 0) return plan;
    return { ...plan, exterior: moveExterior(doc.size, plan.exterior, target.id, part.start + along) };
  }
  return plan;
}

/** R キー。家具と設備は回し、建具は開き勝手を送る */
export function rotateSelection(doc: PlanDoc, floor: Floor, target: SelectionTarget): FloorPlan {
  const plan = doc.floors[floor];
  if (!target) return plan;
  if (target.kind === "furniture") {
    return { ...plan, furniture: rotateFurniture(doc.size, plan.furniture, target.id) };
  }
  if (target.kind === "fixture") {
    return { ...plan, fixtures: rotateFixture(doc.size, plan.fixtures, target.id) };
  }
  if (target.kind === "opening") {
    const o = plan.openings.find((entry) => entry.id === target.id);
    if (!o) return plan;
    const turned = cycleSwing(o);
    const next = resizeOpening(plan.layout, doc.size, ceilingOf(doc.size, floor), plan.openings, target.id, {
      hinge: turned.hinge,
      swing: turned.swing,
    });
    return next === plan.openings ? plan : { ...plan, openings: next };
  }
  return plan;
}

/** Delete / Backspace。部屋は消さない（塗って作るものなので、塗り替えで消える） */
export function removeSelection(doc: PlanDoc, floor: Floor, target: SelectionTarget): FloorPlan {
  const plan = doc.floors[floor];
  if (!target) return plan;
  if (target.kind === "furniture") return { ...plan, furniture: removeFurniture(plan.furniture, target.id) };
  if (target.kind === "fixture") return { ...plan, fixtures: removeFixture(plan.fixtures, target.id) };
  if (target.kind === "opening") return { ...plan, openings: removeOpening(plan.openings, target.id) };
  if (target.kind === "exterior") return { ...plan, exterior: removeExterior(plan.exterior, target.id) };
  return plan;
}

/* ---- 描く --------------------------------------------------------------- */

type Stroke = { pointerId: number; floor: Floor; room: RoomId; cells: number[]; at: { x: number; z: number } };
type Grab = { pointerId: number; floor: Floor; target: SelectionTarget; dx: number; dz: number };
/** 2 本指のピンチ。始めたときの指の間隔と拡大率を覚えておき、その比で拡げ縮めする */
type Pinch = { ids: readonly number[]; span: number; zoom: number };

/** 画面の上での 2 点の間の距離（px） */
function spanBetween(a: { x: number; y: number }, b: { x: number; y: number }): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/** マウスの右ボタン・中ボタンで押した。右ドラッグは 3D の平行移動に使うので、ここでは何も始めない */
function isSecondaryPress(event: ReactPointerEvent<SVGElement>): boolean {
  return event.pointerType === "mouse" && event.button !== 0;
}

/** setPointerCapture は環境によっては例外を投げる。取れなくても塗り・ドラッグは止めない */
function captureQuietly(target: Element, pointerId: number): void {
  try {
    target.setPointerCapture(pointerId);
  } catch {
    // 取れなくても続行する
  }
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function renderShapes(shapes: readonly Shape[], keyPrefix: string, selected: boolean) {
  return shapes.map((shape, index) => {
    const key = `${keyPrefix}-${index}`;
    const className =
      selected && (shape.role === "fill" || shape.role === "stroke")
        ? shape.role === "fill"
          ? "fp-glyph-selected"
          : "fp-opening-selected"
        : ROLE_CLASS[shape.role];
    if (shape.kind === "rect") {
      return <rect key={key} className={className} x={shape.x} y={shape.y} width={shape.w} height={shape.h} />;
    }
    if (shape.kind === "line") {
      return <line key={key} className={className} x1={shape.x1} y1={shape.y1} x2={shape.x2} y2={shape.y2} />;
    }
    if (shape.kind === "path") {
      return <path key={key} className={className} d={shape.d} />;
    }
    return (
      <text key={key} className={className} x={shape.x} y={shape.y}>
        {shape.text}
      </text>
    );
  });
}

/** 部屋名を輪郭の内側に留めるための余白（ユーザー単位） */
const LABEL_PAD_X = 110;
const LABEL_PAD_Y = 40;
/** 名前を出すマス数の下限と、広さも出すマス数の下限 */
const LABEL_MIN_CELLS = 2;
const AREA_MIN_CELLS = 4;

export function Editor({
  doc,
  floor,
  mode,
  zoom,
  selection,
  showDimensions,
  readonly,
  labels,
  activeRoomId,
  openingPreset,
  fixtureKind,
  onSelect,
  onFloorChange,
  onNotice,
  onZoom,
  svgRef,
}: EditorProps) {
  const localRef = useRef<SVGSVGElement | null>(null);
  const ref = svgRef ?? localRef;
  const stroke = useRef<Stroke | null>(null);
  const grab = useRef<Grab | null>(null);
  // いま触れている指（マウス以外）の位置。2 本そろったらピンチに切り替える
  const points = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<Pinch | null>(null);

  const size = doc.size;
  const plan = doc.floors[floor];
  const layout = plan.layout;
  const ceiling = ceilingOf(size, floor);
  const locked = readonly || mode === "paint";
  const dimensions = showDimensions || mode === "dimension";

  // 外へ出る外周（バルコニーなど）のぶん、図面の枠を広げる
  const overhang = useMemo(() => planOverhang(size, plan.exterior), [size, plan.exterior]);

  const gridPath = useMemo(() => {
    const parts: string[] = [];
    for (let col = 1; col < colsOf(size); col++) parts.push(`M${col * CELL * SCALE} 0V${size.depth * SCALE}`);
    for (let row = 1; row < rowsOf(size); row++) parts.push(`M0 ${row * CELL * SCALE}H${size.width * SCALE}`);
    return parts.join("");
  }, [size]);

  const rects = roomRects(size, layout);
  const walls = wallSegments(size, layout);
  const firstRects = new Map<RoomId, RoomRect>();
  for (const entry of rects) if (!firstRects.has(entry.roomId)) firstRects.set(entry.roomId, entry);

  function planPoint(event: ReactPointerEvent<SVGElement>): { x: number; z: number } | null {
    const ctm = ref.current?.getScreenCTM();
    if (!ctm) return null;
    const point = new DOMPoint(event.clientX, event.clientY).matrixTransform(ctm.inverse());
    return { x: point.x / SCALE, z: point.y / SCALE };
  }

  function padOf(event: ReactPointerEvent<SVGElement>): number {
    return event.pointerType === "mouse" ? 0 : TOUCH_PAD;
  }

  function startPaint(event: ReactPointerEvent<SVGSVGElement>, at: { x: number; z: number }, index: number) {
    const target = activeRoomId && layout.rooms.some((room) => room.id === activeRoomId)
      ? activeRoomId
      : layout.cells[index];
    if (!activeRoomId) onSelect({ kind: "room", id: target });
    captureQuietly(event.currentTarget, event.pointerId);
    stroke.current = { pointerId: event.pointerId, floor, room: target, cells: [index], at };
    const painted = paintCells(size, layout, [index], target);
    if (painted !== layout) {
      onFloorChange({ ...plan, layout: painted, openings: pruneOpenings(painted, size, ceiling, plan.openings) });
    }
  }

  /**
   * 2 本目の指が着いた。進めていた塗り・つかみはそこまでで手放し（取り消しはしない。
   * 変更はその都度もう親へ渡してある）、以降はピンチとして扱う。
   */
  function startPinch(event: ReactPointerEvent<SVGSVGElement>) {
    event.preventDefault();
    stroke.current = null;
    grab.current = null;
    const ids = Array.from(points.current.keys()).slice(0, 2);
    const first = points.current.get(ids[0]);
    const second = points.current.get(ids[1]);
    if (!first || !second) return;
    const span = spanBetween(first, second);
    if (span <= 0) return;
    pinch.current = { ids, span, zoom };
  }

  function handleDown(event: ReactPointerEvent<SVGSVGElement>) {
    if (isSecondaryPress(event)) return;
    if (event.pointerType !== "mouse") {
      points.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
      // 2 本目からは塗りもつかみも始めない（1 本目のものは startPinch が手放す）
      if (points.current.size >= 2) {
        if (!pinch.current) startPinch(event);
        return;
      }
    }
    if (stroke.current || grab.current) return;
    // 触ったら Delete / Backspace が届くよう、フォーカスを SVG へ移す
    event.preventDefault();
    ref.current?.focus({ preventScroll: true });
    const at = planPoint(event);
    if (!at) return;
    const index = cellFromPoint(size, at.x, at.z);

    if (mode === "paint" && !readonly && index !== null) {
      startPaint(event, at, index);
      return;
    }
    if (mode === "opening" && !readonly) {
      const placed = placeOpening(layout, size, ceiling, plan.openings, openingPreset, at.x, at.z);
      if (!placed) {
        onNotice(labels.noFit);
        return;
      }
      onFloorChange({ ...plan, openings: [...plan.openings, placed] });
      onSelect({ kind: "opening", id: placed.id });
      return;
    }
    if (mode === "fixture" && !readonly && index !== null) {
      const next = addFixture(size, plan.fixtures, fixtureKind, [at.x, at.z]);
      onFloorChange({ ...plan, fixtures: next });
      onSelect({ kind: "fixture", id: next[next.length - 1].id });
      return;
    }

    const target = pickAt(doc, floor, at.x, at.z, padOf(event));
    onSelect(target);
    if (readonly || !target) return;
    if (target.kind === "furniture" || target.kind === "fixture" || target.kind === "opening") {
      captureQuietly(event.currentTarget, event.pointerId);
      const holder =
        target.kind === "furniture"
          ? plan.furniture.find((item) => item.id === target.id)
          : target.kind === "fixture"
            ? plan.fixtures.find((item) => item.id === target.id)
            : null;
      grab.current = {
        pointerId: event.pointerId,
        floor,
        target,
        dx: holder ? holder.x - at.x : 0,
        dz: holder ? holder.z - at.z : 0,
      };
    }
  }

  function handleMove(event: ReactPointerEvent<SVGSVGElement>) {
    // ピンチ中。2 点の間隔の比をそのまま拡大率にする
    const pinching = pinch.current;
    if (pinching) {
      if (!points.current.has(event.pointerId)) return;
      points.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
      if (!pinching.ids.includes(event.pointerId)) return;
      const first = points.current.get(pinching.ids[0]);
      const second = points.current.get(pinching.ids[1]);
      if (!first || !second) return;
      const span = spanBetween(first, second);
      if (span <= 0) return;
      zoomTo(pinching.zoom * (span / pinching.span));
      return;
    }

    const painting = stroke.current;
    if (painting && painting.pointerId === event.pointerId) {
      // なぞっている途中で階が変わった。別の階のマスを塗らないよう捨てる
      if (painting.floor !== floor) {
        stroke.current = null;
        return;
      }
      // 離したのを取りこぼしたまま動いている（画面の外で離した等）
      if (event.buttons === 0) return;
      const at = planPoint(event);
      if (!at) return;
      const along = cellsAlong(size, painting.at, at);
      painting.at = at;
      let changed = false;
      for (const index of along) {
        if (painting.cells.includes(index)) continue;
        painting.cells.push(index);
        changed = true;
      }
      if (!changed) return;
      const painted = paintCells(size, layout, painting.cells, painting.room);
      onFloorChange({ ...plan, layout: painted, openings: pruneOpenings(painted, size, ceiling, plan.openings) });
      return;
    }

    const held = grab.current;
    if (!held || held.pointerId !== event.pointerId) return;
    if (event.buttons === 0 || held.floor !== floor) {
      grab.current = null;
      return;
    }
    const at = planPoint(event);
    if (!at || !held.target) return;
    if (held.target.kind === "furniture") {
      onFloorChange({
        ...plan,
        furniture: moveFurniture(size, plan.furniture, held.target.id, at.x + held.dx, at.z + held.dz),
      });
      return;
    }
    if (held.target.kind === "fixture") {
      onFloorChange({
        ...plan,
        fixtures: moveFixture(size, plan.fixtures, held.target.id, at.x + held.dx, at.z + held.dz),
      });
      return;
    }
    const o = plan.openings.find((entry) => entry.id === held.target!.id);
    if (!o) return;
    const along = o.axis === "x" ? at.z : at.x;
    const next = moveOpening(layout, size, ceiling, plan.openings, o.id, along - o.width / 2);
    if (next !== plan.openings) onFloorChange({ ...plan, openings: next });
  }

  /** 指が離れた。ピンチをやめても、残った指で塗り直さない（stroke も grab も空のまま） */
  function endPointer(pointerId: number) {
    points.current.delete(pointerId);
    if (pinch.current?.ids.includes(pointerId)) pinch.current = null;
  }

  function handleUp(event: ReactPointerEvent<SVGSVGElement>) {
    endPointer(event.pointerId);
    if (stroke.current?.pointerId === event.pointerId) stroke.current = null;
    if (grab.current?.pointerId === event.pointerId) grab.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
  }

  /** SVG の外へ出た。capture が取れていれば離した合図は必ず届くので、そのまま続ける */
  function handleLeave(event: ReactPointerEvent<SVGSVGElement>) {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) return;
    endPointer(event.pointerId);
    if (stroke.current?.pointerId === event.pointerId) stroke.current = null;
    if (grab.current?.pointerId === event.pointerId) grab.current = null;
  }

  const selectedId = selection?.id ?? null;
  const isSelected = (kind: NonNullable<SelectionTarget>["kind"], id: string) =>
    selection?.kind === kind && selection.id === id;

  const zoomTo = (next: number) => onZoom?.(clamp(next, ZOOM_MIN, ZOOM_MAX));

  return (
    <div className="fp-editor">
      <div className="fp-editor-row" role="group" aria-label={labels.zoomGroup}>
        <button type="button" className="fp-button" onClick={() => zoomTo(zoom * ZOOM_STEP)}>
          {labels.zoomIn}
        </button>
        <button type="button" className="fp-button" onClick={() => zoomTo(zoom / ZOOM_STEP)}>
          {labels.zoomOut}
        </button>
        <button type="button" className="fp-button" onClick={() => zoomTo(1)}>
          {labels.zoomFit}
        </button>
      </div>

      <svg
        ref={ref}
        className={mode === "paint" ? "fp-plan fp-plan-paint" : "fp-plan"}
        viewBox={planViewBox(size, zoom, overhang)}
        role="group"
        aria-label={labels.planAria.replace("{floor}", String(floor))}
        tabIndex={-1}
        onPointerDown={handleDown}
        onPointerMove={handleMove}
        onPointerUp={handleUp}
        onPointerCancel={handleUp}
        onPointerLeave={handleLeave}
        onLostPointerCapture={handleUp}
      >
        {rects.map((entry) => (
          <rect
            key={entry.id}
            className={entry.roomId === selectedId ? "fp-room-selected" : "fp-room"}
            x={entry.x * SCALE}
            y={entry.z * SCALE}
            width={entry.w * SCALE}
            height={entry.d * SCALE}
          />
        ))}

        <path className="fp-grid" d={gridPath} />

        {walls.map((wall) => {
          const across = wall.axis === "x";
          return (
            <line
              key={wall.id}
              className="fp-wall"
              x1={(across ? wall.at : wall.from) * SCALE}
              y1={(across ? wall.from : wall.at) * SCALE}
              x2={(across ? wall.at : wall.to) * SCALE}
              y2={(across ? wall.to : wall.at) * SCALE}
            />
          );
        })}

        <rect className="fp-outline" x={0} y={0} width={size.width * SCALE} height={size.depth * SCALE} />

        {plan.exterior.map((part: ExteriorPart) => (
          <g key={part.id} className="fp-labels">
            {renderShapes(exteriorShapes(size, part), part.id, isSelected("exterior", part.id))}
          </g>
        ))}

        {plan.fixtures.map((item: Fixture) => (
          <g
            key={item.id}
            className={locked ? "fp-item fp-item-locked" : "fp-item"}
            transform={`translate(${item.x * SCALE} ${item.z * SCALE}) rotate(${item.rotation})`}
          >
            {renderShapes(fixtureShapes(item), item.id, isSelected("fixture", item.id))}
          </g>
        ))}

        {plan.furniture.map((item: PlacedFurniture) => (
          <g
            key={item.id}
            className={locked ? "fp-item fp-item-locked" : "fp-item"}
            transform={`translate(${item.x * SCALE} ${item.z * SCALE}) rotate(${item.rotation})`}
          >
            {renderShapes(furnitureShapes(item), item.id, isSelected("furniture", item.id))}
          </g>
        ))}

        {plan.openings.map((o: Opening) => (
          <g key={o.id}>{renderShapes(openingShapes(o), o.id, isSelected("opening", o.id))}</g>
        ))}

        {dimensions && (
          <g className="fp-labels">
            {layout.rooms.map((room) => {
              const dim = roomDimension(size, layout, room.id);
              if (!dim) return null;
              const top = dim.exact ? formatLength(dim.w) : `${labels.maxPrefix} ${formatLength(dim.w)}`;
              const left = formatLength(dim.d);
              const bounds = { x: 0, z: 0, w: dim.w, d: dim.d };
              const anchor = rects.find((entry) => entry.roomId === room.id);
              if (!anchor) return null;
              return (
                <g key={`dim-${room.id}`}>
                  {renderShapes(
                    dimensionShapes({ ...bounds, x: anchor.x, z: anchor.z }, top, left),
                    `dim-${room.id}`,
                    false,
                  )}
                </g>
              );
            })}
            {[...plan.furniture, ...plan.fixtures].map((item) => {
              const [w, d] = footprintOf(item);
              return (
                <g key={`dim-${item.id}`}>
                  {renderShapes(
                    dimensionShapes(
                      { x: item.x - w / 2, z: item.z - d / 2, w, d },
                      formatLength(w),
                      formatLength(d),
                    ),
                    `dim-${item.id}`,
                    false,
                  )}
                </g>
              );
            })}
          </g>
        )}

        {/* 家具の記号の上に重なっても読めるよう、部屋名と広さはすべての上に最後に描く。
            読み上げは下のキーボードの的（aria-label）が受け持つので、ここは読ませない */}
        {layout.rooms.map((room) => {
          const dim = roomDimension(size, layout, room.id);
          if (!dim) return null;
          const cells = Math.round(dim.area / (CELL * CELL));
          if (cells < LABEL_MIN_CELLS) return null;
          const withArea = cells >= AREA_MIN_CELLS;
          const anchor = rects.find((entry) => entry.roomId === room.id);
          if (!anchor) return null;
          const x = clamp((anchor.x + anchor.w / 2) * SCALE, LABEL_PAD_X, size.width * SCALE - LABEL_PAD_X);
          const y = clamp((anchor.z + anchor.d / 2) * SCALE, LABEL_PAD_Y, size.depth * SCALE - LABEL_PAD_Y);
          return (
            <g key={`label-${room.id}`} className="fp-labels" aria-hidden="true">
              <text className="fp-name" x={x} y={withArea ? y - 10 : y + 14}>
                {room.label}
              </text>
              {withArea && (
                <text className="fp-area" x={x} y={y + 37}>
                  {formatArea(dim.area)} {labels.areaUnit} / {formatJo(dim.jo)} {labels.joUnit}
                </text>
              )}
            </g>
          );
        })}

        {/* キーボードの的。部屋ごとに 1 枚だけ置く（同じ部屋で何度も Tab が止まらないように） */}
        {[...firstRects.values()].map((entry) => {
          const dim = roomDimension(size, layout, entry.roomId);
          return (
            <rect
              key={`focus-${entry.id}`}
              className="fp-focus"
              x={entry.x * SCALE}
              y={entry.z * SCALE}
              width={entry.w * SCALE}
              height={entry.d * SCALE}
              tabIndex={0}
              role="button"
              aria-pressed={entry.roomId === selectedId}
              aria-label={`${entry.label} ${formatArea(dim?.area ?? 0)} ${labels.areaUnit}`}
              onKeyDown={(event) => {
                if (event.key !== "Enter" && event.key !== " ") return;
                event.preventDefault();
                onSelect({ kind: "room", id: entry.roomId });
              }}
            />
          );
        })}
      </svg>
    </div>
  );
}
