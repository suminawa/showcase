/**
 * 売り物: 画面に出していない階の間取り図を、その場で 1 回だけ描いて文字列にする。
 * 印刷の 1 枚は 1F と 2F の両方を載せるが、画面に出ているのは片方だけなので、
 * もう片方はここで（document に足さない div の中に）描いてから取り出す。
 */
import { createElement } from "react";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";

import { Editor, type EditorProps } from "./Editor";
import { serializePlanSvg } from "./planStyle";

/** 描くのに要る props から、触りに関わるもの（呼び返し）を抜いたもの */
export type OffscreenPlanProps = Omit<
  EditorProps,
  "onSelect" | "onFloorChange" | "onNotice" | "onZoom" | "svgRef"
>;

const noop = () => {};

/**
 * tokensFrom は色（--fp-*）を読む先。ここで描く div は document に足さないので、
 * この SVG からは getComputedStyle でも --fp-* が読めない。
 * 画面に出ている SVG を渡せば、1 枚の中で 1F と 2F の色がそろう。
 */
export function renderPlanMarkup(
  doc: Document,
  props: OffscreenPlanProps,
  tokensFrom?: Element | null,
): string {
  const host = doc.createElement("div");
  const ref: { current: SVGSVGElement | null } = { current: null };
  const root = createRoot(host);
  // render は既定では次の描画まで待つので、その場で取り出せるよう flushSync で流し込む
  flushSync(() => {
    root.render(
      createElement(Editor, {
        ...props,
        onSelect: noop,
        onFloorChange: noop,
        onNotice: noop,
        svgRef: ref,
      }),
    );
  });
  const markup = ref.current ? serializePlanSvg(ref.current, tokensFrom ?? ref.current) : "";
  // 描いたそばから片づけると React が「描いている最中の unmount」と見なすので、1 拍おく
  setTimeout(() => root.unmount(), 0);
  return markup;
}
