import { describe, expect, it, vi } from "vitest";
import { defaultPlanFile } from "../model/plan";
import { DEFAULT_LABELS } from "./labels";
import { escapeHtml, openPrintSheet, printSheetHtml } from "./print";

const doc = defaultPlanFile().plans[0];
const sheets = [
  { floor: 1 as const, markup: "<svg><rect/></svg>" },
  { floor: 2 as const, markup: "<svg><circle/></svg>" },
];

describe("printSheetHtml", () => {
  it("A4 横で、案の名前と外皮の寸法が載る", () => {
    const html = printSheetHtml(doc, sheets, DEFAULT_LABELS);
    expect(html).toContain("@page");
    expect(html).toContain("A4 landscape");
    expect(html).toContain("案 1");
    expect(html).toContain("9.00 × 8.00 m");
    expect(html).toContain("<svg><rect/></svg>");
    expect(html).toContain("<svg><circle/></svg>");
  });

  it("部屋の一覧に名前・面積・帖が並ぶ", () => {
    const html = printSheetHtml(doc, sheets, DEFAULT_LABELS);
    expect(html).toContain("LDK");
    expect(html).toContain("33.00");
    expect(html).toContain("20.4");
  });

  it("家具の一覧に名前と寸法が並ぶ", () => {
    const html = printSheetHtml(doc, sheets, DEFAULT_LABELS);
    expect(html).toContain("ソファ");
    expect(html).toContain("1.90 × 0.85 × 0.80 m");
    expect(html).toContain("階段");
  });

  it("平屋では 2F の欄を出さない", () => {
    const flat = { ...doc, size: { ...doc.size, floors: 1 as const } };
    const html = printSheetHtml(flat, [sheets[0]], DEFAULT_LABELS);
    expect(html).not.toContain("<svg><circle/></svg>");
  });

  it("差し替えられる文言（単位）も、そのまま埋めずに記号を逃がす", () => {
    const labels = { ...DEFAULT_LABELS, areaUnit: "<b>m2</b>", joUnit: "<i>帖</i>" };
    const html = printSheetHtml(doc, sheets, labels);
    expect(html).not.toContain("<b>m2</b>");
    expect(html).not.toContain("<i>帖</i>");
    expect(html).toContain("&lt;b&gt;m2&lt;/b&gt;");
    expect(html).toContain("&lt;i&gt;帖&lt;/i&gt;");
  });

  it("案の名前は毎回そのまま埋めず、記号を逃がす", () => {
    expect(escapeHtml('<a href="#">&</a>')).toBe("&lt;a href=&quot;#&quot;&gt;&amp;&lt;/a&gt;");
    const html = printSheetHtml({ ...doc, name: "<script>" }, sheets, DEFAULT_LABELS);
    expect(html).not.toContain("<script>");
    expect(html).toContain("&lt;script&gt;");
  });
});

describe("openPrintSheet", () => {
  it("別タブが開けたら true、塞がれていたら false", () => {
    const print = vi.fn();
    const write = vi.fn();
    const close = vi.fn();
    const fake = { document: { write, close }, print, focus: vi.fn() } as unknown as Window;
    const win = { open: vi.fn(() => fake) } as unknown as Window;
    expect(openPrintSheet("<html></html>", win)).toBe(true);
    expect(write).toHaveBeenCalledWith("<html></html>");
    expect(print).toHaveBeenCalled();
    const blocked = { open: vi.fn(() => null) } as unknown as Window;
    expect(openPrintSheet("<html></html>", blocked)).toBe(false);
    expect(openPrintSheet("<html></html>", undefined)).toBe(false);
  });
});
