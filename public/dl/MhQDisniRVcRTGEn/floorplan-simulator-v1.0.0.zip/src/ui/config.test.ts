import { describe, expect, it, vi } from "vitest";
import { DEFAULT_SCENE_COLORS, DEFAULT_SIZE } from "../model/house";
import { defaultPlanFile, serializePlanFile, STORAGE_KEY } from "../model/plan";
import { DEFAULT_LABELS } from "./labels";
import { defaultLayout } from "../model/grid";
import { isHexColor, resetPlanWarnings, resolveConfig } from "./config";

describe("resolveConfig", () => {
  it("既定値", () => {
    const config = resolveConfig();
    expect(config.readonly).toBe(false);
    expect(config.storage).toEqual({ key: STORAGE_KEY, enabled: true });
    expect(config.features).toEqual({
      plans: true,
      export: true,
      print: true,
      scene: true,
      floors: 2,
      collapseBelow: 960,
    });
    expect(config.scene.autoRotate).toBe(false);
    expect(config.scene.src).toBeNull();
    expect(config.scene.colors).toEqual(DEFAULT_SCENE_COLORS);
    expect(config.labels.modePaint).toBe(DEFAULT_LABELS.modePaint);
    expect(config.initial).toBeNull();
    expect(config.catalog.furniture).toHaveLength(18);
    expect(config.catalog.rooms.length).toBe(19);
    expect(config.catalog.sizes).toHaveLength(5);
  });

  it("readonly では複数案と保存を切る", () => {
    const config = resolveConfig({ readonly: true });
    expect(config.readonly).toBe(true);
    expect(config.features.plans).toBe(false);
    expect(config.storage.enabled).toBe(false);
    // 書き出しと印刷は readonly でも残す
    expect(config.features.export).toBe(true);
    expect(config.features.print).toBe(true);
  });

  it("features を個別に切れる", () => {
    const config = resolveConfig({ features: { scene: false, print: false, floors: 1 } });
    expect(config.features.scene).toBe(false);
    expect(config.features.print).toBe(false);
    expect(config.features.floors).toBe(1);
    // 知らない階数は 2 に戻す
    expect(resolveConfig({ features: { floors: 5 as never } }).features.floors).toBe(2);
  });

  it("features.collapseBelow は 0 以上の数だけ受け取る", () => {
    expect(resolveConfig({ features: { collapseBelow: 0 } }).features.collapseBelow).toBe(0);
    expect(resolveConfig({ features: { collapseBelow: 600 } }).features.collapseBelow).toBe(600);
    // 数でないもの・負の数は既定の 960 に戻す
    expect(resolveConfig({ features: { collapseBelow: -1 } }).features.collapseBelow).toBe(960);
    expect(resolveConfig({ features: { collapseBelow: "wide" as never } }).features.collapseBelow).toBe(960);
  });

  it("scene.src は相対パスと http(s) だけ受け取る", () => {
    expect(resolveConfig({ scene: { src: "./floorplan-3d.global.js" } }).scene.src).toBe(
      "./floorplan-3d.global.js",
    );
    expect(resolveConfig({ scene: { src: "/js/floorplan-3d.global.js" } }).scene.src).toBe(
      "/js/floorplan-3d.global.js",
    );
    expect(resolveConfig({ scene: { src: "https://cdn.example.com/3d.js" } }).scene.src).toBe(
      "https://cdn.example.com/3d.js",
    );
    // そのまま <script src> になるので、scheme つきのものは http(s) 以外を捨てる
    expect(resolveConfig({ scene: { src: "javascript:alert(1)" } }).scene.src).toBeNull();
    expect(resolveConfig({ scene: { src: "JAVASCRIPT:alert(1)" } }).scene.src).toBeNull();
    // ブラウザは URL の中の改行を取り除いてから解釈するので、こちらも取り除いてから見る
    expect(resolveConfig({ scene: { src: "java\nscript:alert(1)" } }).scene.src).toBeNull();
    expect(resolveConfig({ scene: { src: "data:text/javascript,alert(1)" } }).scene.src).toBeNull();
    expect(resolveConfig({ scene: { src: "//example.com/3d.js" } }).scene.src).toBeNull();
    expect(resolveConfig({ scene: { src: "  " } }).scene.src).toBeNull();
    expect(resolveConfig({ scene: { src: 42 as never } }).scene.src).toBeNull();
  });

  it("scene.src の制御文字は、scheme を見る前に落とす", () => {
    // ブラウザは URL の前後の制御文字と空白を取り除いてから読む。
    // こちらが落とさずに見ると、制御文字を挟んで scheme の検査に当たらなくした
    // "javascript:" が、相対パスのふりをして <script src> に入ってしまう
    for (const src of [
      "\u0001javascript:alert(1)",
      "java\u0000script:alert(1)",
      "\u000bjavascript:alert(1)",
      "\u0001\u0002JAVASCRIPT:alert(1)\u007f",
      " javascript:alert(1) ",
    ]) {
      expect(resolveConfig({ scene: { src } }).scene.src, JSON.stringify(src)).toBeNull();
    }
    // 前後の空白と制御文字は落として、中身のある相対パスはそのまま通す
    expect(resolveConfig({ scene: { src: " \u0001./3d.js " } }).scene.src).toBe("./3d.js");
  });

  it("保存の鍵を差し替えられる", () => {
    expect(resolveConfig({ storage: { key: "shop:floorplan" } }).storage.key).toBe("shop:floorplan");
    expect(resolveConfig({ storage: { enabled: false } }).storage.enabled).toBe(false);
    expect(resolveConfig({ storage: { key: "  " } }).storage.key).toBe(STORAGE_KEY);
  });

  it("catalog.furniture で種類を隠し、標準寸法を足せる", () => {
    const config = resolveConfig({
      catalog: {
        furniture: {
          piano: { hidden: true },
          sofa: { presets: [{ id: "sofa-xl", name: "特大", size: { w: 2.5, d: 1, h: 0.8 } }] },
        },
      },
    });
    expect(config.catalog.furniture.some((type) => type.id === "piano")).toBe(false);
    const sofa = config.catalog.furniture.find((type) => type.id === "sofa")!;
    expect(sofa.presets.map((preset) => preset.id)).toEqual(["sofa-2", "sofa-3", "sofa-xl"]);
    // 壊れた標準寸法は足さない
    const broken = resolveConfig({
      catalog: { furniture: { sofa: { presets: [{ id: "", name: "", size: { w: 0, d: 1, h: 1 } }] } } },
    });
    expect(broken.catalog.furniture.find((type) => type.id === "sofa")!.presets).toHaveLength(2);
  });

  it("catalog.rooms / openings / sizes を差し替えられる", () => {
    const config = resolveConfig({
      catalog: {
        rooms: ["LDK", "主寝室", "屋上"],
        openings: { door: { kind: "door", style: null, name: "玄関ドア", width: 1, sill: 0, height: 2.2 } },
        sizes: [
          { id: "custom", name: "12 × 10 m", size: { width: 12, depth: 10, floors: 2 } },
          { id: "bad", name: "だめ", size: { width: 99, depth: 10, floors: 2 } },
        ],
      },
    });
    // 知らない部屋名は落とす
    expect(config.catalog.rooms).toEqual(["LDK", "主寝室"]);
    expect(config.catalog.openings.door.width).toBe(1);
    expect(config.catalog.openings.koshi.width).toBe(1.5);
    expect(config.catalog.sizes).toHaveLength(1);
    // 空の一覧は既定に戻す
    expect(resolveConfig({ catalog: { rooms: [] } }).catalog.rooms.length).toBe(19);
  });

  it("3D の色は #rrggbb だけ受け取り、ほかは既定に戻す", () => {
    expect(isHexColor("#abc")).toBe(true);
    expect(isHexColor("#aabbcc")).toBe(true);
    expect(isHexColor("red")).toBe(false);
    expect(isHexColor("javascript:alert(1)")).toBe(false);
    const config = resolveConfig({ scene: { wall: "#123456", roof: "chartreuse", autoRotate: true } });
    expect(config.scene.colors.wall).toBe("#123456");
    expect(config.scene.colors.roof).toBe(DEFAULT_SCENE_COLORS.roof);
    expect(config.scene.autoRotate).toBe(true);
  });

  it("labels は渡した分だけ差し替わる", () => {
    const config = resolveConfig({ labels: { modePaint: "ぬる" } });
    expect(config.labels.modePaint).toBe("ぬる");
    expect(config.labels.modeSelect).toBe(DEFAULT_LABELS.modeSelect);
  });

  it("plan に PlanFile・PlanDoc・JSON 文字列を渡せる", () => {
    const file = defaultPlanFile();
    expect(resolveConfig({ plan: file }).initial).toEqual(file);
    expect(resolveConfig({ plan: serializePlanFile(file) }).initial).toEqual(file);
    const wrapped = resolveConfig({ plan: file.plans[0] }).initial!;
    expect(wrapped.plans).toHaveLength(1);
    expect(wrapped.plans[0].size).toEqual(DEFAULT_SIZE);
    // 読めないものは null（呼ぶ側が既定値に戻す）
    expect(resolveConfig({ plan: "{" }).initial).toBeNull();
    expect(resolveConfig({ plan: { version: 1 } as never }).initial).toBeNull();
  });

  it("v2（見本の書き出し）は、文字列でも object でも受け取る", () => {
    const v2 = {
      version: 2,
      floors: { 1: defaultLayout(DEFAULT_SIZE, 1), 2: defaultLayout(DEFAULT_SIZE, 2) },
      furniture: [{ id: "f-1", type: "sofa", floor: 1, x: 2, z: 4.25, rotation: 0 }],
    };
    const asObject = resolveConfig({ plan: v2 as never }).initial;
    const asText = resolveConfig({ plan: JSON.stringify(v2) }).initial;
    expect(asObject).not.toBeNull();
    expect(asObject!.version).toBe(3);
    expect(asText).toEqual(asObject);
  });

  it("読めない plan は、理由を添えて 1 度だけ断りを出す", () => {
    resetPlanWarnings();
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    resolveConfig({ plan: "{" });
    expect(warn).toHaveBeenCalledTimes(1);
    expect(String(warn.mock.calls[0][0])).toContain("config.plan");
    // 描き直すたびに同じ断りを繰り返さない
    resolveConfig({ plan: "{" });
    expect(warn).toHaveBeenCalledTimes(1);
    // 別の壊れ方なら、その理由で 1 度出す
    resolveConfig({ plan: { id: "plan-1" } as never });
    expect(warn).toHaveBeenCalledTimes(2);
    expect(String(warn.mock.calls[1][0])).toContain("PlanDoc");
    warn.mockRestore();
    resetPlanWarnings();
  });

  it("建具の差し替えは、範囲の外の寸法を受け取らない", () => {
    const config = resolveConfig({
      catalog: {
        openings: {
          door: { kind: "door", style: null, name: "玄関ドア", width: 99, sill: 0, height: 2.2 },
          // 下端 + 高さが 1 階の天井 2.7 m を超える組み合わせ
          koshi: { kind: "window", style: "koshi", name: "高窓", width: 1.5, sill: 2, height: 1.2 },
          // 形の違うもの
          sliding: { kind: "swing", name: "", width: "wide", sill: -1, height: 0 } as never,
        },
      },
    });
    // 名前は通るが、範囲の外の幅は元のまま
    expect(config.catalog.openings.door.name).toBe("玄関ドア");
    expect(config.catalog.openings.door.width).toBe(0.75);
    expect(config.catalog.openings.door.height).toBe(2.2);
    expect(config.catalog.openings.koshi).toMatchObject({ name: "高窓", sill: 0.9, height: 1.2 });
    expect(config.catalog.openings.sliding).toEqual({
      kind: "sliding",
      style: null,
      name: "引き戸",
      width: 1.5,
      sill: 0,
      height: 2,
    });
  });

  it("コールバックはそのまま持ち越す", () => {
    const onChange = vi.fn();
    expect(resolveConfig({ onChange }).onChange).toBe(onChange);
    expect(resolveConfig().onChange).toBeUndefined();
  });
});
