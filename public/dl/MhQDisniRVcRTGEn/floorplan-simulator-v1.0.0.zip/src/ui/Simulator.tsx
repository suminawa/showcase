/*
 * 売り物: 状態を 1 つだけ持つ入れ物。間取り図（Editor）と操作列（Panel）と 3D（Scene）に props で配る。
 * だから壁や家具を動かしている最中も、3D がそのまま追いつく。
 * 保存は localStorage だけで、サーバーへは送らない。書き出しは 300ms まとめ。
 */
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from "react";

import { defaultSeed, presetSeed } from "../model/catalog";
import { addExterior, resizeExterior, type ExteriorKind, type ExteriorSide } from "../model/exterior";
import { resizeFixture, type FixtureKind } from "../model/fixtures";
import { addFurniture, resizeFurniture, type PlacedFurniture } from "../model/furniture";
import { addRoom, labelAnchor, renameRoom, type RoomLabel } from "../model/grid";
import {
  ceilingOf,
  clampPlanSize,
  floorsOf,
  type Floor,
  type FloorMode,
  type LightingMode,
  type PlanSize,
  type ViewMode,
} from "../model/house";
import { resizeOpening, type OpeningPresetId } from "../model/openings";
import {
  activePlan,
  addPlan,
  defaultPlanFile,
  duplicatePlan,
  MAX_PLANS,
  parsePlanJson,
  removePlan,
  renamePlan,
  resizePlan,
  selectPlan,
  serializePlanFile,
  updateFloor,
  updatePlan,
  type FloorPlan,
  type PlanDoc,
  type PlanFile,
} from "../model/plan";
import { migrate } from "../model/migrate";
import { loadScene, type SceneApi, type SceneComponent } from "../scene/loader";
import { resolveConfig, type FloorplanConfig, type SelectionTarget } from "./config";
import { Editor, nudge, removeSelection, rotateSelection, type EditorMode } from "./Editor";
import { downloadBlob, exportFileName, renderPng, snapshotCanvas } from "./export";
import { renderPlanMarkup } from "./offscreen";
import { Panel } from "./Panel";
import { serializePlanSvg } from "./planStyle";
import { openPrintSheet, printSheetHtml, type PrintSheet } from "./print";

/** 最後の変更から、これだけ経ってから書き出す（ms） */
const SAVE_DELAY = 300;
/** 断りを出しておく長さ（ms） */
const NOTICE_MS = 2000;

export type SimulatorApi = {
  getFile(): PlanFile;
  setFile(file: PlanFile | PlanDoc | string): void;
  getActivePlan(): PlanDoc;
  setActivePlan(id: string): void;
  exportPng(target?: "plan" | "scene" | "both"): Promise<Blob | null>;
  print(): boolean;
  subscribe(listener: (file: PlanFile) => void): () => void;
};

export type SimulatorProps = {
  config?: FloorplanConfig;
  className?: string;
  handleRef?: (api: SimulatorApi) => void;
};

function hasWebgl(): boolean {
  if (typeof window === "undefined") return false;
  if (typeof window.WebGLRenderingContext === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("webgl2") ?? canvas.getContext("webgl");
    if (!ctx) return false;
    // 判定専用のコンテキストなので、持ち続けずすぐ手放す
    ctx.getExtension("WEBGL_lose_context")?.loseContext();
    return true;
  } catch {
    return false;
  }
}

/**
 * ルート要素の幅（px）。狭い画面で 3D をたたむかどうかの判断に使う。
 * ResizeObserver が無い環境（古い WebView・jsdom）と、まだ幅の測れないとき（0）は
 * 窓の幅で代える ── 0 のせいで広い画面まで折りたたまれないように。
 */
function useRootWidth(ref: RefObject<HTMLElement | null>, enabled: boolean): number {
  const [width, setWidth] = useState(() => (typeof window === "undefined" ? 0 : window.innerWidth));
  // 最初の 1 回は自分で測る。ResizeObserver の呼び返しを待つと、
  // 広い窓の中の狭い枠（サイドバーの中の埋め込みなど）で 3D が 1 拍だけ開いてしまう
  useLayoutEffect(() => {
    if (!enabled) return;
    const element = ref.current;
    const measured = element?.getBoundingClientRect().width ?? 0;
    // まだ measure できない（jsdom・display:none）ときは窓の幅で代える
    setWidth(measured > 0 ? measured : window.innerWidth);
    if (!element || typeof ResizeObserver !== "function") return;
    const observer = new ResizeObserver((entries) => {
      const next = entries[0]?.contentRect.width ?? 0;
      setWidth(next > 0 ? next : window.innerWidth);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, [enabled, ref]);
  return width;
}

export function Simulator({ config: raw, className, handleRef }: SimulatorProps) {
  const config = useMemo(() => resolveConfig(raw), [raw]);
  const rootRef = useRef<HTMLDivElement | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const listeners = useRef(new Set<(file: PlanFile) => void>());
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pending = useRef<PlanFile | null>(null);

  const [file, setFileState] = useState<PlanFile>(() => config.initial ?? defaultPlanFile());
  const [floor, setFloor] = useState<Floor>(1);
  const [floorMode, setFloorMode] = useState<FloorMode>("1f");
  const [view, setView] = useState<ViewMode>("orbit");
  const [lighting, setLighting] = useState<LightingMode>("day");
  const [mode, setMode] = useState<EditorMode>("select");
  const [zoom, setZoom] = useState(1);
  const [showDimensions, setShowDimensions] = useState(false);
  const [selection, setSelection] = useState<SelectionTarget>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [openingPreset, setOpeningPreset] = useState<OpeningPresetId>("door");
  const [fixtureKind, setFixtureKind] = useState<FixtureKind>("closet");
  const [exteriorKind, setExteriorKind] = useState<ExteriorKind>("balcony");
  const [exteriorSide, setExteriorSide] = useState<ExteriorSide>("s");
  const [furniturePick, setFurniturePick] = useState<{ type: PlacedFurniture["type"]; preset: string }>(
    () => {
      const seed = defaultSeed(config.catalog.furniture[0].id);
      return { type: seed.type, preset: seed.preset ?? "" };
    },
  );
  const [reducedMotion, setReducedMotion] = useState(false);
  const [support, setSupport] = useState<"checking" | "ok" | "none">("checking");
  const [Scene, setScene] = useState<SceneComponent | null>(null);
  // 3D の取っ手は ref ではなく状態で持つ。ref のままだと、用意ができても描き直しが起きず、
  // 「3D を PNG で」「両方を 1 枚で」が押せないままになる
  const [sceneApi, setSceneApi] = useState<SceneApi | null>(null);
  // 3D の束が見つからなかった（置いていないサイト、読み込みに失敗した）
  const [noScene, setNoScene] = useState(false);
  // 狭い画面では 3D をたたんでおき、「3D で見る」を押したときだけ開く
  const [sceneOpen, setSceneOpen] = useState(false);

  const doc = activePlan(file);
  const collapseBelow = config.features.scene ? config.features.collapseBelow : 0;
  const rootWidth = useRootWidth(rootRef, collapseBelow > 0);
  const collapsed = collapseBelow > 0 && rootWidth < collapseBelow;
  // 3D の束を読むのは、枠を出すと決まってから
  const wantScene = config.features.scene && (!collapsed || sceneOpen);
  // R3F は unmount の 0.5 秒あとに WebGL の context を自分で捨てる。たたんだあとに届く
  // webglcontextlost は「この環境では使えない」の合図ではないので、使っている間だけ受け取る
  const wantSceneRef = useRef(wantScene);
  wantSceneRef.current = wantScene;
  const handleContextLost = useCallback(() => {
    if (wantSceneRef.current) setSupport("none");
  }, []);

  /**
   * 変更を 1 か所で受ける。保存の予約・コールバック・購読者への配りはここだけ。
   * 呼ばれるのは必ず操作の合図の中（描画の途中では呼ばない）ので、副作用をここに置いてよい。
   */
  const commit = useCallback(
    (next: PlanFile) => {
      pending.current = next;
      setFileState(next);
      config.onChange?.(next);
      listeners.current.forEach((listener) => listener(next));
    },
    [config],
  );

  // 3D の側から渡される取っ手。参照が変わらないようにして、Scene の効果が毎回走るのを防ぐ
  const handleSceneReady = useCallback((api: SceneApi) => setSceneApi(api), []);

  const notify = useCallback((message: string) => {
    setNotice(message);
    if (noticeTimer.current !== null) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(null), NOTICE_MS);
  }, []);

  // WebGL と「動きを減らす」設定は、描いたあとに 1 度だけ調べる（サーバーとの食い違いを避ける）。
  // 設定を変えられたら追いかける
  useEffect(() => {
    setSupport(hasWebgl() ? "ok" : "none");
    // jsdom や古い WebView には matchMedia が無い。無ければ「減らさない」で続ける
    if (typeof window.matchMedia !== "function") return;
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(query.matches);
    const onChange = (event: MediaQueryListEvent) => setReducedMotion(event.matches);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, []);

  // 保存されているものの読み込みは、1 つの鍵につき 1 回だけ。
  // 設定を書き換えるたびに読み直すと、300ms の書き出し待ちの間の編集が巻き戻る
  const loadedKey = useRef<string | null>(null);
  const hasInitial = config.initial !== null;
  useEffect(() => {
    if (hasInitial || !config.storage.enabled) return;
    if (loadedKey.current === config.storage.key) return;
    loadedKey.current = config.storage.key;
    try {
      const stored = parsePlanJson(window.localStorage.getItem(config.storage.key));
      if (stored) setFileState(stored);
    } catch {
      // 読めなくても既定値で続けられる
    }
  }, [hasInitial, config.storage.enabled, config.storage.key]);

  // 3D の束は、使うと決まってから読む（狭い画面ではボタンを押してから）。
  // 見つからなければ待ち続けず、断りを出して 2D だけで続ける
  useEffect(() => {
    if (!wantScene || support !== "ok") return;
    let alive = true;
    const aborter = new AbortController();
    void loadScene(window, aborter.signal, config.scene.src).then((component) => {
      if (!alive) return;
      if (component) setScene(() => component);
      else setNoScene(true);
    });
    return () => {
      alive = false;
      aborter.abort();
    };
  }, [wantScene, support, config.scene.src]);

  // 3D の枠が無くなったら（閉じた・狭くなってたたんだ・コンテキストを失った）取っ手を離す。
  // 持ったままだと「3D を PNG で」が押せて、真っ白な PNG が落ちてしまう。
  // 開き直したときは Scene の onReady がもう一度呼ばれるので、取っ手は戻る
  useEffect(() => {
    if (!wantScene || support !== "ok") setSceneApi(null);
  }, [wantScene, support]);

  // 保存の宛先は、画面を閉じるときにも要る。最後の値を ref で持っておく
  const storage = useRef(config.storage);
  storage.current = config.storage;

  const writeFile = useCallback((value: PlanFile) => {
    if (!storage.current.enabled) return;
    try {
      window.localStorage.setItem(storage.current.key, serializePlanFile(value));
    } catch {
      // 保存できなくても編集は続けられる
    }
  }, []);

  /** 待っている保存をその場で書き出す */
  const flushSave = useCallback(() => {
    if (saveTimer.current !== null) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    const value = pending.current;
    pending.current = null;
    if (value !== null) writeFile(value);
  }, [writeFile]);

  // 保存は待ち時間のあと 1 回だけ。待っている間に画面を離れたらその場で書き出す
  useEffect(() => {
    if (!config.storage.enabled) return;
    const waiting = pending.current;
    if (waiting !== null) {
      if (saveTimer.current !== null) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        saveTimer.current = null;
        pending.current = null;
        writeFile(waiting);
      }, SAVE_DELAY);
    }
    const onVisibility = () => {
      if (document.hidden) flushSave();
    };
    window.addEventListener("pagehide", flushSave);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      window.removeEventListener("pagehide", flushSave);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [file, config.storage.enabled, flushSave, writeFile]);

  // 画面から外れるとき（destroy / unmount）も、待っている保存を捨てずに書き出す
  useEffect(() => {
    return () => flushSave();
  }, [flushSave]);

  const changeFloorPlan = useCallback(
    (next: FloorPlan) => {
      commit(updatePlan(file, doc.id, updateFloor(doc, floor, next)));
    },
    [commit, doc, file, floor],
  );

  const select = useCallback(
    (target: SelectionTarget) => {
      setSelection(target);
      config.onSelect?.(target);
    },
    [config],
  );

  // キーボード。編集画面にフォーカスが無いとき・入力中のキーは横取りしない
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (!rootRef.current?.contains(document.activeElement)) return;
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      if (event.key === "Escape") {
        select(null);
        return;
      }
      if (config.readonly || !selection) return;
      const step = 0.25;
      const moves: Record<string, [number, number]> = {
        ArrowLeft: [-step, 0],
        ArrowRight: [step, 0],
        ArrowUp: [0, -step],
        ArrowDown: [0, step],
      };
      const move = moves[event.key];
      if (move) {
        event.preventDefault();
        changeFloorPlan(nudge(doc, floor, selection, move[0], move[1]));
        return;
      }
      if (event.key === "r" || event.key === "R") {
        event.preventDefault();
        changeFloorPlan(rotateSelection(doc, floor, selection));
        return;
      }
      if (event.key === "Delete" || event.key === "Backspace") {
        event.preventDefault();
        changeFloorPlan(removeSelection(doc, floor, selection));
        select(null);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [changeFloorPlan, config.readonly, doc, floor, select, selection]);

  const exportPng = useCallback(
    async (target: "plan" | "scene" | "both" = "plan") => {
      // WebGL は preserveDrawingBuffer を付けていないので、読む直前に描き直し、
      // その場で 2D の canvas へ写し取る。間取り図の読み込みを待ってからでは中身が消えている
      let shot: HTMLCanvasElement | null = null;
      if (target !== "plan" && sceneApi) {
        sceneApi.renderNow();
        shot = snapshotCanvas(sceneApi.canvas, document);
      }
      const blob = await renderPng({
        target,
        svg: svgRef.current,
        canvas: shot,
        background: "#ffffff",
        doc: document,
      });
      if (!blob) return null;
      const name = exportFileName(target, doc.name);
      config.onExport?.({ kind: "png", target, blob, name });
      downloadBlob(blob, name, document);
      return blob;
    },
    [config, doc.name, sceneApi],
  );

  const print = useCallback(() => {
    // 1 枚には全部の階の表が載るので、図面もその階のぶんだけ出す。
    // 画面に出していない階は、その場で 1 回だけ描いて文字列にする
    const sheets: PrintSheet[] = floorsOf(doc.size).map((sheet) => ({
      floor: sheet,
      markup:
        sheet === floor && svgRef.current
          ? serializePlanSvg(svgRef.current)
          : renderPlanMarkup(
              document,
              {
                doc,
                floor: sheet,
                mode: "select",
                zoom: 1,
                selection: null,
                showDimensions,
                readonly: true,
                labels: config.labels,
                activeRoomId: null,
                openingPreset,
                fixtureKind,
              },
              // 色は画面に出ている図面から読む（document の外では --fp-* が読めない）
              svgRef.current,
            ),
    }));
    const opened = openPrintSheet(printSheetHtml(doc, sheets, config.labels), window);
    if (!opened) notify(config.labels.popupBlocked);
    return opened;
  }, [config.labels, doc, fixtureKind, floor, notify, openingPreset, showDimensions]);

  /*
   * 取っ手を親（mount / React ラッパー）へ渡す。
   * 中身は毎回の描画で入れ替わるが、取っ手そのものは 1 つのまま（参照が変わらない）ようにする ──
   * mount は root.render の直後に取っ手を返すので、あとから作り直されると困る。
   * 渡すのは useLayoutEffect（flushSync の中で必ず走る）。
   */
  const latest = useRef({ file, exportPng, print, commit });
  latest.current = { file, exportPng, print, commit };

  const api = useMemo<SimulatorApi>(
    () => ({
      getFile: () => latest.current.file,
      setFile: (next) => {
        const parsed =
          typeof next === "string" || (next as PlanFile).version === 3
            ? migrate(next as PlanFile | string)
            : migrate({ version: 3, plans: [next as PlanDoc], activeId: (next as PlanDoc).id });
        if (parsed) latest.current.commit(parsed);
      },
      getActivePlan: () => activePlan(latest.current.file),
      setActivePlan: (id) => latest.current.commit(selectPlan(latest.current.file, id)),
      exportPng: (target = "plan") => latest.current.exportPng(target),
      print: () => latest.current.print(),
      subscribe: (listener) => {
        listeners.current.add(listener);
        return () => {
          listeners.current.delete(listener);
        };
      },
    }),
    [],
  );

  useLayoutEffect(() => {
    handleRef?.(api);
  }, [api, handleRef]);

  useEffect(() => {
    return () => {
      if (noticeTimer.current !== null) clearTimeout(noticeTimer.current);
    };
  }, []);

  const plan = doc.floors[floor];
  const selectedRoomLabel =
    selection?.kind === "room"
      ? plan.layout.rooms.find((room) => room.id === selection.id)?.label ?? null
      : null;

  const panel = (
    <Panel
      config={config}
      file={file}
      doc={doc}
      floor={floor}
      mode={mode}
      floorMode={floorMode}
      view={view}
      lighting={lighting}
      showDimensions={showDimensions}
      selection={selection}
      selectedRoomLabel={selectedRoomLabel}
      openingPreset={openingPreset}
      fixtureKind={fixtureKind}
      exteriorKind={exteriorKind}
      exteriorSide={exteriorSide}
      furniturePick={furniturePick}
      notice={notice}
      sceneReady={Scene !== null && sceneApi !== null}
      onMode={setMode}
      onFloor={(next) => {
        setFloor(next);
        setFloorMode(next === 1 ? "1f" : "2f");
        select(null);
      }}
      onFloorMode={setFloorMode}
      onView={setView}
      onLighting={setLighting}
      onToggleDimensions={() => setShowDimensions((value) => !value)}
      onSize={(size: PlanSize) => {
        // 外皮を変えるとマスも家具も動くので、選んでいたものを離す
        select(null);
        commit(updatePlan(file, doc.id, resizePlan(doc, clampPlanSize(size))));
      }}
      onNewRoom={() => {
        const added = addRoom(plan.layout, config.catalog.rooms[0]);
        changeFloorPlan({ ...plan, layout: added.layout });
        select({ kind: "room", id: added.id });
        setMode("paint");
      }}
      onRoomLabel={(label: RoomLabel) => {
        if (selection?.kind !== "room") return;
        changeFloorPlan({ ...plan, layout: renameRoom(plan.layout, selection.id, label) });
      }}
      onOpeningPreset={(id) => {
        setOpeningPreset(id);
        setMode("opening");
      }}
      onFixtureKind={(kind) => {
        setFixtureKind(kind);
        setMode("fixture");
      }}
      onFurniturePick={setFurniturePick}
      onPlaceFurniture={() => {
        const at: [number, number] =
          selection?.kind === "room"
            ? labelAnchor(doc.size, plan.layout, selection.id)
            : [doc.size.width / 2, doc.size.depth / 2];
        const seed = presetSeed(furniturePick.type, furniturePick.preset);
        const next = addFurniture(doc.size, plan.furniture, seed, at);
        changeFloorPlan({ ...plan, furniture: next });
        select({ kind: "furniture", id: next[next.length - 1].id });
      }}
      onExterior={(kind, side) => {
        const along = side === "n" || side === "s" ? doc.size.width / 2 : doc.size.depth / 2;
        const next = addExterior(doc.size, plan.exterior, kind, side, along);
        changeFloorPlan({ ...plan, exterior: next });
        select({ kind: "exterior", id: next[next.length - 1].id });
      }}
      onExteriorKind={setExteriorKind}
      onExteriorSide={setExteriorSide}
      onResizeFurniture={(patch) => {
        if (selection?.kind !== "furniture") return;
        changeFloorPlan({
          ...plan,
          furniture: resizeFurniture(doc.size, plan.furniture, selection.id, patch),
        });
      }}
      onResizeFixture={(patch) => {
        if (selection?.kind !== "fixture") return;
        changeFloorPlan({ ...plan, fixtures: resizeFixture(doc.size, plan.fixtures, selection.id, patch) });
      }}
      onResizeOpening={(patch) => {
        if (selection?.kind !== "opening") return;
        const next = resizeOpening(
          plan.layout,
          doc.size,
          ceilingOf(doc.size, floor),
          plan.openings,
          selection.id,
          patch,
        );
        // 壁からはみ出す・ほかの建具と重なる寸法は受け取らず、断りだけ出す
        if (next === plan.openings) {
          notify(config.labels.noFit);
          return;
        }
        changeFloorPlan({ ...plan, openings: next });
      }}
      onResizeExterior={(patch) => {
        if (selection?.kind !== "exterior") return;
        changeFloorPlan({ ...plan, exterior: resizeExterior(doc.size, plan.exterior, selection.id, patch) });
      }}
      onRotate={() => changeFloorPlan(rotateSelection(doc, floor, selection))}
      onRemove={() => {
        changeFloorPlan(removeSelection(doc, floor, selection));
        select(null);
      }}
      onPlanAdd={() => {
        if (file.plans.length >= MAX_PLANS) {
          notify(config.labels.plansFull);
          return;
        }
        commit(addPlan(file));
      }}
      onPlanSelect={(id) => {
        commit(selectPlan(file, id));
        select(null);
      }}
      onPlanDuplicate={() => {
        if (file.plans.length >= MAX_PLANS) {
          notify(config.labels.plansFull);
          return;
        }
        commit(duplicatePlan(file, doc.id));
      }}
      onPlanRename={(name) => commit(renamePlan(file, doc.id, name))}
      onPlanRemove={() => {
        select(null);
        commit(removePlan(file, doc.id));
      }}
      onExport={(target) => void exportPng(target)}
      onPrint={print}
      onReset={() => {
        commit(defaultPlanFile());
        select(null);
      }}
    />
  );

  let stage: ReactNode = null;
  if (config.features.scene) {
    if (support === "none") {
      stage = (
        <div className="fp-fallback">
          <p className="fp-fallback-text">{config.labels.noWebgl}</p>
        </div>
      );
    } else if (!wantScene) {
      // 狭い画面。押されるまで枠も出さず、3D の束も読まない
      stage = (
        <div className="fp-stage-collapsed">
          <button
            type="button"
            className="fp-button"
            aria-expanded={false}
            onClick={() => setSceneOpen(true)}
          >
            {config.labels.open3d}
          </button>
        </div>
      );
    } else {
      stage = (
        <div className="fp-stage-open">
          {collapsed && (
            <div className="fp-editor-row">
              <button
                type="button"
                className="fp-button"
                aria-expanded={true}
                onClick={() => setSceneOpen(false)}
              >
                {config.labels.close3d}
              </button>
            </div>
          )}
          <div className="fp-stage">
            {Scene ? (
              <Scene
                doc={doc}
                activeFloor={floor}
                floorMode={floorMode}
                view={view}
                lighting={lighting}
                colors={config.scene.colors}
                autoRotate={config.scene.autoRotate}
                reducedMotion={reducedMotion}
                selection={selection}
                onContextLost={handleContextLost}
                onReady={handleSceneReady}
              />
            ) : (
              <p className="fp-loading">{noScene ? config.labels.noScene : config.labels.building}</p>
            )}
          </div>
        </div>
      );
    }
  }

  return (
    <div className={className ? `fp ${className}` : "fp"} ref={rootRef}>
      {panel}
      <div className="fp-workspace">
        {stage}
        <Editor
          doc={doc}
          floor={floor}
          mode={mode}
          zoom={zoom}
          selection={selection}
          showDimensions={showDimensions}
          readonly={config.readonly}
          labels={config.labels}
          activeRoomId={selection?.kind === "room" ? selection.id : null}
          openingPreset={openingPreset}
          fixtureKind={fixtureKind}
          onSelect={select}
          onFloorChange={changeFloorPlan}
          onNotice={notify}
          onZoom={setZoom}
          svgRef={svgRef}
        />
      </div>
      <p className="fp-caption">{config.labels.caption}</p>
    </div>
  );
}
