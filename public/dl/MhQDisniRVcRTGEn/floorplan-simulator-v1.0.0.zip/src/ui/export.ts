/**
 * 売り物: PNG の書き出し。外部の画像もフォントの埋め込みも使わない。
 * 間取り図は SVG を XMLSerializer → data URL → Image → canvas に描く。
 * 3D は WebGL の canvas をそのまま読む（preserveDrawingBuffer は付けず、
 * 書き出す回だけ描き直してから読む。呼ぶ側の仕事）。
 */
import { type ExportTarget } from "./config";
import { serializePlanSvg } from "./planStyle";

/** 書き出す画像の横幅（px 相当） */
export const EXPORT_WIDTH = 2000;

/** ファイル名に使えない記号を落とす。中身が無くなったら「案」 */
export function sanitizeName(name: string): string {
  const cleaned = name
    // ファイル名に使えない記号と制御文字を落とす
    .replace(/[\u0000-\u001f<>:"/\\|?*]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 40);
  // 「////」のように区切りしか無い名前は、落としたあとが「----」になるので名前として使わない
  if (/^[-\s]*$/.test(cleaned)) return "案";
  return cleaned;
}

export function exportFileName(target: ExportTarget, planName: string): string {
  const name = sanitizeName(planName);
  if (target === "scene") return `間取り-${name}-3D.png`;
  if (target === "both") return `間取り-${name}-両方.png`;
  return `間取り-${name}.png`;
}

/**
 * SVG を data URL にする。xmlns と、いまの色を入れた <style> はここで足す ──
 * data URL の中の SVG には外部のスタイルシートが効かないので、
 * 足さないと塗りが黒・線が無しで描かれてしまう。
 */
export function svgToDataUrl(svg: SVGSVGElement): string {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(serializePlanSvg(svg))}`;
}

/**
 * WebGL の canvas を、その場で 2D の canvas へ写し取る。
 * preserveDrawingBuffer を付けていないので、描き直したあと await を 1 つでも挟むと
 * 中身が消える（間取り図の読み込みを待つあいだに、3D の側が真っ白になる）。
 * 描き直した直後に、同期のまま呼ぶこと。
 */
export function snapshotCanvas(canvas: HTMLCanvasElement, doc: Document): HTMLCanvasElement | null {
  if (!canvas.width || !canvas.height) return null;
  const copy = doc.createElement("canvas");
  copy.width = canvas.width;
  copy.height = canvas.height;
  const ctx = copy.getContext("2d");
  if (!ctx) return null;
  ctx.drawImage(canvas, 0, 0);
  return copy;
}

export type RenderInput = {
  target: ExportTarget;
  svg: SVGSVGElement | null;
  canvas: HTMLCanvasElement | null;
  background: string;
  doc: Document;
  width?: number;
};

// win: Window だけだと Image が型に無い（lib.dom では Image は window ではなく
// globalThis 側の宣言）。実際に渡ってくるのは defaultView の型なので合わせる
function loadImage(url: string, win: Window & typeof globalThis): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const image = new win.Image();
    image.onload = () => resolve(image);
    image.onerror = () => resolve(null);
    image.src = url;
  });
}

/**
 * PNG を作る。target が "both" のときは、間取り図と 3D を横に並べた 1 枚にする。
 * 書き出す相手が無いとき（3D を読み込んでいない等）は null。
 */
export async function renderPng(input: RenderInput): Promise<Blob | null> {
  const win = input.doc.defaultView;
  if (!win) return null;
  const width = input.width ?? EXPORT_WIDTH;
  const sources: { image: HTMLImageElement | HTMLCanvasElement; w: number; h: number }[] = [];

  if (input.target !== "scene" && input.svg) {
    const box = input.svg.viewBox.baseVal;
    const image = await loadImage(svgToDataUrl(input.svg), win);
    if (image) sources.push({ image, w: box.width || image.width, h: box.height || image.height });
  }
  if (input.target !== "plan" && input.canvas) {
    sources.push({ image: input.canvas, w: input.canvas.width, h: input.canvas.height });
  }
  if (sources.length === 0) return null;

  const gap = sources.length > 1 ? 40 : 0;
  const totalRatio = sources.reduce((sum, source) => sum + source.w / source.h, 0);
  const height = Math.round((width - gap * (sources.length - 1)) / totalRatio);
  const canvas = input.doc.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.fillStyle = input.background;
  ctx.fillRect(0, 0, width, height);
  let x = 0;
  for (const source of sources) {
    const w = Math.round(height * (source.w / source.h));
    ctx.drawImage(source.image, x, 0, w, height);
    x += w + gap;
  }
  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob), "image/png");
  });
}

/** blob をファイルとして落とす。a タグは押したらすぐ片づける */
export function downloadBlob(blob: Blob, name: string, doc: Document): void {
  const url = URL.createObjectURL(blob);
  const anchor = doc.createElement("a");
  anchor.href = url;
  anchor.download = name;
  doc.body.append(anchor);
  anchor.click();
  anchor.remove();
  // 押した直後に片づけると、保存が始まる前に url が消えて落ちないブラウザがある。
  // 1 拍おいてから手放す
  setTimeout(() => URL.revokeObjectURL(url), 0);
}
