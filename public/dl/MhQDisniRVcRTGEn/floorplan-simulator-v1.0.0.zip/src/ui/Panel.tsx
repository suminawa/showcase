/*
 * 売り物: 操作列。押されたことを親（Simulator）へ返すだけで、間取りは持たない。
 * 持つのは「打ちかけの数字」だけ ── 1 文字ごとに親へ渡すと、"12" の "1" の時点で
 * 外皮が 4 m に丸められて部屋が消えてしまうため。
 * ボタンはすべて素の <button type="button"> なので、3D を読み終える前でも押せる。
 */
import { useState, type ReactNode } from "react";

import { clampSize, furnitureType, presetSeed, tvSeed, tvStandHint, type FurnitureType } from "../model/catalog";
import { formatLength, formatSize3, snapValue } from "../model/dimensions";
import {
  EXTERIOR_MAX_DEPTH,
  EXTERIOR_MIN_DEPTH,
  EXTERIOR_MIN_LENGTH,
  EXTERIOR_PRESETS,
  sideLength,
  type ExteriorKind,
  type ExteriorPart,
  type ExteriorPatch,
  type ExteriorSide,
} from "../model/exterior";
import {
  FIXTURE_LIMITS,
  FIXTURE_PRESETS,
  STAIRS_MAX_STEPS,
  STAIRS_MIN_STEPS,
  stepsOf,
  type Fixture,
  type FixtureKind,
  type FixturePatch,
} from "../model/fixtures";
import { round2, type PlacedFurniture, type Size3 } from "../model/furniture";
import { type RoomLabel } from "../model/grid";
import {
  ceilingOf,
  floorsOf,
  HEIGHT_SNAP,
  SIZE_MAX,
  SIZE_MIN,
  SNAP,
  type Floor,
  type FloorMode,
  type LightingMode,
  type PlanSize,
  type ViewMode,
} from "../model/house";
import {
  OPENING_MAX_WIDTH,
  OPENING_MIN_HEIGHT,
  OPENING_MIN_WIDTH,
  type Opening,
  type OpeningPatch,
  type OpeningPresetId,
} from "../model/openings";
import { type PlanDoc, type PlanFile } from "../model/plan";
import { type ResolvedConfig, type SelectionTarget } from "./config";
import { type EditorMode } from "./Editor";
import { type FloorplanLabels } from "./labels";

/** 家具の寸法を変えるときに親へ渡すもの。preset を外すと「任意寸法にした」の印になる */
export type FurniturePatch = Partial<Size3> & { preset?: string | null; inch?: number | null };

/** テレビのインチの範囲。43 型より小さいものは家具として置く意味が薄い */
const TV_MIN_INCH = 43;
const TV_MAX_INCH = 100;
const TV_FALLBACK_INCH = 55;

export type PanelProps = {
  config: ResolvedConfig;
  file: PlanFile;
  doc: PlanDoc;
  floor: Floor;
  mode: EditorMode;
  floorMode: FloorMode;
  view: ViewMode;
  lighting: LightingMode;
  showDimensions: boolean;
  selection: SelectionTarget;
  selectedRoomLabel: RoomLabel | null;
  openingPreset: OpeningPresetId;
  fixtureKind: FixtureKind;
  exteriorKind: ExteriorKind;
  exteriorSide: ExteriorSide;
  furniturePick: { type: PlacedFurniture["type"]; preset: string };
  notice: string | null;
  sceneReady: boolean;
  onMode: (mode: EditorMode) => void;
  onFloor: (floor: Floor) => void;
  onFloorMode: (mode: FloorMode) => void;
  onView: (view: ViewMode) => void;
  onLighting: (mode: LightingMode) => void;
  onToggleDimensions: () => void;
  onSize: (size: PlanSize) => void;
  onNewRoom: () => void;
  onRoomLabel: (label: RoomLabel) => void;
  onOpeningPreset: (id: OpeningPresetId) => void;
  onFixtureKind: (kind: FixtureKind) => void;
  onFurniturePick: (pick: { type: PlacedFurniture["type"]; preset: string }) => void;
  onPlaceFurniture: () => void;
  onExterior: (kind: ExteriorKind, side: ExteriorSide) => void;
  onExteriorKind: (kind: ExteriorKind) => void;
  onExteriorSide: (side: ExteriorSide) => void;
  onResizeFurniture: (patch: FurniturePatch) => void;
  onResizeFixture: (patch: FixturePatch) => void;
  onResizeOpening: (patch: OpeningPatch) => void;
  onResizeExterior: (patch: ExteriorPatch) => void;
  onRotate: () => void;
  onRemove: () => void;
  onPlanAdd: () => void;
  onPlanSelect: (id: string) => void;
  onPlanDuplicate: () => void;
  onPlanRename: (name: string) => void;
  onPlanRemove: () => void;
  onExport: (target: "plan" | "scene" | "both") => void;
  onPrint: () => void;
  onReset: () => void;
};

const SIDES: { value: ExteriorSide; label: string }[] = [
  { value: "n", label: "北" },
  { value: "e", label: "東" },
  { value: "s", label: "南" },
  { value: "w", label: "西" },
];

/**
 * 数字の入力。打っている間は手元で預かり、Enter か枠から外れたときに 1 回だけ親へ渡す。
 * 数にならない打ちかけ（空・"-" だけ）は捨てて、いまの値に戻す。
 */
function NumberField({
  label,
  value,
  min,
  max,
  step,
  format = String,
  inputMode = "decimal",
  onCommit,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  /** 打っていないときの見せ方。寸法の欄は小数 2 桁で出す */
  format?: (value: number) => string;
  inputMode?: "decimal" | "numeric";
  onCommit: (value: number) => void;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const commit = () => {
    if (draft === null) return;
    const parsed = Number(draft);
    setDraft(null);
    if (draft.trim() === "" || !Number.isFinite(parsed)) return;
    if (parsed !== value) onCommit(parsed);
  };
  return (
    <label className="fp-field">
      {label}
      <input
        className="fp-input"
        type="number"
        inputMode={inputMode}
        step={step}
        min={min}
        max={max}
        value={draft ?? format(value)}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            commit();
          }
          // 打ちかけを捨てて、いまの値に戻す
          if (event.key === "Escape") setDraft(null);
        }}
      />
    </label>
  );
}

/**
 * 「寸法」モードで選んだものの下に開く入力欄。読み上げには「{名前} の寸法」と伝える。
 * Enter で送信されないよう（NumberField が打ち終わりに 1 回だけ親へ渡すので）既定の動きは止める。
 */
function SizeForm({ label, children }: { label: string; children: ReactNode }) {
  return (
    <form className="fp-size-form" aria-label={label} onSubmit={(event) => event.preventDefault()}>
      {children}
    </form>
  );
}

function Toggle<T extends string | number>({
  value,
  current,
  label,
  onPick,
}: {
  value: T;
  current: T;
  label: string;
  onPick: (value: T) => void;
}) {
  return (
    <button
      type="button"
      className="fp-button"
      aria-pressed={current === value}
      onClick={() => onPick(value)}
    >
      {label}
    </button>
  );
}

/** 建具の種類と様式から、標準寸法の名前を引くための id */
function openingPresetId(item: Opening): OpeningPresetId {
  if (item.kind === "window") return item.style === "hakidashi" ? "hakidashi" : "koshi";
  return item.kind;
}

/**
 * 家具の寸法。テレビだけはインチから画面の大きさが決まるので、幅・奥行きの代わりにインチを出す。
 * 打ち込まれた寸法は clampSize で刻みと範囲に収めるが、標準寸法を選び直したときは
 * 表の寸法（ベッドの奥行き 1.95 m など）をそのまま使う。
 */
function FurnitureSizeForm({
  labels,
  item,
  type,
  onResize,
}: {
  labels: FloorplanLabels;
  item: PlacedFurniture;
  type: FurnitureType;
  onResize: (patch: FurniturePatch) => void;
}) {
  const title = labels.sizeFormLabel.replace("{name}", type.name);
  if (item.type === "tv") {
    const inch = item.inch ?? TV_FALLBACK_INCH;
    return (
      <SizeForm label={title}>
        <NumberField
          label={labels.inchLabel}
          value={inch}
          min={TV_MIN_INCH}
          max={TV_MAX_INCH}
          step={1}
          inputMode="numeric"
          onCommit={(next) => {
            const seed = tvSeed(snapValue(next, 1, TV_MIN_INCH, TV_MAX_INCH));
            onResize({ ...seed.size, preset: seed.preset, inch: seed.inch });
          }}
        />
        <p className="fp-size-hint">
          {labels.tvStandHint.replace("{width}", formatLength(tvStandHint(inch)))}
        </p>
      </SizeForm>
    );
  }
  // 打ち込んだ欄だけを刻みに収める。ほかの欄まで通すと、標準寸法の 1.95 m が 2.00 m に動いてしまう
  const commit = (axis: keyof Size3, value: number) => {
    const rounded = clampSize(item.type, { ...item.size, [axis]: value })[axis];
    const size: Size3 = { ...item.size, [axis]: rounded };
    const same = type.presets.find(
      (preset) => preset.size.w === size.w && preset.size.d === size.d && preset.size.h === size.h,
    );
    onResize({ ...size, preset: same?.id ?? null });
  };
  return (
    <SizeForm label={title}>
      <label className="fp-field">
        {labels.presetLabel}
        <select
          className="fp-select"
          value={item.preset ?? ""}
          onChange={(event) => {
            // 「—」は「標準寸法から外れている」という表示だけ。選び直せるものではないので、
            // 選ばれても寸法は変えない（presetSeed は空の id を 1 つ目に読み替えてしまう）
            if (event.target.value === "") return;
            const seed = presetSeed(item.type, event.target.value);
            onResize({ ...seed.size, preset: seed.preset, inch: seed.inch });
          }}
        >
          <option value="" disabled>—</option>
          {type.presets.map((preset) => (
            <option key={preset.id} value={preset.id}>
              {preset.name}（{formatSize3(preset.size)}）
            </option>
          ))}
        </select>
      </label>
      <NumberField
        label={labels.widthLabel}
        value={item.size.w}
        min={type.limits.w[0]}
        max={type.limits.w[1]}
        step={type.step.w}
        format={formatLength}
        onCommit={(value) => commit("w", value)}
      />
      <NumberField
        label={labels.depthLabel}
        value={item.size.d}
        min={type.limits.d[0]}
        max={type.limits.d[1]}
        step={type.step.d}
        format={formatLength}
        onCommit={(value) => commit("d", value)}
      />
      <NumberField
        label={labels.heightLabel}
        value={item.size.h}
        min={type.limits.h[0]}
        max={type.limits.h[1]}
        step={type.step.h}
        format={formatLength}
        onCommit={(value) => commit("h", value)}
      />
    </SizeForm>
  );
}

/** 設備の寸法。階段だけ段数も変えられる（段数は 3D の段板と 2D の線の本数になる） */
function FixtureSizeForm({
  labels,
  item,
  onResize,
}: {
  labels: FloorplanLabels;
  item: Fixture;
  onResize: (patch: FixturePatch) => void;
}) {
  const limits = FIXTURE_LIMITS[item.kind];
  return (
    <SizeForm label={labels.sizeFormLabel.replace("{name}", FIXTURE_PRESETS[item.kind].name)}>
      <NumberField
        label={labels.widthLabel}
        value={item.size.w}
        min={limits.w[0]}
        max={limits.w[1]}
        step={SNAP}
        format={formatLength}
        onCommit={(w) => onResize({ w })}
      />
      <NumberField
        label={labels.depthLabel}
        value={item.size.d}
        min={limits.d[0]}
        max={limits.d[1]}
        step={SNAP}
        format={formatLength}
        onCommit={(d) => onResize({ d })}
      />
      <NumberField
        label={labels.heightLabel}
        value={item.size.h}
        min={limits.h[0]}
        max={limits.h[1]}
        step={HEIGHT_SNAP}
        format={formatLength}
        onCommit={(h) => onResize({ h })}
      />
      {item.kind === "stairs" && (
        <NumberField
          label={labels.stepsLabel}
          value={stepsOf(item)}
          min={STAIRS_MIN_STEPS}
          max={STAIRS_MAX_STEPS}
          step={1}
          inputMode="numeric"
          onCommit={(steps) => onResize({ steps })}
        />
      )}
    </SizeForm>
  );
}

/**
 * 建具の寸法と開き勝手。窓は下端も変えられ、吊元と開く側は持たない。
 * 引き戸は引き込む側だけなので、吊元の 2 つだけ出す。
 */
function OpeningSizeForm({
  labels,
  item,
  name,
  ceiling,
  onResize,
}: {
  labels: FloorplanLabels;
  item: Opening;
  name: string;
  ceiling: number;
  onResize: (patch: OpeningPatch) => void;
}) {
  return (
    <SizeForm label={labels.sizeFormLabel.replace("{name}", name)}>
      <NumberField
        label={labels.widthLabel}
        value={item.width}
        min={OPENING_MIN_WIDTH}
        max={OPENING_MAX_WIDTH}
        step={SNAP}
        format={formatLength}
        onCommit={(width) => onResize({ width })}
      />
      <NumberField
        label={labels.heightLabel}
        value={item.height}
        min={OPENING_MIN_HEIGHT}
        max={round2(ceiling - item.sill)}
        step={HEIGHT_SNAP}
        format={formatLength}
        onCommit={(height) => onResize({ height })}
      />
      {item.kind === "window" && (
        <NumberField
          label={labels.sillLabel}
          value={item.sill}
          min={0}
          max={round2(ceiling - OPENING_MIN_HEIGHT)}
          step={HEIGHT_SNAP}
          format={formatLength}
          onCommit={(sill) => onResize({ sill })}
        />
      )}
      {item.kind !== "window" && (
        <>
          <Toggle
            value="start"
            current={item.hinge}
            label={labels.hingeStart}
            onPick={(hinge) => onResize({ hinge })}
          />
          <Toggle
            value="end"
            current={item.hinge}
            label={labels.hingeEnd}
            onPick={(hinge) => onResize({ hinge })}
          />
        </>
      )}
      {item.kind === "door" && (
        <>
          <Toggle
            value="plus"
            current={item.swing}
            label={labels.swingPlus}
            onPick={(swing) => onResize({ swing })}
          />
          <Toggle
            value="minus"
            current={item.swing}
            label={labels.swingMinus}
            onPick={(swing) => onResize({ swing })}
          />
        </>
      )}
    </SizeForm>
  );
}

/** 外周の寸法。長さは取り付く面の残りまで、手すりは入り切りのトグル */
function ExteriorSizeForm({
  labels,
  part,
  span,
  onResize,
}: {
  labels: FloorplanLabels;
  part: ExteriorPart;
  /** 取り付く面の長さ（m） */
  span: number;
  onResize: (patch: ExteriorPatch) => void;
}) {
  return (
    <SizeForm label={labels.sizeFormLabel.replace("{name}", EXTERIOR_PRESETS[part.kind].name)}>
      <NumberField
        label={labels.lengthLabel}
        value={part.length}
        min={EXTERIOR_MIN_LENGTH}
        max={round2(span - part.start)}
        step={SNAP}
        format={formatLength}
        onCommit={(length) => onResize({ length })}
      />
      <NumberField
        label={labels.depthLabel}
        value={part.depth}
        min={EXTERIOR_MIN_DEPTH}
        max={EXTERIOR_MAX_DEPTH}
        step={SNAP}
        format={formatLength}
        onCommit={(depth) => onResize({ depth })}
      />
      <button
        type="button"
        className="fp-button"
        aria-pressed={part.railing}
        onClick={() => onResize({ railing: !part.railing })}
      >
        {labels.railingLabel}
      </button>
    </SizeForm>
  );
}

export function Panel(props: PanelProps) {
  const config = props.config;
  const labels = config.labels;
  const doc = props.doc;
  const file = props.file;
  const floors = floorsOf(doc.size).filter((floor) => floor <= config.features.floors);
  const editing = !config.readonly;
  const plan = doc.floors[props.floor];
  const selection = props.selection;
  const found = <T extends { id: string }>(list: readonly T[], kind: string) =>
    selection !== null && selection.kind === kind
      ? list.find((item) => item.id === selection.id) ?? null
      : null;
  const selectedFurniture = found(plan.furniture, "furniture");
  const selectedFixture = found(plan.fixtures, "fixture");
  const selectedOpening = found(plan.openings, "opening");
  const selectedExterior = found(plan.exterior, "exterior");
  const pickedType = furnitureType(props.furniturePick.type);
  // 「寸法」モードで選んでいるものにだけ入力欄を開く。見せるだけの埋め込みでは開かない
  const sizing = editing && props.mode === "dimension";

  // 選択中のものの寸法。家具・設備は 幅 × 奥行き × 高さ、建具は 幅 と 高さ（窓は下端も）、
  // 外周は 長さ と 奥行き
  let selectedNote: string | null = null;
  if (selectedFurniture) selectedNote = formatSize3(selectedFurniture.size);
  else if (selectedFixture) selectedNote = formatSize3(selectedFixture.size);
  else if (selectedOpening) {
    const parts = [
      `${labels.widthLabel} ${formatLength(selectedOpening.width)}`,
      `${labels.heightLabel} ${formatLength(selectedOpening.height)}`,
    ];
    if (selectedOpening.kind === "window") {
      parts.push(`${labels.sillLabel} ${formatLength(selectedOpening.sill)}`);
    }
    selectedNote = `${parts.join(" / ")} m`;
  } else if (selectedExterior) {
    selectedNote =
      `${labels.lengthLabel} ${formatLength(selectedExterior.length)}` +
      ` / ${labels.depthLabel} ${formatLength(selectedExterior.depth)} m`;
  }

  const modes: { value: EditorMode; label: string }[] = [
    { value: "select", label: labels.modeSelect },
    { value: "paint", label: labels.modePaint },
    { value: "opening", label: labels.modeOpening },
    { value: "fixture", label: labels.modeFixture },
    { value: "dimension", label: labels.modeDimension },
  ];

  return (
    <div className="fp-controls">
      {editing && (
        <div className="fp-group" role="group" aria-label={labels.modeGroup}>
          <span className="fp-group-label">{labels.modeGroup}</span>
          {modes.map((item) => (
            <Toggle key={item.value} value={item.value} current={props.mode} label={item.label} onPick={props.onMode} />
          ))}
        </div>
      )}

      <div className="fp-group" role="group" aria-label={labels.floorGroup}>
        <span className="fp-group-label">{labels.floorGroup}</span>
        {floors.map((floor) => (
          <Toggle
            key={floor}
            value={floor}
            current={props.floor}
            label={floor === 1 ? labels.floor1 : labels.floor2}
            onPick={props.onFloor}
          />
        ))}
        <button
          type="button"
          className="fp-button"
          aria-pressed={props.showDimensions}
          onClick={props.onToggleDimensions}
        >
          {labels.dimensionShow}
        </button>
      </div>

      {config.features.scene && (
        <>
          <div className="fp-group" role="group" aria-label={labels.viewGroup}>
            <span className="fp-group-label">{labels.viewGroup}</span>
            <Toggle value="orbit" current={props.view} label={labels.viewOrbit} onPick={props.onView} />
            <Toggle value="top" current={props.view} label={labels.viewTop} onPick={props.onView} />
            <Toggle value="all" current={props.floorMode} label={labels.floorAll} onPick={props.onFloorMode} />
          </div>
          <div className="fp-group" role="group" aria-label={labels.lightGroup}>
            <span className="fp-group-label">{labels.lightGroup}</span>
            <Toggle value="day" current={props.lighting} label={labels.lightDay} onPick={props.onLighting} />
            <Toggle value="night" current={props.lighting} label={labels.lightNight} onPick={props.onLighting} />
          </div>
        </>
      )}

      {editing && (
        <div className="fp-group" role="group" aria-label={labels.sizeGroup}>
          <span className="fp-group-label">{labels.sizeGroup}</span>
          <label className="fp-field">
            {labels.sizePreset}
            <select
              className="fp-select"
              value=""
              onChange={(event) => {
                const found = config.catalog.sizes.find((entry) => entry.id === event.target.value);
                if (found) props.onSize(found.size);
              }}
            >
              <option value="">—</option>
              {config.catalog.sizes.map((entry) => (
                <option key={entry.id} value={entry.id}>
                  {entry.name}
                </option>
              ))}
            </select>
          </label>
          <NumberField
            label={labels.sizeWidth}
            value={doc.size.width}
            min={SIZE_MIN}
            max={SIZE_MAX}
            step={0.5}
            onCommit={(width) => props.onSize({ ...doc.size, width })}
          />
          <NumberField
            label={labels.sizeDepth}
            value={doc.size.depth}
            min={SIZE_MIN}
            max={SIZE_MAX}
            step={0.5}
            onCommit={(depth) => props.onSize({ ...doc.size, depth })}
          />
          <span className="fp-group-label">{labels.sizeFloors}</span>
          <Toggle
            value={1}
            current={doc.size.floors}
            label={labels.sizeFlat}
            onPick={(value) => props.onSize({ ...doc.size, floors: value })}
          />
          <Toggle
            value={2}
            current={doc.size.floors}
            label={labels.sizeTwo}
            onPick={(value) => props.onSize({ ...doc.size, floors: value })}
          />
        </div>
      )}

      {editing && (
        <div className="fp-group" role="group" aria-label={labels.roomGroup}>
          <span className="fp-group-label">{labels.roomGroup}</span>
          <button type="button" className="fp-button" onClick={props.onNewRoom}>
            {labels.roomNew}
          </button>
          {props.selectedRoomLabel && (
            <label className="fp-field">
              {labels.roomLabel}
              <select
                className="fp-select"
                value={props.selectedRoomLabel}
                onChange={(event) => props.onRoomLabel(event.target.value as RoomLabel)}
              >
                {config.catalog.rooms.map((label) => (
                  <option key={label} value={label}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>
      )}

      {editing && (
        <div className="fp-group" role="group" aria-label={labels.openingGroup}>
          <span className="fp-group-label">{labels.openingGroup}</span>
          {(Object.keys(config.catalog.openings) as OpeningPresetId[]).map((id) => (
            <Toggle
              key={id}
              value={id}
              current={props.openingPreset}
              label={config.catalog.openings[id].name}
              onPick={props.onOpeningPreset}
            />
          ))}
        </div>
      )}

      {sizing && selectedOpening && (
        <OpeningSizeForm
          labels={labels}
          item={selectedOpening}
          name={config.catalog.openings[openingPresetId(selectedOpening)].name}
          ceiling={ceilingOf(doc.size, props.floor)}
          onResize={props.onResizeOpening}
        />
      )}

      {editing && (
        <div className="fp-group" role="group" aria-label={labels.fixtureGroup}>
          <span className="fp-group-label">{labels.fixtureGroup}</span>
          {(Object.keys(FIXTURE_PRESETS) as FixtureKind[]).map((kind) => (
            <Toggle
              key={kind}
              value={kind}
              current={props.fixtureKind}
              label={FIXTURE_PRESETS[kind].name}
              onPick={props.onFixtureKind}
            />
          ))}
        </div>
      )}

      {sizing && selectedFixture && (
        <FixtureSizeForm labels={labels} item={selectedFixture} onResize={props.onResizeFixture} />
      )}

      {editing && (
        <div className="fp-group" role="group" aria-label={labels.furnitureGroup}>
          <span className="fp-group-label">{labels.furnitureGroup}</span>
          <label className="fp-field">
            {labels.furnitureGroup}
            <select
              className="fp-select"
              value={props.furniturePick.type}
              onChange={(event) => {
                const type = furnitureType(event.target.value as PlacedFurniture["type"]);
                props.onFurniturePick({ type: type.id, preset: type.presets[0].id });
              }}
            >
              {config.catalog.furniture.map((type) => (
                <option key={type.id} value={type.id}>
                  {type.name}
                </option>
              ))}
            </select>
          </label>
          <label className="fp-field">
            {labels.presetLabel}
            <select
              className="fp-select"
              value={props.furniturePick.preset}
              onChange={(event) =>
                props.onFurniturePick({ type: props.furniturePick.type, preset: event.target.value })
              }
            >
              {pickedType.presets.map((preset) => (
                <option key={preset.id} value={preset.id}>
                  {preset.name}（{formatSize3(preset.size)}）
                </option>
              ))}
            </select>
          </label>
          <button type="button" className="fp-button" onClick={props.onPlaceFurniture}>
            {pickedType.name}
          </button>
        </div>
      )}

      {sizing && selectedFurniture && (
        <FurnitureSizeForm
          labels={labels}
          item={selectedFurniture}
          type={furnitureType(selectedFurniture.type)}
          onResize={props.onResizeFurniture}
        />
      )}

      {editing && (
        <div className="fp-group" role="group" aria-label={labels.exteriorGroup}>
          <span className="fp-group-label">{labels.exteriorGroup}</span>
          {(Object.keys(EXTERIOR_PRESETS) as ExteriorKind[]).map((kind) => (
            <Toggle
              key={kind}
              value={kind}
              current={props.exteriorKind}
              label={EXTERIOR_PRESETS[kind].name}
              onPick={props.onExteriorKind}
            />
          ))}
          <label className="fp-field">
            {labels.sideLabel}
            <select
              className="fp-select"
              value={props.exteriorSide}
              onChange={(event) => props.onExteriorSide(event.target.value as ExteriorSide)}
            >
              {SIDES.map((side) => (
                <option key={side.value} value={side.value}>
                  {side.label}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            className="fp-button"
            onClick={() => props.onExterior(props.exteriorKind, props.exteriorSide)}
          >
            {EXTERIOR_PRESETS[props.exteriorKind].name}
          </button>
        </div>
      )}

      {sizing && selectedExterior && (
        <ExteriorSizeForm
          labels={labels}
          part={selectedExterior}
          span={sideLength(doc.size, selectedExterior.side)}
          onResize={props.onResizeExterior}
        />
      )}

      {editing && selection && selection.kind !== "room" && (
        <div className="fp-group" role="group" aria-label={labels.selectedGroup}>
          <span className="fp-group-label">{labels.selectedGroup}</span>
          {selectedNote && <span className="fp-note">{selectedNote}</span>}
          <button type="button" className="fp-button" onClick={props.onRotate}>
            {selection.kind === "opening" ? labels.swingNext : labels.rotate}
          </button>
          <button type="button" className="fp-button" onClick={props.onRemove}>
            {labels.remove}
          </button>
        </div>
      )}

      {config.features.plans && (
        <div className="fp-group" role="group" aria-label={labels.plansGroup}>
          <span className="fp-group-label">{labels.plansGroup}</span>
          <ul className="fp-plans">
            {file.plans.map((plan) => (
              <li key={plan.id}>
                <button
                  type="button"
                  className="fp-button fp-plan-tab"
                  aria-pressed={plan.id === file.activeId}
                  onClick={() => props.onPlanSelect(plan.id)}
                >
                  {plan.name}
                </button>
              </li>
            ))}
          </ul>
          <button type="button" className="fp-button" onClick={props.onPlanAdd}>
            {labels.planAdd}
          </button>
          <button type="button" className="fp-button" onClick={props.onPlanDuplicate}>
            {labels.planDuplicate}
          </button>
          <label className="fp-field">
            {labels.planRename}
            <input
              className="fp-input fp-input-wide"
              type="text"
              maxLength={30}
              value={doc.name}
              aria-label={labels.planNameLabel}
              onChange={(event) => props.onPlanRename(event.target.value)}
            />
          </label>
          <button type="button" className="fp-button" onClick={props.onPlanRemove}>
            {labels.planRemove}
          </button>
        </div>
      )}

      {(config.features.export || config.features.print) && (
        <div className="fp-group" role="group" aria-label={labels.exportGroup}>
          <span className="fp-group-label">{labels.exportGroup}</span>
          {config.features.export && (
            <>
              <button type="button" className="fp-button" onClick={() => props.onExport("plan")}>
                {labels.exportPlan}
              </button>
              {config.features.scene && (
                <>
                  <button
                    type="button"
                    className="fp-button"
                    disabled={!props.sceneReady}
                    onClick={() => props.onExport("scene")}
                  >
                    {labels.exportScene}
                  </button>
                  <button
                    type="button"
                    className="fp-button"
                    disabled={!props.sceneReady}
                    onClick={() => props.onExport("both")}
                  >
                    {labels.exportBoth}
                  </button>
                </>
              )}
            </>
          )}
          {config.features.print && (
            <button type="button" className="fp-button" onClick={props.onPrint}>
              {labels.print}
            </button>
          )}
        </div>
      )}

      {editing && (
        <div className="fp-group">
          <button type="button" className="fp-button" onClick={props.onReset}>
            {labels.reset}
          </button>
          <span className="fp-note">
            {labels.sizeGroup} {formatLength(doc.size.width)} × {formatLength(doc.size.depth)} m
          </span>
        </div>
      )}

      {props.notice && <p className="fp-hint">{props.notice}</p>}
    </div>
  );
}
