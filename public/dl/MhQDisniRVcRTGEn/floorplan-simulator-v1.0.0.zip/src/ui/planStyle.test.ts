import { describe, expect, it } from "vitest";
import {
  isSafeTokenValue,
  planStyleBlock,
  planTokens,
  PLAN_TOKENS,
  serializePlanSvg,
} from "./planStyle";

// 配布する CSS の中身そのもの。@types/node を足さずに読むため、
// 読み込み先を組み立てて（= TS に中身を見に行かせずに）node の fs を借りる。
// ?raw で読むと Vite の CSS の扱いが先に効いて空になるので、素直にファイルを読む
declare const process: { cwd(): string };
const nodeFs = "node:fs";
const { readFileSync } = (await import(nodeFs)) as {
  readFileSync(path: string, encoding: string): string;
};
const CSS = readFileSync(`${process.cwd()}/styles/floorplan-simulator.css`, "utf8");

function svgWith(tokens: Record<string, string> = {}): SVGSVGElement {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 900 800");
  for (const [name, value] of Object.entries(tokens)) svg.style.setProperty(name, value);
  return svg;
}

describe("書き出しに入れる色", () => {
  it("既定の色は CSS の .fp と同じ（片方だけ直すと食い違うので、ここで見張る）", () => {
    for (const [name, value] of Object.entries(PLAN_TOKENS)) {
      const found = new RegExp(`${name}:\\s*([^;]+);`).exec(CSS);
      expect(found, `${name} が CSS に無い`).not.toBeNull();
      expect(found![1].trim(), name).toBe(value);
    }
  });

  it("読み取れない場所では既定の色に落ちる", () => {
    expect(planTokens(svgWith())["--fp-room"]).toBe(PLAN_TOKENS["--fp-room"]);
    expect(planTokens(svgWith({ "--fp-room": "#123456" }))["--fp-room"]).toBe("#123456");
  });

  it("var() を残さず、間取り図の class をひととおり書く", () => {
    const css = planStyleBlock(svgWith());
    expect(css).not.toContain("var(");
    for (const name of [
      "fp-outline",
      "fp-room",
      "fp-room-selected",
      "fp-grid",
      "fp-wall",
      "fp-focus",
      "fp-glyph",
      "fp-glyph-selected",
      "fp-glyph-line",
      "fp-glyph-thin",
      "fp-glyph-dash",
      "fp-opening-cut",
      "fp-opening",
      "fp-opening-selected",
      "fp-name",
      "fp-area",
      "fp-dim-line",
      "fp-dim-text",
    ]) {
      expect(css, name).toContain(`.${name}{`);
    }
  });

  it("<style> の外へ出る値は受け取らず、既定の色に落とす", () => {
    for (const value of [
      "#fff}.fp-wall{stroke:red",
      "red;stroke:red",
      "</style><script>alert(1)</script>",
      'url("x")',
      "url('x')",
    ]) {
      expect(isSafeTokenValue(value), value).toBe(false);
      const css = planStyleBlock(svgWith({ "--fp-room": value }));
      expect(css, value).toContain(`.fp-room{fill:${PLAN_TOKENS["--fp-room"]}}`);
      expect(css, value).not.toContain(value);
    }
    // 色として普通に書ける値はそのまま通す
    expect(isSafeTokenValue("#123456")).toBe(true);
    expect(isSafeTokenValue("rgba(28, 26, 21, 0.18)")).toBe(true);
    expect(planStyleBlock(svgWith({ "--fp-room": "rgba(1, 2, 3, 0.5)" }))).toContain(
      ".fp-room{fill:rgba(1, 2, 3, 0.5)}",
    );
  });

  it("色を読む先は別に渡せる（document の外で描いた図面のため）", () => {
    const offscreen = svgWith();
    const onscreen = svgWith({ "--fp-room": "#ff0000" });
    expect(planStyleBlock(offscreen)).toContain(`.fp-room{fill:${PLAN_TOKENS["--fp-room"]}}`);
    expect(planStyleBlock(offscreen, onscreen)).toContain(".fp-room{fill:#ff0000}");
    expect(serializePlanSvg(offscreen, onscreen)).toContain(".fp-room{fill:#ff0000}");
  });

  it("serializePlanSvg は <style> と xmlns を足し、元の SVG は触らない", () => {
    const svg = svgWith();
    const markup = serializePlanSvg(svg);
    expect(markup).toContain('xmlns="http://www.w3.org/2000/svg"');
    expect(markup).toContain("<style>");
    expect(markup).not.toContain("var(");
    expect(svg.querySelector("style")).toBeNull();
  });
});
