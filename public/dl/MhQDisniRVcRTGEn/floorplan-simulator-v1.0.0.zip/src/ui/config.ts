/**
 * 売り物: 埋め込みの設定。渡された分だけ上書きし、知らない値・壊れた値は既定に戻す。
 * 3D の中の色だけはここで受ける（CSS のカスケードに乗らないため）。
 * 画面と操作列の色は CSS の --fp-* だけで、この設定には出てこない。
 */
import { FURNITURE, type FurniturePreset, type FurnitureType } from "../model/catalog";
import { type FurnitureId } from "../model/furniture";
import { ROOM_LABELS, type RoomLabel } from "../model/grid";
import {
  ceilingOf,
  DEFAULT_SCENE_COLORS,
  DEFAULT_SIZE,
  isPlanSize,
  SIZE_PRESETS,
  type PlanSize,
  type SceneColors,
} from "../model/house";
import { migrate } from "../model/migrate";
import {
  OPENING_MAX_WIDTH,
  OPENING_MIN_HEIGHT,
  OPENING_MIN_WIDTH,
  OPENING_PRESETS,
  type OpeningKind,
  type WindowStyle,
} from "../model/openings";
import { parsePlanFile, STORAGE_KEY, type PlanDoc, type PlanFile } from "../model/plan";
import { DEFAULT_LABELS, type FloorplanLabels } from "./labels";

export type DeepPartial<T> = T extends object ? { [K in keyof T]?: DeepPartial<T[K]> } : T;

export type SelectionTarget =
  | { kind: "room" | "furniture" | "fixture" | "opening" | "exterior"; id: string }
  | null;

export type ExportTarget = "plan" | "scene" | "both";

export type ExportResult = { kind: "png"; target: ExportTarget; blob: Blob; name: string };

export type SizePreset = { id: string; name: string; size: PlanSize };

export type FloorplanConfig = {
  /** 初期の間取り。PlanFile か PlanDoc か、その JSON 文字列 */
  plan?: PlanFile | PlanDoc | string;
  /** 見せるだけにする。編集の操作列・保存・複数案を出さず、3D と寸法と書き出しだけ残す */
  readonly?: boolean;
  storage?: {
    /** 既定 "suminawa-floorplan:v3"。1 つのサイトに 2 つ置くときは分ける */
    key?: string;
    /** false なら localStorage を触らない（readonly の既定は false） */
    enabled?: boolean;
  };
  features?: {
    plans?: boolean;
    export?: boolean;
    print?: boolean;
    /** false なら three をいっさい読まない（軽い埋め込み用） */
    scene?: boolean;
    /** 出す階数の上限 */
    floors?: 1 | 2;
    /**
     * この幅（px）より狭いときは 3D をたたみ、「3D で見る」を押すまで読み込まない。
     * 既定 960。0 なら常に開いたまま
     */
    collapseBelow?: number;
  };
  catalog?: {
    rooms?: string[];
    furniture?: Partial<Record<FurnitureId, { hidden?: boolean; presets?: FurniturePreset[] }>>;
    openings?: Partial<typeof OPENING_PRESETS>;
    sizes?: SizePreset[];
  };
  /** 3D の中の色。three の材質に渡す値なので CSS からは取らない */
  scene?: {
    autoRotate?: boolean;
    /**
     * 3D の部品（floorplan-3d.global.js）の置き場所。渡すと、3D を出すと決まってから
     * この script を読み込みます。ページの <script> で先に読ませたくないときに使います。
     * 相対パスか http(s) の URL だけ受け取ります
     */
    src?: string;
    wall?: string;
    trim?: string;
    roof?: string;
    floorTone?: string;
    interior?: string;
  };
  labels?: Partial<FloorplanLabels>;
  onChange?(file: PlanFile): void;
  onSelect?(target: SelectionTarget): void;
  onExport?(result: ExportResult): void;
};

export type ResolvedConfig = {
  readonly: boolean;
  storage: { key: string; enabled: boolean };
  features: {
    plans: boolean;
    export: boolean;
    print: boolean;
    scene: boolean;
    floors: 1 | 2;
    collapseBelow: number;
  };
  catalog: {
    rooms: RoomLabel[];
    furniture: FurnitureType[];
    openings: typeof OPENING_PRESETS;
    sizes: SizePreset[];
  };
  scene: { autoRotate: boolean; src: string | null; colors: SceneColors };
  labels: FloorplanLabels;
  /** config.plan から読めた間取り。読めなければ null */
  initial: PlanFile | null;
  onChange?: (file: PlanFile) => void;
  onSelect?: (target: SelectionTarget) => void;
  onExport?: (result: ExportResult) => void;
};

/** #rgb と #rrggbb だけ通す。three に渡す前に弾いて、知らない値で場面が黒くなるのを防ぐ */
export function isHexColor(value: unknown): boolean {
  return typeof value === "string" && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(value);
}

function color(value: unknown, fallback: string): string {
  return isHexColor(value) ? (value as string) : fallback;
}

function bool(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}

/** 0 以上の数だけ通す。それ以外は既定に戻す */
function positive(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : fallback;
}

/**
 * 3D の部品の置き場所。相対パス（"./floorplan-3d.global.js"、"/js/x.js"）と
 * http(s) の URL だけ通す。`javascript:` などの scheme は捨てる ──
 * ここに入った文字列はそのまま <script src> になるため。
 * ブラウザは URL を読む前に制御文字と前後の空白を取り除くので、こちらも先に取り除いて見る
 * （制御文字を挟んで scheme の検査に当たらなくした "javascript:" を、相対パスとして通さないため）。
 */
export function sceneSrc(value: unknown): string | null {
  if (typeof value !== "string") return null;
  // 制御文字（C0 と DEL）を落としてから読む。タブ・改行もこの範囲に入っている
  const src = value.replace(/[\u0000-\u001f\u007f]/g, "").trim();
  if (src === "") return null;
  // "//example.com/x.js"（scheme を継ぐ書き方）は相対パスではないので受け取らない
  if (src.startsWith("//")) return null;
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(src);
  if (scheme) return /^https?$/i.test(scheme[1]) ? src : null;
  return src;
}

function validPreset(preset: unknown): preset is FurniturePreset {
  if (typeof preset !== "object" || preset === null) return false;
  const item = preset as Record<string, unknown>;
  if (typeof item.id !== "string" || item.id === "") return false;
  if (typeof item.name !== "string" || item.name === "") return false;
  const size = item.size as Record<string, unknown> | undefined;
  if (!size) return false;
  return (
    typeof size.w === "number" &&
    typeof size.d === "number" &&
    typeof size.h === "number" &&
    size.w > 0 &&
    size.d > 0 &&
    size.h > 0
  );
}

type OpeningPreset = (typeof OPENING_PRESETS)[keyof typeof OPENING_PRESETS];

const OPENING_KINDS: readonly OpeningKind[] = ["door", "sliding", "window"];
const WINDOW_STYLES: readonly WindowStyle[] = ["koshi", "hakidashi"];
/** 1 階の天井。建具はここに収まる高さでなければ、そもそも壁に空けられない */
const TOP_CEILING = ceilingOf(DEFAULT_SIZE, 1);

/**
 * 建具の標準寸法の差し替え。欄ごとに見て、範囲の外や形の違うものは元の値のまま残す
 * （壁に空けられない寸法を通すと、置こうとしたときに黙って置けなくなる）。
 */
function mergeOpening(base: OpeningPreset, patch: Partial<OpeningPreset>): OpeningPreset {
  const num = (value: unknown, min: number, max: number, fallback: number) =>
    typeof value === "number" && Number.isFinite(value) && value >= min && value <= max
      ? value
      : fallback;
  const sill = num(patch.sill, 0, TOP_CEILING - OPENING_MIN_HEIGHT, base.sill);
  const height = num(patch.height, OPENING_MIN_HEIGHT, TOP_CEILING, base.height);
  return {
    kind: OPENING_KINDS.includes(patch.kind as OpeningKind) ? (patch.kind as OpeningKind) : base.kind,
    style:
      patch.style === null || WINDOW_STYLES.includes(patch.style as WindowStyle)
        ? (patch.style as WindowStyle | null)
        : base.style,
    name: typeof patch.name === "string" && patch.name.trim() !== "" ? patch.name : base.name,
    width: num(patch.width, OPENING_MIN_WIDTH, OPENING_MAX_WIDTH, base.width),
    // 下端 + 高さが天井を超えると壁に空けられないので、その組み合わせは受け取らない
    sill: sill + height <= TOP_CEILING ? sill : base.sill,
    height: sill + height <= TOP_CEILING ? height : base.height,
  };
}

function resolveCatalog(config: FloorplanConfig): ResolvedConfig["catalog"] {
  const wanted = config.catalog ?? {};
  const rooms = (wanted.rooms ?? []).filter((label): label is RoomLabel =>
    (ROOM_LABELS as readonly string[]).includes(label),
  );
  const furniture = FURNITURE.filter((type) => wanted.furniture?.[type.id]?.hidden !== true).map(
    (type) => {
      const extra = (wanted.furniture?.[type.id]?.presets ?? []).filter(validPreset);
      if (extra.length === 0) return type;
      return { ...type, presets: [...type.presets, ...extra] };
    },
  );
  const openings = { ...OPENING_PRESETS };
  for (const key of Object.keys(openings) as (keyof typeof OPENING_PRESETS)[]) {
    const override = wanted.openings?.[key];
    if (override) openings[key] = mergeOpening(openings[key], override);
  }
  const sizes = (wanted.sizes ?? []).filter(
    (entry) =>
      typeof entry?.id === "string" &&
      entry.id !== "" &&
      typeof entry.name === "string" &&
      isPlanSize(entry.size),
  );
  return {
    rooms: rooms.length > 0 ? rooms : [...ROOM_LABELS],
    furniture,
    openings,
    sizes: sizes.length > 0 ? sizes : [...SIZE_PRESETS],
  };
}

/** 同じ断りを何度も出さない（描き直すたびに resolveConfig を通るため） */
const warned = new Set<string>();

/** テスト専用。出した断りを忘れる */
export function resetPlanWarnings(): void {
  warned.clear();
}

function warnPlan(reason: string): void {
  if (warned.has(reason)) return;
  warned.add(reason);
  console.warn(`[floorplan-simulator] config.plan を読めないので既定の間取りで始める: ${reason}`);
}

/**
 * config.plan を PlanFile に直す。PlanDoc 1 件はファイルに包む。読めなければ null。
 * v2（見本の書き出し）は文字列でも object でも受け取る。
 */
function resolveInitial(plan: FloorplanConfig["plan"]): PlanFile | null {
  if (plan === undefined) return null;
  if (typeof plan === "string") {
    const parsed = migrate(plan);
    if (!parsed) warnPlan("JSON として読めないか、version が 3 でも 2 でもない");
    return parsed;
  }
  if (typeof plan !== "object" || plan === null) {
    warnPlan("PlanFile・PlanDoc・その JSON 文字列のどれでもない");
    return null;
  }
  const version = (plan as { version?: unknown }).version;
  if (version === 3 || version === 2) {
    const parsed = migrate(plan);
    if (!parsed) warnPlan(`version ${version} の形に合わない（階・マス・家具の欄を確かめる）`);
    return parsed;
  }
  const doc = plan as PlanDoc;
  const parsed = parsePlanFile({ version: 3, plans: [doc], activeId: doc.id });
  if (!parsed) warnPlan("PlanDoc として読めない（id・size・floors の欄を確かめる）");
  return parsed;
}

export function resolveConfig(config: FloorplanConfig = {}): ResolvedConfig {
  const readonly = bool(config.readonly, false);
  const ownKey = typeof config.storage?.key === "string" && config.storage.key.trim() !== "";
  const key = ownKey ? (config.storage?.key as string) : STORAGE_KEY;
  const floors = config.features?.floors === 1 ? 1 : 2;
  const initial = resolveInitial(config.plan);
  // plan を渡された埋め込みは「決まった間取りを見せる」ための置き方なので、
  // 鍵を分けてもらわない限り保存しない ── 既定の鍵に書くと、同じサイトの
  // 編集用の埋め込みと混ざるうえ、書いたものを読み返す先も無い
  const canStore = !readonly && !(initial !== null && !ownKey);
  return {
    readonly,
    storage: {
      key,
      enabled: bool(config.storage?.enabled, canStore),
    },
    features: {
      plans: readonly ? false : bool(config.features?.plans, true),
      export: bool(config.features?.export, true),
      print: bool(config.features?.print, true),
      scene: bool(config.features?.scene, true),
      floors,
      collapseBelow: positive(config.features?.collapseBelow, 960),
    },
    catalog: resolveCatalog(config),
    scene: {
      autoRotate: bool(config.scene?.autoRotate, false),
      src: sceneSrc(config.scene?.src),
      colors: {
        wall: color(config.scene?.wall, DEFAULT_SCENE_COLORS.wall),
        trim: color(config.scene?.trim, DEFAULT_SCENE_COLORS.trim),
        roof: color(config.scene?.roof, DEFAULT_SCENE_COLORS.roof),
        floorTone: color(config.scene?.floorTone, DEFAULT_SCENE_COLORS.floorTone),
        interior: color(config.scene?.interior, DEFAULT_SCENE_COLORS.interior),
      },
    },
    labels: { ...DEFAULT_LABELS, ...(config.labels ?? {}) },
    initial,
    onChange: config.onChange,
    onSelect: config.onSelect,
    onExport: config.onExport,
  };
}
