/**
 * 売り物: 印刷用の 1 枚（A4 横）。PDF のライブラリは積まず、
 * 組み立てた HTML を別タブに開いて window.print() に渡す。
 * 買い手はブラウザの印刷画面から PDF で保存する（見積もり電卓と同じやり方）。
 */
import { furnitureType } from "../model/catalog";
import { formatArea, formatJo, formatLength, formatSize3, roomDimension } from "../model/dimensions";
import { exteriorName } from "../model/exterior";
import { fixtureName } from "../model/fixtures";
import { floorsOf, type Floor } from "../model/house";
import { type PlanDoc } from "../model/plan";
import { type FloorplanLabels } from "./labels";

export type PrintSheet = { floor: Floor; markup: string };

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function roomRows(doc: PlanDoc, floor: Floor, labels: FloorplanLabels): string {
  const plan = doc.floors[floor];
  return plan.layout.rooms
    .map((room) => {
      const dim = roomDimension(doc.size, plan.layout, room.id);
      if (!dim) return "";
      return `<tr><td>${floor}F</td><td>${escapeHtml(room.label)}</td><td class="num">${formatArea(dim.area)} ${escapeHtml(labels.areaUnit)}</td><td class="num">${formatJo(dim.jo)} ${escapeHtml(labels.joUnit)}</td></tr>`;
    })
    .join("");
}

function itemRows(doc: PlanDoc, floor: Floor): string {
  const plan = doc.floors[floor];
  const furniture = plan.furniture.map(
    (item) =>
      `<tr><td>${floor}F</td><td>${escapeHtml(furnitureType(item.type).name)}</td><td class="num">${formatSize3(item.size)}</td></tr>`,
  );
  const fixtures = plan.fixtures.map(
    (item) =>
      `<tr><td>${floor}F</td><td>${escapeHtml(fixtureName(item.kind))}</td><td class="num">${formatSize3(item.size)}</td></tr>`,
  );
  const exterior = plan.exterior.map(
    (part) =>
      `<tr><td>${floor}F</td><td>${escapeHtml(exteriorName(part.kind))}</td><td class="num">${formatLength(part.length)} × ${formatLength(part.depth)} m</td></tr>`,
  );
  return [...furniture, ...fixtures, ...exterior].join("");
}

/** A4 横 1 枚。案の名前・間取り図（1F・2F）・部屋の一覧・家具の一覧・外皮の寸法を載せる */
export function printSheetHtml(
  doc: PlanDoc,
  sheets: readonly PrintSheet[],
  labels: FloorplanLabels,
): string {
  const floors = floorsOf(doc.size);
  const shown = sheets.filter((sheet) => floors.includes(sheet.floor));
  const plans = shown
    .map(
      (sheet) =>
        `<figure class="plan"><figcaption>${sheet.floor}F</figcaption>${sheet.markup}</figure>`,
    )
    .join("");
  const rooms = floors.map((floor) => roomRows(doc, floor, labels)).join("");
  const items = floors.map((floor) => itemRows(doc, floor)).join("");
  const outer = `${formatLength(doc.size.width)} × ${formatLength(doc.size.depth)} m`;
  const storeys = doc.size.floors === 1 ? labels.sizeFlat : labels.sizeTwo;
  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>${escapeHtml(doc.name)}</title>
<style>
@page { size: A4 landscape; margin: 10mm; }
* { box-sizing: border-box; }
body { margin: 0; font-family: system-ui, sans-serif; color: #1c1a15; font-size: 10pt; line-height: 1.5; }
h1 { margin: 0 0 2mm; font-size: 14pt; }
.meta { margin: 0 0 4mm; color: #6a665d; }
.sheet { display: grid; grid-template-columns: 3fr 2fr; gap: 6mm; align-items: start; }
.plans { display: grid; grid-auto-flow: column; gap: 4mm; }
.plan { margin: 0; }
.plan figcaption { font-weight: 700; margin-bottom: 1mm; }
.plan svg { width: 100%; height: auto; }
table { width: 100%; border-collapse: collapse; margin-bottom: 4mm; }
caption { text-align: left; font-weight: 700; padding-bottom: 1mm; }
th, td { border-bottom: 1px solid rgba(28,26,21,0.2); padding: 1mm 1.5mm; text-align: left; }
td.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
</style>
</head>
<body>
<h1>${escapeHtml(doc.name)}</h1>
<p class="meta">${escapeHtml(labels.sizeGroup)}: ${outer}（${escapeHtml(storeys)}）</p>
<div class="sheet">
  <div class="plans">${plans}</div>
  <div>
    <table><caption>${escapeHtml(labels.roomGroup)}</caption>
      <tbody>${rooms}</tbody>
    </table>
    <table><caption>${escapeHtml(labels.furnitureGroup)}</caption>
      <tbody>${items}</tbody>
    </table>
  </div>
</div>
</body>
</html>`;
}

/** 別タブに開いて印刷画面を出す。ポップアップを塞がれていたら false */
export function openPrintSheet(html: string, win: Window | undefined): boolean {
  if (!win) return false;
  const tab = win.open("", "_blank");
  if (!tab) return false;
  tab.document.write(html);
  tab.document.close();
  tab.focus();
  tab.print();
  return true;
}
