import { act, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { defaultPlanFile, serializePlanFile, STORAGE_KEY } from "../model/plan";
import { registerScene, resetSceneRegistry, type SceneApi, type SceneComponent } from "../scene/loader";
import { Simulator, type SimulatorApi } from "./Simulator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

function mount(props: Parameters<typeof Simulator>[0] = {}) {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  let handle: SimulatorApi | null = null;
  act(() => {
    root.render(<Simulator {...props} handleRef={(api) => (handle = api)} />);
  });
  return { container, root, get handle() { return handle as unknown as SimulatorApi; } };
}

const click = (el: Element) => act(() => {
  el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
});

const buttonNamed = (container: HTMLElement, text: string) =>
  [...container.querySelectorAll("button")].find((button) => button.textContent?.trim() === text)!;

/** ラベルの文言で入力を引く */
const fieldNamed = (container: HTMLElement, text: string) =>
  [...container.querySelectorAll("label.fp-field")]
    .find((label) => label.textContent?.startsWith(text))!
    .querySelector("input")!;

/**
 * 制御された input に値を入れる。input.value への直接代入だと React の tracker まで
 * 一緒に書き換わって onChange が呼ばれないので、ネイティブの setter を直接呼ぶ
 */
function typeInto(input: HTMLInputElement, value: string) {
  act(() => {
    const setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")!.set!;
    setValue.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

const press = (el: Element, key: string) =>
  act(() => {
    el.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));
  });

/** WebGL がある環境のふりをする。jsdom には WebGL も canvas も無い */
function fakeWebgl() {
  vi.stubGlobal("WebGLRenderingContext", class {});
  return vi
    .spyOn(window.HTMLCanvasElement.prototype, "getContext")
    .mockReturnValue({ getExtension: () => ({ loseContext: () => {} }) } as never);
}

beforeEach(() => {
  window.localStorage.clear();
  vi.useFakeTimers();
});

afterEach(() => {
  // 「断り」の 2 秒タイマーが残ったまま次のテストに入ると、ここで setNotice(null) が
  // act() の外で走り、React の act 警告が出る（10 件を超えたら足さず、のテストで実測）。
  // act() で包んで、残っていた分もこの場で正しく片づける
  act(() => {
    vi.runOnlyPendingTimers();
  });
  vi.useRealTimers();
  document.body.replaceChildren();
});

describe("描く", () => {
  it("根の中に操作列と SVG を作る", () => {
    const { container } = mount();
    expect(container.querySelector(".fp")).not.toBeNull();
    expect(container.querySelector(".fp-controls")).not.toBeNull();
    expect(container.querySelector("svg.fp-plan")).not.toBeNull();
    expect(buttonNamed(container, "塗る")).toBeTruthy();
    expect(buttonNamed(container, "建具")).toBeTruthy();
    expect(buttonNamed(container, "寸法")).toBeTruthy();
  });

  it("すべてのボタンが type=button", () => {
    const { container } = mount();
    for (const button of container.querySelectorAll("button")) {
      expect(button.getAttribute("type")).toBe("button");
    }
  });

  it("モードのボタンは aria-pressed で押した状態を示す", () => {
    const { container } = mount();
    const paint = buttonNamed(container, "塗る");
    expect(paint.getAttribute("aria-pressed")).toBe("false");
    click(paint);
    expect(buttonNamed(container, "塗る").getAttribute("aria-pressed")).toBe("true");
    expect(container.querySelector("svg.fp-plan")!.getAttribute("class")).toContain("fp-plan-paint");
  });

  it("「塗る」のあいだは家具に触れない", () => {
    const { container } = mount();
    click(buttonNamed(container, "塗る"));
    expect(container.querySelectorAll(".fp-item-locked").length).toBeGreaterThan(0);
  });
});

describe("複数案", () => {
  it("案を足す・切り替える・複製する・名前を変える・消す", () => {
    const { container, handle } = mount();
    click(buttonNamed(container, "案を足す"));
    expect(handle.getFile().plans).toHaveLength(2);
    expect(handle.getActivePlan().id).toBe("plan-2");

    const tab = [...container.querySelectorAll(".fp-plan-tab")].find(
      (button) => button.textContent?.trim() === "案 1",
    )!;
    click(tab);
    expect(handle.getActivePlan().id).toBe("plan-1");

    click(buttonNamed(container, "複製"));
    expect(handle.getFile().plans).toHaveLength(3);

    const input = container.querySelector<HTMLInputElement>(".fp-input-wide")!;
    act(() => {
      // input.value への直接代入だと、React が計装した instance 側の setter を
      // 経由して値の追跡（tracker）まで一緒に書き換わり、input イベントを送っても
      // 「変化なし」と見なされて onChange が呼ばれない（制御された input を素の DOM
      // イベントでテストするときの既知の落とし穴。計測: この代入のままだと
      // onChange の呼び出し回数は 0、ネイティブの setter 経由だと 1）。
      // ネイティブの setter を直接呼んで、tracker を経由せずに値だけ差し替える
      const setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")!.set!;
      setValue.call(input, "南入りの案");
      input.dispatchEvent(new Event("input", { bubbles: true }));
    });
    expect(handle.getActivePlan().name).toBe("南入りの案");

    click(buttonNamed(container, "この案を消す"));
    expect(handle.getFile().plans).toHaveLength(2);
  });

  it("案を消すと、選んでいたものを離す", () => {
    const onSelect = vi.fn();
    const { container } = mount({ config: { onSelect } });
    click(buttonNamed(container, "案を足す"));
    const focus = container.querySelector(".fp-focus")!;
    press(focus, "Enter");
    expect(onSelect).toHaveBeenLastCalledWith({ kind: "room", id: expect.any(String) });
    click(buttonNamed(container, "この案を消す"));
    expect(onSelect).toHaveBeenLastCalledWith(null);
  });

  it("10 件を超えたら足さず、断りを出す", () => {
    const { container, handle } = mount();
    for (let i = 0; i < 12; i++) click(buttonNamed(container, "案を足す"));
    expect(handle.getFile().plans).toHaveLength(10);
    expect(container.querySelector(".fp-hint")?.textContent).toContain("10 件まで");
  });
});

describe("保存", () => {
  it("変更から 300ms 後に localStorage へ書く", () => {
    const { container, handle } = mount();
    click(buttonNamed(container, "案を足す"));
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
    act(() => {
      vi.advanceTimersByTime(300);
    });
    const saved = window.localStorage.getItem(STORAGE_KEY);
    expect(saved).not.toBeNull();
    expect(JSON.parse(saved!).plans).toHaveLength(2);
    expect(handle.getFile().plans).toHaveLength(2);
  });

  it("保存されているものがあれば読み込む", () => {
    const file = defaultPlanFile();
    file.plans[0].name = "前に作った案";
    window.localStorage.setItem(STORAGE_KEY, serializePlanFile(file));
    const { handle } = mount();
    expect(handle.getActivePlan().name).toBe("前に作った案");
  });

  it("壊れた保存データは捨てて既定値に戻す", () => {
    window.localStorage.setItem(STORAGE_KEY, "{ ");
    const { handle } = mount();
    expect(handle.getActivePlan().name).toBe("案 1");
  });

  it("storage.enabled が false なら触らない", () => {
    const { container } = mount({ config: { storage: { enabled: false } } });
    click(buttonNamed(container, "案を足す"));
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
  });

  it("鍵を差し替えられる", () => {
    const { container } = mount({ config: { storage: { key: "shop:fp" } } });
    click(buttonNamed(container, "案を足す"));
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(window.localStorage.getItem("shop:fp")).not.toBeNull();
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
  });
});

describe("readonly", () => {
  it("編集の操作列を出さず、案の操作も出さない", () => {
    const { container } = mount({ config: { readonly: true } });
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "塗る")).toBe(false);
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "案を足す")).toBe(false);
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "寸法を出す")).toBe(true);
    expect(container.querySelectorAll(".fp-item-locked").length).toBeGreaterThan(0);
  });
});

describe("コールバック", () => {
  it("onChange は変更のたびに呼ばれる", () => {
    const onChange = vi.fn();
    const { container } = mount({ config: { onChange } });
    click(buttonNamed(container, "案を足す"));
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange.mock.calls[0][0].plans).toHaveLength(2);
  });

  it("onSelect は選んだものを返す", () => {
    const onSelect = vi.fn();
    const { container } = mount({ config: { onSelect } });
    const focus = container.querySelector(".fp-focus")!;
    act(() => {
      focus.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    });
    expect(onSelect).toHaveBeenCalledWith({ kind: "room", id: expect.any(String) });
  });
});

describe("setFile と destroy", () => {
  it("setFile で差し替えられ、読めないものは無視する", () => {
    const { handle } = mount();
    const file = defaultPlanFile();
    file.plans[0].name = "差し替え";
    act(() => handle.setFile(file));
    expect(handle.getActivePlan().name).toBe("差し替え");
    act(() => handle.setFile("{"));
    expect(handle.getActivePlan().name).toBe("差し替え");
  });

  it("unmount で listener とタイマーが残らない", () => {
    const removeSpy = vi.spyOn(window, "removeEventListener");
    const { root, container } = mount();
    act(() => root.unmount());
    expect(container.querySelector(".fp")).toBeNull();
    expect(removeSpy).toHaveBeenCalledWith("keydown", expect.any(Function));
    expect(removeSpy).toHaveBeenCalledWith("pagehide", expect.any(Function));
    removeSpy.mockRestore();
  });
});

describe("features", () => {
  it("scene が false なら 3D の枠も切替も出さない", () => {
    const { container } = mount({ config: { features: { scene: false } } });
    expect(container.querySelector(".fp-stage")).toBeNull();
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "斜めから")).toBe(false);
  });

  it("floors が 1 なら 2F のタブを出さない", () => {
    const { container } = mount({ config: { features: { floors: 1 } } });
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "2F")).toBe(false);
  });

  it("export / print を切れる", () => {
    const { container } = mount({ config: { features: { export: false, print: false } } });
    expect([...container.querySelectorAll("button")].some((b) => b.textContent?.includes("PNG"))).toBe(false);
    expect([...container.querySelectorAll("button")].some((b) => b.textContent?.includes("印刷"))).toBe(false);
  });
});

describe("外皮の入力", () => {
  it("打っている間は間取りを変えず、Enter で 1 回だけ変える", () => {
    const { container, handle } = mount();
    const input = fieldNamed(container, "間口");
    expect(input.value).toBe("9");
    // "12" の "1" を打った時点で 4 m に丸められると、部屋が消えてしまう
    typeInto(input, "1");
    expect(handle.getActivePlan().size.width).toBe(9);
    typeInto(input, "12");
    expect(handle.getActivePlan().size.width).toBe(9);
    press(input, "Enter");
    expect(handle.getActivePlan().size.width).toBe(12);
    expect(fieldNamed(container, "間口").value).toBe("12");
  });

  it("枠から外れたときにも変える。空のままなら元に戻す", () => {
    const { container, handle } = mount();
    const depth = fieldNamed(container, "奥行き");
    typeInto(depth, "10");
    act(() => {
      depth.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    });
    expect(handle.getActivePlan().size.depth).toBe(10);

    typeInto(depth, "");
    act(() => {
      depth.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    });
    expect(handle.getActivePlan().size.depth).toBe(10);
    expect(fieldNamed(container, "奥行き").value).toBe("10");
  });

  it("範囲の外は端で止める", () => {
    const { container, handle } = mount();
    const input = fieldNamed(container, "間口");
    typeInto(input, "99");
    press(input, "Enter");
    expect(handle.getActivePlan().size.width).toBe(16);
  });

  it("外皮を変えると、選んでいたものを離す", () => {
    const onSelect = vi.fn();
    const { container } = mount({ config: { onSelect } });
    const focus = container.querySelector(".fp-focus")!;
    press(focus, "Enter");
    expect(onSelect).toHaveBeenLastCalledWith({ kind: "room", id: expect.any(String) });
    const input = fieldNamed(container, "間口");
    typeInto(input, "10");
    press(input, "Enter");
    expect(onSelect).toHaveBeenLastCalledWith(null);
  });
});

describe("設定を毎回作り直す親の下でも壊れない", () => {
  it("親が描き直しても、保存の読み込みで編集が巻き戻らない", () => {
    const stored = defaultPlanFile();
    stored.plans[0].name = "前に作った案";
    window.localStorage.setItem(STORAGE_KEY, serializePlanFile(stored));

    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    let handle: SimulatorApi | null = null;
    let redraw: (() => void) | null = null;
    const api = () => handle as unknown as SimulatorApi;

    function Parent() {
      const [count, setCount] = useState(0);
      redraw = () => setCount((value) => value + 1);
      // 設定の入れ物を毎回その場で作る書き方（README は useMemo を勧めるが、これでも壊さない）
      return (
        <Simulator
          config={{ labels: {}, features: { scene: false } }}
          className={`draw-${count}`}
          handleRef={(next) => (handle = next)}
        />
      );
    }
    act(() => root.render(<Parent />));
    expect(api().getActivePlan().name).toBe("前に作った案");

    // 書き出しを待っている 300ms の間に、親が描き直す
    click(buttonNamed(container, "案を足す"));
    expect(api().getFile().plans).toHaveLength(2);
    act(() => redraw!());
    expect(api().getFile().plans).toHaveLength(2);
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(JSON.parse(window.localStorage.getItem(STORAGE_KEY)!).plans).toHaveLength(2);
    act(() => root.unmount());
  });

  it("config.plan を渡した埋め込みは、鍵を分けない限り保存しない", () => {
    const file = defaultPlanFile();
    file.plans[0].name = "物件 A";
    const { container, handle } = mount({ config: { plan: file } });
    expect(handle.getActivePlan().name).toBe("物件 A");
    click(buttonNamed(container, "案を足す"));
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
  });

  it("config.plan でも、鍵を渡されていれば保存する", () => {
    const file = defaultPlanFile();
    const { container } = mount({ config: { plan: file, storage: { key: "shop:fp" } } });
    click(buttonNamed(container, "案を足す"));
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(window.localStorage.getItem("shop:fp")).not.toBeNull();
  });

  it("「動きを減らす」設定の変更を聞き、unmount で聞くのをやめる", () => {
    const listeners = new Set<() => void>();
    const query = {
      matches: false,
      addEventListener: (_type: string, fn: () => void) => listeners.add(fn),
      removeEventListener: (_type: string, fn: () => void) => listeners.delete(fn),
    };
    vi.stubGlobal("matchMedia", vi.fn(() => query));
    const { root } = mount();
    expect(listeners.size).toBe(1);
    act(() => root.unmount());
    expect(listeners.size).toBe(0);
    vi.unstubAllGlobals();
  });
});

describe("3D の受け渡し", () => {
  afterEach(() => {
    resetSceneRegistry();
  });

  it("3D の用意ができたら、3D の書き出しボタンが押せる", async () => {
    const getContext = fakeWebgl();
    const canvas = document.createElement("canvas");
    const renderNow = vi.fn();
    const Fake: SceneComponent = ({ onReady }) => {
      useEffect(() => {
        onReady?.({ renderNow, canvas } as SceneApi);
      }, [onReady]);
      return null;
    };
    registerScene(Fake);
    const { container } = mount();
    const sceneButton = () => buttonNamed(container, "3D を PNG で") as HTMLButtonElement;
    const bothButton = () => buttonNamed(container, "両方を 1 枚で") as HTMLButtonElement;
    expect(sceneButton().disabled).toBe(true);
    await act(async () => {
      await Promise.resolve();
    });
    expect(sceneButton().disabled).toBe(false);
    expect(bothButton().disabled).toBe(false);
    getContext.mockRestore();
    vi.unstubAllGlobals();
  });

  it("3D の束が見つからなければ、断りを出して間取り図は使えるままにする", async () => {
    const getContext = fakeWebgl();
    const { container } = mount();
    await act(async () => {
      // 合図が来ないまま読み込みが終わった（3D の束を置いていないサイト）
      window.dispatchEvent(new Event("load"));
      await Promise.resolve();
    });
    expect(container.querySelector(".fp-loading")?.textContent).toContain("読み込めませんでした");
    expect(container.querySelector("svg.fp-plan")).not.toBeNull();
    expect(buttonNamed(container, "塗る")).toBeTruthy();
    getContext.mockRestore();
    vi.unstubAllGlobals();
  });
});

describe("狭い画面では 3D をたたむ", () => {
  /** ルート要素の幅を返す ResizeObserver のふり。jsdom には無い */
  function stubWidth(width: number) {
    class FakeObserver {
      constructor(private readonly callback: (entries: { contentRect: { width: number } }[]) => void) {}
      observe() {
        this.callback([{ contentRect: { width } }]);
      }
      unobserve() {}
      disconnect() {}
    }
    vi.stubGlobal("ResizeObserver", FakeObserver);
  }

  const sceneScripts = () => Array.from(document.querySelectorAll("script[data-fp-scene]"));

  afterEach(() => {
    resetSceneRegistry();
    for (const script of sceneScripts()) script.remove();
    vi.unstubAllGlobals();
  });

  it("幅 375 では「3D で見る」だけを出し、押すまで 3D の部品を読み込まない", () => {
    const getContext = fakeWebgl();
    stubWidth(375);
    const { container } = mount({ config: { scene: { src: "./floorplan-3d.global.js" } } });
    expect(container.querySelector(".fp-stage")).toBeNull();
    expect(buttonNamed(container, "3D で見る")).toBeTruthy();
    // 押すまでは script も足さない（= loadScene を呼んでいない）
    expect(sceneScripts()).toHaveLength(0);

    click(buttonNamed(container, "3D で見る"));
    expect(container.querySelector(".fp-stage")).not.toBeNull();
    expect(sceneScripts()).toHaveLength(1);

    click(buttonNamed(container, "3D を閉じる"));
    expect(container.querySelector(".fp-stage")).toBeNull();
    expect(buttonNamed(container, "3D で見る")).toBeTruthy();
    getContext.mockRestore();
  });

  it("3D を閉じたら「3D を PNG で」を押せなくする（白い PNG を落とさない）", async () => {
    const getContext = fakeWebgl();
    stubWidth(375);
    const canvas = document.createElement("canvas");
    const Fake: SceneComponent = ({ onReady }) => {
      useEffect(() => {
        onReady?.({ renderNow: () => {}, canvas } as SceneApi);
      }, [onReady]);
      return null;
    };
    registerScene(Fake);
    const { container } = mount();
    const sceneButton = () => buttonNamed(container, "3D を PNG で") as HTMLButtonElement;
    const bothButton = () => buttonNamed(container, "両方を 1 枚で") as HTMLButtonElement;
    expect(sceneButton().disabled).toBe(true);

    click(buttonNamed(container, "3D で見る"));
    await act(async () => {
      await Promise.resolve();
    });
    expect(sceneButton().disabled).toBe(false);
    expect(bothButton().disabled).toBe(false);

    click(buttonNamed(container, "3D を閉じる"));
    expect(sceneButton().disabled).toBe(true);
    expect(bothButton().disabled).toBe(true);

    // 開き直せば、また押せる（Scene の onReady がもう一度呼ばれる）
    click(buttonNamed(container, "3D で見る"));
    await act(async () => {
      await Promise.resolve();
    });
    expect(sceneButton().disabled).toBe(false);
    getContext.mockRestore();
  });

  it("3D の開け閉めのボタンは、開いているかどうかを aria-expanded で伝える", () => {
    const getContext = fakeWebgl();
    stubWidth(375);
    const { container } = mount();
    expect(buttonNamed(container, "3D で見る").getAttribute("aria-expanded")).toBe("false");
    click(buttonNamed(container, "3D で見る"));
    expect(buttonNamed(container, "3D を閉じる").getAttribute("aria-expanded")).toBe("true");
    getContext.mockRestore();
  });

  it("窓ではなく枠の幅で決める（広い窓の中の狭い枠でもたたむ）", () => {
    const getContext = fakeWebgl();
    // 呼び返しを出さない ResizeObserver。最初の 1 回を自分で測れているかだけを見る
    class SilentObserver {
      observe() {}
      unobserve() {}
      disconnect() {}
    }
    vi.stubGlobal("ResizeObserver", SilentObserver);
    vi.stubGlobal("innerWidth", 1440);
    const rect = vi
      .spyOn(window.HTMLDivElement.prototype, "getBoundingClientRect")
      .mockReturnValue({ width: 300, height: 600 } as DOMRect);
    const { container } = mount();
    expect(container.querySelector(".fp-stage")).toBeNull();
    expect(buttonNamed(container, "3D で見る")).toBeTruthy();
    rect.mockRestore();
    getContext.mockRestore();
  });

  it("幅が測れない（jsdom・表示前）ときは、窓の幅で代える", () => {
    const getContext = fakeWebgl();
    vi.stubGlobal("innerWidth", 1440);
    const rect = vi
      .spyOn(window.HTMLDivElement.prototype, "getBoundingClientRect")
      .mockReturnValue({ width: 0, height: 0 } as DOMRect);
    const { container } = mount();
    expect(container.querySelector(".fp-stage")).not.toBeNull();
    rect.mockRestore();
    getContext.mockRestore();
  });

  it("collapseBelow が 0 なら、狭くても最初から枠を出す", () => {
    const getContext = fakeWebgl();
    stubWidth(375);
    const { container } = mount({ config: { features: { collapseBelow: 0 } } });
    expect(container.querySelector(".fp-stage")).not.toBeNull();
    expect([...container.querySelectorAll("button")].some((b) => b.textContent === "3D で見る")).toBe(false);
    getContext.mockRestore();
  });

  it("広い画面（ResizeObserver の無い環境も）では、たたまない", () => {
    const getContext = fakeWebgl();
    const { container } = mount();
    expect(container.querySelector(".fp-stage")).not.toBeNull();
    getContext.mockRestore();
  });

  it("scene.src の script は、2 つ置いても 1 本だけ", () => {
    const getContext = fakeWebgl();
    mount({ config: { scene: { src: "./floorplan-3d.global.js" } } });
    mount({ config: { scene: { src: "./floorplan-3d.global.js" }, storage: { key: "two" } } });
    expect(sceneScripts()).toHaveLength(1);
    getContext.mockRestore();
  });

  it("scene.src が読めなければ、断りを出して間取り図は使えるままにする", async () => {
    const getContext = fakeWebgl();
    const { container } = mount({ config: { scene: { src: "./missing-3d.js" } } });
    const script = sceneScripts()[0];
    expect(script).toBeTruthy();
    await act(async () => {
      script.dispatchEvent(new Event("error"));
      await Promise.resolve();
    });
    expect(container.querySelector(".fp-loading")?.textContent).toContain("読み込めませんでした");
    expect(container.querySelector("svg.fp-plan")).not.toBeNull();
    getContext.mockRestore();
  });
});

describe("印刷", () => {
  it("1 枚には、画面に出していない階の間取り図も色つきで載る", () => {
    let html = "";
    const tab = {
      document: {
        write: (value: string) => {
          html = value;
        },
        close: () => {},
      },
      print: () => {},
      focus: () => {},
    } as unknown as Window;
    const open = vi.spyOn(window, "open").mockReturnValue(tab);
    const { container } = mount();
    click(buttonNamed(container, "印刷（PDF 保存）"));
    expect(open).toHaveBeenCalled();
    expect(html).toContain("<figcaption>1F</figcaption>");
    expect(html).toContain("<figcaption>2F</figcaption>");
    expect(html.match(/<svg/g) ?? []).toHaveLength(2);
    // 別のタブには CSS が付いていかないので、色は SVG の中に入れて渡す
    expect(html).toContain(".fp-room{fill:");
    expect(html).not.toContain("var(");
    // 2F の部屋は 2F の図面にだけ出る
    expect(html).toContain("主寝室");
    open.mockRestore();
  });

  it("1F と 2F の色がそろう（画面に出していない階も --fp-* を受け取る）", () => {
    let html = "";
    const tab = {
      document: { write: (value: string) => (html = value), close: () => {} },
      print: () => {},
      focus: () => {},
    } as unknown as Window;
    const open = vi.spyOn(window, "open").mockReturnValue(tab);
    const { container } = mount();
    // 買い手が --fp-room を差し替えた状態。画面の図面にだけ効く
    const svg = container.querySelector("svg.fp-plan") as SVGSVGElement;
    svg.style.setProperty("--fp-room", "#ff0000");
    click(buttonNamed(container, "印刷（PDF 保存）"));
    expect(html.match(/<figure/g) ?? []).toHaveLength(2);
    // 2 枚とも同じ色。片方だけ既定の色に落ちていたら食い違う
    expect(html.match(/\.fp-room\{fill:#ff0000\}/g) ?? []).toHaveLength(2);
    expect(html).not.toContain(".fp-room{fill:#efece4}");
    open.mockRestore();
  });

  it("平屋では 1 枚だけ載せる", () => {
    let html = "";
    const tab = {
      document: { write: (value: string) => (html = value), close: () => {} },
      print: () => {},
      focus: () => {},
    } as unknown as Window;
    const open = vi.spyOn(window, "open").mockReturnValue(tab);
    const { container } = mount();
    click(buttonNamed(container, "平屋"));
    click(buttonNamed(container, "印刷（PDF 保存）"));
    expect(html.match(/<svg/g) ?? []).toHaveLength(1);
    open.mockRestore();
  });
});
