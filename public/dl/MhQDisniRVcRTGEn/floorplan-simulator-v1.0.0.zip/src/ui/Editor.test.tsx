import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { DEFAULT_LABELS } from "./labels";
import { defaultPlanFile, type PlanDoc } from "../model/plan";
import { Editor, nudge, pickAt, removeSelection, rotateSelection, ZOOM_MAX, ZOOM_STEP } from "./Editor";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const doc: PlanDoc = defaultPlanFile().plans[0];

describe("pickAt", () => {
  it("家具の上をタップすると家具を返す", () => {
    const item = doc.floors[1].furniture[0];
    expect(pickAt(doc, 1, item.x, item.z, 0)).toEqual({ kind: "furniture", id: item.id });
  });

  it("何も無いところをタップすると、その下の部屋を返す", () => {
    const target = pickAt(doc, 1, 0.25, 0.25, 0);
    expect(target?.kind).toBe("room");
  });

  it("輪郭の外は null", () => {
    expect(pickAt(doc, 1, 99, 99, 0)).toBeNull();
  });

  it("建具は家具より先に拾う", () => {
    const opening = doc.floors[1].openings[0];
    const along = opening.start + opening.width / 2;
    const point = opening.axis === "x" ? { x: opening.at, z: along } : { x: along, z: opening.at };
    expect(pickAt(doc, 1, point.x, point.z, 0.12)).toEqual({ kind: "opening", id: opening.id });
  });

  it("外周は輪郭の外でも拾う", () => {
    const part = doc.floors[2].exterior[0];
    expect(pickAt(doc, 2, part.start + part.length / 2, doc.size.depth + 0.5, 0)).toEqual({
      kind: "exterior",
      id: part.id,
    });
  });
});

describe("矢印で動かす・回す・消す", () => {
  it("家具は 0.25 m 動く", () => {
    const item = doc.floors[1].furniture[0];
    const next = nudge(doc, 1, { kind: "furniture", id: item.id }, 0.25, 0);
    expect(next.furniture[0].x).toBeCloseTo(item.x + 0.25, 9);
  });

  it("建具は壁に沿って動く", () => {
    const opening = doc.floors[1].openings[0];
    const next = nudge(doc, 1, { kind: "opening", id: opening.id }, 0.25, 0.25);
    const moved = next.openings.find((o) => o.id === opening.id)!;
    expect(Math.abs(moved.start - opening.start)).toBeLessThanOrEqual(0.25);
  });

  it("部屋は動かない", () => {
    const room = doc.floors[1].layout.rooms[0];
    expect(nudge(doc, 1, { kind: "room", id: room.id }, 0.25, 0)).toBe(doc.floors[1]);
  });

  it("rotateSelection は家具と設備だけ回し、建具は開き勝手を送る", () => {
    const item = doc.floors[1].furniture[0];
    expect(rotateSelection(doc, 1, { kind: "furniture", id: item.id }).furniture[0].rotation).toBe(90);
    const fixture = doc.floors[1].fixtures[0];
    expect(rotateSelection(doc, 1, { kind: "fixture", id: fixture.id }).fixtures[0].rotation).toBe(90);
    const opening = doc.floors[1].openings[0];
    const turned = rotateSelection(doc, 1, { kind: "opening", id: opening.id });
    const after = turned.openings.find((o) => o.id === opening.id)!;
    expect(`${after.hinge}/${after.swing}`).not.toBe(`${opening.hinge}/${opening.swing}`);
  });

  it("removeSelection は選んだものだけ消す。部屋は消さない", () => {
    const item = doc.floors[1].furniture[0];
    const next = removeSelection(doc, 1, { kind: "furniture", id: item.id });
    expect(next.furniture.some((f) => f.id === item.id)).toBe(false);
    const room = doc.floors[1].layout.rooms[0];
    expect(removeSelection(doc, 1, { kind: "room", id: room.id })).toBe(doc.floors[1]);
  });
});

describe("描く", () => {
  function render(props: Partial<Parameters<typeof Editor>[0]> = {}) {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const onSelect = vi.fn();
    const onFloorChange = vi.fn();
    act(() => {
      root.render(
        <Editor
          doc={doc}
          floor={1}
          mode="select"
          zoom={1}
          selection={null}
          showDimensions={false}
          readonly={false}
          labels={DEFAULT_LABELS}
          activeRoomId={null}
          openingPreset="door"
          fixtureKind="closet"
          onSelect={onSelect}
          onFloorChange={onFloorChange}
          onNotice={vi.fn()}
          {...props}
        />,
      );
    });
    return { container, root, onSelect, onFloorChange };
  }

  it("部屋・家具・建具・外周を描き、拡大縮小のボタンを出す", () => {
    const { container } = render();
    const svg = container.querySelector("svg.fp-plan")!;
    expect(svg.getAttribute("viewBox")).toBe("-12 -12 924 824");
    expect(container.querySelectorAll(".fp-room, .fp-room-selected").length).toBeGreaterThan(0);
    expect(container.querySelectorAll(".fp-item").length).toBe(
      doc.floors[1].furniture.length + doc.floors[1].fixtures.length,
    );
    expect(container.querySelectorAll(".fp-opening-cut").length).toBe(doc.floors[1].openings.length);
    expect(container.querySelectorAll("button[type='button']").length).toBe(3);
    expect(container.querySelector(".fp-dim-text")).toBeNull();
  });

  it("2F のバルコニーのぶん、枠が下へ伸びる（外周が切れない）", () => {
    const { container } = render({ floor: 2 });
    const part = doc.floors[2].exterior[0];
    expect(part.side).toBe("s");
    const box = container
      .querySelector("svg.fp-plan")!
      .getAttribute("viewBox")!
      .split(" ")
      .map(Number);
    expect(box[3]).toBe(824 + part.depth * 100);
    // バルコニーの下端（奥行き 8 m + 1.25 m）が枠の中に入る
    expect((doc.size.depth + part.depth) * 100).toBeLessThan(box[1] + box[3]);
  });

  it("寸法を出すと寸法の文字が現れる", () => {
    const { container } = render({ showDimensions: true });
    expect(container.querySelectorAll(".fp-dim-text").length).toBeGreaterThan(0);
  });

  it("「塗る」のあいだは家具に触れない", () => {
    const { container } = render({ mode: "paint" });
    expect(container.querySelectorAll(".fp-item-locked").length).toBeGreaterThan(0);
    expect(container.querySelector("svg.fp-plan")!.getAttribute("class")).toContain("fp-plan-paint");
  });

  it("readonly では部屋のキーボードの的だけになり、家具はつかめない", () => {
    const { container } = render({ readonly: true });
    expect(container.querySelectorAll(".fp-item-locked").length).toBe(
      doc.floors[1].furniture.length + doc.floors[1].fixtures.length,
    );
  });

  it("拡大のボタンで onZoom が呼ばれる", () => {
    const onZoom = vi.fn();
    const { container } = render({ onZoom });
    const buttons = [...container.querySelectorAll("button")];
    act(() => {
      buttons[0].dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });
    expect(onZoom).toHaveBeenCalledWith(1 * ZOOM_STEP);
  });

  describe("2 本指のピンチ", () => {
    type PatchedSvg = { getScreenCTM?: () => unknown };
    type PatchedElement = { hasPointerCapture?: (id: number) => boolean };

    beforeEach(() => {
      // jsdom には SVG の座標変換も指の捕まえ方も無い。1 m = 100 px の写し取りで代える
      (window.SVGSVGElement.prototype as PatchedSvg).getScreenCTM = () => ({ inverse: () => ({}) });
      (window.Element.prototype as PatchedElement).hasPointerCapture = () => false;
      vi.stubGlobal(
        "DOMPoint",
        class {
          x: number;
          y: number;
          constructor(x: number, y: number) {
            this.x = x;
            this.y = y;
          }
          matrixTransform() {
            return { x: this.x, y: this.y };
          }
        },
      );
    });

    afterEach(() => {
      vi.unstubAllGlobals();
      delete (window.SVGSVGElement.prototype as PatchedSvg).getScreenCTM;
      delete (window.Element.prototype as PatchedElement).hasPointerCapture;
    });

    function fingers(container: HTMLElement) {
      const svg = container.querySelector("svg.fp-plan")!;
      return (type: string, pointerId: number, x: number, y: number, buttons = 1) =>
        act(() => {
          svg.dispatchEvent(
            new PointerEvent(type, {
              bubbles: true,
              pointerId,
              pointerType: "touch",
              clientX: x,
              clientY: y,
              buttons,
            }),
          );
        });
    }

    it("指の間隔の比で onZoom を呼び、2 本目の指では塗らない", () => {
      const onZoom = vi.fn();
      const { container, onFloorChange } = render({ mode: "paint", onZoom });
      const send = fingers(container);
      send("pointerdown", 1, 100, 100);
      const painted = onFloorChange.mock.calls.length;

      // 2 本目。ここまでの塗りは手放し、以降はピンチ
      send("pointerdown", 2, 200, 100);
      expect(onFloorChange).toHaveBeenCalledTimes(painted);
      // 間隔が 100 → 200 で 2 倍
      send("pointermove", 2, 300, 100);
      expect(onZoom).toHaveBeenLastCalledWith(2);
      expect(onFloorChange).toHaveBeenCalledTimes(painted);
      // 上限で止まる
      send("pointermove", 2, 1100, 100);
      expect(onZoom).toHaveBeenLastCalledWith(ZOOM_MAX);
    });

    it("指を離すと元に戻り、残った指で塗り直さない", () => {
      const onZoom = vi.fn();
      const { container, onFloorChange } = render({ mode: "paint", onZoom });
      const send = fingers(container);
      send("pointerdown", 1, 100, 100);
      send("pointerdown", 2, 200, 100);
      const painted = onFloorChange.mock.calls.length;
      send("pointerup", 2, 200, 100, 0);
      send("pointermove", 1, 400, 400);
      expect(onFloorChange).toHaveBeenCalledTimes(painted);
      expect(onZoom).not.toHaveBeenCalled();
    });

    it("マウスでは 2 つ目のボタンでも拡大縮小を始めない", () => {
      const onZoom = vi.fn();
      const { container } = render({ onZoom });
      const svg = container.querySelector("svg.fp-plan")!;
      for (const clientX of [100, 200]) {
        act(() => {
          svg.dispatchEvent(
            new PointerEvent("pointerdown", {
              bubbles: true,
              pointerId: clientX,
              pointerType: "mouse",
              clientX,
              clientY: 100,
            }),
          );
        });
      }
      expect(onZoom).not.toHaveBeenCalled();
    });
  });
});
