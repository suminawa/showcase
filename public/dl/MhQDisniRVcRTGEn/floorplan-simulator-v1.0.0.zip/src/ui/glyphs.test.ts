import { describe, expect, it } from "vitest";
import { addExterior, exteriorRect } from "../model/exterior";
import { fixtureSeed, type Fixture } from "../model/fixtures";
import { presetSeed } from "../model/catalog";
import { type PlacedFurniture } from "../model/furniture";
import { DEFAULT_SIZE } from "../model/house";
import { type Opening } from "../model/openings";
import {
  dimensionShapes,
  exteriorShapes,
  fixtureShapes,
  furnitureShapes,
  openingHitBox,
  openingShapes,
  planOverhang,
  planViewBox,
  ROLE_CLASS,
  SCALE,
  type Shape,
} from "./glyphs";

const SIZE = DEFAULT_SIZE;

function op(patch: Partial<Opening> = {}): Opening {
  return {
    id: "o-1",
    kind: "door",
    style: null,
    axis: "x",
    at: 5.5,
    start: 2,
    width: 0.75,
    sill: 0,
    height: 2,
    hinge: "start",
    swing: "plus",
    ...patch,
  };
}

const roles = (shapes: Shape[]) => shapes.map((shape) => shape.role);
const kinds = (shapes: Shape[]) => shapes.map((shape) => shape.kind);

describe("下ごしらえ", () => {
  it("1 m = 100 単位。viewBox は外皮から作る", () => {
    expect(SCALE).toBe(100);
    expect(planViewBox(SIZE, 1)).toBe("-12 -12 924 824");
    // 拡大すると枠が狭くなり、中心はそのまま
    const zoomed = planViewBox(SIZE, 1.25).split(" ").map(Number);
    expect(zoomed[2]).toBeLessThan(924);
    expect(zoomed[0] + zoomed[2] / 2).toBeCloseTo(450, 6);
  });

  it("外周が無ければ、はみ出しは 0 で枠も変わらない", () => {
    expect(planOverhang(SIZE, [])).toEqual({ n: 0, e: 0, s: 0, w: 0 });
    expect(planViewBox(SIZE, 1, planOverhang(SIZE, []))).toBe(planViewBox(SIZE, 1));
  });

  it("南のバルコニーのぶん、枠が奥行き方向へ伸びる（PNG と印刷から切れないように）", () => {
    const parts = addExterior(SIZE, [], "balcony", "s", SIZE.width / 2);
    const overhang = planOverhang(SIZE, parts);
    expect(overhang).toEqual({ n: 0, e: 0, s: 1.25, w: 0 });

    const plain = planViewBox(SIZE, 1).split(" ").map(Number);
    const grown = planViewBox(SIZE, 1, overhang).split(" ").map(Number);
    // 伸びるのは高さだけ。上と左右の余白は 12 のまま
    expect(grown[3]).toBe(plain[3] + 1.25 * SCALE);
    expect(grown[0]).toBe(plain[0]);
    expect(grown[1]).toBe(-12);
    expect(grown[2]).toBe(plain[2]);
    // バルコニーの下端が枠の中に収まる（元の枠では 812 で切れていた）
    const rect = exteriorRect(SIZE, parts[0]);
    expect((rect.z + rect.d) * SCALE).toBe(925);
    expect((rect.z + rect.d) * SCALE).toBeLessThan(grown[1] + grown[3]);
    expect((rect.z + rect.d) * SCALE).toBeGreaterThan(plain[1] + plain[3]);
  });

  it("西と北の外周では、枠が左と上へ伸びる", () => {
    const parts = addExterior(
      SIZE,
      addExterior(SIZE, [], "terrace", "w", SIZE.depth / 2),
      "porch",
      "n",
      SIZE.width / 2,
    );
    const overhang = planOverhang(SIZE, parts);
    expect(overhang).toEqual({ n: 1, e: 0, s: 0, w: 1.5 });
    const box = planViewBox(SIZE, 1, overhang).split(" ").map(Number);
    expect(box[0]).toBe(-162);
    expect(box[1]).toBe(-112);
    expect(box[2]).toBe(924 + 150);
    expect(box[3]).toBe(824 + 100);
  });

  it("役割ごとの class が決まっている", () => {
    expect(ROLE_CLASS.cut).toBe("fp-opening-cut");
    expect(ROLE_CLASS.stroke).toBe("fp-opening");
    expect(ROLE_CLASS.fill).toBe("fp-glyph");
    expect(ROLE_CLASS.dim).toBe("fp-dim-line");
  });
});

describe("建具の記号", () => {
  it("共通: 開口ぶんの壁を切る線と、両端の枠の短線", () => {
    const shapes = openingShapes(op());
    const cut = shapes.find((shape) => shape.role === "cut")!;
    expect(cut.kind).toBe("line");
    expect(cut).toMatchObject({ x1: 550, y1: 200, x2: 550, y2: 275 });
    expect(shapes.filter((shape) => shape.role === "stroke" && shape.kind === "line").length).toBeGreaterThanOrEqual(2);
  });

  it("ドアは扉の板 1 本と弧 1 つ", () => {
    const shapes = openingShapes(op());
    expect(kinds(shapes)).toContain("path");
    const arc = shapes.find((shape) => shape.kind === "path")!;
    expect(arc.kind === "path" && arc.d.startsWith("M")).toBe(true);
    expect(arc.kind === "path" && arc.d.includes("A 75 75")).toBe(true);
  });

  it("開く側を変えると扉の板が反対側へ出る", () => {
    const plus = openingShapes(op({ swing: "plus" }));
    const minus = openingShapes(op({ swing: "minus" }));
    const leafOf = (shapes: Shape[]) => {
      // .at() は tsconfig の lib（ES2020）に無いため、添字で末尾要素を取る
      const strokes = shapes.filter((s): s is Extract<Shape, { kind: "line" }> => s.kind === "line" && s.role === "stroke");
      return strokes[strokes.length - 1];
    };
    expect(leafOf(plus).x2).toBeGreaterThan(550);
    expect(leafOf(minus).x2).toBeLessThan(550);
  });

  it("吊元を変えると板の根元が反対の端へ移る", () => {
    const start = openingShapes(op({ hinge: "start" }));
    const end = openingShapes(op({ hinge: "end" }));
    const leafOf = (shapes: Shape[]) => {
      // .at() は tsconfig の lib（ES2020）に無いため、添字で末尾要素を取る
      const strokes = shapes.filter((s): s is Extract<Shape, { kind: "line" }> => s.kind === "line" && s.role === "stroke");
      return strokes[strokes.length - 1];
    };
    expect(leafOf(start).y1).toBeCloseTo(200, 6);
    expect(leafOf(end).y1).toBeCloseTo(275, 6);
  });

  it("引き戸は中央の細い線と、引き込む側の平行線 2 本", () => {
    const shapes = openingShapes(op({ kind: "sliding", width: 1.5 }));
    expect(roles(shapes).filter((role) => role === "thin")).toHaveLength(3);
    expect(kinds(shapes)).not.toContain("path");
  });

  it("腰窓は平行線 3 本、掃き出し窓はさらに破線 2 本", () => {
    const koshi = openingShapes(op({ kind: "window", style: "koshi", sill: 0.9, height: 1.2, width: 1.5 }));
    expect(roles(koshi).filter((role) => role === "thin")).toHaveLength(3);
    expect(roles(koshi)).not.toContain("dash");
    const haki = openingShapes(op({ kind: "window", style: "hakidashi", width: 1.75 }));
    expect(roles(haki).filter((role) => role === "dash")).toHaveLength(2);
  });

  it("z 軸の壁では x と y が入れ替わる", () => {
    const alongX = openingShapes(op({ axis: "x", at: 5.5, start: 2 }));
    const alongZ = openingShapes(op({ axis: "z", at: 5.5, start: 2 }));
    expect(alongZ).toHaveLength(alongX.length);
    // 開口を切る線: x 軸の壁は at が x、沿う向きが y。z 軸の壁はその逆
    expect(alongX[0]).toMatchObject({ kind: "line", x1: 550, y1: 200, x2: 550, y2: 275 });
    expect(alongZ[0]).toMatchObject({ kind: "line", x1: 200, y1: 550, x2: 275, y2: 550 });
    // 枠の短線（壁の厚みぶん、法線の向きへ ±8 単位）も同じように入れ替わる
    expect(alongX[1]).toMatchObject({ x1: 542, y1: 200, x2: 558, y2: 200 });
    expect(alongZ[1]).toMatchObject({ x1: 200, y1: 542, x2: 200, y2: 558 });
    // 役割の並びは軸で変わらない
    expect(roles(alongZ)).toEqual(roles(alongX));
  });

  it("当たり判定の箱は指の太さぶん広げられる", () => {
    const box = openingHitBox(op(), 0.12);
    expect(box.x).toBeCloseTo(550 - 12, 6);
    expect(box.w).toBeCloseTo(24, 6);
    expect(box.y).toBeCloseTo(200 - 12, 6);
    expect(box.h).toBeCloseTo(75 + 24, 6);
  });
});

describe("設備の記号", () => {
  function fixture(kind: Fixture["kind"]): Fixture {
    return { ...fixtureSeed(kind), id: "x-1", x: 4, z: 4, rotation: 0 };
  }

  it("外形の矩形と棚板の線が出る", () => {
    const shapes = fixtureShapes(fixture("closet"));
    expect(shapes.some((shape) => shape.kind === "rect" && shape.role === "fill")).toBe(true);
    expect(shapes.some((shape) => shape.role === "thin")).toBe(true);
  });

  it("扉の種類で記号が変わる", () => {
    const folding = fixtureShapes(fixture("closet"));
    const sliding = fixtureShapes(fixture("oshiire"));
    const hinged = fixtureShapes(fixture("genkan"));
    expect(hinged.some((shape) => shape.kind === "path")).toBe(true);
    expect(folding.filter((shape) => shape.role === "stroke").length).toBeGreaterThanOrEqual(2);
    expect(sliding.some((shape) => shape.kind === "path")).toBe(false);
  });

  it("階段は段板の線と上り方向の三角", () => {
    const shapes = fixtureShapes(fixture("stairs"));
    expect(shapes.filter((shape) => shape.role === "thin")).toHaveLength(12);
    expect(shapes.some((shape) => shape.kind === "path" && shape.role === "fill")).toBe(true);
  });

  it("外形の矩形は size の中に収まる（開き戸の弧だけは外へ出る）", () => {
    for (const kind of ["closet", "oshiire", "genkan", "stairs"] as const) {
      const item = fixture(kind);
      const halfW = (item.size.w / 2) * SCALE;
      const halfD = (item.size.d / 2) * SCALE;
      const rects = fixtureShapes(item).filter(
        (shape): shape is Extract<Shape, { kind: "rect" }> => shape.kind === "rect",
      );
      expect(rects.length).toBeGreaterThan(0);
      for (const shape of rects) {
        expect(shape.x).toBeGreaterThanOrEqual(-halfW - 1e-6);
        expect(shape.x + shape.w).toBeLessThanOrEqual(halfW + 1e-6);
        expect(shape.y).toBeGreaterThanOrEqual(-halfD - 1e-6);
        expect(shape.y + shape.h).toBeLessThanOrEqual(halfD + 1e-6);
      }
    }
  });
});

describe("家具と外周の記号", () => {
  it("家具は catalog の記号をそのまま図形にする", () => {
    const item: PlacedFurniture = {
      ...presetSeed("sofa", "sofa-3"),
      id: "f-1",
      x: 2,
      z: 2,
      rotation: 0,
    };
    const shapes = furnitureShapes(item);
    expect(shapes.filter((shape) => shape.kind === "rect")).toHaveLength(2);
    expect(shapes[0].role).toBe("fill");
  });

  it("外周は破線の矩形と名前。手すりがあれば細い線 3 本", () => {
    const shapes = exteriorShapes(SIZE, {
      id: "e-1",
      kind: "balcony",
      side: "s",
      start: 2,
      length: 3,
      depth: 1.25,
      railing: true,
    });
    expect(shapes.filter((shape) => shape.role === "dash")).toHaveLength(1);
    expect(shapes.filter((shape) => shape.role === "thin")).toHaveLength(3);
    const text = shapes.find((shape) => shape.kind === "text")!;
    expect(text.kind === "text" && text.text).toBe("バルコニー");
    const noRail = exteriorShapes(SIZE, {
      id: "e-2",
      kind: "porch",
      side: "n",
      start: 1,
      length: 2,
      depth: 1,
      railing: false,
    });
    expect(noRail.filter((shape) => shape.role === "thin")).toHaveLength(0);
  });
});

describe("寸法の記号", () => {
  it("上辺と左辺に寸法線、両端に斜線、中央に数値", () => {
    const shapes = dimensionShapes({ x: 1, z: 1, w: 2, d: 3 }, "2.00", "3.00");
    expect(shapes.filter((shape) => shape.kind === "text")).toHaveLength(2);
    // 寸法線 2 本 + 端の斜線 4 本
    expect(shapes.filter((shape) => shape.kind === "line" && shape.role === "dim")).toHaveLength(6);
  });

  it("片方だけでも出せる", () => {
    const shapes = dimensionShapes({ x: 0, z: 0, w: 1, d: 1 }, "1.00", null);
    expect(shapes.filter((shape) => shape.kind === "text")).toHaveLength(1);
    expect(dimensionShapes({ x: 0, z: 0, w: 1, d: 1 }, null, null)).toEqual([]);
  });
});
