/**
 * 売り物: 画面の文言。お客さまの目に触れるので、すべて敬体で書く。
 * config.labels で 1 つずつ差し替えられる（英語化もここで）。
 */
export type FloorplanLabels = {
  // モード
  modeGroup: string;
  modeSelect: string;
  modePaint: string;
  modeOpening: string;
  modeFixture: string;
  modeDimension: string;
  // 階
  floorGroup: string;
  floor1: string;
  floor2: string;
  floorAll: string;
  // 3D の見せ方
  viewGroup: string;
  viewOrbit: string;
  viewTop: string;
  lightGroup: string;
  lightDay: string;
  lightNight: string;
  open3d: string;
  close3d: string;
  building: string;
  noWebgl: string;
  noScene: string;
  // 案
  plansGroup: string;
  planAdd: string;
  planDuplicate: string;
  planRename: string;
  planRemove: string;
  planNameLabel: string;
  plansFull: string;
  // 部屋
  roomGroup: string;
  roomNew: string;
  roomLabel: string;
  // 外皮
  sizeGroup: string;
  sizePreset: string;
  sizeWidth: string;
  sizeDepth: string;
  sizeFloors: string;
  sizeFlat: string;
  sizeTwo: string;
  // 置くもの
  furnitureGroup: string;
  fixtureGroup: string;
  openingGroup: string;
  exteriorGroup: string;
  presetLabel: string;
  // 選択中
  selectedGroup: string;
  rotate: string;
  remove: string;
  swingNext: string;
  hingeStart: string;
  hingeEnd: string;
  swingPlus: string;
  swingMinus: string;
  railingLabel: string;
  stepsLabel: string;
  inchLabel: string;
  sideLabel: string;
  // 寸法
  dimensionShow: string;
  /** 入力欄の読み上げ。{name} に「ソファ」などが入る */
  sizeFormLabel: string;
  widthLabel: string;
  depthLabel: string;
  heightLabel: string;
  sillLabel: string;
  lengthLabel: string;
  areaUnit: string;
  joUnit: string;
  maxPrefix: string;
  // 拡大縮小
  zoomGroup: string;
  zoomIn: string;
  zoomOut: string;
  zoomFit: string;
  // 書き出し
  exportGroup: string;
  exportPlan: string;
  exportScene: string;
  exportBoth: string;
  print: string;
  popupBlocked: string;
  // そのほか
  reset: string;
  noFit: string;
  tvStandHint: string;
  caption: string;
  planAria: string;
};

export const DEFAULT_LABELS: FloorplanLabels = {
  modeGroup: "編集のしかた",
  modeSelect: "選ぶ",
  modePaint: "塗る",
  modeOpening: "建具",
  modeFixture: "設備",
  modeDimension: "寸法",

  floorGroup: "階",
  floor1: "1F",
  floor2: "2F",
  floorAll: "全体",

  viewGroup: "視点",
  viewOrbit: "斜めから",
  viewTop: "真上から",
  lightGroup: "明かり",
  lightDay: "昼",
  lightNight: "夜",
  open3d: "3D で見る",
  close3d: "3D を閉じる",
  building: "建物を組み立てています…",
  noWebgl: "お使いの環境では 3D（WebGL）を表示できません。間取り図の編集はそのままお使いいただけます。",
  noScene: "3D の部品を読み込めませんでした。間取り図の編集はそのままお使いいただけます。",

  plansGroup: "案",
  planAdd: "案を足す",
  planDuplicate: "複製",
  planRename: "名前",
  planRemove: "この案を消す",
  planNameLabel: "案の名前",
  plansFull: "案は 10 件までです。",

  roomGroup: "部屋",
  roomNew: "新しい部屋",
  roomLabel: "部屋の名前",

  sizeGroup: "外皮",
  sizePreset: "よくある大きさ",
  sizeWidth: "間口",
  sizeDepth: "奥行き",
  sizeFloors: "階数",
  sizeFlat: "平屋",
  sizeTwo: "2 階建て",

  furnitureGroup: "家具",
  fixtureGroup: "設備",
  openingGroup: "建具",
  exteriorGroup: "外周",
  presetLabel: "大きさ",

  selectedGroup: "選択中",
  rotate: "回す",
  remove: "消す",
  swingNext: "開き勝手",
  hingeStart: "吊元 手前",
  hingeEnd: "吊元 奥",
  swingPlus: "外へ開く",
  swingMinus: "内へ開く",
  railingLabel: "手すり",
  stepsLabel: "段数",
  inchLabel: "インチ",
  sideLabel: "面",

  dimensionShow: "寸法を出す",
  sizeFormLabel: "{name} の寸法",
  widthLabel: "幅",
  depthLabel: "奥行き",
  heightLabel: "高さ",
  sillLabel: "下端",
  lengthLabel: "長さ",
  areaUnit: "m²",
  joUnit: "帖",
  maxPrefix: "最大",

  zoomGroup: "表示の大きさ",
  zoomIn: "拡大",
  zoomOut: "縮小",
  zoomFit: "全体",

  exportGroup: "書き出し",
  exportPlan: "間取り図を PNG で",
  exportScene: "3D を PNG で",
  exportBoth: "両方を 1 枚で",
  print: "印刷（PDF 保存）",
  popupBlocked: "印刷用のタブが開けませんでした。ポップアップを許可してください。",

  reset: "最初に戻す",
  noFit: "そこには入りません。",
  tvStandHint: "テレビ台は幅 {width} m 以上が目安です。",
  caption:
    "間取り図は「塗る」で部屋をなぞり、「選ぶ」で家具を動かし、「寸法」で数値を直せます。拡大縮小は 2 本指のピンチでもできます。3D はドラッグで回転します。",
  planAria: "{floor} 階の間取り図",
};
