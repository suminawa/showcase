import { afterEach, describe, expect, it, vi } from "vitest";
import {
  EXPORT_WIDTH,
  downloadBlob,
  exportFileName,
  renderPng,
  sanitizeName,
  snapshotCanvas,
  svgToDataUrl,
} from "./export";

/** 間取り図の代わりの SVG。色は CSS の class に任せる（画面と同じ作り） */
function planSvg(): SVGSVGElement {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 900 800");
  const room = document.createElementNS("http://www.w3.org/2000/svg", "rect");
  room.setAttribute("class", "fp-room");
  room.setAttribute("width", "100");
  svg.append(room);
  return svg;
}

/** drawImage の呼ばれ方を覚える 2D の描き先 */
function recordingCanvas() {
  const drawn: unknown[] = [];
  const ctx = {
    fillStyle: "",
    fillRect: vi.fn(),
    drawImage: vi.fn((...args: unknown[]) => drawn.push(args[0])),
  };
  const canvas = {
    width: 0,
    height: 0,
    getContext: () => ctx,
    toBlob: (done: (blob: Blob | null) => void) => done(new Blob(["png"])),
  };
  return { canvas, ctx, drawn };
}

/** jsdom は画像を読まないので、src を入れたら読めたことにする */
class FakeImage {
  onload: (() => void) | null = null;
  onerror: (() => void) | null = null;
  width = 900;
  height = 800;
  set src(_value: string) {
    queueMicrotask(() => this.onload?.());
  }
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("ファイル名", () => {
  it("記号を落として、案の名前を挟む", () => {
    expect(sanitizeName("南入りの案")).toBe("南入りの案");
    expect(sanitizeName('A/B:C*D?E"F<G>H|I')).toBe("A-B-C-D-E-F-G-H-I");
    expect(sanitizeName("   ")).toBe("案");
    // 区切りしか残らない名前も「案」に落とす（"////" が "----" にならないように）
    expect(sanitizeName("////")).toBe("案");
    expect(sanitizeName("/ * ?")).toBe("案");
    expect(sanitizeName("A/B")).toBe("A-B");
    expect(sanitizeName("あ".repeat(60))).toHaveLength(40);
  });

  it("3 通りで名前を分ける", () => {
    expect(exportFileName("plan", "案 1")).toBe("間取り-案 1.png");
    expect(exportFileName("scene", "案 1")).toBe("間取り-案 1-3D.png");
    expect(exportFileName("both", "案 1")).toBe("間取り-案 1-両方.png");
  });
});

describe("svgToDataUrl", () => {
  it("data:image/svg+xml で始まり、中身が入っている", () => {
    const svg = planSvg();
    const url = svgToDataUrl(svg);
    expect(url.startsWith("data:image/svg+xml;charset=utf-8,")).toBe(true);
    expect(decodeURIComponent(url).includes("<rect")).toBe(true);
    // xmlns が無い SVG でも、書き出しのときに付ける
    expect(decodeURIComponent(url).includes('xmlns="http://www.w3.org/2000/svg"')).toBe(true);
  });

  it("色を入れた <style> が入り、var() は残らない", () => {
    const markup = decodeURIComponent(svgToDataUrl(planSvg()));
    expect(markup).toContain("<style");
    expect(markup).not.toContain("var(");
    // 部屋・壁・記号・名前に、実際の色が入っている
    expect(markup).toContain(".fp-room{fill:#efece4}");
    expect(markup).toContain(".fp-wall{stroke:#1c1a15");
    expect(markup).toContain(".fp-glyph{fill:#ffffff;stroke:#6a665d");
    // 触るためだけの矩形が全面を覆わないよう、塗らないことを書いておく
    expect(markup).toContain(".fp-focus{fill:none;stroke:none}");
  });

  it("画面で --fp-* を差し替えていれば、その色で書き出す", () => {
    const svg = planSvg();
    svg.style.setProperty("--fp-room", "#112233");
    svg.style.setProperty("--fp-line-strong", "#445566");
    const markup = decodeURIComponent(svgToDataUrl(svg));
    expect(markup).toContain(".fp-room{fill:#112233}");
    expect(markup).toContain(".fp-wall{stroke:#445566");
    expect(markup).not.toContain("var(");
  });

  it("元の SVG は書き換えない", () => {
    const svg = planSvg();
    svgToDataUrl(svg);
    expect(svg.querySelector("style")).toBeNull();
    expect(svg.getAttribute("xmlns")).toBeNull();
  });
});

describe("snapshotCanvas", () => {
  it("いまの中身を別の canvas に写す", () => {
    const source = { width: 800, height: 600 } as HTMLCanvasElement;
    const { canvas, drawn } = recordingCanvas();
    vi.spyOn(document, "createElement").mockReturnValueOnce(canvas as unknown as HTMLElement);
    const shot = snapshotCanvas(source, document);
    expect(shot).toBe(canvas as unknown as HTMLCanvasElement);
    expect(canvas.width).toBe(800);
    expect(canvas.height).toBe(600);
    expect(drawn).toEqual([source]);
  });

  it("大きさの無い canvas は写さない", () => {
    expect(snapshotCanvas({ width: 0, height: 0 } as HTMLCanvasElement, document)).toBeNull();
  });
});

describe("renderPng", () => {
  it("書き出す相手が無ければ null", async () => {
    expect(await renderPng({ target: "plan", svg: null, canvas: null, background: "#fff", doc: document })).toBeNull();
    expect(await renderPng({ target: "scene", svg: null, canvas: null, background: "#fff", doc: document })).toBeNull();
  });

  it("既定の幅は 2000px", () => {
    expect(EXPORT_WIDTH).toBe(2000);
  });

  it("両方を 1 枚では、渡された 3D の写しをそのまま描く", async () => {
    vi.stubGlobal("Image", FakeImage);
    const { canvas, ctx, drawn } = recordingCanvas();
    vi.spyOn(document, "createElement").mockReturnValueOnce(canvas as unknown as HTMLElement);
    // 3D の canvas そのものではなく、書き出す直前に写し取ったもの
    const shot = { width: 800, height: 600 } as HTMLCanvasElement;
    const blob = await renderPng({
      target: "both",
      svg: planSvg(),
      canvas: shot,
      background: "#ffffff",
      doc: document,
    });
    expect(blob).not.toBeNull();
    expect(ctx.fillRect).toHaveBeenCalled();
    // 左が間取り図、右が 3D の写し
    expect(drawn).toHaveLength(2);
    expect(drawn[1]).toBe(shot);
    // 右半分は白いままにならない（x は左の幅ぶん進んでいる）
    const right = ctx.drawImage.mock.calls[1];
    expect(right[1]).toBeGreaterThan(0);
    expect(right[3]).toBeGreaterThan(0);
    expect(canvas.width).toBe(2000);
  });

  it("3D だけなら写しだけを描く", async () => {
    const { canvas, drawn } = recordingCanvas();
    vi.spyOn(document, "createElement").mockReturnValueOnce(canvas as unknown as HTMLElement);
    const shot = { width: 800, height: 600 } as HTMLCanvasElement;
    await renderPng({ target: "scene", svg: planSvg(), canvas: shot, background: "#fff", doc: document });
    expect(drawn).toEqual([shot]);
  });
});

describe("downloadBlob", () => {
  it("a タグを作って押し、1 拍おいてから後始末する", () => {
    vi.useFakeTimers();
    const createObjectURL = vi.fn(() => "blob:x");
    const revokeObjectURL = vi.fn();
    vi.stubGlobal("URL", { ...URL, createObjectURL, revokeObjectURL });
    const click = vi.fn();
    const anchor = document.createElement("a");
    anchor.click = click;
    const spy = vi.spyOn(document, "createElement").mockReturnValueOnce(anchor);
    downloadBlob(new Blob(["x"]), "間取り-案 1.png", document);
    expect(click).toHaveBeenCalled();
    expect(anchor.download).toBe("間取り-案 1.png");
    expect(document.body.contains(anchor)).toBe(false);
    // 押した直後に消すと、保存が始まる前に url が無くなるブラウザがある
    expect(revokeObjectURL).not.toHaveBeenCalled();
    vi.runAllTimers();
    expect(revokeObjectURL).toHaveBeenCalledWith("blob:x");
    spy.mockRestore();
    vi.useRealTimers();
  });
});
