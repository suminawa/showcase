/**
 * 売り物: 間取り図（SVG）を、そのまま絵にできる形に書き出す。
 *
 * 画面の SVG は styles/floorplan-simulator.css の .fp-* に色を任せているので、
 * XMLSerializer で取り出しただけの文字列には色がいっさい入っていない ──
 * それを <img> や別タブに渡すと、塗りは既定の黒、線は無しで描かれてしまう
 * （部屋も家具も真っ黒になり、fp-focus の矩形が上から全面を覆う）。
 *
 * そこで書き出す前に、いま効いている --fp-* の値を getComputedStyle で読み取り、
 * 実際の色に置き換えた <style> を SVG の中へ入れる。PNG も印刷も同じ関数を通す。
 */

/** 書き出す SVG に入れる色。styles/floorplan-simulator.css の .fp と同じ値を持つ */
export const PLAN_TOKENS: Readonly<Record<string, string>> = {
  "--fp-bg": "#faf8f3",
  "--fp-fg": "#1c1a15",
  "--fp-muted": "#6a665d",
  "--fp-brand": "#4a6b7d",
  "--fp-brand-ink": "#2f4855",
  "--fp-line": "rgba(28, 26, 21, 0.18)",
  "--fp-line-strong": "#1c1a15",
  "--fp-surface": "#ffffff",
  "--fp-input-line": "rgba(28, 26, 21, 0.35)",
  "--fp-room": "#efece4",
  "--fp-room-selected": "#4a6b7d",
  "--fp-glyph": "#6a665d",
  "--fp-glyph-selected": "#4a6b7d",
  "--fp-dim": "#6a665d",
};

/**
 * <style> の中へそのまま置ける値か。`}` や `;` で宣言の外へ出る書き方、
 * `<` で要素を閉じる書き方、引用符は受け取らない（既定の色に落とす）。
 * 色は買い手が CSS で決めるものなので、置き場所を間違えても図面が壊れないようにしておく。
 */
export function isSafeTokenValue(value: string): boolean {
  return value !== "" && !/[<>{};"'\\]/.test(value);
}

/**
 * いま効いている --fp-* の値。読めなければ既定値
 * （スタイルシートを読み込んでいない埋め込みや、テストの jsdom ではここに落ちる）。
 */
export function planTokens(svg: Element): Record<string, string> {
  const win = svg.ownerDocument?.defaultView;
  let computed: CSSStyleDeclaration | null = null;
  try {
    computed = win?.getComputedStyle(svg) ?? null;
  } catch {
    // getComputedStyle が使えない環境でも、既定の色で書き出せる
  }
  const out: Record<string, string> = {};
  for (const [name, fallback] of Object.entries(PLAN_TOKENS)) {
    const value = computed?.getPropertyValue(name)?.trim();
    out[name] = value && isSafeTokenValue(value) ? value : fallback;
  }
  return out;
}

/**
 * 書き出す SVG に入れる CSS。styles/floorplan-simulator.css の「間取り図」の節と同じ形を、
 * var() を使わずに書く（外部のスタイルシートが効かない場所へ持ち出すため）。
 */
export function planStyleBlock(svg: Element, tokensFrom: Element = svg): string {
  const t = planTokens(tokensFrom);
  return [
    `.fp-outline{fill:none;stroke:${t["--fp-line-strong"]};stroke-width:10}`,
    `.fp-room{fill:${t["--fp-room"]}}`,
    `.fp-room-selected{fill:${t["--fp-room-selected"]};fill-opacity:0.22}`,
    `.fp-grid{fill:none;stroke:${t["--fp-input-line"]};stroke-opacity:0.5;stroke-width:1}`,
    `.fp-wall{stroke:${t["--fp-line-strong"]};stroke-width:10;stroke-linecap:square}`,
    `.fp-focus{fill:none;stroke:none}`,
    `.fp-glyph{fill:${t["--fp-surface"]};stroke:${t["--fp-glyph"]};stroke-width:3}`,
    `.fp-glyph-selected{fill:${t["--fp-surface"]};stroke:${t["--fp-glyph-selected"]};stroke-width:6}`,
    `.fp-glyph-line{fill:none;stroke:${t["--fp-glyph"]};stroke-width:3}`,
    `.fp-glyph-thin{fill:none;stroke:${t["--fp-glyph"]};stroke-width:2}`,
    `.fp-glyph-dash{fill:none;stroke:${t["--fp-glyph"]};stroke-width:3;stroke-dasharray:14 10}`,
    `.fp-opening-cut{stroke:${t["--fp-surface"]};stroke-width:12;stroke-linecap:butt}`,
    `.fp-opening{fill:none;stroke:${t["--fp-line-strong"]};stroke-width:3}`,
    `.fp-opening-selected{fill:none;stroke:${t["--fp-glyph-selected"]};stroke-width:5}`,
    `.fp-name{fill:${t["--fp-fg"]};font-size:44px;font-weight:700;text-anchor:middle}`,
    `.fp-area{fill:${t["--fp-muted"]};font-size:40px;text-anchor:middle}`,
    `.fp-dim-line{fill:none;stroke:${t["--fp-dim"]};stroke-width:2}`,
    `.fp-dim-text{fill:${t["--fp-dim"]};font-size:32px;text-anchor:middle}`,
    `text{font-family:system-ui,sans-serif}`,
  ].join("");
}

/**
 * 書き出し用の SVG の文字列。色を入れた <style> と xmlns を足して組み立てる。
 * 元の SVG には触らない（画面はそのまま）。
 *
 * tokensFrom は色を読む先。画面に出していない階を document の外で描いたときは、
 * その SVG からは --fp-* が読めない（カスケードに乗っていない）ので、
 * 画面に出ている SVG を渡す ── そうしないと 1 枚の中で 1F と 2F の色が食い違う。
 */
export function serializePlanSvg(svg: SVGSVGElement, tokensFrom: Element = svg): string {
  const doc = svg.ownerDocument;
  const clone = svg.cloneNode(true) as SVGSVGElement;
  clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  clone.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
  const style = doc.createElementNS("http://www.w3.org/2000/svg", "style");
  style.textContent = planStyleBlock(svg, tokensFrom);
  clone.prepend(style);
  return new XMLSerializer().serializeToString(clone);
}
