import { createElement } from "react";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";

import { type FloorplanConfig } from "../ui/config";
import { Simulator, type SimulatorApi } from "../ui/Simulator";

export type FloorplanHandle = SimulatorApi & {
  /** 中身を消して、listener とタイマーを落とす */
  destroy(): void;
};

/**
 * 間取りシミュレーターを root の中に描く。描画実装はここ 1 つだけで、React ラッパーも同じものを呼ぶ。
 * root.render は既定では次の描画まで待つので、取っ手をその場で返せるよう flushSync で流し込む。
 */
export function mount(root: HTMLElement, config: FloorplanConfig = {}): FloorplanHandle {
  const reactRoot = createRoot(root);
  let api: SimulatorApi | null = null;
  flushSync(() => {
    reactRoot.render(
      createElement(Simulator, {
        config,
        handleRef: (next: SimulatorApi) => {
          api = next;
        },
      }),
    );
  });
  if (!api) throw new Error("間取りシミュレーターを描けませんでした");
  const current: SimulatorApi = api;
  return {
    getFile: () => current.getFile(),
    setFile: (file) => current.setFile(file),
    getActivePlan: () => current.getActivePlan(),
    setActivePlan: (id) => current.setActivePlan(id),
    exportPng: (target) => current.exportPng(target),
    print: () => current.print(),
    subscribe: (listener) => current.subscribe(listener),
    destroy: () => reactRoot.unmount(),
  };
}
