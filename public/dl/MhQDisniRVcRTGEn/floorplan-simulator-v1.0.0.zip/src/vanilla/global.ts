// IIFE の入口（1 本目）。<script src="floorplan.global.js"> で window.FloorplanSimulator になる
export { resolveConfig } from "../ui/config";
export { DEFAULT_LABELS } from "../ui/labels";
export { defaultPlanFile, parsePlanFile, parsePlanJson, serializePlanFile, STORAGE_KEY } from "../model/plan";
export { migrate } from "../model/migrate";
export { SIZE_PRESETS } from "../model/house";
export { mount } from "./mount";

// 3D の束（floorplan-3d.global.js）が同じ React を使うための受け渡し。
// 直接使うものではない
import React from "react";
import ReactJsxRuntime from "react/jsx-runtime";
import ReactDOM from "react-dom";
import ReactDOMClient from "react-dom/client";
export { React, ReactJsxRuntime, ReactDOM, ReactDOMClient };
