import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { defaultPlanFile, STORAGE_KEY } from "../model/plan";
import { mount } from "./mount";

beforeEach(() => window.localStorage.clear());

// 置いたものは必ず片づける。React の描き直しが残ったままこのファイルを終えると、
// jsdom を畳んだあとに scheduler が動いて「window is not defined」が飛ぶ（たまに起きる）
const placed: { destroy(): void }[] = [];
afterEach(() => {
  while (placed.length > 0) placed.pop()!.destroy();
  document.body.replaceChildren();
});

function place(config = {}) {
  const root = document.createElement("div");
  document.body.append(root);
  const handle = mount(root, config);
  placed.push({ destroy: () => handle.destroy() });
  return { root, handle };
}

describe("mount", () => {
  it("根の中に操作列と SVG を作り、取っ手をその場で返す", () => {
    const { root, handle } = place();
    expect(root.querySelector(".fp-controls")).not.toBeNull();
    expect(root.querySelector("svg.fp-plan")).not.toBeNull();
    expect(handle.getFile().version).toBe(3);
    expect(handle.getActivePlan().name).toBe("案 1");
  });

  it("config.plan を渡すと、その間取りで始まる", () => {
    const file = defaultPlanFile();
    file.plans[0].name = "物件 A";
    const { handle } = place({ plan: file });
    expect(handle.getActivePlan().name).toBe("物件 A");
    // config.plan があるときは localStorage を読まない
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
  });

  it("readonly では編集の操作列を出さない", () => {
    const { root } = place({ readonly: true });
    expect([...root.querySelectorAll("button")].some((b) => b.textContent === "塗る")).toBe(false);
  });

  it("subscribe と setActivePlan が動く", () => {
    const { handle } = place();
    const listener = vi.fn();
    const stop = handle.subscribe(listener);
    handle.setFile(defaultPlanFile());
    expect(listener).toHaveBeenCalledTimes(1);
    stop();
    handle.setFile(defaultPlanFile());
    expect(listener).toHaveBeenCalledTimes(1);
  });

  it("destroy で中身が消える", () => {
    const { root, handle } = place();
    handle.destroy();
    expect(root.querySelector(".fp")).toBeNull();
  });

  it("destroy のとき、待っている保存を捨てずに書き出す", () => {
    const { handle } = place();
    const file = defaultPlanFile();
    file.plans[0].name = "書きかけの案";
    handle.setFile(file);
    // 300ms の待ち時間が来る前に閉じる
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
    handle.destroy();
    const saved = window.localStorage.getItem(STORAGE_KEY);
    expect(saved).not.toBeNull();
    expect(JSON.parse(saved!).plans[0].name).toBe("書きかけの案");
  });

  it("storage.enabled が false なら、destroy でも書かない", () => {
    const { handle } = place({ storage: { enabled: false } });
    const file = defaultPlanFile();
    file.plans[0].name = "書きかけの案";
    handle.setFile(file);
    handle.destroy();
    expect(window.localStorage.getItem(STORAGE_KEY)).toBeNull();
  });
});
