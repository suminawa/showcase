import { useMemo, useRef } from "react";

import { type FloorplanConfig } from "../ui/config";
import { Simulator, type SimulatorApi } from "../ui/Simulator";
import { type PlanFile } from "../model/plan";

export type FloorplanSimulatorProps = {
  /** 参照が変わると作り直す。定数か useMemo で渡すこと */
  config?: FloorplanConfig;
  onChange?: (file: PlanFile) => void;
  className?: string;
  handleRef?: (api: SimulatorApi) => void;
};

/** vanilla と同じ Simulator を描くだけの薄いラッパー */
export function FloorplanSimulator({
  config,
  onChange,
  className,
  handleRef,
}: FloorplanSimulatorProps) {
  // onChange は毎回の描画で変わりうるので、ref 経由で呼ぶ（config の参照を保つため）
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;
  const merged = useMemo<FloorplanConfig>(
    () => ({
      ...config,
      onChange: (file: PlanFile) => {
        config?.onChange?.(file);
        onChangeRef.current?.(file);
      },
    }),
    [config],
  );
  return <Simulator config={merged} className={className} handleRef={handleRef} />;
}
