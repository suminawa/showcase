import { act } from "react";
import { createRoot } from "react-dom/client";
import { describe, expect, it, vi } from "vitest";
import { FloorplanSimulator } from "./FloorplanSimulator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

describe("FloorplanSimulator（React）", () => {
  it("描画され、onChange が渡り、unmount で消える", async () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const onChange = vi.fn();
    await act(async () => {
      root.render(<FloorplanSimulator config={{ onChange }} className="mine" />);
    });
    expect(container.querySelector(".fp.mine")).not.toBeNull();
    expect(container.querySelector("svg.fp-plan")).not.toBeNull();
    const add = [...container.querySelectorAll("button")].find((b) => b.textContent === "案を足す")!;
    await act(async () => {
      add.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });
    expect(onChange).toHaveBeenCalledTimes(1);
    await act(async () => {
      root.unmount();
    });
    expect(container.querySelector(".fp")).toBeNull();
  });
});
