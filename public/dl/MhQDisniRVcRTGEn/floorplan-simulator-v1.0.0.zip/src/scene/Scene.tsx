"use client";

/*
 * 売り物: 3D。寸法も色も持たず、shell.ts が返す「箱の一覧」を並べるだけ。
 * 形を直したいときは model/ の側だけを触る。
 * このファイルだけが three と R3F を import する（束を分けるため）。
 */
import { Html, OrbitControls } from "@react-three/drei";
import { Canvas, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import { BoxGeometry, MeshStandardMaterial, MOUSE, TOUCH } from "three";

import { lighten } from "../model/furniture";
import {
  cameraPose,
  isCutaway,
  lightingPreset,
  showsRoof,
  visibleFloors,
  WINDOW_TONE,
  type Vec3,
} from "../model/house";
import {
  annotationPositions,
  BOX_BUDGET,
  countBoxes,
  floorBoxes,
  roofShape,
  roomToneOf,
  type FloorBoxes,
} from "../model/shell";
import { type SceneApi, type SceneProps } from "./loader";

/** 最初の視点。毎回新しい配列を渡すと R3F がカメラを作り直すので、1 つだけ作って使い回す */
const INITIAL_CAMERA = { fov: 42, near: 0.1, far: 300, position: [13, 10, 14] as Vec3 };
const MOUSE_BUTTONS = { LEFT: MOUSE.ROTATE, MIDDLE: MOUSE.DOLLY, RIGHT: MOUSE.PAN };
const TOUCHES = { ONE: TOUCH.ROTATE, TWO: TOUCH.DOLLY_PAN };

/** 箱は 1 辺 1 の geometry を使い回し、大きさは scale で付ける。材質も色ごとに 1 つ */
function useBoxKit() {
  const kit = useMemo(() => {
    const geometry = new BoxGeometry(1, 1, 1);
    const materials = new Map<string, MeshStandardMaterial>();
    const materialFor = (color: string, roughness = 0.85) => {
      const key = `${color}-${roughness}`;
      let material = materials.get(key);
      if (!material) {
        material = new MeshStandardMaterial({ color, roughness, metalness: 0 });
        materials.set(key, material);
      }
      return material;
    };
    // 窓ガラスは明かりを受ける材質が違う。窓ごとに作らず、色と明るさの組ごとに 1 つ
    const glassFor = (color: string, emissiveIntensity: number) => {
      const key = `glass-${color}-${emissiveIntensity}`;
      let material = materials.get(key);
      if (!material) {
        material = new MeshStandardMaterial({
          color,
          emissive: WINDOW_TONE.emissive,
          emissiveIntensity,
          roughness: 0.15,
          metalness: 0.1,
        });
        materials.set(key, material);
      }
      return material;
    };
    return { geometry, materials, materialFor, glassFor };
  }, []);
  useEffect(() => {
    return () => {
      kit.geometry.dispose();
      kit.materials.forEach((material) => material.dispose());
      kit.materials.clear();
    };
  }, [kit]);
  return kit;
}

type Kit = ReturnType<typeof useBoxKit>;

function Boxes({
  kit,
  items,
  color,
  roughness,
}: {
  kit: Kit;
  items: readonly { id: string; position: Vec3; size: Vec3 }[];
  color: string;
  roughness?: number;
}) {
  const material = kit.materialFor(color, roughness);
  return (
    <>
      {items.map((item) => (
        <mesh key={item.id} geometry={kit.geometry} material={material} position={item.position} scale={item.size} />
      ))}
    </>
  );
}

function Stage({ lighting }: { lighting: SceneProps["lighting"] }) {
  const preset = lightingPreset(lighting);
  return (
    <>
      <color attach="background" args={[preset.background]} />
      <ambientLight color={preset.ambient.color} intensity={preset.ambient.intensity} />
      <hemisphereLight
        color={preset.hemisphere.sky}
        groundColor={preset.hemisphere.ground}
        intensity={preset.hemisphere.intensity}
      />
      <directionalLight
        color={preset.key.color}
        intensity={preset.key.intensity}
        position={preset.key.position}
      />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.27, 0]}>
        <circleGeometry args={[40, 64]} />
        <meshStandardMaterial color={preset.ground} roughness={1} />
      </mesh>
    </>
  );
}

function FloorGroup({
  kit,
  boxes,
  floor,
  colors,
  lighting,
  selectedId,
  highlight,
}: {
  kit: Kit;
  boxes: FloorBoxes;
  floor: 1 | 2;
  colors: SceneProps["colors"];
  lighting: SceneProps["lighting"];
  selectedId: string | null;
  highlight: boolean;
}) {
  const preset = lightingPreset(lighting);
  const glass = kit.glassFor(
    lighting === "night" ? WINDOW_TONE.night : WINDOW_TONE.day,
    preset.windowEmissive,
  );
  return (
    <group>
      <Boxes kit={kit} items={[boxes.slab]} color={colors.trim} />
      <Boxes kit={kit} items={boxes.walls} color={colors.wall} />
      <Boxes kit={kit} items={boxes.interiorWalls} color={colors.interior} />
      <Boxes kit={kit} items={boxes.frames} color={colors.trim} />
      <Boxes kit={kit} items={boxes.marks} color={colors.trim} />
      {boxes.rooms.map((room) => (
        <Boxes
          kit={kit}
          key={room.panel.id}
          items={[room.panel]}
          color={roomToneOf(floor, highlight && room.roomId === selectedId, colors.floorTone)}
          roughness={0.95}
        />
      ))}
      {boxes.glass.map((pane) => (
        <mesh key={pane.id} geometry={kit.geometry} material={glass} position={pane.position} scale={pane.size} />
      ))}
      {boxes.fixtures.map((part) => (
        <Boxes kit={kit} key={part.id} items={[part]} color={part.color} />
      ))}
      {boxes.exterior.map((part) => (
        <Boxes kit={kit} key={part.id} items={[part]} color={part.color} />
      ))}
      {boxes.furniture.map((entry) => (
        <Boxes
          kit={kit}
          key={entry.part.id}
          items={[entry.part]}
          color={entry.itemId === selectedId ? lighten(entry.part.color, 0.12) : entry.part.color}
        />
      ))}
    </group>
  );
}

/** 表示を切り替えたら視点を置き直す。途中の動きは付けない（動きを減らす設定の人にも同じ見え方） */
function CameraRig({ doc, floorMode, view }: Pick<SceneProps, "doc" | "floorMode" | "view">) {
  const camera = useThree((state) => state.camera);
  const invalidate = useThree((state) => state.invalidate);
  useEffect(() => {
    const pose = cameraPose(doc.size, floorMode, view);
    camera.position.set(pose.position[0], pose.position[1], pose.position[2]);
    camera.updateProjectionMatrix();
    // frameloop="demand" のときは、動かしただけでは描き直らないので明示的に起こす
    invalidate();
  }, [camera, invalidate, doc.size, floorMode, view]);
  return null;
}

function Ready({ onReady }: { onReady?: (api: SceneApi) => void }) {
  const gl = useThree((state) => state.gl);
  const scene = useThree((state) => state.scene);
  const camera = useThree((state) => state.camera);
  // 呼び返しは描くたびに作り直されうるので、ref 経由で呼ぶ（毎回の描画で効果を走らせない）
  const ref = useRef(onReady);
  ref.current = onReady;
  useEffect(() => {
    ref.current?.({
      // preserveDrawingBuffer を付けていないので、読む直前に描き直す
      renderNow: () => gl.render(scene, camera),
      canvas: gl.domElement,
    });
  }, [camera, gl, scene]);
  return null;
}

export default function Scene({
  doc,
  activeFloor,
  floorMode,
  view,
  lighting,
  colors,
  autoRotate,
  reducedMotion,
  selection,
  onContextLost,
  onReady,
}: SceneProps) {
  const kit = useBoxKit();
  const [spinning, setSpinning] = useState(autoRotate && !reducedMotion);
  const cutaway = isCutaway(floorMode);
  const floors = visibleFloors(doc.size, floorMode);
  const boxes = useMemo(
    () => floors.map((floor) => ({ floor, boxes: floorBoxes(doc, floor, cutaway) })),
    [cutaway, doc, floors],
  );
  const total = boxes.reduce((sum, entry) => sum + countBoxes(entry.boxes), 0);
  useEffect(() => {
    if (total > BOX_BUDGET) {
      console.warn(`[floorplan-simulator] 箱が ${total} 個あります（目安 ${BOX_BUDGET} 個）。家具か建具を減らしてください`);
    }
  }, [total]);

  const pose = cameraPose(doc.size, floorMode, view);
  const roof = roofShape(doc.size);
  const spin = spinning && !reducedMotion && view === "orbit";
  const selectedId = selection?.id ?? null;

  return (
    <Canvas
      className="fp-canvas"
      dpr={[1, 2]}
      camera={INITIAL_CAMERA}
      gl={{ antialias: true }}
      frameloop={spin ? "always" : "demand"}
      onCreated={({ gl }) => {
        gl.domElement.addEventListener("webglcontextlost", (event) => {
          event.preventDefault();
          onContextLost?.();
        });
      }}
    >
      <Stage lighting={lighting} />
      {boxes.map((entry) => (
        <FloorGroup
          key={entry.floor}
          kit={kit}
          boxes={entry.boxes}
          floor={entry.floor}
          colors={colors}
          lighting={lighting}
          selectedId={selectedId}
          highlight={entry.floor === activeFloor}
        />
      ))}
      {showsRoof(floorMode) && (
        <group position={roof.position} scale={[1, 1, roof.scaleZ]}>
          <mesh rotation={[0, roof.rotationY, 0]}>
            <coneGeometry args={[roof.radius, roof.height, 4]} />
            <meshStandardMaterial color={colors.roof} roughness={0.9} flatShading />
          </mesh>
        </group>
      )}
      {/* 屋根が載っている全体では中が見えないので注記を出さない。
          出すのは部屋名だけ（面積と帖は間取り図の側に出る）── 名前と面積を並べると
          札が横に伸びて、隣の部屋の札と重なってしまう */}
      {!showsRoof(floorMode) &&
        floors.flatMap((floor) =>
          annotationPositions(doc.size, doc.floors[floor].layout, floor).map((note) => (
            <Html key={note.id} position={note.position} center distanceFactor={11} zIndexRange={[20, 0]} pointerEvents="none">
              <span className="fp-note-bubble">{note.label}</span>
            </Html>
          )),
        )}
      <CameraRig doc={doc} floorMode={floorMode} view={view} />
      <Ready onReady={onReady} />
      <OrbitControls
        makeDefault
        target={pose.target}
        enableDamping={!reducedMotion}
        dampingFactor={0.08}
        autoRotate={spin}
        autoRotateSpeed={0.5}
        onStart={() => setSpinning(false)}
        enableRotate
        enablePan
        mouseButtons={MOUSE_BUTTONS}
        touches={TOUCHES}
        minDistance={5}
        maxDistance={60}
        maxPolarAngle={Math.PI / 2.05}
      />
    </Canvas>
  );
}
