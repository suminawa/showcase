/** npm 用の公開面。three は読まない（3D は動的 import で読む） */
export { mount, type FloorplanHandle } from "./vanilla/mount";
export { Simulator, type SimulatorApi, type SimulatorProps } from "./ui/Simulator";
export {
  resolveConfig,
  isHexColor,
  type DeepPartial,
  type ExportResult,
  type ExportTarget,
  type FloorplanConfig,
  type ResolvedConfig,
  type SelectionTarget,
  type SizePreset,
} from "./ui/config";
export { DEFAULT_LABELS, type FloorplanLabels } from "./ui/labels";
export {
  defaultPlanFile,
  defaultPlanDoc,
  defaultFloorPlan,
  parsePlanFile,
  parsePlanJson,
  serializePlanFile,
  addPlan,
  duplicatePlan,
  renamePlan,
  removePlan,
  selectPlan,
  resizePlan,
  activePlan,
  MAX_PLANS,
  STORAGE_KEY,
  type FloorPlan,
  type PlanDoc,
  type PlanFile,
} from "./model/plan";
export { migrate } from "./model/migrate";
export {
  CELL,
  SNAP,
  HEIGHT_SNAP,
  DEFAULT_SIZE,
  SIZE_PRESETS,
  SIZE_MIN,
  SIZE_MAX,
  houseOf,
  colsOf,
  rowsOf,
  cellCountOf,
  isPlanSize,
  clampPlanSize,
  type Floor,
  type FloorMode,
  type LightingMode,
  type PlanSize,
  type SceneColors,
  type ViewMode,
} from "./model/house";
export { ROOM_LABELS, type GridLayout, type RoomLabel } from "./model/grid";
export {
  FURNITURE,
  furnitureType,
  // clampSize は「打ち込まれた任意寸法」だけに使う（標準寸法は刻みに乗っていないので通さない）
  presetSeed,
  defaultSeed,
  tvSeed,
  tvSize,
  screenWidth,
  screenHeight,
  tvStandHint,
  clampSize,
  type FurniturePreset,
  type FurnitureType,
} from "./model/catalog";
export { type FurnitureId, type PlacedFurniture, type Rotation, type Size3 } from "./model/furniture";
export { OPENING_PRESETS, type Opening, type OpeningPresetId } from "./model/openings";
export { FIXTURE_PRESETS, type Fixture, type FixtureKind } from "./model/fixtures";
export { EXTERIOR_PRESETS, type ExteriorKind, type ExteriorPart } from "./model/exterior";
export { jo, formatArea, formatJo, formatLength, formatSize3, roomDimension } from "./model/dimensions";
export { registerScene, type SceneApi, type SceneComponent, type SceneProps } from "./scene/loader";
