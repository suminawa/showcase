/*
 * 1.0.1 の直し: 取り消し・やり直し、塗り替えで部屋が減ったときの断り、拡大中の平行移動、
 * setFile 直後の getFile、保存の失敗、WebGL2 の判定、新しい部屋の名前、読み上げ。
 * jsdom には SVG の座標変換が無いので、図面が幅 924 px で表示されている取り決めで viewBox から写す
 * （拡大・平行移動で viewBox が動くと、同じ画面の点が別の図面の点になるところまで再現する）。
 */
import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { defaultPlanFile } from "../model/plan";
import { SCALE } from "./glyphs";
import { Simulator, type SimulatorApi } from "./Simulator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

type PatchedSvg = { getScreenCTM?: () => unknown };
type PatchedElement = { hasPointerCapture?: (id: number) => boolean };

function mount(props: Parameters<typeof Simulator>[0] = {}) {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  let handle: SimulatorApi | null = null;
  act(() => {
    root.render(<Simulator {...props} handleRef={(api) => (handle = api)} />);
  });
  return { container, root, get handle() { return handle as unknown as SimulatorApi; } };
}

const click = (el: Element) =>
  act(() => {
    el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  });

const buttonNamed = (root: ParentNode, text: string) =>
  [...root.querySelectorAll("button")].find((button) => button.textContent?.trim() === text) as
    | HTMLButtonElement
    | undefined;

const svgOf = (container: HTMLElement) => container.querySelector("svg.fp-plan") as SVGSVGElement;
const viewBoxOf = (container: HTMLElement) => svgOf(container).getAttribute("viewBox")!.split(" ").map(Number);

/** 図面が画面に出ている幅（px） */
const SHOWN_WIDTH = 924;

/** 図面の (x, z) m を、いまの viewBox での画面の点にする */
function screenAt(container: HTMLElement, x: number, z: number) {
  const [vx, vy, vw] = viewBoxOf(container);
  const k = vw / SHOWN_WIDTH;
  return { clientX: (x * SCALE - vx) / k, clientY: (z * SCALE - vy) / k };
}

function pointer(container: HTMLElement, type: string, at: { clientX: number; clientY: number }, extra = {}) {
  act(() => {
    svgOf(container).dispatchEvent(
      new PointerEvent(type, { bubbles: true, pointerId: 1, pointerType: "mouse", buttons: 1, ...at, ...extra }),
    );
  });
}

/** マウスで (from) から (to) までなぞって離す。どちらも図面の m */
function dragPlan(container: HTMLElement, from: [number, number], to: [number, number]) {
  const start = screenAt(container, ...from);
  const end = screenAt(container, ...to);
  pointer(container, "pointerdown", start);
  pointer(container, "pointermove", end);
  pointer(container, "pointerup", end, { buttons: 0 });
}

const press = (key: string, init: KeyboardEventInit = {}) =>
  act(() => {
    (document.activeElement ?? document.body).dispatchEvent(
      new KeyboardEvent("keydown", { key, bubbles: true, ...init }),
    );
  });

const roomOf = (handle: SimulatorApi, x: number, z: number) => {
  const doc = handle.getActivePlan();
  const cols = doc.size.width / 0.5;
  return doc.floors[1].layout.cells[Math.floor(z / 0.5) * cols + Math.floor(x / 0.5)];
};

beforeEach(() => {
  window.localStorage.clear();
  vi.useFakeTimers();
  (window.SVGSVGElement.prototype as PatchedSvg).getScreenCTM = function (this: SVGSVGElement) {
    const [x, y, w] = (this.getAttribute("viewBox") ?? "0 0 0 0").split(" ").map(Number);
    return { inverse: () => ({ x, y, k: w / SHOWN_WIDTH }) };
  };
  (window.Element.prototype as PatchedElement).hasPointerCapture = () => false;
  vi.stubGlobal(
    "DOMPoint",
    class {
      x: number;
      y: number;
      constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
      }
      matrixTransform(m: { x: number; y: number; k: number }) {
        return { x: m.x + this.x * m.k, y: m.y + this.y * m.k };
      }
    },
  );
});

afterEach(() => {
  act(() => {
    vi.runOnlyPendingTimers();
  });
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
  delete (window.SVGSVGElement.prototype as PatchedSvg).getScreenCTM;
  delete (window.Element.prototype as PatchedElement).hasPointerCapture;
  document.body.replaceChildren();
});

describe("setFile 直後の getFile", () => {
  it("描き直しを待たずに新しい値を返す（README の例の並び）", () => {
    const { handle } = mount();
    const file = defaultPlanFile();
    file.plans[0].name = "差し替え";
    let seenName = "";
    let seenActive = "";
    act(() => {
      handle.setFile(file);
      seenName = handle.getFile().plans[0].name;
    });
    expect(seenName).toBe("差し替え");
    act(() => {
      handle.setFile({ ...file, plans: [...file.plans, { ...file.plans[0], id: "plan-3", name: "3" }] });
      handle.setActivePlan("plan-3");
      seenActive = handle.getActivePlan().id;
    });
    expect(seenActive).toBe("plan-3");
  });
});

describe("取り消し・やり直し", () => {
  it("ボタンで 1 手ずつ戻し、やり直せる。履歴が無いあいだは押せない", () => {
    const { container, handle } = mount();
    const undo = () => buttonNamed(container, "取り消す")!;
    const redo = () => buttonNamed(container, "やり直す")!;
    expect(undo().disabled).toBe(true);
    expect(redo().disabled).toBe(true);
    const before = handle.getFile();
    click(buttonNamed(container, "案を足す")!);
    expect(handle.getFile().plans).toHaveLength(2);
    expect(undo().disabled).toBe(false);
    click(undo());
    expect(handle.getFile()).toBe(before);
    expect(redo().disabled).toBe(false);
    click(redo());
    expect(handle.getFile().plans).toHaveLength(2);
    expect(redo().disabled).toBe(true);
  });

  it("Ctrl+Z / ⌘Z で戻し、Shift を足すとやり直す", () => {
    const { container, handle } = mount();
    const before = handle.getFile();
    click(buttonNamed(container, "案を足す")!);
    buttonNamed(container, "取り消す")!.focus();
    press("z", { ctrlKey: true });
    expect(handle.getFile()).toBe(before);
    press("Z", { metaKey: true, shiftKey: true });
    expect(handle.getFile().plans).toHaveLength(2);
    press("z", { metaKey: true });
    expect(handle.getFile()).toBe(before);
  });

  it("なぞった 1 筆は、途中で何度変わっても 1 手で戻る", () => {
    const { container, handle } = mount();
    const before = handle.getFile();
    click(buttonNamed(container, "新しい部屋")!);
    const added = handle.getFile();
    dragPlan(container, [0.25, 0.25], [2.25, 0.25]);
    dragPlan(container, [0.25, 0.75], [2.25, 0.75]);
    expect(handle.getFile()).not.toBe(added);
    click(buttonNamed(container, "取り消す")!);
    click(buttonNamed(container, "取り消す")!);
    expect(handle.getFile()).toBe(added);
    click(buttonNamed(container, "取り消す")!);
    expect(handle.getFile()).toBe(before);
  });

  it("新しく変えると、やり直しの先は捨てる", () => {
    const { container } = mount();
    click(buttonNamed(container, "案を足す")!);
    click(buttonNamed(container, "取り消す")!);
    click(buttonNamed(container, "複製")!);
    expect(buttonNamed(container, "やり直す")!.disabled).toBe(true);
  });

  it("「最初に戻す」も取り消せ、戻したことを知らせる", () => {
    const { container, handle } = mount();
    click(buttonNamed(container, "案を足す")!);
    const edited = handle.getFile();
    click(buttonNamed(container, "最初に戻す")!);
    expect(handle.getFile().plans).toHaveLength(1);
    expect(container.querySelector(".fp-hint")?.textContent).toContain("取り消す");
    click(buttonNamed(container, "取り消す")!);
    expect(handle.getFile()).toBe(edited);
  });

  it("readonly では出さない", () => {
    const { container } = mount({ config: { readonly: true } });
    expect(buttonNamed(container, "取り消す")).toBeUndefined();
  });
});

describe("塗り替えで既存の部屋が減ったとき", () => {
  it("どの部屋から何マス移ったかを断りに出す", () => {
    const { container, handle } = mount();
    const owner = roomOf(handle, 0.25, 0.25);
    const label = handle.getActivePlan().floors[1].layout.rooms.find((room) => room.id === owner)!.label;
    click(buttonNamed(container, "新しい部屋")!);
    dragPlan(container, [0.25, 0.25], [0.75, 0.25]);
    const hint = container.querySelector(".fp-hint")!;
    expect(hint.textContent).toContain(`「${label}」`);
    expect(hint.textContent).toContain("2 マス");
  });

  it("断りは読み上げられる（role=status）", () => {
    const { container } = mount();
    const hint = container.querySelector(".fp-hint")!;
    expect(hint.getAttribute("role")).toBe("status");
    expect(hint.getAttribute("aria-live")).toBe("polite");
  });
});

describe("拡大中の平行移動", () => {
  it("「選ぶ」で部屋の上をドラッグすると図面が動き、「全体」で戻る", () => {
    const { container } = mount();
    click(buttonNamed(container, "拡大")!);
    click(buttonNamed(container, "拡大")!);
    const centered = viewBoxOf(container);
    const start = screenAt(container, 4, 4);
    pointer(container, "pointerdown", start);
    pointer(container, "pointermove", { clientX: start.clientX - 50, clientY: start.clientY - 30 });
    pointer(container, "pointerup", start, { buttons: 0 });
    const moved = viewBoxOf(container);
    // つかんだ点が指についてくる: 左上へ動かすと、見える範囲は右下へずれる
    const k = centered[2] / SHOWN_WIDTH;
    expect(moved[0]).toBeCloseTo(centered[0] + 50 * k, 1);
    expect(moved[1]).toBeCloseTo(centered[1] + 30 * k, 1);
    click(buttonNamed(container.querySelector(".fp-editor")!, "全体")!);
    expect(viewBoxOf(container)).toEqual([-12, -12, 924, 824]);
  });

  it("等倍ではドラッグしても動かず、間取りも変えない", () => {
    const { container, handle } = mount();
    const before = handle.getFile();
    dragPlan(container, [4, 4], [2, 2]);
    expect(viewBoxOf(container)).toEqual([-12, -12, 924, 824]);
    expect(handle.getFile()).toBe(before);
  });

  it("2 本指では、ピンチしながら指の中点のぶん動く", () => {
    const { container } = mount();
    click(buttonNamed(container, "拡大")!);
    click(buttonNamed(container, "拡大")!);
    const centered = viewBoxOf(container);
    const touch = (type: string, pointerId: number, clientX: number, clientY: number) =>
      act(() => {
        svgOf(container).dispatchEvent(
          new PointerEvent(type, { bubbles: true, pointerId, pointerType: "touch", clientX, clientY, buttons: 1 }),
        );
      });
    touch("pointerdown", 1, 200, 200);
    touch("pointerdown", 2, 300, 200);
    // 間隔はそのまま、2 本とも左上へ 40 px
    touch("pointermove", 1, 160, 160);
    touch("pointermove", 2, 260, 160);
    const moved = viewBoxOf(container);
    // 間隔が戻ったので拡大率も戻り、見える範囲は 40 px ぶん右下へずれる
    const k = centered[2] / SHOWN_WIDTH;
    expect(moved[2]).toBeCloseTo(centered[2], 1);
    expect(moved[0]).toBeCloseTo(centered[0] + 40 * k, 0);
    expect(moved[1]).toBeCloseTo(centered[1] + 40 * k, 0);
  });
});

describe("小さな直し", () => {
  it("新しい部屋は、まだ使っていない名前で始まる", () => {
    const { container, handle } = mount();
    const used = handle.getActivePlan().floors[1].layout.rooms.map((room) => room.label);
    click(buttonNamed(container, "新しい部屋")!);
    const rooms = handle.getActivePlan().floors[1].layout.rooms;
    expect(used).not.toContain(rooms[rooms.length - 1].label);
  });

  it("localStorage に書けなければ、1 度だけ断りを出す", () => {
    vi.spyOn(window.localStorage, "setItem").mockImplementation(() => {
      throw new Error("QuotaExceededError");
    });
    const { container } = mount();
    click(buttonNamed(container, "案を足す")!);
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(container.querySelector(".fp-hint")?.textContent).toContain("保存できませんでした");
  });

  it("WebGL1 しか無い環境では 3D を出さず、断りを出す（three r185 は WebGL2 が要る）", () => {
    vi.stubGlobal("WebGLRenderingContext", class {});
    vi.spyOn(window.HTMLCanvasElement.prototype, "getContext").mockImplementation(((id: string) =>
      id === "webgl2" ? null : { getExtension: () => null }) as never);
    const { container } = mount();
    expect(container.querySelector(".fp-fallback-text")?.textContent).toContain("WebGL");
  });

  it("3D の枠には代わりの文がある", () => {
    vi.stubGlobal("WebGLRenderingContext", class {});
    vi.spyOn(window.HTMLCanvasElement.prototype, "getContext").mockReturnValue({
      getExtension: () => ({ loseContext: () => {} }),
    } as never);
    const { container } = mount();
    const stage = container.querySelector(".fp-stage")!;
    expect(stage.getAttribute("role")).toBe("img");
    expect(stage.getAttribute("aria-label")).toContain("3D");
  });

  it("家具・設備・建具は Tab で止まり、Enter で選べる", () => {
    const onSelect = vi.fn();
    const { container, handle } = mount({ config: { onSelect } });
    const items = [...container.querySelectorAll<SVGGElement>("svg.fp-plan [tabindex='0'][role='button']")];
    const furniture = handle.getActivePlan().floors[1].furniture[0];
    const target = items.find((item) => item.getAttribute("data-id") === furniture.id)!;
    expect(target.getAttribute("aria-label")).toBeTruthy();
    act(() => {
      target.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    });
    expect(onSelect).toHaveBeenLastCalledWith({ kind: "furniture", id: furniture.id });
    const opening = handle.getActivePlan().floors[1].openings[0];
    expect(items.some((item) => item.getAttribute("data-id") === opening.id)).toBe(true);
  });
});
