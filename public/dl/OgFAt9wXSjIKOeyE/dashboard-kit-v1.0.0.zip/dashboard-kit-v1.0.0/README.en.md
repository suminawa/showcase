# Dashboard Kit

Turn numbers that already live in a spreadsheet or a CSV into a single screen of KPIs, charts, goals and tables, by writing a config file rather than chart code. No charting library, no BI subscription. One zip gives you three ways to run it: drop it into a page you already have, build it into a Next.js app, or publish it straight from a Google Sheet.

What is in the zip: `dist/` (the built files you ship), `demo/index.html` (a self-contained demo), `samples/` (sample CSVs and configs), `templates/nextjs/` (a ready-to-deploy Next.js app), `src/`, `test/` and `scripts/` (the source and its tests), plus `package.json`, `README.ja.md`, `README.en.md`, `LICENSE.md` and `CHANGELOG.md`.

Start by opening `demo/index.html` in a browser. With no server and no network, it runs six months of sales for a fictional shop, Shiokaze Coffee, through every part of the kit.

## 1. What it does

The screen is one page: a single row of filters at the top, a grid of widgets below. Change a filter and every widget below it updates together.

There are five widgets.

| Type | What it shows |
|---|---|
| `kpi` | One number, the change against the previous period (with ▲▼ and a sign), and a small sparkline |
| `line` | A trend over time. Split by a column to get series (up to 4; the rest become "Other") |
| `bar` | Size per category. Split by a column to stack it (top 8 categories plus "Other") |
| `meter` | Progress against a goal. At 100% or above it says "Goal reached". A monthly goal is compared with that month's figures |
| `table` | A grouped summary or the latest rows. Click a header to sort; export to CSV |

Every chart has a "View as table" toggle, so every number can be read without opening a tooltip. Legends appear when there are two or more series, and not when there is one. Mouse, touch and keyboard focus all produce the same tooltip. Japanese and English are both built in, light and dark follow the OS, and there is a print stylesheet.

Some things are left out on purpose, and it is fairer to say so up front: pie and doughnut charts, dual-axis charts, maps, drill-down, editing the config from the screen, direct database connections, login, and AI summaries. Section 10 explains each one.

## 2. Choosing how to run it

| | Embedded | Next.js template | Google Sheets |
|---|---|---|---|
| Best for | Adding a page to a site you already run | Freelancers and agencies shipping a client dashboard | Teams whose numbers already live in a sheet |
| You need | Somewhere to host static HTML | Node.js and a host such as Vercel | One Google account |
| Where the data lives | A CSV or JSON file (`https:` or a relative path) | A URL in an environment variable; the server fetches it | Sheets in the same spreadsheet |
| Who can see it | Anyone who can see the page | Anyone who can see the site (add your own auth) | Only people the spreadsheet is shared with |
| Time to set up | 5 minutes | 15 minutes | 15 minutes |

All three run the same rendering code. The only difference is where the config and the rows come from, so you can switch later without rewriting your config.

## 3. Embedding in a page

### 3-1. The shortest version

You need both `dist/dashboard.css` and `dashboard.js`. **One without the other will not render correctly**: without the stylesheet the text and the numbers still appear, but the cards lose their frames and the charts stretch to the full width of the page. `dashboard.js` is about 248 KB and `dashboard.css` about 16 KB.

```html
<link rel="stylesheet" href="./dashboard.css" />
<div id="app"></div>
<script src="./dashboard.js"></script>
<script>
  Dashboard.mount(document.getElementById("app"), { config: "./dashboard.config.json" });
</script>
```

> **Serve this over `https:` or `http:`.** Opening the HTML file straight from your disk (`file://`) means the browser refuses to read the CSV and the config file, and the page says "This dashboard is unavailable right now". To try it locally, start a small web server in that folder first (`npx serve` or `python3 -m http.server`, for example). Passing the config and the rows directly through `config` and `data` (3-2) does work over `file://`.

Loading `dashboard.js` adds exactly one global, `window.Dashboard`. Nothing else leaks into the page. `Dashboard.version` holds the version of the kit (`1.0.0`), so you can tell which build is running on a customer's site.

### 3-2. Passing the config and the rows directly

Instead of a path, you can hand `mount` the config object itself. Anything you put in `data` is used as-is and never fetched, and those datasets need no `url` at all.

```js
const rows = [
  { date: "2026-09-01", channel: "Store", amount: 4200 },
  { date: "2026-09-02", channel: "Online", amount: 7800 }
];
const datasets = { sales: rows };

const view = Dashboard.mount(document.getElementById("app"), {
  config: settings,
  data: datasets,
  lang: "en",
  theme: "auto"
});
```

`mount` accepts seven options: `config`, `data`, `source`, `lang`, `theme`, `today` and `hash`. `lang` and `theme` take precedence over the config. Passing `today` as `YYYY-MM-DD` fixes what "today" means, which keeps screenshots and tests reproducible.

### 3-3. Which URLs are allowed

A dataset `url` must be **either an `https:` URL or a relative path**. Plain `http:`, protocol-relative `//host/...`, `javascript:` and `data:` are all rejected, and the reason is listed at the top of the dashboard. Passing `config` as a string follows the same rule. The body is parsed as CSV by default, and as JSON when the path ends in `.json` or the server says the response is JSON.

### 3-4. Caching and refreshing

Fetched bodies are kept in `sessionStorage` for `cacheMinutes` (default 5, range 0–1440) and disappear when the tab closes. The config file itself is always fetched fresh. Set it to `0` to fetch every time. To force a fetch right now, call `refresh()`.

```js
view.refresh();  // refetch, ignoring the cache
view.destroy();  // tear the dashboard and all its listeners down
```

If your app replaces that part of the page, call `destroy()` as it goes away. Mounting twice into the same element is safe: the previous instance is torn down first.

### 3-5. Sharing a filtered view by URL

Changing a filter writes a marker into the URL hash, such as `#db.p=last30&db.d.Channel=Online`. Send that URL and the recipient opens the same view. Every key starts with `db.`.

If the page already has a hash of its own (`#pricing`, say), the dashboard leaves the hash completely alone rather than overwriting the page's own anchor. Filtering still works; you just cannot share it by URL on that page.

Putting two dashboards on one page? Give them different prefixes. `hash: false` turns the URL sync off.

```js
Dashboard.mount(document.getElementById("left"), { config: "./a.json", hash: "a" });
```

Without separate prefixes, only whichever dashboard is filtered first writes to the hash. The other one still filters, but its state never reaches the URL. Setting `hash: false` on one of them makes that explicit.

### 3-6. As an ES module

Use `dist/dashboard.mjs` if you would rather import it. The stylesheet is loaded the same way.

```js
import { mountDashboard } from "./dashboard.mjs";
mountDashboard(document.getElementById("app"), { config: "./dashboard.config.json" });
```

> Browsers refuse to load ES modules from a `file://` page, so this form needs a web server (`https:` or `http:`); opened from disk the page simply stays blank.

### 3-7. Replacing the fetch (`source`)

By default the kit fetches the `url` written in the config. Hand `source` an object with a `load()` method and you replace the fetching entirely. `load()` resolves to `{ config, datasets, missing }`; the Next.js template's `app/DashboardClient.tsx` is a working example that calls its own server-side API instead, keeping the upstream URL hidden.

`source: "memory"` (the built-in sample data) exists only in the demo page and is not part of the `dist/` bundle. Ask for it there and the dashboard says so in one polite line.

## 4. The Google Sheets edition

This turns a spreadsheet into a published dashboard in about 15 minutes.

On an English Google account the editor reads Extensions → Apps Script, the default script file is `Code.gs`, the manifest is turned on with Project Settings → "Show 'appsscript.json' manifest file in editor", and the deployment is Deploy → New deployment → Web app, with Execute as: User accessing the web app and Who has access: Anyone with a Google account. Everything the kit itself creates stays in Japanese: the 「ダッシュボード」 menu, the sheet names `設定` and `定義`, and the column headings of `定義`. Only the *values* in those sheets may be written in English. 「見本を入れる」 (Insert sample data) writes an English sample when 言語 is set to 英語, and a Japanese one otherwise.

1. Open the spreadsheet holding your numbers. Check File → Settings → time zone: date cells are read in the **spreadsheet's** time zone, not the script's
2. Open Extensions → Apps Script（拡張機能 → Apps Script）
3. Delete everything in the default `コード.gs` and paste the contents of `dist/Code.gs`
4. In the Files pane, click "+" → HTML and name it `App`. Typing `App.html` produces a file called `App.html.html`, so type just `App`. Replace its contents with `dist/App.html`
5. Open Project Settings (the gear) and tick "Show 'appsscript.json' manifest file in editor". Back in the editor, replace `appsscript.json` with `dist/appsscript.json`
6. Save
7. Reload the spreadsheet. A new menu, 「ダッシュボード」 (Dashboard), appears
8. Choose 「初期化（「設定」と「定義」のシートを作る）」 (Initialise). Two sheets, `設定` (Settings) and `定義` (Widgets), are created
9. If you would like something to copy from, choose 「見本を入れる」 (Insert sample data). Sample sales, goals and a full config are written in
10. Choose 「ダッシュボードの URL」 (Dashboard URL). If you have not deployed yet, it tells you how: open Extensions → Apps Script, then Deploy → New deployment, and pick
    - 種類: ウェブアプリ — Type: Web app
    - 次のユーザーとして実行: ウェブアプリにアクセスしているユーザー — Execute as: User accessing the web app
    - アクセスできるユーザー: Google アカウントを持つ全員 — Who has access: Anyone with a Google account

11. Choose 「ダッシュボードの URL」 again to get the link. After editing the sheets, 「設定を確かめる」 (Check the settings) lists everything that is wrong in one alert

### The two permissions on the consent screen

The first run asks for two scopes.

| Permission | Scope requested | What the kit actually does |
|---|---|---|
| Spreadsheets | `spreadsheets` | Reads `設定`, `定義` and your data sheets in this spreadsheet. Writes only to `設定`, `定義` and the sample sheets, and only when you pick Initialise or Insert sample data |
| Menu | `script.container.ui` | Shows the 「ダッシュボード」 menu and its alerts |

The consent screen itself will say "See, edit, create and delete all your Google Sheets spreadsheets", because that is the narrowest permission Google offers here. The only spreadsheet this kit ever touches is the one the script lives in, which you can verify in `src/gas/gas_sheets.js`.

**The dashboard itself only reads.** The only writes come from the two menu items that create `設定` and `定義` (and the sample data sheets). Your existing data sheets are never written to. A read-only scope is not enough, because those two menu items create sheets.

If Google warns that the app is not verified, use "Advanced" → "Go to <project name> (unsafe)". That notice appears for any script you write yourself.

### Only people who can open the spreadsheet can see it

The deployment uses `ANYONE` for access and `USER_ACCESSING` for execution, which means the dashboard **runs as whoever opens it**. Someone who has no permission to view the spreadsheet sees no numbers at all when they open the link — just the message "This dashboard is unavailable right now. Please try again later." (the real reason is written only to the Apps Script execution log).

Because of that, each viewer is asked to authorise once, the first time they open it, and never again. If you want people outside your organisation to see the dashboard, change the spreadsheet's sharing first.

A sheet passes at most 20,000 rows to the screen. The remaining rows are not used, and the page says "Showing the first 20,000 rows" underneath.

## 5. The Next.js template

`templates/nextjs/` is a working App Router project. `npm install && npm run dev` brings it up on the bundled sample data with no configuration at all. Those sample CSVs carry fixed dates (April to September 2026), so the template's config uses `"period": "all"`; switch it to `thisMonth` and the screen goes empty, because no sample row falls in the current month.

The important part: the fetch happens on the server, in a Route Handler, and the upstream URL lives only in an environment variable (`DASHBOARD_DATA_SALES` and friends). **The data source URL never reaches the visitor's browser.** The Route Handler refuses to take a URL from the request, so it cannot be pointed at anything else.

**In production, a dataset with no environment variable does not fall back to the sample data.** It returns 404, and the card reads "The dataset "sales" was not found." — so a forgotten variable is visible instead of quietly shipping invented numbers to your client. To try the bundled sample on a real deployment, set `DASHBOARD_SAMPLE=1`, and remove it once your own data is connected.

After deploying, open `/api/dashboard/data?dataset=sales` and check that **your own headers and values come back**. Sample product names such as "Shiokaze Blend" mean either `DASHBOARD_SAMPLE` is still set or your environment variables are not taking effect.

**There is no login in this template.** If the numbers are private, put the site behind your host's authentication — Vercel's Password Protection, for example.

The full walkthrough — publishing a Google Sheet as CSV, how environment variable names are derived, deploying to Vercel, and updating the kit — is in `templates/nextjs/README.md`, in Japanese and English. `npm install` pulls in Next.js and React from npm (both MIT licensed); the kit itself has no dependencies.

## 6. Writing the configuration

### 6-1. Top-level options

| Option | Meaning | Default |
|---|---|---|
| `title` | Heading shown above the dashboard | (empty) |
| `lang` | Language of the built-in labels: `ja` or `en` | `ja` |
| `theme` | `auto` (follow the OS), `light`, `dark` | `auto` |
| `cacheMinutes` | How long a fetched body stays in `sessionStorage` (0–1440) | 5 |
| `datasets` | Name → where to get the rows. At least one | (required) |
| `filters` | The filter row at the top | see below |
| `widgets` | The widgets, in order. At least one | (required) |

Each entry in `datasets` looks like this.

| Field | Meaning | Default |
|---|---|---|
| `url` | A CSV or JSON location: `https:` or a relative path | (optional; omit it when you pass rows through `data`, and in the Sheets edition) |
| `dateColumn` | The column the period filter uses. A line chart needs this (or its own `dateColumn`) | (empty — the dataset is then never filtered by period) |
| `types` | Force a column type, e.g. `{ "member_id": "text" }` | (empty — types are inferred) |

A dataset with neither a `url` nor rows in `data` is not a config error: only the widgets that name it are replaced by a "The dataset "…" was not found." card.

And `filters`:

| Field | Meaning | Default |
|---|---|---|
| `period` | `thisMonth`, `lastMonth`, `last7`, `last30`, `last90`, `thisYear`, `all`, `custom` | `thisMonth` |
| `from` / `to` | Start and end for `custom`, as `YYYY-MM-DD` | (empty) |
| `dimensions` | Columns offered as dropdowns. At most 3 | (empty) |

### 6-2. Fields every widget accepts

| Field | Meaning | Default |
|---|---|---|
| `type` | `kpi`, `line`, `bar`, `meter`, `table` | (required) |
| `title` | Card heading | (empty) |
| `dataset` | A name from `datasets` | (required) |
| `size` | `s` (quarter width), `m` (half), `l` (full) | per type, below |
| `format` | `number`, `yen`, `usd`, `percent`, or the `custom` object below | `number` |
| `note` | A short line printed under the card | (empty) |

Default sizes: `kpi` is `s`, `meter` and `bar` are `m`, `line` and `table` are `l`. **Line and bar charts cannot use `s`** — axis ticks and category names are unreadable at that width — and the config error says "size must be m or l". On narrow screens `m` and `l` both take the full row.

For units, write `format` as an object: `{ "type": "custom", "prefix": "", "suffix": " items", "decimals": 0 }`. `decimals` is a non-negative integer and applies **only where numbers are printed in full** (tables, tooltips, CSV). Wherever a number is abbreviated — KPI values, goal cards, bar end labels, axis ticks — it always keeps one decimal place, whatever `decimals` says (see 7-8).

### 6-3. `kpi`

| Field | Meaning | Default |
|---|---|---|
| `value` | Column to aggregate (optional only when `agg` is `count`) | (required) |
| `agg` | `sum`, `avg`, `count`, `distinct`, `min`, `max` | `sum` |
| `compare` | `previous` (against the previous period) or `none` | `previous` |
| `goodWhen` | `up` (higher is better) or `down` | `up` |
| `sparkline` | Draw the small trend line inside the card (`true` / `false`) | `true` |

If the dataset has no `dateColumn`, there is nothing to compare against, so `compare` quietly becomes `none`.

### 6-4. `line`

| Field | Meaning | Default |
|---|---|---|
| `value` / `agg` | as above | `agg` is `sum` |
| `splitBy` | Column to split into series; empty means a single line | (empty) |
| `bucket` | `auto`, `day`, `week`, `month`, `quarter`, `year` | `auto` |
| `dateColumn` | Use a different date column for this widget only | the dataset's `dateColumn` |

**A line chart needs a date column.** If neither the dataset's `dateColumn` nor the widget's own `dateColumn` is set, the widget becomes a card reading "is missing its date column."

At most 4 series are drawn; beyond that you get the top 3 plus "Other". A single series gets a faint fill of its own colour underneath.

### 6-5. `bar`

| Field | Meaning | Default |
|---|---|---|
| `category` | The category column | (required) |
| `value` / `agg` | as above | `agg` is `sum` |
| `splitBy` | Column to stack by | (empty) |
| `top` | How many categories to keep (1–20) | 8 |
| `sort` | `value` (largest first) or `label` (by name) | `value` |
| `horizontal` | `true`, `false`, `auto` | `auto` |

`auto` switches to horizontal bars once there are more than 8 categories, or when the names are too long to sit side by side. A stack holds at most 6 segments; the rest collapse into "Other".

### 6-6. `meter`

| Field | Meaning | Default |
|---|---|---|
| `value` / `agg` | as above | `agg` is `sum` |
| `target` | A number, or the lookup below | (required) |

For a fixed goal, write `"target": 3000000`. To read a monthly goal out of another dataset, point at it:

```json
{ "dataset": "targets", "value": "Target", "agg": "sum", "matchMonth": "Month" }
```

The `matchMonth` column should hold `2026-09`-style values (or anything readable as a date in that month). Leave it out and the column named `月` is used.

Written this way, the goal is **a goal for one month**, so the actual figure covers that one month too. Six months of sales are never held up against a single month's goal, not even under "All time". Which month it is depends on the period on screen:

| Period on screen | Month compared |
|---|---|
| Any period with an end date (This month, Last month, Last 90 days, a custom range, …) | The month of **the end date** |
| A period with no end date, such as "All time" | The month of the **most recent date** in the filtered rows |

Only rows that fall inside that month *and* inside the current period and filters are counted. With "Last 90 days" ending on 19 September, for instance, the goal is compared with sales from 1 to 19 September. The card prints the month quietly next to the figures (`Sep 2026`), and "View as table" and the tooltip carry it as "Month".

When the dataset has no date column, there is no way to split by month: the goal for today's month is used and the actual figure covers every filtered row (no month is printed in that case).

A fixed number (`"target": 3000000`) ignores months entirely and is compared with the whole period on screen.

### 6-7. `table`

A grouped summary table:

| Field | Meaning | Default |
|---|---|---|
| `groupBy` | Column to group rows by | (required) |
| `columns` | A list of `{ "value": column, "agg": …, "label": heading, "format": … }` | (required) |
| `sort` | The heading of the column to sort by | (empty — the first numeric column) |
| `order` | `desc` (largest first) or `asc` | `desc` |
| `top` | How many rows to show (1–200) | 20 |

For the latest rows as they are, write `"rows": "latest"`. Then `columns` is a plain list of column names, such as `["Date", "Product", "Amount"]`, and `sort` and `order` are ignored. "Latest" only means newest-first when the dataset has a `dateColumn`; without one, the rows stay in file order.

### 6-8. A complete example

```json
{
  "title": "Shiokaze Coffee — Sales dashboard",
  "lang": "en",
  "theme": "auto",
  "datasets": {
    "sales": { "url": "./sales.csv", "dateColumn": "Date" },
    "targets": { "url": "./targets.csv" }
  },
  "filters": { "period": "thisMonth", "dimensions": ["Channel", "Category"] },
  "widgets": [
    { "type": "kpi", "title": "Sales", "dataset": "sales", "value": "Amount", "agg": "sum", "format": "yen", "compare": "previous", "goodWhen": "up", "size": "s" },
    { "type": "line", "title": "Sales trend", "dataset": "sales", "value": "Amount", "agg": "sum", "splitBy": "Channel", "bucket": "auto", "format": "yen", "size": "l" },
    { "type": "bar", "title": "Sales by category", "dataset": "sales", "category": "Category", "value": "Amount", "agg": "sum", "top": 8, "format": "yen", "size": "m" },
    { "type": "meter", "title": "This month's goal", "dataset": "sales", "value": "Amount", "agg": "sum", "target": { "dataset": "targets", "value": "Target", "matchMonth": "Month" }, "format": "yen", "size": "m" },
    { "type": "table", "title": "By product", "dataset": "sales", "groupBy": "Product", "columns": [{ "value": "Qty", "agg": "sum", "label": "Qty" }, { "value": "Amount", "agg": "sum", "label": "Sales", "format": "yen" }], "sort": "Sales", "top": 20, "size": "l" }
  ]
}
```

The same file ships as `samples/en/dashboard.config.json` alongside the CSVs it reads (`samples/ja/` is the Japanese pair). Those bundled CSVs carry fixed dates (April to September 2026), so the shipped configs use `"period": "all"`; switching them to `thisMonth` leaves the screen empty, because no sample row falls in the current month. The goal card is a monthly goal, so even under "All time" it compares the last month in the data (September 2026) with that month's target.

### 6-9. The `定義` sheet (Sheets edition)

In the Sheets edition, each widget is one row of the `定義` sheet instead of one object in `widgets`. Columns may be in any order, and headings the kit does not recognise are skipped. Values may be written in Japanese, as below, or with the English spellings used in JSON (`kpi`, `sum`, `m` and so on).

| Column | JSON field | Accepted values |
|---|---|---|
| 種類 | `type` | 数字 (kpi) / 折れ線 (line) / 棒 (bar) / 目標 (meter) / 表 (table) |
| 題 | `title` | Anything — the card heading |
| データ | `dataset` | The name of the sheet holding the rows |
| 値の列 | `value` (`columns` for tables) | A column name. Tables take several, separated by 「、」, and `column=heading` renames one |
| 集計 | `agg` | 合計 (sum) / 平均 (avg) / 件数 (count) / 種類の数 (distinct) / 最小 (min) / 最大 (max) |
| 区分の列 | `category` (`groupBy` for tables) | A column name |
| 分ける列 | `splitBy` | A column name |
| 日付の列 | `dateColumn` | A column name; it also becomes that sheet's date column |
| 刻み | `bucket` | 自動 (auto) / 日 (day) / 週 (week) / 月 (month) / 四半期 (quarter) / 年 (year) |
| 書式 | `format` | 数値 (number) / 円 (yen) / ドル (usd) / 割合 or パーセント (percent). For tables, one per entry of 値の列, in the same order |
| 目標 | `target` | A number, or `SheetName!Column`. If the month column is not called 月, write `SheetName!Column!MonthColumn` |
| 大きさ | `size` | 小 (s) / 中 (m) / 大 (l) |
| 上位 | `top` | A number (1–20 for bars, 1–200 for tables) |
| 並び | `sort` | For bars, 値 (value) or 名前 (label). For tables, the heading to sort by |
| 比べる | `compare` | なし (none) / 前の期間 (previous). Only used by 数字; blank means 前の期間 |
| 良し悪し | `goodWhen` | 上がると良い (up) / 下がると良い (down). Only used by 数字; blank means 上がると良い. Use 下がると良い for figures where lower is better, such as cancellations, refunds or costs |
| 明細 | `rows` | 最新 (latest) — tables only; lists the newest rows as they are |

**Some options cannot be written in the sheets.** In 1.0 these live only in the JSON config: the KPI sparkline (`sparkline`), bar orientation (`horizontal`), table sort direction (`order`), the note under a card (`note`), unit formats (`format` as a `custom` object), the refresh interval (`cacheMinutes`), column type overrides (`types`), and the goal's aggregation (`target.agg`, which is always a sum in the sheets). The start and end of a custom period do have sheet rows — see 開始日 and 終了日 below.

### 6-10. The `設定` sheet (Sheets edition)

Two columns, 項目 (item) and 値 (value). Rows may be in any order, and a blank value falls back to the default.

| Item | Accepted values |
|---|---|
| 題名 | The heading shown above the dashboard |
| 言語 | 日本語 (ja) / 英語 (en). Blank means 日本語 |
| テーマ | 自動 (auto) / 明るい (light) / 暗い (dark). Blank means 自動 |
| 期間 | 今月 / 先月 / 直近7日 / 直近30日 / 直近90日 / 今年 / 全期間 / 期間を指定 |
| 開始日 | Start date when 期間 is 期間を指定 (write `2026-09-01`; a real date cell is read too) |
| 終了日 | End date when 期間 is 期間を指定 |
| 絞り込みの列 | Up to 3 column names to offer as dropdowns, separated by 「、」 |

## 7. How the data is read

### 7-1. Column types

Per column: if at least 90% of the non-empty values parse as numbers it is a number column; if at least 90% parse as dates it is a date column; otherwise it is text. Digit strings with a leading zero (`090…`) and strings of 13 or more digits are treated as identifiers, not numbers, so phone numbers and member IDs stay intact.

When the guess is wrong, override it with `types` on the dataset. The three values are `number`, `date` and `text`.

### 7-2. Date formats

Accepted: `2026-09-19`, `2026/9/19`, `2026.9.19`, `2026年9月19日`, ISO timestamps such as `2026-09-19T10:00:00Z`, and real date cells from Sheets. In short, **anything that starts with a four-digit year**.

Month-first dates such as `9/19/2026` are deliberately not parsed: the same string reads as day/month/year in much of the world and month/day/year elsewhere, and guessing silently corrupts a whole column. Convert the column to `YYYY-MM-DD` before importing.

### 7-3. Number formats

`1,234`, `¥1,200`, `1200円`, `$15`, `12%` and full-width digits like `１２３４` all parse. A trailing `%` is stripped without dividing by 100, so `12%` is 12. Parenthesised negatives (`(500)`) and exponent notation (`1.2e3`) do not parse.

Blanks are never counted. `count` counts rows. `sum`, `avg`, `min` and `max` drop values that are not numbers, then print how many were dropped in small type under the card — "Skipped N values that are not numbers". Nothing is treated as zero without telling you.

### 7-4. The row limit

20,000 rows per dataset. Past that, only the first 20,000 are used and the page says "Showing the first 20,000 rows".

### 7-5. Time buckets

With `bucket: "auto"`, the span decides: 31 days or fewer between the first and the last day is daily, 183 days or fewer is weekly (weeks start on Monday), longer is monthly. If a choice would produce more than 400 buckets, it is coarsened step by step through day → week → month → quarter → year. When even yearly buckets exceed 400 — a mistyped year such as `9999-12-31` will do it — only the **most recent 400** are drawn, and the card says "This period is long, so only the most recent 400 buckets are shown". Empty buckets are 0 for `sum`, `count` and `distinct`, and left as gaps for `avg`, `min` and `max`.

### 7-6. What "the previous period" means

- A whole calendar month (1st to last day) → the whole previous month
- From the 1st to a day mid-month (this month) → the previous month, 1st to the same day (clamped to its last day)
- From 1 January to a day mid-year (this year) → the previous year up to the same month and day
- Anything else → the immediately preceding range of the same length
- All time → no comparison

If the previous period contains no rows at all, no change is shown: there is nothing to compare against, and "+100%" would only look like a fact. If the previous value is exactly 0, the absolute change is shown and the percentage is left out.

### 7-7. How "Other" is built

When there are more categories than a widget shows, the remainder is folded into "Other". That only works for aggregates you can add up: `sum` and `count`. For `avg`, `distinct`, `min` and `max`, adding the leftovers would produce a meaningless number, so the extra categories are simply not shown.

### 7-8. How numbers are abbreviated

Where space is tight, large numbers are abbreviated: 万 and 億 in Japanese, K, M and B in English. There is always one decimal place, and a trailing `.0` is dropped (`12,345` → `12.3K`, `20,000` → `20K`). A `decimals` setting in `format` applies to the full-length rendering only; it never changes the abbreviated form.

Only four places abbreviate: the KPI value, the goal card's actual and target, the label at the end of a bar, and axis ticks. Tables, tooltips and exported CSV always print the number in full, with thousands separators.

### 7-9. How a monthly goal is matched

A goal read out of a dataset by month (a `target` with `matchMonth` — see 6-6) is treated as a goal for a single month: the goal row is looked up for that month, and the actual figure sums only that month's rows.

- A period with an end date (This month, Last month, Last 90 days, a custom range, …) → the month of that end date
- A period with no end date ("All time") → the month of the most recent date in the filtered rows
- A dataset with no date column → the goal for today's month, with the actual figure covering every filtered row

Only rows inside that month *and* inside the current period and filters are counted. If the month has no rows at all, the actual figure is 0 and progress reads 0%; that is not an error.

A fixed number (`"target": 3000000`) ignores months and is compared with the whole period on screen.

## 8. Colours and styling

### 8-1. `theme`

`auto` (follow the OS), `light` or `dark`. Set it in the config, or override it with `theme` on `mount`.

### 8-2. The custom properties

Every colour is a CSS custom property, so you can restyle the dashboard from your own page without touching `dashboard.css`.

Tokens that do not change with the theme — `--db-good`, `--db-bad`, `--db-good-strong`, `--db-good-strong-text`, `--db-radius`, `--db-gap` — only need writing once, on `.db`. Surfaces, text and the categorical colours have separate light and dark values, so override them in **all three places**. The dark half of `theme: "auto"` (the default) lives inside a media query, so it is easy to miss.

```css
/* 1. Light, plus anything that does not change with the theme */
.db {
  --db-accent: #7b5cd6;
  --db-radius: 8px;
  --db-gap: 20px;
}

/* 2. When theme is set to "dark" */
.db[data-db-theme="dark"] {
  --db-accent: #a68cf0;
}

/* 3. When theme is "auto" (the default) and the OS is dark */
@media (prefers-color-scheme: dark) {
  .db[data-db-theme="auto"] {
    --db-accent: #a68cf0;
  }
}
```

| Property | What it colours |
|---|---|
| `--db-surface` | The page behind the cards |
| `--db-card` | The card background |
| `--db-border` | Card and control borders |
| `--db-text` | Primary text |
| `--db-text-2` | Body text |
| `--db-text-3` | Small and secondary text |
| `--db-grid` | Gridlines |
| `--db-accent` | The active control colour (defaults to the first categorical colour) |
| `--db-good` | A change in the good direction |
| `--db-bad` | A change in the bad direction |
| `--db-good-strong` | Background of the "Goal reached" badge |
| `--db-good-strong-text` | Text of that badge |
| `--db-radius` | Card corner radius |
| `--db-gap` | Gap between cards |

Dark mode redefines the same names, so write your overrides in the three places above.

### 8-3. Eight categorical colours, and no ninth

The categorical palette is a fixed sequence of 8 colours chosen so that neighbours stay distinguishable.

| # | Property | Light | Dark |
|---|---|---|---|
| 1 | `--db-series-1` | `#2a78d6` | `#3987e5` |
| 2 | `--db-series-2` | `#eb6834` | `#d95926` |
| 3 | `--db-series-3` | `#1baf7a` | `#199e70` |
| 4 | `--db-series-4` | `#eda100` | `#c98500` |
| 5 | `--db-series-5` | `#e87ba4` | `#d55181` |
| 6 | `--db-series-6` | `#008300` | `#008300` |
| 7 | `--db-series-7` | `#4a3aa7` | `#9085e9` |
| 8 | `--db-series-8` | `#e34948` | `#e66767` |
| Other | `--db-series-0` | `#a3a29b` | `#6f6e68` |

There is no ninth colour on purpose: anything past the eighth category is folded into "Other" and drawn in grey (`--db-series-0`). A short palette whose colours are easy to tell apart reads better than a long one where they are not.

Colours are assigned from the ordering of the **unfiltered** data (largest total first, ties by name). Filtering never repaints a category.

The green and red of `--db-good` and `--db-bad` are used only for changes and goals. The categorical sequence has a green and a red of its own; they are different colours.

### 8-4. Printing

Printing collapses the filter row, the "View as table" toggles, the CSV buttons and tooltips, switches to a white background, and keeps cards from being split across pages.

## 9. Troubleshooting

The "Check the settings (N issues)" banner at the top is a collapsed `<details>`: open it to read the issues one by one. Problems with a single widget appear as one red line inside that widget's card.

| Symptom | Cause | Fix |
|---|---|---|
| Text and numbers appear, but the cards have no frame and the charts stretch across the page | `dashboard.css` was not loaded | Add `<link rel="stylesheet" href="./dashboard.css" />` |
| "Check the settings" at the top, and cards reading "The dataset "…" was not found." | The data URL uses `http:` (nothing is logged to the console) | Use an `https:` URL or a relative path |
| Opening the HTML file directly says "This dashboard is unavailable right now"; the ES module version stays blank | The page was opened over `file://` | Serve the folder over HTTP first (`npx serve`, `python3 -m http.server`). Passing the config and rows through `config` and `data` (3-2) works over `file://` |
| A red line replaces the contents of one card | That widget's config has a value the kit cannot read | Open the banner at the top: it names the widget by position and says which field is wrong |
| "No goal was found for …" | The goal data has no row for the last month of the period on screen | Add that month to the goal data. With "All time", the month of the most recent date in the data is used |
| The goal card's actual is smaller than the KPI above it | A monthly goal is compared with that month's figures only | The month being compared is printed next to the figures (`Sep 2026`). To compare against the whole period, give `target` a fixed number (see 7-9) |
| "The column "…" was not found in the dataset "…"" | A misspelled column, or the header row is not the first row | Check that row 1 is the header and that there is no stray whitespace |
| The period filter shows nothing, but "All time" works | The date column was not recognised as dates | Month-first dates such as `9/19/2026` are not parsed. Convert to `YYYY-MM-DD`, or force the column to `date` with `types` |
| A line or bar chart errors with "size must be m or l" | `size` was set to `s` | Use `m` or `l`; axis ticks and category names do not fit in a quarter-width card |
| "Showing the first 20,000 rows" | The dataset is over the limit | Export a narrower period, or split the sheet by month |
| The Sheets edition shows "This dashboard is unavailable right now. Please try again later." | The viewer has no access to the spreadsheet, or the config has an error | Check sharing, then run 「設定を確かめる」. The real reason is in the Apps Script execution log |
| Viewers keep being asked to authorise | Execution is "as the user accessing", so each person authorises once | It should happen exactly once per person. If it repeats, re-check the deployment settings |
| Next.js returns 404 from `/api/dashboard/data?dataset=sales` | The name is not in `dashboard.config.json`, it uses characters that are not allowed, the environment variable is not an `https:` URL, or it is missing in production | A dataset called `sales` needs `DASHBOARD_DATA_SALES`. Names may use lowercase letters, digits and `_` only — no hyphens. To run on the bundled sample in production, set `DASHBOARD_SAMPLE=1` |
| Next.js shows sample product names such as "Shiokaze Blend" | `DASHBOARD_SAMPLE` is still set, or the environment variables are not taking effect | Remove `DASHBOARD_SAMPLE`, set the variables again, and redeploy |
| Worried about a published Sheets CSV URL | "Publish to web" URLs are readable by anyone who has the link | For private numbers use the Sheets edition, where only people the spreadsheet is shared with can see anything |
| The URL never changes when filters change | The page already has its own anchor, such as `#pricing` | The dashboard will not overwrite it. Filtering still works; only URL sharing is unavailable there |

## 10. What we did not build

These are absent from v1.0 on purpose.

| Not built | Why | Instead |
|---|---|---|
| Pie and doughnut charts | Angles of similar size are genuinely hard to compare by eye | Use `bar`; `splitBy` gives you the breakdown as a stack |
| Charts with a second axis | The choice of scales alone can make two series look related or unrelated | Use two charts over the same period, stacked |
| Maps | Boundary data is megabytes on its own, and needs maintaining | Put the region column in `category` and use a bar chart |
| Drill-down | It is easy to lose track of what you are looking at, and it needs its own back behaviour | The filter row does the same job: pick a category and every widget narrows |
| Editing the config on screen | Nobody can tell who changed what, and a broken state has nothing to revert to | The config is a file or a sheet, so changes are reviewable and reversible |
| Direct database connections | Connecting from the browser exposes the credentials to every visitor | Export to CSV or JSON, or adapt the Route Handler in the Next.js template |
| Built-in login | Authentication belongs to the host — it is safer and it is already there | Sheets sharing is the auth in the Sheets edition; use Vercel Password Protection or similar elsewhere |
| AI summaries | They need an external API, a bill, and your numbers leaving the building | The numbers are on screen already; export the CSV into whatever tool you prefer |

## 11. Licence and support

`LICENSE.md` has the full terms (Japanese first, English after; the Japanese text prevails). In short:

- There is a personal licence (the buyer) and an organisation licence (the company or team that bought it)
- You may modify it freely, and ship your modified version as part of client work
- What you may deliver is the result you built with it — the `dist/` files and the config you wrote — not this zip, nor `src/` or `templates/` as a set
- You may not redistribute, resell or share the package, or sell it as a competing product
- Updates within 1.x are free

Defect reports are answered by email for 14 days after purchase. Write to hello@suminawa.dev with the symptom, the edition you are using (embedded, Next.js or Sheets) and the message on screen. We reply within three business days.

### Working on it locally

```bash
npm test          # 706 checks: core, rendering, bundling, and the contents of the release
npm run build     # rebuilds dist/, demo/ and the generated files under templates/nextjs/
npm run release   # release/dashboard-kit-v1.0.0.zip
```

There are no dependencies — just `node --test` on Node 22+ and `scripts/build.mjs`. Everything under `src/core/` is pure: no DOM, no Apps Script, no clock, so it runs directly under Node. See `CHANGELOG.md` for the release history.
