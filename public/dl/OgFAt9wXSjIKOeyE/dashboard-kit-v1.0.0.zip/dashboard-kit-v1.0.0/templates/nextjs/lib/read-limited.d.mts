export function readLimited(stream: ReadableStream<Uint8Array>, maxBytes: number): Promise<Uint8Array | null>;
