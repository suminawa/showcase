export function nextHop(currentUrl: string, locationHeader: string | null | undefined): string | null;
