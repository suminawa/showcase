export function csvToMatrix(text: string): string[][];
