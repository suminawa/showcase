/** @type {import("next").NextConfig} */
const config = {
  // dashboard.config.json と public/sample はサーバーの関数（Route Handler と
  // ページの両方）が実行時に fs で読むので、自動の追跡が見つけられるよう明示する。
  // 実際に fs で読む 2 つの場所（"/" と "/api/dashboard/data"）を名指しし、
  // 念のため "/*" も残しておく（他の場所を増やしても引き続き読めるように）
  outputFileTracingIncludes: {
    "/": ["./dashboard.config.json", "./public/sample/**/*"],
    "/api/dashboard/data": ["./dashboard.config.json", "./public/sample/**/*"],
    "/*": ["./dashboard.config.json", "./public/sample/**/*"],
  },
};

export default config;
