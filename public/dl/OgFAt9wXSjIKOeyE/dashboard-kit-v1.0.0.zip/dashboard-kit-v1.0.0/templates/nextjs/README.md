# ダッシュボード キット — Next.js テンプレ

このフォルダをそのまま Vercel に置くと、売上や指標を見せるダッシュボードのページが動きます。データは自分のパソコンやブラウザではなく、サーバー側（Route Handler）が取りに行くので、データの取得元の URL がお客さまのブラウザに出ることはありません。

## 1. 5 分で試す

```bash
npm install
npm run dev
```

`http://localhost:3000` を開いてください。環境変数を何も入れなくても、同梱の見本データ（架空のお店「しおかぜ珈琲店」の売上）でそのまま動きます。

見本の CSV は固定の日付（2026 年 4 月〜9 月）なので、`dashboard.config.json` の期間は「全期間」（`"period": "all"`）にしてあります。「今月」に切り替えると、その月のデータが無いので空の画面になります。ご自分のデータにつないだあとで「今月」に変えてください。

## 2. 自分のデータにつなぐ

データは Google スプレッドシートの CSV 公開機能を使って読み込みます。

1. スプレッドシートを開き、メニューの「ファイル」→「共有」→「ウェブに公開」を選びます。
2. 公開する範囲で、読み込みたいシートを選びます。
3. 形式を「カンマ区切りの値（.csv）」にして公開し、表示された URL をコピーします。
4. `.env.example` を `.env.local` にコピーし、データセットに合わせて `DASHBOARD_DATA_SALES` のような環境変数にその URL を入れます（どの名前になるかは `.env.example` の説明をご覧ください）。データセットの名前は、半角の小文字・数字・アンダースコア（_）だけが使えます（環境変数の名前になるためです）。CSV の中の列の見出しは日本語で構いません。

**ご注意:**
- 本番では、環境変数を入れ忘れたデータセットは見本に落とさず 404 をお返しします（画面には「データ「sales」が見つかりません」と出ます）。入れ忘れたまま架空の数字をお客さまにお見せしないための決まりです。見本のまま本番で試したいときだけ、環境変数 `DASHBOARD_SAMPLE` に `1` を入れてください。ご自分のデータをつないだら消してください。
- ウェブに公開した URL は、その URL を知っている人なら誰でも読み取れます。このテンプレート自体にはログイン機能が入っていません。数字を人に見せたくないときは、Vercel の Password Protection など、お使いの環境の認証をこのサイトの前に置いてください。
- URL が転送（redirect）を返す場合も、最大 3 回まで自動でたどります。ただし転送先を含め、すべて `https://` である必要があります（`http://` に格下げする転送は失敗として扱います）。
- 取得元からの応答が 15 秒以内に届かない場合や、応答が大きすぎる（10 MB を超える）場合は、失敗として扱います。

## 3. Vercel に置く

1. このフォルダを Git リポジトリにして push します（`vendor/` の中身と `public/sample/` も含めてください）。
2. Vercel で Import し、環境変数（`DASHBOARD_DATA_SALES` など）を入れて Deploy します。
3. 環境変数をあとから変えたときは、再デプロイしないと反映されません。
4. 初回のデプロイ後は、デプロイ先の URL に `/api/dashboard/data?dataset=sales` を足して直接開き、**ご自分のデータの見出しと値が返ってくること**をご確認ください。見本の商品名（「しおかぜブレンド」など）が見えたときは、`DASHBOARD_SAMPLE` が入ったままか、環境変数が効いていません。404 が返るときは、データセットの名前と環境変数の名前が合っていないか、本番で環境変数が入っていません。

## 4. dashboard.config.json を編集する

見出し・部品（KPI・折れ線・棒・目標・表）の並びは `dashboard.config.json` で決めます。書き方はキットの README（「部品（ウィジェット）」の章）をご覧ください。データセットの `url` は編集しても使われません（データの取得元は環境変数だけで決まる決まりです）。

## 5. キットを更新する

新しいバージョンが出たときは、`vendor/dashboard.mjs` と `vendor/dashboard.css` の 2 つのファイルを新しいものに置き換えてください。ほかのファイルはそのままで構いません。

## 6. 入るパッケージについて

`npm install` で入るのは Next.js と React（どちらも MIT ライセンス）で、npm から入ります。ダッシュボード キット本体（`vendor/` の 2 ファイル）には依存パッケージがありません。

---

# Dashboard Kit — Next.js Template

Copy this folder as-is to Vercel and you get a working dashboard page for your sales or metrics. The data is fetched server-side (by a Route Handler), not by your computer or browser, so the data source URL never reaches your visitors' browsers.

## 1. Try it in 5 minutes

```bash
npm install
npm run dev
```

Open `http://localhost:3000`. Without setting any environment variables, it runs on the bundled sample data (sales for a fictional shop, Shiokaze Coffee).

The sample CSVs carry fixed dates (April to September 2026), so `dashboard.config.json` ships with `"period": "all"`. Switch it to `thisMonth` and the screen goes empty, because no sample row falls in the current month. Change it once your own data is connected.

## 2. Connect your own data

Data is loaded from a Google Sheets CSV publication.

1. Open your spreadsheet, then choose File → Share → Publish to web.
2. Pick the sheet you want to load.
3. Publish it as "Comma-separated values (.csv)" and copy the URL shown.
4. Copy `.env.example` to `.env.local`, and set that URL as the matching environment variable, such as `DASHBOARD_DATA_SALES` (see `.env.example` for how names are derived). Dataset names may only use lowercase letters, digits and underscore (_), since they become part of an environment variable name. Column headers inside the CSV may still be in any language.

**Warnings:**
- In production, a dataset whose environment variable is missing returns 404 rather than falling back to the sample data; the card reads "The dataset "sales" was not found." That way a forgotten variable never ships as invented numbers. To try the bundled sample on a real deployment, set `DASHBOARD_SAMPLE=1`, and remove it once your own data is connected.
- Anyone who knows a published URL can read that sheet's data. This template has no login of its own. If the numbers are private, put this site behind your own authentication, such as Vercel's Password Protection.
- If the URL answers with a redirect, up to 3 hops are followed automatically, but every hop (including the final one) must stay on `https://` — a redirect that downgrades to `http://` is treated as a failure.
- If the upstream response doesn't arrive within 15 seconds, or is larger than 10 MB, it's treated as a failure.

## 3. Deploy to Vercel

1. Turn this folder into a Git repository and push it (include the contents of `vendor/` and `public/sample/`).
2. Import it in Vercel, set your environment variables (such as `DASHBOARD_DATA_SALES`), and deploy.
3. Changing environment variables later requires a redeploy to take effect.
4. After the first deploy, open `/api/dashboard/data?dataset=sales` directly on the deployed URL and check that **your own headers and values come back**. If you see sample product names such as "Shiokaze Blend", either `DASHBOARD_SAMPLE` is still set or your environment variables are not taking effect. A 404 means the dataset name and the variable name disagree, or the variable is missing in production.

## 4. Edit dashboard.config.json

The title and the widgets (KPI, line, bar, meter, table) are all configured in `dashboard.config.json`. See the kit's own README (the "Widgets" section) for how to write it. Editing a dataset's `url` has no effect — the actual data source is always controlled by environment variables.

## 5. Update the kit

When a new version is released, replace the two files `vendor/dashboard.mjs` and `vendor/dashboard.css` with the new ones. No other file needs to change.

## 6. What `npm install` brings in

`npm install` installs Next.js and React from npm; both are MIT licensed. The kit itself — the two files under `vendor/` — has no dependencies at all.
