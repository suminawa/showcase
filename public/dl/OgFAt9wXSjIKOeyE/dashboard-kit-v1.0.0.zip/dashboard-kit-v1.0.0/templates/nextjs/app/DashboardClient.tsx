"use client";

import { useEffect, useRef } from "react";

type DashboardConfig = Record<string, unknown>;

type MountedDashboard = {
  destroy(): void;
  refresh(): Promise<void>;
};

/** データセット 1 つぶんを、自分の Route Handler から取ってくる。読めなければ null */
async function fetchDataset(name: string): Promise<unknown[][] | null> {
  let response: Response;
  try {
    // ブラウザのキャッシュ（Cache-Control: max-age=60）を挟むと、手動の再読み込み
    // （refresh()）が古い値を拾うことがあるため、常に取り直す
    response = await fetch("/api/dashboard/data?dataset=" + encodeURIComponent(name), { cache: "no-store" });
  } catch {
    return null;
  }
  if (!response.ok) return null;
  try {
    const body = await response.json();
    return Array.isArray(body) ? body : null;
  } catch {
    return null;
  }
}

/**
 * mountDashboard に渡す小さな読み口。データセットの名前ごとに、自分の API を並行して呼ぶ。
 * URL はここでは持たない（url は環境変数だけが知っている。ここは名前だけで API を呼ぶ）
 */
function createSource(config: DashboardConfig, datasetNames: string[]) {
  return {
    load() {
      return Promise.all(datasetNames.map((name) => fetchDataset(name).then((matrix) => ({ name, matrix })))).then(
        (results) => {
          const datasets: Record<string, unknown[][]> = {};
          const missing: string[] = [];
          for (const { name, matrix } of results) {
            if (matrix !== null) datasets[name] = matrix;
            else missing.push(name);
          }
          return { config, datasets, missing };
        }
      );
    },
  };
}

export function DashboardClient({ config, datasetNames }: { config: DashboardConfig; datasetNames: string[] }) {
  const rootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let instance: MountedDashboard | null = null;
    let cancelled = false;

    import("../vendor/dashboard.mjs").then((mod) => {
      // React の strict mode では、開発時に同じ effect が続けて 2 回動く。
      // 片づけ（cancelled）がすでに済んでいたら、組み立てそのものを見送る
      if (cancelled || rootRef.current === null) return;
      const mounted = mod.mountDashboard(rootRef.current, { source: createSource(config, datasetNames) });
      // 組み立てている間（動的 import 待ち）に片づけが終わっていたら、
      // 組み立てた直後の画面を持ち越さず、その場で片づける
      if (cancelled) {
        mounted.destroy();
        return;
      }
      instance = mounted;
    });

    return () => {
      cancelled = true;
      if (instance !== null) instance.destroy();
    };
  }, [config, datasetNames]);

  return <div ref={rootRef} />;
}
