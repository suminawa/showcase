import type { ReactNode } from "react";
import "../vendor/dashboard.css";

/** このページ自身の文字（<html lang> と、JavaScript が無いときの案内）の言語。既定は ja */
const PAGE_LANG = process.env.DASHBOARD_LANG === "en" ? "en" : "ja";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang={PAGE_LANG}>
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}
