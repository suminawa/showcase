import { readFileSync } from "node:fs";
import { join } from "node:path";
import type { Metadata } from "next";
import { DashboardClient } from "./DashboardClient";

/** このページ自身の文字の言語。layout.tsx と同じ既定（ja） */
const PAGE_LANG = process.env.DASHBOARD_LANG === "en" ? "en" : "ja";

const NOSCRIPT_TEXT: Record<string, string> = {
  ja: "このダッシュボードをご覧いただくには、ブラウザの JavaScript を有効にしてください。",
  en: "Please enable JavaScript in your browser to view this dashboard.",
};

type DashboardConfig = Record<string, unknown> & {
  title?: unknown;
  datasets?: Record<string, Record<string, unknown>>;
};

/**
 * dashboard.config.json を読み、データセットの url をすべて自分の API への相対パスに
 * 差し替える。ファイルに書かれている url をそのままクライアントへ渡すと、書かれていた
 * 中身（万一そこに本物のデータ元の URL が書かれていた場合を含む）がブラウザに届いてしまう。
 * データの取得元は環境変数だけが持つ決まりなので、ここでは中身を見ずに必ず置き換える
 */
function readConfig(): { config: DashboardConfig; datasetNames: string[] } {
  const raw = JSON.parse(readFileSync(join(process.cwd(), "dashboard.config.json"), "utf8")) as DashboardConfig;
  const rawDatasets: Record<string, Record<string, unknown>> =
    raw.datasets && typeof raw.datasets === "object" ? raw.datasets : {};
  const datasetNames = Object.keys(rawDatasets);

  const datasets: Record<string, Record<string, unknown>> = {};
  for (const name of datasetNames) {
    datasets[name] = { ...rawDatasets[name], url: "./api/dashboard/data?dataset=" + name };
  }

  return { config: { ...raw, datasets }, datasetNames };
}

export function generateMetadata(): Metadata {
  const { config } = readConfig();
  const title = typeof config.title === "string" && config.title !== "" ? config.title : "Dashboard";
  return { title };
}

export default function Page() {
  const { config, datasetNames } = readConfig();
  return (
    <>
      <noscript>
        <p style={{ margin: 0, padding: 24, fontFamily: "system-ui, sans-serif", fontSize: 14, lineHeight: 1.8 }}>
          {NOSCRIPT_TEXT[PAGE_LANG]}
        </p>
      </noscript>
      <DashboardClient config={config} datasetNames={datasetNames} />
    </>
  );
}
