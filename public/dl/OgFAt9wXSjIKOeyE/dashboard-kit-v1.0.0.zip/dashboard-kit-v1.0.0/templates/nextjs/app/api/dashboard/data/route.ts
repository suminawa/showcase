import { readFileSync } from "node:fs";
import { join } from "node:path";
import { csvToMatrix } from "../../../../lib/csv.mjs";
import { readLimited } from "../../../../lib/read-limited.mjs";
import { nextHop } from "../../../../lib/safe-fetch.mjs";

// dataset 名として受け取ってよい形。環境変数の名前になるため、
// 半角の小文字・数字・アンダースコアだけにしてある（ハイフンは使えない）
const DATASET_NAME_PATTERN = /^[a-z0-9_]{1,40}$/;
// これより大きい応答は、上流の取り違え・詰まりとみなして 502 にする
const MAX_UPSTREAM_BYTES = 10 * 1024 * 1024;
// 上流からの応答がここまでに届かなければ、詰まっているとみなして 502 にする
const UPSTREAM_TIMEOUT_MS = 15000;
// 転送（3xx）をたどってよい回数。スプレッドシートの「ウェブに公開」の URL は
// 別のホストへ 1 回転送することがあるため、少し余裕を持たせて 3 回まで許す
const MAX_REDIRECT_HOPS = 3;
// 誤りの中身（URL・理由）は外に出さず、常にこの文だけを返す
const GENERIC_ERROR_BODY = { error: "ただいま表示できません。しばらくしてからお試しください。" };

/** dashboard.config.json の datasets に書かれている名前の一覧（読めなければ空） */
function knownDatasetNames(): string[] {
  try {
    const raw = JSON.parse(readFileSync(join(process.cwd(), "dashboard.config.json"), "utf8"));
    const datasets = raw && typeof raw === "object" ? raw.datasets : null;
    return datasets && typeof datasets === "object" ? Object.keys(datasets) : [];
  } catch {
    return [];
  }
}

/** データセット名から、その URL を持つはずの環境変数の名前を作る */
function envKeyFor(name: string): string {
  return "DASHBOARD_DATA_" + name.toUpperCase();
}

/** https の URL だけを取りに行ってよいことにする */
function isHttpsUrl(value: string): boolean {
  return value.startsWith("https://");
}

/**
 * 同梱の見本データを返してよいか。
 * 本番で環境変数を入れ忘れたときに、架空のお店の数字を 200 で返してしまうと、
 * 確認の手順（API を開いて JSON が返ること）まで見本で通ってしまう。
 * そこで、見本を返すのは本番以外のときか、DASHBOARD_SAMPLE=1 を入れたときだけにする
 */
function sampleAllowed(): boolean {
  return process.env.NODE_ENV !== "production" || process.env.DASHBOARD_SAMPLE === "1";
}

/** 同梱の見本 CSV（環境変数が無いときに使う）。無ければ null */
function sampleTextFor(name: string): string | null {
  try {
    return readFileSync(join(process.cwd(), "public", "sample", name + ".csv"), "utf8");
  } catch {
    return null;
  }
}

function jsonError(status: number): Response {
  return Response.json(GENERIC_ERROR_BODY, { status, headers: { "Cache-Control": "private, max-age=60" } });
}

/**
 * 環境変数に書かれた URL を取りに行く。転送（3xx）は自動でたどらず、
 * 行き先を毎回 nextHop() で検査してから自分で次を取りに行く（manual）。
 * 転送のたどり先が https でない・転送が MAX_REDIRECT_HOPS 回を超える・
 * 通信そのものが失敗する（タイムアウトを含む）のいずれでも null を返す
 */
async function fetchUpstream(startUrl: string): Promise<Response | null> {
  let url = startUrl;

  for (let hop = 0; hop <= MAX_REDIRECT_HOPS; hop++) {
    let response: Response;
    try {
      response = await fetch(url, {
        redirect: "manual",
        signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS),
        next: { revalidate: Number(process.env.DASHBOARD_REVALIDATE ?? 300) },
      });
    } catch {
      return null;
    }

    const isRedirect = response.status >= 300 && response.status < 400;
    if (!isRedirect) return response;
    if (hop === MAX_REDIRECT_HOPS) return null;

    const hopUrl = nextHop(url, response.headers.get("location"));
    if (hopUrl === null) return null;
    url = hopUrl;
  }

  return null;
}

export async function GET(request: Request): Promise<Response> {
  const dataset = new URL(request.url).searchParams.get("dataset") ?? "";
  if (!DATASET_NAME_PATTERN.test(dataset) || !knownDatasetNames().includes(dataset)) {
    return new Response(null, { status: 404 });
  }

  const envUrl = process.env[envKeyFor(dataset)];
  let text: string;

  if (typeof envUrl !== "string" || envUrl === "") {
    // 環境変数が無いときは、同梱の見本データで試用できるようにする（本番では sampleAllowed のときだけ）
    const sample = sampleAllowed() ? sampleTextFor(dataset) : null;
    if (sample === null) return new Response(null, { status: 404 });
    text = sample;
  } else if (!isHttpsUrl(envUrl)) {
    // 設定の誤り（https 以外）を外に出さないよう、理由は言わずに 404 にする
    return new Response(null, { status: 404 });
  } else {
    const upstream = await fetchUpstream(envUrl);
    if (upstream === null || !upstream.ok) return jsonError(502);

    // content-length が分かっている場合は、読み始める前に大きすぎる応答を弾く
    const contentLength = upstream.headers.get("content-length");
    if (contentLength !== null && Number(contentLength) > MAX_UPSTREAM_BYTES) return jsonError(502);

    if (upstream.body === null) {
      text = "";
    } else {
      const bytes = await readLimited(upstream.body, MAX_UPSTREAM_BYTES);
      if (bytes === null) return jsonError(502);
      text = new TextDecoder("utf-8").decode(bytes);
    }
  }

  return Response.json(csvToMatrix(text), { headers: { "Cache-Control": "private, max-age=60" } });
}
