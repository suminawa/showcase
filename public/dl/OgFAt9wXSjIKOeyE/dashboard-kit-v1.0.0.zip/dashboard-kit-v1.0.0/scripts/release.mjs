#!/usr/bin/env node
/*
 * 配布 zip を release/ に作る。
 *
 * zip の中は dashboard-kit-v<版>/ の 1 つのフォルダにまとめる（解いたときに
 * 買い手のフォルダにファイルが散らばらないようにするため）。
 * 使うのは OS の zip コマンドだけで、依存パッケージは入れない。
 *
 * dist/・demo/app.js・templates/nextjs/vendor/ などは npm run build が作る生成物で、
 * git には入っていない。そろっていなければ、ここで止めて先に build を促す
 * （追跡ファイルだけの zip では、テンプレも見本ページも動かないため）。
 */
import { execFileSync } from "node:child_process";
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/** 丸ごと入れるフォルダ（この並びの順に、中は名前順で入れる） */
export const RELEASE_DIRS = ["dist", "demo", "samples", "src", "scripts", "test", "templates"];

/** 単体で入れるファイル */
export const RELEASE_FILES = ["README.ja.md", "README.en.md", "LICENSE.md", "CHANGELOG.md", "package.json"];

/** 名前がこれと同じなら、フォルダごと・ファイルごと入れない */
const RELEASE_SKIP_NAMES_ = ["node_modules", ".next", ".git", ".vercel", ".DS_Store", "release", "package-lock.json", "next-env.d.ts"];

/** 入れてよい唯一の .env ファイル（値は空の見本） */
const RELEASE_ENV_KEEP_ = ".env.example";

/**
 * npm run build が作る生成物。1 つでも無ければ zip を作らない。
 * （git に入っていないので、build を飛ばすと静かに欠けた zip ができてしまう）
 */
export const RELEASE_GENERATED = [
  "dist/dashboard.js",
  "dist/dashboard.mjs",
  "dist/dashboard.css",
  "dist/Code.gs",
  "dist/App.html",
  "dist/appsscript.json",
  "demo/app.js",
  "demo/app.css",
  "templates/nextjs/vendor/dashboard.mjs",
  "templates/nextjs/vendor/dashboard.css",
  "templates/nextjs/public/sample/sales.csv",
  "templates/nextjs/public/sample/targets.csv",
  "templates/nextjs/dashboard.config.json",
];

/** その名前を zip に入れるか（フォルダにもファイルにも使う） */
function releaseKeepName_(name) {
  if (RELEASE_SKIP_NAMES_.indexOf(name) !== -1) return false;
  if (name.startsWith(".env")) return name === RELEASE_ENV_KEEP_;
  return true;
}

/** dir の下のファイルを、どの階層も名前順にたどって集める（相対の道すじで返す） */
function releaseWalk_(root, relDir) {
  const found = [];
  const names = readdirSync(join(root, relDir)).slice().sort();
  for (const name of names) {
    if (!releaseKeepName_(name)) continue;
    const relPath = relDir + "/" + name;
    if (statSync(join(root, relPath)).isDirectory()) found.push(...releaseWalk_(root, relPath));
    else found.push(relPath);
  }
  return found;
}

/**
 * zip に入るファイルの一覧を、入る順に返す（root からの相対の道すじ）。
 * 読むだけの純粋な組み立てなので、テストからそのまま呼べる
 */
export function releaseFileList(root) {
  const base = root === undefined ? ROOT : root;
  const found = [];
  for (const dir of RELEASE_DIRS) {
    if (!existsSync(join(base, dir))) continue;
    found.push(...releaseWalk_(base, dir));
  }
  for (const file of RELEASE_FILES) {
    if (existsSync(join(base, file))) found.push(file);
  }
  return found;
}

/** そろっていない生成物の一覧（すべてそろっていれば空） */
export function releaseMissing(root) {
  const base = root === undefined ? ROOT : root;
  return RELEASE_GENERATED.concat(RELEASE_FILES).filter((relPath) => !existsSync(join(base, relPath)));
}

/** package.json の version */
export function releaseVersion(root) {
  const base = root === undefined ? ROOT : root;
  return JSON.parse(readFileSync(join(base, "package.json"), "utf8")).version;
}

/** zip の中の、いちばん外側のフォルダの名前 */
export function releaseFolderName(root) {
  return "dashboard-kit-v" + releaseVersion(root);
}

/** 既定の置き場所 */
export function releaseZipPath(root) {
  const base = root === undefined ? ROOT : root;
  return join(base, "release", releaseFolderName(base) + ".zip");
}

/**
 * zip を作る。outPath を渡さなければ release/dashboard-kit-v<版>.zip。
 * 生成物がそろっていなければ Error を投げる（呼び出し側で文にして出す）。
 * 返すのは { zipPath, bytes, files }
 */
export function createRelease(root, outPath) {
  const base = root === undefined ? ROOT : root;
  const missing = releaseMissing(base);
  if (missing.length > 0) {
    throw new Error(
      "配布 zip を作れません。次のファイルがまだありません。\n  " +
        missing.join("\n  ") +
        "\n先に npm run build を実行してください（npm run release なら自動で実行されます）。"
    );
  }

  const zipPath = outPath === undefined ? releaseZipPath(base) : resolve(outPath);
  const folder = releaseFolderName(base);
  const files = releaseFileList(base);

  mkdirSync(dirname(zipPath), { recursive: true });
  if (existsSync(zipPath)) rmSync(zipPath);

  // zip はフォルダ名を付け替えられないので、いちど写してから固める
  const stage = zipPath + ".stage";
  rmSync(stage, { recursive: true, force: true });
  for (const relPath of files) {
    const to = join(stage, folder, relPath);
    mkdirSync(dirname(to), { recursive: true });
    cpSync(join(base, relPath), to);
  }

  try {
    execFileSync("zip", ["-q", "-X", zipPath].concat(files.map((relPath) => folder + "/" + relPath)), { cwd: stage });
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }

  return { zipPath, bytes: statSync(zipPath).size, files: files.length };
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  try {
    const made = createRelease();
    console.log(made.zipPath + " を作りました");
    console.log("大きさ: " + made.bytes.toLocaleString("ja-JP") + " バイト / ファイル数: " + made.files);
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
}
