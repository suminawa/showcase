#!/usr/bin/env node
// src/core・src/ui・src/gas を束ねて、dist/（配布物）と demo/（見本ページの部品）に書き出す。
import { cpSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/** 商品の版。package.json の 1 か所だけが持つ（束ねた 1 本の Dashboard.version もここから） */
export const VERSION = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")).version;

/**
 * 束ねる順（設計どおり）。一覧にあるのにまだ無いファイルは、環境変数 BUILD_ALLOW_MISSING=1
 * のときだけ飛ばして進む（すべて揃えば、この変数を付けずに実行しても同じ生成物になる）。
 *
 * samples.js（見本データの生成器）は見本のページと GAS のメニューだけで使うので、
 * 配布する dist/dashboard.js・dist/dashboard.mjs（と Next.js テンプレの vendor）には積まない
 */
export const CORE_ORDER = [
  "text.js",
  "dates.js",
  "numbers.js",
  "csv.js",
  "table.js",
  "i18n.js",
  "config.js",
  "filter.js",
  "aggregate.js",
  "colors.js",
  "model.js",
  "samples.js",
];
/** 配布する 1 本に積む core（見本データの生成器を外したもの） */
export const DIST_CORE_ORDER = CORE_ORDER.filter((name) => name !== "samples.js");
/** 画面側の部品。入口ごとの source-*.js と main.js はこのあとに続く */
export const UI_ORDER = ["state.js", "svg.js", "render.js", "render-charts.js", "render-table.js"];
/**
 * 入口ごとに積む読み口。
 * 配布する 1 本には、取りに行く読み口だけを積む（見本の読み口は見本データの生成器を連れてくる
 * ので、買い手が使わない数十 KB を配らずに済ませる。指定されたときは丁寧な誤りになる）。
 * 見本のページ（demo/app.js）には見本の読み口も積み、GAS の画面は GAS の読み口だけを積む
 */
export const BROWSER_SOURCES = ["source-web.js"];
export const DEMO_SOURCES = ["source-web.js", "source-memory.js"];
export const GAS_SOURCES = ["source-gas.js"];
/**
 * GAS サーバー側は集計をしない（設定の検査と行の受け渡しだけ）ので、必要な core だけを積む。
 * table.js（型の推論・行の上限切り）は画面（main.js）側だけが使う道具で、サーバー側のどこからも
 * 呼ばれないので積まない（積んでも束ねた Code.gs の中で誰にも呼ばれない、ただの死んだ関数になる）
 */
export const GAS_CORE_ORDER = ["text.js", "dates.js", "numbers.js", "i18n.js", "config.js", "samples.js"];
export const GAS_ORDER = ["gas_sheets.js", "gas_web.js", "gas_main.js"];

export const MANIFEST = {
  timeZone: "Asia/Tokyo",
  // 思いがけない失敗を、スクリプトの実行ログ（Cloud のログ）に残す
  exceptionLogging: "STACKDRIVER",
  runtimeVersion: "V8",
  // ANYONE = リンクを知っていれば誰でも（ログイン不要）。USER_ACCESSING = 開いた人の権限で動く
  webapp: { access: "ANYONE", executeAs: "USER_ACCESSING" },
  // spreadsheets = シートの読み書き、script.container.ui = メニューの表示
  oauthScopes: ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/script.container.ui"],
};

function allowMissing_() {
  return process.env.BUILD_ALLOW_MISSING === "1";
}

/**
 * Apps Script も素の <script> も import / export を解さない。
 * 1 ファイルに並べれば同じ名前空間になるので、import 行は落とし、行頭の export だけを剥がす。
 */
export function toBundleSource(source) {
  const lines = String(source).split("\n");
  const kept = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (/^import\s[^;]*from\s+["'][^"']+["'];?\s*$/.test(line)) continue;
    kept.push(line.replace(/^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\s)/, ""));
  }
  return kept.join("\n").trim();
}

/**
 * 同じ名前の関数・定数が 2 つのファイルにあると、束ねたときに後勝ちで壊れる。先に見つけて止める。
 * 束ねる最終成果物（ブラウザの入口ごと・Code.gs）1 つにつき、そこに積む全ファイルをまとめて渡すこと。
 * core だけ／ui だけのように群ごとに分けて検査すると、群をまたぐ重複（core の名前を ui や gas で
 * 再定義する等）を見逃す＝束ねる本当の境界は「最終成果物 1 つ」であって、群の切れ目ではない
 */
function checkDuplicates_(parts) {
  // Map で持つ（素の {} だと "toString" のような名前が、書いていないのに「もうある」ことになる）
  const seen = new Map();
  for (let i = 0; i < parts.length; i += 1) {
    const names = parts[i].code.match(/^(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm) || [];
    for (let j = 0; j < names.length; j += 1) {
      const name = names[j].replace(/^(?:async\s+)?(?:function|class|const|let|var)\s+/, "");
      const before = seen.get(name);
      if (before !== undefined && before !== parts[i].file) {
        throw new Error("同じ名前「" + name + "」が " + before + " と " + parts[i].file + " にあります");
      }
      seen.set(name, parts[i].file);
    }
  }
}

/** files のうち、まだ無いものは allowMissing のときだけ飛ばして読み込む（重複検査・結合はしない） */
function loadParts_(root, dir, files) {
  const parts = [];
  for (let i = 0; i < files.length; i += 1) {
    const path = join(root, dir, files[i]);
    if (!existsSync(path)) {
      if (allowMissing_()) continue;
      throw new Error(files[i] + " が見つかりません（" + dir + "）");
    }
    const code = toBundleSource(readFileSync(path, "utf8"));
    parts.push({ file: dir + "/" + files[i], code: "// ===== " + files[i] + " =====\n" + code });
  }
  return parts;
}

/** 束ねる最終成果物 1 つ分の parts（複数の群をまとめたもの）を、重複を検査してから 1 本の文字列にする */
function join_(parts) {
  checkDuplicates_(parts);
  const joined = parts.map((p) => p.code).join("\n\n");
  const leftover = joined.match(/^\s*(import|export)\s/m);
  if (leftover) throw new Error("import / export が残っている: " + leftover[0].trim());
  return joined;
}

/** まだ main.js 等が無く mountDashboard が定義されていないとき、束ねた出力が壊れないように差し込む仮の関数 */
const MOUNT_STUB = 'function mountDashboard() { throw new Error("dashboard: まだ組み立て中です"); }';

function withMountStub_(bundle) {
  if (/^(?:async\s+)?(?:function|const|let|var)\s+mountDashboard\b/m.test(bundle)) return bundle;
  if (!allowMissing_()) throw new Error("mountDashboard が見つかりません");
  return (bundle + "\n\n" + MOUNT_STUB).trim();
}

/** 画面の地の色（style.css）。まだ無ければ allowMissing のときだけ空にする */
export function buildCss(root) {
  const base = root === undefined ? ROOT : root;
  const path = join(base, "src", "ui", "style.css");
  if (existsSync(path)) return readFileSync(path, "utf8");
  if (allowMissing_()) return "";
  throw new Error("src/ui/style.css が見つかりません");
}

/**
 * 画面まわりの束ね。core → UI → 入口の source-*.js → main.js の順。
 * 重複検査は、この入口 1 つ分（core + ui + source-*.js + main.js）をまとめて 1 回だけ行う
 */
function buildBrowserBundle_(root, sourceFiles, coreOrder) {
  const base = root === undefined ? ROOT : root;
  const sources = Array.isArray(sourceFiles) ? sourceFiles : [sourceFiles];
  const coreParts = loadParts_(base, join("src", "core"), coreOrder === undefined ? CORE_ORDER : coreOrder);
  const uiParts = loadParts_(base, join("src", "ui"), UI_ORDER.concat(sources, ["main.js"]));
  return withMountStub_(join_(coreParts.concat(uiParts)).trim());
}

/** 束ねた 1 本を、外に漏らさない包みに入れる（出すのは window.Dashboard だけ） */
function wrapBrowserBundle_(bundle) {
  return "(function () {\n" + bundle + '\n\nwindow.Dashboard = { mount: mountDashboard, version: "' + VERSION + '" };\n})();\n';
}

/** 埋め込みスクリプト本体（IIFE）。window.Dashboard 以外のグローバルを漏らさない */
export function buildDashboardJs(root) {
  return wrapBrowserBundle_(buildBrowserBundle_(root, BROWSER_SOURCES, DIST_CORE_ORDER));
}

/** Next.js テンプレートなどが import する ESM 版 */
export function buildDashboardMjs(root) {
  const bundle = buildBrowserBundle_(root, BROWSER_SOURCES, DIST_CORE_ORDER);
  return bundle + '\n\nexport const version = "' + VERSION + '";\nexport { mountDashboard };\n';
}

/**
 * 見本ページ（demo/app.js）。配布物とまったく同じ包み方にして、見本データの読み口で動かす。
 * 見本のページだけは、見本の読み口と見本データの生成器も積む。
 * 見本のページも、ページ側から見えるのは window.Dashboard だけにする
 * （束ねた中の名前がページに出ていると、買い手がそれを当てにして書いてしまうため）
 */
export function buildDemoScript(root) {
  return wrapBrowserBundle_(buildBrowserBundle_(root, DEMO_SOURCES, CORE_ORDER));
}

/**
 * GAS サーバー側（Code.gs）。集計はしない。設定の検査と行の受け渡しだけ。
 * 重複検査は、Code.gs 1 つ分（core + gas）をまとめて 1 回だけ行う
 */
export function buildServer(root) {
  const base = root === undefined ? ROOT : root;
  const coreParts = loadParts_(base, join("src", "core"), GAS_CORE_ORDER);
  const gasParts = loadParts_(base, join("src", "gas"), GAS_ORDER);
  return join_(coreParts.concat(gasParts)).trim();
}

function fill_(template, marker, content) {
  return template.split(marker).join(content);
}

/**
 * GAS の画面（App.html）に差し込む 1 本。外に漏らすのは window.Dashboard だけにしつつ、
 * 最後に自分で置き場所（#app）を見つけて組み立てまで済ませる
 * （index.html は <script> を 1 つ置くだけで、束ねた中の名前を直に呼ばない）
 */
function wrapGasBundle_(bundle) {
  return (
    "(function () {\n" +
    bundle +
    "\n\n" +
    'window.Dashboard = { mount: mountDashboard, version: "' + VERSION + '" };\n' +
    'var root = document.getElementById("app");\n' +
    'if (root) mountDashboard(root, { source: "gas", hash: false });\n' +
    "})();\n"
  );
}

/**
 * GAS の画面（App.html）。index.html の型に、地の色と画面の JS を差し込む。
 * 画面の JS は 1 つの IIFE で、組み立て（mountDashboard の呼び出し）までそこに含む
 */
export function buildAppHtml(root) {
  const base = root === undefined ? ROOT : root;
  const html = readFileSync(join(base, "src", "ui", "index.html"), "utf8");
  const css = buildCss(base);
  // GAS の画面は 1 枚の HTML なので、差し込む中身が包みの閉じ札を含んでいると、そこで切れてしまう
  if (css.indexOf("</style") >= 0) throw new Error("画面の地の色に </style が含まれています");
  // 画面の側では見本データを作らない（メニューの「見本を入れる」はサーバー側の Code.gs が持つ）
  const js = wrapGasBundle_(buildBrowserBundle_(base, GAS_SOURCES, DIST_CORE_ORDER)) + "\n";
  if (js.indexOf("</script") >= 0) throw new Error("画面の JS に </script が含まれています");
  return fill_(fill_(html, "/*__CSS__*/", css), "/*__JS__*/", js);
}

/**
 * Next.js テンプレの dashboard.config.json（見本の ja 設定を土台にする）。
 * データセットの url は、環境変数の URL がブラウザに出ないよう、必ず自分の API への
 * 相対パスに差し替える（parseConfig は url を要るので、安全な置き場所を渡す）
 */
export function buildNextTemplateConfig(root) {
  const base = root === undefined ? ROOT : root;
  const raw = JSON.parse(readFileSync(join(base, "samples", "ja", "dashboard.config.json"), "utf8"));
  const sourceDatasets = raw && typeof raw === "object" && raw.datasets && typeof raw.datasets === "object" ? raw.datasets : {};
  const datasets = {};
  for (const name of Object.keys(sourceDatasets)) {
    datasets[name] = Object.assign({}, sourceDatasets[name], { url: "./api/dashboard/data?dataset=" + name });
  }
  return Object.assign({}, raw, { datasets });
}

/**
 * Next.js テンプレに、束ねた 2 本（dashboard.mjs・dashboard.css）と、ja の見本 CSV、
 * 差し替え済みの dashboard.config.json を置く。ここで作るものは、この関数の生成物と
 * 必ず同じになる（コミットせず、テストが npm run build のあとの中身を確かめる）。
 *
 * samples/ja（見本データ）が無い base（build.test.mjs が src/ だけを写して build() を
 * 呼ぶ単体テストの写しなど）では、この一式は静かに見送る
 */
function buildNextTemplate_(base) {
  if (!existsSync(join(base, "samples", "ja", "dashboard.config.json"))) return;

  const templateRoot = join(base, "templates", "nextjs");
  mkdirSync(join(templateRoot, "vendor"), { recursive: true });
  mkdirSync(join(templateRoot, "public", "sample"), { recursive: true });

  cpSync(join(base, "dist", "dashboard.mjs"), join(templateRoot, "vendor", "dashboard.mjs"));
  cpSync(join(base, "dist", "dashboard.css"), join(templateRoot, "vendor", "dashboard.css"));
  cpSync(join(base, "samples", "ja", "sales.csv"), join(templateRoot, "public", "sample", "sales.csv"));
  cpSync(join(base, "samples", "ja", "targets.csv"), join(templateRoot, "public", "sample", "targets.csv"));
  writeFileSync(join(templateRoot, "dashboard.config.json"), JSON.stringify(buildNextTemplateConfig(base), null, 2) + "\n");
}

export function build(root) {
  const base = root === undefined ? ROOT : root;
  mkdirSync(join(base, "dist"), { recursive: true });
  mkdirSync(join(base, "demo"), { recursive: true });
  const header = "// ダッシュボード キット — scripts/build.mjs が src/ から作る。ここを直接編集しない\n\n";
  writeFileSync(join(base, "dist", "dashboard.js"), header + buildDashboardJs(base));
  writeFileSync(join(base, "dist", "dashboard.mjs"), header + buildDashboardMjs(base));
  writeFileSync(join(base, "dist", "dashboard.css"), buildCss(base));
  writeFileSync(join(base, "dist", "Code.gs"), header + buildServer(base) + "\n");
  writeFileSync(join(base, "dist", "App.html"), buildAppHtml(base));
  writeFileSync(join(base, "dist", "appsscript.json"), JSON.stringify(MANIFEST, null, 2) + "\n");
  writeFileSync(join(base, "demo", "app.js"), header + buildDemoScript(base));
  writeFileSync(join(base, "demo", "app.css"), buildCss(base));
  buildNextTemplate_(base);
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  build();
  console.log("wrote dist/dashboard.js, dist/dashboard.mjs, dist/dashboard.css, dist/Code.gs, dist/App.html, dist/appsscript.json, demo/app.js, demo/app.css");
}
