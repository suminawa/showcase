#!/usr/bin/env node
// しおかぜ珈琲店の見本データ（CSV・設定）を、固定の today で samples/ja・samples/en に書き出す。
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { sampleData } from "../src/core/samples.js";
import { toCsv } from "../src/core/csv.js";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/** 見本を作るときに使う、固定の today（見本は毎回この日付で作り直す。コミットしてよい） */
export const SAMPLES_TODAY = "2026-09-30";
export const SAMPLES_LANGS = ["ja", "en"];

/**
 * ディスクに置く見本の期間。見本の CSV は固定の日付（2026 年 4 月〜9 月）なので、
 * 「今月」のままだと 10 月以降に開いたときに全部が空になってしまう。
 * ブラウザの中で today から作る見本（demo・GAS の「見本を入れる」）は「今月」のまま
 */
export const SAMPLES_DISK_PERIOD = "all";

/**
 * 言語ごとの sales.csv・targets.csv・dashboard.config.json の中身を、ディスクに触れずに作る。
 * キーは "ja/sales.csv" のような、samples/ 以下の相対パス
 */
export function sampleFiles(today) {
  const files = {};
  for (const lang of SAMPLES_LANGS) {
    const { config, datasets } = sampleData(today, lang);
    const onDisk = Object.assign({}, config, {
      filters: Object.assign({}, config.filters, { period: SAMPLES_DISK_PERIOD }),
    });
    files[lang + "/sales.csv"] = toCsv(datasets.sales);
    files[lang + "/targets.csv"] = toCsv(datasets.targets);
    files[lang + "/dashboard.config.json"] = JSON.stringify(onDisk, null, 2) + "\n";
  }
  return files;
}

/** sampleFiles の中身を samples/ 以下に書き出す */
export function writeSamples(root, today) {
  const base = root === undefined ? ROOT : root;
  const files = sampleFiles(today === undefined ? SAMPLES_TODAY : today);
  for (const relPath of Object.keys(files)) {
    const full = join(base, "samples", relPath);
    mkdirSync(dirname(full), { recursive: true });
    writeFileSync(full, files[relPath]);
  }
  return files;
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  writeSamples();
  console.log("wrote samples/ja/{sales.csv,targets.csv,dashboard.config.json}, samples/en/{sales.csv,targets.csv,dashboard.config.json}");
}
