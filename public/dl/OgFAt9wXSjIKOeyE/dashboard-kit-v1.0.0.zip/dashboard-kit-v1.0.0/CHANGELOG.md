# 更新履歴

## 1.0.0 — 2026-09-27

初版。

- CSV・JSON・Google スプレッドシートの行を、設定 1 つで KPI・折れ線・棒・目標・表の 1 画面にします
  (Turns CSV, JSON or Google Sheets rows into one screen of KPI, line, bar, meter and table widgets from a single config)
- 3 つの置き方を同じ 1 本で動かします。埋め込み（`dist/dashboard.js` と `dist/dashboard.css`）、Next.js テンプレ（`templates/nextjs/`）、Google スプレッドシート（`dist/Code.gs`・`App.html`・`appsscript.json`）
  (Three ways to run the same bundle: an embeddable script, a Next.js App Router template, and a Google Apps Script web app)
- スプレッドシート版は `設定`・`定義` の 2 枚だけで書けます。「良し悪し」で下がると良い数にも対応し、「開始日」「終了日」で期間も指定できます
  (The Sheets edition is configured from two sheets, including a good/bad direction column and a custom date range)
- 画面の上の絞り込みは 1 行だけです。期間（今月・先月・直近 7/30/90 日・今年・全期間・期間の指定）と、列ごとの絞り込みが 3 つまで。下の部品がすべて同時に変わります
  (One filter row: period presets plus up to three column filters, all widgets updating together)
- 絞り込みの状態は URL の `#db.…` に入り、同じ URL を開くと同じ画面になります。ページに別の目印があるときは書き込みません
  (Filter state is shared through the URL hash, and never overwrites a page's own anchor)
- どのグラフにも「表で見る」の切り替えと CSV の書き出しがあります。どの値も、吹き出しを開かずに読めます
  (Every chart has a table view and a CSV export, so every value can be read without a tooltip)
- マウス・指・キーボードの focus で同じ吹き出しが出ます。動きを控える設定と、印刷の体裁にも合わせます
  (The same tooltip for mouse, touch and keyboard focus; reduced motion and print are handled)
- 日本語と英語（画面の固定の文と README の 2 冊）。明るい配色・暗い配色は OS に合わせるか、指定できます
  (Japanese and English UI strings and manuals; light and dark themes)
- 区分の色は 8 色の決まった並びで、9 個目は「その他」にまとめます。色の割り当ては絞り込みで変わりません
  (A fixed eight-colour categorical palette; assignments never change when filtering)
- 日付は暦の日付の文字で扱い、時差で 1 日ずれません。`9/19/2026` のような月が先の形は、読み取らずにお知らせします
  (Dates are handled as calendar strings, so they never shift by a day; month-first dates are rejected rather than guessed)
- 1 つのデータにつき 20,000 行まで。超えた分は使わず、画面の下にその旨を出します
  (Up to 20,000 rows per dataset, with a notice when the limit is reached)
- 依存パッケージなし。706 件の検査つき（`npm test`）
  (No dependencies; 706 tests)
- 見本のお店「しおかぜ珈琲店」（架空）の 6 か月ぶんのデータと、ブラウザだけで動く見本ページ
  (Six months of sample data for a fictional shop, Shiokaze Coffee, and a demo page that runs from the file system)
- zip の中身: `dist/`・`demo/`・`samples/`・`templates/nextjs/`・`src/`・`test/`・`scripts/`・`package.json`・`README.ja.md`・`README.en.md`・`LICENSE.md`・`CHANGELOG.md`
  (In the zip: the built files, the demo page, the samples, the Next.js template, the source and its tests, and the four documents)
