# 更新履歴

## 1.0.0 — 発売前の見直し（2026-09-23）

版は 1.0.0 のままです。スプレッドシート版を、検査用の偽の Apps Script を本物の癖に寄せて見直しました（`test/helpers/gas-fakes.mjs`。書いた文字の数や日付への読み替え・マニフェストに無い許可・画面から呼ばれたときの `getUi()`・公開の設定による実行者の違い・`google.script.run` が Date を運べないこと）。見つかった点はキットの側で直しています。
(Pre-release review of the Sheets edition. The test fakes now behave like the real Apps Script, and every gap they found was fixed in the kit.)

- 「次のユーザーとして実行」が「自分」で公開されていると、URL を知っている方ならどなたでも持ち主の権限で数字を見られてしまうため、開いた方と実行している方が違うときは数字を出さずに止めます。そのために許可 `userinfo.email` を 1 つ足しました（アドレスは確かめるだけで、書き込みも送信もしません）
  (A deployment set to "Execute as: Me" is now refused instead of showing the owner's numbers to anyone with the link. Adds the `userinfo.email` scope for this check)
- 「見本を入れる」で `設定` の「開始日」「終了日」の行が消えていたのを直しました。見本でも全項目と書き方の列を並べます。「初期化」は、すでにある `設定` に足りない項目の行だけを書き足します
  (Insert sample data no longer drops the start/end date rows; Initialise appends missing setting rows)
- `設定`・`定義` のセルを書式なしテキストにして、`10/1` や `001` が日付や数に読み替えられないようにしました
  (The config sheets are written as plain text, so values are not turned into dates or numbers)
- `設定` の開始日・終了日を日付のセルで書いたとき、スプレッドシートの時間帯で読むようにしました（時間帯によっては 1 日ずれていました）
  (Date cells in the settings are read in the spreadsheet's time zone, fixing a one-day shift)
- 項目名・見出し・決まった言葉に空白（全角も）が混ざっていても読みます（「開始　日」「値 の列」「期間を 指定」など）
  (Stray spaces in item names, headings and keywords are ignored)
- メニューの処理をウェブアプリの画面から呼ばれても、シートに書き込む前に止まるようにしました
  (Menu functions invoked from the web app stop before touching any sheet)
- 説明書に、公開の設定を選ぶ理由と、間違えたときの直し方（デプロイを管理 → 鉛筆 → 新バージョン）、CSV の取り込み方を足しました
  (The manuals explain the deployment settings, how to fix a wrong deployment, and how to import a CSV)
- 検査は 722 件になりました
  (722 tests)

## 1.0.0 — 2026-09-27

初版。

- CSV・JSON・Google スプレッドシートの行を、設定 1 つで KPI・折れ線・棒・目標・表の 1 画面にします
  (Turns CSV, JSON or Google Sheets rows into one screen of KPI, line, bar, meter and table widgets from a single config)
- 3 つの置き方を同じ 1 本で動かします。埋め込み（`dist/dashboard.js` と `dist/dashboard.css`）、Next.js テンプレ（`templates/nextjs/`）、Google スプレッドシート（`dist/Code.gs`・`App.html`・`appsscript.json`）
  (Three ways to run the same bundle: an embeddable script, a Next.js App Router template, and a Google Apps Script web app)
- スプレッドシート版は `設定`・`定義` の 2 枚だけで書けます。「良し悪し」で下がると良い数にも対応し、「開始日」「終了日」で期間も指定できます
  (The Sheets edition is configured from two sheets, including a good/bad direction column and a custom date range)
- 画面の上の絞り込みは 1 行だけです。期間（今月・先月・直近 7/30/90 日・今年・全期間・期間の指定）と、列ごとの絞り込みが 3 つまで。下の部品がすべて同時に変わります
  (One filter row: period presets plus up to three column filters, all widgets updating together)
- 絞り込みの状態は URL の `#db.…` に入り、同じ URL を開くと同じ画面になります。ページに別の目印があるときは書き込みません
  (Filter state is shared through the URL hash, and never overwrites a page's own anchor)
- どのグラフにも「表で見る」の切り替えと CSV の書き出しがあります。どの値も、吹き出しを開かずに読めます
  (Every chart has a table view and a CSV export, so every value can be read without a tooltip)
- マウス・指・キーボードの focus で同じ吹き出しが出ます。動きを控える設定と、印刷の体裁にも合わせます
  (The same tooltip for mouse, touch and keyboard focus; reduced motion and print are handled)
- 日本語と英語（画面の固定の文と README の 2 冊）。明るい配色・暗い配色は OS に合わせるか、指定できます
  (Japanese and English UI strings and manuals; light and dark themes)
- 区分の色は 8 色の決まった並びで、9 個目は「その他」にまとめます。色の割り当ては絞り込みで変わりません
  (A fixed eight-colour categorical palette; assignments never change when filtering)
- 日付は暦の日付の文字で扱い、時差で 1 日ずれません。`9/19/2026` のような月が先の形は、読み取らずにお知らせします
  (Dates are handled as calendar strings, so they never shift by a day; month-first dates are rejected rather than guessed)
- 1 つのデータにつき 20,000 行まで。超えた分は使わず、画面の下にその旨を出します
  (Up to 20,000 rows per dataset, with a notice when the limit is reached)
- 依存パッケージなし。706 件の検査つき（`npm test`）
  (No dependencies; 706 tests)
- 見本のお店「しおかぜ珈琲店」（架空）の 6 か月ぶんのデータと、ブラウザだけで動く見本ページ
  (Six months of sample data for a fictional shop, Shiokaze Coffee, and a demo page that runs from the file system)
- zip の中身: `dist/`・`demo/`・`samples/`・`templates/nextjs/`・`src/`・`test/`・`scripts/`・`package.json`・`README.ja.md`・`README.en.md`・`LICENSE.md`・`CHANGELOG.md`
  (In the zip: the built files, the demo page, the samples, the Next.js template, the source and its tests, and the four documents)
