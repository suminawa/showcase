import { test } from "node:test";
import assert from "node:assert/strict";
import { parseNumber, formatNumber, niceTicks } from "../src/core/numbers.js";

test("parseNumber: 数値はそのまま。NaN・Infinity は null", () => {
  assert.equal(parseNumber(1234), 1234);
  assert.equal(parseNumber(0), 0);
  assert.equal(parseNumber(-12.5), -12.5);
  assert.equal(parseNumber(NaN), null);
  assert.equal(parseNumber(Infinity), null);
  assert.equal(parseNumber(-Infinity), null);
});

test("parseNumber: 通貨記号・桁区切り・全角を外して読む", () => {
  assert.equal(parseNumber("¥1,200"), 1200);
  assert.equal(parseNumber("￥1,200"), 1200);
  assert.equal(parseNumber("$1,200"), 1200);
  assert.equal(parseNumber("1,200円"), 1200);
  assert.equal(parseNumber("１２，３４５"), 12345, "全角の数字と全角カンマも読む");
  assert.equal(parseNumber("  1,200  "), 1200, "前後の空白は外す");
});

test("parseNumber: 末尾の % はそのままの数（100 で割らない）", () => {
  assert.equal(parseNumber("12%"), 12);
  assert.equal(parseNumber("-12%"), -12);
});

test("parseNumber: 読めない形は null", () => {
  assert.equal(parseNumber("(1,234)"), null, "かっこ負数は読まない");
  assert.equal(parseNumber("1e3"), null, "指数表記は読まない");
  assert.equal(parseNumber(""), null);
  assert.equal(parseNumber("   "), null);
  assert.equal(parseNumber(null), null);
  assert.equal(parseNumber(undefined), null);
  assert.equal(parseNumber("しおかぜ"), null);
  assert.equal(parseNumber("+5"), null, "先頭の + は数として読まない（正規表現は - だけを許す）");
});

test("formatNumber: 円・ドル・数値の書式と符号", () => {
  assert.equal(formatNumber(1200, "yen"), "¥1,200");
  assert.equal(formatNumber(-1200, "yen"), "-¥1,200");
  assert.equal(formatNumber(1200, "usd"), "$1,200");
  assert.equal(formatNumber(-1200, "usd"), "-$1,200");
  assert.equal(formatNumber(1234, "number"), "1,234");
  assert.equal(formatNumber(0, "number"), "0");
});

test("formatNumber: percent は値をそのまま出し、小数 1 桁", () => {
  assert.equal(formatNumber(12.5, "percent"), "12.5%");
  assert.equal(formatNumber(12, "percent"), "12.0%");
  assert.equal(formatNumber(-3.4, "percent"), "-3.4%");
});

test("formatNumber: null・undefined・NaN は —", () => {
  assert.equal(formatNumber(null, "yen"), "—");
  assert.equal(formatNumber(undefined, "number"), "—");
  assert.equal(formatNumber(NaN, "number"), "—");
});

test("formatNumber: options.decimals が指定されればそれが勝つ", () => {
  assert.equal(formatNumber(1234.5678, "number", "ja", { decimals: 2 }), "1,234.57");
  assert.equal(formatNumber(12.345, "percent", "ja", { decimals: 0 }), "12%");
});

test("formatNumber: custom 書式は prefix / suffix / decimals を使う", () => {
  assert.equal(formatNumber(42, { type: "custom", prefix: "×", suffix: "回" }), "×42回");
  assert.equal(formatNumber(3.14159, { type: "custom", prefix: "", suffix: "pt", decimals: 2 }), "3.14pt");
});

test("formatNumber: compact（ja）は 1万で「万」、1億で「億」。1万未満はそのまま", () => {
  assert.equal(formatNumber(12345, "number", "ja", { compact: true }), "1.2万");
  assert.equal(formatNumber(120000000, "number", "ja", { compact: true }), "1.2億");
  assert.equal(formatNumber(100000000, "number", "ja", { compact: true }), "1億", "末尾の .0 は落とす");
  assert.equal(formatNumber(5000, "number", "ja", { compact: true }), "5,000", "1万未満はそのまま");
  assert.equal(formatNumber(9999, "number", "ja", { compact: true }), "9,999", "1万未満はそのまま（4 桁でも）");
});

test("formatNumber: compact（ja）は丸めで次の単位に届いたら繰り上げる", () => {
  assert.equal(formatNumber(99999999, "number", "ja", { compact: true }), "1億", "万で丸めると10000万になるので億に繰り上げる");
  assert.equal(formatNumber(-99999999, "number", "ja", { compact: true }), "-1億", "負の値も同じ繰り上げをしてから符号を付ける");
  assert.equal(formatNumber(99999500, "yen", "ja", { compact: true }), "¥1億", "yen などの書式を重ねても繰り上げは変わらない");
  assert.equal(formatNumber(1234500000000, "number", "ja", { compact: true }), "12,345億", "億より上の単位は無いので、3桁区切りで表す");
});

test("formatNumber: compact（en）は K・M・B。1000未満はそのまま", () => {
  assert.equal(formatNumber(1200, "number", "en", { compact: true }), "1.2K");
  assert.equal(formatNumber(3400000, "number", "en", { compact: true }), "3.4M");
  assert.equal(formatNumber(5600000000, "number", "en", { compact: true }), "5.6B");
  assert.equal(formatNumber(500, "number", "en", { compact: true }), "500");
});

test("formatNumber: compact（en）は丸めで次の単位に届いたら繰り上げる", () => {
  assert.equal(formatNumber(999999999, "number", "en", { compact: true }), "1B", "Mで丸めると1000Mになるので B に繰り上げる");
  assert.equal(formatNumber(999950, "number", "en", { compact: true }), "1M", "Kで丸めると1000Kになるので M に繰り上げる（1000K にしない）");
  assert.equal(formatNumber(1234000000000, "number", "en", { compact: true }), "1,234B", "Bより上の単位は無いので、3桁区切りで表す");
});

test("formatNumber: compact は yen などほかの書式にも重ねられる", () => {
  assert.equal(formatNumber(12345, "yen", "ja", { compact: true }), "¥1.2万");
});

test("niceTicks: 0 を含み、きりのいい刻みで max 以上まで並べる", () => {
  assert.deepEqual(niceTicks(0, 87), [0, 25, 50, 75, 100]);
  assert.deepEqual(niceTicks(0, 100, 4), [0, 25, 50, 75, 100]);
  assert.deepEqual(niceTicks(0, 10, 1), [0, 10]);
});

test("niceTicks: max === 0（または max <= min）は [0, 1]", () => {
  assert.deepEqual(niceTicks(0, 0), [0, 1]);
  assert.deepEqual(niceTicks(5, 3), [0, 1]);
  assert.deepEqual(niceTicks(5, 5), [0, 1]);
});

test("niceTicks: 最小が負なら、きりのいい負の下限も含める", () => {
  assert.deepEqual(niceTicks(-30, 80, 4), [-50, 0, 50, 100]);
});

test("formatNumber: 丸めた結果がゼロなら、負の符号を付けない（コード審査 M1）", () => {
  assert.equal(formatNumber(-0.4, "number"), "0");
  assert.equal(formatNumber(-0.4, "yen"), "¥0");
  assert.equal(formatNumber(-0.4, "usd"), "$0");
  assert.equal(formatNumber(-0.04, "percent"), "0.0%");
  assert.equal(formatNumber(-0.4, { type: "custom", prefix: "", suffix: " 件", decimals: 0 }), "0 件");
  assert.equal(formatNumber(-0, "number"), "0");
  assert.equal(formatNumber(-0.6, "number"), "-1", "丸めてもゼロでなければ符号は残す");
  assert.equal(formatNumber(-0.4, "number", "ja", { compact: true }), "0", "縮めない大きさでも同じ");
  assert.equal(formatNumber(-0.44, "number", "ja", { decimals: 1 }), "-0.4", "桁を残せば符号も残る");
});

test("formatNumber: 縮めた数の小数はいつも 1 桁（decimals は縮めない表示だけに効く）", () => {
  const items = { type: "custom", prefix: "", suffix: " 件", decimals: 0 };
  assert.equal(formatNumber(12345, items, "ja", { compact: true }), "1.2万 件", "decimals: 0 でも 1 万 件にしない");
  assert.equal(formatNumber(12345, items, "ja"), "12,345 件", "縮めない表示では decimals どおり");
  assert.equal(formatNumber(20000, items, "ja", { compact: true }), "2万 件", "末尾の .0 は落とす");
  assert.equal(formatNumber(12345, { type: "custom", prefix: "", suffix: "", decimals: 3 }, "ja", { compact: true }), "1.2万");
  assert.equal(formatNumber(12345, "number", "en", { compact: true }), "12.3K");
  assert.equal(formatNumber(1234, { type: "custom", prefix: "", suffix: "", decimals: 2 }, "ja", { compact: true }), "1,234.00", "しきい値未満は縮めないので decimals どおり");
});
