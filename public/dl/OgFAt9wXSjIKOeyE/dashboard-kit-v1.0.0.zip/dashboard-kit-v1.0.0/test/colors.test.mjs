import { test } from "node:test";
import assert from "node:assert/strict";
import { assignSeriesColors } from "../src/core/colors.js";

const ALL_ROWS = [
  { チャネル: "EC", 金額: 100 },
  { チャネル: "EC", 金額: 100 },
  { チャネル: "店舗", 金額: 250 },
  { チャネル: "電話", 金額: 10 },
];

test("assignSeriesColors: 合計の大きい順に 1 から番号を振る", () => {
  const colors = assignSeriesColors(ALL_ROWS, "チャネル", "金額", "sum", 8);
  assert.equal(colors.get("店舗"), 1); // 250
  assert.equal(colors.get("EC"), 2); // 200
  assert.equal(colors.get("電話"), 3); // 10
});

test("assignSeriesColors: 同じ合計は名前順で並べる", () => {
  const rows = [
    { チャネル: "b", 金額: 10 },
    { チャネル: "a", 金額: 10 },
  ];
  const colors = assignSeriesColors(rows, "チャネル", "金額", "sum", 8);
  assert.equal(colors.get("a"), 1);
  assert.equal(colors.get("b"), 2);
});

test("assignSeriesColors: max を超えた分は 0（灰の「その他」）", () => {
  const rows = [
    { 区分: "A", 金額: 40 },
    { 区分: "B", 金額: 30 },
    { 区分: "C", 金額: 20 },
    { 区分: "D", 金額: 10 },
  ];
  const colors = assignSeriesColors(rows, "区分", "金額", "sum", 2);
  assert.equal(colors.get("A"), 1);
  assert.equal(colors.get("B"), 2);
  assert.equal(colors.get("C"), 0);
  assert.equal(colors.get("D"), 0);
});

test("assignSeriesColors: 空の区分は blankLabel を渡したときだけそのラベルでまとまる", () => {
  const rows = [
    { 区分: "A", 金額: 5 },
    { 区分: "", 金額: 50 },
    { 区分: null, 金額: 20 },
  ];
  const colors = assignSeriesColors(rows, "区分", "金額", "sum", 8, "（空）");
  assert.equal(colors.get("（空）"), 1); // 50 + 20 = 70
  assert.equal(colors.get("A"), 2);
});

test("assignSeriesColors: 色の割り当ては全データの並びで決まり、絞り込み後の一部だけでは変わらない", () => {
  // 全データでは「店舗」がいちばん大きいが、EC だけに絞ると見かけ上は EC しか残らない。
  // 色は絞り込み後の rows ではなく、渡された allRows（全データ）のランキングで決まる
  const colors = assignSeriesColors(ALL_ROWS, "チャネル", "金額", "sum", 8);
  const filtered = ALL_ROWS.filter((r) => r.チャネル === "EC");
  // 絞り込んだ後でも、同じ Map をそのまま引けば「店舗」を除いた EC の番号は変わらない
  assert.equal(colors.get("EC"), 2);
  assert.equal(new Set(filtered.map((r) => r.チャネル)).size, 1);
});
