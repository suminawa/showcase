import { test, after } from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdtempSync, mkdirSync, readFileSync, cpSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { MANIFEST, VERSION, build, toBundleSource, buildServer, buildDashboardJs, buildDashboardMjs, buildDemoScript } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const PACKAGE_VERSION = JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version;

test("版は package.json の 1 か所だけが持つ（build.mjs は直接書かない）", () => {
  assert.equal(VERSION, PACKAGE_VERSION);
  const source = readFileSync(join(root, "scripts", "build.mjs"), "utf8");
  assert.equal(source.includes('version: "' + PACKAGE_VERSION + '"'), false, "版を build.mjs に直接書かない");
  assert.ok(source.includes('JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")).version'), "package.json から読むはず");
});

test("toBundleSource: import 行を落とし、行頭の export だけ剥がす", () => {
  const src = 'import { a } from "./a.js";\nexport function f() {}\nexport const X = 1;\nexport class C {}\nconst inner = "export function g";\n';
  const out = toBundleSource(src);
  assert.equal(out.indexOf("import"), -1);
  assert.ok(out.startsWith("function f() {}"));
  assert.ok(out.includes("\nconst X = 1;"));
  assert.ok(out.includes("\nclass C {}"));
  assert.ok(out.includes('const inner = "export function g"'));
});

test("build: dist と demo に 8 つの生成物を書き、import / export が残らない", () => {
  // 本物の dist は pretest（npm run build）が作るので、ここでは写しの上で作って確かめる
  const dir = mktempCopy_();
  build(dir);
  for (const name of [
    "dist/dashboard.js",
    "dist/dashboard.mjs",
    "dist/dashboard.css",
    "dist/Code.gs",
    "dist/App.html",
    "dist/appsscript.json",
    "demo/app.js",
    "demo/app.css",
  ]) {
    assert.ok(existsSync(join(dir, name)), name + " が無い");
  }
  const js = readFileSync(join(dir, "dist", "dashboard.js"), "utf8");
  assert.equal(/^\s*(import|export)\s/m.test(js), false);
  assert.ok(js.includes('window.Dashboard = { mount: mountDashboard, version: "' + PACKAGE_VERSION + '" };'));

  const mjs = readFileSync(join(dir, "dist", "dashboard.mjs"), "utf8");
  assert.equal(/^\s*import\s/m.test(mjs), false);
  assert.ok(mjs.includes('export const version = "' + PACKAGE_VERSION + '";'), "版も export するはず");
  assert.ok(mjs.trim().endsWith("export { mountDashboard };"));

  const manifest = JSON.parse(readFileSync(join(dir, "dist", "appsscript.json"), "utf8"));
  assert.deepEqual(manifest, MANIFEST);

  // 置き場所は id だけ（描く側が .db の包みを作る）。差し込みの目印も残さない
  const html = readFileSync(join(dir, "dist", "App.html"), "utf8");
  assert.ok(html.includes('<div id="app"></div>'));
  assert.equal(html.includes("/*__CSS__*/"), false);
  assert.equal(html.includes("/*__JS__*/"), false);

  const demoJs = readFileSync(join(dir, "demo", "app.js"), "utf8");
  assert.ok(demoJs.includes("window.Dashboard"));
});

test("束ねる一覧にあるファイルが無いと、build が止まる", () => {
  const dir = mktempCopy_();
  rmSync(join(dir, "src", "gas", "gas_web.js"));
  assert.throws(() => buildServer(dir), /gas_web\.js が見つかりません/);

  const another = mktempCopy_();
  rmSync(join(another, "src", "ui", "source-web.js"));
  assert.throws(() => build(another), /source-web\.js が見つかりません/);
});

test("dashboard.js（IIFE）は仮の window の上で実行でき、mountDashboard が出そろっている", () => {
  const code = readFileSync(join(root, "dist", "dashboard.js"), "utf8");
  // main.js が mountDashboard を持ってきたら、仮の関数は差し込まれない
  assert.equal(code.includes("まだ組み立て中です"), false, "仮の mountDashboard が残っている");
  const sandboxWindow = {};
  const run = new Function("window", code);
  run(sandboxWindow);
  assert.equal(typeof sandboxWindow.Dashboard.mount, "function");
  assert.equal(sandboxWindow.Dashboard.version, PACKAGE_VERSION);
  assert.throws(() => sandboxWindow.Dashboard.mount(), /置き場所の要素/);
});

test("dashboard.mjs は動的 import でき、mountDashboard と version を出す", async () => {
  const mod = await import(pathToFileURL(join(root, "dist", "dashboard.mjs")).href);
  assert.equal(typeof mod.mountDashboard, "function");
  assert.equal(mod.version, PACKAGE_VERSION);
  assert.throws(() => mod.mountDashboard(), /置き場所の要素/);
});

test("Code.gs（GAS）に import / export が残らない", () => {
  const code = readFileSync(join(root, "dist", "Code.gs"), "utf8");
  assert.equal(/^\s*(import|export)\s/m.test(code), false);
});

test("同じ名前の関数が 2 ファイルにあると build が止まる（同じグループ内: core 同士）", () => {
  const dir = mktempCopy_();
  writeFileSync(join(dir, "src", "core", "dates.js"), 'export function textOf() {}\n');
  assert.throws(() => buildServer(dir), /同じ名前「textOf」/);
});

test("同じ名前の関数が core と ui にまたがってあると build が止まる（束ねる境界をまたぐ重複）", () => {
  const dir = mktempCopy_();
  // text.js（core）の textOf と同じ名前を、ui 側のファイルにも定義する
  writeFileSync(join(dir, "src", "ui", "state.js"), 'export function textOf() {}\n');
  assert.throws(() => buildDashboardJs(dir), /同じ名前「textOf」/);
});

test("同じ名前の関数が core と gas にまたがってあると build が止まる（Code.gs の束ねる境界をまたぐ重複）", () => {
  const dir = mktempCopy_();
  mkdirSync(join(dir, "src", "gas"), { recursive: true });
  // text.js（core）の escapeHtml と同じ名前を、gas 側のファイルにも定義する
  writeFileSync(join(dir, "src", "gas", "gas_web.js"), 'export function escapeHtml() {}\n');
  assert.throws(() => buildServer(dir), /同じ名前「escapeHtml」/);
});

test("画面の JS に </script が混ざると build が止まる", () => {
  const dir = mktempCopy_();
  writeFileSync(join(dir, "src", "ui", "main.js"), 'const BAD = "</script>";\nfunction mountDashboard() {}\n');
  assert.throws(() => build(dir), /<\/script/);
});

const tempDirs_ = [];

function mktempCopy_() {
  const dir = mkdtempSync(join(tmpdir(), "dashboard-kit-"));
  cpSync(join(root, "src"), join(dir, "src"), { recursive: true });
  tempDirs_.push(dir);
  return dir;
}

after(() => {
  for (const dir of tempDirs_) rmSync(dir, { recursive: true, force: true });
});

test("画面の地の色に </style が混ざると build が止まる", () => {
  const dir = mktempCopy_();
  writeFileSync(join(dir, "src", "ui", "style.css"), ".db { content: '</style>'; }\n");
  assert.throws(() => build(dir), /<\/style/);
});

test("重複の検査は、JS が最初から持っている名前でも誤って止めない（コード審査 M9）", () => {
  const dir = mktempCopy_();
  // top-level の名前が "toString" でも、ほかのファイルと重なっていなければ通る
  writeFileSync(join(dir, "src", "ui", "state.js"), 'export const PERIOD_PRESETS = [];\nconst toString = 1;\nexport function reduce(s) { return s + toString; }\nexport function initialState() { return {}; }\nexport function filtersDiffer() { return false; }\n');
  assert.doesNotThrow(() => buildDashboardJs(dir));
});

test("配布する 1 本には見本データの生成器を積まず、見本のページには積む", () => {
  const distJs = buildDashboardJs(root);
  assert.equal(distJs.includes("// ===== samples.js ====="), false);
  assert.equal(distJs.includes("// ===== source-memory.js ====="), false);
  assert.ok(distJs.includes("// ===== source-web.js ====="));

  const demo = buildDemoScript(root);
  assert.ok(demo.includes("// ===== samples.js ====="));
  assert.ok(demo.includes("// ===== source-memory.js ====="));

  // GAS のサーバー側（Code.gs）は、メニューの「見本を入れる」のために持ち続ける
  assert.ok(buildServer(root).includes("// ===== samples.js ====="));
});
