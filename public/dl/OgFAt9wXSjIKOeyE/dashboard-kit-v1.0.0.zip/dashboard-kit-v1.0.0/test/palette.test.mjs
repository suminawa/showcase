/**
 * 区分の色（--db-series-1〜8 と、「その他」の --db-series-0）を見張る。
 *
 * ねらいは 2 つ。
 * （1）決めた 9 色が、明るい配色でも暗い配色でも 1 字も変わっていないこと。
 * （2）並びで隣り合う色どうしが、目で見て十分に離れていること
 *     （sRGB を OKLab に移した距離。色覚のちがいまでは見ないので、値の固定が主なねらい）。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const CSS = readFileSync(fileURLToPath(new URL("../src/ui/style.css", import.meta.url)), "utf8");

/** 決めた並び（1〜8）と、「その他」の灰。ここが商品の決まりそのもの */
const PALETTE_LIGHT_ = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"];
const PALETTE_DARK_ = ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"];
const PALETTE_OTHER_ = { light: "#a3a29b", dark: "#6f6e68" };

/** 隣り合う色に、少なくともこれだけの隔たりを求める（OKLab の距離 × 100） */
const PALETTE_MIN_GAP_ = 15;

/**
 * 選び方（selector）の決まり書きを取り出す。行の頭（空白だけを挟んで）から始まるものだけを見る
 * （ファイル頭の説明の中の .db { … } を拾わないため）。
 * 暗い配色の auto は media query の中で字下げしてあるので、字下げも受け取る
 */
function block_(selector) {
  const found = CSS.match(new RegExp("\\n[ \\t]*" + selector.replace(/[.[\]"=-]/g, "\\$&") + " \\{[\\s\\S]*?\\n[ \\t]*\\}"));
  assert.notEqual(found, null, selector + " が style.css に見つかりません");
  return found[0];
}

/** その決まり書きの中の --db-series-N の色 */
function series_(block, index) {
  const found = block.match(new RegExp("--db-series-" + index + ":\\s*(#[0-9a-f]{6})"));
  assert.notEqual(found, null, "--db-series-" + index + " の色が見つかりません");
  return found[1];
}

/** sRGB の 1 成分（0〜255）を、光の量に戻す */
function linear_(value) {
  const c = value / 255;
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

/** #rrggbb を OKLab の [L, a, b] にする */
function oklab_(hex) {
  const r = linear_(parseInt(hex.slice(1, 3), 16));
  const g = linear_(parseInt(hex.slice(3, 5), 16));
  const b = linear_(parseInt(hex.slice(5, 7), 16));
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
  const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
  const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
  ];
}

/** 2 色の隔たり（OKLab の距離 × 100） */
function gap_(a, b) {
  const x = oklab_(a);
  const y = oklab_(b);
  return Math.hypot(x[0] - y[0], x[1] - y[1], x[2] - y[2]) * 100;
}

function round_(value) {
  return Math.round(value * 100) / 100;
}

const LIGHT_BLOCK_ = block_(".db");
const DARK_BLOCK_ = block_('.db[data-db-theme="dark"]');

test("自己点検: OKLab の距離が、知られた値と合う", () => {
  assert.equal(round_(gap_("#000000", "#000000")), 0);
  assert.equal(round_(gap_("#000000", "#ffffff")), 100, "黒と白は L だけが 0 から 1 へ動く");
});

test("style.css の区分の色が、決めた 9 色（明・暗）とちょうど同じ", () => {
  for (const [name, block, wanted, other] of [
    ["明るい配色", LIGHT_BLOCK_, PALETTE_LIGHT_, PALETTE_OTHER_.light],
    ["暗い配色", DARK_BLOCK_, PALETTE_DARK_, PALETTE_OTHER_.dark],
  ]) {
    wanted.forEach((hex, index) => {
      assert.equal(series_(block, index + 1), hex, name + " の --db-series-" + (index + 1));
    });
    assert.equal(series_(block, 0), other, name + " の「その他」の灰");
    assert.equal(block.match(/--db-series-\d:/g).length, 9, name + " の区分の色は 9 つ（0〜8）");
    assert.equal(/--db-series-9\s*:/.test(block), false, name + ": 9 個目の色は作らない");
  }
});

test("OS に従う暗い配色も、指定したときと同じ 9 色を配る", () => {
  const auto = block_('.db[data-db-theme="auto"]');
  for (let index = 0; index <= 8; index += 1) {
    assert.equal(series_(auto, index), series_(DARK_BLOCK_, index), "--db-series-" + index);
  }
});

test("並びで隣り合う色は、明でも暗でも十分に離れている", () => {
  for (const [name, palette] of [
    ["明るい配色", PALETTE_LIGHT_],
    ["暗い配色", PALETTE_DARK_],
  ]) {
    for (let index = 1; index < palette.length; index += 1) {
      const distance = gap_(palette[index - 1], palette[index]);
      assert.ok(
        distance >= PALETTE_MIN_GAP_,
        name + " の " + index + " 番目と " + (index + 1) + " 番目（" + palette[index - 1] + " / " + palette[index] + "）が " + round_(distance)
      );
    }
  }
});

test("「その他」の灰は、1 番目の色（いちばんよく出る色）から十分に離れている", () => {
  for (const [name, palette, other] of [
    ["明るい配色", PALETTE_LIGHT_, PALETTE_OTHER_.light],
    ["暗い配色", PALETTE_DARK_, PALETTE_OTHER_.dark],
  ]) {
    const distance = gap_(palette[0], other);
    assert.ok(distance >= PALETTE_MIN_GAP_, name + ": " + palette[0] + " と灰 " + other + " が " + round_(distance));
  }
});

test("区分の色を配る class は、0〜8 の 9 つだけ", () => {
  const classes = CSS.match(/\.db \.db-s\d \{/g) || [];
  assert.equal(classes.length, 9);
  for (let index = 0; index <= 8; index += 1) {
    assert.ok(CSS.includes(".db .db-s" + index + " { color: var(--db-series-" + index + "); }"), "db-s" + index);
  }
});
