import { test } from "node:test";
import assert from "node:assert/strict";
import { LANGS, MESSAGES, t } from "../src/core/i18n.js";

test("LANGS は ja と en", () => {
  assert.deepEqual(LANGS, ["ja", "en"]);
});

test("ja と en の key の集合が同じ", () => {
  const jaKeys = Object.keys(MESSAGES.ja).sort();
  const enKeys = Object.keys(MESSAGES.en).sort();
  assert.deepEqual(jaKeys, enKeys);
  assert.ok(jaKeys.length > 0, "key が 1 つも無い");
});

test("t: 期間の名前（8 つ）", () => {
  assert.equal(t("ja", "filter.period.thisMonth"), "今月");
  assert.equal(t("ja", "filter.period.lastMonth"), "先月");
  assert.equal(t("ja", "filter.period.last7"), "直近 7 日");
  assert.equal(t("ja", "filter.period.last30"), "直近 30 日");
  assert.equal(t("ja", "filter.period.last90"), "直近 90 日");
  assert.equal(t("ja", "filter.period.thisYear"), "今年");
  assert.equal(t("ja", "filter.period.all"), "全期間");
  assert.equal(t("ja", "filter.period.custom"), "期間を指定");
  assert.equal(t("en", "filter.period.thisMonth"), "This month");
  assert.equal(t("en", "filter.period.all"), "All time");
});

test("t: 開始日・終了日・すべて", () => {
  assert.equal(t("ja", "filter.from"), "開始日");
  assert.equal(t("ja", "filter.to"), "終了日");
  assert.equal(t("ja", "filter.allValues"), "すべて");
  assert.equal(t("en", "filter.from"), "Start date");
  assert.equal(t("en", "filter.to"), "End date");
});

test("t: 絞り込みの行の札（期間・戻す）", () => {
  assert.equal(t("ja", "filter.period"), "期間");
  assert.equal(t("ja", "filter.reset"), "絞り込みを戻す");
  assert.equal(t("en", "filter.period"), "Period");
  assert.equal(t("en", "filter.reset"), "Reset filters");
});

test("t: 設定の誤りの数を添えた文", () => {
  assert.equal(t("ja", "state.configIssues", { count: 2 }), "設定をご確認ください（2 件）");
  assert.equal(t("en", "state.configIssues", { count: 2 }), "Check the settings (2 issues)");
});

test("t: 合計", () => {
  assert.equal(t("ja", "label.total"), "合計");
  assert.equal(t("en", "label.total"), "Total");
});

test("t: 表で見る・グラフで見る・CSV をダウンロード", () => {
  assert.equal(t("ja", "widget.showTable"), "表で見る");
  assert.equal(t("ja", "widget.showChart"), "グラフで見る");
  assert.equal(t("ja", "action.downloadCsv"), "CSV をダウンロード");
  assert.equal(t("en", "widget.showTable"), "View as table");
  assert.equal(t("en", "widget.showChart"), "View as chart");
  assert.equal(t("en", "action.downloadCsv"), "Download CSV");
});

test("t: 状態の文（データがありません・設定をご確認ください・読み込んでいます・ただいま表示できません・20,000 行）", () => {
  assert.equal(t("ja", "state.noData"), "データがありません");
  assert.equal(t("ja", "state.checkConfig"), "設定をご確認ください");
  assert.equal(t("en", "state.checkConfig"), "Check the settings");
  assert.equal(t("ja", "state.loading"), "読み込んでいます…");
  assert.equal(t("ja", "state.unavailable"), "ただいま表示できません。しばらくしてからお試しください。");
  assert.equal(t("ja", "state.truncated"), "20,000 行までを表示しています");
  assert.equal(t("en", "state.noData"), "No data for this period");
  assert.equal(t("en", "state.unavailable"), "This dashboard is unavailable right now. Please try again later.");
  assert.equal(t("en", "state.truncated"), "Showing the first 20,000 rows");
});

test("t: {count} を差し込む", () => {
  assert.equal(t("ja", "state.skippedValues", { count: 3 }), "数として読めない値を 3 件のぞきました");
  assert.equal(t("en", "state.skippedValues", { count: 3 }), "Skipped 3 values that are not numbers");
});

test("t: vars が無い・値が無い key はプレースホルダをそのまま残す", () => {
  assert.equal(t("ja", "state.skippedValues"), "数として読めない値を {count} 件のぞきました");
});

test("t: その他・達成", () => {
  assert.equal(t("ja", "label.other"), "その他");
  assert.equal(t("ja", "label.goalReached"), "達成");
  assert.equal(t("en", "label.other"), "Other");
  assert.equal(t("en", "label.goalReached"), "Goal reached");
});

test("t: 見つからない列の文（データの名前と列の名前を差し込む）", () => {
  assert.equal(
    t("ja", "error.columnMissing", { dataset: "sales", column: "金額" }),
    "データ「sales」に列「金額」が見つかりません。設定をご確認ください。"
  );
  assert.equal(
    t("en", "error.columnMissing", { dataset: "sales", column: "Amount" }),
    'The column "Amount" was not found in the dataset "sales". Please check the settings.'
  );
});

test("t: 目標が 0 以下のときの文は、ja と en のどちらも理由と直し方を書く", () => {
  assert.equal(t("ja", "error.goalNotPositive"), "目標が 0 以下のため、達成率を計算できません。目標のデータをご確認ください。");
  assert.equal(t("en", "error.goalNotPositive"), "Progress cannot be calculated because the goal is zero or less. Please check the goal data.");
});

test("t: 前の期間の名前（6 つ）", () => {
  assert.equal(t("ja", "compare.lastMonth"), "先月比");
  assert.equal(t("ja", "compare.last7"), "前の 7 日比");
  assert.equal(t("ja", "compare.last30"), "前の 30 日比");
  assert.equal(t("ja", "compare.last90"), "前の 90 日比");
  assert.equal(t("ja", "compare.thisYear"), "昨年比");
  assert.equal(t("ja", "compare.generic"), "前の期間比");
});

test("t: 集計の名前（6 つ）", () => {
  assert.equal(t("ja", "agg.sum"), "合計");
  assert.equal(t("ja", "agg.avg"), "平均");
  assert.equal(t("ja", "agg.count"), "件数");
  assert.equal(t("ja", "agg.distinct"), "種類の数");
  assert.equal(t("ja", "agg.min"), "最小");
  assert.equal(t("ja", "agg.max"), "最大");
});

test("t: 画面の外がわ（見本のページ）の文は、ここには置かない", () => {
  // 見本のページの題と添え書きは、ダッシュボードの中ではなくページ自身の持ちもの。
  // 画面の中の文だけをここに集める（同じ文を 2 か所に置かないため）
  assert.equal(t("ja", "demo.title"), "demo.title");
  assert.equal(t("en", "demo.note"), "demo.note");
});

test("t: 知らない lang は ja にする", () => {
  assert.equal(t("fr", "label.other"), "その他");
  assert.equal(t(undefined, "label.other"), "その他");
});

test("t: 無い key は key をそのまま返す", () => {
  assert.equal(t("ja", "no.such.key"), "no.such.key");
});
