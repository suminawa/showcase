import { test } from "node:test";
import assert from "node:assert/strict";
import {
  pad2,
  isDateKey,
  toDateKey,
  addDays,
  diffDays,
  weekdayOf,
  weekStartOf,
  monthOf,
  quarterOf,
  yearOf,
  bucketKey,
  bucketStart,
  bucketsBetween,
  autoBucket,
  periodRange,
  previousRange,
  bucketLabel,
} from "../src/core/dates.js";

test("pad2: 2 桁に揃える", () => {
  assert.equal(pad2(3), "03");
  assert.equal(pad2(12), "12");
});

test("toDateKey: 区切りちがいの形をすべて読む", () => {
  assert.equal(toDateKey("2026-09-19"), "2026-09-19");
  assert.equal(toDateKey("2026/9/19"), "2026-09-19");
  assert.equal(toDateKey("2026.9.19"), "2026-09-19");
  assert.equal(toDateKey("2026年9月19日"), "2026-09-19");
  assert.equal(toDateKey("２０２６－０９－１９"), "2026-09-19", "全角も半角にしてから読む");
});

test("toDateKey: ISO の日時は先頭 10 字を読む", () => {
  assert.equal(toDateKey("2026-09-19T10:00:00Z"), "2026-09-19");
  assert.equal(toDateKey("2026-09-19 10:00:00"), "2026-09-19");
});

test("toDateKey: Date オブジェクトは getFullYear/getMonth/getDate（ローカル）で読む", () => {
  const d = new Date(2026, 8, 19); // 月は 0 始まり。ローカル時刻で 2026-09-19
  assert.equal(toDateKey(d), "2026-09-19");
});

test("toDateKey: 月が先の形・実在しない日・読めない字は空文字", () => {
  assert.equal(toDateKey("9/19/2026"), "", "月が先の形は読まない");
  assert.equal(toDateKey("2026-02-30"), "", "実在しない日");
  assert.equal(toDateKey("2026-13-01"), "", "13 月は無い");
  assert.equal(toDateKey(""), "");
  assert.equal(toDateKey(null), "");
  assert.equal(toDateKey(undefined), "");
  assert.equal(toDateKey("きょう"), "");
});

test("toDateKey: うるう年の 2/29 は読み、平年の 2/29 は空文字", () => {
  assert.equal(toDateKey("2028-02-29"), "2028-02-29", "2028 年はうるう年");
  assert.equal(toDateKey("2027-02-29"), "", "2027 年はうるう年でない");
});

test("isDateKey: 実在する YYYY-MM-DD だけ true", () => {
  assert.equal(isDateKey("2026-09-19"), true);
  assert.equal(isDateKey("2026-02-30"), false);
  assert.equal(isDateKey("2026/09/19"), false, "区切りが - でない形は false");
  assert.equal(isDateKey(20260919), false);
});

test("addDays: 月またぎ・年またぎ・うるう日をまたぐ", () => {
  assert.equal(addDays("2026-08-31", 1), "2026-09-01", "月またぎ");
  assert.equal(addDays("2026-12-31", 1), "2027-01-01", "年またぎ");
  assert.equal(addDays("2026-02-28", 1), "2026-03-01", "2026 年はうるう年でない");
  assert.equal(addDays("2028-02-28", 1), "2028-02-29", "2028 年はうるう年");
  assert.equal(addDays("2026-09-01", -1), "2026-08-31", "負の数は前へ");
});

test("diffDays: 後の日付との日数の差", () => {
  assert.equal(diffDays("2026-09-10", "2026-09-19"), 9);
  assert.equal(diffDays("2026-09-19", "2026-09-10"), -9);
  assert.equal(diffDays("2026-09-19", "2026-09-19"), 0);
});

test("weekdayOf: 0（日）〜6（土）", () => {
  assert.equal(weekdayOf("2026-09-20"), 0, "日曜");
  assert.equal(weekdayOf("2026-09-19"), 6, "土曜");
});

test("weekStartOf: その週の月曜日（週は月曜はじまり）", () => {
  assert.equal(weekStartOf("2026-09-20"), "2026-09-14", "日曜は前の月曜まで戻る");
  assert.equal(weekStartOf("2026-09-14"), "2026-09-14", "月曜自身はそのまま");
});

test("monthOf・quarterOf・yearOf", () => {
  assert.equal(monthOf("2026-09-19"), "2026-09");
  assert.equal(quarterOf("2026-09-19"), "2026-Q3");
  assert.equal(quarterOf("2026-01-01"), "2026-Q1");
  assert.equal(quarterOf("2026-12-31"), "2026-Q4");
  assert.equal(yearOf("2026-09-19"), "2026");
});

test("bucketKey・bucketStart: 刻みキーへの変換とその逆", () => {
  assert.equal(bucketKey("2026-09-19", "day"), "2026-09-19");
  assert.equal(bucketKey("2026-09-19", "week"), "2026-09-14");
  assert.equal(bucketKey("2026-09-19", "month"), "2026-09");
  assert.equal(bucketKey("2026-09-19", "quarter"), "2026-Q3");
  assert.equal(bucketKey("2026-09-19", "year"), "2026");

  assert.equal(bucketStart("2026-09-14", "week"), "2026-09-14");
  assert.equal(bucketStart("2026-09", "month"), "2026-09-01");
  assert.equal(bucketStart("2026-Q3", "quarter"), "2026-07-01");
  assert.equal(bucketStart("2026", "year"), "2026-01-01");
});

test("bucketsBetween: 週の刻み（端を含む）", () => {
  assert.deepEqual(bucketsBetween("2026-09-01", "2026-09-20", "week"), ["2026-08-31", "2026-09-07", "2026-09-14"]);
});

test("bucketsBetween: 月の刻み（端を含む）", () => {
  assert.deepEqual(bucketsBetween("2026-08-15", "2026-10-05", "month"), ["2026-08", "2026-09", "2026-10"]);
});

test("autoBucket: 期間の長さから刻みを選ぶ", () => {
  assert.equal(autoBucket("2026-01-01", "2026-02-01"), "day", "31 日以下");
  assert.equal(autoBucket("2026-01-01", "2026-02-02"), "week", "32 日");
  assert.equal(autoBucket("2026-01-01", "2026-07-01"), "week", "183 日以下");
  assert.equal(autoBucket("2026-01-01", "2026-07-05"), "month", "184 日を超える");
});

test("periodRange: よく使うプリセット（today 起点）", () => {
  const today = "2026-09-19";
  assert.deepEqual(periodRange("thisMonth", today), { from: "2026-09-01", to: "2026-09-19" });
  assert.deepEqual(periodRange("lastMonth", today), { from: "2026-08-01", to: "2026-08-31" });
  assert.deepEqual(periodRange("last7", today), { from: addDays(today, -6), to: today });
  assert.deepEqual(periodRange("last30", today), { from: addDays(today, -29), to: today });
  assert.deepEqual(periodRange("last90", today), { from: addDays(today, -89), to: today });
  assert.deepEqual(periodRange("thisYear", today), { from: "2026-01-01", to: today });
  assert.deepEqual(periodRange("all", today), { from: "", to: "" });
  assert.deepEqual(periodRange("custom", today), { from: "", to: "" }, "custom は呼び出し側が from/to を決める");
});

test("previousRange (a): from が月の1日で to が同じ月の末日 → 前の月まるごと", () => {
  assert.deepEqual(previousRange({ from: "2026-09-01", to: "2026-09-30" }), { from: "2026-08-01", to: "2026-08-31" });
  assert.deepEqual(previousRange({ from: "2026-03-01", to: "2026-03-31" }), { from: "2026-02-01", to: "2026-02-28" });
});

test("previousRange (b): from が月の1日で to が同じ月の途中 → 前の月の同じ日まで", () => {
  assert.deepEqual(previousRange({ from: "2026-09-01", to: "2026-09-19" }), { from: "2026-08-01", to: "2026-08-19" });
});

test("previousRange (c): from が1/1で to が同じ年 → 前の年の同じ月日まで", () => {
  assert.deepEqual(previousRange({ from: "2026-01-01", to: "2026-09-19" }), { from: "2025-01-01", to: "2025-09-19" });
});

test("previousRange (d): それ以外 → 同じ日数の直前の範囲", () => {
  assert.deepEqual(previousRange({ from: "2026-09-10", to: "2026-09-19" }), { from: "2026-08-31", to: "2026-09-09" });
});

test("previousRange (e): all（空）は比べない", () => {
  assert.deepEqual(previousRange({ from: "", to: "" }), { from: "", to: "" });
});

test("bucketLabel: 画面に出す短いラベル（ja / en）", () => {
  assert.equal(bucketLabel("2026-09-19", "day", "ja"), "9/19");
  assert.equal(bucketLabel("2026-09-19", "day", "en"), "Sep 19");
  assert.equal(bucketLabel("2026-09-14", "week", "ja"), "9/14週");
  assert.equal(bucketLabel("2026-09-14", "week", "en"), "Wk of Sep 14");
  assert.equal(bucketLabel("2026-09", "month", "ja"), "2026年9月");
  assert.equal(bucketLabel("2026-09", "month", "en"), "Sep 2026");
  assert.equal(bucketLabel("2026-Q3", "quarter", "ja"), "2026 Q3");
  assert.equal(bucketLabel("2026-Q3", "quarter", "en"), "2026 Q3");
  assert.equal(bucketLabel("2026", "year", "ja"), "2026年");
  assert.equal(bucketLabel("2026", "year", "en"), "2026");
});
