import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";
import { MANIFEST, VERSION } from "../scripts/build.mjs";
import { sampleSheets } from "../src/core/samples.js";

// dist/ は npm test の前（pretest の npm run build）に作られる
const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const CODE_GS_ = readFileSync(join(root, "dist", "Code.gs"), "utf8");
const APP_HTML_ = readFileSync(join(root, "dist", "App.html"), "utf8");
const MANIFEST_JSON_ = JSON.parse(readFileSync(join(root, "dist", "appsscript.json"), "utf8"));

/** GAS から呼ばれる入口。1 つでも束ね漏れがあれば、vm の中で ReferenceError になる */
const ENTRY_NAMES_ = ["doGet", "onOpen", "api_bootstrap", "menu_init", "menu_samples", "menu_check", "menu_url"];

const TODAY_ = "2026-09-30";

// ---- 偽の GAS（vm の中に置く最小限のもの） ----------------------------------

function fakeSheet_(name, values) {
  const rows = values.map((row) => row.slice());
  const sheet = {
    rows,
    cleared: 0,
    getName: () => name,
    getLastRow: () => rows.length,
    getLastColumn: () => rows.reduce((most, row) => Math.max(most, row.length), 0),
    getDataRange: () => ({ getValues: () => (rows.length === 0 ? [[""]] : rows.map((row) => row.slice())) }),
    getRange: (r, c) => ({
      setValues: (grid) => {
        for (let i = 0; i < grid.length; i += 1) {
          const at = r - 1 + i;
          while (rows.length <= at) rows.push([]);
          for (let j = 0; j < grid[i].length; j += 1) rows[at][c - 1 + j] = grid[i][j];
        }
      },
    }),
    // clear() は書式まで消すので実装しない。書き込みは clearContents() だけを使うはず
    clearContents: () => {
      sheet.cleared += 1;
      rows.length = 0;
    },
    setFrozenRows: () => {},
  };
  return sheet;
}

/** 本物の Utilities.formatDate と同じく、指定した時間帯で実際に書式づける（Intl 任せ） */
function fakeFormatDate_(date, timeZone, format) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).formatToParts(date);
  const get = (type) => parts.find((p) => p.type === type).value;
  if (format === "yyyy-MM-dd") return get("year") + "-" + get("month") + "-" + get("day");
  if (format === "yyyy") return get("year");
  if (format === "HH:mm") return get("hour") + ":" + get("minute");
  throw new Error("fakeFormatDate_: 知らない書式です: " + format);
}

function createSandbox_(options) {
  const opts = options || {};
  const sheets = new Map();
  const seed = opts.sheets || {};
  for (const name of Object.keys(seed)) sheets.set(name, fakeSheet_(name, seed[name]));

  const trace = { alerts: [], prompts: [], menu: [], errors: [], html: [] };
  const menu = { addItem: (label, fn) => (trace.menu.push([label, fn]), menu), addSeparator: () => menu, addToUi: () => {} };
  const ui = {
    Button: { YES: "YES", NO: "NO", OK: "OK" },
    ButtonSet: { YES_NO: "YES_NO", OK: "OK" },
    alert: (a, b, c) => {
      if (c === undefined) {
        trace.alerts.push(String(a));
        return "OK";
      }
      trace.prompts.push(String(b));
      return opts.answer === undefined ? "NO" : opts.answer;
    },
    createMenu: (title) => (trace.menu.push(["menu", title]), menu),
  };
  const book = {
    getSheetByName: (name) => (sheets.has(name) ? sheets.get(name) : null),
    insertSheet: (name) => {
      if (sheets.has(name)) throw new Error("すでにあります: " + name);
      const made = fakeSheet_(name, []);
      sheets.set(name, made);
      return made;
    },
    // スプレッドシート本体の時間帯。スクリプトの時間帯（Asia/Tokyo）とわざと違えてある
    getSpreadsheetTimeZone: () => (opts.spreadsheetTimeZone === undefined ? "America/Los_Angeles" : opts.spreadsheetTimeZone),
  };

  return {
    sheets,
    trace,
    globals: {
      console: { error: (error) => trace.errors.push(error), log: () => {}, warn: () => {} },
      SpreadsheetApp: { getActiveSpreadsheet: () => book, getUi: () => ui },
      HtmlService: {
        createHtmlOutputFromFile: (file) => {
          const out = { file, title: "", meta: [] };
          out.setTitle = (title) => ((out.title = title), out);
          out.addMetaTag = (key, value) => (out.meta.push([key, value]), out);
          trace.html.push(out);
          return out;
        },
      },
      ScriptApp: { getService: () => ({ getUrl: () => (opts.appUrl === undefined ? "" : opts.appUrl) }) },
      Session: { getScriptTimeZone: () => "Asia/Tokyo" },
      Utilities: { formatDate: fakeFormatDate_ },
    },
  };
}

/**
 * vm の中で作られたものは、この場のオブジェクトと素性が違って deepEqual が通らない。
 * JSON を通して、この場の素のオブジェクトにする
 */
function plain_(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

/** dist/Code.gs を偽の GAS の上で動かし、入口の関数を取り出す */
function loadBundle_(options) {
  const made = createSandbox_(options);
  const context = createContext(made.globals);
  const exports = ENTRY_NAMES_.map((name) => name + ": typeof " + name + " === 'function' ? " + name + " : null").join(", ");
  runInContext(CODE_GS_ + "\nglobalThis.__entry = { " + exports + " };\n", context);

  const entry = {};
  for (const name of ENTRY_NAMES_) {
    const fn = made.globals.__entry[name];
    entry[name] = fn === null ? null : (...args) => fn.apply(null, args);
  }
  return { entry, sheets: made.sheets, trace: made.trace };
}

function sampleSeed_() {
  const sample = sampleSheets(TODAY_, "ja");
  return { 設定: sample.settings, 定義: sample.definitions, 売上: sample.data["売上"], 目標: sample.data["目標"] };
}

/** App.html の中の、束ねた 1 本を差し込んである <script>（いちばん長いもの）を取り出す */
function inlineScriptOf_(html) {
  const found = html.match(/<script>([\s\S]*?)<\/script>/g) || [];
  let longest = "";
  for (const block of found) {
    const body = block.slice("<script>".length, -"</script>".length);
    if (body.length > longest.length) longest = body;
  }
  return longest;
}

// ---- dist/Code.gs ----------------------------------------------------------

test("Code.gs: import / export が残らず、画面の道具にも触れていない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(CODE_GS_), false);
  assert.equal(/\bdocument\b/.test(CODE_GS_), false, "サーバー側が画面の道具に触れてはならない");
  assert.equal(/\bwindow\b/.test(CODE_GS_), false, "サーバー側が画面の道具に触れてはならない");
});

test("Code.gs: GAS から呼ぶ入口が 7 つとも出そろっている", () => {
  const { entry } = loadBundle_({ sheets: sampleSeed_() });
  for (const name of ENTRY_NAMES_) assert.equal(typeof entry[name], "function", name + " が Code.gs にない");
});

test("Code.gs: 束ねた 1 本のまま api_bootstrap が通る（束ね漏れがあれば ReferenceError）", () => {
  const { entry } = loadBundle_({ sheets: sampleSeed_() });
  const result = plain_(entry.api_bootstrap());

  assert.equal(result.ok, true);
  assert.deepEqual(result.missing, []);
  assert.deepEqual(result.truncated, []);
  assert.deepEqual(Object.keys(result.datasets).sort(), ["売上", "目標"]);
  assert.equal(result.config.widgets.length, 10);
});

test("Code.gs: doGet が App.html を題名つきで返す", () => {
  const { entry } = loadBundle_({ sheets: sampleSeed_() });
  const out = entry.doGet();
  assert.equal(out.file, "App");
  assert.equal(out.title, "しおかぜ珈琲店 売上ダッシュボード");
  assert.deepEqual(plain_(out.meta), [["viewport", "width=device-width, initial-scale=1"]]);
});

test("Code.gs: メニューの 4 つと onOpen が、束ねた 1 本のまま動く", () => {
  const empty = loadBundle_({ sheets: {} });
  empty.entry.onOpen();
  assert.deepEqual(
    empty.trace.menu.slice(1).map((item) => item[1]),
    ["menu_init", "menu_samples", "menu_check", "menu_url"]
  );

  empty.entry.menu_init();
  assert.ok(empty.sheets.has("設定") && empty.sheets.has("定義"));

  empty.entry.menu_url();
  assert.match(empty.trace.alerts[empty.trace.alerts.length - 1], /まだ公開されていません/);

  const filled = loadBundle_({ sheets: {}, answer: "YES" });
  filled.entry.menu_samples();
  assert.deepEqual(Array.from(filled.sheets.keys()).sort(), ["売上", "定義", "目標", "設定"].sort());

  filled.entry.menu_check();
  assert.equal(filled.trace.alerts[filled.trace.alerts.length - 1], "設定に誤りはありません。");
  assert.deepEqual(filled.trace.errors, [], "実行ログに思いがけない失敗を残していない");
});

test("Code.gs: menu_check は壊れた設定を一覧にし、menu_url は公開済みなら URL を出し、menu_samples は既存データで YES/NO どちらも正しく動く（束ねた 1 本のまま）", () => {
  // 壊れた設定（定義に書いたデータのシートが無い）
  const broken = loadBundle_({
    sheets: { 設定: [["項目", "値"], ["題名", "テスト"]], 定義: [["種類", "題", "データ", "値の列"], ["数字", "売上", "見つからないシート", "金額"]] },
  });
  broken.entry.menu_check();
  const brokenText = broken.trace.alerts[broken.trace.alerts.length - 1];
  assert.match(brokenText, /^次の点をご確認ください。/);
  assert.match(brokenText, /データのシート「見つからないシート」が見つかりません/);

  // 公開済みなら URL を出す
  const deployed = loadBundle_({ sheets: {}, appUrl: "https://script.google.com/macros/s/AAA/exec" });
  deployed.entry.menu_url();
  assert.match(deployed.trace.alerts[deployed.trace.alerts.length - 1], /https:\/\/script\.google\.com\/macros\/s\/AAA\/exec/);

  // 既存データに menu_samples: いいえ なら書き換えない
  const existingNo = loadBundle_({ sheets: sampleSeed_(), answer: "NO" });
  const before = existingNo.sheets.get("売上").rows.length;
  existingNo.entry.menu_samples();
  assert.equal(existingNo.sheets.get("売上").rows.length, before, "いいえのときは書き換えないはず");
  assert.match(existingNo.trace.alerts[existingNo.trace.alerts.length - 1], /そのままにしました/);

  // 既存データに menu_samples: はい なら書き換える
  const existingYes = loadBundle_({ sheets: sampleSeed_(), answer: "YES" });
  existingYes.entry.menu_samples();
  assert.match(existingYes.trace.alerts[existingYes.trace.alerts.length - 1], /見本を入れました/);
  assert.ok(existingYes.sheets.get("売上").rows.length > 100, "書き換えた見本の行が入っているはず");
});

// ---- dist/App.html ---------------------------------------------------------

test("App.html: 地の色も画面の JS も差し込み済みで、外へ取りに行かない", () => {
  assert.ok(APP_HTML_.startsWith("<!doctype html>"));
  assert.ok(APP_HTML_.includes('<meta charset="utf-8" />'));
  assert.ok(APP_HTML_.includes('<base target="_top" />'));
  assert.ok(APP_HTML_.includes("--db-series-8"), "地の色（style.css）を差し込むはず");
  assert.ok(APP_HTML_.includes('mountDashboard(root, { source: "gas", hash: false });'), "束ねた 1 本の中で、自分で組み立てまで済ませるはず");
  assert.ok(APP_HTML_.includes("JavaScript を有効にしてください"), "JavaScript が切ってあるときの案内を出すはず");

  assert.equal(APP_HTML_.includes("<script src="), false, "外から読み込むものがあってはならない");
  assert.equal(APP_HTML_.includes("<link "), false, "外から読み込むものがあってはならない");
  assert.equal(APP_HTML_.includes("/*__CSS__*/"), false);
  assert.equal(APP_HTML_.includes("/*__JS__*/"), false);
});

test("App.html: 置き場所は id だけ（描く側が .db の包みを作るので、二重にしない）", () => {
  const markup = APP_HTML_.slice(0, APP_HTML_.indexOf("<script"));
  assert.ok(markup.includes('<div id="app"></div>'));
  assert.equal(markup.includes('class="db"'), false, "置き場所に .db を付けると包みが二重になる");
});

test("App.html: 差し込んだ 1 本は 1 つの IIFE で包まれ、動かしても window.Dashboard 以外の名前を漏らさない", async () => {
  const script = inlineScriptOf_(APP_HTML_);
  assert.ok(script.length > 10000, "束ねた 1 本が取り出せない");

  // 束ねた 1 本を包む IIFE が、行の頭（空白だけを挟んで）にちょうど 1 つだけ
  // （中の道具の呼び出しに紛れた同じ形の並び "…(function () {" は、行の途中にあるので数えない）
  const topLevelIifeCount = (script.match(/^[ \t]*\(function\s*\(\)\s*\{/gm) || []).length;
  assert.equal(topLevelIifeCount, 1, "束ねた 1 本を包む IIFE がちょうど 1 つのはず");

  const calls = [];
  const before = {
    window: {},
    document: { getElementById: (id) => (id === "app" ? { id } : null) },
    console: { log() {}, error() {}, warn() {} },
    google: {
      script: {
        run: {
          withSuccessHandler() {
            return this;
          },
          withFailureHandler() {
            return this;
          },
          api_bootstrap() {
            calls.push("api_bootstrap"); // 返事は返さない。読み込みが始まったことだけを確かめれば十分
          },
        },
      },
    },
  };
  createContext(before);
  const names = new Set(Object.getOwnPropertyNames(before));
  runInContext(script, before);
  // 読み込みは Promise を挟むので、マイクロタスクが片づくまで待ってから確かめる
  await new Promise((resolve) => setTimeout(resolve, 0));

  const leaked = Object.getOwnPropertyNames(before).filter((name) => !names.has(name));
  assert.deepEqual(leaked, [], "束ねた中の名前が漏れている: " + leaked.join(" / "));
  assert.deepEqual(Object.keys(before.window), ["Dashboard"], "window に足すのは Dashboard だけ");
  assert.deepEqual(calls, ["api_bootstrap"], "置き場所を見つけて、自分で組み立てて読み込みまで始めるはず");
});

// ---- dist/appsscript.json --------------------------------------------------

test("appsscript.json: 時間帯・V8・ウェブアプリの公開の仕方・2 つの権限をそのまま持つ", () => {
  assert.deepEqual(MANIFEST_JSON_, MANIFEST);
  assert.deepEqual(MANIFEST_JSON_, {
    timeZone: "Asia/Tokyo",
    exceptionLogging: "STACKDRIVER",
    runtimeVersion: "V8",
    webapp: { access: "ANYONE", executeAs: "USER_ACCESSING" },
    oauthScopes: ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/script.container.ui"],
  });
});

// ---- demo/（見本のページ） --------------------------------------------------

test("demo/app.js は配布物と同じ包み方で、ページに出るのは window.Dashboard だけ", () => {
  const code = readFileSync(join(root, "demo", "app.js"), "utf8");
  assert.equal(/^\s*(import|export)\s/m.test(code), false, "import / export が残っている");

  const before = { window: {}, document: undefined, console };
  createContext(before);
  const names = new Set(Object.getOwnPropertyNames(before));
  runInContext(code, before);

  const leaked = Object.getOwnPropertyNames(before).filter((name) => !names.has(name));
  assert.deepEqual(leaked, [], "束ねた中の名前がページに出ている: " + leaked.join(" / "));
  assert.deepEqual(Object.keys(before.window), ["Dashboard"], "window に足すのは Dashboard だけ");
  assert.equal(typeof before.window.Dashboard.mount, "function");
  assert.equal(before.window.Dashboard.version, VERSION);

  // 試すときだけ使う差し込み口も、ページからは触れない
  assert.equal(typeof before.setEnvironmentForTests, "undefined");
  assert.equal(typeof before.window.setEnvironmentForTests, "undefined");
});

test("demo/index.html は、束ねた中の名前に頼らない", () => {
  const html = readFileSync(join(root, "demo", "index.html"), "utf8");
  const script = html.slice(html.lastIndexOf("<script>"), html.lastIndexOf("</script>"));

  assert.ok(script.includes("window.Dashboard.mount("), "組み立ては window.Dashboard から呼ぶ");
  assert.equal(/\bt\s*\(/.test(script), false, "束ねた中の文の道具を、ページから呼んではならない");
  assert.equal(script.includes("mountDashboard("), false, "束ねた中の名前を直に呼んではならない");

  // ページの文は、ページ自身が ja と en の両方を持つ
  assert.ok(script.includes("しおかぜ珈琲店"));
  assert.ok(script.includes("Shiokaze Coffee"));
});
