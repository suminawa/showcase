import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const CSS = readFileSync(fileURLToPath(new URL("../src/ui/style.css", import.meta.url)), "utf8");

/** 明るい配色（.db の中）と暗い配色（.db[data-db-theme="dark"] の中）の色を読み分ける */
function block_(selector) {
  const at = CSS.indexOf(selector + " {");
  assert.notEqual(at, -1, selector + " が見つからない");
  return CSS.slice(at, CSS.indexOf("\n}", at));
}

function token_(block, name) {
  const found = block.match(new RegExp("--" + name + ":\\s*(#[0-9a-fA-F]{6})"));
  assert.notEqual(found, null, name + " の色が見つからない");
  return found[1];
}

function channel_(value) {
  const c = value / 255;
  return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

/** 色の明るさ（WCAG の相対輝度） */
function luminance_(hex) {
  const r = channel_(parseInt(hex.slice(1, 3), 16));
  const g = channel_(parseInt(hex.slice(3, 5), 16));
  const b = channel_(parseInt(hex.slice(5, 7), 16));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** 2 色の差（WCAG の contrast ratio）。小さな字は 4.5 以上ほしい */
function ratio_(a, b) {
  const la = luminance_(a);
  const lb = luminance_(b);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}

function round_(value) {
  return Math.round(value * 100) / 100;
}

const LIGHT = block_(".db");
const DARK = block_('.db[data-db-theme="dark"]');

test("contrast: 相対輝度と差の計算が、知られた値と合う", () => {
  assert.equal(round_(ratio_("#000000", "#ffffff")), 21);
  assert.equal(round_(ratio_("#ffffff", "#ffffff")), 1);
  assert.equal(round_(ratio_("#767676", "#ffffff")), 4.54);
});

test("style.css: 字の色は、明るい配色でも地に対して 4.5 以上の差がある", () => {
  const card = token_(LIGHT, "db-card");
  const surface = token_(LIGHT, "db-surface");
  for (const name of ["db-text", "db-text-2", "db-text-3"]) {
    const color = token_(LIGHT, name);
    assert.ok(ratio_(color, card) >= 4.5, name + " は札の地（" + card + "）に対して " + round_(ratio_(color, card)));
    assert.ok(ratio_(color, surface) >= 4.5, name + " は画面の地（" + surface + "）に対して " + round_(ratio_(color, surface)));
  }
});

test("style.css: 字の色は、暗い配色でも地に対して 4.5 以上の差がある", () => {
  const card = token_(DARK, "db-card");
  const surface = token_(DARK, "db-surface");
  for (const name of ["db-text", "db-text-2", "db-text-3"]) {
    const color = token_(DARK, name);
    assert.ok(ratio_(color, card) >= 4.5, name + " は札の地（" + card + "）に対して " + round_(ratio_(color, card)));
    assert.ok(ratio_(color, surface) >= 4.5, name + " は画面の地（" + surface + "）に対して " + round_(ratio_(color, surface)));
  }
});

test("style.css: 「達成」の札は、字と面のあいだに 4.5 以上の差がある", () => {
  for (const [theme, block] of [["明るい配色", LIGHT], ["暗い配色", DARK]]) {
    const background = token_(block, "db-good-strong");
    const text = token_(block, "db-good-strong-text");
    assert.ok(ratio_(text, background) >= 4.5, theme + "の達成の札は " + round_(ratio_(text, background)));
    assert.ok(ratio_(background, token_(block, "db-card")) >= 2.5, theme + "の達成の札は、札の地からも見分けられる");
  }
  assert.ok(CSS.includes("background: var(--db-good-strong)"), "達成の札は、字をのせる用の色を使う");
});

test("style.css: 暗い配色は、OS に従うときも指定のときも同じ色を配る", () => {
  const auto = block_('.db[data-db-theme="auto"]');
  for (const name of ["db-surface", "db-card", "db-text", "db-text-2", "db-text-3", "db-good-strong", "db-good-strong-text"]) {
    assert.equal(token_(auto, name), token_(DARK, name), name);
  }
});
