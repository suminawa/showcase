/**
 * 配布 zip の中身と、README に書いた決まりが本当のコードと合っているかを見張る。
 *
 * ここが緑なら、買い手の手元に届く zip は
 * （1）要るものがそろっていて、（2）入ってはいけないものが入っておらず、
 * （3）README の見本・表・手順が、実際に動くコードと同じ値を指している。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { createRelease, releaseFileList, releaseFolderName, RELEASE_GENERATED } from "../scripts/release.mjs";
import { DEFAULT_CONFIG, CONFIG_DEFINITION_COLUMNS_, parseConfig } from "../src/core/config.js";
import { MESSAGES } from "../src/core/i18n.js";
import { INTERNAL_WORDS, INTERNAL_PATHS, WORK_IN_PROGRESS_MARKS, hasRawControlChar, assertNoWords } from "./helpers/forbidden.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

const readmeJa = readFileSync(join(ROOT, "README.ja.md"), "utf8");
const readmeEn = readFileSync(join(ROOT, "README.en.md"), "utf8");
const configSource = readFileSync(join(ROOT, "src", "core", "config.js"), "utf8");
const modelSource = readFileSync(join(ROOT, "src", "core", "model.js"), "utf8");
const tableSource = readFileSync(join(ROOT, "src", "core", "table.js"), "utf8");
const mainSource = readFileSync(join(ROOT, "src", "ui", "main.js"), "utf8");
const styleSource = readFileSync(join(ROOT, "src", "ui", "style.css"), "utf8");
const gasMainSource = readFileSync(join(ROOT, "src", "gas", "gas_main.js"), "utf8");

// ---- コードから値を読み出す小道具 -------------------------------------------

/** `const NAME = ["a", "b"];` の中身を取り出す */
function constArray_(source, name) {
  const matched = source.match(new RegExp("const " + name + " = \\[([^\\]]*)\\]"));
  assert.ok(matched, name + " が見つかりません");
  return matched[1]
    .split(",")
    .map((cell) => cell.trim().replace(/^"|"$/g, ""))
    .filter((cell) => cell !== "");
}

/** `const NAME = 4;` の数を取り出す */
function constNumber_(source, name) {
  const matched = source.match(new RegExp("const " + name + " = (\\d+)"));
  assert.ok(matched, name + " が見つかりません");
  return Number(matched[1]);
}

/** `const NAME = { a: "x", b: "y" };` の鍵と値を取り出す */
function constObject_(source, name) {
  const matched = source.match(new RegExp("const " + name + " = \\{([^}]*)\\}"));
  assert.ok(matched, name + " が見つかりません");
  const entries = {};
  for (const part of matched[1].split(",")) {
    const pair = part.split(":");
    if (pair.length !== 2) continue;
    const key = pair[0].trim().replace(/^"|"$/g, "");
    const value = pair[1].trim().replace(/^"|"$/g, "");
    if (key !== "") entries[key] = value;
  }
  return entries;
}

const WIDGET_TYPES = constArray_(configSource, "CONFIG_WIDGET_TYPES_");
const AGGS = constArray_(configSource, "CONFIG_AGGS_");
const BUCKETS = constArray_(configSource, "CONFIG_BUCKETS_");
const FORMATS = constArray_(configSource, "CONFIG_FORMATS_");
const SIZES = constArray_(configSource, "CONFIG_SIZES_");
const PERIODS = constArray_(configSource, "CONFIG_PERIODS_");
const COMPARES = constArray_(configSource, "CONFIG_COMPARES_");
const GOOD_WHENS = constArray_(configSource, "CONFIG_GOOD_WHENS_");
const BAR_SORTS = constArray_(configSource, "CONFIG_BAR_SORTS_");
const TABLE_ORDERS = constArray_(configSource, "CONFIG_TABLE_ORDERS_");
const WIDE_ONLY_TYPES = constArray_(configSource, "CONFIG_WIDE_ONLY_TYPES_");
const SIZE_DEFAULTS = constObject_(configSource, "CONFIG_WIDGET_SIZE_DEFAULTS_");
const MAX_DIMENSIONS = constNumber_(configSource, "CONFIG_MAX_DIMENSIONS_");
const BAR_TOP_RANGE = constArray_(configSource, "CONFIG_BAR_TOP_RANGE_").map(Number);
const TABLE_TOP_RANGE = constArray_(configSource, "CONFIG_TABLE_TOP_RANGE_").map(Number);

/** README に出す 20,000 行の上限は、table.js が持つ 1 つの定数から読む */
function rowLimitFromTable_() {
  const matched = tableSource.match(/const TABLE_ROW_LIMIT_ = (\d+)/);
  assert.ok(matched, "TABLE_ROW_LIMIT_ が見つかりません");
  assert.ok(tableSource.includes("limitRows(rows, max = TABLE_ROW_LIMIT_)"), "limitRows の既定は TABLE_ROW_LIMIT_ のはず");
  return Number(matched[1]);
}

const LINE_SERIES_MAX = constNumber_(modelSource, "MODEL_LINE_SERIES_MAX_");
const BAR_SEGMENT_MAX = constNumber_(modelSource, "MODEL_BAR_SEGMENT_MAX_");
const COLOR_MAX = constNumber_(modelSource, "MODEL_COLOR_MAX_");

/** 数を「20,000」のように 3 桁区切りにする（README の書き方にそろえる） */
function grouped_(value) {
  return value.toLocaleString("en-US");
}

// ---- 1. zip に入るファイルの一覧 ---------------------------------------------

const RELEASE_LIST = releaseFileList(ROOT);

test("配布 zip には dist・demo・samples・src・test・scripts・templates と、4 つの文書と package.json が入る", () => {
  for (const required of [
    "dist/dashboard.js",
    "dist/dashboard.mjs",
    "dist/dashboard.css",
    "dist/Code.gs",
    "dist/App.html",
    "dist/appsscript.json",
    "demo/index.html",
    "demo/app.js",
    "demo/app.css",
    "samples/ja/sales.csv",
    "samples/ja/targets.csv",
    "samples/ja/dashboard.config.json",
    "samples/en/sales.csv",
    "samples/en/targets.csv",
    "samples/en/dashboard.config.json",
    "src/core/config.js",
    "src/ui/main.js",
    "src/ui/style.css",
    "src/gas/gas_main.js",
    "scripts/build.mjs",
    "scripts/release.mjs",
    "test/package-files.test.mjs",
    "test/helpers/forbidden.mjs",
    "README.ja.md",
    "README.en.md",
    "LICENSE.md",
    "CHANGELOG.md",
    "package.json",
  ]) {
    assert.ok(RELEASE_LIST.includes(required), required + " が zip に入っていません");
  }
});

test("配布 zip には Next.js テンプレの生成物（vendor・見本 CSV・設定）も入る", () => {
  for (const required of [
    "templates/nextjs/package.json",
    "templates/nextjs/README.md",
    "templates/nextjs/.env.example",
    "templates/nextjs/.gitignore",
    "templates/nextjs/dashboard.config.json",
    "templates/nextjs/app/page.tsx",
    "templates/nextjs/app/api/dashboard/data/route.ts",
    "templates/nextjs/lib/safe-fetch.mjs",
    "templates/nextjs/vendor/dashboard.mjs",
    "templates/nextjs/vendor/dashboard.css",
    "templates/nextjs/vendor/dashboard.d.mts",
    "templates/nextjs/public/sample/sales.csv",
    "templates/nextjs/public/sample/targets.csv",
  ]) {
    assert.ok(RELEASE_LIST.includes(required), required + " が zip に入っていません");
  }
});

test("配布 zip に入れてはいけないものが入っていない", () => {
  for (const relPath of RELEASE_LIST) {
    const parts = relPath.split("/");
    for (const part of parts) {
      assert.notEqual(part, "node_modules", "node_modules を入れない: " + relPath);
      assert.notEqual(part, ".next", ".next を入れない: " + relPath);
      assert.notEqual(part, ".git", ".git を入れない: " + relPath);
      assert.notEqual(part, ".DS_Store", ".DS_Store を入れない: " + relPath);
      assert.notEqual(part, "package-lock.json", "package-lock.json を入れない: " + relPath);
    }
    assert.equal(relPath.startsWith("release/"), false, "release/ を入れない: " + relPath);
    const name = parts[parts.length - 1];
    if (name.startsWith(".env")) assert.equal(name, ".env.example", ".env.example 以外の .env を入れない: " + relPath);
  }
});

test("npm run build の生成物がそろっている（そろわないと zip を作らない）", () => {
  for (const relPath of RELEASE_GENERATED) {
    assert.ok(RELEASE_LIST.includes(relPath), relPath + " がありません（npm run build が必要です）");
  }
});

test("一覧の並びは決まっている（同じ手元なら毎回まったく同じ zip の並びになる）", () => {
  assert.deepEqual(releaseFileList(ROOT), RELEASE_LIST, "呼ぶたびに同じ並びになること");
  const seen = new Set();
  for (const relPath of RELEASE_LIST) {
    assert.equal(seen.has(relPath), false, "同じ道すじが 2 回入っている: " + relPath);
    seen.add(relPath);
  }
  // フォルダごとに、中は名前順
  const bySection = new Map();
  for (const relPath of RELEASE_LIST) {
    const top = relPath.includes("/") ? relPath.split("/")[0] : "";
    if (!bySection.has(top)) bySection.set(top, []);
    bySection.get(top).push(relPath);
  }
  for (const [top, list] of bySection) {
    if (top === "") continue;
    assert.deepEqual(list, list.slice().sort(), top + " の中が名前順ではありません");
  }
});

// ---- 2. 実際に zip を作って、中身を読み直す ------------------------------------

/** zip・unzip が使えるか（使えない手元では、この 1 件だけを飛ばす） */
function hasZipTools_() {
  try {
    execFileSync("zip", ["-h"], { stdio: "ignore" });
    execFileSync("unzip", ["-h"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

test("実際に作った zip の中身が、一覧のとおり dashboard-kit-v… の 1 フォルダに収まっている", (t) => {
  if (!hasZipTools_()) {
    t.skip("zip / unzip がこの環境にありません");
    return;
  }
  const dir = mkdtempSync(join(tmpdir(), "dk-release-"));
  try {
    const made = createRelease(ROOT, join(dir, "check.zip"));
    assert.ok(made.bytes > 0, "zip の大きさが 0 です");
    assert.equal(made.files, RELEASE_LIST.length);

    const listed = execFileSync("unzip", ["-Z1", made.zipPath], { encoding: "utf8" })
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line !== "" && !line.endsWith("/"));

    const folder = releaseFolderName(ROOT);
    assert.equal(folder, "dashboard-kit-v" + JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")).version);
    assert.deepEqual(listed, RELEASE_LIST.map((relPath) => folder + "/" + relPath));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

// ---- 3. zip に入るどのファイルにも、内部の語・手元の道すじ・書きかけの印が無い ----

test("zip に入るどのファイルにも、内部の語・手元の道すじ・生の制御文字・書きかけの印が無い", () => {
  assert.ok(RELEASE_LIST.length > 60, "配布物が " + RELEASE_LIST.length + " ファイルしかありません");
  for (const relPath of RELEASE_LIST) {
    const text = readFileSync(join(ROOT, relPath), "utf8");
    assertNoWords(assert, text, INTERNAL_WORDS, relPath);
    assertNoWords(assert, text, INTERNAL_PATHS, relPath);
    assertNoWords(assert, text, WORK_IN_PROGRESS_MARKS, relPath);
    assert.equal(hasRawControlChar(text), false, relPath + " に生の制御文字が含まれています");
  }
});

// ---- 4. README の章立て -------------------------------------------------------

/** README の見出し（## …）を出てくる順に並べる */
function headings_(readme) {
  return readme
    .split("\n")
    .filter((line) => line.startsWith("## "))
    .map((line) => line.trim());
}

/** README の 1 章分を取り出す（次の "## " の手前まで） */
function section_(readme, heading) {
  const after = readme.split("\n" + heading + "\n")[1];
  assert.ok(after !== undefined, heading + " の章がありません");
  return after.split("\n## ")[0];
}

const JA_HEADINGS = [
  "## 1. 何ができるか",
  "## 2. 置き方を選ぶ",
  "## 3. 埋め込み",
  "## 4. Google スプレッドシート版",
  "## 5. Next.js テンプレ",
  "## 6. 設定の書き方",
  "## 7. データの決まり",
  "## 8. 色と見た目の変え方",
  "## 9. よくあるつまずき",
  "## 10. 作らなかったもの",
  "## 11. ライセンスとサポート",
];

const EN_HEADINGS = [
  "## 1. What it does",
  "## 2. Choosing how to run it",
  "## 3. Embedding in a page",
  "## 4. The Google Sheets edition",
  "## 5. The Next.js template",
  "## 6. Writing the configuration",
  "## 7. How the data is read",
  "## 8. Colours and styling",
  "## 9. Troubleshooting",
  "## 10. What we did not build",
  "## 11. Licence and support",
];

test("README.ja.md と README.en.md の章立ては、同じ番号・同じ順番になっている", () => {
  for (const [readme, wanted, label] of [
    [readmeJa, JA_HEADINGS, "README.ja.md"],
    [readmeEn, EN_HEADINGS, "README.en.md"],
  ]) {
    const found = headings_(readme);
    let at = -1;
    for (const heading of wanted) {
      const index = found.indexOf(heading);
      assert.ok(index !== -1, label + " に " + heading + " がありません");
      assert.ok(index > at, label + " の " + heading + " の位置");
      at = index;
    }
  }
});

// ---- 5. README に載せた設定の見本が、本当に通ること ------------------------------

/** ```json … ``` の中身をすべて取り出す */
function jsonBlocks_(readme) {
  const blocks = [];
  const pattern = /```json\n([\s\S]*?)```/g;
  let matched = pattern.exec(readme);
  while (matched !== null) {
    blocks.push(matched[1]);
    matched = pattern.exec(readme);
  }
  return blocks;
}

for (const [readme, label] of [
  [readmeJa, "README.ja.md"],
  [readmeEn, "README.en.md"],
]) {
  test(label + " に載せた設定の見本は、そのまま parseConfig を誤りなく通る", () => {
    const blocks = jsonBlocks_(readme);
    assert.ok(blocks.length >= 1, label + " に設定の見本（json のブロック）がありません");
    for (const block of blocks) {
      const raw = JSON.parse(block);
      if (!raw || typeof raw !== "object" || !Array.isArray(raw.widgets)) continue; // 設定そのものではない見本
      const { errors, config } = parseConfig(raw);
      assert.deepEqual(errors, [], label + " の見本に誤りがあります: " + JSON.stringify(errors));
      for (const widget of config.widgets) {
        assert.notEqual(widget.type, "error", label + " の見本の部品が誤りの札になっています: " + widget.message);
      }
    }
  });
}

// ---- 6. 埋め込みの見本に書いた mount の項目が、本当にある項目であること -------------

/** main.js が options から読む項目の名前 */
function mountOptionNames_() {
  const found = new Set();
  const pattern = /\b(?:opts|options)\.([A-Za-z_]\w*)/g;
  let matched = pattern.exec(mainSource);
  while (matched !== null) {
    found.add(matched[1]);
    matched = pattern.exec(mainSource);
  }
  return found;
}

/** README の html / js のブロックに出てくる Dashboard.mount / mountDashboard の項目の名前 */
function documentedMountOptions_(readme) {
  const found = new Set();
  const pattern = /```(?:html|js)\n([\s\S]*?)```/g;
  let matched = pattern.exec(readme);
  while (matched !== null) {
    const code = matched[1];
    const call = /(?:Dashboard\.mount|mountDashboard)\s*\([^,]+,\s*\{([\s\S]*?)\}\s*\)/g;
    let inner = call.exec(code);
    while (inner !== null) {
      for (const key of inner[1].matchAll(/(?:^|[,{\s])([A-Za-z_]\w*)\s*:/g)) found.add(key[1]);
      inner = call.exec(code);
    }
    matched = pattern.exec(readme);
  }
  return found;
}

test("README の埋め込みの見本が渡している項目は、すべて main.js が実際に読む項目", () => {
  const known = mountOptionNames_();
  for (const name of ["config", "data", "source", "lang", "theme", "today", "hash"]) {
    assert.ok(known.has(name), "main.js が options." + name + " を読んでいません");
  }
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    const used = documentedMountOptions_(readme);
    assert.ok(used.size > 0, label + " に mount の見本がありません");
    for (const name of used) {
      assert.ok(known.has(name), label + " の見本にある " + name + " を main.js は読みません");
    }
  }
});

test("README に、mount が返す destroy() と refresh()、2 つのファイルが要ることが書いてある", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    for (const word of ["destroy()", "refresh()", "dashboard.css", "dashboard.js", "dashboard.mjs"]) {
      assert.ok(readme.includes(word), label + " に " + word + " の説明がありません");
    }
  }
  // css が要ることを、はっきり書いてある（js だけでは足りない）
  assert.ok(/`dashboard\.css` と `dashboard\.js`[^\n]*2 つとも/.test(readmeJa), "README.ja.md に 2 つとも要ると書いてありません");
});

// ---- 7. --db-* の一覧が、style.css とぴったり合っていること ----------------------

/** style.css が決めている --db-* の名前 */
function cssTokens_() {
  return new Set([...styleSource.matchAll(/^\s*(--db-[a-z0-9-]+)\s*:/gm)].map((m) => m[1]));
}

/** README の表に並べた --db-* の名前 */
function readmeTokens_(readme) {
  return new Set([...readme.matchAll(/`(--db-[a-z0-9-]+)`/g)].map((m) => m[1]));
}

test("--db-* の一覧は、style.css にあるものと README の表がちょうど一致する", () => {
  const inCss = cssTokens_();
  assert.ok(inCss.size >= 20, "style.css の --db-* が " + inCss.size + " 個しかありません");
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    const listed = readmeTokens_(readme);
    for (const token of inCss) assert.ok(listed.has(token), label + " の表に " + token + " がありません");
    for (const token of listed) assert.ok(inCss.has(token), label + " の表にある " + token + " は style.css にありません");
  }
});

/** style.css の `.db { … }`（明るい配色）と `.db[data-db-theme="dark"] { … }` から、区分の色を読む */
function seriesColors_(selector) {
  // 行頭から始まる本物の決まり書きだけを取る（ファイル頭の説明の中の .db { … } を拾わないため）
  const at = styleSource.indexOf("\n" + selector);
  assert.notEqual(at, -1, selector + " が style.css に見つかりません");
  const block = styleSource.slice(at).split("\n}")[0];
  const found = {};
  for (const m of block.matchAll(/(--db-series-\d)\s*:\s*(#[0-9a-f]{6})/g)) found[m[1]] = m[2];
  return found;
}

test("README に並べた区分の色の値が、style.css の明・暗どちらとも合っている", () => {
  const light = seriesColors_(".db {");
  const dark = seriesColors_('.db[data-db-theme="dark"] {');
  assert.equal(Object.keys(light).length, 9, "明るい配色の区分の色は 9 つ（0〜8）");
  assert.equal(Object.keys(dark).length, 9, "暗い配色の区分の色は 9 つ（0〜8）");

  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    for (const token of Object.keys(light)) {
      const row = readme.split("\n").find((line) => line.includes("`" + token + "`") && line.includes("#"));
      assert.ok(row, label + " に " + token + " の色の行がありません");
      assert.ok(row.includes("`" + light[token] + "`"), label + ": " + token + " の明るい配色が違います → " + row);
      assert.ok(row.includes("`" + dark[token] + "`"), label + ": " + token + " の暗い配色が違います → " + row);
    }
  }
});

// ---- 8. 部品の項目・既定値・上限が、config.js と合っていること ---------------------

test("設定の全体の項目の既定値が、DEFAULT_CONFIG と合っている", () => {
  assert.equal(DEFAULT_CONFIG.lang, "ja");
  assert.equal(DEFAULT_CONFIG.theme, "auto");
  assert.equal(DEFAULT_CONFIG.filters.period, "thisMonth");
  for (const word of [
    "`lang`",
    "`theme`",
    "`cacheMinutes`",
    "`datasets`",
    "`filters`",
    "`widgets`",
    "`" + DEFAULT_CONFIG.theme + "`",
    "`" + DEFAULT_CONFIG.filters.period + "`",
    String(DEFAULT_CONFIG.cacheMinutes),
  ]) {
    assert.ok(readmeJa.includes(word), "README.ja.md に " + word + " がありません");
    assert.ok(readmeEn.includes(word), "README.en.md に " + word + " がありません");
  }
});

test("部品の種類・集計・刻み・書式・大きさ・期間の値が、すべて README に並んでいる", () => {
  const lists = { WIDGET_TYPES, AGGS, BUCKETS, FORMATS, SIZES, PERIODS, COMPARES, GOOD_WHENS, BAR_SORTS, TABLE_ORDERS };
  for (const [name, values] of Object.entries(lists)) {
    for (const value of values) {
      assert.ok(readmeJa.includes("`" + value + "`"), "README.ja.md に " + name + " の `" + value + "` がありません");
      assert.ok(readmeEn.includes("`" + value + "`"), "README.en.md に " + name + " の `" + value + "` がありません");
    }
  }
});

test("部品ごとの size の既定値と、折れ線・棒が s を受け取らない決まりが README にある", () => {
  assert.deepEqual(Object.keys(SIZE_DEFAULTS).sort(), WIDGET_TYPES.slice().sort(), "size の既定値は 5 種類ぶんある");
  assert.deepEqual(WIDE_ONLY_TYPES.slice().sort(), ["bar", "line"]);
  const rule = /size は m か l|size must be m or l/;
  assert.ok(rule.test(readmeJa), "README.ja.md に「size は m か l」の決まりがありません");
  assert.ok(rule.test(readmeEn), "README.en.md に size must be m or l がありません");
  // config.js が出す誤りの文と同じ言い回しにしてある
  assert.ok(configSource.includes("size は m か l にしてください"), "config.js の文が変わりました");
});

test("上限の数（絞り込みの列・上位・行数・系列・積み上げ・色）が README と合っている", () => {
  const rowLimit = rowLimitFromTable_();
  assert.equal(rowLimit, 20000);
  const numbers = [
    String(MAX_DIMENSIONS),
    BAR_TOP_RANGE[0] + "〜" + BAR_TOP_RANGE[1],
    TABLE_TOP_RANGE[0] + "〜" + TABLE_TOP_RANGE[1],
    grouped_(rowLimit),
    String(LINE_SERIES_MAX),
    String(BAR_SEGMENT_MAX),
    String(COLOR_MAX),
  ];
  for (const number of numbers) assert.ok(readmeJa.includes(number), "README.ja.md に " + number + " がありません");
  for (const number of [String(MAX_DIMENSIONS), grouped_(rowLimit), String(LINE_SERIES_MAX), String(BAR_SEGMENT_MAX), String(COLOR_MAX)]) {
    assert.ok(readmeEn.includes(number), "README.en.md に " + number + " がありません");
  }
  assert.ok(readmeJa.includes(MESSAGES.ja["state.truncated"]), "README.ja.md に 20,000 行の知らせの文がありません");
  assert.ok(readmeEn.includes(MESSAGES.en["state.truncated"]), "README.en.md に 20,000 行の知らせの文がありません");
});

test("cacheMinutes の範囲（0〜1440）が README に書いてある", () => {
  assert.ok(/minutes > 1440/.test(configSource), "config.js の cacheMinutes の上限が変わりました");
  assert.ok(readmeJa.includes("1440"), "README.ja.md に 1440 がありません");
  assert.ok(readmeEn.includes("1440"), "README.en.md に 1440 がありません");
});

// ---- 9. 日付・数の決まり -------------------------------------------------------

test("受け付ける日付の形と、月が先の形を読まないことが README にある", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    for (const form of ["2026-09-19", "2026/9/19", "9/19/2026"]) {
      assert.ok(readme.includes(form), label + " に日付の形 " + form + " の説明がありません");
    }
  }
  assert.ok(readmeJa.includes(MESSAGES.ja["state.skippedValues"].replace("{count}", "N")), "README.ja.md に「数として読めない値」の文がありません");
});

test("期間の名前と、URL の # の頭（db.）が README にある", () => {
  const prefix = mainSource.match(/const MAIN_HASH_PREFIX_ = "([a-z0-9_-]+)"/);
  assert.ok(prefix, "main.js の # の頭が見つかりません");
  assert.ok(readmeJa.includes("#" + prefix[1] + "."), "README.ja.md に #" + prefix[1] + ". の説明がありません");
  assert.ok(readmeEn.includes("#" + prefix[1] + "."), "README.en.md に #" + prefix[1] + ". の説明がありません");
});

// ---- 10. GAS 版（メニューの名前・公開の手順・シートの語彙） ----------------------

/** gas_main.js の onOpen が並べるメニューの項目名 */
function menuItems_() {
  return [...gasMainSource.matchAll(/\.addItem\("([^"]+)"/g)].map((m) => m[1]);
}

test("メニューの項目名が、gas_main.js のまま README に書いてある", () => {
  const items = menuItems_();
  assert.equal(items.length, 4, "メニューは 4 項目のはず");
  for (const item of items) {
    assert.ok(readmeJa.includes(item), "README.ja.md にメニュー「" + item + "」がありません");
    assert.ok(readmeEn.includes(item), "README.en.md にメニュー「" + item + "」がありません");
  }
  const menuTitle = gasMainSource.match(/const GAS_MENU_TITLE_ = "([^"]+)"/);
  assert.ok(menuTitle, "メニューの名前が見つかりません");
  assert.ok(readmeJa.includes("「" + menuTitle[1] + "」"), "README.ja.md にメニューの名前がありません");
});

test("デプロイの手順が、gas_main.js が出す文言とそのまま同じ", () => {
  const matched = gasMainSource.match(/const GAS_DEPLOY_STEPS_ =\s*([\s\S]*?);\n/);
  assert.ok(matched, "公開の手順の文が見つかりません");
  const lines = [...matched[1].matchAll(/"([^"]*)"/g)]
    .map((m) => m[1].replace(/\\n/g, ""))
    .filter((line) => line.startsWith("・"));
  assert.equal(lines.length, 3, "公開の手順は 3 行のはず");
  for (const line of lines) {
    const body = line.slice(1);
    assert.ok(readmeJa.includes(body), "README.ja.md に公開の手順「" + body + "」がありません");
    assert.ok(readmeEn.includes(body), "README.en.md に公開の手順「" + body + "」がありません");
  }
});

test("`定義` シートの列が、1 つ残らず README の対応表にある", () => {
  for (const column of CONFIG_DEFINITION_COLUMNS_) {
    assert.ok(readmeJa.includes("| " + column + " |"), "README.ja.md の表に 定義 の列「" + column + "」がありません");
    assert.ok(readmeEn.includes("| " + column + " |"), "README.en.md の表に 定義 の列「" + column + "」がありません");
  }
});

test("`定義` シートに日本語で書ける値が、1 つ残らず README にある", () => {
  const dicts = [
    "CONFIG_SHEET_PERIODS_",
    "CONFIG_SHEET_LANGS_",
    "CONFIG_SHEET_THEMES_",
    "CONFIG_SHEET_TYPES_",
    "CONFIG_SHEET_AGGS_",
    "CONFIG_SHEET_BUCKETS_",
    "CONFIG_SHEET_FORMATS_",
    "CONFIG_SHEET_SIZES_",
    "CONFIG_SHEET_BAR_SORTS_",
    "CONFIG_SHEET_COMPARES_",
    "CONFIG_SHEET_GOOD_WHENS_",
    "CONFIG_SHEET_TABLE_ROWS_",
  ];
  for (const name of dicts) {
    for (const word of Object.keys(constObject_(configSource, name))) {
      assert.ok(readmeJa.includes(word), "README.ja.md に " + name + " の「" + word + "」がありません");
      assert.ok(readmeEn.includes(word), "README.en.md に " + name + " の「" + word + "」がありません");
    }
  }
});

test("`設定` シートの項目が README にある", () => {
  for (const item of ["題名", "言語", "テーマ", "期間", "開始日", "終了日", "絞り込みの列"]) {
    assert.ok(gasMainSource.includes('["' + item + '"'), "gas_main.js のひな型に「" + item + "」がありません");
    assert.ok(readmeJa.includes("| " + item + " |"), "README.ja.md の表に 設定 の「" + item + "」がありません");
    assert.ok(readmeEn.includes("| " + item + " |"), "README.en.md の表に 設定 の「" + item + "」がありません");
  }
});

test("GAS の許可・公開の設定・見られる人の決まりが README にある", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    for (const word of ["spreadsheets", "script.container.ui", "USER_ACCESSING", "ANYONE"]) {
      assert.ok(readme.includes(word), label + " に " + word + " の説明がありません");
    }
    assert.ok(readme.includes(MESSAGES[label.includes("ja") ? "ja" : "en"]["state.unavailable"]), label + " に「ただいま表示できません」の説明がありません");
  }
});

// ---- 11. つまずきの章と、作らなかったものの章 -------------------------------------

test("よくあるつまずきの章が、症状 → 原因 → 直し方の表になっている", () => {
  const ja = section_(readmeJa, JA_HEADINGS[8]);
  const en = section_(readmeEn, EN_HEADINGS[8]);
  for (const [body, label] of [
    [ja, "README.ja.md"],
    [en, "README.en.md"],
  ]) {
    const rows = body.split("\n").filter((line) => line.startsWith("| ") && !line.startsWith("| ---"));
    assert.ok(rows.length >= 10, label + " のつまずきの表が " + rows.length + " 行しかありません");
  }
  for (const word of [MESSAGES.ja["state.checkConfig"], "404", "http"]) {
    assert.ok(ja.includes(word), "README.ja.md のつまずきの章に「" + word + "」がありません");
  }
});

test("作らなかったものの章に、8 つの項目と理由がある", () => {
  const ja = section_(readmeJa, JA_HEADINGS[9]);
  for (const word of ["円グラフ", "2 軸", "地図", "ドリルダウン", "データベース", "ログイン", "AI"]) {
    assert.ok(ja.includes(word), "README.ja.md の「作らなかったもの」に " + word + " がありません");
  }
  const en = section_(readmeEn, EN_HEADINGS[9]);
  for (const word of ["Pie", "second axis", "Maps", "Drill", "database", "login", "AI"]) {
    assert.ok(en.includes(word), "README.en.md の「作らなかったもの」に " + word + " がありません");
  }
});

// ---- 12. LICENSE・CHANGELOG ----------------------------------------------------

test("LICENSE.md は日本語が先、英語があと。値段は書かない", () => {
  const license = readFileSync(join(ROOT, "LICENSE.md"), "utf8");
  assert.ok(license.includes("ダッシュボード キット"), "商品の名前がありません");
  assert.ok(license.includes("Dashboard Kit"), "英語の商品の名前がありません");
  assert.ok(license.includes("hello@suminawa.dev"));
  assert.ok(license.includes("再配布"));
  assert.ok(license.includes("14 日間"));
  assert.ok(/日本語.*(優先|正)/.test(license), "日本語が優先される旨がありません");
  assert.equal(/[¥￥$]\s?\d/.test(license), false, "値段は書かない");
  assert.ok(license.indexOf("ダッシュボード キット") < license.indexOf("Dashboard Kit"), "日本語を先に置く");
});

test("CHANGELOG.md に 1.0.0 の行がある。値段は書かない", () => {
  const changelog = readFileSync(join(ROOT, "CHANGELOG.md"), "utf8");
  assert.ok(changelog.includes("## 1.0.0 — 2026-09-27"), "1.0.0 の見出しがありません");
  assert.equal(/[¥￥$]\s?\d/.test(changelog), false, "値段は書かない");
});

test("README に値段と連絡先の決まりが守られている", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    assert.ok(readme.includes("hello@suminawa.dev"), label + " に連絡先がありません");
    assert.ok(readme.includes("しおかぜ珈琲店") || readme.includes("Shiokaze Coffee"), label + " に見本の店の名前がありません");
  }
  assert.ok(readmeJa.includes("架空"), "見本の店が架空だと断っていません");
  assert.ok(readmeEn.includes("fictional"), "見本の店が架空だと断っていません");
});

test("zip の中身の一覧が README の冒頭にある（買い手が最初に読むところ）", () => {
  const head = readmeJa.split("\n## ")[0];
  for (const word of ["dist/", "demo/index.html", "samples/", "templates/nextjs/", "LICENSE.md"]) {
    assert.ok(head.includes(word), "README.ja.md の「はじめに」に " + word + " がありません");
  }
  const headEn = readmeEn.split("\n## ")[0];
  for (const word of ["dist/", "demo/index.html", "samples/", "templates/nextjs/"]) {
    assert.ok(headEn.includes(word), "README.en.md の冒頭に " + word + " がありません");
  }
});

test("ファイルの大きさがそれらしい（README が短すぎない）", () => {
  assert.ok(statSync(join(ROOT, "README.ja.md")).size > 12000, "README.ja.md が短すぎます");
  assert.ok(statSync(join(ROOT, "README.en.md")).size > 10000, "README.en.md が短すぎます");
});

// ---- 13. README に書いた事実が、いまのコード・生成物と合っていること -------------

/** README に「約 NNN KB」と書いてある大きさを、ファイル名ごとに拾う */
function statedSizes_(readme) {
  const found = new Map();
  for (const line of readme.split("\n")) {
    for (const hit of line.matchAll(/`(dashboard\.(?:js|css))`[^`\n]{0,40}?(?:約\s*)?(\d+)\s*KB/g)) {
      found.set(hit[1], Number(hit[2]));
    }
  }
  return found;
}

test("README に書いた配布物の大きさが、いま作ったファイルと ±5% 以内で合っている", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    const stated = statedSizes_(readme);
    assert.equal(stated.size, 2, label + " に dashboard.js と dashboard.css の大きさが書かれていません");
    for (const [name, kb] of stated) {
      const real = statSync(join(ROOT, "dist", name)).size / 1024;
      const gap = Math.abs(real - kb) / real;
      assert.ok(gap <= 0.05, label + ": " + name + " は約 " + Math.round(real) + " KB なのに " + kb + " KB と書いてあります");
    }
  }
});

test("配布する 1 本に見本データの生成器が入っていないことが、README に書いてある", () => {
  const distJs = readFileSync(join(ROOT, "dist", "dashboard.js"), "utf8");
  assert.equal(distJs.includes("source-memory.js"), false, "配布物に見本の読み口が入っています");
  assert.ok(readmeJa.includes('`source: "memory"`'), "README.ja.md に source: \"memory\" の説明がありません");
  assert.ok(readmeEn.includes('`source: "memory"`'), "README.en.md に source: \"memory\" の説明がありません");
  assert.ok(/demo|見本のページ/.test(readmeJa), "見本のページにだけ入っていることを書く");
});

test("Dashboard.version と、その値（package.json の版）が README にある", () => {
  const version = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")).version;
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    assert.ok(readme.includes("`Dashboard.version`"), label + " に Dashboard.version がありません");
    assert.ok(readme.includes("`" + version + "`"), label + " に版 " + version + " がありません");
  }
});

test("刻みの上限の知らせと、その数が README にある", () => {
  const aggregateSource = readFileSync(join(ROOT, "src", "core", "aggregate.js"), "utf8");
  const max = Number(aggregateSource.match(/const AGGREGATE_BUCKET_MAX_ = (\d+)/)[1]);
  assert.equal(max, 400);
  assert.ok(readmeJa.includes(MESSAGES.ja["state.bucketCapped"].replace("{count}", String(max))), "README.ja.md に刻みの上限の知らせがありません");
  assert.ok(readmeEn.includes(MESSAGES.en["state.bucketCapped"].replace("{count}", String(max))), "README.en.md に刻みの上限の知らせがありません");
});

test("縮めた数の決まり（いつも小数 1 桁・縮めるところ）が README にある", () => {
  const numbersSource = readFileSync(join(ROOT, "src", "core", "numbers.js"), "utf8");
  assert.ok(numbersSource.includes("const NUMBER_COMPACT_DECIMALS_ = 1"), "縮めた数の桁数が変わりました");
  assert.ok(readmeJa.includes("### 7-8. 数の縮め方"), "README.ja.md に数の縮め方の小節がありません");
  assert.ok(readmeEn.includes("### 7-8. How numbers are abbreviated"), "README.en.md に数の縮め方の小節がありません");
  for (const [readme, words] of [
    [readmeJa, ["いつも 1 桁", "12,345"]],
    [readmeEn, ["one decimal place", "12,345"]],
  ]) {
    for (const word of words) assert.ok(readme.includes(word), "「" + word + "」がありません");
  }
});

test("目標の月の決まり（期間の終わりが開いているときは、データの最新の月）が README にある", () => {
  const modelSourceText = readFileSync(join(ROOT, "src", "core", "model.js"), "utf8");
  assert.ok(modelSourceText.includes("modelTargetDay_"), "目標の月を決めるところが変わりました");
  assert.ok(readmeJa.includes("いちばん新しい日付の月"), "README.ja.md に目標の月の決まりがありません");
  assert.ok(readmeEn.includes("most recent date"), "README.en.md に目標の月の決まりがありません");
});

test("url が任意であること・Next.js の DASHBOARD_SAMPLE が、README の両方にある", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    assert.ok(readme.includes("DASHBOARD_SAMPLE"), label + " に DASHBOARD_SAMPLE がありません");
  }
  assert.ok(readmeJa.includes("（任意。`data` で行を渡すとき・スプレッドシート版では書きません）"), "README.ja.md の url の行が古いままです");
  assert.ok(readmeEn.includes("(optional; omit it when you pass rows through `data`"), "README.en.md の url の行が古いままです");
  // 設定の検査が、url の無いデータセットを誤りにしないこと（README と同じ決まり）
  const parsed = parseConfig({ datasets: { sales: {} }, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] });
  assert.deepEqual(parsed.errors, []);
});

test("`file://` で開いたときの注意が、README の両方にある", () => {
  assert.ok(readmeJa.includes("file://"), "README.ja.md に file:// の注意がありません");
  assert.ok(readmeEn.includes("file://"), "README.en.md に file:// の注意がありません");
  assert.equal((readmeJa.match(/file:\/\//g) || []).length >= 3, true, "§3-1・§3-6・§9 の 3 か所に書く");
  assert.equal((readmeEn.match(/file:\/\//g) || []).length >= 3, true, "§3-1・§3-6・§9 の 3 か所に書く");
});

test("色を上書きする例が、明・暗・auto の 3 か所をそろえて書いてある", () => {
  for (const [readme, label] of [
    [readmeJa, "README.ja.md"],
    [readmeEn, "README.en.md"],
  ]) {
    for (const selector of [".db {", '.db[data-db-theme="dark"] {', "@media (prefers-color-scheme: dark)", '.db[data-db-theme="auto"] {']) {
      assert.ok(readme.includes(selector), label + " の上書きの例に " + selector + " がありません");
    }
  }
});
