import { test } from "node:test";
import assert from "node:assert/strict";
import { aggregate, groupBy, topN, timeSeries, compareValue, compareEntriesDesc } from "../src/core/aggregate.js";

const ROWS = [
  { 金額: 1000, カテゴリ: "豆" },
  { 金額: 2000, カテゴリ: "豆" },
  { 金額: null, カテゴリ: "菓子" },
  { 金額: 500, カテゴリ: "" },
  { 金額: 500, カテゴリ: null },
];

test("aggregate: sum は null をのぞいて合計し、skipped を数える", () => {
  assert.deepEqual(aggregate(ROWS, "金額", "sum"), { value: 4000, skipped: 1 });
});

test("aggregate: avg は null をのぞいた平均。行がすべて null なら null", () => {
  assert.deepEqual(aggregate(ROWS, "金額", "avg"), { value: 1000, skipped: 1 });
  assert.deepEqual(aggregate([{ 金額: null }], "金額", "avg"), { value: null, skipped: 1 });
});

test("aggregate: min・max も null をのぞく", () => {
  assert.deepEqual(aggregate(ROWS, "金額", "min"), { value: 500, skipped: 1 });
  assert.deepEqual(aggregate(ROWS, "金額", "max"), { value: 2000, skipped: 1 });
});

test("aggregate: count は行数（値を見ない）", () => {
  assert.deepEqual(aggregate(ROWS, "金額", "count"), { value: 5, skipped: 0 });
});

test("aggregate: distinct は種類の数（空文字も数えない）", () => {
  assert.deepEqual(aggregate(ROWS, "カテゴリ", "distinct"), { value: 2, skipped: 0 });
});

test("aggregate: distinct は null・undefined・空文字（前後の空白を落として空になるものも含む）を数えない", () => {
  assert.deepEqual(aggregate([{ v: "a" }, { v: "" }, { v: "a" }, { v: null }, { v: "b" }], "v", "distinct"), { value: 2, skipped: 0 });
});

test("aggregate: distinct は数値と文字列表現が同じ値を 1 つに数える", () => {
  assert.deepEqual(aggregate([{ v: 5 }, { v: "5" }], "v", "distinct"), { value: 1, skipped: 0 });
});

test("aggregate: distinct はすべて空なら 0", () => {
  assert.deepEqual(aggregate([{ v: "" }, { v: null }, { v: undefined }], "v", "distinct"), { value: 0, skipped: 0 });
});

test("aggregate: 行が 0 のとき sum・count・distinct は 0、avg・min・max は null", () => {
  assert.deepEqual(aggregate([], "金額", "sum"), { value: 0, skipped: 0 });
  assert.deepEqual(aggregate([], "金額", "count"), { value: 0, skipped: 0 });
  assert.deepEqual(aggregate([], "カテゴリ", "distinct"), { value: 0, skipped: 0 });
  assert.deepEqual(aggregate([], "金額", "avg"), { value: null, skipped: 0 });
  assert.deepEqual(aggregate([], "金額", "min"), { value: null, skipped: 0 });
  assert.deepEqual(aggregate([], "金額", "max"), { value: null, skipped: 0 });
});

test("groupBy: null と空文字は呼び出し側が渡した blankLabel にまとめ、先に出た順を保つ", () => {
  const groups = groupBy(ROWS, "カテゴリ", "（空）");
  assert.deepEqual([...groups.keys()], ["豆", "菓子", "（空）"]);
  assert.equal(groups.get("豆").length, 2);
  assert.equal(groups.get("（空）").length, 2);
});

test("topN: sum のときの「その他」は残りを 1 つに足し、最後に付く（それが最大でも）", () => {
  const entries = [
    { key: "A", value: 10 },
    { key: "B", value: 100 },
    { key: "C", value: 1 },
    { key: "D", value: 1 },
  ];
  const result = topN(entries, 2, "その他", "sum");
  assert.deepEqual(result.entries, [
    { key: "B", value: 100 },
    { key: "A", value: 10 },
    { key: "その他", value: 2, isOther: true },
  ]);
  assert.equal(result.other, true);
});

test("topN: 同値は名前順（ロケールに寄らない単純比較）", () => {
  const entries = [
    { key: "b", value: 5 },
    { key: "a", value: 5 },
  ];
  const result = topN(entries, 5, "その他", "sum");
  assert.deepEqual(
    result.entries.map((e) => e.key),
    ["a", "b"]
  );
});

test("topN: n 以下なら「その他」は付かない", () => {
  const entries = [
    { key: "A", value: 10 },
    { key: "B", value: 5 },
  ];
  const result = topN(entries, 5, "その他", "sum");
  assert.deepEqual(result.entries, entries);
  assert.equal(result.other, false);
});

test("topN: avg・min・max のときは足し合わせず、切るだけで other は false", () => {
  const entries = [
    { key: "A", value: 30 },
    { key: "B", value: 20 },
    { key: "C", value: 10 },
  ];
  const result = topN(entries, 2, "その他", "avg");
  assert.deepEqual(result.entries, [
    { key: "A", value: 30 },
    { key: "B", value: 20 },
  ]);
  assert.equal(result.other, false);
});

test("topN: 入力の key がすでに otherLabel と同じでも特別扱いしない", () => {
  const entries = [
    { key: "その他", value: 100 },
    { key: "A", value: 5 },
    { key: "B", value: 1 },
  ];
  const result = topN(entries, 1, "その他", "sum");
  assert.deepEqual(result.entries, [
    { key: "その他", value: 100 },
    { key: "その他", value: 6, isOther: true },
  ]);
});

const TIME_ROWS = [
  { 日付: "2026-09-01", 金額: 1000 },
  { 日付: "2026-09-01", 金額: 500 },
  { 日付: "2026-09-03", 金額: 2000 },
];

test("timeSeries: 値の無い刻みは sum なら 0、avg なら null で埋める", () => {
  const sumSeries = timeSeries(TIME_ROWS, {
    dateColumn: "日付",
    value: "金額",
    agg: "sum",
    bucket: "day",
    range: { from: "2026-09-01", to: "2026-09-03" },
  });
  assert.deepEqual(sumSeries.buckets, ["2026-09-01", "2026-09-02", "2026-09-03"]);
  assert.deepEqual(sumSeries.values, [1500, 0, 2000]);
  assert.equal(sumSeries.bucket, "day");

  const avgSeries = timeSeries(TIME_ROWS, {
    dateColumn: "日付",
    value: "金額",
    agg: "avg",
    bucket: "day",
    range: { from: "2026-09-01", to: "2026-09-03" },
  });
  assert.deepEqual(avgSeries.values, [750, null, 2000]);
});

test("timeSeries: 範囲が開いているときはデータの最小・最大の日付を使う", () => {
  const series = timeSeries(TIME_ROWS, { dateColumn: "日付", value: "金額", agg: "sum", bucket: "day", range: { from: "", to: "" } });
  assert.deepEqual(series.buckets, ["2026-09-01", "2026-09-02", "2026-09-03"]);
});

test("timeSeries: 行が無く範囲も開いているときは空を返す", () => {
  const series = timeSeries([], { dateColumn: "日付", value: "金額", agg: "sum", bucket: "day", range: { from: "", to: "" } });
  assert.deepEqual(series, { buckets: [], values: [], capped: false });
});

test("timeSeries: 年の刻みにしても上限を超えるときは、新しいほうから 400 個だけにして capped を立てる", () => {
  // 日付の年を 1 つ打ち間違えた（9999 年）データ。年の刻みでも 7,974 個になる
  const rows = [
    { 日付: "2026-09-01", 金額: 100 },
    { 日付: "2026-09-02", 金額: 200 },
    { 日付: "9999-12-31", 金額: 300 },
  ];
  const series = timeSeries(rows, { dateColumn: "日付", value: "金額", agg: "sum", bucket: "auto", range: { from: "", to: "" } });

  assert.equal(series.bucket, "year", "いちばん粗い年まで粗くするはず");
  assert.equal(series.capped, true, "それでも収まらないので、上限に当たった印を立てるはず");
  assert.equal(series.buckets.length, 400);
  assert.equal(series.buckets[series.buckets.length - 1], "9999", "新しいほうの端は必ず残すはず");
  assert.equal(series.values[series.values.length - 1], 300);
  assert.equal(series.buckets.indexOf("2026"), -1, "古いほうから落とすので、2026 年は入らない");
});

test("timeSeries: 上限に収まるときは capped を立てない", () => {
  const series = timeSeries(TIME_ROWS, { dateColumn: "日付", value: "金額", agg: "sum", bucket: "day", range: { from: "2026-09-01", to: "2026-09-03" } });
  assert.equal(series.capped, false);
});

test("timeSeries: bucket が auto のときは autoBucket で刻みを選ぶ", () => {
  const series = timeSeries(TIME_ROWS, {
    dateColumn: "日付",
    value: "金額",
    agg: "sum",
    bucket: "auto",
    range: { from: "2026-09-01", to: "2026-09-03" },
  });
  assert.equal(series.bucket, "day");
});

test("timeSeries: 刻みの数が 400 を超えるときは粗い刻みに変えて収める", () => {
  const series = timeSeries([{ 日付: "2020-01-01", 金額: 1 }], {
    dateColumn: "日付",
    value: "金額",
    agg: "sum",
    bucket: "day",
    range: { from: "2020-01-01", to: "2022-01-01" }, // 700 日超
  });
  assert.notEqual(series.bucket, "day");
  assert.ok(series.buckets.length <= 400);
});

test("compareValue: 差分と比率", () => {
  assert.deepEqual(compareValue(120, 100), { delta: 20, ratio: 0.2 });
  assert.deepEqual(compareValue(80, 100), { delta: -20, ratio: -0.2 });
});

test("compareValue: 前の期間が 0 のときは ratio が null（delta はそのまま）", () => {
  assert.deepEqual(compareValue(100, 0), { delta: 100, ratio: null });
});

test("compareValue: どちらかが null なら null", () => {
  assert.equal(compareValue(null, 100), null);
  assert.equal(compareValue(100, null), null);
});

test("compareEntriesDesc: value の大きい順、同じなら key の単純比較。値が無いものは最後", () => {
  assert.equal(compareEntriesDesc({ key: "a", value: 5 }, { key: "b", value: 10 }) > 0, true);
  assert.equal(compareEntriesDesc({ key: "a", value: 5 }, { key: "b", value: 5 }) < 0, true);
  assert.equal(compareEntriesDesc({ key: "a", value: null }, { key: "b", value: 5 }) > 0, true);
  assert.equal(compareEntriesDesc({ key: "a", value: null }, { key: "b", value: null }) < 0, true);
});
