import { test } from "node:test";
import assert from "node:assert/strict";
import { parseConfig } from "../src/core/config.js";
import { PERIOD_PRESETS, initialState, reduce, filtersDiffer } from "../src/ui/state.js";

const TODAY = "2026-09-19";

function makeConfig_(overrides) {
  const raw = Object.assign(
    {
      title: "しおかぜ珈琲店 売上ダッシュボード",
      datasets: { sales: { url: "./sales.csv", dateColumn: "日付" } },
      filters: { period: "thisMonth", dimensions: ["チャネル", "カテゴリ"] },
      widgets: [{ type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", size: "s" }],
    },
    overrides || {}
  );
  const parsed = parseConfig(raw);
  assert.deepEqual(parsed.errors, [], "見本の設定に誤りがあってはならない");
  return parsed.config;
}

function ready_(config) {
  return reduce(initialState(config || makeConfig_(), TODAY), { type: "loaded" });
}

test("PERIOD_PRESETS: 期間の並びは 8 つで、custom が最後", () => {
  assert.deepEqual(PERIOD_PRESETS, ["thisMonth", "lastMonth", "last7", "last30", "last90", "thisYear", "all", "custom"]);
});

test("initialState: 読み込み中から始まり、設定どおりの絞り込みを持つ", () => {
  const state = initialState(makeConfig_(), TODAY);
  assert.equal(state.status, "loading");
  assert.equal(state.message, "");
  assert.equal(state.filters.period, "thisMonth");
  assert.equal(state.filters.from, "2026-09-01");
  assert.equal(state.filters.to, "2026-09-19");
  assert.deepEqual(Object.keys(state.filters.dimensions), ["チャネル", "カテゴリ"]);
  assert.deepEqual(state.tableView, {});
  assert.deepEqual(state.sort, {});
  assert.equal(filtersDiffer(state.filters, state.initial), false);
});

test("reduce: loaded で表示できる状態になり、もう一度送っても同じ状態を返す", () => {
  const state = initialState(makeConfig_(), TODAY);
  const loaded = reduce(state, { type: "loaded" });
  assert.equal(loaded.status, "ready");
  assert.notEqual(loaded, state);
  assert.equal(reduce(loaded, { type: "loaded" }), loaded, "変わらないときは同じ状態を返す");
});

test("reduce: failed は知らせの文を持つ誤りの状態にする", () => {
  const state = initialState(makeConfig_(), TODAY);
  const failed = reduce(state, { type: "failed", message: "ただいま表示できません。しばらくしてからお試しください。" });
  assert.equal(failed.status, "error");
  assert.equal(failed.message, "ただいま表示できません。しばらくしてからお試しください。");
  assert.equal(reduce(failed, { type: "failed", message: failed.message }), failed);
});

test("reduce: set-period は期間だけを変え、同じ期間なら同じ状態を返す", () => {
  const state = ready_();
  const next = reduce(state, { type: "set-period", period: "last30" });
  assert.equal(next.filters.period, "last30");
  assert.equal(next.filters.from, state.filters.from, "日付はそのまま残す");
  assert.equal(state.filters.period, "thisMonth", "元の状態を書き換えない");
  assert.equal(reduce(next, { type: "set-period", period: "last30" }), next);
  assert.equal(reduce(next, { type: "set-period", period: "しらない期間" }), next, "知らない期間は受け取らない");
});

test("reduce: set-range は日付を入れ、期間を「期間を指定」に切り替える", () => {
  const state = ready_();
  const next = reduce(state, { type: "set-range", from: "2026-08-01", to: "2026-08-31" });
  assert.equal(next.filters.period, "custom");
  assert.equal(next.filters.from, "2026-08-01");
  assert.equal(next.filters.to, "2026-08-31");
  assert.equal(reduce(next, { type: "set-range", from: "2026-08-01", to: "2026-08-31" }), next);
});

test("reduce: set-dimension は設定にある列だけを変える", () => {
  const state = ready_();
  const next = reduce(state, { type: "set-dimension", column: "チャネル", value: "EC" });
  assert.equal(next.filters.dimensions["チャネル"], "EC");
  assert.equal(next.filters.dimensions["カテゴリ"], "");
  assert.equal(state.filters.dimensions["チャネル"], "", "元の状態を書き換えない");
  assert.equal(reduce(next, { type: "set-dimension", column: "チャネル", value: "EC" }), next);
  assert.equal(reduce(next, { type: "set-dimension", column: "無い列", value: "EC" }), next, "知らない列は受け取らない");
});

test("reduce: set-dimension に特別な名前が来ても、入れ物の素性を書き換えない", () => {
  const state = ready_();
  const next = reduce(state, { type: "set-dimension", column: "__proto__", value: "{}" });
  assert.equal(next, state);
  assert.equal(Object.getPrototypeOf(state.filters.dimensions), null);
});

test("reduce: toggle-table は部品ごとに表とグラフを行き来する", () => {
  const state = ready_();
  const shown = reduce(state, { type: "toggle-table", widget: "w1" });
  assert.equal(shown.tableView.w1, true);
  const hidden = reduce(shown, { type: "toggle-table", widget: "w1" });
  assert.equal(hidden.tableView.w1, false);
  assert.deepEqual(state.tableView, {}, "元の状態を書き換えない");
});

test("reduce: sort は同じ列で 大きい順 → 小さい順 → 並べ替えなし と巡る", () => {
  const state = ready_();
  const desc = reduce(state, { type: "sort", widget: "w1", column: 2 });
  assert.deepEqual(desc.sort.w1, { column: 2, order: "desc" });
  const asc = reduce(desc, { type: "sort", widget: "w1", column: 2 });
  assert.deepEqual(asc.sort.w1, { column: 2, order: "asc" });
  const none = reduce(asc, { type: "sort", widget: "w1", column: 2 });
  assert.equal(none.sort.w1, undefined);

  const other = reduce(desc, { type: "sort", widget: "w1", column: 1 });
  assert.deepEqual(other.sort.w1, { column: 1, order: "desc" }, "別の列は大きい順から始まる");
});

test("reduce: reset は絞り込みを最初に戻し、並べ替えと表の切り替えも消す", () => {
  const state = ready_();
  const touched = reduce(
    reduce(reduce(state, { type: "set-period", period: "all" }), { type: "toggle-table", widget: "w1" }),
    { type: "sort", widget: "w1", column: 1 }
  );
  assert.equal(filtersDiffer(touched.filters, touched.initial), true);

  const back = reduce(touched, { type: "reset" });
  assert.equal(back.filters.period, "thisMonth");
  assert.equal(filtersDiffer(back.filters, back.initial), false);
  assert.deepEqual(back.tableView, {});
  assert.deepEqual(back.sort, {});
  assert.equal(back.status, "ready", "読み込みの具合は変えない");
  assert.equal(reduce(back, { type: "reset" }), back, "戻すものが無いときは同じ状態を返す");
});

test("reduce: 知らない操作・形の無い操作は同じ状態を返す", () => {
  const state = ready_();
  assert.equal(reduce(state, { type: "しらない操作" }), state);
  assert.equal(reduce(state, null), state);
  assert.equal(reduce(state, {}), state);
});

test("filtersDiffer: 期間・日付・区分のどれが違っても true", () => {
  const state = ready_();
  const base = state.filters;
  assert.equal(filtersDiffer(base, base), false);
  assert.equal(filtersDiffer(base, Object.assign({}, base, { period: "all" })), true);
  assert.equal(filtersDiffer(base, Object.assign({}, base, { from: "2020-01-01" })), true);
  const dimensions = Object.assign(Object.create(null), base.dimensions, { チャネル: "EC" });
  assert.equal(filtersDiffer(base, Object.assign({}, base, { dimensions })), true);
});

test("reduce: 同じ絞り込みを続けて選んでも、同じ状態をそのまま返す", () => {
  const state = ready_();
  const first = reduce(state, { type: "set-period", period: "last30" });
  assert.notEqual(first, state);
  assert.equal(reduce(first, { type: "set-period", period: "last30" }), first, "中身が変わらないなら同じ状態");
  assert.equal(reduce(state, { type: "set-period", period: "thisMonth" }), state, "最初と同じ期間を選び直しても変わらない");

  const ranged = reduce(first, { type: "set-range", from: "2026-09-01", to: "2026-09-10" });
  assert.equal(reduce(ranged, { type: "set-range", from: "2026-09-01", to: "2026-09-10" }), ranged);

  const picked = reduce(state, { type: "set-dimension", column: "チャネル", value: "EC" });
  assert.equal(reduce(picked, { type: "set-dimension", column: "チャネル", value: "EC" }), picked);
});
