import { test } from "node:test";
import assert from "node:assert/strict";
import { linePath, areaPath, roundedBar, scaleLinear } from "../src/ui/svg.js";
import { renderKpi, renderLine, renderBar, renderMeter } from "../src/ui/render-charts.js";
import { renderTable, renderDataTable, renderCsvButton } from "../src/ui/render-table.js";
import { renderWidgetFrame } from "../src/ui/render.js";

// ---- 検査の小道具 ---------------------------------------------------------

/** class を先頭に置いた開始タグだけを拾う（描く側はいつも class を先に書く） */
function marks_(html, name, className) {
  return html.match(new RegExp("<" + name + ' class="' + className + '[^"]*"[^>]*>', "g")) || [];
}

function attr_(tag, name) {
  const found = tag.match(new RegExp(" " + name + '="([^"]*)"'));
  return found === null ? null : found[1];
}

/** 属性に入った実体参照を元に戻す（&amp; は最後） */
function unescape_(text) {
  return text
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

function tipOf_(tag) {
  return JSON.parse(unescape_(attr_(tag, "data-tip")));
}

/** 棒の path の「根元 → 値の側」の y（横棒なら x）を読む */
function barEdges_(tag) {
  const found = attr_(tag, "d").match(/^M (-?[\d.]+) (-?[\d.]+) L (-?[\d.]+) (-?[\d.]+)/);
  return { x1: Number(found[1]), y1: Number(found[2]), x2: Number(found[3]), y2: Number(found[4]) };
}

// ---- 見本の model ---------------------------------------------------------

const KPI = {
  id: "w1",
  type: "kpi",
  title: "売上",
  size: "s",
  format: "yen",
  note: "",
  valueText: "¥3.5万",
  valueFull: "¥35,100",
  delta: { text: "+63.3%", textFull: "+63.3%", direction: "up", good: true, label: "先月比" },
  spark: { values: [1000, 2000, null, 3000], min: 0, max: 3000 },
  skipped: 0,
  table: { head: ["項目", "値", "前の期間", "差"], rows: [["売上", "¥35,100", "¥21,500", "+63.3%"]] },
};

const LINE = {
  id: "w2",
  type: "line",
  title: "売上の推移",
  size: "l",
  format: "yen",
  note: "",
  empty: false,
  series: [
    { key: "EC", label: "EC", color: 1, values: [100, null, 300], lastLabel: "¥300" },
    { key: "店舗", label: "店舗", color: 2, values: [50, 80, 60], lastLabel: "¥60" },
  ],
  buckets: [
    { key: "2026-09-01", label: "9/1" },
    { key: "2026-09-02", label: "9/2" },
    { key: "2026-09-03", label: "9/3" },
  ],
  ticks: [0, 100, 200, 300],
  yMax: 300,
  legend: true,
  area: false,
  skipped: 0,
  table: {
    head: ["日付", "EC", "店舗"],
    rows: [["9/1", "¥100", "¥50"], ["9/2", "—", "¥80"], ["9/3", "¥300", "¥60"]],
  },
};

const SINGLE_LINE = Object.assign({}, LINE, {
  series: [{ key: "売上の推移", label: "売上の推移", color: 1, values: [100, 200, 300], lastLabel: "¥300" }],
  legend: false,
  area: true,
  table: { head: ["日付", "売上の推移"], rows: [["9/1", "¥100"], ["9/2", "¥200"], ["9/3", "¥300"]] },
});

function longLine_() {
  const buckets = [];
  const values = [];
  for (let i = 1; i <= 19; i += 1) {
    buckets.push({ key: "2026-09-" + (i < 10 ? "0" + i : i), label: "9/" + i });
    values.push(i * 100);
  }
  return Object.assign({}, SINGLE_LINE, {
    buckets,
    series: [{ key: "売上", label: "売上", color: 1, values, lastLabel: "¥1,900" }],
    ticks: [0, 500, 1000, 1500, 2000],
    yMax: 2000,
  });
}

const BAR = {
  id: "w3",
  type: "bar",
  title: "カテゴリ別の売上",
  size: "m",
  format: "yen",
  note: "",
  empty: false,
  horizontal: false,
  categories: [
    {
      key: "コーヒー豆",
      label: "コーヒー豆",
      total: 300,
      totalText: "¥300",
      posTotal: 300,
      negTotal: 0,
      segments: [{ key: "コーヒー豆", label: "コーヒー豆", color: 1, value: 300, valueText: "¥300" }],
    },
    {
      key: "菓子",
      label: "菓子",
      total: 100,
      totalText: "¥100",
      posTotal: 100,
      negTotal: 0,
      segments: [{ key: "菓子", label: "菓子", color: 1, value: 100, valueText: "¥100" }],
    },
  ],
  ticks: [0, 100, 200, 300],
  min: 0,
  max: 300,
  legend: false,
  skipped: 0,
  table: { head: ["カテゴリ", "カテゴリ別の売上"], rows: [["コーヒー豆", "¥300"], ["菓子", "¥100"]] },
};

/** 0 をまたぐ積み上げ（正 2 面・負 1 面） */
const SIGNED_BAR = Object.assign({}, BAR, {
  title: "部門別の増減",
  categories: [
    {
      key: "部門A",
      label: "部門A",
      total: 100,
      totalText: "¥100",
      posTotal: 300,
      negTotal: -200,
      segments: [
        { key: "入金", label: "入金", color: 1, value: 200, valueText: "¥200" },
        { key: "調整", label: "調整", color: 2, value: 100, valueText: "¥100" },
        { key: "返金", label: "返金", color: 3, value: -200, valueText: "-¥200" },
      ],
    },
  ],
  ticks: [-200, -100, 0, 100, 200, 300],
  min: -200,
  max: 300,
  legend: true,
  table: { head: ["区分", "入金", "調整", "返金"], rows: [["部門A", "¥200", "¥100", "-¥200"]] },
});

const METER = {
  id: "w4",
  type: "meter",
  title: "今月の目標",
  size: "m",
  format: "yen",
  note: "",
  valueText: "¥3.5万",
  valueFull: "¥35,100",
  targetText: "¥5万",
  targetFull: "¥50,000",
  ratio: 0.702,
  ratioText: "70%",
  achieved: false,
  skipped: 0,
  monthLabel: "2026年9月",
  table: { head: ["項目", "値"], rows: [["対象の月", "2026年9月"], ["実績", "¥35,100"], ["目標", "¥50,000"], ["達成率", "70%"]] },
};

const TABLE = {
  id: "w5",
  type: "table",
  title: "商品別",
  size: "l",
  format: "number",
  note: "",
  empty: false,
  head: [
    { label: "商品", numeric: false },
    { label: "売上", numeric: true },
  ],
  rows: [
    [{ text: "深煎り", value: "深煎り" }, { text: "¥7,500", value: 7500 }],
    [{ text: "浅煎り", value: "浅煎り" }, { text: "—", value: null }],
    [{ text: "詰め合わせ", value: "詰め合わせ" }, { text: "¥3,000", value: 3000 }],
  ],
  sortable: true,
  csv: [["商品", "売上"], ["深煎り", "7500"], ["浅煎り", ""], ["詰め合わせ", "3000"]],
  skipped: 0,
  table: { head: ["商品", "売上"], rows: [["深煎り", "¥7,500"], ["浅煎り", "—"], ["詰め合わせ", "¥3,000"]] },
};

// ---- svg.js ---------------------------------------------------------------

test("scaleLinear: 値を描く範囲に移す（幅が 0 なら端に寄せる）", () => {
  const y = scaleLinear([0, 100], [280, 0]);
  assert.equal(y(0), 280);
  assert.equal(y(100), 0);
  assert.equal(y(50), 140);
  assert.equal(scaleLinear([5, 5], [0, 100])(5), 0);
});

test("linePath: 読めない値で線を切る（M が 2 つになる）", () => {
  const d = linePath([{ x: 0, y: 10 }, null, { x: 20, y: 30 }, { x: 30, y: 40 }]);
  assert.equal((d.match(/M /g) || []).length, 2);
  assert.equal(d, "M 0 10 L 0 10 M 20 30 L 30 40");
});

test("areaPath: 端を 0 の線まで落として閉じる", () => {
  const d = areaPath([{ x: 0, y: 10 }, { x: 10, y: 20 }], 100);
  assert.equal(d, "M 0 100 L 0 10 L 10 20 L 10 100 Z");
});

test("roundedBar: 値の側だけ 4px の角丸にし、根元は四角のまま", () => {
  const top = roundedBar({ x: 10, y: 20, width: 24, height: 100, radius: 4, side: "top" });
  assert.equal(top, "M 10 120 L 10 24 A 4 4 0 0 1 14 20 L 30 20 A 4 4 0 0 1 34 24 L 34 120 Z");
  assert.equal((top.match(/A /g) || []).length, 2, "丸いのは値の側の 2 つの角だけ");

  const bottom = roundedBar({ x: 10, y: 20, width: 24, height: 100, radius: 4, side: "bottom" });
  assert.equal(bottom, "M 10 20 L 10 116 A 4 4 0 0 0 14 120 L 30 120 A 4 4 0 0 0 34 116 L 34 20 Z");

  const right = roundedBar({ x: 10, y: 20, width: 100, height: 24, radius: 4, side: "right" });
  assert.equal(right, "M 10 20 L 106 20 A 4 4 0 0 1 110 24 L 110 40 A 4 4 0 0 1 106 44 L 10 44 Z");

  const left = roundedBar({ x: 10, y: 20, width: 100, height: 24, radius: 4, side: "left" });
  assert.equal(left, "M 110 20 L 14 20 A 4 4 0 0 0 10 24 L 10 40 A 4 4 0 0 0 14 44 L 110 44 Z");

  const flat = roundedBar({ x: 10, y: 20, width: 24, height: 100, radius: 0, side: "top" });
  assert.equal(flat, "M 10 120 L 10 20 L 34 20 L 34 120 Z");
  assert.equal(flat.indexOf("A"), -1, "角丸が 0 のときは丸みの命令を書かない");
});

test("roundedBar: 角丸は棒の半分までに収める", () => {
  const tiny = roundedBar({ x: 0, y: 0, width: 24, height: 3, radius: 4, side: "top" });
  assert.ok(tiny.includes("A 1.5 1.5"), "低い棒では角丸を小さくする");
});

// ---- kpi ------------------------------------------------------------------

test("renderKpi: 大きな数・差・小さな折れ線を出す", () => {
  const html = renderKpi(KPI, {}, "ja");
  assert.ok(html.includes("¥3.5万"));
  assert.ok(html.includes("▲"));
  assert.ok(html.includes("+63.3%"));
  assert.ok(html.includes("先月比"));
  assert.ok(html.includes("db-delta-good"));
  assert.ok(html.includes('viewBox="0 0 160 40"'), "小さな折れ線は 160×40");
  assert.ok(html.includes('aria-hidden="true"'), "小さな折れ線は読み上げない");

  const tip = tipOf_(marks_(html, "p", "db-kpi-value")[0]);
  assert.equal(tip.title, "売上");
  assert.equal(tip.rows[0].value, "¥35,100", "吹き出しは縮めない数");
});

test("renderKpi: 良い・悪い・変わらない・差なしで札が変わる", () => {
  const bad = renderKpi(Object.assign({}, KPI, { delta: Object.assign({}, KPI.delta, { good: false }) }), {}, "ja");
  assert.ok(bad.includes("db-delta-bad"));
  assert.ok(bad.includes("▲"), "向きは色ではなく記号と符号で示す");

  const down = renderKpi(
    Object.assign({}, KPI, { delta: { text: "-3.1%", textFull: "-3.1%", direction: "down", good: false, label: "先月比" } }),
    {},
    "ja"
  );
  assert.ok(down.includes("▼"));
  assert.ok(down.includes("db-delta-bad"));

  const flat = renderKpi(
    Object.assign({}, KPI, { delta: { text: "0.0%", textFull: "0.0%", direction: "flat", good: null, label: "先月比" } }),
    {},
    "ja"
  );
  assert.ok(flat.includes("db-delta-flat"));
  assert.ok(flat.includes("—"));
  assert.equal(flat.includes("▲"), false);

  const none = renderKpi(Object.assign({}, KPI, { delta: null }), {}, "ja");
  assert.equal(none.includes("db-kpi-delta"), false, "比べる相手が無いときは差の札を置かない");
  assert.equal(none.includes("—"), false, "意味を持たない「—」を残さない");
  assert.equal(none.includes("▲"), false);
  assert.equal(none.includes("▼"), false);
});

test("renderKpi: 数に素の title を付けない（吹き出しが縮めない数を持つ）", () => {
  const html = renderKpi(KPI, {}, "ja");
  assert.equal(html.includes(' title="'), false);
  assert.ok(tipOf_(marks_(html, "p", "db-kpi-value")[0]).rows[0].value === "¥35,100");
});

test("renderKpi: 小さな折れ線が無いときは描かない", () => {
  const html = renderKpi(Object.assign({}, KPI, { spark: null }), {}, "ja");
  assert.equal(html.includes("<svg"), false);
});

// ---- line -----------------------------------------------------------------

test("renderLine: 640×280 の枠に、系列の数だけ線を引く", () => {
  const html = renderLine(LINE, {}, "ja");
  assert.ok(html.includes('viewBox="0 0 640 280"'));
  assert.ok(html.includes('width="100%"'));
  assert.ok(html.includes('preserveAspectRatio="xMidYMid meet"'));
  const lines = marks_(html, "path", "db-line");
  assert.equal(lines.length, 2);
  assert.ok(attr_(lines[0], "class").includes("db-s1"));
  assert.ok(attr_(lines[1], "class").includes("db-s2"));
  assert.equal(attr_(lines[0], "stroke-width"), "2");
  assert.equal(attr_(lines[0], "stroke-linejoin"), "round");
});

test("renderLine: 読めない値で線が切れる（つながない）", () => {
  const html = renderLine(LINE, {}, "ja");
  const ec = attr_(marks_(html, "path", "db-line")[0], "d");
  assert.equal((ec.match(/M /g) || []).length, 2, "EC の線は 2 本に分かれる");
});

test("renderLine: 1 系列は面を敷いて凡例を出さない。2 系列は面を敷かず凡例を出す", () => {
  const single = renderLine(SINGLE_LINE, {}, "ja");
  assert.equal(marks_(single, "path", "db-area").length, 1);
  assert.equal(single.includes("db-legend"), false);

  const multi = renderLine(LINE, {}, "ja");
  assert.equal(marks_(multi, "path", "db-area").length, 0);
  assert.ok(multi.includes("db-legend"));
  assert.ok(multi.includes(">EC<"));
  assert.ok(multi.includes(">店舗<"));
});

test("renderLine: 直接ラベルは系列の端だけ（全部の点に数字を置かない）", () => {
  const html = renderLine(LINE, {}, "ja");
  const labels = marks_(html, "text", "db-mark-label");
  assert.equal(labels.length, 2, "系列ごとに 1 つまで");
  assert.ok(html.includes(">¥300<"));
  assert.ok(html.includes(">¥60<"));
});

test("renderLine: 端の点は r=4 に 2px の地色の輪", () => {
  const html = renderLine(LINE, {}, "ja");
  const points = marks_(html, "circle", "db-point");
  assert.equal(points.length, 2);
  assert.equal(attr_(points[0], "r"), "4");
  assert.equal(attr_(points[0], "stroke-width"), "2");
  assert.equal(attr_(points[0], "stroke"), "var(--db-card)");
});

test("renderLine: 刻みごとの当たり判定の帯が、その刻みの全系列を 1 つの吹き出しに出す", () => {
  const html = renderLine(LINE, {}, "ja");
  const bands = marks_(html, "rect", "db-hit");
  assert.equal(bands.length, 3);
  assert.equal(attr_(bands[0], "data-bucket"), "0");
  assert.ok(attr_(bands[0], "data-x") !== null);
  assert.equal(attr_(bands[0], "tabindex"), "0");
  assert.equal(attr_(bands[0], "role"), "img");

  const tip = tipOf_(bands[0]);
  assert.equal(tip.title, "9/1");
  assert.deepEqual(tip.rows, [
    { label: "EC", value: "¥100", color: 1 },
    { label: "店舗", value: "¥50", color: 2 },
  ]);
  assert.ok(attr_(bands[0], "aria-label").includes("¥100"), "読み上げでも同じ値が読める");
});

test("renderLine: ポインタに付いてくる縦の細い線を、隠した形で置く", () => {
  const html = renderLine(LINE, {}, "ja");
  const crosshair = marks_(html, "line", "db-crosshair");
  assert.equal(crosshair.length, 1);
  assert.equal(attr_(crosshair[0], "visibility"), "hidden");
});

test("renderLine: 刻みが多いときは、横の札を 8 つまでに間引く（両端は必ず出す）", () => {
  const html = renderLine(longLine_(), {}, "ja");
  const labels = marks_(html, "text", "db-x-label").map((tag) => tag);
  assert.ok(labels.length <= 8, "札は " + labels.length + " 個");
  assert.ok(html.includes(">9/1<"));
  assert.ok(html.includes(">9/19<"));
});

test("renderLine: 週の刻みが 27 個あっても、右端の 2 つの札が重ならない（手前を落とす）", () => {
  const buckets = [];
  const values = [];
  for (let i = 0; i < 27; i += 1) {
    buckets.push({ key: "w" + i, label: "9/" + (i + 1) + "週" });
    values.push(100 + i);
  }
  const model = Object.assign({}, SINGLE_LINE, {
    buckets,
    series: [{ key: "売上", label: "売上", color: 1, values, lastLabel: "126" }],
    ticks: [0, 50, 100, 150],
    yMax: 150,
  });
  const html = renderLine(model, {}, "ja");
  const xs = marks_(html, "text", "db-x-label").map((tag) => Number(attr_(tag, "x")));
  assert.ok(xs.length >= 3 && xs.length <= 8, "札は " + xs.length + " 個");
  const gaps = [];
  for (let i = 1; i < xs.length; i += 1) gaps.push(xs[i] - xs[i - 1]);
  const widest = Math.max(...gaps);
  const narrowest = Math.min(...gaps);
  // 右端だけ極端に詰まっていないこと（いちばん狭い間が、いちばん広い間の 6 割以上）
  assert.ok(narrowest >= widest * 0.6, "間: " + gaps.map((g) => g.toFixed(1)).join(", "));
  assert.ok(html.includes(">9/27週<"), "最後の札は必ず出す");
});

test("renderLine: 目盛り線は 1px の実線（破線にしない）", () => {
  const html = renderLine(LINE, {}, "ja");
  const grid = marks_(html, "line", "db-grid-line");
  assert.ok(grid.length >= 3);
  assert.equal(html.includes("stroke-dasharray"), false);
});

test("renderLine: データが無いときは、軸を描かずにお知らせを出す", () => {
  const html = renderLine(Object.assign({}, LINE, { empty: true, series: [], buckets: [] }), {}, "ja");
  assert.equal(html.includes("<svg"), false);
  assert.ok(html.includes("データがありません"));
});

test("renderLine: 英語のときは英語の文にする", () => {
  const html = renderLine(Object.assign({}, LINE, { empty: true, series: [], buckets: [] }), {}, "en");
  assert.ok(html.includes("No data for this period"));
});

// ---- bar ------------------------------------------------------------------

test("renderBar: 棒は太さ 24px まで・値の側だけ角丸", () => {
  const html = renderBar(BAR, {}, "ja");
  const bars = marks_(html, "path", "db-bar");
  assert.equal(bars.length, 2);
  for (const bar of bars) {
    const d = attr_(bar, "d");
    assert.equal((d.match(/A /g) || []).length, 2, "丸いのは値の側の 2 つの角だけ");
    assert.ok(d.includes("A 4 4 0 0 1"), "縦の棒は上を丸める");
  }
  assert.ok(html.includes('viewBox="0 0 640 280"'));
});

test("renderBar: 0 をまたぐ積み上げは、正を上・負を下に伸ばす", () => {
  const html = renderBar(SIGNED_BAR, {}, "ja");
  const zero = marks_(html, "line", "db-axis-zero");
  assert.equal(zero.length, 1);
  const zeroY = Number(attr_(zero[0], "y1"));

  const bars = marks_(html, "path", "db-bar").map(barEdges_);
  assert.equal(bars.length, 3);
  assert.equal(bars[0].y1, zeroY, "いちばん内側の正の面は 0 の線から始まる");
  assert.ok(bars[0].y2 < zeroY, "正は上へ伸びる");
  assert.ok(bars[1].y2 < bars[0].y2, "積み上げは外へ続く");
  assert.equal(bars[2].y1, zeroY, "負の面も 0 の線から始まる");
  assert.ok(bars[2].y2 > zeroY, "負は下へ伸びる");

  const shapes = marks_(html, "path", "db-bar").map((tag) => attr_(tag, "d"));
  assert.ok(shapes[1].includes("A 4 4 0 0 1"), "いちばん外の正の面だけ上を丸める");
  assert.equal(shapes[0].indexOf("A"), -1, "内側の面は丸めない");
  assert.ok(shapes[2].includes("A 4 4 0 0 0"), "負の面は反対の側を丸める");
});

test("renderBar: 隣り合う面のあいだに 2px の地色のすき間を空ける", () => {
  const bars = marks_(renderBar(SIGNED_BAR, {}, "ja"), "path", "db-bar").map(barEdges_);
  assert.equal(Math.round((bars[0].y2 - bars[1].y1) * 100) / 100, 2);
});

test("renderBar: 区分ごとの当たり判定は帯の幅いっぱいで、面と合計を 1 つの吹き出しに出す", () => {
  const html = renderBar(SIGNED_BAR, {}, "ja");
  const hits = marks_(html, "rect", "db-hit");
  assert.equal(hits.length, 1);
  assert.equal(attr_(hits[0], "data-category"), "0");
  assert.equal(attr_(hits[0], "tabindex"), "0");

  const tip = tipOf_(hits[0]);
  assert.equal(tip.title, "部門A");
  assert.deepEqual(tip.rows, [
    { label: "入金", value: "¥200", color: 1 },
    { label: "調整", value: "¥100", color: 2 },
    { label: "返金", value: "-¥200", color: 3 },
    { label: "合計", value: "¥100", color: null },
  ]);
});

test("renderBar: 面が 1 つだけの棒は、吹き出しに合計を重ねて出さない", () => {
  const tip = tipOf_(marks_(renderBar(BAR, {}, "ja"), "rect", "db-hit")[0]);
  assert.deepEqual(tip.rows, [{ label: "コーヒー豆", value: "¥300", color: 1 }]);
});

test("renderBar: 縦のときは区分名を下に、横のときは左に置く", () => {
  const vertical = renderBar(BAR, {}, "ja");
  const verticalGrid = marks_(vertical, "line", "db-grid-line");
  assert.equal(attr_(verticalGrid[0], "y1"), attr_(verticalGrid[0], "y2"), "縦の棒の目盛り線は横に引く");
  assert.ok(marks_(vertical, "text", "db-x-label").length >= 2);

  const horizontal = renderBar(Object.assign({}, BAR, { horizontal: true }), {}, "ja");
  const horizontalGrid = marks_(horizontal, "line", "db-grid-line");
  assert.equal(attr_(horizontalGrid[0], "x1"), attr_(horizontalGrid[0], "x2"), "横の棒の目盛り線は縦に引く");
  const names = marks_(horizontal, "text", "db-y-label");
  assert.equal(names.length, 2);
  assert.equal(attr_(names[0], "text-anchor"), "end");
  const bars = marks_(horizontal, "path", "db-bar");
  assert.ok(attr_(bars[0], "d").includes("A 4 4 0 0 1"), "横の棒は右を丸める");
});

test("renderBar: 長い区分名は「…」で短くし、元の文字は吹き出しに残す", () => {
  const long = "とてもとても長い区分の名前をここに書きます";
  const model = Object.assign({}, BAR, {
    horizontal: true,
    categories: [Object.assign({}, BAR.categories[0], { key: long, label: long })],
  });
  const html = renderBar(model, {}, "ja");
  assert.ok(html.includes("…"));
  assert.equal(html.includes(">" + long + "<"), false);
  assert.equal(tipOf_(marks_(html, "rect", "db-hit")[0]).title, long);
});

test("renderBar: 先端の札は、収まるときだけ棒の外に出す", () => {
  const html = renderBar(BAR, {}, "ja");
  const labels = marks_(html, "text", "db-mark-label");
  assert.equal(labels.length, 2);
  assert.ok(html.includes(">¥300<"));
});

test("renderBar: データが無いときは、軸を描かずにお知らせを出す", () => {
  const html = renderBar(Object.assign({}, BAR, { empty: true, categories: [] }), {}, "ja");
  assert.equal(html.includes("<svg"), false);
  assert.ok(html.includes("データがありません"));
});

// ---- meter ----------------------------------------------------------------

test("renderMeter: 値と目標と進みを出す", () => {
  const html = renderMeter(METER, {}, "ja");
  assert.ok(html.includes("¥3.5万"));
  assert.ok(html.includes("¥5万"));
  assert.ok(html.includes("70%"));
  const fill = marks_(html, "div", "db-meter-fill")[0];
  assert.ok(attr_(fill, "style").includes("70.2%"));
  const track = marks_(html, "div", "db-meter-track")[0];
  assert.equal(attr_(track, "role"), "img");
  assert.ok(attr_(track, "aria-label").includes("¥50,000"));
});

test("renderMeter: 100% を超えても帯からはみ出さず、達成と出す", () => {
  const html = renderMeter(Object.assign({}, METER, { ratio: 1.17, ratioText: "117%", achieved: true }), {}, "ja");
  const fill = marks_(html, "div", "db-meter-fill")[0];
  assert.ok(attr_(fill, "style").includes("100%"));
  assert.ok(html.includes("達成"));
  assert.ok(html.includes("117%"));
});

test("renderMeter: 英語のときは英語の札にする", () => {
  const html = renderMeter(Object.assign({}, METER, { achieved: true, ratioText: "117%" }), {}, "en");
  assert.ok(html.includes("Goal reached"));
});

test("renderMeter: 月の目標のときは、対象の月を値のとなりに小さく出す", () => {
  const html = renderMeter(METER, {}, "ja");
  const month = marks_(html, "span", "db-meter-month")[0];
  assert.ok(month, "対象の月が出ていない");
  assert.ok(html.includes(">2026年9月<"));
  const track = marks_(html, "div", "db-meter-track")[0];
  assert.ok(attr_(track, "aria-label").includes("2026年9月"), "読み上げにも月を入れる");
  assert.ok(attr_(track, "aria-label").includes("対象の月"), "読み上げに月の見出しを入れる");
  assert.ok(attr_(track, "data-tip").includes("2026"), "吹き出しにも月を入れる");
});

test("renderMeter: 対象の月も、そのまま字として出す（記号は実体参照にする）", () => {
  const html = renderMeter(Object.assign({}, METER, { monthLabel: '<b>"9月"</b>' }), {}, "ja");
  assert.equal(html.includes("<b>"), false, "生の札を出さない");
  assert.ok(html.includes("&lt;b&gt;&quot;9月&quot;&lt;/b&gt;"));
});

test("renderMeter: 目標が数のときは、対象の月を出さない", () => {
  const html = renderMeter(Object.assign({}, METER, { monthLabel: "" }), {}, "ja");
  assert.equal(html.includes("db-meter-month"), false);
  const track = marks_(html, "div", "db-meter-track")[0];
  assert.equal(attr_(track, "aria-label").includes("対象の月"), false);
});

// ---- table ----------------------------------------------------------------

test("renderTable: 数の列は右寄せにし、見出しは並べ替えの押しボタンにする", () => {
  const html = renderTable(TABLE, { sort: {} }, "ja");
  assert.ok(html.includes('<table class="db-table"'));
  assert.ok(html.includes('data-action="sort"'));
  assert.ok(html.includes('data-column="1"'));
  assert.ok(html.includes('aria-sort="none"'));
  assert.ok(html.includes('<td class="db-num"'));
});

test("renderTable: 並べ替えは大きい順・小さい順ともに、読めない値をいつも最後にする", () => {
  const desc = renderTable(TABLE, { sort: { w5: { column: 1, order: "desc" } } }, "ja");
  assert.deepEqual(desc.match(/>(深煎り|浅煎り|詰め合わせ)</g), [">深煎り<", ">詰め合わせ<", ">浅煎り<"]);
  assert.ok(desc.includes('aria-sort="descending"'));

  const asc = renderTable(TABLE, { sort: { w5: { column: 1, order: "asc" } } }, "ja");
  assert.deepEqual(asc.match(/>(深煎り|浅煎り|詰め合わせ)</g), [">詰め合わせ<", ">深煎り<", ">浅煎り<"]);
  assert.ok(asc.includes('aria-sort="ascending"'));

  const none = renderTable(TABLE, { sort: {} }, "ja");
  assert.deepEqual(none.match(/>(深煎り|浅煎り|詰め合わせ)</g), [">深煎り<", ">浅煎り<", ">詰め合わせ<"]);
});

test("renderTable: 行は読み上げに表のまま渡す（role も tabindex も付けない）", () => {
  const html = renderTable(TABLE, { sort: {} }, "ja");
  const rows = marks_(html, "tr", "db-row");
  assert.equal(rows.length, 3);
  for (const row of rows) {
    assert.equal(attr_(row, "role"), null);
    assert.equal(attr_(row, "tabindex"), null);
    assert.equal(attr_(row, "data-tip"), null);
    assert.equal(attr_(row, "aria-label"), null);
  }
  assert.equal(html.includes('role="img"'), false, "表を図として包むと、マスと列のつながりが読み上げから消える");
  assert.equal(html.includes("tabindex"), false);
  assert.ok(html.includes(">¥7,500</td>"), "値はマスの文字としてそのまま読める");
});

test("renderDataTable: 「表で見る」の行にも role も tabindex も付けない", () => {
  const html = renderDataTable(LINE, {}, "ja");
  assert.equal(html.includes('role="img"'), false);
  assert.equal(html.includes("tabindex"), false);
  assert.equal(html.includes("data-tip"), false);
});

test("renderDataTable: 表を持たない model でも落とさず、お知らせを出す", () => {
  const html = renderDataTable({ id: "w9", type: "kpi", title: "売上" }, {}, "ja");
  assert.ok(html.includes("データがありません"));
  assert.equal(renderDataTable({ id: "w9", table: { head: ["日付"] } }, {}, "ja").includes("データがありません"), true);
  assert.equal(renderDataTable(null, {}, "en").includes("No data for this period"), true);
});

test("renderTable・renderCsvButton: 部品の名前は属性として安全な文字にする", () => {
  const model = Object.assign({}, TABLE, { id: 'w5" onmouseover="x' });
  const html = renderTable(model, { sort: {} }, "ja");
  assert.equal(html.includes('onmouseover="x'), false);
  assert.ok(html.includes("&quot;"));
  assert.equal(renderCsvButton('w5" onmouseover="x', "ja").includes('onmouseover="x'), false);
});

test("renderTable: データが無いときはお知らせを出す", () => {
  const html = renderTable(Object.assign({}, TABLE, { empty: true, rows: [] }), { sort: {} }, "ja");
  assert.ok(html.includes("データがありません"));
});

test("renderDataTable: 「表で見る」は並べ替えの押しボタンを付けない", () => {
  const html = renderDataTable(LINE, {}, "ja");
  assert.ok(html.includes('<table class="db-table"'));
  assert.equal(html.includes('data-action="sort"'), false);
  assert.ok(html.includes(">9/1<"));
  assert.ok(html.includes(">¥100<"));
  assert.ok(html.includes('<td class="db-num"'), "1 列目より後ろは数の列として右寄せにする");
});

// ---- 安全 -----------------------------------------------------------------

const NASTY = '<script>alert("x")</script>';

test("危ない文字は、吹き出しや読み上げの中でも実体参照にする", () => {
  const model = Object.assign({}, BAR, {
    title: NASTY,
    categories: [
      Object.assign({}, BAR.categories[0], {
        key: NASTY,
        label: NASTY,
        segments: [{ key: NASTY, label: NASTY, color: 1, value: 300, valueText: "¥300" }],
      }),
    ],
    table: { head: ["区分", NASTY], rows: [[NASTY, "¥300"]] },
  });
  for (const html of [renderBar(model, {}, "ja"), renderDataTable(model, {}, "ja")]) {
    assert.equal(html.includes("<script"), false);
    assert.equal(html.includes('alert("x")'), false);
    assert.ok(html.includes("&lt;script&gt;"));
  }
  const tip = tipOf_(marks_(renderBar(model, {}, "ja"), "rect", "db-hit")[0]);
  assert.equal(tip.title, NASTY, "吹き出しの中身は元の文字に戻る");
});

test("危ない文字は、折れ線の系列名でも実体参照にする", () => {
  const model = Object.assign({}, LINE, {
    series: [Object.assign({}, LINE.series[0], { key: NASTY, label: NASTY })].concat(LINE.series[1]),
  });
  const html = renderLine(model, {}, "ja");
  assert.equal(html.includes("<script"), false);
  assert.ok(html.includes("&lt;script&gt;"));
  assert.equal(tipOf_(marks_(html, "rect", "db-hit")[0]).rows[0].label, NASTY);
});

// ---- 棒の札の場所どり -----------------------------------------------------

/** <text> の中身だけを取り出す */
function texts_(html, className) {
  const found = html.match(new RegExp('<text class="' + className + '[^"]*"[^>]*>([^<]*)</text>', "g")) || [];
  return found.map((tag) => tag.replace(/^[^>]*>/, "").replace(/<\/text>$/, ""));
}

function viewBoxHeight_(html) {
  return Number(html.match(/viewBox="0 0 640 ([\d.]+)"/)[1]);
}

/** 区分名と合計の並びから、1 面だけの棒の model を作る */
function barOf_(entries, options) {
  const opts = options || {};
  const categories = entries.map(([label, total]) => ({
    key: label,
    label,
    total,
    totalText: (total < 0 ? "-¥" : "¥") + Math.abs(total).toLocaleString("en-US"),
    posTotal: total > 0 ? total : 0,
    negTotal: total < 0 ? total : 0,
    segments: [{ key: label, label, color: 1, value: total, valueText: String(total) }],
  }));
  let min = 0;
  let max = 0;
  for (const [, total] of entries) {
    if (total < min) min = total;
    if (total > max) max = total;
  }
  const step = (max - min) / 4 || 1;
  const ticks = [];
  for (let i = 0; i <= 4; i += 1) ticks.push(Math.round(min + step * i));
  return Object.assign({}, BAR, {
    categories,
    ticks,
    min: ticks[0],
    max: ticks[ticks.length - 1],
    legend: false,
    horizontal: opts.horizontal === true,
    table: { head: ["区分", "値"], rows: entries.map(([label, total]) => [label, String(total)]) },
  });
}

/** count 個の区分（名前は name(i)、値は大きい順） */
function entriesOf_(count, name, sign) {
  const entries = [];
  for (let i = 0; i < count; i += 1) entries.push([name(i), (sign || 1) * (count - i) * 1000]);
  return entries;
}

test("renderBar: すべてが負の縦棒でも、値の札が区分名の行とぶつからない", () => {
  const html = renderBar(barOf_([["部門A", -5000], ["部門B", -3000], ["部門C", -1000]]), {}, "ja");
  const names = marks_(html, "text", "db-x-label");
  const values = marks_(html, "text", "db-mark-label");
  assert.equal(names.length, 3, "区分名は 3 つとも出す");
  assert.equal(values.length, 3, "値の札も 3 つとも出す");

  const row = Number(attr_(names[0], "y"));
  for (const name of names) assert.equal(Number(attr_(name, "y")), row, "区分名はいつも図の下の 1 行に並ぶ");
  for (const value of values) {
    assert.ok(row - Number(attr_(value, "y")) >= 16, "値の札は区分名の行から 16 以上離す（y=" + attr_(value, "y") + "）");
  }
  assert.ok(row <= 280 - 4, "区分名の行は図の中に収まる");
  assert.ok(viewBoxHeight_(html) === 280, "縦棒は 640×280 のまま");
});

test("renderBar: 0 をまたぐ区分には先端の札を置かず、正味は吹き出しと表で読ませる", () => {
  const html = renderBar(SIGNED_BAR, {}, "ja");
  assert.equal(marks_(html, "text", "db-mark-label").length, 0, "正と負が混ざる区分に「合計」の札を置かない");

  const tip = tipOf_(marks_(html, "rect", "db-hit")[0]);
  assert.deepEqual(tip.rows[tip.rows.length - 1], { label: "合計", value: "¥100", color: null });
  const en = tipOf_(marks_(renderBar(SIGNED_BAR, {}, "en"), "rect", "db-hit")[0]);
  assert.equal(en.rows[en.rows.length - 1].label, "Total");
});

test("renderBar: 符号が片側だけの区分は、0 をまたぐ図の中でも先端の札を持つ", () => {
  const plain = Object.assign({}, BAR.categories[0], { key: "部門B", label: "部門B", totalText: "¥300" });
  const model = Object.assign({}, SIGNED_BAR, { categories: SIGNED_BAR.categories.concat([plain]) });
  assert.deepEqual(texts_(renderBar(model, {}, "ja"), "db-mark-label"), ["¥300"]);
});

test("renderBar: 先端の札が隣とぶつかるときは、大きい正と小さい負だけを残す", () => {
  const many = barOf_(entriesOf_(12, (i) => "区分" + i));
  assert.deepEqual(texts_(renderBar(many, {}, "ja"), "db-mark-label"), ["¥12,000"]);

  const mixed = barOf_(entriesOf_(11, (i) => "区分" + i).concat([["部門Z", -9000]]));
  assert.deepEqual(texts_(renderBar(mixed, {}, "ja"), "db-mark-label"), ["¥11,000", "-¥9,000"]);

  const few = barOf_(entriesOf_(3, (i) => "区分" + i));
  assert.equal(texts_(renderBar(few, {}, "ja"), "db-mark-label").length, 3, "ゆとりがあるときは全部に付ける");
});

test("renderBar: 横棒は区分が増えると図の縦も伸び、区分名は 24 以上あけて全部出す", () => {
  for (const count of [9, 14, 20]) {
    const model = barOf_(entriesOf_(count, (i) => "部門" + (i + 1)), { horizontal: true });
    const html = renderBar(model, {}, "ja");
    assert.equal(viewBoxHeight_(html), 38 + count * 28, count + " 区分の図の高さ");

    const names = marks_(html, "text", "db-y-label");
    assert.equal(names.length, count, count + " 区分の名前をすべて出す");
    for (let i = 1; i < names.length; i += 1) {
      const pitch = Number(attr_(names[i], "y")) - Number(attr_(names[i - 1], "y"));
      assert.ok(pitch >= 24, count + " 区分の札の間隔は " + pitch);
    }
    assert.deepEqual(texts_(html, "db-y-label"), model.categories.map((c) => c.label), "名前は短くせずに出す");

    const bars = marks_(html, "path", "db-bar");
    assert.equal(bars.length, count);
  }

  const small = barOf_(entriesOf_(6, (i) => "部門" + (i + 1)), { horizontal: true });
  assert.equal(viewBoxHeight_(renderBar(small, {}, "ja")), 280, "区分が少ないうちは 280 のまま");
});

test("renderBar: 縦のままで名前が収まらないときは、切れ端を並べずに間引く", () => {
  const long = barOf_(entriesOf_(8, (i) => "みなと市中央区の店舗" + (i + 1)));
  const html = renderBar(long, {}, "ja");
  const names = texts_(html, "db-x-label");

  assert.ok(names.length >= 1);
  assert.ok(names.length < 8, "置けないときは間引く（" + names.length + " 個）");
  assert.equal(new Set(names).size, names.length, "見分けのつかない同じ札を並べない");
  for (const name of names) {
    assert.ok(Array.from(name.replace("…", "")).length >= 4, "全角 4 字より短い切れ端にしない（" + name + "）");
    assert.ok(long.categories.some((category) => category.label.startsWith(name.replace("…", ""))));
  }
  const tips = marks_(html, "rect", "db-hit").map((tag) => tipOf_(tag).title);
  assert.deepEqual(tips, long.categories.map((category) => category.label), "元の名前は吹き出しに残る");
});

test("renderBar: 半角の名前は全角と同じだけ削らない（幅で短くする）", () => {
  const ascii = barOf_(entriesOf_(8, (i) => "Harbourside Store " + (i + 1)));
  for (const name of texts_(renderBar(ascii, {}, "ja"), "db-x-label")) {
    assert.ok(Array.from(name).length > 8, "半角は字数ではなく幅で切る（" + name + "）");
  }
});

// ---- 刻みが 1 個だけの折れ線（コード審査 C1） -------------------------------

const ONE_BUCKET_LINE = {
  id: "w9",
  type: "line",
  title: "売上の推移",
  size: "l",
  format: "yen",
  note: "",
  limitNote: "",
  empty: false,
  series: [{ key: "売上", label: "売上", color: 1, values: [200000], lastLabel: "¥20万" }],
  buckets: [{ key: "2026-09-01", label: "9/1" }],
  ticks: [0, 50000, 100000, 150000, 200000],
  yMax: 200000,
  legend: false,
  area: true,
  skipped: 0,
  table: { head: ["日付", "売上"], rows: [["9/1", "¥200,000"]] },
};

test("折れ線: 刻みが 1 個だけでも、端の点と札と目盛りが出る", () => {
  const html = renderLine(ONE_BUCKET_LINE, {}, "ja");

  const points = marks_(html, "circle", "db-point");
  assert.equal(points.length, 1, "端の点が 1 つ出る");
  const cx = Number(attr_(points[0], "cx"));
  const cy = Number(attr_(points[0], "cy"));
  assert.ok(cx > 0 && cx < 640, "点が図の横幅の中にある: " + cx);
  assert.ok(cy > 0 && cy < 280, "点が図のたての中にある: " + cy);
  assert.equal(attr_(points[0], "r"), "4");

  assert.ok(html.includes(">¥20万</text>"), "端の直接ラベルが出る");
  assert.ok(html.includes(">9/1</text>"), "刻みの札が出る");

  // 目盛りの札は 0 と上端をふくむ（[0, 1] の軸になっていない）
  assert.ok(html.includes(">¥0</text>"));
  assert.ok(html.includes(">¥10万</text>"));
  assert.equal(marks_(html, "line", "db-grid-line").length + marks_(html, "line", "db-axis-zero").length, 5, "目盛り線は 5 本");

  // 当たり判定の帯は、1 個でも図の幅いっぱいにとる
  const bands = marks_(html, "rect", "db-hit");
  assert.equal(bands.length, 1);
  assert.ok(Number(attr_(bands[0], "width")) > 300, "帯の幅 " + attr_(bands[0], "width"));
});

test("折れ線: 刻みが 1 個でも、面（1 系列のときの薄い敷き）が描ける", () => {
  const html = renderLine(ONE_BUCKET_LINE, {}, "ja");
  const areas = marks_(html, "path", "db-area");
  assert.equal(areas.length, 1);
  assert.ok(attr_(areas[0], "d").length > 0, "面の道すじが空でない");
});

test("折れ線: 刻みを上限で切ったときは、その知らせを札の下に出す", () => {
  const model = Object.assign({}, ONE_BUCKET_LINE, { limitNote: "期間が長いため、新しいほうから 400 個の区切りだけを表示しています" });
  const html = renderWidgetFrame(model, renderLine(model, {}, "ja"), {}, "ja");
  assert.ok(html.includes("新しいほうから 400 個の区切りだけ"), "知らせが出る");
});
