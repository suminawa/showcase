import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { api_bootstrap, doGet } from "../src/gas/gas_web.js";
import { menu_check, menu_init, menu_samples, menu_url, onOpen } from "../src/gas/gas_main.js";
import { GAS_ROW_LIMIT_, gasCellForTransport_, gasHasDataRows_, gasReadDataset_, gasWriteSheet_ } from "../src/gas/gas_sheets.js";
import { sourceGasCreate_ } from "../src/ui/source-gas.js";
import { sampleSheets } from "../src/core/samples.js";
import { parseConfig, configFromSheets, configSheetNotes } from "../src/core/config.js";
import { rowsToObjects } from "../src/core/csv.js";
import { coerceRows, inferTypes, limitRows } from "../src/core/table.js";
import { buildDashboard } from "../src/core/model.js";

import {
  MANIFEST_,
  OWNER_,
  SPREADSHEET_TIME_ZONE_,
  createGasFakes,
  fakeFormatDate_,
  scriptRunTransport_,
  typeInto_,
  zonedMidnight_,
} from "./helpers/gas-fakes.mjs";

const TODAY_ = "2026-09-30";

// ---- 偽の GAS（test/helpers/gas-fakes.mjs）を globalThis に置く ---------------

/** 偽の GAS 一式を globalThis に置く。後片づけは restore_() で行う */
function installGas_(options) {
  const made = createGasFakes(options);
  const saved = {};
  for (const name of Object.keys(made.globals)) {
    saved[name] = globalThis[name];
    globalThis[name] = made.globals[name];
  }
  const savedConsole = globalThis.console;
  globalThis.console = Object.assign({}, savedConsole, { error: (...args) => made.trace.errors.push(args[0]) });
  return Object.assign(made, {
    restore_: () => {
      for (const name of Object.keys(made.globals)) {
        if (saved[name] === undefined) delete globalThis[name];
        else globalThis[name] = saved[name];
      }
      globalThis.console = savedConsole;
    },
  });
}

/** 偽の GAS を置いて run を動かし、必ず後片づけする */
function withGas_(options, run) {
  const gas = installGas_(options);
  try {
    return run(gas);
  } finally {
    gas.restore_();
  }
}

// ---- 見本のシートを、実機と同じ姿（日付は Date、空欄は空文字）にする ----------

/** 暦の日付の文字を、スプレッドシートの時間帯のその日 0 時にあたる Date にする */
function asDate_(dateKey) {
  return zonedMidnight_(dateKey, SPREADSHEET_TIME_ZONE_);
}

/** 見本の売上・目標を、実機の getValues() が返す姿に直す（日付の列だけ Date にする） */
function sheetWithDates_(matrix) {
  return matrix.map((row, index) => (index === 0 ? row.slice() : [asDate_(row[0])].concat(row.slice(1))));
}

function sampleSeed_() {
  const sample = sampleSheets(TODAY_, "ja");
  return {
    設定: sample.settings,
    定義: sample.definitions,
    売上: sheetWithDates_(sample.data["売上"]),
    目標: sample.data["目標"].map((row) => row.slice()),
  };
}

/** 入れ子のどこかに Date が残っていないかを歩いて調べる */
function findDate_(value, path) {
  if (value instanceof Date) return path;
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i += 1) {
      const found = findDate_(value[i], path + "[" + i + "]");
      if (found !== null) return found;
    }
    return null;
  }
  if (value !== null && typeof value === "object") {
    for (const key of Object.keys(value)) {
      const found = findDate_(value[key], path + "." + key);
      if (found !== null) return found;
    }
  }
  return null;
}

// ---- api_bootstrap ---------------------------------------------------------

test("api_bootstrap: 見本のシートから、設定とデータをそのまま渡す", () => {
  withGas_({ sheets: sampleSeed_() }, () => {
    const result = api_bootstrap();

    assert.equal(result.ok, true);
    assert.deepEqual(result.missing, []);
    assert.deepEqual(result.truncated, []);
    assert.deepEqual(Object.keys(result.datasets).sort(), ["売上", "目標"]);
    assert.equal(result.config.title, "しおかぜ珈琲店 売上ダッシュボード");
    assert.equal(result.config.widgets.length, 10);

    const parsed = parseConfig(result.config);
    assert.deepEqual(parsed.errors, [], "見本の設定に誤りがあってはならない");
  });
});

test("api_bootstrap: 日付のマスは YYYY-MM-DD の文字になり、返り値に Date が残らない", () => {
  withGas_({ sheets: sampleSeed_() }, () => {
    const result = api_bootstrap();
    const sales = result.datasets["売上"];

    assert.deepEqual(sales[0], ["日付", "チャネル", "カテゴリ", "商品", "数量", "金額"]);
    assert.equal(sales[1][0], sampleSheets(TODAY_, "ja").data["売上"][1][0]);
    assert.match(sales[1][0], /^\d{4}-\d{2}-\d{2}$/);
    assert.equal(typeof sales[1][4], "number", "数はそのまま数で渡すはず");
    assert.equal(findDate_(result, "result"), null, "google.script.run は Date を運べないので、どこにも残してはならない");
  });
});

test("gasReadDataset_: 日付はスクリプトの時間帯（Asia/Tokyo）ではなく、スプレッドシートの時間帯で決まる", () => {
  // UTC 2026-09-30T02:00 は、東京では 9/30 の昼、ロサンゼルスでは 9/29 の夜（2 つの時間帯で日が違う瞬間を選ぶ）
  const at = new Date("2026-09-30T02:00:00Z");
  withGas_({ sheets: { 売上: [["日付", "金額"], [at, 1000]] }, spreadsheetTimeZone: "America/Los_Angeles" }, () => {
    const read = gasReadDataset_("売上");
    assert.equal(fakeFormatDate_(at, "Asia/Tokyo", "yyyy-MM-dd"), "2026-09-30", "自己点検: スクリプトの時間帯なら 9/30 のはず");
    assert.equal(read.rows[1][0], "2026-09-29", "スプレッドシートの時間帯（ロサンゼルス）の日付が返るはず");
  });
});

test("gasReadDataset_: スプレッドシートの時間帯が読めない・空のときは、スクリプトの時間帯に落ちる", () => {
  const at = new Date("2026-09-30T02:00:00Z");
  withGas_({ sheets: { 売上: [["日付", "金額"], [at, 1000]] }, spreadsheetTimeZoneThrows: true }, () => {
    const read = gasReadDataset_("売上");
    assert.equal(read.rows[1][0], "2026-09-30", "スクリプトの時間帯（Asia/Tokyo）に落ちるはず");
  });
  withGas_({ sheets: { 売上: [["日付", "金額"], [at, 1000]] }, spreadsheetTimeZone: "" }, () => {
    const read = gasReadDataset_("売上");
    assert.equal(read.rows[1][0], "2026-09-30", "空で読めたときも、スクリプトの時間帯に落ちるはず");
  });
});

test("gasCellForTransport_: 時刻だけのマス（1899-12-30 になる）は、日付ではなく HH:mm の文字にする", () => {
  withGas_({}, () => {
    // 時刻だけを入れたマスは、スプレッドシートの中では 1899-12-30 の Date になる
    const timeOnly = new Date(Date.UTC(1899, 11, 30, 14, 30));
    const result = gasCellForTransport_(timeOnly, "UTC");
    assert.equal(result, "14:30");
    assert.equal(/^\d{4}-/.test(result), false, "意味の無い日付にしてはならない");
  });
});

test("gasCellForTransport_: ふつうの日付はこれまでどおり YYYY-MM-DD のまま", () => {
  withGas_({}, () => {
    const result = gasCellForTransport_(new Date(Date.UTC(2026, 8, 30, 3, 0)), "UTC");
    assert.equal(result, "2026-09-30");
  });
});

test("gasWriteSheet_: clearContents() を使い、書式は消さない（clear() は呼ばない）", () => {
  withGas_({}, (gas) => {
    gasWriteSheet_("メモ", [["見出し"], ["値"]]);
    const sheet = gas.sheets.get("メモ");
    assert.equal(sheet.cleared, 1);
    assert.deepEqual(sheet.rows, [["見出し"], ["値"]]);
  });
});

test("api_bootstrap: 設定・定義のシートが無くても止めず、画面が誤りとして知らせられる形を返す", () => {
  withGas_({ sheets: {} }, () => {
    const result = api_bootstrap();

    assert.equal(result.ok, true);
    assert.deepEqual(result.datasets, {});
    assert.deepEqual(result.missing, []);

    const parsed = parseConfig(result.config);
    assert.ok(parsed.errors.length > 0, "設定の誤りとして知らせるはず");
    for (const message of parsed.errors) assert.ok(message.startsWith("dashboard: "), "誤りの文は dashboard: で始めるはず");
  });
});

test("api_bootstrap: 設定に出てくるのに無いシートは missing に入る", () => {
  const seed = sampleSeed_();
  delete seed["目標"];
  withGas_({ sheets: seed }, () => {
    const result = api_bootstrap();
    assert.deepEqual(result.missing, ["目標"]);
    assert.deepEqual(Object.keys(result.datasets), ["売上"]);
  });
});

test("api_bootstrap: 中身の無いシートは、誤りにせず空の行列として渡す", () => {
  const seed = sampleSeed_();
  seed["目標"] = [];
  withGas_({ sheets: seed }, () => {
    const result = api_bootstrap();
    assert.deepEqual(result.missing, [], "シート自体はあるので、見つからない扱いにはしない");
    assert.deepEqual(result.datasets["目標"], []);
  });
});

test("api_bootstrap: 上限を超えるシートは truncated に入り、画面が上限で切って知らせられる", () => {
  const seed = sampleSeed_();
  const rows = [["日付", "チャネル", "カテゴリ", "商品", "数量", "金額"]];
  for (let i = 0; i < GAS_ROW_LIMIT_ + 1; i += 1) rows.push([asDate_(TODAY_), "店頭", "コーヒー豆", "しおかぜブレンド", 1, 2000]);
  seed["売上"] = rows;

  withGas_({ sheets: seed }, () => {
    const result = api_bootstrap();
    assert.deepEqual(result.truncated, ["売上"]);

    const carried = result.datasets["売上"];
    assert.equal(carried.length - 1, GAS_ROW_LIMIT_ + 1, "画面が切ったと分かるよう、上限より 1 行だけ多く渡すはず");
    const limited = limitRows(rowsToObjects(carried).rows);
    assert.equal(limited.rows.length, GAS_ROW_LIMIT_);
    assert.equal(limited.truncated, true, "画面に「20,000 行までを表示しています」が出るはず");
  });
});

test("api_bootstrap: ちょうど上限の行数なら、切らずに渡す", () => {
  const seed = sampleSeed_();
  const rows = [["日付", "金額"]];
  for (let i = 0; i < GAS_ROW_LIMIT_; i += 1) rows.push([asDate_(TODAY_), 2000]);
  seed["売上"] = rows;

  withGas_({ sheets: seed }, () => {
    const result = api_bootstrap();
    assert.deepEqual(result.truncated, []);
    assert.equal(result.datasets["売上"].length - 1, GAS_ROW_LIMIT_);
  });
});

test("api_bootstrap: 思いがけない失敗は、内側の事情を出さない 1 文に包む", () => {
  withGas_({ noSpreadsheet: true }, (gas) => {
    const result = api_bootstrap();
    assert.deepEqual(result, { ok: false, message: "ただいま表示できません。しばらくしてからお試しください。" });
    assert.equal(gas.trace.errors.length, 1, "もとの理由は実行ログに残すはず");
  });
});

// ---- doGet -----------------------------------------------------------------

test("doGet: App.html に、設定の題名と viewport を添えて返す", () => {
  withGas_({ sheets: sampleSeed_() }, () => {
    const out = doGet();
    assert.equal(out.file, "App");
    assert.equal(out.title, "しおかぜ珈琲店 売上ダッシュボード");
    assert.deepEqual(out.meta, [["viewport", "width=device-width, initial-scale=1"]]);
    assert.equal(out.setXFrameOptionsMode, undefined, "入れ子の枠の決まりは触らない");
  });
});

test("doGet: 題名が無いときは「ダッシュボード」にする", () => {
  withGas_({ sheets: { 設定: [["項目", "値"]], 定義: [["種類", "題"]] } }, () => {
    assert.equal(doGet().title, "ダッシュボード");
  });
});

// ---- メニュー ---------------------------------------------------------------

test("onOpen: メニュー「ダッシュボード」に 4 つの項目を出す", () => {
  withGas_({}, (gas) => {
    onOpen();
    assert.deepEqual(gas.trace.menu[0], ["menu", "ダッシュボード"]);
    assert.deepEqual(
      gas.trace.menu.slice(1).map((entry) => entry[1]),
      ["menu_init", "menu_samples", "menu_check", "menu_url"]
    );
  });
});

test("menu_init: 設定・定義を見出しつきで作り、二度目は触らない", () => {
  withGas_({}, (gas) => {
    menu_init();
    assert.deepEqual(gas.sheetRows("設定")[0], ["項目", "値", "書き方"]);
    assert.deepEqual(
      gas.sheetRows("設定").slice(1).map((row) => row[0]),
      ["題名", "言語", "テーマ", "期間", "開始日", "終了日", "絞り込みの列"]
    );
    assert.deepEqual(gas.sheetRows("定義")[0].slice(0, 4), ["種類", "題", "データ", "値の列"]);
    assert.equal(gas.sheetRows("定義").length, 1, "定義は見出しの行だけで作るはず");

    const settingsSheet = gas.sheets.get("設定");
    const writes = settingsSheet.writes;
    menu_init();
    assert.equal(settingsSheet.writes, writes, "すでにあるシートには書き込まないはず");
    assert.equal(settingsSheet.cleared, 1, "すでにあるシートは消さないはず");
    assert.match(gas.trace.alerts[1], /すでにありました/);
  });
});

test("menu_init: 書いたのは 設定 と 定義 の 2 枚だけ", () => {
  withGas_({ sheets: { 売上: [["日付", "金額"], [asDate_(TODAY_), 1000]] } }, (gas) => {
    menu_init();
    assert.deepEqual(Array.from(gas.sheets.keys()).sort(), ["売上", "定義", "設定"].sort());
    assert.equal(gas.sheets.get("売上").writes, 0);
    assert.equal(gas.sheets.get("売上").cleared, 0);
  });
});

test("menu_init のあと menu_samples を選んでも、まだ何も書いていない「設定」には確認しない（誤って「すでに行がある」と言わない）", () => {
  withGas_({}, (gas) => {
    menu_init(); // 「設定」にはひな型（項目名・書き方の説明）だけが入り、値（B 列）は空のまま
    menu_samples();

    assert.deepEqual(gas.trace.prompts, [], "ひな型だけのシートを、客が書いたデータと見なしてはならない");
    assert.match(gas.trace.alerts[gas.trace.alerts.length - 1], /見本を入れました/);
    assert.ok(gas.sheetRows("売上").length > 100, "見本のデータが実際に書かれているはず");
  });
});

test("menu_init のあと「設定」に値を 1 つでも書いたら、menu_samples はお尋ねする（いいえなら何も変えない）", () => {
  withGas_({ answer: "NO" }, (gas) => {
    menu_init();
    const settings = gas.sheets.get("設定");
    settings.getRange(2, 2, 1, 1).setValues([["しおかぜ珈琲店"]]); // 「題名」の値（B 列）に客が書き込む

    const settingsRowsBefore = gas.sheetRows("設定").map((row) => row.slice());
    menu_samples();

    assert.equal(gas.trace.prompts.length, 1, "客が書いた値があるので、お尋ねするはず");
    assert.match(gas.trace.prompts[0].text, /「設定」/);
    assert.deepEqual(gas.sheetRows("設定"), settingsRowsBefore, "いいえのときは「設定」もそのままのはず");
    assert.equal(gas.sheetRows("定義").length, 1, "定義も書き換えられていないはず（見出しだけのまま）");
  });
});

test("menu_samples: 行のあるシートがあれば、はい・いいえでお尋ねする（いいえなら何も書かない）", () => {
  withGas_({ sheets: sampleSeed_(), answer: "NO" }, (gas) => {
    const before = gas.sheets.get("売上").rows.length;
    menu_samples();

    assert.equal(gas.trace.prompts.length, 1);
    assert.equal(gas.trace.prompts[0].buttons, "YES_NO");
    assert.match(gas.trace.prompts[0].text, /書き換えてもよろしいでしょうか/);
    assert.equal(gas.sheets.get("売上").rows.length, before, "いいえのときは書き換えないはず");
    assert.equal(gas.sheets.get("売上").cleared, 0);
    assert.match(gas.trace.alerts[0], /そのままにしました/);
  });
});

test("menu_samples: はい と答えたら、設定・定義・売上・目標の 4 枚だけを書き換える", () => {
  const seed = sampleSeed_();
  seed["ほかの表"] = [["名前", "数"], ["あ", 1]];
  withGas_({ sheets: seed, answer: "YES" }, (gas) => {
    menu_samples();

    assert.deepEqual(gas.sheetRows("設定")[0], ["項目", "値", "書き方"], "見本でも、書き方の列つきのひな型の形で入れるはず");
    assert.equal(gas.sheetRows("定義").length, 11, "見出し 1 行と部品 10 行になるはず");
    assert.deepEqual(gas.sheetRows("目標")[0], ["月", "目標額"]);
    assert.ok(gas.sheetRows("売上").length > 100);
    for (const name of ["設定", "定義", "売上", "目標"]) assert.equal(gas.sheets.get(name).cleared, 1, name + " は書き換えるはず");
    assert.equal(gas.sheets.get("ほかの表").cleared, 0, "見本に関わらないシートは触らないはず");
    assert.equal(gas.sheets.get("ほかの表").writes, 0);
    assert.match(gas.trace.alerts[0], /見本を入れました/);
  });
});

test("menu_samples: まっさらなスプレッドシートなら、お尋ねせずに入れる", () => {
  withGas_({ sheets: {} }, (gas) => {
    menu_samples();
    assert.deepEqual(gas.trace.prompts, []);
    assert.deepEqual(Array.from(gas.sheets.keys()).sort(), ["売上", "定義", "目標", "設定"].sort());
  });
});

test("menu_samples: 入れた見本は、そのまま誤りなく読み直せる", () => {
  withGas_({ sheets: {} }, () => {
    menu_samples();
    const result = api_bootstrap();
    assert.equal(result.ok, true);
    assert.deepEqual(result.missing, []);
    assert.deepEqual(parseConfig(result.config).errors, []);
  });
});

test("menu_check: 誤りが無ければ、その旨だけをお伝えする", () => {
  withGas_({ sheets: sampleSeed_() }, (gas) => {
    menu_check();
    assert.deepEqual(gas.trace.alerts, ["設定に誤りはありません。"]);
  });
});

test("menu_check: 無いシート・無い列・設定の誤りを、まとめて一覧にする", () => {
  const sample = sampleSheets(TODAY_, "ja");
  const definitions = sample.definitions.map((row) => row.slice());
  definitions[1][3] = "売上高"; // 売上のシートに無い列
  definitions.push(["棒", "見つからないシート", "仕入", "金額", "合計", "区分", "", "", "", "円", "", "中", "", "", "", ""]);
  definitions.push(["まる", "知らない種類", "売上", "金額", "合計", "", "", "", "", "", "", "中", "", "", "", ""]);

  withGas_({ sheets: { 設定: sample.settings, 定義: definitions, 売上: sheetWithDates_(sample.data["売上"]), 目標: sample.data["目標"] } }, (gas) => {
    menu_check();
    const text = gas.trace.alerts[0];

    assert.match(text, /^次の点をご確認ください。/);
    assert.match(text, /シート「売上」に列「売上高」が見つかりません/);
    assert.match(text, /データのシート「仕入」が見つかりません/);
    assert.match(text, /知らない種類/, "設定の検査の誤りもそのまま並べるはず");
    for (const line of text.split("\n").slice(2)) {
      if (line !== "") assert.ok(line.startsWith("dashboard: "), "誤りの文は dashboard: で始めるはず: " + line);
    }
  });
});

test("menu_check: 絞り込みの列がどのシートにも無ければ、その旨をお伝えする", () => {
  const sample = sampleSheets(TODAY_, "ja");
  const settings = sample.settings.map((row) => row.slice());
  settings[5][1] = "チャネル、担当者";

  withGas_({ sheets: { 設定: settings, 定義: sample.definitions, 売上: sheetWithDates_(sample.data["売上"]), 目標: sample.data["目標"] } }, (gas) => {
    menu_check();
    assert.match(gas.trace.alerts[0], /絞り込みの列「担当者」が、どのデータのシートにも見つかりません/);
  });
});

test("menu_check: 明細が「最新」の表に「並び」があれば、誤りにはせず「ご参考」として添える", () => {
  const sample = sampleSheets(TODAY_, "ja");
  const definitions = sample.definitions.map((row) => row.slice());
  const recentIndex = definitions.findIndex((row) => row[1] === "最近の注文");
  definitions[recentIndex][13] = "日付"; // 並び（明細が最新なので使われない）

  withGas_({ sheets: { 設定: sample.settings, 定義: definitions, 売上: sheetWithDates_(sample.data["売上"]), 目標: sample.data["目標"] } }, (gas) => {
    menu_check();
    const text = gas.trace.alerts[0];
    assert.match(text, /^設定に誤りはありません。/, "並びが使われないのは誤りではないはず");
    assert.match(text, /ご参考/);
    assert.match(text, /「最近の注文」は最新の明細を出す表なので、「並び」は使われません。/);
  });
});

test("menu_check: 誤りとご参考が両方あるときは、両方まとめて 1 つの札に出す", () => {
  const sample = sampleSheets(TODAY_, "ja");
  const definitions = sample.definitions.map((row) => row.slice());
  const recentIndex = definitions.findIndex((row) => row[1] === "最近の注文");
  definitions[recentIndex][13] = "日付";
  definitions[1][3] = "売上高"; // 売上のシートに無い列（誤り）

  withGas_({ sheets: { 設定: sample.settings, 定義: definitions, 売上: sheetWithDates_(sample.data["売上"]), 目標: sample.data["目標"] } }, (gas) => {
    menu_check();
    const text = gas.trace.alerts[0];
    assert.match(text, /^次の点をご確認ください。/);
    assert.match(text, /シート「売上」に列「売上高」が見つかりません/);
    assert.match(text, /ご参考/);
    assert.match(text, /「最近の注文」は最新の明細を出す表なので、「並び」は使われません。/);
  });
});

test("menu_url: まだ公開されていなければ、公開の手順をお伝えする", () => {
  withGas_({ appUrl: "" }, (gas) => {
    menu_url();
    assert.match(gas.trace.alerts[0], /まだ公開されていません/);
    assert.match(gas.trace.alerts[0], /ウェブアプリにアクセスしているユーザー/);
    assert.match(gas.trace.alerts[0], /Google アカウントを持つ全員/);
  });
});

test("menu_url: 公開されていれば URL と、見られる人の範囲をお伝えする", () => {
  withGas_({ appUrl: "https://script.google.com/macros/s/AAA/exec" }, (gas) => {
    menu_url();
    assert.match(gas.trace.alerts[0], /https:\/\/script\.google\.com\/macros\/s\/AAA\/exec/);
    assert.match(gas.trace.alerts[0], /共有した方だけ/);
  });
});

test("メニューの処理が止まったときは、敬体の知らせを出して実行ログに残す", () => {
  withGas_({ noSpreadsheet: true }, (gas) => {
    menu_check();
    assert.match(gas.trace.alerts[0], /^うまくいきませんでした。/);
    assert.equal(gas.trace.errors.length, 1);
  });
});

// ---- 画面の読み口（source-gas） ---------------------------------------------

/** google.script.run のまね。呼ばれた名前を覚え、answer を成功・失敗どちらかで返す */
function fakeGoogle_(answer, fail) {
  const calls = [];
  const make = () => {
    const runner = {
      withSuccessHandler: (onSuccess) => {
        runner.onSuccess = onSuccess;
        return runner;
      },
      withFailureHandler: (onFailure) => {
        runner.onFailure = onFailure;
        return runner;
      },
      api_bootstrap: () => {
        calls.push("api_bootstrap");
        if (fail) runner.onFailure(fail);
        else runner.onSuccess(scriptRunTransport_(answer)); // 本物と同じく、Date が混ざれば返事ごと null になる
      },
    };
    return runner;
  };
  return { calls, google: { script: { run: make() } } };
}

test("source-gas: api_bootstrap の返事を、そのまま画面の読み口の形にして渡す", async () => {
  const answer = withGas_({ sheets: sampleSeed_() }, () => api_bootstrap());
  const fake = fakeGoogle_(answer);
  const source = sourceGasCreate_({ env: { google: fake.google } });

  const loaded = await source.load();
  assert.deepEqual(fake.calls, ["api_bootstrap"], "呼ぶのは api_bootstrap 1 つだけ");
  assert.deepEqual(loaded.missing, []);
  assert.deepEqual(loaded.truncated, []);
  assert.equal(loaded.config.title, "しおかぜ珈琲店 売上ダッシュボード");
  assert.deepEqual(Object.keys(loaded.datasets).sort(), ["売上", "目標"]);
});

test("source-gas: サーバーが ok: false を返したら、その 1 文で断る", async () => {
  const source = sourceGasCreate_({ env: { google: fakeGoogle_({ ok: false, message: "ただいま表示できません。しばらくしてからお試しください。" }).google } });
  await assert.rejects(source.load(), /ただいま表示できません。しばらくしてからお試しください。/);
});

/** ブラウザの言語のふり（この検査を動かすパソコンの言語に左右されないよう、必ず渡す） */
function fakeNavigator_(language) {
  return { language };
}

test("source-gas: 呼び出しそのものが失敗したら、内側の事情を出さずに断る", async () => {
  const errors = [];
  const fake = fakeGoogle_(null, new Error("ScriptError: 内側の事情"));
  const source = sourceGasCreate_({
    env: { google: fake.google, navigator: fakeNavigator_("ja"), console: { error: (error) => errors.push(error) } },
  });

  await assert.rejects(source.load(), /ただいま表示できません。しばらくしてからお試しください。/);
  assert.equal(errors.length, 1, "もとの理由は実行ログに残すはず");
});

test("source-gas: 呼び出しの入口が無いところでは、静かに断る", async () => {
  const source = sourceGasCreate_({ env: { navigator: fakeNavigator_("ja") } });
  await assert.rejects(source.load(), /ただいま表示できません/);
});

test("source-gas: サーバーの文が無いときは、ブラウザの言語で知らせる", async () => {
  const en = sourceGasCreate_({ env: { navigator: fakeNavigator_("en-US") } });
  await assert.rejects(en.load(), /This dashboard is unavailable right now/);

  const ja = sourceGasCreate_({ env: { navigator: fakeNavigator_("ja-JP") } });
  await assert.rejects(ja.load(), /ただいま表示できません/);

  const unknown = sourceGasCreate_({ env: { navigator: { language: "" } } });
  await assert.rejects(unknown.load(), /ただいま表示できません/, "読めないときは日本語にする");
});

test("source-gas: サーバーが文を返したら、ブラウザの言語に関わらずその文を使う", async () => {
  const english = "This dashboard is unavailable right now. Please try again later.";
  const source = sourceGasCreate_({
    env: { google: fakeGoogle_({ ok: false, message: english }).google, navigator: fakeNavigator_("ja-JP") },
  });
  await assert.rejects(source.load(), new RegExp(english.slice(0, 30)));
});

test("source-gas: 断る誤りには、画面にそのまま出してよい印（dashboardMessage）が付く", async () => {
  const source = sourceGasCreate_({ env: { navigator: fakeNavigator_("ja") } });
  await source.load().then(
    () => assert.fail("断るはず"),
    (error) => assert.equal(error.dashboardMessage, "ただいま表示できません。しばらくしてからお試しください。")
  );
});

test("api_bootstrap: 失敗の知らせは `設定` の「言語」に合わせる（英語なら英語・空欄なら日本語）", () => {
  const sheets = () => ({
    設定: [["項目", "値"], ["言語", "英語"]],
    定義: [["種類", "題", "データ", "値の列"], ["数字", "Sales", "Sales", "Amount"]],
  });

  withGas_({ sheets: sheets(), brokenSheet: "Sales" }, (gas) => {
    const result = api_bootstrap();
    assert.equal(result.ok, false);
    assert.equal(result.message, "This dashboard is unavailable right now. Please try again later.");
    assert.equal(gas.trace.errors.length, 1, "もとの理由は 1 件だけ実行ログに残すはず");
  });

  const japanese = sheets();
  japanese["設定"] = [["項目", "値"], ["言語", ""]];
  withGas_({ sheets: japanese, brokenSheet: "Sales" }, () => {
    assert.equal(api_bootstrap().message, "ただいま表示できません。しばらくしてからお試しください。");
  });
});

test("menu_samples: `設定` の「言語」が英語なら、英語の見本を入れる", () => {
  withGas_({ sheets: { 設定: [["項目", "値"], ["言語", "英語"]] }, answer: "YES" }, (gas) => {
    menu_samples();
    assert.ok(gas.sheets.has("Sales"), "英語のシート名（Sales）で入るはず");
    assert.ok(gas.sheets.has("Targets"));
    assert.deepEqual(gas.sheetRows("Sales")[0], ["Date", "Channel", "Category", "Product", "Qty", "Amount"]);
    assert.deepEqual(
      gas.sheetRows("設定").slice(1).map((row) => row[0]),
      ["題名", "言語", "テーマ", "期間", "開始日", "終了日", "絞り込みの列"],
      "見本を入れても、設定の項目は全部並ぶはず（開始日・終了日の行を消さない）"
    );
    assert.equal(gas.sheetRows("設定")[1][1], "Shiokaze Coffee — Sales dashboard");
  });
});

// ---- 設定・定義のシートから、そのまま画面の設定になること --------------------

test("シートから読んだ設定は、JSON の見本と同じ 10 個の部品になる", () => {
  withGas_({ sheets: sampleSeed_() }, () => {
    const result = api_bootstrap();
    const fromSheets = parseConfig(result.config);
    const direct = parseConfig(configFromSheets(sampleSheets(TODAY_, "ja").settings, sampleSheets(TODAY_, "ja").definitions));
    assert.deepEqual(fromSheets.config, direct.config);
  });
});

test("サーバーが渡した行から、そのまま画面の中身を組み立てられる（誤りの札も空の部品も出ない）", () => {
  const result = withGas_({ sheets: sampleSeed_() }, () => api_bootstrap());
  const { config, errors } = parseConfig(result.config);
  assert.deepEqual(errors, []);

  const datasets = {};
  for (const name of Object.keys(result.datasets)) {
    const shaped = rowsToObjects(result.datasets[name]);
    const types = inferTypes(shaped.columns, shaped.rows, config.datasets[name].types);
    const limited = limitRows(coerceRows(shaped.rows, types));
    datasets[name] = { columns: shaped.columns, rows: limited.rows, types, truncated: limited.truncated };
  }

  const model = buildDashboard({ config, datasets, filters: config.filters, today: TODAY_, lang: "ja" });
  assert.deepEqual(model.notes, []);
  assert.equal(model.widgets.length, 10);
  for (const widget of model.widgets) {
    assert.equal(widget.type === "error", false, widget.title + " が誤りの札になっている: " + widget.message);
    assert.equal(widget.empty === true, false, widget.title + " が空になっている");
  }
});

// ---- 発売前の見直し（2026-09-23）: 偽物を本物の癖に寄せて見つけたこと ----------

const DEPLOYED_AS_OWNER_JA_ = "公開の設定が違うため、表示を止めています";

test("google.script.run のまね: Date が混ざった返事は null になる（偽物の自己点検）", () => {
  assert.equal(scriptRunTransport_({ ok: true, at: new Date() }), null);
  assert.deepEqual(scriptRunTransport_({ ok: true, rows: [["a", 1]] }), { ok: true, rows: [["a", 1]] });
});

test("偽のシートの自己点検: 書いた文字は数や日付に読み替えられ、書式なしテキストのマスと ' つきは文字のまま", () => {
  withGas_({}, (gas) => {
    gasWriteSheet_("メモ", [["見出し", "b", "c", "d"], ["001", "10/1", "2026-09-01", "'001"]]);
    const row = gas.sheetRows("メモ")[1];
    assert.equal(row[0], 1, "先頭の 0 は消える");
    assert.ok(row[1] instanceof Date, "10/1 は日付になる");
    assert.ok(row[2] instanceof Date);
    assert.equal(row[3], "001");

    gasWriteSheet_("文字", [["見出し", "b"], ["001", "10/1"]], { plainText: true });
    assert.deepEqual(gas.sheetRows("文字")[1], ["001", "10/1"]);
  });
});

test("api_bootstrap: 返事は google.script.run を通っても null にならない（見本のまま・見本を入れたあと）", () => {
  withGas_({ sheets: sampleSeed_() }, () => {
    assert.notEqual(scriptRunTransport_(api_bootstrap()), null);
  });
  withGas_({ sheets: {} }, () => {
    menu_samples();
    const carried = scriptRunTransport_(api_bootstrap());
    assert.notEqual(carried, null);
    assert.equal(carried.ok, true);
    assert.deepEqual(parseConfig(carried.config).errors, []);
  });
});

test("`設定` の開始日・終了日を日付のマスで書いても、スプレッドシートの時間帯のその日のまま読む（1 日ずれない）", () => {
  // スクリプトの時間帯（東京）より進んだ時間帯のスプレッドシート。そこの 9/1 0 時は、東京ではまだ 8/31
  const zone = "Pacific/Auckland";
  const sample = sampleSheets(TODAY_, "ja");
  const settings = [["項目", "値"], ["期間", "期間を指定"], ["開始日", "2026-09-01"], ["終了日", "2026/9/30"]];
  withGas_({ sheets: { 設定: settings, 定義: sample.definitions, 売上: sample.data["売上"], 目標: sample.data["目標"] }, spreadsheetTimeZone: zone }, (gas) => {
    assert.ok(gas.sheetRows("設定")[2][1] instanceof Date, "自己点検: 打ち込んだ日付は Date になっている");
    const carried = scriptRunTransport_(api_bootstrap());
    assert.notEqual(carried, null, "返事に Date が混ざってはならない");
    const parsed = parseConfig(carried.config);
    assert.deepEqual(parsed.errors, []);
    assert.equal(parsed.config.filters.from, "2026-09-01");
    assert.equal(parsed.config.filters.to, "2026-09-30");
  });
});

test("「初期化」「見本を入れる」で書いた `設定`・`定義` は書式なしテキストで、そのあと打ち込んだ日付も文字のまま読める", () => {
  withGas_({ sheets: {} }, (gas) => {
    menu_init();
    const settings = gas.sheets.get("設定");
    typeInto_(settings, 6, 2, "2026-09-01"); // 開始日
    typeInto_(settings, 7, 2, "2026-09-30"); // 終了日
    typeInto_(settings, 5, 2, "期間を指定");
    assert.equal(settings.rows[5][1], "2026-09-01", "書式なしテキストのマスなので文字のまま");
    const raw = api_bootstrap().config;
    assert.equal(raw.filters.from, "2026-09-01");
    assert.equal(raw.filters.to, "2026-09-30");
  });
  withGas_({ sheets: {} }, (gas) => {
    menu_samples();
    for (const name of ["設定", "定義"]) {
      for (const row of gas.sheetRows(name)) for (const cell of row) assert.equal(typeof cell, "string", name + " のマスが数や日付に読み替えられている: " + cell);
    }
  });
});

test("「見本を入れる」: 設定の全項目と書き方の列が並び、見本の値が入る", () => {
  withGas_({ sheets: {} }, (gas) => {
    menu_samples();
    const rows = gas.sheetRows("設定");
    assert.deepEqual(rows[0], ["項目", "値", "書き方"]);
    assert.deepEqual(rows.slice(1).map((row) => row[0]), ["題名", "言語", "テーマ", "期間", "開始日", "終了日", "絞り込みの列"]);
    assert.equal(rows[1][1], "しおかぜ珈琲店 売上ダッシュボード");
    assert.equal(rows[5][1], "", "見本は開始日を使わないので空欄のまま");
    for (const row of rows.slice(1)) assert.notEqual(row[2], "", row[0] + " の書き方が空");
  });
});

test("「初期化」: すでにある `設定` に足りない項目の行だけを下に書き足し、書いてある値には触れない", () => {
  withGas_({ sheets: { 設定: [["項目", "値"], ["題名", "うちの店"], ["期間", "今月"]], 定義: [["種類", "題"]] } }, (gas) => {
    menu_init();
    const rows = gas.sheetRows("設定");
    assert.deepEqual(rows[1].slice(0, 2), ["題名", "うちの店"]);
    assert.deepEqual(rows[2].slice(0, 2), ["期間", "今月"]);
    assert.deepEqual(rows.slice(3).map((row) => row[0]), ["言語", "テーマ", "開始日", "終了日", "絞り込みの列"]);
    assert.equal(gas.sheets.get("設定").cleared, 0, "消してはならない");
    assert.match(gas.trace.alerts[0], /書き足しました/);
  });
});

test("項目名・見出し・決まった言葉に空白（全角も）が混ざっていても読む", () => {
  const settings = [["項目", "値"], ["開始　日", "2026-09-01"], [" 終了 日 ", "2026-09-30"], ["期間", "期間を 指定"], ["絞り込み の列", "チャネル"]];
  const definitions = [["種類", "題", "データ ", "値 の列", "集計"], ["数字", "売上", "売上", "金額", "合計"]];
  const raw = configFromSheets(settings, definitions);
  assert.equal(raw.filters.from, "2026-09-01");
  assert.equal(raw.filters.to, "2026-09-30");
  assert.equal(raw.filters.period, "custom");
  assert.deepEqual(raw.filters.dimensions, ["チャネル"]);
  assert.equal(raw.widgets[0].value, "金額");
  assert.equal(raw.widgets[0].dataset, "売上");
  assert.deepEqual(parseConfig(raw).errors, []);
});

test("メニューの関数をウェブアプリの画面から呼ばれても（getUi が例外）、シートには何も書かない", () => {
  const seed = { 売上: [["日付", "金額"], ["2026-09-01", 1000]] };
  withGas_({ sheets: seed, webContext: true, answer: "YES" }, (gas) => {
    for (const run of [menu_init, menu_samples, menu_check, menu_url]) {
      try {
        run();
      } catch (error) {
        // 画面からの呼び出しは失敗で返る（それでよい）
      }
    }
    assert.deepEqual(Array.from(gas.sheets.keys()), ["売上"], "シートを作ってはならない");
    assert.equal(gas.sheets.get("売上").writes, 0);
    assert.equal(gas.sheets.get("売上").cleared, 0);
  });
});

test("「自分として実行」で公開されていたら（開いた方と実行者が違う・開いた方が分からない）、数字を渡さずに止める", () => {
  for (const activeUser of ["", "someone@example.com"]) {
    withGas_({ sheets: sampleSeed_(), activeUser, effectiveUser: OWNER_ }, (gas) => {
      const result = api_bootstrap();
      assert.equal(result.ok, false);
      assert.equal(result.datasets, undefined, "データを渡してはならない");
      assert.equal(result.config, undefined, "設定も渡してはならない");
      assert.ok(result.message.startsWith(DEPLOYED_AS_OWNER_JA_), result.message);
      assert.ok(gas.trace.errors.some((line) => /デプロイを管理/.test(String(line))), "持ち主が直し方を実行ログで読めるはず");
      assert.equal(doGet().title, "ダッシュボード", "題名もシートから読まない");
    });
  }
});

test("「ウェブアプリにアクセスしているユーザー」として動いていれば（開いた方＝実行者）、共有された方にも出す", () => {
  withGas_({ sheets: sampleSeed_(), activeUser: "Viewer@Example.com", effectiveUser: "viewer@example.com" }, () => {
    assert.equal(api_bootstrap().ok, true);
    assert.equal(doGet().title, "しおかぜ珈琲店 売上ダッシュボード");
  });
});

test("マニフェストに開いた方を確かめる許可が無ければ、止めるほうに倒す", () => {
  const scopes = MANIFEST_.oauthScopes.filter((scope) => !scope.endsWith("/userinfo.email"));
  withGas_({ sheets: sampleSeed_(), scopes }, (gas) => {
    const result = api_bootstrap();
    assert.equal(result.ok, false);
    assert.ok(gas.trace.scopeErrors.length > 0);
  });
});

test("マニフェストの許可だけで、画面とメニューのすべてが動く（足りない許可が無い）", () => {
  withGas_({ sheets: {}, answer: "YES", appUrl: "https://script.google.com/macros/s/AAA/exec" }, (gas) => {
    onOpen();
    menu_init();
    menu_samples();
    menu_check();
    menu_url();
    assert.equal(api_bootstrap().ok, true);
    doGet();
    assert.deepEqual(gas.trace.scopeErrors, []);
    assert.deepEqual(gas.trace.errors, []);
  });
});

test("source-gas: 返事に Date が混ざって null で届いたときは、内側の事情を出さずに断る", async () => {
  const source = sourceGasCreate_({ env: { google: fakeGoogle_({ ok: true, config: {}, datasets: { 売上: [[new Date()]] } }).google, navigator: fakeNavigator_("ja") } });
  await assert.rejects(source.load(), /ただいま表示できません/);
});

test("README: マニフェストの許可をすべて説明し、公開の設定とその直し方を書いている", () => {
  const root = new URL("..", import.meta.url);
  for (const name of ["README.ja.md", "README.en.md"]) {
    const text = readFileSync(new URL(name, root), "utf8");
    for (const scope of MANIFEST_.oauthScopes) {
      const short = scope.replace("https://www.googleapis.com/auth/", "");
      assert.ok(text.includes("`" + short + "`"), name + " に許可 " + short + " の説明がありません");
    }
  }
  const ja = readFileSync(new URL("README.ja.md", root), "utf8");
  for (const phrase of ["デプロイを管理", "新バージョン", "ウェブアプリにアクセスしているユーザー", "Google アカウントを持つ全員", DEPLOYED_AS_OWNER_JA_]) {
    assert.ok(ja.includes(phrase), "README.ja.md に「" + phrase + "」がありません");
  }
  const en = readFileSync(new URL("README.en.md", root), "utf8");
  for (const phrase of ["Manage deployments", "New version", "User accessing the web app", "Anyone with Google account"]) {
    assert.ok(en.includes(phrase), "README.en.md に「" + phrase + "」がありません");
  }
});

test("「初期化」: `設定` のシートがあっても空なら、見出しつきのひな型を丸ごと書く", () => {
  withGas_({ sheets: { 設定: [] } }, (gas) => {
    menu_init();
    const rows = gas.sheetRows("設定");
    assert.deepEqual(rows[0], ["項目", "値", "書き方"]);
    assert.equal(rows.length, 8);
  });
});
