import { test } from "node:test";
import assert from "node:assert/strict";
import { parseConfig } from "../src/core/config.js";
import { buildDashboard } from "../src/core/model.js";
import { initialState, reduce } from "../src/ui/state.js";
import { renderDashboard, renderFilters, renderWidgetFrame, renderError, renderLoading } from "../src/ui/render.js";

const TODAY = "2026-09-19";

const SALES_COLUMNS = ["日付", "チャネル", "カテゴリ", "金額"];
const SALES_ROWS = [
  { 日付: "2026-09-01", チャネル: "EC", カテゴリ: "コーヒー豆", 金額: 3000 },
  { 日付: "2026-09-02", チャネル: "店舗", カテゴリ: "菓子", 金額: 1500 },
  { 日付: "2026-09-03", チャネル: "EC", カテゴリ: "コーヒー豆", 金額: 2000 },
  { 日付: "2026-08-10", チャネル: "店舗", カテゴリ: "菓子", 金額: 1000 },
];

const WIDGETS = [
  { type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", size: "s" },
  { type: "line", title: "売上の推移", dataset: "sales", value: "金額", agg: "sum", splitBy: "チャネル", format: "yen", size: "l" },
  { type: "bar", title: "カテゴリ別の売上", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum", format: "yen", size: "m" },
  {
    type: "table",
    title: "カテゴリ別",
    dataset: "sales",
    groupBy: "カテゴリ",
    columns: [{ value: "金額", agg: "sum", label: "売上", format: "yen" }],
    size: "l",
  },
];

function parse_(raw, lang) {
  return parseConfig(
    Object.assign(
      {
        title: "しおかぜ珈琲店 売上ダッシュボード",
        lang: lang || "ja",
        datasets: { sales: { url: "./sales.csv", dateColumn: "日付" } },
        filters: { period: "thisMonth", dimensions: ["チャネル"] },
        widgets: WIDGETS,
      },
      raw || {}
    )
  );
}

/** 設定から、描くのに要るものをひととおり組み立てる */
function makeView_(options) {
  const opts = options || {};
  const lang = opts.lang || "ja";
  const parsed = parse_(opts.raw, lang);
  const config = parsed.config;
  let state = reduce(initialState(config, TODAY), { type: "loaded" });
  for (const action of opts.actions || []) state = reduce(state, action);
  const model = buildDashboard({
    config,
    datasets: { sales: { columns: SALES_COLUMNS, rows: SALES_ROWS, types: {}, truncated: false } },
    filters: state.filters,
    today: TODAY,
    lang,
  });
  return { config, model, state, options: { チャネル: ["EC", "店舗"] }, lang, errors: opts.errors || parsed.errors };
}

function tags_(html, name, className) {
  return html.match(new RegExp("<" + name + ' class="' + className + '[^"]*"[^>]*>', "g")) || [];
}

function attr_(tag, name) {
  const found = tag.match(new RegExp(" " + name + '="([^"]*)"'));
  return found === null ? null : found[1];
}

/** 部品 1 つぶんの切れ端を取り出す */
function cardOf_(html, id) {
  const from = html.indexOf('data-widget="' + id + '"');
  const start = html.lastIndexOf("<section", from);
  return html.slice(start, html.indexOf("</section>", start) + 10);
}

// ---- 全体 -----------------------------------------------------------------

test("renderDashboard: 枠・題・絞り込みの行・部品の格子をこの順で作る", () => {
  const html = renderDashboard(makeView_());
  assert.ok(html.startsWith('<div class="db" data-db-theme="auto" lang="ja">'));
  assert.ok(html.trim().endsWith("</div>"));
  assert.ok(html.includes('<h1 class="db-title">しおかぜ珈琲店 売上ダッシュボード</h1>'));
  assert.ok(html.indexOf('<form class="db-filters"') < html.indexOf('<div class="db-grid">'));
  assert.equal(tags_(html, "section", "db-card").length, 4);
});

test("renderDashboard: theme と lang を枠に写す", () => {
  const dark = renderDashboard(makeView_({ raw: { theme: "dark" } }));
  assert.ok(dark.startsWith('<div class="db" data-db-theme="dark" lang="ja">'));

  const en = renderDashboard(makeView_({ lang: "en", raw: { lang: "en" } }));
  assert.ok(en.startsWith('<div class="db" data-db-theme="auto" lang="en">'));
});

test("renderDashboard: 読み込み中と、出せないときの知らせを出す", () => {
  const view = makeView_();
  const loading = renderDashboard(Object.assign({}, view, { state: Object.assign({}, view.state, { status: "loading" }) }));
  assert.ok(loading.includes('<div class="db-status" role="status">読み込んでいます…</div>'));
  assert.equal(loading.includes("db-grid"), false);

  const failed = renderDashboard(
    Object.assign({}, view, {
      state: Object.assign({}, view.state, { status: "error", message: "ただいま表示できません。しばらくしてからお試しください。" }),
    })
  );
  assert.ok(failed.includes('class="db-status" role="status"'));
  assert.ok(failed.includes("ただいま表示できません。しばらくしてからお試しください。"));
});

test("renderLoading: 読み込み中の知らせだけを作る", () => {
  assert.equal(renderLoading("ja"), '<div class="db-status" role="status">読み込んでいます…</div>');
  assert.ok(renderLoading("en").includes("Loading"));
});

test("renderDashboard: 20,000 行の知らせを下に出す", () => {
  const view = makeView_();
  const model = Object.assign({}, view.model, { notes: ["20,000 行までを表示しています"] });
  const html = renderDashboard(Object.assign({}, view, { model }));
  assert.ok(html.includes('<p class="db-note">20,000 行までを表示しています</p>'));
});

test("renderDashboard: 設定の誤りは、数を添えた畳んだ一覧にして上に出す", () => {
  const view = makeView_({ errors: ["dashboard: datasets（データセット）を設定してください", "dashboard: lang（言語）の値が正しくありません"] });
  const html = renderDashboard(view);
  assert.ok(html.includes('<details class="db-errors">'));
  assert.ok(html.includes("設定をご確認ください（2 件）"));
  assert.ok(html.includes("dashboard: lang（言語）の値が正しくありません"), "一覧では前置きを残す");
  assert.ok(html.indexOf("db-errors") < html.indexOf("db-grid"));

  assert.equal(renderDashboard(makeView_()).includes("db-errors"), false);
});

test("renderDashboard: 題や区分の危ない文字は実体参照にする", () => {
  const nasty = '<script>alert("x")</script>';
  const html = renderDashboard(makeView_({ raw: { title: nasty } }));
  assert.equal(html.includes("<script"), false);
  assert.ok(html.includes("&lt;script&gt;"));
});

// ---- 絞り込み -------------------------------------------------------------

test("renderFilters: 期間の select は 8 つの選び方を持つ", () => {
  const html = renderFilters(makeView_());
  assert.ok(html.includes('<select class="db-select" name="period" data-action="set-period">'));
  for (const label of ["今月", "先月", "直近 7 日", "直近 30 日", "直近 90 日", "今年", "全期間", "期間を指定"]) {
    assert.ok(html.includes(">" + label + "</option>"), label);
  }
  assert.ok(html.includes('value="thisMonth" selected'));
});

test("renderFilters: 日付の 2 つは「期間を指定」のときだけ出す", () => {
  assert.equal(renderFilters(makeView_()).includes('type="date"'), false);

  const html = renderFilters(makeView_({ actions: [{ type: "set-range", from: "2026-09-01", to: "2026-09-10" }] }));
  const inputs = tags_(html, "input", "db-date");
  assert.equal(inputs.length, 2);
  assert.equal(attr_(inputs[0], "name"), "from");
  assert.equal(attr_(inputs[0], "data-action"), "set-range");
  assert.equal(attr_(inputs[0], "value"), "2026-09-01");
  assert.equal(attr_(inputs[1], "name"), "to");
  assert.equal(attr_(inputs[1], "value"), "2026-09-10");
});

test("renderFilters: 区分の select は列ごとに 1 つ、先頭は「すべて」", () => {
  const html = renderFilters(makeView_());
  const selects = tags_(html, "select", "db-select").filter((tag) => attr_(tag, "data-action") === "set-dimension");
  assert.equal(selects.length, 1);
  assert.equal(attr_(selects[0], "data-column"), "チャネル");
  assert.equal(attr_(selects[0], "name"), "dim");
  assert.ok(html.includes('<option value="" selected>すべて</option>'), "何も選んでいないときは「すべて」が選ばれている");
  assert.ok(html.includes('<option value="EC">EC</option>'));
  assert.ok(html.includes('<option value="店舗">店舗</option>'));
});

test("renderFilters: 戻すボタンは、最初と違うときだけ出す", () => {
  assert.equal(renderFilters(makeView_()).includes('data-action="reset"'), false);

  const html = renderFilters(makeView_({ actions: [{ type: "set-dimension", column: "チャネル", value: "EC" }] }));
  assert.ok(html.includes('data-action="reset"'));
  assert.ok(html.includes("絞り込みを戻す"));
  assert.ok(html.includes('<option value="EC" selected>EC</option>'));
});

test("renderFilters: 英語のときは英語の札にする", () => {
  const html = renderFilters(makeView_({ lang: "en", raw: { lang: "en" } }));
  assert.ok(html.includes(">This month</option>"));
  assert.ok(html.includes(">All time</option>"));
  assert.ok(html.includes('<option value="" selected>All</option>'));
});

// ---- 部品の枠 -------------------------------------------------------------

test("renderWidgetFrame: 題・「表で見る」・中身・注記を組む", () => {
  const view = makeView_();
  const html = renderWidgetFrame(view.model.widgets[0], "<p>中身</p>", view.state, "ja");
  assert.ok(html.startsWith('<section class="db-card db-size-s" data-widget="w1" aria-labelledby="w1-title">'));
  assert.ok(html.includes('<h2 id="w1-title" class="db-card-title">売上</h2>'));
  assert.ok(html.includes('data-action="toggle-table" data-widget="w1" aria-pressed="false"'));
  assert.ok(html.includes(">表で見る</button>"));
  assert.ok(html.includes('<div class="db-card-body"><p>中身</p></div>'));
});

test("renderWidgetFrame: 注記と、のぞいた値の数を下に添える", () => {
  const view = makeView_();
  const model = Object.assign({}, view.model.widgets[0], { note: "税込みの金額です", skipped: 2 });
  const html = renderWidgetFrame(model, "", view.state, "ja");
  assert.ok(html.includes('<p class="db-card-note">税込みの金額です</p>'));
  assert.ok(html.includes('<p class="db-card-note">数として読めない値を 2 件のぞきました</p>'));
});

test("renderDashboard: 「表で見る」が true のときは、グラフではなく表を出す", () => {
  const view = makeView_({ actions: [{ type: "toggle-table", widget: "w2" }] });
  const html = renderDashboard(view);
  const card = cardOf_(html, "w2");
  assert.equal(card.includes("<svg"), false);
  assert.ok(card.includes('<table class="db-table"'));
  assert.ok(card.includes('aria-pressed="true"'));
  assert.ok(card.includes(">グラフで見る</button>"));

  const chart = cardOf_(renderDashboard(makeView_()), "w2");
  assert.ok(chart.includes("<svg"));
  assert.ok(chart.includes(">表で見る</button>"));
});

test("renderDashboard: 表の部品には CSV の押しボタンを付け、「表で見る」は付けない", () => {
  const card = cardOf_(renderDashboard(makeView_()), "w4");
  assert.ok(card.includes('data-action="download-csv" data-widget="w4"'));
  assert.ok(card.includes("CSV をダウンロード"));
  assert.equal(card.includes('data-action="toggle-table"'), false);
});

test("renderDashboard: 大きさは格子の幅に写す", () => {
  const html = renderDashboard(makeView_());
  assert.ok(cardOf_(html, "w1").includes("db-size-s"));
  assert.ok(cardOf_(html, "w2").includes("db-size-l"));
  assert.ok(cardOf_(html, "w3").includes("db-size-m"));
});

// ---- 誤りの札 -------------------------------------------------------------

test("renderError: 札の文からは前置きを外す", () => {
  const model = { id: "w1", type: "error", title: "売上", message: "dashboard: 1 番目の部品「売上」の value（値の列）を指定してください" };
  const html = renderError(model, "ja");
  assert.ok(html.includes('data-widget="w1"'));
  assert.ok(html.includes(">売上</h2>"));
  assert.ok(html.includes("1 番目の部品「売上」の value（値の列）を指定してください"));
  assert.equal(html.includes("dashboard: "), false);
  assert.equal(html.includes('data-action="toggle-table"'), false);
});

test("renderError: 題が無いときは「設定をご確認ください」を題にする", () => {
  const html = renderError({ id: "w2", type: "error", title: "", message: "データ「sales」が見つかりません。設定をご確認ください。" }, "ja");
  assert.ok(html.includes(">設定をご確認ください</h2>"));
  assert.ok(html.includes("データ「sales」が見つかりません。設定をご確認ください。"));

  const en = renderError({ id: "w2", type: "error", title: "", message: "dashboard: widget 1 is missing its value column." }, "en");
  assert.ok(en.includes(">Check the settings</h2>"));
  assert.ok(en.includes("widget 1 is missing its value column."));
});

test("renderError: 誤りの文の危ない文字も実体参照にする", () => {
  const html = renderError({ id: "w1", type: "error", title: "<b>題</b>", message: '<script>alert("x")</script>' }, "ja");
  assert.equal(html.includes("<script"), false);
  assert.equal(html.includes("<b>"), false);
  assert.ok(html.includes("&lt;script&gt;"));
});

// ---- 全体を通して ---------------------------------------------------------

test("renderDashboard: データが無い期間でも、誤りにせずお知らせを出す", () => {
  const view = makeView_({ actions: [{ type: "set-range", from: "2026-07-01", to: "2026-07-31" }] });
  const html = renderDashboard(view);
  assert.ok(html.includes("データがありません"));
  assert.equal(html.includes("db-errors"), false);
});

test("renderDashboard: 英語のときは画面の文がすべて英語になる", () => {
  const html = renderDashboard(makeView_({ lang: "en", raw: { lang: "en" } }));
  assert.ok(html.includes("View as table"));
  assert.ok(html.includes("Download CSV"));
  assert.ok(html.includes("This month"));
  assert.equal(html.includes("表で見る"), false);
});

test("renderDashboard: 知らない種類の部品は、それらしい形にせず設定を見直す札にする", () => {
  const view = makeView_();
  const widgets = view.model.widgets.concat([{ id: "w9", type: "gauge", title: "知らない部品", size: "m" }]);
  const html = renderDashboard(Object.assign({}, view, { model: Object.assign({}, view.model, { widgets }) }));
  const card = cardOf_(html, "w9");
  assert.ok(card.includes('<p class="db-error">'), "誤りの札にする");
  assert.equal(card.includes("db-meter"), false, "目標の帯として描かない");
  assert.ok(card.includes("設定をご確認ください"));
  assert.equal(card.includes('data-action="toggle-table"'), false);
});

test("renderError: 札の大きさは部品の設定どおりにする（無ければ m）", () => {
  assert.ok(renderError({ id: "w1", type: "error", title: "売上", message: "文", size: "s" }, "ja").includes("db-size-s"));
  assert.ok(renderError({ id: "w2", type: "error", title: "推移", message: "文", size: "l" }, "ja").includes("db-size-l"));
  assert.ok(renderError({ id: "w3", type: "error", title: "推移", message: "文" }, "ja").includes("db-size-m"));
});

test("renderDashboard: 表の行を図として包まない（role も tabindex も残さない）", () => {
  const html = renderDashboard(makeView_({ actions: [{ type: "toggle-table", widget: "w3" }] }));
  for (const id of ["w3", "w4"]) {
    const card = cardOf_(html, id);
    assert.ok(card.includes('<tr class="db-row">'));
    assert.equal(card.includes('role="img"'), false);
    assert.equal(card.includes("tabindex"), false);
  }
});
