import { test } from "node:test";
import assert from "node:assert/strict";
import { textOf, toHalfWidth, escapeHtml, escapeAttr, isBlankRow, clamp, estimateTextWidth, hasOwn, setOwn, compareCells } from "../src/core/text.js";

test("textOf: 前後の空白を落とした文字にする。null / undefined は空", () => {
  assert.equal(textOf(" a "), "a");
  assert.equal(textOf(null), "");
  assert.equal(textOf(undefined), "");
  assert.equal(textOf(""), "");
  assert.equal(textOf(0), "0");
  assert.equal(textOf(true), "true");
});

test("textOf: 配列やオブジェクトは空にする（検査をすり抜けさせない）", () => {
  assert.equal(textOf({}), "");
  assert.equal(textOf(["a", "b"]), "");
  assert.equal(textOf(() => "x"), "");
});

test("toHalfWidth: 全角の英数字・記号と全角空白を半角にする", () => {
  assert.equal(toHalfWidth("ＡＢＣ１２３＠　x"), "ABC123@ x");
  assert.equal(toHalfWidth(null), "");
  assert.equal(toHalfWidth(undefined), "");
});

test("escapeHtml: & < > \" ' の5文字を実体参照にする。null / undefined は空", () => {
  assert.equal(escapeHtml("<b>a & b</b>"), "&lt;b&gt;a &amp; b&lt;/b&gt;");
  assert.equal(escapeHtml(`it's "ok"`), "it&#39;s &quot;ok&quot;");
  assert.equal(escapeHtml(null), "");
  assert.equal(escapeHtml(undefined), "");
});

test("escapeAttr: 属性値として出しても安全な文字にする（5文字とも実体参照になる）", () => {
  const raw = `しおかぜ"珈琲店 <店> 'A&B'`;
  const escaped = escapeAttr(raw);
  assert.equal(escaped.includes('"'), false);
  assert.equal(escaped.includes("<"), false);
  assert.equal(escaped.includes(">"), false);
  assert.equal(escaped.includes("'"), false);
  // & 自体は &amp; の一部としてのみ残る
  assert.equal(escaped, "しおかぜ&quot;珈琲店 &lt;店&gt; &#39;A&amp;B&#39;");
  assert.equal(escapeAttr(null), "");
  assert.equal(escapeAttr(undefined), "");
});

test("isBlankRow: セルがすべて空なら true。配列でなければ true とみなす", () => {
  assert.equal(isBlankRow(["", " ", null, undefined]), true);
  assert.equal(isBlankRow(["", "a", ""]), false);
  assert.equal(isBlankRow([]), true);
  assert.equal(isBlankRow(null), true);
  assert.equal(isBlankRow(undefined), true);
});

test("clamp: min〜max の範囲に収める", () => {
  assert.equal(clamp(5, 1, 10), 5);
  assert.equal(clamp(-3, 1, 10), 1);
  assert.equal(clamp(99, 1, 10), 10);
  assert.equal(clamp(1, 1, 10), 1);
  assert.equal(clamp(10, 1, 10), 10);
  assert.equal(clamp("たぶん", 1, 10), 1);
});

test("estimateTextWidth: 全角は 12px・半角は 7px を目安にする（字の大きさに比例）", () => {
  assert.equal(estimateTextWidth("abc", 12), 21);
  assert.equal(estimateTextWidth("あい", 12), 24);
  assert.equal(estimateTextWidth("abc", 24), 42);
  assert.equal(estimateTextWidth("", 12), 0);
  assert.equal(estimateTextWidth(null), 0);
  assert.equal(estimateTextWidth("売上"), 24, "字の大きさを渡さなければ 12px で見積もる");
  assert.equal(estimateTextWidth("▲"), 7, "記号は半角なみに見る");
});

test("hasOwn: 自分で持っている名前だけを true にする", () => {
  assert.equal(hasOwn({ a: 1 }, "a"), true);
  assert.equal(hasOwn({ a: undefined }, "a"), true);
  assert.equal(hasOwn({ a: 1 }, "b"), false);
  assert.equal(hasOwn({}, "toString"), false, "JS が最初から持っている名前は拾わない");
  assert.equal(hasOwn({}, "constructor"), false);
  assert.equal(hasOwn(null, "a"), false);
  assert.equal(hasOwn(undefined, "a"), false);
  assert.equal(hasOwn("文字", "length"), false);
  assert.equal(hasOwn({ "": 1 }, ""), false, "名前の無い項目は見に行かない");
});

test("setOwn: 特別な名前でも、入れ物そのものの素性を書き換えずに 1 項目として入れる", () => {
  const box = {};
  setOwn(box, "__proto__", "number");
  assert.equal(hasOwn(box, "__proto__"), true, "自分が持つ項目として入る");
  assert.deepEqual(Object.keys(box), ["__proto__"]);
  assert.equal(Object.getPrototypeOf(box), Object.prototype, "素性は変わらない");
  assert.equal(Object.getPrototypeOf({}), Object.prototype, "ほかの入れ物にも影響しない");

  setOwn(box, "toString", "text");
  assert.equal(box.toString, "text");
  setOwn(box, "toString", "date");
  assert.equal(box.toString, "date", "上書きもできる");
});

test("compareCells: 数は数の大小、文字は単純比較。空はどちらの向きでも最後", () => {
  assert.ok(compareCells(2, 1, "desc") < 0, "大きい順では 2 が先");
  assert.ok(compareCells(1, 2, "asc") < 0, "小さい順では 1 が先");
  assert.equal(compareCells(1, 1, "desc"), 0, "同じ値は 0（呼ぶ側が元の並びを保てる）");

  assert.ok(compareCells("b", "a", "desc") < 0);
  assert.ok(compareCells("a", "b", "asc") < 0);

  for (const order of ["desc", "asc"]) {
    assert.ok(compareCells(null, 5, order) > 0, order + ": null は後");
    assert.ok(compareCells("", 5, order) > 0, order + ": 空文字も後");
    assert.ok(compareCells(undefined, "a", order) > 0, order + ": undefined も後");
    assert.ok(compareCells(5, null, order) < 0, order + ": 読める値が先");
  }
  assert.equal(compareCells(null, "", "desc"), 0, "どちらも空なら 0");
});

test("compareCells: 並べ替えに使うと、読めない値がまとめて最後に来る", () => {
  const values = [3, null, 1, "", 2];
  assert.deepEqual(values.slice().sort((a, b) => compareCells(a, b, "desc")), [3, 2, 1, null, ""]);
  assert.deepEqual(values.slice().sort((a, b) => compareCells(a, b, "asc")), [1, 2, 3, null, ""]);
});
