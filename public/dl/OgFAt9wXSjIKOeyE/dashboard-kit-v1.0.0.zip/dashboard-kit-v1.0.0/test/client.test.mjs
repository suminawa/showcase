import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import { createContext, runInContext } from "node:vm";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import {
  mountDashboard,
  setEnvironmentForTests,
  mainFocusKeyOf_,
  mainNearestBandIndex_,
  mainTipModel_,
  mainFileNameOf_,
  mainHashPrefixOf_,
  mainHashOwned_,
  mainTipPlacement_,
  mainLoadWins_,
} from "../src/ui/main.js";
import { sourceWebCreate_ } from "../src/ui/source-web.js";

const root_ = join(dirname(fileURLToPath(import.meta.url)), "..");
const PACKAGE_VERSION_ = JSON.parse(readFileSync(join(root_, "package.json"), "utf8")).version;

// ---- 偽の画面・偽のブラウザ -------------------------------------------------

function has_(box, name) {
  return Object.prototype.hasOwnProperty.call(box, name);
}

/** 描いた文字列の中の実体参照を、もとの字に戻す（属性の値を読むときに使う） */
function unescape_(text) {
  return text
    .split("&quot;").join('"')
    .split("&#39;").join("'")
    .split("&lt;").join("<")
    .split("&gt;").join(">")
    .split("&amp;").join("&");
}

/** 当たり判定のふり。使うのは属性のあるなし・値と、種類 + class の 3 つの形だけ */
function fakeMatches_(element, selector) {
  const attr = /^\[([\w-]+)(?:="([^"]*)")?\]$/.exec(selector);
  if (attr !== null) {
    const value = element.getAttribute(attr[1]);
    return attr[2] === undefined ? value !== null : value === attr[2];
  }
  const tagged = /^([a-z]+)\.([\w-]+)$/.exec(selector);
  if (tagged !== null) {
    return element.tag === tagged[1] && (" " + (element.className || "") + " ").indexOf(" " + tagged[2] + " ") !== -1;
  }
  const classed = /^\.([\w-]+)$/.exec(selector);
  if (classed !== null) return (" " + (element.className || "") + " ").indexOf(" " + classed[1] + " ") !== -1;
  return false;
}

/**
 * 画面の要素のふり。属性と子と style を持つだけの入れ物。
 * options で 種類（tag）・class・親・どの窓のものか（owner）・画面での場所（rect）を足せる
 */
function fakeElement_(attrs, options) {
  const opts = options || {};
  const element = {
    nodeType: 1,
    tag: opts.tag || "div",
    className: opts.className || "",
    style: {},
    children: [],
    inside: opts.inside || [],
    textContent: "",
    attributes: Object.assign({}, attrs),
    parent: opts.parent || null,
    owner: opts.owner || null,
    rect: opts.rect || { left: 0, top: 0, width: 100, height: 20, right: 100, bottom: 20 },
    offsetWidth: opts.offsetWidth === undefined ? 0 : opts.offsetWidth,
    offsetHeight: opts.offsetHeight === undefined ? 0 : opts.offsetHeight,
    clicked: 0,
    focused: 0,
    setAttribute(name, value) {
      this.attributes[name] = String(value);
    },
    getAttribute(name) {
      return has_(this.attributes, name) ? this.attributes[name] : null;
    },
    appendChild(node) {
      this.children.push(node);
      node.parentNode = this;
      return node;
    },
    removeChild(node) {
      this.children = this.children.filter((child) => child !== node);
      return node;
    },
    remove() {},
    click() {
      this.clicked += 1;
    },
    focus() {
      this.focused += 1;
      if (this.owner && this.owner.document) this.owner.document.activeElement = this;
    },
    matches(selector) {
      return fakeMatches_(this, selector);
    },
    closest(selector) {
      let node = this;
      while (node) {
        if (fakeMatches_(node, selector)) return node;
        node = node.parent;
      }
      return null;
    },
    querySelector(selector) {
      return this.inside.filter((child) => fakeMatches_(child, selector))[0] || null;
    },
    querySelectorAll(selector) {
      return this.inside.filter((child) => fakeMatches_(child, selector));
    },
    getBoundingClientRect() {
      return this.rect;
    },
  };
  for (const child of element.inside) child.parent = element;
  return element;
}

/**
 * 描いた文字列の中から、操作する要素（data-action が付いたもの）だけを組み立て直す。
 * 描き直しのあとに focus を戻せるか、日付の 2 つの入力をまとめて読めるかを、ここで確かめられる
 */
function fakeParse_(html, owner) {
  const parts = [];
  const tags = html.match(/<(input|select|button|a)\b[^>]*>/g) || [];
  for (const tag of tags) {
    if (tag.indexOf("data-action=") === -1) continue;
    const attrs = {};
    const found = /([a-zA-Z_:][-\w:.]*)="([^"]*)"/g;
    let pair = found.exec(tag);
    while (pair !== null) {
      attrs[pair[1]] = unescape_(pair[2]);
      pair = found.exec(tag);
    }
    const element = fakeElement_(attrs, { tag: /^<(\w+)/.exec(tag)[1], owner });
    element.value = has_(attrs, "value") ? attrs.value : "";
    parts.push(element);
  }
  return parts;
}

/**
 * 差し込み先の要素のふり。描かれた文字列と、付け外しした listener を覚えておく。
 * 描いた文字列は、そのつど操作する要素に組み立て直すので、focus の戻し先も探せる
 */
function fakeRoot_(owner) {
  return {
    nodeType: 1,
    html: "",
    parts: [],
    owner: owner || null,
    attributes: {},
    children: [],
    listeners: [],
    rect: { left: 0, top: 0, width: 800, height: 600, right: 800, bottom: 600 },
    offsetWidth: 800,
    offsetHeight: 600,
    firstElementChild: null,
    get innerHTML() {
      return this.html;
    },
    set innerHTML(value) {
      this.html = String(value);
      this.parts = fakeParse_(this.html, this.owner);
    },
    setAttribute(name, value) {
      this.attributes[name] = String(value);
    },
    getAttribute(name) {
      return has_(this.attributes, name) ? this.attributes[name] : null;
    },
    appendChild(node) {
      this.children.push(node);
      node.parentNode = this;
      return node;
    },
    contains(element) {
      return this.parts.indexOf(element) !== -1;
    },
    getBoundingClientRect() {
      return this.rect;
    },
    querySelector(selector) {
      return this.querySelectorAll(selector)[0] || null;
    },
    querySelectorAll(selector) {
      return this.parts.filter((element) => fakeMatches_(element, selector));
    },
    addEventListener(type, handler) {
      this.listeners.push({ type, handler });
    },
    removeEventListener(type, handler) {
      this.listeners = this.listeners.filter((entry) => !(entry.type === type && entry.handler === handler));
    },
  };
}

/** sessionStorage のふり。fail: true にすると、どの操作も例外を投げる */
function fakeStorage_(fail) {
  const box = new Map();
  return {
    box,
    getItem(key) {
      if (fail) throw new Error("storage");
      return box.has(key) ? box.get(key) : null;
    },
    setItem(key, value) {
      if (fail) throw new Error("storage");
      box.set(key, value);
    },
  };
}

/** ブラウザの道具のふり。calls に、記録しておきたい呼び出しを貯める */
function fakeEnv_(patch) {
  const calls = { errors: [], replaced: [], fetched: [], downloads: [], revoked: [] };
  const body = fakeElement_({});
  const env = {
    calls,
    document: {
      body,
      activeElement: null,
      createElement(tag) {
        const element = fakeElement_({});
        element.tag = tag;
        if (tag === "a") calls.downloads.push(element);
        return element;
      },
    },
    window: {
      innerWidth: 1200,
      innerHeight: 800,
      listeners: [],
      timers: new Map(),
      nextTimer: 1,
      addEventListener(type, handler) {
        this.listeners.push({ type, handler });
      },
      removeEventListener(type, handler) {
        this.listeners = this.listeners.filter((entry) => !(entry.type === type && entry.handler === handler));
      },
      setTimeout(run) {
        const id = this.nextTimer;
        this.nextTimer += 1;
        this.timers.set(id, run);
        return id;
      },
      clearTimeout(id) {
        this.timers.delete(id);
      },
      Blob: function Blob(parts, options) {
        this.parts = parts;
        this.options = options;
      },
      URL: {
        createObjectURL() {
          return "blob:dashboard";
        },
        revokeObjectURL(url) {
          calls.revoked.push(url);
        },
      },
    },
    location: { hash: "", pathname: "/demo/index.html", search: "", href: "https://shop.example/demo/index.html" },
    history: {
      replaceState(state, title, url) {
        calls.replaced.push(url);
      },
    },
    sessionStorage: fakeStorage_(false),
    fetch() {
      return Promise.resolve({ ok: false, headers: { get: () => "" }, text: () => Promise.resolve("") });
    },
    console: {
      error(error) {
        calls.errors.push(error);
      },
    },
    now: () => new Date(2026, 2, 15, 9, 0, 0),
  };
  return Object.assign(env, patch || {});
}

/** 読み込みの約束が片づくまで待つ */
function settled_() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

/** root に付いた listener のうち、その種類のものを呼ぶ */
function fire_(root, type, event) {
  for (const entry of root.listeners) {
    if (entry.type === type) entry.handler(event);
  }
}

/** 小さな設定と、それに合う行（行列の形） */
function miniConfig_() {
  return {
    title: "しおかぜ珈琲店 売上ダッシュボード",
    lang: "ja",
    datasets: { sales: { url: "./sales.csv", dateColumn: "日付" }, targets: { url: "./targets.csv" } },
    filters: { period: "all", dimensions: ["チャネル"] },
    widgets: [
      { type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", size: "s" },
      { type: "table", title: "商品別", dataset: "sales", groupBy: "商品", columns: [{ value: "金額", agg: "sum", label: "売上" }], size: "l" },
      { type: "kpi", title: "目標の数", dataset: "targets", value: "目標額", agg: "sum", size: "s" },
    ],
  };
}

const miniSales_ = [
  ["日付", "チャネル", "商品", "金額"],
  ["2026-03-01", "店頭", "ブレンド", "1200"],
  ["2026-03-02", "EC", "深煎り", "2400"],
];
const miniTargets_ = [
  ["月", "目標額"],
  ["2026-03", "100000"],
];

/** load() が決まった中身を返すだけの読み口 */
function fakeSource_(result) {
  return { load: () => Promise.resolve(result) };
}

afterEach(() => {
  setEnvironmentForTests(null);
});

// ---- 組み立て ---------------------------------------------------------------

test("見本の読み口で組み立てると、root にお店の題を含む画面が入る", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, { source: "memory", today: "2026-03-15", hash: false });
  assert.ok(root.innerHTML.includes("読み込んでいます"), "はじめは読み込み中の知らせを出す");

  await settled_();
  assert.ok(root.innerHTML.includes("しおかぜ珈琲店"), "見本のお店の題が出る");
  assert.ok(root.innerHTML.includes('class="db-grid"'), "部品の格子が出る");
  assert.equal(root.getAttribute("data-db-theme"), "auto");
  assert.equal(root.getAttribute("lang"), "ja");
  assert.equal(env.calls.errors.length, 0);
  view.destroy();
});

test("見本の読み口は lang の指定で英語になる", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, { source: "memory", lang: "en", today: "2026-03-15", hash: false });
  await settled_();
  assert.ok(root.innerHTML.includes("Shiokaze Coffee"));
  assert.ok(root.innerHTML.includes("View as table"));
  assert.equal(root.getAttribute("lang"), "en");
  view.destroy();
});

test("data に渡した行（オブジェクトの並び）をそのまま使える", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: {} }),
    data: {
      sales: [
        { 日付: "2026-03-01", チャネル: "店頭", 商品: "ブレンド", 金額: 1200 },
        { 日付: "2026-03-02", チャネル: "EC", 商品: "深煎り", 金額: 2400 },
      ],
      targets: miniTargets_,
    },
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"), "2 行の合計が出る: " + root.innerHTML.slice(0, 200));
  assert.ok(root.innerHTML.includes("ブレンド"), "表に商品名が出る");
  view.destroy();
});

test("data に渡した行列（見出し行つき）も使える", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: {} }),
    data: { sales: miniSales_, targets: miniTargets_ },
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"));
  assert.ok(root.innerHTML.includes("深煎り"));
  view.destroy();
});

test("読み口が失敗したら、やわらかい知らせを出して、誤りは 1 回だけ控える", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: { load: () => Promise.reject(new Error("つながりません")) },
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.ok(root.innerHTML.includes("ただいま表示できません"), "やわらかい知らせを出す");
  assert.equal(root.innerHTML.includes("つながりません"), false, "元の誤りの文は画面に出さない");
  assert.equal(env.calls.errors.length, 1, "誤りは 1 回だけ控える");
  view.destroy();
});

test("取り込めなかったデータだけが札になり、ほかの部品はそのまま描ける", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_ }, missing: ["targets"] }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"), "取り込めたデータの部品は描ける");
  assert.ok(root.innerHTML.includes("データ「targets」が見つかりません"), "足りないデータの部品だけが札になる");
  assert.equal(root.innerHTML.split('class="db-error"').length - 1, 1, "札は 1 枚だけ");
  view.destroy();
});

// ---- URL の # ---------------------------------------------------------------

test("起動のときに URL の # を読み、絞り込みを変えると # に書く", async () => {
  const env = fakeEnv_();
  env.location.hash = "#db.p=all&db.d." + encodeURIComponent("チャネル") + "=EC";
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
  });
  await settled_();
  assert.ok(root.innerHTML.includes('value="EC" selected'), "# の区分が選ばれている");
  assert.ok(root.innerHTML.includes("¥2,400"), "EC の分だけが数えられる");

  const select = fakeElement_({ "data-action": "set-period" });
  select.value = "thisMonth";
  fire_(root, "change", { target: select });
  assert.ok(env.calls.replaced.length > 0, "# を書き換える");
  assert.ok(env.calls.replaced[env.calls.replaced.length - 1].includes("#db.p=thisMonth"), "選んだ期間が # に入る");
  view.destroy();
});

test("絞り込みを最初に戻すと # を空にする", async () => {
  const env = fakeEnv_();
  env.location.hash = "#db.p=all";
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
  });
  await settled_();
  const select = fakeElement_({ "data-action": "set-period" });
  select.value = "last7";
  fire_(root, "change", { target: select });
  fire_(root, "click", { target: fakeElement_({ "data-action": "reset" }) });
  assert.equal(env.calls.replaced[env.calls.replaced.length - 1], "/demo/index.html", "# が消える");
  view.destroy();
});

test("hash: false のときは URL に触らない", async () => {
  const env = fakeEnv_();
  env.location.hash = "#db.p=all";
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  const select = fakeElement_({ "data-action": "set-period" });
  select.value = "last7";
  fire_(root, "change", { target: select });
  assert.equal(env.calls.replaced.length, 0);
  assert.equal(env.window.listeners.length, 0, "window には何も付けない");
  view.destroy();
});

// ---- 後片づけ ---------------------------------------------------------------

test("destroy() は付けた listener をすべて外す", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
  });
  await settled_();
  assert.ok(root.listeners.length >= 6, "root に委譲の listener を付ける");
  assert.equal(env.window.listeners.length, 1, "window には hashchange だけ");
  view.destroy();
  assert.equal(root.listeners.length, 0);
  assert.equal(env.window.listeners.length, 0);
  assert.equal(root.innerHTML, "");
});

// ---- 取り込み（source-web） -------------------------------------------------

/** URL ごとに決まった中身を返す fetch のふり。取りに行った URL を控える */
function fakeFetch_(map, calls) {
  return (url) => {
    calls.fetched.push(url);
    if (!Object.prototype.hasOwnProperty.call(map, url)) {
      return Promise.resolve({ ok: false, headers: { get: () => "" }, text: () => Promise.resolve("") });
    }
    const entry = map[url];
    return Promise.resolve({
      ok: true,
      headers: { get: (name) => (name === "content-type" ? entry.type || "text/csv" : "") },
      text: () => Promise.resolve(entry.body),
    });
  };
}

const webConfig_ = JSON.stringify(miniConfig_());
const webSalesCsv_ = "日付,チャネル,商品,金額\r\n2026-03-01,店頭,ブレンド,1200\r\n2026-03-02,EC,深煎り,2400\r\n";
const webTargetsCsv_ = "月,目標額\r\n2026-03,100000\r\n";

function webMap_() {
  return {
    "./dashboard.config.json": { body: webConfig_, type: "application/json" },
    "./sales.csv": { body: webSalesCsv_ },
    "./targets.csv": { body: webTargetsCsv_ },
  };
}

test("設定も CSV も取りに行って組み立てる", async () => {
  const env = fakeEnv_();
  env.fetch = fakeFetch_(webMap_(), env.calls);
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, { config: "./dashboard.config.json", today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"), "取り込んだ行で数えられる");
  assert.deepEqual(env.calls.fetched.slice(0, 1), ["./dashboard.config.json"]);
  assert.equal(env.calls.fetched.length, 3);
  view.destroy();
});

test("取りに行けなかったデータは、その部品だけが札になる", async () => {
  const env = fakeEnv_();
  const map = webMap_();
  delete map["./targets.csv"];
  env.fetch = fakeFetch_(map, env.calls);
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, { config: "./dashboard.config.json", today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"));
  assert.ok(root.innerHTML.includes("データ「targets」が見つかりません"));
  view.destroy();
});

test("設定の url は javascript: や //よそのところ を断る", async () => {
  for (const bad of ["javascript:alert(1)", "//example.test/x.json", "http://example.test/x.json", "/\\example.test/x.json"]) {
    const env = fakeEnv_();
    env.fetch = fakeFetch_(webMap_(), env.calls);
    setEnvironmentForTests(env);
    const root = fakeRoot_();
    const view = mountDashboard(root, { config: bad, today: "2026-03-15", hash: false });
    await settled_();
    await settled_();
    assert.equal(env.calls.fetched.length, 0, bad + " を取りに行ってしまう");
    assert.ok(root.innerHTML.includes("ただいま表示できません"), bad + " のときは知らせを出す");
    view.destroy();
    setEnvironmentForTests(null);
  }
});

test("覚えておく入れ物が例外を投げても、読み込みは進む", async () => {
  const env = fakeEnv_();
  env.fetch = fakeFetch_(webMap_(), env.calls);
  env.sessionStorage = fakeStorage_(true);
  setEnvironmentForTests(env);
  const root = fakeRoot_();
  const view = mountDashboard(root, { config: "./dashboard.config.json", today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"));
  assert.equal(env.calls.errors.length, 0);
  view.destroy();
});

test("cacheMinutes のあいだは 2 回目を取りに行かず、refresh() は取りに行く", async () => {
  const env = fakeEnv_();
  env.fetch = fakeFetch_(webMap_(), env.calls);
  setEnvironmentForTests(env);

  const first = mountDashboard(fakeRoot_(), { config: { ...miniConfig_(), cacheMinutes: 30 }, today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.deepEqual(env.calls.fetched, ["./sales.csv", "./targets.csv"]);
  first.destroy();

  const root = fakeRoot_();
  const second = mountDashboard(root, { config: { ...miniConfig_(), cacheMinutes: 30 }, today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.equal(env.calls.fetched.length, 2, "覚えておいた中身を使う");
  assert.ok(root.innerHTML.includes("¥3,600"), "覚えておいた中身でも数えられる");

  await second.refresh();
  await settled_();
  assert.equal(env.calls.fetched.length, 4, "refresh() は取りに行き直す");
  second.destroy();
});

test("cacheMinutes を過ぎたら取りに行き直す", async () => {
  const env = fakeEnv_();
  env.fetch = fakeFetch_(webMap_(), env.calls);
  let clock = new Date(2026, 2, 15, 9, 0, 0).getTime();
  env.now = () => new Date(clock);
  setEnvironmentForTests(env);

  const first = mountDashboard(fakeRoot_(), { config: { ...miniConfig_(), cacheMinutes: 5 }, today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.equal(env.calls.fetched.length, 2);
  first.destroy();

  clock += 6 * 60 * 1000;
  const second = mountDashboard(fakeRoot_(), { config: { ...miniConfig_(), cacheMinutes: 5 }, today: "2026-03-15", hash: false });
  await settled_();
  await settled_();
  assert.equal(env.calls.fetched.length, 4);
  second.destroy();
});

// ---- CSV のダウンロード -----------------------------------------------------

test("CSV のファイル名は、使えない字を落として「題-日付.csv」にする", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const config = miniConfig_();
  config.widgets[1].title = '商品別/明細: "3月"';
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config, datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  fire_(root, "click", { target: fakeElement_({ "data-action": "download-csv", "data-widget": "w2" }) });
  const link = env.calls.downloads[env.calls.downloads.length - 1];
  assert.ok(link, "a[download] を作る");
  assert.equal(link.download, "商品別 明細 3月-2026-03-15.csv");
  assert.equal(link.clicked, 1);
  view.destroy();
});

// ---- 束ねた配布物 -----------------------------------------------------------

test("dist/dashboard.js は仮の window の上で動き、window.Dashboard.mount を出す", () => {
  const code = readFileSync(join(root_, "dist", "dashboard.js"), "utf8");
  assert.equal(/^\s*(import|export)\s/m.test(code), false, "import / export が残っている");
  assert.equal(code.includes("まだ組み立て中です"), false, "仮の mountDashboard が残っている");

  const sandbox = { window: {}, document: undefined, console };
  createContext(sandbox);
  runInContext(code, sandbox);
  assert.equal(typeof sandbox.window.Dashboard.mount, "function");
  assert.equal(sandbox.window.Dashboard.version, PACKAGE_VERSION_);
});

test("dist/dashboard.mjs は動的 import でき、mountDashboard を出す", async () => {
  const module = await import(pathToFileURL(join(root_, "dist", "dashboard.mjs")).href);
  assert.equal(typeof module.mountDashboard, "function");
});

test("配布する 1 本には取り込みの読み口だけが入り、見本データの生成器は入らない", () => {
  for (const name of ["dashboard.js", "dashboard.mjs"]) {
    const code = readFileSync(join(root_, "dist", name), "utf8");
    assert.ok(code.includes("source-web.js"), name + " に取り込みの読み口が入っている");
    assert.equal(code.includes("source-memory.js"), false, name + " に見本の読み口を入れない");
    assert.equal(code.includes("samples.js"), false, name + " に見本データの生成器を入れない");
    assert.equal(code.includes("しおかぜ"), false, name + " に見本の店の名前を入れない");
  }
});

test("見本のページ（demo/app.js）には、見本の読み口と見本データの生成器が入っている", () => {
  const code = readFileSync(join(root_, "demo", "app.js"), "utf8");
  assert.ok(code.includes("source-web.js"));
  assert.ok(code.includes("source-memory.js"));
  assert.ok(code.includes("samples.js"));
});

test("Next.js テンプレの vendor は、配布する 1 本と同じ（見本データの生成器が入らない）", () => {
  const vendor = readFileSync(join(root_, "templates", "nextjs", "vendor", "dashboard.mjs"), "utf8");
  assert.equal(vendor, readFileSync(join(root_, "dist", "dashboard.mjs"), "utf8"));
  assert.equal(vendor.includes("source-memory.js"), false);
});

test('配布する 1 本で source: "memory" を指定すると、丁寧な知らせで断る（ja / en）', async () => {
  const code = readFileSync(join(root_, "dist", "dashboard.js"), "utf8");

  for (const [lang, wanted] of [
    ["ja", "見本のデータは、見本のページ"],
    ["en", "The sample data ships only with the demo page"],
  ]) {
    const sandbox = { window: {}, document: undefined, console: { error() {}, log() {}, warn() {} } };
    createContext(sandbox);
    runInContext(code, sandbox);

    const root = fakeRoot_();
    const view = sandbox.window.Dashboard.mount(root, { source: "memory", lang, today: "2026-03-15", hash: false });
    await settled_();
    assert.ok(root.innerHTML.includes(wanted), lang + " の知らせが出る: " + root.innerHTML.slice(0, 300));
    view.destroy();
  }
});

// ---- 画面が無くても確かめられる計算 -----------------------------------------

/** 手がかりを 1 本の文字にするときの区切り（main.js と同じ、番号で書いた字） */
const SEP_ = String.fromCharCode(31);

test("mainFocusKeyOf_: 役目と場所で手がかりを組み、data-focus-key があればそれを使う", () => {
  assert.equal(mainFocusKeyOf_({ action: "sort", widget: "w2", column: "1", name: "" }), ["sort", "w2", "1", ""].join(SEP_));
  assert.equal(mainFocusKeyOf_({ action: "sort", focus: "決め打ち", widget: "w2" }), "決め打ち");
  assert.equal(mainFocusKeyOf_({ action: "set-range", name: "to" }), ["set-range", "", "", "to"].join(SEP_));
  assert.equal(mainFocusKeyOf_({ action: "" }), null, "役目の無い要素には手がかりを作らない");
  assert.equal(mainFocusKeyOf_(null), null);
  // 列が違えば手がかりも違う（並べ替えのあとに、別の列へ focus が飛ばない）
  assert.notEqual(
    mainFocusKeyOf_({ action: "sort", widget: "w2", column: "1" }),
    mainFocusKeyOf_({ action: "sort", widget: "w2", column: "2" })
  );
  // 区切りは、生の制御文字ではなく番号で書いた字であること（<script> に差し込んでも壊れない）
  assert.equal(mainFocusKeyOf_({ action: "a", widget: "b" }).charCodeAt(1), 31);
});

test("mainNearestBandIndex_: 画面の座標を図の座標に移して、いちばん近い帯を選ぶ", () => {
  // 図の幅 800 を、画面では左 100 から 400 の幅で描いている（画面の 1px = 図の 2px）
  const rect = { left: 100, top: 0, width: 400, height: 200 };
  const bands = [0, 200, 400, 600];

  assert.equal(mainNearestBandIndex_(100, rect, 800, bands), 0, "左端は 0 番");
  assert.equal(mainNearestBandIndex_(200, rect, 800, bands), 1, "画面 +100 は図 200");
  assert.equal(mainNearestBandIndex_(260, rect, 800, bands), 2, "図 320 は 400 のほうが近い");
  assert.equal(mainNearestBandIndex_(499, rect, 800, bands), 3, "右端は最後の帯");
  assert.equal(mainNearestBandIndex_(0, rect, 800, bands), 0, "図の外でも、いちばん近い帯に吸い付く");
  assert.equal(mainNearestBandIndex_(300, rect, 800, [0, 400]), 1, "同じ近さなら、先に出てくるほうを選ぶ");

  assert.equal(mainNearestBandIndex_(200, rect, 800, []), -1, "帯が無ければ -1");
  assert.equal(mainNearestBandIndex_(200, { left: 0, width: 0 }, 800, [0]), -1, "幅の無い図は -1");
  assert.equal(mainNearestBandIndex_(200, rect, 0, [0]), -1, "viewBox の幅が読めなければ -1");
  assert.equal(mainNearestBandIndex_(200, null, 800, [0]), -1, "場所が読めなければ -1");
  assert.equal(mainNearestBandIndex_(200, rect, 800, ["とんでもない値", 200]), 1, "数でない位置は飛ばす");
});

test("mainTipModel_: 吹き出しに出す形にそろえ、読めない中身は出さない", () => {
  const model = mainTipModel_({
    title: "9/13",
    rows: [{ color: 2, value: "¥1,200", label: "EC" }, { value: 3400, label: null }, "とんでもない値"],
  });
  assert.deepEqual(model, {
    title: "9/13",
    rows: [
      { color: 2, value: "¥1,200", label: "EC" },
      { color: null, value: "3400", label: "" },
    ],
  });
  assert.equal(mainTipModel_({ title: "題" }), null, "行の並びが無ければ出さない");
  assert.equal(mainTipModel_(null), null);
  assert.deepEqual(mainTipModel_({ rows: [] }), { title: "", rows: [] });
  assert.equal(mainTipModel_({ rows: [{ color: 1.5, value: "1" }] }).rows[0].color, null, "整数でない色の番号は付けない");
});

test("mainFileNameOf_: 使えない字を落として「題-日付.csv」にする", () => {
  assert.equal(mainFileNameOf_('商品別/明細: "3月"', "お店", "2026-03-15"), "商品別 明細 3月-2026-03-15.csv");
  assert.equal(mainFileNameOf_("", "しおかぜ珈琲店", "2026-03-15"), "しおかぜ珈琲店-2026-03-15.csv");
  assert.equal(mainFileNameOf_("", "", "2026-03-15"), "dashboard-2026-03-15.csv");
  assert.equal(mainFileNameOf_("///", "", "2026-03-15"), "dashboard-2026-03-15.csv");
  assert.equal(mainFileNameOf_("  余白  だけ  ", "", "2026-03-15"), "余白 だけ-2026-03-15.csv");
  assert.equal(mainFileNameOf_("改行" + String.fromCharCode(10) + "入り", "", "2026-03-15"), "改行 入り-2026-03-15.csv");
  // 続けて呼んでも同じ答えになる（使えない字の見分けが、前の呼び出しを引きずらない）
  assert.equal(mainFileNameOf_("a/b", "", "2026-03-15"), mainFileNameOf_("a/b", "", "2026-03-15"));
});

test("mainHashPrefixOf_: URL の # に付ける頭を決める", () => {
  assert.equal(mainHashPrefixOf_(undefined), "db");
  assert.equal(mainHashPrefixOf_(true), "db");
  assert.equal(mainHashPrefixOf_(false), "", "false は # を使わない");
  assert.equal(mainHashPrefixOf_("a"), "a");
  assert.equal(mainHashPrefixOf_("sales_2026-q1"), "sales_2026-q1");
  assert.equal(mainHashPrefixOf_(""), "db", "空は既定に戻す");
  assert.equal(mainHashPrefixOf_("大文字ABC"), "db", "使えない字は既定に戻す");
  assert.equal(mainHashPrefixOf_("a".repeat(21)), "db", "長すぎる頭は既定に戻す");
  assert.equal(mainHashPrefixOf_(0), "db");
});

test("mainHashOwned_: 空の # と、自分の頭の鍵だけの # にしか書かない", () => {
  assert.equal(mainHashOwned_("", "db"), true);
  assert.equal(mainHashOwned_("#", "db"), true);
  assert.equal(mainHashOwned_("#db.p=last30&db.d.%E3%83%81=EC", "db"), true);
  assert.equal(mainHashOwned_("#pricing", "db"), false, "ページ自身の目印は消さない");
  assert.equal(mainHashOwned_("#b.p=last7", "db"), false, "もう 1 つのダッシュボードの鍵も消さない");
  assert.equal(mainHashOwned_("#db.p=last7&pricing", "db"), false, "1 つでもよそのものが混じれば書かない");
  assert.equal(mainHashOwned_("#p=last7", "db"), false, "頭の無い鍵も、よそのものとして扱う");
  assert.equal(mainHashOwned_("#dbx.p=last7", "db"), false, "頭が似ていても、点までそろわなければ別もの");
  assert.equal(mainHashOwned_("#db.p=last7", ""), false, "頭が無いときは書かない");
});

test("mainTipPlacement_: 指のそばに置き、包みと画面の中に収める", () => {
  const box = {
    rootRect: { left: 0, top: 0, width: 800, height: 600 },
    rootWidth: 800,
    rootHeight: 600,
    viewWidth: 1000,
    viewHeight: 700,
  };

  // ふつうは指の右下に 14px 離して置く
  assert.deepEqual(mainTipPlacement_(Object.assign({ x: 100, y: 100, tipWidth: 200, tipHeight: 80 }, box)), { left: 114, top: 114 });
  // 右に収まらなければ、指の左がわへ回す（700 - 14 - 200）
  assert.equal(mainTipPlacement_(Object.assign({ x: 700, y: 100, tipWidth: 200, tipHeight: 80 }, box)).left, 486);
  // 下に収まらなければ、指の上がわへ回す（560 - 14 - 80）
  assert.equal(mainTipPlacement_(Object.assign({ x: 100, y: 560, tipWidth: 200, tipHeight: 80 }, box)).top, 466);

  // 包みが 0.8 倍に縮めて置かれた中でも、指のところに出る
  // 画面の x=440 は包みの中では (440-40)/0.8 = 500、そこから 14px 右
  const scaled = {
    rootRect: { left: 40, top: 20, width: 640, height: 480 },
    rootWidth: 800,
    rootHeight: 600,
    viewWidth: 1000,
    viewHeight: 700,
  };
  assert.deepEqual(mainTipPlacement_(Object.assign({ x: 440, y: 180, tipWidth: 128, tipHeight: 64 }, scaled)), { left: 514, top: 214 });

  // 包みの幅が読めないときは 1 倍として置き、目に見えている画面の中にだけ収める
  const unknown = { rootRect: { left: 0, top: 0, width: 0, height: 0 }, rootWidth: 0, rootHeight: 0, viewWidth: 390, viewHeight: 800 };
  assert.equal(mainTipPlacement_(Object.assign({ x: 380, y: 100, tipWidth: 260, tipHeight: 80 }, unknown)).left, 106);
  // 狭い画面では、左の端に寄せて、はみ出させない
  assert.equal(mainTipPlacement_(Object.assign({ x: 10, y: 100, tipWidth: 380, tipHeight: 80 }, unknown)).left, 8);
});

test("mainLoadWins_: いちばん新しい読み込みの返事だけを受け取る", () => {
  assert.equal(mainLoadWins_(3, 3, false), true);
  assert.equal(mainLoadWins_(2, 3, false), false, "古い読み込みの返事は入れない");
  assert.equal(mainLoadWins_(3, 3, true), false, "片づけたあとの返事も入れない");
});

// ---- 読み込みの前後関係 -----------------------------------------------------

/** 好きなときに返事を返せる読み口。settle に貯まった順に、好きな順で片づけられる */
function heldSource_() {
  const settle = [];
  return {
    settle,
    load() {
      return new Promise((resolve) => settle.push(resolve));
    },
  };
}

/** 題だけを変えた小さな設定と、その中身 */
function namedResult_(title) {
  const config = miniConfig_();
  config.title = title;
  return { config, datasets: { sales: miniSales_, targets: miniTargets_ } };
}

test("あとから始めた読み込みが先に片づいたら、遅れて届いた古い返事は入れない", async () => {
  setEnvironmentForTests(fakeEnv_());
  const source = heldSource_();
  const root = fakeRoot_();
  const view = mountDashboard(root, { source, today: "2026-03-15", hash: false });
  await settled_();
  const again = view.refresh();
  await settled_();
  assert.equal(source.settle.length, 2, "読み込みが 2 本始まっている");

  // あとから始めたほうが先に届く
  source.settle[1](namedResult_("新しい中身"));
  await settled_();
  assert.ok(root.innerHTML.includes("新しい中身"));

  // 先に始めたほうが遅れて届く
  source.settle[0](namedResult_("古い中身"));
  await settled_();
  assert.ok(root.innerHTML.includes("新しい中身"), "新しい中身のまま");
  assert.equal(root.innerHTML.includes("古い中身"), false, "古い中身で上書きしない");

  await again;
  view.destroy();
});

test("片づけたあとに届いた返事は、画面にも知らせにも出さない", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const source = heldSource_();
  const root = fakeRoot_();
  const view = mountDashboard(root, { source, today: "2026-03-15", hash: false });
  await settled_();
  view.destroy();

  source.settle[0](namedResult_("あとから届いた中身"));
  await settled_();
  assert.equal(root.innerHTML, "", "画面は空のまま");
  assert.equal(env.calls.errors.length, 0);
});

// ---- 指やペンでの操作 -------------------------------------------------------

/** 折れ線の図のふり。縦の線 1 本と、刻みの帯を 2 つ持つ */
function fakeChart_() {
  const tipOf = (title, value) => JSON.stringify({ title, rows: [{ color: 1, value, label: "EC" }] });
  const crosshair = fakeElement_({ visibility: "hidden" }, { tag: "line", className: "db-crosshair" });
  const first = fakeElement_({ "data-bucket": "0", "data-x": "100", "data-tip": tipOf("9/12", "¥1,200") }, { tag: "rect", className: "db-hit" });
  const second = fakeElement_({ "data-bucket": "1", "data-x": "600", "data-tip": tipOf("9/13", "¥3,400") }, { tag: "rect", className: "db-hit" });
  const svg = fakeElement_({ viewBox: "0 0 800 400" }, {
    tag: "svg",
    className: "db-chart-svg",
    inside: [crosshair, first, second],
    // 図の幅 800 を、画面では 400 の幅で描いている
    rect: { left: 0, top: 0, width: 400, height: 200, right: 400, bottom: 200 },
  });
  return { svg, crosshair, first, second };
}

/** 棒や KPI のような、1 つで完結する印のふり */
function fakeMark_(title, value) {
  return fakeElement_({ "data-tip": JSON.stringify({ title, rows: [{ value, label: "売上" }] }) }, { tag: "rect", className: "db-hit" });
}

/** 画面に出ている吹き出し（root に足された 1 つ） */
function tipOf_(root) {
  return root.children.filter((child) => child.className === "db-tip")[0] || null;
}

function tipShown_(root) {
  const tip = tipOf_(root);
  return tip !== null && tip.style.display === "block" && tip.getAttribute("aria-hidden") === "false";
}

function tipText_(root) {
  const tip = tipOf_(root);
  if (tip === null) return "";
  return tip.children.map((line) => line.children.map((cell) => cell.textContent).join(" ")).join(" / ");
}

/** 指やペンでの操作を組み立てる */
function touch_(target, x, y) {
  return { target, clientX: x, clientY: y, pointerType: "touch" };
}

async function mountForPointer_(env) {
  setEnvironmentForTests(env);
  const root = fakeRoot_(env);
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  return { root, view };
}

test("指で印に触れると吹き出しが出て、離しても読めるまま残る", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForPointer_(env);
  const mark = fakeMark_("コーヒー豆", "¥460,000");

  fire_(root, "pointerdown", touch_(mark, 120, 200));
  assert.equal(tipShown_(root), true, "触れたところの吹き出しが出る");
  assert.ok(tipText_(root).includes("¥460,000"), tipText_(root));

  fire_(root, "pointerup", touch_(mark, 120, 200));
  assert.equal(tipShown_(root), true, "指を離しても、値を読めるように残す");

  // 指を離したあと、置き場所から出ても消えない（指の操作では、離したあとにも出来事が届く）
  fire_(root, "pointerleave", { target: mark, pointerType: "touch" });
  assert.equal(tipShown_(root), true);
  view.destroy();
});

test("指で折れ線を横になぞると、縦の線が刻みを追いかける", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForPointer_(env);
  const chart = fakeChart_();

  fire_(root, "pointerdown", touch_(chart.first, 50, 100));
  assert.equal(chart.crosshair.getAttribute("x1"), "100", "触れたところに近い刻み");
  assert.equal(chart.crosshair.getAttribute("visibility"), "visible");
  assert.ok(tipText_(root).includes("¥1,200"));

  // 触れたまま右へなぞる（画面 300 は図の 600）
  fire_(root, "pointermove", touch_(chart.second, 300, 100));
  assert.equal(chart.crosshair.getAttribute("x1"), "600", "なぞった先の刻みへ動く");
  assert.ok(tipText_(root).includes("¥3,400"));

  fire_(root, "pointercancel", touch_(chart.second, 300, 100));
  assert.equal(tipShown_(root), true, "途中で取り消されても、最後の吹き出しは残す");
  view.destroy();
});

test("触れていないときの指の動きは、吹き出しを動かさない", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForPointer_(env);
  const chart = fakeChart_();

  fire_(root, "pointermove", touch_(chart.first, 50, 100));
  assert.equal(tipShown_(root), false, "触れていない指の動きでは出さない");

  fire_(root, "pointerdown", touch_(chart.first, 50, 100));
  fire_(root, "pointerup", touch_(chart.first, 50, 100));
  fire_(root, "pointermove", touch_(chart.second, 300, 100));
  assert.ok(tipText_(root).includes("¥1,200"), "離したあとの動きでも、触れたときの吹き出しのまま");
  view.destroy();
});

test("印の無いところに触れると吹き出しが消える。Escape と描き直しでも消える", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForPointer_(env);
  const mark = fakeMark_("コーヒー豆", "¥460,000");
  const empty = fakeElement_({}, { tag: "div", className: "db-card" });

  fire_(root, "pointerdown", touch_(mark, 120, 200));
  assert.equal(tipShown_(root), true);
  fire_(root, "pointerdown", touch_(empty, 10, 10));
  assert.equal(tipShown_(root), false, "印の無いところに触れたら消す");

  fire_(root, "pointerdown", touch_(mark, 120, 200));
  fire_(root, "keydown", { key: "Escape", target: mark });
  assert.equal(tipShown_(root), false, "Escape で消す");

  fire_(root, "pointerdown", touch_(mark, 120, 200));
  const select = root.querySelector('[data-action="set-period"]');
  select.value = "last7";
  fire_(root, "change", { target: select });
  assert.equal(tipShown_(root), false, "描き直したら消す");
  view.destroy();
});

test("マウスの動きは今までどおり。置き場所から出れば消える", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForPointer_(env);
  const chart = fakeChart_();

  // マウスは押していなくても、動かすだけで吹き出しが付いてくる
  fire_(root, "pointermove", { target: chart.second, clientX: 300, clientY: 100, pointerType: "mouse" });
  assert.equal(tipShown_(root), true);
  assert.equal(chart.crosshair.getAttribute("x1"), "600");

  fire_(root, "pointerleave", { target: chart.second, pointerType: "mouse" });
  assert.equal(tipShown_(root), false, "置き場所から出たら消える");
  assert.equal(chart.crosshair.getAttribute("visibility"), "hidden");
  view.destroy();
});

test("指の出来事の listener も、destroy() でひととおり外れる", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForPointer_(env);
  const types = root.listeners.map((entry) => entry.type);
  for (const type of ["pointerdown", "pointermove", "pointerup", "pointercancel", "pointerleave"]) {
    assert.ok(types.indexOf(type) !== -1, type + " を見ていない");
  }
  view.destroy();
  assert.equal(root.listeners.length, 0);
});

// ---- 同じ置き場所に 2 回 ----------------------------------------------------

test("同じ置き場所にもう一度組み立てると、先にいたほうを片づけてから差し替える", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const root = fakeRoot_(env);
  const first = mountDashboard(root, {
    source: fakeSource_(namedResult_("はじめの題")),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  const count = root.listeners.length;
  assert.ok(count >= 10, "委ねる出来事がひととおり付いている");

  const second = mountDashboard(root, {
    source: fakeSource_(namedResult_("あとの題")),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.equal(root.listeners.length, count, "listener が二重にならない");
  assert.ok(root.innerHTML.includes("あとの題"));

  first.destroy();
  assert.ok(root.innerHTML.includes("あとの題"), "古いほうを片づけても、いまの画面は消えない");
  assert.equal(root.listeners.length, count, "いまの画面の listener も残る");

  second.destroy();
  assert.equal(root.listeners.length, 0);
  assert.equal(root.innerHTML, "");
});

// ---- URL の # の持ち主 ------------------------------------------------------

/** 期間の select を選び直す（画面が変わったかを確かめるため） */
function pickPeriod_(root, period) {
  const select = root.querySelector('[data-action="set-period"]');
  select.value = period;
  fire_(root, "change", { target: select });
}

async function mountForHash_(env, hash) {
  setEnvironmentForTests(env);
  const root = fakeRoot_(env);
  const options = {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
  };
  if (hash !== undefined) options.hash = hash;
  const view = mountDashboard(root, options);
  await settled_();
  return { root, view };
}

test("ページ自身の目印が # に入っているときは、こちらからは書かない", async () => {
  const env = fakeEnv_();
  env.location.hash = "#pricing";
  const { root, view } = await mountForHash_(env);

  pickPeriod_(root, "last7");
  assert.equal(env.calls.replaced.length, 0, "よその目印を書き換えない");
  assert.equal(env.location.hash, "#pricing", "目印はそのまま");
  assert.ok(root.innerHTML.includes('value="last7" selected'), "絞り込みそのものは効く");

  fire_(root, "click", { target: fakeElement_({ "data-action": "reset" }) });
  assert.equal(env.location.hash, "#pricing", "戻すときも、よその目印を消さない");
  assert.equal(env.calls.replaced.length, 0);
  view.destroy();
});

test("# が自分の鍵だけのときは書き換える。よその鍵が混じれば書かない", async () => {
  const own = fakeEnv_();
  own.location.hash = "#db.p=all";
  const first = await mountForHash_(own);
  pickPeriod_(first.root, "last7");
  assert.equal(own.calls.replaced[own.calls.replaced.length - 1], "#db.p=last7");
  first.view.destroy();
  setEnvironmentForTests(null);

  const shared = fakeEnv_();
  shared.location.hash = "#db.p=all&b.p=last90";
  const second = await mountForHash_(shared);
  assert.ok(second.root.innerHTML.includes('value="all" selected'), "自分の鍵は読める");
  pickPeriod_(second.root, "last7");
  assert.equal(shared.calls.replaced.length, 0, "よその鍵が混じっていれば書かない");
  second.view.destroy();
});

test("hash に頭を渡すと、その頭で読み書きする", async () => {
  const env = fakeEnv_();
  env.location.hash = "#a.p=last90";
  const { root, view } = await mountForHash_(env, "a");
  assert.ok(root.innerHTML.includes('value="last90" selected'), "自分の頭の鍵を読む");

  pickPeriod_(root, "last7");
  assert.equal(env.calls.replaced[env.calls.replaced.length - 1], "#a.p=last7");
  view.destroy();
  setEnvironmentForTests(null);

  // 形の合わない頭は、既定の db に戻す
  const fallback = fakeEnv_();
  const other = await mountForHash_(fallback, "大文字ABC");
  pickPeriod_(other.root, "last7");
  assert.equal(fallback.calls.replaced[fallback.calls.replaced.length - 1], "#db.p=last7");
  other.view.destroy();
});

test("# を書き換えられないページでも、絞り込みの画面は変わる", async () => {
  const env = fakeEnv_();
  env.history = {
    replaceState() {
      throw new Error("この枠では書き換えられません");
    },
  };
  // # そのものも書けないページ（入れ子の枠など）
  Object.defineProperty(env.location, "hash", {
    get() {
      return "";
    },
    set() {
      throw new Error("この枠では書き換えられません");
    },
  });

  const { root, view } = await mountForHash_(env);
  assert.doesNotThrow(() => pickPeriod_(root, "last7"));
  assert.ok(root.innerHTML.includes('value="last7" selected'), "URL に書けなくても、絞り込みは効く");
  assert.equal(env.calls.errors.length, 0);
  view.destroy();
});

// ---- 覚え書きの鍵 -----------------------------------------------------------

test("覚え書きの鍵は、置いたページの場所まで足して作る", async () => {
  const env = fakeEnv_();
  env.fetch = fakeFetch_(webMap_(), env.calls);
  setEnvironmentForTests(env);
  const options = { config: { ...miniConfig_(), cacheMinutes: 30 }, today: "2026-03-15", hash: false };

  env.location.href = "https://shop.example/ja/index.html";
  const first = mountDashboard(fakeRoot_(), options);
  await settled_();
  await settled_();
  assert.equal(env.calls.fetched.length, 2);
  assert.ok(
    Array.from(env.sessionStorage.box.keys()).indexOf("dbkit:https://shop.example/ja/sales.csv") !== -1,
    Array.from(env.sessionStorage.box.keys()).join(" / ")
  );
  first.destroy();

  // 同じ名前のデータを、別の場所に置いた同じ形のページ
  env.location.href = "https://shop.example/en/index.html";
  const second = mountDashboard(fakeRoot_(), options);
  await settled_();
  await settled_();
  assert.equal(env.calls.fetched.length, 4, "別の場所のものを取り違えない");
  second.destroy();
});

// ---- CSV の置き場所の後始末 -------------------------------------------------

async function mountForCsv_(env) {
  setEnvironmentForTests(env);
  const root = fakeRoot_(env);
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  fire_(root, "click", { target: fakeElement_({ "data-action": "download-csv", "data-widget": "w2" }) });
  return { root, view };
}

test("CSV の置き場所は、片づけるときにその場で手放す", async () => {
  const env = fakeEnv_();
  const { view } = await mountForCsv_(env);
  assert.deepEqual(env.calls.revoked, [], "書き出しの途中で消してしまわない");
  assert.equal(env.window.timers.size, 1, "手放すのを待ち合わせている");

  view.destroy();
  assert.deepEqual(env.calls.revoked, ["blob:dashboard"], "片づけるときに手放す");
  assert.equal(env.window.timers.size, 0, "待ち合わせも取りやめる");
});

test("待ち合わせが来たら手放し、そのあと片づけても二度は手放さない", async () => {
  const env = fakeEnv_();
  const { view } = await mountForCsv_(env);
  for (const run of Array.from(env.window.timers.values())) run();
  assert.deepEqual(env.calls.revoked, ["blob:dashboard"]);

  view.destroy();
  assert.deepEqual(env.calls.revoked, ["blob:dashboard"], "同じ置き場所を二度は手放さない");
});

// ---- 読み口が知らせた「渡せなかったデータ」 ---------------------------------

test("読み口が missing で知らせたデータは、行が付いていても札にする", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: [] }, missing: ["targets"] }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.ok(root.innerHTML.includes("¥3,600"), "渡せたデータの部品はそのまま描ける");
  assert.ok(root.innerHTML.includes("データ「targets」が見つかりません"), "知らせてきたデータは札にする");
  view.destroy();
});

test("mount に直に渡した行は、読み口が missing と言っても使う", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_ }, missing: ["targets"] }),
    data: { targets: miniTargets_ },
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.equal(root.innerHTML.includes("データ「targets」が見つかりません"), false);
  assert.ok(root.innerHTML.includes("100,000"), "直に渡した行で数えられる");
  view.destroy();
});

// ---- 描き直しと focus -------------------------------------------------------

test("日付を入れると 2 つとも読み取り、描き直したあとも同じ入力に focus が戻る", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const root = fakeRoot_(env);
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  pickPeriod_(root, "custom");
  const dates = root.querySelectorAll('[data-action="set-range"]');
  assert.equal(dates.length, 2, "「期間を指定」で日付の入力が 2 つ出る");

  const from = dates.filter((input) => input.getAttribute("name") === "from")[0];
  const to = dates.filter((input) => input.getAttribute("name") === "to")[0];
  from.value = "2026-03-01";
  to.value = "2026-03-01";
  to.focus();
  fire_(root, "change", { target: to });

  // 片方を変えただけでも、2 つとも読み取っている
  const after = root.querySelectorAll('[data-action="set-range"]');
  assert.deepEqual(
    after.map((input) => input.getAttribute("name") + "=" + input.value),
    ["from=2026-03-01", "to=2026-03-01"]
  );
  assert.ok(root.innerHTML.includes("¥1,200"), "指定した 1 日ぶんだけが数えられる");

  const active = env.document.activeElement;
  assert.equal(active.getAttribute("name"), "to", "操作していた入力に focus が戻る");
  assert.equal(active === to, false, "描き直しで作り直された、新しいほうの入力に戻っている");
  view.destroy();
});

test("並べ替えを押したあとも、同じ見出しのボタンに focus が戻る", async () => {
  const env = fakeEnv_();
  setEnvironmentForTests(env);
  const root = fakeRoot_(env);
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  const sort = root.querySelectorAll('[data-action="sort"]')[1];
  const column = sort.getAttribute("data-column");
  sort.focus();
  fire_(root, "click", { target: sort });

  const active = env.document.activeElement;
  assert.equal(active.getAttribute("data-action"), "sort");
  assert.equal(active.getAttribute("data-column"), column, "押した列の見出しに戻る");
  assert.equal(active === sort, false, "描き直しで作り直されたほうに戻っている");
  view.destroy();
});

test("URL の # を書き換えるときには、もう画面の描き直しが済んでいる", async () => {
  const env = fakeEnv_();
  const { root, view } = await mountForHash_(env);

  let seen = "";
  env.history.replaceState = (state, title, url) => {
    seen = root.innerHTML;
    env.calls.replaced.push(url);
  };

  pickPeriod_(root, "last7");
  assert.equal(env.calls.replaced.length, 1, "# を書き換えている");
  assert.ok(seen.includes('value="last7" selected'), "# を書くより先に、画面が新しくなっている");
  view.destroy();
});

// ---- 取りに行く直前の許可リスト（コード審査 I1） ----------------------------

test('source: "sheets" の設定に書かれた危ない url は、1 度も取りに行かない', async () => {
  for (const bad of ["javascript:alert(1)", "http://evil.example/sales.csv", "data:text/csv,a,b", "//evil.example/sales.csv"]) {
    const env = fakeEnv_();
    env.fetch = fakeFetch_({}, env.calls);
    setEnvironmentForTests(env);

    // source: "sheets" の設定は、これまで url を検査せずに写していた
    const config = {
      source: "sheets",
      lang: "ja",
      datasets: { sales: { url: bad, dateColumn: "日付" } },
      filters: { period: "all", dimensions: [] },
      widgets: [{ type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", size: "s" }],
    };
    const root = fakeRoot_();
    const view = mountDashboard(root, { config, today: "2026-03-15", hash: false });
    await settled_();
    await settled_();

    assert.deepEqual(env.calls.fetched, [], bad + " を取りに行ってしまう");
    assert.ok(root.innerHTML.includes("データ「sales」が見つかりません"), bad + " のときは札で知らせる");
    view.destroy();
    setEnvironmentForTests(null);
  }
});

test("設定の検査をすり抜けた url でも、取りに行く側がもう一度断る", async () => {
  const env = fakeEnv_();
  env.fetch = fakeFetch_({}, env.calls);
  setEnvironmentForTests(env);

  // parseConfig を通さずに、読み口へ直に危ない url の設定を渡す形（読み口だけを試す）
  const source = sourceWebCreate_({
    env,
    config: {
      lang: "ja",
      datasets: { sales: { url: "javascript:alert(1)" } },
      widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }],
    },
  });
  const loaded = await source.load({});
  assert.deepEqual(env.calls.fetched, [], "取りに行かない");
  assert.deepEqual(loaded.missing, ["sales"], "渡せなかったものとして知らせる");
});

// ---- url を書かないデータセット（文書審査 C2） ------------------------------

test("url を書かずに data で行を渡すと、そのまま動く（誤りの帯を出さない）", async () => {
  setEnvironmentForTests(fakeEnv_());
  const config = {
    title: "しおかぜ珈琲店 売上ダッシュボード",
    lang: "ja",
    datasets: { sales: { dateColumn: "日付" } },
    filters: { period: "all", dimensions: [] },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", size: "s" }],
  };
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    config,
    data: { sales: [{ 日付: "2026-03-01", 金額: 1200 }, { 日付: "2026-03-02", 金額: 2400 }] },
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  assert.ok(root.innerHTML.includes("¥3,600"));
  assert.equal(root.innerHTML.includes("設定をご確認ください"), false, "誤りの帯を出さない: " + root.innerHTML.slice(0, 300));
  view.destroy();
});

test("url も data も無いデータセットは、その部品だけが札になる", async () => {
  setEnvironmentForTests(fakeEnv_());
  const config = {
    lang: "ja",
    datasets: { sales: { dateColumn: "日付" } },
    filters: { period: "all", dimensions: [] },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", size: "s" }],
  };
  const root = fakeRoot_();
  const view = mountDashboard(root, { config, today: "2026-03-15", hash: false });
  await settled_();

  assert.ok(root.innerHTML.includes("データ「sales」が見つかりません"));
  assert.equal(root.innerHTML.includes("設定をご確認ください（"), false, "設定の誤りにはしない");
  view.destroy();
});

// ---- 絞り込みの form（コード審査 M8） ---------------------------------------

test("絞り込みの form を送信しようとしても、ページを読み直させない", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  assert.ok(
    root.listeners.some((entry) => entry.type === "submit"),
    "submit も受け取る"
  );
  let prevented = 0;
  fire_(root, "submit", { target: fakeElement_({}), preventDefault: () => (prevented += 1) });
  assert.equal(prevented, 1, "送信を止める");
  view.destroy();
});

// ---- 行の上限（コード審査 M12） ---------------------------------------------

test("行の上限は、型をそろえる前に切る（20,000 行 + 知らせ）", async () => {
  setEnvironmentForTests(fakeEnv_());
  const matrix = [["日付", "チャネル", "商品", "金額"]];
  for (let i = 0; i < 20005; i += 1) matrix.push(["2026-03-01", "店頭", "ブレンド", "100"]);
  matrix.push(["", "", "", ""]); // 空の行は数に入らない

  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: matrix, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  assert.ok(root.innerHTML.includes("20,000 行までを表示しています"), "上限の知らせを出す");
  assert.ok(root.innerHTML.includes("¥2,000,000"), "使うのは 20,000 行ぶんだけ（100 × 20,000）");
  view.destroy();
});

test("上限ちょうどの行数なら、知らせを出さない", async () => {
  setEnvironmentForTests(fakeEnv_());
  const matrix = [["日付", "チャネル", "商品", "金額"]];
  for (let i = 0; i < 20000; i += 1) matrix.push(["2026-03-01", "店頭", "ブレンド", "100"]);

  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: matrix, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();

  assert.equal(root.innerHTML.includes("20,000 行までを表示しています"), false);
  view.destroy();
});

// ---- 読み口が知らせてきた「切ってある」（コード審査 M6） --------------------

test("読み口が truncated でシートの名前を知らせてきたら、その知らせを出す", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ }, truncated: ["sales"] }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.ok(root.innerHTML.includes("20,000 行までを表示しています"), "こちらで切っていなくても知らせる");
  view.destroy();
});

test("読み口が truncated を知らせてこなければ、知らせを出さない", async () => {
  setEnvironmentForTests(fakeEnv_());
  const root = fakeRoot_();
  const view = mountDashboard(root, {
    source: fakeSource_({ config: miniConfig_(), datasets: { sales: miniSales_, targets: miniTargets_ } }),
    today: "2026-03-15",
    hash: false,
  });
  await settled_();
  assert.equal(root.innerHTML.includes("20,000 行までを表示しています"), false);
  view.destroy();
});
