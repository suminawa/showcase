import { test } from "node:test";
import assert from "node:assert/strict";
import { TABLE_ROW_LIMIT_, inferTypes, coerceRows, limitRows } from "../src/core/table.js";

test("inferTypes: 90% 以上が数なら number", () => {
  const rows = [{ 金額: "1,200" }, { 金額: "800" }, { 金額: "" }];
  assert.deepEqual(inferTypes(["金額"], rows), { 金額: "number" });
});

test("inferTypes: 90% 以上が日付として読めれば date", () => {
  const rows = [{ 日付: "2026-09-01" }, { 日付: "2026/9/2" }, { 日付: "2026年9月3日" }];
  assert.deepEqual(inferTypes(["日付"], rows), { 日付: "date" });
});

test("inferTypes: しきい値ちょうど（数）。空でない10件のうち9件が数なら number", () => {
  const rows = [
    { 金額: "1" }, { 金額: "2" }, { 金額: "3" }, { 金額: "4" }, { 金額: "5" },
    { 金額: "6" }, { 金額: "7" }, { 金額: "8" }, { 金額: "9" }, { 金額: "しおかぜ" },
  ];
  assert.deepEqual(inferTypes(["金額"], rows), { 金額: "number" });
});

test("inferTypes: しきい値未満（数）。空でない10件のうち8件が数なら text", () => {
  const rows = [
    { 金額: "1" }, { 金額: "2" }, { 金額: "3" }, { 金額: "4" }, { 金額: "5" },
    { 金額: "6" }, { 金額: "7" }, { 金額: "8" }, { 金額: "しおかぜ" }, { 金額: "みなと" },
  ];
  assert.deepEqual(inferTypes(["金額"], rows), { 金額: "text" });
});

test("inferTypes: しきい値ちょうど（日付）。空でない10件のうち9件が日付なら date", () => {
  const rows = [
    { 日付: "2026-09-01" }, { 日付: "2026-09-02" }, { 日付: "2026-09-03" }, { 日付: "2026-09-04" }, { 日付: "2026-09-05" },
    { 日付: "2026-09-06" }, { 日付: "2026-09-07" }, { 日付: "2026-09-08" }, { 日付: "2026-09-09" }, { 日付: "しおかぜ" },
  ];
  assert.deepEqual(inferTypes(["日付"], rows), { 日付: "date" });
});

test("inferTypes: しきい値未満（日付）。空でない10件のうち8件が日付なら text", () => {
  const rows = [
    { 日付: "2026-09-01" }, { 日付: "2026-09-02" }, { 日付: "2026-09-03" }, { 日付: "2026-09-04" }, { 日付: "2026-09-05" },
    { 日付: "2026-09-06" }, { 日付: "2026-09-07" }, { 日付: "2026-09-08" }, { 日付: "しおかぜ" }, { 日付: "みなと" },
  ];
  assert.deepEqual(inferTypes(["日付"], rows), { 日付: "text" });
});

test("inferTypes: しきい値未満は text", () => {
  const rows = [{ 列: "1" }, { 列: "2" }, { 列: "しおかぜ" }, { 列: "みなと" }];
  assert.deepEqual(inferTypes(["列"], rows), { 列: "text" });
});

test("inferTypes: 先頭 0 の数字列（電話番号など）は number に数えない", () => {
  const rows = [{ 電話: "090" }, { 電話: "080" }, { 電話: "070" }];
  assert.deepEqual(inferTypes(["電話"], rows), { 電話: "text" });
});

test("inferTypes: 13 桁以上の数字列は number に数えない", () => {
  const rows = [{ ID: "1234567890123" }, { ID: "9876543210987" }];
  assert.deepEqual(inferTypes(["ID"], rows), { ID: "text" });
});

test("inferTypes: 値が無い列は text", () => {
  const rows = [{ 備考: "" }, { 備考: null }, { 備考: undefined }];
  assert.deepEqual(inferTypes(["備考"], rows), { 備考: "text" });
});

test("inferTypes: overrides が推論に勝つ", () => {
  const rows = [{ 金額: "1200" }, { 金額: "800" }];
  assert.deepEqual(inferTypes(["金額"], rows, { 金額: "text" }), { 金額: "text" });
});

test("coerceRows: 型どおりに変換し、新しい行を返す（元の行は変えない）", () => {
  const types = { 金額: "number", 日付: "date", 名前: "text" };
  const rows = [{ 金額: "1,200円", 日付: "2026/9/19", 名前: " 太郎 " }];
  const result = coerceRows(rows, types);
  assert.deepEqual(result, [{ 金額: 1200, 日付: "2026-09-19", 名前: "太郎" }]);
  assert.deepEqual(rows, [{ 金額: "1,200円", 日付: "2026/9/19", 名前: " 太郎 " }], "元の行は変わらない");
  assert.notEqual(result[0], rows[0], "別のオブジェクトになっている");
});

test("coerceRows: 読めない値は null。text は空文字になる", () => {
  const types = { 金額: "number", 日付: "date", 名前: "text" };
  const rows = [{ 金額: "しおかぜ", 日付: "きょう", 名前: null }];
  assert.deepEqual(coerceRows(rows, types), [{ 金額: null, 日付: null, 名前: "" }]);
});

test("limitRows: 上限以下ならそのまま", () => {
  const rows = [{ a: 1 }, { a: 2 }];
  assert.deepEqual(limitRows(rows, 5), { rows, truncated: false });
});

test("limitRows: 上限を超えたら先頭から切り、truncated: true", () => {
  const rows = Array.from({ length: 25000 }, (_, i) => ({ i }));
  const result = limitRows(rows);
  assert.equal(result.rows.length, 20000, "既定の上限は 20000");
  assert.equal(result.truncated, true);
  assert.deepEqual(result.rows[0], { i: 0 });
  assert.deepEqual(result.rows[19999], { i: 19999 });
});

/** { "__proto__": … } と書くと素性が変わってしまうので、1 項目ずつ置いて入れ物を作る */
function own_(pairs) {
  const box = {};
  for (const [name, value] of pairs) Object.defineProperty(box, name, { value, writable: true, enumerable: true, configurable: true });
  return box;
}

test("inferTypes・coerceRows: JS が最初から持っている名前の列でも、取り違えない（コード審査 M2）", () => {
  const columns = ["constructor", "__proto__", "toString"];
  const rows = [own_([["constructor", "1"], ["__proto__", "2026-09-01"], ["toString", "あ"]])];

  // 上書きは自分が持つ項目だけを読む（Object.prototype.toString を型として拾わない）
  const types = inferTypes(columns, rows, {});
  assert.equal(types["constructor"], "number");
  assert.equal(types["toString"], "text");
  assert.equal(types["__proto__"], "date");
  assert.deepEqual(Object.keys(types).sort(), columns.slice().sort(), "3 列ぶんが自分の項目として入る");
  assert.equal(Object.getPrototypeOf(types), Object.prototype, "型の入れ物の素性は書き換わらない");

  const forced = inferTypes(columns, rows, own_([["constructor", "text"]]));
  assert.equal(forced["constructor"], "text", "書いた上書きは効く");

  const coerced = coerceRows(rows, types);
  assert.equal(coerced[0]["constructor"], 1);
  assert.equal(coerced[0]["__proto__"], "2026-09-01");
  assert.deepEqual(Object.keys(coerced[0]).sort(), columns.slice().sort());
  assert.equal(Object.getPrototypeOf(coerced[0]), Object.prototype);
});

test("limitRows: 上限は TABLE_ROW_LIMIT_ の 1 か所から来る", () => {
  assert.equal(TABLE_ROW_LIMIT_, 20000);
  const rows = new Array(TABLE_ROW_LIMIT_ + 1).fill(0).map((_, i) => ({ a: i }));
  const limited = limitRows(rows);
  assert.equal(limited.rows.length, TABLE_ROW_LIMIT_);
  assert.equal(limited.truncated, true);
});
