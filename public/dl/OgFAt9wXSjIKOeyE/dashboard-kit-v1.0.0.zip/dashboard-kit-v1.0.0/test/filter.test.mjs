import { test } from "node:test";
import assert from "node:assert/strict";
import { initialFilters, resolveRange, applyFilters, dimensionOptions, encodeFilters, decodeFilters } from "../src/core/filter.js";

const CONFIG = {
  filters: { period: "thisMonth", from: "", to: "", dimensions: ["チャネル", "カテゴリ"] },
};

// 列名がそのまま自分のキーになるので、__proto__ のような特別な名前の列でも安全な形で組み立てる。
// オブジェクトのリテラルでは __proto__ というキーそのものが作れないので、キーと値の組の並びから作る
function nullProtoMap(entries) {
  const map = Object.create(null);
  for (const [key, value] of entries) map[key] = value;
  return map;
}

const CONFIG_WITH_PROTO_NAMES = {
  filters: { period: "thisMonth", from: "", to: "", dimensions: ["__proto__", "constructor", "チャネル"] },
};

test("initialFilters: 区分の列を空の絞り込みにそろえる", () => {
  const filters = initialFilters(CONFIG, "2026-09-19");
  assert.equal(filters.period, "thisMonth");
  assert.deepEqual(filters.dimensions, nullProtoMap([["チャネル", ""], ["カテゴリ", ""]]));
});

test("initialFilters: __proto__ や constructor という名前の列も、そのまま自分のキーとして持てる", () => {
  const filters = initialFilters(CONFIG_WITH_PROTO_NAMES, "2026-09-19");
  assert.deepEqual(
    Object.keys(filters.dimensions).sort(),
    ["__proto__", "constructor", "チャネル"].sort()
  );
  for (const column of ["__proto__", "constructor", "チャネル"]) {
    assert.equal(Object.prototype.hasOwnProperty.call(filters.dimensions, column), true);
    assert.equal(filters.dimensions[column], "");
  }
});

test("initialFilters: period が custom のときは設定の from/to をそのまま使う", () => {
  const config = { filters: { period: "custom", from: "2026-08-01", to: "2026-08-31", dimensions: [] } };
  const filters = initialFilters(config, "2026-09-19");
  assert.equal(filters.from, "2026-08-01");
  assert.equal(filters.to, "2026-08-31");
});

test("resolveRange: custom は from/to をそのまま返し、片側だけの指定も許す", () => {
  assert.deepEqual(resolveRange({ period: "custom", from: "2026-09-01", to: "2026-09-10" }, "2026-09-19"), {
    from: "2026-09-01",
    to: "2026-09-10",
  });
  assert.deepEqual(resolveRange({ period: "custom", from: "", to: "2026-09-10" }, "2026-09-19"), { from: "", to: "2026-09-10" });
  assert.deepEqual(resolveRange({ period: "custom", from: "2026-09-01", to: "" }, "2026-09-19"), { from: "2026-09-01", to: "" });
});

test("resolveRange: プリセットは periodRange と同じ範囲を返す", () => {
  assert.deepEqual(resolveRange({ period: "last7" }, "2026-09-19"), { from: "2026-09-13", to: "2026-09-19" });
});

test("resolveRange: all は範囲なし（両端とも空）", () => {
  assert.deepEqual(resolveRange({ period: "all" }, "2026-09-19"), { from: "", to: "" });
});

const SALES_ROWS = [
  { 日付: "2026-09-01", チャネル: "EC", カテゴリ: "豆", 金額: 1000 },
  { 日付: "2026-09-10", チャネル: "店舗", カテゴリ: "豆", 金額: 2000 },
  { 日付: "2026-09-19", チャネル: "EC", カテゴリ: "菓子", 金額: 1500 },
  { 日付: null, チャネル: "EC", カテゴリ: "豆", 金額: 500 },
];

test("applyFilters: 期間の端（from・to）を含む", () => {
  const rows = applyFilters(SALES_ROWS, { dateColumn: "日付", range: { from: "2026-09-01", to: "2026-09-10" }, dimensions: {} });
  assert.deepEqual(
    rows.map((r) => r.日付),
    ["2026-09-01", "2026-09-10"]
  );
});

test("applyFilters: 範囲が無い（all）ときは日付が null の行も残す", () => {
  const rows = applyFilters(SALES_ROWS, { dateColumn: "日付", range: { from: "", to: "" }, dimensions: {} });
  assert.equal(rows.length, SALES_ROWS.length);
});

test("applyFilters: 期間つきのときは日付が null の行を外す", () => {
  const rows = applyFilters(SALES_ROWS, { dateColumn: "日付", range: { from: "2026-09-01", to: "" }, dimensions: {} });
  assert.equal(
    rows.some((r) => r.日付 === null),
    false
  );
});

test("applyFilters: dateColumn の無いデータセットは期間を無視する", () => {
  const rows = applyFilters(SALES_ROWS, { dateColumn: "", range: { from: "2026-09-01", to: "2026-09-01" }, dimensions: {} });
  assert.equal(rows.length, SALES_ROWS.length);
});

test("applyFilters: 区分 2 つの絞り込みは AND で効く", () => {
  const rows = applyFilters(SALES_ROWS, {
    dateColumn: "日付",
    range: { from: "", to: "" },
    dimensions: { チャネル: "EC", カテゴリ: "豆" },
  });
  assert.deepEqual(
    rows.map((r) => r.金額),
    [1000, 500]
  );
});

test("applyFilters: 絞り込みの値が空文字の列は無視する", () => {
  const rows = applyFilters(SALES_ROWS, { dateColumn: "日付", range: { from: "", to: "" }, dimensions: { チャネル: "" } });
  assert.equal(rows.length, SALES_ROWS.length);
});

test("applyFilters: 行に無い列を絞り込みに指定すると、その値が空文字でない限り一致しない", () => {
  const rows = applyFilters(SALES_ROWS, { dateColumn: "日付", range: { from: "", to: "" }, dimensions: { 担当: "店長" } });
  assert.equal(rows.length, 0);
});

test("dimensionOptions: 全データから名前順で空を外す", () => {
  const rows = [{ チャネル: "店舗" }, { チャネル: "EC" }, { チャネル: "" }, { チャネル: null }, { チャネル: "EC" }];
  assert.deepEqual(dimensionOptions(rows, "チャネル"), ["EC", "店舗"]);
});

test("dimensionOptions: max を超えた分は切る", () => {
  const rows = [{ 列: "a" }, { 列: "b" }, { 列: "c" }];
  assert.deepEqual(dimensionOptions(rows, "列", 2), ["a", "b"]);
});

test("encodeFilters: p と d. をそれぞれ encodeURIComponent する", () => {
  const hash = encodeFilters({ period: "last30", from: "", to: "", dimensions: { チャネル: "EC", カテゴリ: "" } });
  assert.equal(hash, "db.p=last30&db.d.%E3%83%81%E3%83%A3%E3%83%8D%E3%83%AB=EC");
  assert.equal(decodeURIComponent(hash), "db.p=last30&db.d.チャネル=EC");
});

test("encodeFilters: custom は from/to を足す。先頭に # を付けない", () => {
  const hash = encodeFilters({ period: "custom", from: "2026-09-01", to: "2026-09-19", dimensions: {} });
  assert.equal(hash, "db.p=custom&db.from=2026-09-01&db.to=2026-09-19");
  assert.equal(hash.startsWith("#"), false);
});

test("encodeFilters: custom で片側だけ指定のときは、指定した側だけを足す", () => {
  assert.equal(encodeFilters({ period: "custom", from: "2026-09-01", to: "", dimensions: {} }), "db.p=custom&db.from=2026-09-01");
  assert.equal(encodeFilters({ period: "custom", from: "", to: "2026-09-19", dimensions: {} }), "db.p=custom&db.to=2026-09-19");
});

test("decodeFilters と encodeFilters は往復する", () => {
  const filters = {
    period: "custom",
    from: "2026-09-01",
    to: "2026-09-19",
    dimensions: nullProtoMap([["チャネル", "EC"], ["カテゴリ", "豆"]]),
  };
  const hash = encodeFilters(filters);
  const decoded = decodeFilters(hash, CONFIG);
  assert.deepEqual(decoded, filters);
});

test("decodeFilters: 列名が __proto__ でも自分のキーとして受け取る", () => {
  const decoded = decodeFilters("db.p=last7&db.d.__proto__=EC", CONFIG_WITH_PROTO_NAMES);
  assert.equal(decoded.period, "last7");
  assert.equal(Object.prototype.hasOwnProperty.call(decoded.dimensions, "__proto__"), true);
  assert.equal(decoded.dimensions["__proto__"], "EC");
});

test("decodeFilters と encodeFilters は __proto__ や constructor という列名でも往復する", () => {
  const filters = {
    period: "custom",
    from: "2026-09-01",
    to: "2026-09-19",
    dimensions: nullProtoMap([
      ["__proto__", "EC"],
      ["constructor", "本店"],
      ["チャネル", "EC"],
    ]),
  };
  const hash = encodeFilters(filters);
  const decoded = decodeFilters(hash, CONFIG_WITH_PROTO_NAMES);
  assert.deepEqual(decoded, filters);
});

test("initialFilters・decodeFilters を __proto__ という列名で使っても Object.prototype 自体は変わらない", () => {
  const before = Object.keys(Object.prototype).sort();
  initialFilters(CONFIG_WITH_PROTO_NAMES, "2026-09-19");
  decodeFilters("db.p=last7&db.d.__proto__=EC&db.d.constructor=本店", CONFIG_WITH_PROTO_NAMES);
  assert.deepEqual(Object.keys(Object.prototype).sort(), before);
  assert.equal(({}).__proto__, Object.prototype);
});

test("decodeFilters: 先頭の # の有無どちらも読める", () => {
  assert.deepEqual(decodeFilters("#db.p=last7", CONFIG), { period: "last7" });
  assert.deepEqual(decodeFilters("db.p=last7", CONFIG), { period: "last7" });
});

test("decodeFilters: 知らない preset と知らない区分の列は捨てる", () => {
  const decoded = decodeFilters("db.p=そんな期間はない&db.d.担当=店長&db.d.チャネル=EC", CONFIG);
  assert.equal(decoded.period, undefined);
  assert.deepEqual(decoded.dimensions, nullProtoMap([["チャネル", "EC"]]));
});

test("decodeFilters: custom は from/to が日付キーのときだけ受け取る", () => {
  assert.deepEqual(decodeFilters("db.p=custom&db.from=とんでもない値&db.to=2026-09-19", CONFIG), { period: "custom", to: "2026-09-19" });
});

test("decodeFilters: 壊れた %encoding があっても例外を投げず、その組だけ捨てる", () => {
  assert.doesNotThrow(() => decodeFilters("db.p=last7&db.d.チャネル=%E3%81", CONFIG));
  const decoded = decodeFilters("db.p=last7&db.d.チャネル=%E3%81", CONFIG);
  assert.equal(decoded.period, "last7");
  assert.equal(decoded.dimensions, undefined);
});

test("decodeFilters: 空文字を渡しても空の部分的な設定を返す", () => {
  assert.deepEqual(decodeFilters("", CONFIG), {});
  assert.deepEqual(decodeFilters("#", CONFIG), {});
});

// ---- 鍵の頭（1 つのページに置かれたほかのものと混ざらないように） -----------

test("encodeFilters: 頭を指定すると、すべての鍵がその頭から始まる", () => {
  const filters = { period: "custom", from: "2026-09-01", to: "2026-09-19", dimensions: { チャネル: "EC" } };
  const hash = encodeFilters(filters, "売場");
  assert.equal(decodeURIComponent(hash), "売場.p=custom&売場.from=2026-09-01&売場.to=2026-09-19&売場.d.チャネル=EC");
});

test("encodeFilters: 頭を渡さない・空のときは既定の db を使う", () => {
  const filters = { period: "last7", from: "", to: "", dimensions: {} };
  assert.equal(encodeFilters(filters), "db.p=last7");
  assert.equal(encodeFilters(filters, ""), "db.p=last7");
  assert.equal(encodeFilters(filters, null), "db.p=last7");
});

test("decodeFilters と encodeFilters は、指定した頭のままで往復する", () => {
  const filters = {
    period: "custom",
    from: "2026-09-01",
    to: "2026-09-19",
    dimensions: nullProtoMap([["チャネル", "EC"], ["カテゴリ", "豆"]]),
  };
  const hash = encodeFilters(filters, "a");
  assert.deepEqual(decodeFilters(hash, CONFIG, "a"), filters);
});

test("decodeFilters: 頭の違う鍵と、頭の無い鍵は、どちらも見ない", () => {
  // ページ自身の目印・もう 1 つのダッシュボードの鍵・頭を付けずに書かれた古い形
  const hash = "#pricing&b.p=last7&p=last90&db.p=last30";
  assert.deepEqual(decodeFilters(hash, CONFIG), { period: "last30" });
  assert.deepEqual(decodeFilters(hash, CONFIG, "b"), { period: "last7" });
  assert.deepEqual(decodeFilters(hash, CONFIG, "c"), {});
});

test("decodeFilters: ページの目印だけの # からは、何も読み取らない", () => {
  assert.deepEqual(decodeFilters("#pricing", CONFIG), {});
  assert.deepEqual(decodeFilters("#section-2", CONFIG), {});
});

test("1 つのページに 2 つ置いても、頭が違えば互いの絞り込みを取り違えない", () => {
  const left = { period: "last7", from: "", to: "", dimensions: nullProtoMap([["チャネル", "EC"]]) };
  const right = { period: "last90", from: "", to: "", dimensions: nullProtoMap([["チャネル", "店頭"]]) };

  // 2 つぶんの鍵が 1 つの # に並んでいても、それぞれが自分の頭の鍵だけを読み取る
  const together = encodeFilters(left, "a") + "&" + encodeFilters(right, "b");
  assert.deepEqual(decodeFilters(together, CONFIG, "a"), { period: "last7", dimensions: nullProtoMap([["チャネル", "EC"]]) });
  assert.deepEqual(decodeFilters(together, CONFIG, "b"), { period: "last90", dimensions: nullProtoMap([["チャネル", "店頭"]]) });
});
