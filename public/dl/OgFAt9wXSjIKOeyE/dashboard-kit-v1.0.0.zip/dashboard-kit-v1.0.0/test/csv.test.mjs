import { test } from "node:test";
import assert from "node:assert/strict";
import { parseCsv, rowsToObjects, toCsv } from "../src/core/csv.js";

test("parseCsv: 見出し行とデータ行を配列にする（CRLF）", () => {
  assert.deepEqual(parseCsv("a,b\r\n1,2\r\n"), [
    ["a", "b"],
    ["1", "2"],
  ]);
});

test("parseCsv: 先頭の BOM を外す", () => {
  assert.deepEqual(parseCsv("﻿a,b\n1,2\n"), [
    ["a", "b"],
    ["1", "2"],
  ]);
});

test("parseCsv: 引用符の中のカンマ・改行・二重引用符を読む", () => {
  const text = '"a,b","line1\nline2","she said ""hi"""\n';
  assert.deepEqual(parseCsv(text), [["a,b", "line1\nline2", 'she said "hi"']]);
});

test("parseCsv: 末尾の改行 1 つでは空行を作らない", () => {
  assert.deepEqual(parseCsv("a,b\n"), [["a", "b"]]);
  assert.deepEqual(parseCsv("a,b\n1,2\n"), [
    ["a", "b"],
    ["1", "2"],
  ]);
});

test("parseCsv: 途中の空行はそのまま 1 行として残す", () => {
  assert.deepEqual(parseCsv("a,b\n\n1,2\n"), [["a", "b"], [""], ["1", "2"]]);
});

test("parseCsv: 空文字は空の配列", () => {
  assert.deepEqual(parseCsv(""), []);
});

test("rowsToObjects: 見出しを textOf で整え、空見出しは列N、重複は名前 (2)", () => {
  const matrix = [
    [" 名前 ", "", "名前"],
    ["太郎", "x", "y"],
    ["", "", ""],
    [" ", "", ""],
  ];
  const result = rowsToObjects(matrix);
  assert.deepEqual(result.columns, ["名前", "列2", "名前 (2)"]);
  assert.deepEqual(result.rows, [{ 名前: "太郎", 列2: "x", "名前 (2)": "y" }]);
});

test("rowsToObjects: 見出ししか無い・空の行列でも壊れない", () => {
  assert.deepEqual(rowsToObjects([["a", "b"]]), { columns: ["a", "b"], rows: [] });
  assert.deepEqual(rowsToObjects([]), { columns: [], rows: [] });
});

test("toCsv: BOM つき CRLF で書き出す", () => {
  assert.equal(
    toCsv([
      ["a", "b"],
      ["1", "2"],
    ]),
    "﻿a,b\r\n1,2\r\n",
  );
});

test("toCsv: カンマ・引用符・改行を含むセルは引用符で囲む", () => {
  assert.equal(toCsv([["x,y"]]), '﻿"x,y"\r\n');
  assert.equal(toCsv([['he said "hi"']]), '﻿"he said ""hi"""\r\n');
  assert.equal(toCsv([["line1\nline2"]]), '﻿"line1\nline2"\r\n');
});

test("toCsv: 数式に見える先頭文字には ' を付ける。ただし数として読める値は付けない", () => {
  assert.equal(toCsv([["=SUM(A1)"]]), "﻿'=SUM(A1)\r\n");
  assert.equal(toCsv([["@mention"]]), "﻿'@mention\r\n");
  assert.equal(toCsv([["-12"]]), "﻿-12\r\n", "parseNumber で読める負の数はそのまま");
  // "+5" は先頭が + だが、parseNumber の正規表現は - しか許さないため数として読めない。
  // そのため数式ガードの対象になり、頭に ' が付く（parseNumber の契約と一致させる実装判断）。
  assert.equal(toCsv([["+5"]]), "﻿'+5\r\n");
});

test("toCsv → parseCsv は元の行列に戻る（往復）", () => {
  const matrix = [
    ["名前", "金額", "メモ"],
    ["しおかぜ珈琲店", "1,200", '改行\nと"引用符"とカンマ,を含む'],
  ];
  const csv = toCsv(matrix);
  assert.ok(csv.startsWith("﻿"));
  assert.deepEqual(parseCsv(csv), matrix);
});

test("rowsToObjects: JS が最初から持っている名前の見出しでも、番号を付け足さない（コード審査 M2）", () => {
  const made = rowsToObjects([
    ["constructor", "__proto__", "toString", "hasOwnProperty"],
    ["1", "2", "3", "4"],
  ]);
  assert.deepEqual(made.columns, ["constructor", "__proto__", "toString", "hasOwnProperty"], "(2) を付けない");
  assert.equal(made.rows.length, 1);
  assert.equal(Object.prototype.hasOwnProperty.call(made.rows[0], "__proto__"), true, "自分が持つ項目として入る");
  assert.equal(Object.getPrototypeOf(made.rows[0]), Object.prototype, "行の素性は書き換わらない");
  assert.equal(made.rows[0]["constructor"], "1");
  assert.equal(made.rows[0]["toString"], "3");
});

test("rowsToObjects: 同じ見出しが続いたときは、これまでどおり番号を付ける", () => {
  const made = rowsToObjects([["金額", "金額", "金額"], ["1", "2", "3"]]);
  assert.deepEqual(made.columns, ["金額", "金額 (2)", "金額 (3)"]);
});
