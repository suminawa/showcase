import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { basename, join } from "node:path";
import { sampleData, sampleSheets, SAMPLE_PRODUCTS } from "../src/core/samples.js";
import { parseConfig, configFromSheets, CONFIG_DEFINITION_COLUMNS_ } from "../src/core/config.js";
import { buildDashboard } from "../src/core/model.js";
import { parseCsv, rowsToObjects } from "../src/core/csv.js";
import { inferTypes, coerceRows } from "../src/core/table.js";
import { weekdayOf, monthOf, addDays } from "../src/core/dates.js";
import { ROOT, sampleFiles, SAMPLES_TODAY } from "../scripts/samples.mjs";
import { FORBIDDEN_WORDS } from "./helpers/forbidden.mjs";

// ---- 見本データを、そろった datasets（buildDashboard に渡せる形）にする ----

function toDataset_(matrix, overrides) {
  const { columns, rows } = rowsToObjects(matrix);
  const types = inferTypes(columns, rows, (overrides && overrides.types) || {});
  return { columns, rows: coerceRows(rows, types), types, truncated: false };
}

function buildForToday_(today, lang) {
  const { config: raw, datasets } = sampleData(today, lang || "ja");
  const { config, errors } = parseConfig(raw);
  const salesDataset = toDataset_(datasets.sales);
  const targetsDataset = toDataset_(datasets.targets);
  const model = buildDashboard({
    config,
    today,
    lang: lang || "ja",
    filters: config.filters,
    datasets: { sales: salesDataset, targets: targetsDataset },
  });
  return { raw, config, errors, salesDataset, targetsDataset, model };
}

// ---- 決まった式であること ------------------------------------------------

test("sampleData: 同じ today なら同じ出力になる（決まった式）", () => {
  const a = sampleData("2026-09-30", "ja");
  const b = sampleData("2026-09-30", "ja");
  assert.deepEqual(a, b);
});

test("sampleData: today が違えば中身は変わるが、見出し・形は同じ", () => {
  const a = sampleData("2026-09-30", "ja");
  const b = sampleData("2027-03-15", "ja");
  assert.notDeepEqual(a.datasets.sales, b.datasets.sales);
  assert.deepEqual(a.datasets.sales[0], b.datasets.sales[0], "見出し行は同じ");
  assert.deepEqual(a.datasets.targets[0], b.datasets.targets[0], "見出し行は同じ");
  assert.equal(a.datasets.sales[1].length, b.datasets.sales[1].length, "列の数は同じ");
});

// ---- 設定がそのまま通ること ------------------------------------------------

test("sampleData: config は parseConfig で誤りが出ない（ja / en）", () => {
  for (const lang of ["ja", "en"]) {
    const { config } = sampleData("2026-09-30", lang);
    const { errors } = parseConfig(config);
    assert.deepEqual(errors, [], lang + ": " + JSON.stringify(errors));
  }
});

// ---- buildDashboard が誤りの札・空の札を出さないこと ------------------------

const CHECK_TODAYS = ["2026-09-30", "2026-10-03", "2027-01-05"];

for (const today of CHECK_TODAYS) {
  test("buildDashboard: today=" + today + " で誤り・空の部品が無い", () => {
    const { errors, model } = buildForToday_(today, "ja");
    assert.deepEqual(errors, []);
    for (const widget of model.widgets) {
      assert.notEqual(widget.type, "error", JSON.stringify(widget));
      if (Object.prototype.hasOwnProperty.call(widget, "empty")) {
        assert.equal(widget.empty, false, widget.title + " が空です");
      }
    }
  });
}

// ---- 列の型 ---------------------------------------------------------------

test("列の型: 日付は date、数量・金額は number と推論される", () => {
  const { salesDataset } = buildForToday_(SAMPLES_TODAY, "ja");
  assert.equal(salesDataset.types["日付"], "date");
  assert.equal(salesDataset.types["数量"], "number");
  assert.equal(salesDataset.types["金額"], "number");
});

// ---- 180 日ぶん、1 日 3〜9 行 ------------------------------------------------

test("売上: today の 179 日前から today まで、どの日も 3〜9 行", () => {
  const { datasets } = sampleData(SAMPLES_TODAY, "ja");
  const body = datasets.sales.slice(1);
  const counts = new Map();
  for (const row of body) {
    const date = row[0];
    counts.set(date, (counts.get(date) || 0) + 1);
  }
  assert.equal(counts.size, 180, "180 日ぶんの日付があること");
  for (const [date, count] of counts) {
    assert.ok(count >= 3 && count <= 9, date + " の行数が " + count);
  }
});

// ---- 週末は店頭が多い（比は 1.35〜1.65） -------------------------------------

/** today ごとに使う、まるまる 1 か月ぶんの月間売上・前月比の確かめ */
const REVENUE_CHECK_TODAYS = [SAMPLES_TODAY, "2026-12-28", "2027-01-05"];

function weekendWeekdayStoreRatio_(today) {
  const { datasets } = sampleData(today, "ja");
  const body = datasets.sales.slice(1);
  let weekendSum = 0;
  let weekendCount = 0;
  let weekdaySum = 0;
  let weekdayCount = 0;
  for (const row of body) {
    const [date, channel, , , , amount] = row;
    if (channel !== "店頭") continue;
    const day = weekdayOf(date);
    if (day === 0 || day === 6) {
      weekendSum += amount;
      weekendCount += 1;
    } else {
      weekdaySum += amount;
      weekdayCount += 1;
    }
  }
  assert.ok(weekendCount > 0 && weekdayCount > 0, today + ": 週末・平日の店頭の行が両方あること");
  return weekendSum / weekendCount / (weekdaySum / weekdayCount);
}

for (const today of REVENUE_CHECK_TODAYS) {
  test("週末の店頭の売上の平均は、平日の店頭の売上の平均の 1.35〜1.65 倍（today=" + today + "）", () => {
    const ratio = weekendWeekdayStoreRatio_(today);
    assert.ok(ratio >= 1.35 && ratio <= 1.65, "ratio=" + ratio);
  });
}

// ---- 月ごとの売上がそれらしい大きさで、ゆるやかに伸びる ------------------------

/**
 * today から見た、まるまる 1 か月ぶんの月ごとの売上（端の半端な月は外す）。
 * 12 月をまたぐ月だけは、ギフトの山（決まりどおり）で上限・前月比の緩めの決まりを使う
 */
function fullMonthTotals_(today) {
  const { datasets } = sampleData(today, "ja");
  const body = datasets.sales.slice(1);
  const byMonth = new Map();
  for (const row of body) {
    const month = monthOf(row[0]);
    byMonth.set(month, (byMonth.get(month) || 0) + row[5]);
  }
  const from = addDays(today, -179);
  const fromMonth = monthOf(from);
  const todayMonth = monthOf(today);
  return Array.from(byMonth.keys())
    .filter((month) => month !== fromMonth && month !== todayMonth)
    .sort()
    .map((month) => ({ month, total: byMonth.get(month) }));
}

for (const today of REVENUE_CHECK_TODAYS) {
  test("まるまる 1 か月ぶんの月間売上は ¥1,200,000〜¥2,200,000 に収まる（12 月は ¥2,600,000 まで。today=" + today + "）", () => {
    const months = fullMonthTotals_(today);
    assert.ok(months.length >= 3, "まるまる 1 か月ぶんの比較ができていること");
    for (const { month, total } of months) {
      const upper = month.endsWith("-12") ? 2600000 : 2200000;
      assert.ok(total >= 1200000 && total <= upper, month + " の売上が " + total);
    }
  });

  test("月間売上の前月比は −6%〜+15%（12 月をまたぐ月だけ +35% まで。today=" + today + "）", () => {
    const months = fullMonthTotals_(today);
    for (let i = 1; i < months.length; i += 1) {
      const prev = months[i - 1];
      const curr = months[i];
      const change = (curr.total - prev.total) / prev.total;
      const upper = curr.month.endsWith("-12") ? 0.35 : 0.15;
      assert.ok(change >= -0.06 && change <= upper, prev.month + " → " + curr.month + " の前月比が " + (change * 100).toFixed(1) + "%");
    }
  });

  test("まるまる 1 か月ぶんの、最後の月の売上は最初の月の 1.12 倍以上（today=" + today + "）", () => {
    const months = fullMonthTotals_(today);
    const first = months[0].total;
    const last = months[months.length - 1].total;
    assert.ok(last >= first * 1.12, "最初の月 " + first + " → 最後の月 " + last);
  });
}

// ---- 目標に対する今月の進み ---------------------------------------------------

test("目標メーターの進み具合は 0.6〜1.0（today=" + SAMPLES_TODAY + "）", () => {
  const { model } = buildForToday_(SAMPLES_TODAY, "ja");
  const meter = model.widgets.find((w) => w.title === "今月の目標");
  assert.ok(meter, "目標の部品が見つかること");
  assert.equal(meter.type, "meter");
  assert.ok(meter.ratio >= 0.6 && meter.ratio <= 1.0, "ratio=" + meter.ratio);
});

// ---- ディスクに置いた見本（期間は「全期間」） --------------------------------

/** samples/<lang>/ に置いた設定と CSV を、買い手が開くときと同じように読んで組み立てる */
function buildFromDisk_(lang, today) {
  const dir = join(ROOT, "samples", lang);
  const raw = JSON.parse(readFileSync(join(dir, "dashboard.config.json"), "utf8"));
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, [], lang + " の見本の設定に誤りがあってはならない");
  const datasets = {};
  for (const [name, entry] of Object.entries(config.datasets)) {
    datasets[name] = toDataset_(parseCsv(readFileSync(join(dir, basename(entry.url)), "utf8")));
  }
  return buildDashboard({ config, today, lang, filters: config.filters, datasets });
}

/** 見本の CSV は 2026 年 9 月で終わっているので、いつ開いても目標は 9 月と比べることになる */
const DISK_TODAYS = ["2026-10-15", "2027-03-01"];
const DISK_MONTH_LABELS = { ja: "2026年9月", en: "Sep 2026" };

for (const lang of ["ja", "en"]) {
  for (const today of DISK_TODAYS) {
    test("ディスクの見本（" + lang + "）: today=" + today + " でも、目標はデータの最後の月の実績と比べる", () => {
      const model = buildFromDisk_(lang, today);
      const meter = model.widgets.find((widget) => widget.type === "meter");
      assert.ok(meter, "目標の部品が見つかること");
      assert.ok(meter.ratio >= 0.6 && meter.ratio <= 1.2, "ratio=" + meter.ratio + "（" + meter.valueFull + " / " + meter.targetFull + "）");
      assert.equal(meter.monthLabel, DISK_MONTH_LABELS[lang]);
    });

    test("ディスクの見本（" + lang + "）: today=" + today + " で誤り・空の部品が無い", () => {
      const model = buildFromDisk_(lang, today);
      for (const widget of model.widgets) {
        assert.notEqual(widget.type, "error", widget.title + ": " + widget.message);
        if (Object.prototype.hasOwnProperty.call(widget, "empty")) {
          assert.equal(widget.empty, false, widget.title + " が空です");
        }
      }
    });
  }
}

// ---- samples.js は純粋（Math.random を使わない） -----------------------------

test("samples.js は Math.random を使わない", () => {
  const code = readFileSync(join(ROOT, "src", "core", "samples.js"), "utf8");
  assert.equal(/Math\s*\.\s*random/.test(code), false);
});

// ---- 商品テーブル（金額 = 数量 × 単価。単価は 10 円刻みで 300〜12,000 円） --------------------

test("SAMPLE_PRODUCTS: 単価は 10 円刻みで 300〜12,000 円に収まり、商品名は重複しない", () => {
  const seenJa = new Set();
  const seenEn = new Set();
  for (const product of SAMPLE_PRODUCTS) {
    assert.equal(product.price % 10, 0, product.ja + " の単価が 10 円刻みでない: " + product.price);
    assert.ok(product.price >= 300 && product.price <= 12000, product.ja + " の単価が範囲外: " + product.price);
    assert.equal(seenJa.has(product.ja), false, "商品名（ja）が重複: " + product.ja);
    assert.equal(seenEn.has(product.en), false, "商品名（en）が重複: " + product.en);
    seenJa.add(product.ja);
    seenEn.add(product.en);
  }
});

/** カテゴリキーごとの、画面に出す文字（テストがねらいの文字を知っておくための固定表） */
const CATEGORY_LABELS_BY_KEY_ = {
  coffee: { ja: "コーヒー豆", en: "Coffee beans" },
  drip: { ja: "ドリップバッグ", en: "Drip bags" },
  equipment: { ja: "器具", en: "Equipment" },
  baked: { ja: "焼き菓子", en: "Baked goods" },
  gift: { ja: "ギフト", en: "Gifts" },
};

function productLookupByLabel_(isEn) {
  const map = new Map();
  for (const product of SAMPLE_PRODUCTS) map.set(isEn ? product.en : product.ja, product);
  return map;
}

const PRODUCT_ROW_CHECK_TODAYS = [SAMPLES_TODAY, "2026-12-28", "2027-01-05"];

for (const today of PRODUCT_ROW_CHECK_TODAYS) {
  for (const lang of ["ja", "en"]) {
    test("売上の行: 金額 = 数量 × 単価、数量は 60 以下の正の整数、商品のカテゴリは固定（today=" + today + ", lang=" + lang + "）", () => {
      const isEn = lang === "en";
      const { datasets } = sampleData(today, lang);
      const body = datasets.sales.slice(1);
      assert.ok(body.length > 0, "行が生成されていること");
      const lookup = productLookupByLabel_(isEn);
      for (const row of body) {
        const [, , categoryLabel, productLabel, qty, amount] = row;
        const product = lookup.get(productLabel);
        assert.ok(product, "商品テーブルに無い商品名: " + productLabel);
        assert.ok(Number.isInteger(qty) && qty > 0 && qty <= 60, productLabel + " の数量が不正: " + qty);
        assert.equal(amount, qty * product.price, productLabel + " の金額が「数量 × 単価」でない（" + qty + " × " + product.price + " ≠ " + amount + "）");
        const expectedCategoryLabel = CATEGORY_LABELS_BY_KEY_[product.category][isEn ? "en" : "ja"];
        assert.equal(categoryLabel, expectedCategoryLabel, productLabel + " のカテゴリが揺れている（" + categoryLabel + " ≠ " + expectedCategoryLabel + "）");
      }
    });
  }
}

// ---- 禁止語の一覧 -----------------------------------------------------------

// 内部でだけ使う呼び名は、字のまま書くとこのファイル自身が配布 zip の検査に
// 引っかかるので、test/helpers/forbidden.mjs が文字コードから組み立てたものを使う

function assertNoForbiddenWords_(text, label) {
  for (const word of FORBIDDEN_WORDS) {
    assert.equal(text.includes(word), false, label + " に禁止語「" + word + "」が含まれています");
  }
}

test("生成した見本データ・設定に禁止語が無い（ja / en）", () => {
  for (const lang of ["ja", "en"]) {
    const { config, datasets } = sampleData(SAMPLES_TODAY, lang);
    assertNoForbiddenWords_(JSON.stringify(config), "config(" + lang + ")");
    assertNoForbiddenWords_(JSON.stringify(datasets.sales), "sales(" + lang + ")");
    assertNoForbiddenWords_(JSON.stringify(datasets.targets), "targets(" + lang + ")");
  }
});

// ---- コミットした見本ファイルが samples.mjs の生成物と一致すること --------------

test("samples/ja・samples/en の 3 ファイルずつは、samples.mjs が 2026-09-30 で作るものと一致する", () => {
  const files = sampleFiles(SAMPLES_TODAY);
  for (const [relPath, expected] of Object.entries(files)) {
    const full = join(ROOT, "samples", relPath);
    assert.ok(existsSync(full), full + " が無い（npm run samples を実行してコミットしてください）");
    const actual = readFileSync(full, "utf8");
    assert.equal(actual, expected, relPath + " が samples.mjs の生成物と一致しません");
  }
});

// ---- シートの形の見本（設定・定義・データのシート） --------------------------

const SHEET_NAMES_ = {
  ja: { 売上: "sales", 目標: "targets" },
  en: { Sales: "sales", Targets: "targets" },
};

/** シートの見本と JSON の見本を見比べられるよう、データセットの名前を JSON 側の名前にそろえる */
function renameDatasets_(widgets, names) {
  return widgets.map((widget) => {
    const copy = Object.assign({}, widget);
    if (names[copy.dataset] !== undefined) copy.dataset = names[copy.dataset];
    if (copy.target !== null && typeof copy.target === "object") {
      copy.target = Object.assign({}, copy.target);
      if (names[copy.target.dataset] !== undefined) copy.target.dataset = names[copy.target.dataset];
    }
    return copy;
  });
}

test("sampleSheets: 設定・定義のシートは、JSON の見本と同じダッシュボードになる（ja / en）", () => {
  for (const lang of ["ja", "en"]) {
    const sheets = sampleSheets(SAMPLES_TODAY, lang);
    const fromSheets = parseConfig(configFromSheets(sheets.settings, sheets.definitions));
    const fromJson = parseConfig(sampleData(SAMPLES_TODAY, lang).config);

    assert.deepEqual(fromSheets.errors, [], lang + ": シートの見本に設定の誤りがあってはならない");
    assert.deepEqual(
      renameDatasets_(fromSheets.config.widgets, SHEET_NAMES_[lang]),
      fromJson.config.widgets,
      lang + ": シートの見本の部品は JSON の見本と同じになるはず"
    );
    assert.equal(fromSheets.config.title, fromJson.config.title);
    assert.equal(fromSheets.config.lang, fromJson.config.lang);
    assert.equal(fromSheets.config.theme, fromJson.config.theme);
    assert.deepEqual(fromSheets.config.filters, fromJson.config.filters);
  }
});

test("sampleSheets: データのシートは 売上・目標（英語は Sales・Targets）の見出しつきの行列", () => {
  const ja = sampleSheets(SAMPLES_TODAY, "ja");
  assert.deepEqual(Object.keys(ja.data), ["売上", "目標"]);
  assert.deepEqual(ja.data["売上"][0], ["日付", "チャネル", "カテゴリ", "商品", "数量", "金額"]);
  assert.deepEqual(ja.data["目標"][0], ["月", "目標額"]);
  assert.ok(ja.data["売上"].length > 100, "売上の行が少なすぎる");
  assert.deepEqual(ja.data["売上"], sampleData(SAMPLES_TODAY, "ja").datasets.sales, "JSON の見本と同じ行を使うはず");

  const en = sampleSheets(SAMPLES_TODAY, "en");
  assert.deepEqual(Object.keys(en.data), ["Sales", "Targets"]);
  assert.deepEqual(en.data["Targets"][0], ["Month", "Target"]);
});

test("sampleSheets: 設定・定義の見出しは 設定（項目・値）と 定義 の決まった列", () => {
  const { settings, definitions } = sampleSheets(SAMPLES_TODAY, "ja");
  assert.deepEqual(settings[0].slice(0, 2), ["項目", "値"]);
  assert.deepEqual(
    settings.slice(1).map((row) => row[0]),
    ["題名", "言語", "テーマ", "期間", "絞り込みの列"]
  );
  assert.deepEqual(definitions[0], CONFIG_DEFINITION_COLUMNS_);
  for (const row of definitions) assert.equal(row.length, CONFIG_DEFINITION_COLUMNS_.length, "定義の行は見出しと同じ列数にそろえるはず");
});

test("sampleSheets: シートの見本から組み立てたダッシュボードに、誤りの札も空の部品も出ない", () => {
  const sheets = sampleSheets(SAMPLES_TODAY, "ja");
  const { config, errors } = parseConfig(configFromSheets(sheets.settings, sheets.definitions));
  assert.deepEqual(errors, []);

  const model = buildDashboard({
    config,
    today: SAMPLES_TODAY,
    lang: "ja",
    filters: config.filters,
    datasets: { 売上: toDataset_(sheets.data["売上"]), 目標: toDataset_(sheets.data["目標"]) },
  });

  assert.equal(model.widgets.length, 10);
  for (const widget of model.widgets) {
    assert.equal(widget.type === "error", false, widget.title + " が誤りの札になっている: " + widget.message);
    assert.equal(widget.empty === true, false, widget.title + " が空になっている");
  }
});

test("sampleSheets: 同じ today なら同じ出力になる（決まった式）", () => {
  assert.deepEqual(sampleSheets("2026-09-30", "ja"), sampleSheets("2026-09-30", "ja"));
});
