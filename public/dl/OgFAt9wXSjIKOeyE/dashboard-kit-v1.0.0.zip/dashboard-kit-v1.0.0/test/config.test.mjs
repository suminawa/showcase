import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { CONFIG_DEFINITION_COLUMNS_, CONFIG_PERIODS_, DEFAULT_CONFIG, parseConfig, configFromSheets, configSheetNotes, isAllowedDataUrl } from "../src/core/config.js";
import { decodeFilters } from "../src/core/filter.js";
import { PERIOD_PRESETS } from "../src/ui/state.js";

// 設計書 §3-1 の JSON をそのまま書き写したもの（ゼロ件の誤りで通ることを確かめる）
const DESIGN_DOC_JSON = {
  title: "しおかぜ珈琲店 売上ダッシュボード",
  lang: "ja",
  theme: "auto",
  datasets: {
    sales: { url: "./sales.csv", dateColumn: "日付" },
    targets: { url: "./targets.csv" },
  },
  filters: { period: "thisMonth", dimensions: ["チャネル", "カテゴリ"] },
  widgets: [
    { type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", compare: "previous", goodWhen: "up", size: "s" },
    { type: "line", title: "売上の推移", dataset: "sales", value: "金額", agg: "sum", splitBy: "チャネル", bucket: "auto", format: "yen", size: "l" },
    { type: "bar", title: "カテゴリ別の売上", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum", top: 8, format: "yen", size: "m" },
    {
      type: "meter",
      title: "今月の目標",
      dataset: "sales",
      value: "金額",
      agg: "sum",
      target: { dataset: "targets", value: "目標額", matchMonth: "月" },
      format: "yen",
      size: "m",
    },
    {
      type: "table",
      title: "商品別",
      dataset: "sales",
      groupBy: "商品",
      columns: [
        { value: "数量", agg: "sum", label: "数量" },
        { value: "金額", agg: "sum", label: "売上", format: "yen" },
      ],
      sort: "売上",
      top: 20,
      size: "l",
    },
  ],
};

test("設計書 §3-1 の JSON は誤り 0 件で通る", () => {
  const { config, errors } = parseConfig(DESIGN_DOC_JSON);
  assert.deepEqual(errors, []);
  assert.equal(config.title, "しおかぜ珈琲店 売上ダッシュボード");
  assert.equal(config.widgets.length, 5);
  assert.deepEqual(
    config.widgets.map((w) => w.id),
    ["w1", "w2", "w3", "w4", "w5"]
  );
  assert.equal(config.widgets[0].compare, "previous", "sales に日付の列があるので previous のまま");
  assert.equal(config.widgets[1].dateColumn, "日付", "line の dateColumn は dataset から引き継ぐ");
  assert.deepEqual(config.widgets[3].target, { dataset: "targets", value: "目標額", agg: "sum", matchMonth: "月" });
  assert.equal(config.widgets[2].horizontal, "auto");
  assert.equal(config.widgets[4].columns.length, 2);
});

test("raw がオブジェクトでなければ、空の部品を持つ既定の形と 1 件の誤りを返す", () => {
  for (const bad of [null, undefined, 42, "文字列", [1, 2, 3], true]) {
    const { config, errors } = parseConfig(bad);
    assert.deepEqual(config, { ...DEFAULT_CONFIG, widgets: [] });
    assert.deepEqual(errors, ["dashboard: 設定を読み取れませんでした"]);
  }
});

test("誤りは dashboard: で始まり、lang: en なら英語になる", () => {
  const { errors } = parseConfig({ lang: "en", datasets: {}, widgets: [] });
  assert.ok(errors.some((m) => m.startsWith("dashboard: ") && /[A-Za-z]/.test(m)));
});

test("1 つの部品の誤りで他の部品は生きる。誤りの部品は type: error の札になる", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [
      { type: "kpi", title: "売上", dataset: "sales", value: "金額" },
      { type: "kpi", title: "壊れた部品", dataset: "sales" }, // value も agg も無い → agg 既定 sum → value が要る
    ],
  };
  const { config, errors } = parseConfig(raw);
  assert.equal(config.widgets[0].type, "kpi");
  assert.equal(config.widgets[0].id, "w1");
  assert.equal(config.widgets[1].type, "error");
  assert.equal(config.widgets[1].id, "w2");
  assert.equal(config.widgets[1].title, "壊れた部品");
  assert.equal(config.widgets[1].message, "dashboard: 2 番目の部品「壊れた部品」の value（値の列）を指定してください");
  assert.deepEqual(errors, ["dashboard: 2 番目の部品「壊れた部品」の value（値の列）を指定してください"]);
});

test("agg: count なら value が無くてもよい", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "kpi", title: "件数", dataset: "sales", agg: "count" }],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.equal(config.widgets[0].value, "");
  assert.equal(config.widgets[0].agg, "count");
});

test("url は javascript: だと誤りになり、データセットの url は空になる", () => {
  const raw = {
    datasets: { sales: { url: "javascript:alert(1)" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }],
  };
  const { config, errors } = parseConfig(raw);
  assert.equal(errors.length, 1);
  assert.equal(errors[0], "dashboard: データセット「sales」の url を確認してください");
  assert.equal(config.datasets.sales.url, "");
});

test("url が http: なら「https の URL にしてください」という誤りになる", () => {
  const raw = {
    datasets: { sales: { url: "http://example.com/sales.csv" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, ["dashboard: データセット「sales」の url は https の URL にしてください"]);
  assert.equal(config.datasets.sales.url, "");
});

test("相対パスの url（./ ../ / 、スキーム無し）はどれも通る", () => {
  for (const url of ["./sales.csv", "../data/sales.csv", "/data/sales.csv", "sales.csv", "https://example.com/sales.csv"]) {
    const raw = { datasets: { sales: { url } }, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] };
    const { errors } = parseConfig(raw);
    assert.deepEqual(errors, [], url + " は通るはず");
  }
});

test("url はプロトコル相対（//）やバックスラッシュ、https 以外のスキームをまとめて拒む", () => {
  const badUrls = [
    "//evil.example.com/a.csv", // プロトコル相対
    "/\\evil.example.com/a", // 先頭が / でも中にバックスラッシュ
    "\\\\evil\\a", // まるごとバックスラッシュ（UNC 風）
    "JavaScript:alert(1)", // 危ないスキーム（大文字小文字混在）
    "ftp://x/a.csv", // https 以外のスキーム
  ];
  for (const url of badUrls) {
    const raw = { datasets: { sales: { url } }, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] };
    const { config, errors } = parseConfig(raw);
    assert.equal(errors.length, 1, JSON.stringify(url) + " は誤り 1 件になるはず");
    assert.equal(config.datasets.sales.url, "", JSON.stringify(url) + " の url は空になるはず");
  }
});

test("https は大文字小文字を問わず通る", () => {
  const raw = {
    datasets: { sales: { url: "HTTPS://ok.example.com/a.csv" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }],
  };
  const { errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
});

test("top は範囲に丸めず誤りにする（bar は 1〜20）", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "bar", title: "内訳", dataset: "sales", category: "カテゴリ", agg: "count", top: 0 }],
  };
  const { config, errors } = parseConfig(raw);
  assert.equal(config.widgets[0].type, "error");
  assert.equal(errors.length, 1);
  assert.equal(errors[0], "dashboard: 1 番目の部品「内訳」の top（上位の数）を確認してください");
});

test("top は範囲に丸めず誤りにする（table は 1〜200）", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [
      { type: "table", title: "一覧", dataset: "sales", groupBy: "商品", columns: [{ value: "金額", agg: "sum" }], top: 500 },
    ],
  };
  const { config } = parseConfig(raw);
  assert.equal(config.widgets[0].type, "error");
});

test("top は真偽値を数として緩く読み替えない。全角数字は半角にして受け付ける", () => {
  const base = { datasets: { sales: { url: "./sales.csv" } } };

  const boolTop = parseConfig({
    ...base,
    widgets: [{ type: "bar", title: "内訳", dataset: "sales", category: "カテゴリ", agg: "count", top: true }],
  });
  assert.equal(boolTop.config.widgets[0].type, "error", "top: true は誤りのはず");

  const zenkaku = parseConfig({
    ...base,
    widgets: [{ type: "bar", title: "内訳", dataset: "sales", category: "カテゴリ", agg: "count", top: "８" }],
  });
  assert.equal(zenkaku.config.widgets[0].type, "bar", "全角の８は 8 として通るはず");
  assert.equal(zenkaku.config.widgets[0].top, 8);

  const decimalString = parseConfig({
    ...base,
    widgets: [{ type: "bar", title: "内訳", dataset: "sales", category: "カテゴリ", agg: "count", top: "8.5" }],
  });
  assert.equal(decimalString.config.widgets[0].type, "error", '"8.5" は誤りのはず');
});

test("cacheMinutes は真偽値を数として緩く読み替えない。全角数字の文字列は通る", () => {
  const boolCache = parseConfig({ datasets: {}, widgets: [], cacheMinutes: true });
  assert.equal(boolCache.config.cacheMinutes, 5, "cacheMinutes: true は既定の 5 に戻すはず");
  assert.ok(boolCache.errors.some((m) => m.indexOf("cacheMinutes") !== -1));

  const zenkaku = parseConfig({ datasets: {}, widgets: [], cacheMinutes: "１０" });
  assert.equal(zenkaku.config.cacheMinutes, 10, "全角の１０は 10 として通るはず");
  assert.deepEqual(
    zenkaku.errors.filter((m) => m.indexOf("cacheMinutes") !== -1),
    []
  );
});

test("format.decimals は真偽値を数として緩く読み替えない。全角数字の文字列は通る", () => {
  const base = { datasets: { sales: { url: "./sales.csv" } } };

  const boolDecimals = parseConfig({
    ...base,
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count", format: { type: "custom", decimals: true } }],
  });
  assert.equal(boolDecimals.config.widgets[0].type, "error");

  const zenkakuDecimals = parseConfig({
    ...base,
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count", format: { type: "custom", decimals: "２" } }],
  });
  assert.equal(zenkakuDecimals.config.widgets[0].type, "kpi");
  assert.deepEqual(zenkakuDecimals.config.widgets[0].format, { type: "custom", prefix: "", suffix: "", decimals: 2 });
});

test("lang・theme・size・format の知らない値は誤り", () => {
  assert.equal(parseConfig({ lang: "fr", datasets: {}, widgets: [] }).errors[0], "dashboard: lang（言語）の値が正しくありません");
  assert.equal(parseConfig({ theme: "purple", datasets: {}, widgets: [] }).errors[0], "dashboard: theme（テーマ）の値が正しくありません");

  const badSize = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count", size: "xl" }],
  };
  assert.equal(parseConfig(badSize).config.widgets[0].type, "error");

  const badFormat = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count", format: "euro" }],
  };
  assert.equal(parseConfig(badFormat).config.widgets[0].type, "error");
});

test("折れ線と棒は size に s を受け取らない（m か l にしてもらう）", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv", dateColumn: "日付" } },
    widgets: [
      { type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", size: "s" },
      { type: "line", title: "売上の推移", dataset: "sales", value: "金額", agg: "sum", size: "s" },
      { type: "bar", title: "カテゴリ別の売上", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum", size: "s" },
    ],
  };
  const parsed = parseConfig(raw);
  assert.equal(parsed.config.widgets[0].type, "kpi", "小さな数の札は s のまま");
  assert.equal(parsed.config.widgets[1].type, "error");
  assert.equal(parsed.config.widgets[2].type, "error");
  assert.equal(
    parsed.config.widgets[1].message,
    "dashboard: 2 番目の部品「売上の推移」の size は m か l にしてください（折れ線と棒は小さい札では読めません）"
  );
  assert.deepEqual(parsed.errors, [
    "dashboard: 2 番目の部品「売上の推移」の size は m か l にしてください（折れ線と棒は小さい札では読めません）",
    "dashboard: 3 番目の部品「カテゴリ別の売上」の size は m か l にしてください（折れ線と棒は小さい札では読めません）",
  ]);

  const en = parseConfig(Object.assign({ lang: "en" }, raw));
  assert.equal(
    en.config.widgets[1].message,
    'dashboard: widget 2 "売上の推移" size must be m or l, because a line or bar chart cannot be read in a small card.'
  );

  const ok = parseConfig({
    datasets: { sales: { url: "./sales.csv", dateColumn: "日付" } },
    widgets: [
      { type: "line", title: "売上の推移", dataset: "sales", value: "金額", agg: "sum", size: "m" },
      { type: "bar", title: "カテゴリ別の売上", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum", size: "l" },
      { type: "bar", title: "既定の大きさ", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum" },
    ],
  });
  assert.deepEqual(ok.errors, []);
  assert.deepEqual(ok.config.widgets.map((w) => w.size), ["m", "l", "m"]);
});

test("format はカスタムのオブジェクトも受け付ける", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [
      { type: "kpi", title: "売上", dataset: "sales", agg: "count", format: { type: "custom", prefix: "約", suffix: "件", decimals: 0 } },
    ],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.deepEqual(config.widgets[0].format, { type: "custom", prefix: "約", suffix: "件", decimals: 0 });
});

test("filters.dimensions は 3 つまで。超えたら誤り＋先頭 3 つに丸める", () => {
  const raw = { datasets: {}, filters: { dimensions: ["a", "b", "c", "d"] }, widgets: [] };
  const { config, errors } = parseConfig(raw);
  assert.ok(errors.some((m) => m.indexOf("filters.dimensions") !== -1));
  assert.deepEqual(config.filters.dimensions, ["a", "b", "c"]);
});

test("cacheMinutes は 0〜1440。外れていれば誤りにして既定の 5 に戻す", () => {
  const raw = { datasets: {}, widgets: [], cacheMinutes: 2000 };
  const { config, errors } = parseConfig(raw);
  assert.equal(config.cacheMinutes, 5);
  assert.ok(errors.some((m) => m.indexOf("cacheMinutes") !== -1));
});

test("widgets が空・datasets が無いのは全体の誤り", () => {
  const noWidgets = parseConfig({ datasets: { a: { url: "./a.csv" } }, widgets: [] });
  assert.deepEqual(noWidgets.errors, ["dashboard: 部品を 1 つ以上設定してください"]);

  const noDatasets = parseConfig({ widgets: [{ type: "kpi", dataset: "a", agg: "count" }] });
  assert.ok(noDatasets.errors.includes("dashboard: datasets（データセット）を設定してください"));
});

test("dataset を指定していない・存在しない部品は誤りになる", () => {
  const missing = parseConfig({ datasets: { a: { url: "./a.csv" } }, widgets: [{ type: "kpi", title: "売上", agg: "count" }] });
  assert.equal(missing.config.widgets[0].type, "error");

  const notFound = parseConfig({
    datasets: { a: { url: "./a.csv" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "b", agg: "count" }],
  });
  assert.equal(notFound.config.widgets[0].type, "error");
  assert.equal(notFound.errors[0], 'dashboard: 1 番目の部品「売上」の dataset「b」が見つかりません');
});

test("データセットの名前が __proto__ や constructor だと誤りになり、プロトタイプを汚さない", () => {
  const protoDatasets = JSON.parse('{"__proto__":{"url":"./a.csv"}}');
  const raw = { datasets: protoDatasets, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] };
  const { config, errors } = parseConfig(raw);
  assert.ok(
    errors.some((m) => m.indexOf("__proto__") !== -1),
    "__proto__ という名前は使えない、という誤りが出るはず"
  );
  assert.deepEqual(Object.keys(config.datasets), []);
  assert.equal(Object.getPrototypeOf(config.datasets), Object.prototype, "config.datasets 自体のプロトタイプは書き換えられていない");
  assert.equal(({}).toString, Object.prototype.toString, "グローバルの Object.prototype が汚染されていない");

  const raw2 = { datasets: { constructor: { url: "./b.csv" } }, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] };
  const { errors: errors2 } = parseConfig(raw2);
  assert.ok(errors2.some((m) => m.indexOf("constructor") !== -1));
});

test("widget の dataset が toString など組み込みの名前でも、実在しなければプロトタイプ越しに見つかったことにしない", () => {
  for (const name of ["toString", "url", "constructor", "valueOf", "hasOwnProperty"]) {
    const raw = {
      source: "sheets", // dataset の存在確認を省く経路（ここで ctx.datasets は空のプレーンオブジェクト）
      widgets: [{ type: "kpi", title: "件数", dataset: name, agg: "count", compare: "previous" }],
    };
    const { config, errors } = parseConfig(raw);
    assert.deepEqual(errors, []);
    assert.equal(config.widgets[0].compare, "none", "dataset「" + name + "」は実在しないので previous のままではいけない");
  }
});

test("raw.datasets が配列など使えない形なら、全体の誤り 1 件だけにして部品ごとには重ねない", () => {
  const raw = {
    datasets: [],
    widgets: [
      { type: "kpi", title: "売上", dataset: "sales", agg: "count" },
      { type: "kpi", title: "件数", dataset: "sales", agg: "count" },
    ],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, ["dashboard: datasets の形式を確認してください"]);
  assert.equal(config.widgets[0].type, "error");
  assert.equal(config.widgets[1].type, "error");
});

test("source: sheets で raw.datasets が無ければ、dataset の存在は確かめない（GAS の読み込み時まかせ）", () => {
  const raw = {
    source: "sheets",
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.equal(config.widgets[0].type, "kpi");
});

test("kpi の compare: previous は、dataset に日付の列が無ければ黙って none になる（誤りにしない）", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } }, // dateColumn 無し
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count", compare: "previous" }],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.equal(config.widgets[0].compare, "none");
});

test("line の dateColumn は、自分にも dataset にも無ければ部品の誤りになる", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "line", title: "推移", dataset: "sales", agg: "count" }],
  };
  const { config } = parseConfig(raw);
  assert.equal(config.widgets[0].type, "error");
});

test("meter の target は固定の数でもよい", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "meter", title: "目標", dataset: "sales", agg: "count", target: 3000000 }],
  };
  const { config, errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.equal(config.widgets[0].target, 3000000);
});

test("meter の target.agg が知らない値なら、他の agg と同じく部品の誤りになる", () => {
  const raw = {
    datasets: { sales: { url: "./sales.csv" }, targets: { url: "./targets.csv" } },
    widgets: [
      {
        type: "meter",
        title: "目標",
        dataset: "sales",
        value: "金額",
        agg: "sum",
        target: { dataset: "targets", value: "目標額", agg: "へんな値" },
      },
    ],
  };
  const { config, errors } = parseConfig(raw);
  assert.equal(config.widgets[0].type, "error");
  assert.equal(errors.length, 1);
});

test("明細の表（rows: latest）は columns（列名の並び）が要る", () => {
  const ok = parseConfig({
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "table", title: "明細", dataset: "sales", rows: "latest", columns: ["日付", "金額"], top: 10 }],
  });
  assert.deepEqual(ok.errors, []);
  assert.deepEqual(ok.config.widgets[0].columns, ["日付", "金額"]);

  const bad = parseConfig({
    datasets: { sales: { url: "./sales.csv" } },
    widgets: [{ type: "table", title: "明細", dataset: "sales", rows: "latest" }],
  });
  assert.equal(bad.config.widgets[0].type, "error");
});

// ---- configFromSheets ---------------------------------------------------

test("configFromSheets: 設定・定義シートから読み替えた raw は、同じ内容の JSON と同じ config になる", () => {
  const settingsRows = [
    ["項目", "値"],
    ["題名", "しおかぜ珈琲店 売上ダッシュボード"],
    ["言語", "日本語"],
    ["テーマ", "自動"],
    ["期間", "今月"],
    ["絞り込みの列", "チャネル、カテゴリ"],
  ];
  const definitionRows = [
    ["種類", "題", "データ", "値の列", "集計", "区分の列", "分ける列", "日付の列", "刻み", "書式", "目標", "大きさ", "上位", "並び"],
    ["数字", "売上", "sales", "金額", "合計", "", "", "", "", "円", "", "小", "", ""],
    ["折れ線", "売上の推移", "sales", "金額", "合計", "", "チャネル", "日付", "自動", "円", "", "大", "", ""],
    ["棒", "カテゴリ別の売上", "sales", "金額", "合計", "カテゴリ", "", "", "", "円", "", "中", "8", ""],
    ["目標", "今月の目標", "sales", "金額", "合計", "", "", "", "", "円", "targets!目標額", "中", "", ""],
    ["表", "商品別", "sales", "数量,金額", "合計", "商品", "", "", "", "", "", "大", "20", ""],
  ];

  const fromSheets = parseConfig(configFromSheets(settingsRows, definitionRows));

  const equivalentJson = {
    source: "sheets",
    title: "しおかぜ珈琲店 売上ダッシュボード",
    lang: "ja",
    theme: "auto",
    filters: { period: "thisMonth", dimensions: ["チャネル", "カテゴリ"] },
    datasets: {
      sales: { url: "", dateColumn: "日付" },
      targets: { url: "", dateColumn: "" },
    },
    widgets: [
      { type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", size: "s" },
      {
        type: "line",
        title: "売上の推移",
        dataset: "sales",
        value: "金額",
        agg: "sum",
        splitBy: "チャネル",
        dateColumn: "日付",
        bucket: "auto",
        format: "yen",
        size: "l",
      },
      { type: "bar", title: "カテゴリ別の売上", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum", format: "yen", size: "m", top: 8 },
      {
        type: "meter",
        title: "今月の目標",
        dataset: "sales",
        value: "金額",
        agg: "sum",
        format: "yen",
        target: { dataset: "targets", value: "目標額", agg: "sum", matchMonth: "月" },
        size: "m",
      },
      {
        type: "table",
        title: "商品別",
        dataset: "sales",
        groupBy: "商品",
        columns: [
          { value: "数量", agg: "sum", label: "数量" },
          { value: "金額", agg: "sum", label: "金額" },
        ],
        size: "l",
        top: 20,
      },
    ],
  };
  const fromJson = parseConfig(equivalentJson);

  assert.deepEqual(fromSheets.errors, []);
  assert.deepEqual(fromJson.errors, []);
  assert.deepEqual(fromSheets.config, fromJson.config);
});

test("configFromSheets: 日本語の種類の名前（数字・折れ線・棒・目標・表）を読み替える", () => {
  const header = ["種類", "題", "データ", "値の列", "集計", "区分の列", "分ける列", "日付の列", "刻み", "書式", "目標", "大きさ", "上位", "並び"];
  const cases = [
    ["数字", "kpi"],
    ["折れ線", "line"],
    ["棒", "bar"],
    ["目標", "meter"],
    ["表", "table"],
  ];
  for (const [ja, en] of cases) {
    const definitionRows = [header, [ja, "題", "sales", "金額", "合計", "区分", "", "", "", "", "1", "中", "", ""]];
    const raw = configFromSheets([["項目", "値"]], definitionRows);
    assert.equal(raw.widgets[0].type, en, ja + " は " + en + " になるはず");
  }
});

test("configFromSheets: 日本語の集計の名前（合計・平均・件数・種類の数・最小・最大）を読み替える", () => {
  const header = ["種類", "題", "データ", "値の列", "集計", "区分の列", "分ける列", "日付の列", "刻み", "書式", "目標", "大きさ", "上位", "並び"];
  const cases = [
    ["合計", "sum"],
    ["平均", "avg"],
    ["件数", "count"],
    ["種類の数", "distinct"],
    ["最小", "min"],
    ["最大", "max"],
  ];
  for (const [ja, en] of cases) {
    const definitionRows = [header, ["数字", "題", "sales", "金額", ja, "", "", "", "", "", "", "小", "", ""]];
    const raw = configFromSheets([["項目", "値"]], definitionRows);
    assert.equal(raw.widgets[0].agg, en, ja + " は " + en + " になるはず");
  }
});

test("configFromSheets: 表（種類が「表」）の部品には使わない agg を残さない", () => {
  const definitionRows = [
    ["種類", "題", "データ", "値の列", "集計", "区分の列", "分ける列", "日付の列", "刻み", "書式", "目標", "大きさ", "上位", "並び"],
    ["表", "商品別", "sales", "金額", "合計", "商品", "", "", "", "", "", "大", "", ""],
  ];
  const raw = configFromSheets([["項目", "値"]], definitionRows);
  assert.equal(raw.widgets[0].agg, undefined, "表には widget.agg を残さないはず");
  assert.equal(raw.widgets[0].columns[0].agg, "sum", "列ごとの agg は引き続き使う");
});

test("configFromSheets: 空行は読み飛ばし、知らない列は無視する", () => {
  const definitionRows = [
    ["種類", "題", "データ", "値の列", "集計", "区分の列", "分ける列", "日付の列", "刻み", "書式", "目標", "大きさ", "上位", "並び", "知らない列"],
    ["", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
    ["数字", "売上", "sales", "金額", "合計", "", "", "", "", "", "", "小", "", "", "無視される値"],
  ];
  const raw = configFromSheets([["項目", "値"]], definitionRows);
  assert.equal(raw.widgets.length, 1);
  assert.equal(raw.widgets[0].title, "売上");
});

test("configFromSheets: 「比べる」は 数字 の compare になる（なし / 前の期間）", () => {
  const header = ["種類", "題", "データ", "値の列", "集計", "書式", "大きさ", "比べる"];
  const cases = [
    ["なし", "none"],
    ["前の期間", "previous"],
    ["", undefined],
  ];
  for (const [ja, en] of cases) {
    const raw = configFromSheets([["項目", "値"]], [header, ["数字", "売上", "sales", "金額", "合計", "円", "小", ja]]);
    assert.equal(raw.widgets[0].compare, en, "「" + ja + "」は " + en + " になるはず");
  }
});

test("configFromSheets: 「明細」が「最新」の表は、列の名前をそのまま並べた明細の表になる", () => {
  const header = ["種類", "題", "データ", "値の列", "集計", "日付の列", "大きさ", "上位", "明細"];
  const raw = configFromSheets([["項目", "値"]], [header, ["表", "最近の注文", "sales", "日付、商品、金額", "", "日付", "大", "8", "最新"]]);

  assert.equal(raw.widgets[0].rows, "latest");
  assert.deepEqual(raw.widgets[0].columns, ["日付", "商品", "金額"]);

  const parsed = parseConfig(raw);
  assert.deepEqual(parsed.errors, []);
  assert.equal(parsed.config.widgets[0].type, "table");
  assert.deepEqual(parsed.config.widgets[0].columns, ["日付", "商品", "金額"]);
});

test("configSheetNotes: 明細が「最新」の表に「並び」を書いても、使われないのでご参考として伝える", () => {
  const header = ["種類", "題", "データ", "値の列", "大きさ", "上位", "並び", "明細"];
  const definitions = [header, ["表", "最近の注文", "sales", "日付、商品、金額", "大", "8", "日付", "最新"]];

  const notes = configSheetNotes([["項目", "値"]], definitions);
  assert.deepEqual(notes, ["「最近の注文」は最新の明細を出す表なので、「並び」は使われません。"]);

  // parseConfig の誤り（errors）とは別枠。明細が最新の表そのものは誤りにならない
  const raw = configFromSheets([["項目", "値"]], definitions);
  assert.deepEqual(parseConfig(raw).errors, []);
});

test("configSheetNotes: 「並び」が空、または明細が「最新」でなければ、ご参考は無い", () => {
  const header = ["種類", "題", "データ", "値の列", "上位", "並び", "明細"];
  const noSort = [header, ["表", "最近の注文", "sales", "日付、商品", "8", "", "最新"]];
  assert.deepEqual(configSheetNotes([["項目", "値"]], noSort), []);

  const groupedTable = [header, ["表", "商品別", "sales", "数量", "10", "数量", ""]];
  assert.deepEqual(configSheetNotes([["項目", "値"]], groupedTable), []);

  const notATable = [
    ["種類", "題", "データ", "値の列", "区分の列", "並び"],
    ["棒", "カテゴリ別", "sales", "金額", "カテゴリ", "値"],
  ];
  assert.deepEqual(configSheetNotes([["項目", "値"]], notATable), []);
});

test("configSheetNotes: 「言語」が「英語」なら、ご参考の文も英語になる", () => {
  const header = ["種類", "題", "データ", "値の列", "並び", "明細"];
  const definitions = [header, ["表", "Recent orders", "sales", "Date, Product", "Date", "最新"]];
  const notes = configSheetNotes([["項目", "値"], ["言語", "英語"]], definitions);
  assert.deepEqual(notes, ['The table "Recent orders" shows the latest rows as they are, so "Sort" is not used.']);
});

test("configFromSheets: 表の「値の列」は 列名=見出し で見出しを付けられ、「書式」は列ごとに効く", () => {
  const header = ["種類", "題", "データ", "値の列", "集計", "区分の列", "書式", "大きさ", "並び"];
  const raw = configFromSheets([["項目", "値"]], [header, ["表", "商品別", "sales", "数量、金額=売上", "合計", "商品", "数値、円", "中", "売上"]]);

  assert.deepEqual(raw.widgets[0].columns, [
    { value: "数量", agg: "sum", label: "数量", format: "number" },
    { value: "金額", agg: "sum", label: "売上", format: "yen" },
  ]);
  assert.equal(raw.widgets[0].sort, "売上", "表の「並び」は見出しの名前をそのまま渡すはず");
  assert.equal(raw.widgets[0].format, undefined, "表の「書式」は列ごとの書式なので、部品自体には残さないはず");
});

test("configFromSheets: 目標は「シート名!列名」と「シート名!列名!月の列」のどちらでも書ける", () => {
  const header = ["種類", "題", "データ", "値の列", "集計", "目標", "大きさ"];
  const two = configFromSheets([["項目", "値"]], [header, ["目標", "今月の目標", "sales", "金額", "合計", "目標!目標額", "中"]]);
  assert.deepEqual(two.widgets[0].target, { dataset: "目標", value: "目標額", agg: "sum", matchMonth: "月" });

  const three = configFromSheets([["項目", "値"]], [header, ["目標", "Goal", "Sales", "Amount", "合計", "Targets!Target!Month", "中"]]);
  assert.deepEqual(three.widgets[0].target, { dataset: "Targets", value: "Target", agg: "sum", matchMonth: "Month" });
  assert.ok(three.datasets.Targets !== undefined, "目標の参照先もデータセットとして登録するはず");
});

// ---- 取りに行ってよい置き場所の決まり ---------------------------------------

/**
 * 決まりをもう 1 つ書き写さずに確かめるための引き比べ。
 * データセットの url として parseConfig に通し、そのまま残ったかどうかで見分ける
 * （この形は、取りに行く側が以前していた見分け方でもある）
 */
function urlSurvivesConfig_(url) {
  if (url === "") return false;
  const probe = parseConfig({ datasets: { d: { url } }, widgets: [] });
  const entry = probe.config.datasets.d;
  return entry !== undefined && entry.url === url;
}

const URL_CASES_ = [
  ["https://example.test/data.csv", true],
  ["HTTPS://EXAMPLE.TEST/data.csv", true],
  ["https://example.test/d.csv?v=2#x", true],
  ["https://example.test:8443/d.csv", true],
  ["./sales.csv", true],
  ["../data/sales.csv", true],
  ["/data/sales.csv", true],
  ["sales.csv", true],
  ["data/2026/sales.json", true],
  ["sheets/売上.csv", true],
  ["http://example.test/data.csv", false],
  ["HtTp://example.test/data.csv", false],
  ["//example.test/data.csv", false],
  ["javascript:alert(1)", false],
  ["JavaScript:alert(1)", false],
  ["data:text/csv,a", false],
  ["ftp://example.test/a.csv", false],
  ["mailto:hello@example.test", false],
  ["/\\example.test/x.csv", false],
  ["", false],
];

test("isAllowedDataUrl: 20 通りの置き場所を、決まりどおりに通す・断る", () => {
  assert.equal(URL_CASES_.length, 20);
  for (const [url, allowed] of URL_CASES_) {
    assert.equal(isAllowedDataUrl(url), allowed, JSON.stringify(url) + " の見分け");
  }
});

test("isAllowedDataUrl: 設定の検査が通す形と、答えがひとつも食い違わない", () => {
  for (const [url] of URL_CASES_) {
    assert.equal(isAllowedDataUrl(url), urlSurvivesConfig_(url), JSON.stringify(url) + " が設定の検査と食い違う");
  }
});

test("isAllowedDataUrl: バックスラッシュの経路と制御文字を断る", () => {
  assert.equal(isAllowedDataUrl("\\\\example.test\\a.csv"), false);
  assert.equal(isAllowedDataUrl("./sales" + String.fromCharCode(1) + ".csv"), false);
  assert.equal(isAllowedDataUrl("./sales" + String.fromCharCode(10) + ".csv"), false);
});

test("isAllowedDataUrl: 文字でないものと、前後に余白のあるものの受け取り方", () => {
  assert.equal(isAllowedDataUrl(null), false);
  assert.equal(isAllowedDataUrl(undefined), false);
  assert.equal(isAllowedDataUrl({}), false, "形の無いものは受け取らない");
  assert.equal(isAllowedDataUrl([]), false);
  assert.equal(isAllowedDataUrl("   "), false);
  // 数は設定の検査と同じく文字として読む（"123" という相対の道すじになる）
  assert.equal(isAllowedDataUrl(123), true);
  // 前後の余白は、設定の検査と同じように落としてから見分ける
  assert.equal(isAllowedDataUrl("  ./sales.csv  "), true);
});

// ---- url は任意（文書審査 C2） ----------------------------------------------

test("url を書かないデータセットは誤りにならない（data で行を渡せるようにするため）", () => {
  const raw = {
    datasets: { sales: { dateColumn: "日付" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum" }],
  };
  const { errors, config } = parseConfig(raw);
  assert.deepEqual(errors, [], "url が無くても誤りにしない");
  assert.equal(config.datasets.sales.url, "");
  assert.equal(config.datasets.sales.dateColumn, "日付");
  assert.equal(config.widgets[0].type, "kpi", "部品も誤りの札にならない");
});

test("url が空文字・null・数でも、誤りにはせず「指定なし」として扱う", () => {
  for (const url of ["", "   ", null, undefined, {}, []]) {
    const raw = { datasets: { sales: { url } }, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] };
    const { errors, config } = parseConfig(raw);
    assert.deepEqual(errors, [], JSON.stringify(url) + " は誤りにしない");
    assert.equal(config.datasets.sales.url, "");
  }
});

test("書かれている url は、これまでどおり許可リストで検査する", () => {
  const raw = { datasets: { sales: { url: "javascript:alert(1)" } }, widgets: [{ type: "kpi", title: "売上", dataset: "sales", agg: "count" }] };
  const { errors } = parseConfig(raw);
  assert.deepEqual(errors, ["dashboard: データセット「sales」の url を確認してください"]);
});

// ---- source: "sheets" の url も同じ決まりで検査する（コード審査 I1） --------

test('source: "sheets" のデータセットに url が書かれていたら、同じ許可リストで検査する', () => {
  for (const url of ["javascript:alert(1)", "//evil.example.com/a.csv", "data:text/csv,a", "/\\evil"]) {
    const raw = {
      source: "sheets",
      datasets: { 売上: { url, dateColumn: "日付" } },
      widgets: [{ type: "kpi", title: "売上", dataset: "売上", agg: "count" }],
    };
    const { errors, config } = parseConfig(raw);
    assert.equal(errors.length, 1, JSON.stringify(url) + " は誤り 1 件になるはず: " + JSON.stringify(errors));
    assert.equal(config.datasets["売上"].url, "", JSON.stringify(url) + " の url は空になるはず");
  }
});

test('source: "sheets" で url を書かないのは、これまでどおり正しい形', () => {
  const raw = {
    source: "sheets",
    datasets: { 売上: { url: "", dateColumn: "日付" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "売上", agg: "count" }],
  };
  assert.deepEqual(parseConfig(raw).errors, []);
});

test('source: "sheets" でも http: の url は「https にしてください」になる', () => {
  const raw = {
    source: "sheets",
    datasets: { 売上: { url: "http://example.com/a.csv" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "売上", agg: "count" }],
  };
  assert.deepEqual(parseConfig(raw).errors, ["dashboard: データセット「売上」の url は https の URL にしてください"]);
});

// ---- `定義` の「良し悪し」（コード審査 I4） ----------------------------------

test("`定義` の「良し悪し」が goodWhen になる（日本語・英語のどちらでも）", () => {
  const definitions = [
    ["種類", "題", "データ", "値の列", "集計", "良し悪し"],
    ["数字", "売上", "売上", "金額", "合計", "上がると良い"],
    ["数字", "解約数", "売上", "件数", "合計", "下がると良い"],
    ["数字", "返品額", "売上", "金額", "合計", "down"],
    ["数字", "注文数", "売上", "金額", "合計", ""],
  ];
  const raw = configFromSheets([["項目", "値"]], definitions);
  assert.equal(raw.widgets[0].goodWhen, "up");
  assert.equal(raw.widgets[1].goodWhen, "down");
  assert.equal(raw.widgets[2].goodWhen, "down", "英語の値もそのまま通る");
  assert.equal(raw.widgets[3].goodWhen, undefined, "空欄は書かない（既定の up になる）");

  const { errors, config } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.equal(config.widgets[1].goodWhen, "down");
  assert.equal(config.widgets[3].goodWhen, "up");
});

test("`定義` の「良し悪し」は、数字以外の部品では読まない", () => {
  const definitions = [
    ["種類", "題", "データ", "値の列", "集計", "日付の列", "良し悪し"],
    ["折れ線", "推移", "売上", "金額", "合計", "日付", "下がると良い"],
  ];
  const raw = configFromSheets([["項目", "値"]], definitions);
  assert.equal(raw.widgets[0].goodWhen, undefined);
});

test("`定義` の列に「良し悪し」が入っている（見出しの並びは 17 列）", () => {
  assert.ok(CONFIG_DEFINITION_COLUMNS_.includes("良し悪し"));
  assert.equal(CONFIG_DEFINITION_COLUMNS_.indexOf("良し悪し"), CONFIG_DEFINITION_COLUMNS_.indexOf("比べる") + 1, "「比べる」のすぐ次に置く");
});

// ---- `設定` の「開始日」「終了日」（コード審査 M14） ------------------------

test("`設定` の「開始日」「終了日」が filters.from / to になる", () => {
  const settings = [
    ["項目", "値"],
    ["期間", "期間を指定"],
    ["開始日", "2026-09-01"],
    ["終了日", "2026-09-30"],
  ];
  const raw = configFromSheets(settings, [["種類", "題", "データ", "値の列"], ["数字", "売上", "売上", "金額"]]);
  assert.equal(raw.filters.period, "custom");
  assert.equal(raw.filters.from, "2026-09-01");
  assert.equal(raw.filters.to, "2026-09-30");

  const { errors, config } = parseConfig(raw);
  assert.deepEqual(errors, []);
  assert.equal(config.filters.from, "2026-09-01");
  assert.equal(config.filters.to, "2026-09-30");
});

test("`設定` の「開始日」が日付のマス（Date）でも読める", () => {
  const settings = [["項目", "値"], ["開始日", new Date(2026, 8, 1)], ["終了日", "2026/9/30"]];
  const raw = configFromSheets(settings, []);
  assert.equal(raw.filters.from, "2026-09-01");
  assert.equal(raw.filters.to, "2026-09-30", "2026/9/30 のような書き方も読む");
});

test("`設定` の「開始日」が読めない文字なら、parseConfig が誤りとして知らせる", () => {
  const raw = configFromSheets([["項目", "値"], ["開始日", "9/1/2026"]], [["種類", "題", "データ", "値の列"], ["数字", "売上", "売上", "金額"]]);
  const { errors, config } = parseConfig(raw);
  assert.deepEqual(errors, ["dashboard: filters.from の値が正しくありません"]);
  assert.equal(config.filters.from, "");
});

test("`設定` の「開始日」「終了日」が空欄なら、何も入らない", () => {
  const raw = configFromSheets([["項目", "値"], ["開始日", ""], ["終了日", ""]], []);
  assert.equal(raw.filters.from, "");
  assert.equal(raw.filters.to, "");
});

// ---- 期間の並びは 1 か所（コード審査 M5） ----------------------------------

test("期間の並びは config.js の 1 か所だけが持ち、URL の読み取りと画面の select も同じものを使う", () => {
  assert.deepEqual(CONFIG_PERIODS_, ["thisMonth", "lastMonth", "last7", "last30", "last90", "thisYear", "all", "custom"]);
  assert.equal(PERIOD_PRESETS, CONFIG_PERIODS_, "画面の select も同じ並びを使う");

  for (const source of ["../src/core/filter.js", "../src/ui/state.js"]) {
    const code = readFileSync(new URL(source, import.meta.url), "utf8");
    assert.equal(code.includes('"thisMonth", "lastMonth"'), false, source + " に期間の並びを書き写さない");
  }
  // URL の読み取りが、同じ並びで知らない値を捨てている
  assert.deepEqual(decodeFilters("#db.p=last30", { filters: { dimensions: [] } }, "db"), { period: "last30" });
  assert.deepEqual(decodeFilters("#db.p=とんでもない期間", { filters: { dimensions: [] } }, "db"), {});
});
