import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Script } from "node:vm";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

// 「いま」を自分で読んでよいのは gas と、入口の main・source-* だけ（純粋な計算は today を引数でもらう）
const NEW_DATE_PATTERN = /new\s+Date\s*\(\s*\)/;
const DATE_NOW_PATTERN = /Date\.now\s*\(/;
// ブラウザ・GAS のグローバル。google だけは「google.」の形（google.script.run など）に限る
const BROWSER_GLOBAL_NAMES = ["document", "window", "fetch", "sessionStorage"];
const GOOGLE_DOT_PATTERN = /\bgoogle\s*\./;

function mayReadNow_(path) {
  return path.startsWith("src/gas/") || path === "src/ui/main.js" || /^src\/ui\/source-[^/]+\.js$/.test(path);
}

function mayTouchGlobals_(path) {
  return path === "src/ui/main.js" || /^src\/ui\/source-[^/]+\.js$/.test(path);
}

function allSrcJsFiles_() {
  const files = [];
  (function walk(dir) {
    if (!existsSync(join(root, dir))) return;
    for (const entry of readdirSync(join(root, dir), { withFileTypes: true })) {
      const path = dir + "/" + entry.name;
      if (entry.isDirectory()) walk(path);
      else if (entry.name.endsWith(".js")) files.push(path);
    }
  })("src");
  return files;
}

function findBrowserGlobal_(code) {
  for (const name of BROWSER_GLOBAL_NAMES) {
    if (new RegExp("\\b" + name + "\\b").test(code)) return name;
  }
  return GOOGLE_DOT_PATTERN.test(code) ? "google." : null;
}

test("自己点検: 検査の正規表現はサンプル文字列の違反を見つける", () => {
  assert.ok(NEW_DATE_PATTERN.test("const t = new Date();"), "new Date() を見つけられる");
  assert.equal(NEW_DATE_PATTERN.test("const t = new Date(2026, 0, 1);"), false, "引数ありは違反ではない");
  assert.ok(DATE_NOW_PATTERN.test("const t = Date.now();"), "Date.now( を見つけられる");
  assert.equal(findBrowserGlobal_("const el = document.getElementById('x');"), "document");
  assert.equal(findBrowserGlobal_("window.Dashboard = {};"), "window");
  assert.equal(findBrowserGlobal_("await fetch(url);"), "fetch");
  assert.equal(findBrowserGlobal_("sessionStorage.getItem('k');"), "sessionStorage");
  assert.equal(findBrowserGlobal_("google.script.run.api_bootstrap();"), "google.");
  assert.equal(findBrowserGlobal_("const config = { name: 'ふつうの文字' };"), null, "違反が無ければ null");
});

test("純粋な処理に new Date()（引数なし）と Date.now( が無い", () => {
  const files = allSrcJsFiles_();
  assert.ok(files.length > 0, "src の下に .js が見つからない");
  for (const path of files) {
    if (mayReadNow_(path)) continue;
    const code = readFileSync(join(root, path), "utf8");
    assert.equal(NEW_DATE_PATTERN.test(code), false, path + " に new Date() があります");
    assert.equal(DATE_NOW_PATTERN.test(code), false, path + " に Date.now( があります");
  }
});

test("純粋な処理は document・window・fetch・sessionStorage・google. に触らない", () => {
  const files = allSrcJsFiles_();
  for (const path of files) {
    if (mayTouchGlobals_(path)) continue;
    const code = readFileSync(join(root, path), "utf8");
    assert.equal(findBrowserGlobal_(code), null, path + " が禁止されたグローバルに触れています");
  }
});

// ---- 生の制御文字 -----------------------------------------------------------

/** 番号で書いた制御文字（この検査そのものが、生の制御文字を持たないようにする） */
const NUL_ = String.fromCharCode(0);
const US_ = String.fromCharCode(31);

/** HTML の読み手が <script> の中でする入れ替え（U+0000 → U+FFFD）を、そのまま真似る */
function asHtmlReads_(code) {
  return code.split(NUL_).join(String.fromCharCode(0xfffd));
}

/**
 * 改行・復帰・タブ以外の制御文字が、そのままの字として置いてあるところを探す。
 * 見つかったら「何行目の何文字目に、どの番号の字が」を返す（0 件なら空の配列）。
 *
 * 生の U+0000 は、<script> の中に置くと HTML の読み手が U+FFFD に入れ替えてしまい、
 * 文字の並び（正規表現の [A-B] など）が逆さまになって、その 1 本ぜんたいが動かなくなる。
 * 番号で書く（\x00 や \u001f のような書き方）なら、どこに置いても同じ意味になる
 */
function findRawControlChars_(text) {
  const found = [];
  let line = 1;
  let column = 1;
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i);
    if (code === 10) {
      line += 1;
      column = 1;
      continue;
    }
    if (code !== 13 && code !== 9 && (code < 32 || code === 127)) {
      found.push({ line, column, code });
    }
    column += 1;
  }
  return found;
}

/**
 * 配りものに入るところ（と、そこから作る生成物）のすべてのファイル。
 * 検査そのものも同じ決まりで書くため、test も見る
 * （生の制御文字が 1 つでもあると、git がそのファイルを文書として扱えなくなる）
 */
function shippedFiles_() {
  const files = [];
  for (const top of ["src", "demo", "scripts", "samples", "templates", "test", "dist"]) {
    (function walk(dir) {
      const here = join(root, dir);
      if (!existsSync(here)) return;
      for (const entry of readdirSync(here, { withFileTypes: true })) {
        if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
        const path = dir + "/" + entry.name;
        if (entry.isDirectory()) walk(path);
        else if (statSync(join(root, path)).size > 0) files.push(path);
      }
    })(top);
  }
  return files;
}

/** App.html の中の、束ねた 1 本を差し込んである <script>（いちばん長いもの）を取り出す */
function inlineScriptOf_(html) {
  const found = html.match(/<script>([\s\S]*?)<\/script>/g) || [];
  let longest = "";
  for (const block of found) {
    const body = block.slice("<script>".length, -"</script>".length);
    if (body.length > longest.length) longest = body;
  }
  return longest;
}

test("自己点検: 生の制御文字を見つけられ、HTML の読み替えで壊れる書き方も見分けられる", () => {
  assert.deepEqual(findRawControlChars_("ふつうの文\n\t\r行"), []);
  assert.deepEqual(findRawControlChars_("a" + NUL_ + "b"), [{ line: 1, column: 2, code: 0 }]);
  assert.deepEqual(findRawControlChars_("a\nb" + US_ + "c"), [{ line: 2, column: 2, code: 31 }]);
  assert.deepEqual(findRawControlChars_("\\x00-\\x1f"), [], "番号で書いてあるものは見つけない");

  // HTML の読み手は <script> の中の U+0000 を U+FFFD にする。生の字で書いた並びは、そこで逆さまになる
  const raw = "const re = /[" + NUL_ + "-" + US_ + "]/;";
  assert.throws(() => new Script(asHtmlReads_(raw)), /[Rr]ange out of order|[Ii]nvalid regular expression/);
  assert.doesNotThrow(() => new Script("const re = /[\\x00-\\x1f]/;"));
});

test("配りものに、改行・復帰・タブ以外の生の制御文字が 1 つも無い", () => {
  const files = shippedFiles_();
  assert.ok(files.length > 0, "検査するファイルが見つからない");
  const problems = [];
  for (const path of files) {
    for (const hit of findRawControlChars_(readFileSync(join(root, path), "utf8"))) {
      problems.push(path + ":" + hit.line + ":" + hit.column + " に U+" + hit.code.toString(16).padStart(4, "0").toUpperCase());
    }
  }
  assert.deepEqual(problems, [], "生の制御文字は番号の書き方（\\x00 など）に直してください");
});

test("App.html に差し込んだ 1 本は、HTML の読み替えを通しても文として成り立つ", () => {
  const html = readFileSync(join(root, "dist", "App.html"), "utf8");
  const code = inlineScriptOf_(html);
  assert.ok(code.length > 10000, "束ねた 1 本が取り出せない");
  // ブラウザが読むときと同じ入れ替えをしてから、文として成り立つかを見る
  const asParsed = asHtmlReads_(code);
  assert.doesNotThrow(() => new Script(asParsed), "App.html の <script> が文として読めません");
  assert.doesNotThrow(() => new Function(asParsed), "App.html の <script> が関数として組み立てられません");
});
