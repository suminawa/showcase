/**
 * 配布物（zip）に入ってはいけない語を、1 か所にまとめて組み立てる。
 *
 * この道具を読み込むテストそのものも zip に入るので、探す語を字のまま書くと
 * 「探す側のファイルが検査に引っかかる」ことになってしまう。
 * そこで、内部でだけ使う呼び名・作業場所の手がかり・書きかけの印は、
 * すべて文字コード（code point）から組み立てて持つ。
 *
 * test/ の検査は `test/*.test.mjs` だけを走らせるので、この入れ子の場所に置いた
 * 道具はテストとして実行されない（読み込まれるだけ）。
 */

/** 文字コードの並びから 1 つの語を作る */
function word_(...codePoints) {
  return String.fromCodePoint(...codePoints);
}

/**
 * 内部でだけ使う呼び名。中身は（順に）
 * 手伝い役の道具の名前 1 字・持ち主の呼び名 2 字・手伝い役の製品名・その作り手の名前・作業場所の名前。
 */
export const INTERNAL_WORDS = [
  word_(0x924b),
  word_(0x68df, 0x6881),
  word_(0x43, 0x6c, 0x61, 0x75, 0x64, 0x65),
  word_(0x41, 0x6e, 0x74, 0x68, 0x72, 0x6f, 0x70, 0x69, 0x63),
  word_(0x63, 0x72, 0x65, 0x61, 0x74, 0x6f, 0x72, 0x2d, 0x6f, 0x73),
];

/**
 * 作った人の手元の場所が分かってしまう手がかり。
 * 3 つの OS の持ち物の入れ物の道すじと、内部の書類の置き場所 2 つ。
 */
export const INTERNAL_PATHS = [
  word_(0x2f, 0x55, 0x73, 0x65, 0x72, 0x73, 0x2f),
  word_(0x2f, 0x68, 0x6f, 0x6d, 0x65, 0x2f),
  word_(0x43, 0x3a, 0x5c, 0x55, 0x73, 0x65, 0x72, 0x73),
  word_(0x2e, 0x73, 0x75, 0x70, 0x65, 0x72, 0x70, 0x6f, 0x77, 0x65, 0x72, 0x73),
  word_(0x73, 0x75, 0x6d, 0x69, 0x6e, 0x61, 0x77, 0x61, 0x2d, 0x6f, 0x70, 0x73),
];

/** 書きかけの印（まだ手を入れる、直す、仮置き）。売り物の中に残っていてはいけない */
export const WORK_IN_PROGRESS_MARKS = [
  word_(0x54, 0x4f, 0x44, 0x4f),
  word_(0x46, 0x49, 0x58, 0x4d, 0x45),
  word_(0x58, 0x58, 0x58),
];

/**
 * 実在の会社名・市名など、見本データに紛れ込ませない固有名詞。
 * こちらは内部の語ではないので、字のまま持っていて構わない
 */
export const REAL_WORLD_NAMES = ["横浜", "東京", "大阪", "スターバックス", "Starbucks", "Amazon", "楽天"];

/** 見本データ・見本の設定に出てはいけない語（内部の語 + 実在の固有名詞） */
export const FORBIDDEN_WORDS = INTERNAL_WORDS.concat(REAL_WORLD_NAMES);

/** そのまま置いてよい制御文字（タブ・改行・復帰）の文字コード */
const ALLOWED_CONTROL_CODES_ = [9, 10, 13];

/**
 * 文字コードが 32 より小さい字のうち、タブ・改行・復帰でないものが 1 つでもあるか。
 * 正規表現で書くと、この道具のファイル自身に生の制御文字が紛れ込みかねないので、
 * 文字コードを数で見比べるだけにしてある
 */
export function hasRawControlChar(text) {
  const source = String(text);
  for (let i = 0; i < source.length; i += 1) {
    const code = source.charCodeAt(i);
    if (code >= 32 || ALLOWED_CONTROL_CODES_.indexOf(code) !== -1) continue;
    return true;
  }
  return false;
}

/** text に forbidden の語が 1 つも無いことを確かめる */
export function assertNoWords(assert, text, words, label) {
  for (const word of words) {
    assert.equal(String(text).includes(word), false, label + " に「" + word + "」が含まれています");
  }
}
