/**
 * 偽の GAS（スプレッドシート版のサーバー側を、node の上で動かすためのもの）。
 * test/gas.test.mjs（src/gas を直接）と test/bundle.test.mjs（束ねた dist/Code.gs を vm で）の両方が使う。
 *
 * test/ の検査は `test/*.test.mjs` だけを走らせるので、この入れ子の場所に置いた道具は
 * テストとして実行されない（読み込まれるだけ）。
 */

import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

/** スクリプト（appsscript.json）の時間帯。わざとスプレッドシートの時間帯とは違えてある */
export const SCRIPT_TIME_ZONE_ = "Asia/Tokyo";
/** このテストで使う、スプレッドシート本体の時間帯（既定） */
export const SPREADSHEET_TIME_ZONE_ = "America/Los_Angeles";

// ---- 実機の癖をまねた、偽のスプレッドシート ---------------------------------
//
// 偽物が本物より甘いと、検査が通っても実物で落ちる。ここで再現している本物の癖:
// - 書いた文字は、人が打ち込んだときと同じく読み替えられる（数・先頭の 0 が消える数・割合・TRUE/FALSE・
//   日付・「10/1」のような月日・「2026-04」のような年月）。先頭の ' と、書式なしテキスト（@）のマスは文字のまま
// - 日付に読み替えるときは、スプレッドシート本体の時間帯のその日 0 時になる
// - clearContents() は値だけを消し、書式なしテキストの書式は残る
// - getDataRange().getValues() は長方形（短い行は "" で埋まる）。空のシートでは 1 行 1 列の空
// - getLastRow() は中身のある最後の行
// - マニフェスト（dist/appsscript.json）の oauthScopes に無い許可の呼び出しは例外
// - ウェブアプリの画面から呼ばれた処理では SpreadsheetApp.getUi() が例外
// - Session の getActiveUser / getEffectiveUser は、公開の設定で変わる（「自分」として実行なら違う人か空）
// - google.script.run は Date を運べない（返事に混ざると、返事ごと null になる）

const ROOT_ = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
/** dist/ は npm test の前（pretest の npm run build）に作られる */
export const MANIFEST_ = JSON.parse(readFileSync(join(ROOT_, "dist", "appsscript.json"), "utf8"));
const SCOPE_SHEETS_ = "https://www.googleapis.com/auth/spreadsheets";
const SCOPE_UI_ = "https://www.googleapis.com/auth/script.container.ui";
const SCOPE_EMAIL_ = "https://www.googleapis.com/auth/userinfo.email";
export const OWNER_ = "owner@example.com";
const DIST_DIR_ = join(ROOT_, "dist");

/**
 * 本物の Sheets が、書き込んだ文字を打ち込んだときと同じように読み直すまね。
 * timeZone はスプレッドシート本体の時間帯（日付はその時間帯の 0 時になる）
 */
export function parseWritten_(value, timeZone) {
  if (typeof value !== "string") return value;
  if (value.charAt(0) === "'") return value.slice(1);
  const text = value.trim();
  if (text === "") return value;
  if (/^(true|false)$/i.test(text)) return text.toLowerCase() === "true";
  if (/^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$/.test(text)) return Number(text.replace(/,/g, ""));
  if (/^[+-]?(\d+(\.\d+)?|\.\d+)(e[+-]?\d+)?$/i.test(text)) return Number(text);
  if (/^[+-]?\d+(\.\d+)?%$/.test(text)) return Number(text.slice(0, -1)) / 100;
  const pad = (n) => String(n).padStart(2, "0");
  let m = text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  if (m) return zonedMidnight_(m[1] + "-" + pad(m[2]) + "-" + pad(m[3]), timeZone);
  m = text.match(/^(\d{4})[-/](\d{1,2})$/);
  if (m && +m[2] >= 1 && +m[2] <= 12) return zonedMidnight_(m[1] + "-" + pad(m[2]) + "-01", timeZone);
  m = text.match(/^(\d{1,2})\/(\d{1,2})$/);
  if (m && +m[1] >= 1 && +m[1] <= 12 && +m[2] >= 1 && +m[2] <= 31) return zonedMidnight_("2026-" + pad(m[1]) + "-" + pad(m[2]), timeZone);
  return value;
}

/** 本物と同じく、空のシートの getDataRange() は 1 行 1 列の空を返す。seed は「打ち込まれた」ものとして読み替える */
function fakeSheet_(name, values, context) {
  const timeZone = () => context.timeZone();
  const rows = values.map((row) => row.map((cell) => parseWritten_(cell, timeZone())));
  const plain = new Set(); // 書式なしテキストのマス（"r,c"。0 始まり）
  const widthOf = () => rows.reduce((most, row) => Math.max(most, row.length), 0);
  const isEmpty_ = (cell) => cell === "" || cell === null || cell === undefined;
  const write_ = (r, c, value) => {
    while (rows.length <= r) rows.push([]);
    while (rows[r].length <= c) rows[r].push("");
    // 書式なしテキストのマスは、書いた文字をそのまま持つ（数や Date を書いたときは、その値のまま）
    rows[r][c] = plain.has(r + "," + c) ? value : parseWritten_(value, timeZone());
  };
  const sheet = {
    rows,
    plain,
    cleared: 0,
    writes: 0,
    getName: () => name,
    getLastRow: () => {
      for (let r = rows.length - 1; r >= 0; r -= 1) if (rows[r].some((cell) => !isEmpty_(cell))) return r + 1;
      return 0;
    },
    getLastColumn: widthOf,
    getDataRange: () => ({
      getValues: () => {
        const last = sheet.getLastRow();
        if (last === 0) return [[""]];
        const width = widthOf();
        return rows.slice(0, last).map((row) => {
          const line = row.slice();
          while (line.length < width) line.push("");
          return line;
        });
      },
    }),
    getRange: (r, c, nr, nc) => {
      if (!(r >= 1 && c >= 1)) throw new Error("Those rows are out of bounds.");
      const range = {
        getValues: () => {
          const out = [];
          for (let i = 0; i < (nr || 1); i += 1) {
            const line = [];
            for (let j = 0; j < (nc || 1); j += 1) line.push(rows[r - 1 + i] && rows[r - 1 + i][c - 1 + j] !== undefined ? rows[r - 1 + i][c - 1 + j] : "");
            out.push(line);
          }
          return out;
        },
        setValues: (grid) => {
          // 本物は、範囲と同じ大きさの長方形しか受け付けない
          if (grid.length !== (nr || 1)) throw new Error("The number of rows in the data does not match the number of rows in the range.");
          for (const line of grid) if (line.length !== (nc || 1)) throw new Error("The number of columns in the data does not match the number of columns in the range.");
          sheet.writes += 1;
          for (let i = 0; i < grid.length; i += 1) for (let j = 0; j < grid[i].length; j += 1) write_(r - 1 + i, c - 1 + j, grid[i][j]);
        },
        setNumberFormat: (format) => {
          for (let i = 0; i < (nr || 1); i += 1)
            for (let j = 0; j < (nc || 1); j += 1) {
              if (format === "@") plain.add(r - 1 + i + "," + (c - 1 + j));
              else plain.delete(r - 1 + i + "," + (c - 1 + j));
            }
          return range;
        },
      };
      return range;
    },
    // clear() は書式まで消すので実装しない。書き込みは clearContents() だけを使うはず
    // （うっかり clear() を呼ぶコードが混ざれば、ここで "sheet.clear is not a function" として見つかる）。
    // 本物と同じく、書式（書式なしテキストの指定）は残る
    clearContents: () => {
      sheet.cleared += 1;
      rows.length = 0;
    },
    setFrozenRows: () => {},
  };
  return sheet;
}

/** 人がマスに打ち込むまね（そのマスの書式に従って読み替えられる） */
export function typeInto_(sheet, row, column, text) {
  sheet.getRange(row, column, 1, 1).setValues([[text]]);
}

/**
 * 本物の Utilities.formatDate と同じく、指定した時間帯で実際に書式づける（Intl 任せ）。
 * "yyyy-MM-dd"・"yyyy"（時刻だけのマスの見分けに使う）・"HH:mm"（時刻だけのマスの中身）だけに対応する
 */
export function fakeFormatDate_(date, timeZone, format) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).formatToParts(date);
  const get = (type) => parts.find((p) => p.type === type).value;
  if (format === "yyyy-MM-dd") return get("year") + "-" + get("month") + "-" + get("day");
  if (format === "yyyy") return get("year");
  if (format === "HH:mm") return get("hour") + ":" + get("minute");
  throw new Error("fakeFormatDate_: 知らない書式です: " + format);
}

/**
 * 偽の GAS 一式。globals（SpreadsheetApp など）と、書いたシート・呼ばれた跡（trace）を返す。
 * options:
 * - sheets: 最初からあるシート（打ち込まれた値として読み替える）
 * - answer: はい・いいえの問いへの答え
 * - webContext: ウェブアプリの画面から（google.script.run で）呼ばれた処理（getUi が例外）
 * - activeUser / effectiveUser: 開いた方・権限を使っている方のアドレス（既定はどちらも持ち主）。
 *   「自分として実行」で公開されたときは、effectiveUser が持ち主で activeUser が別の方か空になる
 * - scopes: マニフェストの許可を差し替える（既定は dist/appsscript.json のまま）
 */
export function createGasFakes(options) {
  const opts = options || {};
  const sheets = new Map();
  const context = {
    timeZone: () => (opts.spreadsheetTimeZone ? opts.spreadsheetTimeZone : SPREADSHEET_TIME_ZONE_),
  };
  const seed = opts.sheets || {};
  for (const name of Object.keys(seed)) sheets.set(name, fakeSheet_(name, seed[name], context));

  const trace = { alerts: [], prompts: [], menu: [], errors: [], html: [], scopeErrors: [], bookOpened: 0 };
  const scopes = opts.scopes || MANIFEST_.oauthScopes;
  const need = (scope, what) => {
    if (scopes.indexOf(scope) === -1) {
      trace.scopeErrors.push(what);
      throw new Error("Specified permissions are not sufficient to call " + what + ". Required permissions: " + scope);
    }
  };
  const menu = {
    addItem: (label, fn) => {
      trace.menu.push([label, fn]);
      return menu;
    },
    addSeparator: () => menu,
    addToUi: () => {},
  };
  const ui = {
    Button: { YES: "YES", NO: "NO", OK: "OK" },
    ButtonSet: { YES_NO: "YES_NO", OK: "OK" },
    alert: (a, b, c) => {
      if (c === undefined) {
        trace.alerts.push(String(a));
        return "OK";
      }
      trace.prompts.push({ title: String(a), text: String(b), buttons: c });
      return opts.answer === undefined ? "NO" : opts.answer;
    },
    createMenu: (title) => {
      trace.menu.push(["menu", title]);
      return menu;
    },
  };

  const book = {
    // opts.brokenSheet は「そのシートだけ読めない」を試すため（`設定` は読めるまま失敗させたいとき）
    getSheetByName: (name) => {
      if (opts.brokenSheet !== undefined && name === opts.brokenSheet) throw new Error("You do not have permission to access the requested document.");
      return sheets.has(name) ? sheets.get(name) : null;
    },
    insertSheet: (name) => {
      if (sheets.has(name)) throw new Error('シート "' + name + '" はすでにあります');
      const made = fakeSheet_(name, [], context);
      sheets.set(name, made);
      return made;
    },
    // スプレッドシート本体の時間帯。既定はスクリプトの時間帯（Asia/Tokyo）とわざと違えてある。
    // opts.spreadsheetTimeZone === "" は「空で読めた」、opts.spreadsheetTimeZoneThrows は「読めなかった」を試すため
    getSpreadsheetTimeZone: () => {
      if (opts.spreadsheetTimeZoneThrows) throw new Error("You do not have permission to access the requested document.");
      return opts.spreadsheetTimeZone === undefined ? SPREADSHEET_TIME_ZONE_ : opts.spreadsheetTimeZone;
    },
  };

  const userOf = (email) => ({
    getEmail: () => {
      need(SCOPE_EMAIL_, "Session.getActiveUser().getEmail");
      return email;
    },
  });

  const globals = {
    SpreadsheetApp: {
      getActiveSpreadsheet: () => {
        need(SCOPE_SHEETS_, "SpreadsheetApp.getActiveSpreadsheet");
        if (opts.noSpreadsheet) throw new Error("You do not have permission to access the requested document.");
        trace.bookOpened += 1;
        return book;
      },
      getUi: () => {
        if (opts.webContext) throw new Error("Cannot call SpreadsheetApp.getUi() from this context.");
        need(SCOPE_UI_, "SpreadsheetApp.getUi");
        return ui;
      },
    },
    HtmlService: {
      createHtmlOutputFromFile: (file) => {
        // 本物は、プロジェクトにそのファイルが無ければ例外（貼るのは dist/App.html）
        if (!existsSync(join(DIST_DIR_, file + ".html"))) throw new Error("No HTML file named " + file + " was found.");
        const out = { file, title: "", meta: [] };
        out.setTitle = (title) => {
          out.title = title;
          return out;
        };
        out.addMetaTag = (key, value) => {
          out.meta.push([key, value]);
          return out;
        };
        trace.html.push(out);
        return out;
      },
    },
    ScriptApp: { getService: () => ({ getUrl: () => (opts.appUrl === undefined ? "" : opts.appUrl) }) },
    Session: {
      getScriptTimeZone: () => SCRIPT_TIME_ZONE_,
      getActiveUser: () => userOf(opts.activeUser === undefined ? OWNER_ : opts.activeUser),
      getEffectiveUser: () => userOf(opts.effectiveUser === undefined ? OWNER_ : opts.effectiveUser),
    },
    // 本物の Utilities.formatDate と同じく、指定した時間帯で本当に書式づけする
    Utilities: { formatDate: fakeFormatDate_ },
  };

  return {
    globals,
    sheets,
    trace,
    sheetRows: (name) => (sheets.has(name) ? sheets.get(name).rows : null),
  };
}

/**
 * その一瞬に、timeZone の壁時計が指している時刻と、UTC とのずれ（ミリ秒）。
 * 文字にしてから読み戻す（Date の解釈）と、検査を動かすパソコン自身の時間帯に
 * 引きずられてしまうので、fakeFormatDate_ と同じく formatToParts + Date.UTC で作る
 */
function zonedOffsetMs_(instant, timeZone) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).formatToParts(instant);
  const get = (type) => Number(parts.find((p) => p.type === type).value);
  return Date.UTC(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), get("second")) - instant.getTime();
}

/**
 * dateKey（"YYYY-MM-DD"）の、timeZone での 0 時にあたる Date を作る。
 * 「その時間帯の壁時計で 0 時」から「UTC の一瞬」を作る決まった手順は無いので、
 * 一度 UTC の 0 時と見なしてから、その時間帯とのずれを測って引き戻す。
 * ずれは季節で変わるので、引き戻した一瞬でもう一度測り直す（DST の変わり目をまたいでも合う）
 */
export function zonedMidnight_(dateKey, timeZone) {
  const wanted = Date.parse(dateKey + "T00:00:00Z");
  let guess = wanted - zonedOffsetMs_(new Date(wanted), timeZone);
  guess = wanted - zonedOffsetMs_(new Date(guess), timeZone);
  return new Date(guess);
}


/**
 * google.script.run が返事を画面へ運ぶときのまね。
 * 本物は Date・関数などを運べず、返事のどこかに Date が混ざると返事ごと null になる。
 * undefined の項目は落ち、それ以外は JSON と同じ形の写しになる
 */
export function scriptRunTransport_(value) {
  const hasForbidden = (item) => {
    if (Object.prototype.toString.call(item) === "[object Date]" || typeof item === "function") return true;
    if (Array.isArray(item)) return item.some(hasForbidden);
    if (item !== null && typeof item === "object") return Object.keys(item).some((key) => hasForbidden(item[key]));
    return false;
  };
  if (value === undefined) return null;
  if (hasForbidden(value)) return null;
  return JSON.parse(JSON.stringify(value));
}
