import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { parseConfig } from "../src/core/config.js";
import { buildDashboard } from "../src/core/model.js";

const TODAY = "2026-09-19";

// ---- 手作りのデータ（しおかぜ珈琲店の売上を模した 30 行） -----------------
// 2026-09 は 1 日〜19 日、2026-08 は 19 日までとそれ以降に分けてある。
// 金額に 1 つだけ数として読めなかった値（null）を混ぜ、カテゴリに 1 つだけ空欄を混ぜてある

const SALES_COLUMNS = ["日付", "チャネル", "カテゴリ", "商品", "数量", "金額"];
const SALES_TYPES = { 日付: "date", チャネル: "text", カテゴリ: "text", 商品: "text", 数量: "number", 金額: "number" };

const SALES_CELLS = [
  ["2026-09-01", "EC", "コーヒー豆", "深煎り", 2, 3000],
  ["2026-09-02", "店舗", "コーヒー豆", "深煎り", 1, 1500],
  ["2026-09-03", "EC", "ドリップバッグ", "10袋", 3, 2000],
  ["2026-09-04", "電話", "菓子", "クッキー", 1, 800],
  ["2026-09-05", "EC", "コーヒー豆", "浅煎り", 4, 6000],
  ["2026-09-06", "店舗", "器具", "ドリッパー", 1, 2500],
  ["2026-09-07", "EC", "ギフト", "詰め合わせ", 2, 5000],
  ["2026-09-08", "店舗", "", "未分類", 1, 700],
  ["2026-09-09", "EC", "コーヒー豆", "深煎り", 2, 3000],
  ["2026-09-10", "店舗", "ドリップバッグ", "5袋", 1, 1000],
  ["2026-09-11", "EC", "菓子", "クッキー", 2, 1600],
  ["2026-09-12", "電話", "コーヒー豆", "浅煎り", 1, 1500],
  ["2026-09-13", "EC", "器具", "ミル", 1, 4000],
  ["2026-09-14", "店舗", "コーヒー豆", "深煎り", 1, null],
  ["2026-09-19", "EC", "ギフト", "詰め合わせ", 1, 2500],
  ["2026-08-02", "EC", "コーヒー豆", "深煎り", 2, 3000],
  ["2026-08-04", "店舗", "ドリップバッグ", "10袋", 2, 1500],
  ["2026-08-06", "電話", "菓子", "クッキー", 1, 800],
  ["2026-08-08", "EC", "コーヒー豆", "浅煎り", 3, 4500],
  ["2026-08-10", "店舗", "器具", "ドリッパー", 1, 2500],
  ["2026-08-12", "EC", "ギフト", "詰め合わせ", 1, 2500],
  ["2026-08-14", "店舗", "コーヒー豆", "深煎り", 1, 1500],
  ["2026-08-16", "EC", "ドリップバッグ", "5袋", 2, 2000],
  ["2026-08-18", "電話", "コーヒー豆", "浅煎り", 1, 1500],
  ["2026-08-19", "EC", "菓子", "マドレーヌ", 2, 1700],
  ["2026-08-25", "店舗", "コーヒー豆", "深煎り", 2, 3000],
  ["2026-08-26", "EC", "ドリップバッグ", "10袋", 1, 1000],
  ["2026-08-28", "EC", "ギフト", "詰め合わせ", 1, 2500],
  ["2026-08-30", "電話", "器具", "ミル", 1, 4000],
  ["2026-08-31", "店舗", "", "未分類", 1, 600],
];

function toRows_(columns, cells) {
  return cells.map((row) => {
    const record = {};
    columns.forEach((column, index) => {
      record[column] = row[index];
    });
    return record;
  });
}

const SALES_ROWS = toRows_(SALES_COLUMNS, SALES_CELLS);

const TARGET_COLUMNS = ["月", "目標額"];
const TARGET_TYPES = { 月: "text", 目標額: "number" };
const TARGET_ROWS = toRows_(TARGET_COLUMNS, [
  ["2026-08", 40000],
  ["2026-09", 50000],
]);

const ITEM_COLUMNS = ["区分", "金額"];
const ITEM_TYPES = { 区分: "text", 金額: "number" };
const ITEM_ROWS = toRows_(ITEM_COLUMNS, [
  ["区分A", 400],
  ["区分B", 350],
  ["区分C", 300],
  ["区分D", 250],
  ["区分E", 200],
  ["区分F", 150],
  ["区分G", 100],
  ["区分H", 50],
  ["区分I", 40],
  ["区分J", 30],
  ["区分K", 20],
  ["区分L", 10],
]);

/** 全角 5 字の区分が 8 つ（幅で見ると縦には並べきれない） */
const FIVE_ROWS = toRows_(["区分", "金額"], [
  ["第一営業課", 800],
  ["第二営業課", 700],
  ["第三営業課", 600],
  ["第四営業課", 500],
  ["第五営業課", 400],
  ["第六営業課", 300],
  ["第七営業課", 200],
  ["第八営業課", 100],
]);
/** 同じ 8 区分でも、半角の短い名前なら縦に並べられる */
const CODE_ROWS = toRows_(["区分", "金額"], [
  ["AB-01", 800],
  ["AB-02", 700],
  ["AB-03", 600],
  ["AB-04", 500],
  ["AB-05", 400],
  ["AB-06", 300],
  ["AB-07", 200],
  ["AB-08", 100],
]);

const LABEL_COLUMNS = ["区分", "金額"];
const LABEL_TYPES = { 区分: "text", 金額: "number" };
const LABEL_ROWS = toRows_(LABEL_COLUMNS, [
  ["Drip bag set", 300],
  ["Beans", 200],
  ["Gift", 100],
]);

// 12 区分をひとつの棒に積むための、区分の上に「全体」を足したデータ（色の番号を確かめる）
const WIDE_COLUMNS = ["全体", "区分", "金額"];
const WIDE_TYPES = { 全体: "text", 区分: "text", 金額: "number" };
const WIDE_ROWS = ITEM_ROWS.map((row) => Object.assign({ 全体: "全社" }, row));

// ---- 負の値を含む手作りのデータ ---------------------------------------------

const SIGNED_COLUMNS = ["日付", "区分", "種別", "金額"];
const SIGNED_TYPES = { 日付: "date", 区分: "text", 種別: "text", 金額: "number" };
/** 9 月の 3 区分。合計は 部門C 1,000・部門B -3,000・部門A -5,000 */
const SIGNED_ROWS = toRows_(SIGNED_COLUMNS, [
  ["2026-09-02", "部門A", "調整", -5000],
  ["2026-09-03", "部門B", "調整", -3000],
  ["2026-09-04", "部門C", "売上", 1000],
]);
/** ひとつの区分の中に正と負の面がある（入金 100・返金 -60 で正味 40） */
const NETTED_ROWS = toRows_(SIGNED_COLUMNS, [
  ["2026-09-05", "部門A", "入金", 100],
  ["2026-09-06", "部門A", "返金", -60],
]);

const SWING_COLUMNS = ["日付", "金額"];
const SWING_TYPES = { 日付: "date", 金額: "number" };
/** 9 月から見た前の期間（8/1〜8/19）には行があるが、合計は 0 になる */
const SWING_ROWS = toRows_(SWING_COLUMNS, [
  ["2026-08-05", 15000],
  ["2026-08-06", -15000],
  ["2026-09-03", 33000],
]);
// ---- 3 か月にまたがるデータ（月の目標の確かめに使う） -----------------------

const SPAN_COLUMNS = ["日付", "チャネル", "金額"];
const SPAN_TYPES = { 日付: "date", チャネル: "text", 金額: "number" };
/** 7 月 30,000・8 月 40,000・9 月 35,000（9 月は 19 日より後にも 1 行ある） */
const SPAN_ROWS = toRows_(SPAN_COLUMNS, [
  ["2026-07-10", "EC", 30000],
  ["2026-08-10", "EC", 40000],
  ["2026-09-05", "EC", 20000],
  ["2026-09-18", "店舗", 10000],
  ["2026-09-25", "EC", 5000],
]);

/** どの期間で見ても、前の期間に行が 1 つはあるデータ（差の札を確かめるため） */
const HISTORY_ROWS = toRows_(SWING_COLUMNS, [
  ["2025-05-01", 100],
  ["2026-05-01", 100],
  ["2026-07-10", 100],
  ["2026-08-10", 100],
  ["2026-09-10", 100],
  ["2026-09-15", 100],
]);

function makeDatasets(overrides) {
  return Object.assign(
    {
      sales: { columns: SALES_COLUMNS, rows: SALES_ROWS, types: SALES_TYPES, truncated: false },
      targets: { columns: TARGET_COLUMNS, rows: TARGET_ROWS, types: TARGET_TYPES, truncated: false },
      items: { columns: ITEM_COLUMNS, rows: ITEM_ROWS, types: ITEM_TYPES, truncated: false },
      labels: { columns: LABEL_COLUMNS, rows: LABEL_ROWS, types: LABEL_TYPES, truncated: false },
      fives: { columns: ITEM_COLUMNS, rows: FIVE_ROWS, types: ITEM_TYPES, truncated: false },
      codes: { columns: ITEM_COLUMNS, rows: CODE_ROWS, types: ITEM_TYPES, truncated: false },
      wide: { columns: WIDE_COLUMNS, rows: WIDE_ROWS, types: WIDE_TYPES, truncated: false },
      signed: { columns: SIGNED_COLUMNS, rows: SIGNED_ROWS, types: SIGNED_TYPES, truncated: false },
      netted: { columns: SIGNED_COLUMNS, rows: NETTED_ROWS, types: SIGNED_TYPES, truncated: false },
      swings: { columns: SWING_COLUMNS, rows: SWING_ROWS, types: SWING_TYPES, truncated: false },
      history: { columns: SWING_COLUMNS, rows: HISTORY_ROWS, types: SWING_TYPES, truncated: false },
      span: { columns: SPAN_COLUMNS, rows: SPAN_ROWS, types: SPAN_TYPES, truncated: false },
    },
    overrides || {}
  );
}

function makeConfig(widgets, overrides) {
  const raw = Object.assign(
    {
      title: "しおかぜ珈琲店 売上ダッシュボード",
      lang: "ja",
      datasets: {
        sales: { url: "./sales.csv", dateColumn: "日付" },
        targets: { url: "./targets.csv" },
        items: { url: "./items.csv" },
        labels: { url: "./labels.csv" },
        fives: { url: "./fives.csv" },
        codes: { url: "./codes.csv" },
        wide: { url: "./wide.csv" },
        signed: { url: "./signed.csv", dateColumn: "日付" },
        netted: { url: "./netted.csv", dateColumn: "日付" },
        swings: { url: "./swings.csv", dateColumn: "日付" },
        history: { url: "./history.csv", dateColumn: "日付" },
        span: { url: "./span.csv", dateColumn: "日付" },
      },
      filters: { period: "thisMonth", dimensions: ["チャネル"] },
      widgets,
    },
    overrides || {}
  );
  const parsed = parseConfig(raw);
  assert.deepEqual(parsed.errors, [], "見本の設定に誤りがあってはならない");
  return parsed.config;
}

/** 1 つ以上の部品を組み立てて、ダッシュボード全体を返す */
function build(widgets, options) {
  const opts = options || {};
  const config = makeConfig(widgets, opts.config);
  const filters = Object.assign({ period: "thisMonth", from: "", to: "", dimensions: { チャネル: "" } }, opts.filters);
  return buildDashboard({
    config,
    datasets: opts.datasets || makeDatasets(),
    filters,
    today: TODAY,
    lang: opts.lang || "ja",
  });
}

/** 1 つだけの部品の model を返す */
function only(widget, options) {
  return build([widget], options).widgets[0];
}

const KPI = { type: "kpi", title: "売上", dataset: "sales", value: "金額", agg: "sum", format: "yen", size: "s" };
const LINE = { type: "line", title: "売上の推移", dataset: "sales", value: "金額", agg: "sum", splitBy: "チャネル", bucket: "auto", format: "yen", size: "l" };
const BAR = { type: "bar", title: "カテゴリ別の売上", dataset: "sales", category: "カテゴリ", value: "金額", agg: "sum", top: 8, format: "yen", size: "m" };
const METER = {
  type: "meter",
  title: "今月の目標",
  dataset: "sales",
  value: "金額",
  agg: "sum",
  target: { dataset: "targets", value: "目標額", matchMonth: "月" },
  format: "yen",
  size: "m",
};
/** 3 か月にまたがるデータを使う目標の部品（月の目標の確かめに使う） */
const SPAN_METER = Object.assign({}, METER, { dataset: "span" });
const SWINGS_KPI = { type: "kpi", title: "差引", dataset: "swings", value: "金額", agg: "sum", format: "yen", size: "s" };
const HISTORY_KPI = { type: "kpi", title: "合計", dataset: "history", value: "金額", agg: "sum", format: "number", size: "s" };
const TABLE = {
  type: "table",
  title: "商品別",
  dataset: "sales",
  groupBy: "商品",
  columns: [
    { value: "数量", agg: "sum", label: "数量" },
    { value: "金額", agg: "sum", label: "売上", format: "yen" },
  ],
  sort: "売上",
  top: 3,
  size: "l",
};

// ---- ダッシュボード全体 ---------------------------------------------------

test("buildDashboard: 題・期間・前の期間を返す", () => {
  const dashboard = build([KPI]);
  assert.equal(dashboard.title, "しおかぜ珈琲店 売上ダッシュボード");
  assert.deepEqual(dashboard.range, { from: "2026-09-01", to: "2026-09-19" });
  assert.deepEqual(dashboard.previous, { from: "2026-08-01", to: "2026-08-19" });
  assert.equal(dashboard.widgets.length, 1);
  assert.deepEqual(dashboard.notes, []);
});

test("buildDashboard: id・題・大きさ・書式はそのまま渡す", () => {
  const kpi = only(KPI);
  assert.equal(kpi.id, "w1");
  assert.equal(kpi.type, "kpi");
  assert.equal(kpi.title, "売上");
  assert.equal(kpi.size, "s");
  assert.equal(kpi.format, "yen");
});

test("buildDashboard: データセットが無い名前は誤りの札にする", () => {
  const widget = only(KPI, { datasets: makeDatasets({ sales: undefined }) });
  assert.equal(widget.type, "error");
  assert.equal(widget.id, "w1");
  assert.equal(widget.title, "売上");
  assert.equal(widget.message, "データ「sales」が見つかりません。設定をご確認ください。");
});

test("buildDashboard: 設定に書いた列がデータに無いときは、列の名前を添えた誤りの札にする", () => {
  const latest = { type: "table", title: "新しい明細", dataset: "sales", rows: "latest", columns: ["日付", "無い列"], top: 3, size: "l" };
  const cases = [
    ["値の列", Object.assign({}, KPI, { value: "無い値列" }), "無い値列"],
    ["区分の列", Object.assign({}, BAR, { category: "無い区分列" }), "無い区分列"],
    ["棒の分ける列", Object.assign({}, BAR, { splitBy: "無い分け列" }), "無い分け列"],
    ["折れ線の分ける列", Object.assign({}, LINE, { splitBy: "無い分け列" }), "無い分け列"],
    ["折れ線の日付の列", Object.assign({}, LINE, { dateColumn: "無い日付列" }), "無い日付列"],
    ["表の区分の列", Object.assign({}, TABLE, { groupBy: "無い区分列" }), "無い区分列"],
    ["表の値の列", Object.assign({}, TABLE, { columns: [{ value: "無い値列", agg: "sum", label: "売上" }] }), "無い値列"],
    ["明細の列", latest, "無い列"],
  ];
  for (const [label, widget, column] of cases) {
    const model = only(widget);
    assert.equal(model.type, "error", label + " は誤りの札になる");
    assert.equal(model.title, widget.title);
    assert.equal(model.message, "データ「sales」に列「" + column + "」が見つかりません。設定をご確認ください。", label);
  }
});

test("buildDashboard: データセットの日付の列がデータに無いときも誤りの札にする", () => {
  const config = { datasets: { sales: { url: "./sales.csv", dateColumn: "無い日付列" } } };
  const kpi = only(KPI, { config });
  assert.equal(kpi.type, "error");
  assert.equal(kpi.message, "データ「sales」に列「無い日付列」が見つかりません。設定をご確認ください。");
});

test("buildDashboard: データセットの日付の列がデータに無いときは、部品の種類によらず誤りの札にする", () => {
  const config = { datasets: { sales: { url: "./sales.csv", dateColumn: "無い日付列" }, targets: { url: "./targets.csv" } } };
  const latest = { type: "table", title: "新しい明細", dataset: "sales", rows: "latest", columns: ["日付", "商品"], top: 3, size: "l" };
  const cases = [
    ["棒", BAR],
    ["区分ごとの表", TABLE],
    ["明細の表", latest],
    ["meter", METER],
  ];
  for (const [label, widget] of cases) {
    const model = only(widget, { config });
    assert.equal(model.type, "error", label + " は誤りの札になる");
    assert.equal(model.message, "データ「sales」に列「無い日付列」が見つかりません。設定をご確認ください。", label);
  }
});

test("buildDashboard: データセットの日付の列は、他の列より先に確かめる", () => {
  const config = { datasets: { sales: { url: "./sales.csv", dateColumn: "無い日付列" }, targets: { url: "./targets.csv" } } };
  const bar = only(Object.assign({}, BAR, { category: "無い区分列" }), { config });
  assert.equal(bar.type, "error");
  assert.equal(bar.message, "データ「sales」に列「無い日付列」が見つかりません。設定をご確認ください。");
});

test("meter: 目標のデータセットの日付の列がデータに無いときも誤りの札にする", () => {
  const config = {
    datasets: { sales: { url: "./sales.csv", dateColumn: "日付" }, targets: { url: "./targets.csv", dateColumn: "無い日付列" } },
  };
  const meter = only(METER, { config });
  assert.equal(meter.type, "error");
  assert.equal(meter.message, "データ「targets」に列「無い日付列」が見つかりません。設定をご確認ください。");
});

test("buildDashboard: 日付の列の設定が無いデータセットは、期間を絞っても全部の行を使う", () => {
  const widget = { type: "bar", title: "区分別", dataset: "items", category: "区分", value: "金額", agg: "sum", top: 8, size: "m" };
  const narrowed = only(widget, { filters: { period: "custom", from: "2099-01-01", to: "2099-01-31" } });
  const all = only(widget, { filters: { period: "all" } });
  assert.equal(narrowed.type, "bar");
  assert.deepEqual(narrowed.categories.map((c) => c.total), all.categories.map((c) => c.total));
  assert.equal(narrowed.categories[8].total, 100); // その他 = 40+30+20+10、期間で減っていない
});

test("buildDashboard: 列が無いことより先に、データセットが無いことを知らせる", () => {
  const widget = only(Object.assign({}, BAR, { category: "無い区分列" }), { datasets: makeDatasets({ sales: undefined }) });
  assert.equal(widget.message, "データ「sales」が見つかりません。設定をご確認ください。");
});

test("buildDashboard: 件数を数えるだけの部品は、値の列が無くても誤りにしない", () => {
  const kpi = only(Object.assign({}, KPI, { title: "件数", agg: "count", value: undefined, format: "number" }));
  assert.equal(kpi.type, "kpi");
  assert.equal(kpi.valueFull, "15");
});

test("buildDashboard: 設定の誤りの札はそのまま通す", () => {
  const raw = {
    title: "見本",
    datasets: { sales: { url: "./sales.csv", dateColumn: "日付" } },
    widgets: [{ type: "kpi", title: "売上", dataset: "sales" }],
  };
  const parsed = parseConfig(raw);
  assert.equal(parsed.config.widgets[0].type, "error");
  const dashboard = buildDashboard({
    config: parsed.config,
    datasets: makeDatasets(),
    filters: { period: "thisMonth", from: "", to: "", dimensions: {} },
    today: TODAY,
    lang: "ja",
  });
  assert.deepEqual(dashboard.widgets[0], parsed.config.widgets[0]);
});

test("buildDashboard: 20,000 行を超えたデータを使ったときだけ、その知らせを 1 回だけ出す", () => {
  const datasets = makeDatasets({ items: { columns: ITEM_COLUMNS, rows: ITEM_ROWS, types: ITEM_TYPES, truncated: true } });
  const bar = { type: "bar", title: "区分別", dataset: "items", category: "区分", value: "金額", agg: "sum", size: "m" };
  const dashboard = build([bar, Object.assign({}, bar, { title: "区分別（もう 1 つ）" })], { datasets });
  assert.deepEqual(dashboard.notes, ["20,000 行までを表示しています"]);

  const clean = build([KPI]);
  assert.deepEqual(clean.notes, []);
});

// ---- kpi ------------------------------------------------------------------

test("kpi: 合計・前の期間との差・小さな折れ線を決める", () => {
  const kpi = only(KPI);
  assert.equal(kpi.valueText, "¥3.5万"); // 35,100 を縮めた札
  assert.equal(kpi.valueFull, "¥35,100");
  assert.equal(kpi.skipped, 1); // 金額が読めなかった 1 行
  assert.deepEqual(kpi.delta, { text: "+63.3%", textFull: "+63.3%", direction: "up", good: true, label: "先月比" });
  assert.equal(kpi.spark.values.length, 19);
  assert.equal(kpi.spark.values[0], 3000);
  assert.equal(kpi.spark.values[4], 6000);
  assert.equal(kpi.spark.min, 0);
  assert.equal(kpi.spark.max, 6000);
});

test("kpi: 表で見るは 1 行（項目・値・前の期間・差）", () => {
  const kpi = only(KPI);
  assert.deepEqual(kpi.table.head, ["項目", "値", "前の期間", "差"]);
  assert.deepEqual(kpi.table.rows, [["売上", "¥35,100", "¥21,500", "+63.3%"]]);
});

test("kpi: goodWhen が down のときは、増えたことを良くないと見る", () => {
  const kpi = only(Object.assign({}, KPI, { goodWhen: "down" }));
  assert.equal(kpi.delta.direction, "up");
  assert.equal(kpi.delta.good, false);
});

test("kpi: 比べないときと全期間のときは差を出さない", () => {
  const none = only(Object.assign({}, KPI, { compare: "none" }));
  assert.equal(none.delta, null);
  assert.deepEqual(none.table.rows, [["売上", "¥35,100", "—", "—"]]);

  const all = only(KPI, { filters: { period: "all" } });
  assert.equal(all.delta, null);
  assert.equal(all.valueFull, "¥67,700"); // 30 行すべての合計
});

test("kpi: 差の札は期間の名前で変わる", () => {
  const cases = [
    ["thisMonth", "先月比"],
    ["last7", "前の 7 日比"],
    ["last30", "前の 30 日比"],
    ["last90", "前の 90 日比"],
    ["thisYear", "昨年比"],
  ];
  for (const [period, label] of cases) {
    const kpi = only(HISTORY_KPI, { filters: { period } });
    assert.equal(kpi.delta.label, label, period + " の札");
  }
  const custom = only(HISTORY_KPI, { filters: { period: "custom", from: "2026-09-01", to: "2026-09-19" } });
  assert.equal(custom.delta.label, "前の期間比");
  const lastMonth = only(HISTORY_KPI, { filters: { period: "lastMonth" } });
  assert.equal(lastMonth.delta.label, "前の期間比");
});

test("kpi: 前の期間に行が 1 つも無いときは、比べる相手がないので差を出さない", () => {
  const kpi = only(KPI, { filters: { period: "lastMonth" } }); // 8 月の前は 7 月で、行が 1 つも無い
  assert.equal(kpi.valueFull, "¥32,600");
  assert.equal(kpi.delta, null);
  assert.deepEqual(kpi.table.rows, [["売上", "¥32,600", "—", "—"]]);
});

test("kpi: 前の期間に行があって合計が 0 のときは、割合ではなく差そのものを出す", () => {
  const kpi = only(SWINGS_KPI);
  assert.equal(kpi.valueFull, "¥33,000");
  assert.equal(kpi.delta.direction, "up");
  assert.equal(kpi.delta.good, true);
  assert.equal(kpi.delta.text, "+¥3.3万"); // 札は縮める
  assert.equal(kpi.delta.textFull, "+¥33,000"); // 表は縮めない
  assert.deepEqual(kpi.table.rows, [["差引", "¥33,000", "¥0", "+¥33,000"]]);
});

test("kpi: 割合で出せるときは、札も表も同じ割合の文字にする", () => {
  const kpi = only(KPI);
  assert.equal(kpi.delta.text, "+63.3%");
  assert.equal(kpi.delta.textFull, "+63.3%");
});

test("kpi: sparkline を切ると小さな折れ線を作らない", () => {
  const kpi = only(Object.assign({}, KPI, { sparkline: false }));
  assert.equal(kpi.spark, null);
});

test("kpi: 英語のときは英語の単位と札にする（通貨の記号は設定のまま）", () => {
  const kpi = only(KPI, { lang: "en" });
  assert.equal(kpi.valueText, "¥35.1K");
  assert.equal(kpi.delta.label, "vs last month");
  assert.deepEqual(kpi.table.head, ["Item", "Value", "Previous period", "Change"]);
});

// ---- line -----------------------------------------------------------------

test("line: 系列・刻み・目盛り・凡例を決める", () => {
  const line = only(LINE);
  assert.deepEqual(
    line.series.map((s) => [s.key, s.color]),
    [
      ["EC", 1],
      ["店舗", 2],
      ["電話", 3],
    ]
  );
  assert.equal(line.buckets.length, 19);
  assert.deepEqual(line.buckets[0], { key: "2026-09-01", label: "9/1" });
  assert.equal(line.series[0].values[0], 3000);
  assert.equal(line.series[0].values[18], 2500);
  assert.equal(line.series[1].values[13], 0); // 金額が読めなかった 1 行だけの日は 0
  assert.equal(line.series[0].lastLabel, "¥2,500");
  assert.deepEqual(line.ticks, [0, 2000, 4000, 6000]);
  assert.equal(line.yMax, 6000);
  assert.equal(line.legend, true);
  assert.equal(line.area, false);
  assert.equal(line.skipped, 1);
});

test("line: 表で見るは刻みごとの 1 行・系列ごとの 1 列", () => {
  const line = only(LINE);
  assert.deepEqual(line.table.head, ["日付", "EC", "店舗", "電話"]);
  assert.equal(line.table.rows.length, 19);
  assert.deepEqual(line.table.rows[0], ["9/1", "¥3,000", "¥0", "¥0"]);
});

test("line: 分ける列が無いときは 1 本（題の名前・色 1・面を敷く・凡例なし）", () => {
  const line = only(Object.assign({}, LINE, { splitBy: undefined }));
  assert.equal(line.series.length, 1);
  assert.equal(line.series[0].key, "売上の推移");
  assert.equal(line.series[0].color, 1);
  assert.equal(line.area, true);
  assert.equal(line.legend, false);
});

test("line: 系列が 4 本を超えたら上位 3 + その他にまとめる", () => {
  const line = only(Object.assign({}, LINE, { splitBy: "カテゴリ" }));
  assert.deepEqual(
    line.series.map((s) => [s.key, s.color]),
    [
      ["コーヒー豆", 1],
      ["ギフト", 3],
      ["器具", 2],
      ["その他", 0],
    ]
  );
  const other = line.series[3].values.reduce((sum, v) => sum + v, 0);
  assert.equal(other, 6100); // ドリップバッグ 3,000 + 菓子 2,400 + 空欄 700
  assert.equal(line.legend, true);
});

test("line: 平均のときは足し合わせられないので上位 4 本だけにする", () => {
  const line = only(Object.assign({}, LINE, { splitBy: "カテゴリ", agg: "avg" }));
  assert.equal(line.series.length, 4);
  assert.equal(
    line.series.some((s) => s.key === "その他"),
    false
  );
});

test("line: 絞り込んでも色の番号は変わらない", () => {
  const line = only(LINE, { filters: { dimensions: { チャネル: "店舗" } } });
  assert.equal(line.series.length, 1);
  assert.equal(line.series[0].key, "店舗");
  assert.equal(line.series[0].color, 2); // 全データでの並びのまま
  assert.equal(line.area, true);
});

test("line: 期間に行が無いときは、誤りではなく「空」にする", () => {
  const line = only(LINE, { filters: { period: "custom", from: "2026-07-01", to: "2026-07-31" } });
  assert.equal(line.empty, true);
  assert.deepEqual(line.series, []);
  assert.deepEqual(line.buckets, []);
  assert.deepEqual(line.table.head, ["日付", "売上の推移"]); // 空でも「表で見る」の見出しは出す
  assert.deepEqual(line.table.rows, []);
});

test("line: 英語のときは英語の札にする", () => {
  const line = only(LINE, { lang: "en" });
  assert.deepEqual(line.buckets[0], { key: "2026-09-01", label: "Sep 1" });
  assert.equal(line.series[0].lastLabel, "¥2.5K");
  assert.deepEqual(line.table.head, ["日付", "EC", "店舗", "電話"]); // 列の名前はデータのまま

  const merged = only(Object.assign({}, LINE, { splitBy: "カテゴリ" }), { lang: "en" });
  assert.deepEqual(
    merged.series.map((s) => s.key),
    ["コーヒー豆", "ギフト", "器具", "Other"]
  );
});

// ---- bar ------------------------------------------------------------------

test("bar: 区分ごとの合計を大きい順に決める（分ける列が無ければ色は 1・凡例なし）", () => {
  const bar = only(BAR);
  assert.deepEqual(
    bar.categories.map((c) => [c.label, c.total]),
    [
      ["コーヒー豆", 15000],
      ["ギフト", 7500],
      ["器具", 6500],
      ["ドリップバッグ", 3000],
      ["菓子", 2400],
      ["（空欄）", 700],
    ]
  );
  assert.equal(bar.categories[0].totalText, "¥1.5万");
  assert.deepEqual(bar.categories[0].segments, [
    { key: "コーヒー豆", label: "コーヒー豆", color: 1, value: 15000, valueText: "¥15,000" },
  ]);
  assert.deepEqual(bar.ticks, [0, 5000, 10000, 15000]);
  assert.equal(bar.max, 15000);
  assert.equal(bar.legend, false);
  assert.equal(bar.horizontal, true); // 6 区分だが、区分名を縦に並べると 640 の図に収まらない
  assert.deepEqual(bar.table.head, ["カテゴリ", "カテゴリ別の売上"]);
  assert.deepEqual(bar.table.rows[0], ["コーヒー豆", "¥15,000"]);
});

test("bar: 区分が 12 なら上位 8 + その他（その他は色 0・いつも最後）", () => {
  const bar = only({ type: "bar", title: "区分別", dataset: "items", category: "区分", value: "金額", agg: "sum", top: 8, size: "m" });
  assert.deepEqual(
    bar.categories.map((c) => c.label),
    ["区分A", "区分B", "区分C", "区分D", "区分E", "区分F", "区分G", "区分H", "その他"]
  );
  assert.equal(bar.categories[8].total, 100); // 40 + 30 + 20 + 10
  assert.equal(bar.categories[8].segments[0].color, 0);
  assert.equal(bar.categories[0].segments[0].color, 1);
  assert.deepEqual(bar.ticks, [0, 100, 200, 300, 400]);
  assert.equal(bar.legend, false);
});

test("bar: 名前の並びにすると、その他だけを最後に残して名前順にする", () => {
  const bar = only({ type: "bar", title: "区分別", dataset: "items", category: "区分", value: "金額", agg: "sum", top: 8, sort: "label", size: "m" });
  assert.deepEqual(
    bar.categories.map((c) => c.label),
    ["区分A", "区分B", "区分C", "区分D", "区分E", "区分F", "区分G", "区分H", "その他"]
  );

  const sales = only(Object.assign({}, BAR, { sort: "label" }));
  assert.deepEqual(
    sales.categories.map((c) => c.label),
    ["ギフト", "コーヒー豆", "ドリップバッグ", "器具", "菓子", "（空欄）"]
  );
});

test("bar: 横棒の auto は、区分の数と、区分名を縦に並べたときの幅で決める", () => {
  const many = only({ type: "bar", title: "区分別", dataset: "items", category: "区分", value: "金額", agg: "sum", size: "m" });
  assert.equal(many.horizontal, true); // 上位 8 + その他 で 9 区分（数だけで横になる）

  // 8 区分・全角 5 字（5 字 × 12px + 12px のすき間）× 8 = 576 で、640 の図に並べきれない
  const wideNames = only({ type: "bar", title: "区分別", dataset: "fives", category: "区分", value: "金額", agg: "sum", size: "m" });
  assert.equal(wideNames.horizontal, true);

  // 同じ 8 区分でも、半角の短い名前なら縦のまま置ける（字数ではなく幅で見る）
  const narrowNames = only({ type: "bar", title: "区分別", dataset: "codes", category: "区分", value: "金額", agg: "sum", size: "m" });
  assert.equal(narrowNames.horizontal, false);

  // 半角 12 字の名前 3 つは、日本語の画面でも縦に収まる（言語では変えない）
  const longEnJa = only({ type: "bar", title: "区分別", dataset: "labels", category: "区分", value: "金額", agg: "sum", size: "m" });
  const longEn = only({ type: "bar", title: "区分別", dataset: "labels", category: "区分", value: "金額", agg: "sum", size: "m" }, { lang: "en" });
  assert.equal(longEnJa.horizontal, false);
  assert.equal(longEn.horizontal, false);

  const fixed = only({ type: "bar", title: "区分別", dataset: "items", category: "区分", value: "金額", agg: "sum", horizontal: false, size: "m" });
  assert.equal(fixed.horizontal, false); // 設定が auto に勝つ
  const forced = only({ type: "bar", title: "区分別", dataset: "labels", category: "区分", value: "金額", agg: "sum", horizontal: true, size: "m" });
  assert.equal(forced.horizontal, true);
});

test("bar: 分ける列があると、どの区分も同じ順・同じ色の面を持つ", () => {
  const bar = only(Object.assign({}, BAR, { splitBy: "チャネル" }));
  for (const category of bar.categories) {
    assert.deepEqual(
      category.segments.map((s) => [s.key, s.color]),
      [
        ["EC", 1],
        ["店舗", 2],
        ["電話", 3],
      ],
      category.label + " の面"
    );
  }
  assert.deepEqual(
    bar.categories[0].segments.map((s) => s.valueText),
    ["¥12,000", "¥1,500", "¥1,500"]
  );
  assert.equal(bar.legend, true);
  assert.deepEqual(bar.table.head, ["カテゴリ", "EC", "店舗", "電話"]);
  assert.deepEqual(bar.table.rows[0], ["コーヒー豆", "¥12,000", "¥1,500", "¥1,500"]);
});

test("bar: 積み上げの面は 6 つまで（上位 5 + その他）", () => {
  const bar = only(Object.assign({}, BAR, { category: "チャネル", splitBy: "商品" }));
  for (const category of bar.categories) {
    assert.deepEqual(
      category.segments.map((s) => s.key),
      ["浅煎り", "深煎り", "詰め合わせ", "ミル", "ドリッパー", "その他"],
      category.label + " の面"
    );
  }
  assert.deepEqual(
    bar.categories[0].segments.map((s) => s.color),
    [2, 1, 3, 4, 5, 0]
  );
  assert.equal(bar.legend, true);
});

const SIGNED_BAR = { type: "bar", title: "部門別の増減", dataset: "signed", category: "区分", value: "金額", agg: "sum", size: "m" };

test("bar: 負の合計も軸に収める（0 をまたぐ目盛り）", () => {
  const bar = only(SIGNED_BAR);
  assert.deepEqual(
    bar.categories.map((c) => [c.label, c.total, c.posTotal, c.negTotal]),
    [
      ["部門C", 1000, 1000, 0],
      ["部門B", -3000, 0, -3000],
      ["部門A", -5000, 0, -5000],
    ]
  );
  assert.deepEqual(bar.ticks, [-6000, -4000, -2000, 0, 2000]);
  assert.equal(bar.min, -6000);
  assert.equal(bar.max, 2000);
  assert.equal(bar.categories[2].totalText, "-5,000");
  assert.deepEqual(bar.categories[2].segments, [{ key: "部門A", label: "部門A", color: 1, value: -5000, valueText: "-5,000" }]);
  assert.deepEqual(bar.table.rows, [
    ["部門C", "1,000"],
    ["部門B", "-3,000"],
    ["部門A", "-5,000"],
  ]);
});

test("bar: すべてが負のときは 0 を上端にする", () => {
  const bar = only(SIGNED_BAR, { filters: { period: "custom", from: "2026-09-01", to: "2026-09-03" } });
  assert.deepEqual(
    bar.categories.map((c) => c.total),
    [-3000, -5000]
  );
  assert.deepEqual(bar.ticks, [-6000, -4000, -2000, 0]);
  assert.equal(bar.min, -6000);
  assert.equal(bar.max, 0);
});

test("bar: 積み上げの中に負の面があっても、正味の合計と両側の合計を持つ", () => {
  const bar = only({ type: "bar", title: "部門別の内訳", dataset: "netted", category: "区分", splitBy: "種別", value: "金額", agg: "sum", size: "m" });
  const category = bar.categories[0];
  assert.equal(category.label, "部門A");
  assert.equal(category.total, 40); // 正味
  assert.equal(category.posTotal, 100);
  assert.equal(category.negTotal, -60);
  assert.deepEqual(
    category.segments.map((s) => [s.key, s.color, s.value]),
    [
      ["入金", 1, 100],
      ["返金", 2, -60],
    ]
  );
  assert.deepEqual(bar.ticks, [-100, -50, 0, 50, 100]);
  assert.equal(bar.min, -100);
  assert.equal(bar.max, 100);
  assert.equal(bar.legend, true);
});

test("bar: 期間に行が無いときは、誤りではなく空にする", () => {
  const bar = only(BAR, { filters: { period: "custom", from: "2026-07-01", to: "2026-07-31" } });
  assert.equal(bar.empty, true);
  assert.deepEqual(bar.categories, []);
  assert.deepEqual(bar.ticks, [0, 1]);
  assert.equal(bar.min, 0);
  assert.equal(bar.max, 1);
  assert.equal(bar.legend, false);
  assert.deepEqual(bar.table.head, ["カテゴリ", "カテゴリ別の売上"]);
  assert.deepEqual(bar.table.rows, []);
});

test("bar: 分ける列の値が 8 を超えても、色の番号は 0〜8 に収まる", () => {
  const widget = { type: "bar", title: "区分の内訳", dataset: "wide", category: "全体", splitBy: "区分", value: "金額", agg: "sum", size: "m" };
  const bar = only(widget);
  assert.deepEqual(
    bar.categories[0].segments.map((s) => [s.key, s.color]),
    [
      ["区分A", 1],
      ["区分B", 2],
      ["区分C", 3],
      ["区分D", 4],
      ["区分E", 5],
      ["その他", 0],
    ]
  );

  // 9 番目より下の区分は、9 個目の色を作らずに灰の 0 にする
  const low = only(widget, { filters: { dimensions: { 区分: "区分J" } } });
  assert.deepEqual(
    low.categories[0].segments.map((s) => [s.key, s.color]),
    [["区分J", 0]]
  );
  for (const segment of bar.categories[0].segments.concat(low.categories[0].segments)) {
    assert.ok(Number.isInteger(segment.color) && segment.color >= 0 && segment.color <= 8, "色の番号 " + segment.color);
  }
});

test("bar: 英語のときは英語の札にする", () => {
  const bar = only(BAR, { lang: "en" });
  assert.equal(bar.categories[5].label, "(Blank)");
  assert.equal(bar.categories[0].totalText, "¥15K");
  assert.deepEqual(bar.table.rows[0], ["コーヒー豆", "¥15,000"]);

  const many = only({ type: "bar", title: "By item", dataset: "items", category: "区分", value: "金額", agg: "sum", top: 8, size: "m" }, { lang: "en" });
  assert.equal(many.categories[8].label, "Other");
});

// ---- meter ----------------------------------------------------------------

test("meter: 目標のデータから今月の目標を引いて進みを出す", () => {
  const meter = only(METER);
  assert.equal(meter.valueText, "¥3.5万");
  assert.equal(meter.targetText, "¥5万");
  assert.equal(Math.round(meter.ratio * 1000), 702);
  assert.equal(meter.ratioText, "70%");
  assert.equal(meter.achieved, false);
  assert.equal(meter.skipped, 1);
  assert.equal(meter.monthLabel, "2026年9月");
  assert.deepEqual(meter.table.head, ["項目", "値"]);
  assert.deepEqual(meter.table.rows, [
    ["対象の月", "2026年9月"],
    ["実績", "¥35,100"],
    ["目標", "¥50,000"],
    ["達成率", "70%"],
  ]);
});

test("meter: 目標が数のときはその数をそのまま使い、届いていれば達成にする", () => {
  const meter = only(Object.assign({}, METER, { target: 30000 }));
  assert.equal(meter.targetText, "¥3万");
  assert.equal(meter.ratioText, "117%");
  assert.equal(meter.achieved, true);
  assert.equal(meter.monthLabel, "", "数の目標に月は付かない");
  assert.deepEqual(meter.table.rows, [
    ["実績", "¥35,100"],
    ["目標", "¥30,000"],
    ["達成率", "117%"],
  ]);
});

test("meter: 月の書き方は 4 通りとも読む", () => {
  const forms = ["2026-09", "2026/9", "2026年9月", "2026-09-01"];
  for (const form of forms) {
    const targets = { columns: TARGET_COLUMNS, rows: toRows_(TARGET_COLUMNS, [[form, 50000]]), types: TARGET_TYPES, truncated: false };
    const meter = only(METER, { datasets: makeDatasets({ targets }) });
    assert.equal(meter.type, "meter", form + " を読めない");
    assert.equal(meter.targetText, "¥5万", form + " の目標");
  }
});

test("meter: その月の目標が無ければ誤りの札にする", () => {
  const targets = { columns: TARGET_COLUMNS, rows: toRows_(TARGET_COLUMNS, [["2026-10", 50000]]), types: TARGET_TYPES, truncated: false };
  const meter = only(METER, { datasets: makeDatasets({ targets }) });
  assert.equal(meter.type, "error");
  assert.equal(meter.message, "2026年9月 の目標が見つかりません。目標のデータをご確認ください。");
});

test("meter: 目標が 0 以下なら誤りの札にする", () => {
  const targets = { columns: TARGET_COLUMNS, rows: toRows_(TARGET_COLUMNS, [["2026-09", 0]]), types: TARGET_TYPES, truncated: false };
  const meter = only(METER, { datasets: makeDatasets({ targets }) });
  assert.equal(meter.type, "error");
  assert.equal(meter.message, "目標が 0 以下のため、達成率を計算できません。目標のデータをご確認ください。");
});

test("meter: 目標のデータに無い列を指したときは、列の名前を添えた誤りの札にする", () => {
  const badValue = only(Object.assign({}, METER, { target: { dataset: "targets", value: "無い目標列", matchMonth: "月" } }));
  assert.equal(badValue.type, "error");
  assert.equal(badValue.message, "データ「targets」に列「無い目標列」が見つかりません。設定をご確認ください。");

  const badMonth = only(Object.assign({}, METER, { target: { dataset: "targets", value: "目標額", matchMonth: "無い月列" } }));
  assert.equal(badMonth.type, "error");
  assert.equal(badMonth.message, "データ「targets」に列「無い月列」が見つかりません。設定をご確認ください。");
});

test("meter: 目標のデータに無い列で絞り込んでも、目標は空にならない", () => {
  const meter = only(METER, { filters: { dimensions: { チャネル: "店舗" } } });
  assert.equal(meter.type, "meter");
  assert.equal(meter.targetText, "¥5万");
  assert.equal(meter.valueFull, "¥5,700"); // 店舗だけの合計
});

// ---- table ----------------------------------------------------------------

test("table: 区分ごとに集計し、列の札で並べ替えて上位だけを残す", () => {
  const table = only(TABLE);
  assert.deepEqual(table.head, [
    { label: "商品", numeric: false },
    { label: "数量", numeric: true },
    { label: "売上", numeric: true },
  ]);
  assert.equal(table.sortable, true);
  assert.deepEqual(
    table.rows.map((cells) => cells.map((cell) => cell.text)),
    [
      ["深煎り", "6", "¥7,500"],
      ["浅煎り", "5", "¥7,500"],
      ["詰め合わせ", "3", "¥7,500"],
    ]
  );
  assert.deepEqual(table.rows[0][2], { text: "¥7,500", value: 7500 });
  assert.equal(table.skipped, 1);
});

test("table: 小さい順にすると、小さいものから上位だけを残す", () => {
  const table = only(Object.assign({}, TABLE, { order: "asc" }));
  assert.deepEqual(
    table.rows.map((cells) => cells[0].text),
    ["未分類", "5袋", "10袋"]
  );
});

test("table: CSV は通貨の記号も桁区切りも付けない", () => {
  const table = only(TABLE);
  assert.deepEqual(table.csv, [
    ["商品", "数量", "売上"],
    ["深煎り", "6", "7500"],
    ["浅煎り", "5", "7500"],
    ["詰め合わせ", "3", "7500"],
  ]);
});

test("table: 表で見るは、表そのものの文字にする", () => {
  const table = only(TABLE);
  assert.deepEqual(table.table.head, ["商品", "数量", "売上"]);
  assert.deepEqual(table.table.rows[0], ["深煎り", "6", "¥7,500"]);
});

test("table: 新しい順の明細は、日付の新しい順に並べて列をそのまま出す", () => {
  const widget = { type: "table", title: "新しい明細", dataset: "sales", rows: "latest", columns: ["日付", "商品", "金額"], top: 3, size: "l" };
  const table = only(widget, { filters: { period: "all" } });
  assert.deepEqual(table.head, [
    { label: "日付", numeric: false },
    { label: "商品", numeric: false },
    { label: "金額", numeric: true },
  ]);
  assert.deepEqual(
    table.rows.map((cells) => cells.map((cell) => cell.text)),
    [
      ["2026-09-19", "詰め合わせ", "2,500"],
      ["2026-09-14", "深煎り", "—"],
      ["2026-09-13", "ミル", "4,000"],
    ]
  );
});

test("table: 期間に行が無いときは、誤りではなく空にする", () => {
  const period = { filters: { period: "custom", from: "2026-07-01", to: "2026-07-31" } };
  const grouped = only(TABLE, period);
  assert.equal(grouped.empty, true);
  assert.deepEqual(grouped.rows, []);
  assert.deepEqual(grouped.csv, [["商品", "数量", "売上"]]);
  assert.deepEqual(grouped.table.rows, []);

  const latest = only({ type: "table", title: "新しい明細", dataset: "sales", rows: "latest", columns: ["日付", "商品"], top: 3, size: "l" }, period);
  assert.equal(latest.empty, true);
  assert.deepEqual(latest.rows, []);
  assert.deepEqual(latest.csv, [["日付", "商品"]]);
});

// ---- 速さ -----------------------------------------------------------------

test("buildDashboard: 20,000 行・10 部品でも十分に速い", () => {
  const channels = ["EC", "店舗", "電話"];
  const categories = ["コーヒー豆", "ドリップバッグ", "菓子", "器具", "ギフト", "季節限定", ""];
  const columns = SALES_COLUMNS;
  const rows = [];
  for (let i = 0; i < 20000; i += 1) {
    const day = (i % 28) + 1;
    const month = i % 2 === 0 ? "08" : "09";
    rows.push({
      日付: "2026-" + month + "-" + (day < 10 ? "0" + day : String(day)),
      チャネル: channels[i % 3],
      カテゴリ: categories[i % 7],
      商品: "商品" + (i % 40),
      数量: (i % 5) + 1,
      金額: i % 11 === 0 ? null : (i % 9) * 500,
    });
  }
  const datasets = makeDatasets({ sales: { columns, rows, types: SALES_TYPES, truncated: true } });
  const widgets = [
    KPI,
    Object.assign({}, KPI, { title: "件数", agg: "count", value: undefined, format: "number" }),
    LINE,
    Object.assign({}, LINE, { title: "商品別の推移", splitBy: "商品" }),
    BAR,
    Object.assign({}, BAR, { title: "チャネル別", category: "チャネル", splitBy: "商品" }),
    METER,
    TABLE,
    Object.assign({}, TABLE, { title: "カテゴリ別", groupBy: "カテゴリ", top: 20 }),
    { type: "table", title: "新しい明細", dataset: "sales", rows: "latest", columns: ["日付", "商品", "金額"], top: 20, size: "l" },
  ];
  const startedAt = performance.now();
  const dashboard = build(widgets, { datasets });
  const elapsed = performance.now() - startedAt;
  assert.equal(dashboard.widgets.length, 10);
  assert.equal(
    dashboard.widgets.every((widget) => widget.type !== "error"),
    true
  );
  assert.deepEqual(dashboard.notes, ["20,000 行までを表示しています"]);
  assert.ok(elapsed < 1500, "組み立てに " + Math.round(elapsed) + "ms かかりました");
});

// ---- 値がすべて同じ折れ線（コード審査 C1） ----------------------------------

const FLAT_COLUMNS = ["日付", "金額"];
const FLAT_TYPES = { 日付: "date", 金額: "number" };

/** 同じ値だけを並べたデータセットを作る */
function flatDataset_(dates, value) {
  return {
    columns: FLAT_COLUMNS,
    rows: dates.map((date) => ({ 日付: date, 金額: value })),
    types: FLAT_TYPES,
    truncated: false,
  };
}

const FLAT_LINE = { type: "line", title: "売上の推移", dataset: "flat", value: "金額", agg: "sum", bucket: "auto", format: "yen", size: "l" };

/** flat データセットだけを使う 1 部品の model */
function flatLine_(dataset, filters) {
  return only(FLAT_LINE, {
    datasets: Object.assign(makeDatasets(), { flat: dataset }),
    config: { datasets: { flat: { url: "./flat.csv", dateColumn: "日付" } } },
    filters,
  });
}

test("折れ線: 値がすべて同じ（0 でない）ときも、0 から値までの目盛りを作る", () => {
  // 月の 1 日に「今月」で開いたとき（刻みは 1 個、値は 1 つだけ）
  const model = flatLine_(flatDataset_(["2026-09-01", "2026-09-01"], 100000), { period: "custom", from: "2026-09-01", to: "2026-09-01" });

  assert.equal(model.empty, false);
  assert.equal(model.buckets.length, 1, "刻みは 1 個");
  assert.deepEqual(model.series[0].values, [200000]);
  assert.deepEqual(model.ticks, [0, 50000, 100000, 150000, 200000], "[0, 1] にしない");
  assert.equal(model.yMax, 200000);
});

test("折れ線: 同じ値が何個並んでも、線が図の外に出る目盛りにならない", () => {
  const dates = [];
  for (let i = 0; i < 200; i += 1) dates.push("2026-09-" + String((i % 19) + 1).padStart(2, "0"));
  const model = flatLine_(flatDataset_(dates, 500), { period: "custom", from: "2026-09-01", to: "2026-09-19" });

  const top = model.ticks[model.ticks.length - 1];
  for (const value of model.series[0].values) {
    if (value === null) continue;
    assert.ok(value <= top, "値 " + value + " が上端 " + top + " を超えている");
    assert.ok(value >= model.ticks[0], "値 " + value + " が下端 " + model.ticks[0] + " を下回っている");
  }
  assert.notDeepEqual(model.ticks, [0, 1]);
});

test("折れ線: 値がすべて同じ負の数でも、線が収まる目盛りになる", () => {
  const model = flatLine_(flatDataset_(["2026-09-01", "2026-09-02"], -500), { period: "custom", from: "2026-09-01", to: "2026-09-02" });
  assert.ok(model.ticks[0] <= -500, "下端 " + model.ticks[0]);
  assert.equal(model.yMax, 0);
  assert.notDeepEqual(model.ticks, [0, 1]);
});

test("折れ線: 値がすべて 0 のときは 0〜1 の目盛りのまま（線は 0 の高さに引く）", () => {
  const model = flatLine_(flatDataset_(["2026-09-01"], 0), { period: "custom", from: "2026-09-01", to: "2026-09-01" });
  assert.deepEqual(model.ticks, [0, 1]);
  assert.deepEqual(model.series[0].values, [0]);
});

test("棒・目標・KPI の小さな折れ線には、同じ穴が無い", () => {
  const flat = flatDataset_(["2026-09-01", "2026-09-02"], 100000);
  const datasets = Object.assign(makeDatasets(), { flat });
  const config = { datasets: { flat: { url: "./flat.csv", dateColumn: "日付" } } };
  const filters = { period: "custom", from: "2026-09-01", to: "2026-09-02" };

  const bar = only({ type: "bar", title: "日別", dataset: "flat", category: "日付", value: "金額", agg: "sum", format: "yen", size: "m" }, { datasets, config, filters });
  const top = bar.ticks[bar.ticks.length - 1];
  assert.ok(top >= 100000, "棒の上端 " + top + " が、いちばん高い棒 100000 を覆っている");

  const meter = only(
    { type: "meter", title: "目標", dataset: "flat", value: "金額", agg: "sum", target: 400000, format: "yen", size: "m" },
    { datasets, config, filters }
  );
  assert.equal(meter.type, "meter");
  assert.equal(meter.ratio, 0.5);

  const kpi = only({ type: "kpi", title: "売上", dataset: "flat", value: "金額", agg: "sum", format: "yen", size: "s", sparkline: true }, { datasets, config, filters });
  assert.equal(kpi.spark.min, kpi.spark.max, "小さな折れ線は、平らでも min と max をそのまま持つ（描く側が広げる）");
});

// ---- 刻みの数の上限（コード審査 I3） ----------------------------------------

test("折れ線: 年を打ち間違えた行が混ざると、新しいほうから 400 個に収めて知らせを添える", () => {
  const dataset = {
    columns: FLAT_COLUMNS,
    rows: [
      { 日付: "2026-09-01", 金額: 1000 },
      { 日付: "2026-09-02", 金額: 2000 },
      { 日付: "9999-12-31", 金額: 3000 },
    ],
    types: FLAT_TYPES,
    truncated: false,
  };
  const model = flatLine_(dataset, { period: "all", from: "", to: "" });

  assert.ok(model.buckets.length <= 400, "刻みは " + model.buckets.length + " 個");
  assert.equal(model.limitNote, "期間が長いため、新しいほうから 400 個の区切りだけを表示しています");
});

test("折れ線: 刻みが上限に収まるときは、知らせを添えない", () => {
  assert.equal(only(LINE).limitNote, "");
});

// ---- 目標の月（文書審査 C3） ------------------------------------------------

test("目標: 期間の終わりが決まっていないときは、データの最新の日付の月で探す", () => {
  // today は 2026-09-19 だが、データは 8 月で終わっている。「全期間」では 8 月の目標を使う
  const august = {
    columns: SALES_COLUMNS,
    rows: SALES_ROWS.filter((row) => String(row["日付"]).startsWith("2026-08")),
    types: SALES_TYPES,
    truncated: false,
  };
  const model = only(METER, { datasets: makeDatasets({ sales: august }), filters: { period: "all", from: "", to: "" } });

  assert.equal(model.type, "meter", "誤りの札にならない: " + model.message);
  assert.equal(model.targetFull, "¥40,000", "8 月の目標を使うはず");
});

test("目標: 期間の終わりが決まっていれば、これまでどおりその月で探す", () => {
  const model = only(METER, { filters: { period: "thisMonth", from: "", to: "" } });
  assert.equal(model.targetFull, "¥50,000");
});

test("目標: データに日付の列が無いときは、today の月で探す", () => {
  const noDate = only(
    { type: "meter", title: "目標", dataset: "items", value: "金額", agg: "sum", target: { dataset: "targets", value: "目標額", matchMonth: "月" }, format: "yen", size: "m" },
    { filters: { period: "all", from: "", to: "" } }
  );
  assert.equal(noDate.targetFull, "¥50,000", "today（2026-09-19）の月を使うはず");
  assert.equal(noDate.valueFull, "¥1,900", "月で絞りようがないので、絞り込んだ行すべての合計");
  assert.equal(noDate.monthLabel, "", "月で絞っていないので、月は出さない");
});

// ---- 月の目標は、その月の数字と比べる ---------------------------------------

test("meter: 全期間でも、月の目標はその月の実績とだけ比べる", () => {
  const meter = only(SPAN_METER, { filters: { period: "all", from: "", to: "" } });
  assert.equal(meter.type, "meter", "誤りの札にならない: " + meter.message);
  assert.equal(meter.valueFull, "¥35,000", "9 月の 3 行（20,000 + 10,000 + 5,000）だけを合計するはず");
  assert.equal(meter.targetFull, "¥50,000");
  assert.equal(Math.round(meter.ratio * 1000), 700);
  assert.equal(meter.ratioText, "70%");
  assert.equal(meter.achieved, false);
  assert.equal(meter.monthLabel, "2026年9月");
  assert.deepEqual(meter.table.rows, [
    ["対象の月", "2026年9月"],
    ["実績", "¥35,000"],
    ["目標", "¥50,000"],
    ["達成率", "70%"],
  ]);
});

test("meter: 直近 90 日では、終わりの月のうち期間に入る行だけを合計する", () => {
  // 期間は 2026-06-22〜2026-09-19。9 月の 3 行のうち、25 日の 1 行は期間の外
  const meter = only(SPAN_METER, { filters: { period: "last90", from: "", to: "" } });
  assert.equal(meter.type, "meter", "誤りの札にならない: " + meter.message);
  assert.equal(meter.valueFull, "¥30,000", "9 月のうち期間に入る 2 行（20,000 + 10,000）だけを合計するはず");
  assert.equal(meter.ratioText, "60%");
  assert.equal(meter.monthLabel, "2026年9月");
});

test("meter: 期間がひと月の中に収まっているときは、これまでと同じ合計になる", () => {
  const meter = only(METER, { filters: { period: "custom", from: "2026-09-01", to: "2026-09-10" } });
  assert.equal(meter.type, "meter", "誤りの札にならない: " + meter.message);
  assert.equal(meter.valueFull, "¥25,500", "9/1〜9/10 の 10 行の合計");
  assert.equal(meter.targetFull, "¥50,000");
  assert.equal(meter.ratioText, "51%");
  assert.equal(meter.monthLabel, "2026年9月");
});

test("meter: 目標が数のときは、全期間でも期間ぜんたいを合計する", () => {
  const meter = only(Object.assign({}, METER, { target: 100000 }), { filters: { period: "all", from: "", to: "" } });
  assert.equal(meter.valueFull, "¥67,700", "8 月と 9 月の合計（月では絞らない）");
  assert.equal(Math.round(meter.ratio * 1000), 677);
  assert.equal(meter.monthLabel, "");
});

test("meter: 月で絞ったあとも、区分の絞り込みは効く", () => {
  const meter = only(SPAN_METER, { filters: { period: "all", from: "", to: "", dimensions: { チャネル: "店舗" } } });
  assert.equal(meter.valueFull, "¥10,000", "9 月の店舗の 1 行だけ");
  assert.equal(meter.ratioText, "20%");
  assert.equal(meter.monthLabel, "2026年9月");
});

test("meter: その月に実績が 1 行も無いときは、0 として進みを出す", () => {
  const targets = { columns: TARGET_COLUMNS, rows: toRows_(TARGET_COLUMNS, [["2026-10", 50000]]), types: TARGET_TYPES, truncated: false };
  const meter = only(METER, {
    datasets: makeDatasets({ targets }),
    filters: { period: "custom", from: "2026-10-01", to: "2026-10-31" },
  });
  assert.equal(meter.type, "meter", "誤りの札にならない: " + meter.message);
  assert.equal(meter.valueFull, "¥0");
  assert.equal(meter.ratioText, "0%");
  assert.equal(meter.monthLabel, "2026年10月");
});

// ---- 並べ替えの比べ方をそろえる（コード審査 M13） ---------------------------

test("表: 並べ替えは core の compareCells だけを使う（model.js に自前の比べ方を持たない）", () => {
  const source = readFileSync(new URL("../src/core/model.js", import.meta.url), "utf8");
  assert.ok(source.includes("compareCells(a[at].value, b[at].value, order)"), "compareCells で比べるはず");
  assert.equal(/const sign = order === "asc"/.test(source), false, "自前の比べ方を残さない");
});

test("表: 読めない値が混ざっても、並べ替えたあとも行数は変わらない（空はいつも最後）", () => {
  const rows = toRows_(["商品", "金額"], [["A", 300], ["B", null], ["C", 200]]);
  const dataset = { columns: ["商品", "金額"], rows, types: { 商品: "text", 金額: "number" }, truncated: false };
  const widget = {
    type: "table",
    title: "商品別",
    dataset: "gappy",
    groupBy: "商品",
    columns: [{ value: "金額", agg: "sum", label: "金額" }],
    sort: "金額",
    order: "desc",
    size: "l",
  };
  const model = only(widget, {
    datasets: Object.assign(makeDatasets(), { gappy: dataset }),
    config: { datasets: { gappy: { url: "./gappy.csv" } } },
  });
  assert.deepEqual(model.rows.map((cells) => cells[0].text), ["A", "C", "B"], "合計が 0 の B は最後");
});
