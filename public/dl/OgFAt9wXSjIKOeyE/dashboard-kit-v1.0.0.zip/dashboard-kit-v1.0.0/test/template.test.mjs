import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { parseConfig } from "../src/core/config.js";
import { FORBIDDEN_WORDS, INTERNAL_PATHS, hasRawControlChar } from "./helpers/forbidden.mjs";

const ROOT_ = join(dirname(fileURLToPath(import.meta.url)), "..");
const TEMPLATE_ROOT_ = join(ROOT_, "templates", "nextjs");

function readTemplateFile_(relPath) {
  return readFileSync(join(TEMPLATE_ROOT_, relPath), "utf8");
}

// ---- ファイルがそろっていること ---------------------------------------------

const EXPECTED_FILES_ = [
  "package.json",
  "next.config.mjs",
  "tsconfig.json",
  ".gitignore",
  ".env.example",
  "app/layout.tsx",
  "app/page.tsx",
  "app/DashboardClient.tsx",
  "app/api/dashboard/data/route.ts",
  "dashboard.config.json",
  "public/sample/sales.csv",
  "public/sample/targets.csv",
  "lib/csv.mjs",
  "lib/csv.d.mts",
  "lib/read-limited.mjs",
  "lib/read-limited.d.mts",
  "lib/safe-fetch.mjs",
  "lib/safe-fetch.d.mts",
  "README.md",
  "vendor/dashboard.mjs",
  "vendor/dashboard.css",
];

for (const relPath of EXPECTED_FILES_) {
  test("templates/nextjs: " + relPath + " が存在する", () => {
    assert.ok(existsSync(join(TEMPLATE_ROOT_, relPath)), relPath + " が無い（npm run build を実行しましたか）");
  });
}

// ---- package.json の依存 -----------------------------------------------------

test("templates/nextjs/package.json: dependencies は next・react・react-dom だけ", () => {
  const pkg = JSON.parse(readTemplateFile_("package.json"));
  assert.deepEqual(Object.keys(pkg.dependencies).sort(), ["next", "react", "react-dom"]);
  assert.equal(pkg.private, true);
  assert.equal(pkg.scripts.dev, "next dev");
  assert.equal(pkg.scripts.build, "next build");
  assert.equal(pkg.scripts.start, "next start");
});

test("templates/nextjs/package.json: devDependencies は typescript・@types/* だけ", () => {
  const pkg = JSON.parse(readTemplateFile_("package.json"));
  for (const name of Object.keys(pkg.devDependencies || {})) {
    assert.ok(name === "typescript" || name.startsWith("@types/"), name + " は devDependencies に置けない");
  }
});

// ---- Route Handler: リクエストから URL を受け取らない ------------------------

test("route.ts: fetch( は 1 回だけ書かれていて、その引数は検査済みの hop URL", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  const calls = source.match(/\bfetch\(/g) || [];
  assert.equal(calls.length, 1, "fetch( の呼び出しは 1 回だけのはず");
  assert.match(source, /fetch\(\s*url\s*,/, "fetch の第一引数は url（nextHop で検査済みの hop URL）のはず");
  // dataset・request・searchParams（リクエストの生の値）を fetch の呼び出しに直接混ぜていないこと
  assert.doesNotMatch(source, /fetch\([^)]*\brequest\b/);
  assert.doesNotMatch(source, /fetch\([^)]*\bsearchParams\b/);
  assert.doesNotMatch(source, /fetch\([^)]*\bdataset\b/);
});

test("route.ts: url は startUrl から始まり、nextHop() の戻り値でしか書き換わらない", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.match(source, /let\s+url\s*=\s*startUrl\s*;/, "url の初期値が startUrl になっていない");
  const assignments = source.match(/(?<!let\s)\burl\s*=\s*[^;]+;/g) || [];
  assert.ok(assignments.length >= 1, "url への再代入が見つからない");
  for (const line of assignments) {
    assert.match(line, /hopUrl/, "url への再代入は nextHop の戻り値（hopUrl）からのみのはず: " + line);
  }
});

test("route.ts: redirect は manual で受け、自動ではたどらない", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes('redirect: "manual"'), 'redirect: "manual" が見つからない');
});

test("route.ts: 上流の fetch に AbortSignal.timeout を付ける", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.match(source, /AbortSignal\.timeout\(\s*UPSTREAM_TIMEOUT_MS\s*\)/);
});

test("route.ts: lib/read-limited.mjs の readLimited を使い、arrayBuffer() は使わない", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes('from "../../../../lib/read-limited.mjs"'));
  assert.ok(source.includes("readLimited("));
  assert.doesNotMatch(source, /\.arrayBuffer\(\)/);
});

test("route.ts: lib/safe-fetch.mjs の nextHop で転送先を検査する", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes('from "../../../../lib/safe-fetch.mjs"'));
  assert.ok(source.includes("nextHop("));
});

test("route.ts: 転送をたどる回数の上限がある", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.match(source, /MAX_REDIRECT_HOPS\s*=\s*3/);
});

test("route.ts: content-length が上限を超えていれば、読み始める前に断る", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes('headers.get("content-length")'));
});

test("route.ts: GET だけを出す", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.match(source, /export\s+async\s+function\s+GET\s*\(/);
  for (const method of ["POST", "PUT", "PATCH", "DELETE"]) {
    assert.doesNotMatch(source, new RegExp("export\\s+(async\\s+)?function\\s+" + method + "\\s*\\("));
  }
});

test("route.ts: dataset 名は文書化した正規表現で検査する（ハイフンは使えない）", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes("^[a-z0-9_]{1,40}$"), "dataset 名の正規表現が見つからない");
  assert.ok(!source.includes("^[a-z0-9_-]{1,40}$"), "ハイフンを許す古い正規表現が残っている");
});

test("route.ts: 環境変数の URL が https 以外なら断る", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes('startsWith("https://")'), "https だけを許す検査が見つからない");
});

test("route.ts: dynamic = \"force-dynamic\" は設定しない", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.doesNotMatch(source, /dynamic\s*=\s*["']force-dynamic["']/);
});

test("route.ts: revalidate は DASHBOARD_REVALIDATE から作る", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes("Number(process.env.DASHBOARD_REVALIDATE ?? 300)"));
});

test("route.ts: 応答に Cache-Control: private, max-age=60 を付ける", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  const matches = source.match(/Cache-Control["']?\s*:\s*["']private, max-age=60["']/g) || [];
  assert.ok(matches.length >= 2, "成功時・誤り時の両方に付いているはず");
});

test("route.ts: 誤りの応答に、上流の文字（本文・理由）を混ぜない", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  // 誤りの応答は 1 つの固定文だけを使い、upstream や envUrl の中身を差し込まない
  assert.doesNotMatch(source, /jsonError\([^)]*envUrl/);
  assert.doesNotMatch(source, /jsonError\([^)]*upstream\.(?:text|statusText)/);
  assert.doesNotMatch(source, /catch\s*\(\s*\w*(?:error|err|e)\w*\s*\)\s*{[^}]*\.message/is);
});

test("route.ts: 環境変数が無いときは同梱の見本 CSV を返す仕組みがある", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes("public") && source.includes("sample"));
});

// ---- DashboardClient.tsx ----------------------------------------------------

test('DashboardClient.tsx: 先頭が "use client" で始まる', () => {
  const source = readTemplateFile_("app/DashboardClient.tsx");
  assert.ok(source.trimStart().startsWith('"use client"'), "先頭が \"use client\" ではない");
});

test("DashboardClient.tsx: useEffect の後片づけで destroy() を呼ぶ", () => {
  const source = readTemplateFile_("app/DashboardClient.tsx");
  assert.ok(source.includes("useEffect"));
  const cleanupMatch = source.match(/return\s*\(\)\s*=>\s*{[\s\S]*?};/);
  assert.ok(cleanupMatch, "後片づけの関数（return () => { ... }）が見つからない");
  assert.ok(cleanupMatch[0].includes(".destroy()"), "後片づけの中で destroy() を呼んでいない");
});

test("DashboardClient.tsx: vendor/dashboard.mjs を動的 import する", () => {
  const source = readTemplateFile_("app/DashboardClient.tsx");
  assert.ok(source.includes('import("../vendor/dashboard.mjs")'));
});

test("DashboardClient.tsx: 自分の API を呼ぶ fetch は cache: no-store", () => {
  const source = readTemplateFile_("app/DashboardClient.tsx");
  const fetchLine = source.split("\n").find((line) => line.includes('fetch("/api/dashboard/data?dataset='));
  assert.ok(fetchLine, "自分の API を呼ぶ fetch( が見つからない");
  assert.match(fetchLine, /\{\s*cache:\s*"no-store"\s*\}/);
});

test("DashboardClient.tsx: cancelled のガードが動的 import 直後と mountDashboard 呼び出し直後の両方にある", () => {
  const source = readTemplateFile_("app/DashboardClient.tsx");
  const effectMatch = source.match(/useEffect\(\(\) => \{[\s\S]*?\n {2}\}, \[config, datasetNames\]\);/);
  assert.ok(effectMatch, "useEffect の中身が見つからない");
  const body = effectMatch[0];

  const mountCallIndex = body.indexOf("mountDashboard(");
  assert.ok(mountCallIndex !== -1, "mountDashboard の呼び出しが見つからない");

  const beforeMount = body.slice(0, mountCallIndex);
  assert.match(beforeMount, /if\s*\(\s*cancelled/, "動的 import 直後の cancelled チェックが無い");

  const afterMount = body.slice(mountCallIndex);
  assert.match(afterMount, /if\s*\(\s*cancelled\s*\)\s*\{[\s\S]*?\.destroy\(\)/, "mountDashboard() の直後に、cancelled なら destroy() する片づけが無い");
});

// ---- vendor/ の中身が dist と一致すること ------------------------------------

test("vendor/dashboard.mjs は dist/dashboard.mjs と byte 単位で同じ", () => {
  const vendor = readTemplateFile_("vendor/dashboard.mjs");
  const dist = readFileSync(join(ROOT_, "dist", "dashboard.mjs"), "utf8");
  assert.equal(vendor, dist);
});

test("vendor/dashboard.css は dist/dashboard.css と byte 単位で同じ", () => {
  const vendor = readTemplateFile_("vendor/dashboard.css");
  const dist = readFileSync(join(ROOT_, "dist", "dashboard.css"), "utf8");
  assert.equal(vendor, dist);
});

// ---- public/sample の CSV が samples/ja と一致すること -----------------------

test("public/sample/sales.csv は samples/ja/sales.csv と同じ", () => {
  const template = readTemplateFile_("public/sample/sales.csv");
  const sample = readFileSync(join(ROOT_, "samples", "ja", "sales.csv"), "utf8");
  assert.equal(template, sample);
});

test("public/sample/targets.csv は samples/ja/targets.csv と同じ", () => {
  const template = readTemplateFile_("public/sample/targets.csv");
  const sample = readFileSync(join(ROOT_, "samples", "ja", "targets.csv"), "utf8");
  assert.equal(template, sample);
});

// ---- dashboard.config.json が parseConfig を誤りなく通ること -----------------

test("templates/nextjs/dashboard.config.json は parseConfig で誤りが出ない", () => {
  const raw = JSON.parse(readTemplateFile_("dashboard.config.json"));
  const { errors } = parseConfig(raw);
  assert.deepEqual(errors, []);
});

test("templates/nextjs/dashboard.config.json のデータセットの url はどれも相対パス（自分の API 宛て）", () => {
  const raw = JSON.parse(readTemplateFile_("dashboard.config.json"));
  for (const name of Object.keys(raw.datasets)) {
    assert.equal(raw.datasets[name].url, "./api/dashboard/data?dataset=" + name);
  }
});

// ---- lib/csv.mjs（Route Handler が使う CSV パーサ）---------------------------

test("lib/csv.mjs: CRLF・見出し・データ行を行列にする", async () => {
  const { csvToMatrix } = await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "csv.mjs")).href);
  assert.deepEqual(csvToMatrix("a,b\r\n1,2\r\n"), [
    ["a", "b"],
    ["1", "2"],
  ]);
});

test("lib/csv.mjs: 先頭の BOM を外す", async () => {
  const { csvToMatrix } = await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "csv.mjs")).href);
  assert.deepEqual(csvToMatrix("﻿a,b\n1,2\n"), [
    ["a", "b"],
    ["1", "2"],
  ]);
});

test("lib/csv.mjs: 引用符の中のカンマ・改行・二重引用符（\"\"）を読む", async () => {
  const { csvToMatrix } = await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "csv.mjs")).href);
  const text = '"a,b","line1\nline2","she said ""hi"""\n';
  assert.deepEqual(csvToMatrix(text), [["a,b", "line1\nline2", 'she said "hi"']]);
});

test("lib/csv.mjs: 末尾の改行 1 つでは空行を作らない", async () => {
  const { csvToMatrix } = await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "csv.mjs")).href);
  assert.deepEqual(csvToMatrix("a,b\n"), [["a", "b"]]);
});

test("lib/csv.mjs: 空文字は空の配列", async () => {
  const { csvToMatrix } = await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "csv.mjs")).href);
  assert.deepEqual(csvToMatrix(""), []);
});

// ---- lib/read-limited.mjs（Route Handler が使う、上限つきの読み取り）---------

function streamOf_(chunks) {
  return new ReadableStream({
    start(controller) {
      for (const chunk of chunks) controller.enqueue(chunk);
      controller.close();
    },
  });
}

async function importReadLimited_() {
  return (await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "read-limited.mjs")).href)).readLimited;
}

test("lib/read-limited.mjs: 上限未満はそのまま読み切る", async () => {
  const readLimited = await importReadLimited_();
  const result = await readLimited(streamOf_([new Uint8Array([1, 2]), new Uint8Array([3])]), 10);
  assert.deepEqual(Array.from(result), [1, 2, 3]);
});

test("lib/read-limited.mjs: ちょうど上限のバイト数は許す", async () => {
  const readLimited = await importReadLimited_();
  const result = await readLimited(streamOf_([new Uint8Array([1, 2, 3])]), 3);
  assert.deepEqual(Array.from(result), [1, 2, 3]);
});

test("lib/read-limited.mjs: 1 つのチャンクの途中で上限を超えたら null", async () => {
  const readLimited = await importReadLimited_();
  const result = await readLimited(streamOf_([new Uint8Array([1, 2, 3, 4, 5])]), 3);
  assert.equal(result, null);
});

test("lib/read-limited.mjs: 本文が空なら長さ 0 の配列", async () => {
  const readLimited = await importReadLimited_();
  const result = await readLimited(streamOf_([]), 10);
  assert.equal(result.length, 0);
});

test("lib/read-limited.mjs: ストリームが誤りを出したら null", async () => {
  const readLimited = await importReadLimited_();
  const stream = new ReadableStream({
    start(controller) {
      controller.error(new Error("boom"));
    },
  });
  const result = await readLimited(stream, 10);
  assert.equal(result, null);
});

// ---- lib/safe-fetch.mjs（Route Handler が使う、転送先の検査）------------------

async function importNextHop_() {
  return (await import(pathToFileURL(join(TEMPLATE_ROOT_, "lib", "safe-fetch.mjs")).href)).nextHop;
}

test("lib/safe-fetch.mjs: 相対パスの Location は今の URL を基準に https のまま解決する", async () => {
  const nextHop = await importNextHop_();
  assert.equal(nextHop("https://a.example/x", "/final"), "https://a.example/final");
});

test("lib/safe-fetch.mjs: http への格下げは断る", async () => {
  const nextHop = await importNextHop_();
  assert.equal(nextHop("https://a.example/x", "http://b.example/y"), null);
});

test("lib/safe-fetch.mjs: プロトコル相対（//…）は https として解決する", async () => {
  const nextHop = await importNextHop_();
  assert.equal(nextHop("https://a.example/x", "//b.example/y"), "https://b.example/y");
});

test("lib/safe-fetch.mjs: javascript: は断る", async () => {
  const nextHop = await importNextHop_();
  assert.equal(nextHop("https://a.example/x", "javascript:alert(1)"), null);
});

test("lib/safe-fetch.mjs: Location が無ければ断る", async () => {
  const nextHop = await importNextHop_();
  assert.equal(nextHop("https://a.example/x", null), null);
  assert.equal(nextHop("https://a.example/x", undefined), null);
  assert.equal(nextHop("https://a.example/x", ""), null);
});

// ---- 内部の語・絶対パス・制御文字が templates/ に無いこと --------------------

// 公開物に出してはいけない固有名詞・内部の呼び名・作業場所の手がかりは、
// このファイル自身が配布 zip の検査に引っかからないよう、
// test/helpers/forbidden.mjs が文字コードから組み立てたものを使う

/** テンプレの中には、発行者の名前そのものも出さない（内部の道すじと同じ扱いにする） */
const INTERNAL_MARKERS_ = INTERNAL_PATHS.concat([
  String.fromCodePoint(0x73, 0x75, 0x6d, 0x69, 0x6e, 0x61, 0x77, 0x61),
  String.fromCodePoint(0x77, 0x6f, 0x72, 0x6b, 0x74, 0x72, 0x65, 0x65),
]);

function walkFiles_(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    if (name === "node_modules" || name === ".next" || name === ".git") continue;
    const full = join(dir, name);
    const info = statSync(full);
    if (info.isDirectory()) out.push(...walkFiles_(full));
    else out.push(full);
  }
  return out;
}

test("templates/nextjs 配下のどのファイルにも、内部の語・絶対パス・生の制御文字が無い", () => {
  for (const full of walkFiles_(TEMPLATE_ROOT_)) {
    const relPath = relative(TEMPLATE_ROOT_, full);
    const buffer = readFileSync(full);
    // バイナリではなくテキストとして書き出したファイルだけを対象にする（今のところすべて）
    const text = buffer.toString("utf8");

    for (const word of FORBIDDEN_WORDS) {
      assert.equal(text.includes(word), false, relPath + " に禁止語「" + word + "」が含まれています");
    }
    for (const marker of INTERNAL_MARKERS_) {
      assert.equal(text.includes(marker), false, relPath + " に内部の語「" + marker + "」が含まれています");
    }
    assert.equal(hasRawControlChar(text), false, relPath + " に生の制御文字が含まれています");
  }
});

// ---- tsconfig.json（Next が最初のビルドで書き直す最終形にそろえてある）--------

test("tsconfig.json: allowJs・resolveJsonModule・.next/types を含む最終形にしてある", () => {
  const tsconfig = JSON.parse(readTemplateFile_("tsconfig.json"));
  assert.equal(tsconfig.compilerOptions.allowJs, true);
  assert.equal(tsconfig.compilerOptions.resolveJsonModule, true);
  assert.ok(tsconfig.include.includes(".next/types/**/*.ts"), ".next/types/**/*.ts が include に無い");
});

// ---- next.config.mjs（outputFileTracingIncludes）------------------------------

test("next.config.mjs: outputFileTracingIncludes に \"/\" と \"/api/dashboard/data\" を明示している", () => {
  const source = readTemplateFile_("next.config.mjs");
  assert.match(source, /["']\/["']\s*:\s*\[/, '"/" のキーが見つからない');
  assert.match(source, /["']\/api\/dashboard\/data["']\s*:\s*\[/, '"/api/dashboard/data" のキーが見つからない');
});

// ---- README ------------------------------------------------------------------

test("README.md: 日本語のあとに英語が続く 1 ファイルで、両方に主要な案内がある", () => {
  const readme = readTemplateFile_("README.md");
  const jaIndex = readme.indexOf("ダッシュボード キット");
  const enIndex = readme.indexOf("Dashboard Kit");
  assert.ok(jaIndex !== -1 && enIndex !== -1 && jaIndex < enIndex, "日本語が先、英語があとの構成になっていない");
  assert.ok(readme.includes("ウェブに公開"), "スプレッドシートの公開手順が書かれていない");
  assert.ok(readme.includes("ログイン"), "ログインが無いことの注意が書かれていない");
  assert.ok(readme.includes("Vercel"));
});

// ---- 本番で見本に落ちない（文書審査 C5） ------------------------------------

test("route.ts: 見本への切り替えは、本番以外か DASHBOARD_SAMPLE=1 のときだけ", () => {
  const source = readTemplateFile_("app/api/dashboard/data/route.ts");
  assert.ok(source.includes('process.env.NODE_ENV !== "production"'), "本番かどうかを見る");
  assert.ok(source.includes('process.env.DASHBOARD_SAMPLE === "1"'), "DASHBOARD_SAMPLE で開けられる");
  assert.ok(source.includes("sampleAllowed() ? sampleTextFor(dataset) : null"), "許されないときは見本を読まない");
  // 見本が使えないときは 404（設定の誤りの中身は外に出さない）
  assert.ok(source.includes("if (sample === null) return new Response(null, { status: 404 });"));
});

test(".env.example に、テンプレが読む環境変数がすべて並んでいる", () => {
  const example = readTemplateFile_(".env.example");
  const names = new Set();
  for (const relPath of ["app/api/dashboard/data/route.ts", "app/layout.tsx", "app/page.tsx", "app/DashboardClient.tsx"]) {
    for (const found of readTemplateFile_(relPath).matchAll(/process\.env\.([A-Z][A-Z0-9_]*)/g)) names.add(found[1]);
  }
  // NODE_ENV は Next.js が入れるもので、買い手が書く変数ではない
  names.delete("NODE_ENV");
  assert.ok(names.size >= 3, "読んでいる環境変数が " + names.size + " 個しか見つかりません");
  for (const name of names) {
    assert.ok(example.includes(name), ".env.example に " + name + " の説明がありません");
  }
  // データセットごとの変数は名前が決まらないので、作り方が書いてあることを確かめる
  assert.ok(readTemplateFile_("app/api/dashboard/data/route.ts").includes('"DASHBOARD_DATA_" + name.toUpperCase()'));
  assert.ok(example.includes("DASHBOARD_DATA_SALES"), ".env.example に作り方の例がありません");
});

test("テンプレの README に、DASHBOARD_SAMPLE と見本の見分け方が日本語・英語の両方で書いてある", () => {
  const readme = readTemplateFile_("README.md");
  assert.equal((readme.match(/DASHBOARD_SAMPLE/g) || []).length >= 2, true, "日本語と英語の両方に書く");
  assert.ok(readme.includes("しおかぜブレンド"), "見本と見分ける手がかりを書く");
  assert.ok(readme.includes("Shiokaze Blend"), "英語にも見分ける手がかりを書く");
});

test("テンプレの設定は、固定の日付の見本に合わせて「全期間」になっている", () => {
  const config = JSON.parse(readTemplateFile_("dashboard.config.json"));
  assert.equal(config.filters.period, "all");
});
