/**
 * スプレッドシートの読み書き。
 * ダッシュボードはデータのシートを読むだけで、書き込むのは `設定`・`定義` と、
 * メニューから「見本を入れる」を選んだときの見本のシートだけ。
 */

import { textOf } from "../core/text.js";

/** 設定のシートの名前（項目・値の 2 列） */
export const GAS_SETTINGS_SHEET_ = "設定";
/** 定義のシートの名前（1 行 1 部品） */
export const GAS_DEFINITION_SHEET_ = "定義";
/** 1 つのシートから画面に渡す行数の上限（見出しの行は数えない） */
export const GAS_ROW_LIMIT_ = 20000;

function gasBook_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

/** その名前のシート。無ければ null */
export function gasSheetByName_(name) {
  return gasBook_().getSheetByName(textOf(name));
}

/**
 * 書き出すときの時計の置きどころ。マスに表示形式を効かせているのはスプレッドシート本体の時間帯なので、
 * まずそちらを読む（`appsscript.json` の `timeZone` はスクリプトの実行そのものの時間帯で、
 * 別の時間帯のスプレッドシートに使うと日付が 1 日ずれることがある）。
 * 読めない・空のときだけ、スクリプトの時間帯に落とし、それも読めなければ日本の標準時にする
 */
function gasTimeZone_() {
  try {
    const zone = gasBook_().getSpreadsheetTimeZone();
    if (zone) return zone;
  } catch (error) {
    // 下の既定へ
  }
  try {
    return Session.getScriptTimeZone() || "Asia/Tokyo";
  } catch (error) {
    return "Asia/Tokyo";
  }
}

/** 行がすべて空か（空のシートの getDataRange() は 1 行 1 列の空を返すため） */
function gasRowIsBlank_(row) {
  for (let i = 0; i < row.length; i += 1) {
    if (textOf(row[i]) !== "") return false;
  }
  return true;
}

/**
 * シート 1 枚を行列で読む。1 行目（見出し）まで空なら、中身の無いシートとして空の行列にする
 * （空のシートでも 1 行 1 列の空が返るので、そのままだと見出しが 1 つあるように見えてしまう）
 */
function gasValuesOf_(sheet) {
  const values = sheet.getDataRange().getValues();
  if (values.length === 0 || gasRowIsBlank_(values[0])) return [];
  return values;
}

/** `設定`・`定義` のような、見出しつきの小さなシートを読む。シートが無ければ空の行列 */
export function gasReadConfigSheet_(name) {
  const sheet = gasSheetByName_(name);
  return sheet === null ? [] : gasValuesOf_(sheet);
}

/**
 * 1 つのマスを、画面へ渡せる形にそろえる。
 * 画面へ値を渡す仕組みは日付そのもの（Date）を運べないので、暦の日付の文字にしてから渡す。
 * 時刻だけを入れたマスは、スプレッドシートの中では 1899-12-30 の Date になり、
 * 日付にしても意味が無いので、代わりに時刻（HH:mm）の文字にする。
 * 数・真偽・文字はそのまま、それ以外（それ以外の日時の値など）は文字にする
 */
export function gasCellForTransport_(value, timeZone) {
  if (value instanceof Date) {
    const year = Number(Utilities.formatDate(value, timeZone, "yyyy"));
    return year < 1900 ? Utilities.formatDate(value, timeZone, "HH:mm") : Utilities.formatDate(value, timeZone, "yyyy-MM-dd");
  }
  const kind = typeof value;
  if (kind === "number" || kind === "boolean" || kind === "string") return value;
  if (value === null || value === undefined) return "";
  return String(value);
}

/**
 * データのシートを 1 枚読む。シートが無ければ null、中身の無いシートは見出しも行も無い行列。
 *
 * 画面が描くのは上限の行数までなので、ここでは上限より 1 行だけ多く渡す。
 * 画面はその 1 行を切り落としたときに「20,000 行までを表示しています」を出せる。
 * 空の行は画面でも数に入らないので、ここで落としておく（行数の見立てを画面とそろえるため）
 */
export function gasReadDataset_(name) {
  const sheet = gasSheetByName_(name);
  if (sheet === null) return null;

  const values = gasValuesOf_(sheet);
  const timeZone = gasTimeZone_();
  const carry = (row) => {
    const out = [];
    for (let c = 0; c < row.length; c += 1) out.push(gasCellForTransport_(row[c], timeZone));
    return out;
  };

  if (values.length === 0) return { rows: [], truncated: false };

  const rows = [carry(values[0])];
  for (let r = 1; r < values.length; r += 1) {
    if (rows.length > GAS_ROW_LIMIT_ + 1) break;
    if (gasRowIsBlank_(values[r])) continue;
    rows.push(carry(values[r]));
  }
  return { rows: rows, truncated: rows.length - 1 > GAS_ROW_LIMIT_ };
}

/**
 * そのシートに、見出しより下に「客が入れた値」があるか（シートが無ければ無いものとする）。
 *
 * `設定` は初期化のときに、書き方の説明を 3 列目に添えたひな型を書き込むので、
 * getLastRow() だけで見ると、客が何も書いていなくても「行がある」ことになってしまう。
 * `設定` は 値（B 列）に何か入っているかだけで判断し、それ以外のシート（`定義` やデータのシート）は
 * 見出しより下のどこかのマスに値が入っているかで判断する
 */
export function gasHasDataRows_(name) {
  const sheet = gasSheetByName_(name);
  if (sheet === null) return false;
  const values = gasValuesOf_(sheet);
  if (values.length <= 1) return false;

  if (name === GAS_SETTINGS_SHEET_) {
    for (let r = 1; r < values.length; r += 1) {
      if (textOf(values[r][1]) !== "") return true;
    }
    return false;
  }
  for (let r = 1; r < values.length; r += 1) {
    if (!gasRowIsBlank_(values[r])) return true;
  }
  return false;
}

/** そのシート。無ければ作る */
export function gasEnsureSheet_(name) {
  const sheet = gasSheetByName_(name);
  return sheet === null ? gasBook_().insertSheet(textOf(name)) : sheet;
}

/**
 * シートの中身を丸ごと書き換える（見出しの行は固定する）。
 * clear() は値といっしょに書式（列幅・色など）まで消してしまうので、値だけを消す clearContents() を使う
 */
export function gasWriteSheet_(name, grid) {
  const sheet = gasEnsureSheet_(name);
  sheet.clearContents();
  if (grid.length === 0) return sheet;
  const width = grid.reduce((most, row) => Math.max(most, row.length), 0);
  const padded = grid.map((row) => {
    const line = row.slice();
    while (line.length < width) line.push("");
    return line;
  });
  sheet.getRange(1, 1, padded.length, width).setValues(padded);
  sheet.setFrozenRows(1);
  return sheet;
}

/** そのシートの見出し（1 行目）の文字。シートが無い・空のときは空の並び */
export function gasHeaderOf_(name) {
  const sheet = gasSheetByName_(name);
  if (sheet === null) return [];
  const values = gasValuesOf_(sheet);
  return values.length === 0 ? [] : values[0].map(textOf);
}
