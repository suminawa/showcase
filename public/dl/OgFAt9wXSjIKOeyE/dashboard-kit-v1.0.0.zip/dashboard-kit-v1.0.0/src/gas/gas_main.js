/**
 * スプレッドシートのメニュー「ダッシュボード」。ウェブアプリの入口は gas_web.js。
 * ここから書き込むのは `設定`・`定義` と、見本を入れるときのシートだけで、
 * ふだんのデータのシートには書き込まない。
 */

import { textOf } from "../core/text.js";
import { toDateKey } from "../core/dates.js";
import { CONFIG_DEFINITION_COLUMNS_, configFromSheets, configSheetNotes, parseConfig } from "../core/config.js";
import { sampleSheets } from "../core/samples.js";
import { GAS_DEFINITION_SHEET_, GAS_SETTINGS_SHEET_, gasHasDataRows_, gasHeaderOf_, gasReadConfigSheet_, gasSheetByName_, gasWriteSheet_ } from "./gas_sheets.js";

/** メニューの名前 */
const GAS_MENU_TITLE_ = "ダッシュボード";
/** 設定の誤りの文の前置き（画面に出す文と同じにそろえる） */
const GAS_ERROR_PREFIX_ = "dashboard: ";
/** 公開の手順（まだ公開されていないときにお見せする） */
const GAS_DEPLOY_STEPS_ =
  "まだ公開されていません。「拡張機能」→「Apps Script」を開き、右上の「デプロイ」→「新しいデプロイ」と進んで、\n" +
  "・種類: ウェブアプリ\n" +
  "・次のユーザーとして実行: ウェブアプリにアクセスしているユーザー\n" +
  "・アクセスできるユーザー: Google アカウントを持つ全員\n" +
  "を選んで公開してから、もう一度お試しください。";

/**
 * `設定` シートを作るときの中身。値は空のまま、3 列目に書き方をそえておく
 * （はじめて開いた方が、何をどう書けばよいかをシートの上だけで分かるようにするため）
 */
const GAS_SETTINGS_TEMPLATE_ = [
  ["項目", "値", "書き方"],
  ["題名", "", "画面の上に出す題名です。例: しおかぜ珈琲店 売上ダッシュボード"],
  ["言語", "", "日本語 または 英語。空欄のときは 日本語 になります"],
  ["テーマ", "", "自動 / 明るい / 暗い。空欄のときは 自動 になります"],
  ["期間", "", "今月 / 先月 / 直近7日 / 直近30日 / 直近90日 / 今年 / 全期間 / 期間を指定"],
  ["開始日", "", "「期間」を 期間を指定 にしたときの開始日です。2026-09-01 のように書きます"],
  ["終了日", "", "「期間」を 期間を指定 にしたときの終了日です。2026-09-30 のように書きます"],
  ["絞り込みの列", "", "画面の上で絞り込みに使う列の名前を、3 つまで「、」で区切ります。例: チャネル、カテゴリ"],
];

function gasUi_() {
  return SpreadsheetApp.getUi();
}

function gasAlert_(text) {
  gasUi_().alert(text);
}

/** メニューの処理が途中で止まったときの知らせ。直していただけるよう、原因の文も添える */
function gasMenuFailed_(error) {
  console.error(error);
  gasAlert_("うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error));
}

export function onOpen() {
  gasUi_()
    .createMenu(GAS_MENU_TITLE_)
    .addItem("初期化（「設定」と「定義」のシートを作る）", "menu_init")
    .addItem("見本を入れる", "menu_samples")
    .addSeparator()
    .addItem("設定を確かめる", "menu_check")
    .addItem("ダッシュボードの URL", "menu_url")
    .addToUi();
}

/** `設定`・`定義` のシートを、無いときだけ作る（すでにあるシートには触れない） */
export function menu_init() {
  try {
    const made = [];
    if (gasSheetByName_(GAS_SETTINGS_SHEET_) === null) {
      gasWriteSheet_(GAS_SETTINGS_SHEET_, GAS_SETTINGS_TEMPLATE_);
      made.push(GAS_SETTINGS_SHEET_);
    }
    if (gasSheetByName_(GAS_DEFINITION_SHEET_) === null) {
      gasWriteSheet_(GAS_DEFINITION_SHEET_, [CONFIG_DEFINITION_COLUMNS_.slice()]);
      made.push(GAS_DEFINITION_SHEET_);
    }

    if (made.length === 0) {
      gasAlert_("「" + GAS_SETTINGS_SHEET_ + "」と「" + GAS_DEFINITION_SHEET_ + "」のシートはすでにありましたので、そのままにしました。");
      return;
    }
    gasAlert_(
      "「" + made.join("」と「") + "」のシートを作りました。\n\n" +
        "「" + GAS_SETTINGS_SHEET_ + "」に題名や期間を、「" + GAS_DEFINITION_SHEET_ + "」に 1 行 1 つずつ部品を書いてください。\n" +
        "書き方に迷われたときは、メニューの「見本を入れる」でひととおりの見本をご用意できます。"
    );
  } catch (error) {
    gasMenuFailed_(error);
  }
}

/** 見本で入れ替えるシートの名前（`設定`・`定義` とデータの 2 枚） */
function gasSampleSheetNames_(sample) {
  return [GAS_SETTINGS_SHEET_, GAS_DEFINITION_SHEET_].concat(Object.keys(sample.data));
}

/** `設定` の「言語」が英語なら英語の見本を入れる（読めないときは日本語） */
function gasSampleLang_() {
  try {
    return configFromSheets(gasReadConfigSheet_(GAS_SETTINGS_SHEET_), []).lang === "en" ? "en" : "ja";
  } catch (error) {
    console.error(error);
    return "ja";
  }
}

/** 見本（架空のお店の売上と目標）を入れる。すでに行があるシートは、お尋ねしてからのみ書き換える */
export function menu_samples() {
  try {
    const ui = gasUi_();
    const sample = sampleSheets(toDateKey(new Date()), gasSampleLang_());
    const names = gasSampleSheetNames_(sample);
    const used = names.filter((name) => gasHasDataRows_(name));

    if (used.length > 0) {
      const answer = ui.alert(
        GAS_MENU_TITLE_,
        "「" + used.join("」「") + "」にはすでに行が入っています。\n見本の内容で書き換えてもよろしいでしょうか。\n\n" +
          "（書き換えるのは「" + names.join("」「") + "」の " + names.length + " 枚だけで、ほかのシートはそのままです）",
        ui.ButtonSet.YES_NO
      );
      if (answer !== ui.Button.YES) {
        gasAlert_("見本は入れずに、そのままにしました。");
        return;
      }
    }

    gasWriteSheet_(GAS_SETTINGS_SHEET_, sample.settings);
    gasWriteSheet_(GAS_DEFINITION_SHEET_, sample.definitions);
    const dataNames = Object.keys(sample.data);
    for (let i = 0; i < dataNames.length; i += 1) gasWriteSheet_(dataNames[i], sample.data[dataNames[i]]);

    gasAlert_(
      "見本を入れました（「" + names.join("」「") + "」）。\n\n" +
        "メニューの「ダッシュボードの URL」から画面をお開きいただけます。\n" +
        "ご自分のデータに入れ替えるときは、「" + GAS_DEFINITION_SHEET_ + "」の「データ」の列を、そのシートの名前に書き換えてください。"
    );
  } catch (error) {
    gasMenuFailed_(error);
  }
}

/** 同じ文を二度並べない */
function gasAddProblem_(problems, text) {
  if (problems.indexOf(text) === -1) problems.push(text);
}

/** そのシートに、その列があるか（シートが見つからないことは、別の文でお知らせしている） */
function gasCheckColumn_(problems, headers, sheetName, column) {
  const name = textOf(column);
  if (name === "" || !headers.has(sheetName)) return;
  const header = headers.get(sheetName);
  if (header.length === 0 || header.indexOf(name) !== -1) return;
  gasAddProblem_(problems, GAS_ERROR_PREFIX_ + "シート「" + sheetName + "」に列「" + name + "」が見つかりません");
}

/** 設定に出てくるシートと列が、実際にあるかを確かめる */
function gasDataProblems_(config) {
  const problems = [];
  const headers = new Map();

  const datasetNames = Object.keys(config.datasets);
  for (let i = 0; i < datasetNames.length; i += 1) {
    const name = datasetNames[i];
    if (gasSheetByName_(name) === null) {
      gasAddProblem_(problems, GAS_ERROR_PREFIX_ + "データのシート「" + name + "」が見つかりません");
      continue;
    }
    const header = gasHeaderOf_(name);
    headers.set(name, header);
    if (header.length === 0) gasAddProblem_(problems, GAS_ERROR_PREFIX_ + "シート「" + name + "」に見出しの行がありません");
  }
  for (let i = 0; i < datasetNames.length; i += 1) {
    gasCheckColumn_(problems, headers, datasetNames[i], config.datasets[datasetNames[i]].dateColumn);
  }

  for (let i = 0; i < config.widgets.length; i += 1) {
    const widget = config.widgets[i];
    if (widget.type === "error") continue;
    const dataset = widget.dataset;
    gasCheckColumn_(problems, headers, dataset, widget.value);
    gasCheckColumn_(problems, headers, dataset, widget.category);
    gasCheckColumn_(problems, headers, dataset, widget.splitBy);
    gasCheckColumn_(problems, headers, dataset, widget.groupBy);
    gasCheckColumn_(problems, headers, dataset, widget.dateColumn);
    if (Array.isArray(widget.columns)) {
      for (let c = 0; c < widget.columns.length; c += 1) {
        const column = widget.columns[c];
        gasCheckColumn_(problems, headers, dataset, typeof column === "string" ? column : column.value);
      }
    }
    if (widget.target !== null && typeof widget.target === "object") {
      gasCheckColumn_(problems, headers, widget.target.dataset, widget.target.value);
      gasCheckColumn_(problems, headers, widget.target.dataset, widget.target.matchMonth);
    }
  }

  // 絞り込みの列は、どのシートにあってもよい（1 枚も持っていないときだけお知らせする）
  const dimensions = config.filters.dimensions;
  for (let i = 0; i < dimensions.length; i += 1) {
    const column = dimensions[i];
    let found = false;
    headers.forEach((header) => {
      if (header.indexOf(column) !== -1) found = true;
    });
    if (!found && headers.size > 0) {
      gasAddProblem_(problems, GAS_ERROR_PREFIX_ + "絞り込みの列「" + column + "」が、どのデータのシートにも見つかりません");
    }
  }

  return problems;
}

/** `設定`・`定義` と、そこに出てくるシート・列を確かめて、直すところを一覧でお見せする */
export function menu_check() {
  try {
    const settingsRows = gasReadConfigSheet_(GAS_SETTINGS_SHEET_);
    const definitionRows = gasReadConfigSheet_(GAS_DEFINITION_SHEET_);
    const parsed = parseConfig(configFromSheets(settingsRows, definitionRows));
    const problems = parsed.errors.concat(gasDataProblems_(parsed.config));
    const notes = configSheetNotes(settingsRows, definitionRows);

    const sections = [];
    sections.push(problems.length === 0 ? "設定に誤りはありません。" : "次の点をご確認ください。\n\n" + problems.join("\n"));
    if (notes.length > 0) sections.push("ご参考\n\n" + notes.join("\n"));
    gasAlert_(sections.join("\n\n"));
  } catch (error) {
    gasMenuFailed_(error);
  }
}

/** 公開したウェブアプリの URL。まだ公開されていなければ空 */
function gasAppUrl_() {
  try {
    return textOf(ScriptApp.getService().getUrl());
  } catch (error) {
    console.error(error);
    return "";
  }
}

/** ダッシュボードの URL をお見せする。まだ公開されていなければ、公開の手順をお見せする */
export function menu_url() {
  try {
    const url = gasAppUrl_();
    if (url === "") {
      gasAlert_(GAS_DEPLOY_STEPS_);
      return;
    }
    gasAlert_(
      "ダッシュボードの URL:\n" + url + "\n\n" +
        "この URL をお知らせしても、このスプレッドシートを共有した方だけがご覧になれます。\n" +
        "社外の方にお見せしたいときは、スプレッドシートの共有の設定をご確認ください。"
    );
  } catch (error) {
    gasMenuFailed_(error);
  }
}
