/**
 * ウェブアプリの入口（doGet）と、画面から呼ぶ 1 つの入口（api_bootstrap）。
 *
 * サーバーは集計をしない。`設定`・`定義` をそのままの形（raw）で渡し、必要なシートの行を
 * そのまま渡すだけで、絞り込みも集計も描画も画面の側で行う。
 * 思いがけない失敗は、内側の事情を出さずに 1 文の知らせに包む。
 */

import { textOf } from "../core/text.js";
import { t } from "../core/i18n.js";
import { configFromSheets } from "../core/config.js";
import { GAS_DEFINITION_SHEET_, GAS_SETTINGS_SHEET_, gasReadConfigSheet_, gasReadDataset_ } from "./gas_sheets.js";

/** 題名が決まっていないときに、ブラウザのタブに出す名前 */
const GAS_DEFAULT_TITLE_ = "ダッシュボード";

/**
 * `設定` シートの「言語」を読む。読めないとき・書かれていないときは日本語。
 * 失敗の知らせを、画面と同じ言語で返すために使う。
 * ここは失敗の知らせを組み立てる途中で呼ぶので、読めなかったことは実行ログに残さない
 * （もとの理由はすでに残してあり、同じ 1 件が二重に並ぶのを避けるため）
 */
function gasLang_() {
  try {
    return configFromSheets(gasReadConfigSheet_(GAS_SETTINGS_SHEET_), []).lang === "en" ? "en" : "ja";
  } catch (error) {
    return "ja";
  }
}

/**
 * 思いがけない失敗を包む。理由は実行ログにだけ残し、画面にはあたりさわりのない 1 文を返す
 * （シートの中身や内側の言葉を、見ている人に出さないため）。
 * 文の言語は `設定` の「言語」に合わせる（読めなければ日本語）
 */
export function gasSafely_(action) {
  try {
    return action();
  } catch (error) {
    console.error(error);
    return { ok: false, message: t(gasLang_(), "state.unavailable") };
  }
}

/**
 * 公開の設定が「自分として実行」になっていないかを確かめる。
 * このアプリは「ウェブアプリにアクセスしているユーザー」として動かす決まりで、そのときは
 * 開いた人（getActiveUser）と、権限を使っている人（getEffectiveUser）が同じ人になる。
 * 「自分」として公開されていると、開いた人が誰でも持ち主の権限でシートを読めてしまうので、
 * 2 人が違うとき・開いた人が分からないとき（ログインしていない・別の組織の方など）は、何も読まずに止める。
 * 確かめられなかったとき（許可が足りないなど）も、止めるほうに倒す
 */
export function gasRunsAsViewer_() {
  try {
    const active = textOf(Session.getActiveUser().getEmail()).toLowerCase();
    const effective = textOf(Session.getEffectiveUser().getEmail()).toLowerCase();
    return active !== "" && active === effective;
  } catch (error) {
    console.error(error);
    return false;
  }
}

/** 公開の設定が違うときの知らせ。持ち主の方が直し方にたどり着けるよう、実行ログにも理由を残す */
function gasDeployedAsOwner_() {
  console.error(
    "dashboard: ウェブアプリが「次のユーザーとして実行: 自分」で公開されているか、開いた方が分からないため、表示を止めました。" +
      "デプロイを管理 → 鉛筆 → 次のユーザーとして実行「ウェブアプリにアクセスしているユーザー」・バージョン「新バージョン」→ デプロイ で直せます。"
  );
  return { ok: false, message: t(gasLang_(), "state.deployedAsOwner") };
}

/**
 * 名前のとおりの場所に値を置く（"__proto__" のような名前のシートがあっても、
 * 入れ物のもとの形を書き換えないようにする）
 */
function gasSetOwn_(box, name, value) {
  Object.defineProperty(box, name, { value: value, writable: true, enumerable: true, configurable: true });
}

/** `設定` シートから題名だけを読む。読めないときは空 */
function gasTitle_() {
  try {
    return textOf(configFromSheets(gasReadConfigSheet_(GAS_SETTINGS_SHEET_), []).title);
  } catch (error) {
    console.error(error);
    return "";
  }
}

/**
 * 画面が最初に 1 回だけ呼ぶ入口。
 * `設定`・`定義` をそのままの形で渡し（シートが無くても止めず、画面が設定の誤りとして知らせる）、
 * 設定に出てくるシートの行をまとめて渡す。
 * - missing: 設定に出てくるのに見つからなかったシートの名前
 * - truncated: 行数の上限を超えていたシートの名前
 */
export function api_bootstrap() {
  return gasSafely_(function () {
    if (!gasRunsAsViewer_()) return gasDeployedAsOwner_();
    const raw = configFromSheets(gasReadConfigSheet_(GAS_SETTINGS_SHEET_), gasReadConfigSheet_(GAS_DEFINITION_SHEET_));
    const datasets = {};
    const missing = [];
    const truncated = [];

    const names = Object.keys(raw.datasets);
    for (let i = 0; i < names.length; i += 1) {
      const name = names[i];
      const read = gasReadDataset_(name);
      if (read === null) {
        missing.push(name);
        continue;
      }
      gasSetOwn_(datasets, name, read.rows);
      if (read.truncated) truncated.push(name);
    }

    return { ok: true, config: raw, datasets: datasets, missing: missing, truncated: truncated };
  });
}

/**
 * ウェブアプリの画面。App.html をそのまま返す。
 * このアプリは「ウェブアプリにアクセスしているユーザー」として動くので、
 * このスプレッドシートを見られる人だけが中身を見られる。
 * 公開の設定が違うとき（gasRunsAsViewer_ が false）は、題名もシートから読まない
 */
export function doGet() {
  const title = gasRunsAsViewer_() ? gasTitle_() : "";
  return HtmlService.createHtmlOutputFromFile("App")
    .setTitle(title || GAS_DEFAULT_TITLE_)
    .addMetaTag("viewport", "width=device-width, initial-scale=1");
}
