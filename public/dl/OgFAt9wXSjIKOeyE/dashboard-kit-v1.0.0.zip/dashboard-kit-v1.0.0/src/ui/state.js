/**
 * 画面の状態（読み込みの具合・絞り込み・「表で見る」・並べ替え）と、操作から次の状態を作る 1 か所。
 * ここは純粋な計算だけを行う。状態を書き換えず、変わるときだけ新しい状態を作って返す
 * （変わらないときは同じ状態をそのまま返すので、描き直しが要るかを「同じものか」で見分けられる）。
 */

import { textOf, hasOwn } from "../core/text.js";
import { CONFIG_PERIODS_ } from "../core/config.js";
import { initialFilters } from "../core/filter.js";

/**
 * 期間の選び方の並び（絞り込みの select もこの順で出す）。custom はいつも最後。
 * 設定の検査と同じ 1 つの並びを使う（別々に持つと、足したときに片方だけ古くなるため）
 */
export const PERIOD_PRESETS = CONFIG_PERIODS_;

/** 並べ替えの巡り。同じ列を押すたびに 大きい順 → 小さい順 → 並べ替えなし に戻る */
const STATE_SORT_NEXT_ = { desc: "asc", asc: "" };

/**
 * 名前をキーにした入れ物を写して、1 項目だけ入れ替える。列名は利用者が自由に書ける文字なので、
 * "__proto__" のような名前でも入れ物自体の素性を書き換えないよう、プロトタイプの無い入れ物に組む
 */
function stateSetOwn_(box, name, value) {
  const copy = Object.create(null);
  const source = box && typeof box === "object" ? box : {};
  for (const key of Object.keys(source)) copy[key] = source[key];
  if (name !== undefined) Object.defineProperty(copy, name, { value, writable: true, enumerable: true, configurable: true });
  return copy;
}

/** 区分の絞り込みが 2 つとも同じ中身か */
function stateSameDimensions_(a, b) {
  const left = a && typeof a === "object" ? a : {};
  const right = b && typeof b === "object" ? b : {};
  const keys = Object.keys(left);
  if (keys.length !== Object.keys(right).length) return false;
  for (const key of keys) {
    if (!hasOwn(right, key) || left[key] !== right[key]) return false;
  }
  return true;
}

/** 絞り込みが 2 つとも同じ中身か（描く側が「戻す」を出すかの判断にも使う） */
export function filtersDiffer(a, b) {
  const left = a && typeof a === "object" ? a : {};
  const right = b && typeof b === "object" ? b : {};
  if (left.period !== right.period) return true;
  if (left.from !== right.from || left.to !== right.to) return true;
  return !stateSameDimensions_(left.dimensions, right.dimensions);
}

/** 項目がどれか変わるときだけ、新しい状態を作る */
function stateWith_(state, patch) {
  for (const key of Object.keys(patch)) {
    if (state[key] !== patch[key]) return Object.assign({}, state, patch);
  }
  return state;
}

/** 絞り込みを差し替える（中身が同じなら、元の状態をそのまま返す） */
function stateWithFilters_(state, filters) {
  if (!filtersDiffer(state.filters, filters)) return state;
  return Object.assign({}, state, { filters });
}

/**
 * 設定と today（"YYYY-MM-DD"）から、画面の最初の状態を作る。
 * initial は「戻す」で帰る先。絞り込みが最初と違うかを描く側が見分けるためにも持たせる
 */
export function initialState(config, today) {
  const filters = initialFilters(config, today);
  return { status: "loading", filters, initial: filters, tableView: {}, sort: {}, message: "" };
}

function stateSetPeriod_(state, action) {
  const period = textOf(action.period);
  if (PERIOD_PRESETS.indexOf(period) === -1) return state;
  return stateWithFilters_(state, Object.assign({}, state.filters, { period }));
}

function stateSetRange_(state, action) {
  const from = textOf(action.from);
  const to = textOf(action.to);
  return stateWithFilters_(state, Object.assign({}, state.filters, { period: "custom", from, to }));
}

function stateSetDimension_(state, action) {
  const column = textOf(action.column);
  // 設定に書かれた列だけを受け取る（知らない列は静かに見送る）
  if (!hasOwn(state.filters.dimensions, column)) return state;
  const dimensions = stateSetOwn_(state.filters.dimensions, column, textOf(action.value));
  return stateWithFilters_(state, Object.assign({}, state.filters, { dimensions }));
}

function stateToggleTable_(state, action) {
  const id = textOf(action.widget);
  if (id === "") return state;
  const showing = hasOwn(state.tableView, id) && state.tableView[id] === true;
  const tableView = stateSetOwn_(state.tableView, id, !showing);
  return Object.assign({}, state, { tableView });
}

function stateSort_(state, action) {
  const id = textOf(action.widget);
  const column = Number(action.column);
  if (id === "" || !Number.isInteger(column) || column < 0) return state;

  const current = hasOwn(state.sort, id) ? state.sort[id] : null;
  const order = current && current.column === column ? STATE_SORT_NEXT_[current.order] || "" : "desc";
  if (order === "") {
    // 3 回目で並べ替えをやめる。元の並び（model が決めた順）に戻す
    const sort = stateSetOwn_(state.sort, undefined, undefined);
    delete sort[id];
    return Object.assign({}, state, { sort });
  }
  return Object.assign({}, state, { sort: stateSetOwn_(state.sort, id, { column, order }) });
}

function stateReset_(state) {
  const cleared = stateWithFilters_(state, state.initial);
  const sameTable = Object.keys(state.tableView).length === 0;
  const sameSort = Object.keys(state.sort).length === 0;
  if (cleared === state && sameTable && sameSort) return state;
  return Object.assign({}, cleared, { filters: state.initial, tableView: {}, sort: {} });
}

/**
 * 操作（action）から次の状態を作る。知らない操作・形の無い操作は、元の状態をそのまま返す。
 * action は { type, … } の形で、type ごとに使う項目が違う
 * （set-period は period、set-range は from/to、set-dimension は column/value、
 * toggle-table は widget、sort は widget/column、failed は message）
 */
export function reduce(state, action) {
  if (!state || typeof state !== "object") return state;
  const type = action && typeof action === "object" ? textOf(action.type) : "";

  if (type === "loaded") return stateWith_(state, { status: "ready", message: "" });
  if (type === "failed") return stateWith_(state, { status: "error", message: textOf(action.message) });
  if (type === "set-period") return stateSetPeriod_(state, action);
  if (type === "set-range") return stateSetRange_(state, action);
  if (type === "set-dimension") return stateSetDimension_(state, action);
  if (type === "toggle-table") return stateToggleTable_(state, action);
  if (type === "sort") return stateSort_(state, action);
  if (type === "reset") return stateReset_(state);
  return state;
}
