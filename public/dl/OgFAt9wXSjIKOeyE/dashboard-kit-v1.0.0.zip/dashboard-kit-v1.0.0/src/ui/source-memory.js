/**
 * 見本の読み口。ブラウザの中で作った見本データ（しおかぜ珈琲店）をそのまま渡す。
 * 設定に書いてある CSV の置き場所は見に行かない（行はすでに手もとにあるため）。
 * 見本のページと、買う前に動かして確かめてもらうための読み口で、外へは一度も取りに行かない。
 */

import { textOf } from "../core/text.js";
import { sampleData } from "../core/samples.js";

/**
 * 見本データを渡す読み口を作る。options は { today: "YYYY-MM-DD", lang: "ja" | "en" }。
 * today が同じなら、何度読んでも同じ中身になる
 */
export function sourceMemoryCreate_(options) {
  const opts = options && typeof options === "object" ? options : {};
  const today = textOf(opts.today);
  const lang = opts.lang === "en" ? "en" : "ja";

  return {
    load() {
      const sample = sampleData(today, lang);
      return Promise.resolve({ config: sample.config, datasets: sample.datasets, missing: [] });
    },
  };
}
