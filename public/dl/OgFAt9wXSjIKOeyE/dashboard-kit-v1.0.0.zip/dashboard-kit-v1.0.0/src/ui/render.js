/**
 * 画面ぜんたいの組み立て。枠・題・絞り込みの行・部品の格子・注記までを 1 つの文字列にする。
 * 数の計算も書式づくりもここでは行わず、model と state が決めたものを置くだけ。
 * 画面には触れない（差し込みと操作は別のところで行う）。
 */

import { textOf, escapeHtml, escapeAttr, hasOwn } from "../core/text.js";
import { formatNumber } from "../core/numbers.js";
import { t } from "../core/i18n.js";
import { PERIOD_PRESETS, filtersDiffer } from "./state.js";
import { renderKpi, renderLine, renderBar, renderMeter } from "./render-charts.js";
import { renderTable, renderDataTable, renderCsvButton } from "./render-table.js";

/** 設定の誤りの文に付く前置き。札に出すときは外す（一覧では残す） */
const RENDER_ERROR_PREFIX_ = "dashboard: ";

/** 描ける部品の種類。これ以外は設定を見直す札にする */
const RENDER_WIDGET_TYPES_ = ["kpi", "line", "bar", "meter", "table"];

/** 部品の大きさ（知らない値は真ん中の m にする） */
function renderSize_(model) {
  return model && (model.size === "s" || model.size === "l") ? model.size : "m";
}

/** その部品が「表で見る」に切り替わっているか */
function renderShowsTable_(state, id) {
  const shown = state && state.tableView;
  return hasOwn(shown, id) && shown[id] === true;
}

function renderLang_(view) {
  if (view.lang === "en" || view.lang === "ja") return view.lang;
  return view.config && view.config.lang === "en" ? "en" : "ja";
}

/** 読み込み中・出せないときの知らせ（読み上げにもその場で伝わるようにする） */
function renderStatus_(text) {
  return '<div class="db-status" role="status">' + escapeHtml(text) + "</div>";
}

/** 読み込み中の知らせ */
export function renderLoading(lang) {
  return renderStatus_(t(lang, "state.loading"));
}

/** 設定の誤りの一覧。数を添えて畳んでおき、開くと 1 件ずつ読める */
function renderErrorList_(errors, lang) {
  const list = (Array.isArray(errors) ? errors : []).filter((message) => textOf(message) !== "");
  if (list.length === 0) return "";
  const items = list.map((message) => "<li>" + escapeHtml(message) + "</li>").join("");
  return (
    '<details class="db-errors"><summary>' + escapeHtml(t(lang, "state.configIssues", { count: list.length })) +
    "</summary><ul>" + items + "</ul></details>"
  );
}

// ---- 絞り込みの行 ---------------------------------------------------------

function renderOption_(value, label, selected) {
  return '<option value="' + escapeAttr(value) + '"' + (selected ? " selected" : "") + ">" + escapeHtml(label) + "</option>";
}

function renderField_(label, control) {
  return '<label class="db-field"><span class="db-field-label">' + escapeHtml(label) + "</span>" + control + "</label>";
}

function renderDateField_(name, value, lang) {
  return renderField_(
    t(lang, name === "from" ? "filter.from" : "filter.to"),
    '<input class="db-date" type="date" name="' + name + '" data-action="set-range" value="' + escapeAttr(value) + '" />'
  );
}

/** 区分の絞り込み 1 つ。先頭はいつも「すべて」（値は空文字） */
function renderDimensionField_(column, current, values, lang) {
  const options = [renderOption_("", t(lang, "filter.allValues"), current === "")];
  for (const value of values) options.push(renderOption_(value, value, value === current));
  return renderField_(
    column,
    '<select class="db-select" name="dim" data-column="' + escapeAttr(column) + '" data-action="set-dimension">' + options.join("") + "</select>"
  );
}

/**
 * 画面の上の 1 行。期間の select、「期間を指定」のときだけ日付 2 つ、設定に書いた区分の select、
 * そして最初と違うときだけ「戻す」。絞り込みは下のすべての部品に同時に効く
 */
export function renderFilters(view) {
  const lang = renderLang_(view);
  const state = view.state || {};
  const filters = state.filters || {};
  const options = view.options || {};
  const parts = [];

  const periods = PERIOD_PRESETS.map((preset) => renderOption_(preset, t(lang, "filter.period." + preset), filters.period === preset));
  parts.push(
    renderField_(t(lang, "filter.period"), '<select class="db-select" name="period" data-action="set-period">' + periods.join("") + "</select>")
  );

  if (filters.period === "custom") {
    parts.push(renderDateField_("from", textOf(filters.from), lang));
    parts.push(renderDateField_("to", textOf(filters.to), lang));
  }

  for (const column of Object.keys(filters.dimensions || {})) {
    const values = hasOwn(options, column) ? options[column] : null;
    const current = hasOwn(filters.dimensions, column) ? filters.dimensions[column] : "";
    parts.push(renderDimensionField_(column, textOf(current), Array.isArray(values) ? values : [], lang));
  }

  if (filtersDiffer(filters, state.initial)) {
    parts.push('<button type="button" class="db-reset" data-action="reset">' + escapeHtml(t(lang, "filter.reset")) + "</button>");
  }

  return '<form class="db-filters" autocomplete="off">' + parts.join("") + "</form>";
}

// ---- 部品 -----------------------------------------------------------------

/** 部品の下に添える注記（設定に書いた文、上限に当たった知らせ、数として読めなかった値の数） */
function renderNotes_(model, lang) {
  const notes = [];
  if (textOf(model.note) !== "") notes.push(model.note);
  if (textOf(model.limitNote) !== "") notes.push(model.limitNote);
  if (Number.isFinite(model.skipped) && model.skipped > 0) {
    notes.push(t(lang, "state.skippedValues", { count: formatNumber(model.skipped, "number", lang) }));
  }
  return notes.map((note) => '<p class="db-card-note">' + escapeHtml(note) + "</p>").join("");
}

/** 題の右に置く押しボタン。表の部品は CSV、それ以外は「表で見る」の切り替え */
function renderCardAction_(model, showingTable, lang) {
  if (model.type === "table") return renderCsvButton(model.id, lang);
  return (
    '<button type="button" class="db-toggle" data-action="toggle-table" data-widget="' + escapeAttr(model.id) +
    '" aria-pressed="' + (showingTable ? "true" : "false") + '">' +
    escapeHtml(t(lang, showingTable ? "widget.showChart" : "widget.showTable")) + "</button>"
  );
}

/**
 * 部品 1 つの枠（題・押しボタン・中身・注記）。inner はすでに組み立てた中身の文字列。
 * lang は押しボタンと注記の文に使う（既定は ja）
 */
export function renderWidgetFrame(model, inner, state, lang) {
  const tongue = lang === "en" ? "en" : "ja";
  const id = escapeAttr(model.id);
  const showingTable = renderShowsTable_(state, model.id);
  return (
    '<section class="db-card db-size-' + renderSize_(model) + '" data-widget="' + id + '" aria-labelledby="' + id + '-title">' +
    '<div class="db-card-head"><h2 id="' + id + '-title" class="db-card-title">' + escapeHtml(model.title) + "</h2>" +
    renderCardAction_(model, showingTable, tongue) + "</div>" +
    '<div class="db-card-body">' + inner + "</div>" +
    renderNotes_(model, tongue) +
    "</section>"
  );
}

/**
 * 設定や列の行き違いを知らせる札。前置きは一覧のためのものなので、札では外す。
 * 大きさは部品の設定どおりにして、格子の並びが崩れないようにする
 */
export function renderError(model, lang) {
  const tongue = lang === "en" ? "en" : "ja";
  const id = escapeAttr(model.id);
  const title = textOf(model.title) || t(tongue, "state.checkConfig");
  const message = textOf(model.message);
  const shown = message.startsWith(RENDER_ERROR_PREFIX_) ? message.slice(RENDER_ERROR_PREFIX_.length) : message;
  return (
    '<section class="db-card db-size-' + renderSize_(model) + '" data-widget="' + id + '" aria-labelledby="' + id + '-title">' +
    '<div class="db-card-head"><h2 id="' + id + '-title" class="db-card-title">' + escapeHtml(title) + "</h2></div>" +
    '<div class="db-card-body"><p class="db-error">' + escapeHtml(shown || t(tongue, "state.checkConfig")) + "</p></div>" +
    "</section>"
  );
}

/** 部品の中身。「表で見る」が入っているときは、グラフの代わりに同じ値の表を出す */
function renderWidgetBody_(model, state, lang) {
  if (model.type === "table") return renderTable(model, state, lang);
  if (renderShowsTable_(state, model.id)) return renderDataTable(model, state, lang);
  if (model.type === "kpi") return renderKpi(model, state, lang);
  if (model.type === "line") return renderLine(model, state, lang);
  if (model.type === "bar") return renderBar(model, state, lang);
  return renderMeter(model, state, lang);
}

function renderWidget_(model, state, lang) {
  if (!model || typeof model !== "object") return "";
  // 知らない種類を目標の帯として描くと、それらしい形に見えて間違いに気づけないので、札にして知らせる
  if (model.type === "error" || RENDER_WIDGET_TYPES_.indexOf(model.type) === -1) return renderError(model, lang);
  return renderWidgetFrame(model, renderWidgetBody_(model, state, lang), state, lang);
}

// ---- ダッシュボード -------------------------------------------------------

/**
 * 画面ぜんたい。view は { config, model, state, options, lang, errors }。
 * options は区分の絞り込みの選び方（{ 列の名前: 値の並び }）、errors は設定の誤りの文の並び。
 * 読み込み中・出せないときは、知らせだけを枠の中に置く
 */
export function renderDashboard(view) {
  const source = view && typeof view === "object" ? view : {};
  const config = source.config || {};
  const model = source.model || {};
  const state = source.state || {};
  const lang = renderLang_(source);
  const theme = config.theme === "light" || config.theme === "dark" ? config.theme : "auto";

  const parts = [];
  const title = textOf(model.title) || textOf(config.title);
  if (title !== "") parts.push('<h1 class="db-title">' + escapeHtml(title) + "</h1>");

  if (state.status === "loading") {
    parts.push(renderLoading(lang));
  } else if (state.status === "error") {
    parts.push(renderStatus_(textOf(state.message) || t(lang, "state.unavailable")));
  } else {
    parts.push(renderErrorList_(source.errors, lang));
    parts.push(renderFilters(source));
    const widgets = (Array.isArray(model.widgets) ? model.widgets : []).map((widget) => renderWidget_(widget, state, lang));
    parts.push('<div class="db-grid">' + widgets.join("") + "</div>");
    for (const note of Array.isArray(model.notes) ? model.notes : []) {
      parts.push('<p class="db-note">' + escapeHtml(note) + "</p>");
    }
  }

  return '<div class="db" data-db-theme="' + theme + '" lang="' + lang + '">' + parts.join("") + "</div>";
}
