/**
 * model（組み立て済みの形）を、そのまま画面に出せる文字列にする。KPI・折れ線・棒・目標の 4 つ。
 * 値の計算も書式づくりもここでは行わず、model が決めたものを置くだけ。
 * 画面には触れず、文字列を作って返すだけにしてある（差し込みと操作は別のところで行う）。
 * どれも (model, state, lang) の同じ形で呼べるようにしてある（state を見るのは表だけ）。
 */

import { escapeHtml, estimateTextWidth, clamp } from "../core/text.js";
import { formatNumber } from "../core/numbers.js";
import { t } from "../core/i18n.js";
import { linePath, areaPath, roundedBar, scaleLinear, tipAttrs } from "./svg.js";

/** 折れ線・縦棒の枠。幅は置かれた場所に合わせて伸び縮みさせる（横棒だけは高さが区分の数で伸びる） */
const CHART_WIDTH_ = 640;
const CHART_HEIGHT_ = 280;
/**
 * 札の場所どりを見積もるときの字の大きさ。図は置かれた場所の幅に合わせて伸び縮みし、
 * 狭い画面では札の字を少し大きくする（style.css）ので、余白は広めにとっておく
 * （広くとりすぎても札が切れることはないが、狭いと切れてしまうため）
 */
const CHART_FONT_ = 15;
/** 棒の太さ・値の側の角丸・隣り合う面のすき間 */
const CHART_BAR_MAX_ = 24;
const CHART_BAR_RADIUS_ = 4;
const CHART_BAR_GAP_ = 2;
/** 横に並ぶ札は多くても 8 つ（両端は必ず出す） */
const CHART_X_LABEL_MAX_ = 8;
/** 図の内がわに、いつもとっておく余白 */
const CHART_PAD_ = 12;
/** 図の下の端と、いちばん下の札の基準線とのすき間 */
const CHART_EDGE_ = 8;
/** 札 1 行ぶんの高さ（札を置く行を数えるときの目安） */
const CHART_TEXT_ROW_ = 16;
/** 札と札・札と棒のあいだに、必ず残すすき間 */
const CHART_CLEAR_ = 4;
/** 目盛りの札と、図の本体とのすき間 */
const CHART_TICK_GAP_ = 10;
/** 直接ラベルの基準線を、点や棒の先端からどれだけ離すか（下に出すとき・横に出すとき） */
const CHART_MARK_GAP_ = 14;
/** 直接ラベルを、棒の先端より上に置くときの持ち上げ */
const CHART_MARK_LIFT_ = 6;
/** 直接ラベルと、印そのもののあいだのすき間 */
const CHART_MARK_OFFSET_ = 8;
/** 直接ラベルどうしが重ならないと見なせる、たての隔たり（折れ線の端の札） */
const CHART_LABEL_GAP_ = 14;
/** 隣り合う先端の札が、これより近づくなら札を絞る */
const CHART_LABEL_NEAR_ = 6;
/** 区分名を「…」で短くするとき、必ず残す字の数（全角に直したときの目安） */
const CHART_LABEL_MIN_ = 4;
/** 横棒 1 本ぶんの高さ（区分が増えると、図の縦もこの分だけ伸びる） */
const CHART_ROW_PITCH_ = 28;
/** 横棒の上の余白 */
const CHART_ROW_TOP_ = 10;
/** 区分名を置く左の余白の上限 */
const CHART_LEFT_MAX_ = 210;
/** 先端の札のために空ける、右の余白の上限（棒・折れ線） */
const CHART_BAR_RIGHT_MAX_ = 150;
const CHART_LINE_RIGHT_MAX_ = 170;
/** KPI の小さな折れ線 */
const CHART_SPARK_WIDTH_ = 160;
const CHART_SPARK_HEIGHT_ = 40;

/** 図の中の数は小数 2 桁まで */
function chartNum_(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) return "0";
  return String(Math.round(num * 100) / 100);
}

function chartIsNumber_(value) {
  return typeof value === "number" && Number.isFinite(value);
}

/** 図の中の 1 行の文字（文字は系列の色を着けず、--db-text* の色のままにする） */
function chartText_(className, x, y, anchor, text) {
  return (
    '<text class="' + className + '" x="' + chartNum_(x) + '" y="' + chartNum_(y) + '" text-anchor="' + anchor + '">' +
    escapeHtml(text) +
    "</text>"
  );
}

/** 目盛りの数を、部品の書式のまま短く読める札にする */
function chartTickText_(value, format, lang) {
  return formatNumber(value, format, lang, { compact: true });
}

/** 「…」で短くした名前を置くのに、最低限これだけの幅は要る（全角 4 字 + 「…」） */
function chartLabelFloor_() {
  return CHART_LABEL_MIN_ * CHART_FONT_ + estimateTextWidth("…", CHART_FONT_);
}

/**
 * 決まった幅に収まるところまで、名前を字の幅で短くする（そのまま収まるなら短くしない）。
 * 字数ではなく幅で切るので、半角の名前が全角の倍も削られることはない。
 * 全角 4 字 + 「…」も置けない狭さのときは "" を返し、呼ぶ側が間引きに切り替える
 * （見分けのつかない切れ端ばかりを並べないため。元の名前は吹き出しと「表で見る」に残る）
 */
function chartFitLabel_(text, width) {
  const whole = String(text === null || text === undefined ? "" : text);
  if (estimateTextWidth(whole, CHART_FONT_) <= width) return whole;
  if (width < chartLabelFloor_()) return "";
  const chars = Array.from(whole);
  for (let keep = chars.length - 1; keep >= 1; keep -= 1) {
    const candidate = chars.slice(0, keep).join("") + "…";
    if (estimateTextWidth(candidate, CHART_FONT_) <= width) return candidate;
  }
  return "";
}

/**
 * count 個の札のうち、どれを出すかを決める（多くても limit 個、両端は必ず出す）。
 * 最後の 1 つだけが近づきすぎるときは、その手前を落として重なりを防ぐ
 */
function chartThin_(count, limit) {
  if (count <= 0) return [];
  if (count === 1) return [0];
  const keep = Math.max(2, Math.min(limit, count));
  const step = Math.ceil((count - 1) / (keep - 1));
  const picked = [];
  for (let i = 0; i < count - 1; i += step) picked.push(i);
  // 最後の札との間が、ほかの間の 3/4 に満たないときは手前を落とす（半分ちょうどでも文字が重なるため）
  if (picked.length > 1 && count - 1 - picked[picked.length - 1] < step * 0.75) picked.pop();
  picked.push(count - 1);
  return picked;
}

/** 幅いっぱいに並べたとき、重ならずに置ける札の数 */
function chartLabelRoom_(labels, span) {
  let widest = 0;
  for (const label of labels) widest = Math.max(widest, estimateTextWidth(label, CHART_FONT_));
  const room = Math.floor(span / (widest + CHART_MARK_OFFSET_));
  return Math.max(2, Math.min(CHART_X_LABEL_MAX_, room));
}

/** データが無いときの、やわらかいお知らせ（軸は描かない） */
export function renderEmptyNote(lang) {
  return '<p class="db-empty">' + escapeHtml(t(lang, "state.noData")) + "</p>";
}

/** 凡例（2 系列以上のときだけ出す）。鍵は印と同じ形にする（折れ線は短い線、棒は四角） */
function chartLegend_(items, shape) {
  const parts = items.map(
    (item) =>
      '<li class="db-legend-item"><span class="db-legend-swatch db-legend-' + shape + " db-s" + item.color + '" aria-hidden="true"></span>' +
      '<span class="db-legend-label">' + escapeHtml(item.label) + "</span></li>"
  );
  return '<ul class="db-legend">' + parts.join("") + "</ul>";
}

/**
 * 図ぜんたいの包み。svg の下に凡例を置く。
 * height は横棒だけが使う（区分が増えると縦に伸びる）。渡さなければ決まった高さ
 */
function chartFrame_(title, body, legend, height) {
  const tall = Number.isFinite(height) ? height : CHART_HEIGHT_;
  return (
    '<div class="db-chart"><svg class="db-chart-svg" viewBox="0 0 ' + CHART_WIDTH_ + " " + chartNum_(tall) +
    '" width="100%" preserveAspectRatio="xMidYMid meet" role="group"><title>' +
    escapeHtml(title) + "</title>" + body + "</svg>" + legend + "</div>"
  );
}

/**
 * 目盛り線と、その札。0 の線は少しだけ濃くする（0 をまたぐグラフで、行き来が読めるように）。
 * 縦のグラフは横線を引いて左に札を置き、横のグラフは縦線を引いて下に札を置く
 */
function chartGrid_(ticks, scale, box, vertical, format, lang, thinned) {
  const parts = [];
  const labels = ticks.map((tick) => chartTickText_(tick, format, lang));
  const show = thinned === true ? chartThin_(ticks.length, chartLabelRoom_(labels, box.right - box.left)) : null;
  ticks.forEach((tick, index) => {
    const at = chartNum_(scale(tick));
    const zero = tick === 0 ? "db-axis-zero" : "db-grid-line";
    if (vertical) {
      parts.push('<line class="' + zero + '" x1="' + chartNum_(box.left) + '" y1="' + at + '" x2="' + chartNum_(box.right) + '" y2="' + at + '" />');
      parts.push(chartText_("db-y-label", box.left - CHART_MARK_OFFSET_, scale(tick) + CHART_CLEAR_, "end", labels[index]));
    } else {
      parts.push('<line class="' + zero + '" x1="' + at + '" y1="' + chartNum_(box.top) + '" x2="' + at + '" y2="' + chartNum_(box.bottom) + '" />');
      if (show === null || show.indexOf(index) !== -1) {
        parts.push(chartText_("db-x-label", scale(tick), box.bottom + CHART_TEXT_ROW_, "middle", labels[index]));
      }
    }
  });
  return parts.join("");
}

// ---- kpi ------------------------------------------------------------------

/** 差の向きを表す印。色だけに頼らず、記号と符号でも分かるようにする */
const CHART_DELTA_MARKS_ = { up: "▲", down: "▼", flat: "—" };

function chartKpiDelta_(delta) {
  // 比べる相手が無いときは、札そのものを置かない（意味を持たない「—」を残さない）
  if (delta === null || delta === undefined) return "";
  const tone = delta.good === true ? "db-delta-good" : delta.good === false ? "db-delta-bad" : "db-delta-flat";
  const mark = CHART_DELTA_MARKS_[delta.direction] || "—";
  return (
    '<p class="db-kpi-delta ' + tone + '"><span class="db-delta-mark">' + escapeHtml(mark + " " + delta.text) + "</span>" +
    '<span class="db-delta-label">' + escapeHtml(delta.label) + "</span></p>"
  );
}

/** KPI の小さな折れ線。軸も札も持たない飾りなので、読み上げからは外す */
function chartSpark_(spark) {
  if (!spark || !Array.isArray(spark.values) || spark.values.length < 2) return "";
  const pad = 5;
  // 値がすべて同じときは、上下の幅を少し広げて真ん中に引く（下端に貼りつかせない）
  const flat = spark.min === spark.max;
  const x = scaleLinear([0, spark.values.length - 1], [pad, CHART_SPARK_WIDTH_ - pad]);
  const y = scaleLinear(flat ? [spark.min - 1, spark.max + 1] : [spark.min, spark.max], [CHART_SPARK_HEIGHT_ - pad, pad]);
  const points = spark.values.map((value, index) => (chartIsNumber_(value) ? { x: x(index), y: y(value) } : null));

  let last = null;
  for (let i = points.length - 1; i >= 0; i -= 1) {
    if (points[i] !== null) {
      last = points[i];
      break;
    }
  }
  const dot =
    last === null
      ? ""
      : '<circle class="db-spark-point" cx="' + chartNum_(last.x) + '" cy="' + chartNum_(last.y) +
        '" r="3" fill="var(--db-accent)" stroke="var(--db-card)" stroke-width="2" />';
  return (
    '<svg class="db-spark" viewBox="0 0 ' + CHART_SPARK_WIDTH_ + " " + CHART_SPARK_HEIGHT_ +
    '" width="100%" preserveAspectRatio="xMidYMid meet" aria-hidden="true" focusable="false">' +
    '<path class="db-spark-line db-s0" d="' + linePath(points) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />' +
    dot + "</svg>"
  );
}

/** 1 つの数と、前の期間との差と、小さな折れ線 */
export function renderKpi(model, state, lang) {
  const rows = [{ label: t(lang, "table.value"), value: model.valueFull, color: null }];
  if (model.delta) rows.push({ label: model.delta.label, value: model.delta.textFull, color: null });
  const tip = tipAttrs({ title: model.title, rows }, lang);
  return (
    '<div class="db-kpi">' +
    // 縮めない数は吹き出しが持つので、ここに素の title は付けない（2 つの吹き出しが重なって出てしまう）
    '<p class="db-kpi-value"' + tip + ">" + escapeHtml(model.valueText) + "</p>" +
    chartKpiDelta_(model.delta) +
    chartSpark_(model.spark) +
    "</div>"
  );
}

// ---- line -----------------------------------------------------------------

/**
 * 折れ線の余白。目盛りの札・両端の刻みの札・端の直接ラベルが、どれも切れない幅をとる。
 * 刻みの札は図の下の 1 行（labelY）に置くので、その 1 行ぶんを下に空けておく
 */
function chartLineBox_(model, lang) {
  const tickLabels = model.ticks.map((tick) => chartTickText_(tick, model.format, lang));
  let left = CHART_PAD_;
  for (const label of tickLabels) left = Math.max(left, estimateTextWidth(label, CHART_FONT_) + CHART_TICK_GAP_);

  const bucketLabels = model.buckets.map((bucket) => bucket.label);
  const first = bucketLabels.length > 0 ? estimateTextWidth(bucketLabels[0], CHART_FONT_) / 2 + CHART_CLEAR_ : 0;
  const last = bucketLabels.length > 0 ? estimateTextWidth(bucketLabels[bucketLabels.length - 1], CHART_FONT_) / 2 + CHART_CLEAR_ : 0;
  left = Math.max(left, first);

  let right = Math.max(CHART_PAD_, last);
  for (const line of model.series) right = Math.max(right, estimateTextWidth(line.lastLabel, CHART_FONT_) + CHART_MARK_GAP_);
  right = Math.min(right, CHART_LINE_RIGHT_MAX_);

  const labelY = CHART_HEIGHT_ - CHART_EDGE_;
  return { left, right: CHART_WIDTH_ - right, top: CHART_TEXT_ROW_, bottom: labelY - CHART_TEXT_ROW_ - CHART_CLEAR_, labelY };
}

/** 直接ラベルは端だけに置く。重なるときは高い方だけを残す（見分けは凡例が受け持つ） */
function chartLineLabels_(marks) {
  const sorted = marks.slice().sort((a, b) => a.y - b.y);
  const kept = [];
  for (const mark of sorted) {
    if (kept.length > 0 && mark.y - kept[kept.length - 1].y < CHART_LABEL_GAP_) continue;
    kept.push(mark);
  }
  return kept;
}

/** 刻み 1 つぶんの当たり判定の帯。その刻みの全系列を 1 つの吹き出しに出す */
function chartLineBands_(model, box, xAt, band, lang) {
  return model.buckets
    .map((bucket, index) => {
      const center = xAt(index);
      const from = Math.max(box.left, center - band / 2);
      const to = Math.min(box.right, center + band / 2);
      const rows = model.series.map((line) => ({
        label: line.label,
        value: formatNumber(line.values[index], model.format, lang),
        color: line.color,
      }));
      return (
        '<rect class="db-hit" x="' + chartNum_(from) + '" y="' + chartNum_(box.top) + '" width="' + chartNum_(to - from) +
        '" height="' + chartNum_(box.bottom - box.top) + '" data-bucket="' + index + '" data-x="' + chartNum_(center) + '"' +
        tipAttrs({ title: bucket.label, rows }, lang) + " />"
      );
    })
    .join("");
}

/** 時間の推移。系列は model が 4 本までに収めてある */
export function renderLine(model, state, lang) {
  if (model.empty === true || model.buckets.length === 0 || model.series.length === 0) return renderEmptyNote(lang);

  const box = chartLineBox_(model, lang);
  const count = model.buckets.length;
  const y = scaleLinear([model.ticks[0], model.yMax], [box.bottom, box.top]);
  const xAt = (index) => (count === 1 ? (box.left + box.right) / 2 : box.left + (index * (box.right - box.left)) / (count - 1));
  const band = count === 1 ? box.right - box.left : (box.right - box.left) / (count - 1);
  const baseY = clamp(y(0), box.top, box.bottom);

  const parts = [chartGrid_(model.ticks, y, box, true, model.format, lang)];

  const labels = model.buckets.map((bucket) => bucket.label);
  for (const index of chartThin_(count, chartLabelRoom_(labels, box.right - box.left))) {
    parts.push(chartText_("db-x-label", xAt(index), box.labelY, "middle", labels[index]));
  }

  const marks = [];
  for (const line of model.series) {
    const points = line.values.map((value, index) => (chartIsNumber_(value) ? { x: xAt(index), y: y(value) } : null));
    if (model.area === true) {
      parts.push('<path class="db-area db-s' + line.color + '" d="' + areaPath(points, baseY) + '" fill="currentColor" fill-opacity="0.1" />');
    }
    parts.push(
      '<path class="db-line db-s' + line.color + '" d="' + linePath(points) +
        '" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />'
    );
    for (let i = points.length - 1; i >= 0; i -= 1) {
      if (points[i] === null) continue;
      marks.push({ x: points[i].x, y: points[i].y, color: line.color, text: line.lastLabel });
      break;
    }
  }

  for (const mark of marks) {
    parts.push(
      '<circle class="db-point db-s' + mark.color + '" cx="' + chartNum_(mark.x) + '" cy="' + chartNum_(mark.y) +
        '" r="4" fill="currentColor" stroke="var(--db-card)" stroke-width="2" />'
    );
  }
  for (const mark of chartLineLabels_(marks)) {
    parts.push(chartText_("db-mark-label", mark.x + CHART_MARK_OFFSET_, mark.y + CHART_CLEAR_, "start", mark.text));
  }

  parts.push(
    '<line class="db-crosshair" x1="' + chartNum_(box.left) + '" y1="' + chartNum_(box.top) + '" x2="' + chartNum_(box.left) +
      '" y2="' + chartNum_(box.bottom) + '" visibility="hidden" />'
  );
  parts.push(chartLineBands_(model, box, xAt, band, lang));

  const legend = model.legend === true ? chartLegend_(model.series.map((line) => ({ label: line.label, color: line.color })), "line") : "";
  return chartFrame_(model.title, parts.join(""), legend);
}

// ---- bar ------------------------------------------------------------------

/** 0 の線から上（右）へ積む面と、下（左）へ積む面に分ける */
function chartBarStacks_(category) {
  const positive = [];
  const negative = [];
  for (const segment of category.segments) {
    if (!chartIsNumber_(segment.value) || segment.value === 0) continue;
    (segment.value > 0 ? positive : negative).push(segment);
  }
  return { positive, negative };
}

/**
 * 棒の余白と、図の高さ。目盛りの札・区分名・先端の札が、どれも切れない幅をとる。
 *
 * 横棒は区分が増えるほど縦に伸ばす（1 区分あたり 28px）。詰め込むと棒も区分名も
 * つぶれてしまうため。縦棒は 640×280 のまま。
 * 縦棒で負の側があるときは、先端の札が 0 の線より下に出るので、区分名の行とぶつからないよう
 * 1 行ぶん余分に空けておく（区分名はいつも図の下の 1 行 labelY に置く）
 */
function chartBarBox_(model, lang) {
  const tickLabels = model.ticks.map((tick) => chartTickText_(tick, model.format, lang));

  if (model.horizontal === true) {
    const count = Math.max(1, model.categories.length);
    const height = Math.max(CHART_HEIGHT_, CHART_ROW_TOP_ + CHART_TEXT_ROW_ + CHART_PAD_ + count * CHART_ROW_PITCH_);
    let left = CHART_PAD_;
    let right = CHART_PAD_;
    for (const category of model.categories) {
      left = Math.max(left, estimateTextWidth(category.label, CHART_FONT_) + CHART_TICK_GAP_);
      right = Math.max(right, estimateTextWidth(category.totalText, CHART_FONT_) + CHART_MARK_GAP_);
    }
    const half = tickLabels.length > 0 ? estimateTextWidth(tickLabels[tickLabels.length - 1], CHART_FONT_) / 2 + CHART_CLEAR_ : 0;
    return {
      left: Math.min(left, CHART_LEFT_MAX_),
      right: CHART_WIDTH_ - Math.min(Math.max(right, half), CHART_BAR_RIGHT_MAX_),
      top: CHART_ROW_TOP_,
      bottom: height - CHART_TEXT_ROW_ - CHART_PAD_,
      labelY: height - CHART_EDGE_,
      height,
    };
  }

  let left = CHART_PAD_;
  for (const label of tickLabels) left = Math.max(left, estimateTextWidth(label, CHART_FONT_) + CHART_TICK_GAP_);
  const labelY = CHART_HEIGHT_ - CHART_EDGE_;
  const belowZero = model.min < 0 ? CHART_TEXT_ROW_ + CHART_CLEAR_ : 0;
  return {
    left,
    right: CHART_WIDTH_ - CHART_PAD_,
    top: CHART_TEXT_ROW_ + CHART_CLEAR_,
    bottom: labelY - CHART_TEXT_ROW_ - CHART_CLEAR_ - belowZero,
    labelY,
    height: CHART_HEIGHT_,
  };
}

/**
 * 面を 1 つ描く。値の側だけを丸め、根元は四角のまま。内側の面は値の側を 2px 削って、
 * 隣り合う面のあいだに地色のすき間を作る（枠線では区切らない）
 */
function chartBarSegment_(segment, geometry) {
  const outer = geometry.outer;
  const radius = outer ? CHART_BAR_RADIUS_ : 0;
  const gap = outer ? 0 : CHART_BAR_GAP_;

  if (geometry.horizontal) {
    const length = geometry.toward > 0 ? geometry.to - gap - geometry.from : geometry.from - (geometry.to + gap);
    if (length <= 0.5) return "";
    const x = geometry.toward > 0 ? geometry.from : geometry.to + gap;
    const d = roundedBar({ x, y: geometry.center - geometry.thickness / 2, width: length, height: geometry.thickness, radius, side: geometry.toward > 0 ? "right" : "left" });
    return '<path class="db-bar db-s' + segment.color + '" d="' + d + '" fill="currentColor" />';
  }

  const length = geometry.toward > 0 ? geometry.from - (geometry.to + gap) : geometry.to - gap - geometry.from;
  if (length <= 0.5) return "";
  const y = geometry.toward > 0 ? geometry.to + gap : geometry.from;
  const d = roundedBar({ x: geometry.center - geometry.thickness / 2, y, width: geometry.thickness, height: length, radius, side: geometry.toward > 0 ? "top" : "bottom" });
  return '<path class="db-bar db-s' + segment.color + '" d="' + d + '" fill="currentColor" />';
}

/** 区分 1 つぶんの面をすべて描く（正の側を根元から外へ、そのあと負の側） */
function chartBarStack_(category, scale, center, thickness, horizontal) {
  const { positive, negative } = chartBarStacks_(category);
  const parts = [];
  for (const [segments, toward] of [[positive, 1], [negative, -1]]) {
    let cumulative = 0;
    segments.forEach((segment, index) => {
      const from = scale(cumulative);
      cumulative += segment.value;
      const to = scale(cumulative);
      parts.push(
        chartBarSegment_(segment, { from, to, center, thickness, horizontal, toward, outer: index === segments.length - 1 })
      );
    });
  }
  return parts.join("");
}

/**
 * 先端の札を置く値（正味の符号の側の、積み上げの先）。
 * 正と負の面が混ざる区分は null にして札を置かない。どちらの先端に置いても、
 * 見た目の高さと数が食い違って「合計」に読めないため（正味・内わけは吹き出しと表が受け持つ）
 */
function chartBarEnd_(category) {
  if (category.posTotal > 0 && category.negTotal < 0) return null;
  const total = chartIsNumber_(category.total) ? category.total : 0;
  const end = total < 0 ? category.negTotal : category.posTotal;
  return chartIsNumber_(end) && end !== 0 ? end : null;
}

/** 先端の札（合計）。収まるときだけ棒の外に出し、収まらないときは置かない（切らない） */
function chartBarTotal_(category, scale, center, horizontal) {
  const end = chartBarEnd_(category);
  if (end === null) return "";
  const width = estimateTextWidth(category.totalText, CHART_FONT_);
  const at = scale(end);

  if (horizontal) {
    if (end < 0) {
      const x = at - CHART_MARK_OFFSET_;
      return x - width < CHART_CLEAR_ ? "" : chartText_("db-mark-label", x, center + CHART_CLEAR_, "end", category.totalText);
    }
    const x = at + CHART_MARK_OFFSET_;
    return x + width > CHART_WIDTH_ - CHART_CLEAR_ ? "" : chartText_("db-mark-label", x, center + CHART_CLEAR_, "start", category.totalText);
  }

  if (center - width / 2 < CHART_CLEAR_ || center + width / 2 > CHART_WIDTH_ - CHART_CLEAR_) return "";
  // 下に出す札の場所は chartBarBox_ が先に空けてあるので、ここでは高さを気にしなくてよい
  if (end < 0) return chartText_("db-mark-label", center, at + CHART_MARK_GAP_, "middle", category.totalText);
  const y = at - CHART_MARK_LIFT_;
  return y < CHART_PAD_ ? "" : chartText_("db-mark-label", center, y, "middle", category.totalText);
}

/**
 * 先端の札を出す区分を決める。隣り合う札が近づきすぎると、どの棒の数か分からなくなるので、
 * 近すぎる組が 1 つでもあれば、いちばん大きい正の合計と、いちばん小さい負の合計だけを残す
 * （残りの数は吹き出しと「表で見る」で読める）。gapOf は隣り合う 2 つの札のすき間を返す
 */
function chartBarLabelKeep_(categories, marks, gapOf) {
  const keep = new Set();
  let crowded = false;
  for (let i = 1; i < marks.length; i += 1) {
    if (gapOf(marks[i - 1], marks[i]) < CHART_LABEL_NEAR_) {
      crowded = true;
      break;
    }
  }
  if (!crowded) {
    for (const mark of marks) keep.add(mark.index);
    return keep;
  }

  let highest = null;
  let lowest = null;
  for (const mark of marks) {
    const total = categories[mark.index].total;
    if (!chartIsNumber_(total)) continue;
    if (total > 0 && (highest === null || total > categories[highest].total)) highest = mark.index;
    if (total < 0 && (lowest === null || total < categories[lowest].total)) lowest = mark.index;
  }
  if (highest !== null) keep.add(highest);
  if (lowest !== null) keep.add(lowest);
  return keep;
}

/**
 * 区分 1 つぶんの吹き出し。面をすべて並べ、積み上げのときは正味の合計も添える。
 * 0 をまたぐ区分（正と負の面が混ざる区分）は先端の札を持たないので、
 * 正味の合計をここと「表で見る」で必ず読めるようにしておく
 */
function chartBarTip_(category, lang) {
  const rows = category.segments.map((segment) => ({ label: segment.label, value: segment.valueText, color: segment.color }));
  if (category.segments.length > 1) rows.push({ label: t(lang, "label.total"), value: category.totalText, color: null });
  return tipAttrs({ title: category.label, rows }, lang);
}

/**
 * 縦棒の区分名。帯に収まるところまで幅で短くし（全角 4 字 + 「…」は必ず残す）、
 * それも置けないときや、短くした名前が互いに同じ形になってしまうときは、
 * 1 つ飛ばし・2 つ飛ばしと間引いて場所を広げる。
 * 「みなと市中…」ばかりを並べるより、間引いて読める名前を残すほうが分かりやすい
 * （どの棒の値も、吹き出しと「表で見る」では名前つきで読める）
 */
function chartBarNames_(labels, band) {
  const count = labels.length;
  for (let step = 1; step <= count; step += 1) {
    const room = band * step - CHART_CLEAR_;
    const picked = [];
    const seen = new Set();
    let placed = true;
    for (let index = 0; index < count; index += step) {
      const text = chartFitLabel_(labels[index], room);
      if (text === "" || seen.has(text)) {
        placed = false;
        break;
      }
      seen.add(text);
      picked.push({ index, text });
    }
    if (placed) return picked;
  }
  return [];
}

/** 区分ごとの大きさ。横棒のときは区分名を左に、縦棒のときは下に置く */
export function renderBar(model, state, lang) {
  if (model.empty === true || model.categories.length === 0) return renderEmptyNote(lang);

  const horizontal = model.horizontal === true;
  const box = chartBarBox_(model, lang);
  const count = model.categories.length;
  const along = horizontal ? box.bottom - box.top : box.right - box.left;
  const band = along / count;
  const thickness = Math.max(2, Math.min(CHART_BAR_MAX_, band - CHART_BAR_GAP_));
  const scale = horizontal
    ? scaleLinear([model.min, model.max], [box.left, box.right])
    : scaleLinear([model.min, model.max], [box.bottom, box.top]);
  const centerAt = (index) => (horizontal ? box.top : box.left) + band * (index + 0.5);

  const parts = [chartGrid_(model.ticks, scale, box, !horizontal, model.format, lang, horizontal)];

  // 区分名は、どの棒がどれか分かるように全部に付ける。収まらない名前は幅で短くし、
  // それでも置けないほど込み合うときだけ間引く（元の名前は吹き出しと「表で見る」に残る）
  const names = model.categories.map((category) => category.label);
  if (horizontal) {
    names.forEach((name, index) => {
      const text = chartFitLabel_(name, box.left - CHART_TICK_GAP_);
      if (text !== "") parts.push(chartText_("db-y-label", box.left - CHART_MARK_OFFSET_, centerAt(index) + CHART_CLEAR_, "end", text));
    });
  } else {
    for (const name of chartBarNames_(names, band)) {
      parts.push(chartText_("db-x-label", centerAt(name.index), box.labelY, "middle", name.text));
    }
  }

  model.categories.forEach((category, index) => {
    parts.push(chartBarStack_(category, scale, centerAt(index), thickness, horizontal));
  });

  // 先端の札は、隣どうしが近づきすぎないところまで
  const marks = [];
  model.categories.forEach((category, index) => {
    if (chartBarEnd_(category) === null) return;
    marks.push({ index, center: centerAt(index), width: estimateTextWidth(category.totalText, CHART_FONT_) });
  });
  const keep = chartBarLabelKeep_(
    model.categories,
    marks,
    horizontal
      ? (a, b) => b.center - a.center - CHART_TEXT_ROW_
      : (a, b) => b.center - b.width / 2 - (a.center + a.width / 2)
  );
  model.categories.forEach((category, index) => {
    if (keep.has(index)) parts.push(chartBarTotal_(category, scale, centerAt(index), horizontal));
  });

  // 当たり判定は見た目より広く、帯の幅いっぱいにとる
  model.categories.forEach((category, index) => {
    const start = (horizontal ? box.top : box.left) + band * index;
    const rect = horizontal
      ? 'x="' + chartNum_(box.left) + '" y="' + chartNum_(start) + '" width="' + chartNum_(box.right - box.left) + '" height="' + chartNum_(band) + '"'
      : 'x="' + chartNum_(start) + '" y="' + chartNum_(box.top) + '" width="' + chartNum_(band) + '" height="' + chartNum_(box.bottom - box.top) + '"';
    parts.push('<rect class="db-hit" ' + rect + ' data-category="' + index + '"' + chartBarTip_(category, lang) + " />");
  });

  const legendItems = model.categories[0].segments.map((segment) => ({ label: segment.label, color: segment.color }));
  return chartFrame_(model.title, parts.join(""), model.legend === true ? chartLegend_(legendItems, "bar") : "", box.height);
}

// ---- meter ----------------------------------------------------------------

/** 目標に対する進み。帯は同じ色の薄い段で、100% を超えても帯からはみ出させない */
export function renderMeter(model, state, lang) {
  const ratio = chartIsNumber_(model.ratio) ? model.ratio : 0;
  const width = chartNum_(clamp(Math.round(ratio * 1000) / 10, 0, 100));
  // 月から引いた目標のときは、どの月の数字なのかを値のとなりと吹き出しに添える
  const monthLabel = model.monthLabel === null || model.monthLabel === undefined ? "" : String(model.monthLabel);
  const month = monthLabel === "" ? "" : '<span class="db-meter-month">' + escapeHtml(monthLabel) + "</span>";
  const rows = (monthLabel === "" ? [] : [{ label: t(lang, "label.targetMonth"), value: monthLabel, color: null }]).concat([
    { label: t(lang, "label.actual"), value: model.valueFull, color: null },
    { label: t(lang, "label.goal"), value: model.targetFull, color: null },
    { label: t(lang, "label.progress"), value: model.ratioText, color: null },
  ]);
  const foot = model.achieved === true
    ? '<span class="db-meter-reached">' + escapeHtml(t(lang, "label.goalReached")) + "</span>"
    : "";

  return (
    '<div class="db-meter">' +
    '<p class="db-meter-head"><span class="db-meter-value">' + escapeHtml(model.valueText) + "</span>" +
    '<span class="db-meter-sep" aria-hidden="true">/</span>' +
    '<span class="db-meter-target">' + escapeHtml(model.targetText) + "</span>" + month + "</p>" +
    '<div class="db-meter-track"' + tipAttrs({ title: model.title, rows }, lang) + '>' +
    '<div class="db-meter-fill" style="width: ' + width + '%"></div></div>' +
    '<p class="db-meter-foot">' + foot + '<span class="db-meter-ratio">' + escapeHtml(model.ratioText) + "</span></p>" +
    "</div>"
  );
}
