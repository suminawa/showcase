/**
 * スプレッドシート版の読み口。同じスプレッドシートのサーバー側（api_bootstrap）を 1 回だけ呼び、
 * 返ってきた設定（そろえる前の raw）とシートの行を、そのまま画面へ渡す。
 *
 * 外へは一度も取りに行かない（見ている人の権限でスプレッドシートを読むだけ）。
 * サーバーが読めなかったときは、あたりさわりのない 1 文だけを画面に伝え、
 * もとの理由は実行ログに残す。
 *
 * その 1 文の言語は、サーバーが文を返してきたらそれをそのまま使う（`設定` の「言語」で
 * 決まる）。通信そのものが届かず、サーバーの文が無いときだけ、ブラウザの言語で決める。
 */

import { textOf } from "../core/text.js";
import { t } from "../core/i18n.js";

/** 呼び出しの入口。試すときは env.google に差し替えたものを渡せる */
function sourceGasRunner_(env) {
  const holder = env !== null && typeof env === "object" && env.google ? env.google : typeof google === "undefined" ? null : google;
  const script = holder && holder.script ? holder.script : null;
  return script && script.run ? script.run : null;
}

/** もとの理由を実行ログにだけ残す */
function sourceGasLog_(env, error) {
  const log = env && env.console ? env.console : typeof console === "undefined" ? null : console;
  if (log && typeof log.error === "function") log.error(error);
}

/**
 * サーバーの文が無いときに使う言語。ブラウザの言語が読めないとき・日本語のときは ja、
 * それ以外は en（`設定` の「言語」はサーバーが読めたときだけ分かるので、ここでは使えない）
 */
function sourceGasLang_(env) {
  const holder = env !== null && typeof env === "object" && env.navigator ? env.navigator : typeof navigator === "undefined" ? null : navigator;
  const tag = holder ? textOf(holder.language).toLowerCase() : "";
  return tag === "" || tag === "ja" || tag.startsWith("ja-") ? "ja" : "en";
}

/**
 * 画面にそのまま出してよい知らせを持つ失敗にする。dashboardMessage が付いている誤りだけを、
 * 画面（main.js）はそのまま出す（付いていない誤りは、あたりさわりのない既定の 1 文になる）
 */
function sourceGasFailure_(message) {
  const error = new Error(message);
  error.dashboardMessage = message;
  return error;
}

/**
 * スプレッドシートから読む読み口を作る。options は { env }。
 * load() は { config（そのままの設定）, datasets, missing, truncated } を返す。
 * datasets は シート名 → 見出し行つきの行列。
 *
 * 行数が上限を超えていたシートは、サーバーが上限より 1 行だけ多く渡してくる。
 * その 1 行は画面が上限で切り落とし、「20,000 行までを表示しています」の知らせになる
 * （truncated にもそのシートの名前が入る）
 */
export function sourceGasCreate_(options) {
  const opts = options && typeof options === "object" ? options : {};
  const env = opts.env && typeof opts.env === "object" ? opts.env : {};

  return {
    load() {
      const lang = sourceGasLang_(env);
      return new Promise((resolve, reject) => {
        const run = sourceGasRunner_(env);
        if (run === null) {
          reject(sourceGasFailure_(t(lang, "state.unavailable")));
          return;
        }

        run
          .withSuccessHandler((result) => {
            if (result === null || typeof result !== "object" || result.ok !== true) {
              // サーバーが文を返してきたら、その言語のまま使う（`設定` の「言語」で決まっている）
              const message = result !== null && typeof result === "object" ? textOf(result.message) : "";
              reject(sourceGasFailure_(message === "" ? t(lang, "state.unavailable") : message));
              return;
            }
            resolve({
              config: result.config,
              datasets: result.datasets && typeof result.datasets === "object" ? result.datasets : {},
              missing: Array.isArray(result.missing) ? result.missing : [],
              truncated: Array.isArray(result.truncated) ? result.truncated : [],
            });
          })
          .withFailureHandler((error) => {
            sourceGasLog_(env, error);
            reject(sourceGasFailure_(t(lang, "state.unavailable")));
          })
          .api_bootstrap();
      });
    },
  };
}
