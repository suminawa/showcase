/**
 * 置いたページから設定とデータを取りに行く読み口。設定（JSON）と、データセットごとの
 * CSV / JSON を取りに行き、そのままの中身を返す。検査も集計もここでは行わない。
 *
 * 取りに行ってよい置き場所は、設定の検査と同じ決まり（isAllowedDataUrl）で見分ける
 * （https の URL か、同じ置き場所からの相対の道すじ）。決まりは設定の側の 1 か所にある。
 * 取ってきた中身は cacheMinutes のあいだ、その場かぎりの覚え書き（sessionStorage）に置く。
 * 覚え書きは使えないことがある（人の設定で切ってあるなど）ので、どの出し入れも
 * うまくいかなければ黙って見送り、取りに行くほうで進める。
 */

import { textOf, hasOwn } from "../core/text.js";
import { parseConfig, isAllowedDataUrl } from "../core/config.js";
import { parseCsv } from "../core/csv.js";

/** 覚え書きの鍵の頭。ほかの置き物と混ざらないようにする */
const SOURCE_WEB_CACHE_PREFIX_ = "dbkit:";
/** これより大きい中身は覚えない（入れ物があふれて、ほかの覚え書きまで消えてしまうため） */
const SOURCE_WEB_CACHE_MAX_ = 2 * 1024 * 1024;
/** JSON として読む置き場所の見分け */
const SOURCE_WEB_JSON_PATH_ = /\.json$/i;
const SOURCE_WEB_JSON_TYPE_ = /\bjson\b/i;

/** 置き場所と中身の種類から、JSON として読むかを決める（それ以外は CSV） */
function sourceWebIsJson_(url, contentType) {
  if (SOURCE_WEB_JSON_TYPE_.test(contentType)) return true;
  const path = String(url).split("#")[0].split("?")[0];
  return SOURCE_WEB_JSON_PATH_.test(path);
}

/**
 * 覚え書きの鍵。相対の道すじ（./sales.csv）は、置いたページの場所を足して 1 本の URL に伸ばす。
 * 伸ばさずに使うと、/ja/ と /en/ のように別の場所に置いた同じ名前のデータが、
 * 同じ鍵になって取り違えられてしまう。伸ばせないところでは、書かれたままを鍵にする
 */
function sourceWebCacheKey_(env, url) {
  const base = env && env.location ? textOf(env.location.href) : "";
  try {
    return SOURCE_WEB_CACHE_PREFIX_ + new URL(url, base === "" ? undefined : base).href;
  } catch {
    return SOURCE_WEB_CACHE_PREFIX_ + url;
  }
}

/** 覚え書きから、まだ新しい中身を取り出す。使えないとき・古いときは null */
function sourceWebCacheRead_(env, url, minutes) {
  if (!(minutes > 0)) return null;
  try {
    const store = env.sessionStorage;
    if (!store || typeof store.getItem !== "function") return null;
    const saved = store.getItem(sourceWebCacheKey_(env, url));
    if (typeof saved !== "string" || saved === "") return null;
    const entry = JSON.parse(saved);
    if (!entry || typeof entry.body !== "string") return null;
    const at = Number(entry.at);
    const nowMs = env.now().getTime();
    if (!Number.isFinite(at) || nowMs < at || nowMs - at > minutes * 60000) return null;
    return { ok: true, text: entry.body, contentType: textOf(entry.type) };
  } catch {
    return null;
  }
}

/** 取ってきた中身を覚え書きに置く。入れ物が使えないときは、覚えずに進む */
function sourceWebCacheWrite_(env, url, got, minutes) {
  if (!(minutes > 0) || got.text.length > SOURCE_WEB_CACHE_MAX_) return;
  try {
    const store = env.sessionStorage;
    if (!store || typeof store.setItem !== "function") return;
    store.setItem(sourceWebCacheKey_(env, url), JSON.stringify({ at: env.now().getTime(), body: got.text, type: got.contentType }));
  } catch {
    // 覚え書きが使えないときは、次も取りに行けばよいので何もしない
  }
}

/** 1 か所を取りに行く。返事が 200 でなければ ok: false にする */
function sourceWebFetch_(env, url) {
  const get = env && typeof env.fetch === "function" ? env.fetch : null;
  if (!get) return Promise.reject(new Error("dashboard: データを取りに行けません"));
  return Promise.resolve(get(url, { credentials: "same-origin" })).then((response) => {
    if (!response || response.ok !== true) return { ok: false, text: "", contentType: "" };
    const headers = response.headers;
    const contentType = headers && typeof headers.get === "function" ? textOf(headers.get("content-type")) : "";
    return Promise.resolve(response.text()).then((text) => ({ ok: true, text: typeof text === "string" ? text : "", contentType }));
  });
}

/** 覚え書きを見てから取りに行く。fresh のときは覚え書きを読み飛ばす */
function sourceWebRead_(env, url, minutes, fresh) {
  if (fresh !== true) {
    const saved = sourceWebCacheRead_(env, url, minutes);
    if (saved !== null) return Promise.resolve(saved);
  }
  return sourceWebFetch_(env, url).then(
    (got) => {
      if (got.ok) sourceWebCacheWrite_(env, url, got, minutes);
      return got;
    },
    () => ({ ok: false, text: "", contentType: "" })
  );
}

/**
 * 取ってきた中身を行の形にする。JSON は配列（オブジェクトの並びか、見出し行つきの行列）、
 * それ以外は CSV として読む。配列にならない JSON は読めなかったことにする
 */
function sourceWebRows_(got, url) {
  if (!sourceWebIsJson_(url, got.contentType)) return parseCsv(got.text);
  try {
    const parsed = JSON.parse(got.text);
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/** 設定そのものを用意する。オブジェクトならそのまま、文字なら取りに行って JSON として読む */
function sourceWebRawConfig_(env, config, fresh) {
  if (config !== null && typeof config === "object") return Promise.resolve(config);
  const url = textOf(config);
  if (!isAllowedDataUrl(url)) {
    return Promise.reject(new Error("dashboard: 設定の置き場所をご確認ください"));
  }
  return sourceWebRead_(env, url, 0, fresh).then((got) => {
    if (!got.ok) throw new Error("dashboard: 設定を取り込めませんでした");
    return JSON.parse(got.text);
  });
}

/**
 * 取りに行く読み口を作る。options は { config, data, env }。
 * config はそろっていないままの設定（オブジェクト）か、その置き場所（文字）。
 * data に渡した行は取りに行かずにそのまま使う。
 * load() は { config（そのままの設定）, datasets, missing } を返す
 */
export function sourceWebCreate_(options) {
  const opts = options && typeof options === "object" ? options : {};
  const env = opts.env && typeof opts.env === "object" ? opts.env : {};
  const inline = opts.data && typeof opts.data === "object" ? opts.data : null;

  return {
    load(loadOptions) {
      const fresh = loadOptions !== null && typeof loadOptions === "object" && loadOptions.fresh === true;
      return sourceWebRawConfig_(env, opts.config, fresh).then((raw) => {
        const parsed = parseConfig(raw);
        const minutes = Number(parsed.config.cacheMinutes);
        const datasets = Object.create(null);
        const missing = [];

        const jobs = Object.keys(parsed.config.datasets).map((name) => {
          if (inline !== null && hasOwn(inline, name)) {
            datasets[name] = inline[name];
            return Promise.resolve();
          }
          const url = textOf(parsed.config.datasets[name].url);
          // 取りに行ってよい置き場所かを、取りに行く直前にここでも必ず確かめる
          // （設定の検査を通らない道すじ── source: "sheets" の設定など──から来た url も止める）。
          // 空の url は「指定なし」なので、同じくここでは取りに行かない
          if (!isAllowedDataUrl(url)) {
            missing.push(name);
            return Promise.resolve();
          }
          return sourceWebRead_(env, url, minutes, fresh).then((got) => {
            const rows = got.ok ? sourceWebRows_(got, url) : null;
            if (rows === null) missing.push(name);
            else datasets[name] = rows;
          });
        });

        return Promise.all(jobs).then(() => ({ config: raw, datasets, missing }));
      });
    },
  };
}
