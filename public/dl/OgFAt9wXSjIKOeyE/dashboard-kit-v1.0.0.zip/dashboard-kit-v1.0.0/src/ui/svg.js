/**
 * グラフの形を作る小道具。座標の移し替え・線と面の道すじ・角丸の棒・印に添える目じるし。
 * 文字列を組み立てるだけで、画面には触れない（ここも純粋な計算だけを行う）。
 * 字の幅の見積もりは model と分け合うので、src/core/text.js の estimateTextWidth を使う。
 */

import { escapeAttr } from "../core/text.js";

/** 道すじの数は小数 2 桁まで（長い小数で道すじが読みにくくならないように） */
function svgNum_(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) return "0";
  return String(Math.round(num * 100) / 100);
}

/**
 * 値の範囲 domain を、描く範囲 range に移す関数を作る。
 * domain の幅が 0（値がすべて同じ）のときは range の始まりに寄せる
 */
export function scaleLinear(domain, range) {
  const d0 = Number(domain[0]);
  const d1 = Number(domain[1]);
  const r0 = Number(range[0]);
  const r1 = Number(range[1]);
  const span = d1 - d0;
  if (span === 0) return () => r0;
  return (value) => r0 + ((Number(value) - d0) / span) * (r1 - r0);
}

/** 続いている点のかたまりに切り分ける（読めない値は null で渡し、そこで線を切る） */
function svgRuns_(points) {
  const list = Array.isArray(points) ? points : [];
  const runs = [];
  let run = [];
  for (const point of list) {
    if (point === null || point === undefined) {
      if (run.length > 0) runs.push(run);
      run = [];
      continue;
    }
    run.push(point);
  }
  if (run.length > 0) runs.push(run);
  return runs;
}

/**
 * 折れ線の道すじ。読めない値のところで線を切り、次のかたまりを新しい M から始める
 * （間を勝手につながない）。点が 1 つだけのかたまりは、丸い継ぎ目の点として残す
 */
export function linePath(points) {
  const parts = [];
  for (const run of svgRuns_(points)) {
    const steps = run.map((point) => svgNum_(point.x) + " " + svgNum_(point.y));
    // 点が 1 つだけのときも、同じ場所へ L を引いて丸い点として見えるようにする
    if (steps.length === 1) steps.push(steps[0]);
    parts.push("M " + steps[0] + " L " + steps.slice(1).join(" L "));
  }
  return parts.join(" ");
}

/** 1 系列のときに敷く面の道すじ。線の下を baseY（0 の線）まで落として閉じる */
export function areaPath(points, baseY) {
  const base = svgNum_(baseY);
  const parts = [];
  for (const run of svgRuns_(points)) {
    const steps = run.map((point) => "L " + svgNum_(point.x) + " " + svgNum_(point.y));
    parts.push("M " + svgNum_(run[0].x) + " " + base + " " + steps.join(" ") + " L " + svgNum_(run[run.length - 1].x) + " " + base + " Z");
  }
  return parts.join(" ");
}

/**
 * 棒 1 本（積み上げの面 1 つ）の道すじ。値の側（side: "top" "bottom" "left" "right"）の
 * 2 つの角だけを radius で丸め、根元は四角のままにする。radius が 0 のときは丸みの命令を書かない。
 * 角丸は棒の半分までに収める（低い棒・細い棒でも形がくずれないように）
 */
export function roundedBar(options) {
  const opts = options || {};
  const x = Number(opts.x) || 0;
  const y = Number(opts.y) || 0;
  const width = Number(opts.width) || 0;
  const height = Number(opts.height) || 0;
  const side = opts.side;
  const r = Math.max(0, Math.min(Number(opts.radius) || 0, width / 2, height / 2));

  const x2 = x + width;
  const y2 = y + height;
  const n = svgNum_;
  const arc = (sweep, ax, ay) => "A " + n(r) + " " + n(r) + " 0 0 " + sweep + " " + n(ax) + " " + n(ay);

  if (side === "bottom") {
    if (r === 0) return "M " + n(x) + " " + n(y) + " L " + n(x) + " " + n(y2) + " L " + n(x2) + " " + n(y2) + " L " + n(x2) + " " + n(y) + " Z";
    return (
      "M " + n(x) + " " + n(y) + " L " + n(x) + " " + n(y2 - r) + " " + arc(0, x + r, y2) +
      " L " + n(x2 - r) + " " + n(y2) + " " + arc(0, x2, y2 - r) + " L " + n(x2) + " " + n(y) + " Z"
    );
  }
  if (side === "left") {
    if (r === 0) return "M " + n(x2) + " " + n(y) + " L " + n(x) + " " + n(y) + " L " + n(x) + " " + n(y2) + " L " + n(x2) + " " + n(y2) + " Z";
    return (
      "M " + n(x2) + " " + n(y) + " L " + n(x + r) + " " + n(y) + " " + arc(0, x, y + r) +
      " L " + n(x) + " " + n(y2 - r) + " " + arc(0, x + r, y2) + " L " + n(x2) + " " + n(y2) + " Z"
    );
  }
  if (side === "right") {
    if (r === 0) return "M " + n(x) + " " + n(y) + " L " + n(x2) + " " + n(y) + " L " + n(x2) + " " + n(y2) + " L " + n(x) + " " + n(y2) + " Z";
    return (
      "M " + n(x) + " " + n(y) + " L " + n(x2 - r) + " " + n(y) + " " + arc(1, x2, y + r) +
      " L " + n(x2) + " " + n(y2 - r) + " " + arc(1, x2 - r, y2) + " L " + n(x) + " " + n(y2) + " Z"
    );
  }
  // 既定は上（縦の棒の、正の値の側）
  if (r === 0) return "M " + n(x) + " " + n(y2) + " L " + n(x) + " " + n(y) + " L " + n(x2) + " " + n(y) + " L " + n(x2) + " " + n(y2) + " Z";
  return (
    "M " + n(x) + " " + n(y2) + " L " + n(x) + " " + n(y + r) + " " + arc(1, x + r, y) +
    " L " + n(x2 - r) + " " + n(y) + " " + arc(1, x2, y + r) + " L " + n(x2) + " " + n(y2) + " Z"
  );
}

/** 吹き出しの中身を読み上げ用の 1 行にする（見える値と同じことを、字だけで伝える） */
function svgTipSpeech_(tip, lang) {
  const separator = lang === "en" ? ", " : "、";
  const parts = tip.title === "" ? [] : [tip.title];
  for (const row of tip.rows) parts.push(row.label === "" ? row.value : row.label + " " + row.value);
  return parts.join(separator);
}

/**
 * 図の中の印（棒・折れ線の帯・目標の帯）に添える目じるし。吹き出しの中身（JSON）と、
 * キーボードの focus、読み上げ用の同じ中身を 1 組で付ける。
 * 使うのは図の印だけにする。表の行に付けると、行が 1 つの図として読まれてしまい、
 * マスと列の組み合わせを読み上げでたどれなくなるため。
 * tip は { title, rows: [{ label, value, color }] }（color は系列の番号、無ければ null）
 */
export function tipAttrs(tip, lang) {
  const safe = { title: tip && tip.title ? String(tip.title) : "", rows: tip && Array.isArray(tip.rows) ? tip.rows : [] };
  const rows = safe.rows.map((row) => ({
    label: String(row.label === null || row.label === undefined ? "" : row.label),
    value: String(row.value === null || row.value === undefined ? "" : row.value),
    color: Number.isInteger(row.color) ? row.color : null,
  }));
  const payload = JSON.stringify({ title: safe.title, rows });
  return ' data-tip="' + escapeAttr(payload) + '" tabindex="0" role="img" aria-label="' + escapeAttr(svgTipSpeech_({ title: safe.title, rows }, lang)) + '"';
}
