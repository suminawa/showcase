/**
 * 画面を組み立てて動かす入口。設定とデータを読み、描く形（model）を組み立て、文字列にして
 * 置き場所に差し込み、操作（絞り込み・表で見る・並べ替え・吹き出し・CSV）をつなぐ。
 *
 * ブラウザの道具（画面・窓・住所・履歴・その場かぎりの覚え書き・取り込み・いまの日）は
 * mainEnv_() の 1 か所だけから受け取る。数の計算も書式づくりもここでは行わず、
 * core と render が決めたものを置くだけにしてある。
 */

import { textOf, hasOwn, setOwn, isBlankRow } from "../core/text.js";
import { pad2, isDateKey } from "../core/dates.js";
import { parseConfig } from "../core/config.js";
import { t } from "../core/i18n.js";
import { rowsToObjects, toCsv } from "../core/csv.js";
import { TABLE_ROW_LIMIT_, inferTypes, coerceRows, limitRows } from "../core/table.js";
import { decodeFilters, encodeFilters, dimensionOptions } from "../core/filter.js";
import { buildDashboard } from "../core/model.js";
import { initialState, reduce, filtersDiffer } from "./state.js";
import { renderDashboard } from "./render.js";
import { sourceWebCreate_ } from "./source-web.js";
import { sourceMemoryCreate_ } from "./source-memory.js";

/** root に委ねる出来事。どれも root に 1 つずつ付け、destroy() で外す */
const MAIN_EVENTS_ = [
  "change",
  "click",
  "submit",
  "pointerdown",
  "pointermove",
  "pointerup",
  "pointercancel",
  "pointerleave",
  "focusin",
  "focusout",
  "keydown",
];
/** 押して画面が変わる操作。select や日付の入力は click では見ない */
const MAIN_CLICK_ACTIONS_ = ["reset", "toggle-table", "sort", "download-csv"];
/** 指やペンでの操作。マウスと違い、触れているあいだだけ位置が分かる */
const MAIN_TOUCH_POINTERS_ = ["touch", "pen"];
/** 吹き出しを、指や印からどれだけ離して置くか */
const MAIN_TIP_GAP_ = 14;
/** 吹き出しを、画面の端からどれだけ内がわに収めるか */
const MAIN_TIP_EDGE_ = 8;
/** 操作していた要素の手がかりを 1 本の文字にするときの区切り（番号で書く。生の制御文字は置かない） */
const MAIN_FOCUS_SEP_ = "\u001f";
/** URL の # に付ける頭の決まり（買い手が hash: "売上" のように変えられる） */
const MAIN_HASH_PREFIX_ = "db";
/** 頭として受け取ってよい形。ここに外れた指定は既定の頭に戻す */
const MAIN_HASH_PREFIX_PATTERN_ = /^[a-z0-9_-]{1,20}$/;
/** 書き出した CSV の置き場所を手放すまでの間（ミリ秒） */
const MAIN_REVOKE_DELAY_ = 1000;
/**
 * ファイル名に使えない字（入れ替えて落とす）。制御文字は番号で書く。
 * 生の制御文字をそのまま置くと、<script> に差し込んだときに HTML の読み手が
 * 別の字に置き換えてしまい、字の並びが逆さまになって 1 本ぜんたいが動かなくなる
 */
const MAIN_FILE_UNSAFE_ = /[\\/:*?"<>|\x00-\x1f]/g;
/** 見た目の選び方 */
const MAIN_THEMES_ = ["auto", "light", "dark"];

/** テストのときだけ差し替える、ブラウザの道具の置き換え（ふだんは null） */
let mainEnvironment_ = null;

/**
 * 置き場所ごとの、いま生きているダッシュボード。同じ置き場所にもう一度組み立てるときは、
 * 先にいたほうを片づけてから組み立てる（listener が二重に付いて、操作が 2 回効くのを防ぐ）
 */
const MAIN_INSTANCES_ = new WeakMap();

/**
 * ブラウザの道具をひとまとめにして返す。ここだけがブラウザの中身に触れる。
 * 取り出せないもの（覚え書きを切ってある窓など）は null にして、呼ぶ側で見分けられるようにする
 */
function mainEnv_() {
  if (mainEnvironment_ !== null) return mainEnvironment_;

  const win = typeof window === "undefined" ? null : window;
  const doc = typeof document === "undefined" ? null : document;
  let store = null;
  try {
    store = typeof sessionStorage === "undefined" ? null : sessionStorage;
  } catch {
    // 覚え書きを切ってある窓では、触れるだけで断られることがある
    store = null;
  }

  return {
    document: doc,
    window: win,
    location: win ? win.location : null,
    history: win ? win.history : null,
    sessionStorage: store,
    fetch: win && typeof win.fetch === "function" ? (url, init) => win.fetch(url, init) : null,
    console: typeof console === "undefined" ? null : console,
    now: () => new Date(),
  };
}

/**
 * テスト専用の差し込み口。ブラウザの道具の代わりに、確かめやすい偽物を渡す。
 * 製品の動きでは使わない（null を渡すと、もとのブラウザの道具に戻る）
 */
export function setEnvironmentForTests(env) {
  mainEnvironment_ = env !== null && typeof env === "object" ? env : null;
}

// ---- 純粋な計算 -------------------------------------------------------------
// ここから下の 6 つは、画面が無くても同じ答えになる計算だけを取り出したもの。
// 束ねるときに export は剥がされるので、配りものの中では、ただの内がわの関数になる

/**
 * 操作していた要素を見分ける手がかりを、属性の値から 1 本の文字にする。
 * data-focus-key が書いてあればそれを、無ければ役目と場所の組み合わせを使う。
 * 役目（data-action）が無い要素には手がかりを作らない（null）
 */
export function mainFocusKeyOf_(parts) {
  const source = parts !== null && typeof parts === "object" ? parts : {};
  const action = textOf(source.action);
  if (action === "") return null;
  const given = textOf(source.focus);
  if (given !== "") return given;
  return [action, textOf(source.widget), textOf(source.column), textOf(source.name)].join(MAIN_FOCUS_SEP_);
}

/**
 * 指のところに、いちばん近い帯はどれか（当てはまるものが無ければ -1）。
 * clientX は画面の座標、rect は図の画面での位置と大きさ、viewWidth は viewBox の幅、
 * positions は帯の中心（図の座標）。画面の座標を図の座標に移してから比べる
 */
export function mainNearestBandIndex_(clientX, rect, viewWidth, positions) {
  const box = rect !== null && typeof rect === "object" ? rect : null;
  const list = Array.isArray(positions) ? positions : [];
  if (box === null || !(box.width > 0) || !(viewWidth > 0) || list.length === 0) return -1;

  const at = ((clientX - box.left) / box.width) * viewWidth;
  let nearest = -1;
  let gap = Infinity;
  for (let index = 0; index < list.length; index += 1) {
    const x = Number(list[index]);
    if (!Number.isFinite(x)) continue;
    const distance = Math.abs(x - at);
    if (distance >= gap) continue;
    gap = distance;
    nearest = index;
  }
  return nearest;
}

/**
 * 印に添えてある中身（data-tip を読んだもの）から、吹き出しに出す形をそろえる。
 * 行の並びが無いものは吹き出しを出さない（null）。色の鍵は整数のときだけ付ける
 */
export function mainTipModel_(parsed) {
  if (parsed === null || typeof parsed !== "object" || !Array.isArray(parsed.rows)) return null;
  const rows = [];
  for (const row of parsed.rows) {
    if (row === null || typeof row !== "object") continue;
    rows.push({
      color: Number.isInteger(row.color) ? row.color : null,
      value: textOf(row.value),
      label: textOf(row.label),
    });
  }
  return { title: textOf(parsed.title), rows };
}

/** 「題-YYYY-MM-DD.csv」。ファイル名に使えない字は落とし、題が無いときは dashboard にする */
export function mainFileNameOf_(title, fallback, today) {
  const want = textOf(title) !== "" ? textOf(title) : textOf(fallback);
  const safe = want.replace(MAIN_FILE_UNSAFE_, " ").replace(/\s+/g, " ").trim();
  return (safe === "" ? "dashboard" : safe) + "-" + textOf(today) + ".csv";
}

/**
 * options.hash の指定から、URL の # に付ける頭を決める。
 * false は「# を使わない」（空文字）。文字の指定は小文字の英数字・_・- の 20 字までを受け取り、
 * それ以外の形は既定の頭に戻す。1 つのページに 2 つ置くときは、頭を分ければ取り違えない
 */
export function mainHashPrefixOf_(value) {
  if (value === false) return "";
  if (typeof value === "string") return MAIN_HASH_PREFIX_PATTERN_.test(value) ? value : MAIN_HASH_PREFIX_;
  return MAIN_HASH_PREFIX_;
}

/**
 * いまの # に書いてよいか。空のとき、または自分の頭の鍵だけのときだけ書く。
 * ページ自身の目印（#pricing）や、もう 1 つのダッシュボードの鍵が混じっているときは書かない
 * （絞り込みは今までどおり効く。そのページでは URL で配れないだけ）
 */
export function mainHashOwned_(hash, prefix) {
  if (textOf(prefix) === "") return false;
  const text = typeof hash === "string" ? hash : "";
  const body = text.startsWith("#") ? text.slice(1) : text;
  if (body === "") return true;

  const head = prefix + ".";
  for (const pair of body.split("&")) {
    if (pair === "") continue;
    const eq = pair.indexOf("=");
    const key = eq === -1 ? pair : pair.slice(0, eq);
    if (!key.startsWith(head)) return false;
  }
  return true;
}

/**
 * 吹き出しを置く場所を決める。答えは、描いた中身の包み（.db）の左上からの見た目の px。
 * 包みが拡大・縮小された中にあっても同じところに出せるよう、画面の座標を包みの倍率で割る。
 * 収まらないときは指の反対がわへ回し、包みの中と、目に見えている画面の中に収める
 */
export function mainTipPlacement_(input) {
  const at = input !== null && typeof input === "object" ? input : {};
  const rect = at.rootRect !== null && typeof at.rootRect === "object" ? at.rootRect : { left: 0, top: 0, width: 0, height: 0 };
  const rootWidth = Number(at.rootWidth);
  const rootHeight = Number(at.rootHeight);
  const gap = Number.isFinite(at.gap) ? at.gap : MAIN_TIP_GAP_;
  const edge = Number.isFinite(at.edge) ? at.edge : MAIN_TIP_EDGE_;

  // 包みが縮められていたら、その分だけ座標も縮む。0 で割らないように 1 倍へ逃がす
  const scale = rect.width > 0 && rootWidth > 0 ? rect.width / rootWidth : 1;
  const ratio = scale > 0 && Number.isFinite(scale) ? scale : 1;
  const tipWidth = Number(at.tipWidth) > 0 ? Number(at.tipWidth) / ratio : 0;
  const tipHeight = Number(at.tipHeight) > 0 ? Number(at.tipHeight) / ratio : 0;

  const x = (Number(at.x) - rect.left) / ratio;
  const y = (Number(at.y) - rect.top) / ratio;

  const view = (size, start) => (Number(size) > 0 ? { from: (0 - start) / ratio, to: (Number(size) - start) / ratio } : null);
  const across = view(at.viewWidth, rect.left);
  const down = view(at.viewHeight, rect.top);

  const place = (want, size, limit, window_) => {
    let low = edge;
    let high = Infinity;
    if (Number.isFinite(limit) && limit > 0) high = limit - edge - size;
    if (window_ !== null) {
      low = Math.max(low, window_.from + edge);
      high = Math.min(high, window_.to - edge - size);
    }
    let put = want + gap;
    if (put > high) put = want - gap - size;
    if (put < low) put = low;
    return Math.min(Math.max(put, low), Math.max(low, high));
  };

  return {
    left: Math.round(place(x, tipWidth, rootWidth, across)),
    top: Math.round(place(y, tipHeight, rootHeight, down)),
  };
}

/**
 * 遅れて届いた読み込みを、画面に入れてよいか。
 * あとから始めた読み込みが先に片づいたあとで、先に始めたほうの返事が届くことがある。
 * そのときは古い中身で上書きしないよう、いちばん新しい読み込みの返事だけを受け取る
 */
export function mainLoadWins_(token, current, destroyed) {
  return destroyed !== true && Number.isFinite(token) && token === current;
}

// ---- 小さな道具 -------------------------------------------------------------

function mainAttr_(element, name) {
  return element && typeof element.getAttribute === "function" ? element.getAttribute(name) : null;
}

/** その要素か、その先祖のうち、いちばん近い当てはまるもの */
function mainClosest_(target, selector) {
  const element = target && target.nodeType === 1 ? target : target && target.parentNode ? target.parentNode : null;
  return element && typeof element.closest === "function" ? element.closest(selector) : null;
}

/** ブラウザの暦の「今日」を YYYY-MM-DD にする（入口で 1 回だけ読む） */
function mainToday_(env) {
  const now = typeof env.now === "function" ? env.now() : new Date();
  return now.getFullYear() + "-" + pad2(now.getMonth() + 1) + "-" + pad2(now.getDate());
}

/** いま入れてある URL の # */
function mainHash_(ctx) {
  return ctx.env.location ? textOf(ctx.env.location.hash) : "";
}

// ---- データの下ごしらえ -----------------------------------------------------

/** オブジェクトの並びから、出てきた順に列の名前を集める */
function mainColumnsOf_(rows) {
  const columns = [];
  const seen = new Set();
  for (const row of rows) {
    if (!row || typeof row !== "object") continue;
    for (const key of Object.keys(row)) {
      if (seen.has(key)) continue;
      seen.add(key);
      columns.push(key);
    }
  }
  return columns;
}

/**
 * 上限より 1 行だけ多く残して、取り込んだそのままの形（見出し行つきの行列か、オブジェクトの並び）で切る。
 * 型をそろえる前にここで切るので、上限を大きく超えるデータでも、使わない行まで作り直さずに済む。
 * 空の行と、行として読めないものは、ここで落としておく（数えかたを、このあとの変換とそろえるため）
 */
function mainCutRaw_(list, matrix, max) {
  const kept = matrix && list.length > 0 ? [list[0]] : [];
  const head = kept.length;
  for (let i = head; i < list.length; i += 1) {
    const row = list[i];
    const usable = matrix
      ? Array.isArray(row) && !isBlankRow(row)
      : row !== null && typeof row === "object" && !Array.isArray(row);
    if (!usable) continue;
    kept.push(row);
    if (kept.length - head > max) break; // 上限 + 1 行まで（切ったかどうかを、このあと limitRows が見分ける）
  }
  return kept;
}

/**
 * 取り込んだ行を、描く側が使える形にそろえる。
 * 見出し行つきの行列はオブジェクトの並びに直し、列の型を決め、値をその型に合わせる。
 * 行数の上限は、型をそろえる前（行列・配列のまま）で切ってある
 */
function mainDataset_(raw, types) {
  const list = Array.isArray(raw) ? raw : [];
  const matrix = list.length > 0 && Array.isArray(list[0]);
  const cut = mainCutRaw_(list, matrix, TABLE_ROW_LIMIT_);
  const shaped = matrix ? rowsToObjects(cut) : { columns: mainColumnsOf_(cut), rows: cut };

  const kinds = inferTypes(shaped.columns, shaped.rows, types);
  const limited = limitRows(shaped.rows, TABLE_ROW_LIMIT_);
  return { columns: shaped.columns, rows: coerceRows(limited.rows, kinds), types: kinds, truncated: limited.truncated };
}

/**
 * 設定に書かれたデータセットのうち、行が届いたものだけをそろえる（届かないものは部品の札になる）。
 * mount に直に渡した行（inline）は、読み口が持ってきた行より先に使う。
 *
 * 読み口が「このデータは渡せませんでした」と名前で知らせてきたとき（missing）は、
 * たとえ空の行が付いていても、届かなかったものとして扱う
 * （スプレッドシートの読み口は、無いシートをこの形で知らせてくる）。
 *
 * 「このデータは上限で切ってある」と名前で知らせてきたとき（capped）は、
 * こちらで切った行が 1 行も無くても、切られたものとして知らせを出す
 */
function mainBuildDatasets_(config, loaded, inline, missing, capped) {
  const source = loaded !== null && typeof loaded === "object" ? loaded : {};
  const absent = new Set(Array.isArray(missing) ? missing.map((name) => textOf(name)) : []);
  const cut = new Set(Array.isArray(capped) ? capped.map((name) => textOf(name)) : []);
  const datasets = Object.create(null);
  const put = (name, rows) => {
    const made = mainDataset_(rows, config.datasets[name] ? config.datasets[name].types : {});
    if (cut.has(name)) made.truncated = true;
    datasets[name] = made;
  };
  for (const name of Object.keys(config.datasets)) {
    if (inline !== null && hasOwn(inline, name)) {
      put(name, inline[name]);
      continue;
    }
    if (absent.has(name) || !hasOwn(source, name) || source[name] === undefined) continue;
    put(name, source[name]);
  }
  return datasets;
}

/**
 * 区分の絞り込みの選び方。全データの値から作るので、ほかの絞り込みを変えても選べる値は減らない
 * （同じ列が 2 つのデータセットにあるときは、両方の値を合わせる）
 */
function mainDimensionOptions_(config, datasets) {
  const columns = Array.isArray(config.filters.dimensions) ? config.filters.dimensions : [];
  const options = {};
  for (const column of columns) {
    const values = new Set();
    for (const name of Object.keys(datasets)) {
      const dataset = datasets[name];
      if (dataset.columns.indexOf(column) === -1) continue;
      for (const value of dimensionOptions(dataset.rows, column)) values.add(value);
    }
    // 列の名前は設定に書かれた文字なので、"__proto__" のような名前でも
    // 入れ物そのものの素性を書き換えないように入れる
    setOwn(options, column, Array.from(values).sort());
  }
  return options;
}

// ---- 絞り込みの出し入れ -----------------------------------------------------

/**
 * base（設定から作った最初の絞り込み）に、partial（URL の # や、読み直す前の絞り込み）を重ねる。
 * 設定に無い区分の列は受け取らない。空の値は「すべて」に戻す
 */
function mainMergeFilters_(base, partial) {
  const source = partial !== null && typeof partial === "object" ? partial : {};
  const merged = { period: base.period, from: base.from, to: base.to, dimensions: base.dimensions };
  if (typeof source.period === "string" && source.period !== "") merged.period = source.period;
  if (typeof source.from === "string" && source.from !== "") merged.from = source.from;
  if (typeof source.to === "string" && source.to !== "") merged.to = source.to;

  if (source.dimensions) {
    // 列の名前がそのまま鍵になるので、initialFilters と同じくプロトタイプの無い入れ物に組む
    const dimensions = Object.create(null);
    for (const column of Object.keys(base.dimensions)) {
      dimensions[column] = hasOwn(source.dimensions, column) ? textOf(source.dimensions[column]) : "";
    }
    merged.dimensions = dimensions;
  }
  return merged;
}

/**
 * いまの絞り込みを URL の # に映す。最初と同じときは # を消す（何も絞っていない URL を配れるように）。
 * 履歴は積まずに、いま見ている 1 つを書き換える。
 *
 * # にページ自身の目印（#pricing など）やほかのダッシュボードの鍵が入っているときは、
 * こちらからは何も書かない（相手の目印を消さないため）。絞り込みそのものは今までどおり効く。
 * 書けないところでも画面が止まらないよう、書き換えの失敗はすべてここで受け止める
 */
function mainSyncHash_(ctx) {
  const prefix = ctx.hashPrefix;
  const location = ctx.env.location;
  if (prefix === "" || !location) return;
  if (!mainHashOwned_(mainHash_(ctx), prefix)) return;

  const history = ctx.env.history;
  const same = !filtersDiffer(ctx.state.filters, ctx.state.initial);
  const query = same ? "" : encodeFilters(ctx.state.filters, prefix);
  try {
    if (history && typeof history.replaceState === "function") {
      history.replaceState(null, "", same ? textOf(location.pathname) + textOf(location.search) : "#" + query);
      return;
    }
    // 入れ子の窓など、履歴を書き換えられないところでは # だけを入れ替える
    location.hash = query;
  } catch {
    try {
      location.hash = query;
    } catch {
      // 書けないページでは、絞り込みを URL で配れないだけにする（画面の操作は止めない）
    }
  }
}

// ---- 描き直し ---------------------------------------------------------------

function mainView_(ctx) {
  return { config: ctx.config, model: ctx.model, state: ctx.state, options: ctx.options, lang: ctx.lang, errors: ctx.errors };
}

/** 置き場所に、言語と見た目の選び方を持たせる（買い手が外から色を上書きできるように） */
function mainRootAttrs_(ctx) {
  const root = ctx.root;
  if (typeof root.setAttribute !== "function") return;
  root.setAttribute("data-db-theme", MAIN_THEMES_.indexOf(ctx.config.theme) === -1 ? "auto" : ctx.config.theme);
  root.setAttribute("lang", ctx.lang);
}

/**
 * 操作していた要素を見分ける手がかり。描き直すと要素は作り直されるので、
 * 役目（data-action）と、どの部品・どの列・どの入力かで同じ場所を探し当てる
 */
function mainFocusKey_(element) {
  if (element === null || element === undefined) return null;
  return mainFocusKeyOf_({
    action: mainAttr_(element, "data-action"),
    focus: mainAttr_(element, "data-focus-key"),
    widget: mainAttr_(element, "data-widget"),
    column: mainAttr_(element, "data-column"),
    name: mainAttr_(element, "name"),
  });
}

/** いま操作している要素（置き場所の中にあるときだけ） */
function mainActive_(ctx) {
  const doc = ctx.env.document;
  const element = doc ? doc.activeElement : null;
  if (!element) return null;
  return typeof ctx.root.contains === "function" && ctx.root.contains(element) ? element : null;
}

/** 描き直したあと、同じ手がかりの要素に focus を戻す */
function mainRestoreFocus_(ctx, key) {
  const list = typeof ctx.root.querySelectorAll === "function" ? ctx.root.querySelectorAll("[data-action]") : [];
  for (const element of list) {
    if (mainFocusKey_(element) !== key) continue;
    if (typeof element.focus === "function") element.focus();
    return;
  }
}

function mainBuildModel_(ctx) {
  ctx.model = buildDashboard({
    config: ctx.config,
    datasets: ctx.datasets,
    filters: ctx.state.filters,
    today: ctx.today,
    lang: ctx.lang,
  });
}

function mainRender_(ctx) {
  if (ctx.destroyed) return;
  const key = mainFocusKey_(mainActive_(ctx));
  mainHideTip_(ctx);
  ctx.root.innerHTML = renderDashboard(mainView_(ctx));
  mainPlaceTip_(ctx);
  if (key !== null) mainRestoreFocus_(ctx, key);
}

/**
 * 描き直しをひとまとめにする。続けて起きた操作を 1 回の描き直しにまとめると、
 * 押しつづけても画面がなめらかに保てる。窓が無いところでは、その場で描く
 */
function mainSchedule_(ctx) {
  if (ctx.destroyed || ctx.pending) return;
  const win = ctx.env.window;
  if (!win || typeof win.requestAnimationFrame !== "function") {
    mainBuildModel_(ctx);
    mainRender_(ctx);
    return;
  }
  ctx.pending = true;
  ctx.frame = win.requestAnimationFrame(() => {
    ctx.pending = false;
    ctx.frame = 0;
    mainBuildModel_(ctx);
    mainRender_(ctx);
  });
}

// ---- 吹き出し ---------------------------------------------------------------

/** 吹き出しは 1 つだけ作って使い回す。中身は textContent で入れる（文字列は差し込まない） */
function mainPlaceTip_(ctx) {
  const doc = ctx.env.document;
  if (!doc || typeof doc.createElement !== "function") return;
  if (ctx.tip === null) {
    const tip = doc.createElement("div");
    tip.className = "db-tip";
    tip.setAttribute("role", "tooltip");
    tip.setAttribute("aria-hidden", "true");
    tip.style.display = "none";
    ctx.tip = tip;
  }
  // 描いた中身と同じ包みの中に置くと、明るい・暗いの選び方がそのまま吹き出しにも効き、
  // 置き場所が拡大・縮小された中にあっても、包みと一緒に動く
  const host = mainTipHost_(ctx);
  if (typeof host.appendChild === "function") host.appendChild(ctx.tip);
}

function mainHideTip_(ctx) {
  if (ctx.tip !== null) {
    ctx.tip.style.display = "none";
    ctx.tip.setAttribute("aria-hidden", "true");
  }
  mainHideCrosshair_(ctx);
}

/** 印に添えてある吹き出しの中身（JSON）。読めない形は無いものとして扱う */
function mainTipData_(element) {
  const raw = mainAttr_(element, "data-tip");
  if (raw === null || raw === "") return null;
  try {
    return mainTipModel_(JSON.parse(raw));
  } catch {
    return null;
  }
}

/** 吹き出しの中身を組み立てる。値が先、系列の名前が後、色の鍵は短い線 */
function mainFillTip_(ctx, data) {
  const doc = ctx.env.document;
  const tip = ctx.tip;
  while (tip.firstChild) tip.removeChild(tip.firstChild);

  if (data.title !== "") {
    const title = doc.createElement("div");
    title.className = "db-tip-title";
    title.textContent = data.title;
    tip.appendChild(title);
  }
  for (const row of data.rows) {
    const line = doc.createElement("div");
    line.className = "db-tip-row";
    if (row.color !== null) {
      const key = doc.createElement("span");
      key.className = "db-tip-key db-tip-swatch db-s" + row.color;
      key.setAttribute("aria-hidden", "true");
      line.appendChild(key);
    }
    const value = doc.createElement("span");
    value.className = "db-tip-value";
    value.textContent = row.value;
    line.appendChild(value);

    const label = doc.createElement("span");
    label.className = "db-tip-label";
    label.textContent = row.label;
    line.appendChild(label);

    tip.appendChild(line);
  }
}

/** 吹き出しを入れてある包み（描いた中身の .db）。無ければ置き場所そのもの */
function mainTipHost_(ctx) {
  return ctx.root.firstElementChild || ctx.root;
}

/**
 * 吹き出しを、指や印のそばに置く。包みの左上からの場所で置くので、
 * ページ側で拡大・縮小された中に埋め込まれていても、指のところに出る
 */
function mainMoveTip_(ctx, x, y) {
  const tip = ctx.tip;
  const win = ctx.env.window;
  const host = mainTipHost_(ctx);
  const box = typeof tip.getBoundingClientRect === "function" ? tip.getBoundingClientRect() : { width: 0, height: 0 };
  const rootRect = typeof host.getBoundingClientRect === "function" ? host.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };

  const place = mainTipPlacement_({
    x,
    y,
    tipWidth: box.width,
    tipHeight: box.height,
    rootRect,
    rootWidth: Number(host.offsetWidth),
    rootHeight: Number(host.offsetHeight),
    viewWidth: win && Number.isFinite(win.innerWidth) ? win.innerWidth : 0,
    viewHeight: win && Number.isFinite(win.innerHeight) ? win.innerHeight : 0,
  });
  tip.style.left = place.left + "px";
  tip.style.top = place.top + "px";
}

function mainShowTip_(ctx, element, x, y) {
  const data = mainTipData_(element);
  if (data === null || ctx.tip === null || !ctx.env.document) {
    mainHideTip_(ctx);
    return;
  }
  mainFillTip_(ctx, data);
  ctx.tip.style.display = "block";
  ctx.tip.setAttribute("aria-hidden", "false");
  mainMoveTip_(ctx, x, y);
}

// ---- 折れ線の縦の線 ---------------------------------------------------------

function mainHideCrosshair_(ctx) {
  if (ctx.crosshair === null) return;
  ctx.crosshair.setAttribute("visibility", "hidden");
  ctx.crosshair = null;
}

function mainShowCrosshair_(ctx, svg, at) {
  const line = typeof svg.querySelector === "function" ? svg.querySelector(".db-crosshair") : null;
  if (!line) return;
  line.setAttribute("x1", at);
  line.setAttribute("x2", at);
  line.setAttribute("visibility", "visible");
  ctx.crosshair = line;
}

/** 図の中の座標の幅（viewBox の 3 つめの数） */
function mainViewBoxWidth_(svg) {
  const parts = textOf(mainAttr_(svg, "viewBox")).split(/\s+/);
  const width = Number(parts[2]);
  return Number.isFinite(width) && width > 0 ? width : 0;
}

/** 指のところに、いちばん近い刻みの帯を探す（画面の座標を図の座標に移して比べる） */
function mainNearestBand_(svg, clientX) {
  if (typeof svg.getBoundingClientRect !== "function" || typeof svg.querySelectorAll !== "function") return null;
  const bands = Array.from(svg.querySelectorAll("[data-bucket]"));
  const positions = bands.map((band) => Number(mainAttr_(band, "data-x")));
  const index = mainNearestBandIndex_(clientX, svg.getBoundingClientRect(), mainViewBoxWidth_(svg), positions);
  return index === -1 ? null : bands[index];
}

/** その印が折れ線の帯なら、縦の線をそこへ動かす */
function mainTrackCrosshair_(ctx, element) {
  const svg = mainClosest_(element, "svg.db-chart-svg");
  const at = mainAttr_(element, "data-x");
  if (svg === null || at === null) {
    mainHideCrosshair_(ctx);
    return;
  }
  mainShowCrosshair_(ctx, svg, at);
}

// ---- 出来事 -----------------------------------------------------------------

function mainDispatch_(ctx, action) {
  const before = ctx.state;
  const next = reduce(before, action);
  if (next === before) return;
  ctx.state = next;
  // 先に描き直しを予約してから URL を書き換える。URL の書き換えでつまずいても、画面は必ず変わる
  mainSchedule_(ctx);
  if (filtersDiffer(before.filters, next.filters) || action.type === "reset") mainSyncHash_(ctx);
}

/** 日付の 2 つの入力は、どちらを変えても両方まとめて読む（片側だけの指定も受ける） */
function mainReadRange_(ctx) {
  const range = { from: "", to: "" };
  const list = typeof ctx.root.querySelectorAll === "function" ? ctx.root.querySelectorAll('[data-action="set-range"]') : [];
  for (const input of list) {
    const name = mainAttr_(input, "name");
    if (name === "from" || name === "to") range[name] = textOf(input.value);
  }
  return range;
}

function mainOnChange_(ctx, event) {
  const element = event.target;
  const action = mainAttr_(element, "data-action");
  if (action === "set-period") {
    mainDispatch_(ctx, { type: "set-period", period: textOf(element.value) });
  } else if (action === "set-dimension") {
    mainDispatch_(ctx, { type: "set-dimension", column: textOf(mainAttr_(element, "data-column")), value: textOf(element.value) });
  } else if (action === "set-range") {
    const range = mainReadRange_(ctx);
    mainDispatch_(ctx, { type: "set-range", from: range.from, to: range.to });
  }
}

function mainOnClick_(ctx, event) {
  const element = mainClosest_(event.target, "[data-action]");
  const action = mainAttr_(element, "data-action");
  if (action === null || MAIN_CLICK_ACTIONS_.indexOf(action) === -1) return;

  if (action === "download-csv") {
    mainDownloadCsv_(ctx, textOf(mainAttr_(element, "data-widget")));
    return;
  }
  if (action === "sort") {
    mainDispatch_(ctx, { type: "sort", widget: textOf(mainAttr_(element, "data-widget")), column: mainAttr_(element, "data-column") });
    return;
  }
  if (action === "toggle-table") {
    mainDispatch_(ctx, { type: "toggle-table", widget: textOf(mainAttr_(element, "data-widget")) });
    return;
  }
  mainDispatch_(ctx, { type: "reset" });
}

/** 指やペンでの操作か（マウスは押していなくても位置が分かるので、分けて扱う） */
function mainIsTouch_(event) {
  return MAIN_TOUCH_POINTERS_.indexOf(textOf(event && event.pointerType)) !== -1;
}

/** 指した先に合わせて、吹き出しと縦の線を出す（マウスでも指でも同じ） */
function mainPointAt_(ctx, event) {
  const svg = mainClosest_(event.target, "svg.db-chart-svg");
  if (svg !== null && typeof svg.querySelector === "function" && svg.querySelector(".db-crosshair")) {
    const band = mainNearestBand_(svg, event.clientX);
    if (band !== null) {
      mainShowCrosshair_(ctx, svg, mainAttr_(band, "data-x"));
      mainShowTip_(ctx, band, event.clientX, event.clientY);
      return;
    }
  }
  mainHideCrosshair_(ctx);
  const mark = mainClosest_(event.target, "[data-tip]");
  if (mark === null) mainHideTip_(ctx);
  else mainShowTip_(ctx, mark, event.clientX, event.clientY);
}

/**
 * 指やペンで触れたとき。印に触れればその吹き出しを出し、印の無いところに触れれば消す。
 * ここから指を離すまでのあいだは、横になぞると縦の線が刻みを追いかける
 */
function mainOnPointerDown_(ctx, event) {
  if (!mainIsTouch_(event)) return;
  ctx.touching = true;
  mainPointAt_(ctx, event);
}

/** マウスはいつでも、指やペンは触れているあいだだけ、指した先を追いかける */
function mainOnPointerMove_(ctx, event) {
  if (mainIsTouch_(event) && ctx.touching !== true) return;
  mainPointAt_(ctx, event);
}

/**
 * 指を離したとき。吹き出しはそのまま残す（触れたものの値を、離してから読めるように）。
 * 消えるのは、印の無いところに触れたときと、Escape と、描き直したときだけ
 */
function mainOnPointerEnd_(ctx) {
  ctx.touching = false;
}

/** 置き場所から出たとき。指やペンでは、離したあとにも届くので、マウスのときだけ消す */
function mainOnPointerLeave_(ctx, event) {
  if (mainIsTouch_(event)) return;
  ctx.touching = false;
  mainHideTip_(ctx);
}

/** キーボードの focus でも、指で指したときと同じ吹き出しを出す */
function mainOnFocusIn_(ctx, event) {
  const mark = mainClosest_(event.target, "[data-tip]");
  if (mark === null) {
    mainHideTip_(ctx);
    return;
  }
  mainTrackCrosshair_(ctx, mark);
  const box = typeof mark.getBoundingClientRect === "function" ? mark.getBoundingClientRect() : null;
  const x = box ? box.left + box.width / 2 : 0;
  const y = box ? box.top + Math.min(box.height / 2, 60) : 0;
  mainShowTip_(ctx, mark, x, y);
}

function mainOnKeyDown_(ctx, event) {
  if (event.key === "Escape" || event.key === "Esc") mainHideTip_(ctx);
}

/**
 * 絞り込みの form は、押しボタンではなく select と日付の入力だけで動く。
 * それでも Enter などで送信されるとページが読み直されてしまうので、ここで止める
 */
function mainOnSubmit_(event) {
  if (event && typeof event.preventDefault === "function") event.preventDefault();
}

function mainHandle_(ctx, type, event) {
  if (ctx.destroyed) return;
  if (type === "change") mainOnChange_(ctx, event);
  else if (type === "click") mainOnClick_(ctx, event);
  else if (type === "submit") mainOnSubmit_(event);
  else if (type === "pointerdown") mainOnPointerDown_(ctx, event);
  else if (type === "pointermove") mainOnPointerMove_(ctx, event);
  else if (type === "pointerup" || type === "pointercancel") mainOnPointerEnd_(ctx);
  else if (type === "pointerleave") mainOnPointerLeave_(ctx, event);
  else if (type === "focusin") mainOnFocusIn_(ctx, event);
  else if (type === "keydown") mainOnKeyDown_(ctx, event);
  else mainHideTip_(ctx); // focusout
}

function mainBind_(ctx) {
  const root = ctx.root;
  if (typeof root.addEventListener === "function") {
    for (const type of MAIN_EVENTS_) {
      const handler = (event) => mainHandle_(ctx, type, event);
      ctx.handlers.push({ type, handler });
      root.addEventListener(type, handler);
    }
  }
  const win = ctx.env.window;
  if (ctx.hashPrefix !== "" && win && typeof win.addEventListener === "function") {
    ctx.hashHandler = () => {
      if (ctx.destroyed) return;
      const filters = mainMergeFilters_(ctx.state.initial, decodeFilters(mainHash_(ctx), ctx.config, ctx.hashPrefix));
      if (!filtersDiffer(ctx.state.filters, filters)) return;
      ctx.state = Object.assign({}, ctx.state, { filters });
      mainSchedule_(ctx);
    };
    win.addEventListener("hashchange", ctx.hashHandler);
  }
}

function mainUnbind_(ctx) {
  const root = ctx.root;
  if (typeof root.removeEventListener === "function") {
    for (const entry of ctx.handlers) root.removeEventListener(entry.type, entry.handler);
  }
  ctx.handlers = [];
  const win = ctx.env.window;
  if (ctx.hashHandler !== null && win && typeof win.removeEventListener === "function") {
    win.removeEventListener("hashchange", ctx.hashHandler);
  }
  ctx.hashHandler = null;
}

// ---- CSV の書き出し ---------------------------------------------------------

function mainWidget_(ctx, id) {
  const widgets = ctx.model && Array.isArray(ctx.model.widgets) ? ctx.model.widgets : [];
  for (const widget of widgets) {
    if (widget && widget.id === id) return widget;
  }
  return null;
}

/** 表の中身をそのまま CSV にして渡す。表計算ソフトが数式として動かさない形は toCsv が受け持つ */
function mainDownloadCsv_(ctx, id) {
  const widget = mainWidget_(ctx, id);
  if (widget === null || !Array.isArray(widget.csv)) return;

  const doc = ctx.env.document;
  const win = ctx.env.window;
  if (!doc || !win || typeof win.Blob !== "function" || !win.URL) return;

  const blob = new win.Blob([toCsv(widget.csv)], { type: "text/csv;charset=utf-8" });
  const url = win.URL.createObjectURL(blob);
  const link = doc.createElement("a");
  link.href = url;
  link.download = mainFileNameOf_(widget.title, ctx.config.title, ctx.today);
  link.rel = "noopener";

  const host = doc.body || ctx.root;
  if (typeof host.appendChild === "function") host.appendChild(link);
  link.click();
  if (typeof link.remove === "function") link.remove();

  // 書き出しが始まる前に消してしまわないよう、少し待ってから手放す。
  // 待っているあいだに片づけられたときのために、待ち合わせを控えておく
  const pending = { url, timer: 0 };
  const release = () => {
    ctx.revokes = ctx.revokes.filter((entry) => entry !== pending);
    win.URL.revokeObjectURL(url);
  };
  if (typeof win.setTimeout === "function") {
    pending.timer = win.setTimeout(release, MAIN_REVOKE_DELAY_);
    ctx.revokes.push(pending);
  } else {
    release();
  }
}

/** 待ち合わせを取りやめて、まだ手放していない置き場所をその場で手放す */
function mainReleaseUrls_(ctx) {
  const win = ctx.env.window;
  const pending = ctx.revokes;
  ctx.revokes = [];
  for (const entry of pending) {
    if (entry.timer && win && typeof win.clearTimeout === "function") win.clearTimeout(entry.timer);
    if (win && win.URL && typeof win.URL.revokeObjectURL === "function") win.URL.revokeObjectURL(entry.url);
  }
}

// ---- 読み込み ---------------------------------------------------------------

/** まだ設定が届いていないときの、いちばん外がわの形（読み込み中の知らせを出すために使う） */
function mainBlankConfig_(lang, theme) {
  return { title: "", lang, theme, cacheMinutes: 5, datasets: {}, filters: { period: "all", from: "", to: "", dimensions: [] }, widgets: [] };
}

function mainBlankState_() {
  const dimensions = Object.create(null);
  const filters = { period: "all", from: "", to: "", dimensions };
  return { status: "loading", filters, initial: filters, tableView: {}, sort: {}, message: "" };
}

/** 届いた設定とデータを画面の形にそろえて、描く */
function mainApply_(ctx, result) {
  const loaded = result !== null && typeof result === "object" ? result : {};
  const parsed = parseConfig(loaded.config);
  const config = parsed.config;
  if (ctx.langOverride !== "") config.lang = ctx.langOverride;
  if (ctx.themeOverride !== "") config.theme = ctx.themeOverride;

  ctx.config = config;
  ctx.errors = parsed.errors;
  ctx.lang = config.lang === "en" ? "en" : "ja";
  ctx.datasets = mainBuildDatasets_(config, loaded.datasets, ctx.inline, loaded.missing, loaded.truncated);
  ctx.options = mainDimensionOptions_(config, ctx.datasets);

  const fresh = initialState(config, ctx.today);
  const before = ctx.state.status === "ready" ? ctx.state : null;
  // 読み直しのときは、いま選んでいる絞り込みを引き継ぐ。はじめは URL の # を読む
  const partial =
    before !== null ? before.filters : ctx.hashPrefix !== "" ? decodeFilters(mainHash_(ctx), config, ctx.hashPrefix) : null;
  const state = Object.assign({}, fresh, { filters: mainMergeFilters_(fresh.filters, partial) });
  if (before !== null) {
    state.tableView = before.tableView;
    state.sort = before.sort;
  }
  ctx.state = reduce(state, { type: "loaded" });

  mainRootAttrs_(ctx);
  mainBuildModel_(ctx);
  mainRender_(ctx);
}

/**
 * 読み込めなかったときは、やわらかい知らせだけを出す。
 * 読み口が「この文はそのまま出してよい」と印を付けてきたとき（dashboardMessage）だけ、
 * その文を画面に出す。印の無い誤りは、内がわの事情を見せないよう既定の 1 文にする
 */
function mainFail_(ctx, error) {
  const log = ctx.env.console;
  if (log && typeof log.error === "function") log.error(error);
  ctx.model = {};
  const shown = error !== null && typeof error === "object" ? textOf(error.dashboardMessage) : "";
  ctx.state = reduce(ctx.state, { type: "failed", message: shown });
  mainRender_(ctx);
}

/**
 * 設定とデータを読み込んで画面に入れる。
 *
 * 読み込みには順番の札（token）を持たせ、いちばん新しい読み込みの返事だけを画面に入れる。
 * 先に始めたほうが遅れて返ってきても、そこで古い中身に戻ってしまわないようにするため
 * （片づけたあと（destroy）に届いた返事も、同じ仕組みで見送る）
 */
function mainLoad_(ctx, fresh) {
  ctx.loadToken += 1;
  const token = ctx.loadToken;
  return Promise.resolve()
    .then(() => ctx.source.load({ fresh }))
    .then(
      (result) => {
        if (mainLoadWins_(token, ctx.loadToken, ctx.destroyed)) mainApply_(ctx, result);
      },
      (error) => {
        if (mainLoadWins_(token, ctx.loadToken, ctx.destroyed)) mainFail_(ctx, error);
      }
    );
}

/** load() が、画面にそのまま出してよい 1 文で必ず失敗する読み口 */
function mainFailingSource_(message) {
  return {
    load() {
      const error = new Error(message);
      error.dashboardMessage = message;
      return Promise.reject(error);
    },
  };
}

/**
 * どこから設定とデータを持ってくるかを決める。load() を持つものを渡されたらそれを使い、
 * "memory" なら見本、それ以外は取りに行く読み口にする。
 * 束ねた中に入っていない読み口は typeof で確かめる（入口ごとに積む読み口が違うため）。
 * 見本の読み口は見本のページ（demo/app.js）にだけ入れてあるので、配布物で "memory" を
 * 指定されたときは、そのことを丁寧にお伝えして失敗の表示にする
 */
function mainSource_(ctx, options) {
  const given = options.source;
  if (given !== null && typeof given === "object" && typeof given.load === "function") return given;

  const name = textOf(given);
  if (name === "memory") {
    if (typeof sourceMemoryCreate_ !== "function") return mainFailingSource_(t(ctx.lang, "error.sampleOnlyInDemo"));
    return sourceMemoryCreate_({ today: ctx.today, lang: ctx.langOverride || "ja" });
  }
  if (name === "gas" && typeof sourceGasCreate_ === "function") {
    return sourceGasCreate_({ env: ctx.env });
  }
  if (typeof sourceWebCreate_ === "function") {
    return sourceWebCreate_({ config: options.config, data: options.data, env: ctx.env });
  }
  return { load: () => Promise.reject(new Error("dashboard: データの読み口が見つかりません")) };
}

/**
 * 置き場所（root）にダッシュボードを組み立てる。options は
 * { config, data, source, lang, theme, today, hash }。
 * hash は true（既定・URL の # に "db." の頭で書く）／"売上" のような頭の指定／false（使わない）。
 * 戻り値の destroy() で後片づけ、refresh() で取り込み直す。
 *
 * 同じ置き場所にもう一度組み立てるときは、先にいたほうを片づけてから組み立てる
 * （そのあとで古いほうの destroy() を呼んでも、新しい画面は消えない）
 */
export function mountDashboard(root, options) {
  if (root === null || typeof root !== "object") throw new TypeError("dashboard: 置き場所の要素を渡してください");

  const living = MAIN_INSTANCES_.get(root);
  if (living !== undefined && typeof living.destroy === "function") living.destroy();

  const env = mainEnv_();
  const opts = options !== null && typeof options === "object" ? options : {};
  const today = isDateKey(textOf(opts.today)) ? textOf(opts.today) : mainToday_(env);
  const langOverride = opts.lang === "en" || opts.lang === "ja" ? opts.lang : "";
  const themeOverride = MAIN_THEMES_.indexOf(opts.theme) === -1 ? "" : opts.theme;

  const ctx = {
    env,
    root,
    today,
    langOverride,
    themeOverride,
    lang: langOverride === "" ? "ja" : langOverride,
    inline: opts.data !== null && typeof opts.data === "object" ? opts.data : null,
    hashPrefix: env.location ? mainHashPrefixOf_(opts.hash) : "",
    config: mainBlankConfig_(langOverride === "" ? "ja" : langOverride, themeOverride === "" ? "auto" : themeOverride),
    errors: [],
    datasets: Object.create(null),
    options: {},
    model: {},
    state: mainBlankState_(),
    tip: null,
    crosshair: null,
    touching: false,
    handlers: [],
    hashHandler: null,
    revokes: [],
    pending: false,
    frame: 0,
    loadToken: 0,
    destroyed: false,
    source: null,
  };

  const view = {
    destroy() {
      if (ctx.destroyed) return;
      ctx.destroyed = true;
      if (MAIN_INSTANCES_.get(root) === view) MAIN_INSTANCES_.delete(root);
      mainUnbind_(ctx);
      const win = ctx.env.window;
      if (ctx.frame && win && typeof win.cancelAnimationFrame === "function") win.cancelAnimationFrame(ctx.frame);
      mainReleaseUrls_(ctx);
      mainHideTip_(ctx);
      if (ctx.tip !== null && ctx.tip.parentNode && typeof ctx.tip.parentNode.removeChild === "function") {
        ctx.tip.parentNode.removeChild(ctx.tip);
      }
      ctx.tip = null;
      ctx.root.innerHTML = "";
    },
    refresh() {
      if (ctx.destroyed) return Promise.resolve();
      return mainLoad_(ctx, true);
    },
  };

  MAIN_INSTANCES_.set(root, view);
  mainRootAttrs_(ctx);
  mainRender_(ctx);
  mainBind_(ctx);
  ctx.source = mainSource_(ctx, opts);
  mainLoad_(ctx, false);
  return view;
}
