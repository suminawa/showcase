/**
 * 表の見た目。区分ごとの集計表・明細の表（renderTable）と、どのグラフにも付く
 * 「表で見る」の中身（renderDataTable）の 2 つ。
 * 並べ替えはここで行う（純粋な計算で、元の行は書き換えない）。
 */

import { escapeHtml, escapeAttr, hasOwn, compareCells } from "../core/text.js";
import { t } from "../core/i18n.js";
import { renderEmptyNote } from "./render-charts.js";

/** 並べ替えの向きを、読み上げに伝える言い方にする */
const TABLE_ARIA_SORT_ = { desc: "descending", asc: "ascending" };

/**
 * at 列で並べ替えた、新しい行の並びを作る。比べ方は core の compareCells の 1 か所だけにあり、
 * model が組み立てる表（model.js）と同じ決まり（空はどちらの向きでもいつも最後）になる。
 * 同じ値のときは元の並びのまま（並べ替えても行が入れ替わらない）
 */
function tableSorted_(rows, at, order) {
  const decorated = rows.map((cells, index) => ({ cells, index }));
  decorated.sort((a, b) => {
    const gap = compareCells(a.cells[at] ? a.cells[at].value : null, b.cells[at] ? b.cells[at].value : null, order);
    return gap === 0 ? a.index - b.index : gap;
  });
  return decorated.map((entry) => entry.cells);
}

/**
 * 表の本体を組む。numeric の列は右寄せ・等幅数字にする（桁がそろって比べやすいように）。
 * 行には吹き出しを付けない。マスの値はどれもそのまま見えている文字なので、
 * 添えるものが無いうえ、行を 1 つの図として包むと、読み上げが列と行のつながりを
 * たどれなくなってしまうため
 */
function tableBody_(rows, head) {
  const lines = rows.map((cells) => {
    const tds = cells
      .map((cell, index) => (head[index] && head[index].numeric ? '<td class="db-num">' : "<td>") + escapeHtml(cell.text) + "</td>")
      .join("");
    return '<tr class="db-row">' + tds + "</tr>";
  });
  return "<tbody>" + lines.join("") + "</tbody>";
}

/** 並べ替えの押しボタンつきの見出し。いま並べ替えている列は、向きも読み上げに伝える */
function tableHead_(head, widgetId, sort) {
  const id = escapeAttr(widgetId);
  const cells = head.map((column, index) => {
    const active = sort && sort.column === index;
    const order = active ? TABLE_ARIA_SORT_[sort.order] || "none" : "none";
    const inner = widgetId === ""
      ? escapeHtml(column.label)
      : '<button type="button" class="db-sort" data-action="sort" data-widget="' + id + '" data-column="' + index + '">' +
        escapeHtml(column.label) + "</button>";
    return "<th scope=\"col\"" + (column.numeric ? ' class="db-num"' : "") + ' aria-sort="' + order + '">' + inner + "</th>";
  });
  return "<thead><tr>" + cells.join("") + "</tr></thead>";
}

/**
 * 区分ごとの集計表・明細の表。見出しを押すと並べ替わる（state.sort が向きを持つ）。
 * lang は読み上げの文の区切りに使う
 */
export function renderTable(model, state, lang) {
  if (model.empty === true || !Array.isArray(model.rows) || model.rows.length === 0) return renderEmptyNote(lang);

  const sort = (hasOwn(state && state.sort, model.id) ? state.sort[model.id] : null) || null;
  const rows = sort && sort.column >= 0 && sort.column < model.head.length ? tableSorted_(model.rows, sort.column, sort.order) : model.rows;
  return (
    '<div class="db-table-wrap"><table class="db-table">' +
    tableHead_(model.head, model.id, sort) +
    tableBody_(rows, model.head) +
    "</table></div>"
  );
}

/**
 * どのグラフにも付く「表で見る」の中身。model.table（1 列目が刻みや区分の名前、
 * それより後ろが値）を、並べ替えの押しボタンを持たない同じ見た目の表にする。
 * 表を持たない model（誤りの札など）が来ても、落とさずにお知らせを出す
 */
export function renderDataTable(model, state, lang) {
  const table = model && model.table ? model.table : null;
  const source = table && Array.isArray(table.head) && Array.isArray(table.rows) ? table : { head: [], rows: [] };
  if (source.rows.length === 0) return renderEmptyNote(lang);

  const head = source.head.map((label, index) => ({ label, numeric: index > 0 }));
  const rows = source.rows.map((cells) => cells.map((text) => ({ text, value: text })));
  return (
    '<div class="db-table-wrap"><table class="db-table">' +
    tableHead_(head, "", null) +
    tableBody_(rows, head) +
    "</table></div>"
  );
}

/** 表の部品に添える、CSV の押しボタン */
export function renderCsvButton(widgetId, lang) {
  return (
    '<button type="button" class="db-action" data-action="download-csv" data-widget="' + escapeAttr(widgetId) + '">' +
    escapeHtml(t(lang, "action.downloadCsv")) +
    "</button>"
  );
}
