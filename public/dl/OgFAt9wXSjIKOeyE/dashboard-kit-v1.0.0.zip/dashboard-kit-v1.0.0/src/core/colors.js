/**
 * 区分ごとの色（1〜8 の番号。0 は灰の「その他」）を、いつ見ても変わらないように決める道具。
 * 番号は CSS の --db-series-1〜8 に対応させるのは画面側の仕事で、ここでは番号だけを決める
 */

import { groupBy, aggregate, compareEntriesDesc } from "./aggregate.js";

/**
 * column の値ごとに、allRows（絞り込む前の全データ）で value を agg 集計し、大きい順（同じなら
 * 名前順）に並べて、上位 max 件に 1…max を振る。それ以外は 0（灰の「その他」）。
 * blankLabel（既定 ""）は groupBy と同じ決まりで、空・null の値をまとめるときの札。
 * 絞り込んだ後の rows ではなく、常に全データから決めるので、絞り込みで番号は変わらない
 */
export function assignSeriesColors(allRows, column, value, agg, max = 8, blankLabel = "") {
  const groups = groupBy(allRows, column, blankLabel);
  const entries = [];
  for (const [key, rows] of groups) {
    entries.push({ key, value: aggregate(rows, value, agg).value });
  }
  entries.sort(compareEntriesDesc);

  const colors = new Map();
  entries.forEach((entry, index) => {
    colors.set(entry.key, index < max ? index + 1 : 0);
  });
  return colors;
}
