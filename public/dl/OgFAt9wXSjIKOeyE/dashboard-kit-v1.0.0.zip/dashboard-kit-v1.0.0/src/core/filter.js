/**
 * 期間・区分の絞り込みまわりの純粋な道具。設定（config.filters）と画面の状態を行き来させる。
 * URL のハッシュとの往復（encodeFilters / decodeFilters）もここに置く
 */

import { isDateKey, periodRange } from "./dates.js";
import { CONFIG_PERIODS_ } from "./config.js";

/**
 * URL のハッシュの鍵に付ける頭の既定値。
 * 置いたページ自身の目印（#pricing）や、同じページのもう 1 つのダッシュボードと
 * 取り違えないよう、鍵はかならずこの頭と "." から始める
 */
const FILTER_HASH_PREFIX_ = "db";

/** 頭の指定を受け取る（空・文字でないものは既定の頭にする） */
function filterPrefix_(prefix) {
  return typeof prefix === "string" && prefix !== "" ? prefix : FILTER_HASH_PREFIX_;
}

/**
 * 画面の絞り込みの初期状態を作る。config.filters.dimensions（列名の配列）は、値が空文字の
 * 絞り込みオブジェクトにする。period が custom のときは設定の from/to をそのまま使い、
 * それ以外のときは periodRange(period, today) で、いまの範囲を from/to の初期値として持たせる
 * （custom に切り替えたときに、それまでの期間の日付が入り口として入っているように）
 */
export function initialFilters(config, today) {
  const source = config && config.filters ? config.filters : {};
  const period = source.period || "thisMonth";

  let from = "";
  let to = "";
  if (period === "custom") {
    from = source.from || "";
    to = source.to || "";
  } else {
    const range = periodRange(period, today);
    from = range.from;
    to = range.to;
  }

  // 列名がそのままキーになるので、__proto__ のような特別な名前の列でも自分のキーとして
  // 持てるよう、プロトタイプの無いオブジェクトに組み立てる
  const dimensions = Object.create(null);
  const columns = Array.isArray(source.dimensions) ? source.dimensions : [];
  for (const column of columns) dimensions[column] = "";

  return { period, from, to, dimensions };
}

/**
 * いま選んでいる絞り込みから、実際に使う日付の範囲を決める。
 * custom は from/to をそのまま返す（どちらかが空でも、その側は無しとして扱う＝片側だけの指定を許す）。
 * それ以外のプリセットは periodRange に任せる
 */
export function resolveRange(filters, today) {
  const period = filters ? filters.period : "";
  if (period === "custom") {
    return { from: (filters && filters.from) || "", to: (filters && filters.to) || "" };
  }
  return periodRange(period, today);
}

/** 日付キーが range に収まるか。range の両端が空（絞り込みなし）なら、値を見ずに常に通す */
function filterInRange_(dateKey, range) {
  const from = range && range.from ? range.from : "";
  const to = range && range.to ? range.to : "";
  if (from === "" && to === "") return true;
  if (typeof dateKey !== "string" || dateKey === "") return false;
  if (from !== "" && dateKey < from) return false;
  if (to !== "" && dateKey > to) return false;
  return true;
}

/**
 * 行が dimensions（{ 列名: 値 }）に一致するか。値が空文字の列は見ない。複数の列は AND。
 * 行にその列が無いときは、空文字でない絞り込みには一致しない
 */
function filterMatchesDimensions_(row, dimensions) {
  for (const column of Object.keys(dimensions)) {
    const want = dimensions[column];
    if (want === undefined || want === null || want === "") continue;
    if (!row || row[column] !== want) return false;
  }
  return true;
}

/**
 * rows を期間・区分で絞り込む。dateColumn が空文字のデータセットは期間を無視する。
 * 期間つき（range の片方でも指定あり）のときは、日付が null の行を外す
 */
export function applyFilters(rows, options) {
  const opts = options || {};
  const dateColumn = opts.dateColumn || "";
  const range = opts.range || { from: "", to: "" };
  const dimensions = opts.dimensions || {};
  const list = Array.isArray(rows) ? rows : [];

  return list.filter((row) => {
    if (dateColumn !== "" && !filterInRange_(row ? row[dateColumn] : null, range)) return false;
    return filterMatchesDimensions_(row, dimensions);
  });
}

/** column の値の一覧を、全データから名前順（単純比較）で作る。空・null は外し、max を超えた分は切る */
export function dimensionOptions(rows, column, max = 200) {
  const list = Array.isArray(rows) ? rows : [];
  const seen = new Set();
  for (const row of list) {
    const value = row ? row[column] : undefined;
    if (value === null || value === undefined || value === "") continue;
    seen.add(String(value));
  }
  return Array.from(seen)
    .sort()
    .slice(0, max);
}

/**
 * 絞り込みを URL のハッシュの形にする（先頭に # は付けない）。
 * 鍵はすべて prefix（既定は "db"）と "." から始める。
 * 例: "db.p=last30&db.d.チャネル=EC"。custom のときは from/to を足す（指定した側だけ）。
 * 区分の絞り込みは、値が空文字の列を省く。列名・値はどちらも encodeURIComponent する
 */
export function encodeFilters(filters, prefix) {
  const source = filters || {};
  const head = filterPrefix_(prefix) + ".";
  const period = source.period || "";
  const parts = [head + "p=" + encodeURIComponent(period)];

  if (period === "custom") {
    if (source.from) parts.push(head + "from=" + encodeURIComponent(source.from));
    if (source.to) parts.push(head + "to=" + encodeURIComponent(source.to));
  }

  const dimensions = source.dimensions || {};
  for (const column of Object.keys(dimensions)) {
    const value = dimensions[column];
    if (value === undefined || value === null || value === "") continue;
    parts.push(head + "d." + encodeURIComponent(column) + "=" + encodeURIComponent(value));
  }

  return parts.join("&");
}

/** rawKey=rawValue の 1 組を安全に decodeURIComponent する。壊れた %encoding は null */
function filterDecodePair_(pair) {
  const eq = pair.indexOf("=");
  const rawKey = eq === -1 ? pair : pair.slice(0, eq);
  const rawValue = eq === -1 ? "" : pair.slice(eq + 1);
  try {
    return { key: decodeURIComponent(rawKey), value: decodeURIComponent(rawValue) };
  } catch {
    return null;
  }
}

/**
 * URL のハッシュ（先頭に # が付いていてもいなくてもよい）を、絞り込みの一部（partial）にする。
 * 読むのは prefix（既定は "db"）と "." から始まる鍵だけで、ほかの鍵は何も見ない
 * （ページ自身の目印や、同じページのもう 1 つのダッシュボードの鍵をそのまま置いておくため）。
 *
 * 知らない preset・知らない区分の列（config.filters.dimensions に無い列）・日付として読めない
 * from/to・壊れた %encoding は、それぞれその 1 項目だけを捨てる（例外は投げない）
 */
export function decodeFilters(hash, config, prefix) {
  const text = typeof hash === "string" ? hash : "";
  const body = text.startsWith("#") ? text.slice(1) : text;
  const head = filterPrefix_(prefix) + ".";
  const allowedDimensions = config && config.filters && Array.isArray(config.filters.dimensions) ? config.filters.dimensions : [];

  const result = {};
  // ここも列名がそのままキーになるので、initialFilters と同じくプロトタイプの無いオブジェクトにする
  const dimensions = Object.create(null);
  let hasDimensions = false;

  if (body === "") return result;

  for (const pair of body.split("&")) {
    if (pair === "") continue;
    const decoded = filterDecodePair_(pair);
    if (!decoded || !decoded.key.startsWith(head)) continue;
    const key = decoded.key.slice(head.length);
    const value = decoded.value;

    if (key === "p") {
      // 知らない期間の名前は、その 1 項目だけを捨てる（並びは設定の検査と同じ 1 か所から取る）
      if (CONFIG_PERIODS_.indexOf(value) !== -1) result.period = value;
    } else if (key === "from") {
      if (isDateKey(value)) result.from = value;
    } else if (key === "to") {
      if (isDateKey(value)) result.to = value;
    } else if (key.startsWith("d.")) {
      const column = key.slice(2);
      if (allowedDimensions.indexOf(column) !== -1) {
        dimensions[column] = value;
        hasDimensions = true;
      }
    }
  }

  if (hasDimensions) result.dimensions = dimensions;
  return result;
}
