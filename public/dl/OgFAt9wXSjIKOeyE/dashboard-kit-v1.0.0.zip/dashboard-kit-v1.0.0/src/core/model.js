/**
 * 設定・データ・絞り込みから、画面にそのまま描ける形（model）を組み立てる 1 か所。
 * 数・札・目盛り・色の番号・凡例の有無・「表で見る」の中身まで、迷いの残らないところまでここで決める。
 * 描く側は形を選ぶだけで、数の計算も書式づくりも行わない。
 * ここは純粋な計算だけを行う（「今日」は today "YYYY-MM-DD" で受け取る）
 */

import { textOf, toHalfWidth, estimateTextWidth, compareCells } from "./text.js";
import { formatNumber, niceTicks } from "./numbers.js";
import { isDateKey, toDateKey, monthOf, pad2, bucketLabel, previousRange } from "./dates.js";
import { t } from "./i18n.js";
import { resolveRange, applyFilters } from "./filter.js";
import { AGGREGATE_BUCKET_MAX_, aggregate, groupBy, topN, timeSeries, compareValue, compareEntriesDesc } from "./aggregate.js";
import { assignSeriesColors } from "./colors.js";

/** 折れ線の系列は 4 本まで（超えたら上位 3 + その他） */
const MODEL_LINE_SERIES_MAX_ = 4;
/** 積み上げの面は 6 つまで（超えたら上位 5 + その他） */
const MODEL_BAR_SEGMENT_MAX_ = 6;
/** 横棒の auto: 区分がこれを超えたら横にする */
const MODEL_BAR_WIDE_COUNT_ = 8;
/** 横棒の auto: 区分名 1 つに要る幅（名前の幅 + 両どなりとのすき間） */
const MODEL_LABEL_GAP_ = 12;
/** 横棒の auto: 縦に並べた区分名が収まる、図の横幅の目安 */
const MODEL_LABEL_ROOM_ = 560;
/** 区分の色は 8 個まで（9 個目は作らず、灰の 0 にまとめる） */
const MODEL_COLOR_MAX_ = 8;

/** 期間の名前ごとの「前の期間」の札。ここに無い期間（先月・期間の指定）は compare.generic */
const MODEL_COMPARE_KEYS_ = {
  thisMonth: "compare.lastMonth",
  last7: "compare.last7",
  last30: "compare.last30",
  last90: "compare.last90",
  thisYear: "compare.thisYear",
};

/** 名前をキーにした入れ物から、自身が持つ項目だけを取り出す（プロトタイプ越しの読み取りを防ぐ） */
function modelOwn_(box, name) {
  if (box === null || box === undefined || typeof box !== "object" || name === "") return undefined;
  return Object.prototype.hasOwnProperty.call(box, name) ? box[name] : undefined;
}

/** KPI の札・目標の札・棒の合計は、大きい数を縮める */
function modelShort_(value, format, lang) {
  return formatNumber(value, format, lang, { compact: true });
}

/** 表・吹き出し・面の値は縮めない */
function modelFull_(value, format, lang) {
  return formatNumber(value, format, lang);
}

/** CSV に入れる数。通貨の記号も桁区切りも付けない（表計算ソフトが数として読み戻せるように） */
function modelPlain_(value, format) {
  if (typeof value !== "number" || !Number.isFinite(value)) return "";
  const fmt = format !== null && typeof format === "object" ? format : { type: format };
  let decimals = fmt.type === "percent" ? 1 : 0;
  if (fmt.type === "custom" && Number.isFinite(fmt.decimals)) decimals = fmt.decimals;
  return value.toFixed(decimals);
}

/**
 * どの種類にも付く項目。描く側はこれを見て枠を作る。
 * note は設定に書かれた一言、limitNote は上限に当たったことをこちらから添える一言
 */
function modelBase_(widget, extra) {
  const base = {
    id: widget.id,
    type: widget.type,
    title: widget.title,
    size: widget.size,
    format: widget.format,
    note: widget.note || "",
    limitNote: "",
  };
  return Object.assign(base, extra);
}

/** 部品 1 つを誤りの札にする */
function modelErrorOf_(widget, message) {
  return { id: widget.id, type: "error", title: widget.title, message };
}

/** 系列が 1 本のときの札。題が空なら値の列の名前、それも空なら集計の名前を使う */
function modelSingleLabel_(widget, lang) {
  if (widget.title !== "") return widget.title;
  if (textOf(widget.value) !== "") return widget.value;
  return t(lang, "agg." + widget.agg);
}

/** そのデータセットが 20,000 行で切られていたら、画面の下に出す知らせの目印を立てる */
function modelMarkTruncated_(dataset, ctx) {
  if (dataset && dataset.truncated === true) ctx.truncated = true;
}

/** 読める数だけの最小・最大（seed から続けて求められる。読める数が 1 つも無ければ min は null） */
function modelExtent_(values, seed) {
  let min = seed ? seed.min : null;
  let max = seed ? seed.max : null;
  for (const value of values) {
    if (typeof value !== "number" || !Number.isFinite(value)) continue;
    if (min === null || value < min) min = value;
    if (max === null || value > max) max = value;
  }
  return { min, max };
}

/**
 * そのデータセットに効く区分の絞り込みだけを取り出す。データセットに無い列の絞り込みは
 * 見ない（例: 目標のデータに「チャネル」の列が無くても、チャネルの絞り込みで空にならない）
 */
function modelDimensionsFor_(dataset, ctx) {
  const cached = ctx.dimensionCache.get(dataset);
  if (cached) return cached;
  const known = new Set(Array.isArray(dataset.columns) ? dataset.columns : []);
  const source = ctx.filters && ctx.filters.dimensions ? ctx.filters.dimensions : {};
  const picked = Object.create(null);
  for (const column of Object.keys(source)) {
    if (known.has(column)) picked[column] = source[column];
  }
  ctx.dimensionCache.set(dataset, picked);
  return picked;
}

/** 設定に書かれた、そのデータセットの日付の列（無ければ ""） */
function modelDateColumn_(ctx, name) {
  const entry = modelOwn_(ctx.config.datasets, name);
  return entry ? textOf(entry.dateColumn) : "";
}

/** 部品が使う行（期間と区分で絞り込んだあと） */
function modelRows_(dataset, name, ctx, range) {
  return applyFilters(dataset.rows, { dateColumn: modelDateColumn_(ctx, name), range, dimensions: modelDimensionsFor_(dataset, ctx) });
}

// ---- 列の関門 -------------------------------------------------------------

/**
 * 部品が名ざしする列を、確かめる順に並べる。件数を数えるだけのときの値の列のように、
 * 読まない列は入れない。データセットの日付の列（期間の絞り込みに使う）は、設定されていれば
 * 部品の種類によらずいちばん先に確かめる。無いままだと絞り込みが全部の行を静かに落としてしまうため
 */
function modelNamedColumns_(widget, ctx) {
  const names = [modelDateColumn_(ctx, widget.dataset), widget.agg === "count" ? "" : widget.value];
  if (widget.type === "line") names.push(widget.splitBy, widget.dateColumn);
  if (widget.type === "bar") names.push(widget.category, widget.splitBy);
  if (widget.type === "table" && widget.rows === "latest") return names.concat(widget.columns);
  if (widget.type === "table") return names.concat(widget.groupBy, widget.columns.map((column) => (column.agg === "count" ? "" : column.value)));
  return names;
}

/**
 * names のうち、そのデータセットに無い列を先頭から探す（すべてあれば ""）。
 * 列の一覧を持たないデータセットは確かめようがないので、そのまま通す
 */
function modelMissingColumn_(dataset, names) {
  if (!Array.isArray(dataset.columns) || dataset.columns.length === 0) return "";
  const known = new Set(dataset.columns);
  for (const name of names) {
    if (textOf(name) !== "" && !known.has(name)) return name;
  }
  return "";
}

/** 列が見つからないことを知らせる文（データの名前と列の名前を添える） */
function modelColumnMissing_(ctx, datasetName, column) {
  return t(ctx.lang, "error.columnMissing", { dataset: datasetName, column });
}

/**
 * 分ける列の値ごとにまとめ、大きい順に並べて上限に収める（折れ線の系列と棒の面で同じ手順を使う）。
 * 合計・件数は足し合わせられるので、上限 - 1 件を残して残りを「その他」にまとめる。
 * 平均・種類の数・最小・最大は足し合わせられないので、上限までで切る（「その他」は作らない）。
 * 色は絞り込む前の全データの並びで決めるので、絞り込んでも番号は変わらない
 */
function modelSplitGroups_(widget, ctx, dataset, rows, max) {
  const blank = t(ctx.lang, "label.blank");
  const groups = groupBy(rows, widget.splitBy, blank);
  const entries = [];
  for (const [key, part] of groups) {
    entries.push({ key, value: aggregate(part, widget.value, widget.agg).value, rows: part });
  }
  entries.sort(compareEntriesDesc);

  const other = entries.length > max && (widget.agg === "sum" || widget.agg === "count");
  const keep = other ? max - 1 : max;
  return {
    kept: entries.slice(0, keep),
    rest: entries.slice(keep),
    other,
    blank,
    colors: assignSeriesColors(dataset.rows, widget.splitBy, widget.value, widget.agg, MODEL_COLOR_MAX_, blank),
  };
}

// ---- kpi ------------------------------------------------------------------

/**
 * 前の期間との差。割合が出せないとき（前が 0）は、差そのものを符号つきで出す。
 * text は札に載せる縮めた文字、textFull は表に入れる縮めない文字（割合のときはどちらも同じ）
 */
function modelDelta_(compared, widget, lang, period) {
  const direction = compared.delta > 0 ? "up" : compared.delta < 0 ? "down" : "flat";
  const sign = direction === "up" ? "+" : direction === "down" ? "-" : "";
  const gap = Math.abs(compared.delta);
  const ratioText = compared.ratio === null ? "" : sign + formatNumber(Math.abs(compared.ratio * 100), "percent", lang, { decimals: 1 });
  const known = Object.prototype.hasOwnProperty.call(MODEL_COMPARE_KEYS_, period);
  return {
    text: ratioText || sign + modelShort_(gap, widget.format, lang),
    textFull: ratioText || sign + modelFull_(gap, widget.format, lang),
    direction,
    good: direction === "flat" ? null : (direction === "up") === (widget.goodWhen === "up"),
    label: t(lang, known ? MODEL_COMPARE_KEYS_[period] : "compare.generic"),
  };
}

/** KPI の小さな折れ線。刻みが 2 つに満たないとき・読める値が 1 つも無いときは作らない */
function modelSpark_(widget, ctx, rows, dateColumn) {
  if (widget.sparkline !== true || dateColumn === "") return null;
  const made = timeSeries(rows, { dateColumn, value: widget.value, agg: widget.agg, range: ctx.range, bucket: "auto" });
  if (made.buckets.length < 2) return null;
  const extent = modelExtent_(made.values);
  return extent.min === null ? null : { values: made.values, min: extent.min, max: extent.max };
}

function modelKpi_(widget, ctx, dataset, rows) {
  const lang = ctx.lang;
  const main = aggregate(rows, widget.value, widget.agg);
  const dateColumn = modelDateColumn_(ctx, widget.dataset);

  let delta = null;
  let previousText = "—";
  const comparable = widget.compare === "previous" && dateColumn !== "" && ctx.previous.from !== "" && ctx.previous.to !== "";
  if (comparable) {
    // 前の期間に行が 1 つも無いときは、比べる相手がないので差を出さない（0 と比べない）
    const beforeRows = modelRows_(dataset, widget.dataset, ctx, ctx.previous);
    if (beforeRows.length > 0) {
      const before = aggregate(beforeRows, widget.value, widget.agg);
      previousText = modelFull_(before.value, widget.format, lang);
      const compared = compareValue(main.value, before.value);
      if (compared) delta = modelDelta_(compared, widget, lang, ctx.filters ? ctx.filters.period : "");
    }
  }

  const valueFull = modelFull_(main.value, widget.format, lang);
  return modelBase_(widget, {
    valueText: modelShort_(main.value, widget.format, lang),
    valueFull,
    delta,
    spark: modelSpark_(widget, ctx, rows, dateColumn),
    skipped: main.skipped,
    table: {
      head: [t(lang, "table.item"), t(lang, "table.value"), t(lang, "table.previous"), t(lang, "table.delta")],
      // 表は縮めない書式でそろえる（札の +¥3.3万 ではなく +¥33,000 を入れる）
      rows: [[widget.title, valueFull, previousText, delta ? delta.textFull : "—"]],
    },
  });
}

// ---- line -----------------------------------------------------------------

/** 期間の片側が開いているときは、行にある日付の端を使って刻みの範囲を決める */
function modelSpan_(rows, dateColumn, range) {
  const from = range.from || "";
  const to = range.to || "";
  if (from !== "" && to !== "") return { from, to };
  let min = "";
  let max = "";
  for (const row of rows) {
    const key = row ? row[dateColumn] : null;
    if (!isDateKey(key)) continue;
    if (min === "" || key < min) min = key;
    if (max === "" || key > max) max = key;
  }
  return min === "" ? null : { from: from || min, to: to || max };
}

/** rows の dateColumn にある、いちばん新しい日付キー（読める日付が無ければ ""） */
function modelLatestDateKey_(rows, dateColumn) {
  if (dateColumn === "") return "";
  let latest = "";
  for (const row of rows) {
    const key = row ? row[dateColumn] : null;
    if (!isDateKey(key)) continue;
    if (latest === "" || key > latest) latest = key;
  }
  return latest;
}

/** 並びの最後にある、読める値（端のラベルはここに置く） */
function modelLastValue_(values) {
  for (let i = values.length - 1; i >= 0; i -= 1) {
    if (typeof values[i] === "number" && Number.isFinite(values[i])) return values[i];
  }
  return null;
}

/** 折れ線の系列（key・札・色・元の行）を、上限 4 本に収めて決める */
function modelLineSeries_(widget, ctx, dataset, rows) {
  if (widget.splitBy === "") {
    const label = modelSingleLabel_(widget, ctx.lang);
    return [{ key: label, label, color: 1, rows }];
  }

  const split = modelSplitGroups_(widget, ctx, dataset, rows, MODEL_LINE_SERIES_MAX_);
  const series = split.kept.map((entry) => ({ key: entry.key, label: entry.key, color: split.colors.get(entry.key) || 0, rows: entry.rows }));
  if (split.other) {
    const rest = [];
    for (const entry of split.rest) {
      for (const row of entry.rows) rest.push(row);
    }
    const label = t(ctx.lang, "label.other");
    series.push({ key: label, label, color: 0, rows: rest });
  }
  return series;
}

/**
 * 折れ線の目盛り。値がすべて同じ（平らな線）のときは、そのままだと上下の幅が 0 になり
 * niceTicks が [0, 1] を返して線が図の外へ出てしまうので、0 まで伸ばした範囲で作る。
 * 上が 0 の（すべて 0 以下の）範囲も、棒と同じく正負をひっくり返して作ってから裏返す
 */
function modelLineTicks_(min, max) {
  const flat = min === max;
  return modelBarTicks_(flat ? Math.min(0, min) : min, flat ? Math.max(0, max) : max);
}

/** 描くものが無い折れ線（誤りではなく「データがありません」を出してもらう。表の見出しは持たせる） */
function modelLineEmpty_(widget, lang, skipped) {
  const table = { head: [widget.dateColumn, modelSingleLabel_(widget, lang)], rows: [] };
  return { empty: true, series: [], buckets: [], ticks: [0, 1], yMax: 1, legend: false, area: false, skipped, table };
}

function modelLine_(widget, ctx, dataset, rows) {
  const lang = ctx.lang;
  const skipped = aggregate(rows, widget.value, widget.agg).skipped;
  const span = rows.length === 0 ? null : modelSpan_(rows, widget.dateColumn, ctx.range);
  const defs = span === null ? [] : modelLineSeries_(widget, ctx, dataset, rows);
  if (defs.length === 0) return modelBase_(widget, modelLineEmpty_(widget, lang, skipped));

  // 刻みの並びと単位は系列ごとに決めず、同じ範囲から部品ぜんたいで 1 回だけ決めて全系列にそろえる
  const options = { dateColumn: widget.dateColumn, value: widget.value, agg: widget.agg, range: span, bucket: widget.bucket };
  const axis = timeSeries(rows, options);
  const series = defs.map((def) => {
    const made = timeSeries(def.rows, options);
    return { key: def.key, label: def.label, color: def.color, values: made.values, lastLabel: "" };
  });

  let extent = { min: null, max: null };
  for (const line of series) {
    extent = modelExtent_(line.values, extent);
    line.lastLabel = modelShort_(modelLastValue_(line.values), widget.format, lang);
  }
  if (extent.min === null) return modelBase_(widget, modelLineEmpty_(widget, lang, skipped));

  const ticks = modelLineTicks_(extent.min, extent.max);
  // buckets[].key は、描くときには使わないが、model を読んで独自の図を作る買い手のために残してある
  const buckets = axis.buckets.map((key) => ({ key, label: bucketLabel(key, axis.bucket, lang) }));
  return modelBase_(widget, {
    empty: false,
    series,
    buckets,
    ticks,
    yMax: ticks[ticks.length - 1],
    // 刻みが上限を超えて、新しいほうだけを出したときは、そのことを札の下に添える
    limitNote: axis.capped === true ? t(lang, "state.bucketCapped", { count: AGGREGATE_BUCKET_MAX_ }) : "",
    legend: series.length >= 2,
    area: series.length === 1,
    skipped,
    table: {
      head: [widget.dateColumn].concat(series.map((line) => line.label)),
      rows: buckets.map((bucket, index) => [bucket.label].concat(series.map((line) => modelFull_(line.values[index], widget.format, lang)))),
    },
  });
}

// ---- bar ------------------------------------------------------------------
//
// 棒は 0 の線から両側へ積む（縦棒は正が上・負が下、横棒は正が右・負が左）。面の値は符号の
// ついたまま持ち、区分ごとに正の面の和 posTotal と負の面の和 negTotal を添える。軸はいちばん
// 大きい posTotal といちばん小さい negTotal を覆い、min（負が無ければ 0）と max で両端を示す。
// 並べ替えと「その他」へのまとめ、吹き出しの札は、正味の合計 total で決める

/** 積み上げの面の並び（どの区分でも同じ順・同じ色にするので、先に全体で決める） */
function modelBarPlan_(widget, ctx, dataset, rows) {
  if (widget.splitBy === "") return null;
  const split = modelSplitGroups_(widget, ctx, dataset, rows, MODEL_BAR_SEGMENT_MAX_);
  const keys = split.kept.map((entry) => entry.key);
  return { keys, keySet: new Set(keys), other: split.other, blank: split.blank, colors: split.colors };
}

/** 区分 1 つぶんの面。分ける列が無ければ、棒まるごとが 1 つの面（色は 1。「その他」だけ灰の 0） */
function modelBarSegments_(widget, ctx, entry, plan) {
  const lang = ctx.lang;
  if (plan === null) {
    const color = entry.isOther === true ? 0 : 1;
    return [{ key: entry.key, label: entry.key, color, value: entry.value, valueText: modelFull_(entry.value, widget.format, lang) }];
  }

  const groups = groupBy(entry.rows || [], widget.splitBy, plan.blank);
  const segments = plan.keys.map((key) => {
    const value = aggregate(groups.get(key) || [], widget.value, widget.agg).value;
    return { key, label: key, color: plan.colors.get(key) || 0, value, valueText: modelFull_(value, widget.format, lang) };
  });
  if (plan.other) {
    const rest = [];
    for (const [key, part] of groups) {
      if (plan.keySet.has(key)) continue;
      for (const row of part) rest.push(row);
    }
    const label = t(lang, "label.other");
    const value = aggregate(rest, widget.value, widget.agg).value;
    segments.push({ key: label, label, color: 0, value, valueText: modelFull_(value, widget.format, lang) });
  }
  return segments;
}

/** 0 の線から上（右）へ積む面の和と、下（左）へ積む面の和 */
function modelBarTotals_(segments) {
  let posTotal = 0;
  let negTotal = 0;
  for (const segment of segments) {
    if (typeof segment.value !== "number" || !Number.isFinite(segment.value)) continue;
    if (segment.value > 0) posTotal += segment.value;
    else negTotal += segment.value;
  }
  return { posTotal, negTotal };
}

/**
 * 棒の目盛り。負の側があれば 0 をまたぐ範囲にする。すべてが負のとき（正の側が 0）は、
 * niceTicks が上端 0 の範囲を [0, 1] にしてしまうので、正負をひっくり返して作ってから裏返す
 */
function modelBarTicks_(minNeg, maxPos) {
  // 0 - value で引くのは、0 を裏返したときに -0 を作らないため
  if (minNeg < 0 && maxPos <= 0) return niceTicks(0, -minNeg).map((value) => 0 - value).reverse();
  return niceTicks(minNeg, maxPos);
}

/**
 * 横棒にするか。設定の true / false が auto に勝つ。
 * auto のときは、区分の数と「区分名を縦に並べたときに要る幅」で決める。
 * 字数ではなく幅で見るので、半角ばかりの名前が早々に横へ回ることがない
 * （見積もりは描く側と同じ estimateTextWidth を使う）
 */
function modelBarHorizontal_(widget, categories) {
  if (widget.horizontal === true || widget.horizontal === false) return widget.horizontal;
  if (categories.length > MODEL_BAR_WIDE_COUNT_) return true;
  let widest = 0;
  for (const category of categories) widest = Math.max(widest, estimateTextWidth(category.label));
  return categories.length * (widest + MODEL_LABEL_GAP_) > MODEL_LABEL_ROOM_;
}

function modelBar_(widget, ctx, dataset, rows) {
  const lang = ctx.lang;
  const blank = t(lang, "label.blank");
  const groups = groupBy(rows, widget.category, blank);

  const entries = [];
  for (const [key, part] of groups) {
    entries.push({ key, value: aggregate(part, widget.value, widget.agg).value, rows: part });
  }
  const cut = topN(entries, widget.top, t(lang, "label.other"), widget.agg);
  if (cut.other) {
    // 「その他」の棒には、上位から外れた区分の行をまとめて持たせる（積み上げの面を作るため）
    const kept = new Set(cut.entries.filter((entry) => entry.isOther !== true).map((entry) => entry.key));
    const rest = [];
    for (const [key, part] of groups) {
      if (kept.has(key)) continue;
      for (const row of part) rest.push(row);
    }
    cut.entries[cut.entries.length - 1].rows = rest;
  }
  if (widget.sort === "label") {
    // 名前の並びでも「その他」はいつも最後
    cut.entries.sort((a, b) => {
      if (a.isOther === true || b.isOther === true) return (a.isOther === true ? 1 : 0) - (b.isOther === true ? 1 : 0);
      return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
    });
  }

  const plan = modelBarPlan_(widget, ctx, dataset, rows);
  let maxPos = 0;
  let minNeg = 0;
  const categories = cut.entries.map((entry) => {
    const segments = modelBarSegments_(widget, ctx, entry, plan);
    const { posTotal, negTotal } = modelBarTotals_(segments);
    if (posTotal > maxPos) maxPos = posTotal;
    if (negTotal < minNeg) minNeg = negTotal;
    const totalText = modelShort_(entry.value, widget.format, lang);
    // key は label と同じ値だが、描くときには使わない（model を読む買い手のための目印として残してある）
    return { key: entry.key, label: entry.key, total: entry.value, totalText, posTotal, negTotal, segments };
  });
  const ticks = modelBarTicks_(minNeg, maxPos);

  // 凡例は分ける列があって、色が 2 つ以上あるときだけ（大きさだけを見せる棒は 1 系列なので出さない）
  const colorsInPlay = new Set();
  if (plan !== null && categories.length > 0) {
    for (const segment of categories[0].segments) colorsInPlay.add(segment.color);
  }
  const headLabels = plan === null ? [modelSingleLabel_(widget, lang)] : categories.length > 0 ? categories[0].segments.map((segment) => segment.label) : [];

  return modelBase_(widget, {
    empty: categories.length === 0,
    horizontal: modelBarHorizontal_(widget, categories),
    categories,
    ticks,
    min: ticks[0],
    max: ticks[ticks.length - 1],
    legend: colorsInPlay.size >= 2,
    skipped: aggregate(rows, widget.value, widget.agg).skipped,
    table: {
      head: [widget.category].concat(headLabels),
      rows: categories.map((category) =>
        plan === null
          ? [category.label, modelFull_(category.total, widget.format, lang)]
          : [category.label].concat(category.segments.map((segment) => segment.valueText))
      ),
    },
  });
}

// ---- meter ----------------------------------------------------------------

/** 目標の行の「月」のセルを "YYYY-MM" にする。YYYY-MM・日付・YYYY/M・YYYY年M月 を読む */
function modelMonthOf_(cell) {
  const key = toDateKey(cell);
  if (key !== "") return monthOf(key);
  const text = toHalfWidth(textOf(cell)).trim();
  const matched = text.match(/^(\d{4})[-/年.](\d{1,2})月?$/);
  if (!matched) return "";
  const month = Number(matched[2]);
  if (month < 1 || month > 12) return "";
  return matched[1] + "-" + pad2(month);
}

/**
 * 目標を探す月を決める。期間の終わり（range.to）が決まっていればその月。
 * 「全期間」のように終わりが開いているときは、絞り込んだあとのデータのいちばん新しい
 * 日付の月を使う（固定の日付の見本でも、その月の目標が出るように）。
 * 日付の列が無い・読める日付が 1 つも無いときだけ today の月にする
 */
function modelTargetDay_(widget, ctx, rows) {
  if (ctx.range.to !== "") return ctx.range.to;
  const latest = modelLatestDateKey_(rows, modelDateColumn_(ctx, widget.dataset));
  return latest !== "" ? latest : ctx.today;
}

/**
 * 目標の数を決める。数の設定はそのまま、データを指した設定は「その月」の行から集める。
 * actualRows は実績の側の（絞り込んだあとの）行で、目標を探す月を決めるためだけに使う。
 * 月から引いた目標には、その月（month は "YYYY-MM"、monthLabel は画面に出す札）を添える
 */
function modelTarget_(widget, ctx, actualRows) {
  const target = widget.target;
  if (typeof target === "number") return { value: target, month: "", monthLabel: "" };

  const dataset = modelOwn_(ctx.datasets, target.dataset);
  if (!dataset) return { message: t(ctx.lang, "error.datasetMissing", { name: target.dataset }) };
  modelMarkTruncated_(dataset, ctx);
  // 目標のデータの日付の列も、設定されていれば他の列より先に確かめる（絞り込みには使わないが、部品の種類と決まりをそろえる）
  const missing = modelMissingColumn_(dataset, [modelDateColumn_(ctx, target.dataset), target.agg === "count" ? "" : target.value, target.matchMonth]);
  if (missing !== "") return { message: modelColumnMissing_(ctx, target.dataset, missing) };

  const day = modelTargetDay_(widget, ctx, actualRows);
  const month = isDateKey(day) ? monthOf(day) : "";
  const monthText = month === "" ? textOf(day) : bucketLabel(month, "month", ctx.lang);
  // 目標のデータには期間の絞り込みをかけない（月の一致で 1 行を選ぶため）
  const rows = applyFilters(dataset.rows, { dateColumn: "", range: { from: "", to: "" }, dimensions: modelDimensionsFor_(dataset, ctx) });
  const matched = [];
  for (const row of rows) {
    if (modelMonthOf_(row ? row[target.matchMonth] : null) === month) matched.push(row);
  }
  if (month === "" || matched.length === 0) return { message: t(ctx.lang, "error.goalMissing", { month: monthText }) };
  return { value: aggregate(matched, target.value, target.agg).value, month, monthLabel: monthText };
}

/**
 * 月から引いた目標は、その月の行とだけ比べる（「全期間」で半年ぶんの売上を、
 * ひと月の目標にぶつけないため）。日付の列が無いデータは月で分けようがないので、
 * 絞り込んだ行をそのまま使い、月の札も出さない
 */
function modelMeterMonth_(widget, ctx, rows, target) {
  const dateColumn = modelDateColumn_(ctx, widget.dataset);
  if (target.month === "" || dateColumn === "") return { rows, label: "" };
  const inMonth = rows.filter((row) => {
    const key = row ? row[dateColumn] : null;
    return isDateKey(key) && monthOf(key) === target.month;
  });
  return { rows: inMonth, label: target.monthLabel };
}

function modelMeter_(widget, ctx, rows) {
  const lang = ctx.lang;
  const target = modelTarget_(widget, ctx, rows);
  if (target.message) return modelErrorOf_(widget, target.message);
  if (typeof target.value !== "number" || !Number.isFinite(target.value) || target.value <= 0) {
    return modelErrorOf_(widget, t(lang, "error.goalNotPositive"));
  }

  const month = modelMeterMonth_(widget, ctx, rows, target);
  const main = aggregate(month.rows, widget.value, widget.agg);
  const ratio = (main.value === null ? 0 : main.value) / target.value;
  const ratioText = formatNumber(ratio * 100, "percent", lang, { decimals: 0 });
  const valueFull = modelFull_(main.value, widget.format, lang);
  const targetFull = modelFull_(target.value, widget.format, lang);
  return modelBase_(widget, {
    valueText: modelShort_(main.value, widget.format, lang),
    valueFull,
    targetText: modelShort_(target.value, widget.format, lang),
    targetFull,
    ratio,
    ratioText,
    achieved: ratio >= 1,
    skipped: main.skipped,
    // 月から引いた目標のときだけ、どの月の数字なのかを添える（数の目標は期間ぜんたい）
    monthLabel: month.label,
    table: {
      head: [t(lang, "table.item"), t(lang, "table.value")],
      rows: (month.label === "" ? [] : [[t(lang, "label.targetMonth"), month.label]]).concat([
        [t(lang, "label.actual"), valueFull],
        [t(lang, "label.goal"), targetFull],
        [t(lang, "label.progress"), ratioText],
      ]),
    },
  });
}

// ---- table ----------------------------------------------------------------

/** 並べ替えに使う列。設定の sort は列の札で指す。見つからなければ 1 つめの集計の列 */
function modelSortIndex_(widget, head) {
  const sort = textOf(widget.sort);
  if (sort !== "") {
    for (let i = 0; i < head.length; i += 1) {
      if (head[i].label === sort) return i;
    }
  }
  return head.length > 1 ? 1 : 0;
}

/**
 * at 列で並べ替える。空（null・空文字）はいつも最後、同じ値のときは元の並びのまま。
 * 比べ方は compareCells の 1 か所だけにあり、画面の並べ替え（render-table.js）と同じ
 */
function modelSortRows_(body, at, order) {
  body.sort((a, b) => compareCells(a[at].value, b[at].value, order));
}

/** 表の model（区分ごとの表と明細の表で、同じ組み立てを使う）。plainOf は CSV の 1 マスを作る */
function modelTableOf_(widget, head, body, skipped, plainOf) {
  const labels = head.map((column) => column.label);
  return modelBase_(widget, {
    empty: body.length === 0,
    head,
    rows: body,
    // 描くときには使わないが、model を読んで独自の表を作る買い手のために残してある目印
    sortable: true,
    csv: [labels].concat(body.map((cells) => cells.map(plainOf))),
    skipped,
    table: { head: labels, rows: body.map((cells) => cells.map((cell) => cell.text)) },
  });
}

/** 区分ごとにまとめた表 */
function modelTableGrouped_(widget, ctx, rows) {
  const lang = ctx.lang;
  const head = [{ label: widget.groupBy, numeric: false }].concat(widget.columns.map((column) => ({ label: column.label, numeric: true })));
  const groups = groupBy(rows, widget.groupBy, t(lang, "label.blank"));

  const body = [];
  for (const [key, part] of groups) {
    const cells = [{ text: key, value: key }];
    for (const column of widget.columns) {
      const value = aggregate(part, column.value, column.agg).value;
      cells.push({ text: modelFull_(value, column.format, lang), value });
    }
    body.push(cells);
  }
  modelSortRows_(body, modelSortIndex_(widget, head), widget.order);

  // のぞいた値の数は、集計するすべての列ぶんを足す（列ごとに数として読めない値を外すため）
  let skipped = 0;
  for (const column of widget.columns) skipped += aggregate(rows, column.value, column.agg).skipped;

  const plainOf = (cell, index) => (index === 0 ? cell.text : modelPlain_(cell.value, widget.columns[index - 1].format));
  return modelTableOf_(widget, head, body.slice(0, widget.top), skipped, plainOf);
}

/** 明細のセル 1 つ。数は桁区切りだけ、日付は日付キーのまま、それ以外は文字のまま */
function modelDetailCell_(row, column, types, lang) {
  const raw = row ? row[column] : undefined;
  if (modelOwn_(types, column) === "number") {
    const value = typeof raw === "number" && Number.isFinite(raw) ? raw : null;
    return { text: modelFull_(value, "number", lang), value };
  }
  const text = textOf(raw);
  return { text, value: text };
}

/** 新しい順の明細の表 */
function modelTableLatest_(widget, ctx, dataset, rows) {
  const lang = ctx.lang;
  const types = dataset.types || {};
  const dateColumn = modelDateColumn_(ctx, widget.dataset);
  const head = widget.columns.map((column) => ({ label: column, numeric: modelOwn_(types, column) === "number" }));

  const sorted = rows.slice();
  if (dateColumn !== "") {
    sorted.sort((a, b) => {
      const av = a ? a[dateColumn] : null;
      const bv = b ? b[dateColumn] : null;
      const aEmpty = !isDateKey(av);
      const bEmpty = !isDateKey(bv);
      if (aEmpty || bEmpty) return aEmpty && bEmpty ? 0 : aEmpty ? 1 : -1;
      return av < bv ? 1 : av > bv ? -1 : 0;
    });
  }
  const body = sorted.slice(0, widget.top).map((row) => widget.columns.map((column) => modelDetailCell_(row, column, types, lang)));

  const plainOf = (cell, index) => (head[index].numeric ? modelPlain_(cell.value, "number") : cell.text);
  return modelTableOf_(widget, head, body, 0, plainOf);
}

// ---- 組み立て -------------------------------------------------------------

function modelWidget_(widget, ctx) {
  // 設定の誤りの札（config.js が作ったもの）はそのまま通す
  if (!widget || widget.type === "error") return widget;

  const dataset = modelOwn_(ctx.datasets, widget.dataset);
  if (!dataset) return modelErrorOf_(widget, t(ctx.lang, "error.datasetMissing", { name: widget.dataset }));
  modelMarkTruncated_(dataset, ctx);

  // 列の書き間違いは、そのままだと「それらしいグラフ」になって気づけないので、描く前にここで止める
  const missing = modelMissingColumn_(dataset, modelNamedColumns_(widget, ctx));
  if (missing !== "") return modelErrorOf_(widget, modelColumnMissing_(ctx, widget.dataset, missing));

  const rows = modelRows_(dataset, widget.dataset, ctx, ctx.range);
  if (widget.type === "kpi") return modelKpi_(widget, ctx, dataset, rows);
  if (widget.type === "line") return modelLine_(widget, ctx, dataset, rows);
  if (widget.type === "bar") return modelBar_(widget, ctx, dataset, rows);
  if (widget.type === "meter") return modelMeter_(widget, ctx, rows);
  return widget.rows === "latest" ? modelTableLatest_(widget, ctx, dataset, rows) : modelTableGrouped_(widget, ctx, rows);
}

/**
 * そろった設定（parseConfig の config）・データセット・絞り込み・today・言語から、
 * 画面に描く形をひととおり作る。datasets は { 名前: { columns, rows（型をそろえた行）, types, truncated } }。
 * 戻り値は { title, range, previous, widgets, notes }
 */
export function buildDashboard(input) {
  const options = input && typeof input === "object" ? input : {};
  const config = options.config && typeof options.config === "object" ? options.config : {};
  const lang = options.lang === "en" || options.lang === "ja" ? options.lang : config.lang === "en" ? "en" : "ja";
  const today = textOf(options.today);
  const filters = options.filters && typeof options.filters === "object" ? options.filters : { period: "all", dimensions: {} };
  const range = resolveRange(filters, today);

  const datasets = options.datasets && typeof options.datasets === "object" ? options.datasets : {};
  const previous = previousRange(range);
  // dimensionCache は、同じデータセットに効く絞り込みを部品ごとに作り直さないための覚え書き
  const ctx = { config: { datasets: config.datasets || {} }, datasets, filters, range, previous, today, lang, truncated: false, dimensionCache: new Map() };

  const widgets = (Array.isArray(config.widgets) ? config.widgets : []).map((widget) => modelWidget_(widget, ctx));
  const notes = [];
  if (ctx.truncated) notes.push(t(lang, "state.truncated"));

  return { title: textOf(config.title), range, previous: ctx.previous, widgets, notes };
}
