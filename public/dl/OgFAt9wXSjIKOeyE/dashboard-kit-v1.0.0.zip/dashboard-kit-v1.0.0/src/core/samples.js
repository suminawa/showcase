/**
 * しおかぜ珈琲店（架空の店・みなと市）の見本データを、today から決まった式だけで作る 1 か所。
 * 乱数は使わず、日付・行番号から作る線形合同法（LCG）だけで揺らぎを作る。
 * 同じ today なら何度呼んでも同じ出力になり、today が違えば違う（けれど同じ形の）出力になる。
 * ここは純粋な計算だけを行う（「今日」は today "YYYY-MM-DD" で受け取る）
 *
 * 金額はどの行も必ず「数量 × その商品の決まった単価」（SAMPLE_PRODUCTS）で、あとから金額に
 * 縮尺を掛けたりはしない。月ごとの売上のねらい（samplesMonthTarget_）に近づけるのは、
 * その月に何が・どれだけ売れたか（行数・数量）を動かすことだけで行う
 */

import { addDays, monthOf, weekdayOf, bucketsBetween, diffDays } from "./dates.js";
import { CONFIG_DEFINITION_COLUMNS_ } from "./config.js";

/** 見本の売上は today から遡って何日ぶんか（today を含む） */
const SAMPLES_SPAN_DAYS_ = 180;
/** 1 日あたりの行数の範囲 */
const SAMPLES_ROWS_PER_DAY_ = [3, 9];
/** 卸（大口）は 1 か月に 3〜4 件（乱数の日ではなく、月ごとに決まった日にする）。そのときの数量の範囲 */
const SAMPLES_WHOLESALE_ORDERS_PER_MONTH_RANGE_ = [3, 4];
const SAMPLES_WHOLESALE_QTY_RANGE_ = [10, 40];
/** EC は月を追って伸びる（月あたりの伸び率） */
const SAMPLES_ONLINE_GROWTH_PER_MONTH_ = 1.06;
/** 週末は店頭の数量が増える */
const SAMPLES_WEEKEND_STORE_MULTIPLIER_ = 1.4;
const SAMPLES_GIFT_BOOST_MULTIPLIER_ = 1.5;
const SAMPLES_GIFT_WEIGHT_BOOST_ = 3;
/** 数量は、この額から月を追ってゆるやかに伸びる月間売上になるよう調整する（金額そのものは動かさない） */
const SAMPLES_MONTH_BASE_REVENUE_ = 1200000;
const SAMPLES_MONTH_GROWTH_PER_MONTH_ = 1.06;
/** 12 月（ギフトの山）だけ、月ごとの伸びに重ねて掛ける割り増し */
const SAMPLES_DECEMBER_LIFT_MULTIPLIER_ = 1.2;
/** 目標額は、月ごとの売上のねらい額にこれを掛ける（達成率が 100% ぴったりにならないように） */
const SAMPLES_TARGET_MARGIN_ = 1.05;
/** 数量の調整（demand）で動かしてよい倍率の範囲。行の姿（少量ずつ）を保つための歯止め */
const SAMPLES_DEMAND_RANGE_ = [0.6, 2.6];
/** 1 行の数量の上限（正の整数） */
const SAMPLES_QTY_MAX_ = 60;

/** チャネル（ja / en） */
const SAMPLES_CHANNELS_ = {
  store: { ja: "店頭", en: "Store" },
  online: { ja: "EC", en: "Online" },
  wholesale: { ja: "卸", en: "Wholesale" },
};

/** カテゴリ（キー・ja / en・重み・数量のふつうの範囲）。商品は SAMPLE_PRODUCTS の category で結びつける */
const SAMPLES_CATEGORY_DEFS_ = [
  { key: "coffee", ja: "コーヒー豆", en: "Coffee beans", weight: 0.38, qty: [1, 3] },
  { key: "drip", ja: "ドリップバッグ", en: "Drip bags", weight: 0.24, qty: [1, 4] },
  { key: "equipment", ja: "器具", en: "Equipment", weight: 0.1, qty: [1, 2] },
  { key: "baked", ja: "焼き菓子", en: "Baked goods", weight: 0.24, qty: [1, 5] },
  { key: "gift", ja: "ギフト", en: "Gifts", weight: 0.04, qty: [1, 2] },
];
const SAMPLES_GIFT_CATEGORY_KEY_ = "gift";

/**
 * 見本の商品と、その決まった単価（円・10 円刻み・300〜12,000 円）。金額はどの行でも
 * 「数量 × ここにある単価」で決まり、これ以外の場所で金額を作らない・動かさない。
 * key は行の商品を指す内部の名前、category は SAMPLES_CATEGORY_DEFS_ の key
 */
export const SAMPLE_PRODUCTS = [
  { key: "blend", ja: "しおかぜブレンド", en: "Shiokaze Blend", category: "coffee", price: 2000 },
  { key: "kilimanjaro", ja: "深煎り キリマンジャロ", en: "Dark Roast Kilimanjaro", category: "coffee", price: 2200 },
  { key: "ethiopia", ja: "浅煎り エチオピア", en: "Light Roast Ethiopia", category: "coffee", price: 2400 },
  { key: "subscription", ja: "珈琲豆 定期便セット", en: "Coffee Bean Subscription Set", category: "coffee", price: 3800 },
  { key: "morningDrip", ja: "朝のドリップバッグ 10 袋", en: "Morning Drip Bags (10-pack)", category: "drip", price: 1600 },
  { key: "eveningDrip", ja: "夜のドリップバッグ 10 袋", en: "Evening Drip Bags (10-pack)", category: "drip", price: 1600 },
  { key: "dripAssortment", ja: "ドリップバッグ 詰め合わせ 20 袋", en: "Drip Bag Assortment (20-pack)", category: "drip", price: 3000 },
  { key: "kettle", ja: "ハンドドリップ ケトル", en: "Hand Drip Kettle", category: "equipment", price: 6500 },
  { key: "grinder", ja: "コーヒーミル", en: "Coffee Grinder", category: "equipment", price: 11800 },
  { key: "dripperSet", ja: "ドリッパー・サーバー セット", en: "Dripper & Server Set", category: "equipment", price: 4200 },
  { key: "cookies", ja: "珈琲に合うクッキー", en: "Coffee Cookies", category: "baked", price: 500 },
  { key: "madeleine", ja: "珈琲マドレーヌ", en: "Coffee Madeleine", category: "baked", price: 450 },
  { key: "bakedAssortment", ja: "焼き菓子 詰め合わせ", en: "Baked Goods Assortment", category: "baked", price: 1200 },
  { key: "giftAssortment", ja: "しおかぜギフト 詰め合わせ", en: "Shiokaze Gift Assortment", category: "gift", price: 3800 },
  { key: "giftSet", ja: "珈琲とお菓子の贈り物セット", en: "Coffee & Sweets Gift Set", category: "gift", price: 5200 },
];

/** カテゴリの並び（SAMPLES_CATEGORY_DEFS_ の順）に、そのカテゴリの商品を添えたもの */
const SAMPLES_CATEGORIES_ = SAMPLES_CATEGORY_DEFS_.map((def) => ({
  ...def,
  products: SAMPLE_PRODUCTS.filter((product) => product.category === def.key),
}));
const SAMPLES_GIFT_CATEGORY_INDEX_ = SAMPLES_CATEGORIES_.findIndex((category) => category.key === SAMPLES_GIFT_CATEGORY_KEY_);
/** 卸（大口）が買うのは、まとめ買いしやすいコーヒー豆・ドリップバッグだけ */
const SAMPLES_WHOLESALE_CATEGORY_WEIGHTS_ = [
  { index: 0, weight: 0.6 },
  { index: 1, weight: 0.4 },
];

// ---- 乱数の代わり（線形合同法） --------------------------------------------

/** 文字を 32 ビットの数にする（FNV-1a）。tag ごとに違う、決まった種を作るためだけに使う */
function samplesHash32_(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** 32 ビットの線形合同法を 1 歩進める（Numerical Recipes の定数。Math.imul で桁あふれを 32 ビットに保つ） */
function samplesLcgStep_(state) {
  return (Math.imul(state, 1664525) + 1013904223) >>> 0;
}

/** tag から、決まった [0, 1) の乱数もどきを 1 つ作る */
function samplesRandom_(tag) {
  return samplesLcgStep_(samplesHash32_(tag)) / 4294967296;
}

/** tag から、決まった [0, 1) の乱数もどきを count 個作る（同じ行で複数の選択に使う） */
function samplesRandomSeq_(tag, count) {
  let state = samplesHash32_(tag);
  const values = [];
  for (let i = 0; i < count; i += 1) {
    state = samplesLcgStep_(state);
    values.push(state / 4294967296);
  }
  return values;
}

/** rand（[0,1)）と重みの並びから、選ばれた位置（0 始まり）を決める */
function samplesWeightedIndex_(rand, weights) {
  const total = weights.reduce((sum, w) => sum + w, 0);
  let at = rand * total;
  for (let i = 0; i < weights.length; i += 1) {
    at -= weights[i];
    if (at <= 0) return i;
  }
  return weights.length - 1;
}

/** rand から、0〜length-1 のどれかを一様に選ぶ */
function samplesPickIndex_(rand, length) {
  return Math.min(length - 1, Math.floor(rand * length));
}

/** rand から、min〜max（両端を含む）の整数を一様に選ぶ */
function samplesIntInRange_(rand, min, max) {
  return min + Math.floor(rand * (max - min + 1));
}

/** 値を [min, max] に収める */
function samplesClamp_(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// ---- 形の決まり（週末・伸び・ギフトの山） -----------------------------------

/** 土日か */
function samplesIsWeekend_(dateKey) {
  const day = weekdayOf(dateKey);
  return day === 0 || day === 6;
}

/** 12 月、またはその 1 週間前（11 月の最後の週）はギフトが増える */
function samplesGiftBoostActive_(dateKey) {
  return monthOf(dateKey).endsWith("-12") || monthOf(addDays(dateKey, 7)).endsWith("-12");
}

/** fromMonth（"YYYY-MM"）から数えて、month が何か月先か（0 始まり） */
function samplesMonthIndex_(fromMonth, month) {
  const fromYear = Number(fromMonth.slice(0, 4));
  const fromMon = Number(fromMonth.slice(5, 7));
  const year = Number(month.slice(0, 4));
  const mon = Number(month.slice(5, 7));
  return (year - fromYear) * 12 + (mon - fromMon);
}

/** "YYYY-MM" の月の日数（31 日先に進めれば必ず翌月に入ることを使って求める） */
function samplesDaysInMonth_(month) {
  const start = month + "-01";
  const nextMonthStart = monthOf(addDays(start, 31)) + "-01";
  return diffDays(start, nextMonthStart);
}

/**
 * その月の、まるまる 1 か月ぶんの月間売上のねらい額。span の最初の月（fromMonth）を 0 か月目として
 * 数え、月を追ってゆるやかに伸びる形にし、12 月だけギフトの山ぶんを割り増す。
 * 見本の売上（samplesBuildSales_、数量の調整のねらいに使う）と目標の見積もり（samplesBuildTargets_）は
 * 同じこの額を使う
 */
function samplesMonthTarget_(fromMonth, month) {
  const index = samplesMonthIndex_(fromMonth, month);
  const growth = Math.pow(SAMPLES_MONTH_GROWTH_PER_MONTH_, index);
  const lift = month.endsWith("-12") ? SAMPLES_DECEMBER_LIFT_MULTIPLIER_ : 1;
  return SAMPLES_MONTH_BASE_REVENUE_ * growth * lift;
}

/**
 * その月に立つ、卸（大口）の注文の日（1 始まりの日）。乱数の日ではなく、月を等分した区画に
 * 1 件ずつ置くことで、日はばらけながらも件数は毎月 3〜4 件にそろえる
 */
function samplesWholesaleDaysOfMonth_(month) {
  const daysInMonth = samplesDaysInMonth_(month);
  const count = samplesRandom_(month + "|wholesale-count") < 0.5 ? SAMPLES_WHOLESALE_ORDERS_PER_MONTH_RANGE_[0] : SAMPLES_WHOLESALE_ORDERS_PER_MONTH_RANGE_[1];
  const segment = daysInMonth / count;
  const days = new Set();
  for (let i = 0; i < count; i += 1) {
    const rand = samplesRandom_(month + "|wholesale-day-" + i);
    const start = Math.floor(i * segment);
    const end = Math.floor((i + 1) * segment) - 1;
    days.add(start + samplesIntInRange_(rand, 0, Math.max(0, end - start)) + 1);
  }
  return days;
}

// ---- 1 日ぶんの行を決める（言語に依らない「行の計画」を作ってから、あとで訳す） --------

/**
 * その日の、通常（店頭・EC）の行 1 つぶんの計画。qtyFloat は数量のねらい（まだ整数に丸めていない）で、
 * このあと月ごとの demand（samplesBuildSales_ が決める）を掛けてから、行にする直前に 1 回だけ丸める
 */
function samplesPlanNormalRow_(dateKey, rowIndex, ctx) {
  const [channelRand, categoryRand, productRand, qtyRand] = samplesRandomSeq_(dateKey + "|" + rowIndex, 4);

  const isWeekend = samplesIsWeekend_(dateKey);
  const storeProb = isWeekend ? 0.65 : 0.42;
  const channelKey = channelRand < storeProb ? "store" : "online";

  const weights = SAMPLES_CATEGORIES_.map((category, index) =>
    ctx.giftBoost && index === SAMPLES_GIFT_CATEGORY_INDEX_ ? category.weight * SAMPLES_GIFT_WEIGHT_BOOST_ : category.weight
  );
  const categoryIndex = samplesWeightedIndex_(categoryRand, weights);
  const category = SAMPLES_CATEGORIES_[categoryIndex];
  const productIndex = samplesPickIndex_(productRand, category.products.length);

  const qtyBase = samplesIntInRange_(qtyRand, category.qty[0], category.qty[1]);
  let multiplier = 1;
  if (channelKey === "store" && isWeekend) multiplier *= SAMPLES_WEEKEND_STORE_MULTIPLIER_;
  if (channelKey === "online") multiplier *= ctx.onlineGrowth;
  if (categoryIndex === SAMPLES_GIFT_CATEGORY_INDEX_ && ctx.giftBoost) multiplier *= SAMPLES_GIFT_BOOST_MULTIPLIER_;

  return { channelKey, categoryIndex, productIndex, qtyFloat: qtyBase * multiplier };
}

/** 大口（卸）の行 1 つぶんの計画。まとめ買いなので数量が大きい */
function samplesPlanWholesaleRow_(dateKey) {
  const [categoryRand, qtyRand, productRand] = samplesRandomSeq_(dateKey + "|wholesale-detail", 3);
  const pick = samplesWeightedIndex_(
    categoryRand,
    SAMPLES_WHOLESALE_CATEGORY_WEIGHTS_.map((w) => w.weight)
  );
  const categoryIndex = SAMPLES_WHOLESALE_CATEGORY_WEIGHTS_[pick].index;
  const category = SAMPLES_CATEGORIES_[categoryIndex];
  const productIndex = samplesPickIndex_(productRand, category.products.length);
  const qtyFloat = samplesIntInRange_(qtyRand, SAMPLES_WHOLESALE_QTY_RANGE_[0], SAMPLES_WHOLESALE_QTY_RANGE_[1]);
  return { channelKey: "wholesale", categoryIndex, productIndex, qtyFloat };
}

/** その日ぶんの行の計画（3〜9 件。月に 3〜4 日だけ、そのうち 1 件が卸の大口になる） */
function samplesDayPlans_(dateKey, fromMonth) {
  const countRand = samplesRandom_(dateKey + "|count");
  const rowCount = samplesIntInRange_(countRand, SAMPLES_ROWS_PER_DAY_[0], SAMPLES_ROWS_PER_DAY_[1]);
  const dayOfMonth = Number(dateKey.slice(8, 10));
  const hasWholesale = samplesWholesaleDaysOfMonth_(monthOf(dateKey)).has(dayOfMonth);

  const ctx = {
    giftBoost: samplesGiftBoostActive_(dateKey),
    onlineGrowth: Math.pow(SAMPLES_ONLINE_GROWTH_PER_MONTH_, samplesMonthIndex_(fromMonth, monthOf(dateKey))),
  };

  const normalCount = hasWholesale ? rowCount - 1 : rowCount;
  const plans = [];
  for (let i = 0; i < normalCount; i += 1) plans.push(samplesPlanNormalRow_(dateKey, i, ctx));
  if (hasWholesale) plans.push(samplesPlanWholesaleRow_(dateKey));
  return plans;
}

/** その計画 1 つぶんの、単価に掛ける前の「数量のねらい」に単価を掛けただけの、生の（demand を掛ける前の）額 */
function samplesPlanRawAmount_(plan) {
  const category = SAMPLES_CATEGORIES_[plan.categoryIndex];
  const product = category.products[plan.productIndex];
  return plan.qtyFloat * product.price;
}

/**
 * 行の計画と、すでに決まった数量（qty）を、言語ごとの 1 行（日付・チャネル・カテゴリ・商品・数量・金額）
 * にする。金額はその数量と商品の決まった単価の積そのもの（数量 × 単価）で、これ以外の縮尺は一切掛けない
 */
function samplesLocalizeRow_(plan, dateKey, isEn, qty) {
  const category = SAMPLES_CATEGORIES_[plan.categoryIndex];
  const product = category.products[plan.productIndex];
  const channel = SAMPLES_CHANNELS_[plan.channelKey];
  const amount = qty * product.price;
  return [dateKey, isEn ? channel.en : channel.ja, isEn ? category.en : category.ja, isEn ? product.en : product.ja, qty, amount];
}

/**
 * 見本の売上（見出し行を含む行列）。
 * (1) まず日ごとの計画（チャネル・カテゴリ・商品・数量のねらい＝qtyFloat）を揺らぎのある式のまま作り、
 *     月ごとに「demand を掛ける前の生の額」の合計を出す。
 * (2) その月に立つはずの額（samplesMonthTarget_、span に無い日数ぶんは按分）との比で月ごとの
 *     demand（数量の調整倍率）を決め、各行の数量を「qtyFloat × demand」を整数に丸めたものにする
 *     （1〜SAMPLES_QTY_MAX_ に収める）。
 * (3) 整数に丸めた分だけ月間の実額が月のねらいから少しだけずれるので、その月にある卸（大口）の
 *     行の数量を、ねらいとの差ぶんだけ動かして埋め合わせる（大口の行は数量の範囲が広く、1 個の
 *     増減が金額に効くので、ここで動かしても「まとめ買い」の見た目を崩さない）。
 * どの段階でも、行の金額は必ず「その行の数量 × 商品の決まった単価」のまま
 */
function samplesBuildSales_(today, isEn) {
  const from = addDays(today, -(SAMPLES_SPAN_DAYS_ - 1));
  const fromMonth = monthOf(from);

  const days = [];
  const daysPresentByMonth = new Map();
  const rawTotalByMonth = new Map();
  for (let i = 0; i < SAMPLES_SPAN_DAYS_; i += 1) {
    const dateKey = addDays(from, i);
    const month = monthOf(dateKey);
    const plans = samplesDayPlans_(dateKey, fromMonth);
    days.push({ dateKey, month, plans });
    daysPresentByMonth.set(month, (daysPresentByMonth.get(month) || 0) + 1);
    let rawTotal = rawTotalByMonth.get(month) || 0;
    for (const plan of plans) rawTotal += samplesPlanRawAmount_(plan);
    rawTotalByMonth.set(month, rawTotal);
  }

  const targetByMonth = new Map();
  const demandByMonth = new Map();
  for (const [month, daysPresent] of daysPresentByMonth) {
    const proratedTarget = samplesMonthTarget_(fromMonth, month) * (daysPresent / samplesDaysInMonth_(month));
    targetByMonth.set(month, proratedTarget);
    const rawTotal = rawTotalByMonth.get(month);
    const demand = rawTotal > 0 ? proratedTarget / rawTotal : 1;
    demandByMonth.set(month, samplesClamp_(demand, SAMPLES_DEMAND_RANGE_[0], SAMPLES_DEMAND_RANGE_[1]));
  }

  // demand を掛けて丸めた数量（plan ごと）と、月ごとの実額・卸の行の一覧を作る
  const qtyByPlan = new Map();
  const actualTotalByMonth = new Map();
  const wholesalePlansByMonth = new Map();
  for (const day of days) {
    const demand = demandByMonth.get(day.month);
    for (const plan of day.plans) {
      const product = SAMPLES_CATEGORIES_[plan.categoryIndex].products[plan.productIndex];
      const qty = samplesClamp_(Math.round(plan.qtyFloat * demand), 1, SAMPLES_QTY_MAX_);
      qtyByPlan.set(plan, qty);
      actualTotalByMonth.set(day.month, (actualTotalByMonth.get(day.month) || 0) + qty * product.price);
      if (plan.channelKey === "wholesale") {
        const list = wholesalePlansByMonth.get(day.month) || [];
        list.push(plan);
        wholesalePlansByMonth.set(day.month, list);
      }
    }
  }

  // 丸めで生まれた月ごとの差ぶんを、その月の卸（大口）の行の数量で埋め合わせる
  for (const [month, wholesalePlans] of wholesalePlansByMonth) {
    let gap = targetByMonth.get(month) - actualTotalByMonth.get(month);
    for (const plan of wholesalePlans) {
      if (gap === 0) break;
      const product = SAMPLES_CATEGORIES_[plan.categoryIndex].products[plan.productIndex];
      const currentQty = qtyByPlan.get(plan);
      const newQty = samplesClamp_(currentQty + Math.round(gap / product.price), 1, SAMPLES_QTY_MAX_);
      gap -= (newQty - currentQty) * product.price;
      qtyByPlan.set(plan, newQty);
    }
  }

  const header = isEn ? ["Date", "Channel", "Category", "Product", "Qty", "Amount"] : ["日付", "チャネル", "カテゴリ", "商品", "数量", "金額"];
  const rows = [header];
  for (const day of days) {
    for (const plan of day.plans) rows.push(samplesLocalizeRow_(plan, day.dateKey, isEn, qtyByPlan.get(plan)));
  }
  return rows;
}

// ---- 目標（月ごとのねらい額 × 余白） ----------------------------------------

/** 見本の目標（見出し行を含む行列）。span にかかるすべての月に 1 行ずつ。売上と同じ samplesMonthTarget_ を使う */
function samplesBuildTargets_(today, isEn) {
  const from = addDays(today, -(SAMPLES_SPAN_DAYS_ - 1));
  const fromMonth = monthOf(from);
  const months = new Set(bucketsBetween(from, today, "month"));
  months.add(monthOf(today)); // today の月は必ず入れる（決まりの通り、念のため）

  const header = isEn ? ["Month", "Target"] : ["月", "目標額"];
  const rows = [header];
  for (const month of Array.from(months).sort()) {
    const expected = samplesMonthTarget_(fromMonth, month) * SAMPLES_TARGET_MARGIN_;
    const target = Math.round(expected / 10000) * 10000; // 万円単位の、きりのよい目標額にする
    rows.push([month, target]);
  }
  return rows;
}

// ---- 設定（そのまま dashboard.config.json になる） ---------------------------

/** そろった列の名前（ja / en） */
function samplesColumns_(isEn) {
  return isEn
    ? { date: "Date", channel: "Channel", category: "Category", product: "Product", qty: "Qty", amount: "Amount", month: "Month", target: "Target" }
    : { date: "日付", channel: "チャネル", category: "カテゴリ", product: "商品", qty: "数量", amount: "金額", month: "月", target: "目標額" };
}

/** 見本のダッシュボードの題名 */
function samplesTitle_(isEn) {
  return isEn ? "Shiokaze Coffee — Sales dashboard" : "しおかぜ珈琲店 売上ダッシュボード";
}

/** 見本の部品の題（JSON の見本とシートの見本で同じ文を使う） */
function samplesWidgetTitles_(isEn) {
  return isEn
    ? {
        sales: "Sales",
        orders: "Orders",
        average: "Average order value",
        varieties: "Product varieties sold",
        trend: "Sales trend",
        byCategory: "Sales by category",
        goal: "This month's goal",
        channelCategory: "Channel × category",
        byProduct: "By product",
        recent: "Recent orders",
      }
    : {
        sales: "売上",
        orders: "注文数",
        average: "平均の注文額",
        varieties: "売れた商品の種類",
        trend: "売上の推移",
        byCategory: "カテゴリ別の売上",
        goal: "今月の目標",
        channelCategory: "チャネル別 × カテゴリ",
        byProduct: "商品別",
        recent: "最近の注文",
      };
}

/** 見本のダッシュボードの設定（raw のまま。parseConfig を通す前の形） */
function samplesConfig_(isEn) {
  const col = samplesColumns_(isEn);
  const title = samplesTitle_(isEn);
  const name = samplesWidgetTitles_(isEn);

  return {
    title,
    lang: isEn ? "en" : "ja",
    theme: "auto",
    datasets: {
      sales: { url: "./sales.csv", dateColumn: col.date },
      targets: { url: "./targets.csv" },
    },
    filters: { period: "thisMonth", dimensions: [col.channel, col.category] },
    widgets: [
      {
        type: "kpi",
        title: name.sales,
        dataset: "sales",
        value: col.amount,
        agg: "sum",
        format: "yen",
        compare: "previous",
        size: "s",
      },
      { type: "kpi", title: name.orders, dataset: "sales", agg: "count", format: "number", size: "s" },
      {
        type: "kpi",
        title: name.average,
        dataset: "sales",
        value: col.amount,
        agg: "avg",
        format: "yen",
        size: "s",
      },
      {
        type: "kpi",
        title: name.varieties,
        dataset: "sales",
        value: col.product,
        agg: "distinct",
        compare: "none",
        format: "number",
        size: "s",
      },
      {
        type: "line",
        title: name.trend,
        dataset: "sales",
        value: col.amount,
        agg: "sum",
        splitBy: col.channel,
        format: "yen",
        size: "l",
      },
      {
        type: "bar",
        title: name.byCategory,
        dataset: "sales",
        category: col.category,
        value: col.amount,
        agg: "sum",
        format: "yen",
        size: "m",
      },
      {
        type: "meter",
        title: name.goal,
        dataset: "sales",
        value: col.amount,
        agg: "sum",
        target: { dataset: "targets", value: col.target, matchMonth: col.month },
        format: "yen",
        size: "m",
      },
      {
        type: "bar",
        title: name.channelCategory,
        dataset: "sales",
        category: col.channel,
        splitBy: col.category,
        value: col.amount,
        agg: "sum",
        format: "yen",
        size: "m",
      },
      {
        type: "table",
        title: name.byProduct,
        dataset: "sales",
        groupBy: col.product,
        columns: [
          { value: col.qty, agg: "sum", label: col.qty },
          { value: col.amount, agg: "sum", label: name.sales, format: "yen" },
        ],
        sort: name.sales,
        top: 10,
        size: "m",
      },
      {
        type: "table",
        title: name.recent,
        dataset: "sales",
        rows: "latest",
        columns: [col.date, col.channel, col.product, col.qty, col.amount],
        top: 8,
        size: "l",
      },
    ],
  };
}

/**
 * しおかぜ珈琲店の見本データを、today（"YYYY-MM-DD"）と lang（既定 "ja"）から決まった式で作る。
 * 同じ today なら同じ出力、today が違えば違う（同じ形の）出力になる。
 * 戻り値の config はそのまま parseConfig に渡せる raw、datasets は見出し行を含む行列（string[][]）
 */
export function sampleData(today, lang = "ja") {
  const isEn = lang === "en";
  return {
    config: samplesConfig_(isEn),
    datasets: {
      sales: samplesBuildSales_(today, isEn),
      targets: samplesBuildTargets_(today, isEn),
    },
  };
}

// ---- 設定・定義のシートの形の見本（スプレッドシート版） -----------------------

/** データのシートの名前 */
function samplesSheetNames_(isEn) {
  return isEn ? { sales: "Sales", targets: "Targets" } : { sales: "売上", targets: "目標" };
}

/** 1 つのマスに列の名前を並べるときの区切り */
function samplesListSeparator_(isEn) {
  return isEn ? ", " : "、";
}

/** 見出しの名前で書いた 1 行を、`定義` シートの列の並びにそろえる */
function samplesDefinitionRow_(cells) {
  return CONFIG_DEFINITION_COLUMNS_.map((name) => (cells[name] === undefined ? "" : cells[name]));
}

/**
 * `設定`・`定義` シートの見本（見出し行つきの行列）。JSON の見本（samplesConfig_）と
 * 同じダッシュボードを、シートの言葉で書いたもの
 */
function samplesSheetConfig_(isEn) {
  const col = samplesColumns_(isEn);
  const name = samplesWidgetTitles_(isEn);
  const sheet = samplesSheetNames_(isEn);
  const sep = samplesListSeparator_(isEn);
  // 目標は「シート名!列名」。月の列の名前が「月」でなければ、3 つめに月の列を書く
  const target = sheet.targets + "!" + col.target + (col.month === "月" ? "" : "!" + col.month);

  const settings = [
    ["項目", "値"],
    ["題名", samplesTitle_(isEn)],
    ["言語", isEn ? "英語" : "日本語"],
    ["テーマ", "自動"],
    ["期間", "今月"],
    ["絞り込みの列", col.channel + sep + col.category],
  ];

  const definitions = [
    CONFIG_DEFINITION_COLUMNS_.slice(),
    samplesDefinitionRow_({
      種類: "数字",
      題: name.sales,
      データ: sheet.sales,
      値の列: col.amount,
      集計: "合計",
      書式: "円",
      大きさ: "小",
      比べる: "前の期間",
      // 解約数・返品額のように「下がると良い」数のときは、ここを 下がると良い にする
      良し悪し: "上がると良い",
    }),
    samplesDefinitionRow_({ 種類: "数字", 題: name.orders, データ: sheet.sales, 集計: "件数", 書式: "数値", 大きさ: "小" }),
    samplesDefinitionRow_({ 種類: "数字", 題: name.average, データ: sheet.sales, 値の列: col.amount, 集計: "平均", 書式: "円", 大きさ: "小" }),
    samplesDefinitionRow_({ 種類: "数字", 題: name.varieties, データ: sheet.sales, 値の列: col.product, 集計: "種類の数", 書式: "数値", 大きさ: "小", 比べる: "なし" }),
    samplesDefinitionRow_({
      種類: "折れ線",
      題: name.trend,
      データ: sheet.sales,
      値の列: col.amount,
      集計: "合計",
      分ける列: col.channel,
      日付の列: col.date,
      刻み: "自動",
      書式: "円",
      大きさ: "大",
    }),
    samplesDefinitionRow_({ 種類: "棒", 題: name.byCategory, データ: sheet.sales, 値の列: col.amount, 集計: "合計", 区分の列: col.category, 書式: "円", 大きさ: "中" }),
    samplesDefinitionRow_({ 種類: "目標", 題: name.goal, データ: sheet.sales, 値の列: col.amount, 集計: "合計", 書式: "円", 目標: target, 大きさ: "中" }),
    samplesDefinitionRow_({
      種類: "棒",
      題: name.channelCategory,
      データ: sheet.sales,
      値の列: col.amount,
      集計: "合計",
      区分の列: col.channel,
      分ける列: col.category,
      書式: "円",
      大きさ: "中",
    }),
    samplesDefinitionRow_({
      種類: "表",
      題: name.byProduct,
      データ: sheet.sales,
      // 「列名=見出し」で見出しを付け、「書式」は同じ並びで列ごとに効かせる
      値の列: col.qty + sep + col.amount + "=" + name.sales,
      集計: "合計",
      区分の列: col.product,
      書式: "数値" + sep + "円",
      大きさ: "中",
      上位: "10",
      並び: name.sales,
    }),
    samplesDefinitionRow_({
      種類: "表",
      題: name.recent,
      データ: sheet.sales,
      値の列: [col.date, col.channel, col.product, col.qty, col.amount].join(sep),
      大きさ: "大",
      上位: "8",
      明細: "最新",
    }),
  ];

  return { settings, definitions };
}

/**
 * しおかぜ珈琲店の見本を、スプレッドシートに書く形で作る。
 * settings は `設定` シート、definitions は `定義` シート、data はデータのシート
 * （`売上`・`目標`、英語なら `Sales`・`Targets`）の、どれも見出し行つきの行列。
 * 同じ today・lang なら何度呼んでも同じ出力になる
 */
export function sampleSheets(today, lang = "ja") {
  const isEn = lang === "en";
  const sheet = samplesSheetNames_(isEn);
  const { settings, definitions } = samplesSheetConfig_(isEn);
  const data = {};
  data[sheet.sales] = samplesBuildSales_(today, isEn);
  data[sheet.targets] = samplesBuildTargets_(today, isEn);
  return { settings, definitions, data };
}
