/**
 * ダッシュボードのどのファイルからも使う、文字まわりの小さな道具。
 * scripts/build.mjs が 1 本にまとめるので、同じ名前の関数をほかのファイルで定義しない。
 */

/**
 * 設定や集計の値を、前後の空白を落とした文字にする。null / undefined は ""。
 * 配列やオブジェクトも ""（読み込んだ値が思わぬ形で検査をすり抜けないように。toString が
 * 壊れた値で落ちることも防ぐ）
 */
export function textOf(value) {
  if (value === null || value === undefined) return "";
  const kind = typeof value;
  if (kind === "string") return value.trim();
  if (kind === "number" || kind === "boolean" || kind === "bigint") return String(value);
  return "";
}

/** 全角の英数字・記号（！-～）と全角空白を半角にする（入力欄と検索で同一視するため） */
export function toHalfWidth(value) {
  return String(value === null || value === undefined ? "" : value)
    .replace(/[！-～]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/　/g, " ");
}

const HTML_ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

function escape_(value) {
  return String(value === null || value === undefined ? "" : value).replace(/[&<>"']/g, (ch) => HTML_ESCAPES[ch]);
}

/** 画面のテキストとして出す前に安全な文字にする（文字列を組み立てて innerHTML に渡すときに使う） */
export function escapeHtml(value) {
  return escape_(value);
}

/** 属性値（"..."）の中に入れても安全な文字にする */
export function escapeAttr(value) {
  return escape_(value);
}

/**
 * 字の幅の見積もりで、全角として数えない字の範囲。
 * 記号・矢印・幾何学模様（▲▼ … など）は、半角なみの幅で出るので外す
 */
const TEXT_NARROW_RANGES_ = [[0x2000, 0x2bff]];

function textIsWide_(code) {
  if (code < 0x1100) return false;
  for (const [from, to] of TEXT_NARROW_RANGES_) {
    if (code >= from && code <= to) return false;
  }
  return true;
}

/**
 * 字の幅を見積もる（字の形を測れないところで、余白・短くする長さ・間引きを決めるために使う）。
 * 全角 12px・半角 7px を目安にして、字の大きさに比例させる。
 * 棒を横にするかを決める model と、札を置く描く側が、同じ見積もりを使う
 */
export function estimateTextWidth(text, fontPx = 12) {
  const source = text === null || text === undefined ? "" : String(text);
  let units = 0;
  for (const ch of source) units += textIsWide_(ch.codePointAt(0)) ? 12 : 7;
  return (units * fontPx) / 12;
}

/**
 * 名前をキーにした入れ物が、その名前を自分で持っているか。
 * "toString"・"constructor" のような、書いていないのに JS が最初から持っている名前を
 * 誤って拾わないために、値を読む前にここを通す
 */
export function hasOwn(box, name) {
  if (box === null || box === undefined || typeof box !== "object") return false;
  if (typeof name !== "string" || name === "") return false;
  return Object.prototype.hasOwnProperty.call(box, name);
}

/**
 * 名前をキーにした入れ物へ、1 項目を「自分が持つ項目」として入れる。
 * 列の名前は取り込んだ表の見出しなので、"__proto__" のような名前が来ても
 * 入れ物そのものの素性を書き換えないようにする
 */
export function setOwn(box, name, value) {
  Object.defineProperty(box, name, { value, writable: true, enumerable: true, configurable: true });
}

/**
 * 表のマスの値を並べ替えるときの比較。数どうしは数の大小、それ以外は文字の単純比較で、
 * order が "asc" なら小さい順、それ以外は大きい順にする。
 * 空（null・undefined・空文字）は、どちらの向きでもいつも最後に置く。
 * 同じ値のときは 0 を返すので、呼ぶ側が元の並びを保てる
 */
export function compareCells(a, b, order) {
  const aEmpty = a === null || a === undefined || a === "";
  const bEmpty = b === null || b === undefined || b === "";
  if (aEmpty || bEmpty) return aEmpty && bEmpty ? 0 : aEmpty ? 1 : -1;

  let gap = 0;
  if (typeof a === "number" && typeof b === "number") {
    gap = a - b;
  } else {
    const at = String(a);
    const bt = String(b);
    gap = at < bt ? -1 : at > bt ? 1 : 0;
  }
  // 同じ値は 0 のまま返す（-0 を作らない。呼ぶ側が「変わらない」と見分けられるように）
  if (gap === 0) return 0;
  return order === "asc" ? gap : 0 - gap;
}

/** 行のセルがすべて空か。配列でなければ「見るセルが無い」として空とみなす */
export function isBlankRow(row) {
  const cells = Array.isArray(row) ? row : [];
  for (let i = 0; i < cells.length; i += 1) {
    if (textOf(cells[i]) !== "") return false;
  }
  return true;
}

/** n を min〜max の範囲に収める。数として読めない値は min にする */
export function clamp(n, min, max) {
  const num = Number(n);
  if (Number.isNaN(num)) return min;
  if (num < min) return min;
  if (num > max) return max;
  return num;
}
