/**
 * CSV の文字と行列（string[][]）を行き来する道具、行列と見出しつきの行の集まりを行き来する道具。
 * ここは純粋な文字処理だけを行う
 */

import { textOf, isBlankRow, setOwn } from "./text.js";
import { parseNumber } from "./numbers.js";

/**
 * CSV の文字を行列（string[][]）にする。先頭の BOM は外す。
 * 引用符で囲んだ値の中のカンマ・改行（\r\n・\n どちらも）・二重にした "" を読む。
 * 末尾の改行 1 つは行を増やさない（ファイルの終わりの改行はよくあるので、空行を作らない）
 */
export function parseCsv(text) {
  let source = typeof text === "string" ? text : textOf(text);
  if (source.charCodeAt(0) === 0xfeff) source = source.slice(1);

  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;
  const length = source.length;
  let i = 0;

  while (i < length) {
    const ch = source[i];
    if (inQuotes) {
      if (ch === '"') {
        if (source[i + 1] === '"') {
          field += '"';
          i += 2;
        } else {
          inQuotes = false;
          i += 1;
        }
      } else {
        field += ch;
        i += 1;
      }
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      i += 1;
      continue;
    }
    if (ch === ",") {
      row.push(field);
      field = "";
      i += 1;
      continue;
    }
    if (ch === "\r" || ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
      i += ch === "\r" && source[i + 1] === "\n" ? 2 : 1;
      continue;
    }
    field += ch;
    i += 1;
  }
  if (field !== "" || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

/**
 * 行列を見出しつきの行の集まりにする。1 行目を見出しとして使う。
 * 見出しは textOf で前後の空白を落とし、空なら「列N」（N は 1 から始まる位置）、
 * 同じ名前が続けて出てきたら「名前 (2)」のように番号を付ける。
 * データ行のうち、セルがすべて空の行（isBlankRow）は読み飛ばす
 */
export function rowsToObjects(matrix) {
  const grid = Array.isArray(matrix) ? matrix : [];
  if (grid.length === 0) return { columns: [], rows: [] };

  const headerRow = Array.isArray(grid[0]) ? grid[0] : [];
  // 見出しは取り込んだファイルの文字なので、"toString"・"__proto__" のような名前でも
  // JS が最初から持っている項目と取り違えないよう、Map で数える
  const seenCount = new Map();
  const columns = headerRow.map((cell, index) => {
    const name = textOf(cell) || "列" + (index + 1);
    const seen = (seenCount.get(name) || 0) + 1;
    seenCount.set(name, seen);
    return seen === 1 ? name : name + " (" + seen + ")";
  });

  const rows = [];
  for (let r = 1; r < grid.length; r += 1) {
    const raw = Array.isArray(grid[r]) ? grid[r] : [];
    if (isBlankRow(raw)) continue;
    const record = {};
    for (let c = 0; c < columns.length; c += 1) {
      setOwn(record, columns[c], raw[c] !== undefined ? raw[c] : "");
    }
    rows.push(record);
  }
  return { columns, rows };
}

const CSV_FORMULA_PATTERN_ = /^[=+\-@\t\r\n]/;
const CSV_NEEDS_QUOTE_PATTERN_ = /["\r\n,]/;
// BOM（U+FEFF）。ソースに見えない文字をそのまま置かず、文字コードから作る
const CSV_BOM_ = String.fromCharCode(0xfeff);

/** セル 1 つぶんを CSV の文字にする（数式ガードと引用符の付与） */
function csvFormatCell_(cell) {
  let text = textOf(cell);
  if (CSV_FORMULA_PATTERN_.test(text) && parseNumber(text) === null) {
    text = "'" + text;
  }
  if (CSV_NEEDS_QUOTE_PATTERN_.test(text)) {
    text = '"' + text.replace(/"/g, '""') + '"';
  }
  return text;
}

/**
 * 行列を CSV の文字にする。先頭に BOM、行の区切りは CRLF。
 * セルの先頭が = + - @ タブ 改行 のいずれかなら頭に ' を付けて表計算ソフトが数式と
 * 読まないようにする。ただし parseNumber で数と読める値（"-12" など）には付けない。
 * セルに " , 改行 のいずれかを含むときは引用符で囲み、中の " は "" にする
 */
export function toCsv(matrix) {
  const grid = Array.isArray(matrix) ? matrix : [];
  const lines = grid.map((row) => {
    const cells = Array.isArray(row) ? row : [];
    return cells.map(csvFormatCell_).join(",");
  });
  const body = lines.join("\r\n");
  return CSV_BOM_ + body + (lines.length > 0 ? "\r\n" : "");
}
