/**
 * 日付はすべて暦の日付を表す文字 "YYYY-MM-DD"（日付キー）で持ち、計算も文字で行う。
 * Date を内部で使ってよいのは Date.UTC と getUTC* だけ（toDateKey が Date を受け取ったときだけ例外で、
 * ローカルの getFullYear/getMonth/getDate を使う。GAS から渡される Date はスクリプトの時間帯の時刻なので）。
 * 「今日」はここでは読まない。引数を渡さない Date の呼び出しと、いまの時刻を返す呼び出しは使わない。
 * 呼び出し側が today（"YYYY-MM-DD"）を渡す
 */

import { textOf, toHalfWidth } from "./text.js";

/** 2 桁に揃える */
export function pad2(n) {
  return n < 10 ? "0" + n : String(n);
}

/** Date かどうか。realm をまたいでも見分けられるよう instanceof は使わない */
function isDate_(value) {
  return Object.prototype.toString.call(value) === "[object Date]";
}

/** 年月日から日付キーを作る。実在しない日（2/30 など）は "" */
function ymd_(year, month, day) {
  if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return "";
  if (month < 1 || month > 12 || day < 1 || day > 31) return "";
  // Date.UTC(2026, 1, 30) は 3/2 に繰り上がるだけで無効値にならないので、年月日を読み戻して照合する
  const probe = new Date(Date.UTC(year, month - 1, day));
  if (probe.getUTCFullYear() !== year || probe.getUTCMonth() + 1 !== month || probe.getUTCDate() !== day) return "";
  return year + "-" + pad2(month) + "-" + pad2(day);
}

/**
 * 値を日付キー "YYYY-MM-DD" にする。読めなければ ""。
 * 受け付ける形: "2026-09-19"・"2026/9/19"・"2026.9.19"・"2026年9月19日"・ISO の日時の先頭 10 字・Date。
 * "9/19/2026" のような月が先の形は読まない（年の 4 桁で始まる形だけを受け付けるので、自然に弾かれる）。
 * Date は GAS がスクリプトの時間帯で渡すので、UTC ではなく getFullYear/getMonth/getDate を使う。
 */
export function toDateKey(value) {
  if (value === null || value === undefined || value === "") return "";
  if (isDate_(value)) {
    if (Number.isNaN(value.getTime())) return "";
    return value.getFullYear() + "-" + pad2(value.getMonth() + 1) + "-" + pad2(value.getDate());
  }
  const raw = toHalfWidth(textOf(value)).trim();
  if (raw === "") return "";
  // ISO の日時（"2026-09-19T10:00:00Z"・"2026-09-19 10:00" など）は先頭 10 字だけを日付として読む
  const isoHead = raw.match(/^(\d{4})-(\d{2})-(\d{2})(?=[T ])/);
  if (isoHead) return ymd_(Number(isoHead[1]), Number(isoHead[2]), Number(isoHead[3]));
  const matched = raw.match(/^(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})日?$/);
  if (!matched) return "";
  return ymd_(Number(matched[1]), Number(matched[2]), Number(matched[3]));
}

/** "YYYY-MM-DD" の形で、実在する日付か */
export function isDateKey(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) && toDateKey(value) === value;
}

/** 日付キーを、1970-01-01 からの日数にする（Date.UTC 経由） */
function epochDays_(key) {
  const parts = key.split("-").map(Number);
  return Math.round(Date.UTC(parts[0], parts[1] - 1, parts[2]) / 86400000);
}

/** "YYYY-MM-DD" に日数を足す（負の数は引く）。月・年をまたいでもよい */
export function addDays(key, days) {
  const parts = key.split("-").map(Number);
  const at = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + days));
  return at.getUTCFullYear() + "-" + pad2(at.getUTCMonth() + 1) + "-" + pad2(at.getUTCDate());
}

/** a から b までの日数（b の方が後なら正の数） */
export function diffDays(a, b) {
  return epochDays_(b) - epochDays_(a);
}

/** "YYYY-MM-DD" の曜日。0（日）〜6（土） */
export function weekdayOf(key) {
  const parts = key.split("-").map(Number);
  return new Date(Date.UTC(parts[0], parts[1] - 1, parts[2])).getUTCDay();
}

/** その日を含む週の月曜日（週は月曜はじまり） */
export function weekStartOf(key) {
  const back = (weekdayOf(key) + 6) % 7;
  return addDays(key, -back);
}

/** "YYYY-MM" */
export function monthOf(key) {
  return key.slice(0, 7);
}

/** "YYYY-Qn" */
export function quarterOf(key) {
  const year = key.slice(0, 4);
  const month = Number(key.slice(5, 7));
  const quarter = Math.floor((month - 1) / 3) + 1;
  return year + "-Q" + quarter;
}

/** "YYYY" */
export function yearOf(key) {
  return key.slice(0, 4);
}

/** その日が属する月の初日 */
function monthStart_(key) {
  return key.slice(0, 7) + "-01";
}

/** 次の月の初日 */
function nextMonthStart_(key) {
  const year = Number(key.slice(0, 4));
  const month = Number(key.slice(5, 7));
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  return nextYear + "-" + pad2(nextMonth) + "-01";
}

/** その日が属する月の末日 */
function lastDayOfMonth_(key) {
  return addDays(nextMonthStart_(key), -1);
}

/**
 * 日付キーを、指定した刻みの「刻みキー」にする。
 * day はそのまま日付キー、week はその週の月曜日、month は "YYYY-MM"、quarter は "YYYY-Qn"、year は "YYYY"
 */
export function bucketKey(key, bucket) {
  if (bucket === "week") return weekStartOf(key);
  if (bucket === "month") return monthOf(key);
  if (bucket === "quarter") return quarterOf(key);
  if (bucket === "year") return yearOf(key);
  return key;
}

/** 刻みキーを、その刻みが始まる日付キーに戻す（bucketKey の逆） */
export function bucketStart(bucketKeyString, bucket) {
  const key = textOf(bucketKeyString);
  if (bucket === "month") return key + "-01";
  if (bucket === "quarter") {
    const matched = key.match(/^(\d{4})-Q([1-4])$/);
    if (!matched) return "";
    const firstMonth = (Number(matched[2]) - 1) * 3 + 1;
    return matched[1] + "-" + pad2(firstMonth) + "-01";
  }
  if (bucket === "year") return key + "-01-01";
  return key; // day・week はすでに日付キー
}

/** 月の刻みキー "YYYY-MM" を、0 年 1 月から数えた通し番号にする */
function monthIndex_(key) {
  return Number(key.slice(0, 4)) * 12 + Number(key.slice(5, 7)) - 1;
}

/** 通し番号を月の刻みキー "YYYY-MM" に戻す */
function monthKeyOf_(index) {
  return Math.floor(index / 12) + "-" + pad2((index % 12) + 1);
}

/** 刻みキーを n だけ先へ進める（n が負なら戻る）。bucketsBetween の中だけで使う */
function bucketAdd_(key, bucket, n) {
  if (bucket === "week") return addDays(key, 7 * n);
  if (bucket === "month") return monthKeyOf_(monthIndex_(key) + n);
  if (bucket === "quarter") {
    const matched = key.match(/^(\d{4})-Q([1-4])$/);
    const index = Number(matched[1]) * 4 + Number(matched[2]) - 1 + n;
    return Math.floor(index / 4) + "-Q" + ((index % 4) + 1);
  }
  if (bucket === "year") return String(Number(key) + n);
  return addDays(key, n); // day
}

/** 刻みキーを 1 つ先へ進める（bucketsBetween の内部だけで使う） */
function nextBucketKey_(bucketKeyString, bucket) {
  return bucketAdd_(bucketKeyString, bucket, 1);
}

/**
 * from から to までに刻みがいくつあるか（端を含む）。並びを作らずに数えるので、
 * 何十万個になる組み合わせでも軽い。読めない日付・逆さまの範囲は 0
 */
export function bucketCountBetween(from, to, bucket) {
  if (!isDateKey(from) || !isDateKey(to) || diffDays(from, to) < 0) return 0;
  const start = bucketKey(from, bucket);
  const end = bucketKey(to, bucket);
  if (bucket === "week") return Math.floor(diffDays(start, end) / 7) + 1;
  if (bucket === "month") return monthIndex_(end) - monthIndex_(start) + 1;
  if (bucket === "quarter") {
    const at = (key) => Number(key.slice(0, 4)) * 4 + Number(key.slice(6, 7)) - 1;
    return at(end) - at(start) + 1;
  }
  if (bucket === "year") return Number(end) - Number(start) + 1;
  return diffDays(start, end) + 1; // day
}

/** 1 回の呼び出しで並べる刻みキーの上限（超えるときは古いほうを落として、新しいほうを残す） */
export const DATES_BUCKET_LIMIT_ = 100000;

/**
 * from から to までの刻みキーを、端を含めて並べる。
 * 数が上限（DATES_BUCKET_LIMIT_）を超えるときは、古いほうを落として**新しいほうから**
 * 上限ぶんだけを返す（末尾＝いちばん新しい刻みは必ず残す）。
 * 画面に出す 400 個までの絞り込みは、呼び出し側（aggregate.js）が行う
 */
export function bucketsBetween(from, to, bucket) {
  const total = bucketCountBetween(from, to, bucket);
  if (total <= 0) return [];
  const endKey = bucketKey(to, bucket);
  const keep = Math.min(total, DATES_BUCKET_LIMIT_);
  let cursor = keep === total ? bucketKey(from, bucket) : bucketAdd_(endKey, bucket, -(keep - 1));

  const result = [];
  for (let i = 0; i < keep; i += 1) {
    result.push(cursor);
    if (cursor === endKey) break;
    cursor = nextBucketKey_(cursor, bucket);
  }
  return result;
}

/** 期間の長さから、ちょうどよい刻みを選ぶ（31 日以下は日、183 日以下は週、それ以外は月） */
export function autoBucket(from, to) {
  const days = diffDays(from, to);
  if (days <= 31) return "day";
  if (days <= 183) return "week";
  return "month";
}

/** よく使う期間のプリセットを、today（"YYYY-MM-DD"）を基準にした日付キーの範囲にする */
export function periodRange(preset, today) {
  const day = isDateKey(today) ? today : "";
  if (day === "") return { from: "", to: "" };
  if (preset === "thisMonth") return { from: monthStart_(day), to: day };
  if (preset === "lastMonth") {
    const prevMonthLastDay = addDays(monthStart_(day), -1);
    return { from: monthStart_(prevMonthLastDay), to: prevMonthLastDay };
  }
  if (preset === "last7") return { from: addDays(day, -6), to: day };
  if (preset === "last30") return { from: addDays(day, -29), to: day };
  if (preset === "last90") return { from: addDays(day, -89), to: day };
  if (preset === "thisYear") return { from: day.slice(0, 4) + "-01-01", to: day };
  // "all" と "custom"、読めない値: from/to は呼び出し側（設定の custom や「比べない」）が決める
  return { from: "", to: "" };
}

/**
 * いま選んでいる範囲の「ひとつ前」を返す。決まりは (a)〜(e):
 * (a) from が月の1日で to が同じ月の末日 → 前の月まるごと。
 * (b) from が月の1日で to が同じ月の途中 → 前の月の1日から同じ「日」まで（前の月が短ければ末日で止める）。
 * (c) from が1/1で to が同じ年 → 前の年の同じ月日まで。
 * (d) それ以外 → 同じ日数の直前の範囲。
 * (e) from も to も ""（all） → 比べない
 */
export function previousRange(range) {
  const from = range && typeof range.from === "string" ? range.from : "";
  const to = range && typeof range.to === "string" ? range.to : "";
  if (from === "" && to === "") return { from: "", to: "" };
  if (!isDateKey(from) || !isDateKey(to)) return { from: "", to: "" };

  const fromIsMonthStart = from.slice(8) === "01";
  if (fromIsMonthStart && to.slice(0, 7) === from.slice(0, 7)) {
    const prevMonthStart = monthStart_(addDays(from, -1));
    if (to === lastDayOfMonth_(from)) {
      // (a) 月まるごと
      return { from: prevMonthStart, to: lastDayOfMonth_(prevMonthStart) };
    }
    // (b) 前の月の同じ「日」まで（短ければ末日で止める）
    const day = Number(to.slice(8));
    const prevLastDay = Number(lastDayOfMonth_(prevMonthStart).slice(8));
    return { from: prevMonthStart, to: prevMonthStart.slice(0, 8) + pad2(Math.min(day, prevLastDay)) };
  }

  const fromIsJan1 = from.slice(5) === "01-01";
  if (fromIsJan1 && to.slice(0, 4) === from.slice(0, 4)) {
    // (c) 前の年の同じ月日まで
    const prevYear = Number(from.slice(0, 4)) - 1;
    return { from: prevYear + "-01-01", to: prevYear + to.slice(4) };
  }

  // (d) 同じ日数の直前の範囲
  const length = diffDays(from, to) + 1;
  const newTo = addDays(from, -1);
  return { from: addDays(newTo, -(length - 1)), to: newTo };
}

const EN_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** 刻みキーを、画面に出す短いラベルにする（lang は既定 "ja"、"en" のときだけ英語） */
export function bucketLabel(bucketKeyString, bucket, lang) {
  const isEn = lang === "en";
  const key = textOf(bucketKeyString);
  if (bucket === "day" || bucket === "week") {
    const month = Number(key.slice(5, 7));
    const day = Number(key.slice(8, 10));
    if (bucket === "day") return isEn ? EN_MONTHS[month - 1] + " " + day : month + "/" + day;
    return isEn ? "Wk of " + EN_MONTHS[month - 1] + " " + day : month + "/" + day + "週";
  }
  if (bucket === "month") {
    const year = key.slice(0, 4);
    const month = Number(key.slice(5, 7));
    return isEn ? EN_MONTHS[month - 1] + " " + year : year + "年" + month + "月";
  }
  if (bucket === "quarter") return key.replace("-", " ");
  if (bucket === "year") return isEn ? key : key + "年";
  return key;
}
