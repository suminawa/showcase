/**
 * 画面に出す固定の文をここに 1 か所にまとめる。ja（既定）と en の 2 つ。
 * ここは文字の組み立てだけを行う純粋な道具
 */

/** 対応している言語 */
export const LANGS = ["ja", "en"];

export const MESSAGES = {
  ja: {
    "filter.period.thisMonth": "今月",
    "filter.period.lastMonth": "先月",
    "filter.period.last7": "直近 7 日",
    "filter.period.last30": "直近 30 日",
    "filter.period.last90": "直近 90 日",
    "filter.period.thisYear": "今年",
    "filter.period.all": "全期間",
    "filter.period.custom": "期間を指定",
    "filter.period": "期間",
    "filter.from": "開始日",
    "filter.to": "終了日",
    "filter.allValues": "すべて",
    "filter.reset": "絞り込みを戻す",

    "widget.showTable": "表で見る",
    "widget.showChart": "グラフで見る",

    "action.downloadCsv": "CSV をダウンロード",

    "state.noData": "データがありません",
    "state.checkConfig": "設定をご確認ください",
    "state.configIssues": "設定をご確認ください（{count} 件）",
    "state.loading": "読み込んでいます…",
    "state.unavailable": "ただいま表示できません。しばらくしてからお試しください。",
    "state.truncated": "20,000 行までを表示しています",
    "state.bucketCapped": "期間が長いため、新しいほうから {count} 個の区切りだけを表示しています",
    "state.skippedValues": "数として読めない値を {count} 件のぞきました",

    "label.other": "その他",
    "label.goalReached": "達成",
    "label.blank": "（空欄）",
    "label.actual": "実績",
    "label.goal": "目標",
    "label.targetMonth": "対象の月",
    "label.progress": "達成率",
    "label.total": "合計",

    "table.item": "項目",
    "table.value": "値",
    "table.previous": "前の期間",
    "table.delta": "差",

    "error.datasetMissing": "データ「{name}」が見つかりません。設定をご確認ください。",
    "error.columnMissing": "データ「{dataset}」に列「{column}」が見つかりません。設定をご確認ください。",
    "error.goalMissing": "{month} の目標が見つかりません。目標のデータをご確認ください。",
    "error.goalNotPositive": "目標が 0 以下のため、達成率を計算できません。目標のデータをご確認ください。",
    "error.sampleOnlyInDemo": "見本のデータは、見本のページ（demo/app.js）にだけ入っています。配布物では、config と data にご自分のデータをお渡しください。",

    "compare.lastMonth": "先月比",
    "compare.last7": "前の 7 日比",
    "compare.last30": "前の 30 日比",
    "compare.last90": "前の 90 日比",
    "compare.thisYear": "昨年比",
    "compare.generic": "前の期間比",

    "agg.sum": "合計",
    "agg.avg": "平均",
    "agg.count": "件数",
    "agg.distinct": "種類の数",
    "agg.min": "最小",
    "agg.max": "最大",
  },
  en: {
    "filter.period.thisMonth": "This month",
    "filter.period.lastMonth": "Last month",
    "filter.period.last7": "Last 7 days",
    "filter.period.last30": "Last 30 days",
    "filter.period.last90": "Last 90 days",
    "filter.period.thisYear": "This year",
    "filter.period.all": "All time",
    "filter.period.custom": "Custom range",
    "filter.period": "Period",
    "filter.from": "Start date",
    "filter.to": "End date",
    "filter.allValues": "All",
    "filter.reset": "Reset filters",

    "widget.showTable": "View as table",
    "widget.showChart": "View as chart",

    "action.downloadCsv": "Download CSV",

    "state.noData": "No data for this period",
    "state.checkConfig": "Check the settings",
    "state.configIssues": "Check the settings ({count} issues)",
    "state.loading": "Loading…",
    "state.unavailable": "This dashboard is unavailable right now. Please try again later.",
    "state.truncated": "Showing the first 20,000 rows",
    "state.bucketCapped": "This period is long, so only the most recent {count} buckets are shown",
    "state.skippedValues": "Skipped {count} values that are not numbers",

    "label.other": "Other",
    "label.goalReached": "Goal reached",
    "label.blank": "(Blank)",
    "label.actual": "Actual",
    "label.goal": "Goal",
    "label.targetMonth": "Month",
    "label.progress": "Progress",
    "label.total": "Total",

    "table.item": "Item",
    "table.value": "Value",
    "table.previous": "Previous period",
    "table.delta": "Change",

    "error.datasetMissing": 'The dataset "{name}" was not found. Please check the settings.',
    "error.columnMissing": 'The column "{column}" was not found in the dataset "{dataset}". Please check the settings.',
    "error.goalMissing": "No goal was found for {month}. Please check the goal data.",
    "error.goalNotPositive": "Progress cannot be calculated because the goal is zero or less. Please check the goal data.",
    "error.sampleOnlyInDemo": "The sample data ships only with the demo page (demo/app.js). In the released bundle, pass your own data through config and data.",

    "compare.lastMonth": "vs last month",
    "compare.last7": "vs previous 7 days",
    "compare.last30": "vs previous 30 days",
    "compare.last90": "vs previous 90 days",
    "compare.thisYear": "vs last year",
    "compare.generic": "vs previous period",

    "agg.sum": "Sum",
    "agg.avg": "Average",
    "agg.count": "Count",
    "agg.distinct": "Distinct",
    "agg.min": "Min",
    "agg.max": "Max",
  },
};

const VAR_PATTERN_ = /\{(\w+)\}/g;

/** vars の値を文の {name} に差し込む。値が無ければ {name} をそのまま残す */
function fillVars_(text, vars) {
  if (!vars || typeof vars !== "object") return text;
  return text.replace(VAR_PATTERN_, (whole, name) => (vars[name] === undefined ? whole : String(vars[name])));
}

/**
 * lang・key から画面の文を返す。lang が LANGS に無ければ ja にする。
 * key が無ければ key をそのまま返す（差し込みは行わない）
 */
export function t(lang, key, vars) {
  const table = MESSAGES[lang] || MESSAGES.ja;
  const text = table[key];
  if (text === undefined) return key;
  return fillVars_(text, vars);
}
