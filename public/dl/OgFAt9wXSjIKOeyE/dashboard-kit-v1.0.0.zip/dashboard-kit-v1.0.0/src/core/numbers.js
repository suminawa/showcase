/**
 * 数の読み取りと書式づくりの道具。設定の値や取り込んだ表の値はここを通して数にする。
 * ここは純粋な計算だけを行い、画面や日時には触れない
 */

import { toHalfWidth } from "./text.js";

const NUMBER_STRIP_PATTERN_ = /[¥￥$,円]/g;
const NUMBER_ONLY_PATTERN_ = /^-?\d+(\.\d+)?$/;

/**
 * 値を数にする。数値はそのまま（NaN・Infinity は null）。
 * 文字は全角を半角にしたあと、通貨の記号（¥ ￥ $）・桁区切りのカンマ・「円」を外し、
 * 前後の空白を落とす。末尾の % は 100 で割らず、その数のまま外す（"12%" → 12）。
 * 残った文字が -?数字(.数字)? の形だけなら数にする。かっこの負数・指数表記・空文字は null
 */
export function parseNumber(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value !== "string") return null;
  let text = toHalfWidth(value).replace(NUMBER_STRIP_PATTERN_, "").trim();
  if (text.endsWith("%")) text = text.slice(0, -1).trim();
  return NUMBER_ONLY_PATTERN_.test(text) ? Number(text) : null;
}

/** 3 桁ごとにカンマを入れる（value は 0 以上、すでに小数の桁数を揃えた文字列にしてから呼ぶ） */
function numberGroup_(value, decimals) {
  const fixed = value.toFixed(decimals);
  const parts = fixed.split(".");
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return parts.join(".");
}

/**
 * compact 用の書式。小数 1 桁のときだけ末尾の .0 を落とす。
 * grouped が true のときは（いちばん大きい単位で桁があふれたときのために）3 桁ごとにカンマも入れる
 */
function numberFixed_(value, decimals, dropTrailingZero, grouped) {
  const fixed = grouped ? numberGroup_(value, decimals) : value.toFixed(decimals);
  if (dropTrailingZero && decimals === 1 && fixed.endsWith(".0")) return fixed.slice(0, -2);
  return fixed;
}

/**
 * 縮めた数（compact）の小数の桁。札の場所どりを一定に保つため、書式の decimals に
 * 関わらずいつも 1 桁にする（末尾の .0 は落とす）。decimals は縮めない表示にだけ効く
 */
const NUMBER_COMPACT_DECIMALS_ = 1;

/** compact の単位。小さい方から並べる。ja は 万・億、en は K・M・B */
const NUMBER_COMPACT_UNITS_JA_ = [
  { divisor: 1e4, unit: "万" },
  { divisor: 1e8, unit: "億" },
];
const NUMBER_COMPACT_UNITS_EN_ = [
  { divisor: 1e3, unit: "K" },
  { divisor: 1e6, unit: "M" },
  { divisor: 1e9, unit: "B" },
];

/**
 * compact のときの単位と縮めた値。しきい値未満なら null（そのままの数で表す）。
 * まず raw の大きさで単位を選び、decimals 桁に丸めたあとの値が次の単位のしきい値に届くなら
 * （例: 万で丸めると 10000.0 になる）ひとつ上の単位に繰り上げる。届かなくなるまで、または
 * いちばん大きい単位に着くまで繰り返す。いちばん大きい単位（ja の億・en の B）はこれ以上
 * 繰り上げる先が無いので、terminal を true にして返す（3 桁区切りが要るかの目印にする）
 */
function numberCompactScale_(abs, isEn, decimals) {
  const units = isEn ? NUMBER_COMPACT_UNITS_EN_ : NUMBER_COMPACT_UNITS_JA_;
  let index = -1;
  for (let i = units.length - 1; i >= 0; i -= 1) {
    if (abs >= units[i].divisor) {
      index = i;
      break;
    }
  }
  if (index === -1) return null;

  let value = abs / units[index].divisor;
  while (index + 1 < units.length) {
    const rounded = Number(value.toFixed(decimals));
    const nextStep = units[index + 1].divisor / units[index].divisor;
    if (rounded < nextStep) break;
    index += 1;
    value = abs / units[index].divisor;
  }
  return { value, unit: units[index].unit, terminal: index === units.length - 1 };
}

/**
 * value を format・options に沿った文字列にする。
 * format は "number"|"yen"|"usd"|"percent" か { type: "custom", prefix, suffix, decimals }。
 * lang が "en" のときだけ英語の compact 単位（K/M/B）を使う（既定は ja の 万・億）。
 * 小数の桁は既定 0、percent は既定 1。options.decimals を渡すと、それがすべてに勝つ。
 * ただし縮めた数（compact）だけは、いつも 1 桁にする（末尾の .0 は落とす）。
 * 丸めた結果が 0 になったときは、負の符号を付けない（"-0" を作らない）。
 * value が数でなければ "—"
 */
export function formatNumber(value, format, lang, options) {
  if (typeof value !== "number" || !Number.isFinite(value)) return "—";
  const opts = options && typeof options === "object" ? options : {};
  const fmt = format && typeof format === "object" ? format : { type: format };
  const isEn = lang === "en";

  const negative = value < 0;
  let abs = Math.abs(value);

  let unit = "";
  let compacting = false;
  let terminal = false;
  if (opts.compact === true && fmt.type !== "percent") {
    // 繰り上げの判定は「実際に表示する桁」で丸めてから行う。縮めた数の桁はいつも 1 つ
    const scaled = numberCompactScale_(abs, isEn, NUMBER_COMPACT_DECIMALS_);
    if (scaled) {
      abs = scaled.value;
      unit = scaled.unit;
      terminal = scaled.terminal;
      compacting = true;
    }
  }

  let decimals = 0;
  if (fmt.type === "percent") decimals = 1;
  if (fmt.type === "custom" && Number.isFinite(fmt.decimals)) decimals = fmt.decimals;
  if (Number.isFinite(opts.decimals)) decimals = opts.decimals;
  if (compacting) decimals = NUMBER_COMPACT_DECIMALS_;

  const numText = compacting ? numberFixed_(abs, decimals, true, terminal) : numberGroup_(abs, decimals);
  // 丸めた結果がゼロなら符号を落とす（-0.4 を小数 0 桁で出すと "-0" になってしまう）
  const sign = negative && Number(numText.split(",").join("")) !== 0 ? "-" : "";

  if (fmt.type === "yen") return sign + "¥" + numText + unit;
  if (fmt.type === "usd") return sign + "$" + numText + unit;
  if (fmt.type === "percent") return sign + numText + unit + "%";
  if (fmt.type === "custom") return sign + (fmt.prefix || "") + numText + unit + (fmt.suffix || "");
  return sign + numText + unit;
}

const NICE_STEP_MULTIPLES_ = [1, 2, 2.5, 5, 10];

/**
 * rawStep 以上になる、1・2・2.5・5 の倍数（× 10^n）でいちばん小さいもの。
 * magnitude は rawStep と同じ桁（10^n）なので residual は必ず 1〜10 未満になり、
 * NICE_STEP_MULTIPLES_ の最後の 10 でいつも見つかる
 */
function numberNiceStep_(rawStep) {
  const magnitude = Math.pow(10, Math.floor(Math.log10(rawStep) + 1e-12));
  const residual = rawStep / magnitude;
  const multiple = NICE_STEP_MULTIPLES_.find((candidate) => residual <= candidate + 1e-9);
  return multiple * magnitude;
}

/** 浮動小数の誤差（0.1 + 0.2 のような）を消す丸め */
function numberRound_(value) {
  return Math.round(value * 1e9) / 1e9;
}

/**
 * min〜max を見やすく表す目盛りの配列を作る。0 以上の範囲は 0 から始める。
 * min が負のときは、min を下回らないきりのいい負の下限から始める。
 * 刻みは 1・2・2.5・5 × 10^n から、count 個ぶんの間隔にいちばん近いものを選ぶ。
 * 最後の目盛りは max 以上。max が min 以下、または max が 0 のときは [0, 1] にする
 */
export function niceTicks(min, max, count = 4) {
  if (max <= min || max === 0) return [0, 1];

  const start = min >= 0 ? 0 : min;
  const rawStep = (max - start) / count;
  const step = numberNiceStep_(rawStep);
  const first = min >= 0 ? 0 : Math.floor(min / step) * step;

  const ticks = [first];
  let cursor = first;
  while (cursor < max) {
    cursor = numberRound_(cursor + step);
    ticks.push(cursor);
  }
  return ticks;
}
