/**
 * 集計まわりの純粋な道具。sum・avg・count・distinct・min・max、区分ごとのグループ分け、
 * 上位 N と「その他」、日付の刻みごとの推移、前の期間との比較を行う。
 * 数の値は JS の number か null（null は「読めなかった値」）としてここに来る
 */

import { isDateKey, bucketKey, bucketCountBetween, bucketsBetween, autoBucket } from "./dates.js";
import { textOf } from "./text.js";

/** value が数として使える値か（null・undefined・NaN・±Infinity は使えない） */
function aggregateIsNumber_(value) {
  return typeof value === "number" && Number.isFinite(value);
}

/**
 * rows の value 列を agg で集計する。
 * count は行数そのもの（値は見ない）。distinct は空（null・undefined・前後の空白を落として
 * 空文字になるものも含む）をのぞいた種類の数。数値と文字列表現が同じ値（5 と "5"）は 1 つに数える。
 * sum・avg・min・max は数でない値（null 等）をのぞき、その件数を skipped で返す。
 * 行が 0 件のとき sum・count・distinct は 0、avg・min・max は null
 */
export function aggregate(rows, value, agg) {
  const list = Array.isArray(rows) ? rows : [];

  if (agg === "count") return { value: list.length, skipped: 0 };

  if (agg === "distinct") {
    // 空（null・undefined・前後の空白を落として空文字になるもの）は数えない。
    // 文字列表現で数えるので、5 と "5" のように型だけ違う値は 1 つにまとまる
    const seen = new Set();
    for (const row of list) {
      const v = row ? row[value] : undefined;
      const key = textOf(v);
      if (key === "") continue;
      seen.add(key);
    }
    return { value: seen.size, skipped: 0 };
  }

  const valid = [];
  let skipped = 0;
  for (const row of list) {
    const v = row ? row[value] : undefined;
    if (aggregateIsNumber_(v)) {
      valid.push(v);
    } else {
      skipped += 1;
    }
  }

  if (agg === "sum") return { value: valid.reduce((a, b) => a + b, 0), skipped };
  if (agg === "avg") return { value: valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : null, skipped };
  if (agg === "min") return { value: valid.length ? Math.min(...valid) : null, skipped };
  if (agg === "max") return { value: valid.length ? Math.max(...valid) : null, skipped };
  return { value: null, skipped: 0 };
}

/**
 * rows を column の値ごとに分ける（先に出てきた値の順を保つ Map）。
 * 値が null・undefined・空文字のときは、呼び出し側が渡した blankLabel にまとめる
 * （画面の言葉は呼び出し側が t(lang, ...) で用意する。ここでは文字を決め打ちしない）
 */
export function groupBy(rows, column, blankLabel) {
  const map = new Map();
  const list = Array.isArray(rows) ? rows : [];
  for (const row of list) {
    const raw = row ? row[column] : undefined;
    const key = raw === null || raw === undefined || raw === "" ? blankLabel : String(raw);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(row);
  }
  return map;
}

/**
 * { key, value } の並びを value の大きい順、同じなら key の単純比較（ロケールに寄らない）で
 * 並べるための比較関数。topN のほか、区分ごとの色決めの並び替えでも使う共通の道具
 */
export function compareEntriesDesc(a, b) {
  const av = aggregateIsNumber_(a.value) ? a.value : null;
  const bv = aggregateIsNumber_(b.value) ? b.value : null;
  if (av === null && bv === null) return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
  if (av === null) return 1;
  if (bv === null) return -1;
  if (av !== bv) return bv - av;
  return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
}

/**
 * { key, value } の並びを value の大きい順（同じなら key 順）に並べ、上位 n 件にする。
 * n を超えた分は、sum・count のときだけ 1 つの otherLabel（{ isOther: true }）に足し合わせて
 * 最後に付ける（その値がほかより大きくても最後）。avg・distinct・min・max は足し合わせられない
 * ので、超えた分は切り捨てるだけで other は false のまま。
 * 入力の key がすでに otherLabel と同じでも、特別扱いはしない
 */
export function topN(entries, n, otherLabel, agg) {
  const sorted = (Array.isArray(entries) ? entries.slice() : []).sort(compareEntriesDesc);
  if (sorted.length <= n) return { entries: sorted, other: false };

  const kept = sorted.slice(0, n);
  const overflow = sorted.slice(n);

  if (agg === "sum" || agg === "count") {
    const total = overflow.reduce((acc, entry) => acc + (aggregateIsNumber_(entry.value) ? entry.value : 0), 0);
    kept.push({ key: otherLabel, value: total, isOther: true });
    return { entries: kept, other: true };
  }

  return { entries: kept, other: false };
}

const AGGREGATE_BUCKET_ORDER_ = ["day", "week", "month", "quarter", "year"];

/** 1 つのグラフに並べる刻みの上限 */
export const AGGREGATE_BUCKET_MAX_ = 400;

/**
 * 刻みの数が上限を超えないよう、day → week → month → quarter → year の順に粗くする。
 * いちばん粗い year にしても収まらないときは（日付の年を打ち間違えて 9999 年の行が
 * 混ざったときなど）、**新しいほうから上限ぶんだけ**を使い、capped を立てて呼び出し側に知らせる。
 * 数を先に数えてから並びを 1 回だけ作るので、何十万個になる組み合わせでも軽い
 */
function aggregateCoarsenBucket_(bucket, from, to) {
  let current = bucket;
  while (bucketCountBetween(from, to, current) > AGGREGATE_BUCKET_MAX_) {
    const at = AGGREGATE_BUCKET_ORDER_.indexOf(current);
    if (at === -1 || at === AGGREGATE_BUCKET_ORDER_.length - 1) break;
    current = AGGREGATE_BUCKET_ORDER_[at + 1];
  }
  const all = bucketsBetween(from, to, current);
  if (all.length <= AGGREGATE_BUCKET_MAX_) return { bucket: current, buckets: all, capped: false };
  return { bucket: current, buckets: all.slice(all.length - AGGREGATE_BUCKET_MAX_), capped: true };
}

/** rows の dateColumn から、日付キーの最小・最大を求める（読めない値は無視）。無ければ "" */
function aggregateDateSpan_(rows, dateColumn) {
  let min = "";
  let max = "";
  for (const row of rows) {
    const key = row ? row[dateColumn] : null;
    if (!isDateKey(key)) continue;
    if (min === "" || key < min) min = key;
    if (max === "" || key > max) max = key;
  }
  return { min, max };
}

/**
 * rows を刻み（bucket）ごとに value を agg で集計した推移にする。
 * range の from/to が空（開いている）ときは、rows にある日付の最小・最大を範囲にする
 * （それでもデータが無ければ { buckets: [], values: [] }）。
 * bucket が "auto" なら autoBucket(from, to) で決め、刻みの数が上限を超えるときは粗くする。
 * いちばん粗くしても収まらないときは、新しいほうから上限ぶんだけを使い capped: true を返す。
 * 値の無い刻みは、sum・count・distinct は 0、avg・min・max は null になる（aggregate の既定と同じ）
 */
export function timeSeries(rows, options) {
  const opts = options || {};
  const dateColumn = opts.dateColumn;
  const value = opts.value;
  const agg = opts.agg;
  const list = Array.isArray(rows) ? rows : [];
  const rangeIn = opts.range || { from: "", to: "" };

  let from = rangeIn.from || "";
  let to = rangeIn.to || "";
  if (from === "" || to === "") {
    const span = aggregateDateSpan_(list, dateColumn);
    if (span.min === "") return { buckets: [], values: [], capped: false };
    if (from === "") from = span.min;
    if (to === "") to = span.max;
  }

  const startBucket = opts.bucket === "auto" ? autoBucket(from, to) : opts.bucket;
  const resolved = aggregateCoarsenBucket_(startBucket, from, to);

  const grouped = new Map();
  for (const row of list) {
    const dateValue = row ? row[dateColumn] : null;
    if (!isDateKey(dateValue) || dateValue < from || dateValue > to) continue;
    const key = bucketKey(dateValue, resolved.bucket);
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }

  const values = resolved.buckets.map((key) => aggregate(grouped.get(key) || [], value, agg).value);

  return { bucket: resolved.bucket, buckets: resolved.buckets, values, capped: resolved.capped };
}

/**
 * いまの値と前の値を比べる。どちらかが null なら比べようがないので null。
 * ratio は delta を前の値の絶対値で割ったもの。前の値が 0 のときは割れないので ratio は null
 * （delta 自体は返す）
 */
export function compareValue(current, previous) {
  if (current === null || previous === null) return null;
  const delta = current - previous;
  const ratio = previous === 0 ? null : delta / Math.abs(previous);
  return { delta, ratio };
}
