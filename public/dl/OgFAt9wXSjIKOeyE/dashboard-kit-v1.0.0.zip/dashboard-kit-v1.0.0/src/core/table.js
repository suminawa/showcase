/**
 * 取り込んだ表の列の型を決め、値をその型に合わせ、行数を上限で切る道具。
 * ここは純粋な計算だけを行う
 */

import { textOf, hasOwn, setOwn } from "./text.js";
import { parseNumber } from "./numbers.js";
import { toDateKey } from "./dates.js";

const TABLE_LEADING_ZERO_PATTERN_ = /^0\d+$/;
const TABLE_LONG_DIGITS_PATTERN_ = /^\d{13,}$/;

/**
 * 電話番号・郵便番号のような先頭が 0 の数字列や、13 桁以上の長い数字列は、
 * 数として読めても「数の列」の証拠には数えない（先頭の 0 が消えたり、桁が大きすぎるため）
 */
function tableLooksLikeIdText_(text) {
  return TABLE_LEADING_ZERO_PATTERN_.test(text) || TABLE_LONG_DIGITS_PATTERN_.test(text);
}

/** 1 つの列について、空でない値のうち数・日付として読める割合から型を決める */
function tableInferColumnType_(rows, column) {
  let nonEmpty = 0;
  let numberish = 0;
  let dateish = 0;
  for (const row of rows) {
    const raw = row && typeof row === "object" ? row[column] : undefined;
    const text = textOf(raw);
    if (text === "") continue;
    nonEmpty += 1;
    if (!tableLooksLikeIdText_(text) && parseNumber(text) !== null) numberish += 1;
    if (toDateKey(text) !== "") dateish += 1;
  }
  if (nonEmpty === 0) return "text";
  if (numberish / nonEmpty >= 0.9) return "number";
  if (dateish / nonEmpty >= 0.9) return "date";
  return "text";
}

/**
 * 各列の型を "number"|"date"|"text" で決める。空でない値の 90% 以上が数なら number、
 * 90% 以上が日付として読めれば date、それ以外・値が無い列は text。
 * overrides（{ 列名: 型 }）に載っている列は、その型をそのまま使う（推論に勝つ）
 */
export function inferTypes(columns, rows, overrides) {
  const cols = Array.isArray(columns) ? columns : [];
  const list = Array.isArray(rows) ? rows : [];
  const overrideMap = overrides && typeof overrides === "object" ? overrides : {};
  const result = {};
  for (const column of cols) {
    // 列の名前は取り込んだ表の見出しなので、"toString" のような名前で JS が最初から
    // 持っている項目を拾わないよう、自分が持つ項目だけを読む
    const forced = hasOwn(overrideMap, column) ? overrideMap[column] : undefined;
    const type = forced === "number" || forced === "date" || forced === "text" ? forced : tableInferColumnType_(list, column);
    setOwn(result, column, type);
  }
  return result;
}

/**
 * 行を型どおりの値に作り直す（新しいオブジェクトを返し、元の行は変えない）。
 * number は parseNumber、date は toDateKey、それ以外（text）は textOf の値にする。
 * number・date で読めない値は null、text は読めなくても空文字にする
 */
export function coerceRows(rows, types) {
  const list = Array.isArray(rows) ? rows : [];
  const typeMap = types && typeof types === "object" ? types : {};
  const columns = Object.keys(typeMap);
  return list.map((row) => {
    const src = row && typeof row === "object" ? row : {};
    const record = {};
    for (const column of columns) {
      const raw = src[column];
      const type = typeMap[column];
      if (type === "number") {
        setOwn(record, column, parseNumber(raw));
      } else if (type === "date") {
        const key = toDateKey(raw);
        setOwn(record, column, key === "" ? null : key);
      } else {
        setOwn(record, column, textOf(raw));
      }
    }
    return record;
  });
}

/** 1 つのデータにつき、画面が扱う行数の上限（README の「20,000 行」はこの数） */
export const TABLE_ROW_LIMIT_ = 20000;

/**
 * 行数が max（既定 TABLE_ROW_LIMIT_）を超えたら、先頭から max 行だけにして truncated: true を返す。
 * 超えていなければそのまま truncated: false
 */
export function limitRows(rows, max = TABLE_ROW_LIMIT_) {
  const list = Array.isArray(rows) ? rows : [];
  if (list.length <= max) return { rows: list, truncated: false };
  return { rows: list.slice(0, max), truncated: true };
}
