/**
 * ダッシュボードの設定を検査し、そろった形にする 1 か所。
 * JSON から読んだ raw も、configFromSheets が シートから作った raw も、ここを通す。
 * ここは純粋な検査・組み立てだけを行う
 */

import { textOf, toHalfWidth } from "./text.js";
import { parseNumber } from "./numbers.js";
import { isDateKey, toDateKey } from "./dates.js";

const CONFIG_LANGS_ = ["ja", "en"];
const CONFIG_THEMES_ = ["auto", "light", "dark"];
/**
 * 期間の名前の並び。設定の検査・URL の読み取り（filter.js）・画面の select（state.js）は、
 * どれもこの 1 つの並びを使う（3 か所に書くと、足したときに片方だけ古いままになるため）
 */
export const CONFIG_PERIODS_ = ["thisMonth", "lastMonth", "last7", "last30", "last90", "thisYear", "all", "custom"];
const CONFIG_SIZES_ = ["s", "m", "l"];
const CONFIG_FORMATS_ = ["number", "yen", "usd", "percent"];
const CONFIG_WIDGET_TYPES_ = ["kpi", "line", "bar", "meter", "table"];
const CONFIG_AGGS_ = ["sum", "avg", "count", "distinct", "min", "max"];
const CONFIG_BUCKETS_ = ["auto", "day", "week", "month", "quarter", "year"];
const CONFIG_COMPARES_ = ["previous", "none"];
const CONFIG_GOOD_WHENS_ = ["up", "down"];
const CONFIG_BAR_SORTS_ = ["value", "label"];
const CONFIG_TABLE_ORDERS_ = ["desc", "asc"];
const CONFIG_MAX_DIMENSIONS_ = 3;
const CONFIG_BAR_TOP_RANGE_ = [1, 20];
const CONFIG_TABLE_TOP_RANGE_ = [1, 200];

const CONFIG_WIDGET_SIZE_DEFAULTS_ = { kpi: "s", meter: "m", bar: "m", line: "l", table: "l" };
/** 小さい札では目盛りも区分名も読めなくなるので、s を受け取らない部品 */
const CONFIG_WIDE_ONLY_TYPES_ = ["line", "bar"];

/** そろった形の設定の既定値。parseConfig はこれを土台にする（この定数自体は書き換えない） */
export const DEFAULT_CONFIG = {
  title: "",
  lang: "ja",
  theme: "auto",
  cacheMinutes: 5,
  datasets: {},
  filters: { period: "thisMonth", from: "", to: "", dimensions: [] },
  widgets: [],
};

/** 呼び出しのたびに新しいオブジェクトを返す（DEFAULT_CONFIG を書き換えさせないため） */
function configDefault_() {
  return {
    title: "",
    lang: "ja",
    theme: "auto",
    cacheMinutes: 5,
    datasets: {},
    filters: { period: "thisMonth", from: "", to: "", dimensions: [] },
    widgets: [],
  };
}

function configIsPlainObject_(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

/**
 * 名前をキーにした入れ物（datasets など）から、自身が持つ項目だけを取り出す。
 * "toString"・"constructor" のような、書いていないのに JS が最初から持っている名前を
 * 誤って拾わないため（プロトタイプ越しの読み取りを防ぐ）。無ければ undefined
 */
function configOwn_(obj, name) {
  return name !== "" && Object.prototype.hasOwnProperty.call(obj, name) ? obj[name] : undefined;
}

/**
 * 名前をキーにした入れ物へ、"__proto__" という名前でも入れ物自体のプロトタイプを
 * 書き換えずに、普通の 1 項目として入れる
 */
function configSetOwn_(obj, name, value) {
  Object.defineProperty(obj, name, { value, writable: true, enumerable: true, configurable: true });
}

/**
 * value を「本当に数だけを表しているか」厳しく読む。数値はそのまま（有限のときだけ）。
 * 文字は全角を半角にして前後の空白を落とし、数字だけ（0〜9 の並び）ならその数にする。
 * true/false・配列・小数点を含む文字など、それ以外は null にする
 * （Number(true) が 1 になるような緩い読み替えで誤りを見逃さないため）
 */
function configStrictNumber_(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value !== "string") return null;
  const text = toHalfWidth(value).trim();
  return /^\d+$/.test(text) ? Number(text) : null;
}

/** エラーの文の言語。raw.lang が厳密に "en" のときだけ英語。それ以外はすべて日本語 */
function configErrorLang_(raw) {
  return raw !== null && raw !== undefined && raw.lang === "en" ? "en" : "ja";
}

/** 全体の誤り（部品に属さない）の文 */
function configTopError_(lang, ja, en) {
  return "dashboard: " + (lang === "en" ? en : ja);
}

/** 部品の誤りの文。position は 1 から始まる順番、title は空でもよい */
function configWidgetError_(lang, position, title, ja, en) {
  if (lang === "en") {
    const label = title ? ' "' + title + '"' : "";
    return "dashboard: widget " + position + label + " " + en;
  }
  const label = title ? "「" + title + "」" : "";
  return "dashboard: " + position + " 番目の部品" + label + "の " + ja;
}

/** raw[field] が知られた値の並びに含まれるか。無ければ既定値を、あれば誤りとして知らせる印を返す */
function configPickEnum_(raw, field, allowed, fallback) {
  const value = raw[field];
  if (value === undefined) return { value: fallback, present: false };
  if (allowed.indexOf(value) === -1) return { value: fallback, present: true, invalid: true };
  return { value, present: true };
}

const CONFIG_URL_HTTP_PATTERN_ = /^http:/i;
const CONFIG_URL_HTTPS_PATTERN_ = /^https:/i;
const CONFIG_URL_SCHEME_PATTERN_ = /^[a-zA-Z][a-zA-Z0-9+.-]*:/;
const CONFIG_URL_CONTROL_CHAR_PATTERN_ = /[\x00-\x1f]/;

/**
 * データセットの url が使ってよい形か。使ってよいのは https の URL か、相対パス
 * （バックスラッシュを含まない・// で始まらない・スキームを持たない・制御文字を含まない）だけ。
 * "httpOnly" は http: だけが理由で誤りのとき、それ以外の誤りはまとめて "scheme"
 * （// で始まる、バックスラッシュを含む、https 以外のスキーム、制御文字を含む、のどれか）
 */
function configUrlProblem_(url) {
  if (CONFIG_URL_HTTPS_PATTERN_.test(url)) return null;
  if (CONFIG_URL_HTTP_PATTERN_.test(url)) return "httpOnly";
  if (url.indexOf("\\") !== -1) return "scheme"; // /\evil や \\evil\a のようなバックスラッシュの経路
  if (url.startsWith("//")) return "scheme"; // //evil.example.com のようなプロトコル相対 URL
  if (CONFIG_URL_SCHEME_PATTERN_.test(url)) return "scheme"; // javascript: や ftp: など、https 以外のスキーム
  if (CONFIG_URL_CONTROL_CHAR_PATTERN_.test(url)) return "scheme";
  return null; // スキームも // もバックスラッシュも無い相対パス
}

/**
 * その置き場所を取りに行ってよいか。決まりは configUrlProblem_ の 1 か所だけにあり、
 * これはそれをそのまま真偽で言い直したもの（空の url は「指定なし」なので取りに行かない）。
 * 設定の検査と、実際に取りに行く側の両方から、同じ答えを見られるようにするために外に出してある
 */
export function isAllowedDataUrl(url) {
  const want = textOf(url);
  return want !== "" && configUrlProblem_(want) === null;
}

/** データセットの名前として使えない、JS が最初から特別に扱う名前 */
const CONFIG_RESERVED_DATASET_NAMES_ = ["__proto__", "prototype", "constructor"];

/**
 * データセットの url を検査する。空のときは「指定なし」として何も言わない
 * （data で行を渡すときと、スプレッドシート版では url を書かないため）。
 * 書かれているのに使えない形のときだけ誤りにし、url は空にして取りに行かせない。
 * source が "sheets" のときも同じ検査を通す（取りに行く側と同じ決まりにそろえるため）
 */
function configCheckUrl_(name, value, lang, errors) {
  const url = textOf(value);
  if (url === "") return "";
  const problem = configUrlProblem_(url);
  if (problem === null) return url;
  if (problem === "httpOnly") {
    errors.push(
      configTopError_(lang, "データセット「" + name + "」の url は https の URL にしてください", 'dataset "' + name + '" url must use https.')
    );
  } else {
    errors.push(configTopError_(lang, "データセット「" + name + "」の url を確認してください", 'dataset "' + name + '" url is not valid.'));
  }
  return "";
}

/**
 * raw.datasets を検査してそろえる。source が "sheets" かつ raw.datasets が無いときは、
 * GAS の仕組み（データセット名 = シート名、存在は読み込み時にサーバーが確かめる）として、
 * 「datasets が無い」という全体の誤りにしない
 */
function configBuildDatasets_(raw, lang, errors) {
  const isSheetsSource = raw.source === "sheets";
  const hasDatasets = raw.datasets !== undefined;

  if (!hasDatasets) {
    if (!isSheetsSource) {
      errors.push(configTopError_(lang, "datasets（データセット）を設定してください", "Add at least one dataset in datasets."));
    }
    return { datasets: {}, skipExistenceCheck: isSheetsSource, broken: false };
  }

  if (!configIsPlainObject_(raw.datasets)) {
    errors.push(configTopError_(lang, "datasets の形式を確認してください", "datasets is not a valid object."));
    return { datasets: {}, skipExistenceCheck: false, broken: true };
  }

  const datasets = {};
  for (const rawName of Object.keys(raw.datasets)) {
    const name = textOf(rawName);
    if (name === "") continue;
    if (CONFIG_RESERVED_DATASET_NAMES_.indexOf(name) !== -1) {
      errors.push(
        configTopError_(
          lang,
          "データの名前「" + name + "」は使えません。別の名前にしてください",
          'The name "' + name + '" cannot be used for a dataset. Please choose a different name.'
        )
      );
      continue;
    }
    const entry = raw.datasets[rawName];
    const src = configIsPlainObject_(entry) ? entry : {};
    const dateColumn = textOf(src.dateColumn);
    const url = configCheckUrl_(name, src.url, lang, errors);
    const types = configIsPlainObject_(src.types) ? src.types : {};
    datasets[name] = { url, dateColumn, types };
  }
  return { datasets, skipExistenceCheck: false, broken: false };
}

/** dataset 名が使えるか（存在の検査を省く場合は、空でなければ使えるとする） */
function configDatasetExists_(name, datasetsCtx) {
  if (name === "") return false;
  if (datasetsCtx.skipExistenceCheck) return true;
  return Object.prototype.hasOwnProperty.call(datasetsCtx.datasets, name);
}

function configBuildFilters_(raw, lang, errors) {
  const filters = configIsPlainObject_(raw.filters) ? raw.filters : {};

  const periodPick = configPickEnum_(filters, "period", CONFIG_PERIODS_, "thisMonth");
  if (periodPick.invalid) {
    errors.push(configTopError_(lang, "filters.period（期間）の値が正しくありません", "filters.period is not valid."));
  }

  let from = textOf(filters.from);
  if (from !== "" && !isDateKey(from)) {
    errors.push(configTopError_(lang, "filters.from の値が正しくありません", "filters.from is not valid."));
    from = "";
  }
  let to = textOf(filters.to);
  if (to !== "" && !isDateKey(to)) {
    errors.push(configTopError_(lang, "filters.to の値が正しくありません", "filters.to is not valid."));
    to = "";
  }

  let dimensions = Array.isArray(filters.dimensions) ? filters.dimensions.map(textOf).filter((v) => v !== "") : [];
  if (dimensions.length > CONFIG_MAX_DIMENSIONS_) {
    errors.push(
      configTopError_(
        lang,
        "filters.dimensions（絞り込みの列）は " + CONFIG_MAX_DIMENSIONS_ + " つまでにしてください",
        "filters.dimensions can have at most " + CONFIG_MAX_DIMENSIONS_ + " columns."
      )
    );
    dimensions = dimensions.slice(0, CONFIG_MAX_DIMENSIONS_);
  }

  return { period: periodPick.value, from, to, dimensions };
}

/** agg が "count" でなければ value が要る、という決まりに沿って value を取り出す */
function configRequireValue_(item, agg) {
  const value = textOf(item.value);
  if (value === "" && agg !== "count") return { ok: false };
  return { ok: true, value };
}

function configBuildFormat_(item) {
  if (item.format === undefined) return { ok: true, value: "number" };
  if (typeof item.format === "string") {
    if (CONFIG_FORMATS_.indexOf(item.format) === -1) return { ok: false };
    return { ok: true, value: item.format };
  }
  if (configIsPlainObject_(item.format) && item.format.type === "custom") {
    let decimals = 0;
    if (item.format.decimals !== undefined) {
      const num = configStrictNumber_(item.format.decimals);
      if (num === null || !Number.isInteger(num) || num < 0) return { ok: false };
      decimals = num;
    }
    return {
      ok: true,
      value: { type: "custom", prefix: textOf(item.format.prefix), suffix: textOf(item.format.suffix), decimals },
    };
  }
  return { ok: false };
}

/** top（上位の数）。範囲に丸めず、外れていれば誤り。true や "8.5" のような値も誤りにする */
function configBuildTop_(item, range, fallback) {
  if (item.top === undefined) return { ok: true, value: fallback };
  const num = configStrictNumber_(item.top);
  if (num === null || !Number.isInteger(num) || num < range[0] || num > range[1]) return { ok: false };
  return { ok: true, value: num };
}

/** 種類に関わらず使う size・format を組み立てる。誤りがあれば { ok:false, field } を返す */
function configBuildCommonTail_(item, type) {
  const sizePick = configPickEnum_(item, "size", CONFIG_SIZES_, CONFIG_WIDGET_SIZE_DEFAULTS_[type]);
  if (sizePick.invalid) return { ok: false, field: "size" };
  if (sizePick.value === "s" && CONFIG_WIDE_ONLY_TYPES_.indexOf(type) !== -1) return { ok: false, field: "sizeSmall" };
  const format = configBuildFormat_(item);
  if (!format.ok) return { ok: false, field: "format" };
  return { ok: true, size: sizePick.value, format: format.value, note: textOf(item.note) };
}

function configBuildKpi_(item, ctx) {
  const aggPick = configPickEnum_(item, "agg", CONFIG_AGGS_, "sum");
  if (aggPick.invalid) return { ok: false, field: "agg" };
  const valuePick = configRequireValue_(item, aggPick.value);
  if (!valuePick.ok) return { ok: false, field: "value" };

  const comparePick = configPickEnum_(item, "compare", CONFIG_COMPARES_, "previous");
  if (comparePick.invalid) return { ok: false, field: "compare" };
  const goodWhenPick = configPickEnum_(item, "goodWhen", CONFIG_GOOD_WHENS_, "up");
  if (goodWhenPick.invalid) return { ok: false, field: "goodWhen" };
  if (item.sparkline !== undefined && typeof item.sparkline !== "boolean") return { ok: false, field: "sparkline" };
  const sparkline = item.sparkline === undefined ? true : item.sparkline;

  let compare = comparePick.value;
  if (compare === "previous") {
    const dataset = configOwn_(ctx.datasets, textOf(item.dataset));
    if (!dataset || dataset.dateColumn === "") compare = "none";
  }

  return { ok: true, extra: { value: valuePick.value, agg: aggPick.value, compare, goodWhen: goodWhenPick.value, sparkline } };
}

function configBuildLine_(item, ctx) {
  const aggPick = configPickEnum_(item, "agg", CONFIG_AGGS_, "sum");
  if (aggPick.invalid) return { ok: false, field: "agg" };
  const valuePick = configRequireValue_(item, aggPick.value);
  if (!valuePick.ok) return { ok: false, field: "value" };
  const bucketPick = configPickEnum_(item, "bucket", CONFIG_BUCKETS_, "auto");
  if (bucketPick.invalid) return { ok: false, field: "bucket" };

  const dataset = configOwn_(ctx.datasets, textOf(item.dataset));
  const ownDateColumn = textOf(item.dateColumn);
  const dateColumn = ownDateColumn !== "" ? ownDateColumn : dataset ? dataset.dateColumn : "";
  if (dateColumn === "") return { ok: false, field: "dateColumn" };

  return {
    ok: true,
    extra: { value: valuePick.value, agg: aggPick.value, splitBy: textOf(item.splitBy), bucket: bucketPick.value, dateColumn },
  };
}

function configBuildBar_(item) {
  const category = textOf(item.category);
  if (category === "") return { ok: false, field: "category" };
  const aggPick = configPickEnum_(item, "agg", CONFIG_AGGS_, "sum");
  if (aggPick.invalid) return { ok: false, field: "agg" };
  const valuePick = configRequireValue_(item, aggPick.value);
  if (!valuePick.ok) return { ok: false, field: "value" };
  const topPick = configBuildTop_(item, CONFIG_BAR_TOP_RANGE_, 8);
  if (!topPick.ok) return { ok: false, field: "top" };
  const sortPick = configPickEnum_(item, "sort", CONFIG_BAR_SORTS_, "value");
  if (sortPick.invalid) return { ok: false, field: "sort" };
  const horizontal = item.horizontal;
  if (horizontal !== undefined && horizontal !== true && horizontal !== false && horizontal !== "auto") {
    return { ok: false, field: "horizontal" };
  }

  return {
    ok: true,
    extra: {
      category,
      value: valuePick.value,
      agg: aggPick.value,
      splitBy: textOf(item.splitBy),
      top: topPick.value,
      sort: sortPick.value,
      horizontal: horizontal === undefined ? "auto" : horizontal,
    },
  };
}

function configBuildMeterTarget_(item, ctx) {
  const raw = item.target;
  if (raw === undefined) return { ok: false, field: "target", reason: "missing" };
  if (typeof raw === "number") {
    if (!Number.isFinite(raw)) return { ok: false, field: "target", reason: "invalid" };
    return { ok: true, value: raw };
  }
  if (!configIsPlainObject_(raw)) return { ok: false, field: "target", reason: "invalid" };

  const dataset = textOf(raw.dataset);
  const value = textOf(raw.value);
  if (dataset === "" || value === "") return { ok: false, field: "target", reason: "invalid" };
  if (!configDatasetExists_(dataset, ctx)) return { ok: false, field: "target", reason: "notFound", dataset };
  const aggPick = configPickEnum_(raw, "agg", CONFIG_AGGS_, "sum");
  if (aggPick.invalid) return { ok: false, field: "target", reason: "invalid" };
  const matchMonth = textOf(raw.matchMonth) || "月";
  return { ok: true, value: { dataset, value, agg: aggPick.value, matchMonth } };
}

function configBuildMeter_(item, ctx) {
  const aggPick = configPickEnum_(item, "agg", CONFIG_AGGS_, "sum");
  if (aggPick.invalid) return { ok: false, field: "agg" };
  const valuePick = configRequireValue_(item, aggPick.value);
  if (!valuePick.ok) return { ok: false, field: "value" };
  const targetPick = configBuildMeterTarget_(item, ctx);
  if (!targetPick.ok) return targetPick;

  return { ok: true, extra: { value: valuePick.value, agg: aggPick.value, target: targetPick.value } };
}

function configBuildTableColumns_(columns) {
  const result = [];
  for (const columnDef of columns) {
    const src = configIsPlainObject_(columnDef) ? columnDef : {};
    const value = textOf(src.value);
    if (value === "") return { ok: false };
    const aggPick = configPickEnum_(src, "agg", CONFIG_AGGS_, "sum");
    if (aggPick.invalid) return { ok: false };
    const format = configBuildFormat_(src);
    if (!format.ok) return { ok: false };
    const label = textOf(src.label) || value;
    result.push({ value, agg: aggPick.value, label, format: format.value });
  }
  return { ok: true, value: result };
}

function configSplitColumnList_(text) {
  return text
    .split(/[,、]/)
    .map((v) => v.trim())
    .filter((v) => v !== "");
}

function configBuildTable_(item) {
  const isDetail = textOf(item.rows) === "latest";
  const topPick = configBuildTop_(item, CONFIG_TABLE_TOP_RANGE_, 20);
  if (!topPick.ok) return { ok: false, field: "top" };

  if (isDetail) {
    const columns = Array.isArray(item.columns) ? item.columns.map(textOf).filter((v) => v !== "") : [];
    if (columns.length === 0) return { ok: false, field: "columns" };
    return { ok: true, extra: { rows: "latest", columns, top: topPick.value } };
  }

  const groupBy = textOf(item.groupBy);
  if (groupBy === "") return { ok: false, field: "groupBy" };
  if (!Array.isArray(item.columns) || item.columns.length === 0) return { ok: false, field: "columns" };
  const columnsPick = configBuildTableColumns_(item.columns);
  if (!columnsPick.ok) return { ok: false, field: "columns" };
  const orderPick = configPickEnum_(item, "order", CONFIG_TABLE_ORDERS_, "desc");
  if (orderPick.invalid) return { ok: false, field: "order" };

  return {
    ok: true,
    extra: { groupBy, columns: columnsPick.value, sort: textOf(item.sort), order: orderPick.value, top: topPick.value },
  };
}

const CONFIG_WIDGET_FIELD_TEXT_ = {
  agg: { ja: "agg（集計）を確認してください", en: "aggregation is not valid." },
  value: { ja: "value（値の列）を指定してください", en: "is missing its value column." },
  compare: { ja: "compare（比較）を確認してください", en: "compare option is not valid." },
  goodWhen: { ja: "goodWhen（良し悪しの向き）を確認してください", en: "goodWhen option is not valid." },
  sparkline: { ja: "sparkline（推移の表示）を確認してください", en: "sparkline option is not valid." },
  bucket: { ja: "bucket（刻み）を確認してください", en: "bucket option is not valid." },
  dateColumn: { ja: "dateColumn（日付の列）を指定してください", en: "is missing its date column." },
  category: { ja: "category（区分の列）を指定してください", en: "is missing its category column." },
  top: { ja: "top（上位の数）を確認してください", en: "top is not valid." },
  sort: { ja: "sort（並び）を確認してください", en: "sort option is not valid." },
  horizontal: { ja: "horizontal（向き）を確認してください", en: "horizontal option is not valid." },
  groupBy: { ja: "groupBy（区分の列）を指定してください", en: "is missing its groupBy column." },
  columns: { ja: "columns（列）を指定してください", en: "is missing its columns." },
  order: { ja: "order（並び順）を確認してください", en: "order option is not valid." },
  size: { ja: "size（大きさ）を確認してください", en: "size is not valid." },
  sizeSmall: {
    ja: "size は m か l にしてください（折れ線と棒は小さい札では読めません）",
    en: "size must be m or l, because a line or bar chart cannot be read in a small card.",
  },
  format: { ja: "format（書式）を確認してください", en: "format is not valid." },
  dataset: { ja: "dataset（データ）を指定してください", en: "is missing its dataset." },
  type: { ja: "type（種類）を確認してください", en: "type is not valid." },
};

function configFieldFailureText_(field) {
  return CONFIG_WIDGET_FIELD_TEXT_[field] || CONFIG_WIDGET_FIELD_TEXT_.format;
}

/** 1 つの部品を検査する。だめなら { id, type: "error", title, message } を、よければ組み立てた部品を返す */
function configBuildWidget_(item, index, ctx, lang, errors) {
  const position = index + 1;
  const raw = configIsPlainObject_(item) ? item : {};
  const title = textOf(raw.title);
  const id = "w" + position;

  const fail = (jaEn, extraJa, extraEn) => {
    const text = jaEn === "notFoundDataset"
      ? { ja: "dataset「" + extraJa + "」が見つかりません", en: 'dataset "' + extraEn + '" was not found.' }
      : jaEn === "notFoundTargetDataset"
      ? { ja: "target の dataset「" + extraJa + "」が見つかりません", en: 'target dataset "' + extraEn + '" was not found.' }
      : jaEn === "targetMissing"
      ? { ja: "target（目標）を指定してください", en: "is missing its target." }
      : jaEn === "targetInvalid"
      ? { ja: "target（目標）を確認してください", en: "target is not valid." }
      : configFieldFailureText_(jaEn);
    const message = configWidgetError_(lang, position, title, text.ja, text.en);
    errors.push(message);
    return { id, type: "error", title, message };
  };

  const typePick = configPickEnum_(raw, "type", CONFIG_WIDGET_TYPES_, "");
  if (typePick.value === "") return fail("type");

  const datasetName = textOf(raw.dataset);
  if (datasetName === "") return fail("dataset");
  if (ctx.datasetsBroken) {
    // datasets 自体が使えない形のときは、全体の誤りをすでに 1 件出しているので、
    // ここでは部品を誤りの札にするだけにして、同じ原因の文を errors に重ねない
    const text = { ja: "データセットを確認できないため使えません", en: "cannot be used because datasets could not be checked." };
    const message = configWidgetError_(lang, position, title, text.ja, text.en);
    return { id, type: "error", title, message };
  }
  if (!configDatasetExists_(datasetName, ctx)) return fail("notFoundDataset", datasetName, datasetName);

  let built;
  if (typePick.value === "kpi") built = configBuildKpi_(raw, ctx);
  else if (typePick.value === "line") built = configBuildLine_(raw, ctx);
  else if (typePick.value === "bar") built = configBuildBar_(raw);
  else if (typePick.value === "meter") built = configBuildMeter_(raw, ctx);
  else built = configBuildTable_(raw);

  if (!built.ok) {
    if (built.reason === "missing") return fail("targetMissing");
    if (built.reason === "notFound") return fail("notFoundTargetDataset", built.dataset, built.dataset);
    if (built.reason === "invalid") return fail("targetInvalid");
    return fail(built.field);
  }

  const tail = configBuildCommonTail_(raw, typePick.value);
  if (!tail.ok) return fail(tail.field);

  return Object.assign({ id, type: typePick.value, title, dataset: datasetName, size: tail.size, format: tail.format, note: tail.note }, built.extra);
}

/**
 * 設定を検査し、そろった形にする。raw がオブジェクトでなければ、空の部品を持つ既定の形と
 * 1 つの全体の誤りを返す。部品ごとの誤りは、その部品を { type: "error" } の札に置き換え、
 * 同じ文を errors にも入れる
 */
export function parseConfig(raw) {
  const lang = configErrorLang_(raw);

  if (!configIsPlainObject_(raw)) {
    const config = configDefault_();
    return { config, errors: [configTopError_(lang, "設定を読み取れませんでした", "The configuration could not be read.")] };
  }

  const errors = [];
  const config = configDefault_();
  config.title = textOf(raw.title);

  const langPick = configPickEnum_(raw, "lang", CONFIG_LANGS_, "ja");
  if (langPick.invalid) errors.push(configTopError_(lang, "lang（言語）の値が正しくありません", "lang is not valid."));
  config.lang = langPick.value;

  const themePick = configPickEnum_(raw, "theme", CONFIG_THEMES_, "auto");
  if (themePick.invalid) errors.push(configTopError_(lang, "theme（テーマ）の値が正しくありません", "theme is not valid."));
  config.theme = themePick.value;

  if (raw.cacheMinutes === undefined) {
    config.cacheMinutes = 5;
  } else {
    const minutes = configStrictNumber_(raw.cacheMinutes);
    if (minutes === null || minutes < 0 || minutes > 1440) {
      errors.push(configTopError_(lang, "cacheMinutes（更新の間隔）の値が正しくありません", "cacheMinutes is not valid."));
      config.cacheMinutes = 5;
    } else {
      config.cacheMinutes = minutes;
    }
  }

  const datasetsResult = configBuildDatasets_(raw, lang, errors);
  config.datasets = datasetsResult.datasets;
  const ctx = {
    datasets: datasetsResult.datasets,
    skipExistenceCheck: datasetsResult.skipExistenceCheck,
    datasetsBroken: datasetsResult.broken,
  };

  config.filters = configBuildFilters_(raw, lang, errors);

  if (!Array.isArray(raw.widgets) || raw.widgets.length === 0) {
    errors.push(configTopError_(lang, "部品を 1 つ以上設定してください", "Add at least one widget."));
    config.widgets = [];
  } else {
    config.widgets = raw.widgets.map((item, index) => configBuildWidget_(item, index, ctx, lang, errors));
  }

  return { config, errors };
}

// ---- configFromSheets ---------------------------------------------------

const CONFIG_SHEET_PERIODS_ = {
  今月: "thisMonth",
  先月: "lastMonth",
  直近7日: "last7",
  直近30日: "last30",
  直近90日: "last90",
  今年: "thisYear",
  全期間: "all",
  期間を指定: "custom",
};
const CONFIG_SHEET_LANGS_ = { 日本語: "ja", 英語: "en" };
const CONFIG_SHEET_THEMES_ = { 自動: "auto", 明るい: "light", 暗い: "dark" };
const CONFIG_SHEET_TYPES_ = { 数字: "kpi", 折れ線: "line", 棒: "bar", 目標: "meter", 表: "table" };
const CONFIG_SHEET_AGGS_ = { 合計: "sum", 平均: "avg", 件数: "count", 種類の数: "distinct", 最小: "min", 最大: "max" };
const CONFIG_SHEET_BUCKETS_ = { 自動: "auto", 日: "day", 週: "week", 月: "month", 四半期: "quarter", 年: "year" };
const CONFIG_SHEET_FORMATS_ = { 数値: "number", 円: "yen", ドル: "usd", 割合: "percent", パーセント: "percent" };
const CONFIG_SHEET_SIZES_ = { 小: "s", 中: "m", 大: "l" };
const CONFIG_SHEET_BAR_SORTS_ = { 値: "value", 名前: "label" };
/** 「比べる」（種類が 数字 のときだけ使う）。空欄は前の期間と比べる */
const CONFIG_SHEET_COMPARES_ = { なし: "none", 前の期間: "previous" };
/**
 * 「良し悪し」（種類が 数字 のときだけ使う）。空欄は「上がると良い」。
 * 解約数・返品額・経費のように、下がったほうが良い数のときに「下がると良い」と書く
 */
const CONFIG_SHEET_GOOD_WHENS_ = { 上がると良い: "up", 下がると良い: "down" };
/** 「明細」（種類が 表 のときだけ使う）。空欄はまとめた表、「最新」は新しい順に行をそのまま並べる表 */
const CONFIG_SHEET_TABLE_ROWS_ = { 最新: "latest" };

/**
 * `定義` シートの見出し。並びは問わず、知らない見出しは読み飛ばす（configSheetHeaderIndex_）。
 * 「比べる」「明細」は後から足した列なので、無くてもそれまでどおり読める。
 * - 種類: 数字 / 折れ線 / 棒 / 目標 / 表
 * - 集計: 合計 / 平均 / 件数 / 種類の数 / 最小 / 最大
 * - 刻み: 自動 / 日 / 週 / 月 / 四半期 / 年
 * - 書式: 数値 / 円 / ドル / 割合（表のときは「値の列」と同じ並びで、列ごとの書式）
 * - 目標: 数、または「シート名!列名」「シート名!列名!月の列」
 * - 大きさ: 小 / 中 / 大
 * - 並び: 棒は 値 / 名前、表は並べ替えに使う列の見出し
 * - 比べる: なし / 前の期間
 * - 良し悪し: 上がると良い / 下がると良い
 * - 明細: 最新
 */
export const CONFIG_DEFINITION_COLUMNS_ = [
  "種類",
  "題",
  "データ",
  "値の列",
  "集計",
  "区分の列",
  "分ける列",
  "日付の列",
  "刻み",
  "書式",
  "目標",
  "大きさ",
  "上位",
  "並び",
  "比べる",
  "良し悪し",
  "明細",
];

/**
 * シートの項目名・見出し・決まった言葉をくらべるための形。全角の英数字を半角にし、
 * 空白（全角も）をすべて除く（「開始 日」「値の列　」「直近 7 日」も、書き方どおりの名前と見なす）
 */
function configSheetKey_(value) {
  return toHalfWidth(textOf(value)).replace(/\s+/g, "");
}

/** 見出し行から、知っている列名の位置を調べる（見出しの並びは問わない。知らない列は無視する） */
function configSheetHeaderIndex_(headerRow, names) {
  const row = Array.isArray(headerRow) ? headerRow : [];
  const index = {};
  for (const name of names) {
    const at = row.findIndex((cell) => configSheetKey_(cell) === name);
    if (at !== -1) index[name] = at;
  }
  return index;
}

function configSheetCell_(row, index, name) {
  const at = index[name];
  return at === undefined ? "" : textOf(row[at]);
}

/** 日本語・英語どちらでも受ける、辞書引きの読み替え（辞書に無ければそのまま返し、parseConfig に判断させる） */
function configSheetMap_(text, dict) {
  if (text === "") return undefined;
  if (Object.prototype.hasOwnProperty.call(dict, text)) return dict[text];
  const key = configSheetKey_(text);
  return Object.prototype.hasOwnProperty.call(dict, key) ? dict[key] : text;
}

/**
 * `設定` の日付のマスを "YYYY-MM-DD" にする。日付として入力されたマスは Date で届くので、
 * まず日付として読み、読めなければ書かれた文字をそのまま渡す（誤りの判断は parseConfig に任せる）
 */
function configSheetDate_(cell) {
  const key = toDateKey(cell);
  return key !== "" ? key : textOf(cell);
}

/** 行がすべて空文字か */
function configSheetRowIsBlank_(cells) {
  return cells.every((cell) => cell === "");
}

/**
 * "目標" の 1 マスを、固定の数か目標の参照にする。
 * 参照は「シート名!列名」、月の列の名前が「月」でなければ「シート名!列名!月の列」と書く
 */
function configSheetParseTarget_(text) {
  if (text === "") return undefined;
  const asNumber = parseNumber(text);
  if (asNumber !== null) return asNumber;
  const parts = text.split("!").map((part) => part.trim());
  // 読めない形はそのまま渡し、parseConfig に誤りとして扱わせる
  if (parts.length < 2 || parts.length > 3 || parts.some((part) => part === "")) return text;
  return { dataset: parts[0], value: parts[1], agg: "sum", matchMonth: parts.length === 3 ? parts[2] : "月" };
}

/** 表の「値の列」の 1 つ。「列名」か「列名=見出し」（見出しを省いたら列名をそのまま見出しにする） */
function configSheetColumnAlias_(text) {
  const at = text.indexOf("=");
  if (at === -1) return { value: text, label: text };
  const value = text.slice(0, at).trim();
  const label = text.slice(at + 1).trim();
  return { value, label: label === "" ? value : label };
}

/** 表の「値の列」から、列ごとの定義を組み立てる（書式は「書式」の同じ並びの値） */
function configSheetTableColumns_(valueText, formatText, agg) {
  const formats = configSplitColumnList_(formatText).map((text) => configSheetMap_(text, CONFIG_SHEET_FORMATS_));
  return configSplitColumnList_(valueText).map((entry, at) => {
    const alias = configSheetColumnAlias_(entry);
    const column = { value: alias.value, agg: agg || "sum", label: alias.label };
    if (formats[at] !== undefined) column.format = formats[at];
    return column;
  });
}

/**
 * `設定`・`定義` シート（見出し行を含む 2 次元配列）を、parseConfig に渡せる raw の形にする。
 * 検査はしない（parseConfig の 1 か所だけで行う）
 */
export function configFromSheets(settingsRows, definitionRows) {
  const raw = { source: "sheets", filters: {}, datasets: {}, widgets: [] };

  const settings = Array.isArray(settingsRows) ? settingsRows.slice(1) : [];
  for (const row of settings) {
    const cells = Array.isArray(row) ? row : [];
    const item = configSheetKey_(cells[0]);
    const value = textOf(cells[1]);
    if (item === "") continue;
    if (item === "題名") raw.title = value;
    else if (item === "言語") raw.lang = configSheetMap_(value, CONFIG_SHEET_LANGS_);
    else if (item === "テーマ") raw.theme = configSheetMap_(value, CONFIG_SHEET_THEMES_);
    else if (item === "期間") raw.filters.period = configSheetMap_(value, CONFIG_SHEET_PERIODS_);
    else if (item === "開始日") raw.filters.from = configSheetDate_(cells[1]);
    else if (item === "終了日") raw.filters.to = configSheetDate_(cells[1]);
    else if (item === "絞り込みの列") raw.filters.dimensions = configSplitColumnList_(value);
  }

  const definitionGrid = Array.isArray(definitionRows) ? definitionRows : [];
  const headerRow = definitionGrid[0];
  const index = configSheetHeaderIndex_(headerRow, CONFIG_DEFINITION_COLUMNS_);
  const datasetDateColumns = {};

  const widgetRows = [];
  for (let r = 1; r < definitionGrid.length; r += 1) {
    const row = Array.isArray(definitionGrid[r]) ? definitionGrid[r] : [];
    const cells = {};
    for (const name of CONFIG_DEFINITION_COLUMNS_) cells[name] = configSheetCell_(row, index, name);
    if (configSheetRowIsBlank_(Object.values(cells))) continue;

    const datasetName = cells["データ"];
    if (datasetName !== "" && cells["日付の列"] !== "" && configOwn_(datasetDateColumns, datasetName) === undefined) {
      configSetOwn_(datasetDateColumns, datasetName, cells["日付の列"]);
    }
    widgetRows.push(cells);
  }

  // データセット名はシートの見出しやセルの値（利用者が自由に書ける文字）なので、
  // "__proto__" のような名前が来ても入れ物のプロトタイプを書き換えないよう configSetOwn_ を使う。
  // 使える名前かどうかの判断は、この先の parseConfig の 1 か所だけで行う
  for (const key of Object.keys(datasetDateColumns)) {
    configSetOwn_(raw.datasets, key, { url: "", dateColumn: configOwn_(datasetDateColumns, key) });
  }
  for (const cells of widgetRows) {
    const datasetName = cells["データ"];
    if (datasetName !== "" && configOwn_(raw.datasets, datasetName) === undefined) {
      configSetOwn_(raw.datasets, datasetName, { url: "", dateColumn: "" });
    }
  }

  for (const cells of widgetRows) {
    const type = configSheetMap_(cells["種類"], CONFIG_SHEET_TYPES_);
    const widget = { type, title: cells["題"], dataset: cells["データ"] };

    const agg = configSheetMap_(cells["集計"], CONFIG_SHEET_AGGS_);
    if (agg !== undefined && type !== "table") widget.agg = agg; // 表は列ごとに agg を持つので、部品自体には要らない

    if (type === "table") {
      const rows = configSheetMap_(cells["明細"], CONFIG_SHEET_TABLE_ROWS_);
      if (rows !== undefined) widget.rows = rows;
      if (cells["値の列"] !== "") {
        // 明細の表は行をそのまま並べるので、列は名前だけ（まとめる表は列ごとに集計・見出し・書式を持つ）
        widget.columns =
          widget.rows === "latest"
            ? configSplitColumnList_(cells["値の列"]).map((entry) => configSheetColumnAlias_(entry).value)
            : configSheetTableColumns_(cells["値の列"], cells["書式"], agg);
      }
      if (cells["区分の列"] !== "") widget.groupBy = cells["区分の列"];
      if (cells["並び"] !== "" && widget.rows !== "latest") widget.sort = cells["並び"];
    } else {
      if (cells["値の列"] !== "") widget.value = cells["値の列"];
      if (cells["区分の列"] !== "" && type === "bar") widget.category = cells["区分の列"];
      if (cells["並び"] !== "" && type === "bar") widget.sort = configSheetMap_(cells["並び"], CONFIG_SHEET_BAR_SORTS_);
      const format = configSheetMap_(cells["書式"], CONFIG_SHEET_FORMATS_);
      if (format !== undefined) widget.format = format;
      if (type === "kpi") {
        const compare = configSheetMap_(cells["比べる"], CONFIG_SHEET_COMPARES_);
        if (compare !== undefined) widget.compare = compare;
        const goodWhen = configSheetMap_(cells["良し悪し"], CONFIG_SHEET_GOOD_WHENS_);
        if (goodWhen !== undefined) widget.goodWhen = goodWhen;
      }
    }

    if (cells["分ける列"] !== "") widget.splitBy = cells["分ける列"];
    if (cells["日付の列"] !== "") widget.dateColumn = cells["日付の列"];
    const bucket = configSheetMap_(cells["刻み"], CONFIG_SHEET_BUCKETS_);
    if (bucket !== undefined) widget.bucket = bucket;
    const target = configSheetParseTarget_(cells["目標"]);
    if (target !== undefined) {
      widget.target = target;
      // 目標の参照先（例: "targets!目標額"）のシートは、どの部品も データ に使っていなくても
      // データセットとして登録しておく（存在の確認はサーバーが読み込み時に行う）
      if (configIsPlainObject_(target) && target.dataset && configOwn_(raw.datasets, target.dataset) === undefined) {
        configSetOwn_(raw.datasets, target.dataset, { url: "", dateColumn: "" });
      }
    }
    const size = configSheetMap_(cells["大きさ"], CONFIG_SHEET_SIZES_);
    if (size !== undefined) widget.size = size;
    if (cells["上位"] !== "") {
      const top = parseNumber(cells["上位"]);
      widget.top = top === null ? cells["上位"] : top;
    }

    raw.widgets.push(widget);
  }

  return raw;
}

// ---- configSheetNotes ----------------------------------------------------

/** `設定` シートの「言語」から、ご参考の文の言語を決める（無ければ日本語） */
function configSheetNotesLang_(settingsRows) {
  const settings = Array.isArray(settingsRows) ? settingsRows.slice(1) : [];
  for (const row of settings) {
    const cells = Array.isArray(row) ? row : [];
    if (configSheetKey_(cells[0]) === "言語") return configSheetMap_(textOf(cells[1]), CONFIG_SHEET_LANGS_) === "en" ? "en" : "ja";
  }
  return "ja";
}

/**
 * `設定`・`定義` シートだけで気づける、誤りではないけれど添えておきたい一言を集める（純粋な検査）。
 * いまのところは 1 つだけ: 明細（最新の行をそのまま並べる表）に並びを書いても、使われずに無視される。
 * parseConfig の誤り（errors）とは別の並びで返し、menu_check がそのまま「ご参考」として添える
 */
export function configSheetNotes(settingsRows, definitionRows) {
  const lang = configSheetNotesLang_(settingsRows);
  const notes = [];

  const definitionGrid = Array.isArray(definitionRows) ? definitionRows : [];
  const headerRow = definitionGrid[0];
  const index = configSheetHeaderIndex_(headerRow, CONFIG_DEFINITION_COLUMNS_);

  for (let r = 1; r < definitionGrid.length; r += 1) {
    const row = Array.isArray(definitionGrid[r]) ? definitionGrid[r] : [];
    const cells = {};
    for (const name of CONFIG_DEFINITION_COLUMNS_) cells[name] = configSheetCell_(row, index, name);
    if (configSheetRowIsBlank_(Object.values(cells))) continue;

    const type = configSheetMap_(cells["種類"], CONFIG_SHEET_TYPES_);
    const rows = configSheetMap_(cells["明細"], CONFIG_SHEET_TABLE_ROWS_);
    if (type !== "table" || rows !== "latest" || cells["並び"] === "") continue;

    const title = cells["題"];
    notes.push(
      lang === "en"
        ? 'The table "' + title + '" shows the latest rows as they are, so "Sort" is not used.'
        : "「" + title + "」は最新の明細を出す表なので、「並び」は使われません。"
    );
  }

  return notes;
}
