# 利用許諾（ダッシュボード キット）

発行者: suminawa（hello@suminawa.dev）　対象: 本 zip に含まれるすべてのファイル　版: 1.0（2026-09-27）

1. 個人ライセンス: 購入者本人が、自分の業務・自分の案件で、数に制限なく使えます。
2. 組織ライセンス: 購入した組織（法人・チーム）が、その組織の業務で使えます。個人ライセンスで購入した場合、所属組織の他のメンバーへの配布はできません。
3. 改変: 自由です。改変したものを自分の業務で使うことも、クライアントのウェブサイト・アプリケーション・スプレッドシートに組み込んで納品することもできます。納品できるのは、組み込んだ成果物（`dist/` のファイルと、お書きになった設定など）です。この zip そのものや `src/`・`templates/` 一式をお渡しになることはできません。
4. 禁止: 本ファイル一式（改変の有無を問わず）の再配布・転売・共有、テンプレートやパック商品としての再販、同種の商品として販売すること。
5. 保証と責任: 現状有姿で提供します。発行者の故意または重大な過失による場合を除き、本ソフトウェアに関する損害賠償の責任は購入代金を上限とします。集計結果の誤り、データの取得の失敗、通信の途絶によって生じた結果について、発行者は責任を負いません。表示された数値にもとづく判断は、お客さまご自身の責任で行ってください。
6. サポート: 購入後 14 日間、不具合のご連絡にメールで対応します（3 営業日以内に返信）。
7. 更新: 1.x のあいだの更新は無料です。
8. 返金: デジタル商品の性質上、ダウンロード後の返金はできません。不具合のご連絡には、第 6 項のとおり購入後 14 日間、3 営業日以内に返信いたします。
9. 準拠法: 日本法。紛争が生じたときは、発行者の所在地を管轄する裁判所を第一審の専属的合意管轄とします。

購入日をもって本許諾に同意したものとします。

本許諾には、下に英訳を添えています。日本語と英語の内容に食い違いがあるときは、日本語を優先します。

---

# Licence (Dashboard Kit)

Publisher: suminawa (hello@suminawa.dev)　Covers: every file in this zip　Version: 1.0 (2026-09-27)

1. Personal licence: the purchaser may use the kit in their own work and their own client projects, with no limit on the number of projects.
2. Organisation licence: the organisation (company or team) that bought the kit may use it for that organisation's work. A personal licence does not extend to other members of the purchaser's organisation.
3. Modification: permitted without restriction. You may use modified versions in your own work, and you may deliver them as part of a client's website, application or spreadsheet. What you deliver is the result you built with the kit — the `dist/` files and the configuration you wrote — not this zip itself, nor `src/` or `templates/` as a set.
4. Not permitted: redistributing, reselling or sharing the package as a whole (modified or not); reselling it as a template or in a bundle; selling it as a competing product.
5. Warranty and liability: provided as is. Except in cases of wilful misconduct or gross negligence by the publisher, liability for any damages relating to this software is limited to the purchase price. The publisher is not liable for consequences arising from incorrect aggregates, failed data fetches or loss of connectivity. Decisions based on the figures shown are your own responsibility.
6. Support: defect reports are handled by email for 14 days after purchase, with a reply within three business days.
7. Updates: updates within 1.x are free.
8. Refunds: as a digital product, it cannot be refunded once downloaded. Defect reports are answered as set out in clause 6: within three business days, for 14 days after purchase.
9. Governing law: the laws of Japan. Any dispute shall be submitted to the exclusive jurisdiction of the court of first instance having jurisdiction over the publisher's place of business.

Purchase constitutes acceptance of these terms.

**In the event of any discrepancy between the Japanese text above and this English translation, the Japanese text prevails.**
