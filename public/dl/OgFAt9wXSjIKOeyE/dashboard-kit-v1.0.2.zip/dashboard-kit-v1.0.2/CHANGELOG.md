# 更新履歴

## 1.0.2 — 2026-10-22

Next.js のテンプレが使う Next.js と React を、セキュリティ修正版より下に落ちないようにしました。1.0.x をお求めの方は無料で更新いただけます。

更新のしかた: Next.js テンプレをお使いの方は、`package.json` の `next`・`react`・`react-dom` の 3 行を 1.0.2 のもの（`^15.5.28`・`^19.2.9`・`^19.2.9`）に合わせ、`npm install` を実行してからデプロイし直してください。埋め込みとスプレッドシート版は、版の表示（`Dashboard.version`）のほかは 1.0.1 と同じ動きですので、差し替えなくてもお使いいただけます。
(Security update for the Next.js template: `next`, `react` and `react-dom` now require at least the patched releases (`^15.5.28`, `^19.2.9`, `^19.2.9`). Free update for 1.0.x owners: set those three lines in your template's `package.json`, run `npm install` and redeploy. The embed and Sheets editions behave as in 1.0.1 apart from `Dashboard.version`, so replacing them is optional.)

- Next.js テンプレの `package.json` で、Next.js を 15.5.28 以上、React を 19.2.9 以上に決めました。2026-10-14 に公表された Next.js と React（サーバーで描く部品）の脆弱性の直った版です。以前に `npm install` した手元の環境でも、新しい `package.json` で入れ直すと直った版に上がります。機能の変更はありません
  (The Next.js template now requires Next.js 15.5.28 or later and React 19.2.9 or later, the releases that fix the Next.js and React Server Components vulnerabilities published on 2026-10-14. Reinstalling with the new `package.json` upgrades an existing install. No functional changes)

## 1.0.1 — 2026-10-20

ご自分のデータを入れたときに、読めない値が黙って 0 になったり、「今月」が 0 件になったりする点を直しました。あわせて、スマホの幅での見え方と、色の読みやすさを直しています。1.0.0 をお求めの方は無料で更新いただけます。

更新のしかた: 埋め込みは `dist/dashboard.js` と `dist/dashboard.css` を、Next.js テンプレは `vendor/dashboard.mjs` と `vendor/dashboard.css` を差し替えてください。スプレッドシート版は `Code.gs` と `App.html` の中身を貼り直し、「デプロイ」→「デプロイを管理」→ 鉛筆 →「新バージョン」でデプロイし直してください（承認し直す必要はありません）。
(Fixes for real-world data: unreadable values and form timestamps no longer turn totals or "This month" into zero without a word. Also fixes the phone layout and colour contrast. Free update for 1.0.0 owners: replace the two files in `dist/` (or `vendor/` in the Next.js template); for the Sheets edition, paste `Code.gs` and `App.html` again and deploy a new version.)

- 合計・平均・最小・最大に使う列は、いつも数の列として読むようにしました。これまでは金額の列に「-」のような数でない値が 1 割を超えて混ざると、列ぜんたいが文字の列になり、KPI が 0 になっていました。読めない値はのぞいて計算し、のぞいた件数を札の下にお知らせします
  (Columns used for sum, avg, min and max are always read as numbers. A few "-" cells no longer make the total zero; skipped values are counted under the card)
- Google フォームの回答のタイムスタンプ（`2026/09/19 10:00:00` のように、日付の後ろに時刻が付いた形）を、日付として読むようにしました。これまでは CSV で公開したフォームの回答を埋め込むと、「今月」が 0 件になっていました
  (Dates followed by a time, such as Google Forms timestamps, are now read as dates)
- 日付の列に日付として読めない値があるときは、部品の上に赤い帯で件数と例をお知らせします。その行は期間の絞り込みに入りません
  (A red banner reports how many values in the date column cannot be read, with an example)
- データを取り込めなかったときは、理由を部品に赤字で出し、ブラウザの console にも残します（サーバーの返事の番号、返事が届かない（CORS など）、中身を行として読めない、url が使えない形）。これまではどの場合も「データが見つかりません」の一文でした
  (When a dataset cannot be loaded, the card now says why — HTTP status, unreachable/CORS, unreadable body, or a bad url — and the reason is logged to the console)
- 設定に知らない項目名があるときは、近い名前を添えてお知らせします（「`dateColum` は知らない項目です。`dateColumn` のことですか」）。これまでは黙って読み飛ばしていました。`_` で始まる名前はメモとして読み飛ばします
  (Unknown setting names are reported with a suggestion instead of being ignored. Names starting with "_" are treated as notes)
- KPI の数字は、縮めずに 7 字に収まるときはそのまま出すようにしました（平均の注文額のような数が「1万」に丸められず、「10,226」と出ます）
  (KPI values that fit in seven characters are shown in full, e.g. 10,226 instead of 1万)
- 幅 560px 以下の画面で、小さな札の「表で見る」を題の横から札の下へ移し、題が 1〜2 字ずつ折れないようにしました。KPI の数字は画面の幅に合わせて 1 行に収めます
  (On narrow screens the "View as table" button of small cards moves below the content, so titles no longer break every character or two)
- 横にはみ出す表に、続きがあることを示す影を付け、キーボードでも横に送れるようにしました
  (Tables that overflow sideways show an edge shadow and can be scrolled with the keyboard)
- 増えたときの緑（▲）を濃くし、白い地に対して読みやすさの基準（4.5:1）を満たすようにしました。暗い配色では、減ったときの赤（▼）を明るくしています。部品の誤りの一文も赤字にしました
  (The up-arrow green now meets the 4.5:1 contrast ratio, the dark-theme red is lighter, and widget error lines are red)
- 説明書に、Google スプレッドシートを「ウェブに公開」して埋め込みで使う手順と、絞り込みの値が URL に入ることへの注意を足しました
  (The manuals explain how to publish a Google Sheet as CSV for embedding, and note that filter values appear in the URL)
- ES モジュール版の型（`dist/dashboard.d.mts`）を `dist/` にも入れました
  (Type declarations for the ES module now ship in `dist/` as well)
- 検査は 736 件になりました
  (736 tests)

## 1.0.0 — 発売前の見直し（2026-09-23）

版は 1.0.0 のままです。スプレッドシート版を、検査用の偽の Apps Script を本物の癖に寄せて見直しました（`test/helpers/gas-fakes.mjs`。書いた文字の数や日付への読み替え・マニフェストに無い許可・画面から呼ばれたときの `getUi()`・公開の設定による実行者の違い・`google.script.run` が Date を運べないこと）。見つかった点はキットの側で直しています。
(Pre-release review of the Sheets edition. The test fakes now behave like the real Apps Script, and every gap they found was fixed in the kit.)

- 「次のユーザーとして実行」が「自分」で公開されていると、URL を知っている方ならどなたでも持ち主の権限で数字を見られてしまうため、開いた方と実行している方が違うときは数字を出さずに止めます。そのために許可 `userinfo.email` を 1 つ足しました（アドレスは確かめるだけで、書き込みも送信もしません）
  (A deployment set to "Execute as: Me" is now refused instead of showing the owner's numbers to anyone with the link. Adds the `userinfo.email` scope for this check)
- 「見本を入れる」で `設定` の「開始日」「終了日」の行が消えていたのを直しました。見本でも全項目と書き方の列を並べます。「初期化」は、すでにある `設定` に足りない項目の行だけを書き足します
  (Insert sample data no longer drops the start/end date rows; Initialise appends missing setting rows)
- `設定`・`定義` のセルを書式なしテキストにして、`10/1` や `001` が日付や数に読み替えられないようにしました
  (The config sheets are written as plain text, so values are not turned into dates or numbers)
- `設定` の開始日・終了日を日付のセルで書いたとき、スプレッドシートの時間帯で読むようにしました（時間帯によっては 1 日ずれていました）
  (Date cells in the settings are read in the spreadsheet's time zone, fixing a one-day shift)
- 項目名・見出し・決まった言葉に空白（全角も）が混ざっていても読みます（「開始　日」「値 の列」「期間を 指定」など）
  (Stray spaces in item names, headings and keywords are ignored)
- メニューの処理をウェブアプリの画面から呼ばれても、シートに書き込む前に止まるようにしました
  (Menu functions invoked from the web app stop before touching any sheet)
- 説明書に、公開の設定を選ぶ理由と、間違えたときの直し方（デプロイを管理 → 鉛筆 → 新バージョン）、CSV の取り込み方を足しました
  (The manuals explain the deployment settings, how to fix a wrong deployment, and how to import a CSV)
- 検査は 722 件になりました
  (722 tests)

## 1.0.0 — 2026-09-23

初版。

- CSV・JSON・Google スプレッドシートの行を、設定 1 つで KPI・折れ線・棒・目標・表の 1 画面にします
  (Turns CSV, JSON or Google Sheets rows into one screen of KPI, line, bar, meter and table widgets from a single config)
- 3 つの置き方を同じ 1 本で動かします。埋め込み（`dist/dashboard.js` と `dist/dashboard.css`）、Next.js テンプレ（`templates/nextjs/`）、Google スプレッドシート（`dist/Code.gs`・`App.html`・`appsscript.json`）
  (Three ways to run the same bundle: an embeddable script, a Next.js App Router template, and a Google Apps Script web app)
- スプレッドシート版は `設定`・`定義` の 2 枚だけで書けます。「良し悪し」で下がると良い数にも対応し、「開始日」「終了日」で期間も指定できます
  (The Sheets edition is configured from two sheets, including a good/bad direction column and a custom date range)
- 画面の上の絞り込みは 1 行だけです。期間（今月・先月・直近 7/30/90 日・今年・全期間・期間の指定）と、列ごとの絞り込みが 3 つまで。下の部品がすべて同時に変わります
  (One filter row: period presets plus up to three column filters, all widgets updating together)
- 絞り込みの状態は URL の `#db.…` に入り、同じ URL を開くと同じ画面になります。ページに別の目印があるときは書き込みません
  (Filter state is shared through the URL hash, and never overwrites a page's own anchor)
- どのグラフにも「表で見る」の切り替えと CSV の書き出しがあります。どの値も、吹き出しを開かずに読めます
  (Every chart has a table view and a CSV export, so every value can be read without a tooltip)
- マウス・指・キーボードの focus で同じ吹き出しが出ます。動きを控える設定と、印刷の体裁にも合わせます
  (The same tooltip for mouse, touch and keyboard focus; reduced motion and print are handled)
- 日本語と英語（画面の固定の文と README の 2 冊）。明るい配色・暗い配色は OS に合わせるか、指定できます
  (Japanese and English UI strings and manuals; light and dark themes)
- 区分の色は 8 色の決まった並びで、9 個目は「その他」にまとめます。色の割り当ては絞り込みで変わりません
  (A fixed eight-colour categorical palette; assignments never change when filtering)
- 日付は暦の日付の文字で扱い、時差で 1 日ずれません。`9/19/2026` のような月が先の形は、読み取らずにお知らせします
  (Dates are handled as calendar strings, so they never shift by a day; month-first dates are rejected rather than guessed)
- 1 つのデータにつき 20,000 行まで。超えた分は使わず、画面の下にその旨を出します
  (Up to 20,000 rows per dataset, with a notice when the limit is reached)
- 依存パッケージなし。706 件の検査つき（`npm test`）
  (No dependencies; 706 tests)
- 見本のお店「しおかぜ珈琲店」（架空）の 6 か月ぶんのデータと、ブラウザだけで動く見本ページ
  (Six months of sample data for a fictional shop, Shiokaze Coffee, and a demo page that runs from the file system)
- zip の中身: `dist/`・`demo/`・`samples/`・`templates/nextjs/`・`src/`・`test/`・`scripts/`・`package.json`・`README.ja.md`・`README.en.md`・`LICENSE.md`・`CHANGELOG.md`
  (In the zip: the built files, the demo page, the samples, the Next.js template, the source and its tests, and the four documents)
