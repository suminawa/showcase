/**
 * Gmail の検索・本文の取り出し・下書き・ラベル。GmailMessage から素の値を取り出して mail.js に渡す。
 */
import { buildInput, parseFrom } from "./mail.js";

export const LABEL_DONE = "AI整理済";
export const LABEL_SKIPPED = "AI整理対象外";
export const LABEL_ATTENTION = "AI要対応";
export const LABEL_PREFIX = "AI_";

/** 自分のアドレスが読めなかったときに実行ログへ残す 1 行（黙って守りが外れるのを防ぐ） */
const NO_OWN_ADDRESS_LOG = "問い合わせ整理: 自分のアドレスを読めなかったので、自分からのメールを除く守りが効きません。承認をやり直すと直ります";

function emailOf_(user) {
  try {
    const email = user().getEmail();
    return email ? String(email).trim().toLowerCase() : "";
  } catch (error) {
    return "";
  }
}

/**
 * GmailApp が読む Gmail の持ち主（= スクリプトを実行しているアカウント）のアドレス。読めなければ空。
 * getActiveUser() はトリガーからの実行などで空になることがあるので、getEffectiveUser() を先に見る。
 */
export function ownAddress_() {
  let address = emailOf_(function () {
    return Session.getEffectiveUser();
  });
  if (address === "") {
    address = emailOf_(function () {
      return Session.getActiveUser();
    });
  }
  if (address === "") Logger.log(NO_OWN_ADDRESS_LOG);
  return address;
}

export function searchThreads_(query, max) {
  return GmailApp.search(query, 0, max);
}

/** スレッドの最後の、自分以外からのメッセージ。無ければ null */
export function latestInboundMessage_(thread, ownAddress) {
  const messages = thread.getMessages();
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const message = messages[i];
    if (message.isDraft()) continue;
    const from = parseFrom(message.getFrom()).address.toLowerCase();
    if (ownAddress !== "" && from === ownAddress) continue;
    return message;
  }
  return null;
}

/** 配信メールの見分けに使うヘッダー。無ければ "" */
export function headersOf_(message) {
  return {
    listUnsubscribe: message.getHeader("List-Unsubscribe"),
    precedence: message.getHeader("Precedence"),
    autoSubmitted: message.getHeader("Auto-Submitted"),
  };
}

export function messageInput_(message, config) {
  // 既定ではインライン画像（署名の画像など）も「添付」に入ってしまうので外す
  const attachments = message.getAttachments({ includeInlineImages: false });
  const names = [];
  for (let i = 0; i < attachments.length; i += 1) names.push(attachments[i].getName());
  return buildInput(
    {
      from: message.getFrom(),
      subject: message.getSubject(),
      date: message.getDate(),
      plainBody: message.getPlainBody(),
      htmlBody: message.getBody(),
      attachmentNames: names,
    },
    config,
  );
}

/** 返信の下書きを、そのメッセージへの返信として作る（送らない） */
export function createDraft_(message, body) {
  message.createDraftReply(body);
}

function labelOf_(name) {
  const found = GmailApp.getUserLabelByName(name);
  return found ? found : GmailApp.createLabel(name);
}

export function labelThread_(thread, names) {
  for (let i = 0; i < names.length; i += 1) thread.addLabel(labelOf_(names[i]));
}
