/** スプレッドシートから設定を読み、「問い合わせ」シートに書く。 */
import { ConfigError, parseConfig } from "./config.js";

export const SETTINGS_SHEET = "設定";
export const INQUIRY_SHEET = "問い合わせ";

function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

export function readConfig_() {
  const book = book_();
  const timeZone = book.getSpreadsheetTimeZone();
  if (timeZone !== "Asia/Tokyo") {
    throw new ConfigError(
      "スプレッドシートのタイムゾーンが " + timeZone + " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと受信日時が 1 日ずれます）。",
    );
  }
  const sheet = book.getSheetByName(SETTINGS_SHEET);
  if (!sheet) throw new ConfigError("「設定」シートがありません。README.ja.md の手順 1 を見てください。");
  return parseConfig(sheet.getDataRange().getValues());
}

/**
 * 設定が壊れていてもエラーだけは届くように、通知先の行だけを検証せずに読む。
 * 返り値は notifyAll_ に渡せる形。読めなければ null。
 */
export function readRawTargets_() {
  try {
    const sheet = book_().getSheetByName(SETTINGS_SHEET);
    if (!sheet) return null;
    const rows = sheet.getDataRange().getValues();
    const found = { targets: [], slackWebhookUrl: "", discordWebhookUrl: "", lineToken: "", lineTo: "" };
    const known = ["slack", "discord", "line"];
    for (let i = 0; i < rows.length; i += 1) {
      const key = String(rows[i][0]).replace(/\s+/g, "").toLowerCase();
      const value = String(rows[i][1] === null || rows[i][1] === undefined ? "" : rows[i][1]).trim();
      if (key === "通知先") {
        const parts = value.toLowerCase().split(/[,、]/);
        for (let j = 0; j < parts.length; j += 1) {
          const name = parts[j].trim();
          if (known.indexOf(name) >= 0 && found.targets.indexOf(name) < 0) found.targets.push(name);
        }
      }
      if (key === "slackwebhookurl") found.slackWebhookUrl = value;
      if (key === "discordwebhookurl") found.discordWebhookUrl = value;
      if (key === "lineチャネルアクセストークン") found.lineToken = value;
      if (key === "line送信先id") found.lineTo = value;
    }
    return found.targets.length === 0 ? null : found;
  } catch (error) {
    return null;
  }
}

/** 問い合わせシート。無ければ作る */
function inquirySheet_() {
  const book = book_();
  const sheet = book.getSheetByName(INQUIRY_SHEET);
  return sheet ? sheet : book.insertSheet(INQUIRY_SHEET);
}

/** 1 行目。シートが無いか空なら [] */
export function readHeader_() {
  const sheet = book_().getSheetByName(INQUIRY_SHEET);
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
}

/** 通知に載せる、その行を開くリンク（スプレッドシートの URL + シートと行の指定） */
export function rowUrl_(rowNumber) {
  return book_().getUrl() + "#gid=" + inquirySheet_().getSheetId() + "&range=A" + rowNumber;
}

/** 末尾に 1 行足し、その行番号を返す。見出しはシートが空のとき、または列を足したときだけ書き直す */
export function appendInquiryRow_(header, row, writeHeader) {
  const sheet = inquirySheet_();
  if (header.length > sheet.getMaxColumns()) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), header.length - sheet.getMaxColumns());
  }
  if (sheet.getLastRow() === 0 || writeHeader === true) {
    sheet.getRange(1, 1, 1, header.length).setValues([header]);
  }
  sheet.appendRow(row);
  return sheet.getLastRow();
}
