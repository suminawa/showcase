/**
 * Messages API を UrlFetchApp で呼ぶ。429 / 5xx / 529 は 2 秒待って 1 回だけやり直す。
 * 鍵はここに渡ってくるだけで、ログにもエラー文にも出さない。
 */
import { ANTHROPIC_VERSION, MESSAGES_URL } from "./prompt.js";

const RETRY_WAIT_MS = 2000;
const RETRYABLE = [408, 409, 429, 500, 502, 503, 504, 529];

export class ClaudeError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ClaudeError";
    this.status = status;
  }
}

export function isRetryable_(status) {
  return RETRYABLE.indexOf(status) >= 0;
}

function messageFor_(status) {
  if (status === 401) return "API キーが受け付けられませんでした。スクリプト プロパティの ANTHROPIC_API_KEY を確かめてください。";
  if (status === 403) return "この API キーでは使えない機能です。Anthropic Console の設定を確かめてください。";
  if (status === 400 || status === 404) return "リクエストが受け付けられませんでした（" + status + "）。「モデル」の設定を確かめてください。";
  if (status === 429) return "API の回数の上限に当たりました（429）。しばらくして自動でやり直します。";
  if (isRetryable_(status)) return "API から " + status + " が返りました。しばらくして自動でやり直します。";
  return "API から " + status + " が返りました。「モデル」の設定と Anthropic Console の状態を確かめてください。";
}

function fetch_(apiKey, body) {
  return UrlFetchApp.fetch(MESSAGES_URL, {
    method: "post",
    contentType: "application/json",
    headers: { "x-api-key": apiKey, "anthropic-version": ANTHROPIC_VERSION },
    payload: JSON.stringify(body),
    muteHttpExceptions: true,
  });
}

/** 返り値 { text, usage, stopReason }。text は最初の text ブロック（無ければ ""） */
export function callClaude_(apiKey, body) {
  let response = fetch_(apiKey, body);
  let status = response.getResponseCode();
  if (isRetryable_(status)) {
    Utilities.sleep(RETRY_WAIT_MS);
    response = fetch_(apiKey, body);
    status = response.getResponseCode();
  }
  if (status < 200 || status >= 300) throw new ClaudeError(messageFor_(status), status);
  let json;
  try {
    json = JSON.parse(response.getContentText());
  } catch (error) {
    // 2xx なのに JSON でない（途中の proxy の応答など）。次回にやり直す扱いにする
    throw new ClaudeError("API の応答を読み取れませんでした。しばらくして自動でやり直します。", 502);
  }
  if (json === null || typeof json !== "object") {
    throw new ClaudeError("API の応答を読み取れませんでした。しばらくして自動でやり直します。", 502);
  }
  let text = "";
  const content = Array.isArray(json.content) ? json.content : [];
  for (let i = 0; i < content.length; i += 1) {
    if (content[i].type === "text") {
      text = String(content[i].text);
      break;
    }
  }
  return { text: text, usage: json.usage ? json.usage : null, stopReason: json.stop_reason ? String(json.stop_reason) : "" };
}
