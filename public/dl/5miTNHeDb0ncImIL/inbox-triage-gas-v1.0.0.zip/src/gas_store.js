/**
 * スクリプト プロパティに置く覚え書き: API キー・受付番号の続き・1 日の件数・今月のトークン数。
 * メールの中身は何も残さない。
 */
import { emptyUsage } from "./usage.js";

/** 同時に走った実行を待たせる時間（トリガーとメニューが重なったとき） */
const LOCK_WAIT_MS = 30000;
const API_KEY_PROPERTY = "ANTHROPIC_API_KEY";
const LAST_RECEIPT_KEY = "lastReceipt";
const LAST_ERROR_NOTICE_KEY = "lastErrorNotice";
/** Gmail を整理するアカウント（最初に整理した人か、トリガーを入れた人）。消すと、次に動かした人が持ち主になる */
const OWNER_KEY = "owner";

function props_() {
  return PropertiesService.getScriptProperties();
}

/**
 * action を 1 つずつ順番に実行する（受付番号と 1 日の件数が重ならないように）。
 * 待っても取れなければ { busy: true } を返す。トリガーとメニューが重なるのは平常運転なので、
 * ぶつかった側は何もしないのが正しい（waitLock は tryLock と違って例外を投げる）。
 */
export function withLock_(action) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(LOCK_WAIT_MS);
  } catch (error) {
    Logger.log("問い合わせ整理: ほかの整理が動いているため、今回は何もしません");
    return { busy: true };
  }
  try {
    return action();
  } finally {
    lock.releaseLock();
  }
}

/** 同じエラーを 1 日に何通も送らないための覚え書き（「日付 + エラー文の先頭」） */
export function readLastErrorNotice_() {
  const raw = props_().getProperty(LAST_ERROR_NOTICE_KEY);
  return raw ? String(raw) : "";
}

export function saveLastErrorNotice_(notice) {
  props_().setProperty(LAST_ERROR_NOTICE_KEY, String(notice));
}

export function readOwner_() {
  const raw = props_().getProperty(OWNER_KEY);
  return raw ? String(raw).trim().toLowerCase() : "";
}

export function saveOwner_(address) {
  props_().setProperty(OWNER_KEY, String(address).trim().toLowerCase());
}

/** 鍵はここからだけ読む。無ければ空 */
export function readApiKey_() {
  const raw = props_().getProperty(API_KEY_PROPERTY);
  return raw ? String(raw).trim() : "";
}

export function readLastReceipt_() {
  const raw = props_().getProperty(LAST_RECEIPT_KEY);
  return raw ? String(raw) : "";
}

export function saveLastReceipt_(receipt) {
  props_().setProperty(LAST_RECEIPT_KEY, String(receipt));
}

export function readDailyCount_(dateKey) {
  const raw = props_().getProperty("count:" + dateKey);
  const number = Number(raw);
  return Number.isFinite(number) ? number : 0;
}

export function saveDailyCount_(dateKey, count) {
  props_().setProperty("count:" + dateKey, String(count));
}

export function readMonthUsage_(monthKey) {
  const raw = props_().getProperty("usage:" + monthKey);
  if (!raw) return emptyUsage();
  try {
    const parsed = JSON.parse(raw);
    const base = emptyUsage();
    for (const key in base) {
      if (Object.prototype.hasOwnProperty.call(parsed, key)) base[key] = Number(parsed[key]) || 0;
    }
    return base;
  } catch (error) {
    return emptyUsage();
  }
}

export function saveMonthUsage_(monthKey, total) {
  props_().setProperty("usage:" + monthKey, JSON.stringify(total));
}
