/**
 * 入口。トリガーが triage() を呼ぶ。メニューからは triageNow / triageSamples / checkConfig / installTrigger / removeTrigger / showUsage。
 * dist/Code.gs の先頭に来るファイル。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { nextReceipt } from "./receipt.js";
import { ConfigError } from "./config.js";
import { buildInput, isBulk, isExcludedSender } from "./mail.js";
import { buildRequest } from "./prompt.js";
import { parseAnswer } from "./schema.js";
import { buildDraftBody, shouldDraft } from "./draft.js";
import { buildHeader, buildRow } from "./rows.js";
import { buildErrorText, buildNotificationText, isAttention } from "./message.js";
import { addUsage, formatUsage } from "./usage.js";
import { SAMPLE_ANSWERS, SAMPLE_EMAILS } from "./samples.js";
import { readApiKey_, readDailyCount_, readLastErrorNotice_, readLastReceipt_, readMonthUsage_, readOwner_, saveDailyCount_, saveLastErrorNotice_, saveLastReceipt_, saveMonthUsage_, saveOwner_, withLock_ } from "./gas_store.js";
import { appendInquiryRow_, prepareInquirySheet_, readConfig_, readHeader_, readRawTargets_, rowUrl_ } from "./gas_sheets.js";
import { ClaudeError, UNREACHABLE, callClaude_, isRetryable_ } from "./gas_claude.js";
import { LABEL_ATTENTION, LABEL_DONE, LABEL_PREFIX, LABEL_SKIPPED, createDraft_, headersOf_, labelThread_, latestInboundMessage_, messageInput_, ownAddress_, searchThreads_ } from "./gas_gmail.js";
import { notifyAll_ } from "./gas_notify.js";

const MENU_TITLE = "問い合わせ整理";
const TRIGGER_FUNCTION = "triage";
/** Apps Script の 1 回の実行は 6 分まで。強制終了は finally も通らないので、その手前で切り上げる */
const DEADLINE_MS = 4.5 * 60000;
const TRUNCATED_NOTE = "答えが長すぎて途中で切れました。";
/** そのメールだけの問題として飛ばす status（設定の誤りなら 401 / 403 で出るので、実行は止めない） */
const SKIP_STATUSES = [400, 404];
const BUSY_MESSAGE = "ほかの整理が動いています。少しあとでお試しください。";

/**
 * GmailApp は「スクリプトを実行しているアカウント」の Gmail を読む。シートを共有した編集者がメニューを押すと
 * その人の Gmail が読まれてしまうので、最初に整理した人（またはトリガーを入れた人）を持ち主として覚え、
 * ほかのアカウントでは Gmail に触らない。claim が true なら、持ち主が未定のとき自分を持ち主にする。
 * 返り値 { ok, me, owner }。自分のアドレスが読めないときは確かめようがないので ok にする。
 */
function ownerCheck_(claim) {
  const me = ownAddress_();
  const owner = readOwner_();
  if (me === "") return { ok: true, me: me, owner: owner };
  if (owner === "") {
    if (claim) saveOwner_(me);
    return { ok: true, me: me, owner: claim ? me : "" };
  }
  return { ok: owner === me, me: me, owner: owner };
}

function otherAccountMessage_(check) {
  return (
    "このキットは " + check.owner + " の Gmail を整理するように設定されています。いまのアカウント（" + check.me + "）では、Gmail の整理とトリガーの出し入れはしません（「見本のメールで試す」は使えます）。" +
    "持ち主を変えるときは、Apps Script のスクリプト プロパティから owner を消してください。"
  );
}

/** トリガーから呼ばれる。失敗しても投げない（トリガーの失敗通知が買い手に飛ばないように） */
export function triage() {
  return runTriage_(new Date(), false);
}

/** メニュー「今すぐ整理する」 */
export function triageNow() {
  const result = runTriage_(new Date(), false);
  SpreadsheetApp.getUi().alert(result.message);
}

/** メニュー「見本のメールで試す」。Claude と Gmail に触らず、シートと通知だけ動かす */
export function triageSamples() {
  const result = runTriage_(new Date(), true);
  SpreadsheetApp.getUi().alert(result.message);
}

/** Gmail から、今回読む候補を集める。skip のものは Claude に送らず、対象外のラベルだけ付ける */
function gmailCandidates_(config, own) {
  const threads = searchThreads_(config.query, config.perRun * 2);
  const candidates = [];
  for (let i = 0; i < threads.length; i += 1) {
    const thread = threads[i];
    const message = latestInboundMessage_(thread, own);
    if (message === null) {
      // 読む対象が無かっただけなので、対象外のラベルは貼らない（貼ると、後から届く本物の問い合わせも永久に外れる）
      candidates.push({ thread: thread, message: null, input: null, skip: true, labelSkipped: false });
      continue;
    }
    const input = messageInput_(message, config);
    const skip = isExcludedSender(input.from.address, config.excludedSenders) || isBulk(headersOf_(message));
    candidates.push({ thread: thread, message: message, input: input, skip: skip, labelSkipped: skip });
  }
  return candidates;
}

/** 見本のメールを、Gmail から来たのと同じ形の候補にする（thread と message は null） */
function sampleCandidates_(config) {
  const candidates = [];
  for (let i = 0; i < SAMPLE_EMAILS.length; i += 1) {
    const sample = SAMPLE_EMAILS[i];
    const input = buildInput(
      { from: sample.from, subject: sample.subject, date: new Date(sample.date), plainBody: sample.plainBody, htmlBody: "", attachmentNames: sample.attachmentNames },
      config,
    );
    const skip = isExcludedSender(input.from.address, config.excludedSenders) || isBulk(sample.headers);
    candidates.push({ thread: null, message: null, input: input, skip: skip, labelSkipped: false, answer: SAMPLE_ANSWERS[sample.id] });
  }
  return candidates;
}

/**
 * Claude に 1 通聞く。やり直しても駄目な 429 / 5xx と、そのメールだけの問題（400 / 404）は
 * null を返して次回に回す。鍵や権限の誤り（401 / 403）は投げて実行を止める。
 */
function ask_(apiKey, config, input) {
  try {
    const result = callClaude_(apiKey, buildRequest(config, input));
    const parsed = parseAnswer(result.text, config);
    if (!parsed.ok) Logger.log("問い合わせ整理: 答えを読み取れなかったので要対応にしました（" + parsed.reason + "）");
    const answer = parsed.answer;
    if (result.stopReason === "max_tokens") {
      answer.notes = answer.notes === "" ? TRUNCATED_NOTE : answer.notes + " " + TRUNCATED_NOTE;
      Logger.log("問い合わせ整理: " + TRUNCATED_NOTE + "「本文の上限文字数」を小さくすると収まりやすくなります");
    }
    return { answer: answer, usage: result.usage };
  } catch (error) {
    if (error instanceof ClaudeError && error.status === UNREACHABLE) {
      // つながらないときは 1 通ごとに時間切れを待つと 6 分を越えるので、この回はここで切り上げる
      Logger.log("問い合わせ整理: " + error.message);
      return { unreachable: error };
    }
    if (error instanceof ClaudeError && isRetryable_(error.status)) {
      Logger.log("問い合わせ整理: " + error.message);
      return null;
    }
    if (error instanceof ClaudeError && SKIP_STATUSES.indexOf(error.status) >= 0) {
      // このメールだけの問題（壊れた文字が混ざっているなど）か、設定の誤り（モデル名など）。ラベルを付けないので次回また試す。
      // 黙って飛ばすと設定の誤りに気づけないので、呼び出し側が 1 日 1 通だけ知らせる
      Logger.log("問い合わせ整理: このメールは受け付けられなかったので飛ばしました（" + error.status + "）: " + error.message);
      return { skipped: error };
    }
    throw error;
  }
}

function labelsFor_(answer) {
  const names = [LABEL_DONE, LABEL_PREFIX + answer.category];
  if (isAttention(answer)) names.push(LABEL_ATTENTION);
  return names;
}

/**
 * 1 回の整理。返り値 { processed, skipped, stopped, message }。
 * stopped は 1 日の上限で止めた数。message は人に見せる 1〜3 行。
 */
export function runTriage_(now, useSamples) {
  const stamp = formatStamp(now);
  const dateKey = toDateKey(now);
  const monthKey = dateKey.slice(0, 7);
  let config = null;
  try {
    config = readConfig_();
    const apiKey = useSamples ? "" : readApiKey_();
    if (!useSamples && apiKey === "") {
      throw new ConfigError("スクリプト プロパティに ANTHROPIC_API_KEY がありません。README.ja.md の手順 2 をご覧ください。");
    }
    let own = "";
    if (!useSamples) {
      const check = ownerCheck_(true);
      if (!check.ok) {
        // 共有した編集者が押しただけなので、失敗の通知はしない
        Logger.log("問い合わせ整理: 持ち主と別のアカウントのため、何もしません");
        return { processed: 0, skipped: 0, stopped: 0, message: otherAccountMessage_(check) };
      }
      own = check.me;
    }
    const outcome = withLock_(function () {
      const candidates = useSamples ? sampleCandidates_(config) : gmailCandidates_(config, own);
      let daily = readDailyCount_(dateKey);
      let usage = readMonthUsage_(monthKey);
      let lastReceipt = readLastReceipt_();
      let header = readHeader_();
      if (header.length === 0) header = buildHeader();
      let writeHeader = false;
      // Claude に送る前に、書き込めるかを確かめる（保護されたシートに書けないまま API を使い続けないように）
      if (candidates.some(function (c) { return !c.skip; })) prepareInquirySheet_(header);
      const items = [];
      let processed = 0;
      let skipped = 0;
      let stopped = 0;
      let unreachable = 0;
      // 途中で例外が出ても、ここまでの利用量は残す（受付番号と件数は 1 件ごとに保存する）
      try {
      for (let i = 0; i < candidates.length; i += 1) {
        const c = candidates[i];
        // 6 分の強制終了に当たると、書いた行が誰にも知らされないまま消える。その手前で切り上げて次回に回す
        if (new Date().getTime() - now.getTime() > DEADLINE_MS) {
          stopped += candidates.length - i;
          Logger.log("問い合わせ整理: 実行時間の上限が近いので、残り " + (candidates.length - i) + " 件を次回に回します");
          break;
        }
        if (c.skip) {
          if (c.thread !== null && c.labelSkipped === true) labelThread_(c.thread, [LABEL_SKIPPED]);
          skipped += 1;
          continue;
        }
        if (processed >= config.perRun || daily >= config.perDay) {
          stopped += 1;
          continue;
        }
        const asked = useSamples ? { answer: c.answer, usage: null } : ask_(apiKey, config, c.input);
        if (asked === null) continue;
        if (asked.unreachable !== undefined) {
          unreachable = candidates.length - i;
          stopped += unreachable;
          if (config.errorNotify) reportError_(asked.unreachable, stamp, config);
          break;
        }
        if (asked.skipped !== undefined) {
          if (config.errorNotify) reportError_(asked.skipped, stamp, config);
          continue;
        }
        const receipt = nextReceipt(lastReceipt, dateKey);
        lastReceipt = receipt;
        const link = c.thread === null ? "" : c.thread.getPermalink();
        const built = buildRow(header, { stamp: stamp, receipt: receipt, answer: asked.answer, input: c.input, link: link });
        const rowNumber = appendInquiryRow_(built.header, built.row, writeHeader || built.added.length > 0);
        header = built.header;
        writeHeader = false;
        if (c.message !== null && shouldDraft(asked.answer, config)) createDraft_(c.message, buildDraftBody(asked.answer, config));
        if (c.thread !== null) labelThread_(c.thread, labelsFor_(asked.answer));
        if (asked.usage !== null) usage = addUsage(usage, asked.usage);
        items.push({ answer: asked.answer, input: c.input, receipt: receipt, rowNumber: rowNumber, rowUrl: c.thread === null ? "" : rowUrl_(rowNumber) });
        processed += 1;
        // 見本は API を使わないので、1 日の件数には数えない
        if (!useSamples) daily += 1;
        // 1 件ごとに残す。6 分で強制終了されても受付番号が重ならず、1 日の上限も抜けない
        saveLastReceipt_(lastReceipt);
        saveDailyCount_(dateKey, daily);
      }
      } finally {
        saveMonthUsage_(monthKey, usage);
      }
      const lines = [(useSamples ? "見本のメール " : "新しい問い合わせ ") + processed + " 件を整理しました。"];
      if (skipped > 0) lines.push("対象外（配信メールや除外の差出人）: " + skipped + " 件");
      if (unreachable > 0) lines.push("Claude に接続できなかったため次回に回した: " + unreachable + " 件");
      if (stopped - unreachable > 0) lines.push("上限に達したため次回に回した: " + (stopped - unreachable) + " 件");
      if (items.length > 0) {
        const sent = notifyAll_(config, function (target) {
          return buildNotificationText(config, items, target);
        });
        // 通知だけが黙って落ちるのが「通知が来ない」の一番多い原因なので、画面と実行ログに出す
        if (config.targets.length > 0 && sent === 0) lines.push("通知を送れませんでした。Webhook URL をご確認ください。");
      }
      Logger.log("問い合わせ整理: " + lines.join(" "));
      return { processed: processed, skipped: skipped, stopped: stopped, message: lines.join("\n") };
    });
    // ロックが取れなかったとき。失敗ではないので、通知もしない
    if (outcome.busy === true) return { processed: 0, skipped: 0, stopped: 0, message: BUSY_MESSAGE };
    return outcome;
  } catch (error) {
    Logger.log("問い合わせ整理: " + error);
    if (config === null || config.errorNotify) reportError_(error, stamp, config);
    return { processed: 0, skipped: 0, stopped: 0, message: "整理を実行できませんでした。\n" + String(error && error.message ? error.message : error) };
  }
}

/**
 * 失敗を通知先へ 1 通流す。設定が壊れているときは、通知先の行だけを読み直す。
 * 同じ日に同じエラーが続くときは実行ログだけにする（15 分ごとに鳴り続けないように）。
 */
export function reportError_(error, stamp, config) {
  try {
    const destination = config ? config : readRawTargets_();
    if (!destination || destination.targets.length === 0) return;
    const detail = String(error && error.message ? error.message : error);
    const notice = String(stamp).slice(0, 10) + " " + detail.slice(0, 40);
    if (readLastErrorNotice_() === notice) {
      Logger.log("問い合わせ整理: 同じエラーは 1 日 1 通だけ通知します。今回は実行ログだけに残します");
      return;
    }
    saveLastErrorNotice_(notice);
    notifyAll_(destination, buildErrorText(error, stamp));
  } catch (sendError) {
    Logger.log("問い合わせ整理: エラー通知も送れませんでした: " + sendError);
  }
}

/** 設定シートを読んで、いまの設定を一覧で出す */
export function checkConfig() {
  const ui = SpreadsheetApp.getUi();
  try {
    const config = readConfig_();
    const check = ownerCheck_(false);
    const gmailOwner = check.owner !== "" ? check.owner : check.me;
    const lines = [
      "整理する Gmail: " + (gmailOwner === "" ? "（アカウントを読めませんでした。承認をやり直してください）" : gmailOwner) + (check.ok ? "" : "（いまのアカウント " + check.me + " では整理しません）"),
      "会社名: " + config.companyName,
      "分類: " + config.categories.join(" / "),
      "下書き: " + (config.makeDrafts ? "作る（作らない分類: " + (config.noDraftCategories.length === 0 ? "なし" : config.noDraftCategories.join(", ")) + "）" : "作らない"),
      "検索条件: " + config.query,
      "モデル: " + config.model + "、間隔: " + config.intervalMinutes + " 分、1 回 " + config.perRun + " 通、1 日 " + config.perDay + " 通",
      "通知先: " + (config.targets.length === 0 ? "（通知しない）" : config.targets.join(", ")),
      "API キー: " + (readApiKey_() === "" ? "未設定（スクリプト プロパティに ANTHROPIC_API_KEY を入れてください）" : "設定済み"),
      "トリガー: " + (triggerInstalled_() ? "入っています" : "入っていません（メニューの「トリガーを入れる」）"),
    ];
    ui.alert("設定は読めました\n\n" + lines.join("\n"));
  } catch (error) {
    ui.alert("設定に直すところがあります\n\n" + String(error && error.message ? error.message : error));
  }
}

function triggerInstalled_() {
  const triggers = ScriptApp.getProjectTriggers();
  for (let i = 0; i < triggers.length; i += 1) {
    if (triggers[i].getHandlerFunction() === TRIGGER_FUNCTION) return true;
  }
  return false;
}

function deleteTriggers_() {
  const triggers = ScriptApp.getProjectTriggers();
  for (let i = 0; i < triggers.length; i += 1) {
    if (triggers[i].getHandlerFunction() === TRIGGER_FUNCTION) ScriptApp.deleteTrigger(triggers[i]);
  }
}

/** メニュー「トリガーを入れる」。設定の間隔で triage を回す。入れ直すと前のは消す */
export function installTrigger() {
  const ui = SpreadsheetApp.getUi();
  try {
    const config = readConfig_();
    const check = ownerCheck_(true);
    if (!check.ok) {
      ui.alert(otherAccountMessage_(check));
      return;
    }
    deleteTriggers_();
    const builder = ScriptApp.newTrigger(TRIGGER_FUNCTION).timeBased();
    if (config.intervalMinutes >= 60) builder.everyHours(1).create();
    else builder.everyMinutes(config.intervalMinutes).create();
    ui.alert(config.intervalMinutes + " 分ごとに整理するトリガーを入れました。止めるときはメニューの「トリガーを外す」です。");
  } catch (error) {
    ui.alert("トリガーを入れられませんでした\n\n" + String(error && error.message ? error.message : error));
  }
}

/** メニュー「トリガーを外す」 */
export function removeTrigger() {
  const check = ownerCheck_(false);
  if (!check.ok) {
    // トリガーは入れた人のものしか見えない（ScriptApp.getProjectTriggers）ので、ほかのアカウントからは外せない
    SpreadsheetApp.getUi().alert("トリガーは持ち主（" + check.owner + "）のアカウントで入っています。そのアカウントでスプレッドシートを開き、「トリガーを外す」を押してください。");
    return;
  }
  deleteTriggers_();
  SpreadsheetApp.getUi().alert("トリガーを外しました。メニューの「今すぐ整理する」は引き続き使えます。");
}

/** メニュー「今月の利用」 */
export function showUsage() {
  const ui = SpreadsheetApp.getUi();
  try {
    const config = readConfig_();
    const monthKey = toDateKey(new Date()).slice(0, 7);
    ui.alert(formatUsage(readMonthUsage_(monthKey), config.model, monthKey));
  } catch (error) {
    ui.alert(String(error && error.message ? error.message : error));
  }
}

/** シートを開いたときにメニューを足す */
export function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu(MENU_TITLE)
    .addItem("今すぐ整理する", "triageNow")
    .addItem("見本のメールで試す", "triageSamples")
    .addItem("設定を確かめる", "checkConfig")
    .addSeparator()
    .addItem("トリガーを入れる", "installTrigger")
    .addItem("トリガーを外す", "removeTrigger")
    .addItem("今月の利用", "showUsage")
    .addToUi();
}
