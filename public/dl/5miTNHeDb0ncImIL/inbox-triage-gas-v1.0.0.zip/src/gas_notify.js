/** Slack / Discord の Webhook と、LINE の push message に 1 通送る。 */
import { buildPayload } from "./message.js";

const LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push";

function post_(url, payload, headers) {
  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  if (headers) options.headers = headers;
  const response = UrlFetchApp.fetch(url, options);
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(status + " が返りました: " + String(response.getContentText()).slice(0, 200));
  }
}

export function postSlack_(url, text) {
  post_(url, buildPayload(text, "slack"));
}

export function postDiscord_(url, text) {
  post_(url, buildPayload(text, "discord"));
}

export function pushLine_(token, to, text) {
  post_(LINE_PUSH_URL, buildPayload(text, "line", { lineTo: to }), { Authorization: "Bearer " + token });
}

/**
 * 設定の通知先すべてに送る。1 つが失敗しても残りには送り、失敗は実行ログに残す。返り値: 送れた宛先の数。
 * text は文字列か、宛先の名前を受けて文面を返す関数（Slack だけリンクの書き方が違うため）。
 */
export function notifyAll_(config, text) {
  let sent = 0;
  for (let i = 0; i < config.targets.length; i += 1) {
    const target = config.targets[i];
    const body = typeof text === "function" ? text(target) : String(text);
    try {
      if (target === "slack") postSlack_(config.slackWebhookUrl, body);
      else if (target === "discord") postDiscord_(config.discordWebhookUrl, body);
      else if (target === "line") pushLine_(config.lineToken, config.lineTo, body);
      else continue;
      sent += 1;
    } catch (error) {
      Logger.log("問い合わせ整理: " + target + " に送れませんでした: " + error);
    }
  }
  return sent;
}
