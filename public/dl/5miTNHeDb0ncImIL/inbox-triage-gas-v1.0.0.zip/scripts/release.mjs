#!/usr/bin/env node
// 配布 zip を release/ に作る。買い手が貼るのは dist/Code.gs の 1 本だけ。
// src / test / scripts も入れる（「手元で動かす」と改造ができるように）。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/inbox-triage-gas-v${pkg.version}.zip`;

for (const required of ["dist/Code.gs", "dist/appsscript.json", "README.ja.md", "LICENSE.md", "CHANGELOG.md"]) {
  if (!existsSync(required)) {
    console.error(required + " が無い。先に npm run build（README などは Task 11 で作る）");
    process.exit(1);
  }
}
mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

execFileSync(
  "zip",
  ["-r", out, "dist", "samples", "src", "test", "scripts", "README.ja.md", "LICENSE.md", "CHANGELOG.md", "package.json", "-x", "*.DS_Store"],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
