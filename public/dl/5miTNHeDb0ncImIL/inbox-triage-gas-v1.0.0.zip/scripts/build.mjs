#!/usr/bin/env node
// src/*.js を 1 本の dist/Code.gs にまとめる。買い手は Apps Script のエディタにこの 1 ファイルを貼る。
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/**
 * つなぐ順。先頭は入口の gas_main.js にする。
 * 関数宣言は巻き上がるうえ、どのファイルも先頭で走るのは定数の初期化だけなので、前に置いても壊れない。
 * 以降は 純粋な処理 → GAS に触る部分。
 */
export const SOURCE_ORDER = [
  "gas_main.js",
  "dates.js",
  "receipt.js",
  "config.js",
  "mail.js",
  "prompt.js",
  "schema.js",
  "draft.js",
  "rows.js",
  "message.js",
  "usage.js",
  "samples.js",
  "gas_store.js",
  "gas_sheets.js",
  "gas_claude.js",
  "gas_gmail.js",
  "gas_notify.js",
];

export const MANIFEST = {
  timeZone: "Asia/Tokyo",
  dependencies: {},
  exceptionLogging: "STACKDRIVER",
  runtimeVersion: "V8",
  // spreadsheets = シートの読み書き、mail.google.com = 検索・下書き・ラベル、userinfo.email = 自分のアドレス、
  // external_request = Claude と通知、scriptapp = トリガーの出し入れ、container.ui = メニューと確認の画面。
  // GmailApp が受け付ける Gmail のスコープは https://mail.google.com/ の 1 つだけ（gmail.modify などの細かいスコープは
  // Gmail API のアドバンス サービス用で GmailApp には効かない）。同意画面は「送信」「完全な削除」まで含む表示になるので
  // README 手順 4 で説明する。送信・削除の命令はこのキットに無い（build.test.mjs が検査する）。
  oauthScopes: [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://mail.google.com/",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/script.scriptapp",
    "https://www.googleapis.com/auth/script.container.ui",
  ],
};

/**
 * Apps Script は import / export を解さない。
 * 1 ファイルに並べれば同じ名前空間になるので、import 行は落とし、行頭の export だけを剥がす。
 */
export function toGasSource(source) {
  const lines = String(source).split("\n");
  const kept = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (/^import\s[^;]*from\s+["'][^"']+["'];?\s*$/.test(line)) continue;
    kept.push(line.replace(/^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\s)/, ""));
  }
  return kept.join("\n").trim();
}

export function buildSource(root) {
  const base = root === undefined ? ROOT : root;
  const parts = [];
  for (let i = 0; i < SOURCE_ORDER.length; i += 1) {
    const name = SOURCE_ORDER[i];
    parts.push("// ===== " + name + " =====\n" + toGasSource(readFileSync(join(base, "src", name), "utf8")));
  }
  const code = parts.join("\n\n");
  const leftover = code.match(/^\s*(import|export)\s/m);
  if (leftover) throw new Error("import / export が残っている: " + leftover[0].trim());
  return code;
}

export function build(root) {
  const base = root === undefined ? ROOT : root;
  mkdirSync(join(base, "dist"), { recursive: true });
  const header = "// AI 問い合わせ整理キット — scripts/build.mjs が src/ から作る。ここを直接編集しない\n\n";
  writeFileSync(join(base, "dist", "Code.gs"), header + buildSource(base) + "\n");
  writeFileSync(join(base, "dist", "appsscript.json"), JSON.stringify(MANIFEST, null, 2) + "\n");
}

const invokedDirectly = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  build();
  console.log("wrote dist/Code.gs, dist/appsscript.json");
}
