import { test } from "node:test";
import assert from "node:assert/strict";
import { HEADERS, STATUS_NEW, buildHeader, buildRow } from "../src/rows.js";

const entry = {
  stamp: "2026-09-14 10:32:05",
  receipt: "20260914-001",
  answer: {
    category: "見積もり依頼",
    urgency: "中",
    summary: "会議室の内装工事の見積もり依頼",
    request: "見積書の送付",
    deadline: "2026-09-30",
    person: { name: "みなと 太郎", company: "みなと商会", phone: "03-0000-0001" },
    replyDraft: "…",
    needsHuman: false,
    confidence: 0.92,
    notes: "=SUM(A1)",
  },
  input: { from: { name: "みなと 太郎", address: "taro@example.com" }, subject: "+見積もりのお願い", attachments: ["図面.pdf", "写真.jpg"], receivedAt: "2026-09-14 10:32", body: "" },
  link: "https://mail.google.com/mail/u/0/#all/abc",
};

test("見出しは 18 列で、受信日時から始まりスレッドで終わる", () => {
  assert.equal(HEADERS.length, 18);
  assert.deepEqual(buildHeader(), HEADERS);
  assert.equal(HEADERS[0], "受信日時");
  assert.equal(HEADERS[HEADERS.length - 1], "スレッド");
  assert.equal(STATUS_NEW, "未対応");
});

test("1 行は見出しの順に並び、数式になりうる字は守られる", () => {
  const built = buildRow(buildHeader(), entry);
  assert.deepEqual(built.added, []);
  assert.deepEqual(built.row, [
    "2026-09-14 10:32:05",
    "20260914-001",
    "見積もり依頼",
    "中",
    "会議室の内装工事の見積もり依頼",
    "見積書の送付",
    "2026-09-30",
    "みなと 太郎",
    "みなと商会",
    "03-0000-0001",
    "taro@example.com",
    "'+見積もりのお願い",
    "図面.pdf, 写真.jpg",
    "未対応",
    "",
    "92%",
    "'=SUM(A1)",
    "https://mail.google.com/mail/u/0/#all/abc",
  ]);
});

test("買い手が列を並べ替えたり消したりしていても、名前で探して書く。無い標準の列は末尾に足す", () => {
  const custom = ["受付番号", "分類", "メモ欄（自由）", "要約", "状態"];
  const built = buildRow(custom, entry);
  assert.deepEqual(built.added, HEADERS.filter((h) => custom.indexOf(h) < 0));
  assert.equal(built.row[0], "20260914-001");
  assert.equal(built.row[1], "見積もり依頼");
  assert.equal(built.row[2], "");
  assert.equal(built.row[3], "会議室の内装工事の見積もり依頼");
  assert.equal(built.row[4], "未対応");
  assert.equal(built.header.length, custom.length + built.added.length);
  assert.equal(built.row.length, built.header.length);
});

test("人の情報が null なら空、期限が null なら空", () => {
  const built = buildRow(buildHeader(), Object.assign({}, entry, { answer: Object.assign({}, entry.answer, { deadline: null, person: { name: null, company: null, phone: null } }) }));
  assert.equal(built.row[6], "");
  assert.equal(built.row[7], "みなと 太郎");
  assert.equal(built.row[8], "");
  assert.equal(built.row[9], "");
});
