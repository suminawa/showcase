import { test } from "node:test";
import assert from "node:assert/strict";
import { buildInput, htmlToText, isBulk, isExcludedSender, parseFrom, stripQuotes, truncateBody } from "../src/mail.js";

test("差出人を名前とアドレスに分ける", () => {
  assert.deepEqual(parseFrom("みなと 太郎 <taro@example.com>"), { name: "みなと 太郎", address: "taro@example.com" });
  assert.deepEqual(parseFrom('"Minato, Taro" <taro@example.com>'), { name: "Minato, Taro", address: "taro@example.com" });
  assert.deepEqual(parseFrom("taro@example.com"), { name: "", address: "taro@example.com" });
  assert.deepEqual(parseFrom(""), { name: "", address: "" });
});

test("引用（> 行・On … wrote:・元のメッセージ）を落とす", () => {
  const text = ["お世話になります。", "見積もりをお願いします。", "", "> 前回のご案内です", "> ありがとうございます", "", "2026年9月13日(土) 10:00 みなと商会 <info@example.com>:", "> ご連絡ありがとうございます"].join("\n");
  assert.equal(stripQuotes(text), "お世話になります。\n見積もりをお願いします。");
  assert.equal(stripQuotes("本文です\n\nOn Sat, Sep 13, 2026 at 10:00 AM Taro <t@example.com> wrote:\n> hi"), "本文です");
  assert.equal(stripQuotes("本文です\n-----Original Message-----\nFrom: x"), "本文です");
  assert.equal(stripQuotes("本文です\n\n> 引用\n続きの本文"), "本文です\n\n続きの本文");
});

test("HTML はタグを落として文にする（改行と箇条書きは残す）", () => {
  const html = "<html><body><p>お世話に<br>なります。</p><ul><li>数量 10</li><li>納期 9/30</li></ul><style>p{}</style><script>x()</script>&amp;&lt;&gt;&nbsp;&quot;</body></html>";
  assert.equal(htmlToText(html), "お世話に\nなります。\n- 数量 10\n- 納期 9/30\n&<> \"");
});

test("上限で切る。切ったら印を足す", () => {
  assert.equal(truncateBody("短い", 4000), "短い");
  const long = "あ".repeat(4100);
  const cut = truncateBody(long, 4000);
  assert.equal(cut.length, 4000 + "\n…（以下省略）".length);
  assert.ok(cut.endsWith("…（以下省略）"));
});

test("除外の差出人は部分一致で、大文字小文字を見ない", () => {
  const list = ["noreply@", "no-reply@", "newsletter@", "info@example.com"];
  assert.equal(isExcludedSender("NoReply@shop.example", list), true);
  assert.equal(isExcludedSender("taro@example.com", list), false);
  assert.equal(isExcludedSender("info@example.com", list), true);
  assert.equal(isExcludedSender("taro@example.com", []), false);
});

test("配信メール・自動送信はヘッダーで見分ける", () => {
  assert.equal(isBulk({ listUnsubscribe: "<https://x/unsub>", precedence: "", autoSubmitted: "" }), true);
  assert.equal(isBulk({ listUnsubscribe: "", precedence: "bulk", autoSubmitted: "" }), true);
  assert.equal(isBulk({ listUnsubscribe: "", precedence: "", autoSubmitted: "auto-replied" }), true);
  assert.equal(isBulk({ listUnsubscribe: "", precedence: "", autoSubmitted: "no" }), false);
  assert.equal(isBulk({ listUnsubscribe: "", precedence: "", autoSubmitted: "" }), false);
  assert.equal(isBulk({ listUnsubscribe: null, precedence: null, autoSubmitted: null }), false);
});

test("HTML の段落の区切り（<br><br> や空行）は残り、箇条書きは 1 行ずつ", () => {
  assert.equal(htmlToText("A<br><br>B"), "A\n\nB");
  assert.equal(htmlToText("<p>A</p>\n\n<p>B</p>"), "A\n\nB");
  assert.equal(htmlToText("<ul><li>a</li><li>b</li></ul>c"), "- a\n- b\nc");
});

test("メール 1 通を Claude に渡す入力にする", () => {
  const input = buildInput(
    {
      from: "みなと 太郎 <taro@example.com>",
      subject: "見積もりのお願い",
      date: new Date(Date.UTC(2026, 8, 14, 1, 32, 5)),
      plainBody: "お世話になります。\n見積もりをお願いします。\n\n> 引用",
      htmlBody: "<p>無視される</p>",
      attachmentNames: ["図面.pdf", "写真.jpg"],
    },
    { bodyLimit: 4000 },
  );
  assert.deepEqual(input, {
    from: { name: "みなと 太郎", address: "taro@example.com" },
    subject: "見積もりのお願い",
    receivedAt: "2026-09-14 10:32",
    attachments: ["図面.pdf", "写真.jpg"],
    body: "お世話になります。\n見積もりをお願いします。",
  });
});

test("本文が無ければ HTML から、それも無ければ空", () => {
  const html = buildInput({ from: "a@example.com", subject: "", date: new Date(0), plainBody: "", htmlBody: "<p>HTML の本文</p>", attachmentNames: [] }, { bodyLimit: 4000 });
  assert.equal(html.body, "HTML の本文");
  const none = buildInput({ from: "a@example.com", subject: "", date: new Date(0), plainBody: "  ", htmlBody: "", attachmentNames: [] }, { bodyLimit: 4000 });
  assert.equal(none.body, "");
  assert.equal(none.receivedAt, "1970-01-01 09:00");
});
