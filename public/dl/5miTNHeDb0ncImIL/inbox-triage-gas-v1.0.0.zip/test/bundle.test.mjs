import { test } from "node:test";
import assert from "node:assert/strict";
import { createContext, runInContext } from "node:vm";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildSource } from "../scripts/build.mjs";
import { HEADERS } from "../src/rows.js";
import { SAMPLE_ANSWERS } from "../src/samples.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

function fakeSheet(values) {
  const rows = values.map((row) => Array.from(row));
  const sheet = {
    rows: rows,
    getSheetId: () => 1234567,
    getLastRow: () => rows.length,
    getLastColumn: () => (rows.length === 0 ? 0 : rows[0].length),
    getMaxColumns: () => 26,
    insertColumnsAfter: () => {},
    getDataRange: () => ({ getValues: () => rows.map((row) => row.slice()) }),
    getRange: (r, c, nr, nc) => ({
      getValues: () => [rows[r - 1].slice(c - 1, c - 1 + nc)],
      setValues: (written) => {
        rows[r - 1] = Array.from(written[0]);
      },
    }),
    appendRow: (row) => {
      rows.push(Array.from(row));
    },
  };
  return sheet;
}

/** 偽の Gmail のメッセージ */
function fakeMessage(spec, trace) {
  return {
    isDraft: () => false,
    getFrom: () => spec.from,
    getSubject: () => spec.subject,
    getDate: () => new Date(spec.date),
    getPlainBody: () => spec.plainBody,
    getBody: () => "",
    getAttachments: (opts) => {
      trace.attachmentOptions.push(opts);
      return (spec.attachmentNames || []).map((name) => ({ getName: () => name }));
    },
    getHeader: (name) => (spec.headers && spec.headers[name]) || "",
    createDraftReply: (body) => trace.drafts.push({ id: spec.id, body: body }),
  };
}

function fakeThread(spec, trace) {
  const labels = [];
  return {
    id: spec.id,
    labels: labels,
    getMessages: () => [fakeMessage(spec, trace)],
    getPermalink: () => "https://mail.google.com/mail/u/0/#all/" + spec.id,
    addLabel: (label) => labels.push(label.name),
  };
}

const SETTINGS = [
  ["項目", "値"],
  ["会社名", "みなと商会"],
  ["署名", "みなと商会\n03-0000-0000"],
  ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
];

const CLAUDE_ANSWER = SAMPLE_ANSWERS["quote-01"];

/** つないだ 1 本を偽の GAS の上で走らせる。options = { threads, apiKey, claudeStatus, settings, lockBusy, claudeBody } */
/** 偽の GAS の時計。引数なしの new Date() と Date.now() は 2026-09-14 10:40 JST に固定する（テストが日付に依存しないように） */
const FIXED_NOW = Date.UTC(2026, 8, 14, 1, 40, 0);
class FixedDate extends Date {
  constructor(...args) {
    if (args.length === 0) super(FIXED_NOW);
    else super(...args);
  }
  static now() {
    return FIXED_NOW;
  }
}

function runBundle(options) {
  const trace = { fetched: [], drafts: [], alerts: [], logs: [], labelsCreated: [], triggers: [], attachmentOptions: [] };
  const props = {};
  const sheets = { 設定: fakeSheet(options.settings || SETTINGS) };
  if (options.inquiries) sheets["問い合わせ"] = options.inquiries;
  if (options.apiKey !== undefined) props.ANTHROPIC_API_KEY = options.apiKey;
  const threads = (options.threads || []).map((spec) => fakeThread(spec, trace));
  const book = {
    getUrl: () => "https://docs.google.com/spreadsheets/d/SHEETID/edit",
    getSpreadsheetTimeZone: () => "Asia/Tokyo",
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      sheets[name] = fakeSheet([]);
      return sheets[name];
    },
  };
  const sandbox = {
    Date: FixedDate,
    SpreadsheetApp: { getActiveSpreadsheet: () => book, getUi: () => ({ alert: (t) => trace.alerts.push(String(t)) }) },
    GmailApp: {
      search: (query, start, max) => threads.slice(0, max),
      getUserLabelByName: (name) => null,
      createLabel: (name) => {
        trace.labelsCreated.push(name);
        return { name: name };
      },
    },
    UrlFetchApp: {
      fetch: (url, opts) => {
        trace.fetched.push({ url: url, payload: opts.payload, headers: opts.headers || {} });
        if (url.indexOf("api.anthropic.com") >= 0) {
          const status = Array.isArray(options.claudeStatuses) ? options.claudeStatuses[Math.min(trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length - 1, options.claudeStatuses.length - 1)] : options.claudeStatus || 200;
          const body = options.claudeBody || { content: [{ type: "text", text: JSON.stringify(CLAUDE_ANSWER) }], usage: { input_tokens: 1200, output_tokens: 300, cache_read_input_tokens: 700, cache_creation_input_tokens: 0 }, stop_reason: "end_turn" };
          return { getResponseCode: () => status, getContentText: () => JSON.stringify(status === 200 ? body : { error: "x" }) };
        }
        return { getResponseCode: () => 200, getContentText: () => "ok" };
      },
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (props[key] === undefined ? null : props[key]),
        setProperty: (key, value) => {
          props[key] = value;
        },
      }),
    },
    LockService: {
      getScriptLock: () => ({
        waitLock: () => {
          // 本物の waitLock は取れないと例外を投げる（tryLock と違う）
          if (options.lockBusy) throw new Error("Could not acquire lock");
        },
        releaseLock: () => {},
      }),
    },
    ScriptApp: {
      getProjectTriggers: () => trace.triggers,
      deleteTrigger: (t) => trace.triggers.splice(trace.triggers.indexOf(t), 1),
      newTrigger: (fn) => ({ timeBased: () => ({ everyMinutes: (m) => ({ create: () => trace.triggers.push({ getHandlerFunction: () => fn, minutes: m }) }), everyHours: (h) => ({ create: () => trace.triggers.push({ getHandlerFunction: () => fn, hours: h }) }) }) }),
    },
    Session: { getActiveUser: () => ({ getEmail: () => "owner@example.com" }) },
    Utilities: { sleep: () => {} },
    Logger: { log: (t) => trace.logs.push(String(t)) },
  };
  const context = createContext(sandbox);
  runInContext(buildSource(root) + "\nglobalThis.__entry = { triage: triage, triageSamples: triageSamples, installTrigger: installTrigger, checkConfig: checkConfig };\n", context);
  return { entry: sandbox.__entry, trace: trace, sheets: sheets, props: props, threads: threads };
}

const INBOUND = {
  id: "t1",
  from: "みなと 太郎 <taro@example.com>",
  subject: "会議室の内装工事の見積もりをお願いします",
  date: "2026-09-14T01:32:00Z",
  plainBody: "見積もりをお願いします。",
  attachmentNames: ["図面.pdf"],
};
const BULK = { id: "t2", from: "ニュースレター <news@example.com>", subject: "今週の情報", date: "2026-09-14T02:00:00Z", plainBody: "配信", headers: { "List-Unsubscribe": "<https://x/u>" } };

test("鍵があれば、Gmail の 1 通を Claude に送り、行・下書き・ラベル・通知が出る", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, BULK] });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(result.skipped, 1);
  const sheet = run.sheets["問い合わせ"];
  assert.deepEqual(sheet.rows[0], HEADERS);
  assert.equal(sheet.rows.length, 2);
  assert.equal(sheet.rows[1][2], "見積もり依頼");
  assert.equal(sheet.rows[1][13], "未対応");
  assert.equal(sheet.rows[1][17], "https://mail.google.com/mail/u/0/#all/t1");
  // Claude への送信は 1 回、鍵はヘッダーに、本文は JSON
  const claude = run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0);
  assert.equal(claude.length, 1);
  assert.equal(claude[0].headers["x-api-key"], "sk-ant-test");
  assert.equal(claude[0].headers["anthropic-version"], "2023-06-01");
  const body = JSON.parse(claude[0].payload);
  assert.equal(body.output_config.format.type, "json_schema");
  assert.ok(body.messages[0].content[0].text.includes("見積もりをお願いします。"));
  // 下書きは署名つき、ラベルは 済 と 分類
  assert.equal(run.trace.drafts.length, 1);
  assert.ok(run.trace.drafts[0].body.endsWith("みなと商会\n03-0000-0000"));
  assert.deepEqual(run.threads[0].labels, ["AI整理済", "AI_見積もり依頼"]);
  assert.deepEqual(run.threads[1].labels, ["AI整理対象外"]);
  // インライン画像（署名の画像など）は添付に入れない
  assert.equal(run.trace.attachmentOptions.length, 2);
  for (const opts of run.trace.attachmentOptions) assert.equal(opts.includeInlineImages, false);
  // Slack へ 1 通。本文は載らず、シートの行はリンクになる
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("新しい問い合わせ 1 件"));
  assert.equal(JSON.parse(slack[0].payload).text.includes("見積もりをお願いします。"), false);
  assert.ok(JSON.parse(slack[0].payload).text.includes("<https://docs.google.com/spreadsheets/d/SHEETID/edit#gid=1234567&range=A2|行 2>"));
  // 覚え書き
  assert.equal(run.props["count:2026-09-14"] !== undefined, true);
  assert.equal(JSON.parse(run.props["usage:2026-09"]).count, 1);
  assert.match(run.props.lastReceipt, /^20260914-001$/);
});

test("鍵が無ければ、何もせずエラーを通知する", () => {
  const run = runBundle({ threads: [INBOUND] });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.ok(result.message.includes("ANTHROPIC_API_KEY"));
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
  assert.equal(run.sheets["問い合わせ"], undefined);
});

test("Claude が 529 を返し続けたら、そのメールは飛ばして次回に回す（ラベルを付けない）", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeStatus: 529 });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.deepEqual(run.threads[0].labels, []);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 2, "1 回やり直す");
  assert.equal(run.trace.drafts.length, 0);
});

test("見本のメールで試すと、鍵と Gmail に触らず 7 行と通知が出る", () => {
  const run = runBundle({});
  run.entry.triageSamples();
  const sheet = run.sheets["問い合わせ"];
  assert.equal(sheet.rows.length, 8);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 0);
  assert.equal(run.trace.drafts.length, 0);
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.startsWith("新しい問い合わせ 7 件\n⚠ 要対応"));
  assert.ok(run.trace.alerts[0].includes("見本のメール 7 件"));
  assert.ok(run.trace.alerts[0].includes("対象外"));
});

test("答えが max_tokens で切れたら、メモにその旨が入り実行ログにも残る", () => {
  const body = { content: [{ type: "text", text: JSON.stringify(CLAUDE_ANSWER) }], usage: { input_tokens: 1200, output_tokens: 4000 }, stop_reason: "max_tokens" };
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeBody: body });
  run.entry.triage();
  assert.equal(run.sheets["問い合わせ"].rows[1][16], "答えが長すぎて途中で切れました。");
  assert.ok(run.trace.logs.some((line) => line.includes("答えが長すぎて途中で切れました。")));
});

test("ほかの実行と重なってロックが取れないときは、何もせず通知もしない", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], lockBusy: true });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.equal(result.skipped, 0);
  assert.equal(result.stopped, 0);
  assert.equal(result.message, "ほかの整理が動いています。少しあとでお試しください。");
  assert.equal(run.trace.fetched.length, 0, "Claude にも通知先にも送らない");
  assert.equal(run.sheets["問い合わせ"], undefined);
  assert.ok(run.trace.logs.some((line) => line.includes("ほかの整理が動いている")));
});

test("同じエラーが続いても、通知は 1 日 1 通だけ（実行ログには毎回残る）", () => {
  const run = runBundle({ threads: [INBOUND] });
  run.entry.triage();
  run.entry.triage();
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1, "2 回目は通知しない");
  assert.ok(run.props.lastErrorNotice.indexOf("ANTHROPIC_API_KEY") >= 0);
  assert.ok(run.trace.logs.some((line) => line.includes("1 日 1 通")));
});

test("設定シートが壊れていても、通知先の行だけを読んでエラーを届ける", () => {
  const broken = [
    ["項目", "値"],
    ["会社名", ""],
    ["通知先", "slack"],
    ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
  ];
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], settings: broken });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.ok(result.message.includes("「会社名」の行"));
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 0);
});

test("1 日の上限に当たったら、残りは行も下書きもラベルも増えずに次回へ回る", () => {
  const settings = SETTINGS.concat([["1 日の上限", "1"]]);
  const second = Object.assign({}, INBOUND, { id: "t3", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], settings: settings });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(result.stopped, 1);
  assert.ok(result.message.includes("上限に達したため次回に回した: 1 件"));
  assert.equal(run.sheets["問い合わせ"].rows.length, 2, "見出し + 1 行");
  assert.equal(run.trace.drafts.length, 1);
  assert.deepEqual(run.threads[1].labels, [], "次回また拾えるようにラベルは付けない");
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 1);
  assert.equal(run.props["count:2026-09-14"], "1");
});

test("思考ブロックが先に来る応答でも、text ブロックを読んで整理できる", () => {
  const body = {
    content: [{ type: "thinking", thinking: "" }, { type: "text", text: JSON.stringify(CLAUDE_ANSWER) }],
    usage: { input_tokens: 1200, output_tokens: 900, cache_read_input_tokens: 700, cache_creation_input_tokens: 0 },
    stop_reason: "end_turn",
  };
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeBody: body });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(run.sheets["問い合わせ"].rows[1][2], "見積もり依頼");
  assert.equal(run.sheets["問い合わせ"].rows[1][16], "", "メモは空（切れていない）");
});

test("トリガーは設定の間隔で 1 つだけ入る", () => {
  const run = runBundle({});
  run.entry.installTrigger();
  run.entry.installTrigger();
  assert.equal(run.trace.triggers.length, 1);
  assert.equal(run.trace.triggers[0].minutes, 15);
});

test("途中で設定の誤り（401）が出ても、それまでの受付番号と件数は残り、次回の番号が重ならない", () => {
  const second = Object.assign({}, INBOUND, { id: "t3", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], claudeStatuses: [200, 401] });
  const result = run.entry.triage();
  assert.equal(result.processed, 0, "エラーの返り値");
  assert.ok(result.message.includes("API キー"));
  const sheet = run.sheets["問い合わせ"];
  assert.equal(sheet.rows.length, 2, "1 件目の行は残る");
  assert.match(run.props.lastReceipt, /-001$/);
  assert.equal(Object.keys(run.props).filter((k) => k.indexOf("count:") === 0).length, 1);
  const dayKey = Object.keys(run.props).find((k) => k.indexOf("count:") === 0);
  assert.equal(run.props[dayKey], "1");
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
});

test("設定の誤り（400）で全部が飛ばされても、エラーは 1 日 1 通だけ知らされる", () => {
  const second = Object.assign({}, INBOUND, { id: "t4", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], claudeStatuses: [400, 400] });
  const first = run.entry.triage();
  assert.equal(first.processed, 0);
  assert.deepEqual(run.threads[0].labels, []);
  assert.deepEqual(run.threads[1].labels, []);
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1, "1 通だけ知らせる");
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
  run.entry.triage();
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0).length, 1, "同じ日の 2 回目は知らせない");
});
