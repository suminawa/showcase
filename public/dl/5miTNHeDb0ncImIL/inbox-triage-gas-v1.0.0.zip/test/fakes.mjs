/**
 * 偽の GAS。dist/Code.gs と同じ中身（scripts/build.mjs）を node:vm で走らせるための最小のグローバル。
 * 本物の Apps Script の癖のうち、このキットの動きに関わるものは偽物でも再現する（偽物が本物より甘いと、
 * テストが通っても実物で落ちる）。再現している癖:
 * - Sheets は書いた文字を打ち込んだときと同じく読み替える（数・先頭の 0 が消える数・日付・割合・TRUE/FALSE。先頭の ' は文字のまま）
 * - 保護されたシート（denyWrite）への書き込みと、シートの追加は例外
 * - プロパティは文字列だけ（数を入れても文字列で返る）。1 つ 9KB まで
 * - GmailApp.search は検索式のラベル（label: / -label:）を見る。max は 500 まで
 * - ラベルは 1 度作れば getUserLabelByName で返り、同じ名前をもう 1 度作ると例外
 * - createDraftReply で作った下書きは、そのスレッドのメッセージに（isDraft で）並ぶ
 * - getPlainBody の改行は \r\n
 * - UrlFetchApp は muteHttpExceptions が無いと 4xx/5xx で例外。接続できないとき（タイムアウトなど）は mute でも例外
 * - Session.getActiveUser() は空のことがある（トリガーや同意の範囲）。Gmail の持ち主は getEffectiveUser()
 * - トリガーは入れた人ごと。getProjectTriggers() は実行している人のものしか返さない。everyMinutes は 1/5/10/15/30 だけ
 * - トリガーからの実行では SpreadsheetApp.getUi() が例外
 * - マニフェストの oauthScopes に無い許可のサービスを呼ぶと例外
 */
import { createContext, runInContext } from "node:vm";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildSource, MANIFEST } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 引数なしの new Date() と Date.now() は 2026-09-14 10:40 JST に固定する（テストが日付に依存しないように） */
export const FIXED_NOW = Date.UTC(2026, 8, 14, 1, 40, 0);
class FixedDate extends Date {
  constructor(...args) {
    if (args.length === 0) super(FIXED_NOW);
    else super(...args);
  }
  static now() {
    return FIXED_NOW;
  }
}

export const OWNER = "owner@example.com";
const PROPERTY_VALUE_LIMIT = 9 * 1024;
const MINUTES_ALLOWED = [1, 5, 10, 15, 30];
const HOURS_ALLOWED = [1, 2, 4, 6, 8, 12];

/**
 * 本物の Sheets は、書き込んだ文字を人が打ち込んだときと同じように読み直す。
 * 先頭が ' なら文字（' は残らない）、数に見えれば数（先頭の 0 は消える）、割合は小数、TRUE/FALSE は真偽、
 * 日付に見えれば日付（JST）。
 */
export function parseWritten_(value) {
  if (typeof value !== "string") return value;
  if (value.charAt(0) === "'") return value.slice(1);
  const text = value.trim();
  if (/^(true|false)$/i.test(text)) return text.toLowerCase() === "true";
  if (/^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$/.test(text)) return Number(text.replace(/,/g, ""));
  if (/^[+-]?(\d+(\.\d+)?|\.\d+)(e[+-]?\d+)?$/i.test(text)) return Number(text);
  if (/^[+-]?\d+(\.\d+)?%$/.test(text)) return Number(text.slice(0, -1)) / 100;
  let m = text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  if (m) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], (m[4] ? +m[4] : 0) - 9, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
  m = text.match(/^(\d{1,2})\/(\d{1,2})$/);
  if (m && +m[1] >= 1 && +m[1] <= 12 && +m[2] >= 1 && +m[2] <= 31) return new Date(Date.UTC(2026, +m[1] - 1, +m[2], -9));
  return value;
}

export function fakeSheet(values, options) {
  const opts = options || {};
  const rows = (values || []).map((row) => Array.from(row).map(parseWritten_));
  const denied = (what) => {
    if (opts.denyWrite) throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit. (" + what + ")");
  };
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const write_ = (r, c, value) => {
    while (rows.length <= r) rows.push([]);
    while (rows[r].length <= c) rows[r].push("");
    rows[r][c] = parseWritten_(value);
  };
  const sheet = {
    rows: rows,
    getSheetId: () => 1234567,
    getLastRow: () => rows.length,
    getLastColumn: () => width(),
    getMaxColumns: () => Math.max(26, width()),
    insertColumnsAfter: () => denied("insertColumnsAfter"),
    getDataRange: () => ({ getValues: () => rows.map((row) => row.slice()) }),
    getRange: (r, c, nr, nc) => ({
      getValues: () => {
        const out = [];
        for (let i = 0; i < (nr || 1); i += 1) {
          const line = [];
          for (let j = 0; j < (nc || 1); j += 1) line.push(rows[r - 1 + i] && rows[r - 1 + i][c - 1 + j] !== undefined ? rows[r - 1 + i][c - 1 + j] : "");
          out.push(line);
        }
        return out;
      },
      setValues: (written) => {
        denied("setValues");
        for (let i = 0; i < written.length; i += 1) for (let j = 0; j < written[i].length; j += 1) write_(r - 1 + i, c - 1 + j, written[i][j]);
      },
    }),
    appendRow: (row) => {
      denied("appendRow");
      const r = rows.length;
      rows.push([]);
      for (let j = 0; j < row.length; j += 1) write_(r, j, row[j]);
    },
  };
  return sheet;
}

/**
 * スレッドの見本 spec = { id, from, subject, date, plainBody, attachmentNames, headers, labels, messages }
 * messages を書くと、そのスレッドは複数のメッセージ（古い順）になる。書かなければ spec そのものが 1 通。
 */
function fakeMessage(spec, trace, thread) {
  return {
    isDraft: () => spec.draft === true,
    getFrom: () => spec.from,
    getSubject: () => spec.subject,
    getDate: () => new Date(spec.date),
    // 本物の getPlainBody は改行が \r\n
    getPlainBody: () => String(spec.plainBody || "").replace(/\r?\n/g, "\r\n"),
    getBody: () => spec.htmlBody || "",
    getAttachments: (opts) => {
      trace.attachmentOptions.push(opts);
      return (spec.attachmentNames || []).map((name) => ({ getName: () => name }));
    },
    getHeader: (name) => (spec.headers && spec.headers[name]) || "",
    createDraftReply: (body) => {
      trace.drafts.push({ id: thread.id, body: body });
      thread.messages.push(fakeMessage({ from: "オーナー <" + OWNER + ">", subject: "Re: " + spec.subject, date: new Date(FIXED_NOW).toISOString(), plainBody: body, draft: true }, trace, thread));
      return {};
    },
  };
}

function fakeThread(spec, trace, labelStore) {
  const thread = { id: spec.id, labels: (spec.labels || []).slice(), messages: [] };
  const specs = spec.messages ? spec.messages : [spec];
  for (const one of specs) thread.messages.push(fakeMessage(Object.assign({ subject: spec.subject }, one), trace, thread));
  thread.getMessages = () => thread.messages.slice();
  thread.getPermalink = () => "https://mail.google.com/mail/u/0/#all/" + spec.id;
  thread.addLabel = (label) => {
    if (!label || labelStore.indexOf(label) < 0) throw new Error("Invalid argument: label");
    if (thread.labels.indexOf(label.getName()) < 0) thread.labels.push(label.getName());
    return thread;
  };
  return thread;
}

/** 検索式のうち label: と -label: だけを見る（ほかの語は本物の Gmail に任せる） */
function matchesQuery_(thread, query) {
  const tokens = String(query).split(/\s+/);
  for (const token of tokens) {
    const m = token.match(/^(-?)label:(.+)$/);
    if (!m) continue;
    const has = thread.labels.indexOf(m[2]) >= 0;
    if (m[1] === "-" && has) return false;
    if (m[1] === "" && !has) return false;
  }
  return true;
}

/**
 * options = {
 *   threads, apiKey, settings, inquiries, props,
 *   claudeStatus / claudeStatuses（数の列）, claudeBody, claudeThrows（true か、呼ぶ回ごとの真偽の列）,
 *   lockBusy, denyWrite, user（実行している人。既定は持ち主）, activeEmail（getActiveUser の値。既定は空）,
 *   fromTrigger（トリガーからの実行。getUi が例外になる）, scopes（マニフェストの許可を差し替える）, triggers（既にあるトリガー）
 * }
 */
export function createSandbox(options) {
  const opts = options || {};
  const trace = { fetched: [], drafts: [], alerts: [], logs: [], labelsCreated: [], attachmentOptions: [], searches: [], scopeErrors: [] };
  const props = {};
  for (const key of Object.keys(opts.props || {})) props[key] = String(opts.props[key]);
  if (opts.apiKey !== undefined) props.ANTHROPIC_API_KEY = String(opts.apiKey);
  const sheets = { 設定: fakeSheet(opts.settings, { denyWrite: opts.denyWrite }) };
  if (opts.inquiries) sheets["問い合わせ"] = fakeSheet(opts.inquiries, { denyWrite: opts.denyWrite });
  const labelStore = [];
  const threads = (opts.threads || []).map((spec) => fakeThread(spec, trace, labelStore));
  const scopes = opts.scopes || MANIFEST.oauthScopes;
  const user = opts.user === undefined ? OWNER : opts.user;
  /** トリガーは { owner, handler, minutes, hours } */
  const triggers = (opts.triggers || []).map((t) => Object.assign({}, t));
  let claudeCalls = 0;

  const need = (scope, what) => {
    if (scopes.indexOf(scope) < 0) {
      trace.scopeErrors.push(what);
      throw new Error("Specified permissions are not sufficient to call " + what + ". Required permissions: " + scope);
    }
  };
  const SHEETS = "https://www.googleapis.com/auth/spreadsheets";
  const GMAIL = "https://mail.google.com/";
  const EMAIL = "https://www.googleapis.com/auth/userinfo.email";
  const FETCH = "https://www.googleapis.com/auth/script.external_request";
  const TRIGGERS = "https://www.googleapis.com/auth/script.scriptapp";
  const UI = "https://www.googleapis.com/auth/script.container.ui";

  const book = {
    getUrl: () => "https://docs.google.com/spreadsheets/d/SHEETID/edit",
    getSpreadsheetTimeZone: () => "Asia/Tokyo",
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Spreadsheet.insertSheet.");
      sheets[name] = fakeSheet([], { denyWrite: opts.denyWrite });
      return sheets[name];
    },
  };
  const menu = { addItem: () => menu, addSeparator: () => menu, addToUi: () => {} };
  const wrapTrigger_ = (t) => ({ getHandlerFunction: () => t.handler, __t: t });
  const timeBuilder_ = (handler) => {
    const built = { owner: user, handler: String(handler), minutes: null, hours: null };
    const b = {
      everyMinutes: (m) => {
        if (MINUTES_ALLOWED.indexOf(m) < 0) throw new Error("The value passed to everyMinutes must be one of 1, 5, 10, 15 or 30.");
        built.minutes = m;
        return b;
      },
      everyHours: (h) => {
        if (HOURS_ALLOWED.indexOf(h) < 0) throw new Error("The value passed to everyHours must be one of 1, 2, 4, 6, 8 or 12.");
        built.hours = h;
        return b;
      },
      create: () => {
        triggers.push(built);
        return wrapTrigger_(built);
      },
    };
    return b;
  };

  const sandbox = {
    Date: FixedDate,
    SpreadsheetApp: {
      getActiveSpreadsheet: () => {
        need(SHEETS, "SpreadsheetApp.getActiveSpreadsheet");
        return book;
      },
      getUi: () => {
        if (opts.fromTrigger) throw new Error("Cannot call SpreadsheetApp.getUi() from this context.");
        need(UI, "SpreadsheetApp.getUi");
        return { alert: (t) => trace.alerts.push(String(t)), createMenu: () => menu };
      },
    },
    GmailApp: {
      search: (query, start, max) => {
        need(GMAIL, "GmailApp.search");
        if (max > 500) throw new Error("Argument max cannot exceed 500.");
        trace.searches.push({ query: query, start: start, max: max });
        return threads.filter((t) => matchesQuery_(t, query)).slice(start, start + max);
      },
      getUserLabelByName: (name) => {
        need(GMAIL, "GmailApp.getUserLabelByName");
        const found = labelStore.find((l) => l.getName() === name);
        return found === undefined ? null : found;
      },
      createLabel: (name) => {
        need(GMAIL, "GmailApp.createLabel");
        if (labelStore.some((l) => l.getName().toLowerCase() === String(name).toLowerCase())) throw new Error("Label name exists or conflicts");
        trace.labelsCreated.push(name);
        const label = { getName: () => String(name) };
        labelStore.push(label);
        return label;
      },
    },
    UrlFetchApp: {
      fetch: (url, fetchOptions) => {
        need(FETCH, "UrlFetchApp.fetch");
        trace.fetched.push({ url: url, payload: fetchOptions.payload, headers: fetchOptions.headers || {}, muted: fetchOptions.muteHttpExceptions === true });
        let status = 200;
        let body = "ok";
        if (url.indexOf("api.anthropic.com") >= 0) {
          claudeCalls += 1;
          const throws = Array.isArray(opts.claudeThrows) ? opts.claudeThrows[Math.min(claudeCalls - 1, opts.claudeThrows.length - 1)] : opts.claudeThrows === true;
          if (throws) throw new Error("Timeout: " + url);
          status = Array.isArray(opts.claudeStatuses) ? opts.claudeStatuses[Math.min(claudeCalls - 1, opts.claudeStatuses.length - 1)] : opts.claudeStatus || 200;
          const answer = opts.claudeBody || { content: [{ type: "text", text: JSON.stringify(opts.claudeAnswer) }], usage: { input_tokens: 1200, output_tokens: 300, cache_read_input_tokens: 700, cache_creation_input_tokens: 0 }, stop_reason: "end_turn" };
          body = JSON.stringify(status === 200 ? answer : { type: "error", error: { type: "overloaded_error", message: "Overloaded" } });
        } else if (opts.notifyStatus) {
          status = opts.notifyStatus;
          body = "error";
        }
        // 本物は muteHttpExceptions が無いと、4xx/5xx を例外にする
        if (status >= 400 && fetchOptions.muteHttpExceptions !== true) throw new Error("Request failed for " + url + " returned code " + status);
        return { getResponseCode: () => status, getContentText: () => body };
      },
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (Object.prototype.hasOwnProperty.call(props, key) ? props[key] : null),
        setProperty: (key, value) => {
          // 本物は文字列にして保存する。1 つ 9KB まで
          const text = String(value);
          if (Buffer.byteLength(key + text, "utf8") > PROPERTY_VALUE_LIMIT) throw new Error("Argument too large: value");
          props[key] = text;
        },
        deleteProperty: (key) => {
          delete props[key];
        },
        getKeys: () => Object.keys(props),
      }),
    },
    LockService: {
      getScriptLock: () => ({
        waitLock: () => {
          // 本物の waitLock は取れないと例外を投げる（tryLock と違う）
          if (opts.lockBusy) throw new Error("Could not acquire lock");
        },
        releaseLock: () => {},
      }),
    },
    ScriptApp: {
      getProjectTriggers: () => {
        need(TRIGGERS, "ScriptApp.getProjectTriggers");
        // 本物は、実行している人が入れたトリガーしか返さない
        return triggers.filter((t) => t.owner === user).map(wrapTrigger_);
      },
      deleteTrigger: (wrapped) => {
        need(TRIGGERS, "ScriptApp.deleteTrigger");
        const i = triggers.indexOf(wrapped.__t);
        if (i >= 0) triggers.splice(i, 1);
      },
      newTrigger: (handler) => {
        need(TRIGGERS, "ScriptApp.newTrigger");
        return { timeBased: () => timeBuilder_(handler) };
      },
    },
    Session: {
      getActiveUser: () => ({
        getEmail: () => {
          need(EMAIL, "Session.getActiveUser().getEmail");
          return opts.activeEmail === undefined ? "" : opts.activeEmail;
        },
      }),
      getEffectiveUser: () => ({
        getEmail: () => {
          need(EMAIL, "Session.getEffectiveUser().getEmail");
          return user;
        },
      }),
    },
    Utilities: { sleep: () => {} },
    Logger: { log: (t) => trace.logs.push(String(t)) },
  };
  return { sandbox: sandbox, sheets: sheets, props: props, trace: trace, threads: threads, triggers: triggers, labels: labelStore };
}

const ENTRY_NAMES = ["triage", "triageNow", "triageSamples", "installTrigger", "removeTrigger", "checkConfig", "showUsage", "onOpen"];

/** Code.gs を偽の GAS の上で走らせ、入口の関数を返す */
export function loadBundle(options) {
  const made = createSandbox(options);
  const context = createContext(made.sandbox);
  const exports = ENTRY_NAMES.map((n) => n + ": " + n).join(", ");
  runInContext(buildSource(root) + "\nglobalThis.__entry = { " + exports + " };\n", context);
  return Object.assign({ entry: made.sandbox.__entry }, made);
}
