import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSource, MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** SOURCE_ORDER のうち、まだ無いファイルは飛ばして束ねる（タスクを順に進めている途中でもテストが通るように） */
function partialSource() {
  return SOURCE_ORDER.filter((n) => existsSync(join(root, "src", n))).map((n) => toGasSource(readFileSync(join(root, "src", n), "utf8"))).join("\n\n");
}

test("import 行は落ち、export だけが剥がれる", () => {
  const input = 'import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\n';
  assert.equal(toGasSource(input), "function f() {\n  return 1;\n}");
});

test("export const / export class も剥がれ、中身の行は触らない", () => {
  const input =
    'export const A = 1;\nexport class B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}\n';
  assert.equal(
    toGasSource(input),
    "const A = 1;\nclass B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}",
  );
});

test("SOURCE_ORDER は 17 個で、先頭は gas_main.js、重複が無い", () => {
  assert.equal(SOURCE_ORDER.length, 17);
  assert.equal(SOURCE_ORDER[0], "gas_main.js");
  assert.deepEqual(SOURCE_ORDER.slice().sort(), Array.from(new Set(SOURCE_ORDER)).sort());
});

test("マニフェストは Asia/Tokyo の V8 で、Gmail と外部通信とトリガーの許可を求める", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
  assert.equal(MANIFEST.webapp, undefined);
  // GmailApp が受け付ける Gmail のスコープは https://mail.google.com/ だけ（gmail.modify では GmailApp.search が動かない）
  assert.deepEqual(MANIFEST.oauthScopes, [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://mail.google.com/",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/script.scriptapp",
    "https://www.googleapis.com/auth/script.container.ui",
  ]);
});

test("つないだ結果に import / export は残らない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(partialSource()), false);
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = partialSource();
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("src にあるファイルは SOURCE_ORDER に全部入っている", () => {
  const files = readdirSync(join(root, "src"))
    .filter((name) => name.endsWith(".js"))
    .sort();
  for (const name of files) assert.ok(SOURCE_ORDER.indexOf(name) >= 0, name + " が SOURCE_ORDER に無い");
});

test("入口の 8 つが gas_main.js にあり、つないだ結果にも入っている", () => {
  const code = partialSource();
  for (const name of ["function triage()", "function triageNow()", "function triageSamples()", "function checkConfig()", "function installTrigger()", "function removeTrigger()", "function showUsage()", "function onOpen()"]) {
    assert.ok(code.includes(name), name + " が無い");
  }
});

test("求める許可は、実際に使うものだけ", () => {
  const code = partialSource();
  assert.ok(code.includes("SpreadsheetApp.getUi()"));
  assert.ok(code.includes("ScriptApp.newTrigger("));
  assert.ok(code.includes("GmailApp.search("));
  assert.equal(code.includes("MailApp"), false, "MailApp を使うなら script.send_mail を足すこと");
  assert.equal(code.includes("ContentService"), false, "ウェブアプリにはしない");
  // https://mail.google.com/ は送信と削除まで含む広い許可なので、その命令が 1 つも無いことを機械で確かめる
  for (const forbidden of ["sendEmail(", ".send(", "moveToTrash(", "deleteLabel("]) {
    assert.equal(code.includes(forbidden), false, forbidden + " は使わない（下書きまでにとどめる）");
  }
});
