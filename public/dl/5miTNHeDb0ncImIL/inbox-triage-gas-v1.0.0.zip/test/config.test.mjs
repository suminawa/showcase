import { test } from "node:test";
import assert from "node:assert/strict";
import { CATEGORY_HINTS, CONFIG_KEYS, ConfigError, DEFAULT_CATEGORIES, DEFAULT_CONFIG, INTERVALS, parseConfig } from "../src/config.js";

const BASE = [
  ["項目", "値"],
  ["会社名", "みなと商会"],
  ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
];

test("CONFIG_KEYS は 22 個で、会社名から始まる", () => {
  assert.equal(CONFIG_KEYS.length, 22);
  assert.equal(CONFIG_KEYS[0], "会社名");
  assert.deepEqual(CONFIG_KEYS.slice().sort(), Array.from(new Set(CONFIG_KEYS)).sort());
});

test("既定の分類は 8 つで、末尾が「その他」。それぞれに目安がある", () => {
  assert.equal(DEFAULT_CATEGORIES.length, 8);
  assert.equal(DEFAULT_CATEGORIES[DEFAULT_CATEGORIES.length - 1], "その他");
  for (const name of DEFAULT_CATEGORIES) assert.equal(typeof CATEGORY_HINTS[name], "string", name + " の目安が無い");
});

test("会社名と Slack だけ書けば、残りは既定値", () => {
  const config = parseConfig(BASE);
  assert.deepEqual(
    config,
    Object.assign({}, DEFAULT_CONFIG, {
      companyName: "みなと商会",
      slackWebhookUrl: "https://hooks.slack.com/services/T000/B000/xxxx",
    }),
  );
  assert.deepEqual(config.categories, DEFAULT_CATEGORIES);
});

test("会社名が無いと止める", () => {
  assert.throws(() => parseConfig([["Slack Webhook URL", "https://hooks.slack.com/x"]]), ConfigError);
  assert.throws(() => parseConfig(BASE.concat([["会社名", "  "]])), /会社名/);
});

test("分類はカンマ（半角・全角）で区切り、末尾に「その他」が無ければ足す。空は落とす", () => {
  const config = parseConfig(BASE.concat([["分類", "見積もり, 苦情、 、営業"]]));
  assert.deepEqual(config.categories, ["見積もり", "苦情", "営業", "その他"]);
  assert.deepEqual(parseConfig(BASE.concat([["分類", "A, その他, B"]])).categories, ["A", "その他", "B"]);
});

test("分類に / は使えない（Gmail のラベルが入れ子になる）", () => {
  assert.throws(() => parseConfig(BASE.concat([["分類", "修理/点検, 質問"]])), /\/ は使えません（Gmail のラベルが入れ子になります）/);
  assert.throws(() => parseConfig(BASE.concat([["分類", "修理/点検, 質問"]])), ConfigError);
});

test("分類が長すぎるときは止める（50 字まで）", () => {
  assert.equal(parseConfig(BASE.concat([["分類", "あ".repeat(50)]])).categories[0].length, 50);
  assert.throws(() => parseConfig(BASE.concat([["分類", "あ".repeat(51)]])), /分類/);
});

test("下書きを作らない分類は、分類の一覧に無いものを書いても止めない（無視する）", () => {
  const config = parseConfig(BASE.concat([["下書きを作らない分類", "営業や勧誘, 存在しない"]]));
  assert.deepEqual(config.noDraftCategories, ["営業や勧誘"]);
});

test("数の項目は整数で、範囲の外は止める", () => {
  assert.equal(parseConfig(BASE.concat([["1 回に読む数", "5"]])).perRun, 5);
  assert.equal(parseConfig(BASE.concat([["1 日の上限", "1000"]])).perDay, 1000);
  assert.equal(parseConfig(BASE.concat([["本文の上限文字数", "8000"]])).bodyLimit, 8000);
  assert.throws(() => parseConfig(BASE.concat([["1 回に読む数", "0"]])), /1 回に読む数/);
  assert.throws(() => parseConfig(BASE.concat([["1 回に読む数", "101"]])), /1 回に読む数/);
  assert.throws(() => parseConfig(BASE.concat([["1 日の上限", "abc"]])), /1 日の上限/);
  assert.throws(() => parseConfig(BASE.concat([["本文の上限文字数", "100"]])), /本文の上限文字数/);
});

test("間隔は 5 / 10 / 15 / 30 / 60 のどれか", () => {
  assert.deepEqual(INTERVALS, [5, 10, 15, 30, 60]);
  assert.equal(parseConfig(BASE.concat([["間隔（分）", "30"]])).intervalMinutes, 30);
  assert.equal(parseConfig(BASE.concat([["間隔(分)", "10"]])).intervalMinutes, 10);
  assert.throws(() => parseConfig(BASE.concat([["間隔（分）", "7"]])), /間隔/);
});

test("モデルは claude- で始まる名前だけ", () => {
  assert.equal(parseConfig(BASE.concat([["モデル", "claude-sonnet-5"]])).model, "claude-sonnet-5");
  assert.throws(() => parseConfig(BASE.concat([["モデル", "gpt-5"]])), /モデル/);
});

test("下書きを作る・エラー通知は TRUE / FALSE / はい / いいえ", () => {
  assert.equal(parseConfig(BASE.concat([["下書きを作る", "FALSE"]])).makeDrafts, false);
  assert.equal(parseConfig(BASE.concat([["下書きを作る", "いいえ"]])).makeDrafts, false);
  assert.equal(parseConfig(BASE.concat([["エラー通知", "しない"]])).errorNotify, false);
  assert.throws(() => parseConfig(BASE.concat([["下書きを作る", "たぶん"]])), /下書きを作る/);
});

test("通知先は S3 と同じ決まり（slack / discord / line、宛先の空と https）", () => {
  assert.deepEqual(parseConfig(BASE.concat([["通知先", "slack, line"], ["LINE チャネルアクセストークン", "t"], ["LINE 送信先 ID", "U1"]])).targets, ["slack", "line"]);
  assert.throws(() => parseConfig(BASE.concat([["通知先", "teams"]])), /通知先/);
  assert.throws(() => parseConfig(BASE.concat([["通知先", "discord"]])), /Discord Webhook URL/);
  assert.throws(() => parseConfig([["会社名", "みなと商会"], ["Slack Webhook URL", "http://hooks"]]), /https/);
  assert.deepEqual(parseConfig([["会社名", "みなと商会"], ["通知先", ""]]).targets, []);
});

test("検索条件と除外の差出人は空欄で「使わない」にできる", () => {
  assert.equal(parseConfig(BASE.concat([["検索条件", ""]])).query, DEFAULT_CONFIG.query);
  assert.deepEqual(parseConfig(BASE.concat([["除外する差出人", ""]])).excludedSenders, []);
  assert.deepEqual(parseConfig(BASE.concat([["除外する差出人", "info@example.com、 ads@"]])).excludedSenders, ["info@example.com", "ads@"]);
});

test("知らない行は無視し、項目名の空白と括弧の揺れは吸収する", () => {
  const config = parseConfig(BASE.concat([["メモ", "自由に書ける"], [" 会社名 ", "さくら設備株式会社"], ["営業時間", "10:00-19:00（水曜定休）"]]));
  assert.equal(config.companyName, "さくら設備株式会社");
  assert.equal(config.businessHours, "10:00-19:00（水曜定休）");
});
