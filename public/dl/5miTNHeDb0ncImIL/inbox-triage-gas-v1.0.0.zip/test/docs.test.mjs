import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CONFIG_KEYS, DEFAULT_CONFIG, parseConfig } from "../src/config.js";
import { HEADERS } from "../src/rows.js";
import { buildSystemPrompt, buildUserText } from "../src/prompt.js";
import { buildInput } from "../src/mail.js";
import { buildNotificationText } from "../src/message.js";
import { SAMPLE_ANSWERS, SAMPLE_EMAILS } from "../src/samples.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function read(name) {
  return readFileSync(join(root, name), "utf8");
}

function settingsTableKeys(readme) {
  const keys = [];
  const lines = readme.split("\n");
  let inside = false;
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (line.indexOf("| 項目 | 既定値 | 意味 |") === 0) {
      inside = true;
      continue;
    }
    if (!inside) continue;
    if (line.indexOf("|") !== 0) break;
    if (/^\|\s*-/.test(line)) continue;
    keys.push(line.split("|")[1].trim());
  }
  return keys;
}

const sampleConfig = () => parseConfig(rowsOf(read("samples/settings-sample.csv")));

test("README の設定表と CONFIG_KEYS と見本の設定シートは、同じ 22 項目が同じ順に並ぶ", () => {
  assert.deepEqual(rowsOf(read("samples/settings-sample.csv")).slice(1).map((r) => r[0]), CONFIG_KEYS);
  assert.deepEqual(settingsTableKeys(read("README.ja.md")), CONFIG_KEYS);
});

test("見本の設定シートを読むと、会社名以外は既定値で、通知先は空（手順 6 で初めて有効になる）", () => {
  assert.deepEqual(sampleConfig(), Object.assign({}, DEFAULT_CONFIG, { companyName: "みなと商会", targets: [] }));
  // 偽の Webhook URL を積むと、買い手が手順 6 を飛ばしたときに通知だけが黙って落ちる
  assert.equal(read("samples/settings-sample.csv").includes("hooks.slack.com"), false);
});

test("見本の問い合わせシートの見出しは HEADERS と同じ", () => {
  assert.deepEqual(rowsOf(read("samples/inquiries-sample.csv"))[0], HEADERS);
});

test("prompt-sample.md は実際に送る system と user と同じ", () => {
  const config = sampleConfig();
  const e = SAMPLE_EMAILS[0];
  const input = buildInput({ from: e.from, subject: e.subject, date: new Date(e.date), plainBody: e.plainBody, htmlBody: "", attachmentNames: e.attachmentNames }, config);
  const md = read("samples/prompt-sample.md");
  assert.ok(md.includes("```\n" + buildSystemPrompt(config) + "\n```"), "system が食い違っている");
  assert.ok(md.includes("```\n" + buildUserText(input) + "\n```"), "user が食い違っている");
});

test("README に載せた通知の例は、見本から実際に出るものと同じ", () => {
  const config = sampleConfig();
  const items = ["quote-01", "complaint-01"].map((id, i) => {
    const e = SAMPLE_EMAILS.find((x) => x.id === id);
    return { answer: SAMPLE_ANSWERS[id], input: buildInput({ from: e.from, subject: e.subject, date: new Date(e.date), plainBody: e.plainBody, htmlBody: "", attachmentNames: e.attachmentNames }, config), receipt: "20260914-00" + (i + 1), rowNumber: i + 2 };
  });
  const text = buildNotificationText(config, items);
  assert.ok(read("README.ja.md").includes(text), "README の通知の例が食い違っている:\n" + text);
});

test("README・LICENSE・CHANGELOG は敬体で、鍵の値や実在の名前を含まない", () => {
  for (const name of ["README.ja.md", "LICENSE.md", "CHANGELOG.md"]) {
    const text = read(name);
    assert.equal(/sk-ant-[A-Za-z0-9]{8,}/.test(text), false, name + " に鍵らしい字がある");
    assert.equal(/鉋|棟梁/.test(text), false, name);
    assert.equal(/業界初|圧倒的|完全に|100%/.test(text), false, name + " に大げさな言葉がある");
  }
  assert.ok(read("README.ja.md").includes("hello@suminawa.dev"));
  assert.ok(read("CHANGELOG.md").includes("## 1.0.0"));
  assert.ok(read("LICENSE.md").includes("AI 問い合わせ整理キット"));
});
