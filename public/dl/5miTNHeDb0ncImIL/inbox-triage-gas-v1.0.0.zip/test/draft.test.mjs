import { test } from "node:test";
import assert from "node:assert/strict";
import { DRAFT_LIMIT, buildDraftBody, shouldDraft } from "../src/draft.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG, { companyName: "みなと商会", signature: "みなと商会 港 花子\n03-0000-0000" });
const answer = { category: "見積もり依頼", replyDraft: "みなと 太郎 様\n\nお問い合わせありがとうございます。確認のうえご連絡します。" };

test("下書きは、作る設定で、作らない分類でなく、返信案があるときだけ", () => {
  assert.equal(shouldDraft(answer, config), true);
  assert.equal(shouldDraft(Object.assign({}, answer, { category: "営業や勧誘" }), config), false);
  assert.equal(shouldDraft(Object.assign({}, answer, { replyDraft: "  " }), config), false);
  assert.equal(shouldDraft(answer, Object.assign({}, config, { makeDrafts: false })), false);
});

test("本文は返信案 + 空行 + 署名。署名が空なら返信案だけ", () => {
  assert.equal(buildDraftBody(answer, config), answer.replyDraft + "\n\nみなと商会 港 花子\n03-0000-0000");
  assert.equal(buildDraftBody(answer, Object.assign({}, config, { signature: "" })), answer.replyDraft);
});

test("300 字を超える返信案は、上限の手前の「。」で切る", () => {
  assert.equal(DRAFT_LIMIT, 300);
  const sentence = "ご連絡ありがとうございます。".repeat(30); // 420 字
  const body = buildDraftBody({ category: "質問", replyDraft: sentence }, Object.assign({}, config, { signature: "" }));
  assert.ok(body.length <= 300);
  assert.ok(body.endsWith("。"));
  const noPeriod = "あ".repeat(400);
  assert.equal(buildDraftBody({ category: "質問", replyDraft: noPeriod }, Object.assign({}, config, { signature: "" })).length, 300);
});
