import { test } from "node:test";
import assert from "node:assert/strict";
import { URGENCIES, buildSchema, fallbackAnswer, normalizeAnswer, parseAnswer } from "../src/schema.js";
import { DEFAULT_CATEGORIES, DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG, { companyName: "みなと商会" });
const GOOD = {
  category: "見積もり依頼",
  urgency: "中",
  summary: "会議室の内装工事の見積もり依頼。図面つき",
  request: "見積書の送付",
  deadline: "2026-09-30",
  person: { name: "みなと 太郎", company: "みなと商会", phone: "03-0000-0001" },
  replyDraft: "みなと 太郎 様\n\nお問い合わせありがとうございます。",
  needsHuman: false,
  confidence: 0.92,
  notes: "",
};

test("JSON Schema は 10 項目すべて必須で、追加を許さない", () => {
  const schema = buildSchema(DEFAULT_CATEGORIES);
  assert.equal(schema.type, "object");
  assert.equal(schema.additionalProperties, false);
  assert.deepEqual(schema.required, ["category", "urgency", "summary", "request", "deadline", "person", "replyDraft", "needsHuman", "confidence", "notes"]);
  assert.deepEqual(schema.properties.category.enum, DEFAULT_CATEGORIES);
  assert.deepEqual(schema.properties.urgency.enum, URGENCIES);
  // 「文字列か null」は anyOf で書く（型の配列ではなく、structured outputs が示している書き方）
  assert.deepEqual(schema.properties.deadline.anyOf, [{ type: "string" }, { type: "null" }]);
  assert.equal(schema.properties.deadline.type, undefined);
  assert.deepEqual(schema.properties.person.properties.name.anyOf, [{ type: "string" }, { type: "null" }]);
  assert.deepEqual(schema.properties.person.required, ["name", "company", "phone"]);
  assert.equal(schema.properties.person.additionalProperties, false);
  assert.equal(schema.properties.needsHuman.type, "boolean");
  assert.equal(schema.properties.confidence.type, "number");
});

test("正しい答えはそのまま通る", () => {
  assert.deepEqual(normalizeAnswer(GOOD, config), GOOD);
  const parsed = parseAnswer(JSON.stringify(GOOD), config);
  assert.equal(parsed.ok, true);
  assert.deepEqual(parsed.answer, GOOD);
});

test("分類が一覧に無ければ「その他」、緊急度が変なら「中」", () => {
  const answer = normalizeAnswer(Object.assign({}, GOOD, { category: "謎", urgency: "超" }), config);
  assert.equal(answer.category, "その他");
  assert.equal(answer.urgency, "中");
});

test("期限は YYYY-MM-DD だけ。それ以外は null", () => {
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "9/30" }), config).deadline, null);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "2026-13-01" }), config).deadline, null);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "" }), config).deadline, null);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "2026-09-30" }), config).deadline, "2026-09-30");
  // 暦に無い日付も落とす（dates.js と同じ照合）
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "2026-02-30" }), config).deadline, null);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "2026-04-31" }), config).deadline, null);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { deadline: "2028-02-29" }), config).deadline, "2028-02-29");
});

test("文字の項目は前後の空白を落とし、要約は 200 字で切る。人の情報は空なら null", () => {
  const answer = normalizeAnswer(Object.assign({}, GOOD, { summary: "  " + "あ".repeat(250) + "  ", request: " 送付 ", person: { name: " ", company: null, phone: "03-0000-0001 " }, notes: null }), config);
  assert.equal(answer.summary.length, 200);
  assert.equal(answer.request, "送付");
  assert.deepEqual(answer.person, { name: null, company: null, phone: "03-0000-0001" });
  assert.equal(answer.notes, "");
});

test("needsHuman と confidence は型を直す", () => {
  const answer = normalizeAnswer(Object.assign({}, GOOD, { needsHuman: "true", confidence: 1.7 }), config);
  assert.equal(answer.needsHuman, true);
  assert.equal(answer.confidence, 1);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { confidence: "abc" }), config).confidence, 0);
  assert.equal(normalizeAnswer(Object.assign({}, GOOD, { needsHuman: 0 }), config).needsHuman, false);
});

test("壊れた JSON や形の違う答えは、要対応の「その他」に落ちる", () => {
  const broken = parseAnswer("{not json", config);
  assert.equal(broken.ok, false);
  assert.equal(broken.reason, "json");
  assert.deepEqual(broken.answer, fallbackAnswer("json"));
  assert.equal(broken.answer.category, "その他");
  assert.equal(broken.answer.needsHuman, true);
  assert.equal(broken.answer.replyDraft, "");
  assert.equal(broken.answer.confidence, 0);
  const notObject = parseAnswer("[1,2]", config);
  assert.equal(notObject.ok, false);
  assert.equal(notObject.reason, "shape");
  assert.equal(parseAnswer("", config).reason, "json");
});
