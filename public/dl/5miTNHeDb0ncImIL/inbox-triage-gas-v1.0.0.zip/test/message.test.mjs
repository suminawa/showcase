import { test } from "node:test";
import assert from "node:assert/strict";
import { ATTENTION, buildErrorText, buildItemLine, buildNotificationText, buildPayload, isAttention } from "../src/message.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG, { companyName: "みなと商会" });
function item(over) {
  return Object.assign(
    {
      answer: { category: "見積もり依頼", urgency: "中", summary: "会議室の内装工事の見積もり依頼", needsHuman: false, person: { name: "みなと 太郎", company: "みなと商会", phone: null } },
      input: { from: { name: "みなと 太郎", address: "taro@example.com" }, subject: "見積もりのお願い" },
      receipt: "20260914-001",
      rowNumber: 12,
    },
    over,
  );
}

test("要対応は、緊急度「高」か needsHuman", () => {
  assert.equal(ATTENTION, "⚠ 要対応");
  assert.equal(isAttention({ urgency: "高", needsHuman: false }), true);
  assert.equal(isAttention({ urgency: "低", needsHuman: true }), true);
  assert.equal(isAttention({ urgency: "中", needsHuman: false }), false);
});

test("1 件の行: [緊急度] 分類｜要約 — 差出人（会社）→ 行 N", () => {
  assert.equal(buildItemLine(item()), "[中] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎（みなと商会） → 行 12");
  const noPerson = item({ answer: Object.assign({}, item().answer, { person: { name: null, company: null, phone: null } }) });
  assert.equal(buildItemLine(noPerson), "[中] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎 → 行 12");
  const attention = item({ answer: Object.assign({}, item().answer, { urgency: "高" }) });
  assert.equal(buildItemLine(attention), "⚠ 要対応 [高] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎（みなと商会） → 行 12");
});

test("シートの行へのリンクがあれば、Slack はリンク記法、Discord と LINE は URL をそのまま", () => {
  const linked = item({ rowUrl: "https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12" });
  assert.ok(buildItemLine(linked, "slack").endsWith(" → <https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12|行 12>"));
  assert.ok(buildItemLine(linked, "discord").endsWith(" → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12"));
  assert.ok(buildItemLine(linked, "line").endsWith(" → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12"));
  // リンクが無いとき（見本のメールなど）と、宛先を渡さないときは行番号だけ
  assert.ok(buildItemLine(item({ rowUrl: "" }), "slack").endsWith(" → 行 12"));
  assert.ok(buildItemLine(item()).endsWith(" → 行 12"));
  assert.ok(buildNotificationText(config, [linked], "slack").includes("|行 12>"));
  assert.ok(buildNotificationText(config, [linked]).endsWith(" → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12"));
});

test("通知は件数と一覧を差し込み、要対応を先頭に並べる", () => {
  const items = [item(), item({ receipt: "20260914-002", rowNumber: 13, answer: Object.assign({}, item().answer, { needsHuman: true, category: "クレーム", summary: "納品が遅れている" }) })];
  const text = buildNotificationText(config, items);
  assert.equal(text, "新しい問い合わせ 2 件\n⚠ 要対応 [中] クレーム｜納品が遅れている — みなと 太郎（みなと商会） → 行 13\n[中] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎（みなと商会） → 行 12");
  assert.equal(buildNotificationText(Object.assign({}, config, { notifyTemplate: "{件数} 件です" }), items), "2 件です");
});

test("本文はどこにも載らない（要約と差出人だけ）", () => {
  const text = buildNotificationText(config, [item({ input: { from: { name: "A", address: "a@example.com" }, subject: "件名", body: "秘密の本文" } })]);
  assert.equal(text.includes("秘密の本文"), false);
  assert.equal(text.includes("a@example.com"), false);
});

test("エラーの文と、宛先ごとの payload は S3 と同じ形", () => {
  assert.equal(buildErrorText(new Error("鍵が無効です"), "2026-09-14 10:32:05"), "【問い合わせ整理｜エラー】2026-09-14 10:32:05\n整理を実行できませんでした: 鍵が無効です\nスプレッドシートの「設定」シートと、スクリプト プロパティの ANTHROPIC_API_KEY を確かめてください。");
  assert.deepEqual(buildPayload("t", "slack"), { text: "t" });
  assert.deepEqual(buildPayload("t", "discord"), { content: "t" });
  assert.deepEqual(buildPayload("t", "line", { lineTo: "U1" }), { to: "U1", messages: [{ type: "text", text: "t" }] });
  assert.ok(buildPayload("x".repeat(6000), "line").messages[0].text.length <= 5000);
});
