import { test } from "node:test";
import assert from "node:assert/strict";
import { formatReceipt, nextReceipt, parseReceipt } from "../src/receipt.js";

test("受付番号は日付 + 3 桁の連番", () => {
  assert.equal(formatReceipt("2026-09-14", 1), "20260914-001");
  assert.equal(formatReceipt("2026-09-14", 42), "20260914-042");
  assert.equal(formatReceipt("2026-09-14", 1000), "20260914-1000");
  assert.equal(formatReceipt("2026-09-14", 0), "20260914-001");
});

test("受付番号を読み戻せる。読めなければ null", () => {
  assert.deepEqual(parseReceipt("20260914-003"), { dateKey: "2026-09-14", sequence: 3 });
  assert.equal(parseReceipt(""), null);
  assert.equal(parseReceipt("2026-09-14-3"), null);
  assert.equal(parseReceipt(null), null);
});

test("同じ日なら次の番号、日が変われば 001", () => {
  assert.equal(nextReceipt("20260914-003", "2026-09-14"), "20260914-004");
  assert.equal(nextReceipt("20260914-003", "2026-09-15"), "20260915-001");
  assert.equal(nextReceipt("", "2026-09-15"), "20260915-001");
});
