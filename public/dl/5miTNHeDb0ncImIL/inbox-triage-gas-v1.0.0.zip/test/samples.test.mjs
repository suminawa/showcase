import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { SAMPLE_ANSWERS, SAMPLE_EMAILS } from "../src/samples.js";
import { DEFAULT_CONFIG } from "../src/config.js";
import { normalizeAnswer } from "../src/schema.js";
import { buildInput, isBulk } from "../src/mail.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const config = Object.assign({}, DEFAULT_CONFIG, { companyName: "みなと商会" });

test("見本は 8 通で、id が重ならず、7 通に答えがある（配信メールには無い）", () => {
  assert.equal(SAMPLE_EMAILS.length, 8);
  const ids = SAMPLE_EMAILS.map((e) => e.id);
  assert.deepEqual(ids, Array.from(new Set(ids)));
  const bulk = SAMPLE_EMAILS.filter((e) => isBulk(e.headers));
  assert.equal(bulk.length, 1);
  assert.equal(bulk[0].id, "newsletter-01");
  assert.deepEqual(Object.keys(SAMPLE_ANSWERS).sort(), ids.filter((id) => id !== "newsletter-01").sort());
});

test("答えは補正しても変わらない（型と一覧に合っている）", () => {
  for (const id of Object.keys(SAMPLE_ANSWERS)) {
    assert.deepEqual(normalizeAnswer(SAMPLE_ANSWERS[id], config), SAMPLE_ANSWERS[id], id);
  }
});

test("見本は入力に整えられ、本文が 4,000 字を超えない", () => {
  for (const e of SAMPLE_EMAILS) {
    const input = buildInput({ from: e.from, subject: e.subject, date: new Date(e.date), plainBody: e.plainBody, htmlBody: "", attachmentNames: e.attachmentNames }, config);
    assert.ok(input.from.address.includes("@"), e.id);
    assert.ok(input.body.length > 0 && input.body.length <= 4000, e.id);
  }
});

test("架空の会社・電話・住所だけ。返信案は敬体", () => {
  const text = JSON.stringify(SAMPLE_EMAILS) + JSON.stringify(SAMPLE_ANSWERS);
  assert.equal(/\d{2,4}-\d{2,4}-\d{4}/.test(text.replace(/03-0000-\d{4}/g, "")), false, "架空でない電話番号がある");
  for (const id of Object.keys(SAMPLE_ANSWERS)) {
    const draft = SAMPLE_ANSWERS[id].replyDraft;
    assert.ok(/(ます|ません|ください|ございます|いたします)。$/.test(draft.trim()), id + " の返信案が敬体で終わっていない");
    assert.ok(draft.length <= 300, id + " の返信案が長い");
  }
});

test("samples/emails.json と expected.json は src/samples.js と同じ", () => {
  assert.deepEqual(JSON.parse(readFileSync(join(root, "samples/emails.json"), "utf8")), SAMPLE_EMAILS);
  assert.deepEqual(JSON.parse(readFileSync(join(root, "samples/expected.json"), "utf8")), SAMPLE_ANSWERS);
});
