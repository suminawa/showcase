/** Slack / Discord の Webhook と、LINE の push message に 1 通送る。 */
import { buildPayload } from "./message.js";

const LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push";

function post_(url, payload, headers) {
  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  if (headers) options.headers = headers;
  const response = UrlFetchApp.fetch(url, options);
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(status + " が返りました: " + String(response.getContentText()).slice(0, 200));
  }
}

/** formatted が true なら、text は Slack 用に組み立て済み（buildNotificationText の "slack"）。ほかは送る前に & < > を文字参照にする */
export function postSlack_(url, text, formatted) {
  post_(url, buildPayload(text, "slack", { formatted: formatted === true }));
}

export function postDiscord_(url, text) {
  post_(url, buildPayload(text, "discord"));
}

export function pushLine_(token, to, text) {
  post_(LINE_PUSH_URL, buildPayload(text, "line", { lineTo: to }), { Authorization: "Bearer " + token });
}

/**
 * 設定の通知先すべてに送る。1 つが失敗しても残りには送り、失敗は実行ログに残す。返り値: 送れた宛先の数。
 * text は文字列か、宛先の名前を受けて文面を返す関数（Slack だけリンクの書き方が違うため）。
 * 関数は、ただの文字列か、その宛先向けに組み立て済みの文を { text, formatted: true } で返す
 * （Slack なら buildNotificationText の "slack"。& < > の文字参照とリンクがもう入っている）。
 * 組み立て済みと明かされていない文は、関数が返したものでも、Slack へ送る前に文字参照にする。
 */
export function notifyAll_(config, text) {
  let sent = 0;
  for (let i = 0; i < config.targets.length; i += 1) {
    const target = config.targets[i];
    const made = typeof text === "function" ? text(target) : text;
    const formatted = made !== null && typeof made === "object" && made.formatted === true;
    const body = formatted ? String(made.text) : String(made);
    try {
      if (target === "slack") postSlack_(config.slackWebhookUrl, body, formatted);
      else if (target === "discord") postDiscord_(config.discordWebhookUrl, body);
      else if (target === "line") pushLine_(config.lineToken, config.lineTo, body);
      else continue;
      sent += 1;
    } catch (error) {
      Logger.log("問い合わせ整理: " + target + " に送れませんでした: " + error);
    }
  }
  return sent;
}
