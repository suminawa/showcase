import { test } from "node:test";
import assert from "node:assert/strict";
import { ATTENTION, buildErrorText, buildItemLine, buildNotificationText, buildPayload, isAttention } from "../src/message.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG, { companyName: "みなと商会" });
function item(over) {
  return Object.assign(
    {
      answer: { category: "見積もり依頼", urgency: "中", summary: "会議室の内装工事の見積もり依頼", needsHuman: false, person: { name: "みなと 太郎", company: "みなと商会", phone: null } },
      input: { from: { name: "みなと 太郎", address: "taro@example.com" }, subject: "見積もりのお願い" },
      receipt: "20260914-001",
      rowNumber: 12,
    },
    over,
  );
}

test("要対応は、緊急度「高」か needsHuman", () => {
  assert.equal(ATTENTION, "⚠ 要対応");
  assert.equal(isAttention({ urgency: "高", needsHuman: false }), true);
  assert.equal(isAttention({ urgency: "低", needsHuman: true }), true);
  assert.equal(isAttention({ urgency: "中", needsHuman: false }), false);
});

test("1 件の行: [緊急度] 分類｜要約 — 差出人（会社）→ 行 N", () => {
  assert.equal(buildItemLine(item()), "[中] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎（みなと商会） → 行 12");
  const noPerson = item({ answer: Object.assign({}, item().answer, { person: { name: null, company: null, phone: null } }) });
  assert.equal(buildItemLine(noPerson), "[中] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎 → 行 12");
  const attention = item({ answer: Object.assign({}, item().answer, { urgency: "高" }) });
  assert.equal(buildItemLine(attention), "⚠ 要対応 [高] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎（みなと商会） → 行 12");
});

test("シートの行へのリンクがあれば、Slack はリンク記法、Discord と LINE は URL をそのまま", () => {
  const linked = item({ rowUrl: "https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12" });
  // Slack の文では URL の & も文字参照にする（Slack が & に戻して開く）
  assert.ok(buildItemLine(linked, "slack").endsWith(" → <https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&amp;range=A12|行 12>"));
  assert.ok(buildItemLine(linked, "discord").endsWith(" → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12"));
  assert.ok(buildItemLine(linked, "line").endsWith(" → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12"));
  // リンクが無いとき（見本のメールなど）と、宛先を渡さないときは行番号だけ
  assert.ok(buildItemLine(item({ rowUrl: "" }), "slack").endsWith(" → 行 12"));
  assert.ok(buildItemLine(item()).endsWith(" → 行 12"));
  assert.ok(buildNotificationText(config, [linked], "slack").includes("|行 12>"));
  assert.ok(buildNotificationText(config, [linked]).endsWith(" → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12"));
});

test("通知は件数と一覧を差し込み、要対応を先頭に並べる", () => {
  const items = [item(), item({ receipt: "20260914-002", rowNumber: 13, answer: Object.assign({}, item().answer, { needsHuman: true, category: "クレーム", summary: "納品が遅れている" }) })];
  const text = buildNotificationText(config, items);
  assert.equal(text, "新しい問い合わせ 2 件\n⚠ 要対応 [中] クレーム｜納品が遅れている — みなと 太郎（みなと商会） → 行 13\n[中] 見積もり依頼｜会議室の内装工事の見積もり依頼 — みなと 太郎（みなと商会） → 行 12");
  assert.equal(buildNotificationText(Object.assign({}, config, { notifyTemplate: "{件数} 件です" }), items), "2 件です");
});

test("本文はどこにも載らない（要約と差出人だけ）", () => {
  const text = buildNotificationText(config, [item({ input: { from: { name: "A", address: "a@example.com" }, subject: "件名", body: "秘密の本文" } })]);
  assert.equal(text.includes("秘密の本文"), false);
  assert.equal(text.includes("a@example.com"), false);
});

test("エラーの文と、宛先ごとの payload は S3 と同じ形", () => {
  assert.equal(buildErrorText(new Error("鍵が無効です"), "2026-09-14 10:32:05"), "【問い合わせ整理｜エラー】2026-09-14 10:32:05\n整理を実行できませんでした: 鍵が無効です\nスプレッドシートの「設定」シートと、スクリプト プロパティの ANTHROPIC_API_KEY を確かめてください。");
  assert.deepEqual(buildPayload("t", "slack"), { text: "t" });
  assert.deepEqual(buildPayload("t", "discord"), { content: "t", allowed_mentions: { parse: [] } });
  assert.deepEqual(buildPayload("t", "line", { lineTo: "U1" }), { to: "U1", messages: [{ type: "text", text: "t" }] });
  assert.ok(buildPayload("x".repeat(6000), "line").messages[0].text.length <= 5000);
});

test("差出人名・会社・要約の字は Slack で呼び出しにならない（& < > を文字参照にし、行へのリンクと改行は残す）", () => {
  const answer = Object.assign({}, item().answer, { summary: "<@U123> への返事 & 見積", person: { name: "<!channel> 太郎", company: "A&B商会", phone: null } });
  const linked = item({ answer: answer, rowUrl: "https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12" });
  const url = "https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&amp;range=A12";
  assert.equal(buildItemLine(linked, "slack"), "[中] 見積もり依頼｜&lt;@U123&gt; への返事 &amp; 見積 — &lt;!channel&gt; 太郎（A&amp;B商会） → <" + url + "|行 12>");
  // Discord と LINE は字のまま（Discord は allowed_mentions で止める）
  assert.equal(buildItemLine(linked, "discord"), "[中] 見積もり依頼｜<@U123> への返事 & 見積 — <!channel> 太郎（A&B商会） → 行 12 https://docs.google.com/spreadsheets/d/ABC/edit#gid=123&range=A12");
  // 通知の文面（設定シートに書いたもの）の & < > も字のまま届く
  const custom = Object.assign({}, config, { notifyTemplate: "<!here> 問い合わせ & 相談 {件数} 件\n{一覧}" });
  const text = buildNotificationText(custom, [linked], "slack");
  assert.equal(text, "&lt;!here&gt; 問い合わせ &amp; 相談 1 件\n[中] 見積もり依頼｜&lt;@U123&gt; への返事 &amp; 見積 — &lt;!channel&gt; 太郎（A&amp;B商会） → <" + url + "|行 12>");
  // 組み立て済みの Slack の文は、重ねて変えずに送る
  assert.deepEqual(buildPayload(text, "slack", { formatted: true }), { text: text });
  const discord = buildNotificationText(custom, [linked], "discord");
  assert.deepEqual(buildPayload(discord, "discord"), { content: discord, allowed_mentions: { parse: [] } });
});

test("ただの文（エラーの文など）は、Slack へ送る前に & < > を文字参照にする", () => {
  const text = buildErrorText(new Error("「モデル」は claude- で始まる名前です: <!channel> & <@U123>"), "2026-09-14 10:32:05");
  const slack = buildPayload(text, "slack").text;
  assert.ok(slack.startsWith("【問い合わせ整理｜エラー】2026-09-14 10:32:05\n整理を実行できませんでした: 「モデル」は claude- で始まる名前です: &lt;!channel&gt; &amp; &lt;@U123&gt;\n"));
  assert.equal(slack.includes("<"), false);
  assert.deepEqual(buildPayload("<!channel>", "slack", { formatted: false }), { text: "&lt;!channel&gt;" });
  assert.deepEqual(buildPayload("@everyone", "discord"), { content: "@everyone", allowed_mentions: { parse: [] } });
});

test("Slack は 39,000 字で切り、切り口で &amp; も行へのリンクも割らない", () => {
  for (const head of ["", "x", "xx", "xxx", "xxxx"]) {
    const text = buildPayload(head + "&".repeat(20000), "slack").text;
    assert.ok(text.length <= 39000, head.length + " 字ずらし: " + text.length);
    assert.ok(/^x{0,4}(&amp;)+\n…（以下省略）$/.test(text), head.length + " 字ずらし: " + text.slice(-20));
  }
  const link = "<https://x/?a=1&amp;b=2|行 1>\n";
  for (let shift = 0; shift < link.length; shift += 1) {
    const text = buildPayload("x".repeat(shift) + link.repeat(2000), "slack", { formatted: true }).text;
    assert.ok(text.length <= 39000, shift + " 字ずらし: " + text.length);
    assert.ok(text.endsWith("\n…（以下省略）"));
    const kept = text.slice(0, text.length - "\n…（以下省略）".length);
    assert.equal(/<[^<>]*$/.test(kept), false, shift + " 字ずらし: リンクが割れた " + kept.slice(-30));
    assert.equal(/&[a-z]{0,3}$/.test(kept), false, shift + " 字ずらし: 文字参照が割れた " + kept.slice(-30));
  }
});
