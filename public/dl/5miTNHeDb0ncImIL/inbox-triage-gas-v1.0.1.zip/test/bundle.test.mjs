import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle, OWNER } from "./fakes.mjs";
import { HEADERS } from "../src/rows.js";
import { SAMPLE_ANSWERS } from "../src/samples.js";

const SETTINGS = [
  ["項目", "値"],
  ["会社名", "みなと商会"],
  ["署名", "みなと商会\n03-0000-0000"],
  ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
];

const CLAUDE_ANSWER = SAMPLE_ANSWERS["quote-01"];

/** つないだ 1 本を偽の GAS（test/fakes.mjs）の上で走らせる */
function runBundle(options) {
  return loadBundle(Object.assign({ settings: SETTINGS, claudeAnswer: CLAUDE_ANSWER }, options, { settings: options.settings || SETTINGS }));
}

const INBOUND = {
  id: "t1",
  from: "みなと 太郎 <taro@example.com>",
  subject: "会議室の内装工事の見積もりをお願いします",
  date: "2026-09-14T01:32:00Z",
  plainBody: "見積もりをお願いします。",
  attachmentNames: ["図面.pdf"],
};
const BULK = { id: "t2", from: "ニュースレター <news@example.com>", subject: "今週の情報", date: "2026-09-14T02:00:00Z", plainBody: "配信", headers: { "List-Unsubscribe": "<https://x/u>" } };

test("鍵があれば、Gmail の 1 通を Claude に送り、行・下書き・ラベル・通知が出る", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, BULK] });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(result.skipped, 1);
  const sheet = run.sheets["問い合わせ"];
  assert.deepEqual(sheet.rows[0], HEADERS);
  assert.equal(sheet.rows.length, 2);
  assert.equal(sheet.rows[1][2], "見積もり依頼");
  assert.equal(sheet.rows[1][13], "未対応");
  assert.equal(sheet.rows[1][17], "https://mail.google.com/mail/u/0/#all/t1");
  // Claude への送信は 1 回、鍵はヘッダーに、本文は JSON
  const claude = run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0);
  assert.equal(claude.length, 1);
  assert.equal(claude[0].headers["x-api-key"], "sk-ant-test");
  assert.equal(claude[0].headers["anthropic-version"], "2023-06-01");
  const body = JSON.parse(claude[0].payload);
  assert.equal(body.output_config.format.type, "json_schema");
  assert.ok(body.messages[0].content[0].text.includes("見積もりをお願いします。"));
  // 下書きは署名つき、ラベルは 済 と 分類
  assert.equal(run.trace.drafts.length, 1);
  assert.ok(run.trace.drafts[0].body.endsWith("みなと商会\n03-0000-0000"));
  assert.deepEqual(run.threads[0].labels, ["AI整理済", "AI_見積もり依頼"]);
  assert.deepEqual(run.threads[1].labels, ["AI整理対象外"]);
  // インライン画像（署名の画像など）は添付に入れない
  assert.equal(run.trace.attachmentOptions.length, 2);
  for (const opts of run.trace.attachmentOptions) assert.equal(opts.includeInlineImages, false);
  // Slack へ 1 通。本文は載らず、シートの行はリンクになる
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("新しい問い合わせ 1 件"));
  assert.equal(JSON.parse(slack[0].payload).text.includes("見積もりをお願いします。"), false);
  assert.ok(JSON.parse(slack[0].payload).text.includes("<https://docs.google.com/spreadsheets/d/SHEETID/edit#gid=1234567&amp;range=A2|行 2>"));
  // 覚え書き
  assert.equal(run.props["count:2026-09-14"] !== undefined, true);
  assert.equal(JSON.parse(run.props["usage:2026-09"]).count, 1);
  assert.match(run.props.lastReceipt, /^20260914-001$/);
});

test("差出人名・会社・要約の字は、Slack と Discord で呼び出しにならない（行へのリンクは残る）", () => {
  const settings = SETTINGS.concat([
    ["通知先", "slack,discord"],
    ["Discord Webhook URL", "https://discord.com/api/webhooks/1/xxxx"],
  ]);
  const answer = Object.assign({}, CLAUDE_ANSWER, { summary: "<@U123> への返事 & 見積", person: Object.assign({}, CLAUDE_ANSWER.person, { name: "<!channel> 太郎", company: "A&B商会" }) });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], settings: settings, claudeAnswer: answer });
  assert.equal(run.entry.triage().processed, 1);
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  const text = JSON.parse(slack[0].payload).text;
  assert.ok(text.includes("&lt;@U123&gt; への返事 &amp; 見積 — &lt;!channel&gt; 太郎（A&amp;B商会） → <https://docs.google.com/spreadsheets/d/SHEETID/edit#gid=1234567&amp;range=A2|行 2>"), text);
  const discord = run.trace.fetched.filter((f) => f.url.indexOf("discord.com") >= 0);
  assert.equal(discord.length, 1);
  const payload = JSON.parse(discord[0].payload);
  assert.ok(payload.content.includes("<@U123> への返事 & 見積 — <!channel> 太郎（A&B商会） → 行 2 https://docs.google.com/spreadsheets/d/SHEETID/edit#gid=1234567&range=A2"), payload.content);
  assert.deepEqual(payload.allowed_mentions, { parse: [] });
});

test("エラーの文に設定シートの字が入っても、Slack で呼び出しにならない", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], settings: SETTINGS.concat([["通知先", "slack"], ["モデル", "<!channel>"]]) });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  const text = JSON.parse(slack[0].payload).text;
  assert.ok(text.includes("【問い合わせ整理｜エラー】"), text);
  assert.ok(text.includes("&lt;!channel&gt;"), text);
  assert.equal(text.includes("<"), false, text);
});

test("notifyAll_ は、宛先ごとの関数がただの文を返したら Slack へ送る前に文字参照にし、{ text, formatted: true } と明かした文だけそのまま送る", () => {
  const run = runBundle({});
  const config = { targets: ["slack", "discord"], slackWebhookUrl: "https://hooks.slack.com/services/T000/B000/xxxx", discordWebhookUrl: "https://discord.com/api/webhooks/1/xxxx" };
  assert.equal(run.sandbox.notifyAll_(config, function () {
    return "<!channel> A&B";
  }), 2);
  assert.equal(run.sandbox.notifyAll_(config, function (target) {
    return { text: target === "slack" ? "<https://x.test/?a=1&amp;b=2|行 2>" : "行 2 https://x.test/?a=1&b=2", formatted: true };
  }), 2);
  const sent = (host) => run.trace.fetched.filter((f) => f.url.indexOf(host) >= 0).map((f) => JSON.parse(f.payload));
  assert.deepEqual(sent("hooks.slack.com").map((p) => p.text), ["&lt;!channel&gt; A&amp;B", "<https://x.test/?a=1&amp;b=2|行 2>"]);
  assert.deepEqual(sent("discord.com").map((p) => p.content), ["<!channel> A&B", "行 2 https://x.test/?a=1&b=2"]);
});

test("鍵が無ければ、何もせずエラーを通知する", () => {
  const run = runBundle({ threads: [INBOUND] });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.ok(result.message.includes("ANTHROPIC_API_KEY"));
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
  assert.equal(run.sheets["問い合わせ"], undefined);
});

test("Claude が 529 を返し続けたら、そのメールは飛ばして次回に回す（ラベルを付けない）", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeStatus: 529 });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.deepEqual(run.threads[0].labels, []);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 2, "1 回やり直す");
  assert.equal(run.trace.drafts.length, 0);
});

test("見本のメールで試すと、鍵と Gmail に触らず 7 行と通知が出る", () => {
  const run = runBundle({});
  run.entry.triageSamples();
  const sheet = run.sheets["問い合わせ"];
  assert.equal(sheet.rows.length, 8);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 0);
  assert.equal(run.trace.drafts.length, 0);
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.startsWith("新しい問い合わせ 7 件\n⚠ 要対応"));
  assert.ok(run.trace.alerts[0].includes("見本のメール 7 件"));
  assert.ok(run.trace.alerts[0].includes("対象外"));
});

test("答えが max_tokens で切れたら、メモにその旨が入り実行ログにも残る", () => {
  const body = { content: [{ type: "text", text: JSON.stringify(CLAUDE_ANSWER) }], usage: { input_tokens: 1200, output_tokens: 4000 }, stop_reason: "max_tokens" };
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeBody: body });
  run.entry.triage();
  assert.equal(run.sheets["問い合わせ"].rows[1][16], "答えが長すぎて途中で切れました。");
  assert.ok(run.trace.logs.some((line) => line.includes("答えが長すぎて途中で切れました。")));
});

test("ほかの実行と重なってロックが取れないときは、何もせず通知もしない", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], lockBusy: true });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.equal(result.skipped, 0);
  assert.equal(result.stopped, 0);
  assert.equal(result.message, "ほかの整理が動いています。少しあとでお試しください。");
  assert.equal(run.trace.fetched.length, 0, "Claude にも通知先にも送らない");
  assert.equal(run.sheets["問い合わせ"], undefined);
  assert.ok(run.trace.logs.some((line) => line.includes("ほかの整理が動いている")));
});

test("同じエラーが続いても、通知は 1 日 1 通だけ（実行ログには毎回残る）", () => {
  const run = runBundle({ threads: [INBOUND] });
  run.entry.triage();
  run.entry.triage();
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1, "2 回目は通知しない");
  assert.ok(run.props.lastErrorNotice.indexOf("ANTHROPIC_API_KEY") >= 0);
  assert.ok(run.trace.logs.some((line) => line.includes("1 日 1 通")));
});

test("設定シートが壊れていても、通知先の行だけを読んでエラーを届ける", () => {
  const broken = [
    ["項目", "値"],
    ["会社名", ""],
    ["通知先", "slack"],
    ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
  ];
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], settings: broken });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.ok(result.message.includes("「会社名」の行"));
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 0);
});

test("1 日の上限に当たったら、残りは行も下書きもラベルも増えずに次回へ回る", () => {
  const settings = SETTINGS.concat([["1 日の上限", "1"]]);
  const second = Object.assign({}, INBOUND, { id: "t3", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], settings: settings });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(result.stopped, 1);
  assert.ok(result.message.includes("上限に達したため次回に回した: 1 件"));
  assert.equal(run.sheets["問い合わせ"].rows.length, 2, "見出し + 1 行");
  assert.equal(run.trace.drafts.length, 1);
  assert.deepEqual(run.threads[1].labels, [], "次回また拾えるようにラベルは付けない");
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 1);
  assert.equal(run.props["count:2026-09-14"], "1");
});

test("思考ブロックが先に来る応答でも、text ブロックを読んで整理できる", () => {
  const body = {
    content: [{ type: "thinking", thinking: "" }, { type: "text", text: JSON.stringify(CLAUDE_ANSWER) }],
    usage: { input_tokens: 1200, output_tokens: 900, cache_read_input_tokens: 700, cache_creation_input_tokens: 0 },
    stop_reason: "end_turn",
  };
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeBody: body });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(run.sheets["問い合わせ"].rows[1][2], "見積もり依頼");
  assert.equal(run.sheets["問い合わせ"].rows[1][16], "", "メモは空（切れていない）");
});

test("トリガーは設定の間隔で 1 つだけ入る", () => {
  const run = runBundle({});
  run.entry.installTrigger();
  run.entry.installTrigger();
  assert.equal(run.triggers.length, 1);
  assert.equal(run.triggers[0].minutes, 15);
});

test("途中で設定の誤り（401）が出ても、それまでの受付番号と件数は残り、次回の番号が重ならない", () => {
  const second = Object.assign({}, INBOUND, { id: "t3", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], claudeStatuses: [200, 401] });
  const result = run.entry.triage();
  assert.equal(result.processed, 0, "エラーの返り値");
  assert.ok(result.message.includes("API キー"));
  const sheet = run.sheets["問い合わせ"];
  assert.equal(sheet.rows.length, 2, "1 件目の行は残る");
  assert.match(run.props.lastReceipt, /-001$/);
  assert.equal(Object.keys(run.props).filter((k) => k.indexOf("count:") === 0).length, 1);
  const dayKey = Object.keys(run.props).find((k) => k.indexOf("count:") === 0);
  assert.equal(run.props[dayKey], "1");
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1);
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
});

test("設定の誤り（400）で全部が飛ばされても、エラーは 1 日 1 通だけ知らされる", () => {
  const second = Object.assign({}, INBOUND, { id: "t4", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], claudeStatuses: [400, 400] });
  const first = run.entry.triage();
  assert.equal(first.processed, 0);
  assert.deepEqual(run.threads[0].labels, []);
  assert.deepEqual(run.threads[1].labels, []);
  const slack = run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0);
  assert.equal(slack.length, 1, "1 通だけ知らせる");
  assert.ok(JSON.parse(slack[0].payload).text.includes("【問い合わせ整理｜エラー】"));
  run.entry.triage();
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0).length, 1, "同じ日の 2 回目は知らせない");
});

// ===== 本物の Apps Script の癖（test/fakes.mjs が再現する）に対する検査 =====

test("トリガーでは getActiveUser が空でも、持ち主の返信を問い合わせと取り違えない", () => {
  const thread = {
    id: "t5",
    subject: "見積もりのお願い",
    messages: [
      { from: "みなと 太郎 <taro@example.com>", date: "2026-09-14T01:00:00Z", plainBody: "お客さまの本文です。" },
      { from: "オーナー <" + OWNER + ">", date: "2026-09-14T01:20:00Z", plainBody: "持ち主の返信です。" },
    ],
  };
  const run = runBundle({ apiKey: "sk-ant-test", threads: [thread], activeEmail: "", fromTrigger: true });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  const claude = run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0);
  const text = JSON.parse(claude[0].payload).messages[0].content[0].text;
  assert.ok(text.includes("お客さまの本文です。"));
  assert.equal(text.includes("持ち主の返信です。"), false);
  assert.equal(run.trace.logs.some((l) => l.includes("自分のアドレスを読めなかった")), false);
});

test("2 回目の整理では、ラベルの付いたスレッドを検索で拾わない（同じ行が 2 度入らない）", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, BULK] });
  assert.equal(run.entry.triage().processed, 1);
  const second = run.entry.triage();
  assert.equal(second.processed, 0);
  assert.equal(second.skipped, 0);
  assert.equal(run.sheets["問い合わせ"].rows.length, 2);
  assert.equal(run.trace.drafts.length, 1);
  assert.deepEqual(run.trace.labelsCreated, ["AI整理済", "AI_見積もり依頼", "AI整理対象外"], "ラベルは 1 度だけ作る");
  assert.deepEqual(run.trace.scopeErrors, [], "マニフェストの許可で足りる");
  for (const s of run.trace.searches) assert.ok(s.max <= 500);
});

test("数や日付に見える字（先頭が 0 の電話・数だけの会社名・9/18 の件名）も、シートでは書いたとおりの文字で残る", () => {
  const answer = Object.assign({}, CLAUDE_ANSWER, { summary: "10/1", person: { name: "山田", company: "1234", phone: "0312345678" }, notes: "TRUE" });
  const body = { content: [{ type: "text", text: JSON.stringify(answer) }], usage: { input_tokens: 1, output_tokens: 1 }, stop_reason: "end_turn" };
  const thread = Object.assign({}, INBOUND, { subject: "9/18", from: "0120 <0120@example.com>" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [thread], claudeBody: body });
  assert.equal(run.entry.triage().processed, 1);
  const header = run.sheets["問い合わせ"].rows[0];
  const row = run.sheets["問い合わせ"].rows[1];
  const at = (name) => row[header.indexOf(name)];
  assert.equal(at("電話"), "0312345678");
  assert.equal(at("会社"), "1234");
  assert.equal(at("要約"), "10/1");
  assert.equal(at("件名"), "9/18");
  assert.equal(at("メモ"), "TRUE");
  assert.equal(at("受付番号"), "20260914-001");
  // 受信日時と期限は日付として入ってよい（並べ替えと絞り込みに使えるように）
  assert.equal(Object.prototype.toString.call(at("受信日時")), "[object Date]");
});

test("「問い合わせ」シートが保護されて書けないときは、Claude に送る前に止まる（API の費用を使わない）", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], inquiries: [HEADERS], denyWrite: true });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.ok(result.message.includes("書き込めません"), result.message);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 0);
  assert.deepEqual(run.threads[0].labels, []);
});

test("Claude に接続できない（タイムアウトなど）ときは、残りを次回に回し、ラベルも付けない", () => {
  const second = Object.assign({}, INBOUND, { id: "t6", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], claudeThrows: true });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.equal(result.stopped, 2);
  assert.ok(result.message.includes("次回に回した: 2 件"), result.message);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0).length, 1, "つながらないときはやり直さず、次の 1 通も送らない");
  assert.deepEqual(run.threads[0].labels, []);
  assert.deepEqual(run.threads[1].labels, []);
  assert.equal(run.trace.fetched.some((f) => JSON.stringify(f).includes("sk-ant-test") && f.url.indexOf("anthropic") < 0), false, "鍵を通知に出さない");
});

test("Claude と通知の呼び出しは、すべて muteHttpExceptions つき（本物は付けないと 4xx/5xx で例外になる）", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], claudeStatuses: [529, 200], notifyStatus: 500 });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.ok(run.trace.fetched.length >= 3);
  for (const f of run.trace.fetched) assert.equal(f.muted, true, f.url);
  assert.ok(result.message.includes("通知を送れませんでした"));
});

test("持ち主と別のアカウント（共有した編集者）では、Gmail を読まず、トリガーも入れない", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND], user: "staff@example.com", props: { owner: OWNER }, triggers: [{ owner: OWNER, handler: "triage", minutes: 15 }] });
  const result = run.entry.triage();
  assert.equal(result.processed, 0);
  assert.ok(result.message.includes(OWNER), result.message);
  assert.equal(run.trace.searches.length, 0, "編集者の Gmail を検索しない");
  assert.equal(run.trace.fetched.length, 0, "Claude にも通知先にも送らない");
  run.entry.installTrigger();
  assert.equal(run.triggers.length, 1, "持ち主のトリガーだけ");
  assert.ok(run.trace.alerts[0].includes(OWNER));
  run.entry.removeTrigger();
  assert.equal(run.triggers.length, 1, "編集者からは持ち主のトリガーは見えず、消えない");
  assert.ok(run.trace.alerts[1].includes(OWNER));
  // 見本のメールは Gmail を読まないので、編集者でも試せる
  run.entry.triageSamples();
  assert.ok(run.trace.alerts[2].includes("見本のメール 7 件"));
});

test("最初に整理した人（またはトリガーを入れた人）が持ち主として覚えられ、「設定を確かめる」に出る", () => {
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND] });
  run.entry.installTrigger();
  assert.equal(run.props.owner, OWNER);
  run.entry.checkConfig();
  assert.ok(run.trace.alerts[1].includes("整理する Gmail: " + OWNER), run.trace.alerts[1]);
});

test("間隔 60 分は everyHours(1)、5 分は everyMinutes(5) で入る（本物は everyMinutes(60) を受け付けない）", () => {
  const hourly = runBundle({ settings: SETTINGS.concat([["間隔(分)", 60]]) });
  hourly.entry.installTrigger();
  assert.equal(hourly.triggers.length, 1);
  assert.equal(hourly.triggers[0].hours, 1);
  const five = runBundle({ settings: SETTINGS.concat([["間隔（分）", "5"]]) });
  five.entry.installTrigger();
  assert.equal(five.triggers[0].minutes, 5);
});

test("設定の項目名に全角の空白や空白の抜けがあっても読める（シートが数や真偽に読み替えた値も読める）", () => {
  const settings = [
    ["項目", "値"],
    ["会社名　", "みなと商会"],
    ["1回に読む数", "1"],
    ["下書きを作る", "FALSE"],
    ["Slack　Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
  ];
  const second = Object.assign({}, INBOUND, { id: "t7", subject: "別の問い合わせ" });
  const run = runBundle({ apiKey: "sk-ant-test", threads: [INBOUND, second], settings: settings });
  const result = run.entry.triage();
  assert.equal(result.processed, 1);
  assert.equal(result.stopped, 1);
  assert.equal(run.trace.drafts.length, 0);
  assert.equal(run.trace.fetched.filter((f) => f.url.indexOf("hooks.slack.com") >= 0).length, 1);
});
