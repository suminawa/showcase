#!/usr/bin/env node
/*
 * 配布 zip を release/ に作ります。
 *
 * zip の中は saas-starter-v<版>/ の 1 つのフォルダにまとめます（解いたときに、
 * 買い手のフォルダにファイルが散らばらないようにするためです）。
 * 使うのは OS の zip コマンドだけで、依存パッケージは増やしません。
 *
 * 入れないもの
 *   node_modules・.next・.git・.vercel・.DS_Store・release・next-env.d.ts・
 *   tsconfig.tsbuildinfo・supabase/.branches・supabase/.temp。
 *   .env で始まるファイルは .env.example だけを入れます。
 *
 * package-lock.json は入れます（買い手の手元で npm ci が同じ版を入れるためです）。
 */
import { execFileSync } from "node:child_process";
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, "..");

/**
 * 丸ごと入れるフォルダ（この並びの順に、中は名前順で入れます）。
 *
 * `public` は、この土台には無くても構いません（無ければ黙って飛ばします）。
 * README 20 章で、ほかのキットの画像を `public/` に置くようご案内していますので、
 * お客さまが `npm run release` をお使いになったときに抜け落ちないよう、並べてあります。
 */
export const RELEASE_DIRS = [
  "app",
  "src",
  "supabase",
  "messages",
  "legal",
  "public",
  "scripts",
  "test",
];

/** 単体で入れるファイル */
export const RELEASE_FILES = [
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "next.config.ts",
  "vitest.config.ts",
  "proxy.ts",
  "plans.config.ts",
  "legal.config.ts",
  ".env.example",
  ".gitignore",
  "README.ja.md",
  "README.en.md",
  "LICENSE.md",
  "CHANGELOG.md",
];

/**
 * 1 つでも欠けていたら zip を作らないファイルです。
 * 上の RELEASE_FILES と、言語の 2 つ・移行の SQL の 3 本・法務の 6 枚です。
 */
export const RELEASE_REQUIRED = RELEASE_FILES.concat([
  "messages/ja.json",
  "messages/en.json",
  "supabase/migrations/20260920000100_init.sql",
  "supabase/migrations/20260920000200_functions.sql",
  "supabase/migrations/20260920000300_rls.sql",
  "legal/tokushoho.ja.txt",
  "legal/terms.ja.txt",
  "legal/privacy.ja.txt",
  "legal/tokushoho.en.txt",
  "legal/terms.en.txt",
  "legal/privacy.en.txt",
]);

/** 名前がこれと同じなら、フォルダごと・ファイルごと入れません */
const RELEASE_SKIP_NAMES_ = [
  "node_modules",
  ".next",
  ".git",
  ".vercel",
  ".DS_Store",
  "release",
  "next-env.d.ts",
  "tsconfig.tsbuildinfo",
  // supabase/ の下にできる、手元だけの控えです
  ".branches",
  ".temp",
];

/** 入れてよい唯一の .env ファイル（値は空の見本です） */
const RELEASE_ENV_KEEP_ = ".env.example";

/** その名前を zip に入れるか（フォルダにもファイルにも使います） */
function releaseKeepName_(name) {
  if (RELEASE_SKIP_NAMES_.indexOf(name) !== -1) return false;
  if (name.startsWith(".env")) return name === RELEASE_ENV_KEEP_;
  return true;
}

/** dir の下のファイルを、どの階層も名前順にたどって集めます（相対の道すじで返します） */
function releaseWalk_(root, relDir) {
  const found = [];
  const names = readdirSync(join(root, relDir)).slice().sort();
  for (const name of names) {
    if (!releaseKeepName_(name)) continue;
    const relPath = relDir + "/" + name;
    if (statSync(join(root, relPath)).isDirectory()) found.push(...releaseWalk_(root, relPath));
    else found.push(relPath);
  }
  return found;
}

/**
 * zip に入るファイルの一覧を、入る順にお返しします（root からの相対の道すじ）。
 * 読むだけの組み立てなので、検査からそのまま呼べます。
 */
export function releaseFileList(root) {
  const base = root === undefined ? ROOT : root;
  const found = [];
  for (const dir of RELEASE_DIRS) {
    if (!existsSync(join(base, dir))) continue;
    found.push(...releaseWalk_(base, dir));
  }
  for (const file of RELEASE_FILES) {
    if (existsSync(join(base, file))) found.push(file);
  }
  return found;
}

/** そろっていない RELEASE_REQUIRED（すべてそろっていれば空です） */
export function releaseMissing(root) {
  const base = root === undefined ? ROOT : root;
  return RELEASE_REQUIRED.filter((relPath) => !existsSync(join(base, relPath)));
}

/** package.json の version */
export function releaseVersion(root) {
  const base = root === undefined ? ROOT : root;
  return JSON.parse(readFileSync(join(base, "package.json"), "utf8")).version;
}

/** zip の中の、いちばん外側のフォルダの名前 */
export function releaseFolderName(root) {
  return "saas-starter-v" + releaseVersion(root);
}

/** 既定の置き場所 */
export function releaseZipPath(root) {
  const base = root === undefined ? ROOT : root;
  return join(base, "release", releaseFolderName(base) + ".zip");
}

/**
 * zip を作ります。outPath を渡さなければ release/saas-starter-v<版>.zip です。
 * そろっていないファイルがあれば Error を投げます（呼んだ側が文にして出します）。
 * お返しするのは { zipPath, bytes, files } です。
 */
export function createRelease(root, outPath) {
  const base = root === undefined ? ROOT : root;
  const missing = releaseMissing(base);
  if (missing.length > 0) {
    throw new Error(
      "配布 zip を作れません。次のファイルがまだありません。\n  " +
        missing.join("\n  ") +
        "\nファイルをそろえてから、もう一度お試しください。",
    );
  }

  const zipPath = outPath === undefined ? releaseZipPath(base) : resolve(outPath);
  const folder = releaseFolderName(base);
  const files = releaseFileList(base);

  mkdirSync(dirname(zipPath), { recursive: true });
  if (existsSync(zipPath)) rmSync(zipPath);

  // zip はフォルダ名を付け替えられないので、いちど写してから固めます
  const stage = zipPath + ".stage";
  rmSync(stage, { recursive: true, force: true });
  for (const relPath of files) {
    const to = join(stage, folder, relPath);
    mkdirSync(dirname(to), { recursive: true });
    cpSync(join(base, relPath), to);
  }

  try {
    execFileSync(
      "zip",
      ["-q", "-X", zipPath].concat(files.map((relPath) => folder + "/" + relPath)),
      { cwd: stage },
    );
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }

  return { zipPath, bytes: statSync(zipPath).size, files: files.length };
}

const invokedDirectly =
  process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  try {
    const made = createRelease();
    console.log(made.zipPath + " を作りました");
    console.log("大きさ: " + made.bytes.toLocaleString("ja-JP") + " バイト / ファイル数: " + made.files);
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
}
