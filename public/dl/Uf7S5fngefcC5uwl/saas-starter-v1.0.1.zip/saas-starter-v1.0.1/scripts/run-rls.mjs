#!/usr/bin/env node
/**
 * 行の出入りの決まり（RLS）の検査を、まとめて回します。
 *
 *   npm run test:rls
 *
 * 次の順に進みます。
 *   1. supabase コマンドと Docker が使えるかを確かめます
 *   2. つなぎ先を確かめます  … そのポートを、別の Supabase が使っていないか
 *   3. supabase start        … この土台のローカルの Supabase を立ち上げます
 *   4. つなぎ先をもう一度確かめて、supabase db reset で移行の SQL をあてなおします
 *   5. supabase test db      … supabase/tests/ の pgTAP を回します
 *   6. vitest test/rls.test.ts … 実際のログインで、役割ごとの可否を確かめます
 *   7. vitest test/supabase.test.ts … つなぎ役（adapter）を、本物のデータベースで確かめます
 *   8. supabase stop         … このコマンドが立ち上げたときだけ、止めます
 *
 * つなぎ先は、**このパッケージの supabase/config.toml だけ**から決めます
 * （データベースの URL も、フォルダの道すじも、環境変数では受け取りません）。
 * つなぎ先が食い違っていたら、SQL を 1 行も流さずに終わります。
 * すでに別の Supabase を動かしていらっしゃる場合は、config.toml の project_id と
 * 4 つのポートをずらしてから、もう一度お試しください。
 *
 * 終わり方は 3 とおりです。
 *   0 … すべて通りました（RLS 実施）
 *   1 … どれかが落ちました
 *   2 … 検査できませんでした（RLS 未実施。理由を 1 行でお伝えします）
 */
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * 相手にするのは、**このパッケージの supabase/ だけ**です。
 *
 * 環境変数では動かしません。身元（config.toml）と行き先（--workdir）が
 * 別々に動くようにしておくと、環境に古い値が残っているときに、
 * 別の案件のデータベースを「この土台だ」と思ったまま作り直してしまいます。
 * 別の設定でお試しになるときは、このフォルダごと写して、
 * 写しのほうの supabase/config.toml を書き換えてからお回しください。
 */
const PACKAGE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CONFIG_PATH = path.join(PACKAGE_DIR, "supabase", "config.toml");

/** Docker を待つ間隔と回数（5 秒 × 18 回 = 90 秒） */
const WAIT_SECONDS = 5;
const WAIT_TIMES = 18;

/** このコマンドが立ち上げたかどうか。立ち上げたときだけ、最後に止めます */
let startedHere = false;

function sleep(seconds) {
  return new Promise((resolve) => setTimeout(resolve, seconds * 1000));
}

/** 画面にそのまま流します（立ち上げのように時間のかかるもの用です） */
function runLoud(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: "inherit", ...options });
  return result.status ?? 1;
}

/** 出力を受け取ってから流します（件数を数えたいもの用です） */
function runQuiet(command, args, options = {}) {
  const result = spawnSync(command, args, { encoding: "utf8", ...options });
  const output = `${result.stdout ?? ""}${result.stderr ?? ""}`;
  process.stdout.write(output);
  return { status: result.status ?? 1, output };
}

/**
 * config.toml から、この土台の名前（project_id）とデータベースのポートを読みます。
 * どちらかが読めなければ null を返します。
 */
function readConfig() {
  let text = "";
  try {
    text = readFileSync(CONFIG_PATH, "utf8");
  } catch {
    return null;
  }

  const projectId = text.match(/^\s*project_id\s*=\s*"([^"]+)"/m)?.[1] ?? null;

  // [db] の節に入ってから、最初の port を読みます
  let section = "";
  let dbPort = null;
  for (const line of text.split("\n")) {
    const header = line.match(/^\s*\[([^\]]+)\]/);
    if (header !== null) section = header[1];
    if (section !== "db") continue;
    const port = line.match(/^\s*port\s*=\s*(\d+)/);
    if (port !== null) {
      dbPort = Number(port[1]);
      break;
    }
  }

  if (projectId === null || dbPort === null) return null;
  return { projectId, dbPort };
}

function supabaseAvailable() {
  const result = spawnSync("supabase", ["--version"], { encoding: "utf8" });
  return result.error === undefined && result.status === 0;
}

function dockerReady() {
  const result = spawnSync("docker", ["info"], { encoding: "utf8" });
  return result.error === undefined && result.status === 0;
}

/** macOS なら、よく使われている 2 つのうち入っているほうを起こします */
function wakeDocker() {
  if (process.platform !== "darwin") return;
  for (const app of ["OrbStack", "Docker"]) {
    const result = spawnSync("open", ["-a", app], { encoding: "utf8" });
    if (result.status === 0) return;
  }
}

async function waitForDocker() {
  if (dockerReady()) return true;

  console.log("Docker の起動をお待ちしています…");
  wakeDocker();
  for (let i = 0; i < WAIT_TIMES; i += 1) {
    await sleep(WAIT_SECONDS);
    if (dockerReady()) return true;
  }
  return false;
}

/**
 * その名前の Supabase が、いま動いているかどうかです。
 *
 * **docker に尋ねられなかったときは null をお返しします。**
 * 「動いていません」と同じ扱いにすると、一時の不調のときに
 * 「このコマンドが立ち上げた」と思い込み、**もとから動いていたものを止めて**しまいます。
 */
function runningState(projectId) {
  const result = spawnSync(
    "docker",
    ["ps", "--filter", `label=com.supabase.cli.project=${projectId}`, "--quiet"],
    { encoding: "utf8" },
  );
  if (result.error !== undefined || result.status !== 0) return null;
  return (result.stdout ?? "").trim() !== "";
}

/**
 * そのポートを開けている Supabase の名前（project_id）です。
 *
 * { ok: false } … docker に尋ねられませんでした（分からない、です）
 * { ok: true, owner: null } … どの Supabase も、そのポートを開けていません
 * { ok: true, owner: "…" }  … その土台が開けています
 */
function projectOnPort(port) {
  const result = spawnSync(
    "docker",
    ["ps", "--filter", `publish=${port}`, "--format", '{{.Label "com.supabase.cli.project"}}'],
    { encoding: "utf8" },
  );
  if (result.error !== undefined || result.status !== 0) return { ok: false };
  const found = (result.stdout ?? "")
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line !== "");
  return { ok: true, owner: found[0] ?? null };
}

/** 出力から件数を読みます。読み取れなければ null（「?」のまま通しません） */
function countFrom(output, pattern) {
  const found = output.match(pattern);
  return found === null ? null : found[1];
}

function readKeys() {
  const result = spawnSync("supabase", ["status", "--workdir", PACKAGE_DIR, "-o", "json"], {
    encoding: "utf8",
  });
  if (result.status !== 0) return null;
  try {
    return JSON.parse(result.stdout);
  } catch {
    return null;
  }
}

async function main() {
  const config = readConfig();
  if (config === null) {
    console.error("RLS 未実施: supabase/config.toml を読み取れませんでした");
    return 2;
  }

  if (!supabaseAvailable()) {
    console.error(
      "RLS 未実施: supabase コマンドが見つかりません（https://supabase.com/docs/guides/local-development の手順で入れてから、npm run test:rls をもう一度お試しください）",
    );
    return 2;
  }

  if (!(await waitForDocker())) {
    console.error(
      "RLS 未実施: Docker が使えません（Docker Desktop か OrbStack を起動してから npm run test:rls をもう一度お試しください）",
    );
    return 2;
  }

  // **立ち上げる前に**、そのポートが空いているか、この土台のものかを確かめます。
  // 別の案件の Supabase が使っているポートに重ねて立ち上げようとすると、
  // そちらの邪魔になります（ここで止まれば、docker に 1 つも触っていません）。
  const before = projectOnPort(config.dbPort);
  if (!before.ok) {
    console.error("RLS 未実施: docker にお尋ねできませんでした（docker ps が通りません）");
    return 2;
  }
  if (before.owner !== null && before.owner !== config.projectId) {
    console.error(
      `RLS 未実施: ポート ${config.dbPort} は、別の Supabase（${before.owner}）が使っています。` +
        "supabase/config.toml の project_id とポートをずらしてから、もう一度お試しください。" +
        "docker には何も触れていません",
    );
    return 2;
  }

  // このコマンドが立ち上げたときだけ、最後に止めます。
  // docker に尋ねられないときは、**立ち上げたことにしません**
  // （もとから動いていたものを、あとで止めてしまわないためです）。
  const running = runningState(config.projectId);
  if (running === null) {
    console.error("RLS 未実施: docker にお尋ねできませんでした（docker ps が通りません）");
    return 2;
  }
  startedHere = !running;

  if (runLoud("supabase", ["start", "--workdir", PACKAGE_DIR]) !== 0) {
    console.error("ローカルの Supabase を立ち上げられませんでした");
    return 1;
  }

  // ここから先は、データベースの中身を作り直します。
  // その前にもう一度、つなぎ先がこの土台のものかどうかを確かめます。
  // 同じ Mac でほかの Supabase を動かしていらっしゃるときに、
  // そちらを作り直してしまわないための確かめです。
  const after = projectOnPort(config.dbPort);
  if (!after.ok || after.owner !== config.projectId) {
    console.error(
      `RLS 未実施: ポート ${config.dbPort} につながっているのは、この土台（${config.projectId}）ではありません` +
        `（${after.ok ? (after.owner === null ? "どの Supabase でもありません" : `いま使っているのは ${after.owner} です`) : "docker にお尋ねできませんでした"}）。` +
        "supabase/config.toml の project_id とポートをご確認ください。データベースには何も流していません",
    );
    return 2;
  }

  if (runLoud("supabase", ["db", "reset", "--local", "--workdir", PACKAGE_DIR]) !== 0) {
    console.error("移行の SQL をあてられませんでした");
    return 1;
  }

  const pgtap = runQuiet("supabase", ["test", "db", "--local", "--workdir", PACKAGE_DIR]);
  if (pgtap.status !== 0) {
    console.error("pgTAP の検査が落ちました");
    return 1;
  }

  const status = readKeys();
  if (status === null) {
    console.error("ローカルの Supabase の鍵を読み取れませんでした");
    return 1;
  }

  // この 2 本は、いつもの npm test では省いてあります。
  // 同じデータベースを相手にするので、1 本ずつ順に回します。
  const testEnv = {
    ...process.env,
    RLS_TEST: "1",
    SUPABASE_URL: status.API_URL,
    SUPABASE_ANON_KEY: status.ANON_KEY,
    SUPABASE_SERVICE_ROLE_KEY: status.SERVICE_ROLE_KEY,
  };

  const vitest = runQuiet("npx", ["vitest", "run", "test/rls.test.ts"], {
    cwd: PACKAGE_DIR,
    env: testEnv,
  });
  if (vitest.status !== 0) {
    console.error("RLS の検査が落ちました");
    return 1;
  }

  const adapter = runQuiet("npx", ["vitest", "run", "test/supabase.test.ts"], {
    cwd: PACKAGE_DIR,
    env: testEnv,
  });
  if (adapter.status !== 0) {
    console.error("つなぎ役の検査が落ちました");
    return 1;
  }

  const pgtapCount = countFrom(pgtap.output, /Tests=(\d+)/);
  const vitestCount = countFrom(vitest.output, /Tests\s+(\d+) passed/);
  const adapterCount = countFrom(adapter.output, /Tests\s+(\d+) passed/);
  if (pgtapCount === null || vitestCount === null || adapterCount === null) {
    console.error("検査は通りましたが、件数を読み取れませんでした（出力の形が変わっています）");
    return 1;
  }

  console.log(`RLS 実施: pgTAP ${pgtapCount} 件 / vitest ${vitestCount} 件`);
  console.log(`つなぎ役の検査 実施: vitest ${adapterCount} 件`);
  return 0;
}

let code = 1;
try {
  code = await main();
} finally {
  // このコマンドが立ち上げたときだけ止めます（もとから動いていたものは、そのままにします）
  if (startedHere) {
    const config = readConfig();
    if (config !== null) {
      runLoud("supabase", ["stop", "--project-id", config.projectId, "--workdir", PACKAGE_DIR]);
    }
  }
}
process.exit(code);
