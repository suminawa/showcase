#!/usr/bin/env node
/**
 * ブラウザに配る束と、組み立て済みのお返事に、鍵が紛れ込んでいないかを調べます。
 *
 * 調べる場所は 3 つです。
 *
 *   ① .next/static … ブラウザにそのまま配られる束です。
 *      鍵の名前や、サーバーの側だけで読み込む口の名前が出てきたときは、
 *      どこかで画面の部品がサーバーのファイルを読み込んでいます。
 *   ② .next/server の .html・.rsc・.body・.meta … あらかじめ組み立てられ、
 *      そのままブラウザへ届くお返事です。部品にお渡しした値がここに焼き付きます。
 *   ③ **実際に立てたサーバーのお返事**。この土台の画面は、どれもお申し付けごとに
 *      組み立て直します（`app/layout.tsx` が cookie を読むためです）。
 *      ②にはディスクへ書き出された画面がほとんど残らないので、
 *      いちばん捕まえたい漏れ方（行をまるごと部品へ渡す、など）は③で見ます。
 *
 * ②と③では、鍵の環境変数の「名前」は調べません。サーバーの側のコードに入るのは正しい姿だからです。
 * 調べるのは、組み立てのときだけ入れた**目印の値**と、ブラウザに届いてはいけない欄の名前です。
 *
 * **1 本も読まなかったときは、赤くしてお止めします。** 「調べて何も無かった」と
 * 「そもそも何も調べていない」は、出力では見分けがつかないためです。
 *
 * 使い方
 *   node scripts/check-bundle.mjs               … 2 通りに組み立て直してから調べます
 *                                                 （見本のしくみと、鍵を入れた形。
 *                                                   鍵には目印の値を入れて、その値そのものも探します）
 *   node scripts/check-bundle.mjs --scan-only   … いま置かれているものだけを調べます
 *
 * 1 件でも見つかったときは、ファイルと語をお出しして 1 で終わります。
 *
 * **調べ終わると .next を消します。**（--scan-only のときは残します）
 * 組み立て直したものには目印の値が焼き付いているため、そのまま配ったり置いたりできません。
 * 配る前・置く前は、このあとに npm run build を取り直してください。
 */
import { spawn, spawnSync } from "node:child_process";
import { existsSync, readFileSync, readdirSync, rmSync, statSync } from "node:fs";
import { createServer } from "node:net";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

/** ブラウザには決してお渡ししない、鍵の環境変数の名前です */
export const SECRET_ENV_NAMES = [
  "SUPABASE_SERVICE_ROLE_KEY",
  "STRIPE_SECRET_KEY",
  "STRIPE_WEBHOOK_SECRET",
  "RESEND_API_KEY",
  "ADMIN_EMAILS",
  "STARTER_FAKE_ALLOW_PRODUCTION",
  "STRIPE_PRICE_STANDARD",
  "STRIPE_PRICE_BUSINESS",
];

/**
 * 束に 1 つも出てきてはいけない語です。
 *
 *   ① 鍵の環境変数の名前（読んでよいのはサーバーだけです）
 *   ② 鍵そのものの形（Stripe の秘密の鍵・決済の通知の秘密・service role）
 *   ③ サーバーの側だけで読み込む口の名前（字を縮められても、property の名前は残ります）
 *   ④ 料金の設定の内側（Price の環境変数の名前を持つ欄）
 */
export const FORBIDDEN_IN_CLIENT = [
  ...SECRET_ENV_NAMES,
  // STRIPE_PRICE_ で始まる名前は、増やされても引っかかるように前だけで見ます
  "STRIPE_PRICE_",
  "service_role",
  "sk_live_",
  "sk_test_",
  "whsec_",
  "createServiceSupabase",
  "createStripeBilling",
  "createResendMail",
  // src/adapters/stripe/client.ts の STRIPE_API_VERSION です（文字列なので、縮めても残ります）
  "2026-08-26.dahlia",
  // service role でしか読めない口と、料金の設定の内側です
  "getBillingSubscription",
  "adminListSubscriptions",
  "priceEnvName",
];

/**
 * 組み立てるときにだけ入れる、目印の値です。
 * 束にこの値が出てきたら、鍵の**中身**がブラウザへ配られています。
 */
export const CANARY_ENV = {
  SUPABASE_SERVICE_ROLE_KEY: "service-role-BUNDLE_CANARY",
  STRIPE_SECRET_KEY: "sk_test_BUNDLE_CANARY",
  STRIPE_WEBHOOK_SECRET: "whsec_BUNDLE_CANARY",
  RESEND_API_KEY: "re_BUNDLE_CANARY",
  ADMIN_EMAILS: "BUNDLE_CANARY@example.com",
  STARTER_FAKE_ALLOW_PRODUCTION: "BUNDLE_CANARY_OFF",
  STRIPE_PRICE_STANDARD: "price_BUNDLE_CANARY_STANDARD",
  STRIPE_PRICE_BUSINESS: "price_BUNDLE_CANARY_BUSINESS",
};

/**
 * 組み立て済みのお返事に、1 つも出てきてはいけない語です。
 *
 * 鍵の環境変数の「名前」は入れません（サーバーの側のコードに入るのは正しい姿です）。
 * ここで見るのは、そのまま届いたら困るものだけです。
 *
 *   ① 鍵そのものの形
 *   ② ブラウザにお渡ししない欄の名前（行をまるごと部品へ渡すと、この字が出ます）
 *
 * 目印の値は、呼ぶ側が別に渡します（CANARY_ENV）。
 */
export const FORBIDDEN_IN_PRERENDER = [
  "service_role",
  "sk_live_",
  "sk_test_",
  "whsec_",
  // 料金の設定の内側（Price の環境変数の名前を持つ欄）です
  "priceEnvName",
  // 決済の契約の番号です（表の列の名前と、この土台での欄の名前の両方を見ます）
  "stripeSubscriptionId",
  "stripe_subscription_id",
  // ご招待のトークンのハッシュです
  "tokenHash",
  "token_hash",
];

/** 組み立て済みのお返事として、そのままブラウザへ届くファイルの種類です */
export const PRERENDER_EXTENSIONS = [".html", ".rsc", ".body", ".meta"];

/** ブラウザに配られるものの置き場です */
export function clientBundleDir(root) {
  return join(root, ".next", "static");
}

/** 組み立て済みのお返事の置き場です（この下の一部だけを調べます） */
export function prerenderDir(root) {
  return join(root, ".next", "server");
}

function filesUnder(dir, out = []) {
  let entries;
  try {
    entries = readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }

  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) filesUnder(path, out);
    else if (entry.isFile()) out.push(path);
  }
  return out;
}

/**
 * dir の下のファイルを残らず読み、terms の語が字面で出てくるものを報告します。
 *
 * **.js だけを見ることはしません。** 設定の写しや見た目の指定も、そのままブラウザへ配られるためです。
 * dir が無いときは、何も報告しません（ご案内は呼んだ側で出します）。
 */
export function scanBundle(dir, terms = FORBIDDEN_IN_CLIENT) {
  const hits = [];
  for (const path of filesUnder(dir)) {
    let text;
    try {
      text = readFileSync(path, "utf8");
    } catch {
      continue;
    }
    for (const term of terms) {
      if (text.includes(term)) hits.push({ file: relative(dir, path), term });
    }
  }
  return hits;
}

/** dir の下の「組み立て済みのお返事」だけを並べます（無いときは空です） */
export function prerenderFiles(dir) {
  return filesUnder(dir).filter((path) =>
    PRERENDER_EXTENSIONS.some((extension) => path.endsWith(extension)),
  );
}

/**
 * dir の下の「組み立て済みのお返事」だけを読み、terms の語が出てくるものを報告します。
 *
 * **.js と .json は読みません。** サーバーの中だけで読まれるもので、
 * 鍵の名前がそこに出てくるのは正しい姿だからです。
 * dir が無いときは、何も報告しません。
 */
export function scanPrerender(dir, terms = FORBIDDEN_IN_PRERENDER) {
  const hits = [];
  for (const path of prerenderFiles(dir)) {
    let text;
    try {
      text = readFileSync(path, "utf8");
    } catch {
      continue;
    }
    for (const term of terms) {
      if (text.includes(term)) hits.push({ file: relative(dir, path), term });
    }
  }
  return hits;
}

/**
 * 調べ終わったあとの合否です。
 *
 * 「調べて何も無かった」と「そもそも調べていない」を取り違えないために、
 * 読めたものが 1 本も無いときだけでなく、**取れなかった画面が 1 本でもあれば赤**にします。
 * いちばん見たい画面（ログインの要る `/app/settings/billing` など）だけが黙って落ちても、
 * 緑で終わらないようにするためです。
 */
export function verdict({ found, scannedFiles, scannedBodies, notFetched }) {
  if (scannedFiles === 0) {
    return { ok: false, message: "調べたファイルが 1 本もありません（組み立ての置き場が空です）" };
  }
  if (scannedBodies === 0) {
    return { ok: false, message: "画面のお返事を 1 本も取れませんでした（立てたサーバーを調べられていません）" };
  }
  if (notFetched > 0) {
    return { ok: false, message: `取れなかった画面が ${notFetched} 本あります（上の ⚠ をご覧ください）` };
  }
  if (found > 0) {
    return {
      ok: false,
      message: `合わせて ${found} 件です。画面の部品からサーバーのファイルを読み込んでいないか、import の道すじをお確かめください。`,
    };
  }
  return { ok: true, message: "" };
}

/**
 * 受け取った本文（名前と中身の組）に、terms の語が出てくるものを報告します。
 * 立てたサーバーから取ってきたお返事を調べるために使います。
 */
export function scanTexts(entries, terms) {
  const hits = [];
  for (const entry of entries) {
    for (const term of terms) {
      if (entry.text.includes(term)) hits.push({ file: entry.name, term });
    }
  }
  return hits;
}

// ---- ここから下は、直に呼ばれたときの進め方です ----

const packageRoot = fileURLToPath(new URL("../", import.meta.url));

/** 目印の値そのものを探すための語です */
const CANARY_TERMS = [...new Set(Object.values(CANARY_ENV))];

/** ログインの要らない画面です。どちらの組み立てでも必ず取ってきます */
const PUBLIC_PATHS = ["/", "/login", "/legal/terms"];

/** 見本の方でお入りいただいてから取ってくる画面です（見本のしくみの組み立てだけ） */
const SIGNED_IN_PATHS = ["/app", "/app/settings/billing"];

const BUILDS = [
  {
    label: "見本のしくみ（STARTER_FAKE=1）",
    /**
     * 本番の組み立て（next build は NODE_ENV=production です）で見本のしくみに入るには、
     * STARTER_FAKE=1 だけでは足りません（src/server/ports.ts の isFakeMode）。
     * 目印の値のほうを上書きして、見本の道（見本の方・偽の Checkout）が
     * 束に入るかどうかを、ここで本当に確かめます。
     */
    env: { STARTER_FAKE: "1", STARTER_FAKE_ALLOW_PRODUCTION: "1" },
    /** 見本の方でお入りいただいた状態の画面も取ってきます */
    signIn: true,
  },
  {
    label: "鍵を入れた形",
    env: {
      STARTER_FAKE: null,
      NEXT_PUBLIC_SUPABASE_URL: "https://check-bundle.supabase.co",
      NEXT_PUBLIC_SUPABASE_ANON_KEY: "anon-key-for-check",
      NEXT_PUBLIC_SITE_URL: "http://localhost:3020",
      MAIL_FROM: "no-reply@example.com",
    },
    // 鍵が偽物なので、ログインの要る画面はお開きになれません（外へつなぎに行きます）
    signIn: false,
  },
];

/**
 * 取らないポートです。
 *   3010〜3013 … ほかの案件の開発用によく使われます
 *   3020〜3022 … この土台の npm run dev / npm run start が使います
 *   54321〜54329 … Supabase のローカルの既定のポートです
 *   55320〜55329 … 2 つ目の Supabase をずらして立てるときによく使う帯です
 * 空きは OS に選んでもらいますので、ここに当たることはまずありません。
 */
function isReservedPort(port) {
  if (port >= 3010 && port <= 3013) return true;
  if (port >= 3020 && port <= 3022) return true;
  if (port >= 54321 && port <= 54329) return true;
  if (port >= 55320 && port <= 55329) return true;
  return false;
}

/** 空いているポートを OS に選んでもらいます（0 番で開いて、番号だけ受け取ります） */
function openPort() {
  return new Promise((resolve, reject) => {
    const probe = createServer();
    probe.on("error", reject);
    probe.listen(0, "127.0.0.1", () => {
      const { port } = probe.address();
      probe.close(() => resolve(port));
    });
  });
}

async function freePort() {
  for (let i = 0; i < 20; i += 1) {
    const port = await openPort();
    if (!isReservedPort(port)) return port;
  }
  throw new Error("空いているポートを見つけられませんでした");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 立ち上がるまで待ちます（60 秒まで） */
async function waitForServer(origin) {
  for (let i = 0; i < 120; i += 1) {
    try {
      const response = await fetch(`${origin}/`, { redirect: "manual" });
      if (response.status > 0) return true;
    } catch {
      // まだ立ち上がっていません
    }
    await sleep(500);
  }
  return false;
}

function unescapeHtml(text) {
  return text
    .replaceAll("&quot;", '"')
    .replaceAll("&#x27;", "'")
    .replaceAll("&#39;", "'")
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replaceAll("&amp;", "&");
}

/**
 * `/login` の中から、見本の方のフォームを 1 つ取り出します。
 *
 * JavaScript の動かないブラウザでも押していただけるよう、Next は
 * その form に隠しの欄（`$ACTION_…`）を書き出します。
 * その欄をそのまま送り返せば、ブラウザと同じようにお申し付けできます。
 */
function demoSignInForm(html) {
  for (const chunk of html.split("<form").slice(1)) {
    const body = chunk.split("</form>")[0] ?? "";
    if (!body.includes('name="userId"')) continue;

    const fields = [];
    for (const input of body.matchAll(/<input[^>]*>/g)) {
      const tag = input[0];
      if (!tag.includes('type="hidden"')) continue;
      const name = tag.match(/name="([^"]*)"/)?.[1];
      if (name === undefined) continue;
      fields.push([unescapeHtml(name), unescapeHtml(tag.match(/value="([^"]*)"/)?.[1] ?? "")]);
    }

    const button = body.match(/<button[^>]*name="userId"[^>]*>/)?.[0] ?? "";
    const userId = button.match(/value="([^"]*)"/)?.[1];
    if (userId === undefined || fields.length === 0) continue;

    return { fields, userId };
  }
  return null;
}

/**
 * 見本の方（いちばん上のオーナー）でお入りいただきます。
 *
 * 見本のしくみのセッションはサーバーのメモリに 1 つだけなので、
 * これが通れば、あとのお申し付けはすべてその方としてご覧になれます。
 */
async function signInAsDemoOwner(origin) {
  const page = await fetch(`${origin}/login`);
  if (!page.ok) return { ok: false, why: `/login が ${page.status} でした` };

  const form = demoSignInForm(await page.text());
  if (form === null) {
    return { ok: false, why: "/login に見本の方のフォームが見つかりませんでした" };
  }

  const body = new FormData();
  for (const [name, value] of form.fields) body.set(name, value);
  body.set("userId", form.userId);

  const posted = await fetch(`${origin}/login`, {
    method: "POST",
    body,
    // Server Action は Origin と Host を突き合わせます（ブラウザと同じ形で送ります）
    headers: { origin },
    redirect: "manual",
  });
  if (posted.status >= 400) {
    return { ok: false, why: `ログインのお申し付けが ${posted.status} でした` };
  }
  return { ok: true, userId: form.userId };
}

/** 画面のお返事を取ってきます。200 以外はその旨をお返しします */
async function fetchPaths(origin, paths) {
  const bodies = [];
  const failures = [];

  for (const path of paths) {
    try {
      const response = await fetch(`${origin}${path}`, { redirect: "manual" });
      const text = await response.text();
      if (response.status !== 200) {
        failures.push(`${path}（${response.status}）`);
        continue;
      }
      bodies.push({ name: `お返事 ${path}`, text });
    } catch (error) {
      failures.push(`${path}（${error instanceof Error ? error.message : "取れませんでした"}）`);
    }
  }
  return { bodies, failures };
}

/**
 * 組み立てたものを立ててから、画面のお返事を取ってきます。
 * **立てたサーバーは、途中で落ちても必ず止めます。**
 */
async function fetchLiveResponses(build, merged) {
  const port = await freePort();
  const origin = `http://127.0.0.1:${port}`;
  const next = join(packageRoot, "node_modules", ".bin", "next");

  console.log(`\n▶ ${build.label} を ${port} 番で立てて、画面のお返事を調べます…`);
  const server = spawn(next, ["start", "--port", String(port)], {
    cwd: packageRoot,
    env: merged,
    stdio: ["ignore", "ignore", "inherit"],
  });

  try {
    if (!(await waitForServer(origin))) {
      return { bodies: [], failures: [`${build.label}: サーバーが立ち上がりませんでした`] };
    }

    const paths = [...PUBLIC_PATHS];
    const failures = [];

    if (build.signIn) {
      const signedIn = await signInAsDemoOwner(origin);
      if (signedIn.ok) paths.push(...SIGNED_IN_PATHS);
      else failures.push(`見本の方でお入りになれませんでした（${signedIn.why}）`);
    }

    const fetched = await fetchPaths(origin, paths);
    return { bodies: fetched.bodies, failures: [...failures, ...fetched.failures] };
  } finally {
    server.kill("SIGTERM");
    await new Promise((resolve) => {
      const done = setTimeout(() => {
        server.kill("SIGKILL");
        resolve();
      }, 5000);
      server.on("exit", () => {
        clearTimeout(done);
        resolve();
      });
    });
    console.log(`  ${port} 番のサーバーを止めました。`);
  }
}

/** その組み立てで使う環境です（目印の値のうえに、その形の設定をかぶせます） */
function envFor(env) {
  const merged = { ...process.env, ...CANARY_ENV, ...env };
  for (const [name, value] of Object.entries(env)) {
    if (value === null) delete merged[name];
  }
  return merged;
}

function buildWith(env, label) {
  const merged = envFor(env);

  console.log(`\n▶ ${label} で組み立てます…`);
  rmSync(clientBundleDir(packageRoot), { recursive: true, force: true });
  rmSync(prerenderDir(packageRoot), { recursive: true, force: true });

  const next = join(packageRoot, "node_modules", ".bin", "next");
  const result = spawnSync(next, ["build"], { cwd: packageRoot, env: merged, stdio: "inherit" });
  if (result.status !== 0) {
    console.error(`\n組み立てに失敗しました（${label}）。先に npm run build をお確かめください。`);
    process.exit(1);
  }
}

function report(hits, label) {
  if (hits.length === 0) {
    console.log(`✓ ${label}: お渡ししてはいけない字はありませんでした`);
    return 0;
  }

  console.error(`\n✗ ${label}: お渡ししてはいけない字が見つかりました`);
  for (const hit of hits) console.error(`  ${hit.file}: ${hit.term}`);
  return hits.length;
}

/**
 * いま置かれている 2 か所と、受け取ったお返事を、ひととおり調べます。
 * 見つけた件数と、実際に読んだ本数をお返しします。
 */
function scanBoth(label, bodies = []) {
  const client = clientBundleDir(packageRoot);
  const prerender = prerenderDir(packageRoot);

  const clientCount = filesUnder(client).length;
  const prerenderCount = prerenderFiles(prerender).length;

  let found = 0;
  found += report(scanBundle(client), `${label}・ブラウザに配る束（${clientCount} 本）`);
  found += report(
    scanBundle(client, CANARY_TERMS),
    `${label}・ブラウザに配る束（目印の値／${clientCount} 本）`,
  );
  found += report(
    scanPrerender(prerender),
    `${label}・組み立て済みのお返事（${prerenderCount} 本）`,
  );
  found += report(
    scanPrerender(prerender, CANARY_TERMS),
    `${label}・組み立て済みのお返事（目印の値／${prerenderCount} 本）`,
  );

  if (bodies.length > 0) {
    const names = bodies.map((body) => body.name.replace("お返事 ", "")).join("・");
    found += report(
      scanTexts(bodies, FORBIDDEN_IN_PRERENDER),
      `${label}・立てたサーバーのお返事（${bodies.length} 本: ${names}）`,
    );
    found += report(
      scanTexts(bodies, CANARY_TERMS),
      `${label}・立てたサーバーのお返事（目印の値／${bodies.length} 本）`,
    );
  }

  return { found, clientCount, prerenderCount, bodyCount: bodies.length };
}

function scanOnly() {
  const dir = clientBundleDir(packageRoot);
  if (!existsSync(dir) || !statSync(dir).isDirectory()) {
    console.error("組み立てたものが見つかりません。先に npm run build を実行してください。");
    process.exit(1);
  }

  const scanned = scanBoth("いま置かれているもの");
  if (scanned.clientCount === 0) {
    console.error("\n✗ 調べたファイルが 1 本もありません（.next/static が空です）");
    process.exit(1);
  }
  console.log(
    "\n※ --scan-only は、いま置かれているものだけを読みます。" +
      "お申し付けごとに組み立てる画面は、ここには出てきません（弱い確かめです）。",
  );
  process.exit(scanned.found === 0 ? 0 : 1);
}

async function buildAndScan() {
  let found = 0;
  let scannedFiles = 0;
  let scannedBodies = 0;
  const notFetched = [];

  for (const build of BUILDS) {
    buildWith(build.env, build.label);

    const live = await fetchLiveResponses(build, envFor(build.env));
    for (const failure of live.failures) notFetched.push(`${build.label}: ${failure}`);

    const scanned = scanBoth(build.label, live.bodies);
    found += scanned.found;
    scannedFiles += scanned.clientCount + scanned.prerenderCount;
    scannedBodies += scanned.bodyCount;
  }

  // 調べ終わったら、目印の値で組み立てたものを残しません。
  // うっかりこのまま配ったり置いたりすると、偽の鍵で動くことになります。
  rmSync(join(packageRoot, ".next"), { recursive: true, force: true });

  for (const line of notFetched) console.error(`⚠ ${line}`);

  const result = verdict({ found, scannedFiles, scannedBodies, notFetched: notFetched.length });
  if (!result.ok) {
    console.error(`\n✗ ${result.message}`);
    process.exit(1);
  }

  console.log(
    `\n✓ 2 通りとも、ブラウザへ届くものに鍵はありませんでした` +
      `（組み立てたもの ${scannedFiles} 本・画面のお返事 ${scannedBodies} 本を読みました）`,
  );
  console.log("  組み立てたものは、目印の値が入っているので消しました。");
  console.log("  配る前・置く前は、npm run build を取り直してください。");
}

function isMain() {
  const invoked = process.argv[1];
  return invoked !== undefined && invoked === fileURLToPath(import.meta.url);
}

if (isMain()) {
  if (process.argv.includes("--scan-only")) scanOnly();
  else await buildAndScan();
}
