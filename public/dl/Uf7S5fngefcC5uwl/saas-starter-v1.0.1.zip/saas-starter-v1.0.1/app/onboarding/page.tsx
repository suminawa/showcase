/**
 * はじめの組織をお作りいただく画面です（ログインが要ります）。
 * すでに組織をお持ちの方は、そのまま /app へお通しします。
 */
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { createOrganizationAction } from "@/app/_actions/organizations";
import { signOutAction } from "@/app/_actions/auth";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";

export default async function OnboardingPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/onboarding"));
  if (gate.status === "not_member") notFound();
  if (gate.status === "ok") redirect("/app");

  const messages = messagesFor(gate.lang);

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <div className={`${ui.panel} ${ui.stack}`}>
          <div className={ui.stackTight}>
            <h1 className={ui.cardTitle}>{t(messages, "onboarding.title")}</h1>
            <p className={ui.cardHint}>{t(messages, "onboarding.lead")}</p>
          </div>

          <ActionForm
            action={createOrganizationAction}
            messages={messages}
            className={ui.stack}
            label={t(messages, "onboarding.title")}
          >
            <Field
              name="name"
              label={t(messages, "field.organizationName")}
              hint={t(messages, "onboarding.nameHint")}
              maxLength={60}
              required
            />
            <SubmitButton tone="primary">{t(messages, "onboarding.submit")}</SubmitButton>
          </ActionForm>
        </div>

        <div className={ui.stackTight}>
          <p className={ui.hint}>
            {t(messages, "onboarding.signedInAs", { email: gate.user.email })}
          </p>
          <ActionForm action={signOutAction} messages={messages}>
            <SubmitButton tone="quiet" size="small">
              {t(messages, "nav.signout")}
            </SubmitButton>
          </ActionForm>
        </div>
      </div>
    </main>
  );
}
