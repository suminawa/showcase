/**
 * 運営の方だけがご覧になる画面です。**読むだけで、何も書き換えません。**
 *
 * 関門は、この画面が自分で通します。
 *   ① ADMIN_EMAILS を頂戴していなければ、この画面があることもお知らせしません
 *   ② ログインしている方を、認証の口から引き直します（cookie やプロフィールの値は見ません）
 *   ③ そのメールアドレスが ADMIN_EMAILS にあるかどうかを、isAdminEmail に尋ねます
 *
 * いずれも、通らなければ **404** をお返しします（403 でもログインへのご案内でもありません。
 * この画面があること自体を、外からは分からないようにするためです）。
 *
 * adminOverviewFlow は権限を確かめません。すべての組織の行をお返しするので、
 * ③ を通す前に呼んではいけません。
 */
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { ReactNode } from "react";
import { formatDate, t, type Lang, type Messages } from "@/src/core/i18n";
import type { PlanId } from "@/src/core/plans";
import type { AdminOrgRow, AdminSubscriptionRow, Profile } from "@/src/ports";
import {
  ADMIN_PER_PAGE,
  adminOverviewFlow,
  adminPageFrom,
  isAdminEmail,
} from "@/src/server/flows/admin";
import { messagesFor } from "@/src/server/messages";
import { adminEmails, getPorts, getRequestLang } from "@/src/server/ports";
import { firstParam } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "./admin.module.css";

/** お客さまごとに中身が変わる画面です。組み立て済みのものを取り置きしません */
export const dynamic = "force-dynamic";

/** 検索の結果に出さないようにします（notFound() のときは Next が同じ印を付けます） */
export const metadata: Metadata = {
  robots: { index: false, follow: false, nocache: true },
};

function planName(planId: PlanId, messages: Messages): string {
  switch (planId) {
    case "standard":
      return t(messages, "plan.standard.name");
    case "business":
      return t(messages, "plan.business.name");
    default:
      return t(messages, "plan.free.name");
  }
}

/**
 * ご契約の状態を、そのままお読みいただける文にします。
 * 鍵はお支払いの画面と同じものです（同じ言葉でお伝えするためです）。
 */
function statusText(status: string, messages: Messages): string {
  switch (status) {
    case "active":
      return t(messages, "billing.status.active");
    case "trialing":
      return t(messages, "billing.status.trialing");
    case "past_due":
      return t(messages, "billing.status.past_due");
    case "unpaid":
      return t(messages, "billing.status.unpaid");
    case "canceled":
      return t(messages, "billing.status.canceled");
    case "incomplete":
      return t(messages, "billing.status.incomplete");
    case "incomplete_expired":
      return t(messages, "billing.status.incomplete_expired");
    case "paused":
      return t(messages, "billing.status.paused");
    default:
      return t(messages, "billing.status.none");
  }
}

function Section({
  title,
  count,
  empty,
  children,
}: {
  title: string;
  count: string;
  empty: string;
  children: ReactNode;
}): ReactNode {
  return (
    <section className={ui.stack}>
      <div className={ui.rowBetween}>
        <h2 className={ui.cardTitle}>{title}</h2>
        <span className={ui.muted}>{count}</span>
      </div>
      {children === null ? (
        <div className={ui.empty}>
          <p className={ui.emptyHint}>{empty}</p>
        </div>
      ) : (
        <ul className={ui.rows}>{children}</ul>
      )}
    </section>
  );
}

/** プランと状態の札です（この 2 つだけを、行の右側に出します） */
function Tags({
  planId,
  status,
  messages,
}: {
  planId: PlanId;
  status: string;
  messages: Messages;
}): ReactNode {
  return (
    <span className={ui.rowActions}>
      <span className={ui.badge}>{planName(planId, messages)}</span>
      <span className={ui.badge}>{statusText(status, messages)}</span>
    </span>
  );
}

export default async function AdminPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}): Promise<ReactNode> {
  // ① 一覧を頂戴していないあいだは、この画面はどなたにもお見せしません
  const allowed = adminEmails();
  if (allowed === undefined) notFound();

  // ② いまログインしている方を、認証の口から引き直します。
  //
  // 鍵をまだ頂戴していないときは、getPorts() が投げます。そのまま投げさせると、
  // 「ADMIN_EMAILS は入っているが鍵が無い」ときだけ 404 ではなく 500 になり、
  // この画面があることが外から分かってしまいます。ここでは 404 にそろえます。
  let ports;
  try {
    ports = await getPorts();
  } catch {
    notFound();
  }

  const user = await ports.auth.getUser();
  if (user === null) notFound();

  // ③ 関門です。ここを通さずに一覧を読んではいけません
  if (!isAdminEmail(user.email, allowed)) notFound();

  const lang: Lang = await getRequestLang(user.lang);
  const messages = messagesFor(lang);

  const page = adminPageFrom(firstParam(await searchParams, "page"));
  const overview = await adminOverviewFlow({ ports, page, perPage: ADMIN_PER_PAGE });
  if (!overview.ok) notFound();

  const { organizations, profiles, subscriptions } = overview.value;

  const full = ADMIN_PER_PAGE;
  const hasNext =
    organizations.length === full || profiles.length === full || subscriptions.length === full;

  return (
    <div className={styles.shell}>
      <header className={styles.topbar}>
        <div className={styles.topbarInner}>
          <Link className={styles.brand} href="/app">
            {t(messages, "common.appName")}
          </Link>
          <span className={ui.badge}>{t(messages, "admin.title")}</span>
        </div>
      </header>

      <main className={styles.main}>
        <div className={styles.head}>
          <h1 className={styles.title}>{t(messages, "admin.title")}</h1>
          <p className={styles.lead}>{t(messages, "admin.lead")}</p>
        </div>

        <p className={`${ui.notice} ${ui.noticeWarn}`}>
          <span className={ui.noticeBody}>
            <span>{t(messages, "admin.notice")}</span>
            <span className={ui.muted}>{t(messages, "admin.readOnly")}</span>
          </span>
        </p>

        <div className={styles.sections}>
          <Section
            title={t(messages, "admin.organizationsTitle")}
            count={t(messages, "admin.countOnPage", { count: organizations.length })}
            empty={t(messages, "admin.organizationEmpty")}
          >
            {organizations.length === 0
              ? null
              : organizations.map((row: AdminOrgRow) => (
                  <li className={ui.rowItem} key={row.organization.id}>
                    <span className={ui.rowMain}>
                      <span className={ui.rowName}>{row.organization.name}</span>
                      <span className={ui.rowMeta}>
                        {t(messages, "admin.memberCount", { count: row.memberCount })}
                      </span>
                      <span className={ui.rowMeta}>
                        {t(messages, "admin.projectCount", { count: row.projectCount })}
                      </span>
                      <span className={ui.rowMeta}>
                        {t(messages, "admin.createdOn", {
                          date: formatDate(row.organization.createdAt, lang),
                        })}
                      </span>
                    </span>
                    <Tags planId={row.planId} status={row.status} messages={messages} />
                  </li>
                ))}
          </Section>

          <Section
            title={t(messages, "admin.profilesTitle")}
            count={t(messages, "admin.countOnPage", { count: profiles.length })}
            empty={t(messages, "admin.profileEmpty")}
          >
            {profiles.length === 0
              ? null
              : profiles.map((profile: Profile) => (
                  <li className={ui.rowItem} key={profile.id}>
                    <span className={ui.rowMain}>
                      <span className={ui.rowName}>{profile.name}</span>
                      <span className={`${ui.rowMeta} ${ui.breakWord}`}>{profile.email}</span>
                      <span className={ui.rowMeta}>
                        {t(messages, "admin.registeredOn", {
                          date: formatDate(profile.createdAt, lang),
                        })}
                      </span>
                    </span>
                  </li>
                ))}
          </Section>

          <Section
            title={t(messages, "admin.subscriptionsTitle")}
            count={t(messages, "admin.countOnPage", { count: subscriptions.length })}
            empty={t(messages, "admin.subscriptionEmpty")}
          >
            {subscriptions.length === 0
              ? null
              : subscriptions.map((row: AdminSubscriptionRow) => (
                  <li className={ui.rowItem} key={row.organizationId}>
                    <span className={ui.rowMain}>
                      <span className={ui.rowName}>{row.organizationName}</span>
                      <span className={ui.rowMeta}>
                        {t(messages, "admin.periodEnd", {
                          date:
                            row.currentPeriodEnd === null
                              ? t(messages, "common.none")
                              : formatDate(row.currentPeriodEnd, lang),
                        })}
                      </span>
                    </span>
                    <Tags planId={row.planId} status={row.status} messages={messages} />
                  </li>
                ))}
          </Section>
        </div>

        <nav className={styles.pager} aria-label={t(messages, "admin.pagerLabel")}>
          {page > 1 ? (
            <Link className={`${ui.button} ${ui.small}`} href={`/admin?page=${page - 1}`}>
              {t(messages, "admin.prev")}
            </Link>
          ) : (
            <span />
          )}
          <span className={ui.muted}>{t(messages, "admin.pageNumber", { page })}</span>
          {hasNext ? (
            <Link className={`${ui.button} ${ui.small}`} href={`/admin?page=${page + 1}`}>
              {t(messages, "admin.next")}
            </Link>
          ) : (
            <span />
          )}
        </nav>
      </main>
    </div>
  );
}
