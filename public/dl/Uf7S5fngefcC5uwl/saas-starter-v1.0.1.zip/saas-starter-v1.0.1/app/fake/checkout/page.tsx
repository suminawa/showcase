/**
 * 見本のお支払いの画面です。
 *
 * **STARTER_FAKE=1 のときだけ**あります。鍵をご用意いただいたあとは、
 * この道すじは「見つかりません」をお返しし、本物の Stripe の画面へお進みいただきます。
 * ここで押していただくと、本物の通知（Webhook）と同じ道をたどって、ご契約が表に入ります。
 */
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { formatYen, t } from "@/src/core/i18n";
import { findPlan, isPlanId } from "@/src/core/plans";
import { fakeCancelAction, fakeCheckoutCompleteAction } from "@/app/_actions/billing";
import { ActionForm } from "@/app/_components/ActionForm";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { messagesFor } from "@/src/server/messages";
import { appGate, isFakeMode } from "@/src/server/ports";
import { firstParam, loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";

export default async function FakeCheckoutPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}): Promise<ReactNode> {
  if (!isFakeMode()) notFound();

  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/settings/billing"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const params = await searchParams;
  const requested = firstParam(params, "plan");

  // お手続きの画面（Customer Portal）の代わりです
  if (requested === "portal") {
    return (
      <main className={ui.centered}>
        <div className={ui.centeredWrap}>
          <div className={`${ui.panel} ${ui.stack}`}>
            <div className={ui.stackTight}>
              <h1 className={ui.cardTitle}>{t(messages, "fake.portalTitle")}</h1>
              <p className={ui.cardHint}>{t(messages, "fake.portalLead")}</p>
            </div>

            <p className={`${ui.notice} ${ui.noticeWarn}`}>{t(messages, "fake.notice")}</p>

            <ActionForm
              action={fakeCancelAction}
              messages={messages}
              className={ui.row}
              label={t(messages, "fake.cancelSubmit")}
            >
              <SubmitButton tone="danger">{t(messages, "fake.cancelSubmit")}</SubmitButton>
            </ActionForm>
          </div>
        </div>
      </main>
    );
  }

  // お申し込みの画面（Checkout）の代わりです
  const plan = isPlanId(requested) ? findPlan(requested) : null;
  if (plan === null || plan.id === "free") notFound();

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <div className={`${ui.panel} ${ui.stack}`}>
          <div className={ui.stackTight}>
            <h1 className={ui.cardTitle}>{t(messages, "fake.checkoutTitle")}</h1>
            <p className={ui.cardHint}>
              {t(messages, "fake.checkoutLead", { organization: ctx.organization.name })}
            </p>
          </div>

          <dl className={ui.rows}>
            <div className={ui.rowItem}>
              <dt className={ui.rowMain}>
                <span className={ui.rowName}>{t(messages, plan.nameKey)}</span>
                <span className={ui.rowMeta}>{t(messages, plan.descriptionKey)}</span>
              </dt>
              <dd className={ui.strong}>
                {formatYen(plan.monthlyYen, ctx.lang)}
                {t(messages, "plan.perMonth")}
              </dd>
            </div>
          </dl>

          <p className={`${ui.notice} ${ui.noticeWarn}`}>{t(messages, "fake.notice")}</p>

          <ActionForm
            action={fakeCheckoutCompleteAction}
            messages={messages}
            className={ui.stack}
            label={t(messages, "fake.checkoutSubmit")}
          >
            <input type="hidden" name="planId" value={plan.id} />
            <div className={ui.row}>
              <SubmitButton tone="primary">{t(messages, "fake.checkoutSubmit")}</SubmitButton>
            </div>
          </ActionForm>
        </div>
      </div>
    </main>
  );
}
