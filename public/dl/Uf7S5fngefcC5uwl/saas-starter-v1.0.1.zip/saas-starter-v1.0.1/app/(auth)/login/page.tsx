/**
 * ログインの画面です（ログインは要りません）。
 *
 * 入り方は 2 つ（メールとパスワード／メールのリンク）で、
 * Google のボタンは NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN を入れたときだけ出ます。
 * STARTER_FAKE=1 のあいだは、見本の方を選んでお入りいただけます。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { FLOW_ERROR_CODES } from "@/src/server/context";
import {
  fakeSignInAction,
  googleSignInAction,
  magicLinkAction,
  signInAction,
} from "@/app/_actions/auth";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { RoleBadge } from "@/app/_components/RoleBadge";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { fakeDemoUsers, googleLoginEnabled, isFakeMode, pageMessages } from "@/src/server/ports";
import { firstParam, isSafeNextPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../auth.module.css";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}): Promise<ReactNode> {
  const { messages } = await pageMessages();

  const params = await searchParams;
  const requested = firstParam(params, "next");
  const next = requested !== null && isSafeNextPath(requested) ? requested : null;

  // メールのリンクの受け口から戻された符号だけを、文に写してお出しします
  const failed = firstParam(params, "error");
  const failedKey =
    failed !== null && (FLOW_ERROR_CODES as readonly string[]).includes(failed)
      ? `error.${failed}`
      : null;

  const demoUsers = isFakeMode() ? await fakeDemoUsers() : [];

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <Link className={styles.brand} href="/">
          {t(messages, "common.appName")}
        </Link>

        <div className={ui.panel}>
          <h1 className={styles.title}>{t(messages, "auth.login.title")}</h1>
          <p className={styles.lead}>{t(messages, "auth.login.lead")}</p>

          {failedKey === null ? null : (
            <p className={`${ui.notice} ${ui.noticeDanger} ${styles.form}`} role="status">
              {t(messages, failedKey)}
            </p>
          )}

          <ActionForm
            action={signInAction}
            messages={messages}
            className={styles.form}
            label={t(messages, "auth.login.title")}
          >
            {next === null ? null : <input type="hidden" name="next" value={next} />}
            <Field
              name="email"
              type="email"
              label={t(messages, "field.email")}
              autoComplete="email"
              required
            />
            <Field
              name="password"
              type="password"
              label={t(messages, "field.password")}
              autoComplete="current-password"
              required
            />
            <SubmitButton tone="primary">{t(messages, "auth.login.submit")}</SubmitButton>
          </ActionForm>

          {/* パスワードをお忘れのときの導線です。この土台には再設定の画面がないため、
              メールのリンクでのログインへご案内します（README 2 章） */}
          <p className={ui.hint}>{t(messages, "auth.login.forgot")}</p>

          <p className={styles.divider}>{t(messages, "auth.or")}</p>

          <ActionForm
            action={magicLinkAction}
            messages={messages}
            className={styles.form}
            label={t(messages, "auth.magic.title")}
          >
            <Field
              name="email"
              type="email"
              label={t(messages, "field.email")}
              hint={t(messages, "auth.magic.hint")}
              autoComplete="email"
              required
            />
            <SubmitButton>{t(messages, "auth.magic.submit")}</SubmitButton>
          </ActionForm>

          {isFakeMode() || !googleLoginEnabled() ? null : (
            // 入り口の URL は、押していただいたときに組み立てます
            // （お戻りの中身をすり替えられないための控えを、そのときに cookie へ残します）
            <ActionForm
              action={googleSignInAction}
              messages={messages}
              className={styles.form}
              label={t(messages, "auth.google")}
            >
              {next === null ? null : <input type="hidden" name="next" value={next} />}
              <SubmitButton>{t(messages, "auth.google")}</SubmitButton>
            </ActionForm>
          )}
        </div>

        {demoUsers.length === 0 ? null : (
          <section className={styles.demo}>
            <h2 className={ui.sectionTitle}>{t(messages, "auth.demo.title")}</h2>
            <p className={ui.hint}>{t(messages, "auth.demo.hint")}</p>
            <ActionForm
              action={fakeSignInAction}
              messages={messages}
              className={styles.demoList}
              label={t(messages, "auth.demo.title")}
            >
              {next === null ? null : <input type="hidden" name="next" value={next} />}
              {demoUsers.map((demoUser) => (
                <SubmitButton
                  key={demoUser.id}
                  name="userId"
                  value={demoUser.id}
                  className={styles.demoButton}
                >
                  <span className={styles.demoName}>
                    {demoUser.name}
                    <span className={styles.demoMail}>{demoUser.email}</span>
                  </span>
                  {demoUser.role === null ? null : (
                    <RoleBadge role={demoUser.role} messages={messages} />
                  )}
                </SubmitButton>
              ))}
            </ActionForm>
          </section>
        )}

        <p className={styles.switch}>
          {t(messages, "auth.login.toSignup")} <Link href="/signup">{t(messages, "nav.signup")}</Link>
        </p>
      </div>
    </main>
  );
}
