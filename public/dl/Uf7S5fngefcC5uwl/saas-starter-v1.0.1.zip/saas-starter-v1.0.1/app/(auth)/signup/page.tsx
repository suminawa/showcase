/**
 * ご登録の画面です（ログインは要りません）。
 *
 * すでにご登録のメールアドレスかどうかは、画面ではお伝えしません
 * （どなたがご登録済みかを、外から確かめられないようにするためです）。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { signUpAction } from "@/app/_actions/auth";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { pageMessages } from "@/src/server/ports";
import ui from "@/app/_components/ui.module.css";
import styles from "../auth.module.css";

export default async function SignupPage(): Promise<ReactNode> {
  const { messages } = await pageMessages();

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <Link className={styles.brand} href="/">
          {t(messages, "common.appName")}
        </Link>

        <div className={ui.panel}>
          <h1 className={styles.title}>{t(messages, "auth.signup.title")}</h1>
          <p className={styles.lead}>{t(messages, "auth.signup.lead")}</p>

          <ActionForm
            action={signUpAction}
            messages={messages}
            className={styles.form}
            label={t(messages, "auth.signup.title")}
          >
            <Field
              name="email"
              type="email"
              label={t(messages, "field.email")}
              autoComplete="email"
              required
            />
            <Field
              name="password"
              type="password"
              label={t(messages, "field.password")}
              hint={t(messages, "auth.signup.passwordHint")}
              autoComplete="new-password"
              required
            />
            <SubmitButton tone="primary">{t(messages, "auth.signup.submit")}</SubmitButton>
          </ActionForm>
        </div>

        <p className={styles.switch}>
          {t(messages, "auth.signup.toLogin")} <Link href="/login">{t(messages, "nav.login")}</Link>
        </p>

        <div className={styles.legal}>
          <p>{t(messages, "auth.signup.legalNote")}</p>
          <p className={styles.legalLinks}>
            <Link href="/legal/terms">{t(messages, "legal.terms.title")}</Link>
            <Link href="/legal/privacy">{t(messages, "legal.privacy.title")}</Link>
          </p>
        </div>
      </div>
    </main>
  );
}
