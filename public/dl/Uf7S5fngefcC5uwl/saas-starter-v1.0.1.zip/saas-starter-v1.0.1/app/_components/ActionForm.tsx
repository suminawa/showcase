"use client";

/**
 * Server Action を呼ぶフォームの入れ物です。
 *
 * ・送信のあいだは SubmitButton が押せなくなります（二重のお申し付けを防ぎます）
 * ・お返事（うまくいった／誤り）を、フォームの先頭に読み上げ付きでお出しします
 * ・どの欄の誤りかは、中の Field が自分で拾います
 *
 * 型だけを src/server から読んでいます（書き出したあとに消えるため、ブラウザには届きません）。
 */
import { createContext, useActionState, useContext, type ReactNode } from "react";
import { t, type Messages } from "@/src/core/i18n";
import type { FieldError } from "@/src/core/validation";
import type { ActionState } from "@/src/server/context";
import ui from "./ui.module.css";

const INITIAL: ActionState = { status: "idle" };

type FormContextValue = { state: ActionState; messages: Messages };

const FormContext = createContext<FormContextValue | null>(null);

/** 同じフォームの中の部品が、いまのお返事を受け取ります */
export function useActionFormContext(): FormContextValue {
  const found = useContext(FormContext);
  if (found === null) {
    throw new Error("This component must be used inside <ActionForm>.");
  }
  return found;
}

/** その欄に対する誤りだけを取り出します */
export function errorsForField(errors: FieldError[] | undefined, field: string): FieldError[] {
  if (errors === undefined) return [];
  return errors.filter((error) => error.field === field);
}

export type ActionFormProps = {
  action: (previous: ActionState, form: FormData) => Promise<ActionState>;
  messages: Messages;
  children: ReactNode;
  className?: string;
  /** 読み上げで、このフォームが何のためのものかをお伝えします */
  label?: string;
};

export function ActionForm({
  action,
  messages,
  children,
  className,
  label,
}: ActionFormProps): ReactNode {
  const [state, formAction] = useActionState(action, INITIAL);

  return (
    <FormContext.Provider value={{ state, messages }}>
      <form action={formAction} className={className} aria-label={label}>
        <div className={ui.formStatus} role="status" aria-live="polite">
          {state.status === "error" ? (
            <p className={`${ui.notice} ${ui.noticeDanger}`}>{t(messages, state.messageKey)}</p>
          ) : null}
          {state.status === "ok" && state.messageKey !== undefined ? (
            <p className={`${ui.notice} ${ui.noticeOk}`}>{t(messages, state.messageKey)}</p>
          ) : null}
          {state.status === "ok" && state.value !== undefined ? (
            <input
              className={ui.valueBox}
              type="text"
              value={state.value}
              readOnly
              aria-label={t(messages, "common.copyValue")}
              onFocus={(event) => event.currentTarget.select()}
            />
          ) : null}
        </div>
        {children}
      </form>
    </FormContext.Provider>
  );
}
