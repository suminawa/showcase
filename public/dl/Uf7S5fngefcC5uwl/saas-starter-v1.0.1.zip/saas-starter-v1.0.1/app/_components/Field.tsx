"use client";

/**
 * 入力の 1 欄です。
 *
 * ・label と入力が htmlFor でつながっています
 * ・誤りがあるときは aria-invalid と aria-describedby で、読み上げにもお伝えします
 * ・誤りの文は、検査の符号（required・bad_email など）を messages から引きます
 */
import { useId, type ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { errorsForField, useActionFormContext } from "./ActionForm";
import ui from "./ui.module.css";

export type FieldOption = { value: string; label: string };

export type FieldProps = {
  name: string;
  label: string;
  /** input の種類です。textarea と select は kind で選びます */
  type?: "text" | "email" | "password" | "url";
  kind?: "input" | "textarea" | "select";
  options?: FieldOption[];
  required?: boolean;
  hint?: string;
  defaultValue?: string;
  placeholder?: string;
  autoComplete?: string;
  maxLength?: number;
  rows?: number;
};

export function Field(props: FieldProps): ReactNode {
  const { state, messages } = useActionFormContext();
  const id = useId();

  const errors = errorsForField(state.status === "error" ? state.errors : undefined, props.name);
  const hasError = errors.length > 0;

  // 誤りでお戻りになったときは、お書きいただいた内容をそのままお出しします
  // （何もお預かりしていないときだけ、はじめの値に戻ります）。
  const kept = state.status === "error" ? state.values?.[props.name] : undefined;

  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  const describedBy = [props.hint === undefined ? null : hintId, hasError ? errorId : null]
    .filter((value) => value !== null)
    .join(" ");

  const shared = {
    id,
    name: props.name,
    required: props.required,
    defaultValue: kept ?? props.defaultValue,
    "aria-invalid": hasError,
    "aria-describedby": describedBy === "" ? undefined : describedBy,
  };

  return (
    <div className={ui.field}>
      <label className={ui.label} htmlFor={id}>
        {props.label}
        {props.required === true ? (
          <span className={ui.required}>{t(messages, "common.required")}</span>
        ) : null}
      </label>

      {props.hint === undefined ? null : (
        <p className={ui.hint} id={hintId}>
          {props.hint}
        </p>
      )}

      {props.kind === "textarea" ? (
        <textarea
          {...shared}
          className={ui.textarea}
          rows={props.rows ?? 3}
          maxLength={props.maxLength}
          placeholder={props.placeholder}
        />
      ) : null}

      {props.kind === "select" ? (
        <select {...shared} className={ui.select}>
          {(props.options ?? []).map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      ) : null}

      {props.kind === undefined || props.kind === "input" ? (
        <input
          {...shared}
          className={ui.input}
          type={props.type ?? "text"}
          maxLength={props.maxLength}
          placeholder={props.placeholder}
          autoComplete={props.autoComplete}
        />
      ) : null}

      {hasError ? (
        <p className={ui.fieldError} id={errorId}>
          {errors.map((error) => t(messages, `error.${error.code}`)).join(" ")}
        </p>
      ) : null}
    </div>
  );
}
