"use client";

/**
 * 画面の行き来です。
 *
 * いまお読みの画面に aria-current="page" を付けるため、ブラウザ側で道すじを見ています
 * （どの画面にいるのかが、見た目と読み上げの両方で分かるようにするためです）。
 */
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import ui from "./ui.module.css";

export type NavItem = {
  href: string;
  label: string;
  /** その画面の仲間をまとめて「いまここ」と見なすときの、道すじの頭です */
  match?: string;
};

export function Nav({
  items,
  label,
  tone = "main",
}: {
  items: NavItem[];
  label: string;
  tone?: "main" | "sub";
}): ReactNode {
  const pathname = usePathname();

  function isCurrent(item: NavItem): boolean {
    if (pathname === item.href) return true;

    const prefix = item.match ?? item.href;
    return prefix !== "/app" && pathname.startsWith(`${prefix}/`);
  }

  return (
    <nav className={tone === "sub" ? `${ui.nav} ${ui.navSub}` : ui.nav} aria-label={label}>
      {items.map((item) => {
        const current = isCurrent(item);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={current ? `${ui.navLink} ${ui.navCurrent}` : ui.navLink}
            aria-current={current ? "page" : undefined}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
