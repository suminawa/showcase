/**
 * 役割の札です（オーナー・管理者・メンバー）。
 * 色だけで見分けていただく作りにはせず、必ず文字でお出しします。
 */
import type { ReactNode } from "react";
import { t, type Messages } from "@/src/core/i18n";
import type { Role } from "@/src/core/permissions";
import ui from "./ui.module.css";

function roleLabel(role: Role, messages: Messages): string {
  switch (role) {
    case "owner":
      return t(messages, "role.owner");
    case "admin":
      return t(messages, "role.admin");
    default:
      return t(messages, "role.member");
  }
}

export function RoleBadge({ role, messages }: { role: Role; messages: Messages }): ReactNode {
  const toneClass = role === "owner" ? ui.badgeOwner : role === "admin" ? ui.badgeAdmin : "";

  return <span className={`${ui.badge} ${toneClass}`.trimEnd()}>{roleLabel(role, messages)}</span>;
}
