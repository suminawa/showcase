"use client";

/**
 * 送信のボタンです。
 * 送信のあいだは押せなくなり、進んでいることを輪の動きでお伝えします
 * （同じお申し付けが二重に届かないようにするためです）。
 */
import { useFormStatus } from "react-dom";
import type { ReactNode } from "react";
import ui from "./ui.module.css";

export type SubmitButtonProps = {
  children: ReactNode;
  tone?: "primary" | "plain" | "danger" | "quiet";
  size?: "medium" | "small";
  /** 1 つのフォームに押すところが複数あるとき、どれを押したかをお伝えします */
  name?: string;
  value?: string;
  className?: string;
};

export function SubmitButton({
  children,
  tone = "plain",
  size = "medium",
  name,
  value,
  className,
}: SubmitButtonProps): ReactNode {
  const { pending } = useFormStatus();

  const toneClass = tone === "plain" ? "" : ui[tone];
  const sizeClass = size === "small" ? ui.small : "";

  return (
    <button
      type="submit"
      name={name}
      value={value}
      className={`${ui.button} ${toneClass} ${sizeClass} ${className ?? ""}`.trimEnd()}
      disabled={pending}
      aria-busy={pending}
    >
      {pending ? <span className={ui.spinner} aria-hidden="true" /> : null}
      {children}
    </button>
  );
}
