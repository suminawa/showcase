/**
 * お支払いの状態をお知らせする帯です。
 *
 * ご契約が止まっているとき・お支払いが確かめられないとき・解約のご予約があるときに、
 * /app のすべての画面の上に出ます。機能は止めません（止めるかどうかは flow が決めます）。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import type { BillingBanner } from "@/src/core/billing-state";
import { t, type Messages } from "@/src/core/i18n";
import ui from "./ui.module.css";

function bannerText(banner: BillingBanner, messages: Messages): string | null {
  switch (banner) {
    case "past_due":
      return t(messages, "banner.past_due");
    case "unpaid":
      return t(messages, "banner.unpaid");
    case "canceled":
      return t(messages, "banner.canceled");
    case "cancel_scheduled":
      return t(messages, "banner.cancel_scheduled");
    case "paused":
      return t(messages, "banner.paused");
    case "incomplete":
      return t(messages, "banner.incomplete");
    default:
      return null;
  }
}

/**
 * 色の濃さです。
 * これからお手続きが進む見込みのあるもの（解約のご予約・お支払いの確認待ち）は
 * 控えめに、いま止まっているものははっきりお出しします。
 */
function toneClass(banner: BillingBanner): string {
  const soft = banner === "cancel_scheduled" || banner === "incomplete" || banner === "paused";
  return soft ? ui.noticeWarn : ui.noticeDanger;
}

export function Banner({
  banner,
  messages,
}: {
  banner: BillingBanner;
  messages: Messages;
}): ReactNode {
  const text = bannerText(banner, messages);
  if (text === null) return null;

  return (
    <div className={`${ui.notice} ${toneClass(banner)}`} role="status">
      <span className={ui.noticeBody}>
        <span>{text}</span>
        <Link href="/app/settings/billing">{t(messages, "banner.action")}</Link>
      </span>
    </div>
  );
}
