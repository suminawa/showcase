"use client";

/**
 * 画面を開き直したときにお出しする、1 行のお知らせです
 * （お支払いのお手続きから戻られたときなど）。
 * ひとりでには消えません。閉じるのはお客さまです。
 */
import { useState, type ReactNode } from "react";
import ui from "./ui.module.css";

export type ToastProps = {
  children: ReactNode;
  tone?: "ok" | "warn" | "danger";
  closeLabel: string;
};

export function Toast({ children, tone = "ok", closeLabel }: ToastProps): ReactNode {
  const [open, setOpen] = useState(true);
  if (!open) return null;

  const toneClass =
    tone === "danger" ? ui.noticeDanger : tone === "warn" ? ui.noticeWarn : ui.noticeOk;

  return (
    <div className={`${ui.notice} ${toneClass}`} role="status">
      <span className={ui.noticeBody}>{children}</span>
      <button type="button" className={ui.noticeClose} onClick={() => setOpen(false)}>
        {closeLabel}
      </button>
    </div>
  );
}
