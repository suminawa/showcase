/**
 * サービスのご紹介です（ログインは要りません）。
 * 料金の表は plans.config.ts から描いています。金額と件数を変えたいときは、そちらをどうぞ。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import { formatYen, t } from "@/src/core/i18n";
import { projectLimitOf, publicPlans } from "@/src/core/plans";
import { pageMessages } from "@/src/server/ports";
import ui from "./_components/ui.module.css";
import styles from "./page.module.css";

export default async function HomePage(): Promise<ReactNode> {
  const { lang, messages } = await pageMessages();
  const plans = publicPlans();

  const points = [
    { term: t(messages, "home.point1.title"), body: t(messages, "home.point1.body") },
    { term: t(messages, "home.point2.title"), body: t(messages, "home.point2.body") },
    { term: t(messages, "home.point3.title"), body: t(messages, "home.point3.body") },
  ];

  return (
    <div className={styles.page}>
      <header className={`${styles.inner} ${styles.header}`}>
        <span className={styles.brand}>{t(messages, "common.appName")}</span>
        <div className={styles.headerActions}>
          <Link className={`${ui.button} ${ui.quiet} ${ui.small}`} href="/login">
            {t(messages, "nav.login")}
          </Link>
          <Link className={`${ui.button} ${ui.primary} ${ui.small}`} href="/signup">
            {t(messages, "nav.signup")}
          </Link>
        </div>
      </header>

      <main>
        <section className={`${styles.inner} ${styles.hero}`}>
          <h1 className={styles.title}>{t(messages, "home.title")}</h1>
          <p className={styles.lead}>{t(messages, "home.lead")}</p>
          <div className={styles.heroActions}>
            <Link className={`${ui.button} ${ui.primary}`} href="/signup">
              {t(messages, "home.cta")}
            </Link>
            <Link className={ui.button} href="/login">
              {t(messages, "nav.login")}
            </Link>
          </div>
        </section>

        <section className={`${styles.inner} ${styles.section}`}>
          <h2 className={styles.sectionTitle}>{t(messages, "home.pointsTitle")}</h2>
          <dl className={styles.points}>
            {points.map((point) => (
              <div className={styles.point} key={point.term}>
                <dt className={styles.pointTerm}>{point.term}</dt>
                <dd className={styles.pointBody}>{point.body}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section className={`${styles.inner} ${styles.section}`} id="plans">
          <h2 className={styles.sectionTitle}>{t(messages, "home.plansTitle")}</h2>
          <div className={styles.plans}>
            {plans.map((plan) => {
              const limit = projectLimitOf(plan);
              return (
                <article className={styles.plan} key={plan.id}>
                  <h3 className={styles.planName}>{t(messages, plan.nameKey)}</h3>
                  <p className={styles.planPrice}>
                    {formatYen(plan.monthlyYen, lang)}
                    <span className={styles.planPer}>{t(messages, "plan.perMonth")}</span>
                  </p>
                  <p className={styles.planLimit}>
                    {limit === null
                      ? t(messages, "plan.limitNone")
                      : t(messages, "plan.limitCount", { count: limit })}
                  </p>
                  <p className={styles.planBody}>{t(messages, plan.descriptionKey)}</p>
                  <p className={styles.planFoot}>
                    <Link className={`${ui.button} ${ui.small}`} href="/signup">
                      {t(messages, "home.planCta")}
                    </Link>
                  </p>
                </article>
              );
            })}
          </div>
          <p className={styles.taxNote}>{t(messages, "home.taxNote")}</p>
        </section>
      </main>

      <footer className={`${styles.inner} ${styles.footer}`}>
        <nav className={styles.footerNav} aria-label={t(messages, "legal.navLabel")}>
          <Link href="/legal/terms">{t(messages, "legal.terms.title")}</Link>
          <Link href="/legal/privacy">{t(messages, "legal.privacy.title")}</Link>
          <Link href="/legal/tokushoho">{t(messages, "legal.tokushoho.title")}</Link>
        </nav>
        <p>{t(messages, "home.footer")}</p>
      </footer>
    </div>
  );
}
