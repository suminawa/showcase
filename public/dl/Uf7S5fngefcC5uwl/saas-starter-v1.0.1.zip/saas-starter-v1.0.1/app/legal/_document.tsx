/**
 * 法務の 3 枚に共通の組み立てです（ログインは要りません）。
 *
 * 文面は legal/*.txt から読み、段落の並びに読み替えてから React の要素に写します。
 * **HTML の文字列は、どこでも組み立てません。**
 * 文面に何が書かれていても、画面の組み立てが崩れることはありません。
 */
import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import { LEGAL } from "@/legal.config";
import { formatDate, isLang, pickLang, t, type Lang } from "@/src/core/i18n";
import { LEGAL_DOCS, missingLegalKeys, type LegalBlock, type LegalDoc } from "@/src/core/legal";
import { legalBlocks } from "@/src/server/legal";
import { messagesFor } from "@/src/server/messages";
import { getRequestLang, isProduction } from "@/src/server/ports";
import { firstParam } from "@/src/server/urls";
import styles from "./legal.module.css";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function titleKey(doc: LegalDoc): string {
  return `legal.${doc}.title`;
}

/** 言語をお選びのときは、ほかの 2 枚へのご案内にも同じ言語を付けます */
function hrefOf(doc: LegalDoc, lang: Lang | null): string {
  return lang === null ? `/legal/${doc}` : `/legal/${doc}?lang=${lang}`;
}

function Block({ block }: { block: LegalBlock }): ReactNode {
  switch (block.kind) {
    case "h2":
      return <h2 className={styles.heading}>{block.text}</h2>;
    case "ul":
      return (
        <ul className={styles.list}>
          {block.items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      );
    case "dl":
      return (
        <dl className={styles.rows}>
          {block.rows.map((row) => (
            <div className={styles.row} key={row.term}>
              <dt className={styles.rowTerm}>{row.term}</dt>
              <dd className={styles.rowText}>{row.text}</dd>
            </div>
          ))}
        </dl>
      );
    default:
      return <p className={styles.paragraph}>{block.text}</p>;
  }
}

/** どの言語でお読みになっているかを決めます（?lang= が先、次にお預かりしているお好み） */
async function langOf(searchParams: SearchParams): Promise<{ lang: Lang; chosen: string | null }> {
  const chosen = firstParam(await searchParams, "lang");
  return { lang: pickLang({ param: chosen, cookie: await getRequestLang() }), chosen };
}

/** ブラウザのタブに出す題です */
export async function legalMetadata(doc: LegalDoc, searchParams: SearchParams): Promise<Metadata> {
  const { lang } = await langOf(searchParams);
  const messages = messagesFor(lang);
  return {
    title: `${t(messages, titleKey(doc))}｜${t(messages, "common.appName")}`,
  };
}

export async function LegalDocument({
  doc,
  searchParams,
}: {
  doc: LegalDoc;
  searchParams: SearchParams;
}): Promise<ReactNode> {
  const { lang, chosen } = await langOf(searchParams);
  const messages = messagesFor(lang);

  // 読んだ結果を覚えておくのは本番だけです。お手元でお書きかえのあいだは、
  // 立ち上げ直さずに、そのまま画面でお確かめいただけます。
  const blocks = legalBlocks(doc, lang, {
    blank: t(messages, "legal.blank"),
    remember: isProduction(),
  });
  const missing = missingLegalKeys(LEGAL);
  const updated = formatDate(LEGAL.updatedOn, lang);
  const linkLang = isLang(chosen) ? chosen : null;

  return (
    <div className={styles.page}>
      <header className={`${styles.inner} ${styles.header}`}>
        <Link className={styles.brand} href="/">
          {t(messages, "common.appName")}
        </Link>
        <nav className={styles.nav} aria-label={t(messages, "legal.navLabel")}>
          {LEGAL_DOCS.map((entry) => (
            <Link
              aria-current={entry === doc ? "page" : undefined}
              className={entry === doc ? `${styles.navLink} ${styles.navHere}` : styles.navLink}
              href={hrefOf(entry, linkLang)}
              key={entry}
            >
              {t(messages, titleKey(entry))}
            </Link>
          ))}
        </nav>
      </header>

      <main className={`${styles.inner} ${styles.main}`}>
        <h1 className={styles.title}>{t(messages, titleKey(doc))}</h1>
        <p className={styles.updated}>
          {t(messages, "legal.updatedOn", {
            date: updated === "" ? t(messages, "legal.blank") : updated,
          })}
        </p>

        {missing.length > 0 ? (
          <aside className={styles.notice}>
            <p className={styles.noticeTitle}>{t(messages, "legal.missingTitle")}</p>
            <p className={styles.noticeText}>
              {t(messages, "legal.missingHint", { count: missing.length })}
            </p>
          </aside>
        ) : null}

        <article className={styles.doc}>
          {blocks.map((block, index) => (
            // 文面の並びは書き換えるまで変わらないので、順番を鍵にします
            <Block block={block} key={`${block.kind}-${index}`} />
          ))}
        </article>
      </main>

      <footer className={`${styles.inner} ${styles.footer}`}>
        <Link className={styles.homeLink} href="/">
          {t(messages, "legal.toHome")}
        </Link>
      </footer>
    </div>
  );
}
