/**
 * 特定商取引法に基づく表記です（ログインは要りません）。
 * 文面は legal/tokushoho.ja.txt と tokushoho.en.txt、差し込む値は legal.config.ts にあります。
 */
import type { Metadata } from "next";
import type { ReactNode } from "react";
import { LegalDocument, legalMetadata } from "../_document";

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  return legalMetadata("tokushoho", searchParams);
}

export default async function TokushohoPage({ searchParams }: Props): Promise<ReactNode> {
  return <LegalDocument doc="tokushoho" searchParams={searchParams} />;
}
