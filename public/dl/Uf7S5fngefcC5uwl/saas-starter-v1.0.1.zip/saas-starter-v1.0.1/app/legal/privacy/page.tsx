/**
 * プライバシーポリシーです（ログインは要りません）。
 * 文面は legal/privacy.ja.txt と privacy.en.txt、差し込む値は legal.config.ts にあります。
 */
import type { Metadata } from "next";
import type { ReactNode } from "react";
import { LegalDocument, legalMetadata } from "../_document";

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  return legalMetadata("privacy", searchParams);
}

export default async function PrivacyPage({ searchParams }: Props): Promise<ReactNode> {
  return <LegalDocument doc="privacy" searchParams={searchParams} />;
}
