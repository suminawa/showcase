/**
 * メールのリンク・OAuth から戻ってこられたときの受け口です。
 *
 * ここでセッションを立て、profiles の行をご用意し、
 * 組織のある方は /app、まだ無い方は /onboarding へお通しします。
 * ?next= でお戻り先をお預かりしているときは、同じサイトの中に限ってそちらを優先します。
 */
import { redirect } from "next/navigation";
import { afterSignIn, buildDeps, getPorts } from "@/src/server/ports";
import { isSafeNextPath, loginPath } from "@/src/server/urls";

function optional(value: string | null): string | undefined {
  return value === null || value === "" ? undefined : value;
}

export async function GET(request: Request): Promise<Response> {
  const url = new URL(request.url);

  const requested = url.searchParams.get("next");
  const next = requested !== null && isSafeNextPath(requested) ? requested : null;

  const deps = buildDeps(await getPorts());
  const result = await deps.ports.auth.completeSignIn({
    code: optional(url.searchParams.get("code")),
    tokenHash: optional(url.searchParams.get("token_hash")),
    type: optional(url.searchParams.get("type")),
  });

  // うまくいかなかったときは、理由の符号だけをログインの画面にお渡しします
  // （符号はそのままつながず、URL の形を壊さないように escape します）
  if (!result.ok) {
    const back = loginPath(next ?? undefined);
    const mark = back.includes("?") ? "&" : "?";
    redirect(`${back}${mark}error=${encodeURIComponent(result.code)}`);
  }

  redirect(await afterSignIn({ deps, next }));
}
