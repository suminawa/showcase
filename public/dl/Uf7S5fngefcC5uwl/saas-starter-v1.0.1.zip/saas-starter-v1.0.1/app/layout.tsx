import type { Metadata } from "next";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { pageMessages } from "@/src/server/ports";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const { messages } = await pageMessages();
  return {
    title: t(messages, "common.appName"),
    description: t(messages, "home.lead"),
  };
}

export default async function RootLayout({
  children,
}: {
  children: ReactNode;
}): Promise<ReactNode> {
  const { lang } = await pageMessages();

  return (
    <html lang={lang}>
      <body>{children}</body>
    </html>
  );
}
