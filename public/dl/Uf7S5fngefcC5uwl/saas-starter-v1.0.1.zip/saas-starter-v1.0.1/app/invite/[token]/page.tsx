/**
 * ご招待のリンクをお開きになったときの画面です。
 *
 * ログインしていらっしゃらないときは、先にログインの画面へお通しし、
 * 済みましたらこの画面にお戻りいただきます。
 * ご参加は、押していただいたときに 1 回だけ行います
 * （リンクを開いただけでは、招待を使い切りません）。
 */
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { acceptInvitationAction } from "@/app/_actions/invitations";
import { ActionForm } from "@/app/_components/ActionForm";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { messagesFor } from "@/src/server/messages";
import { userContext } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";

export default async function InvitePage({
  params,
}: {
  params: Promise<{ token: string }>;
}): Promise<ReactNode> {
  const { token } = await params;

  const ctx = await userContext();
  if (!ctx.ok) redirect(loginPath(`/invite/${token}`));

  const messages = messagesFor(ctx.value.lang);

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <div className={`${ui.panel} ${ui.stack}`}>
          <div className={ui.stackTight}>
            <h1 className={ui.cardTitle}>{t(messages, "invitePage.title")}</h1>
            <p className={ui.cardHint}>{t(messages, "invitePage.lead")}</p>
          </div>

          <ActionForm
            action={acceptInvitationAction}
            messages={messages}
            className={ui.stack}
            label={t(messages, "invitePage.title")}
          >
            <input type="hidden" name="token" value={token} />
            <p className={ui.hint}>
              {t(messages, "invitePage.asEmail", { email: ctx.value.user.email })}
            </p>
            <div className={ui.row}>
              <SubmitButton tone="primary">{t(messages, "invitePage.submit")}</SubmitButton>
            </div>
          </ActionForm>
        </div>
      </div>
    </main>
  );
}
