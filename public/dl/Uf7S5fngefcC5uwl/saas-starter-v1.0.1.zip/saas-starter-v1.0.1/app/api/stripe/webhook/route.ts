/**
 * 決済の通知（Stripe の Webhook）の受け口です。
 *
 * ここを通るのは Stripe だけで、ログインしている方はいらっしゃいません。
 * そのぶん、入口でできることをすべて行います。
 *   ① 署名のヘッダが無ければ、本文も読まずにお断りします
 *   ② 秘密（STRIPE_WEBHOOK_SECRET）が無ければ、本文も読まずにお断りします
 *   ③ 本文は、JSON に直さず**そのままの文字**で、上限（1 MiB）まで読みます
 *   ④ 署名の確かめと、Stripe からの取り直しは、課金の口（つなぎ役）の役目です
 *   ⑤ お返事は短い英語 1 行だけです（誤りの中身は 1 文字も外に出しません）
 *
 * お申し付けのヘッダからは、戻り先も組織も組み立てません。
 * どの組織のご契約かは、Stripe のお客さまの id から表を引いて決めます。
 */
import { applyWebhookFlow } from "@/src/server/flows/billing";
import { getPorts, stripeWebhookReady } from "@/src/server/ports";
import {
  logWebhook,
  readWebhookBody,
  webhookReply,
  webhookReplyName,
} from "@/src/server/webhook";

/** 署名の確かめには node の暗号のしくみが要ります */
export const runtime = "nodejs";

/** 通知は 1 通ずつ違います。取り置きはしません */
export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<Response> {
  // 署名のヘッダが無いお申し付けは、Stripe からのものではありません。
  // **秘密の有無を見る前に**お断りします。順番を逆にすると、
  // お返事が 400 か 503 かで、秘密の置き忘れが外から分かってしまいます。
  const signature = request.headers.get("stripe-signature");
  if (signature === null || signature === "") return webhookReply("bad_signature");

  // 秘密が無いままでは、どなたからの通知かを確かめられません。
  // 400 ではなく 503 をお返しします。お申し付けに誤りがあるのではなく、
  // こちらの支度が済んでいないためです（Stripe は 5xx なら送り直してくれるので、
  // 秘密を入れたあとで、そのあいだの通知が入り直します）。
  if (!stripeWebhookReady()) {
    logWebhook("not_configured");
    return webhookReply("not_configured");
  }

  const body = await readWebhookBody(request);
  if (!body.ok) return webhookReply("too_large");

  try {
    const result = await applyWebhookFlow({
      ports: await getPorts(),
      payload: body.payload,
      signature,
      now: new Date(),
    });
    return webhookReply(webhookReplyName(result));
  } catch (error) {
    // 表に写せませんでした。5xx をお返しすると Stripe が送り直してくれます
    // （flow は「確かめ → 適用 → 記録」の順なので、もう一度届いても安全です）。
    logWebhook("failed", error);
    return webhookReply("failed");
  }
}

/** 受け口は POST だけです */
export async function GET(): Promise<Response> {
  return webhookReply("method_not_allowed");
}
