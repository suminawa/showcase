"use server";

/**
 * 招待のお申し付け（お送りする・取り消す・お受けいただく）です。
 *
 * お作りしたリンクは、この 1 回だけ画面にお出しします
 * （表に残るのはハッシュだけで、あとからリンクをお出しすることはできません）。
 */
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { toActionState, type ActionState } from "@/src/server/context";
import {
  acceptInvitationFlow,
  createInvitationFlow,
  inviteNoticeKey,
  revokeInvitationFlow,
} from "@/src/server/flows/invitations";
import { messagesFor } from "@/src/server/messages";
import {
  actionContext,
  userContext,
  clientIp,
  limiters,
  setCurrentOrganizationId,
} from "@/src/server/ports";

export async function createInvitationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await createInvitationFlow({
    ctx: ctx.value,
    raw: { email: form.get("email"), role: form.get("role") },
    limiter: limiters().invite,
    messages: messagesFor(ctx.value.lang),
  });
  if (!result.ok) return toActionState(result, undefined, form);

  revalidatePath("/app/settings/organization");

  // メールをお送りできない設定でも、リンクをお渡しすればお招きいただけます。
  // どの文でお伝えするかは flow の答えから決まります（この画面では決めません）。
  return {
    status: "ok",
    messageKey: inviteNoticeKey(result.value),
    value: result.value.url,
  };
}

export async function revokeInvitationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await revokeInvitationFlow({
    ctx: ctx.value,
    raw: { invitationId: form.get("invitationId") },
  });
  if (result.ok) revalidatePath("/app/settings/organization");

  return toActionState(result, "invite.revoked", form);
}

export async function acceptInvitationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await userContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const token = form.get("token");
  const result = await acceptInvitationFlow({
    ports: ctx.value.ports,
    user: ctx.value.user,
    token: typeof token === "string" ? token : "",
    limiter: limiters().inviteAccept,
    ip: await clientIp(),
    now: ctx.value.now,
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await setCurrentOrganizationId(result.value.organizationId);
  revalidatePath("/app", "layout");
  redirect("/app");
}
