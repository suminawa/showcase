"use server";

/**
 * ご一緒いただいている方のお申し付け（役割を変える・外れていただく・ご自身で退会する）です。
 * どなたに何ができるかは、すべて flow（と役割の表）が決めます。
 */
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { toActionState, type ActionState } from "@/src/server/context";
import {
  leaveOrganizationFlow,
  removeMemberFlow,
  setMemberRoleFlow,
} from "@/src/server/flows/members";
import { actionContext, clearCurrentOrganizationId } from "@/src/server/ports";

export async function setMemberRoleAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await setMemberRoleFlow({
    ctx: ctx.value,
    raw: { userId: form.get("userId"), role: form.get("role") },
  });
  if (result.ok) revalidatePath("/app/settings/organization");

  return toActionState(result, "member.roleChanged", form);
}

export async function removeMemberAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await removeMemberFlow({
    ctx: ctx.value,
    raw: { userId: form.get("userId") },
  });
  if (result.ok) revalidatePath("/app/settings/organization");

  return toActionState(result, "member.removed", form);
}

export async function leaveOrganizationAction(
  _previous: ActionState,
  _form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx);

  const result = await leaveOrganizationFlow({ ctx: ctx.value });
  if (!result.ok) return toActionState(result);

  await clearCurrentOrganizationId();
  revalidatePath("/app", "layout");
  redirect("/app");
}
