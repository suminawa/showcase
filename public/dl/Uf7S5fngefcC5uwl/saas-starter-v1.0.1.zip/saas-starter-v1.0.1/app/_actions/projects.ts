"use server";

/**
 * プロジェクトのお申し付け（お作りになる・直す・消す）です。
 * 件数の上限も、消せる方の決まりも、flow が持っています。
 */
import { revalidatePath } from "next/cache";
import { toActionState, type ActionState } from "@/src/server/context";
import {
  createProjectFlow,
  deleteProjectFlow,
  updateProjectFlow,
} from "@/src/server/flows/projects";
import { actionContext } from "@/src/server/ports";

export async function createProjectAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await createProjectFlow({
    ctx: ctx.value,
    raw: { name: form.get("name"), note: form.get("note") },
  });
  if (result.ok) revalidatePath("/app/projects");

  return toActionState(result, "project.created", form);
}

export async function updateProjectAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await updateProjectFlow({
    ctx: ctx.value,
    raw: {
      projectId: form.get("projectId"),
      name: form.get("name"),
      note: form.get("note"),
    },
  });
  if (result.ok) revalidatePath("/app/projects");

  return toActionState(result, "project.saved", form);
}

export async function deleteProjectAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await deleteProjectFlow({
    ctx: ctx.value,
    raw: { projectId: form.get("projectId") },
  });
  if (result.ok) revalidatePath("/app/projects");

  return toActionState(result, "project.deleted", form);
}
