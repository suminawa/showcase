"use server";

/**
 * ご登録・ログイン・ログアウトのお申し付けです。
 *
 * ここでは判断をしません。入力を flow にお渡しし、そのお返事を画面の形に写すだけです
 * （回数の上限も、ご登録の有無をお伝えしない決まりも、すべて flow の中にあります）。
 */
import { redirect } from "next/navigation";
import { toActionState, type ActionState } from "@/src/server/context";
import {
  googleSignInFlow,
  magicLinkFlow,
  signInPasswordFlow,
  signUpFlow,
} from "@/src/server/flows/auth";
import {
  afterSignIn,
  buildDeps,
  clearCurrentOrganizationId,
  clientIp,
  fakeSignInAs,
  getPorts,
  limiters,
} from "@/src/server/ports";
import { isSafeNextPath } from "@/src/server/urls";

/** ログインのあとにお戻りいただく先です。同じサイトの中の相対パスだけをお預かりします */
function nextPathFrom(form: FormData): string | null {
  const raw = form.get("next");
  if (typeof raw !== "string" || raw === "") return null;
  return isSafeNextPath(raw) ? raw : null;
}

export async function signUpAction(_previous: ActionState, form: FormData): Promise<ActionState> {
  const deps = buildDeps(await getPorts());
  const limits = limiters();

  const result = await signUpFlow({
    ...deps,
    raw: { email: form.get("email"), password: form.get("password") },
    limiter: limits.login,
    ipLimiter: limits.loginIp,
    ip: await clientIp(),
    now: new Date(),
  });

  return toActionState(result, "auth.signup.sent", form);
}

export async function signInAction(_previous: ActionState, form: FormData): Promise<ActionState> {
  const deps = buildDeps(await getPorts());
  const limits = limiters();

  const result = await signInPasswordFlow({
    ports: deps.ports,
    raw: { email: form.get("email"), password: form.get("password") },
    limiter: limits.login,
    ipLimiter: limits.loginIp,
    ip: await clientIp(),
    now: new Date(),
  });
  if (!result.ok) return toActionState(result, undefined, form);

  const destination = await afterSignIn({ deps, next: nextPathFrom(form) });
  redirect(destination);
}

export async function magicLinkAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const deps = buildDeps(await getPorts());
  const limits = limiters();

  const result = await magicLinkFlow({
    ...deps,
    raw: { email: form.get("email") },
    limiter: limits.login,
    ipLimiter: limits.loginIp,
    ip: await clientIp(),
    now: new Date(),
  });

  return toActionState(result, "auth.magic.sent", form);
}

/**
 * Google でのログインの入り口です。
 *
 * **お申し付けとして受けるのは、cookie を書けるのがここだけだからです。**
 * 入り口の URL を組み立てるときに、お戻りの中身をすり替えられないための
 * 控え（PKCE）を cookie に残します。画面の部品からお呼びすると控えが残らず、
 * お戻りになったときの引き換えができません。
 */
export async function googleSignInAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const deps = buildDeps(await getPorts());
  const limits = limiters();

  const result = await googleSignInFlow({
    ...deps,
    next: nextPathFrom(form),
    // ログインと同じ IP の窓です（メールアドレスを頂戴しないので、窓は 1 本です）
    ipLimiter: limits.loginIp,
    ip: await clientIp(),
    now: new Date(),
  });
  if (!result.ok) return toActionState(result, undefined, form);

  redirect(result.value.url);
}

export async function signOutAction(
  _previous: ActionState,
  _form: FormData,
): Promise<ActionState> {
  const ports = await getPorts();
  await ports.auth.signOut();
  await clearCurrentOrganizationId();

  redirect("/");
}

/** 見本の方でログインします（STARTER_FAKE=1 のときだけ、入り口が開いています） */
export async function fakeSignInAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const chosen = await fakeSignInAs(form.get("userId"));
  if (!chosen.ok) return toActionState(chosen, undefined, form);

  const deps = buildDeps(await getPorts());
  const destination = await afterSignIn({ deps, next: nextPathFrom(form) });
  redirect(destination);
}
