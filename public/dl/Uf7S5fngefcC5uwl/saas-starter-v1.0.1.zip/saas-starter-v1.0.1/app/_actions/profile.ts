"use server";

/**
 * お名前と言語のお申し付けです。
 * 言語は、次にお開きになったときも同じになるよう cookie にも控えます。
 */
import { revalidatePath } from "next/cache";
import { toActionState, type ActionState } from "@/src/server/context";
import { updateProfileFlow } from "@/src/server/flows/auth";
import { userContext, setRequestLang } from "@/src/server/ports";

export async function updateProfileAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await userContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await updateProfileFlow({
    ctx: ctx.value,
    raw: { name: form.get("name"), lang: form.get("lang") },
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await setRequestLang(result.value.lang);
  // 言語が変わると、どの画面の文も変わります
  revalidatePath("/app", "layout");

  return toActionState(result, "profile.saved", form);
}
