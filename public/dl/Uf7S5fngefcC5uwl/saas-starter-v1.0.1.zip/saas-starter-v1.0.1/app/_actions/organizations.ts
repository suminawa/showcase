"use server";

/**
 * 組織のお申し付け（お作りになる・お名前を変える・お消しになる・切り替える）です。
 *
 * 組織の ID は、画面からお送りいただいた値をそのままは使いません。
 * 切り替えのときは flow が memberships を引き直し、通ったものだけを控えます。
 */
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { toActionState, type ActionState } from "@/src/server/context";
import {
  createOrganizationFlow,
  deleteOrganizationFlow,
  renameOrganizationFlow,
  switchOrganizationFlow,
} from "@/src/server/flows/organizations";
import {
  actionContext,
  userContext,
  clearCurrentOrganizationId,
  setCurrentOrganizationId,
} from "@/src/server/ports";

export async function createOrganizationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await userContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await createOrganizationFlow({
    ctx: ctx.value,
    raw: { name: form.get("name") },
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await setCurrentOrganizationId(result.value.id);
  redirect("/app");
}

export async function renameOrganizationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await renameOrganizationFlow({
    ctx: ctx.value,
    raw: { name: form.get("name") },
  });
  if (result.ok) revalidatePath("/app", "layout");

  return toActionState(result, "organization.saved", form);
}

export async function deleteOrganizationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await deleteOrganizationFlow({
    ctx: ctx.value,
    raw: { confirmName: form.get("confirmName") },
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await clearCurrentOrganizationId();
  revalidatePath("/app", "layout");
  redirect("/app");
}

export async function switchOrganizationAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await userContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await switchOrganizationFlow({
    ports: ctx.value.ports,
    user: ctx.value.user,
    raw: { organizationId: form.get("organizationId") },
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await setCurrentOrganizationId(result.value.organizationId);
  revalidatePath("/app", "layout");
  redirect("/app");
}
