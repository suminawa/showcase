"use server";

/**
 * お支払いのお申し付けです。
 *
 * お申し込みの画面（Checkout）とお手続きの画面（Customer Portal）の URL は flow が作ります。
 * 見本のしくみで動いているときは、その 2 つが偽の画面になり、
 * 「お支払いが済んだ」という通知も、本物と同じ道（Webhook の流れ）で表に入ります。
 */
import { revalidatePath } from "next/cache";
import { notFound, redirect } from "next/navigation";
import { isPlanId } from "@/src/core/plans";
import { flowFail, toActionState, type ActionState } from "@/src/server/context";
import { openPortalFlow, startCheckoutFlow } from "@/src/server/flows/billing";
import {
  actionContext,
  fakeCancelSubscription,
  fakeCompleteCheckout,
  isFakeMode,
} from "@/src/server/ports";

const BAD_PLAN = flowFail("invalid", [{ field: "planId", code: "bad_choice" }]);

export async function startCheckoutAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await startCheckoutFlow({
    ctx: ctx.value,
    raw: { planId: form.get("planId") },
  });
  if (!result.ok) return toActionState(result, undefined, form);

  redirect(result.value.url);
}

export async function openPortalAction(
  _previous: ActionState,
  _form: FormData,
): Promise<ActionState> {
  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx);

  const result = await openPortalFlow({ ctx: ctx.value });
  if (!result.ok) return toActionState(result);

  redirect(result.value.url);
}

/**
 * 偽の Checkout で「お支払いを終える」ボタンです。
 * どなたが押せるか・すでにご契約中でないかは、本物と同じ startCheckoutFlow が決めます。
 */
export async function fakeCheckoutCompleteAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  // 見本のしくみのときだけのお申し付けです。ここで先に止めておかないと、
  // 本番では startCheckoutFlow が**本物の Stripe のお客さまとお支払いの画面を
  // 作ってから**落ちます（お客さまの控えだけが残ります）。
  if (!isFakeMode()) notFound();

  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const planId = form.get("planId");
  if (!isPlanId(planId)) return toActionState(BAD_PLAN, undefined, form);

  const allowed = await startCheckoutFlow({ ctx: ctx.value, raw: { planId } });
  if (!allowed.ok) return toActionState(allowed, undefined, form);

  await fakeCompleteCheckout({
    organizationId: ctx.value.organization.id,
    planId,
    now: ctx.value.now,
  });
  revalidatePath("/app", "layout");

  redirect("/app/settings/billing?checkout=done");
}

/** 偽のお手続きの画面での、ご解約です。押せるのは openPortalFlow が通った方だけです */
export async function fakeCancelAction(
  _previous: ActionState,
  _form: FormData,
): Promise<ActionState> {
  // 見本のしくみのときだけのお申し付けです（上と同じ理由です）
  if (!isFakeMode()) notFound();

  const ctx = await actionContext();
  if (!ctx.ok) return toActionState(ctx);

  const allowed = await openPortalFlow({ ctx: ctx.value });
  if (!allowed.ok) return toActionState(allowed);

  await fakeCancelSubscription({
    organizationId: ctx.value.organization.id,
    now: ctx.value.now,
  });
  revalidatePath("/app", "layout");

  redirect("/app/settings/billing?plan=canceled");
}
