"use client";

/**
 * 思いがけない誤りが起きたときの画面です。
 *
 * Next.js の決まりで、この 1 枚だけはクライアントの部品にします。
 * 中の文（例外の message・スタック）は**お客さまにお出ししません**。
 * 文は messages から引きますが、ここはサーバーの module を通せないため、
 * 言語は html の lang を見て決めています。
 *
 * 読むのは**この画面の文だけを持つ小さな辞書**です。
 * 画面の文を丸ごと（約 8KB）ブラウザにお届けしないためで、
 * 中身がずれていないことはテストが見張っています。
 */
import { useEffect, useState, type ReactNode } from "react";
import en from "@/messages/error-page.en.json";
import ja from "@/messages/error-page.ja.json";
import { t, type Messages } from "@/src/core/i18n";
import ui from "@/app/_components/ui.module.css";

export default function AppError({ reset }: { error: Error; reset: () => void }): ReactNode {
  const [messages, setMessages] = useState<Messages>(ja as Messages);

  useEffect(() => {
    if (document.documentElement.lang === "en") setMessages(en as Messages);
  }, []);

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <div className={`${ui.panel} ${ui.stack}`}>
          <div className={ui.stackTight}>
            <h1 className={ui.cardTitle}>{t(messages, "errorPage.title")}</h1>
            <p className={ui.cardHint}>{t(messages, "errorPage.lead")}</p>
          </div>
          <p className={ui.row}>
            <button type="button" className={`${ui.button} ${ui.primary}`} onClick={reset}>
              {t(messages, "errorPage.retry")}
            </button>
          </p>
        </div>
      </div>
    </main>
  );
}
