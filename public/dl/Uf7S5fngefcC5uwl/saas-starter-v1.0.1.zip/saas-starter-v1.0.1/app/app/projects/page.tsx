/**
 * プロジェクトの一覧・作成・編集・削除の画面です。
 *
 * 「消せるかどうか」は役割の表（core/permissions）に尋ねます。
 * 同じ表を flow も見ているので、画面とサーバーの答えが食い違うことはありません。
 */
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { formatDate, t } from "@/src/core/i18n";
import { can } from "@/src/core/permissions";
import {
  createProjectAction,
  deleteProjectAction,
  updateProjectAction,
} from "@/app/_actions/projects";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { listMembersFlow } from "@/src/server/flows/members";
import { listProjectsFlow, PROJECT_NAME_MAX, PROJECT_NOTE_MAX } from "@/src/server/flows/projects";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../app.module.css";

export default async function ProjectsPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/projects"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const [listed, members] = await Promise.all([
    listProjectsFlow({ ctx }),
    listMembersFlow({ ctx }),
  ]);
  if (!listed.ok) notFound();

  const { projects, quota } = listed.value;
  const nameOf = new Map((members.ok ? members.value : []).map((m) => [m.userId, m.name]));

  return (
    <>
      <div className={styles.head}>
        <h1 className={styles.title}>{t(messages, "project.title")}</h1>
        <p className={styles.lead}>
          {quota.unlimited
            ? t(messages, "project.countUnlimited", { used: quota.used })
            : t(messages, "project.count", { used: quota.used, limit: quota.limit })}
        </p>
      </div>

      <div className={styles.sections}>
        {quota.atLimit ? (
          <section className={`${ui.card} ${ui.stack}`}>
            <h2 className={ui.cardTitle}>{t(messages, "project.createTitle")}</h2>
            <p className={`${ui.notice} ${ui.noticeWarn}`}>
              <span className={ui.noticeBody}>
                <span>{t(messages, "project.limitReached")}</span>
                <Link href="/app/settings/billing">{t(messages, "project.seePlans")}</Link>
              </span>
            </p>
          </section>
        ) : (
          <section className={`${ui.card} ${ui.stack}`}>
            <h2 className={ui.cardTitle}>{t(messages, "project.createTitle")}</h2>
            <ActionForm
              action={createProjectAction}
              messages={messages}
              className={ui.stack}
              label={t(messages, "project.createTitle")}
            >
              <Field
                name="name"
                label={t(messages, "field.projectName")}
                maxLength={PROJECT_NAME_MAX}
                required
              />
              <Field
                name="note"
                kind="textarea"
                label={t(messages, "field.note")}
                hint={t(messages, "project.noteHint")}
                maxLength={PROJECT_NOTE_MAX}
              />
              <div className={ui.row}>
                <SubmitButton tone="primary">{t(messages, "project.createSubmit")}</SubmitButton>
              </div>
            </ActionForm>
          </section>
        )}

        {projects.length === 0 ? (
          <div className={ui.empty}>
            <p className={ui.emptyTitle}>{t(messages, "project.emptyTitle")}</p>
            <p className={ui.emptyHint}>{t(messages, "project.emptyHint")}</p>
          </div>
        ) : (
          <ul className={ui.rows}>
            {projects.map((project) => {
              // お作りになった方が退会されていると、作成者の欄は空です。
              // その行は「ご自身がお作りになったもの」には当たりません。
              const mayDelete = can("project:delete", {
                role: ctx.role,
                userId: ctx.user.id,
                resourceOwnerId: project.createdBy ?? undefined,
              });
              // 作成者の欄が空のときだけでなく、その方がこの組織を抜けられて
              // お名前を引けないときも、同じご案内にそろえます
              // （空欄のままだと、誰がお作りになったのか分からなくなります）。
              const creator = project.createdBy === null ? "" : (nameOf.get(project.createdBy) ?? "");
              const creatorName = creator === "" ? t(messages, "project.creatorLeft") : creator;

              return (
                <li key={project.id}>
                  <div className={ui.rowItem}>
                    <span className={ui.rowMain}>
                      <span className={ui.rowName}>{project.name}</span>
                      {project.note === "" ? null : (
                        <span className={ui.rowMeta}>{project.note}</span>
                      )}
                      <span className={ui.rowMeta}>
                        {t(messages, "project.meta", {
                          name: creatorName,
                          date: formatDate(project.updatedAt, ctx.lang),
                        })}
                      </span>
                    </span>
                  </div>

                  <details className={ui.disclosure}>
                    <summary className={ui.summary}>{t(messages, "project.edit")}</summary>
                    <div className={`${ui.disclosureBody} ${ui.stack}`}>
                      <ActionForm
                        action={updateProjectAction}
                        messages={messages}
                        className={ui.stack}
                        label={t(messages, "project.edit")}
                      >
                        <input type="hidden" name="projectId" value={project.id} />
                        <Field
                          name="name"
                          label={t(messages, "field.projectName")}
                          defaultValue={project.name}
                          maxLength={PROJECT_NAME_MAX}
                          required
                        />
                        <Field
                          name="note"
                          kind="textarea"
                          label={t(messages, "field.note")}
                          defaultValue={project.note}
                          maxLength={PROJECT_NOTE_MAX}
                        />
                        <div className={ui.row}>
                          <SubmitButton tone="primary" size="small">
                            {t(messages, "common.save")}
                          </SubmitButton>
                        </div>
                      </ActionForm>

                      {mayDelete ? (
                        <ActionForm
                          action={deleteProjectAction}
                          messages={messages}
                          className={ui.stackTight}
                          label={t(messages, "project.delete")}
                        >
                          <input type="hidden" name="projectId" value={project.id} />
                          <p className={ui.hint}>{t(messages, "project.deleteHint")}</p>
                          <div className={ui.row}>
                            <SubmitButton tone="danger" size="small">
                              {t(messages, "project.delete")}
                            </SubmitButton>
                          </div>
                        </ActionForm>
                      ) : (
                        <p className={ui.hint}>{t(messages, "project.deleteForbidden")}</p>
                      )}
                    </div>
                  </details>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </>
  );
}
