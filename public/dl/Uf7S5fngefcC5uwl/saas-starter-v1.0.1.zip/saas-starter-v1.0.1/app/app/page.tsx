/**
 * いまの組織のようすをまとめてお見せする画面です。
 * どの数もこの画面で決めず、flow がお返しした値をそのまま並べています。
 */
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { formatDate, t } from "@/src/core/i18n";
import { RoleBadge } from "@/app/_components/RoleBadge";
import { billingOverviewFlow } from "@/src/server/flows/billing";
import { listMembersFlow } from "@/src/server/flows/members";
import { listProjectsFlow } from "@/src/server/flows/projects";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "./app.module.css";

/** 何件お使いかの帯です（残りが無いときだけ、色が変わります） */
function usageWidth(used: number, limit: number | null): string {
  if (limit === null || limit <= 0) return "100%";
  return `${Math.min(100, Math.round((used / limit) * 100))}%`;
}

export default async function AppOverviewPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const [projects, members, billing] = await Promise.all([
    listProjectsFlow({ ctx }),
    listMembersFlow({ ctx }),
    billingOverviewFlow({ ctx }),
  ]);

  const quota = projects.ok ? projects.value.quota : null;
  const recent = projects.ok ? projects.value.projects.slice(0, 3) : [];
  const memberCount = members.ok ? members.value.length : 0;
  const planName = billing.ok ? t(messages, billing.value.state.plan.nameKey) : "";
  const periodEnd = ctx.billing.currentPeriodEnd;

  return (
    <>
      <div className={styles.head}>
        <div className={styles.headRow}>
          <h1 className={styles.title}>{ctx.organization.name}</h1>
          <RoleBadge role={ctx.role} messages={messages} />
        </div>
        <p className={styles.lead}>{t(messages, "overview.lead")}</p>
      </div>

      <div className={styles.sections}>
        <section className={`${ui.card} ${ui.stack}`}>
          <div className={ui.rowBetween}>
            <h2 className={ui.cardTitle}>{t(messages, "overview.usageTitle")}</h2>
            <Link href="/app/projects">{t(messages, "overview.toProjects")}</Link>
          </div>

          <div>
            <div className={styles.usage}>
              <p className={styles.usageFigure}>
                {quota === null ? 0 : quota.used}
                <span className={styles.usageOf}>
                  {quota === null || quota.unlimited
                    ? t(messages, "plan.limitNone")
                    : t(messages, "overview.ofLimit", { limit: quota.limit })}
                </span>
              </p>
              <p className={ui.muted}>{t(messages, "overview.planNow", { plan: planName })}</p>
            </div>

            <div className={styles.meter}>
              <span
                className={
                  quota !== null && quota.atLimit
                    ? `${styles.meterFill} ${styles.meterFillFull}`
                    : styles.meterFill
                }
                style={{
                  width:
                    quota === null || quota.unlimited
                      ? "100%"
                      : usageWidth(quota.used, quota.limit),
                }}
              />
            </div>
          </div>

          {quota !== null && quota.atLimit ? (
            <p className={`${ui.notice} ${ui.noticeWarn}`}>
              <span className={ui.noticeBody}>
                <span>{t(messages, "project.limitReached")}</span>
                <Link href="/app/settings/billing">{t(messages, "project.seePlans")}</Link>
              </span>
            </p>
          ) : null}
        </section>

        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "overview.factsTitle")}</h2>
          <dl className={styles.facts}>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "overview.factPlan")}</dt>
              <dd className={styles.factValue}>{planName}</dd>
            </div>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "overview.factMembers")}</dt>
              <dd className={styles.factValue}>
                {t(messages, "overview.memberCount", { count: memberCount })}
              </dd>
            </div>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "overview.factPeriodEnd")}</dt>
              <dd className={styles.factValue}>
                {periodEnd === null
                  ? t(messages, "common.none")
                  : formatDate(periodEnd, ctx.lang)}
              </dd>
            </div>
          </dl>
        </section>

        <section className={`${ui.card} ${ui.stack}`}>
          <div className={ui.rowBetween}>
            <h2 className={ui.cardTitle}>{t(messages, "overview.recentTitle")}</h2>
            <Link href="/app/projects">{t(messages, "overview.toProjects")}</Link>
          </div>

          {recent.length === 0 ? (
            <div className={ui.empty}>
              <p className={ui.emptyTitle}>{t(messages, "project.emptyTitle")}</p>
              <p className={ui.emptyHint}>{t(messages, "project.emptyHint")}</p>
              <p>
                <Link className={`${ui.button} ${ui.small} ${ui.linkButton}`} href="/app/projects">
                  {t(messages, "project.createFirst")}
                </Link>
              </p>
            </div>
          ) : (
            <ul className={ui.rows}>
              {recent.map((project) => (
                <li className={ui.rowItem} key={project.id}>
                  <span className={ui.rowMain}>
                    <span className={ui.rowName}>{project.name}</span>
                    <span className={ui.rowMeta}>
                      {t(messages, "project.updatedAt", {
                        date: formatDate(project.updatedAt, ctx.lang),
                      })}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </>
  );
}
