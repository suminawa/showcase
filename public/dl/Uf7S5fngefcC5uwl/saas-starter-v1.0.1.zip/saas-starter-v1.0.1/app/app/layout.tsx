/**
 * ログインしてお使いいただく画面（/app 以下）の枠です。
 *
 * ここで確かめるのは「ログインしていらっしゃるか」「どの組織をお使いか」の 2 つで、
 * それぞれの画面も、自分でもう一度この関門を通ります
 * （枠の答えを画面に受け渡すしくみが無いため、両方で確かめる形にしています）。
 */
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { signOutAction } from "@/app/_actions/auth";
import { switchOrganizationAction } from "@/app/_actions/organizations";
import { ActionForm } from "@/app/_components/ActionForm";
import { Banner } from "@/app/_components/Banner";
import { Nav } from "@/app/_components/Nav";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { listOrganizationsFlow } from "@/src/server/flows/organizations";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "./app.module.css";

export default async function AppLayout({
  children,
}: {
  children: ReactNode;
}): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const organizations = await listOrganizationsFlow({ ports: ctx.ports, user: ctx.user });
  const rows = organizations.ok ? organizations.value : [];

  return (
    <div className={styles.shell}>
      <header className={styles.topbar}>
        <div className={`${styles.topbarInner} ${styles.topbarRow}`}>
          <Link className={styles.brand} href="/app">
            {t(messages, "common.appName")}
          </Link>
          <div className={styles.account}>
            <span className={styles.accountName}>{ctx.user.name}</span>
            <ActionForm action={signOutAction} messages={messages}>
              <SubmitButton tone="quiet" size="small">
                {t(messages, "nav.signout")}
              </SubmitButton>
            </ActionForm>
          </div>
        </div>

        <div className={`${styles.topbarInner} ${styles.topbarRow}`}>
          <Nav
            label={t(messages, "nav.label")}
            items={[
              { href: "/app", label: t(messages, "nav.overview") },
              { href: "/app/projects", label: t(messages, "nav.projects") },
              {
                href: "/app/settings/profile",
                match: "/app/settings",
                label: t(messages, "nav.settings"),
              },
            ]}
          />

          {rows.length <= 1 ? (
            <span className={styles.orgName}>{ctx.organization.name}</span>
          ) : (
            <ActionForm
              action={switchOrganizationAction}
              messages={messages}
              className={styles.orgSwitch}
              label={t(messages, "organization.switch")}
            >
              <label className={ui.visuallyHidden} htmlFor="st-org-switch">
                {t(messages, "organization.switch")}
              </label>
              <select
                id="st-org-switch"
                name="organizationId"
                className={styles.orgSelect}
                defaultValue={ctx.organization.id}
              >
                {rows.map((row) => (
                  <option key={row.organization.id} value={row.organization.id}>
                    {row.organization.name}
                  </option>
                ))}
              </select>
              <SubmitButton size="small">{t(messages, "organization.switchSubmit")}</SubmitButton>
            </ActionForm>
          )}
        </div>
      </header>

      <main className={styles.main}>
        <Banner banner={ctx.billing.banner} messages={messages} />
        {children}
      </main>
    </div>
  );
}
