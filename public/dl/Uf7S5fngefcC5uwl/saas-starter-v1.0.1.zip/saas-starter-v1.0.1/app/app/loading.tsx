/**
 * /app 以下を読み込んでいるあいだにお見せする、かたちだけの下書きです。
 * ぐるぐる回る印ではなく、これから出てくる並びをそのままお出ししています。
 */
import type { ReactNode } from "react";
import styles from "./app.module.css";

export default function AppLoading(): ReactNode {
  return (
    <div className={styles.skeleton} aria-hidden="true">
      <div className={styles.skeletonBar} />
      <div className={styles.skeletonCard} />
      <div className={styles.skeletonCard} />
    </div>
  );
}
