/**
 * 設定の 3 つの画面（プロフィール・組織・お支払い）の行き来です。
 * 関門（ログインと一員かどうか）は、それぞれの画面が自分で通ります。
 */
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { Nav } from "@/app/_components/Nav";
import { pageMessages } from "@/src/server/ports";

export default async function SettingsLayout({
  children,
}: {
  children: ReactNode;
}): Promise<ReactNode> {
  const { messages } = await pageMessages();

  return (
    <>
      <Nav
        tone="sub"
        label={t(messages, "settings.navLabel")}
        items={[
          { href: "/app/settings/profile", label: t(messages, "settings.profile") },
          { href: "/app/settings/organization", label: t(messages, "settings.organization") },
          { href: "/app/settings/billing", label: t(messages, "settings.billing") },
        ]}
      />
      {children}
    </>
  );
}
