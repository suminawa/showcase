/**
 * 組織の設定です（お名前・ご一緒いただく方・ご招待・退会・組織の削除）。
 *
 * どのボタンをお出しするかは、役割の表（core/permissions）に尋ねています。
 * 押せてしまったときも flow が同じ表で止めるので、二重の守りになっています。
 */
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { formatDate, t } from "@/src/core/i18n";
import { can, type Role } from "@/src/core/permissions";
import {
  createInvitationAction,
  revokeInvitationAction,
} from "@/app/_actions/invitations";
import { leaveOrganizationAction, removeMemberAction, setMemberRoleAction } from "@/app/_actions/members";
import { deleteOrganizationAction, renameOrganizationAction } from "@/app/_actions/organizations";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { RoleBadge } from "@/app/_components/RoleBadge";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { listInvitationsFlow } from "@/src/server/flows/invitations";
import { listMembersFlow } from "@/src/server/flows/members";
import { ORG_NAME_MAX } from "@/src/server/flows/organizations";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../../app.module.css";

export default async function OrganizationSettingsPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/settings/organization"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const [members, invitations] = await Promise.all([
    listMembersFlow({ ctx }),
    listInvitationsFlow({ ctx }),
  ]);

  const mayRename = can("org:rename", { role: ctx.role });
  const mayInvite = can("member:invite", { role: ctx.role, targetRole: "member" });
  const mayDeleteOrganization = can("org:delete", { role: ctx.role });

  // お選びいただける役割も、表に尋ねます（管理者の方には「オーナー」が並びません）
  const allRoles: { value: Role; label: string }[] = [
    { value: "member", label: t(messages, "role.member") },
    { value: "admin", label: t(messages, "role.admin") },
    { value: "owner", label: t(messages, "role.owner") },
  ];
  const roleOptions = allRoles.filter((option) =>
    can("member:setRole", { role: ctx.role, targetRole: option.value }),
  );
  const inviteRoleOptions = allRoles.filter((option) =>
    can("member:invite", { role: ctx.role, targetRole: option.value }),
  );

  const pending = (invitations.ok ? invitations.value : []).filter(
    (invitation) => invitation.status === "pending",
  );

  return (
    <>
      <div className={styles.head}>
        <h1 className={styles.title}>{t(messages, "settings.organizationTitle")}</h1>
        <p className={styles.lead}>{t(messages, "settings.organizationLead")}</p>
      </div>

      <div className={styles.sections}>
        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "organization.basicsTitle")}</h2>
          {mayRename ? (
            <ActionForm
              action={renameOrganizationAction}
              messages={messages}
              className={ui.stack}
              label={t(messages, "organization.basicsTitle")}
            >
              <Field
                name="name"
                label={t(messages, "field.organizationName")}
                defaultValue={ctx.organization.name}
                maxLength={ORG_NAME_MAX}
                required
              />
              <div className={ui.row}>
                <SubmitButton tone="primary">{t(messages, "common.save")}</SubmitButton>
              </div>
            </ActionForm>
          ) : (
            <>
              <p className={styles.factValue}>{ctx.organization.name}</p>
              <p className={ui.hint}>{t(messages, "organization.renameForbidden")}</p>
            </>
          )}
        </section>

        <section className={ui.stack}>
          <div className={ui.rowBetween}>
            <h2 className={ui.cardTitle}>{t(messages, "member.title")}</h2>
            <span className={ui.muted}>
              {t(messages, "overview.memberCount", {
                count: members.ok ? members.value.length : 0,
              })}
            </span>
          </div>

          <ul className={ui.rows}>
            {(members.ok ? members.value : []).map((member) => {
              const isMe = member.userId === ctx.user.id;
              const mayChange =
                !isMe && can("member:setRole", { role: ctx.role, targetRole: member.role });

              return (
                <li key={member.userId}>
                  <div className={ui.rowItem}>
                    <span className={ui.rowMain}>
                      <span className={ui.rowName}>{member.name}</span>
                      <span className={ui.rowMeta}>{member.email}</span>
                    </span>
                    <span className={ui.rowActions}>
                      <RoleBadge role={member.role} messages={messages} />
                    </span>
                  </div>

                  {mayChange ? (
                    <details className={ui.disclosure}>
                      <summary className={ui.summary}>{t(messages, "member.manage")}</summary>
                      <div className={`${ui.disclosureBody} ${ui.stack}`}>
                        <ActionForm
                          action={setMemberRoleAction}
                          messages={messages}
                          className={ui.stack}
                          label={t(messages, "member.roleTitle")}
                        >
                          <input type="hidden" name="userId" value={member.userId} />
                          <Field
                            name="role"
                            kind="select"
                            label={t(messages, "member.roleTitle")}
                            defaultValue={member.role}
                            options={roleOptions}
                            required
                          />
                          <div className={ui.row}>
                            <SubmitButton size="small">{t(messages, "common.save")}</SubmitButton>
                          </div>
                        </ActionForm>

                        <ActionForm
                          action={removeMemberAction}
                          messages={messages}
                          className={ui.stackTight}
                          label={t(messages, "member.remove")}
                        >
                          <input type="hidden" name="userId" value={member.userId} />
                          <p className={ui.hint}>{t(messages, "member.removeHint")}</p>
                          <div className={ui.row}>
                            <SubmitButton tone="danger" size="small">
                              {t(messages, "member.remove")}
                            </SubmitButton>
                          </div>
                        </ActionForm>
                      </div>
                    </details>
                  ) : null}
                </li>
              );
            })}
          </ul>

          {members.ok && members.value.length === 1 ? (
            <div className={ui.empty}>
              <p className={ui.emptyTitle}>{t(messages, "member.aloneTitle")}</p>
              <p className={ui.emptyHint}>{t(messages, "member.aloneHint")}</p>
            </div>
          ) : null}
        </section>

        {mayInvite ? (
          <section className={ui.stack}>
            <h2 className={ui.cardTitle}>{t(messages, "invite.title")}</h2>

            <div className={`${ui.card} ${ui.stack}`}>
              <ActionForm
                action={createInvitationAction}
                messages={messages}
                className={ui.stack}
                label={t(messages, "invite.title")}
              >
                <Field
                  name="email"
                  type="email"
                  label={t(messages, "field.email")}
                  hint={t(messages, "invite.emailHint")}
                  required
                />
                <Field
                  name="role"
                  kind="select"
                  label={t(messages, "invite.role")}
                  defaultValue="member"
                  options={inviteRoleOptions}
                  required
                />
                <div className={ui.row}>
                  <SubmitButton tone="primary">{t(messages, "invite.submit")}</SubmitButton>
                </div>
              </ActionForm>
            </div>

            {pending.length === 0 ? (
              <div className={ui.empty}>
                <p className={ui.emptyTitle}>{t(messages, "invite.emptyTitle")}</p>
                <p className={ui.emptyHint}>{t(messages, "invite.emptyHint")}</p>
              </div>
            ) : (
              <ul className={ui.rows}>
                {pending.map((invitation) => (
                  <li className={ui.rowItem} key={invitation.id}>
                    <span className={ui.rowMain}>
                      <span className={ui.rowName}>{invitation.email}</span>
                      <span className={ui.rowMeta}>
                        {t(messages, "invite.expiresAt", {
                          date: formatDate(invitation.expiresAt, ctx.lang),
                        })}
                      </span>
                    </span>
                    <span className={ui.rowActions}>
                      <RoleBadge role={invitation.role} messages={messages} />
                      <ActionForm
                        action={revokeInvitationAction}
                        messages={messages}
                        label={t(messages, "invite.revoke")}
                      >
                        <input type="hidden" name="invitationId" value={invitation.id} />
                        <SubmitButton size="small">{t(messages, "invite.revoke")}</SubmitButton>
                      </ActionForm>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ) : null}

        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "organization.dangerTitle")}</h2>

          <details className={ui.disclosure}>
            <summary className={ui.summary}>{t(messages, "organization.leave")}</summary>
            <div className={`${ui.disclosureBody} ${ui.stack}`}>
              <ActionForm
                action={leaveOrganizationAction}
                messages={messages}
                className={ui.stackTight}
                label={t(messages, "organization.leave")}
              >
                <p className={ui.hint}>{t(messages, "organization.leaveHint")}</p>
                <div className={ui.row}>
                  <SubmitButton tone="danger" size="small">
                    {t(messages, "organization.leave")}
                  </SubmitButton>
                </div>
              </ActionForm>
            </div>
          </details>

          {mayDeleteOrganization ? (
            <details className={ui.disclosure}>
              <summary className={ui.summary}>{t(messages, "organization.delete")}</summary>
              <div className={`${ui.disclosureBody} ${ui.stack}`}>
                <ActionForm
                  action={deleteOrganizationAction}
                  messages={messages}
                  className={ui.stack}
                  label={t(messages, "organization.delete")}
                >
                  <Field
                    name="confirmName"
                    label={t(messages, "organization.confirmLabel")}
                    hint={t(messages, "organization.confirmHint", {
                      name: ctx.organization.name,
                    })}
                    maxLength={ORG_NAME_MAX}
                    required
                  />
                  <div className={ui.row}>
                    <SubmitButton tone="danger" size="small">
                      {t(messages, "organization.delete")}
                    </SubmitButton>
                  </div>
                </ActionForm>
              </div>
            </details>
          ) : null}
        </section>
      </div>
    </>
  );
}
