/**
 * お名前と言語の画面です（組織をまたいで同じ設定です）。
 */
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { updateProfileAction } from "@/app/_actions/profile";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { myProfileFlow, PROFILE_NAME_MAX } from "@/src/server/flows/auth";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../../app.module.css";

export default async function ProfileSettingsPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/settings/profile"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const profile = await myProfileFlow({ ctx });
  const name = profile.ok ? profile.value.name : ctx.user.name;
  const lang = profile.ok ? profile.value.lang : ctx.lang;

  return (
    <>
      <div className={styles.head}>
        <h1 className={styles.title}>{t(messages, "settings.profileTitle")}</h1>
        <p className={styles.lead}>{t(messages, "settings.profileLead")}</p>
      </div>

      <div className={styles.sections}>
        <section className={`${ui.card} ${ui.stack}`}>
          <ActionForm
            action={updateProfileAction}
            messages={messages}
            className={ui.stack}
            label={t(messages, "settings.profileTitle")}
          >
            <Field
              name="name"
              label={t(messages, "field.name")}
              defaultValue={name}
              maxLength={PROFILE_NAME_MAX}
              autoComplete="name"
              required
            />
            <Field
              name="lang"
              kind="select"
              label={t(messages, "field.lang")}
              defaultValue={lang}
              options={[
                { value: "ja", label: t(messages, "lang.ja") },
                { value: "en", label: t(messages, "lang.en") },
              ]}
              required
            />
            <div className={ui.row}>
              <SubmitButton tone="primary">{t(messages, "common.save")}</SubmitButton>
            </div>
          </ActionForm>
        </section>

        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "settings.accountTitle")}</h2>
          <dl className={styles.facts}>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "field.email")}</dt>
              <dd className={styles.factValue}>{ctx.user.email}</dd>
            </div>
          </dl>
          <p className={ui.hint}>{t(messages, "settings.emailHint")}</p>
        </section>
      </div>
    </>
  );
}
