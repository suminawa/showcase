/**
 * お支払いの画面です。
 *
 * ご契約の状態は subscriptions の表（flow がまとめた ctx.billing）だけを見ます。
 * この画面から Stripe に問い合わせることはありません。
 */
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import type { StripeStatus } from "@/src/core/billing-state";
import { formatDate, formatYen, t, type Messages } from "@/src/core/i18n";
import { projectLimitOf } from "@/src/core/plans";
import { openPortalAction, startCheckoutAction } from "@/app/_actions/billing";
import { ActionForm } from "@/app/_components/ActionForm";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { Toast } from "@/app/_components/Toast";
import { billingOverviewFlow } from "@/src/server/flows/billing";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { firstParam, loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../../app.module.css";

/** ご契約の状態を、そのままお読みいただける文にします */
function statusText(status: StripeStatus | "none", messages: Messages): string {
  switch (status) {
    case "active":
      return t(messages, "billing.status.active");
    case "trialing":
      return t(messages, "billing.status.trialing");
    case "past_due":
      return t(messages, "billing.status.past_due");
    case "unpaid":
      return t(messages, "billing.status.unpaid");
    case "canceled":
      return t(messages, "billing.status.canceled");
    case "incomplete":
      return t(messages, "billing.status.incomplete");
    case "incomplete_expired":
      return t(messages, "billing.status.incomplete_expired");
    case "paused":
      return t(messages, "billing.status.paused");
    default:
      return t(messages, "billing.status.none");
  }
}

export default async function BillingSettingsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/settings/billing"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const overview = await billingOverviewFlow({ ctx });
  if (!overview.ok) notFound();

  const { state, quota, plans, canManage, canStartCheckout } = overview.value;

  const params = await searchParams;
  const checkout = firstParam(params, "checkout");
  const plan = firstParam(params, "plan");

  return (
    <>
      <div className={styles.head}>
        <h1 className={styles.title}>{t(messages, "settings.billingTitle")}</h1>
        <p className={styles.lead}>{t(messages, "settings.billingLead")}</p>
      </div>

      {checkout === "done" ? (
        <Toast closeLabel={t(messages, "common.close")}>{t(messages, "billing.doneToast")}</Toast>
      ) : null}
      {checkout === "canceled" ? (
        <Toast tone="warn" closeLabel={t(messages, "common.close")}>
          {t(messages, "billing.canceledToast")}
        </Toast>
      ) : null}
      {plan === "canceled" ? (
        <Toast tone="warn" closeLabel={t(messages, "common.close")}>
          {t(messages, "billing.planCanceledToast")}
        </Toast>
      ) : null}

      <div className={styles.sections}>
        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "billing.currentTitle")}</h2>
          <dl className={styles.facts}>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "overview.factPlan")}</dt>
              <dd className={styles.factValue}>{t(messages, state.plan.nameKey)}</dd>
            </div>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "billing.statusTitle")}</dt>
              <dd className={styles.factValue}>{statusText(state.status, messages)}</dd>
            </div>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "overview.factPeriodEnd")}</dt>
              <dd className={styles.factValue}>
                {state.currentPeriodEnd === null
                  ? t(messages, "common.none")
                  : formatDate(state.currentPeriodEnd, ctx.lang)}
              </dd>
            </div>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "billing.usageTitle")}</dt>
              <dd className={styles.factValue}>
                {quota.unlimited
                  ? t(messages, "project.countUnlimited", { used: quota.used })
                  : t(messages, "project.count", { used: quota.used, limit: quota.limit })}
              </dd>
            </div>
          </dl>

          {state.cancelAtPeriodEnd ? (
            <p className={`${ui.notice} ${ui.noticeWarn}`}>
              {t(messages, "billing.cancelScheduled")}
            </p>
          ) : null}

          {canManage ? (
            <ActionForm
              action={openPortalAction}
              messages={messages}
              className={ui.row}
              label={t(messages, "billing.portal")}
            >
              <SubmitButton>{t(messages, "billing.portal")}</SubmitButton>
              <span className={ui.hint}>{t(messages, "billing.portalHint")}</span>
            </ActionForm>
          ) : (
            <p className={ui.hint}>{t(messages, "billing.ownerOnly")}</p>
          )}
        </section>

        <section className={ui.stack}>
          <h2 className={ui.cardTitle}>{t(messages, "billing.plansTitle")}</h2>
          <div className={styles.planList}>
            {plans.map((entry) => {
              const limit = projectLimitOf(entry);
              const isCurrent = entry.id === state.planId;

              return (
                <article
                  className={
                    isCurrent ? `${styles.planCard} ${styles.planCardCurrent}` : styles.planCard
                  }
                  key={entry.id}
                >
                  <div className={styles.planCardHead}>
                    <h3 className={styles.planCardName}>{t(messages, entry.nameKey)}</h3>
                    <p className={styles.planCardPrice}>{formatYen(entry.monthlyYen, ctx.lang)}</p>
                  </div>
                  <p className={ui.muted}>
                    {limit === null
                      ? t(messages, "plan.limitNone")
                      : t(messages, "plan.limitCount", { count: limit })}
                  </p>
                  <p className={ui.muted}>{t(messages, entry.descriptionKey)}</p>

                  <div className={styles.planCardFoot}>
                    {isCurrent ? (
                      <span className={ui.badge}>{t(messages, "billing.currentPlan")}</span>
                    ) : entry.id === "free" ? null : canStartCheckout ? (
                      <ActionForm
                        action={startCheckoutAction}
                        messages={messages}
                        label={t(messages, "billing.choose")}
                      >
                        <input type="hidden" name="planId" value={entry.id} />
                        <SubmitButton tone="primary" size="small">
                          {t(messages, "billing.choose")}
                        </SubmitButton>
                      </ActionForm>
                    ) : canManage ? (
                      // ご契約が続いているあいだは、プランの変更はお手続きの画面で行えます
                      <p className={ui.hint}>{t(messages, "billing.changeFromPortal")}</p>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </div>
          <p className={ui.hint}>{t(messages, "billing.taxNote")}</p>
          <nav className={styles.planLegal} aria-label={t(messages, "legal.navLabel")}>
            <Link href="/legal/tokushoho">{t(messages, "legal.tokushoho.title")}</Link>
            <Link href="/legal/terms">{t(messages, "legal.terms.title")}</Link>
            <Link href="/legal/privacy">{t(messages, "legal.privacy.title")}</Link>
          </nav>
        </section>
      </div>
    </>
  );
}
