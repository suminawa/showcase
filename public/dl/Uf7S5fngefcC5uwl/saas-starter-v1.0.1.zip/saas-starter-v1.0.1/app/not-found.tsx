/**
 * お探しのページが見つからないときの画面です。
 * その組織の一員でない方にも、この画面をお返しします
 * （その組織があること自体を、お知らせしないためです）。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { pageMessages } from "@/src/server/ports";
import ui from "@/app/_components/ui.module.css";

export default async function NotFoundPage(): Promise<ReactNode> {
  const { messages } = await pageMessages();

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <div className={`${ui.panel} ${ui.stack}`}>
          <div className={ui.stackTight}>
            <h1 className={ui.cardTitle}>{t(messages, "notFound.title")}</h1>
            <p className={ui.cardHint}>{t(messages, "notFound.lead")}</p>
          </div>
          <p className={ui.row}>
            <Link className={ui.button} href="/">
              {t(messages, "notFound.home")}
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
