import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: {
    alias: {
      // `import "server-only";` は Next が解決します（同梱の空のファイルに置き換わります）。
      // テストは Next を通らないので、同じ空のファイルに向けておきます。
      "server-only": "next/dist/compiled/server-only/empty.js",
      // 画面（app/）が使う「@/…」の書き方を、テストからも同じようにたどれるようにします
      "@": fileURLToPath(new URL("./", import.meta.url)),
    },
  },
  test: {
    environment: "node",
    globals: true,
    include: ["test/**/*.test.ts"],
    // 行の出入りの決まりと、本物のつなぎ役の検査は、ローカルの Supabase が要るので
    // npm run test:rls で別に回す（そのとき scripts/run-rls.mjs が RLS_TEST=1 を立てる）
    exclude:
      process.env.RLS_TEST === "1"
        ? ["node_modules/**"]
        : ["test/rls.test.ts", "test/supabase.test.ts", "node_modules/**"],
  },
});
