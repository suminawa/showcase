/**
 * お申し付けが画面に届く前に、1 回だけ通るところです。
 *
 * **ここの役目は 1 つだけ、ログインの状態の取り直しです。**
 * ログインの控え（トークン）には短い期限があり、画面の部品からは cookie を
 * 書けません。ここで 1 回お尋ねしておくと、新しくなった控えをお返事に載せられます。
 *
 * **画面の関門（ログインの有無・組織の一員かどうか）は、ここには置きません。**
 * ここは速い代わりに当てにならない層です。守りをここに寄せると、画面を直に
 * お呼びになったときに素通りしてしまいます。関門は、画面と操作の 1 つずつが
 * 自分で通ります（src/server/ports.ts の appGate）。
 */
import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { siteOrigin } from "./src/server/urls";

/**
 * ログインの控えに secure（https のときだけお送りする印）を付けるかどうかです。
 *
 * **src/server/ports.ts の cookieSecure() と同じ判定にそろえてあります。**
 * ここは src/ の外にあり、環境変数を直に読める唯一の場所です
 * （src/ の中で環境変数を読むのは、合成の場所 1 か所だけという決まりです）。
 */
function cookieSecure(): boolean {
  return siteOrigin(process.env).startsWith("https://") || process.env.NODE_ENV === "production";
}

/**
 * 見本のしくみ（メモリの偽物）で動いているかどうかです。
 *
 * **src/server/ports.ts の isFakeMode() と同じ判定にそろえてあります。**
 * 本番では、STARTER_FAKE=1 だけでは見本のしくみに入りません
 * （訪れた方全員が同じ見本の方として入ってしまうためです）。
 */
function fakeMode(): boolean {
  if (process.env.STARTER_FAKE !== "1") return false;
  if (process.env.NODE_ENV !== "production") return true;
  return process.env.STARTER_FAKE_ALLOW_PRODUCTION === "1";
}

export async function proxy(request: NextRequest): Promise<NextResponse> {
  const response = NextResponse.next({ request });

  // 見本のしくみでお試しのあいだは、外へ 1 度もつなぎません。
  // ログインの状態はサーバーのメモリにあり、取り直すものがないためです
  // （鍵が置いてあっても、ここでお止めします）。
  if (fakeMode()) return response;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

  // 鍵をまだ頂戴していないときも、そのままお通しします
  if (url === "" || anonKey === "") return response;

  return refreshSession(request, response, { url, anonKey });
}

/**
 * ログインの控えを 1 回だけ取り直し、新しくなった控えをお返事に載せます。
 *
 * **取り直せなかったときは、そのままお通しします。**
 * ここで止めると、認証の口が一時的に応えないあいだ、サイト全体が開かなくなります。
 * 関門（ログインの有無・組織の一員かどうか）は、画面と操作の 1 つずつが
 * 自分で通るので、素通しでも中身はお守りできます。
 */
async function refreshSession(
  request: NextRequest,
  initial: NextResponse,
  config: { url: string; anonKey: string },
): Promise<NextResponse> {
  let response = initial;
  const { url, anonKey } = config;

  try {
    const supabase = createServerClient(url, anonKey, {
    /**
     * ログインの控えに付ける印です（つなぎ口の側と同じ中身にそろえます）。
     * 同梱の既定は httpOnly も secure も付かないため、ここで付け直します。
     */
      cookieOptions: {
        httpOnly: true,
        secure: cookieSecure(),
        sameSite: "lax",
        path: "/",
      },
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet, headers) {
          for (const { name, value } of cookiesToSet) {
            request.cookies.set(name, value);
          }

          response = NextResponse.next({ request });

          for (const { name, value, options } of cookiesToSet) {
            response.cookies.set(name, value, options);
          }

          // 2 つめの引数は、取り置きを止めるためのヘッダです。
          // 取り置かれると、ある方のログインの控えが別の方に渡ってしまうため、
          // お返事にもそのまま載せます。
          for (const [key, headerValue] of Object.entries(headers)) {
            response.headers.set(key, headerValue);
          }
        },
      },
    });

    // お返事を組み立てる前に、1 回だけお尋ねします（ここで控えが新しくなります）
    await supabase.auth.getUser();
  } catch {
    // 何が起きたかは、サーバーの記録にだけ残します
    // （お客さまの画面には出しませんし、誤りの中身も持ち回りません）。
    console.error("ログインの状態を取り直せませんでした。このお申し付けはそのままお通しします");
  }

  return response;
}

export const config = {
  matcher: [
    /**
     * 次のものは通しません。
     *   - 決済の通知の受け口（ログインの状態は要りません。本文にも触れません）
     *   - 組み立て済みのファイルと画像
     *   - 拡張子のついたファイル
     */
    "/((?!api/stripe/webhook|_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js|map|txt|xml|woff|woff2)$).*)",
  ],
};
