/**
 * 運営の画面（/admin）の関門を確かめます。
 *
 * この画面は、ADMIN_EMAILS に書かれた方だけがご覧になれます。
 * それ以外の方には、**403 ではなく 404** をお返しします（画面があること自体をお知らせしないためです）。
 *
 * adminOverviewFlow は権限を確かめません（すべての組織の行をお返しします）。
 * ですので「画面が isAdminEmail を先に通していること」を、字面ではなく
 * **関門の関数を差し替えて**確かめます。差し替えた答えのとおりに 404 になるなら、
 * 画面はたしかにその関門を通っています。
 */
import { readFileSync } from "node:fs";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { FakePorts } from "../src/adapters/fake";

/** 画面は next/headers を通して cookie と見出しを読みます（お申し付けの外から呼ぶための仮の口です） */
vi.mock("next/headers", () => ({
  cookies: async () => ({ get: () => undefined }),
  headers: async () => new Headers(),
}));

const NOT_FOUND = "NEXT_HTTP_ERROR_FALLBACK;404";
const OWNER_EMAIL = "owner@example.com";

const env = process.env as Record<string, string | undefined>;
const before = { STARTER_FAKE: env.STARTER_FAKE, ADMIN_EMAILS: env.ADMIN_EMAILS };

/** 見本のしくみの ports です（合成の場所が 1 つだけ作って覚えています） */
async function fakePorts(): Promise<FakePorts> {
  const { getPorts } = await import("../src/server/ports");
  return (await getPorts()) as FakePorts;
}

async function signInAs(userId: string): Promise<void> {
  (await fakePorts()).auth.signInAs(userId);
}

async function signOut(): Promise<void> {
  await (await fakePorts()).auth.signOut();
}

type Params = Record<string, string | string[] | undefined>;

/** いまの env と mock のまま、画面を組み立てます */
async function openAdmin(params: Params = {}): Promise<unknown> {
  const { default: AdminPage } = await import("../app/admin/page");
  return AdminPage({ searchParams: Promise.resolve(params) });
}

/** 組み上がった画面から、お出しする字をすべて拾います（差し込んだ値も見ます） */
function allText(node: unknown, out: string[] = []): string[] {
  if (typeof node === "string" || typeof node === "number") {
    out.push(String(node));
    return out;
  }
  if (Array.isArray(node)) {
    for (const item of node) allText(item, out);
    return out;
  }
  if (typeof node === "object" && node !== null && "props" in node) {
    const props = (node as { props?: Record<string, unknown> }).props;
    if (props !== undefined) for (const value of Object.values(props)) allText(value, out);
  }
  return out;
}

async function textOfAdmin(params: Params = {}): Promise<string> {
  return allText(await openAdmin(params)).join(" ");
}

type AdminFlows = typeof import("../src/server/flows/admin");

/**
 * 関門（isAdminEmail）と一覧（adminOverviewFlow）を、答えを覚える口に差し替えます。
 *
 * もとの中身は importActual から取ります（1 つ前の差し替えを写してしまわないためです）。
 * answer に true・false をお渡しになると、関門はいつもその答えを返します。
 */
async function spyOnAdminFlows(answer?: boolean): Promise<{
  isAdminEmail: ReturnType<typeof vi.fn>;
  adminOverviewFlow: ReturnType<typeof vi.fn>;
}> {
  vi.doUnmock("../src/server/flows/admin");
  vi.resetModules();

  const actual = await vi.importActual<AdminFlows>("../src/server/flows/admin");
  const isAdminEmail = vi.fn(answer === undefined ? actual.isAdminEmail : () => answer);
  const adminOverviewFlow = vi.fn(actual.adminOverviewFlow);

  vi.doMock("../src/server/flows/admin", () => ({ ...actual, isAdminEmail, adminOverviewFlow }));
  vi.resetModules();
  return { isAdminEmail, adminOverviewFlow };
}

beforeEach(async () => {
  vi.resetModules();
  env.STARTER_FAKE = "1";
  env.ADMIN_EMAILS = OWNER_EMAIL;
  await signOut();
});

afterEach(() => {
  vi.doUnmock("../src/server/flows/admin");
  vi.resetModules();
  for (const [name, value] of Object.entries(before)) {
    if (value === undefined) delete env[name];
    else env[name] = value;
  }
});

describe("運営の画面の関門", () => {
  it("ログインしていない方には、404 をお返しする（ログインの画面へもお通ししません）", async () => {
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
  });

  it("ログインしていても、一覧に無いメールアドレスの方には 404", async () => {
    await signInAs("u-member");
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
  });

  it("ADMIN_EMAILS を頂戴していないときは、どなたにも 404", async () => {
    await signInAs("u-owner");
    delete env.ADMIN_EMAILS;
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
  });

  it("ADMIN_EMAILS が空・空白だけのときも 404", async () => {
    await signInAs("u-owner");

    env.ADMIN_EMAILS = "";
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);

    env.ADMIN_EMAILS = "   ";
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);

    env.ADMIN_EMAILS = " , ";
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
  });

  it("ADMIN_EMAILS は入っていても、鍵をまだ頂戴していないときは 500 ではなく 404", async () => {
    // 「あることを知らせない」を、この組み合わせだけ崩さないための確かめです。
    // 鍵が無いと getPorts() が投げます。そのままにすると、この画面だけが
    // 500 になり、置いてあること自体が外から分かってしまいます。
    await signInAs("u-owner");
    env.STARTER_FAKE = "";
    env.ADMIN_EMAILS = OWNER_EMAIL;
    vi.resetModules();

    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
  });

  it("大文字小文字と前後の空白がちがっても、同じメールアドレスなら開く", async () => {
    await signInAs("u-owner");
    env.ADMIN_EMAILS = " Owner@Example.COM , admin@example.com ";

    const text = await textOfAdmin();
    expect(text).toContain("しおさい設計室");
  });

  it("一覧にあるメールアドレスの方には、組織とご利用の方の一覧をお見せする", async () => {
    await signInAs("u-owner");

    const text = await textOfAdmin();
    expect(text).toContain("しおさい設計室");
    expect(text).toContain("なぎさ工房");
    expect(text).toContain(OWNER_EMAIL);
    expect(text).toContain("みなと 太郎");
  });
});

describe("関門を外したときの番人", () => {
  it("関門が「お入りいただけません」と答えたら、一覧に書かれた方でも 404", async () => {
    await signInAs("u-owner");
    await spyOnAdminFlows(false);

    // ADMIN_EMAILS は一致しています。それでも 404 になるので、
    // 画面はたしかに isAdminEmail の答えで決めています。
    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
  });

  it("関門が「お入りいただけます」と答えたら、一覧に無い方でも開く（関門はここだけ）", async () => {
    await signInAs("u-member");
    env.ADMIN_EMAILS = "somebody-else@example.com";
    const { isAdminEmail } = await spyOnAdminFlows(true);

    const text = allText(await openAdmin()).join(" ");
    expect(text).toContain("しおさい設計室");
    expect(isAdminEmail).toHaveBeenCalled();
  });

  it("関門は、一覧を読むより先に通る", async () => {
    await signInAs("u-owner");
    const { isAdminEmail, adminOverviewFlow } = await spyOnAdminFlows();

    await openAdmin();

    expect(isAdminEmail).toHaveBeenCalledWith(OWNER_EMAIL, OWNER_EMAIL);
    expect(adminOverviewFlow).toHaveBeenCalled();
    expect(isAdminEmail.mock.invocationCallOrder[0]).toBeLessThan(
      adminOverviewFlow.mock.invocationCallOrder[0],
    );
  });

  it("ログインしていない方には、一覧を 1 度も読まない", async () => {
    const { adminOverviewFlow } = await spyOnAdminFlows();

    await expect(openAdmin()).rejects.toThrow(NOT_FOUND);
    expect(adminOverviewFlow).not.toHaveBeenCalled();
  });
});

describe("ページの区切り", () => {
  async function pageAsked(params: Params): Promise<number> {
    const { adminOverviewFlow } = await spyOnAdminFlows();

    await signInAs("u-owner");
    await openAdmin(params);

    const call = adminOverviewFlow.mock.calls[0]?.[0] as { page: number };
    return call.page;
  }

  it("数でない値・空の値は、1 ページ目にする", async () => {
    expect(await pageAsked({ page: "abc" })).toBe(1);
    expect(await pageAsked({ page: "" })).toBe(1);
    expect(await pageAsked({})).toBe(1);
  });

  it("0 と負の数も、1 ページ目にする", async () => {
    expect(await pageAsked({ page: "0" })).toBe(1);
    expect(await pageAsked({ page: "-3" })).toBe(1);
  });

  it("大きすぎる数は、読み飛ばす件数が膨らまないように丸める", async () => {
    expect(await pageAsked({ page: "999999999999" })).toBeLessThanOrEqual(10000);
    expect(await pageAsked({ page: "1e9" })).toBe(1);
  });

  it("同じ名前を 2 つ頂戴したときは、はじめの 1 つだけを見る", async () => {
    expect(await pageAsked({ page: ["2", "5"] })).toBe(2);
  });
});

describe("ご契約の一覧のお名前", () => {
  it("組織が同じページに並んでいなくても、ご契約にお名前が出る", async () => {
    await signInAs("u-owner");

    // 1 ページは 50 件までです。60 件目の組織は、1 ページ目の組織の一覧に入りません。
    const ports = await fakePorts();
    let last = "";
    for (let i = 0; i < 60; i += 1) {
      const created = await ports.data.createOrganizationWithOwner({
        name: `見本の組織 ${i + 1}`,
        userId: "u-owner",
      });
      last = created.id;
    }
    await ports.data.upsertSubscription({
      organizationId: last,
      planId: "business",
      status: "active",
      stripeSubscriptionId: null,
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: "2026-09-20T00:00:00.000Z",
    });

    const text = await textOfAdmin();
    expect(text).toContain("見本の組織 60");
  });
});

describe("お出ししないもの", () => {
  it("決済の番号・お客さまの控え・招待のトークンを、画面に出さない", async () => {
    await signInAs("u-owner");

    const ports = await fakePorts();
    await ports.data.upsertSubscription({
      organizationId: "org-1",
      planId: "standard",
      status: "active",
      stripeSubscriptionId: "sub_SECRET_VALUE",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: "2026-09-20T00:00:00.000Z",
    });
    await ports.data.setStripeCustomer("org-1", "cus_SECRET_VALUE");

    const text = await textOfAdmin();
    expect(text).not.toContain("sub_SECRET_VALUE");
    expect(text).not.toContain("cus_SECRET_VALUE");
    expect(text).not.toContain("stripeSubscriptionId");
    expect(text).not.toContain("tokenHash");
  });
});

describe("読むだけの画面", () => {
  const page = (): string =>
    readFileSync(new URL("../app/admin/page.tsx", import.meta.url), "utf8");

  it("関門の 2 つが、どちらも書かれている", () => {
    const text = page();
    expect(text).toContain("isAdminEmail");
    expect(text).toContain("notFound");
  });

  it("お申し付けの口（form・_actions）を 1 つも置いていない", () => {
    const text = page();
    expect(text).not.toContain("<form");
    expect(text).not.toContain("_actions");
    expect(text).not.toContain("ActionForm");
    expect(text).not.toContain("SubmitButton");
  });

  it("検索エンジンに載せない印を付けている", () => {
    expect(page()).toContain("robots");
    expect(page()).toMatch(/index:\s*false/);
  });

  it("取り置き（キャッシュ）をしない", () => {
    expect(page()).toContain('dynamic = "force-dynamic"');
  });
});
