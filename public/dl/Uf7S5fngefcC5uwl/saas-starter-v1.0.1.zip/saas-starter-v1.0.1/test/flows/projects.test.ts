import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import type { StripeStatus } from "../../src/core/billing-state";
import { findPlan, freePlan, type PlanId } from "../../src/core/plans";
import type { Ports, Project, SessionUser } from "../../src/ports";
import { buildCtx, type Ctx, type FlowResult } from "../../src/server/context";
import {
  PROJECT_NAME_MAX,
  PROJECT_NOTE_MAX,
  createProjectFlow,
  deleteProjectFlow,
  listProjectsFlow,
  updateProjectFlow,
} from "../../src/server/flows/projects";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";

/**
 * 上限の数字は `plans.config.ts` から取ります。
 * README 10 章のとおりに上限をお変えになっても、この検査は緑のままです
 * （同梱の見本では、無料が 3 件・スタンダードが 50 件です）。
 */
const FREE_LIMIT = freePlan().projectLimit;
const STANDARD_LIMIT = findPlan("standard")!.projectLimit;

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };

describe("プロジェクトの流れ", () => {
  let ports: Ports & { store: FakeStore };

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
  });

  async function ctxFor(user: SessionUser, organizationId = "org-1"): Promise<Ctx> {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(`ctx を作れませんでした: ${built.code}`);
    return built.value;
  }

  /** 契約の行を直に置きます（本物では Webhook が書きます） */
  async function setPlan(organizationId: string, planId: PlanId, status: StripeStatus): Promise<void> {
    await ports.data.upsertSubscription({
      organizationId,
      planId,
      status,
      stripeSubscriptionId: "sub_demo",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: NOW.toISOString(),
    });
  }

  async function create(
    user: SessionUser,
    organizationId: string,
    name: string,
  ): Promise<FlowResult<Project>> {
    return createProjectFlow({
      ctx: await ctxFor(user, organizationId),
      raw: { name, note: "" },
    });
  }

  /** 見本のデータの中から、その方がお作りになったプロジェクトを 1 件取ります */
  async function projectBy(organizationId: string, createdBy: string): Promise<Project> {
    const rows = await ports.data.listProjects(organizationId);
    const found = rows.find((row) => row.createdBy === createdBy);
    if (found === undefined) throw new Error(`${createdBy} が作ったプロジェクトがありません`);
    return found;
  }

  it("無料のプランでは上限まで作れて、その次は plan_limit", async () => {
    // なぎさ工房（org-2）は、いその 花子がオーナーで、プロジェクトはまだ 0 件です
    for (let i = 0; i < FREE_LIMIT; i += 1) {
      const result = await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
      expect(result.ok, `${i + 1} 件目`).toBe(true);
    }

    const over = await create(ADMIN, "org-2", "上限の次のプロジェクト");
    expect(over).toEqual({ ok: false, code: "plan_limit" });
    expect(await ports.data.countProjects("org-2")).toBe(FREE_LIMIT);
  });

  it("無料の上限の 1 つ手前で 2 件同時にお作りになっても、片方だけが通る", async () => {
    for (let i = 0; i < FREE_LIMIT - 1; i += 1) {
      const result = await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
      expect(result.ok, `${i + 1} 件目`).toBe(true);
    }

    // 数えるところと作るところが分かれていると、2 件とも通って上限を 1 件超えます
    const [left, right] = await Promise.all([
      create(ADMIN, "org-2", "同時のプロジェクト A"),
      create(ADMIN, "org-2", "同時のプロジェクト B"),
    ]);

    const passed = [left, right].filter((result) => result.ok);
    const stopped = [left, right].filter((result) => !result.ok);
    expect(passed).toHaveLength(1);
    expect(stopped).toEqual([{ ok: false, code: "plan_limit" }]);
    expect(await ports.data.countProjects("org-2")).toBe(FREE_LIMIT);
  });

  it("スタンダードの上限の境目でも、2 件同時にお作りになるのは片方だけ", async () => {
    await setPlan("org-2", "standard", "active");
    for (let i = 0; i < STANDARD_LIMIT - 1; i += 1) {
      await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
    }

    const [left, right] = await Promise.all([
      create(ADMIN, "org-2", "同時のプロジェクト A"),
      create(ADMIN, "org-2", "同時のプロジェクト B"),
    ]);

    expect([left, right].filter((result) => result.ok)).toHaveLength(1);
    expect([left, right].filter((result) => !result.ok)).toEqual([
      { ok: false, code: "plan_limit" },
    ]);
    expect(await ports.data.countProjects("org-2")).toBe(STANDARD_LIMIT);
  });

  it("上限のないプランでは、同時にお作りになっても両方が通る", async () => {
    await setPlan("org-2", "business", "active");

    const [left, right] = await Promise.all([
      create(ADMIN, "org-2", "同時のプロジェクト A"),
      create(ADMIN, "org-2", "同時のプロジェクト B"),
    ]);

    expect(left.ok && right.ok).toBe(true);
    expect(await ports.data.countProjects("org-2")).toBe(2);
  });

  it("スタンダードの契約が生きていれば、無料の上限の次も作れる", async () => {
    for (let i = 0; i < FREE_LIMIT; i += 1) {
      await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
    }
    await setPlan("org-2", "standard", "active");

    const next = await create(ADMIN, "org-2", "上限の次のプロジェクト");
    expect(next.ok).toBe(true);
    expect(await ports.data.countProjects("org-2")).toBe(FREE_LIMIT + 1);
  });

  it("契約が canceled になっても既存は消えず、新しく作るときだけ plan_limit", async () => {
    await setPlan("org-2", "standard", "active");
    for (let i = 0; i < FREE_LIMIT + 1; i += 1) {
      const result = await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
      expect(result.ok, `${i + 1} 件目`).toBe(true);
    }

    await setPlan("org-2", "standard", "canceled");

    const listed = await listProjectsFlow({ ctx: await ctxFor(ADMIN, "org-2") });
    expect(listed.ok).toBe(true);
    if (!listed.ok) return;
    expect(listed.value.projects).toHaveLength(FREE_LIMIT + 1);
    expect(listed.value.quota).toEqual({
      limit: FREE_LIMIT,
      used: FREE_LIMIT + 1,
      remaining: 0,
      atLimit: true,
      unlimited: false,
    });

    const over = await create(ADMIN, "org-2", "ご解約のあとのプロジェクト");
    expect(over).toEqual({ ok: false, code: "plan_limit" });
    expect(await ports.data.countProjects("org-2")).toBe(FREE_LIMIT + 1);
  });

  it("member は自分の作ったものを消せて、他の方の作ったものには forbidden", async () => {
    const mine = await createProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { name: "打ち合わせの記録", note: "" },
    });
    expect(mine.ok).toBe(true);
    if (!mine.ok) return;

    const others = await projectBy("org-1", OWNER.id);
    const denied = await deleteProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { projectId: others.id },
    });
    expect(denied).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.projects.has(others.id)).toBe(true);

    const removed = await deleteProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { projectId: mine.value.id },
    });
    expect(removed).toEqual({ ok: true, value: { projectId: mine.value.id } });
    expect(ports.store.projects.has(mine.value.id)).toBe(false);
  });

  it("退会された方の作ったものは、member には消せず、admin なら消せる", async () => {
    const mine = await createProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { name: "退会される前のプロジェクト", note: "" },
    });
    expect(mine.ok).toBe(true);
    if (!mine.ok) return;

    // 退会されると、作成者の欄は空になります（本物では on delete set null）
    const row = ports.store.projects.get(mine.value.id);
    if (row === undefined) throw new Error("プロジェクトがありません");
    ports.store.projects.set(mine.value.id, { ...row, createdBy: null });

    const denied = await deleteProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { projectId: mine.value.id },
    });
    expect(denied).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.projects.has(mine.value.id)).toBe(true);

    const removed = await deleteProjectFlow({
      ctx: await ctxFor(ADMIN),
      raw: { projectId: mine.value.id },
    });
    expect(removed).toEqual({ ok: true, value: { projectId: mine.value.id } });
    expect(ports.store.projects.has(mine.value.id)).toBe(false);
  });

  it("admin は他の方の作ったものも消せる", async () => {
    const others = await projectBy("org-1", OWNER.id);

    const removed = await deleteProjectFlow({
      ctx: await ctxFor(ADMIN),
      raw: { projectId: others.id },
    });
    expect(removed).toEqual({ ok: true, value: { projectId: others.id } });
    expect(ports.store.projects.has(others.id)).toBe(false);
  });

  it("別の組織のプロジェクトの ID を渡しても触れず、not_found を返す", async () => {
    const outside = await create(ADMIN, "org-2", "なぎさ工房の見本");
    expect(outside.ok).toBe(true);
    if (!outside.ok) return;

    const removed = await deleteProjectFlow({
      ctx: await ctxFor(OWNER),
      raw: { projectId: outside.value.id },
    });
    expect(removed).toEqual({ ok: false, code: "not_found" });

    const updated = await updateProjectFlow({
      ctx: await ctxFor(OWNER),
      raw: { projectId: outside.value.id, name: "書き換え", note: "" },
    });
    expect(updated).toEqual({ ok: false, code: "not_found" });

    const still = ports.store.projects.get(outside.value.id);
    expect(still?.name).toBe("なぎさ工房の見本");
  });

  it("name は 80 文字まで、note は 2000 文字まで（超えると invalid）", async () => {
    const longName = await createProjectFlow({
      ctx: await ctxFor(OWNER),
      raw: { name: "あ".repeat(PROJECT_NAME_MAX + 1), note: "" },
    });
    expect(longName).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "name", code: "too_long" }],
    });

    const longNote = await createProjectFlow({
      ctx: await ctxFor(OWNER),
      raw: { name: "見本のプロジェクト", note: "あ".repeat(PROJECT_NOTE_MAX + 1) },
    });
    expect(longNote).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "note", code: "too_long" }],
    });

    const empty = await createProjectFlow({
      ctx: await ctxFor(OWNER),
      raw: { name: "   ", note: "" },
    });
    expect(empty).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "name", code: "required" }],
    });

    // 境目はお通しします（80 文字と 2000 文字）
    const edge = await createProjectFlow({
      ctx: await ctxFor(OWNER),
      raw: { name: "あ".repeat(PROJECT_NAME_MAX), note: "い".repeat(PROJECT_NOTE_MAX) },
    });
    expect(edge.ok).toBe(true);
    expect(ports.store.projects.size).toBe(3);
  });

  it("listProjectsFlow は、無料のプランでいっぱいのときの残り件数を返す", async () => {
    for (let i = 0; i < FREE_LIMIT; i += 1) {
      await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
    }

    const listed = await listProjectsFlow({ ctx: await ctxFor(ADMIN, "org-2") });
    expect(listed.ok).toBe(true);
    if (!listed.ok) return;
    expect(listed.value.quota).toEqual({
      limit: FREE_LIMIT,
      used: FREE_LIMIT,
      remaining: 0,
      atLimit: true,
      unlimited: false,
    });
    expect(listed.value.projects).toHaveLength(FREE_LIMIT);
  });

  it("listProjectsFlow の件数は、一覧の長さではなく数え直した件数から作る", async () => {
    // 本物のデータベースでは、1 回のお返事に入る行数に上限があります。
    // 一覧の長さをそのまま出すと、上限なしのプランのお客さまの画面が
    // その数字で止まってしまいます（お作りになれる件数は countProjects で判じています）。
    await setPlan("org-2", "business", "active");
    for (let i = 0; i < 3; i += 1) {
      await create(ADMIN, "org-2", `見本のプロジェクト ${i + 1}`);
    }

    // 一覧だけが 2 件で切られている店を作ります
    const truncated: Ports = {
      ...ports,
      data: new Proxy(ports.data, {
        get(target, key, receiver) {
          if (key === "listProjects") {
            return async (organizationId: string) =>
              (await target.listProjects(organizationId)).slice(0, 2);
          }
          const value = Reflect.get(target, key, receiver);
          return typeof value === "function" ? value.bind(target) : value;
        },
      }),
    };

    const built = await buildCtx({
      ports: truncated,
      siteOrigin: ORIGIN,
      user: ADMIN,
      organizationId: "org-2",
      lang: "ja",
      now: NOW,
    });
    expect(built.ok).toBe(true);
    if (!built.ok) return;

    const listed = await listProjectsFlow({ ctx: built.value });
    expect(listed.ok).toBe(true);
    if (!listed.ok) return;
    expect(listed.value.projects).toHaveLength(2);
    // 数字のほうは、切られていない本当の件数です
    expect(listed.value.quota.used).toBe(3);
    expect(listed.value.quota.unlimited).toBe(true);
  });

  it("updateProjectFlow は member も使えて、知らない ID には not_found", async () => {
    const target = await projectBy("org-1", OWNER.id);

    const updated = await updateProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { projectId: target.id, name: "コーポレートサイト刷新（第 2 期）", note: "構成案をご確認いただきました。" },
    });
    expect(updated.ok).toBe(true);
    if (!updated.ok) return;
    expect(updated.value.name).toBe("コーポレートサイト刷新（第 2 期）");
    expect(ports.store.projects.get(target.id)?.note).toBe("構成案をご確認いただきました。");

    const unknown = await updateProjectFlow({
      ctx: await ctxFor(MEMBER),
      raw: { projectId: "st-projects-999", name: "見本", note: "" },
    });
    expect(unknown).toEqual({ ok: false, code: "not_found" });
  });
});
