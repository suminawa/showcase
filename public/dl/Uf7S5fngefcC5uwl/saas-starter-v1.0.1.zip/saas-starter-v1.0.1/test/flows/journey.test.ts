/**
 * 設計書 §6 の通しの流れです。
 * ご登録から解約・組織の削除まで、10 の段を順にたどります。
 *
 * **この 10 件は、書いてある順に実行されることを前提にしています**
 * （同じ 1 つの店（fake の 8 つの表）を上から順に使い、前の段の結果を次の段が使います）。
 * 1 件だけを取り出して実行したり、並びを入れ替えたり（vitest の shuffle）すると落ちます。
 * 段ごとに何を確かめたかが読めるよう、1 つの it にまとめずに分けてあります。
 */
import { readFileSync } from "node:fs";
import { beforeAll, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import type { Messages } from "../../src/core/i18n";
import { freePlan } from "../../src/core/plans";
import type { Ports, SessionUser, SubscriptionChange } from "../../src/ports";
import { buildCtx, type Ctx } from "../../src/server/context";
import {
  ONBOARDING_PATH,
  ensureProfileFlow,
  landingPathFlow,
  signUpFlow,
} from "../../src/server/flows/auth";
import {
  applyWebhookFlow,
  billingOverviewFlow,
  startCheckoutFlow,
} from "../../src/server/flows/billing";
import { acceptInvitationFlow, createInvitationFlow } from "../../src/server/flows/invitations";
import {
  createOrganizationFlow,
  deleteOrganizationFlow,
  listOrganizationsFlow,
} from "../../src/server/flows/organizations";
import { createProjectFlow, deleteProjectFlow } from "../../src/server/flows/projects";
import {
  INVITE_ACCEPT_LIMIT,
  INVITE_LIMIT,
  LOGIN_IP_LIMIT,
  LOGIN_LIMIT,
  createMemoryRateLimiter,
  type RateLimiter,
} from "../../src/server/ratelimit";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";
const CUSTOMER = "cus_demo_1";
const ORG_NAME = "しおさい設計室";

const messages = JSON.parse(
  readFileSync(new URL("../../messages/ja.json", import.meta.url), "utf8"),
) as Messages;

function payloadOf(input: {
  eventId: string;
  eventType: string;
  change: SubscriptionChange | null;
}): string {
  return JSON.stringify(input);
}

const FREE_LIMIT = freePlan().projectLimit;

describe("通しの流れ（ご登録から解約まで）", () => {
  let ports: Ports & { store: FakeStore };
  let loginLimiter: RateLimiter;
  let loginIpLimiter: RateLimiter;
  let inviteLimiter: RateLimiter;
  let inviteAcceptLimiter: RateLimiter;

  let founder: SessionUser = { id: "", email: "", name: "", lang: "ja" };
  let newcomer: SessionUser = { id: "", email: "", name: "", lang: "ja" };
  let organizationId = "";
  let inviteLink = "";
  let founderProjectId = "";

  beforeAll(() => {
    ports = createFakePorts({ now: () => NOW, seeded: false });
    loginLimiter = createMemoryRateLimiter(LOGIN_LIMIT);
    loginIpLimiter = createMemoryRateLimiter(LOGIN_IP_LIMIT);
    inviteLimiter = createMemoryRateLimiter(INVITE_LIMIT);
    inviteAcceptLimiter = createMemoryRateLimiter(INVITE_ACCEPT_LIMIT);
  });

  async function ctxFor(user: SessionUser): Promise<Ctx> {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(`ctx を作れませんでした: ${built.code}`);
    return built.value;
  }

  async function signedInUser(): Promise<SessionUser> {
    const user = await ports.auth.getUser();
    if (user === null) throw new Error("ログインしている方がいません");
    return user;
  }

  it("1. ご登録の直後は、まだ組織が無いので /onboarding へ", async () => {
    const signedUp = await signUpFlow({
      ports,
      raw: { email: "owner@example.com", password: "starter-pass" },
      siteOrigin: ORIGIN,
      limiter: loginLimiter,
      ipLimiter: loginIpLimiter,
      ip: "198.51.100.10",
      now: NOW,
    });
    expect(signedUp).toEqual({ ok: true, value: { sent: true } });

    founder = await signedInUser();
    const profile = await ensureProfileFlow({ ports, user: founder, now: NOW });
    expect(profile.ok).toBe(true);

    const landing = await landingPathFlow({ ports, user: founder });
    expect(landing).toEqual({
      ok: true,
      value: { path: ONBOARDING_PATH, organizationId: null },
    });
  });

  it("2. 組織をお作りになった方は owner になる", async () => {
    const created = await createOrganizationFlow({
      ctx: { ports, siteOrigin: ORIGIN, user: founder, lang: "ja", now: NOW },
      raw: { name: ORG_NAME },
    });
    expect(created.ok).toBe(true);
    if (!created.ok) return;
    organizationId = created.value.id;

    const ctx = await ctxFor(founder);
    expect(ctx.role).toBe("owner");
    expect(ctx.organization.name).toBe(ORG_NAME);
    expect(ctx.billing.planId).toBe("free");
  });

  it("3. 無料のプランでは上限まで作れて、その次は plan_limit", async () => {
    // 上限の数字は plans.config.ts から取ります（同梱の見本では 3 件です）
    for (let i = 0; i < FREE_LIMIT; i += 1) {
      const created = await createProjectFlow({
        ctx: await ctxFor(founder),
        raw: { name: `見本のプロジェクト ${i + 1}`, note: "" },
      });
      expect(created.ok, `${i + 1} 件目`).toBe(true);
      if (created.ok && i === 0) founderProjectId = created.value.id;
    }

    const over = await createProjectFlow({
      ctx: await ctxFor(founder),
      raw: { name: "上限の次のプロジェクト", note: "" },
    });
    expect(over).toEqual({ ok: false, code: "plan_limit" });
  });

  it("4. スタンダードのご契約が入ると、無料の上限の次を作れる", async () => {
    // 本物では Checkout に進むときに Stripe のお客さまが作られ、この対応の行が入ります
    await ports.data.setStripeCustomer(organizationId, CUSTOMER);

    const applied = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_checkout_completed",
        eventType: "checkout.session.completed",
        change: {
          stripeCustomerId: CUSTOMER,
          row: {
            planId: "standard",
            status: "active",
            stripeSubscriptionId: "sub_demo_1",
            currentPeriodEnd: "2026-10-20T00:00:00.000Z",
            cancelAtPeriodEnd: false,
            updatedAt: NOW.toISOString(),
          },
        },
      }),
      signature: "fake",
      now: NOW,
    });
    expect(applied).toEqual({
      ok: true,
      value: { eventId: "evt_checkout_completed", applied: true },
    });

    const ctx = await ctxFor(founder);
    expect(ctx.billing.planId).toBe("standard");
    expect(ctx.billing.entitled).toBe(true);

    const next = await createProjectFlow({
      ctx,
      raw: { name: "上限の次のプロジェクト", note: "" },
    });
    expect(next.ok).toBe(true);
  });

  it("5. メンバーとしてお招きすると、1 回きりのリンクができる", async () => {
    const invited = await createInvitationFlow({
      ctx: await ctxFor(founder),
      raw: { email: "member@example.com", role: "member" },
      limiter: inviteLimiter,
      messages,
    });
    expect(invited.ok).toBe(true);
    if (!invited.ok) return;

    inviteLink = invited.value.url;
    expect(inviteLink.startsWith(`${ORIGIN}/invite/`)).toBe(true);
    expect(invited.value.mailed).toBe(true);
  });

  it("6. お招きした方は、ご自身でログインしてから member として参加できる", async () => {
    const signedUp = await signUpFlow({
      ports,
      raw: { email: "member@example.com", password: "starter-pass" },
      siteOrigin: ORIGIN,
      limiter: loginLimiter,
      ipLimiter: loginIpLimiter,
      ip: "198.51.100.20",
      now: NOW,
    });
    expect(signedUp).toEqual({ ok: true, value: { sent: true } });

    newcomer = await signedInUser();
    await ensureProfileFlow({ ports, user: newcomer, now: NOW });

    const token = inviteLink.slice(`${ORIGIN}/invite/`.length);
    const accepted = await acceptInvitationFlow({
      ports,
      user: newcomer,
      token,
      limiter: inviteAcceptLimiter,
      ip: "198.51.100.20",
      now: NOW,
    });
    expect(accepted).toEqual({ ok: true, value: { organizationId, role: "member" } });

    const ctx = await ctxFor(newcomer);
    expect(ctx.role).toBe("member");
  });

  it("7. member は、他の方のプロジェクトを消せない", async () => {
    const denied = await deleteProjectFlow({
      ctx: await ctxFor(newcomer),
      raw: { projectId: founderProjectId },
    });
    expect(denied).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.projects.has(founderProjectId)).toBe(true);
  });

  it("8. member は、お支払いのお手続きに進めない", async () => {
    const denied = await startCheckoutFlow({
      ctx: await ctxFor(newcomer),
      raw: { planId: "business" },
    });
    expect(denied).toEqual({ ok: false, code: "forbidden" });
  });

  it("9. ご解約のあとは、無料のプランに戻って帯が出る", async () => {
    const applied = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_subscription_deleted",
        eventType: "customer.subscription.deleted",
        change: { stripeCustomerId: CUSTOMER, row: null },
      }),
      signature: "fake",
      now: NOW,
    });
    expect(applied).toEqual({
      ok: true,
      value: { eventId: "evt_subscription_deleted", applied: true },
    });

    const overview = await billingOverviewFlow({ ctx: await ctxFor(founder) });
    expect(overview.ok).toBe(true);
    if (!overview.ok) return;
    expect(overview.value.state.planId).toBe("free");
    expect(overview.value.state.banner).toBe("canceled");
    expect(overview.value.canManage).toBe(true);

    // すでにお作りいただいた分（無料の上限 + 1 件）は残ります（新しく作るときだけ上限でお止めします）
    expect(overview.value.quota.used).toBe(FREE_LIMIT + 1);
    expect(overview.value.quota.atLimit).toBe(true);
  });

  it("10. owner が組織を消すと、一覧には何も残らない", async () => {
    const deleted = await deleteOrganizationFlow({
      ctx: await ctxFor(founder),
      raw: { confirmName: ORG_NAME },
    });
    expect(deleted).toEqual({ ok: true, value: { deleted: true } });

    const mine = await listOrganizationsFlow({ ports, user: founder });
    expect(mine.ok).toBe(true);
    if (!mine.ok) return;
    expect(mine.value).toHaveLength(0);

    const theirs = await listOrganizationsFlow({ ports, user: newcomer });
    expect(theirs.ok && theirs.value).toHaveLength(0);
  });
});
