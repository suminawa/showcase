import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import type { AuthErrorCode, AuthPort, Ports, SessionUser } from "../../src/ports";
import type { UserCtx } from "../../src/server/context";
import {
  ensureProfileFlow,
  googleSignInFlow,
  landingPathFlow,
  magicLinkFlow,
  myProfileFlow,
  signInPasswordFlow,
  signUpFlow,
  updateProfileFlow,
} from "../../src/server/flows/auth";
import {
  LOGIN_IP_LIMIT,
  LOGIN_LIMIT,
  createMemoryRateLimiter,
  type RateLimiter,
} from "../../src/server/ratelimit";
import { DEFAULT_NEXT_PATH, authCallbackUrl, isSafeNextPath } from "../../src/server/urls";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";
const IP = "203.0.113.10";

/** まだプロフィールを作っていない、登録したての方 */
const NEWCOMER: SessionUser = { id: "u-newcomer", email: "newcomer@example.com", name: "", lang: "ja" };

/** ご登録の口だけを差し替えて、決めた符号を返させます（外の様子を作るために使います） */
function portsWithSignUpCode(base: Ports, code: AuthErrorCode): Ports {
  const auth: AuthPort = {
    getUser: () => base.auth.getUser(),
    sendMagicLink: (email, redirectTo) => base.auth.sendMagicLink(email, redirectTo),
    signInWithPassword: (email, password) => base.auth.signInWithPassword(email, password),
    async signUpWithPassword() {
      return { ok: false, code };
    },
    signOut: () => base.auth.signOut(),
    oauthStartUrl: (provider, redirectTo) => base.auth.oauthStartUrl(provider, redirectTo),
    completeSignIn: (input) => base.auth.completeSignIn(input),
  };
  return { ...base, auth };
}

/** Google の入り口だけを差し替えて、決めた URL を返させます */
function portsWithOauthUrl(base: Ports, url: string | null): Ports & { asked: string[] } {
  const asked: string[] = [];
  const auth: AuthPort = {
    getUser: () => base.auth.getUser(),
    sendMagicLink: (email, redirectTo) => base.auth.sendMagicLink(email, redirectTo),
    signInWithPassword: (email, password) => base.auth.signInWithPassword(email, password),
    signUpWithPassword: (email, password, redirectTo) =>
      base.auth.signUpWithPassword(email, password, redirectTo),
    signOut: () => base.auth.signOut(),
    async oauthStartUrl(_provider, redirectTo) {
      asked.push(redirectTo);
      return url;
    },
    completeSignIn: (input) => base.auth.completeSignIn(input),
  };
  return { ...base, auth, asked };
}

/** 数えた鍵を覚えるだけで、いつでも通す入れ物（鍵の形を確かめるために使います） */
function recordingLimiter(keys: string[]): RateLimiter {
  return {
    async hit(key: string): Promise<{ allowed: boolean; retryAfterSeconds: number }> {
      keys.push(key);
      return { allowed: true, retryAfterSeconds: 0 };
    },
  };
}

describe("登録・ログイン・プロフィールの流れ", () => {
  let ports: Ports & { store: FakeStore };
  let limiter: RateLimiter;
  let ipLimiter: RateLimiter;

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
    limiter = createMemoryRateLimiter(LOGIN_LIMIT);
    ipLimiter = createMemoryRateLimiter(LOGIN_IP_LIMIT);
  });

  it("signUpFlow は形の悪いメールアドレスを invalid で返す", async () => {
    const result = await signUpFlow({
      ports,
      raw: { email: "newcomer(at)example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "email", code: "bad_email" }],
    });
  });

  it("signUpFlow は正しい入力で sent: true を返す", async () => {
    const result = await signUpFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: true, value: { sent: true } });
  });

  it("signUpFlow は、すでにご登録のメールアドレスでも同じお返事をする（登録の有無をお伝えしない）", async () => {
    const first = await signUpFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(first).toEqual({ ok: true, value: { sent: true } });

    const again = await signUpFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "another-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    // 1 回目とまったく同じお返事です（email_taken をお返しすると、ご登録の有無が分かってしまいます）
    expect(again).toEqual({ ok: true, value: { sent: true } });

    // 2 回目で上書きされていないこと（1 回目の合言葉のままです）
    expect(ports.store.authUsers.size).toBe(1);
    expect(ports.store.authUsers.get("newcomer@example.com")?.password).toBe("starter-password");
  });

  it("signUpFlow は、混み合っているときと一時的にお使いいただけないときは、その符号をお返しする", async () => {
    // ご登録の有無とは関わりのない符号なので、飲み込まずにお伝えします
    // （画面に「しばらくしてからお試しください」をお出しするためです）。
    const busy = await signUpFlow({
      ports: portsWithSignUpCode(ports, "rate_limited"),
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(busy).toEqual({ ok: false, code: "rate_limited" });

    const down = await signUpFlow({
      ports: portsWithSignUpCode(ports, "unavailable"),
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(down).toEqual({ ok: false, code: "unavailable" });

    // ご登録済みかどうかだけは、最後までお伝えしません
    const taken = await signUpFlow({
      ports: portsWithSignUpCode(ports, "email_taken"),
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(taken).toEqual({ ok: true, value: { sent: true } });
  });

  it("2 本目の窓は IP だけで数え、その鍵にメールアドレスを含めない", async () => {
    const emailKeys: string[] = [];
    const ipKeys: string[] = [];

    await signUpFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter: recordingLimiter(emailKeys),
      ipLimiter: recordingLimiter(ipKeys),
      ip: IP,
      now: NOW,
    });

    expect(ipKeys).toEqual([`login-ip:${IP}`]);
    expect(ipKeys[0]).not.toContain("newcomer@example.com");
    expect(emailKeys).toEqual([`login:${IP}:newcomer@example.com`]);
  });

  it("IP の窓が尽きると、同じ IP からは別のメールアドレスでも rate_limited になる", async () => {
    const smallIpLimiter = createMemoryRateLimiter({ limit: 2, windowSeconds: 600 });

    const first = await signUpFlow({
      ports,
      raw: { email: "one@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter: smallIpLimiter,
      ip: IP,
      now: NOW,
    });
    expect(first.ok).toBe(true);

    const second = await magicLinkFlow({
      ports,
      raw: { email: "two@example.com" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter: smallIpLimiter,
      ip: IP,
      now: NOW,
    });
    expect(second.ok).toBe(true);

    const third = await signInPasswordFlow({
      ports,
      raw: { email: "three@example.com", password: "starter-password" },
      limiter,
      ipLimiter: smallIpLimiter,
      ip: IP,
      now: NOW,
    });
    expect(third).toEqual({ ok: false, code: "rate_limited" });

    // 別の IP からは通ります
    const elsewhere = await magicLinkFlow({
      ports,
      raw: { email: "three@example.com" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter: smallIpLimiter,
      ip: "203.0.113.20",
      now: NOW,
    });
    expect(elsewhere.ok).toBe(true);
  });

  it("magicLinkFlow は正しい入力で sent: true を返し、送信の履歴が 1 件積まれる", async () => {
    const result = await magicLinkFlow({
      ports,
      raw: { email: " Owner@Example.com " },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: true, value: { sent: true } });
    expect(ports.store.magicLinks).toHaveLength(1);
    expect(ports.store.magicLinks[0]?.email).toBe("owner@example.com");
    expect(ports.store.magicLinks[0]?.redirectTo).toBe("http://localhost:3020/auth/callback");
  });

  it("同じ IP とメールアドレスでは 10 回目まで通り、11 回目に rate_limited になる", async () => {
    for (let i = 0; i < LOGIN_LIMIT.limit; i += 1) {
      const result = await magicLinkFlow({
        ports,
        raw: { email: "owner@example.com" },
        siteOrigin: ORIGIN,
        limiter,
        ipLimiter,
        ip: IP,
        now: NOW,
      });
      expect(result.ok, `${i + 1} 回目`).toBe(true);
    }

    const over = await magicLinkFlow({
      ports,
      raw: { email: "owner@example.com" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(over).toEqual({ ok: false, code: "rate_limited" });

    // 鍵はメールアドレスごとなので、同じ IP でも別のメールアドレスは通ります
    const other = await magicLinkFlow({
      ports,
      raw: { email: "admin@example.com" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(other.ok).toBe(true);
  });

  it("signInPasswordFlow は合言葉が違えば bad_credentials、合っていれば userId を返す", async () => {
    await signUpFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "starter-password" },
      siteOrigin: ORIGIN,
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });

    const wrong = await signInPasswordFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "another-password" },
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(wrong).toEqual({ ok: false, code: "bad_credentials" });

    const right = await signInPasswordFlow({
      ports,
      raw: { email: "newcomer@example.com", password: "starter-password" },
      limiter,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(right.ok).toBe(true);
    if (right.ok) expect(right.value.userId).not.toBe("");
  });

  it("ensureProfileFlow は 2 回呼んでもプロフィールが 1 行のまま", async () => {
    const before = ports.store.profiles.size;

    const first = await ensureProfileFlow({ ports, user: NEWCOMER, now: NOW });
    const second = await ensureProfileFlow({ ports, user: NEWCOMER, now: NOW });

    expect(first.ok).toBe(true);
    expect(second.ok).toBe(true);
    expect(ports.store.profiles.size).toBe(before + 1);
    if (first.ok) expect(first.value.email).toBe("newcomer@example.com");
  });

  it("ensureProfileFlow はメールアドレスを小文字にそろえて保存する", async () => {
    const shouting: SessionUser = {
      id: "u-shouting",
      email: " Newcomer@Example.com ",
      name: "",
      lang: "ja",
    };

    const created = await ensureProfileFlow({ ports, user: shouting, now: NOW });
    expect(created.ok).toBe(true);
    expect(ports.store.profiles.get("u-shouting")?.email).toBe("newcomer@example.com");
    // 仮のお名前も、そろえたあとのメールアドレスから作ります
    expect(ports.store.profiles.get("u-shouting")?.name).toBe("newcomer");
  });

  it("ensureProfileFlow は形の悪いメールアドレスを invalid で返し、行を作らない", async () => {
    const broken: SessionUser = { id: "u-broken", email: "newcomer(at)example.com", name: "", lang: "ja" };

    const result = await ensureProfileFlow({ ports, user: broken, now: NOW });
    expect(result).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "email", code: "bad_email" }],
    });
    expect(ports.store.profiles.has("u-broken")).toBe(false);
  });

  it("landingPathFlow は組織の有無で行き先を分ける", async () => {
    const none = await landingPathFlow({ ports, user: NEWCOMER });
    expect(none).toEqual({ ok: true, value: { path: "/onboarding", organizationId: null } });

    const owner: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
    const one = await landingPathFlow({ ports, user: owner });
    expect(one).toEqual({ ok: true, value: { path: "/app", organizationId: "org-1" } });

    const admin: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
    const two = await landingPathFlow({ ports, user: admin });
    expect(two).toEqual({ ok: true, value: { path: "/app", organizationId: "org-1" } });
  });

  it("回数の窓が明ければまた通り、覚える鍵の数には上限がある", async () => {
    const small = createMemoryRateLimiter({ limit: 1, windowSeconds: 60, max: 1 });

    expect(await small.hit("login:1", NOW)).toEqual({ allowed: true, retryAfterSeconds: 0 });
    expect(await small.hit("login:1", NOW)).toEqual({ allowed: false, retryAfterSeconds: 60 });

    // 別の鍵を数えると、上限 1 件なので古い鍵は捨てられます
    expect(await small.hit("login:2", NOW)).toEqual({ allowed: true, retryAfterSeconds: 0 });
    expect(await small.hit("login:1", NOW)).toEqual({ allowed: true, retryAfterSeconds: 0 });

    // 窓が明ければ、同じ鍵でもまた通ります
    const later = new Date(NOW.getTime() + 60_000);
    expect(await small.hit("login:1", NOW)).toEqual({ allowed: false, retryAfterSeconds: 60 });
    expect(await small.hit("login:1", later)).toEqual({ allowed: true, retryAfterSeconds: 0 });
  });

  it("myProfileFlow はいまの方の行を返し、まだ無い方には not_found を返す", async () => {
    const user: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
    const ctx: UserCtx = { ports, siteOrigin: ORIGIN, user, lang: "ja", now: NOW };

    const mine = await myProfileFlow({ ctx });
    expect(mine.ok && mine.value.email).toBe("owner@example.com");

    const stranger = await myProfileFlow({ ctx: { ...ctx, user: NEWCOMER } });
    expect(stranger).toEqual({ ok: false, code: "not_found" });
  });

  it("updateProfileFlow は知らない言語を bad_choice で弾き、正しい入力では保存する", async () => {
    const user: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
    const ctx: UserCtx = { ports, siteOrigin: ORIGIN, user, lang: "ja", now: NOW };

    const bad = await updateProfileFlow({ ctx, raw: { name: "みなと 太郎", lang: "fr" } });
    expect(bad).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "lang", code: "bad_choice" }],
    });

    const good = await updateProfileFlow({ ctx, raw: { name: "みなと 太郎", lang: "en" } });
    expect(good.ok).toBe(true);
    expect(ports.store.profiles.get("u-owner")?.lang).toBe("en");
  });

  it("googleSignInFlow は、ログインと同じ IP の窓で数える", async () => {
    const keys: string[] = [];
    const withUrl = portsWithOauthUrl(ports, "https://auth.example.com/authorize?code_challenge=x");

    const result = await googleSignInFlow({
      ports: withUrl,
      siteOrigin: ORIGIN,
      next: "/app/projects",
      ipLimiter: recordingLimiter(keys),
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({
      ok: true,
      value: { url: "https://auth.example.com/authorize?code_challenge=x" },
    });

    // メールアドレスを頂戴しないので、窓は IP の 1 本だけです
    expect(keys).toEqual([`login-ip:${IP}`]);
    // お戻り先は、依存の束の土台からだけ組みます
    expect(withUrl.asked).toEqual([authCallbackUrl(ORIGIN, "/app/projects")]);
  });

  it("googleSignInFlow は、窓が尽きたら入り口を作らずに止める", async () => {
    const small = createMemoryRateLimiter({ limit: 1, windowSeconds: 600 });
    const withUrl = portsWithOauthUrl(ports, "https://auth.example.com/authorize");

    const input = {
      ports: withUrl,
      siteOrigin: ORIGIN,
      next: null,
      ipLimiter: small,
      ip: IP,
      now: NOW,
    };
    expect((await googleSignInFlow(input)).ok).toBe(true);

    const second = await googleSignInFlow(input);
    expect(second).toEqual({ ok: false, code: "rate_limited" });
    // 2 回目は、認証の口までたどり着いていません
    expect(withUrl.asked).toHaveLength(1);
  });

  it("googleSignInFlow は、入り口をお出しできないときに unavailable", async () => {
    const result = await googleSignInFlow({
      ports: portsWithOauthUrl(ports, null),
      siteOrigin: ORIGIN,
      next: null,
      ipLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: false, code: "unavailable" });
  });
});

describe("ログインしたあとの戻り先", () => {
  it("行き先をお伝えしないときは、そのまま受け口の URL を返す", () => {
    expect(authCallbackUrl(ORIGIN)).toBe("http://localhost:3020/auth/callback");
    expect(authCallbackUrl(`${ORIGIN}/`, "")).toBe("http://localhost:3020/auth/callback");
  });

  it("同じサイトの中の行き先は、そのままお渡しする", () => {
    expect(authCallbackUrl(ORIGIN, "/app/projects")).toBe(
      "http://localhost:3020/auth/callback?next=%2Fapp%2Fprojects",
    );
    expect(authCallbackUrl(ORIGIN, "/app?tab=members")).toBe(
      "http://localhost:3020/auth/callback?next=%2Fapp%3Ftab%3Dmembers",
    );
  });

  it("外のサイトへ行く形の行き先は、既定の行き先に落とす", () => {
    const fallback = `http://localhost:3020/auth/callback?next=${encodeURIComponent(DEFAULT_NEXT_PATH)}`;
    const outside = [
      "https://example.net/steal",
      "//example.net/steal",
      "/\\example.net/steal",
      "http:/example.net",
      "javascript:alert(1)",
      "app/projects",
      "/app\nX",
      "/app\u0000X",
    ];
    for (const next of outside) {
      expect(authCallbackUrl(ORIGIN, next), next).toBe(fallback);
    }
  });

  it("isSafeNextPath は、同じサイトの中の相対パスだけを通す", () => {
    expect(isSafeNextPath("/app")).toBe(true);
    expect(isSafeNextPath("/app/settings/billing?checkout=done")).toBe(true);
    expect(isSafeNextPath("/")).toBe(true);

    expect(isSafeNextPath("//example.net")).toBe(false);
    expect(isSafeNextPath("/\\example.net")).toBe(false);
    expect(isSafeNextPath("https://example.net")).toBe(false);
    expect(isSafeNextPath("")).toBe(false);
    expect(isSafeNextPath("app")).toBe(false);
  });
});
