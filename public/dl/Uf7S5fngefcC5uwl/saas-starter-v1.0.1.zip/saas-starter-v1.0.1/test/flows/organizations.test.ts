import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import { hasOpenSubscription, STRIPE_STATUSES } from "../../src/core/billing-state";
import type { Ports, SessionUser } from "../../src/ports";
import { buildCtx, type Ctx, type UserCtx } from "../../src/server/context";
import {
  MAX_ORGS_PER_USER,
  createOrganizationFlow,
  deleteOrganizationFlow,
  listOrganizationsFlow,
  renameOrganizationFlow,
  switchOrganizationFlow,
} from "../../src/server/flows/organizations";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };
const NEWCOMER: SessionUser = { id: "u-newcomer", email: "newcomer@example.com", name: "", lang: "ja" };

describe("組織の流れ", () => {
  let ports: Ports & { store: FakeStore };

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
  });

  async function ctxFor(user: SessionUser, organizationId: string): Promise<Ctx> {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(`ctx を作れませんでした: ${built.code}`);
    return built.value;
  }

  function userCtxFor(user: SessionUser): UserCtx {
    return { ports, siteOrigin: ORIGIN, user, lang: "ja", now: NOW };
  }

  it("buildCtx は一員でない組織に not_found を返す", async () => {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user: OWNER, organizationId: "org-2", lang: "ja", now: NOW });
    expect(built).toEqual({ ok: false, code: "not_found" });

    const unknown = await buildCtx({ ports, siteOrigin: ORIGIN, user: OWNER, organizationId: "org-9", lang: "ja", now: NOW });
    expect(unknown).toEqual({ ok: false, code: "not_found" });
  });

  it("buildCtx は役割と契約の状態をそろえて返す", async () => {
    const ctx = await ctxFor(ADMIN, "org-1");
    expect(ctx.role).toBe("admin");
    expect(ctx.organization.name).toBe("しおさい設計室");
    // 契約の行がまだ無い組織は、無料プランで機能をお使いいただけます
    expect(ctx.billing.planId).toBe("free");
    expect(ctx.billing.entitled).toBe(true);
  });

  it("createOrganizationFlow は作った方を owner にする", async () => {
    const created = await createOrganizationFlow({
      ctx: userCtxFor(NEWCOMER),
      raw: { name: "はまべ商店" },
    });
    expect(created.ok).toBe(true);
    if (!created.ok) return;

    const membership = await ports.data.getMembership(created.value.id, NEWCOMER.id);
    expect(membership?.role).toBe("owner");
    expect(created.value.name).toBe("はまべ商店");
  });

  it("createOrganizationFlow は空の名前を required、61 文字を too_long で弾く", async () => {
    const empty = await createOrganizationFlow({ ctx: userCtxFor(NEWCOMER), raw: { name: "   " } });
    expect(empty).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "name", code: "required" }],
    });

    const long = await createOrganizationFlow({
      ctx: userCtxFor(NEWCOMER),
      raw: { name: "あ".repeat(61) },
    });
    expect(long).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "name", code: "too_long" }],
    });
  });

  it("createOrganizationFlow は全角の空白だけのお名前を required、制御文字は取り除く", async () => {
    const wide = await createOrganizationFlow({
      ctx: userCtxFor(NEWCOMER),
      raw: { name: "　　" },
    });
    expect(wide).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "name", code: "required" }],
    });

    const created = await createOrganizationFlow({
      ctx: userCtxFor(NEWCOMER),
      raw: { name: "　はまべ商店\u0007　" },
    });
    expect(created.ok).toBe(true);
    if (!created.ok) return;
    expect(created.value.name).toBe("はまべ商店");
  });

  it("createOrganizationFlow は 11 個目を forbidden で止める", async () => {
    for (let i = 0; i < MAX_ORGS_PER_USER; i += 1) {
      const result = await createOrganizationFlow({
        ctx: userCtxFor(NEWCOMER),
        raw: { name: `見本の組織 ${i + 1}` },
      });
      expect(result.ok, `${i + 1} 個目`).toBe(true);
    }

    const over = await createOrganizationFlow({
      ctx: userCtxFor(NEWCOMER),
      raw: { name: "見本の組織 11" },
    });
    expect(over).toEqual({ ok: false, code: "forbidden" });
  });

  it("上限の 1 つ手前で 2 つ同時にお作りになっても、片方だけが通る", async () => {
    for (let i = 0; i < MAX_ORGS_PER_USER - 1; i += 1) {
      const result = await createOrganizationFlow({
        ctx: userCtxFor(NEWCOMER),
        raw: { name: `見本の組織 ${i + 1}` },
      });
      expect(result.ok, `${i + 1} 個目`).toBe(true);
    }

    const [first, second] = await Promise.all([
      createOrganizationFlow({ ctx: userCtxFor(NEWCOMER), raw: { name: "同時の組織 A" } }),
      createOrganizationFlow({ ctx: userCtxFor(NEWCOMER), raw: { name: "同時の組織 B" } }),
    ]);

    const results = [first, second];
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.code === "forbidden")).toHaveLength(1);

    const mine = await ports.data.listOrganizationsForUser(NEWCOMER.id);
    expect(mine).toHaveLength(MAX_ORGS_PER_USER);
  });

  it("renameOrganizationFlow は member に forbidden、admin には通る", async () => {
    const byMember = await renameOrganizationFlow({
      ctx: await ctxFor(MEMBER, "org-1"),
      raw: { name: "あたらしい名前" },
    });
    expect(byMember).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.organizations.get("org-1")?.name).toBe("しおさい設計室");

    const byAdmin = await renameOrganizationFlow({
      ctx: await ctxFor(ADMIN, "org-1"),
      raw: { name: "しおさい設計室（改）" },
    });
    expect(byAdmin.ok).toBe(true);
    expect(ports.store.organizations.get("org-1")?.name).toBe("しおさい設計室（改）");
  });

  it("deleteOrganizationFlow は確認の名前が違えば invalid、合っていれば消す", async () => {
    const wrong = await deleteOrganizationFlow({
      ctx: await ctxFor(OWNER, "org-1"),
      raw: { confirmName: "しおさい設計" },
    });
    expect(wrong).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "confirmName", code: "bad_choice" }],
    });
    expect(ports.store.organizations.has("org-1")).toBe(true);

    const right = await deleteOrganizationFlow({
      ctx: await ctxFor(OWNER, "org-1"),
      raw: { confirmName: "しおさい設計室" },
    });
    expect(right).toEqual({ ok: true, value: { deleted: true } });
    expect(ports.store.organizations.has("org-1")).toBe(false);
  });

  it("deleteOrganizationFlow はご契約の実体が残っているあいだ has_subscription で止める", async () => {
    // はじめのお支払いの確認待ち（incomplete）・一時停止中（paused）・
    // お支払いが滞っている（unpaid）も、決済のしくみの側にはご契約が残っています。
    // ここで消してしまうと、こちらには行が残らないのにお支払いだけが続きます。
    for (const status of STRIPE_STATUSES.filter((one) => hasOpenSubscription(one))) {
      await ports.data.upsertSubscription({
        organizationId: "org-1",
        planId: "standard",
        status,
        stripeSubscriptionId: "sub_1",
        currentPeriodEnd: "2026-10-20T00:00:00.000Z",
        cancelAtPeriodEnd: false,
        updatedAt: NOW.toISOString(),
      });

      const stopped = await deleteOrganizationFlow({
        ctx: await ctxFor(OWNER, "org-1"),
        raw: { confirmName: "しおさい設計室" },
      });
      expect(stopped, status).toEqual({ ok: false, code: "has_subscription" });
      expect(ports.store.organizations.has("org-1")).toBe(true);
    }
  });

  it("deleteOrganizationFlow はご解約のあとなら消せる", async () => {
    // 8 つの状態のうち、実体の残らない 2 つ（ご解約・お申し込みの期限切れ）です
    expect(STRIPE_STATUSES.filter((one) => !hasOpenSubscription(one))).toEqual([
      "canceled",
      "incomplete_expired",
    ]);

    for (const status of ["canceled", "incomplete_expired"] as const) {
      // 前の周回で消えているので、組織を作り直します
      if (!ports.store.organizations.has("org-1")) {
        ports.store.organizations.set("org-1", {
          id: "org-1",
          name: "しおさい設計室",
          createdAt: NOW.toISOString(),
        });
        ports.store.memberships.set(ports.store.membershipKey("org-1", OWNER.id), {
          organizationId: "org-1",
          userId: OWNER.id,
          role: "owner",
          createdAt: NOW.toISOString(),
        });
      }

      await ports.data.upsertSubscription({
        organizationId: "org-1",
        planId: "free",
        status,
        stripeSubscriptionId: "sub_1",
        currentPeriodEnd: "2026-10-20T00:00:00.000Z",
        cancelAtPeriodEnd: false,
        updatedAt: NOW.toISOString(),
      });

      const deleted = await deleteOrganizationFlow({
        ctx: await ctxFor(OWNER, "org-1"),
        raw: { confirmName: "しおさい設計室" },
      });
      expect(deleted, status).toEqual({ ok: true, value: { deleted: true } });
      expect(ports.store.organizations.has("org-1"), status).toBe(false);
    }
  });

  it("deleteOrganizationFlow は admin に forbidden", async () => {
    const byAdmin = await deleteOrganizationFlow({
      ctx: await ctxFor(ADMIN, "org-1"),
      raw: { confirmName: "しおさい設計室" },
    });
    expect(byAdmin).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.organizations.has("org-1")).toBe(true);
  });

  it("switchOrganizationFlow は一員でない組織に not_found を返す", async () => {
    const outside = await switchOrganizationFlow({
      ports,
      user: OWNER,
      raw: { organizationId: "org-2" },
    });
    expect(outside).toEqual({ ok: false, code: "not_found" });

    const inside = await switchOrganizationFlow({
      ports,
      user: OWNER,
      raw: { organizationId: "org-1" },
    });
    expect(inside).toEqual({ ok: true, value: { organizationId: "org-1" } });
  });

  it("listOrganizationsFlow は役割つきで、その方の組織だけを返す", async () => {
    const result = await listOrganizationsFlow({ ports, user: ADMIN });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.value.map((row) => [row.organization.id, row.role])).toEqual([
      ["org-1", "admin"],
      ["org-2", "owner"],
    ]);
  });
});
