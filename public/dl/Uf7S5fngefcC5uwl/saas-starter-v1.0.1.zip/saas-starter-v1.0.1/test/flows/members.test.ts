import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import type { Ports, SessionUser } from "../../src/ports";
import { buildCtx, type Ctx } from "../../src/server/context";
import {
  leaveOrganizationFlow,
  listMembersFlow,
  removeMemberFlow,
  setMemberRoleFlow,
} from "../../src/server/flows/members";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };

describe("メンバーの流れ", () => {
  let ports: Ports & { store: FakeStore };

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
  });

  async function ctxFor(user: SessionUser, organizationId = "org-1"): Promise<Ctx> {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(`ctx を作れませんでした: ${built.code}`);
    return built.value;
  }

  it("listMembersFlow は 3 人を古い順で返す", async () => {
    const result = await listMembersFlow({ ctx: await ctxFor(OWNER) });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.value.map((m) => m.userId)).toEqual(["u-owner", "u-admin", "u-member"]);
  });

  it("admin は owner の役割を変えられない（cannot_touch_owner）", async () => {
    const result = await setMemberRoleFlow({
      ctx: await ctxFor(ADMIN),
      raw: { userId: "u-owner", role: "admin" },
    });
    expect(result).toEqual({ ok: false, code: "cannot_touch_owner" });
    expect(ports.store.memberships.get("org-1:u-owner")?.role).toBe("owner");
  });

  it("admin は誰かを owner に上げられない（cannot_promote_to_owner）", async () => {
    const result = await setMemberRoleFlow({
      ctx: await ctxFor(ADMIN),
      raw: { userId: "u-member", role: "owner" },
    });
    expect(result).toEqual({ ok: false, code: "cannot_promote_to_owner" });
    expect(ports.store.memberships.get("org-1:u-member")?.role).toBe("member");
  });

  it("唯一の owner は自分を admin に降ろせない（last_owner）", async () => {
    const result = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-owner", role: "admin" },
    });
    expect(result).toEqual({ ok: false, code: "last_owner" });
    expect(ports.store.memberships.get("org-1:u-owner")?.role).toBe("owner");
  });

  it("2 人目の owner を足したあとなら、owner は自分を降ろせる", async () => {
    const promoted = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-admin", role: "owner" },
    });
    expect(promoted).toEqual({ ok: true, value: { userId: "u-admin", role: "owner" } });

    const demoted = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-owner", role: "admin" },
    });
    expect(demoted).toEqual({ ok: true, value: { userId: "u-owner", role: "admin" } });
    expect(ports.store.memberships.get("org-1:u-owner")?.role).toBe("admin");
  });

  it("member は誰の役割も変えられない（forbidden）", async () => {
    const result = await setMemberRoleFlow({
      ctx: await ctxFor(MEMBER),
      raw: { userId: "u-admin", role: "member" },
    });
    expect(result).toEqual({ ok: false, code: "forbidden" });
  });

  it("同じ役割への変更は no_change", async () => {
    const result = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-admin", role: "admin" },
    });
    expect(result).toEqual({ ok: false, code: "no_change" });
  });

  it("admin は owner を外せない（cannot_touch_owner）", async () => {
    const result = await removeMemberFlow({
      ctx: await ctxFor(ADMIN),
      raw: { userId: "u-owner" },
    });
    expect(result).toEqual({ ok: false, code: "cannot_touch_owner" });
    expect(ports.store.memberships.has("org-1:u-owner")).toBe(true);

    // 管理者やメンバーであれば外せます
    const removed = await removeMemberFlow({
      ctx: await ctxFor(ADMIN),
      raw: { userId: "u-member" },
    });
    expect(removed).toEqual({ ok: true, value: { userId: "u-member" } });
  });

  it("全角の空白や制御文字が混じった userId も、そろえてから扱う", async () => {
    const result = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "　u-member\u0007　", role: "　admin　" },
    });
    expect(result).toEqual({ ok: true, value: { userId: "u-member", role: "admin" } });
    expect(ports.store.memberships.get("org-1:u-member")?.role).toBe("admin");
  });

  it("removeMemberFlow は組織にいない方に not_found、いる方は外せる", async () => {
    const missing = await removeMemberFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-nobody" },
    });
    expect(missing).toEqual({ ok: false, code: "not_found" });

    const removed = await removeMemberFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-member" },
    });
    expect(removed).toEqual({ ok: true, value: { userId: "u-member" } });
    expect(ports.store.memberships.has("org-1:u-member")).toBe(false);
  });

  it("2 人の owner を同時に降ろしても、片方だけが通る", async () => {
    const promoted = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-admin", role: "owner" },
    });
    expect(promoted.ok).toBe(true);

    // ここまでで owner は 2 人です。2 つのお申し付けが同時に届いた場面を作ります
    const ctxOwner = await ctxFor(OWNER);
    const ctxSecondOwner = await ctxFor(ADMIN);
    const [first, second] = await Promise.all([
      setMemberRoleFlow({ ctx: ctxOwner, raw: { userId: "u-owner", role: "admin" } }),
      setMemberRoleFlow({ ctx: ctxSecondOwner, raw: { userId: "u-admin", role: "admin" } }),
    ]);

    const results = [first, second];
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.code === "last_owner")).toHaveLength(1);
    expect(await ports.data.countOwners("org-1")).toBe(1);
  });

  it("2 人の owner を同時に外しても、片方だけが通る", async () => {
    const promoted = await setMemberRoleFlow({
      ctx: await ctxFor(OWNER),
      raw: { userId: "u-admin", role: "owner" },
    });
    expect(promoted.ok).toBe(true);

    const ctxOwner = await ctxFor(OWNER);
    const ctxSecondOwner = await ctxFor(ADMIN);
    const [first, second] = await Promise.all([
      removeMemberFlow({ ctx: ctxOwner, raw: { userId: "u-admin" } }),
      removeMemberFlow({ ctx: ctxSecondOwner, raw: { userId: "u-owner" } }),
    ]);

    const results = [first, second];
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.code === "last_owner")).toHaveLength(1);
    expect(await ports.data.countOwners("org-1")).toBe(1);
  });

  it("leaveOrganizationFlow は member で通り、唯一の owner では last_owner", async () => {
    const byMember = await leaveOrganizationFlow({ ctx: await ctxFor(MEMBER) });
    expect(byMember).toEqual({ ok: true, value: { left: true } });
    expect(ports.store.memberships.has("org-1:u-member")).toBe(false);

    const byOwner = await leaveOrganizationFlow({ ctx: await ctxFor(OWNER) });
    expect(byOwner).toEqual({ ok: false, code: "last_owner" });
    expect(ports.store.memberships.has("org-1:u-owner")).toBe(true);
  });
});
