import { readFileSync } from "node:fs";
import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { Messages } from "../../src/core/i18n";
import { INVITE_TTL_DAYS } from "../../src/core/invitations";
import type { FakeStore } from "../../src/adapters/fake/store";
import type { InvitationRow, Ports, SessionUser } from "../../src/ports";
import { buildCtx, type Ctx } from "../../src/server/context";
import {
  acceptInvitationFlow,
  createInvitationFlow,
  inviteNoticeKey,
  listInvitationsFlow,
  revokeInvitationFlow,
} from "../../src/server/flows/invitations";
import type { MailFailureCode, MailPort } from "../../src/ports/mail";
import { MAX_ORGS_PER_USER } from "../../src/server/flows/organizations";
import {
  INVITE_ACCEPT_LIMIT,
  INVITE_LIMIT,
  createMemoryRateLimiter,
  type RateLimiter,
} from "../../src/server/ratelimit";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const EIGHT_DAYS_LATER = new Date("2026-09-28T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";
const IP = "203.0.113.10";

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };
const NEWCOMER: SessionUser = { id: "u-newcomer", email: "newcomer@example.com", name: "", lang: "ja" };

const messages = JSON.parse(
  readFileSync(new URL("../../messages/ja.json", import.meta.url), "utf8"),
) as Messages;

describe("招待の流れ", () => {
  let ports: Ports & { store: FakeStore };
  let limiter: RateLimiter;
  let acceptLimiter: RateLimiter;

  beforeEach(async () => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
    limiter = createMemoryRateLimiter(INVITE_LIMIT);
    acceptLimiter = createMemoryRateLimiter(INVITE_ACCEPT_LIMIT);
    // ログインなさった方には、必ずプロフィールの行があります（ensureProfileFlow が作ります）。
    // ご招待の宛先の突き合わせは、本物も見本のしくみも、この行のメールアドレスを見ます。
    await ports.data.upsertProfile({
      id: NEWCOMER.id,
      email: NEWCOMER.email,
      name: NEWCOMER.name,
      lang: "ja",
    });
  });

  async function ctxFor(user: SessionUser, organizationId = "org-1"): Promise<Ctx> {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(`ctx を作れませんでした: ${built.code}`);
    return built.value;
  }

  async function invite(
    user: SessionUser,
    email: string,
    role = "member",
  ): Promise<{
    invitation: InvitationRow;
    url: string;
    mailed: boolean;
    mailCode: MailFailureCode | null;
  }> {
    const result = await createInvitationFlow({
      ctx: await ctxFor(user),
      raw: { email, role },
      limiter,
      messages,
    });
    if (!result.ok) throw new Error(`招待を作れませんでした: ${result.code}`);
    return result.value;
  }

  it("createInvitationFlow は 43 文字のトークンつきのリンクを返す", async () => {
    const { url, mailed } = await invite(OWNER, "newcomer@example.com");
    const prefix = `${ORIGIN}/invite/`;
    expect(url.startsWith(prefix)).toBe(true);
    expect(url.slice(prefix.length)).toHaveLength(43);
    expect(mailed).toBe(true);

    const mail = ports.store.mails[0];
    expect(ports.store.mails).toHaveLength(1);
    expect(mail?.to).toBe("newcomer@example.com");
    expect(mail?.subject).toContain("しおさい設計室");
    expect(mail?.text).toContain(url);
    expect(mail?.text).toContain(String(INVITE_TTL_DAYS));
    expect(mail?.text).toContain("みなと 太郎");
  });

  it("組織の名前に改行が入っていても、件名は 1 行のまま", async () => {
    // 件名が 2 行になると、そのあとの行が新しいヘッダ（Bcc など）として読まれます。
    // 差し込む前に 1 行へ均し、お送りする口でも改行を弾いています。
    await ports.data.renameOrganization("org-1", "しおさい設計室\nBcc: watcher@example.com");

    const { mailed } = await invite(OWNER, "newcomer@example.com");
    expect(mailed).toBe(true);

    const mail = ports.store.mails[0];
    expect(mail?.subject).not.toContain("\n");
    expect(mail?.subject).toContain("しおさい設計室 Bcc: watcher@example.com");
    expect(mail?.text.split("\n")[0]).toContain("しおさい設計室 Bcc:");
  });

  it("表に残るのはハッシュだけで、生のトークンは含まれない", async () => {
    const { invitation, url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    expect(invitation.tokenHash).toMatch(/^[0-9a-f]{64}$/);
    expect(invitation.tokenHash).not.toContain(token);

    const stored = JSON.stringify([...ports.store.invitations.values()]);
    expect(stored).not.toContain(token);
  });

  it("お送りできたときは、符号をお返ししない", async () => {
    const { mailed, mailCode } = await invite(OWNER, "newcomer@example.com");
    expect(mailed).toBe(true);
    expect(mailCode).toBe(null);
  });

  it("お送りできなかったときは、その理由の符号までお返しする", async () => {
    // 「まだ設定が整っていない」と「送ろうとして届かなかった」は、
    // お客さまにお伝えする文が変わります（前者はリンクをお渡しいただく形で足ります）。
    const codes: readonly MailFailureCode[] = ["not_configured", "rejected", "unavailable"];

    for (const code of codes) {
      const mail: MailPort = {
        async send() {
          return { ok: false, code };
        },
      };
      const base = await ctxFor(OWNER);
      const result = await createInvitationFlow({
        ctx: { ...base, ports: { ...base.ports, mail } },
        raw: { email: `${code}@example.com`, role: "member" },
        limiter: createMemoryRateLimiter(INVITE_LIMIT),
        messages,
      });

      expect(result.ok, code).toBe(true);
      if (!result.ok) continue;
      expect(result.value.mailed, code).toBe(false);
      expect(result.value.mailCode, code).toBe(code);
    }
  });

  it("画面にお出しするお知らせは、3 通りに分かれる", () => {
    // お送りできた／まだ設定が整っていない（送っていない）／送ろうとして届かなかった
    expect(inviteNoticeKey({ mailed: true, mailCode: null })).toBe("invite.sentMail");
    expect(inviteNoticeKey({ mailed: false, mailCode: "not_configured" })).toBe("invite.sentLink");
    expect(inviteNoticeKey({ mailed: false, mailCode: "unavailable" })).toBe("invite.mailFailed");
    expect(inviteNoticeKey({ mailed: false, mailCode: "rejected" })).toBe("invite.mailFailed");
  });

  it("同じメールアドレスへの再招待は、前の招待を revoked にしてから作る", async () => {
    await invite(OWNER, "newcomer@example.com");
    await invite(OWNER, "Newcomer@Example.com");

    const rows = await ports.data.listInvitations("org-1");
    expect(rows).toHaveLength(2);
    expect(rows[0]?.status).toBe("revoked");
    expect(rows.filter((row) => row.status === "pending")).toHaveLength(1);
  });

  it("member は招待できず、admin は owner として招待できない", async () => {
    const byMember = await createInvitationFlow({
      ctx: await ctxFor(MEMBER),
      raw: { email: "newcomer@example.com", role: "member" },
      limiter,
      messages,
    });
    expect(byMember).toEqual({ ok: false, code: "forbidden" });

    const byAdmin = await createInvitationFlow({
      ctx: await ctxFor(ADMIN),
      raw: { email: "newcomer@example.com", role: "owner" },
      limiter,
      messages,
    });
    expect(byAdmin).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.invitations.size).toBe(0);
  });

  it("すでに一員のメールアドレスへの招待は no_change", async () => {
    const result = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: "Member@Example.com", role: "member" },
      limiter,
      messages,
    });
    expect(result).toEqual({ ok: false, code: "no_change" });
  });

  it("招待は 20 回まで通り、21 回目に rate_limited になる", async () => {
    for (let i = 0; i < INVITE_LIMIT.limit; i += 1) {
      const result = await createInvitationFlow({
        ctx: await ctxFor(OWNER),
        raw: { email: `invite-${i + 1}@example.com`, role: "member" },
        limiter,
        messages,
      });
      expect(result.ok, `${i + 1} 通目`).toBe(true);
    }

    const over = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: "invite-21@example.com", role: "member" },
      limiter,
      messages,
    });
    expect(over).toEqual({ ok: false, code: "rate_limited" });
  });

  it("招待の回数は、メールアドレスの検査を通ったときだけ数える", async () => {
    const small = createMemoryRateLimiter({ limit: 1, windowSeconds: 3600 });

    // 形の悪いメールアドレスは、回数に入れません
    for (let i = 0; i < 5; i += 1) {
      const broken = await createInvitationFlow({
        ctx: await ctxFor(OWNER),
        raw: { email: "newcomer(at)example.com", role: "member" },
        limiter: small,
        messages,
      });
      expect(broken, `${i + 1} 回目`).toEqual({
        ok: false,
        code: "invalid",
        errors: [{ field: "email", code: "bad_email" }],
      });
    }

    const first = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: "newcomer@example.com", role: "member" },
      limiter: small,
      messages,
    });
    expect(first.ok).toBe(true);

    const second = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: "another@example.com", role: "member" },
      limiter: small,
      messages,
    });
    expect(second).toEqual({ ok: false, code: "rate_limited" });
  });

  it("listInvitationsFlow は owner に一覧を返し、member には forbidden", async () => {
    await invite(OWNER, "newcomer@example.com");

    const forOwner = await listInvitationsFlow({ ctx: await ctxFor(OWNER) });
    expect(forOwner.ok).toBe(true);
    if (forOwner.ok) expect(forOwner.value).toHaveLength(1);

    const forMember = await listInvitationsFlow({ ctx: await ctxFor(MEMBER) });
    expect(forMember).toEqual({ ok: false, code: "forbidden" });
  });

  it("admin は、オーナーとしてお招きしている招待を取り消せない", async () => {
    const { invitation } = await invite(OWNER, "newcomer@example.com", "owner");

    const byAdmin = await revokeInvitationFlow({
      ctx: await ctxFor(ADMIN),
      raw: { invitationId: invitation.id },
    });
    expect(byAdmin).toEqual({ ok: false, code: "forbidden" });
    expect(ports.store.invitations.get(invitation.id)?.status).toBe("pending");

    // オーナーであれば取り消せます
    const byOwner = await revokeInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { invitationId: invitation.id },
    });
    expect(byOwner).toEqual({ ok: true, value: { invitationId: invitation.id } });
  });

  it("revokeInvitationFlow は、お受けいただいた招待と取り消し済みの招待に no_change", async () => {
    // お受けいただいたあとの招待は、もう取り消せません
    const { invitation, url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);
    const accepted = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(accepted.ok).toBe(true);

    const afterAccept = await revokeInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { invitationId: invitation.id },
    });
    expect(afterAccept).toEqual({ ok: false, code: "no_change" });
    expect(ports.store.invitations.get(invitation.id)?.status).toBe("accepted");

    // 2 回続けて取り消したときも、2 回目は「変わりません」とお伝えします
    const second = await invite(OWNER, "another@example.com");
    const first = await revokeInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { invitationId: second.invitation.id },
    });
    expect(first.ok).toBe(true);

    const again = await revokeInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { invitationId: second.invitation.id },
    });
    expect(again).toEqual({ ok: false, code: "no_change" });
  });

  it("revokeInvitationFlow は、ほかの組織の招待の ID に not_found", async () => {
    // なぎさ工房（org-2）のオーナーは、いその 花子です
    const other = await createInvitationFlow({
      ctx: await ctxFor(ADMIN, "org-2"),
      raw: { email: "newcomer@example.com", role: "member" },
      limiter,
      messages,
    });
    expect(other.ok).toBe(true);
    if (!other.ok) return;

    const fromAnotherOrganization = await revokeInvitationFlow({
      ctx: await ctxFor(OWNER, "org-1"),
      raw: { invitationId: other.value.invitation.id },
    });
    expect(fromAnotherOrganization).toEqual({ ok: false, code: "not_found" });
    expect(ports.store.invitations.get(other.value.invitation.id)?.status).toBe("pending");
  });

  it("createInvitationFlow は空のメールアドレスと長すぎるメールアドレスを弾く", async () => {
    const empty = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: "   ", role: "member" },
      limiter,
      messages,
    });
    expect(empty).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "email", code: "required" }],
    });

    const long = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: `${"a".repeat(250)}@example.com`, role: "member" },
      limiter,
      messages,
    });
    expect(long).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "email", code: "too_long" }],
    });

    expect(ports.store.invitations.size).toBe(0);
    expect(ports.store.mails).toHaveLength(0);
  });

  it("全角の空白や制御文字が混じっていても、そろえてから扱う", async () => {
    const result = await createInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { email: "　Newcomer@Example.com\u0007　", role: "　member　" },
      limiter,
      messages,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;

    expect(result.value.invitation.email).toBe("newcomer@example.com");
    expect(result.value.invitation.role).toBe("member");
    expect(ports.store.mails[0]?.to).toBe("newcomer@example.com");
  });

  it("すでにご一緒いただいている方が招待をお受けになっても、役割は変わらない", async () => {
    const { url } = await invite(OWNER, "newcomer@example.com", "admin");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    // 招待とは別の道すじで、先にメンバーとしてお入りいただいた場面です
    await ports.data.addMember("org-1", NEWCOMER.id, "member");
    const before = ports.store.memberships.size;

    const result = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    // 招待の役割（admin）に上がることはありません
    expect(result).toEqual({ ok: true, value: { organizationId: "org-1", role: "member" } });
    expect(ports.store.memberships.size).toBe(before);
    expect((await ports.data.getMembership("org-1", NEWCOMER.id))?.role).toBe("member");

    // 招待は使い終わった扱いになり、2 回目はお使いいただけません
    const again = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(again).toEqual({ ok: false, code: "invite_used" });
  });

  it("acceptInvitationFlow は知らないトークンに invite_not_found", async () => {
    const result = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token: "この-トークンは-ありません",
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: false, code: "invite_not_found" });
  });

  it("acceptInvitationFlow は 8 日後に invite_expired", async () => {
    const { url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    const result = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: EIGHT_DAYS_LATER,
    });
    expect(result).toEqual({ ok: false, code: "invite_expired" });
  });

  it("acceptInvitationFlow は取り消した招待に invite_revoked", async () => {
    const { invitation, url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    const revoked = await revokeInvitationFlow({
      ctx: await ctxFor(OWNER),
      raw: { invitationId: invitation.id },
    });
    expect(revoked).toEqual({ ok: true, value: { invitationId: invitation.id } });

    const result = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: false, code: "invite_revoked" });
  });

  it("acceptInvitationFlow は招待と違うメールアドレスの方に forbidden", async () => {
    const { url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    const result = await acceptInvitationFlow({
      ports,
      user: MEMBER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: false, code: "forbidden" });
  });

  it("acceptInvitationFlow は 1 回目で参加し、2 回目は invite_used", async () => {
    const { url } = await invite(OWNER, "newcomer@example.com", "admin");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    const first = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(first).toEqual({ ok: true, value: { organizationId: "org-1", role: "admin" } });

    const membership = await ports.data.getMembership("org-1", NEWCOMER.id);
    expect(membership?.role).toBe("admin");

    const second = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(second).toEqual({ ok: false, code: "invite_used" });
  });

  it("同じ招待を同時に 2 回お受けになっても、1 回しか入らない", async () => {
    const { url } = await invite(OWNER, "newcomer@example.com", "admin");
    const token = url.slice(`${ORIGIN}/invite/`.length);
    const before = ports.store.memberships.size;

    const [first, second] = await Promise.all([
      acceptInvitationFlow({ ports, user: NEWCOMER, token, limiter: acceptLimiter, ip: IP, now: NOW }),
      acceptInvitationFlow({ ports, user: NEWCOMER, token, limiter: acceptLimiter, ip: IP, now: NOW }),
    ]);

    const results = [first, second];
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.code === "invite_used")).toHaveLength(1);
    expect(ports.store.memberships.size).toBe(before + 1);

    const rows = await ports.data.listInvitations("org-1");
    expect(rows.filter((row) => row.status === "accepted")).toHaveLength(1);
  });

  it("acceptInvitationFlow は IP ごとに数え、尽きると rate_limited になる", async () => {
    const { url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);
    const small = createMemoryRateLimiter({ limit: 2, windowSeconds: 3600 });

    for (let i = 0; i < 2; i += 1) {
      const guess = await acceptInvitationFlow({
        ports,
        user: NEWCOMER,
        token: "この-トークンは-ありません",
        limiter: small,
        ip: IP,
        now: NOW,
      });
      expect(guess, `${i + 1} 回目`).toEqual({ ok: false, code: "invite_not_found" });
    }

    const over = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: small,
      ip: IP,
      now: NOW,
    });
    expect(over).toEqual({ ok: false, code: "rate_limited" });

    // 別の IP からは通ります
    const elsewhere = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: small,
      ip: "203.0.113.20",
      now: NOW,
    });
    expect(elsewhere).toEqual({ ok: true, value: { organizationId: "org-1", role: "member" } });
  });

  it("acceptInvitationFlow は、すでに上限の数の組織に入っている方を forbidden で止める", async () => {
    for (let i = 0; i < MAX_ORGS_PER_USER; i += 1) {
      await ports.data.createOrganizationWithOwner({
        name: `見本の組織 ${i + 1}`,
        userId: NEWCOMER.id,
      });
    }

    const { url } = await invite(OWNER, "newcomer@example.com");
    const token = url.slice(`${ORIGIN}/invite/`.length);

    const result = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(result).toEqual({ ok: false, code: "forbidden" });
    expect(await ports.data.getMembership("org-1", NEWCOMER.id)).toBeNull();

    // 招待は使われていないので、1 つ組織を抜ければお受けいただけます
    await ports.data.removeMember("st-organizations-1", NEWCOMER.id);
    const retried = await acceptInvitationFlow({
      ports,
      user: NEWCOMER,
      token,
      limiter: acceptLimiter,
      ip: IP,
      now: NOW,
    });
    expect(retried).toEqual({ ok: true, value: { organizationId: "org-1", role: "member" } });
  });
  /**
   * ここから 3 件は、**flow を通さずに口を直に撃ちます**。
   *
   * ふだんは flow が正しい値だけをお渡ししますが、「flow の守りが外れても
   * 下の層が止める」という二重の守りは、flow 越しには確かめられません。
   * 本物のデータベースでは `accept_invitation` が同じ 3 つを止めます
   * （`test/supabase.test.ts` が本物の側を撃っています）。
   */
  describe("ご招待の口を、直に撃つ（flow の守りが外れたとき）", () => {
    it("ご招待の役割と違う役割をお渡ししても、その役割では入らない", async () => {
      const { invitation } = await invite(OWNER, "newcomer@example.com", "member");

      // 呼び出し側が admin と言っても、お受けになれません
      expect(await ports.data.acceptInvitation(invitation.id, NEWCOMER.id, "admin")).toBe(
        "not_pending",
      );
      expect(await ports.data.getMembership("org-1", NEWCOMER.id)).toBeNull();

      // ご招待の行のとおりの役割なら、そのとおりに入ります
      expect(await ports.data.acceptInvitation(invitation.id, NEWCOMER.id, "member")).toBe("ok");
      expect((await ports.data.getMembership("org-1", NEWCOMER.id))?.role).toBe("member");
    });

    it("期限の切れたご招待は、口を直に撃っても通らない", async () => {
      const { invitation } = await invite(OWNER, "newcomer@example.com");

      // 期限を過ぎた状態にします（本物では expires_at <= now() です）
      const row = ports.store.invitations.get(invitation.id);
      if (row === undefined) throw new Error("ご招待がありません");
      ports.store.invitations.set(invitation.id, {
        ...row,
        expiresAt: new Date(NOW.getTime() - 1000).toISOString(),
      });

      expect(await ports.data.acceptInvitation(invitation.id, NEWCOMER.id, "member")).toBe(
        "not_pending",
      );
      expect(await ports.data.getMembership("org-1", NEWCOMER.id)).toBeNull();
      // ご招待も、使われないまま pending で残ります
      expect(ports.store.invitations.get(invitation.id)?.status).toBe("pending");
    });

    it("宛先の違う方は、口を直に撃っても通らない", async () => {
      const { invitation } = await invite(OWNER, "newcomer@example.com");

      // なぎさ 健（member@example.com）は、このご招待の宛先ではありません
      expect(await ports.data.acceptInvitation(invitation.id, MEMBER.id, "member")).toBe(
        "not_pending",
      );
      expect(ports.store.invitations.get(invitation.id)?.status).toBe("pending");
    });
  });
});
