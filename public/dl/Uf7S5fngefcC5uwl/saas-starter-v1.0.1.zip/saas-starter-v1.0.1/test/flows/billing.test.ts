import { readFileSync, readdirSync } from "node:fs";
import { beforeEach, describe, expect, it } from "vitest";
import { PLANS } from "../../plans.config";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import {
  billingStateFrom,
  hasOpenSubscription,
  STRIPE_STATUSES,
  type StripeStatus,
} from "../../src/core/billing-state";
import type {
  BillingErrorCode,
  BillingPort,
  Ports,
  SessionUser,
  SubscriptionChange,
} from "../../src/ports";
import { buildCtx, type Ctx, type FlowResult } from "../../src/server/context";
import {
  applyWebhookFlow,
  billingOverviewFlow,
  openPortalFlow,
  startCheckoutFlow,
} from "../../src/server/flows/billing";
import { buildDeps } from "../../src/server/ports";
import {
  DEFAULT_SITE_ORIGIN,
  checkoutCancelUrl,
  checkoutSuccessUrl,
  portalReturnUrl,
  siteOrigin,
} from "../../src/server/urls";

const NOW = new Date("2026-09-20T00:00:00.000Z");
const LATER = new Date("2026-09-21T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";
const CUSTOMER = "cus_demo_1";

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };

type CheckoutInput = Parameters<BillingPort["createCheckoutUrl"]>[0];
type PortalInput = Parameters<BillingPort["createPortalUrl"]>[0];
type WebhookInput = Parameters<BillingPort["readWebhook"]>[0];

/** 偽の課金の口を包んで、渡された戻り先の URL を覚えておきます */
class RecordingBilling implements BillingPort {
  readonly checkouts: CheckoutInput[] = [];
  readonly portals: PortalInput[] = [];

  constructor(private readonly inner: BillingPort) {}

  async createCheckoutUrl(input: CheckoutInput) {
    this.checkouts.push(input);
    return this.inner.createCheckoutUrl(input);
  }

  async createPortalUrl(input: PortalInput) {
    this.portals.push(input);
    return this.inner.createPortalUrl(input);
  }

  async readWebhook(input: WebhookInput) {
    return this.inner.readWebhook(input);
  }
}

/**
 * 課金の口が、決めた符号だけを返すようにします
 * （Stripe の Price の環境変数が空のときや、外が止まっているときの様子です）。
 */
function billingWithCode(code: BillingErrorCode): BillingPort {
  return {
    async createCheckoutUrl() {
      return { ok: false, code };
    },
    async createPortalUrl() {
      return { ok: false, code };
    },
    async readWebhook() {
      return { ok: false, code: "bad_signature" };
    },
  };
}

/**
 * 契約の行への書き込みだけが失敗する店を作ります。
 * （本物では、Stripe の通知をいただいたあとに表への書き込みが落ちる場面にあたります）
 */
function portsWithFailingWrite(base: Ports): Ports {
  const data = new Proxy(base.data, {
    get(target, key, receiver) {
      if (key === "applySubscriptionChange") {
        return async () => {
          throw new Error("契約の行を保存できませんでした");
        };
      }
      const value = Reflect.get(target, key, receiver);
      return typeof value === "function" ? value.bind(target) : value;
    },
  });
  return { ...base, data };
}

/**
 * 画面がご契約を読む口（利用者の鍵）だけが使えない店を作ります。
 *
 * 決済の通知の流れにはログインしている方がいないため、画面の口を呼ぶと
 * 本物では 0 行になり、ご解約の通知を取りこぼします。
 * 呼んだら分かるように、この店では投げるようにしてあります。
 */
function portsWithoutUserSubscription(base: Ports): Ports {
  const data = new Proxy(base.data, {
    get(target, key, receiver) {
      if (key === "getSubscription") {
        return async () => {
          throw new Error("画面の口が、決済の通知の流れから呼ばれました");
        };
      }
      const value = Reflect.get(target, key, receiver);
      return typeof value === "function" ? value.bind(target) : value;
    },
  });
  return { ...base, data };
}

/** 偽の課金の口が読める形の本文を作ります（本物では Stripe が送ってきます） */
function payloadOf(input: {
  eventId: string;
  eventType: string;
  change: SubscriptionChange | null;
}): string {
  return JSON.stringify(input);
}

const STANDARD_ACTIVE: SubscriptionChange = {
  stripeCustomerId: CUSTOMER,
  row: {
    planId: "standard",
    status: "active",
    stripeSubscriptionId: "sub_demo_1",
    currentPeriodEnd: "2026-10-20T00:00:00.000Z",
    cancelAtPeriodEnd: false,
    updatedAt: "2026-09-20T00:00:00.000Z",
  },
};

const BUSINESS_ACTIVE: SubscriptionChange = {
  stripeCustomerId: CUSTOMER,
  row: {
    planId: "business",
    status: "active",
    stripeSubscriptionId: "sub_demo_1",
    currentPeriodEnd: "2026-10-21T00:00:00.000Z",
    cancelAtPeriodEnd: false,
    updatedAt: "2026-09-21T00:00:00.000Z",
  },
};

/**
 * flow が**通ったこと**を先に確かめてから、その中身をお返しします。
 *
 * `expect(result.ok && result.value.x).toBe(false)` と書くと、
 * flow が丸ごと落ちたときも false になり、緑のまま通ってしまいます。
 */
function valueOf<T>(result: FlowResult<T>, label: string): T {
  expect(result.ok, label).toBe(true);
  if (!result.ok) throw new Error(`${label}: ${result.code}`);
  return result.value;
}

describe("課金の流れ", () => {
  let ports: Ports & { store: FakeStore };
  let billing: RecordingBilling;

  beforeEach(() => {
    const fake = createFakePorts({ now: () => NOW, seeded: true });
    billing = new RecordingBilling(fake.billing);
    ports = { ...fake, billing };
  });

  async function ctxFor(user: SessionUser, organizationId = "org-1"): Promise<Ctx> {
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(`ctx を作れませんでした: ${built.code}`);
    return built.value;
  }

  /** ご契約の行を直に置きます（本物では Webhook が書きます） */
  async function setStatus(status: StripeStatus, organizationId = "org-1"): Promise<void> {
    await ports.data.upsertSubscription({
      organizationId,
      planId: "standard",
      status,
      stripeSubscriptionId: "sub_demo_1",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: NOW.toISOString(),
    });
  }

  it("startCheckoutFlow は owner だけが使えて、Checkout の戻り先を渡す", async () => {
    const byMember = await startCheckoutFlow({
      ctx: await ctxFor(MEMBER),
      raw: { planId: "standard" },
    });
    expect(byMember).toEqual({ ok: false, code: "forbidden" });

    const byAdmin = await startCheckoutFlow({
      ctx: await ctxFor(ADMIN),
      raw: { planId: "standard" },
    });
    expect(byAdmin).toEqual({ ok: false, code: "forbidden" });

    const byOwner = await startCheckoutFlow({
      ctx: await ctxFor(OWNER),
      raw: { planId: "standard" },
    });
    expect(byOwner.ok).toBe(true);
    if (!byOwner.ok) return;
    expect(byOwner.value.url).toContain("/fake/checkout");

    // オーナー以外は、課金の口にたどり着いていません
    expect(billing.checkouts).toHaveLength(1);
    const call = billing.checkouts[0];
    expect(call?.organizationId).toBe("org-1");
    expect(call?.planId).toBe("standard");
    // 決済のしくみにお渡しするのは組織のお名前です（どなたのメールアドレスも渡しません）
    expect(call?.organizationName).toBe("しおさい設計室");
    expect(call?.lang).toBe("ja");
    expect(call?.successUrl).toBe(`${ORIGIN}/app/settings/billing?checkout=done`);
    expect(call?.cancelUrl).toBe(`${ORIGIN}/app/settings/billing?checkout=canceled`);
  });

  it("startCheckoutFlow は free と、ない名前のプランを invalid で弾く", async () => {
    const free = await startCheckoutFlow({
      ctx: await ctxFor(OWNER),
      raw: { planId: "free" },
    });
    expect(free).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "planId", code: "bad_choice" }],
    });

    const gold = await startCheckoutFlow({
      ctx: await ctxFor(OWNER),
      raw: { planId: "gold" },
    });
    expect(gold).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "planId", code: "bad_choice" }],
    });

    expect(billing.checkouts).toHaveLength(0);
  });

  it("戻り先の URL は、依存の束の siteOrigin から作る", async () => {
    // 呼び出し側（リクエストのヘッダ）からは受け取りません。
    // 差し替えられた Host で Checkout の戻り先を作ると、知らないサイトへお戻しするためです。
    const ctx: Ctx = { ...(await ctxFor(OWNER)), siteOrigin: "https://app.example.com/" };

    const started = await startCheckoutFlow({ ctx, raw: { planId: "standard" } });
    expect(started.ok).toBe(true);
    expect(billing.checkouts[0]?.successUrl).toBe(
      "https://app.example.com/app/settings/billing?checkout=done",
    );
    expect(billing.checkouts[0]?.cancelUrl).toBe(
      "https://app.example.com/app/settings/billing?checkout=canceled",
    );

    await ports.data.setStripeCustomer("org-1", CUSTOMER);
    const portal = await openPortalFlow({ ctx });
    expect(portal.ok).toBe(true);
    expect(billing.portals[0]?.returnUrl).toBe("https://app.example.com/app/settings/billing");
  });

  it("課金の口が返す符号を、画面に出せる符号に写す", async () => {
    const cases = [
      // Stripe の Price を入れる環境変数が空のとき
      { code: "not_configured", shown: "billing_not_configured" },
      // お客さま情報がまだ無いとき
      { code: "no_customer", shown: "billing_no_customer" },
      // 外が止まっているとき
      { code: "unavailable", shown: "unavailable" },
    ] as const;

    for (const one of cases) {
      const base = await ctxFor(OWNER);
      const ctx: Ctx = { ...base, ports: { ...ports, billing: billingWithCode(one.code) } };

      const started = await startCheckoutFlow({ ctx, raw: { planId: "standard" } });
      expect(started, `checkout: ${one.code}`).toEqual({ ok: false, code: one.shown });

      // お手続きの画面は、先にお客さま情報の有無を見ます
      await ports.data.setStripeCustomer("org-1", CUSTOMER);
      const portal = await openPortalFlow({ ctx });
      expect(portal, `portal: ${one.code}`).toEqual({ ok: false, code: one.shown });
    }
  });

  it("ご契約が生きているあいだの再お申し込みは already_subscribed で止める", async () => {
    // お支払いが続いているあいだに Checkout をもう一度お通しすると、
    // ご契約が 2 本になり、二重にご請求してしまいます。
    for (const status of ["active", "trialing", "past_due"] as const) {
      await setStatus(status);
      const again = await startCheckoutFlow({
        ctx: await ctxFor(OWNER),
        raw: { planId: "business" },
      });
      expect(again, status).toEqual({ ok: false, code: "already_subscribed" });
    }
    expect(billing.checkouts).toHaveLength(0);

    // ご解約のあとは、またお申し込みいただけます
    await setStatus("canceled");
    const after = await startCheckoutFlow({
      ctx: await ctxFor(OWNER),
      raw: { planId: "standard" },
    });
    expect(after.ok).toBe(true);
    expect(billing.checkouts).toHaveLength(1);
  });

  it("openPortalFlow は、お客さま情報の無い組織に billing_no_customer", async () => {
    const before = await openPortalFlow({ ctx: await ctxFor(OWNER) });
    expect(before).toEqual({ ok: false, code: "billing_no_customer" });
    expect(billing.portals).toHaveLength(0);

    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const after = await openPortalFlow({ ctx: await ctxFor(OWNER) });
    expect(after.ok).toBe(true);
    expect(billing.portals[0]?.returnUrl).toBe(`${ORIGIN}/app/settings/billing`);

    const byAdmin = await openPortalFlow({ ctx: await ctxFor(ADMIN) });
    expect(byAdmin).toEqual({ ok: false, code: "forbidden" });
  });

  it("applyWebhookFlow は署名と本文の大きさを確かめる", async () => {
    const badSignature = await applyWebhookFlow({
      ports,
      payload: payloadOf({ eventId: "evt_1", eventType: "checkout.session.completed", change: null }),
      signature: null,
      now: NOW,
    });
    expect(badSignature).toEqual({ ok: false, code: "forbidden" });

    const tooLarge = await applyWebhookFlow({
      ports,
      payload: "x".repeat(1024 * 1024 + 1),
      signature: "fake",
      now: NOW,
    });
    expect(tooLarge).toEqual({ ok: false, code: "invalid" });

    expect(ports.store.stripeEvents.size).toBe(0);
  });

  it("同じ event.id の 2 回目は applied: false で、表は変わらない", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const first = await applyWebhookFlow({
      ports,
      payload: payloadOf({ eventId: "evt_1", eventType: "customer.subscription.updated", change: STANDARD_ACTIVE }),
      signature: "fake",
      now: NOW,
    });
    expect(first).toEqual({ ok: true, value: { eventId: "evt_1", applied: true } });

    // 同じ event.id で、中身だけ違うものが届いても書き換えません
    const second = await applyWebhookFlow({
      ports,
      payload: payloadOf({ eventId: "evt_1", eventType: "customer.subscription.updated", change: BUSINESS_ACTIVE }),
      signature: "fake",
      now: LATER,
    });
    expect(second).toEqual({ ok: true, value: { eventId: "evt_1", applied: false } });

    const row = await ports.data.getSubscription("org-1");
    expect(row?.planId).toBe("standard");
    expect(ports.store.stripeEvents.size).toBe(1);
  });

  it("ご解約のあとに、それより古い更新が届いても canceled のまま", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_created",
        eventType: "customer.subscription.created",
        change: STANDARD_ACTIVE,
      }),
      signature: "fake",
      now: NOW,
    });

    // ご解約を適用します（この行の updatedAt は、受け取った時刻の 9/21 になります）
    await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_deleted",
        eventType: "customer.subscription.deleted",
        change: { stripeCustomerId: CUSTOMER, row: null },
      }),
      signature: "fake",
      now: LATER,
    });
    expect((await ports.data.getSubscription("org-1"))?.status).toBe("canceled");

    // 遅れて届いた、ご解約より前の状態（9/20 に取り直したもの）です
    const stale = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_stale_update",
        eventType: "customer.subscription.updated",
        change: STANDARD_ACTIVE,
      }),
      signature: "fake",
      now: new Date("2026-09-22T00:00:00.000Z"),
    });
    expect(stale).toEqual({ ok: true, value: { eventId: "evt_stale_update", applied: false } });

    const row = await ports.data.getSubscription("org-1");
    expect(row?.status).toBe("canceled");
    expect(row?.planId).toBe("free");
    expect(billingStateFrom(row).entitled).toBe(false);
  });

  it("新しい更新のあとに古い created が届いても、新しいほうが残る", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    // 先に新しい状態（9/21 に取り直したビジネス）が届きました
    const newer = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_updated",
        eventType: "customer.subscription.updated",
        change: BUSINESS_ACTIVE,
      }),
      signature: "fake",
      now: NOW,
    });
    expect(newer).toEqual({ ok: true, value: { eventId: "evt_updated", applied: true } });

    // あとから、それより前の状態（9/20 に取り直したスタンダード）が届きました
    const older = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_created",
        eventType: "customer.subscription.created",
        change: STANDARD_ACTIVE,
      }),
      signature: "fake",
      now: LATER,
    });
    expect(older).toEqual({ ok: true, value: { eventId: "evt_created", applied: false } });

    const row = await ports.data.getSubscription("org-1");
    expect(row?.planId).toBe("business");
    expect(row?.currentPeriodEnd).toBe("2026-10-21T00:00:00.000Z");
    expect(row?.updatedAt).toBe("2026-09-21T00:00:00.000Z");
  });

  it("同じ時刻の行は、あとから届いたほうで書き直す", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const first = { ...STANDARD_ACTIVE.row!, cancelAtPeriodEnd: false };
    const second = { ...STANDARD_ACTIVE.row!, cancelAtPeriodEnd: true };

    await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_one",
        eventType: "customer.subscription.updated",
        change: { stripeCustomerId: CUSTOMER, row: first },
      }),
      signature: "fake",
      now: NOW,
    });

    const again = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_two",
        eventType: "customer.subscription.updated",
        change: { stripeCustomerId: CUSTOMER, row: second },
      }),
      signature: "fake",
      now: LATER,
    });
    expect(again).toEqual({ ok: true, value: { eventId: "evt_two", applied: true } });
    expect((await ports.data.getSubscription("org-1"))?.cancelAtPeriodEnd).toBe(true);
  });

  it("書き込みが失敗したときは記録も残らず、Stripe の再送で入り直す", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const payload = payloadOf({
      eventId: "evt_retry",
      eventType: "customer.subscription.updated",
      change: STANDARD_ACTIVE,
    });

    await expect(
      applyWebhookFlow({
        ports: portsWithFailingWrite(ports),
        payload,
        signature: "fake",
        now: NOW,
      }),
    ).rejects.toThrow();

    // 記録が先だと、この event は「処理済み」のまま二度と適用されません
    expect(ports.store.stripeEvents.size).toBe(0);
    expect(ports.store.subscriptions.size).toBe(0);

    const again = await applyWebhookFlow({ ports, payload, signature: "fake", now: LATER });
    expect(again).toEqual({ ok: true, value: { eventId: "evt_retry", applied: true } });
    expect((await ports.data.getSubscription("org-1"))?.planId).toBe("standard");
    expect(ports.store.stripeEvents.size).toBe(1);
  });

  it("知らない stripeCustomerId の変更は、静かに捨てる", async () => {
    const result = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_unknown",
        eventType: "customer.subscription.updated",
        change: { stripeCustomerId: "cus_unknown", row: STANDARD_ACTIVE.row },
      }),
      signature: "fake",
      now: NOW,
    });
    expect(result).toEqual({ ok: true, value: { eventId: "evt_unknown", applied: false } });
    expect(ports.store.subscriptions.size).toBe(0);
  });

  it("届いた中身に organizationId が紛れていても、別の組織の行は書き換えない", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    // 型の上では入らない値ですが、本文は外から届くものなので、混ざっていても無視します
    const payload = JSON.stringify({
      eventId: "evt_sneaky",
      eventType: "customer.subscription.updated",
      change: {
        stripeCustomerId: CUSTOMER,
        row: { ...STANDARD_ACTIVE.row, organizationId: "org-2" },
      },
    });

    const result = await applyWebhookFlow({ ports, payload, signature: "fake", now: NOW });
    expect(result).toEqual({ ok: true, value: { eventId: "evt_sneaky", applied: true } });

    expect(await ports.data.getSubscription("org-2")).toBeNull();
    expect((await ports.data.getSubscription("org-1"))?.planId).toBe("standard");
  });

  it("知らないプランや状態の行は、書かずに applied: false", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const cases = [
      { eventId: "evt_bad_plan", row: { ...STANDARD_ACTIVE.row, planId: "gold" } },
      { eventId: "evt_bad_status", row: { ...STANDARD_ACTIVE.row, status: "ended" } },
      { eventId: "evt_bad_time", row: { ...STANDARD_ACTIVE.row, updatedAt: "きのう" } },
    ];

    for (const one of cases) {
      const result = await applyWebhookFlow({
        ports,
        payload: JSON.stringify({
          eventId: one.eventId,
          eventType: "customer.subscription.updated",
          change: { stripeCustomerId: CUSTOMER, row: one.row },
        }),
        signature: "fake",
        now: NOW,
      });
      expect(result, one.eventId).toEqual({
        ok: true,
        value: { eventId: one.eventId, applied: false },
      });
    }

    expect(ports.store.subscriptions.size).toBe(0);
  });

  it("扱わない種類のイベント（change が null）は applied: false", async () => {
    const result = await applyWebhookFlow({
      ports,
      payload: payloadOf({ eventId: "evt_other", eventType: "invoice.paid", change: null }),
      signature: "fake",
      now: NOW,
    });
    expect(result).toEqual({ ok: true, value: { eventId: "evt_other", applied: false } });
    expect(ports.store.subscriptions.size).toBe(0);
  });

  it("一度もご契約のない組織へのご解約の通知は、行を作らない", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const result = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_deleted_only",
        eventType: "customer.subscription.deleted",
        change: { stripeCustomerId: CUSTOMER, row: null },
      }),
      signature: "fake",
      now: NOW,
    });
    expect(result).toEqual({ ok: true, value: { eventId: "evt_deleted_only", applied: false } });

    // 行ができると、画面に「ご契約が終了しました」の帯が出てしまいます
    expect(ports.store.subscriptions.size).toBe(0);
    const state = billingStateFrom(await ports.data.getSubscription("org-1"));
    expect(state.banner).toBe("none");
    expect(state.planId).toBe("free");
  });

  it("契約が消えたときは canceled で書き、プランは free に戻る", async () => {
    await ports.data.setStripeCustomer("org-1", CUSTOMER);
    await applyWebhookFlow({
      ports,
      payload: payloadOf({ eventId: "evt_1", eventType: "checkout.session.completed", change: STANDARD_ACTIVE }),
      signature: "fake",
      now: NOW,
    });

    const deleted = await applyWebhookFlow({
      ports,
      payload: payloadOf({
        eventId: "evt_deleted",
        eventType: "customer.subscription.deleted",
        change: { stripeCustomerId: CUSTOMER, row: null },
      }),
      signature: "fake",
      now: LATER,
    });
    expect(deleted).toEqual({ ok: true, value: { eventId: "evt_deleted", applied: true } });

    const row = await ports.data.getSubscription("org-1");
    expect(row?.status).toBe("canceled");
    expect(row?.planId).toBe("free");

    const state = billingStateFrom(row);
    expect(state.planId).toBe("free");
    expect(state.entitled).toBe(false);
    expect(state.banner).toBe("canceled");
  });

  it("決済の通知の流れは、画面の口ではなく通知だけの口からご契約を読む", async () => {
    // 画面の口（利用者の鍵）は、ログインしている方がいて初めて読めます。
    // 決済の通知にはその方がいないため、通知の流れはこちらを呼びません。
    const guarded = portsWithoutUserSubscription(ports);
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const created = await applyWebhookFlow({
      ports: guarded,
      payload: payloadOf({
        eventId: "evt_guarded_1",
        eventType: "checkout.session.completed",
        change: STANDARD_ACTIVE,
      }),
      signature: "fake",
      now: NOW,
    });
    expect(created).toEqual({ ok: true, value: { eventId: "evt_guarded_1", applied: true } });

    // ご解約は、いま入っている行を読み直してから書きます（ここが取りこぼしやすいところです）
    const deleted = await applyWebhookFlow({
      ports: guarded,
      payload: payloadOf({
        eventId: "evt_guarded_2",
        eventType: "customer.subscription.deleted",
        change: { stripeCustomerId: CUSTOMER, row: null },
      }),
      signature: "fake",
      now: LATER,
    });
    expect(deleted).toEqual({ ok: true, value: { eventId: "evt_guarded_2", applied: true } });

    // 決済の契約の番号も、あとからお調べになれるように残ります
    const row = await ports.data.getBillingSubscription("org-1");
    expect(row?.status).toBe("canceled");
    expect(row?.stripeSubscriptionId).toBe("sub_demo_1");
  });

  it("billingOverviewFlow の canManage は owner だけ true", async () => {
    const forOwner = await billingOverviewFlow({ ctx: await ctxFor(OWNER) });
    expect(forOwner.ok).toBe(true);
    if (!forOwner.ok) return;
    expect(forOwner.value.canManage).toBe(true);
    expect(forOwner.value.state.planId).toBe("free");
    expect(forOwner.value.quota.used).toBe(2);
    // 並びも数も、plans.config.ts のとおりです（プランをお増やしになっても同じです）
    expect(forOwner.value.plans.map((plan) => plan.id)).toEqual(PLANS.map((plan) => plan.id));
    // 画面には、Stripe の Price を入れる環境変数の名前をお渡ししません
    for (const plan of forOwner.value.plans) {
      expect(Object.keys(plan), plan.id).not.toContain("priceEnvName");
    }

    const forAdmin = await billingOverviewFlow({ ctx: await ctxFor(ADMIN) });
    expect(valueOf(forAdmin, "admin").canManage).toBe(false);

    const forMember = await billingOverviewFlow({ ctx: await ctxFor(MEMBER) });
    expect(valueOf(forMember, "member").canManage).toBe(false);
  });

  it("billingOverviewFlow の canStartCheckout は、ご契約の実体が残っているあいだ false", async () => {
    // 画面は、この 1 つだけを見てお申し込みのボタンを出します。
    // ご契約の実体が残っているあいだにお通しすると、ご契約が 2 本になってしまうためです
    // （押したあとに startCheckoutFlow が already_subscribed で止めるのではなく、
    // はじめからお出ししません）。
    const before = await billingOverviewFlow({ ctx: await ctxFor(OWNER) });
    expect(valueOf(before, "ご契約の前").canStartCheckout).toBe(true);

    // はじめのお支払いの確認待ち（incomplete）と一時停止中（paused）も、
    // 決済のしくみの側にはご契約が残っています
    for (const status of STRIPE_STATUSES.filter((s) => hasOpenSubscription(s))) {
      await setStatus(status);
      const during = await billingOverviewFlow({ ctx: await ctxFor(OWNER) });
      expect(valueOf(during, status).canStartCheckout, status).toBe(false);
    }

    // ご解約のあと・お申し込みが期限切れになったあとは、またお申し込みいただけます
    for (const status of ["canceled", "incomplete_expired"] as const) {
      await setStatus(status);
      const after = await billingOverviewFlow({ ctx: await ctxFor(OWNER) });
      expect(valueOf(after, status).canStartCheckout, status).toBe(true);
    }
  });

  it("canStartCheckout は、お支払いの操作ができない方には出さない", async () => {
    for (const user of [ADMIN, MEMBER]) {
      const overview = await billingOverviewFlow({ ctx: await ctxFor(user) });
      expect(valueOf(overview, user.id).canStartCheckout, user.id).toBe(false);
    }
  });

  it("canStartCheckout と startCheckoutFlow の答えが、いつもそろっている", async () => {
    // 画面の出し分けと、押されたあとの守りが食い違わないための番人です。
    // **8 つの状態すべて**で見ます（抜けていた 3 つで、ご契約が 2 本立ちえました）。
    expect(STRIPE_STATUSES).toHaveLength(8);
    for (const status of STRIPE_STATUSES) {
      await setStatus(status);
      const ctx = await ctxFor(OWNER);

      const overview = await billingOverviewFlow({ ctx });
      const started = await startCheckoutFlow({ ctx, raw: { planId: "business" } });

      expect(valueOf(overview, status).canStartCheckout, status).toBe(started.ok);
      expect(started.ok, status).toBe(!hasOpenSubscription(status));
    }
  });

});

describe("課金の戻り先の URL", () => {
  it("siteOrigin は末尾の / を落とし、未設定なら既定の行き先を使う", () => {
    expect(siteOrigin({})).toBe(DEFAULT_SITE_ORIGIN);
    expect(siteOrigin({ NEXT_PUBLIC_SITE_URL: "  " })).toBe(DEFAULT_SITE_ORIGIN);
    expect(siteOrigin({ NEXT_PUBLIC_SITE_URL: "https://example.com/" })).toBe("https://example.com");
  });

  it("Checkout と Customer Portal の戻り先は、お支払いの画面に戻る", () => {
    expect(checkoutSuccessUrl("https://example.com/")).toBe(
      "https://example.com/app/settings/billing?checkout=done",
    );
    expect(checkoutCancelUrl("https://example.com")).toBe(
      "https://example.com/app/settings/billing?checkout=canceled",
    );
    expect(portalReturnUrl("https://example.com/")).toBe("https://example.com/app/settings/billing");
  });

  it("buildDeps は、環境変数から土台を作って ports と 1 つの束にする", () => {
    const before = process.env.NEXT_PUBLIC_SITE_URL;
    try {
      process.env.NEXT_PUBLIC_SITE_URL = "https://app.example.com/";
      const ports = createFakePorts({ now: () => NOW, seeded: false });
      const deps = buildDeps(ports);
      expect(deps.siteOrigin).toBe("https://app.example.com");
      expect(deps.ports).toBe(ports);

      delete process.env.NEXT_PUBLIC_SITE_URL;
      expect(buildDeps(ports).siteOrigin).toBe(DEFAULT_SITE_ORIGIN);
    } finally {
      if (before === undefined) delete process.env.NEXT_PUBLIC_SITE_URL;
      else process.env.NEXT_PUBLIC_SITE_URL = before;
    }
  });

  it("環境変数から土台を作るのは、依存の束を組み立てる 1 か所だけ", () => {
    // 戻り先の URL をリクエストのヘッダ（Host・Origin）から作る道を残さないための番人です。
    // 新しく process.env を読むファイルが増えたら、ここで気づけます。
    const root = new URL("../../src/", import.meta.url);
    const found: string[] = [];

    const walk = (dir: URL, prefix: string): void => {
      for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) =>
        a.name.localeCompare(b.name),
      )) {
        if (entry.isDirectory()) {
          walk(new URL(`${entry.name}/`, dir), `${prefix}${entry.name}/`);
          continue;
        }
        if (!entry.name.endsWith(".ts")) continue;
        const text = readFileSync(new URL(entry.name, dir), "utf8");
        if (text.includes("process.env")) found.push(`${prefix}${entry.name}`);
      }
    };
    walk(root, "");

    // メールの口だけは、自分の鍵（RESEND_API_KEY と MAIL_FROM）を自分で読みます。
    // 先頭の server-only がブラウザへの持ち出しを止めており、
    // ここで読むのはメールの設定だけです（土台の URL には触れません）。
    expect(found).toEqual(["adapters/mail/resend.ts", "server/ports.ts"]);
  });
});

describe("見本の applySubscriptionChange（SQL の関数と同じ決まり）", () => {
  it("時刻として読めない行は、書かずに false を返す", async () => {
    const ports = createFakePorts({ now: () => NOW, seeded: true });
    const before = await ports.data.getBillingSubscription("org-1");

    const wrote = await ports.data.applySubscriptionChange({
      organizationId: "org-1",
      row: {
        planId: "business",
        status: "active",
        stripeSubscriptionId: "sub_demo_x",
        currentPeriodEnd: null,
        cancelAtPeriodEnd: false,
        updatedAt: "いつか",
      },
      now: NOW.toISOString(),
    });

    expect(wrote).toBe(false);
    expect(await ports.data.getBillingSubscription("org-1")).toEqual(before);
  });
});
