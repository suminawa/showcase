import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts } from "../../src/adapters/fake";
import type { FakeStore } from "../../src/adapters/fake/store";
import type { Ports } from "../../src/ports";
import { ADMIN_PER_PAGE, adminOverviewFlow, isAdminEmail } from "../../src/server/flows/admin";

const NOW = new Date("2026-09-20T00:00:00.000Z");

describe("管理の画面の流れ", () => {
  let ports: Ports & { store: FakeStore };

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
  });

  it("isAdminEmail は ADMIN_EMAILS が未設定・空のとき、どなたにも false", () => {
    expect(isAdminEmail("owner@example.com", undefined)).toBe(false);
    expect(isAdminEmail("owner@example.com", "")).toBe(false);
    expect(isAdminEmail("owner@example.com", "   ")).toBe(false);
    expect(isAdminEmail("owner@example.com", " , ")).toBe(false);
  });

  it("isAdminEmail はカンマで割り、前後の空白と大文字小文字を気にしない", () => {
    const list = " Owner@Example.com , admin@example.com ";
    expect(isAdminEmail("owner@example.com", list)).toBe(true);
    expect(isAdminEmail(" ADMIN@example.com ", list)).toBe(true);
    expect(isAdminEmail("member@example.com", list)).toBe(false);
    expect(isAdminEmail("", list)).toBe(false);
  });

  it("adminOverviewFlow は組織・ご利用の方・ご契約を読むだけで返す", async () => {
    await ports.data.upsertSubscription({
      organizationId: "org-1",
      planId: "standard",
      status: "active",
      stripeSubscriptionId: "sub_demo_1",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: NOW.toISOString(),
    });

    const result = await adminOverviewFlow({ ports, page: 1, perPage: ADMIN_PER_PAGE });
    expect(result.ok).toBe(true);
    if (!result.ok) return;

    expect(result.value.organizations.map((row) => row.organization.id)).toEqual(["org-1", "org-2"]);
    const first = result.value.organizations[0];
    expect(first?.memberCount).toBe(3);
    expect(first?.projectCount).toBe(2);
    expect(first?.planId).toBe("standard");
    expect(result.value.profiles).toHaveLength(3);
    expect(result.value.subscriptions).toHaveLength(1);
  });

  it("ご契約の一覧は、組織のお名前を一緒にお返しする（ページが進んでも引けます）", async () => {
    // 組織の一覧は 1 ページに 50 件までなので、51 件目より後ろの組織のご契約は、
    // 同じページの組織の一覧からお名前を引けません。ご契約の行が自分で持ちます。
    const far = await ports.data.createOrganizationWithOwner({
      name: "とおくの工房",
      userId: "u-owner",
    });
    await ports.data.upsertSubscription({
      organizationId: far.id,
      planId: "business",
      status: "active",
      stripeSubscriptionId: "sub_demo_far",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: NOW.toISOString(),
    });

    const rows = await ports.data.adminListSubscriptions(100, 0);
    expect(rows).toHaveLength(1);
    const row = rows[0];
    expect(row?.organizationId).toBe(far.id);
    expect(row?.organizationName).toBe("とおくの工房");
    expect(row?.planId).toBe("business");
  });

  it("ご契約の一覧には、決済の契約の番号を入れない", async () => {
    await ports.data.upsertSubscription({
      organizationId: "org-1",
      planId: "standard",
      status: "active",
      stripeSubscriptionId: "sub_demo_1",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: NOW.toISOString(),
    });

    const rows = await ports.data.adminListSubscriptions(100, 0);
    expect(rows).toHaveLength(1);

    // 欄そのものがありません（null で残しておくと、行をそのまま渡した日に漏れます）
    expect(Object.keys(rows[0] ?? {}).sort()).toEqual([
      "cancelAtPeriodEnd",
      "currentPeriodEnd",
      "organizationId",
      "organizationName",
      "planId",
      "status",
      "updatedAt",
    ]);
    expect(JSON.stringify(rows)).not.toContain("sub_demo_1");
  });

  it("お名前の分からない組織のご契約は、一覧に出さない", async () => {
    // 組織を消すとご契約の行も一緒に消えます（データベースの側の決まりです）。
    // 見本のしくみでも同じ見え方にそろえ、名前の無い行を画面へ渡しません。
    await ports.data.upsertSubscription({
      organizationId: "org-nothing",
      planId: "standard",
      status: "active",
      stripeSubscriptionId: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: false,
      updatedAt: NOW.toISOString(),
    });

    expect(await ports.data.adminListSubscriptions(100, 0)).toEqual([]);
  });

  it("adminOverviewFlow は perPage を 1〜100 に丸め、page で続きを返す", async () => {
    for (let i = 0; i < 100; i += 1) {
      await ports.data.createOrganizationWithOwner({ name: `見本の組織 ${i + 1}`, userId: "u-owner" });
    }

    const tooSmall = await adminOverviewFlow({ ports, page: 1, perPage: 0 });
    expect(tooSmall.ok && tooSmall.value.organizations).toHaveLength(1);

    const tooBig = await adminOverviewFlow({ ports, page: 1, perPage: 500 });
    expect(tooBig.ok && tooBig.value.organizations).toHaveLength(100);

    // 102 件のうち、2 ページ目に残るのは 2 件です
    const second = await adminOverviewFlow({ ports, page: 2, perPage: 500 });
    expect(second.ok && second.value.organizations).toHaveLength(2);

    // 0 ページ目・負のページ目は 1 ページ目として扱います
    const zero = await adminOverviewFlow({ ports, page: 0, perPage: 100 });
    expect(zero.ok && zero.value.organizations).toHaveLength(100);
  });

  it("0 件以下をお求めになったときは、何もお返ししない", async () => {
    // 画面の流れは 1〜100 に丸めるので、ここへは来ません。
    // 直にお呼びになったときに、負の数が「末尾を除いた全件」にならないための守りです。
    expect(await ports.data.adminListOrganizations(0, 0)).toEqual([]);
    expect(await ports.data.adminListOrganizations(-1, 0)).toEqual([]);
    expect(await ports.data.adminListProfiles(0, 0)).toEqual([]);
    expect(await ports.data.adminListProfiles(-1, 0)).toEqual([]);
    expect(await ports.data.adminListSubscriptions(0, 0)).toEqual([]);
    expect(await ports.data.adminListSubscriptions(-1, 0)).toEqual([]);
  });
});
