/**
 * ブラウザに配る束（.next/static）に、鍵の名前が紛れ込んでいないかを調べる道具の検査です。
 *
 * **実物の束は、ここでは調べません。** vitest のたびに next build を回すと遅くなるためです。
 * 実物は `npm run check:bundle` が、見本のしくみと鍵を入れた形の 2 通りで組み立て直してから調べます。
 *
 * ここで確かめるのは 3 つです。
 *   1. 調べる道具が、字面を取りこぼさず、余計なものを拾わないこと
 *   2. 調べる語の一覧が痩せていないこと（鍵の名前・鍵の形・サーバー専用の字）
 *   3. 鍵の名前を読んでいるファイルが、すべて server-only を先頭に置いていること
 */
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  CANARY_ENV,
  FORBIDDEN_IN_CLIENT,
  FORBIDDEN_IN_PRERENDER,
  PRERENDER_EXTENSIONS,
  SECRET_ENV_NAMES,
  clientBundleDir,
  prerenderDir,
  prerenderFiles,
  scanBundle,
  scanPrerender,
  scanTexts,
  verdict,
} from "../scripts/check-bundle.mjs";

const packageRoot = fileURLToPath(new URL("../", import.meta.url));
const fixtures = join(packageRoot, "test/fixtures/bundle");

/** その語を報告されたファイルの名前だけを、並べ替えて取り出します */
function filesFor(term: string): string[] {
  return scanBundle(fixtures)
    .filter((hit) => hit.term === term)
    .map((hit) => hit.file)
    .sort();
}

describe("束を調べる道具", () => {
  it("鍵の名前が書かれたファイルを、語とあわせて報告する", () => {
    expect(filesFor("SUPABASE_SERVICE_ROLE_KEY")).toEqual(["a.js"]);
  });

  it("語の入っていないファイルは報告しない", () => {
    const reported = new Set(scanBundle(fixtures).map((hit) => hit.file));
    expect(reported.has("b.js")).toBe(false);
    expect(reported.has("d.css")).toBe(false);
  });

  it("入れ子の入れ物もたどる", () => {
    expect(filesFor("sk_live_")).toEqual([join("nested", "e.js")]);
  });

  it(".js 以外のファイルも調べる（ブラウザには、これらもそのまま配られます）", () => {
    // 束に配るのは JavaScript だけではありません。設定の写しや見た目の指定も配られます。
    expect(filesFor("ADMIN_EMAILS")).toEqual(["c.json"]);
  });

  it("調べる入れ物が無いときは、何も報告しない（呼んだ側がご案内します）", () => {
    expect(scanBundle(join(fixtures, "no-such-folder"))).toEqual([]);
  });

  it("調べる語を、呼ぶ側から差し替えられる（目印の値を調べるために使います）", () => {
    expect(scanBundle(fixtures, ["EXAMPLE_NOT_A_KEY"])).toEqual([
      { file: join("nested", "e.js"), term: "EXAMPLE_NOT_A_KEY" },
    ]);
  });

  it("ブラウザに配る入れ物の場所は .next/static", () => {
    expect(clientBundleDir("/tmp/example")).toBe(join("/tmp/example", ".next", "static"));
  });
});

describe("組み立て済みのお返事を調べる道具", () => {
  const prerender = join(packageRoot, "test/fixtures/prerender");

  function prerenderFilesFor(term: string): string[] {
    return scanPrerender(prerender, [term])
      .map((hit) => hit.file)
      .sort();
  }

  it("組み立て済みのお返事の置き場は .next/server", () => {
    expect(prerenderDir("/tmp/example")).toBe(join("/tmp/example", ".next", "server"));
  });

  it("ブラウザに届く形（html・rsc・body・meta）だけを調べる", () => {
    expect([...PRERENDER_EXTENSIONS].sort()).toEqual([".body", ".html", ".meta", ".rsc"]);
  });

  it("組み立て済みの画面に目印の値が出てきたら報告する", () => {
    expect(prerenderFilesFor(CANARY_ENV.SUPABASE_SERVICE_ROLE_KEY)).toEqual(["index.html"]);
  });

  it("お返事の続き（rsc）と、入れ子の入れ物もたどる", () => {
    expect(prerenderFilesFor(CANARY_ENV.STRIPE_PRICE_STANDARD)).toEqual([
      join("app", "page.rsc"),
    ]);
  });

  it("ブラウザに届いてはいけない欄の名前も調べる", () => {
    expect(prerenderFilesFor("priceEnvName")).toEqual([join("app", "page.rsc")]);
    expect(prerenderFilesFor("stripeSubscriptionId")).toEqual([join("app", "page.rsc")]);
  });

  it("サーバーの中だけで動くファイルは、調べない（鍵の名前は正しく入っています）", () => {
    // .js と .json は、サーバーの中でだけ読まれます。鍵の名前がここに出るのは正しい姿です。
    const reported = new Set(scanPrerender(prerender, FORBIDDEN_IN_PRERENDER).map((h) => h.file));
    expect(reported.has(join("app", "page.js"))).toBe(false);
    expect(reported.has("middleware-manifest.json")).toBe(false);
  });

  it("調べる語には、鍵の名前そのものを入れない（サーバーの側には正しく入ります）", () => {
    for (const name of ["SUPABASE_SERVICE_ROLE_KEY", "STRIPE_SECRET_KEY", "ADMIN_EMAILS"]) {
      expect(FORBIDDEN_IN_PRERENDER, name).not.toContain(name);
    }
  });

  it("調べる語に、鍵の形とブラウザに届いてはいけない欄がそろっている", () => {
    for (const term of [
      "service_role",
      "sk_live_",
      "sk_test_",
      "whsec_",
      "priceEnvName",
      "stripeSubscriptionId",
      "stripe_subscription_id",
      "tokenHash",
      "token_hash",
    ]) {
      expect(FORBIDDEN_IN_PRERENDER, term).toContain(term);
    }
  });

  it("調べる入れ物が無いときは、何も報告しない", () => {
    expect(scanPrerender(join(prerender, "no-such-folder"), ["priceEnvName"])).toEqual([]);
  });

  it("実際に読んだ本数が数えられる（「1 本も読んでいない」を見分けるため）", () => {
    // 「調べて何も無かった」と「そもそも何も調べていない」は、報告の字では同じに見えます。
    // 呼ぶ側は、この本数が 0 のときに赤くしてお止めします。
    expect(prerenderFiles(prerender).length).toBeGreaterThan(0);
    expect(prerenderFiles(join(prerender, "no-such-folder"))).toEqual([]);
    // .js と .json は、ブラウザに届く形ではないので数えません
    for (const path of prerenderFiles(prerender)) {
      expect(PRERENDER_EXTENSIONS.some((extension) => path.endsWith(extension)), path).toBe(true);
    }
  });
});

describe("受け取ったお返事を調べる道具", () => {
  it("お返事の本文に語が出てきたら、その名前とあわせて報告する", () => {
    const bodies = [
      { name: "お返事 /app", text: `{"stripeSubscriptionId":"sub_1"}` },
      { name: "お返事 /", text: "<html>料金の表</html>" },
    ];
    expect(scanTexts(bodies, FORBIDDEN_IN_PRERENDER)).toEqual([
      { file: "お返事 /app", term: "stripeSubscriptionId" },
    ]);
  });

  it("目印の値も、同じ道具で調べられる", () => {
    const bodies = [{ name: "お返事 /login", text: `key=${CANARY_ENV.STRIPE_SECRET_KEY}` }];
    expect(scanTexts(bodies, [CANARY_ENV.STRIPE_SECRET_KEY])).toEqual([
      { file: "お返事 /login", term: CANARY_ENV.STRIPE_SECRET_KEY },
    ]);
  });

  it("お返事が 1 本も無いときは、何も報告しない（呼んだ側が赤くします）", () => {
    expect(scanTexts([], FORBIDDEN_IN_PRERENDER)).toEqual([]);
  });
});

describe("調べ終わったあとの合否", () => {
  const clean = { found: 0, scannedFiles: 56, scannedBodies: 8, notFetched: 0 };

  it("全部読めて、何も見つからなければ緑", () => {
    expect(verdict(clean).ok).toBe(true);
  });

  it("取れなかった画面が 1 本でもあれば赤（ログインの要る画面だけが黙って落ちても、緑にしない）", () => {
    const result = verdict({ ...clean, scannedBodies: 6, notFetched: 1 });
    expect(result.ok).toBe(false);
    expect(result.message).toContain("取れなかった画面が 1 本");
  });

  it("1 本も読めていなければ赤", () => {
    expect(verdict({ ...clean, scannedFiles: 0 }).ok).toBe(false);
    expect(verdict({ ...clean, scannedBodies: 0 }).ok).toBe(false);
  });

  it("語が見つかれば赤", () => {
    expect(verdict({ ...clean, found: 2 }).ok).toBe(false);
  });
});

describe("調べる語の一覧", () => {
  it("鍵の名前が、7 つともそろっている", () => {
    for (const name of [
      "SUPABASE_SERVICE_ROLE_KEY",
      "STRIPE_SECRET_KEY",
      "STRIPE_WEBHOOK_SECRET",
      "RESEND_API_KEY",
      "ADMIN_EMAILS",
      "STARTER_FAKE_ALLOW_PRODUCTION",
      "STRIPE_PRICE_",
    ]) {
      expect(FORBIDDEN_IN_CLIENT, name).toContain(name);
    }
  });

  it("鍵そのものの形も調べる", () => {
    for (const shape of ["service_role", "sk_live_", "sk_test_", "whsec_"]) {
      expect(FORBIDDEN_IN_CLIENT, shape).toContain(shape);
    }
  });

  it("サーバーの側だけで読み込む口の名前も調べる", () => {
    for (const marker of ["createServiceSupabase", "createStripeBilling", "createResendMail"]) {
      expect(FORBIDDEN_IN_CLIENT, marker).toContain(marker);
    }
  });

  it("料金の設定の内側（Price の環境変数の名前）も調べる", () => {
    expect(FORBIDDEN_IN_CLIENT).toContain("priceEnvName");
  });

  it("決済の API の版は、いまのつなぎ先と同じ字を調べている", () => {
    // 字を縮められても残る印として、文字列そのものを調べています。
    // SDK を上げて版を書き換えたときは、この一覧も一緒に直してください。
    const client = readFileSync(join(packageRoot, "src/adapters/stripe/client.ts"), "utf8");
    const version = /STRIPE_API_VERSION = "([^"]+)"/.exec(client)?.[1];
    expect(version).toBeDefined();
    expect(FORBIDDEN_IN_CLIENT).toContain(version);
  });

  it("目印の値は、調べる語の一覧とは別に持つ（組み立てのときだけ入れます）", () => {
    const canary = CANARY_ENV as Record<string, string | undefined>;
    for (const name of SECRET_ENV_NAMES) {
      expect(canary[name], name).toBeDefined();
    }
    // 目印は、どの値にも同じ字が入っています（1 語で調べられるようにするためです）
    for (const value of Object.values(CANARY_ENV)) {
      expect(value, value).toContain("BUNDLE_CANARY");
    }
  });
});

describe("鍵を読むファイルの守り", () => {
  type SourceFile = { path: string; text: string };

  function walk(dir: string, prefix: string, out: SourceFile[]): void {
    for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) =>
      a.name.localeCompare(b.name),
    )) {
      if (entry.isDirectory()) {
        walk(join(dir, entry.name), `${prefix}${entry.name}/`, out);
        continue;
      }
      if (!entry.name.endsWith(".ts") && !entry.name.endsWith(".tsx")) continue;
      out.push({
        path: `${prefix}${entry.name}`,
        text: readFileSync(join(dir, entry.name), "utf8"),
      });
    }
  }

  /** 覚え書き（コメント）を落とした中身です。名前が本文に出てくるかだけを見ます */
  function withoutComments(text: string): string {
    return text
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .split("\n")
      .filter((line) => !line.trimStart().startsWith("//"))
      .join("\n");
  }

  /** 根に置いてある、画面とサーバーの両方が読む設定のファイルです */
  function rootConfigFiles(): SourceFile[] {
    return readdirSync(packageRoot, { withFileTypes: true })
      .filter((entry) => entry.isFile() && entry.name.endsWith(".config.ts"))
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((entry) => ({
        path: entry.name,
        text: readFileSync(join(packageRoot, entry.name), "utf8"),
      }));
  }

  /**
   * 鍵の名前を書いてよい、共有の設定のファイルです。
   *
   * `plans.config.ts` は Price の環境変数の**名前**を持ちますが、値は読みません
   * （読むのは `src/server/ports.ts` の priceIdFor だけです）。
   * 画面もサーバーも読む設定なので、`server-only` は付けられません。
   * **除け者はこの 2 つだけ**で、ほかのファイルが増えたら赤くなります。
   */
  const SHARED_CONFIG_FILES: readonly string[] = ["legal.config.ts", "plans.config.ts"];

  it("鍵の名前を本文に書いているファイルは、すべて server-only から始まる", () => {
    // `src/` だけを歩いていたころは、`app/` と根の設定のファイルを 1 度も見ていませんでした
    // （画面の部品が process.env.STRIPE_SECRET_KEY を読んでも気づけませんでした）。
    const files: SourceFile[] = [...rootConfigFiles()];
    walk(join(packageRoot, "src"), "src/", files);
    walk(join(packageRoot, "app"), "app/", files);

    const offenders: string[] = [];
    for (const file of files) {
      if (SHARED_CONFIG_FILES.includes(file.path)) continue;

      const body = withoutComments(file.text);
      const used = SECRET_ENV_NAMES.filter((name: string) => body.includes(name));
      if (used.length === 0) continue;

      // 覚え書きを落としたあと、いちばん初めに書かれている行が import "server-only"; です
      const first = body.split("\n").find((line) => line.trim() !== "");
      if (first?.trim() !== 'import "server-only";') {
        offenders.push(`${file.path}: ${used.join(", ")}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it("歩いているのは src・app・根の設定で、除け者は 2 つだけ", () => {
    // 題と中身がそろっていることの番人です（歩く先が痩せたら、ここで気づけます）
    const files: SourceFile[] = [...rootConfigFiles()];
    walk(join(packageRoot, "src"), "src/", files);
    walk(join(packageRoot, "app"), "app/", files);

    const paths = files.map((file) => file.path);
    expect(paths).toContain("src/server/ports.ts");
    expect(paths).toContain("app/layout.tsx");
    expect(paths).toContain("plans.config.ts");
    expect(paths).toContain("legal.config.ts");
    expect(files.length).toBeGreaterThan(80);

    // 除け者の 2 つは、どちらも Price の環境変数の**名前**だけを持ちます
    for (const name of SHARED_CONFIG_FILES) {
      expect(paths, name).toContain(name);
    }
    expect(SHARED_CONFIG_FILES).toHaveLength(2);
  });

  it("鍵の名前の一覧が痩せていない", () => {
    expect(SECRET_ENV_NAMES.length).toBeGreaterThanOrEqual(8);
  });
});
