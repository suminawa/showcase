/**
 * 画面の決まりを、ブラウザを立てずに字面と組み立てだけで確かめます。
 *
 * ここで守っているのは、審査で見る 3 つの約束です。
 *   1. 依存の向き（app/ は src/adapters/ を直に見ない。クライアントの部品は src/server/ を持ち込まない）
 *   2. 判断の置き場所（権限と上限は flow にあり、Server Actions には無い）
 *   3. 画面の文はすべて messages にあり、日本語と英語がそろっている
 */
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { afterEach, describe, expect, it } from "vitest";
import type { BillingBanner } from "../src/core/billing-state";
import { messagesFor } from "../src/server/messages";
import type { ValidationCode } from "../src/core/validation";
import { FLOW_ERROR_CODES, flowFail, flowOk, toActionState } from "../src/server/context";
import { cookieSecure, isFakeMode } from "../src/server/ports";
import { DEFAULT_NEXT_PATH, loginPath } from "../src/server/urls";

const packageRoot = fileURLToPath(new URL("../", import.meta.url));
const appRoot = join(packageRoot, "app");

/** 入力の検査が返す符号（messages の error.<符号> と対になります） */
const VALIDATION_CODES: readonly ValidationCode[] = [
  "required",
  "too_long",
  "too_short",
  "bad_email",
  "bad_choice",
  "bad_id",
];

type SourceFile = { path: string; text: string };

function walk(dir: string, prefix: string, out: SourceFile[]): void {
  for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) =>
    a.name.localeCompare(b.name),
  )) {
    if (entry.isDirectory()) {
      walk(join(dir, entry.name), `${prefix}${entry.name}/`, out);
      continue;
    }
    if (!entry.name.endsWith(".ts") && !entry.name.endsWith(".tsx")) continue;
    out.push({
      path: `${prefix}${entry.name}`,
      text: readFileSync(join(dir, entry.name), "utf8"),
    });
  }
}

function sources(): SourceFile[] {
  const out: SourceFile[] = [];
  walk(appRoot, "", out);
  return out;
}

function read(relative: string): string {
  return readFileSync(join(packageRoot, relative), "utf8");
}

const ja = JSON.parse(read("messages/ja.json")) as Record<string, string>;
const en = JSON.parse(read("messages/en.json")) as Record<string, string>;

/** 設計書 §2-1 の 12 の道すじと、決済の通知の受け口 */
const ROUTES = [
  "app/page.tsx",
  "app/(auth)/login/page.tsx",
  "app/(auth)/signup/page.tsx",
  "app/auth/callback/route.ts",
  "app/api/stripe/webhook/route.ts",
  "app/onboarding/page.tsx",
  "app/app/page.tsx",
  "app/app/projects/page.tsx",
  "app/app/settings/profile/page.tsx",
  "app/app/settings/organization/page.tsx",
  "app/app/settings/billing/page.tsx",
  "app/invite/[token]/page.tsx",
  "app/fake/checkout/page.tsx",
  "app/legal/tokushoho/page.tsx",
  "app/legal/terms/page.tsx",
  "app/legal/privacy/page.tsx",
];

/** globals.css に置く、着せ替えのための変数 */
const TOKENS = [
  "--st-bg",
  "--st-surface",
  "--st-border",
  "--st-text",
  "--st-text-muted",
  "--st-accent",
  "--st-accent-text",
  "--st-ok",
  "--st-warn",
  "--st-danger",
  "--st-radius",
  "--st-gap",
  "--st-font",
];

describe("画面のファイルと決まり", () => {
  it("設計書の道すじが、すべてそろっている", () => {
    const missing = ROUTES.filter((route) => !existsSync(join(packageRoot, route)));
    expect(missing).toEqual([]);
  });

  it("dangerouslySetInnerHTML をどこにも書いていない", () => {
    const found = sources()
      .filter((file) => file.text.includes("dangerouslySetInnerHTML"))
      .map((file) => file.path);
    expect(found).toEqual([]);
  });

  it("app/ から src/adapters/ を直に読んでいない（合成の場所だけが知っています）", () => {
    const found = sources()
      .filter((file) => /from\s+"[^"]*src\/adapters/.test(file.text))
      .map((file) => file.path);
    expect(found).toEqual([]);
  });

  it("src/server/ から src/adapters/ を読むのは、合成の場所（ports.ts）だけ", () => {
    // つなぎ役を知っているのは合成の場所 1 つだけ、という約束です。
    // 共有したい値（本文の上限など）は、両方から見える src/ports/ に置きます。
    const files: SourceFile[] = [];
    walk(join(packageRoot, "src/server"), "", files);

    const found = files
      .filter((file) => file.path !== "ports.ts")
      .filter((file) => /from\s+"[^"]*adapters\//.test(file.text))
      .map((file) => file.path);
    expect(found).toEqual([]);
  });

  it("page.tsx・layout.tsx・route.ts はサーバーの部品のまま（use client を付けていない）", () => {
    const found = sources()
      .filter((file) => /\/(page|layout|route|not-found)\.tsx?$/.test(file.path))
      .filter((file) => file.text.includes('"use client"'))
      .map((file) => file.path);
    expect(found).toEqual([]);
  });

  it("クライアントの部品は、サーバーの module を持ち込まない（型だけは通します）", () => {
    // 型は書き出したあとに消えるので、束には入りません。値の import だけを止めます。
    const offenders: string[] = [];
    for (const file of sources()) {
      if (!file.text.startsWith('"use client"')) continue;
      for (const match of file.text.matchAll(/import\s+([^;]*?)from\s+"([^"]+)"/g)) {
        const [, clause, specifier] = match;
        if (!specifier.includes("src/server/")) continue;
        if (!clause.trimStart().startsWith("type ")) offenders.push(`${file.path}: ${specifier}`);
      }
    }
    expect(offenders).toEqual([]);
  });
});

describe("お支払いの画面", () => {
  const page = () => read("app/app/settings/billing/page.tsx");

  it("プランのボタンを出すかどうかは、flow の canStartCheckout だけで決める", () => {
    const text = page();
    expect(text).toContain("canStartCheckout");
    // ご契約が生きているかどうかの判定を、画面が自分で持たないための番人です
    expect(text).not.toContain("isLiveSubscription");
    expect(text).not.toMatch(/state\.status ===/);
    expect(text).toMatch(/canStartCheckout \? \(/);
  });

  it("ボタンをお出ししないときは、お支払いの管理へのご案内をお出しする", () => {
    expect(page()).toContain("billing.changeFromPortal");
    expect(ja["billing.changeFromPortal"]).toBeDefined();
    expect(en["billing.changeFromPortal"]).toBeDefined();
    // ご案内の先は、同じ画面にある「お支払いの管理」です
    expect(ja["billing.changeFromPortal"]).toContain(ja["billing.portal"]);
  });
});

describe("お支払いの帯", () => {
  /** 「何も出さない」以外の、すべての帯の種類です */
  const KINDS: readonly Exclude<BillingBanner, "none">[] = [
    "past_due",
    "unpaid",
    "canceled",
    "cancel_scheduled",
    "incomplete",
  ];

  /** 組み上がった画面の部品から、お出しする文だけを拾います */
  function textOf(node: unknown): string {
    if (typeof node === "string") return node;
    if (Array.isArray(node)) return node.map(textOf).join(" ");
    if (typeof node === "object" && node !== null && "props" in node) {
      return textOf((node as { props?: { children?: unknown } }).props?.children);
    }
    return "";
  }

  it("どの種類の帯も、日英の文をお出しできる", async () => {
    const { Banner } = await import("../app/_components/Banner");
    const messages = messagesFor("ja");

    for (const kind of KINDS) {
      expect(ja[`banner.${kind}`], kind).toBeDefined();
      expect(en[`banner.${kind}`], kind).toBeDefined();

      const shown = Banner({ banner: kind, messages });
      expect(shown, kind).not.toBeNull();
      expect(textOf(shown), kind).toContain(ja[`banner.${kind}`]);
    }
  });

  it("出す用のないときは、帯そのものを出さない", async () => {
    const { Banner } = await import("../app/_components/Banner");
    expect(Banner({ banner: "none", messages: messagesFor("ja") })).toBeNull();
  });
});

describe("組織の設定の画面", () => {
  it("カードの見出しが、中の欄の名前と重ならない", () => {
    // 見出しも欄の名前も「組織の名前」だと、同じ字が 2 つ並んで読みづらくなります
    const text = read("app/app/settings/organization/page.tsx");
    expect(text).toContain("organization.basicsTitle");
    expect(text).not.toContain("organization.nameTitle");

    for (const [lang, messages] of Object.entries({ ja, en })) {
      expect(messages["organization.basicsTitle"], lang).toBeDefined();
      expect(messages["organization.basicsTitle"], lang).not.toBe(
        messages["field.organizationName"],
      );
    }
    expect(ja["organization.basicsTitle"]).toBe("組織の基本情報");
  });
});

describe("ログインの受け口（/auth/callback）", () => {
  it("お戻りの誤りの符号は、URL に入れる前に escape する", () => {
    // 符号をそのまま字としてつなぐと、& や # が混じったときに
    // 行き先の URL が別の形に読まれてしまいます。
    expect(read("app/auth/callback/route.ts")).toMatch(
      /error=\$\{encodeURIComponent\(result\.code\)\}/,
    );
  });

  it("ログインが成り立たなかったときは、符号を添えてログインの画面へお戻しする", async () => {
    const env = process.env as Record<string, string | undefined>;
    const before = env.STARTER_FAKE;
    env.STARTER_FAKE = "1";

    try {
      const { GET } = await import("../app/auth/callback/route");
      const request = new Request("http://localhost:3020/auth/callback?next=%2Fapp%2Fprojects");

      await expect(GET(request)).rejects.toThrow("NEXT_REDIRECT");

      const thrown: unknown = await GET(request).catch((error: unknown) => error);
      const digest = (thrown as { digest?: string }).digest;
      expect(digest).toContain("/login?next=%2Fapp%2Fprojects&error=unavailable");
    } finally {
      if (before === undefined) delete env.STARTER_FAKE;
      else env.STARTER_FAKE = before;
    }
  });
});

describe("誤りの画面（app/error.tsx）", () => {
  const text = () => read("app/error.tsx");

  it("画面の文を丸ごとブラウザにお渡ししない（小さな辞書だけを読む）", () => {
    // error.tsx は Next の決まりでクライアントの部品です。
    // ここで messages/ja.json と en.json を読むと、約 8KB の文がすべて束に入ります。
    expect(text()).not.toMatch(/from "@\/messages\/(ja|en)\.json"/);
    expect(text()).toMatch(/error-page\.ja\.json/);
    expect(text()).toMatch(/error-page\.en\.json/);
  });

  it("小さな辞書の文が、messages の文と同じ（ずれの番人）", () => {
    const small = {
      ja: JSON.parse(read("messages/error-page.ja.json")) as Record<string, string>,
      en: JSON.parse(read("messages/error-page.en.json")) as Record<string, string>,
    };

    expect(Object.keys(small.ja).sort()).toEqual(Object.keys(small.en).sort());
    expect(Object.keys(small.ja).length).toBeGreaterThan(0);

    for (const [key, value] of Object.entries(small.ja)) expect(ja[key], key).toBe(value);
    for (const [key, value] of Object.entries(small.en)) expect(en[key], key).toBe(value);

    // 誤りの画面が使う鍵は、すべて小さな辞書に入っています
    for (const match of text().matchAll(/t\(\s*messages\s*,\s*"([^"]+)"/g)) {
      expect(small.ja[match[1]], match[1]).toBeDefined();
    }
  });
});

describe("cookie の属性", () => {
  const env = process.env as Record<string, string | undefined>;
  const before = {
    NEXT_PUBLIC_SITE_URL: env.NEXT_PUBLIC_SITE_URL,
    NODE_ENV: env.NODE_ENV,
  };

  afterEach(() => {
    for (const [name, value] of Object.entries(before)) {
      if (value === undefined) delete env[name];
      else env[name] = value;
    }
  });

  it("secure は、https でお使いのときと、本番のときに付ける", () => {
    // お手元でお試しのあいだ（http）は、付けると cookie が届かなくなります
    env.NEXT_PUBLIC_SITE_URL = "http://localhost:3020";
    env.NODE_ENV = "development";
    expect(cookieSecure()).toBe(false);

    env.NEXT_PUBLIC_SITE_URL = "https://app.example.com";
    expect(cookieSecure()).toBe(true);

    // 本番では、NEXT_PUBLIC_SITE_URL をまだお書きでなくても付けます
    // （中継の内側で http のまま動かしていることがあるためです）
    env.NEXT_PUBLIC_SITE_URL = "http://app.example.com";
    env.NODE_ENV = "production";
    expect(cookieSecure()).toBe(true);

    delete env.NEXT_PUBLIC_SITE_URL;
    expect(cookieSecure()).toBe(true);
  });
});

describe("画面の関門", () => {
  const ports = () => read("src/server/ports.ts");

  it("1 回のお申し付けの中では、関門が 1 度だけ走る（React の cache で包む）", () => {
    // /app 以下は、枠（layout）と画面（page）がそれぞれ自分で関門を通ります。
    // 守りの形はそのままに、同じお申し付けの中では
    // auth.getUser() と memberships の読み取りが 1 度で済むようにしています。
    const text = ports();
    expect(text).toMatch(/import \{ cache \} from "react";/);
    expect(text).toMatch(/export const appGate = cache\(/);
  });

  it("各画面が自分で関門を通る形は、そのまま", () => {
    // 枠（layout）から画面（page）へ答えを渡す形にはしません。
    // 画面だけを直に開かれたときにも、必ず関門を通るようにするためです。
    const offenders: string[] = [];
    for (const path of [
      "app/app/layout.tsx",
      "app/app/page.tsx",
      "app/app/projects/page.tsx",
      "app/app/settings/profile/page.tsx",
      "app/app/settings/organization/page.tsx",
      "app/app/settings/billing/page.tsx",
    ]) {
      if (!read(path).includes("appGate()")) offenders.push(path);
    }
    expect(offenders).toEqual([]);
  });
});

describe("Server Actions", () => {
  function actionFiles(): SourceFile[] {
    return sources().filter((file) => file.path.startsWith("_actions/"));
  }

  it("7 つのファイルが、すべて use server で始まっている", () => {
    const files = actionFiles();
    expect(files.map((file) => file.path)).toEqual([
      "_actions/auth.ts",
      "_actions/billing.ts",
      "_actions/invitations.ts",
      "_actions/members.ts",
      "_actions/organizations.ts",
      "_actions/profile.ts",
      "_actions/projects.ts",
    ]);
    for (const file of files) {
      expect(file.text.startsWith('"use server";'), file.path).toBe(true);
    }
  });

  it("権限と上限の判断が、Server Actions に書かれていない（判断は flow にあります）", () => {
    const banned = ["ctx.role ===", "PERMISSION_MATRIX", "canCreateProject", "isLiveSubscription"];
    const offenders: string[] = [];
    for (const file of actionFiles()) {
      for (const word of banned) {
        if (file.text.includes(word)) offenders.push(`${file.path}: ${word}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it("FormData の値を as で型に当てていない（検査は flow の validation です）", () => {
    const offenders = actionFiles()
      .filter((file) => /form\.get\([^)]*\)\s+as\s/.test(file.text))
      .map((file) => file.path);
    expect(offenders).toEqual([]);
  });
});

describe("配色と動き", () => {
  const css = read("app/globals.css");

  function block(startsWith: string): string {
    const at = css.indexOf(startsWith);
    expect(at, startsWith).toBeGreaterThan(-1);
    const from = css.indexOf("{", at);
    let depth = 0;
    for (let i = from; i < css.length; i += 1) {
      if (css[i] === "{") depth += 1;
      if (css[i] === "}") {
        depth -= 1;
        if (depth === 0) return css.slice(from, i);
      }
    }
    throw new Error(`${startsWith} の { } が閉じていません`);
  }

  it("明るい配色に、13 の変数がすべてある", () => {
    const light = block(":root {");
    const missing = TOKENS.filter((token) => !light.includes(`${token}:`));
    expect(missing).toEqual([]);
  });

  it("暗い配色にも、同じ 13 の変数がある", () => {
    const dark = block("@media (prefers-color-scheme: dark)");
    const missing = TOKENS.filter((token) => !dark.includes(`${token}:`));
    expect(missing).toEqual([]);
  });

  it("手で選んだ暗い配色（data-st-theme）にも、同じ 13 の変数がある", () => {
    const dark = block('[data-st-theme="dark"] {');
    const missing = TOKENS.filter((token) => !dark.includes(`${token}:`));
    expect(missing).toEqual([]);
  });

  it("動きを控えたいご希望に合わせる節がある", () => {
    expect(css).toContain("prefers-reduced-motion: reduce");
  });

  it("フォーカスの輪を消していない", () => {
    expect(css).toContain(":focus-visible");
    expect(css).not.toMatch(/outline:\s*(none|0)\s*;/);
  });
});

describe("画面の文", () => {
  /** app/ の中で t(messages, "…") と書かれている鍵を、そのまま拾います */
  function usedKeys(): string[] {
    const keys = new Set<string>();
    for (const file of sources()) {
      for (const match of file.text.matchAll(/\bt\(\s*messages\s*,\s*"([^"]+)"/g)) {
        keys.add(match[1]);
      }
    }
    return [...keys].sort();
  }

  it("画面が使う鍵が、日本語の文にすべてある", () => {
    const missing = usedKeys().filter((key) => ja[key] === undefined);
    expect(missing).toEqual([]);
  });

  it("画面が使う鍵が、英語の文にもすべてある", () => {
    const missing = usedKeys().filter((key) => en[key] === undefined);
    expect(missing).toEqual([]);
  });

  it("画面の部品に、日本語を直に書いていない", () => {
    const offenders: string[] = [];
    for (const file of sources()) {
      const withoutComments = file.text
        .replace(/\/\*[\s\S]*?\*\//g, "")
        .split("\n")
        .filter((line) => !line.trimStart().startsWith("//"))
        .join("\n");
      if (/[ぁ-んァ-ン一-龥]/.test(withoutComments)) offenders.push(file.path);
    }
    expect(offenders).toEqual([]);
  });

  it("Server Actions がお返しする鍵も、日英の文がそろっている", () => {
    const keys = new Set<string>();
    for (const file of sources()) {
      if (!file.path.startsWith("_actions/")) continue;
      for (const match of file.text.matchAll(/toActionState\([^,)]+,\s*"([^"]+)"/g)) {
        keys.add(match[1]);
      }
      for (const match of file.text.matchAll(/messageKey:\s*"([^"]+)"/g)) {
        keys.add(match[1]);
      }
    }

    expect(keys.size).toBeGreaterThan(8);
    for (const key of keys) {
      expect(ja[key], key).toBeDefined();
      expect(en[key], key).toBeDefined();
    }
  });

  it("誤りの符号が、すべて error.<符号> の鍵になり、日英の文がそろっている", () => {
    for (const code of FLOW_ERROR_CODES) {
      const state = toActionState(flowFail(code));
      expect(state, code).toEqual({ status: "error", messageKey: `error.${code}` });
      expect(ja[`error.${code}`], code).toBeDefined();
      expect(en[`error.${code}`], code).toBeDefined();
    }
  });

  it("入力の誤りも、error.<符号> の鍵で日英の文がそろっている", () => {
    for (const code of VALIDATION_CODES) {
      expect(ja[`error.${code}`], code).toBeDefined();
      expect(en[`error.${code}`], code).toBeDefined();
    }
  });
});

describe("toActionState", () => {
  it("うまくいったときは、お伝えする文の鍵を添える", () => {
    expect(toActionState(flowOk({ id: "st-projects-1" }), "project.created")).toEqual({
      status: "ok",
      messageKey: "project.created",
    });
  });

  it("お伝えする文が無いときは、鍵を添えない", () => {
    expect(toActionState(flowOk(null))).toEqual({ status: "ok" });
  });

  it("入力の誤りは、どの欄のことかを持ち回る", () => {
    const errors = [{ field: "email", code: "bad_email" } as const];
    expect(toActionState(flowFail("invalid", errors))).toEqual({
      status: "error",
      messageKey: "error.invalid",
      errors,
    });
  });
});

describe("お預かりした値（誤りでお戻しするとき）", () => {
  function formOf(entries: Record<string, string>): FormData {
    const form = new FormData();
    for (const [name, value] of Object.entries(entries)) form.append(name, value);
    return form;
  }

  it("お書きいただいた内容を、そのままお返しする", () => {
    // React は、送信のあとに入力の欄を初めの値に戻します。
    // 誤りでお戻しするときまで戻ってしまうと、長いお覚え書きを書き直していただくことになります。
    const form = formOf({ name: "", note: "長いお覚え書きです" });
    const state = toActionState(
      flowFail("invalid", [{ field: "name", code: "required" }]),
      undefined,
      form,
    );

    expect(state).toEqual({
      status: "error",
      messageKey: "error.invalid",
      errors: [{ field: "name", code: "required" }],
      // 空にしてお送りになった欄は、空のままお返しします
      values: { name: "", note: "長いお覚え書きです" },
    });
  });

  it("合言葉とトークンは、お預かりした値に入れない", () => {
    const form = formOf({
      email: "owner@example.com",
      password: "very-secret-pass",
      newPassword: "another-secret",
      token: "invitation-token",
      csrfToken: "abc",
    });

    const state = toActionState(flowFail("bad_credentials"), undefined, form);
    expect(state.status === "error" ? state.values : null).toEqual({
      email: "owner@example.com",
    });
  });

  it("うまくいったときは、値を持ち帰らない（欄は気持ちよく空に戻ります）", () => {
    const state = toActionState(flowOk(null), "project.created", formOf({ name: "新しい試み" }));
    expect(state).toEqual({ status: "ok", messageKey: "project.created" });
  });

  it("お預かりする値が無いときは、values を付けない", () => {
    expect(toActionState(flowFail("forbidden"))).toEqual({
      status: "error",
      messageKey: "error.forbidden",
    });
    expect(toActionState(flowFail("forbidden"), undefined, new FormData())).toEqual({
      status: "error",
      messageKey: "error.forbidden",
    });
  });

  it("入力の欄は、お預かりした値があればそちらを初めの値にする", () => {
    // 1 か所（Field）の直しで、すべてのフォームに効きます
    const text = read("app/_components/Field.tsx");
    expect(text).toMatch(/state\.values\?\.\[props\.name\]/);
    expect(text).toMatch(/kept \?\? props\.defaultValue/);
  });

  it("値を受け取るお申し付けは、誤りのお返事に form を添えている", () => {
    const offenders: string[] = [];
    for (const file of sources()) {
      if (!file.path.startsWith("_actions/")) continue;

      for (const block of file.text.split(/export async function /).slice(1)) {
        const name = block.slice(0, Math.max(0, block.indexOf("(")));
        // 欄のないお申し付け（_form）は、お預かりする値がありません
        if (!/\bform: FormData\b/.test(block)) continue;

        for (const call of block.match(/toActionState\([^)]*\)/g) ?? []) {
          if (!call.endsWith(", form)")) offenders.push(`${file.path} ${name}: ${call}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });
});

describe("ログインの画面への行き先", () => {
  it("同じサイトの中の行き先は、そのままお預かりする", () => {
    expect(loginPath("/app/projects")).toBe("/login?next=%2Fapp%2Fprojects");
  });

  it("外のサイトを指す行き先は、お預かりしない", () => {
    expect(loginPath("//example.com/")).toBe("/login");
    expect(loginPath("https://example.com/")).toBe("/login");
  });

  it("行き先が無いときは、そのままログインの画面へ", () => {
    expect(loginPath()).toBe("/login");
    expect(DEFAULT_NEXT_PATH).toBe("/app");
  });
});

describe("見本の画面（STARTER_FAKE=1 のときだけ）", () => {
  // NODE_ENV は型の上では読むだけの値なので、差し替えるあいだだけこの形で触ります
  const env = process.env as Record<string, string | undefined>;
  const before = {
    STARTER_FAKE: env.STARTER_FAKE,
    STARTER_FAKE_ALLOW_PRODUCTION: env.STARTER_FAKE_ALLOW_PRODUCTION,
    NODE_ENV: env.NODE_ENV,
  };

  /** 本番で動いているふりをします（Next は NODE_ENV でその区別をしています） */
  function pretendProduction(): void {
    env.NODE_ENV = "production";
  }

  afterEach(() => {
    for (const [name, value] of Object.entries(before)) {
      if (value === undefined) delete env[name];
      else env[name] = value;
    }
  });

  it("STARTER_FAKE が 1 のときだけ、見本のしくみを使う", () => {
    env.STARTER_FAKE = "1";
    expect(isFakeMode()).toBe(true);

    process.env.STARTER_FAKE = "0";
    expect(isFakeMode()).toBe(false);

    delete process.env.STARTER_FAKE;
    expect(isFakeMode()).toBe(false);
  });

  it("見本のログインと偽のお支払いの画面は、本番では見つからないお返事をする", () => {
    for (const route of ["app/fake/checkout/page.tsx", "app/(auth)/login/page.tsx"]) {
      const text = read(route);
      expect(text, route).toContain("isFakeMode()");
    }
    expect(read("app/fake/checkout/page.tsx")).toContain("notFound()");
  });

  it("見本の方へのログインは、本番では入り口ごと閉じている", async () => {
    delete process.env.STARTER_FAKE;
    const { fakeSignInAs } = await import("../src/server/ports");
    await expect(fakeSignInAs("u-owner")).rejects.toThrow();
  });

  it("本番では、STARTER_FAKE=1 だけで見本のしくみに入らない", () => {
    // 見本モードでは、訪れた方全員が同じ見本の方として入り、同じ中身をご覧になります。
    // 公開の場所でそのまま動くと、お客さまのデータが混ざって見えてしまいます。
    env.STARTER_FAKE = "1";
    pretendProduction();
    delete env.STARTER_FAKE_ALLOW_PRODUCTION;
    expect(isFakeMode()).toBe(false);

    // 承知のうえでお試しになるときだけ、もう 1 つの変数でお開けになれます
    env.STARTER_FAKE_ALLOW_PRODUCTION = "1";
    expect(isFakeMode()).toBe(true);

    env.STARTER_FAKE_ALLOW_PRODUCTION = "0";
    expect(isFakeMode()).toBe(false);
  });

  it("本番では、見本のしくみの 3 つの入り口が通らない", async () => {
    env.STARTER_FAKE = "1";
    pretendProduction();
    delete env.STARTER_FAKE_ALLOW_PRODUCTION;

    const { fakeCancelSubscription, fakeCompleteCheckout, fakeSignInAs } = await import(
      "../src/server/ports"
    );
    const now = new Date("2026-09-20T00:00:00.000Z");

    await expect(fakeSignInAs("u-owner")).rejects.toThrow();
    await expect(
      fakeCompleteCheckout({ organizationId: "org-1", planId: "standard", now }),
    ).rejects.toThrow();
    await expect(fakeCancelSubscription({ organizationId: "org-1", now })).rejects.toThrow();
  });

  it("本番では、偽のお支払いの画面が「見つかりません」をお返しする", async () => {
    env.STARTER_FAKE = "1";
    pretendProduction();
    delete env.STARTER_FAKE_ALLOW_PRODUCTION;

    const { default: FakeCheckoutPage } = await import("../app/fake/checkout/page");
    await expect(
      FakeCheckoutPage({ searchParams: Promise.resolve({ plan: "standard" }) }),
    ).rejects.toThrow("NEXT_HTTP_ERROR_FALLBACK;404");
  });

  it("鍵が無いときのお知らせが、.env.example と本番の決まりにも触れている", async () => {
    env.STARTER_FAKE = "1";
    pretendProduction();
    delete env.STARTER_FAKE_ALLOW_PRODUCTION;

    const { getPorts } = await import("../src/server/ports");
    await expect(getPorts()).rejects.toThrow(/\.env\.example/);
    await expect(getPorts()).rejects.toThrow(/本番/);
  });

  it(".env.example に、本番でお開けになるときの変数と注意がある", () => {
    const text = read(".env.example");
    expect(text).toContain("STARTER_FAKE_ALLOW_PRODUCTION=");
    expect(text).toContain("公開の場所ではお使いにならないでください");
  });
});
