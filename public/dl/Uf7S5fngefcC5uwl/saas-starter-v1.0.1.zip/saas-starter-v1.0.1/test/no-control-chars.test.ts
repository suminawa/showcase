/**
 * 配布するファイルに、生の制御文字が 1 つも入っていないことを確かめます。
 *
 * 制御文字（NUL など）がそのままファイルに入っていると、
 *   ・git が「文字のファイル」ではなく「中身の分からないファイル」として扱い、
 *     差分が出なくなります（審査で中身を確かめられません）
 *   ・エディタや端末によっては見えず、書き換えのときに黙って落ちます
 * ということが起きます。
 *
 * 制御文字を表したいときは、**エスケープの表記**（\u0000 の形）でお書きください。
 * 許すのは、ふつうの文字として使う TAB・改行・復帰だけです。
 */
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { releaseFileList } from "../scripts/release.mjs";

const packageRoot = fileURLToPath(new URL("../", import.meta.url));

/**
 * 見に行く先は、**配る zip に入る一覧そのもの**です。
 *
 * 作業中のフォルダ全体を歩いていたころは、お客さまが `public/` に動画や書体を
 * 置かれると、種類の一覧に無いというだけで赤くなっていました。
 * 配るものだけを見れば、その取り違えは起きません。
 */
const SKIP_EXTENSIONS: readonly string[] = [
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".ico",
  ".webp",
  ".avif",
  ".woff",
  ".woff2",
  ".ttf",
  ".otf",
  ".zip",
  ".pdf",
  ".mp4",
  ".webm",
  ".mp3",
  ".wasm",
];

/** 生の制御文字かどうか（TAB・改行・復帰だけは、ふつうの文字として通します） */
function isControlByte(byte: number): boolean {
  return byte < 9 || (byte > 13 && byte < 32) || byte === 127;
}

function textFiles(): string[] {
  return releaseFileList(packageRoot).filter(
    (relative) => !SKIP_EXTENSIONS.some((extension) => relative.endsWith(extension)),
  );
}

/** 1 つのファイルの中の、生の制御文字の在り処です */
function offendersIn(relative: string): string[] {
  const bytes = readFileSync(join(packageRoot, relative));
  const out: string[] = [];

  for (const [index, byte] of bytes.entries()) {
    if (!isControlByte(byte)) continue;
    const code = byte.toString(16).padStart(4, "0");
    out.push(`${relative}: ${index} バイト目に \\u${code}`);
  }
  return out;
}

describe("生の制御文字", () => {
  it("見に行く先に、配布するファイルが並んでいる", () => {
    const files = textFiles();
    // 見落としの番人です（除外を書きすぎて、何も見ていない形になっていないか）
    expect(files.length).toBeGreaterThan(100);
    for (const name of ["package.json", "src/adapters/mail/safety.ts", "legal/terms.ja.txt"]) {
      expect(files, name).toContain(name);
    }
  });

  it("制御文字の見分け方（TAB・改行・復帰だけを通す）", () => {
    for (const allowed of [9, 10, 13, 32, 65]) expect(isControlByte(allowed), `${allowed}`).toBe(false);
    for (const rejected of [0, 1, 8, 27, 31, 127]) expect(isControlByte(rejected), `${rejected}`).toBe(true);
  });

  it("どのファイルにも、生の制御文字が入っていない", () => {
    const offenders = textFiles().flatMap((relative) => offendersIn(relative));
    expect(offenders).toEqual([]);
  });
});
