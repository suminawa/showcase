import { beforeEach, describe, expect, it } from "vitest";
import type { Ports } from "../../src/ports";
import { createFakePorts } from "../../src/adapters/fake";
import { FakeAuth } from "../../src/adapters/fake/auth";
import type { FakeStore } from "../../src/adapters/fake/store";

describe("FakeStore と fake adapter（seedDemo 済み）", () => {
  let ports: Ports & { store: FakeStore };

  beforeEach(() => {
    ports = createFakePorts();
  });

  it("1. listOrganizationsForUser がロールつきで、その方の組織だけを返す", async () => {
    const forOwner = await ports.data.listOrganizationsForUser("u-owner");
    expect(forOwner).toHaveLength(1);
    expect(forOwner[0]?.organization.name).toBe("しおさい設計室");
    expect(forOwner[0]?.role).toBe("owner");

    const forAdmin = await ports.data.listOrganizationsForUser("u-admin");
    expect(forAdmin).toHaveLength(2);
    expect(forAdmin.map((x) => [x.organization.name, x.role])).toEqual([
      ["しおさい設計室", "admin"],
      ["なぎさ工房", "owner"],
    ]);
  });

  it("2. countOwners が 1、listMembers が createdAt の古い順で 3 件", async () => {
    expect(await ports.data.countOwners("org-1")).toBe(1);
    const members = await ports.data.listMembers("org-1");
    expect(members).toHaveLength(3);
    expect(members.map((m) => m.userId)).toEqual(["u-owner", "u-admin", "u-member"]);
  });

  it("3. createProject のあと listProjects/countProjects が増え、組織をまたいで getProject できない", async () => {
    const created = await ports.data.createProject({
      organizationId: "org-1",
      name: "新規のご相談",
      note: "問い合わせフォームから届いた案件です。",
      createdBy: "u-owner",
    });
    expect(await ports.data.listProjects("org-1")).toHaveLength(3);
    expect(await ports.data.countProjects("org-1")).toBe(3);
    expect(await ports.data.getProject("org-2", created.id)).toBeNull();
  });

  it("4. 組織をまたいだ deleteProject は無視される", async () => {
    const [firstOfOrg1] = await ports.data.listProjects("org-1");
    await ports.data.deleteProject("org-2", firstOfOrg1!.id);
    expect(await ports.data.listProjects("org-1")).toHaveLength(2);
  });

  it("5. createInvitation → findInvitationByHash で見つかり、revokePendingInvitations で revoked になる", async () => {
    const created = await ports.data.createInvitation({
      organizationId: "org-1",
      email: "new@example.com",
      role: "member",
      tokenHash: "a".repeat(64),
      expiresAt: "2026-09-27T00:00:00.000Z",
      invitedBy: "u-owner",
    });
    expect(await ports.data.findInvitationByHash("a".repeat(64))).toEqual(created);

    expect(await ports.data.revokePendingInvitations("org-1", "new@example.com")).toBe(1);
    const after = await ports.data.findInvitationByHash("a".repeat(64));
    expect(after?.status).toBe("revoked");
  });

  it("6. markInvitationAccepted のあと status が accepted、acceptedBy が入る", async () => {
    const created = await ports.data.createInvitation({
      organizationId: "org-1",
      email: "new2@example.com",
      role: "member",
      tokenHash: "b".repeat(64),
      expiresAt: "2026-09-27T00:00:00.000Z",
      invitedBy: "u-owner",
    });
    await ports.data.markInvitationAccepted(created.id, "u-newbie");
    const after = await ports.data.findInvitationByHash("b".repeat(64));
    expect(after?.status).toBe("accepted");
    expect(after?.acceptedBy).toBe("u-newbie");
  });

  it("7. recordStripeEvent は 1 回目 true、2 回目 false（二重処理を止める）", async () => {
    const first = await ports.data.recordStripeEvent({
      id: "evt_1",
      type: "checkout.session.completed",
      receivedAt: "2026-09-20T00:00:00.000Z",
    });
    const second = await ports.data.recordStripeEvent({
      id: "evt_1",
      type: "checkout.session.completed",
      receivedAt: "2026-09-20T00:00:01.000Z",
    });
    expect(first).toBe(true);
    expect(second).toBe(false);
  });

  it("8. upsertSubscription → getSubscription が同じ行。2 回 upsert しても 1 行のまま", async () => {
    const row = {
      organizationId: "org-1",
      planId: "standard" as const,
      status: "active" as const,
      stripeSubscriptionId: "sub_1",
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: "2026-09-20T00:00:00.000Z",
    };
    await ports.data.upsertSubscription(row);
    await ports.data.upsertSubscription({ ...row, status: "past_due", updatedAt: "2026-09-21T00:00:00.000Z" });

    expect(await ports.data.getSubscription("org-1")).toEqual({
      ...row,
      status: "past_due",
      updatedAt: "2026-09-21T00:00:00.000Z",
    });
  });

  it("9. setStripeCustomer → findOrganizationByStripeCustomer。知らない id は null", async () => {
    await ports.data.setStripeCustomer("org-1", "cus_1");
    expect(await ports.data.findOrganizationByStripeCustomer("cus_1")).toBe("org-1");
    expect(await ports.data.findOrganizationByStripeCustomer("cus_unknown")).toBeNull();
  });

  it("10. removeMember のあと listMembers が 2 件、getMembership が null", async () => {
    await ports.data.removeMember("org-1", "u-member");
    expect(await ports.data.listMembers("org-1")).toHaveLength(2);
    expect(await ports.data.getMembership("org-1", "u-member")).toBeNull();
  });

  it("11. deleteOrganization のあと、プロジェクト・契約・メンバー・招待がすべて消えている", async () => {
    await ports.data.upsertSubscription({
      organizationId: "org-1",
      planId: "free",
      status: "active",
      stripeSubscriptionId: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: false,
      updatedAt: "2026-09-20T00:00:00.000Z",
    });

    await ports.data.createInvitation({
      organizationId: "org-1",
      email: "new-member@example.com",
      role: "member",
      tokenHash: "a".repeat(64),
      invitedBy: "u-owner",
      expiresAt: "2026-09-27T00:00:00.000Z",
    });
    expect(await ports.data.listInvitations("org-1")).toHaveLength(1);

    await ports.data.deleteOrganization("org-1");

    expect(await ports.data.listProjects("org-1")).toHaveLength(0);
    expect(await ports.data.getSubscription("org-1")).toBeNull();
    expect(await ports.data.listMembers("org-1")).toHaveLength(0);
    expect(await ports.data.listInvitations("org-1")).toHaveLength(0);
    // ほかの組織は巻き込まれない
    expect((await ports.data.listMembers("org-2")).length).toBeGreaterThan(0);
  });

  it("12. FakeAuth.signInAs で見本の人を選び、getUser が返す。signOut のあとは null", async () => {
    const auth = new FakeAuth(ports.store);
    auth.signInAs("u-member");
    expect(await auth.getUser()).toEqual({
      id: "u-member",
      email: "member@example.com",
      name: "なぎさ 健",
      lang: "ja",
    });
    await auth.signOut();
    expect(await auth.getUser()).toBeNull();
  });

  it("13. FakeMail.send が store.mails に積まれ、{ ok: true } を返す", async () => {
    const result = await ports.mail.send({
      to: "member@example.com",
      subject: "お知らせ",
      text: "本文です。",
      lang: "ja",
    });
    expect(result).toEqual({ ok: true });
    expect(ports.store.mails).toEqual([
      { to: "member@example.com", subject: "お知らせ", text: "本文です。", lang: "ja" },
    ]);
  });

  it("14. adminListOrganizations が 2 件、memberCount が 3 と 1", async () => {
    const rows = await ports.data.adminListOrganizations(10, 0);
    expect(rows).toHaveLength(2);
    expect(rows.map((r) => r.memberCount)).toEqual([3, 1]);
  });
});
