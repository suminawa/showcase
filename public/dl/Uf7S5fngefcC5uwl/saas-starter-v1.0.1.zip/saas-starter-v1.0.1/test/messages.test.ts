import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { LEGAL } from "../legal.config";
import { FLOW_ERROR_CODES } from "../src/server/context";

const ja = JSON.parse(readFileSync(new URL("../messages/ja.json", import.meta.url), "utf8"));
const en = JSON.parse(readFileSync(new URL("../messages/en.json", import.meta.url), "utf8"));

/** 画面・メール・法務の帯で、必ず要る鍵です */
const REQUIRED = [
  "invite.sentMail",
  "invite.sentLink",
  "invite.mailFailed",
  "mail.invite.subject",
  "mail.invite.body",
  "legal.tokushoho.title",
  "legal.terms.title",
  "legal.privacy.title",
  "legal.updatedOn",
  "legal.blank",
  "legal.missingTitle",
  "legal.missingHint",
  "legal.navLabel",
  "legal.toHome",
];

/**
 * 審査で決まった日本語の文です。
 *
 * どれも「何が起きたか」だけで終わらず、「次にどうすればよいか」まで書きます。
 * もとの短い文に戻すと、ここで落ちます。
 */
const DECIDED_JA: Readonly<Record<string, string>> = {
  "error.required": "ご入力ください。",
  "nav.signout": "ログアウト",
  "error.forbidden":
    "こちらの操作は、権限をお持ちの方のみ行えます。組織のオーナーまたは管理者の方にご依頼ください。",
  "error.last_owner":
    "組織には、オーナーが 1 名以上必要です。ほかの方をオーナーにしてから、もう一度お試しください。",
  "error.billing_no_customer":
    "お支払いのご契約が見つかりませんでした。お手数ですが、「お支払い」からもう一度お申し込みください。",
  "error.rate_limited":
    "お手続きの回数が上限に達しました。しばらく時間をおいてから、もう一度お試しください。",
  "error.no_change": "すでに同じ内容が設定されています。",
  "error.invite_used":
    "この招待リンクは、すでに使われています。お手数ですが、招待してくださった方に、もう一度お送りいただくようご依頼ください。",
  "auth.demo.hint": "接続の設定がお済みでないあいだは、見本の方を選んでお入りいただけます。",
  "home.title": "組織のプロジェクトを、ひとつの場所で",
  "project.creatorLeft": "組織を抜けられた方",
};

/** 敬体の閉じ方です（この形で終わっていない文は、会社がお客さまに向けて書く文ではありません） */
const POLITE = /(です|ます|ました|ません|ませんでした|ください|でした|ましょう|ございます)。$/;

/**
 * 「。」で終わる文を、値の中からすべて取り出します。
 *
 * 値には、1 つの中に何文も入っているもの（誤りのご案内）と、
 * 行を分けて書くもの（メールの本文。最後は署名で、「。」では終わりません）があります。
 * 末尾の 1 文だけを見ていると、途中の常体も、メールの本文も素通りします。
 */
function sentences(value: string): string[] {
  return value
    .split("\n")
    .flatMap((line) => line.split("。").slice(0, -1).map((part) => `${part}。`));
}

describe("messages", () => {
  it("ja と en の鍵がそろっている", () => {
    expect(Object.keys(ja).sort()).toEqual(Object.keys(en).sort());
  });

  it("鍵が減っていない（画面の文を消してしまっていないかの番人）", () => {
    expect(Object.keys(ja).length).toBeGreaterThanOrEqual(239);
    expect(Object.keys(en).length).toBeGreaterThanOrEqual(239);
  });

  it("画面のサービス名が、法務の設定のサービス名とそろっている", () => {
    // サービスの名前は 4 か所にあります（README 9 章の 0 番）。
    // ここだけをお直しになると、画面は新しい名前・法務のページとご招待のメールは
    // 古い名前になり、**どの検査も気づけません**。
    // 英語は別のお名前をお使いになることがあるので、日本語だけを突き合わせます。
    expect(ja["common.appName"]).toBe(LEGAL.serviceName);
  });

  it("メールと法務の鍵が、日英ともそろっている", () => {
    for (const key of REQUIRED) {
      expect(ja[key], key).toBeDefined();
      expect(en[key], key).toBeDefined();
    }
  });
  it("flow の誤りの符号に、日英の文がそろっている", () => {
    for (const code of FLOW_ERROR_CODES) {
      expect(ja[`error.${code}`], code).toBeDefined();
      expect(en[`error.${code}`], code).toBeDefined();
    }
  });
  it("空の文が無い", () => {
    for (const [key, value] of Object.entries<string>(ja)) expect(value.trim(), key).not.toBe("");
    for (const [key, value] of Object.entries<string>(en)) expect(value.trim(), key).not.toBe("");
  });
  it("同じ鍵の差し込みの変数がそろっている", () => {
    const vars = (s: string) => (s.match(/\{[a-zA-Z]+\}/g) ?? []).sort();
    for (const key of Object.keys(ja)) expect(vars(en[key]), key).toEqual(vars(ja[key]));
  });
  it("文の切り出しは、改行をまたいでも 1 文ずつになる", () => {
    expect(sentences("あります。いたします。\nお送りします。{serviceName}")).toEqual([
      "あります。",
      "いたします。",
      "お送りします。",
    ]);
  });

  it("値の途中の常体を、見逃さない（末尾の 1 文だけを見ていたころは通していました）", () => {
    const value = "すでにその状態になっている。もう一度お試しください。";
    // 末尾だけを見る検査では、この値は通ってしまいます
    expect(POLITE.test(value)).toBe(true);
    expect(sentences(value).filter((one) => !POLITE.test(one))).toEqual([
      "すでにその状態になっている。",
    ]);
  });

  it("審査で決めた日本語の文になっている", () => {
    for (const [key, value] of Object.entries(DECIDED_JA)) expect(ja[key], key).toBe(value);
  });

  it("ログインとログアウトで、言葉をそろえている", () => {
    expect(ja["nav.login"]).toBe("ログイン");
    expect(ja["nav.signout"]).toBe("ログアウト");
    // 英語は Sign in / Sign out のままです
    expect(en["nav.login"]).toBe("Sign in");
    expect(en["nav.signout"]).toBe("Sign out");
  });

  it("英語の件数は、値だけにして見出しに任せる（単数と複数を作り分けないため）", () => {
    expect(en["overview.memberCount"]).toBe("{count}");
    expect(en["project.countUnlimited"]).toBe("{used}");
    // 日本語は助数詞が 1 つで足りるので、そのままです
    expect(ja["overview.memberCount"]).toBe("{count} 名");
    expect(ja["project.countUnlimited"]).toBe("{used} 件");
  });

  it("英語の誤りのご案内にも、次にどうすればよいかが書いてある", () => {
    const next: Readonly<Record<string, readonly string[]>> = {
      "error.forbidden": ["owner", "admin"],
      "error.last_owner": ["at least one owner", "try again"],
      "error.billing_no_customer": ["billing"],
      "error.rate_limited": ["try again"],
      "error.invite_used": ["ask"],
    };
    for (const [key, words] of Object.entries(next)) {
      for (const word of words) {
        expect(en[key].toLowerCase(), `${key}: ${word}`).toContain(word);
      }
    }
  });

  it("日本語の文が敬体で終わっている（。で終わる文は です・ます・ください で閉じる）", () => {
    const offenders: string[] = [];
    for (const [key, value] of Object.entries<string>(ja)) {
      // 札・ボタンの短い語（。で終わる文を 1 つも含まないもの）は対象外です
      for (const one of sentences(value)) {
        if (!POLITE.test(one)) offenders.push(`${key}: ${one}`);
      }
    }
    expect(offenders).toEqual([]);
  });
});
