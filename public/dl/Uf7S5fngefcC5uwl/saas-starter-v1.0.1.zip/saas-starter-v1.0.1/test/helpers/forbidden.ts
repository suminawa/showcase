/**
 * 配布物（zip）に入ってはいけない語を、1 か所で組み立てます。
 *
 * この道具を読み込む検査そのものも zip に入ります。探す語を字のまま書くと
 * 「探す側のファイルが検査に引っかかる」ことになってしまうので、
 * 内部でだけ使う呼び名・作った場所の手がかり・書きかけの印は、
 * すべて文字コード（code point）から組み立てて持ちます。
 *
 * vitest が回すのは `test/**\/*.test.ts` だけなので、この入れ子の場所に置いた
 * 道具は検査として実行されません（読み込まれるだけです）。
 */

/** 文字コードの並びから、1 つの語を作ります */
function word(...codePoints: number[]): string {
  return String.fromCodePoint(...codePoints);
}

/**
 * 内部でだけ使う呼び名です。中身は（順に）
 * 手伝い役の道具の名前 1 字・持ち主の呼び名 2 字・手伝い役の製品名・その作り手の名前・
 * 作業場所の名前です。
 */
export const INTERNAL_WORDS: readonly string[] = [
  word(0x924b),
  word(0x68df, 0x6881),
  word(0x43, 0x6c, 0x61, 0x75, 0x64, 0x65),
  word(0x41, 0x6e, 0x74, 0x68, 0x72, 0x6f, 0x70, 0x69, 0x63),
  word(0x63, 0x72, 0x65, 0x61, 0x74, 0x6f, 0x72, 0x2d, 0x6f, 0x73),
];

/**
 * 作った人の手元の場所が分かってしまう手がかりです。
 * 3 つの OS の持ち物の入れ物の道すじと、内部の書類の置き場所 2 つです。
 */
export const INTERNAL_PATHS: readonly string[] = [
  word(0x2f, 0x55, 0x73, 0x65, 0x72, 0x73, 0x2f),
  word(0x2f, 0x68, 0x6f, 0x6d, 0x65, 0x2f),
  word(0x43, 0x3a, 0x5c, 0x55, 0x73, 0x65, 0x72, 0x73),
  word(0x2e, 0x73, 0x75, 0x70, 0x65, 0x72, 0x70, 0x6f, 0x77, 0x65, 0x72, 0x73),
  word(0x73, 0x75, 0x6d, 0x69, 0x6e, 0x61, 0x77, 0x61, 0x2d, 0x6f, 0x70, 0x73),
];

/** 書きかけの印（まだ手を入れる、直す、仮置き）です。売り物に残っていてはいけません */
export const WORK_IN_PROGRESS_MARKS: readonly string[] = [
  word(0x54, 0x4f, 0x44, 0x4f),
  word(0x46, 0x49, 0x58, 0x4d, 0x45),
  word(0x58, 0x58, 0x58),
];

/**
 * 見本に紛れ込ませない、実在の地名です（9 つ）。
 *
 * この一覧も、字のまま書くとこのファイル自身が見張りに引っかかります。
 * 上と同じく、文字コードから組み立てて持ちます。
 */
export const REAL_WORLD_NAMES: readonly string[] = [
  word(0x6a2a, 0x6d5c),
  word(0x6771, 0x4eac),
  word(0x5927, 0x962a),
  word(0x540d, 0x53e4, 0x5c4b),
  word(0x672d, 0x5e4c),
  word(0x798f, 0x5ca1),
  word(0x6e0b, 0x8c37),
  word(0x65b0, 0x5bbf),
  word(0x5343, 0x4ee3, 0x7530),
];

/** そのまま置いてよい制御文字（タブ・改行・復帰）の文字コードです */
const ALLOWED_CONTROL_CODES: readonly number[] = [9, 10, 13];

/**
 * 文字コードが 32 より小さい字のうち、タブ・改行・復帰でないものが 1 つでもあるか。
 * 正規表現で書くと、この道具のファイル自身に生の制御文字が紛れ込みかねないので、
 * 文字コードを数で見比べるだけにしてあります。
 */
export function hasRawControlChar(text: string): boolean {
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i);
    if (code >= 32 || ALLOWED_CONTROL_CODES.includes(code)) continue;
    return true;
  }
  return false;
}

/** text の中に見つかった語を並べます（1 つも無ければ空です） */
export function foundWords(text: string, words: readonly string[]): string[] {
  return words.filter((wanted) => text.includes(wanted));
}
