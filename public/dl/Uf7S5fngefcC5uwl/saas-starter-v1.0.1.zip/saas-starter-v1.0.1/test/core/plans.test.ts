import { describe, expect, it } from "vitest";
import { PLANS } from "../../plans.config";
import {
  canCreateProject,
  findPlan,
  freePlan,
  isPlanId,
  planPriceText,
  priceIdFor,
  projectLimitOf,
  projectQuota,
  publicPlans,
  upgradablePlans,
  type Plan,
} from "../../src/core/plans";

/**
 * 配る側（この土台をお届けする側）の決まりを回すかどうかです。
 *
 * 下の 4 件は「**同梱の見本のプランが、お届けしたときのままか**」を見るもので、
 * お客さまのアプリのための決まりではありません。README 10 章のとおりに
 * プランをお増やしになると、そのままでは赤くなってしまいます。
 * `npm run release:check` のときだけ回します。
 */
const RELEASE_GATE = process.env.RELEASE_GATE === "1";

describe("見本のプラン", () => {
  it("3 つで、順に 無料・スタンダード・ビジネス", () => {
    if (!RELEASE_GATE) return;
    expect(PLANS.map((p) => p.id)).toEqual(["free", "standard", "business"]);
  });
  it("金額は設計書のとおり", () => {
    if (!RELEASE_GATE) return;
    expect(PLANS.map((p) => p.monthlyYen)).toEqual([0, 2980, 9800]);
  });
  it("プロジェクトの上限は 3・50・上限なし", () => {
    if (!RELEASE_GATE) return;
    expect(PLANS.map((p) => p.projectLimit)).toEqual([3, 50, -1]);
  });
  it("Price の環境変数は有料の 2 つだけ", () => {
    if (!RELEASE_GATE) return;
    expect(PLANS.map((p) => p.priceEnvName)).toEqual([
      null,
      "STRIPE_PRICE_STANDARD",
      "STRIPE_PRICE_BUSINESS",
    ]);
  });
  it("無料のプランにだけ Price の環境変数がない", () => {
    // こちらは、プランをお増やしになっても当てはまる決まりです
    for (const plan of PLANS) {
      if (plan.monthlyYen === 0) expect(plan.priceEnvName, plan.id).toBeNull();
      else expect(plan.priceEnvName, plan.id).not.toBeNull();
    }
  });
});

/**
 * ここから下は、**`plans.config.ts` の金額や上限をお変えになっても当てはまる形**で書いてあります
 * （README 10 章のとおりにお直しになっても、`npm test` は緑のままです）。
 * 計算そのものは、検査の中で組み立てたプランで撃ちます。
 */
const limited = (projectLimit: number, monthlyYen = 0): Plan => ({
  id: "free",
  nameKey: "plan.free.name",
  descriptionKey: "plan.free.description",
  monthlyYen,
  projectLimit,
  priceEnvName: null,
});
const unlimited = limited(-1, 9800);
const paidPlans = PLANS.filter((plan) => plan.priceEnvName !== null);

describe("findPlan / isPlanId", () => {
  it("知っている id だけ", () => {
    for (const plan of PLANS) {
      expect(findPlan(plan.id), plan.id).toEqual(plan);
      expect(isPlanId(plan.id), plan.id).toBe(true);
      expect(isPlanId(plan.id.toUpperCase()), plan.id).toBe(false);
    }
    expect(findPlan("enterprise-x")).toBeNull();
    expect(isPlanId("enterprise-x")).toBe(false);
    expect(isPlanId(3)).toBe(false);
  });
  it("freePlan は無料のプラン", () => {
    expect(freePlan().id).toBe("free");
    expect(freePlan().monthlyYen).toBe(0);
    expect(freePlan().priceEnvName).toBeNull();
  });
});

describe("canCreateProject", () => {
  it("上限の手前までは作れて、上限からは作れない", () => {
    const plan = limited(3);
    expect(canCreateProject(plan, 0)).toBe(true);
    expect(canCreateProject(plan, 2)).toBe(true);
    expect(canCreateProject(plan, 3)).toBe(false);
    expect(canCreateProject(plan, 9)).toBe(false);
  });
  it("同梱の無料のプランも、その上限のとおりに止まる", () => {
    const free = freePlan();
    const limit = free.projectLimit;
    if (limit < 0) return; // 無料のプランを上限なしにお変えになったときは、止まるところがありません
    if (limit > 0) expect(canCreateProject(free, limit - 1)).toBe(true);
    expect(canCreateProject(free, limit)).toBe(false);
    expect(canCreateProject(free, limit + 2)).toBe(false);
  });
  it("上限なしはいつでも作れる", () => {
    expect(canCreateProject(unlimited, 100000)).toBe(true);
  });
});

describe("projectLimitOf", () => {
  it("上限のあるプランは件数、上限のないプランは null", () => {
    expect(projectLimitOf(limited(3))).toBe(3);
    expect(projectLimitOf(limited(50))).toBe(50);
    expect(projectLimitOf(unlimited)).toBeNull();
    for (const plan of PLANS) {
      expect(projectLimitOf(plan), plan.id).toBe(plan.projectLimit < 0 ? null : plan.projectLimit);
    }
  });
});

describe("projectQuota", () => {
  it("残りと上限に達したかを返す", () => {
    expect(projectQuota(limited(3), 2)).toEqual({
      limit: 3,
      used: 2,
      remaining: 1,
      atLimit: false,
      unlimited: false,
    });
    expect(projectQuota(limited(3), 3)).toEqual({
      limit: 3,
      used: 3,
      remaining: 0,
      atLimit: true,
      unlimited: false,
    });
  });
  it("上限を超えていても remaining は 0 で止まる", () => {
    expect(projectQuota(limited(3), 5).remaining).toBe(0);
  });
  it("上限なしは remaining が null", () => {
    expect(projectQuota(unlimited, 7)).toEqual({
      limit: -1,
      used: 7,
      remaining: null,
      atLimit: false,
      unlimited: true,
    });
  });
});

describe("publicPlans", () => {
  it("画面へお渡しするプランには、Price の環境変数の名前が入っていない", () => {
    const plans = publicPlans();
    // 並びも数も、plans.config.ts のとおりです（プランをお増やしになっても同じです）
    expect(plans.map((p) => p.id)).toEqual(PLANS.map((p) => p.id));
    for (const plan of plans) {
      expect(Object.keys(plan), plan.id).not.toContain("priceEnvName");
    }
  });
  it("表示に使うところはそのまま渡す", () => {
    for (const plan of PLANS) {
      expect(publicPlans().find((p) => p.id === plan.id), plan.id).toEqual({
        id: plan.id,
        nameKey: plan.nameKey,
        descriptionKey: plan.descriptionKey,
        monthlyYen: plan.monthlyYen,
        projectLimit: plan.projectLimit,
      });
    }
  });
});

describe("priceIdFor", () => {
  it("環境変数から Price を読む", () => {
    for (const plan of paidPlans) {
      expect(priceIdFor(plan, { [plan.priceEnvName!]: "price_123" }), plan.id).toBe("price_123");
    }
  });
  it("空の環境変数は null", () => {
    for (const plan of paidPlans) {
      expect(priceIdFor(plan, { [plan.priceEnvName!]: "" }), plan.id).toBeNull();
      expect(priceIdFor(plan, {}), plan.id).toBeNull();
    }
  });
  it("無料のプランは null", () => {
    expect(priceIdFor(freePlan(), { STRIPE_PRICE_STANDARD: "price_123" })).toBeNull();
  });
});

describe("planPriceText / upgradablePlans", () => {
  it("金額の文", () => {
    expect(planPriceText(limited(3, 0), "ja")).toBe("¥0");
    expect(planPriceText(limited(50, 2980), "ja")).toBe("¥2,980");
    expect(planPriceText(limited(-1, 9800), "en")).toBe("¥9,800");
    expect(planPriceText(limited(-1, 1234567), "ja")).toBe("¥1,234,567");
  });
  it("いまより上のプランだけ", () => {
    // plans.config.ts の並びから作ります（プランをお増やしになっても当てはまります）
    const ids = PLANS.map((plan) => plan.id);
    for (const [at, id] of ids.entries()) {
      expect(upgradablePlans(id).map((plan) => plan.id), id).toEqual(ids.slice(at + 1));
    }
    expect(upgradablePlans(ids[ids.length - 1]!)).toEqual([]);
  });
});
