import { describe, expect, it } from "vitest";
import { LANGS, formatDate, formatYen, isLang, pickLang, t } from "../../src/core/i18n";

describe("言語", () => {
  it("ja と en の 2 つ", () => {
    expect(LANGS).toEqual(["ja", "en"]);
    expect(isLang("ja")).toBe(true);
    expect(isLang("fr")).toBe(false);
  });

  it("pickLang は param → cookie → profile → header の順", () => {
    expect(pickLang({ param: "en", cookie: "ja", profile: "ja" })).toBe("en");
    expect(pickLang({ param: "fr", cookie: "en" })).toBe("en");
    expect(pickLang({ profile: "en" })).toBe("en");
    expect(pickLang({ header: "en-GB,en;q=0.9" })).toBe("en");
    expect(pickLang({})).toBe("ja");
    expect(pickLang({ param: null, cookie: null, profile: null, header: null })).toBe("ja");
  });
});

describe("t", () => {
  const messages = { "greeting": "{name} さん、こんにちは。", "plain": "ようこそ。" };

  it("差し込みをする", () => {
    expect(t(messages, "greeting", { name: "みなと 太郎" })).toBe("みなと 太郎 さん、こんにちは。");
  });
  it("変数の無い文はそのまま", () => {
    expect(t(messages, "plain")).toBe("ようこそ。");
  });
  it("知らない鍵は鍵を返す", () => {
    expect(t(messages, "unknown.key")).toBe("unknown.key");
  });
  it("値の無い変数はそのまま残す", () => {
    expect(t(messages, "greeting")).toBe("{name} さん、こんにちは。");
  });
  it("差し込んだ値の中の {…} はもう一度差し込まない", () => {
    expect(t(messages, "greeting", { name: "{name}" })).toBe("{name} さん、こんにちは。");
  });
});

describe("formatYen", () => {
  it("3 桁ごとに区切る", () => {
    expect(formatYen(0, "ja")).toBe("¥0");
    expect(formatYen(2980, "ja")).toBe("¥2,980");
    expect(formatYen(9800, "en")).toBe("¥9,800");
    expect(formatYen(1234567, "ja")).toBe("¥1,234,567");
  });
  it("負は頭に -", () => {
    expect(formatYen(-1200, "ja")).toBe("-¥1,200");
  });
});

describe("formatDate", () => {
  it("ja と en", () => {
    expect(formatDate("2026-10-06T12:00:00.000Z", "ja")).toBe("2026年10月6日");
    expect(formatDate("2026-10-06T12:00:00.000Z", "en")).toBe("6 October 2026");
  });
  it("読めない値は空", () => {
    expect(formatDate("いつか", "ja")).toBe("");
    expect(formatDate("", "ja")).toBe("");
  });
});
