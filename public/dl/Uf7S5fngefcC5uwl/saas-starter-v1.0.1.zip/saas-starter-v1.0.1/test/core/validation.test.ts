import { describe, expect, it } from "vitest";
import {
  collect,
  trimText,
  validateChoice,
  validateEmail,
  validateId,
  validatePassword,
  validateText,
} from "../../src/core/validation";

describe("trimText", () => {
  it("前後の空白と全角空白を落とす", () => {
    expect(trimText("  ねこ  ")).toBe("ねこ");
    expect(trimText("　ねこ　")).toBe("ねこ");
  });
  it("制御文字を外す", () => {
    expect(trimText("ね\x00こ\x07")).toBe("ねこ");
    expect(trimText("ね\x7fこ")).toBe("ねこ");
  });
  it("タブと CRLF は残す", () => {
    expect(trimText("ね\tこ")).toBe("ね\tこ");
    expect(trimText("ね\r\nこ")).toBe("ね\r\nこ");
  });
  it("改行は残す", () => {
    expect(trimText("ね\nこ")).toBe("ね\nこ");
  });
  it("文字でない値は空", () => {
    expect(trimText(undefined)).toBe("");
    expect(trimText(null)).toBe("");
    expect(trimText(12)).toBe("");
  });
});

describe("validateEmail", () => {
  it("ふつうのメールを通す", () => {
    expect(validateEmail(" Owner@Example.com ")).toEqual({ ok: true, value: "owner@example.com" });
  });
  it("空は required", () => {
    expect(validateEmail("")).toEqual({ ok: false, errors: [{ field: "email", code: "required" }] });
  });
  it("形が違えば bad_email", () => {
    for (const bad of ["ねこ", "a@", "@b.com", "a b@example.com", "a@b", "a@@b.com"]) {
      expect(validateEmail(bad)).toEqual({ ok: false, errors: [{ field: "email", code: "bad_email" }] });
    }
  });
  it("長すぎれば too_long（254 文字まで）", () => {
    const long = "a".repeat(250) + "@example.com";
    expect(validateEmail(long)).toEqual({ ok: false, errors: [{ field: "email", code: "too_long" }] });
  });
  it("field の名前を差し替えられる", () => {
    expect(validateEmail("", "inviteEmail")).toEqual({
      ok: false,
      errors: [{ field: "inviteEmail", code: "required" }],
    });
  });
});

describe("validatePassword", () => {
  it("8 文字以上 72 文字以下", () => {
    expect(validatePassword("abcdefgh")).toEqual({ ok: true, value: "abcdefgh" });
    expect(validatePassword("abcdefg")).toEqual({
      ok: false,
      errors: [{ field: "password", code: "too_short" }],
    });
    expect(validatePassword("a".repeat(73))).toEqual({
      ok: false,
      errors: [{ field: "password", code: "too_long" }],
    });
  });
  it("前後の空白を落とさない", () => {
    expect(validatePassword(" abcdefgh ")).toEqual({ ok: true, value: " abcdefgh " });
  });
  it("空は required", () => {
    expect(validatePassword("")).toEqual({
      ok: false,
      errors: [{ field: "password", code: "required" }],
    });
  });
});

describe("validateText", () => {
  const org = { field: "name", min: 1, max: 60 };
  it("前後の空白を落としてから測る", () => {
    expect(validateText("  しおさい設計室  ", org)).toEqual({ ok: true, value: "しおさい設計室" });
  });
  it("空白だけは required", () => {
    expect(validateText("　 ", org)).toEqual({
      ok: false,
      errors: [{ field: "name", code: "required" }],
    });
  });
  it("長さは文字の数で測る（絵文字も 1 文字）", () => {
    expect(validateText("あ".repeat(60), org).ok).toBe(true);
    expect(validateText("あ".repeat(61), org)).toEqual({
      ok: false,
      errors: [{ field: "name", code: "too_long" }],
    });
    expect(validateText("🐈".repeat(60), org).ok).toBe(true);
  });
  it("min 0 なら空を通す", () => {
    expect(validateText("", { field: "note", min: 0, max: 2000 })).toEqual({ ok: true, value: "" });
  });
});

describe("validateChoice", () => {
  it("並びにある値だけ通す", () => {
    expect(validateChoice("admin", ["owner", "admin", "member"] as const, "role")).toEqual({
      ok: true,
      value: "admin",
    });
    expect(validateChoice("root", ["owner", "admin", "member"] as const, "role")).toEqual({
      ok: false,
      errors: [{ field: "role", code: "bad_choice" }],
    });
  });
});

describe("validateId", () => {
  it("UUID の形だけ通す", () => {
    expect(validateId("6f3d2c1a-8b4e-4f7a-9c1d-2e5b7a9f0c3d", "organizationId")).toEqual({
      ok: true,
      value: "6f3d2c1a-8b4e-4f7a-9c1d-2e5b7a9f0c3d",
    });
    expect(validateId("../../etc/passwd", "organizationId")).toEqual({
      ok: false,
      errors: [{ field: "organizationId", code: "bad_id" }],
    });
    expect(validateId("", "organizationId")).toEqual({
      ok: false,
      errors: [{ field: "organizationId", code: "required" }],
    });
  });
});

describe("collect", () => {
  it("すべて通れば値をまとめる", () => {
    expect(
      collect({ email: validateEmail("a@example.com"), name: validateText("太郎", { field: "name", min: 1, max: 60 }) }),
    ).toEqual({ ok: true, value: { email: "a@example.com", name: "太郎" } });
  });
  it("落ちたものをすべて集める（最初の 1 つで止めない）", () => {
    const got = collect({ email: validateEmail("x"), password: validatePassword("abc") });
    expect(got).toEqual({
      ok: false,
      errors: [
        { field: "email", code: "bad_email" },
        { field: "password", code: "too_short" },
      ],
    });
  });
});
