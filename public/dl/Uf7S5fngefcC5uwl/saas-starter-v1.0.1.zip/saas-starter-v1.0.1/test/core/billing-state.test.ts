import { freePlan } from "../../src/core/plans";
import { describe, expect, it } from "vitest";
import type { StripeStatus, SubscriptionRow } from "../../src/core/billing-state";
import {
  billingStateFrom,
  hasOpenSubscription,
  isEntitled,
  isLiveSubscription,
  isStripeStatus,
  STRIPE_STATUSES,
} from "../../src/core/billing-state";

const row = (over: Partial<SubscriptionRow> = {}): SubscriptionRow => ({
  organizationId: "org-1",
  planId: "standard",
  status: "active",
  stripeSubscriptionId: "sub_1",
  currentPeriodEnd: "2026-10-31T00:00:00.000Z",
  cancelAtPeriodEnd: false,
  updatedAt: "2026-10-01T00:00:00.000Z",
  ...over,
});

describe("isStripeStatus", () => {
  it("Stripe の 8 つだけ", () => {
    for (const status of [
      "active", "canceled", "incomplete", "incomplete_expired",
      "past_due", "paused", "trialing", "unpaid",
    ]) {
      expect(isStripeStatus(status)).toBe(true);
    }
    expect(isStripeStatus("none")).toBe(false);
    expect(isStripeStatus("ended")).toBe(false);
  });
});

describe("isEntitled", () => {
  it("止めるのは canceled・unpaid・incomplete_expired・incomplete の 4 つ", () => {
    // incomplete は「はじめのお支払いがまだ確定していない」状態です。
    // ここでお使いいただけるようにすると、お支払いが通らないまま
    // 上のプランの上限でお使いいただけてしまいます。
    const stopped: StripeStatus[] = [
      "canceled",
      "unpaid",
      "incomplete_expired",
      "incomplete",
    ];
    const running: StripeStatus[] = ["active", "trialing", "past_due", "paused"];
    for (const status of stopped) expect(isEntitled(status), status).toBe(false);
    for (const status of running) expect(isEntitled(status), status).toBe(true);
  });

  it("知らない状態は、使えない側に倒す", () => {
    // Stripe に新しい状態が増えたときに、使える側へ黙って倒れないようにします
    for (const status of ["", "ended", "trial", "ACTIVE"]) {
      expect(isEntitled(status as StripeStatus), status).toBe(false);
    }
  });
});

describe("isLiveSubscription", () => {
  it("生きているのは active・trialing・past_due の 3 つ", () => {
    const live: StripeStatus[] = ["active", "trialing", "past_due"];
    const over: (StripeStatus | "none")[] = [
      "canceled",
      "unpaid",
      "incomplete",
      "incomplete_expired",
      "paused",
      "none",
    ];
    for (const status of live) expect(isLiveSubscription(status), status).toBe(true);
    for (const status of over) expect(isLiveSubscription(status), status).toBe(false);
  });
});

describe("hasOpenSubscription", () => {
  it("実体が残らないのは canceled・incomplete_expired・none の 3 つだけ", () => {
    // 「機能をお使いいただけるか」とは別の問いです。
    // incomplete・paused・unpaid は、機能は止めても実体は残っています。
    const open: StripeStatus[] = [
      "active",
      "trialing",
      "past_due",
      "unpaid",
      "incomplete",
      "paused",
    ];
    const closed: (StripeStatus | "none")[] = ["canceled", "incomplete_expired", "none"];

    for (const status of open) expect(hasOpenSubscription(status), status).toBe(true);
    for (const status of closed) expect(hasOpenSubscription(status), status).toBe(false);
    expect(open.length + closed.length).toBe(STRIPE_STATUSES.length + 1);
  });

  it("isEntitled とは答えが違う（incomplete・unpaid と paused で分かれます）", () => {
    // ここが同じ判定になっていると、二重のお申し込みか、誤った足止めのどちらかが起きます
    const different = STRIPE_STATUSES.filter(
      (status) => isEntitled(status) !== hasOpenSubscription(status),
    );
    expect([...different].sort()).toEqual(["incomplete", "unpaid"]);
  });
});

describe("billingStateFrom", () => {
  it("契約が無ければ無料で使える", () => {
    const got = billingStateFrom(null);
    expect(got.planId).toBe("free");
    expect(got.status).toBe("none");
    expect(got.entitled).toBe(true);
    expect(got.banner).toBe("none");
    expect(got.plan.projectLimit).toBe(freePlan().projectLimit);
  });

  it("active は帯を出さない", () => {
    const got = billingStateFrom(row());
    expect(got.planId).toBe("standard");
    expect(got.banner).toBe("none");
    expect(got.entitled).toBe(true);
    expect(got.currentPeriodEnd).toBe("2026-10-31T00:00:00.000Z");
  });

  it("解約の予約は cancel_scheduled", () => {
    expect(billingStateFrom(row({ cancelAtPeriodEnd: true })).banner).toBe("cancel_scheduled");
    expect(billingStateFrom(row({ cancelAtPeriodEnd: true })).entitled).toBe(true);
  });

  it("past_due は帯を出すが止めない", () => {
    const got = billingStateFrom(row({ status: "past_due" }));
    expect(got.banner).toBe("past_due");
    expect(got.entitled).toBe(true);
    expect(got.planId).toBe("standard");
  });

  it("paused は、一時停止中であることをお伝えする帯（機能は止めません）", () => {
    // 同じ画面の状態の行は「一時停止中」と出ています。
    // 「お支払いの確認ができていません」の帯を出すと、言うことが食い違います。
    const got = billingStateFrom(row({ status: "paused" }));
    expect(got.banner).toBe("paused");
    expect(got.entitled).toBe(true);
    expect(got.planId).toBe("standard");
  });

  it("incomplete は専用の帯で、無料のプランの上限に戻る", () => {
    // はじめのお支払いが確定するまでは、無料のプランの上限でのご利用です。
    // 「お支払いが確認できません」とは事情が違うので、帯も分けます。
    const got = billingStateFrom(row({ status: "incomplete" }));
    expect(got.banner).toBe("incomplete");
    expect(got.entitled).toBe(false);
    expect(got.planId).toBe("free");
    expect(got.plan.projectLimit).toBe(freePlan().projectLimit);
    // ご契約の状態そのものは、そのままお見せします
    expect(got.status).toBe("incomplete");
  });

  it("画面に届くプランに、Stripe の Price の環境変数の名前を入れない", () => {
    // ご契約の状態は、そのまま画面（Server Component）に渡ります。
    // どの環境変数をお使いかは、外からお見せする用のない知らせです。
    for (const state of [
      billingStateFrom(null),
      billingStateFrom(row()),
      billingStateFrom(row({ planId: "business" })),
      billingStateFrom(row({ status: "canceled" })),
    ]) {
      expect(Object.keys(state.plan), state.planId).not.toContain("priceEnvName");
      expect(state.plan.id).toBe(state.planId);
    }
  });

  it("canceled と unpaid は無料に落ちる", () => {
    const canceled = billingStateFrom(row({ status: "canceled" }));
    expect(canceled.entitled).toBe(false);
    expect(canceled.planId).toBe("free");
    expect(canceled.banner).toBe("canceled");

    const unpaid = billingStateFrom(row({ status: "unpaid" }));
    expect(unpaid.planId).toBe("free");
    expect(unpaid.banner).toBe("unpaid");

    expect(billingStateFrom(row({ status: "incomplete_expired" })).banner).toBe("canceled");
  });
});
