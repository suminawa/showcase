import { describe, expect, it } from "vitest";
import {
  ACTIONS,
  PERMISSION_MATRIX,
  ROLES,
  can,
  canChangeMembership,
  isRole,
  roleRank,
} from "../../src/core/permissions";

describe("役割", () => {
  it("3 つだけで、順に並んでいる", () => {
    expect(ROLES).toEqual(["owner", "admin", "member"]);
  });

  it("isRole は知らない値を通さない", () => {
    expect(isRole("owner")).toBe(true);
    expect(isRole("admin")).toBe(true);
    expect(isRole("member")).toBe(true);
    expect(isRole("Owner")).toBe(false);
    expect(isRole("superuser")).toBe(false);
    expect(isRole(undefined)).toBe(false);
    expect(isRole(1)).toBe(false);
  });

  it("roleRank は owner > admin > member", () => {
    expect(roleRank("owner")).toBeGreaterThan(roleRank("admin"));
    expect(roleRank("admin")).toBeGreaterThan(roleRank("member"));
  });
});

describe("権限の表", () => {
  it("表の升目が、設計書のとおりの値になっている", () => {
    /**
     * **値そのものを、1 升ずつ突き合わせます。**
     *
     * 「答えがある（`toBeDefined`）」だけでは、`member:setRole` の admin の升目を
     * `notOwner` から `yes` に書き換えても緑のままです（型は全域の `Record` なので、
     * `tsc` も気づきません）。この表は、画面・仕事の流れ・行の出入りの決まりの
     * 3 か所の出どころですので、升目の値が変わったらここで止めます。
     */
    expect(PERMISSION_MATRIX).toEqual({
      "project:read": { owner: "yes", admin: "yes", member: "yes" },
      "project:create": { owner: "yes", admin: "yes", member: "yes" },
      "project:update": { owner: "yes", admin: "yes", member: "yes" },
      "project:delete": { owner: "yes", admin: "yes", member: "own" },
      "member:invite": { owner: "yes", admin: "notOwner", member: "no" },
      "member:remove": { owner: "yes", admin: "notOwner", member: "no" },
      "member:setRole": { owner: "yes", admin: "notOwner", member: "no" },
      "org:rename": { owner: "yes", admin: "yes", member: "no" },
      "billing:manage": { owner: "yes", admin: "no", member: "no" },
      "org:delete": { owner: "yes", admin: "no", member: "no" },
    });

    // 操作と役割の一覧も、表の鍵とそろっています
    expect(Object.keys(PERMISSION_MATRIX).sort()).toEqual([...ACTIONS].sort());
    for (const action of ACTIONS) {
      expect(Object.keys(PERMISSION_MATRIX[action]).sort(), action).toEqual([...ROLES].sort());
    }
  });

  it("設計書の表のとおり（プロジェクト）", () => {
    for (const action of ["project:read", "project:create", "project:update"] as const) {
      expect(can(action, { role: "owner" })).toBe(true);
      expect(can(action, { role: "admin" })).toBe(true);
      expect(can(action, { role: "member" })).toBe(true);
    }
  });

  it("member はプロジェクトを消せるのが自分の作ったものだけ", () => {
    expect(can("project:delete", { role: "owner", userId: "u1", resourceOwnerId: "u2" })).toBe(true);
    expect(can("project:delete", { role: "admin", userId: "u1", resourceOwnerId: "u2" })).toBe(true);
    expect(can("project:delete", { role: "member", userId: "u1", resourceOwnerId: "u1" })).toBe(true);
    expect(can("project:delete", { role: "member", userId: "u1", resourceOwnerId: "u2" })).toBe(false);
    expect(can("project:delete", { role: "member", userId: "u1" })).toBe(false);
  });

  it("member はメンバーの操作ができない", () => {
    expect(can("member:invite", { role: "member", targetRole: "member" })).toBe(false);
    expect(can("member:remove", { role: "member", targetRole: "member" })).toBe(false);
    expect(can("member:setRole", { role: "member", targetRole: "member" })).toBe(false);
  });

  it("admin は owner に触れない", () => {
    expect(can("member:remove", { role: "admin", targetRole: "member" })).toBe(true);
    expect(can("member:remove", { role: "admin", targetRole: "admin" })).toBe(true);
    expect(can("member:remove", { role: "admin", targetRole: "owner" })).toBe(false);
    expect(can("member:invite", { role: "admin", targetRole: "owner" })).toBe(false);
    expect(can("member:invite", { role: "admin", targetRole: "admin" })).toBe(true);
  });

  it("targetRole を渡し忘れた notOwner の操作は通さない", () => {
    expect(can("member:remove", { role: "admin" })).toBe(false);
  });

  it("表には、画面と flow が使う操作がすべて並んでいる", () => {
    expect(ACTIONS).toEqual([
      "project:read",
      "project:create",
      "project:update",
      "project:delete",
      "member:invite",
      "member:remove",
      "member:setRole",
      "org:rename",
      "billing:manage",
      "org:delete",
    ]);
    expect(Object.keys(PERMISSION_MATRIX).sort()).toEqual([...ACTIONS].sort());
  });

  it("組織のお名前の変更は owner と admin", () => {
    expect(can("org:rename", { role: "owner" })).toBe(true);
    expect(can("org:rename", { role: "admin" })).toBe(true);
    expect(can("org:rename", { role: "member" })).toBe(false);
  });

  it("課金と組織の削除は owner だけ", () => {
    for (const action of ["billing:manage", "org:delete"] as const) {
      expect(can(action, { role: "owner" })).toBe(true);
      expect(can(action, { role: "admin" })).toBe(false);
      expect(can(action, { role: "member" })).toBe(false);
    }
  });
});

describe("canChangeMembership", () => {
  const base = { actorUserId: "u1", targetUserId: "u2", ownerCount: 2 };

  it("owner は admin を member に降ろせる", () => {
    expect(
      canChangeMembership({ ...base, actorRole: "owner", targetRole: "admin", next: "member" }),
    ).toEqual({ ok: true });
  });

  it("admin は owner を降ろせない", () => {
    expect(
      canChangeMembership({ ...base, actorRole: "admin", targetRole: "owner", next: "member" }),
    ).toEqual({ ok: false, code: "cannot_touch_owner" });
  });

  it("admin は誰かを owner に上げられない", () => {
    expect(
      canChangeMembership({ ...base, actorRole: "admin", targetRole: "member", next: "owner" }),
    ).toEqual({ ok: false, code: "cannot_promote_to_owner" });
  });

  it("member は誰にも触れない", () => {
    expect(
      canChangeMembership({ ...base, actorRole: "member", targetRole: "member", next: "admin" }),
    ).toEqual({ ok: false, code: "forbidden" });
  });

  it("最後の owner は外せない", () => {
    expect(
      canChangeMembership({
        ...base,
        ownerCount: 1,
        actorRole: "owner",
        targetRole: "owner",
        next: "remove",
      }),
    ).toEqual({ ok: false, code: "last_owner" });
  });

  it("最後の owner は自分を降ろせない", () => {
    expect(
      canChangeMembership({
        actorUserId: "u1",
        targetUserId: "u1",
        ownerCount: 1,
        actorRole: "owner",
        targetRole: "owner",
        next: "admin",
      }),
    ).toEqual({ ok: false, code: "last_owner" });
  });

  it("owner が 2 人いれば 1 人は降りられる", () => {
    expect(
      canChangeMembership({
        actorUserId: "u1",
        targetUserId: "u1",
        ownerCount: 2,
        actorRole: "owner",
        targetRole: "owner",
        next: "admin",
      }),
    ).toEqual({ ok: true });
  });

  it("member は自分で退会できる", () => {
    expect(
      canChangeMembership({
        actorUserId: "u3",
        targetUserId: "u3",
        ownerCount: 1,
        actorRole: "member",
        targetRole: "member",
        next: "remove",
      }),
    ).toEqual({ ok: true });
  });

  it("同じ役割への変更は no_change", () => {
    expect(
      canChangeMembership({ ...base, actorRole: "owner", targetRole: "admin", next: "admin" }),
    ).toEqual({ ok: false, code: "no_change" });
  });
});
