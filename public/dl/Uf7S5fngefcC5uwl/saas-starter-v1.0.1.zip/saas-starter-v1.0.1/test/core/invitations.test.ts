import { describe, expect, it } from "vitest";
import type { InvitationRow } from "../../src/core/invitations";
import {
  INVITE_TOKEN_BYTES,
  INVITE_TTL_DAYS,
  checkInvite,
  createInviteToken,
  hashInviteToken,
  inviteExpiresAt,
  inviteUrl,
} from "../../src/core/invitations";

const row = (over: Partial<InvitationRow> = {}): InvitationRow => ({
  id: "inv-1",
  organizationId: "org-1",
  email: "member@example.com",
  role: "member",
  tokenHash: "x".repeat(64),
  expiresAt: "2026-09-27T00:00:00.000Z",
  status: "pending",
  invitedBy: "u1",
  acceptedBy: null,
  createdAt: "2026-09-20T00:00:00.000Z",
  ...over,
});

describe("トークン", () => {
  it("決まりの数", () => {
    expect(INVITE_TOKEN_BYTES).toBe(32);
    expect(INVITE_TTL_DAYS).toBe(7);
  });

  it("32 バイトを base64url にすると 43 文字", () => {
    const { token } = createInviteToken();
    expect(token).toHaveLength(43);
    expect(token).toMatch(/^[A-Za-z0-9_-]{43}$/);
  });

  it("毎回ちがう", () => {
    const seen = new Set(Array.from({ length: 50 }, () => createInviteToken().token));
    expect(seen.size).toBe(50);
  });

  it("ハッシュは SHA-256 の hex で、同じトークンから同じ値", () => {
    const { token, tokenHash } = createInviteToken();
    expect(tokenHash).toMatch(/^[0-9a-f]{64}$/);
    expect(hashInviteToken(token)).toBe(tokenHash);
    expect(hashInviteToken(token + "a")).not.toBe(tokenHash);
  });

  it("ハッシュからトークンを取り出せない（トークンの文字が入っていない）", () => {
    const { token, tokenHash } = createInviteToken();
    expect(tokenHash).not.toContain(token);
  });
});

describe("inviteExpiresAt", () => {
  it("7 日後の ISO 8601", () => {
    expect(inviteExpiresAt(new Date("2026-09-20T09:00:00.000Z"))).toBe("2026-09-27T09:00:00.000Z");
  });
});

describe("checkInvite", () => {
  const now = new Date("2026-09-21T00:00:00.000Z");

  it("pending で期限内なら通る", () => {
    const got = checkInvite(row(), now);
    expect(got.ok).toBe(true);
  });
  it("無ければ not_found", () => {
    expect(checkInvite(null, now)).toEqual({ ok: false, code: "not_found" });
  });
  it("使い終わっていれば used", () => {
    expect(checkInvite(row({ status: "accepted" }), now)).toEqual({ ok: false, code: "used" });
  });
  it("取り消してあれば revoked", () => {
    expect(checkInvite(row({ status: "revoked" }), now)).toEqual({ ok: false, code: "revoked" });
  });
  it("期限が切れていれば expired", () => {
    expect(checkInvite(row(), new Date("2026-09-27T00:00:00.001Z"))).toEqual({
      ok: false,
      code: "expired",
    });
  });
  it("期限ちょうどは切れている", () => {
    expect(checkInvite(row(), new Date("2026-09-27T00:00:00.000Z"))).toEqual({
      ok: false,
      code: "expired",
    });
  });
  it("使い終わっていれば、期限が切れていても used", () => {
    expect(checkInvite(row({ status: "accepted" }), new Date("2027-01-01T00:00:00.000Z"))).toEqual({
      ok: false,
      code: "used",
    });
  });
});

describe("inviteUrl", () => {
  it("末尾の / を重ねない", () => {
    expect(inviteUrl("https://example.com", "abc")).toBe("https://example.com/invite/abc");
    expect(inviteUrl("https://example.com/", "abc")).toBe("https://example.com/invite/abc");
  });
});
