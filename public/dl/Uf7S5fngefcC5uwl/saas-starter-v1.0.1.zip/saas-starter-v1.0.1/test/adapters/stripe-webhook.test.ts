/**
 * 決済のつなぎ役（署名の確かめ・状態の取り直し・表に書く形づくり）の検査です。
 *
 * 本物の Stripe とは通信しません。
 *   - 署名は SDK の generateTestHeaderString で本物と同じ形に作ります
 *   - API を呼ぶところ（subscriptions.retrieve・checkout.sessions.create など）は、
 *     型の合う作りものを引数で差し込みます（fetch の差し替えはしていません）
 * 鍵は "sk_test_dummy" で足ります（署名の確かめは通信をしないためです）。
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it, vi } from "vitest";
import Stripe from "stripe";
import { createFakePorts, type FakePorts } from "../../src/adapters/fake";
import { STRIPE_API_VERSION, stripeClient } from "../../src/adapters/stripe/client";
import { WEBHOOK_MAX_BYTES } from "../../src/ports/billing";
import {
  createStripeBilling,
  type StripeBillingApi,
} from "../../src/adapters/stripe/billing";
import {
  readStripeWebhook,
  subscriptionToRow,
  type StripeWebhookApi,
} from "../../src/adapters/stripe/webhook";
import type { PlanId } from "../../src/core/plans";
import type { Ports } from "../../src/ports";
import { applyWebhookFlow } from "../../src/server/flows/billing";
import {
  logWebhook,
  readWebhookBody,
  webhookReply,
  webhookReplyName,
} from "../../src/server/webhook";

const SECRET = "whsec_test_secret";
const OTHER_SECRET = "whsec_another_secret";
const CUSTOMER = "cus_test_1";
const SUBSCRIPTION = "sub_test_1";
const PRICE_STANDARD = "price_standard_test";
const PRICE_BUSINESS = "price_business_test";
const PERIOD_END = 1793750400; // 2026-11-04T00:00:00.000Z（秒）
const RETRIEVED_AT = new Date("2026-09-20T12:00:00.000Z");
const NOW = new Date("2026-09-20T00:00:00.000Z");

/** 通信はしないので、鍵は見本の文字列で足ります */
const stripe = stripeClient("sk_test_dummy");

function planIdOf(priceId: string): PlanId | null {
  if (priceId === PRICE_STANDARD) return "standard";
  if (priceId === PRICE_BUSINESS) return "business";
  return null;
}

// ---- 作りもの（Stripe が返す形の、検査に要るところだけ） ----

type ItemSeed = { priceId: string; currentPeriodEnd?: number | null };

type SubscriptionSeed = {
  id?: string;
  customer?: string;
  status?: string;
  /** null のときは items.data を空にします */
  priceId?: string | null;
  /** null のときは、項目から期間の終わりを落とします */
  currentPeriodEnd?: number | null;
  /** 項目が 2 つ以上のご契約を組むときは、こちらでお渡しします */
  items?: ItemSeed[];
  cancelAtPeriodEnd?: boolean;
  /** cancel_at（終わる日時、秒）です。新しい版の Stripe はこちらで届きます */
  cancelAt?: number | null;
};

function subscriptionItem(seed: ItemSeed, at: number): unknown {
  return {
    id: `si_test_${at + 1}`,
    object: "subscription_item",
    price: { id: seed.priceId, object: "price" },
    ...(seed.currentPeriodEnd === null
      ? {}
      : { current_period_end: seed.currentPeriodEnd ?? PERIOD_END }),
  };
}

/**
 * Stripe の契約の形です。
 * 検査に要る項目だけを組み、残りは省いています（本物は項目がもっと多くあります）。
 */
function subscription(seed: SubscriptionSeed = {}): Stripe.Subscription {
  const seeds: ItemSeed[] =
    seed.items ??
    (seed.priceId === null
      ? []
      : [{ priceId: seed.priceId ?? PRICE_STANDARD, currentPeriodEnd: seed.currentPeriodEnd }]);

  return {
    id: seed.id ?? SUBSCRIPTION,
    object: "subscription",
    customer: seed.customer ?? CUSTOMER,
    status: seed.status ?? "active",
    cancel_at_period_end: seed.cancelAtPeriodEnd ?? false,
    cancel_at: seed.cancelAt ?? null,
    items: {
      object: "list",
      data: seeds.map(subscriptionItem),
      has_more: false,
      url: "/v1/subscription_items",
    },
  } as unknown as Stripe.Subscription;
}

function eventPayload(type: string, object: unknown, id = "evt_test_1"): string {
  return JSON.stringify({
    id,
    object: "event",
    api_version: STRIPE_API_VERSION,
    created: 1790000000,
    livemode: false,
    pending_webhooks: 0,
    request: null,
    type,
    data: { object },
  });
}

function sign(payload: string, options: { secret?: string; timestamp?: number } = {}): string {
  return stripe.webhooks.generateTestHeaderString({
    payload,
    secret: options.secret ?? SECRET,
    ...(options.timestamp === undefined ? {} : { timestamp: options.timestamp }),
  });
}

/** 本物の Stripe が「もうありません」と言うときの形です */
function missingError(): Error {
  const error = new Error("No such subscription") as Error & {
    code?: string;
    statusCode?: number;
  };
  error.code = "resource_missing";
  error.statusCode = 404;
  return error;
}

type Retrieved = Stripe.Subscription | "missing" | "unreachable";

/** 署名の確かめだけ本物を使い、API を呼ぶところは作りものにします */
function webhookApi(
  options: { subscriptions?: Record<string, Retrieved>; calls?: string[] } = {},
): StripeWebhookApi {
  return {
    webhooks: stripe.webhooks,
    subscriptions: {
      async retrieve(id: string): Promise<Stripe.Subscription> {
        options.calls?.push(id);
        const found = options.subscriptions?.[id];
        if (found === undefined || found === "missing") throw missingError();
        if (found === "unreachable") throw new Error("つながりませんでした");
        return found;
      },
    },
  };
}

async function read(
  payload: string,
  options: {
    signature?: string | null;
    secret?: string;
    subscriptions?: Record<string, Retrieved>;
    calls?: string[];
  } = {},
) {
  return readStripeWebhook({
    stripe: webhookApi({ subscriptions: options.subscriptions, calls: options.calls }),
    secret: options.secret ?? SECRET,
    payload,
    signature: options.signature === undefined ? sign(payload) : options.signature,
    planIdOf,
    now: () => RETRIEVED_AT,
  });
}

// ---- つなぎ先の決め ----

describe("Stripe のつなぎ先", () => {
  it("待ち時間の上限を置き、送り直しは 1 回までにする", () => {
    // 待ち時間の上限がないと、Stripe が黙っているあいだ受け口の 1 本が塞がり、
    // 通知が渋滞します。送り直しは、呼び出しごとに添えた冪等性キーが効く
    // 範囲にとどめます（お申し込みが二重に立たないようにするためです）。
    const client = stripeClient("sk_test_dummy");
    expect(client.getApiField("timeout")).toBe(10_000);
    expect(client.getMaxNetworkRetries()).toBe(1);
  });

  it("API の版を書いてある（設定側の版で黙って動かさない）", () => {
    expect(stripeClient("sk_test_dummy").getApiField("version")).toBe(STRIPE_API_VERSION);
  });
});

// ---- subscriptionToRow ----

describe("Stripe の契約を、表に書く行に写す", () => {
  it("期間の終わり（秒）を、そのまま読める時刻に直す", () => {
    const row = subscriptionToRow(subscription(), planIdOf, RETRIEVED_AT);
    expect(row).toEqual({
      planId: "standard",
      status: "active",
      stripeSubscriptionId: SUBSCRIPTION,
      currentPeriodEnd: "2026-11-04T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: RETRIEVED_AT.toISOString(),
    });
  });

  it("期間の終わりが入っていない項目のときは、期間の終わりを空にする", () => {
    const row = subscriptionToRow(
      subscription({ currentPeriodEnd: null }),
      planIdOf,
      RETRIEVED_AT,
    );
    expect(row?.currentPeriodEnd).toBeNull();
    expect(row?.planId).toBe("standard");
  });

  it("項目が 1 つも無い契約は、プランを決められないので写さない", () => {
    expect(subscriptionToRow(subscription({ priceId: null }), planIdOf, RETRIEVED_AT)).toBeNull();
  });

  it("項目が 2 つ以上のときは、こちらのプランに当たる項目を使う", () => {
    // ほかの商品（お席の追加など）を同じご契約に足していらっしゃることがあります。
    // 並びの 1 つ目とはかぎらないので、当たる項目を探します。
    const row = subscriptionToRow(
      subscription({
        items: [
          { priceId: "price_someone_else", currentPeriodEnd: 1790000000 },
          { priceId: PRICE_STANDARD, currentPeriodEnd: PERIOD_END },
        ],
      }),
      planIdOf,
      RETRIEVED_AT,
    );

    expect(row?.planId).toBe("standard");
    // 期間の終わりも、その項目から採ります
    expect(row?.currentPeriodEnd).toBe("2026-11-04T00:00:00.000Z");
  });

  it("当たる項目が 2 つ以上あるときは、上のプランを採る", () => {
    // どちらの上限でお使いいただけるか決まらなくなるため、
    // お客さまに不利にならないほう（上のプラン）に寄せます。
    const upper = subscriptionToRow(
      subscription({
        items: [
          { priceId: PRICE_STANDARD, currentPeriodEnd: 1790000000 },
          { priceId: PRICE_BUSINESS, currentPeriodEnd: PERIOD_END },
        ],
      }),
      planIdOf,
      RETRIEVED_AT,
    );
    expect(upper?.planId).toBe("business");
    expect(upper?.currentPeriodEnd).toBe("2026-11-04T00:00:00.000Z");

    // 並びが逆でも、決まり方は同じです
    const reversed = subscriptionToRow(
      subscription({
        items: [
          { priceId: PRICE_BUSINESS, currentPeriodEnd: PERIOD_END },
          { priceId: PRICE_STANDARD, currentPeriodEnd: 1790000000 },
        ],
      }),
      planIdOf,
      RETRIEVED_AT,
    );
    expect(reversed?.planId).toBe("business");
    expect(reversed?.currentPeriodEnd).toBe("2026-11-04T00:00:00.000Z");
  });

  it("どの項目も当たらないご契約は、写さない", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      const row = subscriptionToRow(
        subscription({
          items: [{ priceId: "price_other_1" }, { priceId: "price_other_2" }],
        }),
        planIdOf,
        RETRIEVED_AT,
      );
      expect(row).toBeNull();

      const logged = warn.mock.calls.map((call) => call.join(" ")).join("\n");
      expect(logged).toContain("price_other_1");
      expect(logged).toContain("price_other_2");
      expect(logged).not.toContain(CUSTOMER);
      expect(logged).not.toContain(SUBSCRIPTION);
    } finally {
      warn.mockRestore();
    }
  });

  it("存じ上げない価格の契約は写さず、記録に出すのは価格の id だけ", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      const row = subscriptionToRow(
        subscription({ priceId: "price_someone_else" }),
        planIdOf,
        RETRIEVED_AT,
      );
      expect(row).toBeNull();

      const logged = warn.mock.calls.map((call) => call.join(" ")).join("\n");
      expect(logged).toContain("price_someone_else");
      // お客さまの id や契約の id は、記録にも出しません
      expect(logged).not.toContain(CUSTOMER);
      expect(logged).not.toContain(SUBSCRIPTION);
    } finally {
      warn.mockRestore();
    }
  });

  it("期間の終わりでのご解約の予定を、そのまま写す", () => {
    const row = subscriptionToRow(
      subscription({ cancelAtPeriodEnd: true }),
      planIdOf,
      RETRIEVED_AT,
    );
    expect(row?.cancelAtPeriodEnd).toBe(true);
  });

  it("新しい版の Stripe が cancel_at で知らせる解約の予定も、予定ありと写す", () => {
    const row = subscriptionToRow(
      subscription({ cancelAtPeriodEnd: false, cancelAt: PERIOD_END }),
      planIdOf,
      RETRIEVED_AT,
    );
    expect(row?.cancelAtPeriodEnd).toBe(true);
  });

  it("cancel_at が無ければ、予定なしのまま", () => {
    const row = subscriptionToRow(
      subscription({ cancelAtPeriodEnd: false, cancelAt: null }),
      planIdOf,
      RETRIEVED_AT,
    );
    expect(row?.cancelAtPeriodEnd).toBe(false);
  });

  it("存じ上げない状態のときは、書かずに止める", () => {
    expect(() =>
      subscriptionToRow(subscription({ status: "ended" }), planIdOf, RETRIEVED_AT),
    ).toThrow();
  });

  it("書き込みの時刻は、Stripe から取り直した時刻になる", () => {
    const later = new Date("2026-09-25T09:00:00.000Z");
    const row = subscriptionToRow(subscription(), planIdOf, later);
    expect(row?.updatedAt).toBe(later.toISOString());
  });

  it("その時刻は、取り直しが終わってから採る", async () => {
    // 取り直しにお時間がかかった分だけ、書き込みの時刻は後ろにずれます。
    // 呼ぶ前に採ると、いまの状態が実際より古い時刻で入り、
    // あとから届いた本当に新しい状態が「古い」と判じられかねません。
    const payload = eventPayload("customer.subscription.updated", subscription());
    let seconds = 0;

    const result = await readStripeWebhook({
      stripe: {
        webhooks: stripe.webhooks,
        subscriptions: {
          async retrieve(): Promise<Stripe.Subscription> {
            seconds += 30; // 取り直しのあいだに、時間が進みます
            return subscription();
          },
        },
      },
      secret: SECRET,
      payload,
      signature: sign(payload),
      planIdOf,
      now: () => new Date(Date.UTC(2026, 8, 20, 12, 0, seconds)),
    });

    expect(result.ok && result.change?.row?.updatedAt).toBe("2026-09-20T12:00:30.000Z");
  });
});

// ---- 署名の確かめ ----

describe("決済の通知の読み取り（署名の確かめ）", () => {
  it("(a) 正しい署名の通知は、そのまま読める", async () => {
    const payload = eventPayload("customer.subscription.updated", subscription());
    const result = await read(payload, { subscriptions: { [SUBSCRIPTION]: subscription() } });

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.eventId).toBe("evt_test_1");
    expect(result.eventType).toBe("customer.subscription.updated");
    expect(result.change?.stripeCustomerId).toBe(CUSTOMER);
  });

  it("(b) 署名が壊れているとき・そもそも無いときは、お受けしない", async () => {
    const payload = eventPayload("customer.subscription.updated", subscription());

    expect(await read(payload, { signature: "t=1,v1=0000" })).toEqual({
      ok: false,
      code: "bad_signature",
    });
    expect(await read(payload, { signature: null })).toEqual({
      ok: false,
      code: "bad_signature",
    });
    expect(await read(payload, { signature: "" })).toEqual({
      ok: false,
      code: "bad_signature",
    });
  });

  it("秘密が空のままでは、署名を確かめに進まずに止める", async () => {
    // 空の秘密で確かめに進むと、SDK の中の比べ方しだいで通ってしまいかねません。
    // ここで止めておけば、受け口が 5xx をお返しし、秘密を入れたあとに入り直します。
    const payload = eventPayload("customer.subscription.updated", subscription());

    await expect(
      readStripeWebhook({
        stripe: webhookApi(),
        secret: "",
        payload,
        signature: sign(payload),
        planIdOf,
        now: () => RETRIEVED_AT,
      }),
    ).rejects.toThrow();

    await expect(
      readStripeWebhook({
        stripe: webhookApi(),
        secret: "   ",
        payload,
        signature: sign(payload),
        planIdOf,
        now: () => RETRIEVED_AT,
      }),
    ).rejects.toThrow();
  });

  it("秘密をまだ頂戴していないときも、お受けしたことにしない", async () => {
    // 400 をお返しすると、Stripe は「送っても無駄」と受け取って送り直しません。
    // 止めておけば受け口が 5xx をお返しし、秘密を入れたあとに入り直します。
    const ports = createFakePorts({ now: () => NOW });
    const payload = eventPayload("customer.subscription.updated", subscription());

    for (const webhookSecret of [null, ""]) {
      const billing = createStripeBilling({
        stripe: billingApi({}),
        customers: ports.data,
        webhookSecret,
        priceIdOf: () => PRICE_STANDARD,
        planIdOf,
        now: () => RETRIEVED_AT,
      });

      await expect(
        billing.readWebhook({ payload, signature: sign(payload) }),
      ).rejects.toThrow();
    }
  });

  it("(c) 署名の時刻が古すぎるときは、お受けしない", async () => {
    const payload = eventPayload("customer.subscription.updated", subscription());
    const old = Math.floor(Date.now() / 1000) - 60 * 60;

    expect(await read(payload, { signature: sign(payload, { timestamp: old }) })).toEqual({
      ok: false,
      code: "bad_signature",
    });
  });

  it("(d) 別の秘密で署名された通知は、お受けしない", async () => {
    const payload = eventPayload("customer.subscription.updated", subscription());

    expect(
      await read(payload, { signature: sign(payload, { secret: OTHER_SECRET }) }),
    ).toEqual({ ok: false, code: "bad_signature" });
  });

  it("(e) 1 MiB を超える本文は、署名を確かめる前にお断りする", async () => {
    const big = JSON.stringify({ id: "evt_big", padding: "あ".repeat(WEBHOOK_MAX_BYTES) });
    expect(big.length).toBeGreaterThan(WEBHOOK_MAX_BYTES);

    const calls: string[] = [];
    const result = await readStripeWebhook({
      stripe: webhookApi({ calls }),
      secret: SECRET,
      payload: big,
      // 正しい署名でも、大きさで先にお断りします
      signature: sign(big),
      planIdOf,
      now: () => RETRIEVED_AT,
    });

    expect(result).toEqual({ ok: false, code: "too_large" });
    expect(calls).toEqual([]);
  });

  it("文字の数が上限以下でも、バイトの数で測ってお断りする", async () => {
    // 日本語は 1 文字 3 バイトです。文字の数で測ると、上限の 3 倍まで通ってしまいます。
    const big = JSON.stringify({ id: "evt_big_ja", padding: "あ".repeat(400_000) });
    expect(big.length).toBeLessThan(WEBHOOK_MAX_BYTES);
    expect(Buffer.byteLength(big, "utf8")).toBeGreaterThan(WEBHOOK_MAX_BYTES);

    const calls: string[] = [];
    const result = await readStripeWebhook({
      stripe: webhookApi({ calls }),
      secret: SECRET,
      payload: big,
      signature: sign(big),
      planIdOf,
      now: () => RETRIEVED_AT,
    });

    expect(result).toEqual({ ok: false, code: "too_large" });
    expect(calls).toEqual([]);
  });

  it("(f) 扱わない種類の通知は、受け取るだけで何もしない", async () => {
    for (const type of ["customer.created", "invoice.paid", "charge.succeeded"]) {
      const payload = eventPayload(type, { id: "obj_1", object: "customer" }, `evt_${type}`);
      const calls: string[] = [];
      const result = await read(payload, { calls });

      expect(result, type).toEqual({
        ok: true,
        eventId: `evt_${type}`,
        eventType: type,
        change: null,
      });
      expect(calls, type).toEqual([]);
    }
  });
});

// ---- 5 つの通知の中身 ----

describe("決済の通知の読み取り（5 つの種類）", () => {
  it("ご契約の更新は、通知の中身ではなく Stripe から取り直した状態を書く", async () => {
    // 通知の中身は canceled、Stripe の本当の状態は active です
    const payload = eventPayload(
      "customer.subscription.updated",
      subscription({ status: "canceled" }),
    );
    const calls: string[] = [];
    const result = await read(payload, {
      calls,
      subscriptions: { [SUBSCRIPTION]: subscription({ status: "active" }) },
    });

    expect(calls).toEqual([SUBSCRIPTION]);
    expect(result.ok && result.change?.row?.status).toBe("active");
  });

  it("ご契約の始まりも、同じように取り直す", async () => {
    const payload = eventPayload("customer.subscription.created", subscription());
    const calls: string[] = [];
    await read(payload, { calls, subscriptions: { [SUBSCRIPTION]: subscription() } });

    expect(calls).toEqual([SUBSCRIPTION]);
  });

  it("ご解約の通知でも取り直し、もう無いときだけ契約を消す形にする", async () => {
    const payload = eventPayload("customer.subscription.deleted", subscription());
    const calls: string[] = [];
    const result = await read(payload, { calls, subscriptions: { [SUBSCRIPTION]: "missing" } });

    expect(calls).toEqual([SUBSCRIPTION]);
    expect(result).toEqual({
      ok: true,
      eventId: "evt_test_1",
      eventType: "customer.subscription.deleted",
      change: { stripeCustomerId: CUSTOMER, row: null },
    });
  });

  it("ご解約の通知が遅れて届いても、お支払いが続いていれば消さない", async () => {
    const payload = eventPayload("customer.subscription.deleted", subscription());
    const result = await read(payload, {
      subscriptions: { [SUBSCRIPTION]: subscription({ status: "active" }) },
    });

    expect(result.ok && result.change?.row?.status).toBe("active");
  });

  it("ご解約のあとの状態（canceled）を取り直せたときは、契約を消す形にする", async () => {
    const payload = eventPayload("customer.subscription.deleted", subscription());
    const result = await read(payload, {
      subscriptions: { [SUBSCRIPTION]: subscription({ status: "canceled" }) },
    });

    expect(result.ok && result.change?.row).toBeNull();
  });

  it("ご解約以外の通知で「もうありません」と返ってきたときは、契約を消さずに止める", async () => {
    // 取り直しの 404 は、一時のことで起こります（作られた直後・向け先の取り違えなど）。
    // ここをご解約に倒すと、お支払い中の組織が黙って無料に落ちます。
    // 止めれば受け口が 5xx をお返しし、Stripe が送り直してくださいます。
    const cases: [string, unknown][] = [
      ["customer.subscription.created", subscription()],
      ["customer.subscription.updated", subscription()],
      [
        "checkout.session.completed",
        {
          id: "cs_missing",
          object: "checkout.session",
          customer: CUSTOMER,
          subscription: SUBSCRIPTION,
          mode: "subscription",
        },
      ],
      [
        "invoice.payment_failed",
        {
          id: "in_missing",
          object: "invoice",
          customer: CUSTOMER,
          parent: {
            type: "subscription_details",
            quote_details: null,
            subscription_details: { subscription: SUBSCRIPTION, metadata: null },
          },
        },
      ],
    ];

    for (const [type, object] of cases) {
      const payload = eventPayload(type, object, `evt_${type}_missing`);
      await expect(
        read(payload, { subscriptions: { [SUBSCRIPTION]: "missing" } }),
        type,
      ).rejects.toThrow();
    }
  });

  it("Stripe につながらないときは、お返事を返さずに送り直していただく", async () => {
    const payload = eventPayload("customer.subscription.updated", subscription());
    await expect(read(payload, { subscriptions: { [SUBSCRIPTION]: "unreachable" } })).rejects.toThrow();
  });

  it("お申し込みが済んだ通知は、その契約を取り直して書く", async () => {
    const session = {
      id: "cs_test_1",
      object: "checkout.session",
      customer: CUSTOMER,
      subscription: SUBSCRIPTION,
      mode: "subscription",
    };
    const payload = eventPayload("checkout.session.completed", session);
    const calls: string[] = [];
    const result = await read(payload, {
      calls,
      subscriptions: { [SUBSCRIPTION]: subscription() },
    });

    expect(calls).toEqual([SUBSCRIPTION]);
    expect(result.ok && result.change).toEqual({
      stripeCustomerId: CUSTOMER,
      row: {
        planId: "standard",
        status: "active",
        stripeSubscriptionId: SUBSCRIPTION,
        currentPeriodEnd: "2026-11-04T00:00:00.000Z",
        cancelAtPeriodEnd: false,
        updatedAt: RETRIEVED_AT.toISOString(),
      },
    });
  });

  it("お申し込みにご契約がひもづいていないときは、何もしない（落ちない）", async () => {
    const session = {
      id: "cs_test_2",
      object: "checkout.session",
      customer: CUSTOMER,
      subscription: null,
      mode: "payment",
    };
    const payload = eventPayload("checkout.session.completed", session);
    const calls: string[] = [];
    const result = await read(payload, { calls });

    expect(result.ok && result.change).toBeNull();
    expect(calls).toEqual([]);
  });

  it("ご契約のお申し込み以外のお支払いは、受け取るだけで何もしない", async () => {
    // 買い切りやお支払い方法のご登録でも、この通知は届きます。
    // ご契約のお手続き（subscription）以外は、表を触りません。
    for (const mode of ["payment", "setup"]) {
      const session = {
        id: `cs_${mode}`,
        object: "checkout.session",
        customer: CUSTOMER,
        // ひもづきが入っていても、お手続きの種類が違えば見ません
        subscription: SUBSCRIPTION,
        mode,
      };
      const calls: string[] = [];
      const result = await read(eventPayload("checkout.session.completed", session, `evt_${mode}`), {
        calls,
        subscriptions: { [SUBSCRIPTION]: subscription() },
      });

      expect(result.ok && result.change, mode).toBeNull();
      expect(calls, mode).toEqual([]);
    }
  });

  it("お支払いに失敗した知らせは、請求からご契約をたどって取り直す", async () => {
    const invoice = {
      id: "in_test_1",
      object: "invoice",
      customer: CUSTOMER,
      parent: {
        type: "subscription_details",
        quote_details: null,
        subscription_details: { subscription: SUBSCRIPTION, metadata: null },
      },
    };
    const payload = eventPayload("invoice.payment_failed", invoice);
    const calls: string[] = [];
    const result = await read(payload, {
      calls,
      subscriptions: { [SUBSCRIPTION]: subscription({ status: "past_due" }) },
    });

    expect(calls).toEqual([SUBSCRIPTION]);
    expect(result.ok && result.change?.row?.status).toBe("past_due");
  });

  it("ご契約のない請求の知らせは、何もしない", async () => {
    const invoice = { id: "in_test_2", object: "invoice", customer: CUSTOMER, parent: null };
    const payload = eventPayload("invoice.payment_failed", invoice);
    const calls: string[] = [];
    const result = await read(payload, { calls });

    expect(result.ok && result.change).toBeNull();
    expect(calls).toEqual([]);
  });

  it("お客さまの id が入っていない通知は、何もしない", async () => {
    const payload = eventPayload(
      "customer.subscription.updated",
      { ...subscription(), customer: null },
    );
    const result = await read(payload, { subscriptions: { [SUBSCRIPTION]: subscription() } });

    expect(result.ok && result.change).toBeNull();
  });

  it("(j) 存じ上げない価格のご契約は、ご解約とは分けて『何もしない』にする", async () => {
    // ここを row: null にすると、別の商品のご契約でこちらの契約が消えてしまいます
    const payload = eventPayload("customer.subscription.updated", subscription());
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      const result = await read(payload, {
        subscriptions: { [SUBSCRIPTION]: subscription({ priceId: "price_someone_else" }) },
      });
      expect(result.ok && result.change).toBeNull();
    } finally {
      warn.mockRestore();
    }
  });
});

// ---- お申し込みとお手続きの画面 ----

type CustomerCall = {
  email: string | undefined;
  name: string | undefined;
  key: string | undefined;
};

/**
 * 同じ冪等性キーを、**違う引数**でお使いになったときの誤りです。
 * 本物の Stripe はこれをお返しになるので、作りものも同じ厳しさにします
 * （引数のそろわない鍵を付けてしまうと、ここで気づけます）。
 */
function idempotencyError(key: string): Error {
  return new Stripe.errors.StripeIdempotencyError({
    type: "idempotency_error",
    message:
      `Keys for idempotent requests can only be used with the same parameters ` +
      `they were first used with. Try using a key other than '${key}'.`,
  });
}

/**
 * 冪等性キーの控えです。本物の Stripe と同じく
 *   ① 同じ鍵・同じ引数 … 1 回目のお返事をそのままお返しします
 *   ② 同じ鍵・違う引数 … idempotency_error でお断りします
 * の 2 つに分かれます。
 */
function idempotencyStore<T>(): (key: string | undefined, params: unknown, make: () => T) => T {
  const seen = new Map<string, { params: string; value: T }>();

  return (key, params, make) => {
    if (key === undefined) return make();

    const shape = JSON.stringify(params);
    const found = seen.get(key);
    if (found !== undefined) {
      if (found.params !== shape) throw idempotencyError(key);
      return found.value;
    }

    const value = make();
    seen.set(key, { params: shape, value });
    return value;
  };
}

function billingApi(options: {
  sessionUrl?: string | null;
  customers?: CustomerCall[];
  sessions?: Stripe.Checkout.SessionCreateParams[];
  sessionKeys?: (string | undefined)[];
  portals?: Stripe.BillingPortal.SessionCreateParams[];
  failWith?: Error;
}): StripeBillingApi {
  const customerKeys = idempotencyStore<Stripe.Customer>();
  const sessionKeys = idempotencyStore<Stripe.Checkout.Session>();
  let made = 0;
  let opened = 0;

  return {
    ...webhookApi(),
    customers: {
      async create(params, requestOptions) {
        const key = requestOptions?.idempotencyKey;
        options.customers?.push({ email: params.email, name: params.name, key });

        return customerKeys(key, params, () => {
          made += 1;
          return { id: `cus_made_${made}`, object: "customer" } as unknown as Stripe.Customer;
        });
      },
    },
    checkout: {
      sessions: {
        async create(params, requestOptions) {
          if (options.failWith !== undefined) throw options.failWith;
          const key = requestOptions?.idempotencyKey;
          options.sessions?.push(params);
          options.sessionKeys?.push(key);

          return sessionKeys(key, params, () => {
            opened += 1;
            return {
              id: `cs_made_${opened}`,
              object: "checkout.session",
              url:
                options.sessionUrl === undefined
                  ? `https://checkout.example/${opened}`
                  : options.sessionUrl,
            } as unknown as Stripe.Checkout.Session;
          });
        },
      },
    },
    billingPortal: {
      sessions: {
        async create(params) {
          if (options.failWith !== undefined) throw options.failWith;
          options.portals?.push(params);
          return {
            id: "bps_made_1",
            object: "billing_portal.session",
            url: "https://portal.example/1",
          } as unknown as Stripe.BillingPortal.Session;
        },
      },
    },
  };
}

/** 時計は、お渡しがなければ止めたままにします（お申し込みの鍵の区切りが動かないようにです） */
function billingFor(api: StripeBillingApi, ports: Ports, now: () => Date = () => RETRIEVED_AT) {
  return createStripeBilling({
    stripe: api,
    customers: ports.data,
    webhookSecret: SECRET,
    priceIdOf: (planId) =>
      planId === "standard" ? PRICE_STANDARD : planId === "business" ? PRICE_BUSINESS : null,
    planIdOf,
    now,
  });
}

const CHECKOUT_INPUT = {
  organizationId: "org-1",
  organizationName: "しおさい設計室",
  planId: "standard" as const,
  successUrl: "https://example.com/app/settings/billing?checkout=done",
  cancelUrl: "https://example.com/app/settings/billing?checkout=canceled",
  lang: "ja" as const,
};

describe("お申し込み（Checkout）", () => {
  it("Price の環境変数が入っていないプランは、設定が足りない旨をお返しする", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const billing = billingFor(billingApi({}), ports);

    expect(await billing.createCheckoutUrl({ ...CHECKOUT_INPUT, planId: "free" })).toEqual({
      ok: false,
      code: "not_configured",
    });
  });

  it("渡された戻り先だけを Stripe にお渡しし、日本語のときは日本語の画面にする", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const sessions: Stripe.Checkout.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ sessions }), ports);

    const result = await billing.createCheckoutUrl(CHECKOUT_INPUT);
    expect(result).toEqual({ ok: true, url: "https://checkout.example/1" });

    const params = sessions[0];
    expect(params.mode).toBe("subscription");
    expect(params.line_items).toEqual([{ price: PRICE_STANDARD, quantity: 1 }]);
    expect(params.success_url).toBe(CHECKOUT_INPUT.successUrl);
    expect(params.cancel_url).toBe(CHECKOUT_INPUT.cancelUrl);
    expect(params.locale).toBe("ja");
  });

  it("日本語以外のときは、Stripe にお任せの言葉づかいにする", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const sessions: Stripe.Checkout.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ sessions }), ports);

    await billing.createCheckoutUrl({ ...CHECKOUT_INPUT, lang: "en" });
    expect(sessions[0].locale).toBe("auto");
  });

  it("すでに表にあるお客さまは、作り直さずに使い回す", async () => {
    const ports = createFakePorts({ now: () => NOW });
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const customers: CustomerCall[] = [];
    const sessions: Stripe.Checkout.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ customers, sessions }), ports);

    await billing.createCheckoutUrl(CHECKOUT_INPUT);
    expect(customers).toEqual([]);
    expect(sessions[0].customer).toBe(CUSTOMER);
    expect(sessions[0].customer_email).toBeUndefined();
  });

  it("表にまだ無いときは、お客さまを作って表に控える", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const customers: CustomerCall[] = [];
    const sessions: Stripe.Checkout.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ customers, sessions }), ports);

    await billing.createCheckoutUrl(CHECKOUT_INPUT);

    expect(customers).toHaveLength(1);
    // お渡しするのは組織のお名前だけです。どなたのメールアドレスも添えません
    // （組織ごとに決まる冪等性キーと、引数をそろえるためです）。
    expect(customers[0].name).toBe("しおさい設計室");
    expect(customers[0].email).toBeUndefined();
    expect(sessions[0].customer).toBe("cus_made_1");
    expect(await ports.data.getStripeCustomer("org-1")).toEqual({
      organizationId: "org-1",
      stripeCustomerId: "cus_made_1",
    });
  });

  it("オーナーが 2 人の組織で、2 人目もお申し込みになれる", async () => {
    // お客さまを作るときの引数にメールアドレスを入れていると、
    // 同じ冪等性キーに違う引数を添えることになり、Stripe が idempotency_error で
    // お断りになります（2 人目がお申し込みになれません）。
    const ports = createFakePorts({ now: () => NOW });
    const customers: CustomerCall[] = [];
    const sessions: Stripe.Checkout.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ customers, sessions }), ports);

    const first = await billing.createCheckoutUrl(CHECKOUT_INPUT);
    // 2 人目は、控えが取れる前に押されたことにします（表を空に戻します）
    ports.store.stripeCustomers.delete("org-1");
    const second = await billing.createCheckoutUrl(CHECKOUT_INPUT);

    expect(first.ok).toBe(true);
    expect(second.ok).toBe(true);

    // 鍵も引数も組織ごとに決まるので、お客さまは 1 人のままです
    expect(new Set(customers.map((call) => call.key)).size).toBe(1);
    expect(new Set(sessions.map((params) => params.customer))).toEqual(new Set(["cus_made_1"]));
  });

  it("同じときに 2 回お申し込みになっても、お客さまは 1 人しかできない", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const customers: CustomerCall[] = [];
    const sessions: Stripe.Checkout.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ customers, sessions }), ports);

    await Promise.all([
      billing.createCheckoutUrl(CHECKOUT_INPUT),
      billing.createCheckoutUrl(CHECKOUT_INPUT),
    ]);

    // 組織ごとに決まる冪等性キーを付けているので、Stripe 側では 1 人にまとまります
    const keys = customers.map((call) => call.key);
    expect(new Set(keys).size).toBe(1);
    expect(keys[0]).toBeDefined();
    expect(new Set(sessions.map((params) => params.customer)).size).toBe(1);
    expect(await ports.data.getStripeCustomer("org-1")).toEqual({
      organizationId: "org-1",
      stripeCustomerId: "cus_made_1",
    });
  });

  it("続けて押されても、お申し込みは 1 本にまとまる", async () => {
    // 連打や二重の送信で 2 本立つと、二重にご請求してしまいます。
    // 鍵を添えておけば、Stripe が 1 回目のお申し込みをそのままお返しになります。
    const ports = createFakePorts({ now: () => NOW });
    const sessionKeys: (string | undefined)[] = [];
    const billing = billingFor(billingApi({ sessionKeys }), ports);

    const [first, second] = await Promise.all([
      billing.createCheckoutUrl(CHECKOUT_INPUT),
      billing.createCheckoutUrl(CHECKOUT_INPUT),
    ]);

    expect(first).toEqual({ ok: true, url: "https://checkout.example/1" });
    expect(second).toEqual(first);
    expect(new Set(sessionKeys).size).toBe(1);
    expect(sessionKeys[0]).toContain("org-1");
    expect(sessionKeys[0]).toContain("standard");
  });

  it("お申し込みの鍵は、組織とプランごとに分かれる", async () => {
    // プランをお選び直しになったときに、前のお申し込みが返ってしまわないようにします
    const ports = createFakePorts({ now: () => NOW });
    const sessionKeys: (string | undefined)[] = [];
    const billing = billingFor(billingApi({ sessionKeys }), ports);

    await billing.createCheckoutUrl(CHECKOUT_INPUT);
    await billing.createCheckoutUrl({ ...CHECKOUT_INPUT, planId: "business" });

    expect(new Set(sessionKeys).size).toBe(2);
  });

  it("お申し込みの鍵は、10 分で区切られる", async () => {
    // Stripe の冪等性キーは 24 時間効きます。区切りが無いと、ご解約の直後に
    // 同じプランへお申し込み直されたときに、もう終わったお申し込みの画面が
    // そのまま返り、お客さまが進めない画面へお通ししてしまいます。
    const ports = createFakePorts({ now: () => NOW });
    const sessionKeys: (string | undefined)[] = [];
    let clock = new Date("2026-09-20T12:00:00.000Z");
    const billing = billingFor(billingApi({ sessionKeys }), ports, () => clock);

    const first = await billing.createCheckoutUrl(CHECKOUT_INPUT);
    clock = new Date("2026-09-20T12:09:59.999Z");
    const second = await billing.createCheckoutUrl(CHECKOUT_INPUT);
    clock = new Date("2026-09-20T12:10:00.000Z");
    const third = await billing.createCheckoutUrl(CHECKOUT_INPUT);

    // 同じ区切りの中は、1 本にまとまります（連打と二重の送信のお守りです）
    expect(sessionKeys[1]).toBe(sessionKeys[0]);
    expect(second).toEqual(first);
    // 区切りをまたぐと、新しいお申し込みの画面をお出しします
    expect(sessionKeys[2]).not.toBe(sessionKeys[0]);
    expect(third).not.toEqual(first);
  });

  it("言葉づかいの違うお二人が押されても、お断りしない", async () => {
    // お申し込みの画面の言葉づかいは、押した方のお好みで変わります。
    // 鍵をそのままにして引数だけ変えると、Stripe が idempotency_error で
    // お断りになり、2 人目がお申し込みになれません。
    const ports = createFakePorts({ now: () => NOW });
    const billing = billingFor(billingApi({}), ports);

    const ja = await billing.createCheckoutUrl(CHECKOUT_INPUT);
    const en = await billing.createCheckoutUrl({ ...CHECKOUT_INPUT, lang: "en" });

    expect(ja.ok).toBe(true);
    expect(en.ok).toBe(true);
  });

  it("Stripe が行き先をお返しにならないときは、一時的にお使いいただけない旨をお返しする", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const billing = billingFor(billingApi({ sessionUrl: null }), ports);

    expect(await billing.createCheckoutUrl(CHECKOUT_INPUT)).toEqual({
      ok: false,
      code: "unavailable",
    });
  });

  it("Stripe が止まっているときも、誤りの中身は持ち帰らない", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const error = new Error("Invalid API Key provided: sk_test_******");
    const billing = billingFor(billingApi({ failWith: error }), ports);

    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      const result = await billing.createCheckoutUrl(CHECKOUT_INPUT);
      // 持ち帰るのは符号だけで、Stripe の文は記録にしか残りません
      expect(result).toEqual({ ok: false, code: "unavailable" });
      expect(logged).toHaveBeenCalled();
      expect(JSON.stringify(result)).not.toContain("API Key");
    } finally {
      logged.mockRestore();
    }
  });

  it("Stripe の誤りは、記録にも種類と符号だけを残す", async () => {
    // Stripe の message には、メールアドレスや id がそのまま入ることがあります。
    // サーバーの記録に残すのは、種類（type）と符号（code）だけにします。
    const ports = createFakePorts({ now: () => NOW });
    const error = new Stripe.errors.StripeInvalidRequestError({
      type: "invalid_request_error",
      message: "No such customer: 'cus_secret_1' for owner@example.com",
      code: "resource_missing",
    });
    const billing = billingFor(billingApi({ failWith: error }), ports);

    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      expect(await billing.createCheckoutUrl(CHECKOUT_INPUT)).toEqual({
        ok: false,
        code: "unavailable",
      });

      const text = logged.mock.calls.map((call) => call.join(" ")).join("\n");
      expect(text).toContain("StripeInvalidRequestError");
      expect(text).toContain("resource_missing");
      expect(text).not.toContain("owner@example.com");
      expect(text).not.toContain("cus_secret_1");
    } finally {
      logged.mockRestore();
    }
  });
});

describe("お手続きの画面（Customer Portal）", () => {
  it("まだお客さまが表に無いときは、お手続きの画面をお出ししない", async () => {
    const ports = createFakePorts({ now: () => NOW });
    const billing = billingFor(billingApi({}), ports);

    expect(
      await billing.createPortalUrl({
        organizationId: "org-1",
        returnUrl: "https://example.com/app/settings/billing",
        lang: "ja",
      }),
    ).toEqual({ ok: false, code: "no_customer" });
  });

  it("表のお客さまで開き、戻り先は渡された URL のままにする", async () => {
    const ports = createFakePorts({ now: () => NOW });
    await ports.data.setStripeCustomer("org-1", CUSTOMER);

    const portals: Stripe.BillingPortal.SessionCreateParams[] = [];
    const billing = billingFor(billingApi({ portals }), ports);

    const result = await billing.createPortalUrl({
      organizationId: "org-1",
      returnUrl: "https://example.com/app/settings/billing",
      lang: "ja",
    });

    expect(result).toEqual({ ok: true, url: "https://portal.example/1" });
    expect(portals[0]).toEqual({
      customer: CUSTOMER,
      return_url: "https://example.com/app/settings/billing",
      locale: "ja",
    });
  });
});

// ---- 表に写すところまで（flow と合わせて） ----

describe("決済の通知を、表に写すところまで", () => {
  /** 見本のデータの組（org-1）に、本物の決済のつなぎ役を差し込んだ一式です */
  async function setup() {
    const ports = createFakePorts({ now: () => NOW });
    await ports.data.setStripeCustomer("org-1", CUSTOMER);
    return ports;
  }

  /**
   * 決済の通知を 1 通お届けします。
   * retrievedAt は「つなぎ役が Stripe から状態を取り直した時刻」で、
   * 順不同の通知を並べ直すのに使う時刻です。
   */
  async function deliver(
    ports: FakePorts,
    payload: string,
    options: {
      subscriptions?: Record<string, Retrieved>;
      retrievedAt?: Date;
      receivedAt?: Date;
    } = {},
  ) {
    const billing = createStripeBilling({
      stripe: { ...billingApi({}), ...webhookApi({ subscriptions: options.subscriptions }) },
      customers: ports.data,
      webhookSecret: SECRET,
      priceIdOf: (planId) => (planId === "standard" ? PRICE_STANDARD : null),
      planIdOf,
      now: () => options.retrievedAt ?? RETRIEVED_AT,
    });

    return applyWebhookFlow({
      ports: { ...ports, billing } satisfies Ports,
      payload,
      signature: sign(payload),
      now: options.receivedAt ?? NOW,
    });
  }

  it("(g) 同じ通知をもう一度いただいても、二度は書かない", async () => {
    const ports = await setup();
    const payload = eventPayload("customer.subscription.updated", subscription(), "evt_same");
    const subscriptions = { [SUBSCRIPTION]: subscription() };

    const first = await deliver(ports, payload, { subscriptions });
    const second = await deliver(ports, payload, { subscriptions });

    expect(first).toEqual({ ok: true, value: { eventId: "evt_same", applied: true } });
    expect(second).toEqual({ ok: true, value: { eventId: "evt_same", applied: false } });
    expect(ports.store.stripeEvents.size).toBe(1);
  });

  it("(h) ご解約のあとに、それより古いご契約の更新が届いても、元に戻さない", async () => {
    const ports = await setup();

    // ① まずご契約が入ります
    await deliver(ports, eventPayload("customer.subscription.updated", subscription(), "evt_1"), {
      subscriptions: { [SUBSCRIPTION]: subscription() },
      retrievedAt: new Date("2026-09-20T00:00:00.000Z"),
    });
    expect(ports.store.subscriptions.get("org-1")?.status).toBe("active");

    // ② ご解約（Stripe 側にはもう契約がありません）
    await deliver(ports, eventPayload("customer.subscription.deleted", subscription(), "evt_2"), {
      subscriptions: { [SUBSCRIPTION]: "missing" },
      receivedAt: new Date("2026-09-21T00:00:00.000Z"),
    });
    expect(ports.store.subscriptions.get("org-1")?.status).toBe("canceled");

    // ③ ご解約より前に取り直した更新が、遅れて届きます
    const stale = await deliver(
      ports,
      eventPayload("customer.subscription.updated", subscription(), "evt_3"),
      {
        subscriptions: { [SUBSCRIPTION]: subscription() },
        retrievedAt: new Date("2026-09-19T00:00:00.000Z"),
        receivedAt: new Date("2026-09-22T00:00:00.000Z"),
      },
    );

    expect(stale).toEqual({ ok: true, value: { eventId: "evt_3", applied: false } });
    expect(ports.store.subscriptions.get("org-1")?.status).toBe("canceled");
  });

  it("(i) 存じ上げないお客さまの通知は、静かに捨てる", async () => {
    const ports = await setup();
    const other = subscription({ id: "sub_other", customer: "cus_unknown" });
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});

    try {
      const result = await deliver(
        ports,
        eventPayload("customer.subscription.updated", other, "evt_unknown"),
        { subscriptions: { sub_other: other } },
      );

      expect(result).toEqual({ ok: true, value: { eventId: "evt_unknown", applied: false } });
      expect(ports.store.subscriptions.size).toBe(0);
    } finally {
      warn.mockRestore();
    }
  });

  it("存じ上げないお客さまの通知は、気づけるように記録へ 1 行だけ残す", async () => {
    // ダッシュボードから直にご契約をお作りになった場合などに届きます。
    // 何も残さないと、買い手が「通知が入らない」と気づいたときの手がかりが
    // ありません。お客さまの id は先頭だけにし、個人の知らせは出しません。
    const ports = await setup();
    const other = subscription({ id: "sub_other", customer: "cus_unknown_customer_1" });
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});

    try {
      await deliver(
        ports,
        eventPayload("customer.subscription.updated", other, "evt_unknown_2"),
        { subscriptions: { sub_other: other } },
      );

      expect(warn).toHaveBeenCalledTimes(1);
      const line = String(warn.mock.calls[0]?.[0] ?? "");
      expect(line).toContain("cus_unkn");
      expect(line).toContain("customer.subscription.updated");
      // お客さまの id を、そのまま記録に残すことはしません
      expect(line).not.toContain("cus_unknown_customer_1");
    } finally {
      warn.mockRestore();
    }
  });

  it("(k) 本文に別の組織の id が紛れていても、表で引いた組織にしか書かない", async () => {
    const ports = await setup();
    const session = {
      id: "cs_test_3",
      object: "checkout.session",
      customer: CUSTOMER,
      subscription: SUBSCRIPTION,
      mode: "subscription",
      // 送り主が名乗る組織です（信用しません）
      client_reference_id: "org-2",
      metadata: { organization_id: "org-2" },
    };

    await deliver(ports, eventPayload("checkout.session.completed", session, "evt_spoof"), {
      subscriptions: { [SUBSCRIPTION]: subscription() },
    });

    expect(ports.store.subscriptions.get("org-1")?.planId).toBe("standard");
    expect(ports.store.subscriptions.get("org-2")).toBeUndefined();
  });

  it("同じ通知が同時に 2 通届いても、記録は 1 件で、表も同じところに落ち着く", async () => {
    // 送り直しが重なったときの形です。どちらの順で終わっても、
    // 記録が増えたり、別の組織に行ったりしないことを確かめます。
    const ports = await setup();
    const payload = eventPayload("customer.subscription.updated", subscription(), "evt_race");
    const subscriptions = { [SUBSCRIPTION]: subscription() };

    const [first, second] = await Promise.all([
      deliver(ports, payload, { subscriptions }),
      deliver(ports, payload, { subscriptions }),
    ]);

    expect(first.ok, "1 通目").toBe(true);
    expect(second.ok, "2 通目").toBe(true);
    expect(ports.store.stripeEvents.size).toBe(1);
    expect(ports.store.subscriptions.size).toBe(1);

    const row = ports.store.subscriptions.get("org-1");
    expect(row?.planId).toBe("standard");
    expect(row?.status).toBe("active");
    expect(row?.updatedAt).toBe(RETRIEVED_AT.toISOString());
  });

  it("違う通知が同時に 2 通届いても、あとに残るのは必ず新しいほうの状態", async () => {
    /**
     * ご解約の瞬間に起きる形です。
     *
     * 決済のしくみは通知の順序を約束せず、**並べて**配ります。
     * ご解約（新しい）とお支払いの失敗（古い）が同時に届いたとき、
     * 「いまの行を読む → 比べる → 書く」を 2 回に分けていると、
     * どちらも同じ古い行を読み、古いほうがあとから書いてしまいます。
     * そうなると、ご解約のあともずっと有料のプランの上限のままで、
     * どちらの event も記録済みなので、決済のしくみは送り直してくれません。
     *
     * 届く順を入れ替えても、あとに残るのが必ず新しいほうであることを見ます。
     */
    const OLD = new Date("2026-09-20T12:00:00.000Z");
    const NEW = new Date("2026-09-20T12:00:30.000Z");
    const BASE = new Date("2026-09-20T11:00:00.000Z");

    const failedInvoice = {
      id: "in_race",
      object: "invoice",
      customer: CUSTOMER,
      parent: {
        type: "subscription_details",
        quote_details: null,
        subscription_details: { subscription: SUBSCRIPTION, metadata: null },
      },
    };

    for (const order of ["古い順", "新しい順"] as const) {
      const ports = await setup();

      // まず、ご契約が 1 本入っている状態にします
      await deliver(
        ports,
        eventPayload("customer.subscription.updated", subscription(), "evt_base"),
        { subscriptions: { [SUBSCRIPTION]: subscription() }, retrievedAt: BASE, receivedAt: BASE },
      );
      expect(ports.store.subscriptions.get("org-1")?.status, order).toBe("active");

      // 古いほう: お支払いの失敗（past_due）。取り直した時刻は 12:00:00
      const stale = () =>
        deliver(ports, eventPayload("invoice.payment_failed", failedInvoice, "evt_stale"), {
          subscriptions: { [SUBSCRIPTION]: subscription({ status: "past_due" }) },
          retrievedAt: OLD,
          receivedAt: OLD,
        });

      // 新しいほう: ご解約。受け取った時刻は 12:00:30
      const fresh = () =>
        deliver(
          ports,
          eventPayload(
            "customer.subscription.deleted",
            subscription({ status: "canceled" }),
            "evt_fresh",
          ),
          {
            subscriptions: { [SUBSCRIPTION]: subscription({ status: "canceled" }) },
            retrievedAt: NEW,
            receivedAt: NEW,
          },
        );

      const both = order === "古い順" ? [stale, fresh] : [fresh, stale];
      const [one, two] = await Promise.all(both.map((send) => send()));

      expect(one.ok, `${order} 1 通目`).toBe(true);
      expect(two.ok, `${order} 2 通目`).toBe(true);
      // どちらの event も、二度と送られてきません（記録は 3 件です）
      expect(ports.store.stripeEvents.size, order).toBe(3);

      // あとに残るのは、必ず新しいほう（ご解約）です
      const row = ports.store.subscriptions.get("org-1");
      expect(row?.status, order).toBe("canceled");
      expect(row?.planId, order).toBe("free");
      expect(row?.updatedAt, order).toBe(NEW.toISOString());
      // あとからお調べになれるよう、決済の契約の番号は残ります
      expect(row?.stripeSubscriptionId, order).toBe(SUBSCRIPTION);
    }
  });

  it("(j) 知らない価格の通知では、ご契約を消さない", async () => {
    const ports = await setup();
    await deliver(ports, eventPayload("customer.subscription.updated", subscription(), "evt_a"), {
      subscriptions: { [SUBSCRIPTION]: subscription() },
    });
    expect(ports.store.subscriptions.get("org-1")?.status).toBe("active");

    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      const result = await deliver(
        ports,
        eventPayload("customer.subscription.updated", subscription(), "evt_b"),
        {
          subscriptions: { [SUBSCRIPTION]: subscription({ priceId: "price_someone_else" }) },
          retrievedAt: new Date("2026-09-25T00:00:00.000Z"),
        },
      );
      expect(result).toEqual({ ok: true, value: { eventId: "evt_b", applied: false } });
    } finally {
      warn.mockRestore();
    }

    expect(ports.store.subscriptions.get("org-1")?.status).toBe("active");
  });
});

// ---- 通知の受け口（本文の読み方とお返事） ----

describe("決済の通知の受け口", () => {
  function requestOf(body: string, headers: Record<string, string> = {}): Request {
    return new Request("https://example.com/api/stripe/webhook", {
      method: "POST",
      headers,
      body,
    });
  }

  it("本文は、JSON に直さずそのままの文字で受け取る", async () => {
    const payload = eventPayload("customer.subscription.updated", subscription());
    const result = await readWebhookBody(requestOf(payload));

    expect(result).toEqual({ ok: true, payload });
  });

  it("Content-Length が上限を超えているときは、本文を読まずにお断りする", async () => {
    const request = new Request("https://example.com/api/stripe/webhook", {
      method: "POST",
      headers: { "content-length": String(WEBHOOK_MAX_BYTES + 1) },
      body: "{}",
    });

    expect(await readWebhookBody(request)).toEqual({ ok: false });
  });

  it("Content-Length が無くても、流れを数えて途中で打ち切る", async () => {
    // 100 バイトずつ、いつまでも流れてくる本文です（上限で止まらなければ終わりません）
    const chunk = new Uint8Array(100).fill(0x61);
    let sent = 0;
    const body = new ReadableStream<Uint8Array>({
      pull(controller) {
        sent += chunk.byteLength;
        controller.enqueue(chunk);
      },
    });
    const request = new Request("https://example.com/api/stripe/webhook", {
      method: "POST",
      body,
      // @ts-expect-error Node の fetch は、流れる本文にこの印を求めます
      duplex: "half",
    });

    expect(await readWebhookBody(request, 1000)).toEqual({ ok: false });
    expect(sent).toBeLessThan(WEBHOOK_MAX_BYTES);
  });

  it("Content-Length を小さく偽られても、流れを数えて打ち切る", async () => {
    // 申告は当てになりません。申告が上限以下でも、流れてくる分を数えます。
    const request = new Request("https://example.com/api/stripe/webhook", {
      method: "POST",
      headers: { "content-length": "10" },
      body: "a".repeat(5000),
    });

    expect(await readWebhookBody(request, 1000)).toEqual({ ok: false });
  });

  it("文字の数が上限以下でも、バイトの数が上限を超えていればお断りする", async () => {
    // 日本語は 1 文字 3 バイトです。文字の数で測ると、上限の 3 倍まで通ってしまいます。
    const body = "あ".repeat(400_000);
    expect(body.length).toBeLessThan(WEBHOOK_MAX_BYTES);
    expect(Buffer.byteLength(body, "utf8")).toBeGreaterThan(WEBHOOK_MAX_BYTES);

    expect(await readWebhookBody(requestOf(body))).toEqual({ ok: false });
  });

  it("上限ちょうどまでは受け取る", async () => {
    const body = "a".repeat(1000);
    expect(await readWebhookBody(requestOf(body), 1000)).toEqual({ ok: true, payload: body });
  });

  it("お返事は、短い英語 1 行だけで、取り置きもさせない", () => {
    const reply = webhookReply("bad_signature");
    expect(reply.status).toBe(400);
    expect(reply.headers.get("cache-control")).toContain("no-store");
  });

  it("お返事の対応: 署名は 400、大きすぎは 413、書けなかったときは 5xx", () => {
    expect(webhookReplyName({ ok: true, value: { eventId: "evt_1", applied: true } })).toBe(
      "accepted",
    );
    expect(webhookReplyName({ ok: false, code: "forbidden" })).toBe("bad_signature");
    expect(webhookReplyName({ ok: false, code: "invalid" })).toBe("too_large");
    expect(webhookReplyName({ ok: false, code: "unavailable" })).toBe("failed");

    expect(webhookReply("accepted").status).toBe(200);
    expect(webhookReply("too_large").status).toBe(413);
    expect(webhookReply("failed").status).toBe(500);
    expect(webhookReply("not_configured").status).toBe(503);
    expect(webhookReply("method_not_allowed").status).toBe(405);
    expect(webhookReply("method_not_allowed").headers.get("allow")).toBe("POST");
  });

  it("うまくいかなかったわけは、記録にだけ残してお返事には混ぜない", async () => {
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      logWebhook("failed", new Error("insert or update on table subscriptions"));
      logWebhook("not_configured");

      const text = logged.mock.calls.map((call) => call.join(" ")).join("\n");
      expect(text).toContain("subscriptions");
      expect(text).toContain("STRIPE_WEBHOOK_SECRET");
    } finally {
      logged.mockRestore();
    }

    expect(await webhookReply("failed").text()).not.toContain("subscriptions");
    expect(await webhookReply("not_configured").text()).not.toContain("STRIPE_WEBHOOK_SECRET");
  });

  it("写せなかったわけが Stripe の誤りのときは、種類と符号だけを残す", async () => {
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      logWebhook(
        "failed",
        new Stripe.errors.StripeAPIError({
          type: "api_error",
          message: "Request failed for owner@example.com (sub_secret_1)",
          code: "lock_timeout",
        }),
      );

      const text = logged.mock.calls.map((call) => call.join(" ")).join("\n");
      expect(text).toContain("StripeAPIError");
      expect(text).toContain("lock_timeout");
      expect(text).not.toContain("owner@example.com");
      expect(text).not.toContain("sub_secret_1");
    } finally {
      logged.mockRestore();
    }
  });

  it("お返事の中身に、内部の文や秘密は入っていない", async () => {
    for (const name of [
      "accepted",
      "not_configured",
      "too_large",
      "bad_signature",
      "failed",
      "method_not_allowed",
    ] as const) {
      const text = await webhookReply(name).text();
      expect(text.length, name).toBeLessThan(40);
      expect(text, name).toMatch(/^[a-z ]*$/);
    }
  });
});

describe("決済の通知の道すじ（app/api/stripe/webhook/route.ts）", () => {
  const packageRoot = fileURLToPath(new URL("../../", import.meta.url));
  const route = readFileSync(`${packageRoot}app/api/stripe/webhook/route.ts`, "utf8");

  it("Node の側で動き、取り置きもしない", () => {
    expect(route).toContain('export const runtime = "nodejs"');
    expect(route).toContain('export const dynamic = "force-dynamic"');
  });

  it("本文は、JSON に直す前にそのままの文字で受け取る", () => {
    expect(route).toContain("readWebhookBody");
    // request.json() で受けると、署名を確かめる前に形を変えてしまいます
    expect(route).not.toContain("request.json()");
  });

  it("POST 以外のお申し付けはお受けしない", async () => {
    const { GET } = await import("../../app/api/stripe/webhook/route");
    const reply = await GET();
    expect(reply.status).toBe(405);
    expect(reply.headers.get("allow")).toBe("POST");
  });

  it("お申し付けのヘッダから、戻り先や組織を作っていない", () => {
    // ヘッダは差し替えられます。ここから URL や組織を作ると、
    // 送り主の言うとおりの場所へ戻してしまいます。
    // 語は多めに見ます（1 つだけだと、別の書き方をされたときに素通りします）。
    for (const word of [
      "x-forwarded-host",
      "forwarded",
      "origin",
      "host",
      "referer",
      "referrer",
      "NEXT_PUBLIC_SITE_URL",
    ]) {
      expect(route.toLowerCase(), word).not.toContain(word.toLowerCase());
    }
  });

  /** 受け口をそのまま呼びます（お返事の番号だけを確かめます） */
  async function post(headers: Record<string, string>, body = "{}"): Promise<Response> {
    const { POST } = await import("../../app/api/stripe/webhook/route");
    return POST(new Request("https://example.com/api/stripe/webhook", {
      method: "POST",
      headers,
      body,
    }));
  }

  it("署名のヘッダが無いお申し付けは、秘密の有無にかかわらずお断りする", async () => {
    // ここで 503 と 400 を出し分けると、秘密の置き忘れが外から分かってしまいます
    vi.stubEnv("STARTER_FAKE", "1");
    try {
      expect((await post({})).status).toBe(400);
      expect((await post({ "stripe-signature": "" })).status).toBe(400);
    } finally {
      vi.unstubAllEnvs();
    }

    vi.stubEnv("STARTER_FAKE", "");
    vi.stubEnv("STRIPE_SECRET_KEY", "sk_test_dummy");
    vi.stubEnv("STRIPE_WEBHOOK_SECRET", SECRET);
    try {
      expect((await post({})).status).toBe(400);
    } finally {
      vi.unstubAllEnvs();
    }
  });

  it("秘密をまだ頂戴していないときは、支度が済んでいない旨をお返しする", async () => {
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    vi.stubEnv("STARTER_FAKE", "");
    vi.stubEnv("STRIPE_SECRET_KEY", "sk_test_dummy");
    vi.stubEnv("STRIPE_WEBHOOK_SECRET", "");
    try {
      const reply = await post({ "stripe-signature": "t=1,v1=0000" });
      expect(reply.status).toBe(503);
      expect(await reply.text()).toBe("not configured");
      expect(logged).toHaveBeenCalled();
    } finally {
      vi.unstubAllEnvs();
      logged.mockRestore();
    }
  });

  it("見本のしくみでお試しのあいだは、受け口を開けない", async () => {
    // 見本の Checkout は流れを直に呼ぶので、この道は要りません。
    // 開けたままにすると、署名を確かめずに書ける入口になってしまいます。
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    vi.stubEnv("STARTER_FAKE", "1");
    try {
      const reply = await post({ "stripe-signature": "fake" });
      expect(reply.status).toBe(503);
      expect(await reply.text()).toBe("not configured");
    } finally {
      vi.unstubAllEnvs();
      logged.mockRestore();
    }
  });

  it("本文が大きすぎるときは、署名を確かめる前にお断りする", async () => {
    vi.stubEnv("STARTER_FAKE", "");
    vi.stubEnv("STRIPE_SECRET_KEY", "sk_test_dummy");
    vi.stubEnv("STRIPE_WEBHOOK_SECRET", SECRET);
    try {
      const reply = await post(
        {
          "stripe-signature": "t=1,v1=0000",
          "content-length": String(WEBHOOK_MAX_BYTES + 1),
        },
        "{}",
      );
      expect(reply.status).toBe(413);
      expect(await reply.text()).toBe("too large");
    } finally {
      vi.unstubAllEnvs();
    }
  });

  it("proxy.ts は、この道すじを通していない", async () => {
    // 字が書いてあるかどうかではなく、**その決まりを正規表現として撃ちます**。
    // （? の向きを 1 文字変えると、決済の受け口だけを通す形になります。
    // そうなると、署名を確かめる前のお申し付けに Supabase への往復が 1 本増え、
    // 受け口が詰まります。config.matcher を確かめているのは、ここだけです。）
    const { config } = await import("../../proxy");
    expect(config.matcher).toHaveLength(1);

    // Next は、この決まりを道すじ全体に当てます（前と後ろを留めて撃ちます）
    const matcher = new RegExp(`^${config.matcher[0]}$`);
    expect(matcher.test("/api/stripe/webhook")).toBe(false);

    // 画面の道すじは、いままでどおり通ります
    for (const path of ["/app", "/app/settings/billing", "/login", "/", "/invite/abc"]) {
      expect(matcher.test(path), path).toBe(true);
    }

    // 組み立て済みのものと、拡張子のついたファイルも通しません
    for (const path of ["/_next/static/chunk.js", "/favicon.ico", "/robots.txt"]) {
      expect(matcher.test(path), path).toBe(false);
    }
  });
});
