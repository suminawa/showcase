/**
 * メールの口（console と Resend）と、ご招待の文面の検査です。
 *
 * ここで守っているのは 4 つです。
 *   1. 鍵が無いときは送らない（そして「お送りしました」とお伝えしない）
 *   2. 記録に、本文とリンクとメールアドレスを丸ごと残さない
 *   3. 宛先と件名に改行を混ぜる形（メールヘッダの注入）を弾く
 *   4. ご招待の文面に、差し込みがすべて埋まる
 */
import { readFileSync } from "node:fs";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createConsoleMail } from "../../src/adapters/mail/console";
import { createResendMail } from "../../src/adapters/mail/resend";
import { isSendable, maskAddress } from "../../src/adapters/mail/safety";
import { t } from "../../src/core/i18n";
import { INVITE_TTL_DAYS } from "../../src/core/invitations";
import { LEGAL } from "../../legal.config";
import { inviteNoticeKey } from "../../src/server/flows/invitations";
import { messagesFor } from "../../src/server/messages";
import type { MailMessage } from "../../src/ports/mail";

/** Resend には、お送りせずに「何をお渡ししたか」だけを見ます */
const { sendMock } = vi.hoisted(() => ({ sendMock: vi.fn() }));

vi.mock("resend", () => ({
  Resend: class {
    emails = { send: sendMock };
  },
}));

const ja = messagesFor("ja");
const en = messagesFor("en");

const env = process.env as Record<string, string | undefined>;
const KEYS = ["RESEND_API_KEY", "MAIL_FROM", "STARTER_FAKE"] as const;
const before: Record<string, string | undefined> = {};

function message(overrides: Partial<MailMessage> = {}): MailMessage {
  return {
    to: "newcomer@example.com",
    subject: "しおさい設計室 へのご招待",
    text: "https://app.example.com/invite/token-abc をお開きください。",
    lang: "ja",
    ...overrides,
  };
}

beforeEach(() => {
  sendMock.mockReset();
  for (const key of KEYS) {
    before[key] = env[key];
    delete env[key];
  }
});

afterEach(() => {
  for (const key of KEYS) {
    if (before[key] === undefined) delete env[key];
    else env[key] = before[key];
  }
  vi.restoreAllMocks();
});

describe("コンソールの口（鍵が無いとき）", () => {
  it("お送りせず、「まだ整っていません」をお返しする", async () => {
    // 送っていないのに { ok: true } をお返しすると、画面が
    // 「ご招待のメールをお送りしました」と、事実でないことをお伝えしてしまいます。
    const info = vi.spyOn(console, "info").mockImplementation(() => {});

    expect(await createConsoleMail().send(message())).toEqual({
      ok: false,
      code: "not_configured",
    });
    expect(info).toHaveBeenCalledTimes(1);
  });

  it("記録に、本文とリンクを残さない", async () => {
    const info = vi.spyOn(console, "info").mockImplementation(() => {});
    await createConsoleMail().send(message());

    const line = info.mock.calls.flat().join(" ");
    expect(line).toContain("[mail]");
    expect(line).not.toContain("https://app.example.com/invite/token-abc");
    expect(line).not.toContain("をお開きください");
  });

  it("「まだ整っていません」を受けた画面は、リンクをお渡しくださいとお伝えする", async () => {
    // 送っていないのに「お送りしました」とお伝えしないための、口と画面のつなぎ目です。
    vi.spyOn(console, "info").mockImplementation(() => {});
    const result = await createConsoleMail().send(message());

    expect(result.ok).toBe(false);
    expect(inviteNoticeKey({ mailed: result.ok, mailCode: result.ok ? null : result.code })).toBe(
      "invite.sentLink",
    );
  });

  it("記録に、メールアドレスを丸ごと残さない", async () => {
    const info = vi.spyOn(console, "info").mockImplementation(() => {});
    await createConsoleMail().send(message());

    const line = info.mock.calls.flat().join(" ");
    expect(line).not.toContain("newcomer@example.com");
    expect(line).toContain("example.com");
  });

  it("宛先の名前の部分だけを伏せる", () => {
    expect(maskAddress("newcomer@example.com")).toBe("n***@example.com");
    expect(maskAddress("a@example.com")).toBe("***@example.com");
    expect(maskAddress("壊れた住所")).toBe("***");
  });
});

describe("Resend の口", () => {
  it("RESEND_API_KEY が無ければ、送らずに「まだ整っていません」", async () => {
    env.MAIL_FROM = "SaaS スターター <no-reply@example.com>";
    expect(await createResendMail().send(message())).toEqual({
      ok: false,
      code: "not_configured",
    });
  });

  it("MAIL_FROM が無いときも、送らずに「まだ整っていません」", async () => {
    env.RESEND_API_KEY = "re_test_key";
    expect(await createResendMail().send(message())).toEqual({
      ok: false,
      code: "not_configured",
    });
  });

  it("空白だけの値は、頂戴していないものとして扱う", async () => {
    env.RESEND_API_KEY = "   ";
    env.MAIL_FROM = "SaaS スターター <no-reply@example.com>";
    expect(await createResendMail().send(message())).toEqual({
      ok: false,
      code: "not_configured",
    });
  });
});

describe("Resend にお渡しする中身", () => {
  beforeEach(() => {
    env.RESEND_API_KEY = "re_test_key";
    env.MAIL_FROM = "SaaS スターター <no-reply@example.com>";
  });

  it("お渡しするのは from・to・subject・text の 4 つだけ（HTML は組み立てません）", async () => {
    // HTML をお送りすると、お客さまがお書きになった組織の名前やお名前が
    // そのまま組み立てに混じります。この土台は、テキストだけをお送りします。
    sendMock.mockResolvedValue({ data: { id: "re_1" }, error: null, headers: {} });

    expect(await createResendMail().send(message())).toEqual({ ok: true });
    expect(sendMock).toHaveBeenCalledTimes(1);

    const payload = sendMock.mock.calls[0]?.[0] as Record<string, unknown>;
    expect(Object.keys(payload).sort()).toEqual(["from", "subject", "text", "to"]);
    for (const forbidden of ["html", "react", "template", "bcc", "cc", "reply_to"]) {
      expect(payload[forbidden], forbidden).toBeUndefined();
    }
    expect(payload.from).toBe("SaaS スターター <no-reply@example.com>");
    expect(payload.to).toBe("newcomer@example.com");
  });

  it("Resend が error をお返しになったときは、例外ではなく符号で受ける", async () => {
    // Resend は投げずに error に入れてお返しになるので、try/catch だけでは取りこぼします。
    sendMock.mockResolvedValue({ data: null, error: { name: "validation_error" }, headers: {} });
    const problem = vi.spyOn(console, "error").mockImplementation(() => {});

    expect(await createResendMail().send(message())).toEqual({ ok: false, code: "unavailable" });

    const line = problem.mock.calls.flat().join(" ");
    expect(line).not.toContain("newcomer@example.com");
    expect(line).not.toContain("https://app.example.com/invite/token-abc");
  });
});

describe("メールヘッダの注入", () => {
  const BAD: readonly Partial<MailMessage>[] = [
    { to: "newcomer@example.com\nBcc: watcher@example.com" },
    { to: "newcomer@example.com\r\nBcc: watcher@example.com" },
    { subject: "ご招待\nBcc: watcher@example.com" },
    { subject: "ご招待\u0000" },
  ];

  it("宛先と件名に改行が混じっていたら、送れないものとして見る", () => {
    for (const bad of BAD) expect(isSendable(message(bad)), JSON.stringify(bad)).toBe(false);
    expect(isSendable(message())).toBe(true);
  });

  it("本文の改行は、そのまま通す（本文は行を分けて書きます）", () => {
    expect(isSendable(message({ text: "1 行目\n2 行目" }))).toBe(true);
  });

  it("コンソールの口は、弾いたことを記録にも残さずお返しする", async () => {
    const info = vi.spyOn(console, "info").mockImplementation(() => {});
    const result = await createConsoleMail().send(
      message({ to: "newcomer@example.com\nBcc: watcher@example.com" }),
    );

    expect(result).toEqual({ ok: false, code: "rejected" });
    expect(info).not.toHaveBeenCalled();
  });

  it("Resend の口は、鍵がそろっていても弾く", async () => {
    env.RESEND_API_KEY = "re_test_key";
    env.MAIL_FROM = "SaaS スターター <no-reply@example.com>";

    expect(await createResendMail().send(message({ subject: "ご招待\nBcc: watcher@example.com" })))
      .toEqual({ ok: false, code: "rejected" });
  });
});

describe("合成の場所が選ぶ口", () => {
  it("見本のしくみのときは、外へ出さない口を使う", async () => {
    env.STARTER_FAKE = "1";
    const { createMail } = await import("../../src/server/ports");

    const info = vi.spyOn(console, "info").mockImplementation(() => {});
    expect(await createMail().send(message())).toEqual({ ok: true });
    expect(info).not.toHaveBeenCalled();
  });

  it("鍵が無いときは、コンソールの口（送らずに 1 行だけ残す）", async () => {
    const { createMail } = await import("../../src/server/ports");
    const info = vi.spyOn(console, "info").mockImplementation(() => {});

    expect(await createMail().send(message())).toEqual({ ok: false, code: "not_configured" });
    expect(info).toHaveBeenCalledTimes(1);
  });

  it("鍵だけで差出人をまだ頂戴していないときは、記録の残る口に落とす", async () => {
    // Resend の口を選んでしまうと、送られないまま記録にも 1 行も出ません。
    // 鍵を入れたおつもりの買い手に、届いていないことが伝わらなくなります。
    env.RESEND_API_KEY = "re_test_key";
    delete env.MAIL_FROM;
    const { createMail } = await import("../../src/server/ports");
    const info = vi.spyOn(console, "info").mockImplementation(() => {});

    expect(await createMail().send(message())).toEqual({ ok: false, code: "not_configured" });
    expect(info).toHaveBeenCalledTimes(1);
  });

  it("差出人だけで鍵をまだ頂戴していないときも、記録の残る口", async () => {
    delete env.RESEND_API_KEY;
    env.MAIL_FROM = "SaaS スターター <no-reply@example.com>";
    const { createMail } = await import("../../src/server/ports");
    const info = vi.spyOn(console, "info").mockImplementation(() => {});

    expect(await createMail().send(message())).toEqual({ ok: false, code: "not_configured" });
    expect(info).toHaveBeenCalledTimes(1);
  });

  it("鍵と差出人がそろったときだけ、Resend の口（記録を残さない）", async () => {
    env.RESEND_API_KEY = "re_test_key";
    env.MAIL_FROM = "SaaS スターター <no-reply@example.com>";
    const { createMail } = await import("../../src/server/ports");
    const info = vi.spyOn(console, "info").mockImplementation(() => {});

    // 本物の Resend にはつながないので、送信そのものは落ちます。
    // 見ているのは「記録に 1 行も出ない口が選ばれたこと」です。
    const sent = await createMail().send(message());
    expect(sent.ok).toBe(false);
    expect(info).not.toHaveBeenCalled();
  });
});

describe("Supabase の認証のメール（4 種）", () => {
  const config = readFileSync(new URL("../../supabase/config.toml", import.meta.url), "utf8");

  const TEMPLATES = [
    { kind: "confirmation", file: "confirmation.html" },
    { kind: "magic_link", file: "magic-link.html" },
    { kind: "recovery", file: "recovery.html" },
    { kind: "email_change", file: "email-change.html" },
  ] as const;

  it("4 つとも、件名と本文の置き場が config.toml に書いてある", () => {
    for (const template of TEMPLATES) {
      expect(config, template.kind).toContain(`[auth.email.template.${template.kind}]`);
      expect(config, template.kind).toContain(`./supabase/templates/${template.file}`);
    }
  });

  it("件名は、どれも敬体で、legal.config.ts のサービスの名前を添えている", () => {
    // 名前を書き換えたのに、認証のメールだけ古い名前でお送りしてしまう形を止めます
    const subjects = config.split("\n").filter((row) => row.startsWith("subject = "));
    expect(subjects).toHaveLength(4);

    for (const line of subjects) {
      const subject = /^subject = "(.*)"$/.exec(line)?.[1] ?? "";
      expect(subject, line).not.toBe("");
      expect(subject, line).toContain(`（${LEGAL.serviceName}）`);

      // **終わり方**を見ます。行のどこかに当たればよい形だと、
      // 「ご案内」のような語が常体の文の途中にあっても通ってしまいます。
      const head = subject.replace(`（${LEGAL.serviceName}）`, "").trim();
      expect(head, line).toMatch(/(いたします|します|ください|ご案内)$/);
    }
  });

  it("本文に、押すと何が起きるか・期限・お心当たりのないときのご案内がある", () => {
    for (const template of TEMPLATES) {
      const html = readFileSync(
        new URL(`../../supabase/templates/${template.file}`, import.meta.url),
        "utf8",
      );
      expect(html, template.file).toContain("{{ .ConfirmationURL }}");
      expect(html, template.file).toContain("1 時間");
      expect(html, template.file).toContain("お心当たりのない");
      // 署名も本文の名乗りも、legal.config.ts のサービスの名前とそろえます
      expect(html, template.file).toContain(LEGAL.serviceName);
      // **名前が末尾（署名）にあること**まで見ます。
      // 全行をつないで調べると、本文のどこかに名前があるだけで通ってしまい、
      // 直前の行と同じことを 2 回確かめているだけになります。
      // 印を外して、読める字だけを並べ、そのいちばん最後を見ます。
      const text = html
        .replace(/<[^>]*>/g, "\n")
        .split("\n")
        .map((line) => line.trim())
        .filter((line) => line !== "");
      expect(text[text.length - 1], template.file).toContain(LEGAL.serviceName);
      // 文面のひな形に、画面の秘密（鍵やトークンの値）を書き写しません
      expect(html, template.file).not.toContain("{{ .Token }}");
    }
  });

  it("メールのリンクが使える時間は、config.toml の値と文面でそろえている", () => {
    expect(config).toContain("otp_expiry = 3600");
  });
});

describe("ご招待の文面", () => {
  const VARS = {
    inviterName: "みなと 太郎",
    organization: "しおさい設計室",
    roleName: "メンバー",
    url: "https://app.example.com/invite/token-abc",
    days: INVITE_TTL_DAYS,
    serviceName: "SaaS スターター",
  };

  it("日本語の本文に、差し込みが 1 つも残らない", () => {
    const body = t(ja, "mail.invite.body", VARS);
    expect(body).not.toContain("{");
    for (const value of Object.values(VARS)) expect(body).toContain(String(value));
  });

  it("英語の本文にも、差し込みが 1 つも残らない", () => {
    const body = t(en, "mail.invite.body", VARS);
    expect(body).not.toContain("{");
    for (const value of Object.values(VARS)) expect(body).toContain(String(value));
  });

  it("日数は文に埋め込まず、差し込みで渡す", () => {
    expect(ja["mail.invite.body"]).toContain("{days}");
    expect(ja["mail.invite.body"]).not.toContain("7 日間");
    expect(en["mail.invite.body"]).toContain("{days}");
  });

  it("件名に、どの組織のお話かが入っている", () => {
    expect(ja["mail.invite.subject"]).toContain("{organization}");
    expect(en["mail.invite.subject"]).toContain("{organization}");
  });

  it("本文に、お心当たりのないときのご案内が入っている", () => {
    expect(t(ja, "mail.invite.body", VARS)).toContain("お心当たり");
    expect(t(en, "mail.invite.body", VARS)).toContain("weren't expecting");
  });

  it("本文の終わりが、サービスの名前の署名になっている", () => {
    expect(t(ja, "mail.invite.body", VARS).trimEnd().endsWith(VARS.serviceName)).toBe(true);
    expect(t(en, "mail.invite.body", VARS).trimEnd().endsWith(VARS.serviceName)).toBe(true);
  });
});
