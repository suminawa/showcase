/**
 * データベースの行（snake_case）と、画面の側の型（camelCase）の写しの検査です。
 *
 * ここは通信をしません。純粋な写しだけを確かめます
 * （実際のデータベースを相手にした検査は test/supabase.test.ts にあります）。
 */
import { describe, expect, it } from "vitest";
import {
  fromSubscription,
  isUuid,
  toInvitation,
  toMemberView,
  toMembership,
  toOrganization,
  toProfile,
  toProject,
  toStripeCustomer,
  toSubscription,
} from "../../src/adapters/supabase/rows";

describe("行の写し", () => {
  it("プロジェクトの行を、画面の側の名前に写す", () => {
    expect(
      toProject({
        id: "11111111-1111-4111-8111-111111111111",
        organization_id: "22222222-2222-4222-8222-222222222222",
        name: "海図の作成",
        note: "はじめの一歩です",
        created_by: "33333333-3333-4333-8333-333333333333",
        created_at: "2026-09-20T00:00:00+00:00",
        updated_at: "2026-09-21T00:00:00+00:00",
      }),
    ).toEqual({
      id: "11111111-1111-4111-8111-111111111111",
      organizationId: "22222222-2222-4222-8222-222222222222",
      name: "海図の作成",
      note: "はじめの一歩です",
      createdBy: "33333333-3333-4333-8333-333333333333",
      createdAt: "2026-09-20T00:00:00+00:00",
      updatedAt: "2026-09-21T00:00:00+00:00",
    });
  });

  it("退会された方がお作りになったプロジェクトは、作成者の欄が空のまま写る", () => {
    const project = toProject({
      id: "11111111-1111-4111-8111-111111111111",
      organization_id: "22222222-2222-4222-8222-222222222222",
      name: "海図の作成",
      note: "",
      created_by: null,
      created_at: "2026-09-20T00:00:00+00:00",
      updated_at: "2026-09-20T00:00:00+00:00",
    });
    expect(project.createdBy).toBeNull();
  });

  it("組織・メンバー・お名前の行を写す", () => {
    expect(
      toOrganization({
        id: "22222222-2222-4222-8222-222222222222",
        name: "しおさい設計室",
        created_at: "2026-09-20T00:00:00+00:00",
      }),
    ).toEqual({
      id: "22222222-2222-4222-8222-222222222222",
      name: "しおさい設計室",
      createdAt: "2026-09-20T00:00:00+00:00",
    });

    expect(
      toMembership({
        organization_id: "22222222-2222-4222-8222-222222222222",
        user_id: "33333333-3333-4333-8333-333333333333",
        role: "admin",
        created_at: "2026-09-20T00:00:00+00:00",
      }),
    ).toEqual({
      organizationId: "22222222-2222-4222-8222-222222222222",
      userId: "33333333-3333-4333-8333-333333333333",
      role: "admin",
      createdAt: "2026-09-20T00:00:00+00:00",
    });

    expect(
      toStripeCustomer({
        organization_id: "22222222-2222-4222-8222-222222222222",
        stripe_customer_id: "cus_1",
      }),
    ).toEqual({
      organizationId: "22222222-2222-4222-8222-222222222222",
      stripeCustomerId: "cus_1",
    });
  });

  it("メンバーの一覧は、つないで読んだお名前の行から写す", () => {
    expect(
      toMemberView({
        user_id: "33333333-3333-4333-8333-333333333333",
        role: "member",
        created_at: "2026-09-20T00:00:00+00:00",
        profiles: { email: "member@example.com", name: "なぎさ 健" },
      }),
    ).toEqual({
      userId: "33333333-3333-4333-8333-333333333333",
      email: "member@example.com",
      name: "なぎさ 健",
      role: "member",
      createdAt: "2026-09-20T00:00:00+00:00",
    });
  });

  it("お名前の行が見えないときは、空の文字にする（メモリの見本と同じです）", () => {
    const view = toMemberView({
      user_id: "33333333-3333-4333-8333-333333333333",
      role: "member",
      created_at: "2026-09-20T00:00:00+00:00",
      profiles: null,
    });
    expect(view.email).toBe("");
    expect(view.name).toBe("");
  });

  it("知らない言語は、既定の言語に倒す", () => {
    const profile = toProfile({
      id: "33333333-3333-4333-8333-333333333333",
      email: "owner@example.com",
      name: "みなと 太郎",
      lang: "fr",
      created_at: "2026-09-20T00:00:00+00:00",
    });
    expect(profile.lang).toBe("ja");
  });

  it("知らない役割のご招待は、写さずにお止めする", () => {
    expect(() =>
      toInvitation({
        id: "44444444-4444-4444-8444-444444444444",
        organization_id: "22222222-2222-4222-8222-222222222222",
        email: "guest@example.com",
        role: "superuser",
        token_hash: "a".repeat(64),
        expires_at: "2026-09-27T00:00:00+00:00",
        status: "pending",
        invited_by: null,
        accepted_by: null,
        created_at: "2026-09-20T00:00:00+00:00",
      }),
    ).toThrow();
  });

  it("ご契約の行は、期間の終わりが空でも写せる", () => {
    const row = toSubscription({
      organization_id: "22222222-2222-4222-8222-222222222222",
      plan_id: "standard",
      status: "active",
      stripe_subscription_id: null,
      current_period_end: null,
      cancel_at_period_end: false,
      updated_at: "2026-09-20T00:00:00+00:00",
    });
    expect(row.currentPeriodEnd).toBeNull();
    expect(row.stripeSubscriptionId).toBeNull();
  });

  it("時刻は、文字のまま写す（日付の形に直さない）", () => {
    const row = toSubscription({
      organization_id: "22222222-2222-4222-8222-222222222222",
      plan_id: "standard",
      status: "active",
      stripe_subscription_id: "sub_1",
      current_period_end: "2026-10-20T00:00:00+00:00",
      cancel_at_period_end: true,
      updated_at: "2026-09-20T00:00:00+00:00",
    });
    expect(row.currentPeriodEnd).toBe("2026-10-20T00:00:00+00:00");
    expect(row.updatedAt).toBe("2026-09-20T00:00:00+00:00");
  });

  it("決済の契約の番号が開かれていないときは、空として写す", () => {
    // 一員の方の鍵では、この列そのものが返りません（列ごとの許しで閉じています）
    const row = toSubscription({
      organization_id: "22222222-2222-4222-8222-222222222222",
      plan_id: "free",
      status: "canceled",
      current_period_end: null,
      cancel_at_period_end: false,
      updated_at: "2026-09-20T00:00:00+00:00",
    });
    expect(row.stripeSubscriptionId).toBeNull();
  });

  it("知らないプランや状態のご契約は、写さずにお止めする", () => {
    const base = {
      organization_id: "22222222-2222-4222-8222-222222222222",
      plan_id: "standard",
      status: "active",
      stripe_subscription_id: null,
      current_period_end: null,
      cancel_at_period_end: false,
      updated_at: "2026-09-20T00:00:00+00:00",
    };
    expect(() => toSubscription({ ...base, status: "ended" })).toThrow();
    expect(() => toSubscription({ ...base, plan_id: "gold" })).toThrow();
  });

  it("ご契約の行は、写して戻すと元の行と同じになる", () => {
    const row = {
      organization_id: "22222222-2222-4222-8222-222222222222",
      plan_id: "business",
      status: "past_due",
      stripe_subscription_id: "sub_1",
      current_period_end: "2026-10-20T00:00:00+00:00",
      cancel_at_period_end: true,
      updated_at: "2026-09-20T00:00:00+00:00",
    };
    expect(fromSubscription(toSubscription(row))).toEqual(row);
  });

  it("uuid の形をしていない値は、データベースに投げる前に見分ける", () => {
    expect(isUuid("22222222-2222-4222-8222-222222222222")).toBe(true);
    expect(isUuid("22222222-2222-4222-8222-222222222222".toUpperCase())).toBe(true);
    expect(isUuid("abc")).toBe(false);
    expect(isUuid("")).toBe(false);
    expect(isUuid("22222222-2222-4222-8222-22222222222g")).toBe(false);
    expect(isUuid(" 22222222-2222-4222-8222-222222222222 ")).toBe(false);
  });
});
