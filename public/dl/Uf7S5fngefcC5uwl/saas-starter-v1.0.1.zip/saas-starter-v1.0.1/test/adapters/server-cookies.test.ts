/**
 * ログインの控え（cookie）の受け渡しを、偽の入れ物で確かめます。
 *
 * ここで見張っているのは 2 か所です。
 *   ① src/adapters/supabase/server.ts … 画面と操作のつなぎ口
 *   ② proxy.ts                        … お申し付けが画面に届く前に 1 回通るところ
 *
 * あわせて、回数の上限が数える「お客さまの IP」の読み方（`clientIp`）も、
 * 同じ差し替えで確かめます。ここを取り違えると、上限がサイト全体で 1 つの枠になります。
 *
 * ①と②は、どちらも `@supabase/ssr` の `createServerClient` に cookie の読み書きをお渡しします。
 * その中身（getAll と setAll の対、付ける印、2 つめの引数のヘッダ）は、
 * ブラウザでお試しにならないと分からないところでした。
 * つなぎ口の作り方を差し替えて、お渡ししている中身をそのまま確かめます。
 */
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

type CookieToSet = { name: string; value: string; options: Record<string, unknown> };

type CookieMethods = {
  getAll: () => { name: string; value: string }[];
  setAll: (cookiesToSet: CookieToSet[], headers: Record<string, string>) => void;
};

type ClientOptions = {
  cookieOptions?: Record<string, unknown>;
  cookies: CookieMethods;
};

/** 偽の cookie の入れ物です（画面の部品からは書けない様子も作れます） */
type FakeJar = {
  getAll: () => { name: string; value: string }[];
  set: (name: string, value: string, options: Record<string, unknown>) => void;
};

const mocks = vi.hoisted(() => ({
  /** createServerClient にお渡しした中身を、そのまま覚えておきます */
  calls: [] as { url: string; key: string; options: ClientOptions }[],
  /** next/headers の cookies() が返す入れ物です */
  jar: null as FakeJar | null,
  /** next/headers の headers() が返す見出しです */
  headers: new Headers(),
  /** auth.getUser() のふるまいです */
  getUser: async (): Promise<{ data: { user: { id: string } | null }; error: unknown }> => ({
    data: { user: null },
    error: null,
  }),
  /** つなぎ口そのものを作れないときの様子です */
  failCreate: false,
}));

vi.mock("@supabase/ssr", () => ({
  createServerClient: (url: string, key: string, options: ClientOptions) => {
    if (mocks.failCreate) throw new Error("つなぎ口を作れませんでした");
    mocks.calls.push({ url, key, options });
    return { auth: { getUser: () => mocks.getUser() } };
  },
}));

vi.mock("next/headers", () => ({
  cookies: async () => mocks.jar,
  headers: async () => mocks.headers,
}));

const { createServerSupabase } = await import("../../src/adapters/supabase/server");
const { proxy } = await import("../../proxy");
const { clientIp, trustedProxyHops } = await import("../../src/server/ports");

const URL_ = "http://127.0.0.1:55321";
const ANON_KEY = "anon-key-for-test";

/** 書ける入れ物です（Server Action と受け口の様子です） */
function writableJar(initial: { name: string; value: string }[] = []): FakeJar & {
  written: CookieToSet[];
} {
  const written: CookieToSet[] = [];
  return {
    written,
    getAll: () => initial,
    set: (name, value, options) => {
      written.push({ name, value, options });
    },
  };
}

/** 書けない入れ物です（画面の部品の様子です。next/headers が投げます） */
function readOnlyJar(initial: { name: string; value: string }[] = []): FakeJar {
  return {
    getAll: () => initial,
    set: () => {
      throw new Error("Cookies can only be modified in a Server Action or Route Handler");
    },
  };
}

function lastOptions(): ClientOptions {
  const call = mocks.calls[mocks.calls.length - 1];
  if (call === undefined) throw new Error("つなぎ口が作られていません");
  return call.options;
}

describe("ログインの控えの受け渡し", () => {
  beforeEach(() => {
    mocks.calls.length = 0;
    mocks.jar = null;
    mocks.failCreate = false;
    mocks.getUser = async () => ({ data: { user: null }, error: null });
  });

  it("つなぎ口は、cookie に httpOnly と sameSite と path を付ける", async () => {
    mocks.jar = writableJar();
    await createServerSupabase({ url: URL_, anonKey: ANON_KEY, cookieSecure: true });

    const options = lastOptions().cookieOptions;
    // 画面の JavaScript からは読ませません（この土台はサーバーだけが Supabase を呼びます）
    expect(options?.httpOnly).toBe(true);
    expect(options?.sameSite).toBe("lax");
    expect(options?.path).toBe("/");
    expect(options?.secure).toBe(true);
  });

  it("お手元でお試しのあいだ（http）は、secure を付けない", async () => {
    mocks.jar = writableJar();
    await createServerSupabase({ url: URL_, anonKey: ANON_KEY, cookieSecure: false });

    expect(lastOptions().cookieOptions?.secure).toBe(false);
  });

  it("getAll と setAll は対で渡し、入れ物への読み書きにつながっている", async () => {
    const jar = writableJar([{ name: "sb-access-token", value: "old" }]);
    mocks.jar = jar;
    await createServerSupabase({ url: URL_, anonKey: ANON_KEY, cookieSecure: false });

    const cookies = lastOptions().cookies;
    expect(cookies.getAll()).toEqual([{ name: "sb-access-token", value: "old" }]);

    cookies.setAll([{ name: "sb-access-token", value: "new", options: { path: "/" } }], {
      "cache-control": "private, no-store",
    });
    expect(jar.written).toEqual([
      { name: "sb-access-token", value: "new", options: { path: "/" } },
    ]);
  });

  it("画面の部品から呼ばれたときは、書けなくても投げない", async () => {
    mocks.jar = readOnlyJar();
    await createServerSupabase({ url: URL_, anonKey: ANON_KEY, cookieSecure: false });

    // 控えの入れ替えは proxy.ts が行うので、ここでは黙って見送ります
    expect(() =>
      lastOptions().cookies.setAll(
        [{ name: "sb-access-token", value: "new", options: {} }],
        {},
      ),
    ).not.toThrow();
  });
});

/** proxy.ts は環境変数を直に読みます（src/ の外にあるためです） */
const ENV_KEYS = [
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_ANON_KEY",
  "NEXT_PUBLIC_SITE_URL",
  "STARTER_FAKE",
  "STARTER_FAKE_ALLOW_PRODUCTION",
  "NODE_ENV",
] as const;

describe("お申し付けが画面に届く前の、控えの取り直し", () => {
  /** NODE_ENV は型のうえでは読むだけなので、書き換えるときはこちらから触ります */
  const env = process.env as Record<string, string | undefined>;
  const saved = new Map<string, string | undefined>();

  beforeEach(() => {
    mocks.calls.length = 0;
    mocks.jar = null;
    mocks.failCreate = false;
    mocks.getUser = async () => ({ data: { user: null }, error: null });

    for (const key of ENV_KEYS) saved.set(key, env[key]);
    for (const key of ENV_KEYS) delete env[key];
    env.NEXT_PUBLIC_SUPABASE_URL = URL_;
    env.NEXT_PUBLIC_SUPABASE_ANON_KEY = ANON_KEY;
  });

  afterEach(() => {
    for (const key of ENV_KEYS) {
      const before = saved.get(key);
      if (before === undefined) delete env[key];
      else env[key] = before;
    }
  });

  function requestFor(path: string, cookie = ""): NextRequest {
    const headers = cookie === "" ? undefined : { cookie };
    return new NextRequest(`http://localhost:3020${path}`, { headers });
  }

  it("取り直した控えと、取り置きを止めるヘッダを、お返事に載せる", async () => {
    // 本物の Supabase は、控えが新しくなったところで setAll を呼びます
    mocks.getUser = async () => {
      lastOptions().cookies.setAll(
        [{ name: "sb-access-token", value: "new", options: { path: "/", httpOnly: true } }],
        { "cache-control": "private, no-cache, no-store, must-revalidate, max-age=0" },
      );
      return { data: { user: { id: "u-1" } }, error: null };
    };

    const response = await proxy(requestFor("/app", "sb-access-token=old"));

    const setCookie = response.headers.get("set-cookie") ?? "";
    expect(setCookie).toContain("sb-access-token=new");
    expect(setCookie).toContain("HttpOnly");
    // 取り置かれると、ある方の控えが別の方に渡ってしまいます
    expect(response.headers.get("cache-control")).toBe(
      "private, no-cache, no-store, must-revalidate, max-age=0",
    );
  });

  it("控えに httpOnly と sameSite と path を付け、http のあいだは secure を付けない", async () => {
    await proxy(requestFor("/app"));

    const options = lastOptions().cookieOptions;
    expect(options?.httpOnly).toBe(true);
    expect(options?.sameSite).toBe("lax");
    expect(options?.path).toBe("/");
    expect(options?.secure).toBe(false);
  });

  it("土台の URL が https のときは、secure を付ける", async () => {
    env.NEXT_PUBLIC_SITE_URL = "https://app.example.com";
    await proxy(requestFor("/app"));

    expect(lastOptions().cookieOptions?.secure).toBe(true);
  });

  it("見本のしくみでお試しのあいだは、Supabase につながない", async () => {
    env.STARTER_FAKE = "1";

    const response = await proxy(requestFor("/app", "sb-access-token=old"));

    // 鍵が置いてあっても、見本のしくみのあいだは 1 度もお尋ねしません
    expect(mocks.calls).toHaveLength(0);
    expect(response.headers.get("set-cookie")).toBeNull();
  });

  it("本番で見本の印だけが立っているときは、いつもどおり取り直す", async () => {
    // 本番では、STARTER_FAKE=1 だけでは見本のしくみに入りません
    env.NODE_ENV = "production";
    env.STARTER_FAKE = "1";

    await proxy(requestFor("/app"));
    expect(mocks.calls).toHaveLength(1);

    // 承知のうえでお開けになったときは、こちらも素通しします
    mocks.calls.length = 0;
    env.STARTER_FAKE_ALLOW_PRODUCTION = "1";
    await proxy(requestFor("/app"));
    expect(mocks.calls).toHaveLength(0);
  });

  it("鍵をまだ頂戴していないときは、素通しする", async () => {
    delete env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    const response = await proxy(requestFor("/app"));
    expect(mocks.calls).toHaveLength(0);
    expect(response.status).toBe(200);
  });

  it("取り直しに失敗しても、お申し付けはそのままお通しする", async () => {
    // 認証の口が一時的に応えないときです（ここで止めると、サイト全体が開かなくなります）
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    mocks.getUser = async () => {
      throw new Error("fetch failed");
    };

    try {
      const response = await proxy(requestFor("/app", "sb-access-token=old"));
      expect(response.status).toBe(200);
      // 何が起きたかは、サーバーの記録にだけ残します
      expect(logged).toHaveBeenCalledTimes(1);
    } finally {
      logged.mockRestore();
    }
  });

  it("つなぎ口そのものを作れないときも、そのままお通しする", async () => {
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});
    mocks.failCreate = true;

    try {
      const response = await proxy(requestFor("/app"));
      expect(response.status).toBe(200);
      expect(logged).toHaveBeenCalledTimes(1);
    } finally {
      mocks.failCreate = false;
      logged.mockRestore();
    }
  });
});

describe("回数の上限が数える、お客さまの IP", () => {
  const env = process.env as Record<string, string | undefined>;
  const before = env.TRUSTED_PROXY_HOPS;

  beforeEach(() => {
    mocks.headers = new Headers();
    delete env.TRUSTED_PROXY_HOPS;
  });

  afterEach(() => {
    if (before === undefined) delete env.TRUSTED_PROXY_HOPS;
    else env.TRUSTED_PROXY_HOPS = before;
  });

  it("中継が 1 段（既定）なら、末尾を採る", async () => {
    mocks.headers = new Headers({ "x-forwarded-for": "203.0.113.9" });
    expect(await clientIp()).toBe("203.0.113.9");

    // 先頭はお客さまが自由に書けます。ここを採ると、上限をいくらでもすり抜けられます
    mocks.headers = new Headers({ "x-forwarded-for": "a, b, c" });
    expect(await clientIp()).toBe("c");
  });

  it("見出しが無いときは 0.0.0.0（中継のない置き方です）", async () => {
    expect(await clientIp()).toBe("0.0.0.0");

    // 空白だけの見出しも、同じお返事です
    mocks.headers = new Headers({ "x-forwarded-for": " , , " });
    expect(await clientIp()).toBe("0.0.0.0");
  });

  it("中継が 2 段のときは、末尾から 1 つ戻ったところを採る", async () => {
    env.TRUSTED_PROXY_HOPS = "2";
    expect(trustedProxyHops()).toBe(2);

    // Cloudflare → nginx → アプリ。末尾は nginx が足した中継の IP です
    mocks.headers = new Headers({ "x-forwarded-for": "203.0.113.9, 198.51.100.7, 198.51.100.8" });
    expect(await clientIp()).toBe("198.51.100.7");

    // 並びが段数より短いのは、前段を通っていないお申し付けです。
    // 先頭はお客さまが自由に書けますので採らず、まとめて 1 つの枠（0.0.0.0）に落とします
    mocks.headers = new Headers({ "x-forwarded-for": "203.0.113.9" });
    expect(await clientIp()).toBe("0.0.0.0");

    // 値を 1 回ごとに変えても、枠は変わりません（回数の上限をすり抜けられません）
    mocks.headers = new Headers({ "x-forwarded-for": "198.51.100.200" });
    expect(await clientIp()).toBe("0.0.0.0");
  });

  it("段数には上限があり、大きすぎる値は 8 として扱う", async () => {
    for (const value of ["9", "10", "1000"]) {
      env.TRUSTED_PROXY_HOPS = value;
      expect(trustedProxyHops(), value).toBe(8);
    }
    env.TRUSTED_PROXY_HOPS = "8";
    expect(trustedProxyHops()).toBe(8);
  });

  it("数にならない段数は、いちばん安全な 1 として扱う", async () => {
    for (const value of ["", " ", "0", "-1", "いち", "1.5"]) {
      env.TRUSTED_PROXY_HOPS = value;
      expect(trustedProxyHops(), value).toBe(1);
    }
  });
});
