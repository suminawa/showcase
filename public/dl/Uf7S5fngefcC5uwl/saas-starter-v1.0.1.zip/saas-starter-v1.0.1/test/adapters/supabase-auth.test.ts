/**
 * 認証のつなぎ役のうち、本物のデータベースが無くても確かめられるところです。
 * （ログインそのものの往復は test/supabase.test.ts で確かめています）
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import { describe, expect, it, vi } from "vitest";
import { createSupabaseAuth } from "../../src/adapters/supabase/auth";

const USER = {
  id: "11111111-1111-4111-8111-111111111111",
  email: "owner@example.com",
  user_metadata: { name: "みなと 太郎" },
};

/** つなぎ口にお渡しした呼び出しを、順に積んでおくところです */
type Call = (string | number | boolean | null | undefined)[];

/**
 * 認証の口だけが動き、profiles の読み取りが決まった答えを返すつなぎ口です。
 * 本物の形のうち、ここで使うところだけを作っています。
 *
 * **引数も残らず覚えておきます。** 引数を 1 つも見ない作りものにすると、
 * 別の表を引いても、別の方の id で引いても緑のままになってしまいます。
 */
function clientWithProfile(
  profile: { data: unknown; error: unknown },
  calls: Call[] = [],
): SupabaseClient {
  return {
    auth: {
      getUser: async () => {
        calls.push(["auth.getUser"]);
        return { data: { user: USER }, error: null };
      },
    },
    from: (table: string) => {
      calls.push(["from", table]);
      return {
        select: (columns: string) => {
          calls.push(["select", columns]);
          return {
            eq: (column: string, value: string) => {
              calls.push(["eq", column, value]);
              return {
                maybeSingle: async () => {
                  calls.push(["maybeSingle"]);
                  return profile;
                },
              };
            },
          };
        },
      };
    },
  } as unknown as SupabaseClient;
}

describe("認証のつなぎ役", () => {
  it("プロフィールを読めたときは、そのお名前と言語を使う", async () => {
    const calls: Call[] = [];
    const auth = createSupabaseAuth({
      client: clientWithProfile({ data: { name: "みなと 太郎", lang: "en" }, error: null }, calls),
      googleEnabled: false,
    });

    expect(await auth.getUser()).toEqual({
      id: USER.id,
      email: "owner@example.com",
      name: "みなと 太郎",
      lang: "en",
    });

    // **どの表を、どの列で、どなたの id で引いたか**まで確かめます。
    // ここを見ていないと、別の表を引いても別の方の id で引いても緑になります。
    expect(calls).toEqual([
      ["auth.getUser"],
      ["from", "profiles"],
      ["select", "name, lang"],
      ["eq", "id", USER.id],
      ["maybeSingle"],
    ]);
  });

  it("プロフィールを読めなかったときは、記録に 1 行だけ残す", async () => {
    // 読めない理由（表が開かれていない・つながらない）は、気づけないと直せません。
    // とはいえ画面は止めず、仮のお名前でお通しします。
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: clientWithProfile({
          data: null,
          error: { code: "42501", message: "permission denied for table profiles" },
        }),
        googleEnabled: false,
      });

      const user = await auth.getUser();
      // ログインの状態そのものは、認証の口から引けています
      expect(user).toEqual({
        id: USER.id,
        email: "owner@example.com",
        name: "みなと 太郎",
        lang: "ja",
      });

      expect(logged).toHaveBeenCalledTimes(1);
      const line = String(logged.mock.calls[0]?.[0] ?? "");
      // 内部の文（表の名前や SQL）は、記録にも持ち回りません
      expect(line).not.toContain("permission denied");
      expect(line).not.toContain("profiles");
    } finally {
      logged.mockRestore();
    }
  });

  it("ログインのリンクをお受けいただけなかったときは、記録に 1 行だけ残す", async () => {
    // この符号は、まだご登録のないメールアドレスへのお求めでも返りますし、
    // Email の設定が無効のときにも返ります。お返事は「お送りしました」の
    // ままにして（ご登録の有無を隠すため）、気づけるように記録だけ残します。
    const logged = vi.spyOn(console, "warn").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: {
          auth: {
            signInWithOtp: async () => ({
              error: {
                code: "otp_disabled",
                status: 422,
                message: "Signups not allowed for otp",
              },
            }),
          },
        } as unknown as SupabaseClient,
        googleEnabled: false,
      });

      // お返事は、お送りしたときと同じです
      expect(await auth.sendMagicLink("owner@example.com", "https://example.com/auth/callback"))
        .toEqual({ ok: true });

      expect(logged).toHaveBeenCalledTimes(1);
      const line = String(logged.mock.calls[0]?.[0] ?? "");
      // メールアドレスは、記録にも残しません
      expect(line).not.toContain("owner@example.com");
      expect(line).toContain("Email");
    } finally {
      logged.mockRestore();
    }
  });

  it("ログインのリンクをお送りできたときは、記録に何も残さない", async () => {
    const logged = vi.spyOn(console, "warn").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: {
          auth: { signInWithOtp: async () => ({ error: null }) },
        } as unknown as SupabaseClient,
        googleEnabled: false,
      });

      expect(await auth.sendMagicLink("owner@example.com", "https://example.com/auth/callback"))
        .toEqual({ ok: true });
      expect(logged).not.toHaveBeenCalled();
    } finally {
      logged.mockRestore();
    }
  });

  it("プロフィールの行がまだ無いときは、記録に残さない", async () => {
    // ご登録の直後で、行を作る前です（誤りではありません）
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: clientWithProfile({ data: null, error: null }),
        googleEnabled: false,
      });

      const user = await auth.getUser();
      expect(user?.name).toBe("みなと 太郎");
      expect(logged).not.toHaveBeenCalled();
    } finally {
      logged.mockRestore();
    }
  });
});
