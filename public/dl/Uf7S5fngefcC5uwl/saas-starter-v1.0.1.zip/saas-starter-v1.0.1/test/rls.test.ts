/**
 * 行の出入りの決まり（RLS）を、実際のログインで確かめます。
 *
 * ここは `npm test` では回りません（ローカルの Supabase が要るためです）。
 * `npm run test:rls` が、Supabase を立ち上げてから回します。
 * つなぎ先と鍵が渡されていないときは、まるごと見送ります。
 *
 * 見本の顔ぶれは 5 人と 2 つの組織です。
 *   しおさい設計室 … owner（オーナー）/ admin（管理者）/ member（メンバー）/ guest（メンバー）
 *   なぎさ工房     … owner（オーナー）/ guest（メンバー）
 *   outsider       … どちらにも入っていない方
 * guest は、役割ごとの総当たりで「相手役」になっていただく方です。
 *
 * いちばん大事なのは最後の「役割の表との突き合わせ」で、
 * src/core/permissions.ts の can() の答えと、表を直に読み書きした結果が
 * 1 つずつ一致することを確かめています。
 */
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { beforeAll, describe, expect, it } from "vitest";
import { can, type Action, type Role } from "../src/core/permissions";
import { PLANS } from "../plans.config";

const SUPABASE_URL = process.env.SUPABASE_URL ?? "";
const ANON_KEY = process.env.SUPABASE_ANON_KEY ?? "";
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";

/**
 * つなぎ先が、お手元のもの（127.0.0.1 か localhost）かどうかです。
 *
 * この検査は、行を作っては消します。公開のプロジェクトに向けてしまうと、
 * そちらの中身が変わります。**お手元でなければ、1 度もつながずにお止めします。**
 */
function isLocalHost(url: string): boolean {
  try {
    const host = new URL(url).hostname;
    return host === "127.0.0.1" || host === "localhost" || host === "::1" || host === "[::1]";
  } catch {
    return false;
  }
}

/**
 * つなぎ先と 2 つの鍵は、npm run test:rls が渡します。
 * 3 つそろっていないときは、この 1 本をまるごと見送ります
 * （どこかで動いている別の Supabase につないでしまわないようにするためです。
 * ローカルの鍵はどの土台でも同じ値なので、つなぎ先を決め打ちにはしません）。
 */
const CONFIGURED = SUPABASE_URL !== "" && ANON_KEY !== "" && SERVICE_KEY !== "";

// 見送るのではなく、はっきりお止めします（黙って通ると、向けた先が変わったことに気づけません）
if (CONFIGURED && !isLocalHost(SUPABASE_URL)) {
  throw new Error("この検査は、お手元の Supabase（127.0.0.1 か localhost）でだけ回せます");
}

const READY = CONFIGURED;

/** 見送るときは、読み込みで止まらないように形だけの値を使います（通信はしません） */
const PLACEHOLDER_URL = "http://127.0.0.1:1";
const PLACEHOLDER_KEY = "skipped";

const suite = describe.skipIf(!READY);

/** ローカルでだけ使う、見本の合言葉です */
const PASSWORD = "local-starter-8891";

type ActorName = "owner" | "admin" | "member" | "guest" | "outsider";

const ACTORS: readonly ActorName[] = ["owner", "admin", "member", "guest", "outsider"];

/** 役割ごとの総当たりで「する側」になっていただく 3 人です */
const MATRIX_ACTORS: readonly ActorName[] = ["owner", "admin", "member"];

const EMAILS: Record<ActorName, string> = {
  owner: "owner@example.com",
  admin: "admin@example.com",
  member: "member@example.com",
  guest: "guest@example.com",
  outsider: "outsider@example.com",
};

/** 退会していただく道を確かめるための、この 1 本だけでお迎えする方です */
const LEAVER_EMAIL = "leaver@example.com";

/** 8 つの表の名前です */
const TABLES = [
  "profiles",
  "organizations",
  "memberships",
  "invitations",
  "projects",
  "subscriptions",
  "stripe_customers",
  "stripe_events",
] as const;

function newClient(key: string): SupabaseClient {
  return createClient(READY ? SUPABASE_URL : PLACEHOLDER_URL, READY ? key : PLACEHOLDER_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

const service = newClient(SERVICE_KEY);
const visitor = newClient(ANON_KEY);

const clients = {} as Record<ActorName, SupabaseClient>;
const userIds = {} as Record<ActorName, string>;

let shiosai = "";
let nagisa = "";

/** 組織ごとの、オーナーがお作りになった行と、guest がお作りになった行です */
const ownerProject: Record<string, string> = {};
const guestProject: Record<string, string> = {};

/** 見本の顔ぶれの、組織ごとの役割です */
const seatedAs: Record<string, Record<string, Role | undefined>> = {};

function roleIn(actor: ActorName, organizationId: string): Role | null {
  return seatedAs[organizationId]?.[actor] ?? null;
}

/** 書き込みが通ったかどうか。誤りでも 0 行でも「通らなかった」と数えます */
type Outcome = { ok: boolean; message: string };

function outcomeOf(result: { data: unknown; error: { message: string } | null }): Outcome {
  if (result.error !== null) return { ok: false, message: result.error.message };
  const rows = Array.isArray(result.data) ? result.data : result.data === null ? [] : [result.data];
  return { ok: rows.length > 0, message: rows.length === 0 ? "0 行" : "" };
}

async function createOrganization(actor: ActorName, name: string): Promise<string> {
  const { data, error } = await clients[actor].rpc("create_organization_guarded", {
    p_name: name,
    p_max_per_user: 10,
  });
  if (error !== null) throw new Error(`組織を作れませんでした: ${error.message}`);
  const payload = data as { result: string; organization?: { id: string } };
  if (payload.result !== "ok" || payload.organization === undefined) {
    throw new Error(`組織を作れませんでした: ${payload.result}`);
  }
  return payload.organization.id;
}

async function createProject(
  actor: ActorName,
  organizationId: string,
  name: string,
): Promise<string> {
  const { data, error } = await clients[actor]
    .from("projects")
    .insert({
      organization_id: organizationId,
      name,
      note: "",
      created_by: userIds[actor],
    })
    .select("id")
    .single();
  if (error !== null) throw new Error(`プロジェクトを作れませんでした: ${error.message}`);
  return (data as { id: string }).id;
}

/** 見本の行をすべて片づけます（何度でも回せるようにするためです） */
async function wipe(): Promise<void> {
  await service.from("subscriptions").delete().not("organization_id", "is", null);
  await service.from("projects").delete().not("id", "is", null);
  await service.from("organizations").delete().not("id", "is", null);
  await service.from("stripe_events").delete().not("id", "is", null);

  const emails = new Set<string>([...Object.values(EMAILS), LEAVER_EMAIL]);
  const { data } = await service.auth.admin.listUsers({ page: 1, perPage: 200 });
  for (const user of data?.users ?? []) {
    if (user.email !== undefined && emails.has(user.email)) {
      await service.auth.admin.deleteUser(user.id);
    }
  }
}

beforeAll(async () => {
  if (!READY) return;
  await wipe();

  for (const actor of ACTORS) {
    const created = await service.auth.admin.createUser({
      email: EMAILS[actor],
      password: PASSWORD,
      email_confirm: true,
    });
    if (created.error !== null) throw created.error;
    userIds[actor] = created.data.user.id;

    const client = newClient(ANON_KEY);
    const signedIn = await client.auth.signInWithPassword({
      email: EMAILS[actor],
      password: PASSWORD,
    });
    if (signedIn.error !== null) throw signedIn.error;
    clients[actor] = client;
  }

  shiosai = await createOrganization("owner", "しおさい設計室");
  nagisa = await createOrganization("owner", "なぎさ工房");

  const seats = await service.from("memberships").insert([
    { organization_id: shiosai, user_id: userIds.admin, role: "admin" },
    { organization_id: shiosai, user_id: userIds.member, role: "member" },
    { organization_id: shiosai, user_id: userIds.guest, role: "member" },
    { organization_id: nagisa, user_id: userIds.guest, role: "member" },
  ]);
  if (seats.error !== null) throw seats.error;

  seatedAs[shiosai] = { owner: "owner", admin: "admin", member: "member", guest: "member" };
  seatedAs[nagisa] = { owner: "owner", guest: "member" };

  for (const organizationId of [shiosai, nagisa]) {
    ownerProject[organizationId] = await createProject(
      "owner",
      organizationId,
      "見本のプロジェクト",
    );
    guestProject[organizationId] = await createProject(
      "guest",
      organizationId,
      "ご一緒の方のプロジェクト",
    );
  }

  const subscription = await service.from("subscriptions").insert({
    organization_id: shiosai,
    plan_id: "standard",
    status: "active",
    stripe_subscription_id: "sub_example",
    cancel_at_period_end: false,
  });
  if (subscription.error !== null) throw subscription.error;
}, 120_000);

suite("ログインしていない方（anon）", () => {
  it("8 つの表から 1 行も読めません", async () => {
    const counts: Record<string, number> = {};
    for (const table of TABLES) {
      const { data } = await visitor.from(table).select("*");
      counts[table] = data?.length ?? 0;
    }
    expect(counts).toEqual({
      profiles: 0,
      organizations: 0,
      memberships: 0,
      invitations: 0,
      projects: 0,
      subscriptions: 0,
      stripe_customers: 0,
      stripe_events: 0,
    });
  });

  it("組織もプロジェクトも作れません", async () => {
    const organization = await visitor.from("organizations").insert({ name: "なぎさ工房" }).select();
    const project = await visitor
      .from("projects")
      .insert({ organization_id: shiosai, name: "作れないはず", note: "", created_by: userIds.owner })
      .select();
    expect(outcomeOf(organization).ok).toBe(false);
    expect(outcomeOf(project).ok).toBe(false);
  });

  it("組織を作る関数を呼べません", async () => {
    const { error } = await visitor.rpc("create_organization_guarded", {
      p_name: "なぎさ工房",
      p_max_per_user: 10,
    });
    expect(error).not.toBeNull();
  });
});

suite("組織の外の方（outsider）", () => {
  it("どの表からも 1 行も読めません", async () => {
    const counts: Record<string, number> = {};
    for (const table of TABLES) {
      const { data } = await clients.outsider.from(table).select("*");
      counts[table] = data?.length ?? 0;
    }
    expect(counts).toEqual({
      profiles: 1, // ご自身の profiles だけは読めます
      organizations: 0,
      memberships: 0,
      invitations: 0,
      projects: 0,
      subscriptions: 0,
      stripe_customers: 0,
      stripe_events: 0,
    });
  });

  it("ほかの組織にプロジェクトを作れません", async () => {
    const direct = await clients.outsider
      .from("projects")
      .insert({
        organization_id: shiosai,
        name: "作れないはず",
        note: "",
        created_by: userIds.outsider,
      })
      .select();
    expect(outcomeOf(direct).ok).toBe(false);

    const viaFunction = await clients.outsider.rpc("create_project_guarded", {
      p_organization_id: shiosai,
      p_name: "作れないはず",
      p_note: "",
      p_created_by: userIds.outsider,
      p_limit: null,
    });
    expect(viaFunction.error).not.toBeNull();
  });
});

suite("プロフィール", () => {
  it("ご一緒の方の行は読めますが、組織の外の方の行は読めません", async () => {
    const { data } = await clients.member.from("profiles").select("id");
    const seen = new Set((data ?? []).map((row) => (row as { id: string }).id));
    expect(seen.has(userIds.member)).toBe(true);
    expect(seen.has(userIds.owner)).toBe(true);
    expect(seen.has(userIds.admin)).toBe(true);
    expect(seen.has(userIds.outsider)).toBe(false);
  });

  it("ご自身の行でも、ご本人と分かる欄は書き換えられません", async () => {
    const patches: Record<string, unknown>[] = [
      { id: userIds.outsider },
      { email: "someone-else@example.com" },
      { created_at: new Date(0).toISOString() },
    ];
    for (const patch of patches) {
      const changed = await clients.member
        .from("profiles")
        .update(patch)
        .eq("id", userIds.member)
        .select();
      expect(outcomeOf(changed).ok, Object.keys(patch)[0]).toBe(false);
    }

    const { data } = await service
      .from("profiles")
      .select("id, email")
      .eq("id", userIds.member)
      .single();
    expect(data).toEqual({ id: userIds.member, email: "member@example.com" });
  });

  it("お名前は 80 文字までです", async () => {
    const tooLong = await clients.member
      .from("profiles")
      .update({ name: "あ".repeat(81) })
      .eq("id", userIds.member)
      .select();
    expect(outcomeOf(tooLong).ok).toBe(false);

    const fits = await clients.member
      .from("profiles")
      .update({ name: "あ".repeat(80) })
      .eq("id", userIds.member)
      .select();
    expect(outcomeOf(fits).ok).toBe(true);

    await service.from("profiles").update({ name: "なぎさ 健" }).eq("id", userIds.member);
  });

  it("ほかの方の行は書き換えられません", async () => {
    const other = await clients.member
      .from("profiles")
      .update({ name: "書き換えられないはず" })
      .eq("id", userIds.owner)
      .select();
    const own = await clients.member
      .from("profiles")
      .update({ name: "なぎさ 健" })
      .eq("id", userIds.member)
      .select();
    expect(outcomeOf(other)).toEqual({ ok: false, message: "0 行" });
    expect(outcomeOf(own).ok).toBe(true);
  });
});

suite("組織どうしの隔て", () => {
  it("組織は、表を直に書く道では作れません", async () => {
    const created = await clients.owner
      .from("organizations")
      .insert({ name: "なぎさ工房" })
      .select();
    expect(outcomeOf(created).ok).toBe(false);
  });

  it("メンバーは、ご一緒の組織のプロジェクトだけを読めます", async () => {
    const mine = await clients.member.from("projects").select("id").eq("organization_id", shiosai);
    const theirs = await clients.member.from("projects").select("id").eq("organization_id", nagisa);
    expect(mine.data?.length).toBe(2);
    expect(theirs.data?.length ?? 0).toBe(0);
  });

  it("メンバーは、ご一緒の組織のメンバーの一覧を読めます（決まりが際限なく回りません）", async () => {
    const { data, error } = await clients.member.from("memberships").select("user_id, role");
    expect(error).toBeNull();
    expect(data?.length).toBe(4);
  });

  it("プロジェクトを、ほかの組織へ付け替えられません", async () => {
    const moved = await clients.member
      .from("projects")
      .update({ organization_id: nagisa })
      .eq("id", ownerProject[shiosai])
      .select();
    expect(outcomeOf(moved).ok).toBe(false);

    const { data } = await service
      .from("projects")
      .select("organization_id")
      .eq("id", ownerProject[shiosai])
      .single();
    expect((data as { organization_id: string }).organization_id).toBe(shiosai);
  });
});

suite("プロジェクトの削除", () => {
  it("メンバーは、ご自身がお作りになった行だけを消せます", async () => {
    const own = await createProject("member", shiosai, "ご自身のプロジェクト");
    const removedOwn = await clients.member.from("projects").delete().eq("id", own).select();
    expect(outcomeOf(removedOwn).ok).toBe(true);

    const removedOther = await clients.member
      .from("projects")
      .delete()
      .eq("id", guestProject[shiosai])
      .select();
    expect(outcomeOf(removedOther)).toEqual({ ok: false, message: "0 行" });
  });

  it("管理者は、ほかの方がお作りになった行も消せます", async () => {
    const target = await createProject("guest", shiosai, "消される見本");
    const removed = await clients.admin.from("projects").delete().eq("id", target).select();
    expect(outcomeOf(removed).ok).toBe(true);
  });
});

suite("ご招待", () => {
  let invitationId = "";

  beforeAll(async () => {
    const { data, error } = await clients.owner
      .from("invitations")
      .insert({
        organization_id: shiosai,
        email: "outsider@example.com",
        role: "member",
        token_hash: "a".repeat(64),
        expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        invited_by: userIds.owner,
      })
      .select("id")
      .single();
    if (error !== null) throw error;
    invitationId = (data as { id: string }).id;
  });

  it("メンバーとお招きした方からは、ご招待が 1 件も見えません", async () => {
    const asMember = await clients.member.from("invitations").select("*");
    const asInvited = await clients.outsider.from("invitations").select("*");
    expect(asMember.data?.length ?? 0).toBe(0);
    expect(asInvited.data?.length ?? 0).toBe(0);
  });

  it("トークンのハッシュは、メンバーとお招きした方からは読めません", async () => {
    const asMember = await clients.member.from("invitations").select("token_hash");
    const asInvited = await clients.outsider.from("invitations").select("token_hash");
    expect(asMember.data?.length ?? 0).toBe(0);
    expect(asInvited.data?.length ?? 0).toBe(0);
  });

  it("オーナーと管理者には見えます", async () => {
    const asOwner = await clients.owner.from("invitations").select("id");
    const asAdmin = await clients.admin.from("invitations").select("id");
    expect(asOwner.data?.length).toBe(1);
    expect(asAdmin.data?.length).toBe(1);
    expect(invitationId).not.toBe("");
  });

  it("管理者は、オーナーとしてのご招待には触れません", async () => {
    const created = await clients.admin
      .from("invitations")
      .insert({
        organization_id: shiosai,
        email: "guest@example.com",
        role: "owner",
        token_hash: "b".repeat(64),
        expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        invited_by: userIds.admin,
      })
      .select();
    expect(outcomeOf(created).ok).toBe(false);

    const byOwner = await clients.owner
      .from("invitations")
      .insert({
        organization_id: shiosai,
        email: "guest@example.com",
        role: "owner",
        token_hash: "c".repeat(64),
        expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        invited_by: userIds.owner,
      })
      .select("id")
      .single();
    expect(byOwner.error).toBeNull();

    const revoked = await clients.admin
      .from("invitations")
      .update({ status: "revoked" })
      .eq("id", (byOwner.data as { id: string }).id)
      .select();
    expect(outcomeOf(revoked)).toEqual({ ok: false, message: "0 行" });

    await service.from("invitations").delete().eq("id", (byOwner.data as { id: string }).id);
  });
});

suite("課金の 3 つの表", () => {
  it("一員の方はご契約を読めますが、オーナーでも書けません", async () => {
    const read = await clients.member.from("subscriptions").select("plan_id");
    expect(read.data?.length).toBe(1);

    const inserted = await clients.owner
      .from("subscriptions")
      .insert({ organization_id: nagisa, plan_id: "business", status: "active" })
      .select();
    const updated = await clients.owner
      .from("subscriptions")
      .update({ plan_id: "business" })
      .eq("organization_id", shiosai)
      .select();
    const removed = await clients.owner
      .from("subscriptions")
      .delete()
      .eq("organization_id", shiosai)
      .select();
    expect(outcomeOf(inserted).ok).toBe(false);
    expect(outcomeOf(updated).ok).toBe(false);
    expect(outcomeOf(removed).ok).toBe(false);
  });

  it("ご契約の決済の番号は、オーナーにもお見せしません", async () => {
    // 列そのものへの許しが無いので、* で読もうとすると誤りになります
    const everything = await clients.owner.from("subscriptions").select("*");
    expect(everything.error).not.toBeNull();

    const theNumber = await clients.owner.from("subscriptions").select("stripe_subscription_id");
    expect(theNumber.error).not.toBeNull();

    // 画面に要る列だけは読めます
    const shown = await clients.member
      .from("subscriptions")
      .select("organization_id, plan_id, status, current_period_end, cancel_at_period_end, updated_at");
    expect(shown.error).toBeNull();
    expect(shown.data?.length).toBe(1);
  });

  it("決済のお客さま番号と通知の記録は、どなたにも見えません", async () => {
    const seeded = await service
      .from("stripe_customers")
      .insert({ organization_id: shiosai, stripe_customer_id: "cus_example" });
    expect(seeded.error).toBeNull();
    const event = await service
      .from("stripe_events")
      .insert({ id: "evt_example", type: "checkout.session.completed" });
    expect(event.error).toBeNull();

    for (const actor of ACTORS) {
      const customers = await clients[actor].from("stripe_customers").select("*");
      const events = await clients[actor].from("stripe_events").select("*");
      expect(customers.data?.length ?? 0).toBe(0);
      expect(events.data?.length ?? 0).toBe(0);
    }
  });

  it("決済のお客さま番号と通知の記録は、どなたにも書けません", async () => {
    const customer = await clients.owner
      .from("stripe_customers")
      .insert({ organization_id: nagisa, stripe_customer_id: "cus_denied" })
      .select();
    const removedCustomer = await clients.owner
      .from("stripe_customers")
      .delete()
      .eq("organization_id", shiosai)
      .select();
    const event = await clients.owner
      .from("stripe_events")
      .insert({ id: "evt_denied", type: "checkout.session.completed" })
      .select();
    const removedEvent = await clients.owner
      .from("stripe_events")
      .delete()
      .eq("id", "evt_example")
      .select();
    expect(outcomeOf(customer).ok).toBe(false);
    expect(outcomeOf(removedCustomer).ok).toBe(false);
    expect(outcomeOf(event).ok).toBe(false);
    expect(outcomeOf(removedEvent).ok).toBe(false);

    const { data } = await service.from("stripe_events").select("id");
    expect(data?.length).toBe(1);
  });
});

suite("オーナーの行の守り", () => {
  it("管理者は、オーナーの行に触れません", async () => {
    const demoted = await clients.admin
      .from("memberships")
      .update({ role: "member" })
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.owner)
      .select();
    const removed = await clients.admin
      .from("memberships")
      .delete()
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.owner)
      .select();
    expect(outcomeOf(demoted)).toEqual({ ok: false, message: "0 行" });
    expect(outcomeOf(removed)).toEqual({ ok: false, message: "0 行" });
  });

  it("表を直に書く道では、どなたもオーナーに上げられません", async () => {
    const byOwner = await clients.owner
      .from("memberships")
      .update({ role: "owner" })
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.member)
      .select();
    const byAdmin = await clients.admin
      .from("memberships")
      .update({ role: "owner" })
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.member)
      .select();
    const inserted = await clients.owner
      .from("memberships")
      .insert({ organization_id: nagisa, user_id: userIds.member, role: "owner" })
      .select();
    expect(outcomeOf(byOwner).ok).toBe(false);
    expect(outcomeOf(byAdmin).ok).toBe(false);
    expect(outcomeOf(inserted).ok).toBe(false);
  });

  it("最後のオーナーは、降ろすことも外すこともできません", async () => {
    const demote = await clients.owner.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.owner,
      p_role: "member",
    });
    const remove = await clients.owner.rpc("remove_member_guarded", {
      p_organization_id: shiosai,
      p_user_id: userIds.owner,
    });
    expect(demote.data).toBe("last_owner");
    expect(remove.data).toBe("last_owner");

    const direct = await clients.owner
      .from("memberships")
      .delete()
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.owner)
      .select();
    expect(outcomeOf(direct).ok).toBe(false);

    const { data } = await service
      .from("memberships")
      .select("role")
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.owner)
      .single();
    expect((data as { role: string }).role).toBe("owner");
  });
});

suite("お止めした理由の符号", () => {
  /** 画面の側（adapter）が理由を見分けられるように、理由ごとに符号を分けています */
  it("止めた理由ごとに、別の符号が返ります", async () => {
    const forbidden = await clients.member.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.guest,
      p_role: "admin",
    });
    expect(forbidden.error?.code, "権限なし").toBe("ST001");

    const touchOwner = await clients.admin.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.owner,
      p_role: "member",
    });
    expect(touchOwner.error?.code, "オーナーに関わる操作").toBe("ST002");

    const lastOwner = await clients.owner
      .from("memberships")
      .delete()
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.owner)
      .select();
    expect(lastOwner.error?.code, "最後のオーナー").toBe("ST003");

    const moved = await clients.member
      .from("projects")
      .update({ organization_id: nagisa })
      .eq("id", ownerProject[shiosai])
      .select();
    expect(moved.error?.code, "付け替えの禁止").toBe("ST004");

    const removed = await clients.owner
      .from("organizations")
      .delete()
      .eq("id", shiosai)
      .select();
    expect(removed.error?.code, "ご契約が続いています").toBe("ST005");
  });
});

suite("関数を直に呼んでも、権限はすり抜けられません", () => {
  it("メンバーは、役割を変える関数を呼べません", async () => {
    const changed = await clients.member.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.guest,
      p_role: "admin",
    });
    const removed = await clients.member.rpc("remove_member_guarded", {
      p_organization_id: shiosai,
      p_user_id: userIds.guest,
    });
    expect(changed.error).not.toBeNull();
    expect(removed.error).not.toBeNull();
  });

  it("管理者は、関数を通してもオーナーに触れません", async () => {
    const demote = await clients.admin.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.owner,
      p_role: "member",
    });
    const promote = await clients.admin.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.member,
      p_role: "owner",
    });
    const removeOwner = await clients.admin.rpc("remove_member_guarded", {
      p_organization_id: shiosai,
      p_user_id: userIds.owner,
    });
    expect(demote.error).not.toBeNull();
    expect(promote.error).not.toBeNull();
    expect(removeOwner.error).not.toBeNull();
  });

  it("組織の外の方は、その組織の関数を呼べません", async () => {
    const changed = await clients.outsider.rpc("change_member_role", {
      p_organization_id: shiosai,
      p_user_id: userIds.member,
      p_role: "admin",
    });
    expect(changed.error).not.toBeNull();
  });

  it("ほかの方の名前でプロジェクトを作れません", async () => {
    const { error } = await clients.member.rpc("create_project_guarded", {
      p_organization_id: shiosai,
      p_name: "作れないはず",
      p_note: "",
      p_created_by: userIds.owner,
      p_limit: null,
    });
    expect(error).not.toBeNull();
  });

  it("件数の上限に達しているときは limit を返し、行を作りません", async () => {
    const { data: before } = await service
      .from("projects")
      .select("id")
      .eq("organization_id", nagisa);
    const count = before?.length ?? 0;

    const { data, error } = await clients.owner.rpc("create_project_guarded", {
      p_organization_id: nagisa,
      p_name: "上限のあとの 1 件",
      p_note: "",
      p_created_by: userIds.owner,
      p_limit: count,
    });
    expect(error).toBeNull();
    expect((data as { result: string }).result).toBe("limit");

    const { data: after } = await service
      .from("projects")
      .select("id")
      .eq("organization_id", nagisa);
    expect(after?.length ?? 0).toBe(count);
  });

  it("入れる組織の数の上限に達しているときは limit を返し、組織を作りません", async () => {
    const { data, error } = await clients.owner.rpc("create_organization_guarded", {
      p_name: "なぎさ工房",
      p_max_per_user: 2,
    });
    expect(error).toBeNull();
    expect((data as { result: string }).result).toBe("limit");
  });
});

suite("ご招待をお受けいただく流れ", () => {
  const tokenHash = "d".repeat(64);
  let invitationId = "";

  beforeAll(async () => {
    const { data, error } = await clients.owner
      .from("invitations")
      .insert({
        organization_id: nagisa,
        email: "outsider@example.com",
        role: "member",
        token_hash: tokenHash,
        expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        invited_by: userIds.owner,
      })
      .select("id")
      .single();
    if (error !== null) throw error;
    invitationId = (data as { id: string }).id;
  });

  it("ハッシュで探すと、トークンのハッシュを除いた行が返ります", async () => {
    const { data, error } = await clients.outsider.rpc("find_invitation_by_hash", {
      p_token_hash: tokenHash,
    });
    expect(error).toBeNull();
    const row = data as Record<string, unknown>;
    expect(row.id).toBe(invitationId);
    expect(row.organization_id).toBe(nagisa);
    expect("token_hash" in row).toBe(false);
  });

  it("ほかの方の代わりにはお受けになれません", async () => {
    const { error } = await clients.member.rpc("accept_invitation", {
      p_invitation_id: invitationId,
      p_user_id: userIds.outsider,
      p_role: "member",
    });
    expect(error).not.toBeNull();
  });

  it("宛先が違うご招待は、無いご招待と見分けがつきません", async () => {
    // 宛先の違う方からは、ご招待があること自体が分かりません
    const wrongPerson = await clients.member.rpc("accept_invitation", {
      p_invitation_id: invitationId,
      p_user_id: userIds.member,
      p_role: "member",
    });
    // 役割を言い当てようとしても、同じお返事です
    const wrongRole = await clients.member.rpc("accept_invitation", {
      p_invitation_id: invitationId,
      p_user_id: userIds.member,
      p_role: "owner",
    });
    // そもそも無いご招待でも、同じお返事です
    const missing = await clients.member.rpc("accept_invitation", {
      p_invitation_id: "00000000-0000-4000-8000-00000000ffff",
      p_user_id: userIds.member,
      p_role: "member",
    });

    expect(wrongPerson.error).toBeNull();
    expect(wrongRole.error).toBeNull();
    expect(missing.error).toBeNull();
    expect([wrongPerson.data, wrongRole.data, missing.data]).toEqual([
      "not_pending",
      "not_pending",
      "not_pending",
    ]);

    // お受けになっていないので、ご招待は pending のままです
    const { data } = await service
      .from("invitations")
      .select("status")
      .eq("id", invitationId)
      .single();
    expect((data as { status: string }).status).toBe("pending");
  });

  it("お受けになると、1 回だけメンバーに加わります", async () => {
    const first = await clients.outsider.rpc("accept_invitation", {
      p_invitation_id: invitationId,
      p_user_id: userIds.outsider,
      p_role: "member",
    });
    const second = await clients.outsider.rpc("accept_invitation", {
      p_invitation_id: invitationId,
      p_user_id: userIds.outsider,
      p_role: "member",
    });
    expect(first.data).toBe("ok");
    expect(second.data).toBe("not_pending");

    const { data } = await service
      .from("memberships")
      .select("role")
      .eq("organization_id", nagisa)
      .eq("user_id", userIds.outsider);
    expect(data?.length).toBe(1);
  });

  it("すでにご一緒の方の役割は、あとのご招待でも変わりません", async () => {
    const again = await clients.owner
      .from("invitations")
      .insert({
        organization_id: nagisa,
        email: "outsider@example.com",
        role: "admin",
        token_hash: "e".repeat(64),
        expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        invited_by: userIds.owner,
      })
      .select("id")
      .single();
    expect(again.error).toBeNull();

    const accepted = await clients.outsider.rpc("accept_invitation", {
      p_invitation_id: (again.data as { id: string }).id,
      p_user_id: userIds.outsider,
      p_role: "admin",
    });
    expect(accepted.data).toBe("already_member");

    const { data } = await service
      .from("memberships")
      .select("role")
      .eq("organization_id", nagisa)
      .eq("user_id", userIds.outsider)
      .single();
    expect((data as { role: string }).role).toBe("member");

    // 総当たりの前に、もとの顔ぶれへ戻します
    await service
      .from("memberships")
      .delete()
      .eq("organization_id", nagisa)
      .eq("user_id", userIds.outsider);
  });
});

suite("退会された方", () => {
  /** ご自身の組織をお持ちで、そこでお 1 人だけのオーナーの方です */
  let leaverId = "";
  let org = "";
  let projectId = "";

  beforeAll(async () => {
    const created = await service.auth.admin.createUser({
      email: LEAVER_EMAIL,
      password: PASSWORD,
      email_confirm: true,
    });
    if (created.error !== null) throw created.error;
    leaverId = created.data.user.id;

    const client = newClient(ANON_KEY);
    const signedIn = await client.auth.signInWithPassword({
      email: LEAVER_EMAIL,
      password: PASSWORD,
    });
    if (signedIn.error !== null) throw signedIn.error;

    const made = await client.rpc("create_organization_guarded", {
      p_name: "退会の見本",
      p_max_per_user: 10,
    });
    if (made.error !== null) throw made.error;
    org = (made.data as { organization: { id: string } }).organization.id;

    const seats = await service.from("memberships").insert([
      { organization_id: org, user_id: userIds.admin, role: "admin" },
      { organization_id: org, user_id: userIds.member, role: "member" },
    ]);
    if (seats.error !== null) throw seats.error;

    const { data, error } = await client
      .from("projects")
      .insert({
        organization_id: org,
        name: "退会された方のプロジェクト",
        note: "",
        created_by: leaverId,
      })
      .select("id")
      .single();
    if (error !== null) throw error;
    projectId = (data as { id: string }).id;
  });

  it("お 1 人だけのオーナーでも、退会していただけます", async () => {
    const removed = await service.auth.admin.deleteUser(leaverId);
    expect(removed.error).toBeNull();

    const { data: seats } = await service
      .from("memberships")
      .select("user_id")
      .eq("organization_id", org)
      .eq("user_id", leaverId);
    expect(seats?.length ?? 0).toBe(0);
  });

  it("お作りになったプロジェクトは残り、作成者の欄が空になります", async () => {
    const { data } = await service
      .from("projects")
      .select("name, created_by")
      .eq("id", projectId)
      .single();
    expect(data).toEqual({ name: "退会された方のプロジェクト", created_by: null });
  });

  it("その行を消せるのは、オーナーと管理者だけです", async () => {
    const byMember = await clients.member
      .from("projects")
      .delete()
      .eq("id", projectId)
      .select("id");
    expect(outcomeOf(byMember)).toEqual({ ok: false, message: "0 行" });

    const byAdmin = await clients.admin.from("projects").delete().eq("id", projectId).select("id");
    expect(outcomeOf(byAdmin).ok).toBe(true);
  });
});

suite("ご招待の行は、あとから作り替えられません", () => {
  let invitationId = "";

  beforeAll(async () => {
    const { data, error } = await clients.owner
      .from("invitations")
      .insert({
        organization_id: shiosai,
        email: "invited@example.com",
        role: "member",
        token_hash: "9".repeat(64),
        expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        invited_by: userIds.owner,
      })
      .select("id")
      .single();
    if (error !== null) throw error;
    invitationId = (data as { id: string }).id;
  });

  it("宛先・役割・トークン・組織・お招きした方は、変えられません", async () => {
    const patches: Record<string, unknown>[] = [
      { email: "other@example.com" },
      { role: "admin" },
      { token_hash: "8".repeat(64) },
      { organization_id: nagisa },
      { invited_by: userIds.admin },
      { accepted_by: userIds.member },
      { created_at: new Date(0).toISOString() },
    ];
    for (const patch of patches) {
      const changed = await clients.owner
        .from("invitations")
        .update(patch)
        .eq("id", invitationId)
        .select();
      expect(outcomeOf(changed).ok, Object.keys(patch)[0]).toBe(false);
    }

    const { data } = await service
      .from("invitations")
      .select("email, role, organization_id, token_hash")
      .eq("id", invitationId)
      .single();
    expect(data).toEqual({
      email: "invited@example.com",
      role: "member",
      organization_id: shiosai,
      token_hash: "9".repeat(64),
    });
  });

  it("状態は、お受けいただくか取り消すかの一方向だけです", async () => {
    const revoked = await clients.owner
      .from("invitations")
      .update({ status: "revoked" })
      .eq("id", invitationId)
      .select();
    expect(outcomeOf(revoked).ok).toBe(true);

    for (const status of ["pending", "accepted"]) {
      const back = await clients.owner
        .from("invitations")
        .update({ status })
        .eq("id", invitationId)
        .select();
      expect(outcomeOf(back).ok, status).toBe(false);
    }

    await service.from("invitations").delete().eq("id", invitationId);
  });
});

suite("メンバーの行を増やす道", () => {
  it("オーナーでも管理者でも、表を直に書く道では増やせません", async () => {
    const byOwner = await clients.owner
      .from("memberships")
      .insert({ organization_id: shiosai, user_id: userIds.outsider, role: "member" })
      .select();
    const byAdmin = await clients.admin
      .from("memberships")
      .insert({ organization_id: shiosai, user_id: userIds.outsider, role: "admin" })
      .select();
    expect(outcomeOf(byOwner).ok).toBe(false);
    expect(outcomeOf(byAdmin).ok).toBe(false);

    const { data } = await service
      .from("memberships")
      .select("user_id")
      .eq("organization_id", shiosai)
      .eq("user_id", userIds.outsider);
    expect(data?.length ?? 0).toBe(0);
  });
});

suite("オーナーが 0 人になる道", () => {
  /** オーナーの数を数えてから書くところが、同時のお申し出で追い越されないことを見ます */
  async function leaveAllAtOnce(round: number): Promise<{ left: number; owners: number }> {
    const { data: org, error } = await service
      .from("organizations")
      .insert({ name: `同時の退会の見本 ${round}` })
      .select("id")
      .single();
    if (error !== null) throw error;
    const organizationId = (org as { id: string }).id;

    const seated = await service
      .from("memberships")
      .insert(
        ACTORS.map((actor) => ({
          organization_id: organizationId,
          user_id: userIds[actor],
          role: "owner",
        })),
      );
    if (seated.error !== null) throw seated.error;

    // 5 本の接続から、同時に退会をお申し出になります
    const results = await Promise.all(
      ACTORS.map((actor) =>
        clients[actor]
          .from("memberships")
          .delete()
          .eq("organization_id", organizationId)
          .eq("user_id", userIds[actor])
          .select("user_id"),
      ),
    );

    const { data: owners } = await service
      .from("memberships")
      .select("user_id")
      .eq("organization_id", organizationId)
      .eq("role", "owner");

    await service.from("organizations").delete().eq("id", organizationId);
    return {
      left: results.filter((one) => outcomeOf(one).ok).length,
      owners: owners?.length ?? 0,
    };
  }

  it("オーナーが同時に退会されても、お 1 人は必ず残ります", async () => {
    for (let round = 1; round <= 3; round += 1) {
      const { left, owners } = await leaveAllAtOnce(round);
      expect(owners, `${round} 回目`).toBe(1);
      expect(left, `${round} 回目`).toBe(ACTORS.length - 1);
    }
  });
});

suite("プランの上限", () => {
  /** ご契約のないうちは無料のプランです（上限 3 件） */
  let org = "";

  async function projectCount(organizationId: string): Promise<number> {
    const { data } = await service.from("projects").select("id").eq("organization_id", organizationId);
    return data?.length ?? 0;
  }

  async function tryCreate(name: string, limit: number | null): Promise<string> {
    const { data, error } = await clients.owner.rpc("create_project_guarded", {
      p_organization_id: org,
      p_name: name,
      p_note: "",
      p_created_by: userIds.owner,
      p_limit: limit,
    });
    if (error !== null) throw error;
    return (data as { result: string }).result;
  }

  beforeAll(async () => {
    org = await createOrganization("owner", "上限の見本");
    const seated = await service
      .from("memberships")
      .insert({ organization_id: org, user_id: userIds.guest, role: "member" });
    if (seated.error !== null) throw seated.error;
  });

  it("上限の表の中身が、plans.config.ts と同じです", async () => {
    const { data, error } = await clients.owner.from("plan_limits").select("plan_id, project_limit");
    expect(error).toBeNull();

    const inDatabase: Record<string, number | null> = {};
    for (const row of (data ?? []) as { plan_id: string; project_limit: number | null }[]) {
      inDatabase[row.plan_id] = row.project_limit;
    }

    const inConfig: Record<string, number | null> = {};
    for (const plan of PLANS) inConfig[plan.id] = plan.projectLimit < 0 ? null : plan.projectLimit;

    expect(inDatabase).toEqual(inConfig);
  });

  it("上限の表は、読めますが書けません", async () => {
    const changed = await clients.owner
      .from("plan_limits")
      .update({ project_limit: 9999 })
      .eq("plan_id", "free")
      .select();
    const added = await clients.owner
      .from("plan_limits")
      .insert({ plan_id: "unlimited", project_limit: null })
      .select();
    const removed = await clients.owner.from("plan_limits").delete().eq("plan_id", "free").select();
    expect(outcomeOf(changed).ok).toBe(false);
    expect(outcomeOf(added).ok).toBe(false);
    expect(outcomeOf(removed).ok).toBe(false);

    const asVisitor = await visitor.from("plan_limits").select("plan_id");
    expect(asVisitor.data?.length ?? 0).toBe(0);
  });

  it("無料のプランでは、上限なしとお申し付けいただいても 3 件で止まります", async () => {
    const results = [
      await tryCreate("上限の見本 1", null),
      await tryCreate("上限の見本 2", null),
      await tryCreate("上限の見本 3", null),
      await tryCreate("上限の見本 4", null),
    ];
    expect(results).toEqual(["ok", "ok", "ok", "limit"]);
    expect(await projectCount(org)).toBe(3);
  });

  it("ご契約のあるプランでは、そのプランの上限まで作れます", async () => {
    const seeded = await service.from("subscriptions").insert({
      organization_id: org,
      plan_id: "standard",
      status: "active",
    });
    expect(seeded.error).toBeNull();

    expect(await tryCreate("上限の見本 4", null)).toBe("ok");
    expect(await projectCount(org)).toBe(4);
  });

  it("ご契約が止まっているあいだは、無料のプランの上限に戻ります", async () => {
    for (const status of ["canceled", "unpaid", "incomplete_expired"]) {
      const changed = await service
        .from("subscriptions")
        .update({ status })
        .eq("organization_id", org);
      expect(changed.error, status).toBeNull();
      expect(await tryCreate("止まっているあいだの 1 件", null), status).toBe("limit");
    }

    await service.from("subscriptions").update({ status: "active" }).eq("organization_id", org);
    expect(await projectCount(org)).toBe(4);
  });

  it("はじめのお支払いが確定するまでは、無料のプランの上限のままです", async () => {
    // incomplete は、お申し込みはお済みでもお支払いがまだ確定していない状態です。
    // ここを通してしまうと、お支払いが通らないまま有料の上限でお作りになれます。
    // 上限なしとお申し付け（p_limit: null）いただいても、SQL の中で止めます。
    const changed = await service
      .from("subscriptions")
      .update({ status: "incomplete" })
      .eq("organization_id", org);
    expect(changed.error).toBeNull();

    expect(await tryCreate("お支払いの確定をお待ちしているあいだの 1 件", null)).toBe("limit");
    expect(await projectCount(org)).toBe(4);

    await service.from("subscriptions").update({ status: "active" }).eq("organization_id", org);
  });

  it("お申し付けの上限は、厳しくはできますが緩められません", async () => {
    // いまは 4 件。5 件までとお申し付けいただけば作れます
    expect(await tryCreate("上限の見本 5", 5)).toBe("ok");
    // 4 件までとお申し付けいただければ、プランの上限より先にこちらで止まります
    expect(await tryCreate("上限の見本 6", 4)).toBe("limit");
    expect(await projectCount(org)).toBe(5);
  });

  it("同時に 2 件お申し込みいただいても、上限を超えて入りません", async () => {
    // 無料のプラン（3 件）に戻し、あと 1 件で上限になるところまで片づけます
    await service.from("subscriptions").delete().eq("organization_id", org);
    const { data } = await service.from("projects").select("id").eq("organization_id", org);
    const rows = (data ?? []) as { id: string }[];
    for (const row of rows.slice(2)) await service.from("projects").delete().eq("id", row.id);
    expect(await projectCount(org)).toBe(2);

    // 2 本の接続から同時にお申し込みいただきます（通るのは片方だけです）
    const [first, second] = await Promise.all([
      clients.owner.rpc("create_project_guarded", {
        p_organization_id: org,
        p_name: "同時のお申し込み 1",
        p_note: "",
        p_created_by: userIds.owner,
        p_limit: null,
      }),
      clients.guest.rpc("create_project_guarded", {
        p_organization_id: org,
        p_name: "同時のお申し込み 2",
        p_note: "",
        p_created_by: userIds.guest,
        p_limit: null,
      }),
    ]);

    const results = [first, second].map((one) =>
      one.error !== null ? "error" : (one.data as { result: string }).result,
    );
    expect(results.filter((result) => result === "ok").length).toBe(1);
    expect(results.filter((result) => result === "limit").length).toBe(1);
    expect(await projectCount(org)).toBe(3);
  });

  it("入れる組織の数は、お申し付けの数では増やせません", async () => {
    // いま入っていらっしゃる数を数えてから、上限の 10 まで作ります
    const { data: seats } = await service
      .from("memberships")
      .select("organization_id")
      .eq("user_id", userIds.owner);
    for (let i = (seats?.length ?? 0) + 1; i <= 10; i += 1) {
      const { data, error } = await clients.owner.rpc("create_organization_guarded", {
        p_name: `見本の組織 ${i}`,
        p_max_per_user: 10,
      });
      expect(error, `${i}`).toBeNull();
      expect((data as { result: string }).result, `${i}`).toBe("ok");
    }

    const { data, error } = await clients.owner.rpc("create_organization_guarded", {
      p_name: "11 番めの組織",
      p_max_per_user: 1000,
    });
    expect(error).toBeNull();
    expect((data as { result: string }).result).toBe("limit");
  });
});

/**
 * ここからが、役割の表（src/core/permissions.ts）との突き合わせです。
 * 「する側」3 人 × 組織 2 つで総当たりし、can() の答えと、
 * 表を直に読み書きした結果が一致することを確かめます。
 */
suite("役割の表との突き合わせ", () => {
  /** 突き合わせの 1 行分です */
  type Pair = { key: string; expected: boolean; actual: boolean };

  function expectedFor(
    action: Action,
    actor: ActorName,
    organizationId: string,
    extra: { resourceOwnerId?: string; targetRole?: Role } = {},
  ): boolean {
    const role = roleIn(actor, organizationId);
    if (role === null) return false;
    return can(action, { role, userId: userIds[actor], ...extra });
  }

  function label(actor: ActorName, organizationId: string): string {
    return `${actor}/${organizationId === shiosai ? "しおさい設計室" : "なぎさ工房"}`;
  }

  async function sweep(
    action: Action,
    probe: (actor: ActorName, organizationId: string) => Promise<boolean>,
    extra: (actor: ActorName, organizationId: string) => { resourceOwnerId?: string; targetRole?: Role } = () => ({}),
  ): Promise<Pair[]> {
    const pairs: Pair[] = [];
    for (const organizationId of [shiosai, nagisa]) {
      for (const actor of MATRIX_ACTORS) {
        pairs.push({
          key: label(actor, organizationId),
          expected: expectedFor(action, actor, organizationId, extra(actor, organizationId)),
          actual: await probe(actor, organizationId),
        });
      }
    }
    return pairs;
  }

  function agree(pairs: Pair[]): void {
    expect(pairs.map((pair) => `${pair.key}=${pair.actual}`)).toEqual(
      pairs.map((pair) => `${pair.key}=${pair.expected}`),
    );
  }

  it("project:read", async () => {
    agree(
      await sweep("project:read", async (actor, organizationId) => {
        const { data } = await clients[actor]
          .from("projects")
          .select("id")
          .eq("organization_id", organizationId);
        return (data?.length ?? 0) > 0;
      }),
    );
  });

  it("project:create", async () => {
    agree(
      await sweep("project:create", async (actor, organizationId) => {
        const created = await clients[actor]
          .from("projects")
          .insert({
            organization_id: organizationId,
            name: "総当たりの 1 件",
            note: "",
            created_by: userIds[actor],
          })
          .select("id");
        const outcome = outcomeOf(created);
        if (outcome.ok) {
          const rows = created.data as { id: string }[];
          await service.from("projects").delete().eq("id", rows[0].id);
        }
        return outcome.ok;
      }),
    );
  });

  it("project:update", async () => {
    agree(
      await sweep("project:update", async (actor, organizationId) => {
        const updated = await clients[actor]
          .from("projects")
          .update({ name: "見本のプロジェクト" })
          .eq("id", ownerProject[organizationId])
          .select("id");
        return outcomeOf(updated).ok;
      }),
    );
  });

  it("project:delete（ほかの方がお作りになった行）", async () => {
    agree(
      await sweep(
        "project:delete",
        async (actor, organizationId) => {
          const removed = await clients[actor]
            .from("projects")
            .delete()
            .eq("id", guestProject[organizationId])
            .select("id");
          const outcome = outcomeOf(removed);
          if (outcome.ok) {
            guestProject[organizationId] = await createProject(
              "guest",
              organizationId,
              "ご一緒の方のプロジェクト",
            );
          }
          return outcome.ok;
        },
        () => ({ resourceOwnerId: userIds.guest }),
      ),
    );
  });

  it("project:delete（ご自身がお作りになった行）", async () => {
    agree(
      await sweep(
        "project:delete",
        async (actor, organizationId) => {
          if (roleIn(actor, organizationId) === null) {
            // 組織の外の方は、そもそも行をお作りになれません
            const removed = await clients[actor]
              .from("projects")
              .delete()
              .eq("id", ownerProject[organizationId])
              .select("id");
            return outcomeOf(removed).ok;
          }
          const own = await createProject(actor, organizationId, "ご自身の 1 件");
          const removed = await clients[actor].from("projects").delete().eq("id", own).select("id");
          const outcome = outcomeOf(removed);
          if (!outcome.ok) await service.from("projects").delete().eq("id", own);
          return outcome.ok;
        },
        (actor) => ({ resourceOwnerId: userIds[actor] }),
      ),
    );
  });

  it("member:invite（メンバーとしてお招きする）", async () => {
    let seq = 0;
    agree(
      await sweep(
        "member:invite",
        async (actor, organizationId) => {
          seq += 1;
          const created = await clients[actor]
            .from("invitations")
            .insert({
              organization_id: organizationId,
              email: `sweep-${seq}@example.com`,
              role: "member",
              token_hash: `1${seq}`.padStart(64, "0"),
              expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
              invited_by: userIds[actor],
            })
            .select("id");
          const outcome = outcomeOf(created);
          if (outcome.ok) {
            const rows = created.data as { id: string }[];
            await service.from("invitations").delete().eq("id", rows[0].id);
          }
          return outcome.ok;
        },
        () => ({ targetRole: "member" }),
      ),
    );
  });

  it("member:invite（オーナーとしてお招きする）", async () => {
    let seq = 0;
    agree(
      await sweep(
        "member:invite",
        async (actor, organizationId) => {
          seq += 1;
          const created = await clients[actor]
            .from("invitations")
            .insert({
              organization_id: organizationId,
              email: `sweep-owner-${seq}@example.com`,
              role: "owner",
              token_hash: `2${seq}`.padStart(64, "0"),
              expires_at: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
              invited_by: userIds[actor],
            })
            .select("id");
          const outcome = outcomeOf(created);
          if (outcome.ok) {
            const rows = created.data as { id: string }[];
            await service.from("invitations").delete().eq("id", rows[0].id);
          }
          return outcome.ok;
        },
        () => ({ targetRole: "owner" }),
      ),
    );
  });

  it("member:setRole（メンバーの役割を変える）", async () => {
    agree(
      await sweep(
        "member:setRole",
        async (actor, organizationId) => {
          const updated = await clients[actor]
            .from("memberships")
            .update({ role: "admin" })
            .eq("organization_id", organizationId)
            .eq("user_id", userIds.guest)
            .select("user_id");
          const outcome = outcomeOf(updated);
          if (outcome.ok) {
            await service
              .from("memberships")
              .update({ role: "member" })
              .eq("organization_id", organizationId)
              .eq("user_id", userIds.guest);
          }
          return outcome.ok;
        },
        () => ({ targetRole: "member" }),
      ),
    );
  });

  it("member:remove（メンバーを外す）", async () => {
    agree(
      await sweep(
        "member:remove",
        async (actor, organizationId) => {
          const removed = await clients[actor]
            .from("memberships")
            .delete()
            .eq("organization_id", organizationId)
            .eq("user_id", userIds.guest)
            .select("user_id");
          const outcome = outcomeOf(removed);
          if (outcome.ok) {
            await service
              .from("memberships")
              .insert({ organization_id: organizationId, user_id: userIds.guest, role: "member" });
          }
          return outcome.ok;
        },
        () => ({ targetRole: "member" }),
      ),
    );
  });

  it("org:rename", async () => {
    agree(
      await sweep("org:rename", async (actor, organizationId) => {
        const updated = await clients[actor]
          .from("organizations")
          .update({ name: organizationId === shiosai ? "しおさい設計室" : "なぎさ工房" })
          .eq("id", organizationId)
          .select("id");
        return outcomeOf(updated).ok;
      }),
    );
  });

  it("org:delete", async () => {
    // ご契約が続いているあいだは、オーナーでも消せません
    const blocked = await clients.owner
      .from("organizations")
      .delete()
      .eq("id", shiosai)
      .select("id");
    expect(outcomeOf(blocked).ok).toBe(false);
    await service.from("subscriptions").delete().eq("organization_id", shiosai);

    // 消せてしまうと続きが確かめられないので、消せない方から順に見ます
    const pairs: Pair[] = [];
    for (const organizationId of [nagisa, shiosai]) {
      for (const actor of ["member", "admin", "owner"] as const) {
        const removed = await clients[actor]
          .from("organizations")
          .delete()
          .eq("id", organizationId)
          .select("id");
        pairs.push({
          key: label(actor, organizationId),
          expected: expectedFor("org:delete", actor, organizationId),
          actual: outcomeOf(removed).ok,
        });
      }
    }
    agree(pairs);
  });
});
