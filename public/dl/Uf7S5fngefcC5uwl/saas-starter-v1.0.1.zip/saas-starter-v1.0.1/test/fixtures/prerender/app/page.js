// サーバーの中だけで動くファイルの見本です。ブラウザには配られません。
// 鍵の名前も、鍵の形の字も、ここに出てくるのは正しい姿です。
const url = process.env.SUPABASE_SERVICE_ROLE_KEY;
const secret = process.env.STRIPE_SECRET_KEY;
const admins = process.env.ADMIN_EMAILS;
// 鍵そのものではなく、**調べる語の頭だけ**です（続きの文字は入れていません）。
const shapes = ["service_role", "sk_live_", "sk_test_", "whsec_"];
const fields = ["priceEnvName", "stripeSubscriptionId", "stripe_subscription_id", "tokenHash"];
module.exports = { url, secret, admins, shapes, fields };
