// 入れ子の入れ物も、たどって調べます。
// 鍵そのものではなく、**鍵の形をした見本の文字**です
// （gitleaks などの道具に当たらないよう、そうと分かる字にしてあります）。
export const secret = "sk_live_EXAMPLE_NOT_A_KEY";
