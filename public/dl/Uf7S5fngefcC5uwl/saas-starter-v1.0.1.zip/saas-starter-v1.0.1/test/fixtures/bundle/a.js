// ブラウザに配られる束に、鍵の名前が紛れ込んだときの見本です。
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
export default key;
