// 何も紛れ込んでいない束の見本です。
export const hello = "こんにちは";
