/**
 * プランの上限は 2 か所にあります。
 *   1. plans.config.ts … 画面の料金表と、お申し込みの前のご案内
 *   2. 移行の SQL の plan_limits … データベースの中で上限を引き直すときの元
 *
 * 上限を引き直すときの**条件**（どの状態のとき無料の上限に戻すか）も、同じく 2 か所です。
 *   1. src/core/billing-state.ts の isEntitled … 画面と flow が見る一覧
 *   2. 移行の SQL の create_project_guarded … SQL を直に呼んだときに効く一覧
 *
 * 片方だけを書き換えると、ご案内と実際の上限が食い違います。
 * この検査は移行の SQL の文字を読んで突き合わせるので、
 * ローカルの Supabase が無くても回ります
 * （データベースにつないだ形の同じ確かめは test/rls.test.ts にあります）。
 */
import { readdirSync, readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { PLANS } from "../plans.config";
import {
  hasOpenSubscription,
  isEntitled,
  STRIPE_STATUSES,
} from "../src/core/billing-state";
import { MAX_ORGS_PER_USER } from "../src/server/flows/organizations";

const MIGRATIONS_DIR = new URL("../supabase/migrations/", import.meta.url);

/**
 * 移行の SQL を、**名前順にすべて**つないだものです。
 *
 * プランを増やすときは、はじめの移行を書き換えるのではなく、
 * 新しい移行のファイルをお足しになります（README 10 章）。
 * 1 つ目のファイルだけを読むと、そのお直しが見えず、
 * データベースは正しいのにこの検査だけが赤くなってしまいます。
 */
const sql = readdirSync(MIGRATIONS_DIR)
  .filter((name) => name.endsWith(".sql"))
  .sort()
  .map((name) => readFileSync(new URL(name, MIGRATIONS_DIR), "utf8"))
  .join("\n");

/**
 * 移行の SQL が plan_limits に入れている上限です（null は上限なし）。
 *
 * 同じプランが何度も出てくるときは、**あとの移行のほうを採ります**
 * （あとから上限をお変えになっても、そのとおりに読めます）。
 */
function limitsInSql(): Record<string, number | null> {
  const found: Record<string, number | null> = {};

  for (const block of sql.matchAll(/insert into public\.plan_limits[\s\S]*?;/gi)) {
    for (const row of block[0].matchAll(/\(\s*'([a-z_]+)'\s*,\s*(\d+|null)\s*\)/gi)) {
      found[row[1]] = row[2].toLowerCase() === "null" ? null : Number(row[2]);
    }
  }

  if (Object.keys(found).length === 0) {
    throw new Error("移行の SQL に plan_limits の行がありません");
  }
  return found;
}

/**
 * subscriptions.plan_id に並んでいるプランの名前です。
 *
 * **いちばん最後の書き方を採ります。** この check をお直しになるときは、
 * 列の定義ではなく `alter table … drop constraint … add constraint …` の形になるためです。
 */
function planIdsInCheck(): string[] {
  const all = [...sql.matchAll(/check\s*\(\s*plan_id\s+in\s*\(([^)]*)\)/gi)];
  const last = all[all.length - 1];
  if (last === undefined) {
    throw new Error("移行の SQL に subscriptions.plan_id の check がありません");
  }
  return [...last[1].matchAll(/'([a-z_]+)'/gi)].map((found) => found[1]);
}

/** plans.config.ts の -1（上限なし）を、SQL の null に読み替えます */
function limitsInConfig(): Record<string, number | null> {
  const found: Record<string, number | null> = {};
  for (const plan of PLANS) found[plan.id] = plan.projectLimit < 0 ? null : plan.projectLimit;
  return found;
}

describe("プランの上限は 2 か所でそろっています", () => {
  it("plans.config.ts と plan_limits の中身が同じです", () => {
    expect(limitsInSql()).toEqual(limitsInConfig());
  });

  it("プランの名前が、subscriptions の check ともそろっています", () => {
    expect(planIdsInCheck().sort()).toEqual(PLANS.map((plan) => plan.id).sort());
  });

  it("上限なしのプランは、SQL では null です（-1 という書き方は持ち込みません）", () => {
    const unlimited = PLANS.filter((plan) => plan.projectLimit < 0).map((plan) => plan.id);
    const sqlLimits = limitsInSql();
    for (const id of unlimited) expect(sqlLimits[id], id).toBeNull();
  });
});

/** SQL の in (…) に並んでいる '…' を、そのままの順で取り出します */
function quotedIn(list: string): string[] {
  return [...list.matchAll(/'([a-z_]+)'/gi)].map((found) => found[1]);
}

/** create_project_guarded が「止まっている」と見ている状態です */
function stoppedInSql(): string[] {
  // あとの移行で関数をお書き直しになったときは、いちばん最後の書き方を採ります
  const all = [...sql.matchAll(/v_status\s+in\s*\(([^)]*)\)/gi)];
  const found = all[all.length - 1];
  if (found === undefined) {
    throw new Error("create_project_guarded に、止まっている状態の一覧がありません");
  }
  return quotedIn(found[1] ?? "");
}

/** organizations_guard_delete が「ご契約の実体が残っている」と見ている状態です */
function openInSql(): string[] {
  // こちらも、いちばん最後の書き方を採ります
  const all = [...sql.matchAll(/s\.status\s+in\s*\(([^)]*)\)/gi)];
  const found = all[all.length - 1];
  if (found === undefined) {
    throw new Error("organizations_guard_delete に、ご契約の状態の一覧がありません");
  }
  return quotedIn(found[1] ?? "");
}

describe("ご契約の状態の一覧は、SQL と TypeScript でそろっています", () => {
  it("上限を無料に戻す状態が、isEntitled と同じです", () => {
    // 食い違うと、SQL を直に呼んだときだけ有料の上限で作れてしまいます
    // （flow は厳しい側の上限を渡すので、画面からは気づけません）。
    const stopped = STRIPE_STATUSES.filter((status) => !isEntitled(status));
    expect(stoppedInSql().sort()).toEqual([...stopped].sort());
  });

  it("組織を消せない状態が、hasOpenSubscription と同じです", () => {
    // 食い違うと、ご契約が残ったままの組織が、SQL の側では消せてしまいます
    // （お支払いだけが続き、こちらには組織も決済のお客さま番号も残りません）。
    const open = STRIPE_STATUSES.filter((status) => hasOpenSubscription(status));
    expect(openInSql().sort()).toEqual([...open].sort());
  });
});

describe("お一人が入れる組織の数", () => {
  it("サーバーの処理と、SQL の中の数がそろっています", () => {
    const found = sql.match(/least\(p_max_per_user,\s*(\d+)\)/);
    expect(found, "SQL に上限の数がありません").not.toBeNull();
    expect(Number(found?.[1])).toBe(MAX_ORGS_PER_USER);
  });
});
