# 利用許諾（SaaS スターター キット）

発行者: suminawa（hello@suminawa.dev）　対象: 本 zip に含まれるすべてのファイル　版: 1.0（2026-10-06）

1. 個人ライセンス: 購入者本人が、自分の業務・自分の案件で、数に制限なく使えます。
2. 組織ライセンス: 購入した組織（法人・チーム）が、その組織の業務で使えます。個人ライセンスで購入した場合、所属組織の他のメンバーへの配布はできません。
3. 改変: 自由です。改変したものを自分の業務で使うことも、クライアントのウェブサービスに組み込んで納品することもできます。納品できるのは、組み込んだ成果物（この土台の上にお作りになったサービス一式）です。この zip そのものや `src/`・`app/`・`supabase/` 一式を、そのままお渡しになることはできません。
4. 禁止: 本ファイル一式（改変の有無を問わず）の再配布・転売・共有、テンプレートやパック商品としての再販、同種の商品として販売すること。
5. 法務のひな形: `legal/` の 6 つの文面と `legal.config.ts` は、書き換えてお使いいただくための見本です。**そのままお使いいただけることを保証しません。**内容の正しさ・法令への適合について、発行者は責任を負いません。公開の前に、弁護士など専門家のご確認をお願いいたします。
6. 保証と責任: 現状有姿で提供します。発行者の故意または重大な過失による場合を除き、本ソフトウェアに関する損害賠償の責任は購入代金を上限とします。決済の失敗、ご契約の状態の取り違え、データの消失、通信の途絶によって生じた結果について、発行者は責任を負いません。Supabase・Stripe・Resend・置き場所の各サービスのご利用料金と、それらの規約の遵守は、お客さまのご負担とご責任になります。
7. サポート: 購入後 14 日間、不具合のご連絡にメールで対応します（3 営業日以内に返信）。
8. 更新: 1.x のあいだの更新は無料です。
9. 返金: デジタル商品の性質上、ダウンロード後の返金はできません。不具合のご連絡には、第 7 項のとおり購入後 14 日間、3 営業日以内に返信いたします。
10. 準拠法: 日本法。紛争が生じたときは、発行者の所在地を管轄する裁判所を第一審の専属的合意管轄とします。

購入日をもって本許諾に同意したものとします。

本許諾には、下に英訳を添えています。日本語と英語の内容に食い違いがあるときは、日本語を優先します。

---

# Licence (SaaS Starter Kit)

Publisher: suminawa (hello@suminawa.dev)　Covers: every file in this zip　Version: 1.0 (2026-10-06)

1. Personal licence: the purchaser may use the kit in their own work and their own client projects, with no limit on the number of projects.
2. Organisation licence: the organisation (company or team) that bought the kit may use it for that organisation's work. A personal licence does not extend to other members of the purchaser's organisation.
3. Modification: permitted without restriction. You may use modified versions in your own work, and you may deliver them as part of a client's web service. What you deliver is the service you built on this foundation — not this zip itself, nor `src/`, `app/` or `supabase/` as a set.
4. Not permitted: redistributing, reselling or sharing the package as a whole (modified or not); reselling it as a template or in a bundle; selling it as a competing product.
5. Legal templates: the six documents in `legal/` and the values in `legal.config.ts` are samples meant to be rewritten. **They are not guaranteed to be usable as they are.** The publisher accepts no responsibility for their accuracy or for their compliance with any law. Please have a lawyer or another qualified professional review them before you publish.
6. Warranty and liability: provided as is. Except in cases of wilful misconduct or gross negligence by the publisher, liability for any damages relating to this software is limited to the purchase price. The publisher is not liable for consequences arising from failed payments, misread subscription state, data loss or loss of connectivity. The fees charged by Supabase, Stripe, Resend and your hosting provider, and compliance with those services' terms, are your own responsibility.
7. Support: defect reports are handled by email for 14 days after purchase, with a reply within three business days.
8. Updates: updates within 1.x are free.
9. Refunds: as a digital product, it cannot be refunded once downloaded. Defect reports are answered as set out in clause 7: within three business days, for 14 days after purchase.
10. Governing law: the laws of Japan. Any dispute shall be submitted to the exclusive jurisdiction of the court of first instance having jurisdiction over the publisher's place of business.

Purchase constitutes acceptance of these terms.

**In the event of any discrepancy between the Japanese text above and this English translation, the Japanese text prevails.**
