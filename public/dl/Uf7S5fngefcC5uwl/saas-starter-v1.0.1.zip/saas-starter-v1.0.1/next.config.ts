import type { NextConfig } from "next";

const config: NextConfig = {
  reactStrictMode: true,
  // 鍵の名前をクライアントの束に持ち込まないため、env の自動の受け渡しは使わない。
  // ブラウザで読んでよいのは NEXT_PUBLIC_ で始まる変数だけ。
  poweredByHeader: false,
  // 配布物に覚え書きのファイルを増やさないため、自動生成は止めています
  agentRules: false,
  // 法務の 3 枚は、素のテキストを立ち上げた場所から読んでお出しします。
  // 配る先に legal/ が付いてこないと、その 3 枚だけ 500 になります。
  // 組み立ての道具の見立てに任せず、ここで一緒に配るようお願いしています。
  // 鍵はページの道すじ、値はこの場所からのたどり方です。
  outputFileTracingIncludes: {
    "/legal/*": ["./legal/*.txt"],
  },
};

export default config;
