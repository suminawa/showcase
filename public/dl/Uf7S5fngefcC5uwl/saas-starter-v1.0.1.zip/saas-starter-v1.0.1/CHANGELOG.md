# 更新履歴

## 1.0.1 — 2026-09-25

小さな手直しです。1.0.0 をお求めの方は無料で更新いただけます。

- ログインの誤り（`error=unavailable`）のうち、確認メールのリンクを登録したときと別のブラウザで開いたときだけの症状を、`wrong_browser` という新しい符号に分けました。ログインの画面には「確認メールのリンクは、登録したときと同じブラウザで開いてください。別のブラウザで開いた場合は、このページから合言葉（パスワード）でログインするか、もう一度登録のメールをお送りください。」と出るようになります（ほかの `unavailable` の場面の文はそのままです）。README のよくあるつまずきの表にも、同じ症状と直し方を足しました
  (Split the login error `error=unavailable` case that is specific to opening the confirmation link in a different browser than the one used to sign up into its own `wrong_browser` code, with a message explaining the fix on the login page. The generic `unavailable` message for other situations is unchanged. The same symptom and fix were added to the README's troubleshooting table)
- README の `stripe listen` の手順に、`Ready!` のあとの確かめ方を足しました。決済のたびに `-->` と `<-- [200]` の行が並ぶことを見て、並ばなければ `--forward-to` の付け忘れだと分かるようにしています
  (Added a verification step after the `stripe listen` command in the README: confirm a matching `-->`/`<-- [200]` line appears for each payment, and that its absence means `--forward-to` is missing)
- 「承ります」の言い回しを、画面・法務のひな形・README から取り除きました（「行えます」「受け付けます」などに言い換えています）
  (Removed the word "承ります" from the app, the legal templates and the README, rephrasing each occurrence in plain 敬体 Japanese)

## 1.0.0 — 2026-09-24

初版。

- 発売前の一周（2026-09-24、本物の Stripe のテストモード）で見つけた 2 点を直してあります
  (Two fixes from the pre-release walkthrough against real Stripe test mode)
  - 「期間の終わりでのご解約」を、新しい版の Stripe が `cancel_at` で知らせてきても、予定ありとして写します
    (Scheduled cancellations reported via `cancel_at` by the current Stripe API are now reflected as `cancel_at_period_end`)
  - README の `stripe listen` に `--events …` を付けました（CLI 1.5x で必須です）
    (The `stripe listen` command in the README now includes `--events`, which the CLI 1.5x requires)
- ログイン・組織・ご招待・プロジェクト・お支払い・法務の 16 の道すじが、そのまま動きます
  (Sixteen working routes: sign-in, organisations, invitations, projects, billing and the legal pages)
- 役割は owner・admin・member の 3 つ。表は `src/core/permissions.ts` の 1 か所にあり、画面と仕事の流れと行の出入りの決まりが、同じ表から決まります
  (Three roles, defined once in `src/core/permissions.ts`, from which the screens, the flows and the database policies are all derived)
- 表は 8 つ。すべてに行の出入りの決まり（RLS）があり、`memberships` を通してだけ見えます。ご契約と決済の 3 つの表に書けるのは service role だけです
  (Eight tables, all with row-level security; visibility flows through `memberships`, and only the service role writes the three billing tables)
- プランは 3 つ（無料・スタンダード ¥2,980・ビジネス ¥9,800）。上限は `plans.config.ts` と `plan_limits` の 2 か所でそろえます
  (Three plans, with quotas kept in step between `plans.config.ts` and `plan_limits`)
- Stripe の Checkout とお支払いの管理の画面、決済の通知 5 種。順不同で届いても最新の状態を取り直してから書き、同じ `event.id` は二度処理しません
  (Stripe Checkout, the customer portal, and five webhook event types; state is re-fetched before writing and each event id is handled once)
- ご招待はトークン 32 バイト・期限 7 日・1 回きり。表に置くのはハッシュだけです
  (Invitations use a 32-byte token, expire in 7 days and work once; only the hash is stored)
- `STARTER_FAKE=1` のあいだは、鍵が 1 つも無くても全部の画面が動きます。外へは何も送りません
  (With `STARTER_FAKE=1` every screen runs without a single key, and nothing leaves the machine)
- 画面の文は日本語と英語。明るい配色と暗い配色、390px 幅で 1 列、キーボードだけで一周できます
  (Japanese and English interface strings, light and dark palettes, a single column at 390px, and full keyboard operation)
- 法務のひな形は 3 種 6 枚（日本語が正、英語は要点の訳）。差し込む値は `legal.config.ts` にまとまっています
  (Three legal documents in two languages, with the interpolated values collected in `legal.config.ts`)
- 運営の方だけの見渡しの画面（`/admin`）。読むだけで、`ADMIN_EMAILS` が未設定のあいだは 404 です
  (A read-only operator overview at `/admin`, which is a 404 until `ADMIN_EMAILS` is set)
- 検査は vitest が 591 件、行の出入りの決まりが pgTAP 26 件とログインでの検査 65 件、つなぎ役の検査 36 件
  (591 vitest tests, plus 26 pgTAP checks, 65 policy tests and 36 adapter tests against a real database)
- ブラウザへ届くものに鍵が無いことを、2 通りに組み立て直し、立てたサーバーのお返事まで読んで確かめます（`npm run check:bundle`）
  (`npm run check:bundle` rebuilds the app both ways, then reads the live responses of a server it starts)
- 依存パッケージは 7 つだけ（`next`・`react`・`react-dom`・`@supabase/supabase-js`・`@supabase/ssr`・`stripe`・`resend`）
  (Seven runtime dependencies and no CSS framework)
- zip の中身: `app/`・`src/`・`supabase/`・`messages/`・`legal/`・`scripts/`・`test/`・設定のファイル 8 つと、4 つの文書
  (In the zip: the app, the source, the database, the strings, the legal text, the scripts, the tests, eight config files and the four documents)
