-- 関数と引き金です。
--
-- 大きく 3 つに分かれます。
--   1. 見え方を決める補助の関数（is_member・member_role・shares_organization）
--      行の出入りの決まりが memberships を直に読むと、その決まりがまた memberships を読み……と
--      際限がなくなります。security definer の関数をはさんで、そこで切ります。
--   2. 表を守る引き金（最後のオーナー・組織の付け替え・ご契約が残ったままの削除）
--   3. 「数えてから書く」を 1 回で行う関数（同時に 2 つ届いても、片方だけが通ります）
--
-- security definer の関数は、いずれも中で auth.uid() と memberships を確かめます。
-- 関数を直に呼んでも、画面から呼んだときより広いことはできません。
-- search_path は空に固定してあります（呼んだ側の設定で別の表にすり替えられないように
-- するためです）。そのため、表も関数も public. まで書いてあります。
--
-- お止めしたときの符号（画面の側は、この符号で理由を見分けます）
--   ST001 … その操作を行える立場ではありません（ログインが要る・一員でない・役割が足りない）
--   ST002 … オーナーに関わる操作は、オーナーだけが行えます
--   ST003 … 組織にはオーナーがお 1 人は要ります（最後のオーナーは降ろせません）
--   ST004 … あとから変えられない欄を、変えようとしました
--   ST005 … ご契約が続いているあいだは、組織を消せません
--   ST006 … プランの上限の設定が見つかりません（plan_limits の行が足りません）
--   22023 … 渡された値が正しくありません（役割の名前など）

-- ===========================================================================
-- 1. 見え方を決める補助の関数
-- ===========================================================================

create or replace function public.is_member(org uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.memberships m
    where m.organization_id = org and m.user_id = auth.uid()
  );
$$;

comment on function public.is_member(uuid) is 'いまログインしている方が、その組織の一員かどうか';

create or replace function public.member_role(org uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select m.role from public.memberships m
  where m.organization_id = org and m.user_id = auth.uid();
$$;

comment on function public.member_role(uuid) is
  'いまログインしている方の、その組織での役割。一員でなければ null';

create or replace function public.shares_organization(p_user uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.memberships mine
    join public.memberships theirs on theirs.organization_id = mine.organization_id
    where mine.user_id = auth.uid() and theirs.user_id = p_user
  );
$$;

comment on function public.shares_organization(uuid) is
  'いまログインしている方と、その方が、同じ組織にご一緒かどうか';

-- ===========================================================================
-- 2. 表を守る引き金
-- ===========================================================================

-- auth.users に行が入ったら、対になる profiles の行を作ります。
-- 組織はここでは作りません（はじめの組織は /onboarding でお作りいただきます）。
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, name)
  values (
    new.id,
    coalesce(lower(new.email), ''),
    -- お名前は 80 文字までです。長いときは、ご登録そのものを止めずに切り詰めます。
    -- お名前を頂戴していないときは、メールアドレスの @ より前を仮のお名前にします
    -- （画面の側の「表示のお名前が空のとき」の決まりと同じです。
    -- あとからプロフィールの画面でお変えいただけます）。
    left(
      coalesce(
        nullif(trim(new.raw_user_meta_data ->> 'name'), ''),
        split_part(coalesce(new.email, ''), '@', 1)
      ),
      80
    )
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

comment on function public.handle_new_user() is 'ご登録に合わせて profiles の行を作ります';

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ご本人と分かる欄（id・メールアドレス・ご登録の時刻）は、あとから変えられません。
-- メールアドレスは、ご登録のときに auth.users から写した値のままにします
-- （ご招待の突き合わせが、この値で行われるためです）。
create or replace function public.profiles_before_update()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.id is distinct from old.id
    or new.email is distinct from old.email
    or new.created_at is distinct from old.created_at
  then
    raise exception 'ご本人と分かる欄は、あとから変えられません' using errcode = 'ST004';
  end if;
  return new;
end;
$$;

create trigger profiles_before_update
  before update on public.profiles
  for each row execute function public.profiles_before_update();

-- プロジェクトは、あとから別の組織へ移せません。
-- 更新の時刻は、この引き金が入れます（呼んだ側の時計に頼りません）。
-- お作りになった方が退会された道でだけ、作成者の欄が空に変わります。
create or replace function public.projects_before_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_creator_left boolean := new.created_by is null
    and old.created_by is not null
    and not exists (select 1 from public.profiles p where p.id = old.created_by);
begin
  if new.id is distinct from old.id
    or new.organization_id is distinct from old.organization_id
    or (new.created_by is distinct from old.created_by and not v_creator_left)
  then
    raise exception 'プロジェクトの組織と作成者は変更できません' using errcode = 'ST004';
  end if;

  new.created_at := old.created_at;
  -- 退会に合わせて欄が空になるだけのときは、更新の時刻を動かしません
  new.updated_at := case when v_creator_left then old.updated_at else now() end;
  return new;
end;
$$;

create trigger projects_before_update
  before update on public.projects
  for each row execute function public.projects_before_update();

-- オーナーが 0 人の組織を作らないための守りです。
-- 組織そのものを消したときは、連れて消える行を止めません。
create or replace function public.memberships_guard()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owners integer;
begin
  if tg_op = 'UPDATE' then
    if new.organization_id is distinct from old.organization_id
      or new.user_id is distinct from old.user_id
    then
      raise exception 'メンバーの行は、別の組織や別の方へ付け替えられません' using errcode = 'ST004';
    end if;
  end if;

  if old.role = 'owner' and (tg_op = 'DELETE' or new.role <> 'owner') then
    -- 組織ごと消したときと、その方が退会された（profiles の行が消えた）ときは、
    -- 連れて消える行を止めません。止めると、退会そのものができなくなるためです
    if exists (select 1 from public.organizations o where o.id = old.organization_id)
      and exists (select 1 from public.profiles p where p.id = old.user_id)
    then
      -- 数える前に錠を取ります（役割を変える関数と同じ鍵です）。
      -- これが無いと、お 2 人が同時に退会をお申し出になったときに、
      -- どちらも「まだ 2 人いる」と数えてしまい、オーナーが 0 人になります。
      perform pg_advisory_xact_lock(
        hashtext('saas_starter:memberships'),
        hashtext(old.organization_id::text)
      );

      select count(*) into v_owners
      from public.memberships m
      where m.organization_id = old.organization_id and m.role = 'owner';

      if v_owners <= 1 then
        raise exception '組織にはオーナーが 1 人以上必要です' using errcode = 'ST003';
      end if;
    end if;
  end if;

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

create trigger memberships_guard
  before update or delete on public.memberships
  for each row execute function public.memberships_guard();

-- ご招待は、お出ししたあとで中身を作り替えられません。
-- 宛先や役割を書き換えられると、お出ししたご招待が別のものに化けてしまいます。
-- 状態は pending から accepted / revoked への一方向だけです。
-- 「どなたがお受けになったか」は、お受けになった瞬間にだけ入ります。
create or replace function public.invitations_before_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  -- 退会に伴って、その方を指していた列が null に落ちる道です
  v_inviter_left boolean := new.invited_by is null
    and old.invited_by is not null
    and not exists (select 1 from public.profiles p where p.id = old.invited_by);
  v_accepter_left boolean := new.accepted_by is null
    and old.accepted_by is not null
    and not exists (select 1 from public.profiles p where p.id = old.accepted_by);
begin
  if new.id is distinct from old.id
    or new.organization_id is distinct from old.organization_id
    or new.token_hash is distinct from old.token_hash
    or new.email is distinct from old.email
    or new.role is distinct from old.role
    or new.created_at is distinct from old.created_at
    or (new.invited_by is distinct from old.invited_by and not v_inviter_left)
  then
    raise exception 'ご招待の宛先と役割は、あとから変えられません' using errcode = 'ST004';
  end if;

  if new.status is distinct from old.status
    and not (old.status = 'pending' and new.status in ('accepted', 'revoked'))
  then
    raise exception 'ご招待の状態は、お受けになるか取り消すかの一方向だけです' using errcode = 'ST004';
  end if;

  if new.accepted_by is distinct from old.accepted_by
    and not v_accepter_left
    and not (
      old.accepted_by is null
      and new.accepted_by is not null
      and old.status = 'pending'
      and new.status = 'accepted'
    )
  then
    raise exception 'お受けになった方の記録は、あとから変えられません' using errcode = 'ST004';
  end if;

  return new;
end;
$$;

create trigger invitations_before_update
  before update on public.invitations
  for each row execute function public.invitations_before_update();

-- ご契約が残ったまま組織を消すと、お支払いだけが続いてしまいます。
-- 画面の流れでも同じことをお止めしていますが、ここが最後の砦です。
create or replace function public.organizations_guard_delete()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  -- 決済のしくみの側に、まだご契約の実体が残っている状態です
  -- （src/core/billing-state.ts の hasOpenSubscription とそろえてあります。
  -- 食い違うと test/plan-limits.test.ts が落ちます）。
  -- incomplete（はじめのお支払いの確認待ち）と paused（一時停止中）と
  -- unpaid（お支払いが滞っている）も、そのあとご請求が始まりえますので止めます。
  if exists (
    select 1 from public.subscriptions s
    where s.organization_id = old.id
      and s.status in ('active', 'trialing', 'past_due', 'paused', 'unpaid', 'incomplete')
  ) then
    raise exception 'ご契約が続いているあいだは、組織を消せません' using errcode = 'ST005';
  end if;
  return old;
end;
$$;

create trigger organizations_guard_delete
  before delete on public.organizations
  for each row execute function public.organizations_guard_delete();

-- ===========================================================================
-- 3. 「数えてから書く」を 1 回で行う関数
--
-- どれも、数えるところと書くところを同じ取引の中で行います。
-- 同じ組織（または同じ方）に対する呼び出しは、助言の錠で 1 つずつ通します。
-- 戻り値は、画面の側の型（DataPort）と同じ言葉です。
-- 引数の uuid は、呼ぶ側（adapter）が形をそろえてからお渡しください。
-- ===========================================================================

-- 組織を作り、お作りになった方をオーナーにします。
-- 戻り値: {"result":"ok","organization":{…}} または {"result":"limit"}
create or replace function public.create_organization_guarded(
  p_name text,
  p_max_per_user integer
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  -- お一人が入れる組織の数の上限です。お申し付けの数では増やせません
  -- （least は null を無視するので、お申し付けが無ければこの数になります）。
  v_max integer := least(p_max_per_user, 10);
  v_count integer;
  v_org public.organizations;
begin
  if v_user is null then
    raise exception 'ログインが必要です' using errcode = 'ST001';
  end if;

  -- 同じ方からの同時のお申し付けを 1 つずつ通します
  perform pg_advisory_xact_lock(hashtext('saas_starter:org_per_user'), hashtext(v_user::text));

  select count(*) into v_count
  from public.memberships m
  where m.user_id = v_user;

  if v_count >= v_max then
    return jsonb_build_object('result', 'limit');
  end if;

  insert into public.organizations (name) values (p_name) returning * into v_org;

  insert into public.memberships (organization_id, user_id, role, created_at)
  values (v_org.id, v_user, 'owner', v_org.created_at);

  return jsonb_build_object('result', 'ok', 'organization', to_jsonb(v_org));
end;
$$;

comment on function public.create_organization_guarded(text, integer) is
  '組織を作り、お作りになった方をオーナーにします。上限を超えるときは limit';

-- プロジェクトを 1 件作ります。
-- 件数の上限は、その組織のご契約から plan_limits を引き直して決めます。
-- p_limit（呼ぶ側のお申し付け）は、上限を厳しくする向きにだけ効きます。
-- 戻り値: {"result":"ok","project":{…}} または {"result":"limit"}
create or replace function public.create_project_guarded(
  p_organization_id uuid,
  p_name text,
  p_note text,
  p_created_by uuid,
  p_limit integer
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_plan text;
  v_status text;
  v_limit integer;
  v_count integer;
  v_project public.projects;
begin
  if v_user is null then
    raise exception 'ログインが必要です' using errcode = 'ST001';
  end if;
  if p_created_by is distinct from v_user then
    raise exception 'ご自身以外の名前ではお作りになれません' using errcode = 'ST001';
  end if;
  if not public.is_member(p_organization_id) then
    raise exception 'この組織のメンバーではありません' using errcode = 'ST001';
  end if;

  -- いまのプランです。ご契約が無いときと、止まっているときは無料のプランです。
  -- incomplete（はじめのお支払いがまだ確定していない）も、ここでは止まっている側です
  -- （確定する前に、上のプランの上限でお使いいただけてしまわないようにするためです）。
  -- この一覧は src/core/billing-state.ts の isEntitled とそろえてあります
  -- （食い違うと test/plan-limits.test.ts が落ちます）。
  select s.plan_id, s.status into v_plan, v_status
  from public.subscriptions s
  where s.organization_id = p_organization_id;

  if v_plan is null
    or v_status in ('canceled', 'unpaid', 'incomplete', 'incomplete_expired')
  then
    v_plan := 'free';
  end if;

  -- 上限は、この土台の中で引き直します（呼ぶ側の言い値は使いません）
  select l.project_limit into v_limit
  from public.plan_limits l
  where l.plan_id = v_plan;

  if not found then
    -- 知らないプランの名前のときは、いちばん厳しい無料の上限に寄せます
    select l.project_limit into v_limit
    from public.plan_limits l
    where l.plan_id = 'free';

    if not found then
      raise exception 'プランの上限の設定が見つかりません' using errcode = 'ST006';
    end if;
  end if;

  -- 呼ぶ側のお申し付けは、上限を厳しくする向きにだけ効きます
  -- （least は null を無視するので、どちらかが「上限なし」でも正しく決まります）。
  v_limit := least(v_limit, p_limit);

  if v_limit is not null then
    -- 同じ組織への同時のお申し付けを 1 つずつ通します
    perform pg_advisory_xact_lock(
      hashtext('saas_starter:project_limit'),
      hashtext(p_organization_id::text)
    );

    select count(*) into v_count
    from public.projects p
    where p.organization_id = p_organization_id;

    if v_count >= v_limit then
      return jsonb_build_object('result', 'limit');
    end if;
  end if;

  insert into public.projects (organization_id, name, note, created_by)
  values (p_organization_id, p_name, p_note, v_user)
  returning * into v_project;

  return jsonb_build_object('result', 'ok', 'project', to_jsonb(v_project));
end;
$$;

comment on function public.create_project_guarded(uuid, text, text, uuid, integer) is
  'プロジェクトを 1 件作ります。上限に達しているときは limit';

-- 役割を変えます。戻り値: 'ok' | 'last_owner' | 'not_found'
create or replace function public.change_member_role(
  p_organization_id uuid,
  p_user_id uuid,
  p_role text
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor text;
  v_target text;
  v_owners integer;
begin
  if auth.uid() is null then
    raise exception 'ログインが必要です' using errcode = 'ST001';
  end if;
  if p_role not in ('owner', 'admin', 'member') then
    raise exception '役割の名前が正しくありません' using errcode = '22023';
  end if;

  v_actor := public.member_role(p_organization_id);
  if v_actor is null then
    raise exception 'この組織のメンバーではありません' using errcode = 'ST001';
  end if;
  if v_actor = 'member' then
    raise exception '役割を変えられるのは、オーナーと管理者だけです' using errcode = 'ST001';
  end if;

  -- 同じ組織へのお申し付けを 1 つずつ通します（オーナーの数を正しく数えるためです）
  perform pg_advisory_xact_lock(
    hashtext('saas_starter:memberships'),
    hashtext(p_organization_id::text)
  );

  select m.role into v_target
  from public.memberships m
  where m.organization_id = p_organization_id and m.user_id = p_user_id;

  if v_target is null then
    return 'not_found';
  end if;

  -- 管理者は、オーナーの行に触れません。オーナーに上げることもできません
  if v_actor = 'admin' and (v_target = 'owner' or p_role = 'owner') then
    raise exception 'オーナーに関わる変更は、オーナーだけが行えます' using errcode = 'ST002';
  end if;

  if v_target = 'owner' and p_role <> 'owner' then
    select count(*) into v_owners
    from public.memberships m
    where m.organization_id = p_organization_id and m.role = 'owner';

    if v_owners <= 1 then
      return 'last_owner';
    end if;
  end if;

  update public.memberships
  set role = p_role
  where organization_id = p_organization_id and user_id = p_user_id;

  return 'ok';
end;
$$;

comment on function public.change_member_role(uuid, uuid, text) is
  '役割を変えます。最後のオーナーは降ろせません（last_owner）';

-- メンバーを外します（ご自身の退会も同じ関数です）。
-- 戻り値: 'ok' | 'last_owner' | 'not_found'
create or replace function public.remove_member_guarded(
  p_organization_id uuid,
  p_user_id uuid
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor text;
  v_target text;
  v_owners integer;
  v_self boolean;
begin
  if auth.uid() is null then
    raise exception 'ログインが必要です' using errcode = 'ST001';
  end if;

  v_self := (p_user_id = auth.uid());
  v_actor := public.member_role(p_organization_id);
  if v_actor is null then
    raise exception 'この組織のメンバーではありません' using errcode = 'ST001';
  end if;
  if not v_self and v_actor = 'member' then
    raise exception 'メンバーを外せるのは、オーナーと管理者だけです' using errcode = 'ST001';
  end if;

  perform pg_advisory_xact_lock(
    hashtext('saas_starter:memberships'),
    hashtext(p_organization_id::text)
  );

  select m.role into v_target
  from public.memberships m
  where m.organization_id = p_organization_id and m.user_id = p_user_id;

  if v_target is null then
    return 'not_found';
  end if;

  if not v_self and v_actor = 'admin' and v_target = 'owner' then
    raise exception 'オーナーを外せるのは、オーナーだけです' using errcode = 'ST002';
  end if;

  if v_target = 'owner' then
    select count(*) into v_owners
    from public.memberships m
    where m.organization_id = p_organization_id and m.role = 'owner';

    if v_owners <= 1 then
      return 'last_owner';
    end if;
  end if;

  delete from public.memberships
  where organization_id = p_organization_id and user_id = p_user_id;

  return 'ok';
end;
$$;

comment on function public.remove_member_guarded(uuid, uuid) is
  'メンバーを外します。最後のオーナーは外せません（last_owner）';

-- ご招待をハッシュで探します。生のトークンをお持ちの方だけがたどり着けます。
-- まだ組織の外にいらっしゃる方が使うため、行の出入りの決まりを通さずに読みます。
-- トークンのハッシュそのものは返しません。
create or replace function public.find_invitation_by_hash(p_token_hash text)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_row jsonb;
begin
  if auth.uid() is null then
    raise exception 'ログインが必要です' using errcode = 'ST001';
  end if;

  select to_jsonb(i) - 'token_hash' into v_row
  from public.invitations i
  where i.token_hash = p_token_hash;

  return v_row;
end;
$$;

comment on function public.find_invitation_by_hash(text) is
  'ご招待をトークンのハッシュで探します。ハッシュそのものは返しません';

-- ご招待をお受けいただきます。
-- 「招待を accepted にする」と「メンバーに加える」を 1 回で行います。
-- 戻り値: 'ok' | 'already_member' | 'not_pending'
-- お受けになれないときは、理由を分けずに not_pending をお返しします
-- （無いご招待・期限切れ・すでにお受けのもの・宛先が違うもの、すべて同じです）。
create or replace function public.accept_invitation(
  p_invitation_id uuid,
  p_user_id uuid,
  p_role text
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_org uuid;
  v_role text;
  v_status text;
  v_expires timestamptz;
  v_invite_email text;
  v_user_email text;
  v_inserted integer;
begin
  if auth.uid() is null then
    raise exception 'ログインが必要です' using errcode = 'ST001';
  end if;
  if p_user_id is distinct from auth.uid() then
    raise exception 'ほかの方の代わりにお受けになることはできません' using errcode = 'ST001';
  end if;

  -- 同じご招待への 2 回目は、ここで待ってから status を読み直します
  select i.organization_id, i.role, i.status, i.expires_at, lower(i.email)
  into v_org, v_role, v_status, v_expires, v_invite_email
  from public.invitations i
  where i.id = p_invitation_id
  for update;

  if v_org is null or v_status <> 'pending' or v_expires <= now() then
    return 'not_pending';
  end if;

  -- お招きしたメールアドレスの方だけがお受けになれます。
  -- 宛先が違うときと役割が合わないときは、無いご招待と同じお返事にします
  -- （id を当てずっぽうに試しても、ご招待があること自体が分からないようにするためです）。
  select lower(u.email) into v_user_email from auth.users u where u.id = p_user_id;
  if v_user_email is null or v_user_email is distinct from v_invite_email then
    return 'not_pending';
  end if;
  if p_role is distinct from v_role then
    return 'not_pending';
  end if;

  update public.invitations
  set status = 'accepted', accepted_by = p_user_id
  where id = p_invitation_id;

  -- すでにご一緒いただいている方の役割は、上書きしません
  insert into public.memberships (organization_id, user_id, role)
  values (v_org, p_user_id, v_role)
  on conflict (organization_id, user_id) do nothing;

  get diagnostics v_inserted = row_count;
  if v_inserted = 0 then
    return 'already_member';
  end if;

  return 'ok';
end;
$$;

comment on function public.accept_invitation(uuid, uuid, text) is
  'ご招待をお受けいただきます。招待を accepted にし、メンバーに加えるところまでを 1 回で行います';

-- 決済の通知を、ご契約の表へ写します。
--
-- 通知は順不同で、しかも**同時に**届きます。読んでから書くまでを 2 回に分けると、
-- そのあいだに別の通知がもっと新しい状態を書いていても気づけず、
-- 古い状態で上書きしてしまいます（ご解約のあとに past_due が入ると、
-- そのままずっと有料のプランの上限でお使いいただけてしまいます）。
-- 読むところと書くところを、この関数 1 つ（＝ 1 つの取引）の中に入れます。
--
-- p_row が null のときはご解約です。あとからお調べになれるよう、
-- 決済の契約の番号と期間の終わりはそのまま残し、プランを free、状態を canceled にします。
-- p_now は、その通知を受け取った時刻です（ご解約は取り直した行がないため、この時刻で比べます）。
--
-- 戻り値: 実際にお書きしたときだけ true（古い通知を捨てたときは false）
create or replace function public.apply_subscription_change(
  p_organization_id uuid,
  p_row jsonb,
  p_now timestamptz
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_existing public.subscriptions;
  v_found boolean;
  v_stamp timestamptz;
begin
  -- 同じ組織への同時のお申し付けを 1 つずつ通します。
  -- for update は、すでにある行にしか効きません。はじめの 1 通が 2 つ同時に届くと
  -- どちらも「行が無い」を見てしまうので、行の有無によらない錠で先に押さえます。
  perform pg_advisory_xact_lock(
    hashtext('saas_starter:subscription'),
    hashtext(p_organization_id::text)
  );

  select * into v_existing
  from public.subscriptions s
  where s.organization_id = p_organization_id
  for update;
  v_found := found;

  -- 届いた状態の時刻です（取り直した時刻。ご解約は受け取った時刻）
  v_stamp := case
    when p_row is null then p_now
    else (p_row ->> 'updated_at')::timestamptz
  end;

  -- 時刻の無い行は、新しいか古いかを判じられませんので、書かずに捨てます
  -- （例外にすると、決済の通知の受け口が 500 を返し続け、送り直しが収束しません）
  if v_stamp is null then
    return false;
  end if;

  -- いま入っている行より前の状態は、書かずに捨てます
  -- （同じ時刻のものは、あとから届いたほうで書き直します）
  if v_found and v_stamp < v_existing.updated_at then
    return false;
  end if;

  if p_row is null then
    -- 一度もご契約のない組織には、ご解約の行を作りません
    -- （お申し込みいただいたことのない方の画面に、帯が出てしまうためです）
    if not v_found then
      return false;
    end if;

    update public.subscriptions s
       set plan_id = 'free',
           status = 'canceled',
           cancel_at_period_end = false,
           updated_at = p_now
     where s.organization_id = p_organization_id;

    return true;
  end if;

  -- 組織の ID は、呼ぶ側が stripe_customers から引き直したものだけを使います
  -- （p_row の中身に別の組織の id が紛れていても、そちらには書きません）。
  insert into public.subscriptions (
    organization_id, plan_id, status, stripe_subscription_id,
    current_period_end, cancel_at_period_end, updated_at
  )
  values (
    p_organization_id,
    p_row ->> 'plan_id',
    p_row ->> 'status',
    p_row ->> 'stripe_subscription_id',
    (p_row ->> 'current_period_end')::timestamptz,
    coalesce((p_row ->> 'cancel_at_period_end')::boolean, false),
    (p_row ->> 'updated_at')::timestamptz
  )
  on conflict (organization_id) do update
     set plan_id = excluded.plan_id,
         status = excluded.status,
         stripe_subscription_id = excluded.stripe_subscription_id,
         current_period_end = excluded.current_period_end,
         cancel_at_period_end = excluded.cancel_at_period_end,
         updated_at = excluded.updated_at;

  return true;
end;
$$;

comment on function public.apply_subscription_change(uuid, jsonb, timestamptz) is
  '決済の通知をご契約の表へ写します。届いた状態が表より前のときは、書かずに false を返します';

-- ===========================================================================
-- 呼べる方を絞ります。
--
-- この土台では、新しい関数に anon と authenticated の両方が自動で付きます。
-- そのままにすると、ログインしていない方からも呼べてしまうので、
-- 1 つずつ取り上げてから、ログイン中の方にだけお渡しします。
-- 引き金の関数は、どなたからも直には呼べないようにします。
-- ===========================================================================

revoke all on function public.is_member(uuid) from public, anon;
revoke all on function public.member_role(uuid) from public, anon;
revoke all on function public.shares_organization(uuid) from public, anon;
revoke all on function public.create_organization_guarded(text, integer) from public, anon;
revoke all on function public.create_project_guarded(uuid, text, text, uuid, integer) from public, anon;
revoke all on function public.change_member_role(uuid, uuid, text) from public, anon;
revoke all on function public.remove_member_guarded(uuid, uuid) from public, anon;
revoke all on function public.find_invitation_by_hash(text) from public, anon;
revoke all on function public.accept_invitation(uuid, uuid, text) from public, anon;

grant execute on function public.is_member(uuid) to authenticated;
grant execute on function public.member_role(uuid) to authenticated;
grant execute on function public.shares_organization(uuid) to authenticated;
grant execute on function public.create_organization_guarded(text, integer) to authenticated;
grant execute on function public.create_project_guarded(uuid, text, text, uuid, integer) to authenticated;
grant execute on function public.change_member_role(uuid, uuid, text) to authenticated;
grant execute on function public.remove_member_guarded(uuid, uuid) to authenticated;
grant execute on function public.find_invitation_by_hash(text) to authenticated;
grant execute on function public.accept_invitation(uuid, uuid, text) to authenticated;

-- 決済の通知の関数は、画面の側からは呼べません（service role だけです）。
-- ここを開けると、ログイン中のどなたでもご契約の行を書き換えられてしまいます。
revoke all on function public.apply_subscription_change(uuid, jsonb, timestamptz)
  from public, anon, authenticated;
grant execute on function public.apply_subscription_change(uuid, jsonb, timestamptz)
  to service_role;

revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.profiles_before_update() from public, anon, authenticated;
revoke all on function public.invitations_before_update() from public, anon, authenticated;
revoke all on function public.projects_before_update() from public, anon, authenticated;
revoke all on function public.memberships_guard() from public, anon, authenticated;
revoke all on function public.organizations_guard_delete() from public, anon, authenticated;
