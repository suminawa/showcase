-- 行の出入りの決まり（RLS）です。
--
-- 8 つの表すべてで有効にし、表の持ち主にも同じ決まりを当てます（force）。
-- service role はこの決まりを素通りするので、ここに書くのはログイン中の方
-- （authenticated）のための決まりだけです。ログインしていない方（anon）に当たる
-- 決まりは 1 つも書きません＝何も読めません。
--
-- 役割ごとの可否は src/core/permissions.ts の表が正で、ここはその写しです。
--   プロジェクトを見る・作る・直す … owner ○ / admin ○ / member ○
--   プロジェクトを消す           … owner ○ / admin ○ / member 自分が作ったものだけ
--   メンバーの招待・削除・役割    … owner ○ / admin ○（オーナーには触れない）/ member ×
--   組織の名前を変える           … owner ○ / admin ○ / member ×
--   組織を消す                   … owner ○ / admin × / member ×
--
-- オーナーの行を作る・オーナーに上げるのは、表を直に書く道では行えません。
-- 20260920000200_functions.sql の関数だけが行えます（オーナーが 0 人になる形を防ぐためです）。

alter table public.plan_limits       enable row level security;
alter table public.profiles          enable row level security;
alter table public.organizations     enable row level security;
alter table public.memberships       enable row level security;
alter table public.invitations       enable row level security;
alter table public.projects          enable row level security;
alter table public.subscriptions     enable row level security;
alter table public.stripe_customers  enable row level security;
alter table public.stripe_events     enable row level security;

alter table public.plan_limits       force row level security;
alter table public.profiles          force row level security;
alter table public.organizations     force row level security;
alter table public.memberships       force row level security;
alter table public.invitations       force row level security;
alter table public.projects          force row level security;
alter table public.subscriptions     force row level security;
alter table public.stripe_customers  force row level security;
alter table public.stripe_events     force row level security;

-- ---------------------------------------------------------------------------
-- plan_limits: ログイン中の方は読めます。書けるのは service role だけです
-- （料金表のご案内に使うだけで、上限の判定はこの表を関数の中で引き直します）
-- ---------------------------------------------------------------------------
create policy plan_limits_select on public.plan_limits
  for select to authenticated
  using (true);

-- ---------------------------------------------------------------------------
-- profiles: ご自身の行と、同じ組織にご一緒の方の行が見えます。消せません
-- ---------------------------------------------------------------------------
create policy profiles_select on public.profiles
  for select to authenticated
  using (id = (select auth.uid()) or public.shares_organization(id));

create policy profiles_insert on public.profiles
  for insert to authenticated
  with check (id = (select auth.uid()));

create policy profiles_update on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- ---------------------------------------------------------------------------
-- organizations: 一員の方だけに見えます。作るのは create_organization_guarded だけです
-- ---------------------------------------------------------------------------
create policy organizations_select on public.organizations
  for select to authenticated
  using (public.is_member(id));

create policy organizations_update on public.organizations
  for update to authenticated
  using (public.member_role(id) in ('owner', 'admin'))
  with check (public.member_role(id) in ('owner', 'admin'));

create policy organizations_delete on public.organizations
  for delete to authenticated
  using (public.member_role(id) = 'owner');

-- ---------------------------------------------------------------------------
-- memberships: 同じ組織の方の行が見えます。
-- 書けるのはオーナーと管理者で、管理者はオーナーの行に触れません。
-- どの道でも「オーナーに上げる」ことはできません（関数だけが行えます）
-- ---------------------------------------------------------------------------
create policy memberships_select on public.memberships
  for select to authenticated
  using (public.is_member(organization_id));

-- メンバーの行を増やす決まりは置きません。
-- 増やせるのは accept_invitation（ご招待をお受けになったとき）と
-- create_organization_guarded（組織をお作りになった方をオーナーにするとき）だけです。
-- 表を直に書く道を開けておくと、オーナーと管理者が、ご招待を通さずに
-- 任意の方を組織へ入れられてしまうためです。
-- 見本のデータづくりは service role で行ってください。

create policy memberships_update on public.memberships
  for update to authenticated
  using (
    public.member_role(organization_id) = 'owner'
    or (public.member_role(organization_id) = 'admin' and role <> 'owner')
  )
  with check (
    public.member_role(organization_id) in ('owner', 'admin')
    and role <> 'owner'
  );

create policy memberships_delete on public.memberships
  for delete to authenticated
  using (
    user_id = (select auth.uid())
    or public.member_role(organization_id) = 'owner'
    or (public.member_role(organization_id) = 'admin' and role <> 'owner')
  );

-- ---------------------------------------------------------------------------
-- invitations: オーナーと管理者だけに見えます。
-- 管理者は、オーナーとしてのご招待には触れません
-- ---------------------------------------------------------------------------
create policy invitations_select on public.invitations
  for select to authenticated
  using (public.member_role(organization_id) in ('owner', 'admin'));

create policy invitations_insert on public.invitations
  for insert to authenticated
  with check (
    public.member_role(organization_id) = 'owner'
    or (public.member_role(organization_id) = 'admin' and role <> 'owner')
  );

create policy invitations_update on public.invitations
  for update to authenticated
  using (
    public.member_role(organization_id) = 'owner'
    or (public.member_role(organization_id) = 'admin' and role <> 'owner')
  )
  with check (
    public.member_role(organization_id) = 'owner'
    or (public.member_role(organization_id) = 'admin' and role <> 'owner')
  );

create policy invitations_delete on public.invitations
  for delete to authenticated
  using (
    public.member_role(organization_id) = 'owner'
    or (public.member_role(organization_id) = 'admin' and role <> 'owner')
  );

-- ---------------------------------------------------------------------------
-- projects: 一員の方は見る・作る・直すができます。
-- 消せるのは、オーナー・管理者と、ご自身がお作りになった行だけです
-- ---------------------------------------------------------------------------
create policy projects_select on public.projects
  for select to authenticated
  using (public.is_member(organization_id));

create policy projects_insert on public.projects
  for insert to authenticated
  with check (
    public.is_member(organization_id)
    and created_by = (select auth.uid())
  );

create policy projects_update on public.projects
  for update to authenticated
  using (public.is_member(organization_id))
  with check (public.is_member(organization_id));

create policy projects_delete on public.projects
  for delete to authenticated
  using (
    public.member_role(organization_id) in ('owner', 'admin')
    or created_by = (select auth.uid())
  );

-- ---------------------------------------------------------------------------
-- subscriptions: 一員の方は見るだけです。書けるのは service role だけです
-- ---------------------------------------------------------------------------
create policy subscriptions_select on public.subscriptions
  for select to authenticated
  using (public.is_member(organization_id));

-- ---------------------------------------------------------------------------
-- stripe_customers と stripe_events: 決まりを 1 つも置きません。
-- ログイン中の方からは、見ることも書くこともできません（service role だけです）
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- 表そのものへの許し（行の出入りの決まりとは別の、もう 1 枚の守りです）
--
-- この土台では、新しく作った表に anon と authenticated が自動で all を持ちます。
-- 上の決まりで止まってはいますが、お金に関わる表だけは、いったん取り上げてから
-- 要るものだけをお渡しします。決まりを 1 行書き落としたときに、
-- そのまま見えてしまうことを防ぐためです。
-- ---------------------------------------------------------------------------
revoke all on table public.plan_limits from anon, authenticated;
revoke all on table public.subscriptions from anon, authenticated;
revoke all on table public.stripe_customers from anon, authenticated;
revoke all on table public.stripe_events from anon, authenticated;

grant select on table public.plan_limits to authenticated;

-- ご契約のうち、画面に要るのはプランと状態と期間だけです。
-- 決済の契約の番号（stripe_subscription_id）は、一員の方にもお見せしません
-- （お使いになるのは service role の側だけです）。
-- そのため、この表を * で読むことはできません。列の名前を並べてお読みください。
grant select (
  organization_id,
  plan_id,
  status,
  current_period_end,
  cancel_at_period_end,
  updated_at
) on table public.subscriptions to authenticated;
