-- 表の土台です。この 9 つ以外の表は作りません
-- （お客さまの行が入る 8 つと、プランの上限を置く 1 つです）。
-- 列の名前は snake_case で、画面の側（TypeScript）は camelCase に写します。
-- 行の出入りの決まり（誰が何をできるか）は 20260920000300_rls.sql にあります。

-- ---------------------------------------------------------------------------
-- profiles: ログインした方の表示用の情報です。auth.users と 1 対 1 で対になります
-- ---------------------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  name text not null default '' check (char_length(name) <= 80),
  lang text not null default 'ja' check (lang in ('ja', 'en')),
  created_at timestamptz not null default now()
);

comment on table public.profiles is 'ログインした方の表示用の情報。auth.users と対になります';

-- ---------------------------------------------------------------------------
-- organizations と memberships: 組織と、そこにいらっしゃる方の役割です
-- ---------------------------------------------------------------------------
create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  created_at timestamptz not null default now()
);

comment on table public.organizations is '組織。すべての行はこの組織を通してだけ見えます';

create table public.memberships (
  organization_id uuid not null references public.organizations (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  role text not null check (role in ('owner', 'admin', 'member')),
  created_at timestamptz not null default now(),
  -- 同じ方が同じ組織に二重に入ることはありません（同時にお申し込みが届いても 1 行です）
  primary key (organization_id, user_id)
);

comment on table public.memberships is 'どなたがどの組織で、どの役割かの表。この表が見え方の出どころです';

-- ---------------------------------------------------------------------------
-- invitations: 組織へのご招待です。表に置くのはトークンのハッシュだけです
-- ---------------------------------------------------------------------------
create table public.invitations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations (id) on delete cascade,
  email text not null,
  role text not null check (role in ('owner', 'admin', 'member')),
  token_hash text not null unique,
  expires_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'revoked')),
  invited_by uuid references public.profiles (id) on delete set null,
  accepted_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now()
);

comment on table public.invitations is 'ご招待。生のトークンは保存せず、SHA-256 のハッシュだけを置きます';

-- ---------------------------------------------------------------------------
-- projects: この土台の見本の資源です。お客さまの題材に置き換えてお使いください
-- ---------------------------------------------------------------------------
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  note text not null default '' check (char_length(note) <= 2000),
  -- お作りになった方が退会されると、この欄は空になります（行は残ります）。
  -- 「ご自身がお作りになったものだけ消せる」は、空のときは当てはまりません。
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public.projects is '組織ごとのプロジェクト。お客さまの題材に置き換えてお使いください';

-- ---------------------------------------------------------------------------
-- plan_limits: プランごとの上限です。
-- データベースの中で上限を引き直すときに、この表を見ます
-- （呼び出しの引数で渡された上限は、この表より緩くはできません）。
-- プランを変えるときは、plans.config.ts とこの表の 2 か所をそろえてください。
-- そろっているかどうかは test/plan-limits.test.ts が確かめます。
-- ---------------------------------------------------------------------------
create table public.plan_limits (
  plan_id text primary key,
  -- null は「上限なし」です（画面の側の -1 は、ここでは null になります）
  project_limit integer check (project_limit is null or project_limit >= 0)
);

comment on table public.plan_limits is
  'プランごとの上限。project_limit が null のプランは上限なしです';

insert into public.plan_limits (plan_id, project_limit) values
  ('free', 3),
  ('standard', 50),
  ('business', null);

-- ---------------------------------------------------------------------------
-- 課金の 3 つ: 書けるのは service role だけです（画面からは書けません）
-- ---------------------------------------------------------------------------
create table public.subscriptions (
  -- ご契約は組織ごとに 1 行です
  organization_id uuid primary key references public.organizations (id) on delete cascade,
  plan_id text not null check (plan_id in ('free', 'standard', 'business')),
  -- 決済のしくみの 8 つの状態だけを受け付けます
  -- （src/core/billing-state.ts の StripeStatus と同じ顔ぶれです）。
  -- 知らない値が手で入ると、画面の側が行を読めずに /app が 500 になります。
  status text not null check (
    status in (
      'active', 'trialing', 'past_due', 'canceled',
      'unpaid', 'incomplete', 'incomplete_expired', 'paused'
    )
  ),
  stripe_subscription_id text unique,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  -- 通知が順不同で届いたときに並べ直すための時刻です。自動では動かしません
  updated_at timestamptz not null default now()
);

comment on table public.subscriptions is '組織ごとのご契約。書けるのは service role だけです';
comment on column public.subscriptions.updated_at is
  '決済の口から状態を取り直した時刻。順不同の通知を並べ直すのに使うため、自動では更新しません';

create table public.stripe_customers (
  organization_id uuid primary key references public.organizations (id) on delete cascade,
  stripe_customer_id text not null unique,
  created_at timestamptz not null default now()
);

comment on table public.stripe_customers is '組織と決済のお客さま番号の対。画面からは見えません';

create table public.stripe_events (
  id text primary key,
  type text not null,
  received_at timestamptz not null default now()
);

comment on table public.stripe_events is '処理し終えた通知の id。二重処理を止めるために使います';

-- ---------------------------------------------------------------------------
-- 索引
-- invitations(token_hash)・subscriptions(stripe_subscription_id)・
-- stripe_customers(stripe_customer_id) は unique 制約が索引を兼ねるため、
-- ここでは作り直しません。
-- ---------------------------------------------------------------------------
create index memberships_user_id_idx on public.memberships (user_id);
create index projects_organization_id_created_at_idx
  on public.projects (organization_id, created_at desc);
create index invitations_organization_id_status_idx
  on public.invitations (organization_id, status);
