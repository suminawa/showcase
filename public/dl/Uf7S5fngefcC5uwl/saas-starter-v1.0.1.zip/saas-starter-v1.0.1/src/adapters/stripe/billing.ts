import "server-only";

/**
 * 本物の Stripe を相手にする、課金の口です。
 *
 * 画面と flow は、この中を知りません（ports の形だけを見ます）。
 * Stripe のつなぎ役・stripe_customers の読み書き・秘密・Price の対応は、
 * すべて引数でお預かりします。環境変数はここでは読みません
 * （読むのは合成の場所、src/server/ports.ts だけです）。
 */
import type Stripe from "stripe";
import type { PlanId } from "../../core/plans";
import { billingErrorText, type BillingPort, type WebhookResult } from "../../ports/billing";
import type { StripeCustomer } from "../../ports/data";
import { readStripeWebhook, type StripeWebhookApi } from "./webhook";

/** この口が Stripe にお願いすることの、すべてです（検査では作りものを差し込みます） */
export type StripeBillingApi = StripeWebhookApi & {
  customers: {
    create(
      params: Stripe.CustomerCreateParams,
      options?: Stripe.RequestOptions,
    ): Promise<Stripe.Customer>;
  };
  checkout: {
    sessions: {
      create(
        params: Stripe.Checkout.SessionCreateParams,
        options?: Stripe.RequestOptions,
      ): Promise<Stripe.Checkout.Session>;
    };
  };
  billingPortal: {
    sessions: {
      create(
        params: Stripe.BillingPortal.SessionCreateParams,
        options?: Stripe.RequestOptions,
      ): Promise<Stripe.BillingPortal.Session>;
    };
  };
};

/** stripe_customers の表の、読み書きのところだけです（DataPort の一部です） */
export type StripeCustomerStore = {
  getStripeCustomer(organizationId: string): Promise<StripeCustomer | null>;
  setStripeCustomer(organizationId: string, stripeCustomerId: string): Promise<void>;
};

export type StripeBillingDeps = {
  stripe: StripeBillingApi;
  customers: StripeCustomerStore;
  /** STRIPE_WEBHOOK_SECRET です。無いあいだは、通知を 1 通もお受けしません */
  webhookSecret: string | null;
  /** プラン → Stripe の Price の id（環境変数から作ります） */
  priceIdOf: (planId: PlanId) => string | null;
  /** Stripe の Price の id → プラン */
  planIdOf: (priceId: string) => PlanId | null;
  /**
   * いまの時刻です（既定はいまの時刻）。
   * 状態を取り直した時刻と、お申し込みの鍵の区切りに使います。
   */
  now?: () => Date;
};

type CheckoutInput = Parameters<BillingPort["createCheckoutUrl"]>[0];
type CheckoutResult = Awaited<ReturnType<BillingPort["createCheckoutUrl"]>>;
type PortalInput = Parameters<BillingPort["createPortalUrl"]>[0];
type PortalResult = Awaited<ReturnType<BillingPort["createPortalUrl"]>>;

/**
 * Stripe の言葉づかいです。
 * 日本語のときだけ日本語にし、それ以外はブラウザのご希望に合わせて Stripe にお任せします。
 */
function localeOf(lang: "ja" | "en"): "ja" | "auto" {
  return lang === "ja" ? "ja" : "auto";
}

/** お申し込みの鍵を区切る幅です（10 分） */
const CHECKOUT_KEY_WINDOW_MS = 600_000;

/**
 * お申し込みの画面をお作りするときの、冪等性キーです。
 *
 * 連打や二重の送信で 2 本立つと、二重にご請求してしまいます。
 * この鍵を添えておけば、Stripe が 1 回目のお申し込みをそのままお返しになります。
 *
 * 鍵に入れるのは、**その呼び出しの引数を決めるものすべて**です
 * （組織・プラン・言葉づかい）。同じ鍵に違う引数を添えると
 * Stripe が idempotency_error でお断りになるため、言葉づかいのお好みが違う方が
 * 続けてお申し込みになったときに、2 人目がお申し込みになれなくなります。
 *
 * 末尾は 10 分ごとの区切りです。Stripe の冪等性キーは 24 時間効くため、
 * これが無いと、ご解約の直後に同じプランへお申し込み直されたときに、
 * もう終わった画面がそのまま返ってしまいます。
 * 同じ区切りの中の連打は 1 本にまとまり、10 分たてば新しい画面をお出しします。
 *
 * 2 つの窓から別々にお支払いまで進まれる形は、Stripe の側では止められません
 * （README に、二重に立ったときのお手当てをご案内しています）。
 */
function checkoutKey(input: CheckoutInput, now: Date): string {
  const window = Math.floor(now.getTime() / CHECKOUT_KEY_WINDOW_MS);
  return `saas-starter:checkout:${input.organizationId}:${input.planId}:${input.lang}:${window}`;
}

/**
 * 誤りの中身（鍵・スタック）は、お返事にも符号にも混ぜません。
 * 記録に残すのも、Stripe の誤りの種類と符号だけです
 * （Stripe の文には、メールアドレスや id がそのまま入ることがあります）。
 */
function unavailable(where: string, error: unknown): { ok: false; code: "unavailable" } {
  console.error(`決済: ${where}をご用意できませんでした（${billingErrorText(error)}）`);
  return { ok: false, code: "unavailable" };
}

export function createStripeBilling(deps: StripeBillingDeps): BillingPort {
  /**
   * その組織の Stripe のお客さまの id です。
   * 表にあれば使い回し、無ければ作って表に控えます。
   *
   * 同じときに 2 回お申し込みになると、どちらも「表に無い」と見てから作りにいきます。
   * そこで**組織ごとに決まる冪等性キー**を付けて、Stripe 側で 1 人にまとめています
   * （鍵が同じお申し付けには、Stripe が同じお客さまをお返しします）。
   *
   * **引数も組織ごとに決まる値だけ**にしています。
   * 同じ鍵に違う引数を添えると Stripe が idempotency_error でお断りになるので、
   * 押した方で変わる値（メールアドレスなど）を入れると、
   * オーナーが 2 人いらっしゃる組織で 2 人目がお申し込みになれません。
   * メールアドレスは、お支払いの画面がその場でお伺いして控えてくださいます。
   */
  async function customerIdFor(organizationId: string, organizationName: string): Promise<string> {
    const existing = await deps.customers.getStripeCustomer(organizationId);
    if (existing !== null) return existing.stripeCustomerId;

    const customer = await deps.stripe.customers.create(
      { name: organizationName, metadata: { organization_id: organizationId } },
      { idempotencyKey: `saas-starter:customer:${organizationId}` },
    );

    await deps.customers.setStripeCustomer(organizationId, customer.id);
    return customer.id;
  }

  return {
    async createCheckoutUrl(input: CheckoutInput): Promise<CheckoutResult> {
      // 無料のプランや、Price をまだ入れていないプランには進めません
      const priceId = deps.priceIdOf(input.planId);
      if (priceId === null) return { ok: false, code: "not_configured" };

      try {
        const customer = await customerIdFor(input.organizationId, input.organizationName);

        const session = await deps.stripe.checkout.sessions.create(
          {
            mode: "subscription",
            line_items: [{ price: priceId, quantity: 1 }],
            // 戻り先は、お預かりした値をそのままお渡しします
            // （お申し付けのヘッダからは組み立てません）。
            success_url: input.successUrl,
            cancel_url: input.cancelUrl,
            customer,
            client_reference_id: input.organizationId,
            locale: localeOf(input.lang),
            allow_promotion_codes: true,
            subscription_data: { metadata: { organization_id: input.organizationId } },
            metadata: { organization_id: input.organizationId },
          },
          { idempotencyKey: checkoutKey(input, (deps.now ?? (() => new Date()))()) },
        );

        // Stripe が行き先をお返しにならないことがあります
        if (typeof session.url !== "string" || session.url === "") {
          return { ok: false, code: "unavailable" };
        }
        return { ok: true, url: session.url };
      } catch (error) {
        return unavailable("お申し込みの画面", error);
      }
    },

    async createPortalUrl(input: PortalInput): Promise<PortalResult> {
      try {
        // まだ一度もお支払いに進んでいない組織には、お手続きの画面がありません
        const existing = await deps.customers.getStripeCustomer(input.organizationId);
        if (existing === null) return { ok: false, code: "no_customer" };

        const session = await deps.stripe.billingPortal.sessions.create({
          customer: existing.stripeCustomerId,
          return_url: input.returnUrl,
          locale: localeOf(input.lang),
        });

        if (typeof session.url !== "string" || session.url === "") {
          return { ok: false, code: "unavailable" };
        }
        return { ok: true, url: session.url };
      } catch (error) {
        return unavailable("お手続きの画面", error);
      }
    },

    async readWebhook(input: { payload: string; signature: string | null }): Promise<WebhookResult> {
      // 秘密をまだ頂戴していないあいだは、署名を確かめられません。
      // 「お受けしました」にも「署名が違います」にもせず、止めます
      // （読み取りの入口が、同じ形で止めます）。
      return readStripeWebhook({
        stripe: deps.stripe,
        secret: deps.webhookSecret ?? "",
        payload: input.payload,
        signature: input.signature,
        planIdOf: deps.planIdOf,
        now: deps.now,
      });
    },
  };
}
