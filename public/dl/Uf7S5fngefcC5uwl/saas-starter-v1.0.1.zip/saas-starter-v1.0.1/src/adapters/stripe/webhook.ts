import "server-only";

/**
 * 決済の通知（Webhook）の読み取りです。
 *
 * ここでしていることは 3 つだけです。
 *   ① 本文の大きさを確かめる（署名を確かめる前に打ち切ります）
 *   ② 署名を確かめる（通らなければ、本文を JSON として一切信用しません）
 *   ③ **Stripe から状態を取り直して**、表に書く形に写す
 *
 * ③ が要になります。通知は順不同で届き、遅れて届くこともあるため、
 * 通知の中身の status をそのまま信じると、古い状態で今の状態を上書きしてしまいます。
 * 取り直した時刻を row.updatedAt に入れておくと、受け取った側（flow）が
 * 「これは今より前の状態か」を見て、古いものを書かずに済みます。
 *
 * 通信をするのは Stripe のつなぎ役だけで、そのつなぎ役は引数で受け取ります
 * （検査では、型の合う作りものを差し込みます）。
 */
import type Stripe from "stripe";
import {
  isLiveSubscription,
  isStripeStatus,
  type SubscriptionRow,
} from "../../core/billing-state";
import { PLAN_IDS, type PlanId } from "../../core/plans";
import {
  WEBHOOK_MAX_BYTES,
  type SubscriptionChange,
  type WebhookResult,
} from "../../ports/billing";

/**
 * この読み取りが Stripe にお願いすることの、すべてです。
 * まるごとの Stripe ではなくこの形で受け取ると、検査で作りものを差し込めます
 * （本物の Stripe のつなぎ役は、そのままこの形に当てはまります）。
 */
export type StripeWebhookApi = {
  webhooks: Pick<Stripe["webhooks"], "constructEventAsync">;
  subscriptions: { retrieve(id: string): Promise<Stripe.Subscription> };
};

export type ReadStripeWebhookInput = {
  stripe: StripeWebhookApi;
  /** STRIPE_WEBHOOK_SECRET です */
  secret: string;
  /** 本文。**JSON に直す前の、そのままの文字**でいただきます */
  payload: string;
  signature: string | null;
  planIdOf: (priceId: string) => PlanId | null;
  /** 状態を取り直した時刻を作ります（既定はいまの時刻。検査では固定します） */
  now?: () => Date;
};

/** 扱う通知はこの 5 つだけです。ほかは受け取るだけで何もしません */
export const HANDLED_EVENT_TYPES: readonly string[] = [
  "checkout.session.completed",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
  "invoice.payment_failed",
];

/**
 * Stripe のご契約を、subscriptions の表に書く行に写します。
 *
 * 写せないとき（ご契約に項目が無い・存じ上げない価格）は null をお返しします。
 * null は「**表を触らない**」という意味で、ご解約ではありません。
 *
 * retrievedAt は、この状態を Stripe から取り直した時刻です。
 * 順不同の通知を並べ直すのに使うので、通知が作られた時刻ではありません。
 */
export function subscriptionToRow(
  subscription: Stripe.Subscription,
  planIdOf: (priceId: string) => PlanId | null,
  retrievedAt: Date,
): Omit<SubscriptionRow, "organizationId"> | null {
  const items = subscription.items.data;
  if (items.length === 0) {
    // 項目が無いと、どのプランのご契約か決められません
    console.warn("決済の通知: 項目のないご契約でした（プランを決められません）");
    return null;
  }

  const matched = matchingItem(items, planIdOf);
  if (matched === null) {
    // 記録に出すのは価格の id だけです（お客さまの id や契約の id は出しません）
    const prices = items.map((entry) => priceIdOf(entry)).join(", ");
    console.warn(`決済の通知: 存じ上げない価格でした（price: ${prices}）`);
    return null;
  }

  const { item, planId } = matched;
  const status = subscription.status;
  if (!isStripeStatus(status)) {
    // 知らない状態のまま表に入れると、お使いいただけるかどうかが決まりません。
    // 静かに捨てずに止めます（Stripe が送り直し、そのあいだに気づけます）。
    throw new Error(`決済の通知: 存じ上げないご契約の状態でした（status: ${String(status)}）`);
  }

  const seconds = item.current_period_end;
  const currentPeriodEnd =
    typeof seconds === "number" && Number.isFinite(seconds)
      ? new Date(seconds * 1000).toISOString()
      : null;

  return {
    planId,
    status,
    stripeSubscriptionId: subscription.id,
    currentPeriodEnd,
    // 「期間の終わりでのご解約」は、Stripe の新しい版では cancel_at_period_end ではなく
    // cancel_at（終わる日時）に入って届きます（2026-08-26 の版で確認）。どちらでも予定ありと扱います
    cancelAtPeriodEnd:
      subscription.cancel_at_period_end === true ||
      (typeof subscription.cancel_at === "number" && subscription.cancel_at > 0),
    updatedAt: retrievedAt.toISOString(),
  };
}

/** 項目の価格の id です（展開されていないことがあります） */
function priceIdOf(item: Stripe.SubscriptionItem): string {
  return typeof item.price?.id === "string" ? item.price.id : "";
}

/**
 * ご契約の項目から、こちらのプランに当たるものを 1 つ選びます。
 *
 * ご契約には、ほかの商品（お席の追加など）の項目が並ぶことがあります。
 * 1 つ目とはかぎらないので、当たるものを探します。
 * 当たるものが 2 つ以上あるときは、**上のプラン**（plans.config.ts の並びで後ろ）を
 * 採ります。どちらの上限でお使いいただけるか決まらないままにするより、
 * お客さまに不利にならないほうへ寄せるためです。
 */
function matchingItem(
  items: readonly Stripe.SubscriptionItem[],
  planIdOf: (priceId: string) => PlanId | null,
): { item: Stripe.SubscriptionItem; planId: PlanId } | null {
  let found: { item: Stripe.SubscriptionItem; planId: PlanId; rank: number } | null = null;

  for (const item of items) {
    const priceId = priceIdOf(item);
    const planId = priceId === "" ? null : planIdOf(priceId);
    if (planId === null) continue;

    const rank = PLAN_IDS.indexOf(planId);
    if (found === null || rank > found.rank) found = { item, planId, rank };
  }

  return found === null ? null : { item: found.item, planId: found.planId };
}

/**
 * 決済の通知を 1 通読みます。
 *
 * お返しするのは「確かめ済みの変更」だけで、表に書くのは呼び出した側（flow）です。
 */
export async function readStripeWebhook(input: ReadStripeWebhookInput): Promise<WebhookResult> {
  // 秘密をまだ頂戴していないときは、確かめに進みません。
  // 「署名が違います（400）」でお返しすると、Stripe は送り直してくれないため、
  // 秘密を入れるまでのあいだの通知がすべて失われます。
  // ここで止めれば受け口が 5xx をお返しし、あとから入り直します。
  if (input.secret.trim() === "") {
    throw new Error("決済の通知: 署名の秘密（STRIPE_WEBHOOK_SECRET）が入っていません");
  }

  // 大きさは、署名を確かめるより先に見ます
  if (Buffer.byteLength(input.payload, "utf8") > WEBHOOK_MAX_BYTES) {
    return { ok: false, code: "too_large" };
  }
  if (input.signature === null || input.signature === "") {
    return { ok: false, code: "bad_signature" };
  }

  let event: Stripe.Event;
  try {
    // 署名が通るまで、本文を JSON として読みません（この中で読まれます）
    event = await input.stripe.webhooks.constructEventAsync(
      input.payload,
      input.signature,
      input.secret,
    );
  } catch {
    // 署名が違う・形が壊れている・時刻が古すぎる、のいずれかです
    return { ok: false, code: "bad_signature" };
  }

  return {
    ok: true,
    eventId: event.id,
    eventType: event.type,
    change: await changeFor(event, input),
  };
}

/** 通知の種類ごとに、表に書く変更を組み立てます */
async function changeFor(
  event: Stripe.Event,
  input: ReadStripeWebhookInput,
): Promise<SubscriptionChange | null> {
  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      // ご契約のお手続き以外（買い切り・お支払い方法のご登録）では、何もしません。
      // 同じ通知がこの 3 つの種類で届くため、種類そのものを確かめます。
      if (session.mode !== "subscription") return null;

      const subscriptionId = idOf(session.subscription);
      // まだご契約がひもづいていないお申し込みでも、何もしません
      if (subscriptionId === null) return null;
      return changeOf(input, idOf(session.customer), subscriptionId, false);
    }

    case "customer.subscription.created":
    case "customer.subscription.updated": {
      const subscription = event.data.object;
      return changeOf(input, idOf(subscription.customer), subscription.id, false);
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object;
      // ご解約の通知でも取り直します（お支払いが続いていれば、消しません）
      return changeOf(input, idOf(subscription.customer), subscription.id, true);
    }

    case "invoice.payment_failed": {
      const invoice = event.data.object;
      const subscriptionId = idOf(invoice.parent?.subscription_details?.subscription);
      if (subscriptionId === null) return null;
      return changeOf(input, idOf(invoice.customer), subscriptionId, false);
    }

    default:
      // 扱わない種類です。受け取るだけで何もしません
      return null;
  }
}

/**
 * Stripe から状態を取り直して、変更の形にします。
 *
 * canceling は「ご解約の通知だったかどうか」です。
 * ご解約の通知でも、取り直した結果お支払いが続いていれば消しません
 * （遅れて届いたご解約で、いま生きているご契約を消してしまわないためです）。
 */
async function changeOf(
  input: ReadStripeWebhookInput,
  stripeCustomerId: string | null,
  subscriptionId: string,
  canceling: boolean,
): Promise<SubscriptionChange | null> {
  // どなたのご契約か分からない通知は、書きようがありません
  if (stripeCustomerId === null) return null;

  const subscription = await retrieveSubscription(input.stripe, subscriptionId, canceling);

  // 取り直した時刻は、**取り直しが終わってから**採ります。
  // お問い合わせにお時間がかかることがあり、呼ぶ前に採ると、
  // いまの状態が実際より古い時刻で入ってしまいます
  // （順不同の並べ直しで、本当に新しい状態が「古い」と判じられかねません）。
  const retrievedAt = (input.now ?? (() => new Date()))();

  // Stripe にもうご契約が残っていません（無料のプランにお戻しします）
  if (subscription === null) return { stripeCustomerId, row: null };

  const live = isStripeStatus(subscription.status) && isLiveSubscription(subscription.status);
  if (canceling && !live) return { stripeCustomerId, row: null };

  const row = subscriptionToRow(subscription, input.planIdOf, retrievedAt);
  // 写せなかったときは「何もしない」です。**ご解約（row: null）にはしません**
  // （ほかの商品のご契約で、こちらのご契約を消してしまわないためです）。
  if (row === null) return null;

  return { stripeCustomerId, row };
}

/**
 * ご契約を取り直します。取り直せないときは投げます
 * （投げると受け口が 5xx をお返しし、Stripe が送り直してくれます）。
 *
 * null をお返しする（＝ ご解約に倒す）のは、**ご解約の通知で**、
 * なおかつ Stripe がはっきり「もうありません」と言ったときだけです。
 * ほかの通知の 404 は、一時のことで起こります（お作りになった直後・
 * 向け先の取り違えなど）。そこでご解約に倒すと、お支払い中の組織が
 * 黙って無料に落ちてしまいます。
 */
async function retrieveSubscription(
  stripe: StripeWebhookApi,
  subscriptionId: string,
  canceling: boolean,
): Promise<Stripe.Subscription | null> {
  try {
    return await stripe.subscriptions.retrieve(subscriptionId);
  } catch (error) {
    if (canceling && isMissing(error)) return null;
    throw error;
  }
}

/** Stripe が「そのようなものはありません」と言っているかどうかです */
function isMissing(error: unknown): boolean {
  if (typeof error !== "object" || error === null) return false;
  const found = error as { code?: unknown; statusCode?: unknown };
  return found.code === "resource_missing" || found.statusCode === 404;
}

/** 展開されていれば入れ物、されていなければ id の文字が入っています */
function idOf(value: string | { id: string } | null | undefined): string | null {
  if (typeof value === "string") return value === "" ? null : value;
  if (value === null || value === undefined) return null;
  return typeof value.id === "string" && value.id !== "" ? value.id : null;
}
