import "server-only";

/**
 * Stripe のつなぎ先です。**秘密の鍵を扱うので、サーバーの側だけで読み込みます。**
 *
 * 環境変数はここでは読みません。読んだ値（鍵）は、合成の場所
 * （src/server/ports.ts）から受け取ります。
 */
import Stripe from "stripe";

/**
 * お使いになる API の版です。
 *
 * ここを書かないと、Stripe の設定側の版で動いてしまい、
 * 版が上がった日に、こちらのコードを直さないまま形だけが変わります。
 * **版は必ず書き、SDK を上げたときにここも一緒に上げてください**
 * （合わない版を書くと、型の確かめ（npm run typecheck）で気づけます）。
 */
export const STRIPE_API_VERSION = "2026-08-26.dahlia";

/**
 * 1 回のお問い合わせを待つ上限です（10 秒）。
 *
 * 既定は 80 秒で、その間、決済の通知の受け口の 1 本が塞がったままになります。
 * Stripe がお返事にお時間をいただいているときは、待ち続けるよりも
 * 5xx でお返しして送り直していただくほうが、通知が渋滞しません。
 */
const REQUEST_TIMEOUT_MS = 10_000;

/**
 * 通信が途切れたときの、送り直しの回数です。
 *
 * SDK は送り直しのたびに同じ冪等性キーを添えるので、二重にはなりません。
 * とはいえ、待ち時間の上限（10 秒）と掛け算になるため 1 回までにしています。
 */
const MAX_NETWORK_RETRIES = 1;

/** Stripe のつなぎ役を 1 つ作ります */
export function stripeClient(secretKey: string): Stripe {
  return new Stripe(secretKey, {
    apiVersion: STRIPE_API_VERSION,
    typescript: true,
    timeout: REQUEST_TIMEOUT_MS,
    maxNetworkRetries: MAX_NETWORK_RETRIES,
  });
}
