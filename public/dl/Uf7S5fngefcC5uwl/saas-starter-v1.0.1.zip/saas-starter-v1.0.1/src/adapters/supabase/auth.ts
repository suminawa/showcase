/**
 * AuthPort の本物の実装です（Supabase の認証）。
 *
 * 守りのうえで大事なところが 3 つあります。
 *
 *   ① いまログインしている方は、必ず auth.getUser() で確かめます
 *      （cookie の中身をそのまま信じません）。メールアドレスも、こちらのものを正とします。
 *   ② 誤りの文をそのまま画面に出しません。決まった符号に写してからお返しします。
 *   ③ **ご登録の有無を、外からお確かめになれないようにします。**
 *      すでにご登録のメールアドレスでのご登録と、まだご登録のないメールアドレスへの
 *      ログインのリンクは、どちらも「お送りしました」と同じお返事に見えるようにします。
 */
import type { AuthError, SupabaseClient } from "@supabase/supabase-js";
import type { Lang } from "../../core/i18n";
import { isLang } from "../../core/i18n";
import type {
  AuthErrorCode,
  AuthPort,
  AuthResult,
  OAuthProvider,
  SessionUser,
} from "../../ports/auth";

/** メールのリンクの種類です（@supabase/auth-js の EmailOtpType と同じ顔ぶれです） */
const OTP_TYPES = ["signup", "invite", "magiclink", "recovery", "email_change", "email"] as const;

type OtpType = (typeof OTP_TYPES)[number];

function isOtpType(value: unknown): value is OtpType {
  return typeof value === "string" && (OTP_TYPES as readonly string[]).includes(value);
}

/**
 * 認証の口の誤りを、画面にお出しできる符号に写します。
 *
 * 機械向けの符号（error.code）を先に見て、無ければ文の中身で見分けます
 * （版が上がって符号が増えたときにも、ひとまず正しく写せるようにするためです）。
 */
export function authErrorCode(error: AuthError): AuthErrorCode {
  if (error.status === 429) return "rate_limited";

  switch (error.code) {
    case "over_request_rate_limit":
    case "over_email_send_rate_limit":
    case "over_sms_send_rate_limit":
      return "rate_limited";
    case "invalid_credentials":
      return "bad_credentials";
    case "email_not_confirmed":
      return "not_confirmed";
    case "user_already_exists":
    case "email_exists":
      return "email_taken";
    // メールのリンクを、登録したときと別のブラウザで開いたときの符号です
    // （PKCE の合い札 cookie が、開いたブラウザには無いために起こります）。
    case "bad_code_verifier":
    case "flow_state_not_found":
    case "flow_state_expired":
      return "wrong_browser";
    default:
      break;
  }

  const message = error.message.toLowerCase();
  if (message.includes("invalid login credentials")) return "bad_credentials";
  if (message.includes("email not confirmed")) return "not_confirmed";
  if (message.includes("already registered") || message.includes("already exists")) {
    return "email_taken";
  }
  if (message.includes("rate limit")) return "rate_limited";
  if (message.includes("code verifier") || message.includes("flow state")) {
    return "wrong_browser";
  }

  return "unavailable";
}

/**
 * まだご登録のないメールアドレスへの、ログインのリンクのお求めかどうかです。
 *
 * ご登録のない方には新しくお作りしない（shouldCreateUser: false）ため、
 * 認証の口は「お作りできません」という誤りをお返しします。
 * そのままお伝えすると、そのメールアドレスのご登録の有無が分かってしまうので、
 * お送りしたときと同じお返事に見えるようにします。
 */
function hidesUnknownEmail(error: AuthError): boolean {
  if (error.code === "otp_disabled" || error.code === "user_not_found") return true;

  const message = error.message.toLowerCase();
  return message.includes("signups not allowed") || message.includes("user not found");
}

export type SupabaseAuthOptions = {
  /** お申し付けごとに作った、利用者のセッションのつなぎ口です */
  client: SupabaseClient;
  /** Google でのログインをお使いになるかどうかです（環境変数の読み取りは合成の場所で行います） */
  googleEnabled: boolean;
};

export function createSupabaseAuth(options: SupabaseAuthOptions): AuthPort {
  const supabase = options.client;

  return {
    async getUser(): Promise<SessionUser | null> {
      // cookie の中身ではなく、認証の口にお尋ねします
      const { data, error } = await supabase.auth.getUser();
      if (error !== null || data.user === null) return null;

      const user = data.user;
      // メールアドレスは、認証の口のものを正とします
      const email = typeof user.email === "string" ? user.email : "";

      const metadata = user.user_metadata as Record<string, unknown> | null;
      const metaName = typeof metadata?.name === "string" ? metadata.name : "";

      // 表示のお名前と言語は、プロフィールの行にあればそちらを使います
      const profile = await supabase
        .from("profiles")
        .select("name, lang")
        .eq("id", user.id)
        .maybeSingle();

      if (profile.error !== null) {
        // 行がまだ無いとき（ご登録の直後）は誤りになりません。ここへ来るのは、
        // 表が開かれていない・つながらないなど、気づけないと直せないことです。
        // 画面は止めずに仮のお名前でお通しし、**サーバーの記録にだけ** 1 行残します
        // （誤りの中身は、記録にも持ち回りません）。
        console.error("プロフィールを読み取れませんでした。お名前は仮の値でお出しします");
      }

      const row = profile.error === null ? (profile.data as Record<string, unknown> | null) : null;
      const name = typeof row?.name === "string" && row.name !== "" ? row.name : metaName;
      const lang: Lang = isLang(row?.lang) ? row.lang : "ja";

      return { id: user.id, email, name, lang };
    },

    async sendMagicLink(email: string, redirectTo: string): Promise<AuthResult> {
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: redirectTo,
          // ログインのリンクで、新しくご登録までは行いません（ご登録は /signup です）
          shouldCreateUser: false,
        },
      });
      if (error === null) return { ok: true };

      // まだご登録のないメールアドレスも、お送りしたときと同じお返事にします。
      // ただし、この符号は Email の設定が無効のときにも返ります。
      // お返事を分けるとご登録の有無が漏れるので、**記録にだけ** 1 行残します
      // （メールアドレスは残しません）。
      if (error.code === "otp_disabled") {
        console.warn(
          "ログインのリンクの送信を Supabase が受け付けませんでした。" +
            "まだご登録のないメールアドレスか、Email の設定が無効の可能性があります",
        );
      }
      if (hidesUnknownEmail(error)) return { ok: true };

      return { ok: false, code: authErrorCode(error) };
    },

    async signInWithPassword(email: string, password: string): Promise<AuthResult> {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error !== null) return { ok: false, code: authErrorCode(error) };
      return { ok: true };
    },

    async signUpWithPassword(
      email: string,
      password: string,
      redirectTo: string,
    ): Promise<AuthResult> {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: redirectTo },
      });
      if (error !== null) return { ok: false, code: authErrorCode(error) };

      /**
       * **ご登録の直後に、セッションを残しません。**
       *
       * 確認のメールをお使いでない設定では、認証の口がその場でセッションをお返しします。
       * そのまま入れてしまうと、「入れたかどうか」で、そのメールアドレスの
       * ご登録の有無が外から分かってしまいます
       * （すでにご登録の方は入れず、はじめての方は入れるためです）。
       * ここで閉じておけば、どちらの場合も同じ見え方になります。
       * ログインは、あらためてログインの画面から行います。
       */
      if (data.session !== null) await supabase.auth.signOut();

      // 確認のメールをお使いのときは、すでにご登録のメールアドレスでも
      // 誤りではなく、中身を伏せたお返事が返ります（ご登録の有無は分かりません）。
      // お使いでないときは email_taken が返り、その符号は画面の流れが伏せます。
      return { ok: true };
    },

    async signOut(): Promise<void> {
      await supabase.auth.signOut();
    },

    async oauthStartUrl(provider: OAuthProvider, redirectTo: string): Promise<string | null> {
      if (!options.googleEnabled) return null;

      // お戻りの中身をすり替えられないよう、合言葉の控え（PKCE）を cookie に残します。
      // **この呼び出しは、cookie を書ける場所（お申し付けの受け口）から行ってください。**
      // 画面の部品から呼ぶと控えが残らず、お戻りのときの引き換えができません。
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo, skipBrowserRedirect: true },
      });
      if (error !== null || data.url === null || data.url === "") return null;

      return data.url;
    },

    async completeSignIn(input: {
      code?: string;
      tokenHash?: string;
      type?: string;
    }): Promise<AuthResult> {
      if (typeof input.code === "string" && input.code !== "") {
        const { error } = await supabase.auth.exchangeCodeForSession(input.code);
        if (error !== null) return { ok: false, code: authErrorCode(error) };
        return { ok: true };
      }

      if (typeof input.tokenHash === "string" && input.tokenHash !== "") {
        // 知らない種類は、そのまま渡さずにお止めします
        if (!isOtpType(input.type)) return { ok: false, code: "unavailable" };

        const { error } = await supabase.auth.verifyOtp({
          token_hash: input.tokenHash,
          type: input.type,
        });
        if (error !== null) return { ok: false, code: authErrorCode(error) };
        return { ok: true };
      }

      return { ok: false, code: "unavailable" };
    },
  };
}
