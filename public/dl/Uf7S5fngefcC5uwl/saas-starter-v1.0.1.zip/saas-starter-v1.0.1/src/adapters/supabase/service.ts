import "server-only";

/**
 * service role の鍵でつなぐ口です。
 *
 * **この鍵は、行の出入りの決まり（RLS）を素通りします。** ブラウザには決して渡しません。
 * `import "server-only";` を先頭に置いてあるので、うっかり画面の部品から
 * 読み込むと、組み立ての時点でお止めします。
 *
 * ここを使ってよいのは、次の 3 つだけです。
 *   ① 決済の通知が書く 3 つの表（subscriptions・stripe_customers・stripe_events）
 *   ② 管理の画面の一覧（どの組織にも属さない立場で、全体をご覧になるため）
 *   ③ 見本のデータづくり（メンバーの行は、関数を通さないと増やせないため）
 *
 * 利用者の操作は、必ず利用者ご自身のセッション（server.ts）で行ってください。
 * 表や列の名前を、利用者からお預かりした値で組み立てることもしないでください。
 */
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export type SupabaseServiceConfig = {
  url: string;
  /** service role の鍵です。サーバーの中だけで使います */
  serviceRoleKey: string;
};

export function createServiceSupabase(config: SupabaseServiceConfig): SupabaseClient {
  return createClient(config.url, config.serviceRoleKey, {
    auth: {
      // この口はどなたのセッションも持ちません（cookie も保存しません）
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  });
}
