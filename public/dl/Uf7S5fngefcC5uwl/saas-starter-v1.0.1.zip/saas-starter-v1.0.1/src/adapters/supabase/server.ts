/**
 * サーバー側の Supabase のつなぎ口です。
 *
 * お申し付けの cookie からセッションを読みます。**お申し付けごとに 1 つ作り、
 * お申し付けをまたいで使い回さないでください**（別の方のセッションが混ざります）。
 *
 * 行の出入りの決まり（RLS）は、この鍵でつないだときにだけ働きます。
 * 利用者の操作は、必ずこの口から行ってください。
 */
import { createServerClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import type { SupabaseConfig } from "./client";

export type ServerSupabaseConfig = SupabaseConfig & {
  /**
   * ログインの控えに secure（https のときだけお送りする印）を付けるかどうかです。
   * いまお使いの組織を覚えておく cookie と同じ判定を、合成の場所からお渡しください。
   */
  cookieSecure: boolean;
};

export async function createServerSupabase(
  config: ServerSupabaseConfig,
): Promise<SupabaseClient> {
  // この土台の版では、cookie を読む口は待ってから使います
  const jar = await cookies();

  return createServerClient(config.url, config.anonKey, {
    /**
     * ログインの控えに付ける印です。
     *
     * **同梱の既定は httpOnly も secure も付きません。**
     * この土台の画面は、ブラウザから Supabase を直に呼びません（サーバーだけです）。
     * 画面の JavaScript から読める必要がないため、httpOnly を付けて、
     * 書き出しの隙をついて控えを持ち出される道を閉じます。
     * ブラウザ側のつなぎ口をお足しになるときは、README の但し書きをご覧ください。
     */
    cookieOptions: {
      httpOnly: true,
      secure: config.cookieSecure,
      sameSite: "lax",
      path: "/",
    },
    cookies: {
      getAll() {
        return jar.getAll();
      },
      /**
       * cookie を書き戻す口です。引数は 2 つで、2 つめはキャッシュを止めるための
       * ヘッダです（ここでは使いません。proxy.ts がお返事に載せます）。
       *
       * 画面の部品からは cookie を書けないため、投げられたら黙って見送ります。
       * セッションの入れ替えは proxy.ts が行い、その結果がお返事に載ります。
       */
      setAll(cookiesToSet) {
        try {
          for (const { name, value, options } of cookiesToSet) {
            jar.set(name, value, options);
          }
        } catch {
          // 画面の部品から呼ばれたときです。proxy.ts が代わりに書きます
        }
      },
    },
  });
}
