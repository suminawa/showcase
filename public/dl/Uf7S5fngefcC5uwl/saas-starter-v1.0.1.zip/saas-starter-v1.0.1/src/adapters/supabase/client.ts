/**
 * ブラウザ側の Supabase のつなぎ口です。
 *
 * この土台の画面は、すべてサーバーの側でデータを読み書きします
 * （ブラウザからデータベースを直に呼ぶところはありません）。
 * お客さまが、ブラウザから直にお使いになる部品（その場で更新される一覧など）を
 * お足しになるときに、この関数をお使いください。
 *
 * **つなぎ先と鍵は、引数でお渡しください。** この土台では、環境変数を読む場所を
 * src/server/ports.ts の 1 か所にそろえています（戻り先の URL や鍵の出どころが
 * 散らばらないようにするためです）。ブラウザの部品では、
 * NEXT_PUBLIC_SUPABASE_URL と NEXT_PUBLIC_SUPABASE_ANON_KEY を
 * サーバーの部品から受け取って、ここへお渡しください。
 */
import { createBrowserClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";

/** ブラウザとサーバーの両方が使う、つなぎ先と公開の鍵です */
export type SupabaseConfig = {
  /** Supabase のプロジェクトの URL です */
  url: string;
  /** anon の鍵です。行の出入りの決まり（RLS）が守りの本体で、この鍵は公開されます */
  anonKey: string;
};

export function createBrowserSupabase(config: SupabaseConfig): SupabaseClient {
  return createBrowserClient(config.url, config.anonKey);
}
