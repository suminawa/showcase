/**
 * DataPort の本物の実装です（Supabase のデータベース）。
 *
 * **鍵の使い分けが、この土台の守りの要です。**
 *
 *   - 利用者の操作は、その方のセッション（anon の鍵 + cookie）で行います。
 *     何が見えて何が書けるかは、データベースの側の決まり（RLS）が決めます。
 *   - service role の鍵を使うのは、次の 3 つだけです。
 *       ① 決済の 3 つの表（subscriptions・stripe_customers・stripe_events）への
 *          書き込みと、決済の通知が読むところ（getBillingSubscription）。
 *          決済の通知にはログインの状態が無く、この 3 つは利用者の鍵では書けません。
 *          **画面にお出しするご契約の行（getSubscription）は、利用者の鍵で読みます。**
 *       ② 管理の画面の一覧（どの組織にも属さない立場で、全体をご覧になるため）。
 *       ③ 見本のデータづくり（メンバーの行は、関数を通さないと増やせないため）。
 *
 * 「数えてから書く」呼び出し（組織・プロジェクト・役割・退会・ご招待）は、
 * ここでは組み立て直さず、データベースの関数（rpc）をそのまま 1 対 1 で呼びます。
 * 数えるところと書くところが同じ取引の中に入り、同時のお申し付けでも
 * 上限やオーナーの人数が崩れないためです。
 *
 * 誤りの文は、そのまま外へ出しません（SQL も表の名前も持ち回りません）。
 * 止められたときは `data: <呼び出しの名前>` だけを投げ、画面には
 * 「一時的にお使いいただけません」の文をお出しします。
 * **立場が足りずに止められた例外を、握りつぶして成功にはしません。**
 */
import type { PostgrestError, SupabaseClient } from "@supabase/supabase-js";
import { billingStateFrom, type SubscriptionRow } from "../../core/billing-state";
import type { Lang } from "../../core/i18n";
import type { InvitationRow } from "../../core/invitations";
import type { Role } from "../../core/permissions";
import type {
  AdminOrgRow,
  AdminSubscriptionRow,
  DataPort,
  MemberView,
  Membership,
  Organization,
  Profile,
  Project,
  StripeCustomer,
} from "../../ports/data";
import {
  fromSubscription,
  isUuid,
  toAdminSubscription,
  toInvitation,
  toMemberView,
  toMembership,
  toOrganization,
  toProfile,
  toProject,
  toStripeCustomer,
  toSubscription,
  type Row,
} from "./rows";

/** 同じ行がすでにあるときの符号です */
const DUPLICATE = "23505";

/** 読む列は、いつも並べて書きます（ご契約の表は * では読めません） */
const PROFILE_COLUMNS = "id, email, name, lang, created_at";
const ORGANIZATION_COLUMNS = "id, name, created_at";
const MEMBERSHIP_COLUMNS = "organization_id, user_id, role, created_at";
const PROJECT_COLUMNS = "id, organization_id, name, note, created_by, created_at, updated_at";
const INVITATION_COLUMNS =
  "id, organization_id, email, role, token_hash, expires_at, status, invited_by, accepted_by, created_at";
/** 決済の契約の番号は、一員の方の鍵では読めません（service role のときだけ入ります） */
const SUBSCRIPTION_COLUMNS =
  "organization_id, plan_id, status, stripe_subscription_id, current_period_end, cancel_at_period_end, updated_at";
/** 一員の方に開かれている 6 つの列です（決済の契約の番号は入りません） */
const MEMBER_SUBSCRIPTION_COLUMNS =
  "organization_id, plan_id, status, current_period_end, cancel_at_period_end, updated_at";
/**
 * 運営の画面の一覧です。決済の契約の番号は選ばず、組織のお名前を一緒に読みます
 * （service role で読むため、行の出入りの決まりには遮られません）。
 */
const ADMIN_SUBSCRIPTION_COLUMNS = `${MEMBER_SUBSCRIPTION_COLUMNS}, organizations ( name )`;

type Result = { data: unknown; error: PostgrestError | null };
type CountResult = { count: number | null; error: PostgrestError | null };

/** 誤りの中身は持ち回らず、どの呼び出しで止まったかだけをお伝えします */
function fail(method: string): never {
  throw new Error(`data: ${method}`);
}

function rowsOf(result: Result, method: string): Row[] {
  if (result.error !== null) return fail(method);
  return Array.isArray(result.data) ? (result.data as Row[]) : [];
}

function rowOf(result: Result, method: string): Row {
  if (result.error !== null) return fail(method);
  if (typeof result.data !== "object" || result.data === null) return fail(method);
  return result.data as Row;
}

function maybeRowOf(result: Result, method: string): Row | null {
  if (result.error !== null) return fail(method);
  if (typeof result.data !== "object" || result.data === null) return null;
  return result.data as Row;
}

function countOf(result: CountResult, method: string): number {
  if (result.error !== null) return fail(method);
  return result.count ?? 0;
}

/**
 * 1 回のお返事に入る行数の上限です（supabase/config.toml の max_rows と同じ値）。
 * お客さまがそちらを大きくされても、この値のままで正しく数えられます
 * （小さくされたときは、その回数だけ読み足します）。
 */
const MAX_ROWS = 1000;

/** 読み足す回数の上限です（10 万行まで数えます。それ以上は数え落とします） */
const MAX_PAGES = 100;

/**
 * 上限に当たっているあいだ、続きを読み足します。
 *
 * 数えるための問い合わせが 1 回のお返事の上限で切られると、
 * 件数がその数で止まってしまいます（管理の画面の「○ 件」が合わなくなります）。
 * **並べ方を決めてからお渡しください。** 決めずに読み足すと、
 * 同じ行を二度数えたり、読み落としたりすることがあります。
 */
async function allRows(
  make: (from: number, to: number) => PromiseLike<Result>,
  method: string,
): Promise<Row[]> {
  const out: Row[] = [];

  for (let page = 0; page < MAX_PAGES; page += 1) {
    const from = page * MAX_ROWS;
    const rows = rowsOf(await make(from, from + MAX_ROWS - 1), method);
    out.push(...rows);
    if (rows.length < MAX_ROWS) break;
  }

  return out;
}

/** rpc の戻り値（文字）です。知らない言葉が返ったら、成功にはしません */
function wordOf<T extends string>(
  result: Result,
  method: string,
  allowed: readonly T[],
): T {
  if (result.error !== null) return fail(method);
  const value = result.data;
  if (typeof value !== "string" || !(allowed as readonly string[]).includes(value)) {
    return fail(method);
  }
  return value as T;
}

export type SupabaseDataOptions = {
  /** お申し付けごとに作った、利用者のセッションのつなぎ口です */
  client: SupabaseClient;
  /** service role のつなぎ口です。要るときにだけ作ります */
  service: () => SupabaseClient;
};

export function createSupabaseData(options: SupabaseDataOptions): DataPort {
  const supabase = options.client;

  let serviceClient: SupabaseClient | null = null;
  /** 決済の 3 つの表・管理の一覧・見本のデータづくりだけが呼びます */
  const asServer = (): SupabaseClient => {
    if (serviceClient === null) serviceClient = options.service();
    return serviceClient;
  };

  return {
    // ---- profiles ----

    async getProfile(userId: string): Promise<Profile | null> {
      // uuid の形でなければ、データベースには投げません（見つからない、と同じお返事です）
      if (!isUuid(userId)) return null;

      const result = await supabase
        .from("profiles")
        .select(PROFILE_COLUMNS)
        .eq("id", userId)
        .maybeSingle();

      const row = maybeRowOf(result, "getProfile");
      return row === null ? null : toProfile(row);
    },

    async upsertProfile(input: {
      id: string;
      email: string;
      name: string;
      lang: Lang;
    }): Promise<Profile> {
      if (!isUuid(input.id)) return fail("upsertProfile");

      // ふつうは、ご登録に合わせて引き金が行を作っています。
      // 入れてみて、すでにあればお名前と言語だけを直します
      // （メールアドレスは、ご登録のときの値から動かせません）。
      const inserted = await supabase
        .from("profiles")
        .insert({ id: input.id, email: input.email, name: input.name, lang: input.lang })
        .select(PROFILE_COLUMNS)
        .maybeSingle();

      if (inserted.error === null) {
        const row = maybeRowOf(inserted, "upsertProfile");
        if (row !== null) return toProfile(row);
      } else if (inserted.error.code !== DUPLICATE) {
        return fail("upsertProfile");
      }

      const updated = await supabase
        .from("profiles")
        .update({ name: input.name, lang: input.lang })
        .eq("id", input.id)
        .select(PROFILE_COLUMNS)
        .single();

      return toProfile(rowOf(updated, "upsertProfile"));
    },

    async updateProfile(userId: string, input: { name?: string; lang?: Lang }): Promise<Profile> {
      if (!isUuid(userId)) return fail("updateProfile");

      const patch: Row = {};
      if (input.name !== undefined) patch.name = input.name;
      if (input.lang !== undefined) patch.lang = input.lang;

      const result = await supabase
        .from("profiles")
        .update(patch)
        .eq("id", userId)
        .select(PROFILE_COLUMNS)
        .single();

      return toProfile(rowOf(result, "updateProfile"));
    },

    // ---- organizations と memberships ----

    async listOrganizationsForUser(
      userId: string,
    ): Promise<{ organization: Organization; role: Role }[]> {
      if (!isUuid(userId)) return [];

      const result = await supabase
        .from("memberships")
        .select(`organization_id, user_id, role, created_at, organizations ( ${ORGANIZATION_COLUMNS} )`)
        .eq("user_id", userId)
        .order("created_at", { ascending: true });

      const out: { organization: Organization; role: Role }[] = [];
      for (const row of rowsOf(result, "listOrganizationsForUser")) {
        const joined = row.organizations;
        if (typeof joined !== "object" || joined === null) continue;
        out.push({
          organization: toOrganization(joined as Row),
          role: toMembership(row).role,
        });
      }
      return out;
    },

    /**
     * **この土台では使いません。**
     *
     * 見本のしくみ（メモリの偽物）が、お見せするデータを作るための口です。
     * 本物でお使いになると、数えるところと書くところが離れ、service role で
     * 決まりを素通りして書くことになります。組織をお作りになるときは
     * createOrganizationGuarded をお使いください。
     */
    async createOrganizationWithOwner(_input: {
      name: string;
      userId: string;
    }): Promise<Organization> {
      return fail("createOrganizationWithOwner");
    },

    /**
     * 組織をお作りします。
     * 数えるところと書くところは、データベースの関数が 1 回で行います
     * （お作りになる方は、その関数の中でログインしている方として確かめられます）。
     */
    async createOrganizationGuarded(
      input: { name: string; userId: string },
      maxPerUser: number,
    ): Promise<Organization | "limit"> {
      const result = await supabase.rpc("create_organization_guarded", {
        p_name: input.name,
        p_max_per_user: maxPerUser,
      });
      const payload = rowOf(result, "createOrganizationGuarded");

      if (payload.result === "limit") return "limit";
      if (payload.result !== "ok") return fail("createOrganizationGuarded");

      const organization = payload.organization;
      if (typeof organization !== "object" || organization === null) {
        return fail("createOrganizationGuarded");
      }
      return toOrganization(organization as Row);
    },

    async getOrganization(organizationId: string): Promise<Organization | null> {
      if (!isUuid(organizationId)) return null;

      const result = await supabase
        .from("organizations")
        .select(ORGANIZATION_COLUMNS)
        .eq("id", organizationId)
        .maybeSingle();

      const row = maybeRowOf(result, "getOrganization");
      return row === null ? null : toOrganization(row);
    },

    async renameOrganization(organizationId: string, name: string): Promise<Organization> {
      if (!isUuid(organizationId)) return fail("renameOrganization");

      const result = await supabase
        .from("organizations")
        .update({ name })
        .eq("id", organizationId)
        .select(ORGANIZATION_COLUMNS)
        .single();

      return toOrganization(rowOf(result, "renameOrganization"));
    },

    async deleteOrganization(organizationId: string): Promise<void> {
      if (!isUuid(organizationId)) return;

      // ご契約が続いているあいだは、データベースの引き金がお止めします
      const result = await supabase.from("organizations").delete().eq("id", organizationId);
      if (result.error !== null) return fail("deleteOrganization");
    },

    async getMembership(organizationId: string, userId: string): Promise<Membership | null> {
      if (!isUuid(organizationId) || !isUuid(userId)) return null;

      const result = await supabase
        .from("memberships")
        .select(MEMBERSHIP_COLUMNS)
        .eq("organization_id", organizationId)
        .eq("user_id", userId)
        .maybeSingle();

      const row = maybeRowOf(result, "getMembership");
      return row === null ? null : toMembership(row);
    },

    async listMembers(organizationId: string): Promise<MemberView[]> {
      if (!isUuid(organizationId)) return [];

      const result = await supabase
        .from("memberships")
        .select("user_id, role, created_at, profiles ( email, name )")
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: true });

      return rowsOf(result, "listMembers").map(toMemberView);
    },

    async countOwners(organizationId: string): Promise<number> {
      if (!isUuid(organizationId)) return 0;

      const result = await supabase
        .from("memberships")
        .select("user_id", { count: "exact", head: true })
        .eq("organization_id", organizationId)
        .eq("role", "owner");

      return countOf(result, "countOwners");
    },

    /**
     * **この土台では使いません。**
     *
     * 見本のしくみが、お見せするデータを作るための口です。
     * 本物でお使いになると、service role でメンバーの行を直に増やすことになり、
     * ご招待をお受けいただく道（acceptInvitation）を通らずに組織へ入れてしまいます。
     */
    async addMember(_organizationId: string, _userId: string, _role: Role): Promise<void> {
      return fail("addMember");
    },

    /**
     * 画面の流れは changeMemberRole を使います（こちらは数え直しを行いません）。
     * 1 行も変わらなかったときは、その方がその組織にいらっしゃらないときです。
     * 見本のしくみと同じく、黙って終わらずにお止めします。
     */
    async setMemberRole(organizationId: string, userId: string, role: Role): Promise<void> {
      if (!isUuid(organizationId) || !isUuid(userId)) return fail("setMemberRole");

      const result = await supabase
        .from("memberships")
        .update({ role })
        .eq("organization_id", organizationId)
        .eq("user_id", userId)
        .select("user_id");
      if (rowsOf(result, "setMemberRole").length === 0) return fail("setMemberRole");
    },

    /** 画面の流れは removeMemberGuarded を使います（こちらは数え直しを行いません） */
    async removeMember(organizationId: string, userId: string): Promise<void> {
      if (!isUuid(organizationId) || !isUuid(userId)) return;

      const result = await supabase
        .from("memberships")
        .delete()
        .eq("organization_id", organizationId)
        .eq("user_id", userId);
      if (result.error !== null) return fail("removeMember");
    },

    async changeMemberRole(
      organizationId: string,
      userId: string,
      role: Role,
    ): Promise<"ok" | "last_owner" | "not_found"> {
      if (!isUuid(organizationId) || !isUuid(userId)) return "not_found";

      // 立場が足りないときは、値ではなく例外が返ります（握りつぶしません）
      const result = await supabase.rpc("change_member_role", {
        p_organization_id: organizationId,
        p_user_id: userId,
        p_role: role,
      });

      return wordOf(result, "changeMemberRole", ["ok", "last_owner", "not_found"] as const);
    },

    async removeMemberGuarded(
      organizationId: string,
      userId: string,
    ): Promise<"ok" | "last_owner" | "not_found"> {
      if (!isUuid(organizationId) || !isUuid(userId)) return "not_found";

      const result = await supabase.rpc("remove_member_guarded", {
        p_organization_id: organizationId,
        p_user_id: userId,
      });

      return wordOf(result, "removeMemberGuarded", ["ok", "last_owner", "not_found"] as const);
    },

    // ---- projects ----

    /**
     * その組織のプロジェクトを、新しい順に並べてお返しします。
     *
     * 1 回のお返事に入る行数には上限（supabase/config.toml の max_rows）があります。
     * そのまま読むと、上限を超えた分が**黙って**落ちます（お客さまの一覧から消えます）。
     * 上限に当たっているあいだは続きを読み足します。
     * 並べ方を決めてから読み足すのは、同じ行を二度数えないためです
     * （同じ時刻の行があっても順が決まるよう、id も添えて並べます）。
     */
    async listProjects(organizationId: string): Promise<Project[]> {
      if (!isUuid(organizationId)) return [];

      const rows = await allRows(
        (from, to) =>
          supabase
            .from("projects")
            .select(PROJECT_COLUMNS)
            .eq("organization_id", organizationId)
            .order("created_at", { ascending: false })
            .order("id", { ascending: false })
            .range(from, to),
        "listProjects",
      );

      return rows.map(toProject);
    },

    async countProjects(organizationId: string): Promise<number> {
      if (!isUuid(organizationId)) return 0;

      const result = await supabase
        .from("projects")
        .select("id", { count: "exact", head: true })
        .eq("organization_id", organizationId);

      return countOf(result, "countProjects");
    },

    async getProject(organizationId: string, projectId: string): Promise<Project | null> {
      if (!isUuid(organizationId) || !isUuid(projectId)) return null;

      const result = await supabase
        .from("projects")
        .select(PROJECT_COLUMNS)
        .eq("organization_id", organizationId)
        .eq("id", projectId)
        .maybeSingle();

      const row = maybeRowOf(result, "getProject");
      return row === null ? null : toProject(row);
    },

    /** 見本のデータづくりのための呼び出しです（画面の流れは createProjectGuarded です） */
    async createProject(input: {
      organizationId: string;
      name: string;
      note: string;
      createdBy: string;
    }): Promise<Project> {
      if (!isUuid(input.organizationId) || !isUuid(input.createdBy)) return fail("createProject");

      const result = await supabase
        .from("projects")
        .insert({
          organization_id: input.organizationId,
          name: input.name,
          note: input.note,
          created_by: input.createdBy,
        })
        .select(PROJECT_COLUMNS)
        .single();

      return toProject(rowOf(result, "createProject"));
    },

    /**
     * プロジェクトを 1 件お作りします。
     * 件数の上限は、データベースの側がご契約から引き直します
     * （ここでお渡しする上限は、厳しくする向きにだけ効きます）。
     */
    async createProjectGuarded(
      input: { organizationId: string; name: string; note: string; createdBy: string },
      limit: number | null,
    ): Promise<Project | "limit"> {
      if (!isUuid(input.organizationId) || !isUuid(input.createdBy)) {
        return fail("createProjectGuarded");
      }

      const result = await supabase.rpc("create_project_guarded", {
        p_organization_id: input.organizationId,
        p_name: input.name,
        p_note: input.note,
        p_created_by: input.createdBy,
        p_limit: limit,
      });
      const payload = rowOf(result, "createProjectGuarded");

      if (payload.result === "limit") return "limit";
      if (payload.result !== "ok") return fail("createProjectGuarded");

      const project = payload.project;
      if (typeof project !== "object" || project === null) return fail("createProjectGuarded");
      return toProject(project as Row);
    },

    async updateProject(
      organizationId: string,
      projectId: string,
      input: { name: string; note: string },
    ): Promise<Project> {
      if (!isUuid(organizationId) || !isUuid(projectId)) return fail("updateProject");

      const result = await supabase
        .from("projects")
        .update({ name: input.name, note: input.note })
        .eq("organization_id", organizationId)
        .eq("id", projectId)
        .select(PROJECT_COLUMNS)
        .single();

      return toProject(rowOf(result, "updateProject"));
    },

    async deleteProject(organizationId: string, projectId: string): Promise<void> {
      if (!isUuid(organizationId) || !isUuid(projectId)) return;

      const result = await supabase
        .from("projects")
        .delete()
        .eq("organization_id", organizationId)
        .eq("id", projectId);
      if (result.error !== null) return fail("deleteProject");
    },

    // ---- invitations ----

    async listInvitations(organizationId: string): Promise<InvitationRow[]> {
      if (!isUuid(organizationId)) return [];

      const result = await supabase
        .from("invitations")
        .select(INVITATION_COLUMNS)
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: true });

      return rowsOf(result, "listInvitations").map(toInvitation);
    },

    async createInvitation(input: {
      organizationId: string;
      email: string;
      role: Role;
      tokenHash: string;
      expiresAt: string;
      invitedBy: string;
    }): Promise<InvitationRow> {
      if (!isUuid(input.organizationId) || !isUuid(input.invitedBy)) {
        return fail("createInvitation");
      }

      const result = await supabase
        .from("invitations")
        .insert({
          organization_id: input.organizationId,
          email: input.email,
          role: input.role,
          token_hash: input.tokenHash,
          expires_at: input.expiresAt,
          invited_by: input.invitedBy,
        })
        .select(INVITATION_COLUMNS)
        .single();

      return toInvitation(rowOf(result, "createInvitation"));
    },

    /**
     * ご招待をトークンのハッシュで探します。
     * まだ組織の外にいらっしゃる方が使うため、データベースの関数を通します
     * （関数はハッシュそのものを返さないので、お預かりした値をここで戻します）。
     */
    async findInvitationByHash(tokenHash: string): Promise<InvitationRow | null> {
      const result = await supabase.rpc("find_invitation_by_hash", { p_token_hash: tokenHash });
      const row = maybeRowOf(result, "findInvitationByHash");
      if (row === null) return null;

      return toInvitation({ ...row, token_hash: tokenHash });
    },

    async revokePendingInvitations(organizationId: string, email: string): Promise<number> {
      if (!isUuid(organizationId)) return 0;

      const result = await supabase
        .from("invitations")
        .update({ status: "revoked" })
        .eq("organization_id", organizationId)
        .eq("email", email)
        .eq("status", "pending")
        .select("id");

      return rowsOf(result, "revokePendingInvitations").length;
    },

    /**
     * まだお受けいただいていない招待を、取り消します。
     * 1 行も変わらなかったとき（無い招待・すでにお受けいただいた招待）は、
     * 黙って終わらずにお止めします。画面の流れは、手前で状態を見て
     * not_found か no_change をお返しするので、ここへは来ません。
     */
    async revokeInvitation(organizationId: string, invitationId: string): Promise<void> {
      if (!isUuid(organizationId) || !isUuid(invitationId)) return fail("revokeInvitation");

      const result = await supabase
        .from("invitations")
        .update({ status: "revoked" })
        .eq("organization_id", organizationId)
        .eq("id", invitationId)
        .eq("status", "pending")
        .select("id");
      if (rowsOf(result, "revokeInvitation").length === 0) return fail("revokeInvitation");
    },

    /**
     * 画面の流れは acceptInvitation を使います（こちらはメンバーに加えません）。
     * 1 行も変わらなかったときは、黙って終わらずにお止めします。
     */
    async markInvitationAccepted(invitationId: string, userId: string): Promise<void> {
      if (!isUuid(invitationId) || !isUuid(userId)) return fail("markInvitationAccepted");

      const result = await supabase
        .from("invitations")
        .update({ status: "accepted", accepted_by: userId })
        .eq("id", invitationId)
        .eq("status", "pending")
        .select("id");
      if (rowsOf(result, "markInvitationAccepted").length === 0) {
        return fail("markInvitationAccepted");
      }
    },

    async acceptInvitation(
      invitationId: string,
      userId: string,
      role: Role,
    ): Promise<"ok" | "already_member" | "not_pending"> {
      // 無いご招待と見分けがつかないよう、形の違う ID も同じお返事にします
      if (!isUuid(invitationId) || !isUuid(userId)) return "not_pending";

      const result = await supabase.rpc("accept_invitation", {
        p_invitation_id: invitationId,
        p_user_id: userId,
        p_role: role,
      });

      return wordOf(result, "acceptInvitation", ["ok", "already_member", "not_pending"] as const);
    },

    // ---- 課金（画面がご覧になるところだけ利用者の鍵。ほかは service role です） ----

    /**
     * 画面にお出しするご契約の行です。**利用者の鍵で読みます。**
     *
     * 決済の契約の番号の列は、一員の方には開かれていません。
     * 列の名前を並べて読み、その欄は null のままお返しします
     * （* では読めません。開かれていない列が混ざるためです）。
     * 一員でない組織の行は、行の出入りの決まりで 0 行になります。
     */
    async getSubscription(organizationId: string): Promise<SubscriptionRow | null> {
      if (!isUuid(organizationId)) return null;

      const result = await supabase
        .from("subscriptions")
        .select(MEMBER_SUBSCRIPTION_COLUMNS)
        .eq("organization_id", organizationId)
        .maybeSingle();

      const row = maybeRowOf(result, "getSubscription");
      return row === null ? null : toSubscription(row);
    },

    /**
     * 決済の通知のためのご契約の行です。**service role で読みます。**
     *
     * 決済の通知にはログインの状態が無いため、利用者の鍵では 0 行になり、
     * ご解約の通知が「一度もご契約のない組織」と見なされて何も書かずに終わります。
     * また、ご解約のときに書き戻す決済の契約の番号も、この鍵でなければ読めません。
     * **署名の検証を通った Webhook の流れだけが呼びます。**
     */
    async getBillingSubscription(organizationId: string): Promise<SubscriptionRow | null> {
      if (!isUuid(organizationId)) return null;

      const result = await asServer()
        .from("subscriptions")
        .select(SUBSCRIPTION_COLUMNS)
        .eq("organization_id", organizationId)
        .maybeSingle();

      const row = maybeRowOf(result, "getBillingSubscription");
      return row === null ? null : toSubscription(row);
    },

    /**
     * 決済の通知の変更を、ご契約の表へ条件付きで写します。
     *
     * 読むところと書くところは、データベースの関数 1 つ（＝ 1 つの取引）の中です。
     * 行を押さえてから届いた時刻を比べるので、同時に届いた 2 通のうち
     * 古いほうが、新しいほうを上書きすることがありません。
     * ご解約の枝も、この関数の中にあります。
     */
    async applySubscriptionChange(input: {
      organizationId: string;
      row: Omit<SubscriptionRow, "organizationId"> | null;
      now: string;
    }): Promise<boolean> {
      if (!isUuid(input.organizationId)) return fail("applySubscriptionChange");

      const result = await asServer().rpc("apply_subscription_change", {
        p_organization_id: input.organizationId,
        p_row:
          input.row === null
            ? null
            : fromSubscription({ ...input.row, organizationId: input.organizationId }),
        p_now: input.now,
      });

      if (result.error !== null) return fail("applySubscriptionChange");
      // 知らない形が返ったら、書けたことにはしません
      if (typeof result.data !== "boolean") return fail("applySubscriptionChange");
      return result.data;
    },

    async upsertSubscription(row: SubscriptionRow): Promise<void> {
      if (!isUuid(row.organizationId)) return fail("upsertSubscription");

      const result = await asServer()
        .from("subscriptions")
        .upsert(fromSubscription(row), { onConflict: "organization_id" });
      if (result.error !== null) return fail("upsertSubscription");
    },

    async getStripeCustomer(organizationId: string): Promise<StripeCustomer | null> {
      if (!isUuid(organizationId)) return null;

      const result = await asServer()
        .from("stripe_customers")
        .select("organization_id, stripe_customer_id")
        .eq("organization_id", organizationId)
        .maybeSingle();

      const row = maybeRowOf(result, "getStripeCustomer");
      return row === null ? null : toStripeCustomer(row);
    },

    async setStripeCustomer(organizationId: string, stripeCustomerId: string): Promise<void> {
      if (!isUuid(organizationId)) return fail("setStripeCustomer");

      const result = await asServer()
        .from("stripe_customers")
        .upsert(
          { organization_id: organizationId, stripe_customer_id: stripeCustomerId },
          { onConflict: "organization_id" },
        );
      if (result.error !== null) return fail("setStripeCustomer");
    },

    async findOrganizationByStripeCustomer(stripeCustomerId: string): Promise<string | null> {
      const result = await asServer()
        .from("stripe_customers")
        .select("organization_id")
        .eq("stripe_customer_id", stripeCustomerId)
        .maybeSingle();

      const row = maybeRowOf(result, "findOrganizationByStripeCustomer");
      if (row === null) return null;
      return typeof row.organization_id === "string" ? row.organization_id : null;
    },

    async hasStripeEvent(eventId: string): Promise<boolean> {
      const result = await asServer()
        .from("stripe_events")
        .select("id", { count: "exact", head: true })
        .eq("id", eventId);

      return countOf(result, "hasStripeEvent") > 0;
    },

    async recordStripeEvent(input: {
      id: string;
      type: string;
      receivedAt: string;
    }): Promise<boolean> {
      const result = await asServer()
        .from("stripe_events")
        .insert({ id: input.id, type: input.type, received_at: input.receivedAt });

      if (result.error !== null) {
        // すでに同じ通知をお受けしています（二重の処理をここで止めます）
        if (result.error.code === DUPLICATE) return false;
        return fail("recordStripeEvent");
      }
      return true;
    },

    // ---- /admin（読むだけ。どの組織にも属さない立場でご覧になります） ----

    async adminListOrganizations(limit: number, offset: number): Promise<AdminOrgRow[]> {
      if (limit <= 0) return [];
      const server = asServer();

      const organizations = await server
        .from("organizations")
        .select(ORGANIZATION_COLUMNS)
        .order("created_at", { ascending: true })
        .range(offset, offset + limit - 1);

      const rows = rowsOf(organizations, "adminListOrganizations").map(toOrganization);
      if (rows.length === 0) return [];

      const ids = rows.map((organization) => organization.id);

      // 一覧のための表を足さず、4 本の問い合わせの答えをこちらで突き合わせます。
      // 数えるための 3 本は、1 回のお返事の上限を超える分も読み足します
      // （並べ方を決めてから読み足すので、同じ行を二度数えることはありません）。
      const [members, projects, subscriptions] = await Promise.all([
        allRows(
          (from, to) =>
            server
              .from("memberships")
              .select("organization_id, user_id")
              .in("organization_id", ids)
              .order("organization_id", { ascending: true })
              .order("user_id", { ascending: true })
              .range(from, to),
          "adminListOrganizations",
        ),
        allRows(
          (from, to) =>
            server
              .from("projects")
              .select("organization_id, id")
              .in("organization_id", ids)
              .order("id", { ascending: true })
              .range(from, to),
          "adminListOrganizations",
        ),
        allRows(
          (from, to) =>
            server
              .from("subscriptions")
              .select(SUBSCRIPTION_COLUMNS)
              .in("organization_id", ids)
              .order("organization_id", { ascending: true })
              .range(from, to),
          "adminListOrganizations",
        ),
      ]);

      const memberCounts = new Map<string, number>();
      for (const row of members) {
        const id = row.organization_id;
        if (typeof id !== "string") continue;
        memberCounts.set(id, (memberCounts.get(id) ?? 0) + 1);
      }

      const projectCounts = new Map<string, number>();
      for (const row of projects) {
        const id = row.organization_id;
        if (typeof id !== "string") continue;
        projectCounts.set(id, (projectCounts.get(id) ?? 0) + 1);
      }

      const contracts = new Map<string, SubscriptionRow>();
      for (const row of subscriptions) {
        const contract = toSubscription(row);
        contracts.set(contract.organizationId, contract);
      }

      return rows.map((organization) => {
        const state = billingStateFrom(contracts.get(organization.id) ?? null);
        return {
          organization,
          memberCount: memberCounts.get(organization.id) ?? 0,
          projectCount: projectCounts.get(organization.id) ?? 0,
          planId: state.planId,
          status: state.status,
        };
      });
    },

    async adminListProfiles(limit: number, offset: number): Promise<Profile[]> {
      if (limit <= 0) return [];

      const result = await asServer()
        .from("profiles")
        .select(PROFILE_COLUMNS)
        .order("created_at", { ascending: true })
        .range(offset, offset + limit - 1);

      return rowsOf(result, "adminListProfiles").map(toProfile);
    },

    /**
     * ご契約の一覧です。**決済の契約の番号の列は読みません**
     * （画面に出さなくても、行をそのまま部品へ渡した日に漏れてしまうためです）。
     * 組織のお名前は一緒に読みます。組織の消えた行は一覧からお外しします。
     */
    async adminListSubscriptions(limit: number, offset: number): Promise<AdminSubscriptionRow[]> {
      if (limit <= 0) return [];

      const result = await asServer()
        .from("subscriptions")
        .select(ADMIN_SUBSCRIPTION_COLUMNS)
        .order("updated_at", { ascending: true })
        .range(offset, offset + limit - 1);

      const rows: AdminSubscriptionRow[] = [];
      for (const row of rowsOf(result, "adminListSubscriptions")) {
        const mapped = toAdminSubscription(row);
        if (mapped !== null) rows.push(mapped);
      }
      return rows;
    },
  };
}
