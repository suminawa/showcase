/**
 * データベースの行（snake_case）と、この土台の型（camelCase）の写しです。
 *
 * ここは通信をしません。純粋な写しだけを行います。
 *   - 役割・プラン・ご契約の状態は、知っている値かどうかを確かめてから入れます
 *     （知らない値がそのまま画面や上限の判定に流れないようにするためです）。
 *   - 時刻は、受け取った文字のまま持ちます（日付の形には直しません）。
 *     並べ直しは Date.parse が行うため、どちらの書き方でも同じように比べられます。
 *   - 読み取れない行は、黙って既定の値に倒さずにお止めします
 *     （言語だけは、画面が止まる理由にならないため既定に倒します）。
 */
import { isStripeStatus, type SubscriptionRow } from "../../core/billing-state";
import { isLang } from "../../core/i18n";
import type { InvitationRow, InvitationStatus } from "../../core/invitations";
import { isRole } from "../../core/permissions";
import { isPlanId } from "../../core/plans";
import type {
  AdminSubscriptionRow,
  MemberView,
  Membership,
  Organization,
  Profile,
  Project,
  StripeCustomer,
} from "../../ports/data";

/** データベースから受け取った、1 行ぶんの値です */
export type Row = Record<string, unknown>;

/** 誤りの文には、列の名前だけを入れます（行の中身は入れません） */
function broken(field: string): never {
  throw new Error(`data: 行の ${field} を読み取れませんでした。`);
}

function text(row: Row, field: string): string {
  const value = row[field];
  if (typeof value !== "string") return broken(field);
  return value;
}

/** 空の欄（null）と、開かれていない列（値がそもそも無い）を、どちらも空として読みます */
function optionalText(row: Row, field: string): string | null {
  const value = row[field];
  if (value === null || value === undefined) return null;
  if (typeof value !== "string") return broken(field);
  return value;
}

function flag(row: Row, field: string): boolean {
  const value = row[field];
  if (typeof value !== "boolean") return broken(field);
  return value;
}

function role(row: Row, field: string): Membership["role"] {
  const value = row[field];
  if (!isRole(value)) return broken(field);
  return value;
}

/** uuid の形をしているかどうか（データベースに投げる前の確かめです） */
export function isUuid(value: unknown): value is string {
  return (
    typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)
  );
}

export function toProfile(row: Row): Profile {
  return {
    id: text(row, "id"),
    email: text(row, "email"),
    name: text(row, "name"),
    // 表の決まりで 2 つのうちどちらかしか入りませんが、念のため既定に倒します
    lang: isLang(row.lang) ? row.lang : "ja",
    createdAt: text(row, "created_at"),
  };
}

export function toOrganization(row: Row): Organization {
  return {
    id: text(row, "id"),
    name: text(row, "name"),
    createdAt: text(row, "created_at"),
  };
}

export function toMembership(row: Row): Membership {
  return {
    organizationId: text(row, "organization_id"),
    userId: text(row, "user_id"),
    role: role(row, "role"),
    createdAt: text(row, "created_at"),
  };
}

/**
 * メンバーの一覧の 1 行です。
 * お名前とメールアドレスは、つないで読んだ profiles の行から取ります
 * （その行が見えないときは、空の文字にします）。
 */
export function toMemberView(row: Row): MemberView {
  const joined = row.profiles;
  const profile: Row = typeof joined === "object" && joined !== null ? (joined as Row) : {};

  return {
    userId: text(row, "user_id"),
    email: typeof profile.email === "string" ? profile.email : "",
    name: typeof profile.name === "string" ? profile.name : "",
    role: role(row, "role"),
    createdAt: text(row, "created_at"),
  };
}

export function toProject(row: Row): Project {
  return {
    id: text(row, "id"),
    organizationId: text(row, "organization_id"),
    name: text(row, "name"),
    note: text(row, "note"),
    // お作りになった方が退会されると、この欄は空になります
    createdBy: optionalText(row, "created_by"),
    createdAt: text(row, "created_at"),
    updatedAt: text(row, "updated_at"),
  };
}

export function toInvitation(row: Row): InvitationRow {
  const status = row.status;
  if (status !== "pending" && status !== "accepted" && status !== "revoked") {
    return broken("status");
  }

  return {
    id: text(row, "id"),
    organizationId: text(row, "organization_id"),
    email: text(row, "email"),
    role: role(row, "role"),
    tokenHash: text(row, "token_hash"),
    expiresAt: text(row, "expires_at"),
    status: status as InvitationStatus,
    invitedBy: optionalText(row, "invited_by"),
    acceptedBy: optionalText(row, "accepted_by"),
    createdAt: text(row, "created_at"),
  };
}

export function toSubscription(row: Row): SubscriptionRow {
  if (!isPlanId(row.plan_id)) return broken("plan_id");
  if (!isStripeStatus(row.status)) return broken("status");

  return {
    organizationId: text(row, "organization_id"),
    planId: row.plan_id,
    status: row.status,
    // 決済の契約の番号は、一員の方の鍵では読めません（列ごとの許しで閉じています）
    stripeSubscriptionId: optionalText(row, "stripe_subscription_id"),
    currentPeriodEnd: optionalText(row, "current_period_end"),
    cancelAtPeriodEnd: flag(row, "cancel_at_period_end"),
    updatedAt: text(row, "updated_at"),
  };
}

/**
 * 一緒に読んだ組織の欄から、お名前だけを取り出します。
 *
 * 一対一のつながりは object で返りますが、読み手によっては 1 件だけの配列になります。
 * どちらの形でも同じように読めるようにしておきます。お名前が無ければ null です。
 */
function embeddedName(value: unknown): string | null {
  const one = Array.isArray(value) ? value[0] : value;
  if (typeof one !== "object" || one === null) return null;
  const name = (one as Row).name;
  return typeof name === "string" ? name : null;
}

/**
 * 運営の画面にお出しするご契約の行です。組織のお名前を一緒に読みます。
 *
 * **決済の契約の番号は写しません**（読む側も、その列を選びません）。
 * 組織のお名前を引けない行は null をお返しし、呼んだ側が一覧から外します。
 */
export function toAdminSubscription(row: Row): AdminSubscriptionRow | null {
  if (!isPlanId(row.plan_id)) return broken("plan_id");
  if (!isStripeStatus(row.status)) return broken("status");

  const organizationName = embeddedName(row.organizations);
  if (organizationName === null) return null;

  return {
    organizationId: text(row, "organization_id"),
    organizationName,
    planId: row.plan_id,
    status: row.status,
    currentPeriodEnd: optionalText(row, "current_period_end"),
    cancelAtPeriodEnd: flag(row, "cancel_at_period_end"),
    updatedAt: text(row, "updated_at"),
  };
}

/** ご契約の行を、データベースに書ける形に戻します（書けるのは service role だけです） */
export function fromSubscription(row: SubscriptionRow): Row {
  return {
    organization_id: row.organizationId,
    plan_id: row.planId,
    status: row.status,
    stripe_subscription_id: row.stripeSubscriptionId,
    current_period_end: row.currentPeriodEnd,
    cancel_at_period_end: row.cancelAtPeriodEnd,
    updated_at: row.updatedAt,
  };
}

export function toStripeCustomer(row: Row): StripeCustomer {
  return {
    organizationId: text(row, "organization_id"),
    stripeCustomerId: text(row, "stripe_customer_id"),
  };
}
