/**
 * Resend でメールをお送りする口です（任意のご用意です）。
 *
 * 2 つの環境変数がそろったときだけ働きます。
 *   RESEND_API_KEY … Resend の鍵。**サーバーの外へ出しません**（先頭の server-only が番人です）
 *   MAIL_FROM      … 差出人。`SaaS スターター <no-reply@example.com>` の形が使えます
 *
 * Resend は、送れなかったときに例外を投げず、お返事の error に入れて返します。
 * ですので try/catch だけに頼らず、error も必ず見ます。
 * お返事の中身（Resend からのお知らせ）は画面にはお出ししません。
 * お客さまには「ただいまお手続きできません」だけをお伝えし、
 * 詳しい手がかりはサーバーの記録にとどめます。
 */
import "server-only";
import { Resend } from "resend";
import type { MailMessage, MailPort, MailResult } from "../../ports/mail";
import { isSendable, maskAddress } from "./safety";

/** 前後の空白を落として読みます。空のときは、頂戴していない扱いです */
function envValue(name: string): string | undefined {
  const found = process.env[name];
  if (found === undefined) return undefined;
  const trimmed = found.trim();
  return trimmed === "" ? undefined : trimmed;
}

export function createResendMail(): MailPort {
  return {
    async send(message: MailMessage): Promise<MailResult> {
      if (!isSendable(message)) return { ok: false, code: "rejected" };

      // 鍵は、お送りするたびに読みます（立ち上げのあとに設定を足しても効くようにするためです）
      const apiKey = envValue("RESEND_API_KEY");
      const from = envValue("MAIL_FROM");
      if (apiKey === undefined || from === undefined) return { ok: false, code: "not_configured" };

      try {
        const { error } = await new Resend(apiKey).emails.send({
          from,
          to: message.to,
          subject: message.subject,
          // この土台がお送りするのは、テキストのメールだけです
          text: message.text,
        });

        if (error !== null) {
          // 記録に残すのは、伏せた宛先と Resend の符号だけです（本文と宛先は残しません）
          console.error(`[mail] resend rejected to=${maskAddress(message.to)} code=${error.name}`);
          return { ok: false, code: "unavailable" };
        }
        return { ok: true };
      } catch {
        console.error(`[mail] resend unreachable to=${maskAddress(message.to)}`);
        return { ok: false, code: "unavailable" };
      }
    },
  };
}
