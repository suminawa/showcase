/**
 * メールの鍵をまだ頂戴していないときの口です。
 *
 * **お送りはしません。** サーバーの記録に 1 行だけ残して、
 * 「まだ整っていません」をお返しします。画面は、そのお返事を受けて
 * 「ご招待のリンクをお作りしました」とお伝えし、リンクをお見せします
 * （お送りしていないのに「お送りしました」とお伝えしないためです）。
 *
 * 記録に残すのは、伏せた宛先と件名だけです。
 * 本文にはご参加のリンク（1 回だけ使えるトークン）が入っているため、残しません。
 */
import type { MailMessage, MailPort, MailResult } from "../../ports/mail";
import { isSendable, maskAddress } from "./safety";

export function createConsoleMail(): MailPort {
  return {
    async send(message: MailMessage): Promise<MailResult> {
      if (!isSendable(message)) return { ok: false, code: "rejected" };

      console.info(`[mail] to=${maskAddress(message.to)} subject=${message.subject}`);
      return { ok: false, code: "not_configured" };
    },
  };
}
