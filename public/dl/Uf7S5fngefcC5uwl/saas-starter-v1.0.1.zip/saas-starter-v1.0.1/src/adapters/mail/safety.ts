/**
 * メールをお出しする前の、共通の守りです（どの口からお送りするときも通ります）。
 *
 * メールは「ヘッダ → 空行 → 本文」の形でできています。
 * 宛先や件名に改行が混じっていると、その先の行が新しいヘッダとして読まれ、
 * 知らない宛先（Bcc）や差出人をあとから足されてしまいます。
 * 組織の名前やお名前は、お客さまがお書きになった値がそのまま件名に入るため、
 * お送りする直前にここで確かめます。
 */
import type { MailMessage } from "../../ports/mail";

/**
 * ヘッダの行を分けてしまう文字（復帰・改行）と、途中で切ってしまう NUL です。
 *
 * 制御文字は、**必ずエスケープの表記**でお書きください。生のまま置くと、
 * git がこのファイルを「中身の分からないファイル」として扱い、差分が読めなくなります
 * （test/no-control-chars.test.ts が見張っています）。
 */
const HEADER_BREAK = /[\r\n\u0000]/;

/** 宛先や件名としてお送りできる値かどうかです */
export function isSafeHeaderValue(value: string): boolean {
  return !HEADER_BREAK.test(value);
}

/** 宛先と件名を確かめます（本文の改行は、行を分けて書くためのものなので通します） */
export function isSendable(message: MailMessage): boolean {
  return isSafeHeaderValue(message.to) && isSafeHeaderValue(message.subject);
}

/**
 * 記録に残すための、伏せた宛先です。
 * どちらのお宅あてかは残さず、送り先の形（ドメイン）だけが分かるようにします。
 */
export function maskAddress(to: string): string {
  const at = to.lastIndexOf("@");
  if (at < 0) return "***";

  const local = to.slice(0, at);
  const domain = to.slice(at + 1);
  const head = local.length >= 2 ? local.slice(0, 1) : "";
  return `${head}***@${domain}`;
}
