import "server-only";

/**
 * 合成の場所です。
 *
 * ここだけが「いま偽物で動いているのか、本物で動いているのか」を知っています。
 * 画面（app/）も flow も ports の形しか知りません。
 *
 * 環境変数を読むのは、このファイルだけにしてください
 * （ただ 1 つの例外が、メールの鍵です。server-only の中で
 * src/adapters/mail/resend.ts が自分で読みます）。
 * とくに戻り先の URL の土台は、**リクエストのヘッダ（Host・Origin・X-Forwarded-Host）から
 * 作りません**。ヘッダは差し替えられることがあり、メールのリンクやお支払いの戻り先が
 * 知らないサイトを指してしまうためです。
 */
import { cookies, headers } from "next/headers";
import { cache } from "react";
import { createFakePorts, DEMO_USER_IDS, type FakePorts } from "../adapters/fake";
import { createConsoleMail } from "../adapters/mail/console";
import { createResendMail } from "../adapters/mail/resend";
import { createSupabaseAuth } from "../adapters/supabase/auth";
import type { SupabaseConfig } from "../adapters/supabase/client";
import { createSupabaseData } from "../adapters/supabase/data";
import { createServerSupabase } from "../adapters/supabase/server";
import { createServiceSupabase } from "../adapters/supabase/service";
import { createStripeBilling, type StripeCustomerStore } from "../adapters/stripe/billing";
import { stripeClient } from "../adapters/stripe/client";
import { pickLang, type Lang, type Messages } from "../core/i18n";
import { PLAN_IDS, findPlan, priceIdFor, type PlanId } from "../core/plans";
import type { Role } from "../core/permissions";
import { validateChoice } from "../core/validation";
import type { Ports, SessionUser } from "../ports";
import { buildCtx, flowFail, type Ctx, type Deps, type FlowResult, type UserCtx } from "./context";
import { applyWebhookFlow } from "./flows/billing";
import { ensureProfileFlow, landingPathFlow } from "./flows/auth";
import { messagesFor } from "./messages";
import {
  createMemoryRateLimiter,
  INVITE_ACCEPT_LIMIT,
  INVITE_LIMIT,
  LOGIN_IP_LIMIT,
  LOGIN_LIMIT,
  type RateLimiter,
} from "./ratelimit";
import { DEFAULT_NEXT_PATH, loginPath, siteOrigin } from "./urls";

/** いまお使いの組織を覚えておく cookie の名前です */
export const ORG_COOKIE = "st_org";

/** 言語のお好みを覚えておく cookie の名前です */
export const LANG_COOKIE = "st_lang";

const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;

/** IP をお預かりできなかったときの値です（回数を数える鍵に使います） */
const UNKNOWN_IP = "0.0.0.0";

/** 見本のご契約の期間（日）です */
const FAKE_PERIOD_DAYS = 30;

/**
 * 作り直したくないものを、1 つだけ作って覚えておきます。
 *
 * 回数の上限は「数えた回数」を持っているので、お申し付けのたびに作り直すと
 * 上限が効きません。見本の入れ物（メモリの偽物）も、作り直すと中身が消えてしまいます。
 * 書き換えのたびに読み込み直される作り（開発中）でも 1 つのままにするため、
 * globalThis に置いています。
 */
function singleton<T>(name: string, make: () => T): T {
  const key = Symbol.for(`saas-starter/${name}`);
  const holder = globalThis as unknown as Record<symbol, T | undefined>;
  const found = holder[key];
  if (found !== undefined) return found;

  const created = make();
  holder[key] = created;
  return created;
}

// ---- 環境変数を読むのは、ここから下だけです ----

/** 本番で動いているかどうかです。**NODE_ENV を読むのは、この関数 1 つだけです** */
export function isProduction(): boolean {
  return process.env.NODE_ENV === "production";
}

/** NEXT_PUBLIC_SITE_URL を読むのは、この関数 1 つだけです */
export function currentSiteOrigin(): string {
  return siteOrigin(process.env);
}

/**
 * STARTER_FAKE=1 のあいだは、Supabase にも Stripe にも通信しません。
 *
 * ただし**本番では、この 1 つだけでは見本のしくみに入りません**。
 * 見本のしくみは、ログインの状態もデータもサーバーのメモリに 1 つだけ持つため、
 * 公開の場所でそのまま動くと、訪れた方全員が同じ見本の方として入り、
 * 同じ中身をご覧になってしまいます。
 * 承知のうえでお試しになるときだけ、STARTER_FAKE_ALLOW_PRODUCTION=1 でお開けください。
 *
 * 本番で STARTER_FAKE=1 だけが入っているときは、鍵をまだ頂戴していない扱いになり、
 * getPorts() が「設定が整っていません」をお伝えします。
 */
export function isFakeMode(): boolean {
  if (process.env.STARTER_FAKE !== "1") return false;
  if (!isProduction()) return true;
  return process.env.STARTER_FAKE_ALLOW_PRODUCTION === "1";
}

/**
 * 運営の画面（/admin）にお入りいただける方の一覧です。**ADMIN_EMAILS を読むのは、ここだけです。**
 *
 * 未設定・空・空白だけのときは undefined をお返しします。
 * そのときは、どなたもお入りになれません（画面は 404 をお返しします）。
 */
export function adminEmails(): string | undefined {
  return envValue("ADMIN_EMAILS");
}

/** NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN に値があるときだけ、Google のボタンをお出しします */
export function googleLoginEnabled(): boolean {
  const configured = process.env.NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN;
  return configured !== undefined && configured.trim() !== "";
}

/** 値の前後の空白を落とし、空のときは undefined にします */
function envValue(name: string): string | undefined {
  const found = process.env[name];
  if (found === undefined) return undefined;
  const trimmed = found.trim();
  return trimmed === "" ? undefined : trimmed;
}

/**
 * Supabase のつなぎ先と鍵です。**環境変数を読むのは、ここだけです。**
 * 3 つそろっていなければ null を返します（呼んだ側がお知らせをお出しします）。
 */
function supabaseSettings(): (SupabaseConfig & { serviceRoleKey: string }) | null {
  const url = envValue("NEXT_PUBLIC_SUPABASE_URL");
  const anonKey = envValue("NEXT_PUBLIC_SUPABASE_ANON_KEY");
  const serviceRoleKey = envValue("SUPABASE_SERVICE_ROLE_KEY");

  if (url === undefined || anonKey === undefined || serviceRoleKey === undefined) return null;
  return { url, anonKey, serviceRoleKey };
}

/**
 * Stripe の鍵です。**環境変数を読むのは、ここだけです。**
 * 秘密の鍵がなければ null を返します（お支払いの画面がご案内をお出しします）。
 */
function stripeSettings(): { secretKey: string; webhookSecret: string | null } | null {
  const secretKey = envValue("STRIPE_SECRET_KEY");
  if (secretKey === undefined) return null;
  return { secretKey, webhookSecret: envValue("STRIPE_WEBHOOK_SECRET") ?? null };
}

/** プラン → Stripe の Price の id（plans.config.ts の priceEnvName から引きます） */
function priceIdOf(planId: PlanId): string | null {
  const plan = findPlan(planId);
  if (plan === null) return null;

  const configured = priceIdFor(plan, process.env);
  if (configured === null) return null;

  const trimmed = configured.trim();
  return trimmed === "" ? null : trimmed;
}

/**
 * Stripe の Price の id → プラン。
 * 決済の通知に入っていた価格が、こちらのどのプランなのかを決めます。
 * 環境変数に無い価格（ほかの商品のご契約など）は、存じ上げない扱いにします。
 */
function planIdOf(priceId: string): PlanId | null {
  if (priceId === "") return null;
  return PLAN_IDS.find((planId) => priceIdOf(planId) === priceId) ?? null;
}

/**
 * 決済の通知をお受けできる支度が済んでいるかどうかです。
 * 秘密が無いあいだは署名を確かめられないので、受け口が 503 でお断りします。
 *
 * **見本のしくみでお試しのあいだは、受け口を開けません。**
 * 見本の Checkout は、通知の受け口を通らずに流れを直に呼びます。
 * 開けたままにすると、見本の口は署名を確かめないため、
 * どなたでもご契約の表を書き換えられる入口になってしまいます。
 */
export function stripeWebhookReady(): boolean {
  if (isFakeMode()) return false;

  const settings = stripeSettings();
  return settings !== null && settings.webhookSecret !== null;
}

// ---- ports の組み立て ----

const NOT_CONFIGURED =
  "Supabase と Stripe の設定がまだ整っていません。" +
  ".env.example をご覧のうえ、鍵をご用意ください。" +
  "お手元でお試しのあいだは、STARTER_FAKE=1 のままお使いいただけます" +
  "（本番では、STARTER_FAKE=1 だけでは見本のしくみは動きません）。";

/** 見本のしくみ（メモリの偽物）です。1 つだけ作り、同じ工程の中で使い回します */
function fakePorts(): FakePorts {
  return singleton("fake-ports", () => createFakePorts({ now: () => new Date() }));
}

function requireFakePorts(): FakePorts {
  if (!isFakeMode()) throw new Error(NOT_CONFIGURED);
  return fakePorts();
}

/**
 * お支払いの口が、まだ整っていないときのお返事です。
 * STRIPE_SECRET_KEY を頂戴していないあいだだけこちらになります。
 * 画面には「設定が整っていません」のご案内が出て、決済の通知はお受けしません。
 */
function notConfiguredBilling(): Ports["billing"] {
  return {
    async createCheckoutUrl() {
      return { ok: false, code: "not_configured" };
    },
    async createPortalUrl() {
      return { ok: false, code: "not_configured" };
    },
    async readWebhook() {
      return { ok: false, code: "bad_signature" };
    },
  };
}

/**
 * メールの口です。
 *   見本のしくみ                     … 外へは何も送らず、メモリに積むだけの口
 *   RESEND_API_KEY と MAIL_FROM がある … Resend からお送りする口
 *   どちらでもない                   … 記録に 1 行だけ残し、お送りしない口
 *
 * **2 つそろってはじめて Resend を選びます。** 鍵だけを入れて差出人をお忘れになると、
 * Resend の口は毎回 not_configured を返しますが、記録には 1 行も出ません。
 * 鍵を入れたおつもりの買い手には、お送りしていないことが伝わりません。
 * ここで記録の残る口へ落としておけば、「届かない」の手がかりが必ず残ります。
 *
 * 鍵をまだ頂戴していないときも、ご招待そのものは成り立ちます。
 * 画面には「ご招待のリンクをお作りしました」と出て、リンクをお渡しいただけます。
 */
export function createMail(): Ports["mail"] {
  if (isFakeMode()) return fakePorts().mail;
  if (envValue("RESEND_API_KEY") !== undefined && envValue("MAIL_FROM") !== undefined) {
    return createResendMail();
  }
  return createConsoleMail();
}

/**
 * 本物の Stripe の口です。鍵をまだ頂戴していないときは null をお返しします。
 *
 * Stripe のお客さまの控え（stripe_customers）を読み書きするので、
 * データの口をそのままお渡しします。
 */
function stripeBilling(customers: StripeCustomerStore): Ports["billing"] | null {
  const settings = stripeSettings();
  if (settings === null) return null;

  return createStripeBilling({
    stripe: stripeClient(settings.secretKey),
    customers,
    webhookSecret: settings.webhookSecret,
    priceIdOf,
    planIdOf,
  });
}

/**
 * 4 つの ports です。
 * STARTER_FAKE=1 のときはメモリの偽物、そうでなければ本物の Supabase です。
 *
 * **つなぎ口は、お申し付けごとに作ります。** cookie からログインの状態を読むため、
 * お申し付けをまたいで使い回すと、別の方のセッションが混ざってしまいます。
 * service role の口は、決済の表と管理の一覧で要るときにだけ作ります。
 */
export async function getPorts(): Promise<Ports> {
  if (isFakeMode()) return fakePorts();

  const settings = supabaseSettings();
  if (settings === null) throw new Error(NOT_CONFIGURED);

  // ログインの控えの印（httpOnly ほか）は、いまお使いの組織の cookie と同じ判定にそろえます
  const client = await createServerSupabase({ ...settings, cookieSecure: cookieSecure() });
  const data = createSupabaseData({
    client,
    service: () => createServiceSupabase(settings),
  });

  return {
    auth: createSupabaseAuth({ client, googleEnabled: googleLoginEnabled() }),
    data,
    billing: stripeBilling(data) ?? notConfiguredBilling(),
    mail: createMail(),
  };
}

/**
 * ports と、このサイトの土台の URL を 1 つの束にします。
 * 画面（Server Actions）は 1 回だけこれを作り、flow にはこの束をそのままお渡しします。
 */
export function buildDeps(ports: Ports): Deps {
  return { ports, siteOrigin: currentSiteOrigin() };
}

/**
 * 回数の上限を数える入れ物です。**種類ごとに 1 つだけ**作って使い回します
 * （お申し付けのたびに作り直すと、いつまでも上限に届きません）。
 */
export function limiters(): {
  login: RateLimiter;
  loginIp: RateLimiter;
  invite: RateLimiter;
  inviteAccept: RateLimiter;
} {
  return singleton("rate-limiters", () => ({
    login: createMemoryRateLimiter(LOGIN_LIMIT),
    loginIp: createMemoryRateLimiter(LOGIN_IP_LIMIT),
    invite: createMemoryRateLimiter(INVITE_LIMIT),
    inviteAccept: createMemoryRateLimiter(INVITE_ACCEPT_LIMIT),
  }));
}

// ---- お申し付けごとに読むもの（cookie とヘッダ） ----

/**
 * cookie に secure（https のときだけ送る印）を付けるかどうかです。
 *
 * NEXT_PUBLIC_SITE_URL が https のとき、**または**本番で動いているときに付けます。
 * 本番でも土台の URL を http のまま（中継の内側など）お使いのことがあり、
 * URL の字面だけで決めると、印の無い cookie をそのまま外に出してしまうためです。
 * お手元でお試しのあいだ（http）は付けません（付けると cookie が届きません）。
 */
export function cookieSecure(): boolean {
  return currentSiteOrigin().startsWith("https://") || isProduction();
}

function cookieOptions(): {
  path: string;
  httpOnly: true;
  sameSite: "lax";
  secure: boolean;
  maxAge: number;
} {
  return {
    path: "/",
    // 画面の JavaScript からは読みません（サーバーだけが使います）
    httpOnly: true,
    // ほかのサイトからの書き込みには乗せません
    sameSite: "lax",
    secure: cookieSecure(),
    maxAge: COOKIE_MAX_AGE_SECONDS,
  };
}

/**
 * 信頼する中継の段数です（`TRUSTED_PROXY_HOPS`。既定は 1）。
 *
 * アプリの手前に中継が何段あるかをお知らせいただく数です。
 * 1 なら、`x-forwarded-for` の**末尾**（いちばん近い中継が足した値）がお客さまの IP です。
 * Cloudflare → nginx → アプリのように 2 段はさむときは 2 にしてください。
 * 数にならない値・0 以下は、いちばん安全な 1 として扱います。8 を超える値は 8 として扱います
 * （中継が 8 段を超える置き方は、書き間違いと見ます）。
 */
const MAX_TRUSTED_PROXY_HOPS = 8;

export function trustedProxyHops(): number {
  const raw = envValue("TRUSTED_PROXY_HOPS");
  if (raw === undefined) return 1;

  const hops = Number(raw);
  if (!Number.isInteger(hops) || hops < 1) return 1;
  return Math.min(hops, MAX_TRUSTED_PROXY_HOPS);
}

/**
 * お客さまの IP です。
 *
 * `x-forwarded-for` は「いちばん古い（お客さまに近い）ものが先頭」に並び、
 * 中継が 1 段通るたびに末尾へ 1 つ足されます。**先頭は、お客さまが自由に書けます**ので、
 * そこを信じると回数の上限をいくらでもすり抜けられてしまいます。
 * そこで、末尾から「信頼する中継の段数」ぶん戻ったところを採ります。
 *
 * 段数が足りない（＝並びが思ったより短い）のは、前段を通っていないお申し付けです。
 * 並びのどの値もお客さまが書けますので、どれも採らずに 0.0.0.0 の 1 つの枠へ落とします。
 * ヘッダそのものが無いときも 0.0.0.0（中継のない置き方です）。
 *
 * **ここを取り違えると、回数の上限がサイト全体で 1 つの枠になります**
 * （少し混んだだけで、どなたもログインできなくなります）。
 */
export async function clientIp(): Promise<string> {
  const head = await headers();
  const forwarded = head.get("x-forwarded-for");
  if (forwarded === null) return UNKNOWN_IP;

  const parts = forwarded.split(",").map((part) => part.trim()).filter((part) => part !== "");
  if (parts.length === 0) return UNKNOWN_IP;

  const at = parts.length - trustedProxyHops();
  if (at < 0) return UNKNOWN_IP;
  return parts[at] ?? UNKNOWN_IP;
}

/** cookie → プロフィール → ブラウザのご希望、の順に見ます */
export async function getRequestLang(profileLang?: string | null): Promise<Lang> {
  const [jar, head] = await Promise.all([cookies(), headers()]);
  return pickLang({
    cookie: jar.get(LANG_COOKIE)?.value ?? null,
    profile: profileLang ?? null,
    header: head.get("accept-language"),
  });
}

/** 言語と、その言語の文です（ログインの要らない画面が使います） */
export async function pageMessages(): Promise<{ lang: Lang; messages: Messages }> {
  const lang = await getRequestLang();
  return { lang, messages: messagesFor(lang) };
}

/** Server Action と Route Handler の中だけで呼べます */
export async function setRequestLang(lang: Lang): Promise<void> {
  const jar = await cookies();
  jar.set(LANG_COOKIE, lang, cookieOptions());
}

/**
 * いまお使いの組織の ID です。
 * **この値はお好みの控えで、権限ではありません。** 使う前に必ず memberships を引き直します
 * （buildCtx がその役目です）。
 */
export async function getCurrentOrganizationId(): Promise<string | null> {
  const jar = await cookies();
  return jar.get(ORG_COOKIE)?.value ?? null;
}

/** Server Action と Route Handler の中だけで呼べます */
export async function setCurrentOrganizationId(organizationId: string): Promise<void> {
  const jar = await cookies();
  jar.set(ORG_COOKIE, organizationId, cookieOptions());
}

/** 組織から退会されたときなどに、控えを消します */
export async function clearCurrentOrganizationId(): Promise<void> {
  const jar = await cookies();
  jar.delete(ORG_COOKIE);
}

// ---- 画面の関門 ----

/**
 * /app 以下の画面が、いちばん初めに 1 回だけ呼ぶ関門です。
 *
 *   guest       … ログインしていらっしゃいません（画面は /login へお通しします）
 *   onboarding  … まだ組織がありません（画面は /onboarding へお通しします）
 *   not_member  … その組織の一員ではありません（画面は「見つかりません」をお返しします）
 *   ok          … その組織での役割まで分かりました
 *
 * cookie の組織の ID は、ここで必ず memberships を引き直します。
 * 引き直して一員でなかったときは、**その方が入っていらっしゃる組織**に戻します
 * （組織を移られたあとの古い控えで、行き止まりにならないようにするためです）。
 */
export type AppGate =
  | { status: "guest" }
  | { status: "onboarding"; user: SessionUser; lang: Lang }
  | { status: "not_member" }
  | { status: "ok"; ctx: Ctx };

/**
 * 1 回のお申し付けのあいだ、答えを 1 つだけ作ります（React の cache）。
 *
 * /app 以下では、枠（layout）と画面（page）がそれぞれ自分でここを通ります。
 * 守りの形はそのままに、auth.getUser() と memberships の読み取りが
 * 同じお申し付けの中で二度走らないようにするためです。
 * お申し付けが変われば、また初めから確かめ直します。
 */
export const appGate = cache(async function appGate(): Promise<AppGate> {
  const deps = buildDeps(await getPorts());

  // ここより先へ進む前に、必ずいまログインしている方を引き直します
  const user = await deps.ports.auth.getUser();
  if (user === null) return { status: "guest" };

  const lang = await getRequestLang(user.lang);
  const now = new Date();

  const remembered = await getCurrentOrganizationId();
  if (remembered !== null) {
    const built = await buildCtx({ ...deps, user, organizationId: remembered, lang, now });
    if (built.ok) return { status: "ok", ctx: built.value };
  }

  const landing = await landingPathFlow({ ports: deps.ports, user });
  if (!landing.ok) return { status: "not_member" };

  const organizationId = landing.value.organizationId;
  if (organizationId === null) return { status: "onboarding", user, lang };

  const built = await buildCtx({ ...deps, user, organizationId, lang, now });
  if (!built.ok) return { status: "not_member" };

  return { status: "ok", ctx: built.value };
});

/**
 * Server Action の入口です。
 * 「auth.getUser() → buildCtx（一員かを引き直す） → flow」の順を、ここ 1 か所にまとめています。
 */
export async function actionContext(): Promise<FlowResult<Ctx>> {
  const gate = await appGate();
  if (gate.status === "ok") return { ok: true, value: gate.ctx };
  if (gate.status === "guest") return flowFail("unauthenticated");
  return flowFail("not_found");
}

/**
 * ログインが成り立ったあとの片づけです。
 *   ① profiles の行をご用意する ② いまお使いの組織を控える ③ 次にお通しする画面を決める
 * ログイン・ご登録・メールのリンクの受け口の 3 か所が、同じこの順で通ります。
 */
export async function afterSignIn(input: { deps: Deps; next: string | null }): Promise<string> {
  const user = await input.deps.ports.auth.getUser();
  if (user === null) return loginPath(input.next ?? undefined);

  const now = new Date();
  const profile = await ensureProfileFlow({ ports: input.deps.ports, user, now });

  // 言語のお好みをまだ伺っていないときは、プロフィールの言語を控えます
  // （お選びいただいたあとは、そちらを変えません）。
  const jar = await cookies();
  if (profile.ok && jar.get(LANG_COOKIE) === undefined) {
    await setRequestLang(profile.value.lang);
  }

  const landing = await landingPathFlow({ ports: input.deps.ports, user });
  if (!landing.ok) return input.next ?? DEFAULT_NEXT_PATH;

  if (landing.value.organizationId !== null) {
    await setCurrentOrganizationId(landing.value.organizationId);
  }

  // お戻りいただく先をお預かりしているときは、そちらを先にお通しします
  return input.next ?? landing.value.path;
}

/** 組織がまだ無くてもよい流れ（プロフィール・組織をお作りになるとき）の入口です */
export async function userContext(): Promise<FlowResult<UserCtx>> {
  const deps = buildDeps(await getPorts());

  const user = await deps.ports.auth.getUser();
  if (user === null) return flowFail("unauthenticated");

  const lang = await getRequestLang(user.lang);
  return { ok: true, value: { ...deps, user, lang, now: new Date() } };
}

// ---- 見本のしくみ（STARTER_FAKE=1 のときだけ動きます） ----

export type DemoUser = { id: string; name: string; email: string; role: Role | null };

/** ログインの画面にお出しする「見本の方」の一覧です */
export async function fakeDemoUsers(): Promise<DemoUser[]> {
  const ports = requireFakePorts();

  const rows: DemoUser[] = [];
  for (const id of DEMO_USER_IDS) {
    const profile = await ports.data.getProfile(id);
    if (profile === null) continue;

    const organizations = await ports.data.listOrganizationsForUser(id);
    rows.push({
      id: profile.id,
      name: profile.name,
      email: profile.email,
      role: organizations[0]?.role ?? null,
    });
  }
  return rows;
}

/**
 * 見本の方でログインします（本物の認証のふりをするのは、この 1 か所だけです）。
 * お受けするのは、見本の 3 人の id だけです。
 */
export async function fakeSignInAs(userId: unknown): Promise<FlowResult<{ userId: string }>> {
  const ports = requireFakePorts();

  const chosen = validateChoice(userId, DEMO_USER_IDS, "userId");
  if (!chosen.ok) return flowFail("invalid", chosen.errors);

  ports.auth.signInAs(chosen.value);
  return { ok: true, value: { userId: chosen.value } };
}

function fakeCustomerId(organizationId: string): string {
  return `cus_fake_${organizationId}`;
}

/**
 * 偽の Checkout です。本物の Stripe が行うことを、そのままなぞります。
 *   ① お客さま（customer）をひもづける ② ご契約の通知（Webhook）をこちらへ届ける
 * 表に書くのは、本物と同じく applyWebhookFlow だけです。
 */
export async function fakeCompleteCheckout(input: {
  organizationId: string;
  planId: PlanId;
  now: Date;
}): Promise<void> {
  const ports = requireFakePorts();
  const stripeCustomerId = fakeCustomerId(input.organizationId);
  await ports.data.setStripeCustomer(input.organizationId, stripeCustomerId);

  const periodEnd = new Date(input.now.getTime() + FAKE_PERIOD_DAYS * 24 * 60 * 60 * 1000);
  await applyWebhookFlow({
    ports,
    payload: JSON.stringify({
      eventId: `evt_fake_${input.now.getTime()}`,
      eventType: "checkout.session.completed",
      change: {
        stripeCustomerId,
        row: {
          planId: input.planId,
          status: "active",
          stripeSubscriptionId: `sub_fake_${input.organizationId}`,
          currentPeriodEnd: periodEnd.toISOString(),
          cancelAtPeriodEnd: false,
          updatedAt: input.now.toISOString(),
        },
      },
    }),
    signature: "fake",
    now: input.now,
  });
}

/** 偽のお手続きの画面（Customer Portal）での、ご解約です */
export async function fakeCancelSubscription(input: {
  organizationId: string;
  now: Date;
}): Promise<void> {
  const ports = requireFakePorts();

  await applyWebhookFlow({
    ports,
    payload: JSON.stringify({
      eventId: `evt_fake_cancel_${input.now.getTime()}`,
      eventType: "customer.subscription.deleted",
      change: { stripeCustomerId: fakeCustomerId(input.organizationId), row: null },
    }),
    signature: "fake",
    now: input.now,
  });
}
