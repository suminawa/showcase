import "server-only";

/**
 * 決済の通知の受け口の、決まりごとです（道すじそのものは app/api/stripe/webhook/route.ts）。
 *
 * ここに置いてあるのは 2 つです。
 *   ① 本文の読み方（**JSON に直さず、そのままの文字で**。上限を超えたら途中で打ち切る）
 *   ② お返事の決まり（短い英語 1 行だけ。誤りの中身は 1 文字も外に出しません）
 *
 * お返事の番号には意味があります。
 *   2xx … 受け取りました（表に書いたかどうかは問いません）
 *   4xx … こちらでは扱えません。**送り直していただいても同じです**
 *   5xx … 一時的に写せませんでした。**送り直していただければ入ります**
 * flow は「確かめ → 適用 → 記録」の順に進むので、送り直しは安全です。
 */
import { billingErrorText, WEBHOOK_MAX_BYTES } from "../ports/billing";
import type { FlowResult } from "./context";

export { WEBHOOK_MAX_BYTES };

/** お返事の一覧です。中身は短い英語だけにしてあります */
const REPLIES = {
  accepted: { status: 200, body: "ok" },
  not_configured: { status: 503, body: "not configured" },
  too_large: { status: 413, body: "too large" },
  bad_signature: { status: 400, body: "bad signature" },
  failed: { status: 500, body: "retry later" },
  method_not_allowed: { status: 405, body: "method not allowed" },
} as const;

export type WebhookReplyName = keyof typeof REPLIES;

/** 決済の通知へのお返事を 1 つ作ります */
export function webhookReply(name: WebhookReplyName): Response {
  const reply = REPLIES[name];

  const headers = new Headers({
    "content-type": "text/plain; charset=utf-8",
    // 途中の取り置きに残さないための印です
    "cache-control": "no-store",
  });
  if (name === "method_not_allowed") headers.set("allow", "POST");

  return new Response(reply.body, { status: reply.status, headers });
}

/**
 * flow のお返事を、受け口のお返事に写します。
 *
 *   forbidden … 署名が通りませんでした（送り直していただいても同じです）
 *   invalid   … 本文が大きすぎました（同上）
 *   ほか      … こちらの取りこぼしです（送り直していただければ入ります）
 */
export function webhookReplyName(
  result: FlowResult<{ eventId: string; applied: boolean }>,
): WebhookReplyName {
  if (result.ok) return "accepted";
  if (result.code === "forbidden") return "bad_signature";
  if (result.code === "invalid") return "too_large";
  return "failed";
}

/**
 * 受け口で起きたことを、**記録にだけ**残します。
 *
 * お返事には 1 文字も出しません。とはいえ、まったく残さないと
 * 「通知が入らない」ときに、買い手が手がかりなしで探すことになります。
 * 残すのはサーバーの記録だけで、お客さまの画面には出ません。
 */
export function logWebhook(name: "not_configured" | "failed", error?: unknown): void {
  if (name === "not_configured") {
    console.error("決済の通知: STRIPE_WEBHOOK_SECRET がまだ入っていません");
    return;
  }

  // Stripe の誤りのときは、種類と符号だけを残します
  // （Stripe の文には、メールアドレスや id がそのまま入ることがあります）。
  console.error(`決済の通知: 表に写せませんでした（${billingErrorText(error)}）`);
}

export type WebhookBody = { ok: true; payload: string } | { ok: false };

/**
 * 決済の通知の本文を、**そのままの文字**で読みます。
 *
 * 署名は本文の 1 文字ずつに対して付いているので、JSON に直してから
 * 組み立て直した文字では確かめられません（空白や並びが変わります）。
 *
 * 大きさの上限は 2 段で効かせます。
 *   ① Content-Length が上限を超えていたら、本文をまったく読みません
 *   ② 申告が無い・偽っているときのために、**流れてくる分を数えて打ち切ります**
 */
export async function readWebhookBody(
  request: Request,
  maxBytes: number = WEBHOOK_MAX_BYTES,
): Promise<WebhookBody> {
  const declared = Number(request.headers.get("content-length") ?? "");
  if (Number.isFinite(declared) && declared > maxBytes) return { ok: false };

  const body = request.body;
  if (body === null) return { ok: true, payload: "" };

  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;

  for (;;) {
    const step = await reader.read();
    if (step.done) break;
    if (step.value === undefined) continue;

    total += step.value.byteLength;
    if (total > maxBytes) {
      // ここで読むのをやめます（上限より先は、1 バイトも受け取りません）
      await reader.cancel();
      return { ok: false };
    }
    chunks.push(step.value);
  }

  const joined = new Uint8Array(total);
  let at = 0;
  for (const chunk of chunks) {
    joined.set(chunk, at);
    at += chunk.byteLength;
  }

  return { ok: true, payload: new TextDecoder("utf-8").decode(joined) };
}
