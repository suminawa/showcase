/**
 * 法務の 3 枚の文面を、legal/ から読み込みます。
 *
 * 文面は素のテキストのまま置いてあり、お客さま（この土台をお使いになる方）が
 * エディタで書き換えられるようにしています。
 *
 * **読みに行く先は、下の 6 行の静的な表だけです。**
 * 名前を組み立てて読むと、Vercel などの「関数の形」で配られたときに
 * legal/ が隣になく、お客さまに 500 をお返ししてしまいます。
 * 一緒に配るお願いは next.config.ts の outputFileTracingIncludes にあり、
 * この表は「どこを読むのかが、組み立てのときに分かる形」を保つためのものです。
 *
 * 読む先の土台は、立ち上げた場所です。関数の形でも standalone でも、
 * 取り込みをお願いした legal/ はその隣に置かれます。
 *
 * 新しい言語を足されるときは、この表に 3 行と、next.config.ts の取り込みを
 * 見直してください（表に無いものは、読めません）。
 */
import "server-only";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { LEGAL } from "../../legal.config";
import type { Lang } from "../core/i18n";
import { parseLegal, type LegalBlock, type LegalDoc } from "../core/legal";

/**
 * 6 つの文面の読み方です。
 *
 * 1 行ずつ、ファイルの名前まで書き切ってあります。
 * 名前を組み立てて渡すと、組み立ての道具はどのファイルのことか分からず、
 * **この場所のすべて**を配る側に写します（配るものが重くなり、上限にかかります）。
 */
const SOURCES: Readonly<Record<string, () => string>> = {
  "tokushoho.ja": () => readFileSync(join(process.cwd(), "legal", "tokushoho.ja.txt"), "utf8"),
  "tokushoho.en": () => readFileSync(join(process.cwd(), "legal", "tokushoho.en.txt"), "utf8"),
  "terms.ja": () => readFileSync(join(process.cwd(), "legal", "terms.ja.txt"), "utf8"),
  "terms.en": () => readFileSync(join(process.cwd(), "legal", "terms.en.txt"), "utf8"),
  "privacy.ja": () => readFileSync(join(process.cwd(), "legal", "privacy.ja.txt"), "utf8"),
  "privacy.en": () => readFileSync(join(process.cwd(), "legal", "privacy.en.txt"), "utf8"),
};

const remembered = new Map<string, LegalBlock[]>();

/**
 * 1 枚分の文面です。まだお書きでない項目は、blank の文字でお出しします。
 *
 * remember は、読んだ結果を覚えておくかどうかです。
 * **本番のときだけ true** にしてください。お手元でお書きかえのあいだに覚えてしまうと、
 * 立ち上げ直すまで画面が変わらず、書き換えが効いていないように見えます。
 */
export function legalBlocks(
  doc: LegalDoc,
  lang: Lang,
  options: { blank: string; remember: boolean },
): LegalBlock[] {
  const key = `${doc}.${lang}`;

  if (options.remember) {
    const found = remembered.get(key);
    if (found !== undefined) return found;
  }

  /**
   * 表に無い言語のときは、**既定（日本語）の文面**でお出しします。
   *
   * 言語をお足しになると、`Lang` にも `messages/` にも行き渡ったあとで、
   * この表への 3 行だけが抜けます。そこで投げてしまうと、
   * ほかの画面は出るのに法務の 3 枚だけが 500 になり、原因が分かりません。
   * 文面が翻訳前のまま出るほうが、お客さまにとっても、お直しになる側にとっても親切です。
   * 記録には 1 行だけ残します（気づかないまま公開しないためです）。
   */
  let read = SOURCES[key];
  if (read === undefined) {
    console.warn(
      `法務の文面: ${key} の置き場がありません（src/server/legal.ts の SOURCES に 3 行お足しください）。` +
        "いまは日本語の文面をお出ししています",
    );
    read = SOURCES[`${doc}.ja`];
  }
  if (read === undefined) throw new Error(`legal: 文面の置き場がありません: ${key}`);

  const blocks = parseLegal(read(), LEGAL, { blank: options.blank });
  if (options.remember) remembered.set(key, blocks);
  return blocks;
}
