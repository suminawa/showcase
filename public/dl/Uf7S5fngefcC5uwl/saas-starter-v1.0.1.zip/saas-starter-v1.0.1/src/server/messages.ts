/**
 * 画面とメールの文を、言語ごとに 1 か所からお渡しします。
 *
 * 文そのものは messages/ja.json と messages/en.json にあります。
 * 部品の中に文を直に書かないでください（日本語と英語がずれてしまいます）。
 */
import en from "../../messages/en.json";
import ja from "../../messages/ja.json";
import type { Lang, Messages } from "../core/i18n";

const TABLE: Readonly<Record<Lang, Messages>> = {
  ja: ja as Messages,
  en: en as Messages,
};

/** その言語の文の一覧です。読むだけで、書き換えられません */
export function messagesFor(lang: Lang): Messages {
  return TABLE[lang];
}
