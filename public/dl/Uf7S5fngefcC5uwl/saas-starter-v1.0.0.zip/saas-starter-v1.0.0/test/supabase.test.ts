/**
 * 本物のデータベースを相手にした、つなぎ役（adapter）の検査です。
 *
 * ここは `npm test` では回りません（ローカルの Supabase が要るためです）。
 * `npm run test:rls` が、立ち上げてから回します。
 * つなぎ先と鍵が渡されていないときは、まるごと見送ります。
 *
 * 確かめているのは、メモリの見本で通っている流れが、**本物のつなぎ役でも
 * 同じように通るか**です。
 *   ご登録 → 組織 → ご招待 → 別の方がお受けになる → 役割の変更 →
 *   プロジェクトを上限まで → 上限のお知らせ → 消せる方と消せない方 →
 *   ほかの組織の ID には触れない → 最後のオーナーは外せない
 *
 * あわせて、つなぎ役だけの決まりも確かめます。
 *   - uuid の形でない ID は、データベースに投げずに「見つからない」を返すこと
 *   - ご契約の決済の番号は、一員の方の鍵では読めないこと
 *   - サーバーだけの表は、一員の方の鍵では読めないこと
 *   - 退会された方がお作りになったプロジェクトは、作成者の欄が空になること
 *   - ご登録の有無が、お返事から分からないこと
 */
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { beforeAll, describe, expect, it } from "vitest";
import { createSupabaseAuth } from "../src/adapters/supabase/auth";
import { createSupabaseData } from "../src/adapters/supabase/data";
import { hashInviteToken } from "../src/core/invitations";
import type { Ports, SessionUser } from "../src/ports";
import { buildCtx, type Ctx, type Deps } from "../src/server/context";
import { ensureProfileFlow, signUpFlow } from "../src/server/flows/auth";
import {
  acceptInvitationFlow,
  createInvitationFlow,
  listInvitationsFlow,
} from "../src/server/flows/invitations";
import { leaveOrganizationFlow, setMemberRoleFlow } from "../src/server/flows/members";
import { createOrganizationFlow } from "../src/server/flows/organizations";
import {
  createProjectFlow,
  deleteProjectFlow,
  listProjectsFlow,
} from "../src/server/flows/projects";
import { messagesFor } from "../src/server/messages";
import {
  createMemoryRateLimiter,
  INVITE_ACCEPT_LIMIT,
  INVITE_LIMIT,
  LOGIN_IP_LIMIT,
  LOGIN_LIMIT,
} from "../src/server/ratelimit";

const SUPABASE_URL = process.env.SUPABASE_URL ?? "";
const ANON_KEY = process.env.SUPABASE_ANON_KEY ?? "";
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";

/**
 * つなぎ先が、お手元のもの（127.0.0.1 か localhost）かどうかです。
 *
 * この検査は、行を作っては消します。公開のプロジェクトに向けてしまうと、
 * そちらの中身が変わります。**お手元でなければ、1 度もつながずにお止めします。**
 */
function isLocalHost(url: string): boolean {
  try {
    const host = new URL(url).hostname;
    return host === "127.0.0.1" || host === "localhost" || host === "::1" || host === "[::1]";
  } catch {
    return false;
  }
}

/**
 * つなぎ先と 2 つの鍵は、npm run test:rls が渡します。
 * 3 つそろっていないときは、この 1 本をまるごと見送ります
 * （どこかで動いている別の Supabase につないでしまわないようにするためです。
 * ローカルの鍵はどの土台でも同じ値なので、つなぎ先を決め打ちにはしません）。
 */
const CONFIGURED = SUPABASE_URL !== "" && ANON_KEY !== "" && SERVICE_KEY !== "";

// 見送るのではなく、はっきりお止めします（黙って通ると、向けた先が変わったことに気づけません）
if (CONFIGURED && !isLocalHost(SUPABASE_URL)) {
  throw new Error("この検査は、お手元の Supabase（127.0.0.1 か localhost）でだけ回せます");
}

const READY = CONFIGURED;

/** 見送るときは、読み込みで止まらないように形だけの値を使います（通信はしません） */
const PLACEHOLDER_URL = "http://127.0.0.1:1";
const PLACEHOLDER_KEY = "skipped";

const suite = describe.skipIf(!READY);

/** ローカルでだけ使う、見本の合言葉です */
const PASSWORD = "local-starter-8891";

/** 何度回しても前の行とぶつからないよう、1 回ごとに違う名前をお借りします */
const RUN = Math.random().toString(36).slice(2, 8);

function mail(name: string): string {
  return `adapter-${name}-${RUN}@example.com`;
}

const SITE_ORIGIN = "http://localhost:3020";
const NOW = new Date("2026-09-20T09:00:00.000Z");

function newClient(key: string): SupabaseClient {
  return createClient(READY ? SUPABASE_URL : PLACEHOLDER_URL, READY ? key : PLACEHOLDER_KEY, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      // お戻りの中身をすり替えられない形（PKCE）は、画面の側と同じにそろえます
      flowType: "pkce",
    },
  });
}

const service = newClient(SERVICE_KEY);

/** お支払いとメールの口は、この検査では使いません（設定が無いときのお返事にそろえます） */
const stubBilling: Ports["billing"] = {
  async createCheckoutUrl() {
    return { ok: false, code: "not_configured" };
  },
  async createPortalUrl() {
    return { ok: false, code: "not_configured" };
  },
  async readWebhook() {
    return { ok: false, code: "bad_signature" };
  },
};

const stubMail: Ports["mail"] = {
  async send() {
    return { ok: false, code: "not_configured" };
  },
};

type Actor = {
  email: string;
  client: SupabaseClient;
  ports: Ports;
  user: SessionUser;
};

const limits = {
  login: createMemoryRateLimiter(LOGIN_LIMIT),
  loginIp: createMemoryRateLimiter(LOGIN_IP_LIMIT),
  invite: createMemoryRateLimiter(INVITE_LIMIT),
  inviteAccept: createMemoryRateLimiter(INVITE_ACCEPT_LIMIT),
};

function portsFor(client: SupabaseClient): Ports {
  return {
    auth: createSupabaseAuth({ client, googleEnabled: true }),
    data: createSupabaseData({ client, service: () => service }),
    billing: stubBilling,
    mail: stubMail,
  };
}

/** ご登録をお済ませの方として、セッションを持ったつなぎ役をご用意します */
async function seatActor(email: string): Promise<Actor> {
  const created = await service.auth.admin.createUser({
    email,
    password: PASSWORD,
    email_confirm: true,
  });
  if (created.error !== null) throw new Error(`お迎えできませんでした: ${created.error.message}`);

  const client = newClient(ANON_KEY);
  const ports = portsFor(client);

  const signedIn = await ports.auth.signInWithPassword(email, PASSWORD);
  if (!signedIn.ok) throw new Error(`ログインできませんでした: ${signedIn.code}`);

  const user = await ports.auth.getUser();
  if (user === null) throw new Error("ログインの状態を読み取れませんでした");

  await ensureProfileFlow({ ports, user, now: NOW });

  return { email, client, ports, user };
}

function depsFor(actor: Actor): Deps {
  return { ports: actor.ports, siteOrigin: SITE_ORIGIN };
}

async function ctxFor(actor: Actor, organizationId: string): Promise<Ctx> {
  const built = await buildCtx({
    ...depsFor(actor),
    user: actor.user,
    organizationId,
    lang: "ja",
    now: NOW,
  });
  if (!built.ok) throw new Error(`関門を通れませんでした: ${built.code}`);
  return built.value;
}

let owner: Actor;
let guest: Actor;
let shiosai = "";
let nagisa = "";

suite("本物のデータベースを相手にした、つなぎ役", () => {
  beforeAll(async () => {
    owner = await seatActor(mail("owner"));
    guest = await seatActor(mail("guest"));
  }, 60_000);

  it("ログインした方を、認証の口から引き直せる", async () => {
    const user = await owner.ports.auth.getUser();
    expect(user?.email).toBe(owner.email);
    // お名前と言語は、プロフィールの行から引きます
    expect(user?.lang).toBe("ja");
  });

  it("組織をお作りになった方が、そのオーナーになる", async () => {
    const created = await createOrganizationFlow({
      ctx: { ...depsFor(owner), user: owner.user, lang: "ja", now: NOW },
      raw: { name: "しおさい設計室" },
    });
    expect(created.ok).toBe(true);
    if (!created.ok) return;

    shiosai = created.value.id;

    const membership = await owner.ports.data.getMembership(shiosai, owner.user.id);
    expect(membership?.role).toBe("owner");

    const mine = await owner.ports.data.listOrganizationsForUser(owner.user.id);
    expect(mine.map((row) => row.organization.id)).toContain(shiosai);
  });

  it("別の組織も、それぞれのオーナーとしてお作りになれる", async () => {
    const created = await createOrganizationFlow({
      ctx: { ...depsFor(guest), user: guest.user, lang: "ja", now: NOW },
      raw: { name: "なぎさ工房" },
    });
    expect(created.ok).toBe(true);
    if (!created.ok) return;
    nagisa = created.value.id;
  });

  it("無料のプランでは、3 件までお作りになれる", async () => {
    const ctx = await ctxFor(owner, shiosai);

    for (const name of ["海図の作成", "帆の仕立て", "舵の点検"]) {
      const made = await createProjectFlow({ ctx, raw: { name, note: "" } });
      expect(made.ok, name).toBe(true);
    }

    const rows = await listProjectsFlow({ ctx });
    expect(rows.ok && rows.value.projects.length).toBe(3);
  });

  it("4 件目は、上限のお知らせでお止めする", async () => {
    const ctx = await ctxFor(owner, shiosai);
    const made = await createProjectFlow({ ctx, raw: { name: "錨の手入れ", note: "" } });
    expect(made.ok).toBe(false);
    if (made.ok) return;
    expect(made.code).toBe("plan_limit");
  });

  it("上限は、お申し付けの数では緩められない", async () => {
    // 呼ぶ側が「100 件まで」と言い張っても、データベースが引き直した上限が効きます
    const made = await owner.ports.data.createProjectGuarded(
      { organizationId: shiosai, name: "増やせない試し", note: "", createdBy: owner.user.id },
      100,
    );
    expect(made).toBe("limit");
  });

  it("ご招待をお出しし、お受けいただくとメンバーに入る", async () => {
    const ctx = await ctxFor(owner, shiosai);
    const invited = await createInvitationFlow({
      ctx,
      raw: { email: guest.email, role: "member" },
      limiter: limits.invite,
      messages: messagesFor("ja"),
    });
    expect(invited.ok).toBe(true);
    if (!invited.ok) return;

    // 表に入るのはハッシュだけで、リンクの中の文字はそのまま残りません
    const token = invited.value.url.split("/invite/")[1] ?? "";
    expect(token).not.toBe("");
    expect(invited.value.invitation.tokenHash).toBe(hashInviteToken(token));

    const accepted = await acceptInvitationFlow({
      ports: guest.ports,
      user: guest.user,
      token,
      limiter: limits.inviteAccept,
      ip: "127.0.0.1",
      now: NOW,
    });
    expect(accepted.ok).toBe(true);
    if (!accepted.ok) return;
    expect(accepted.value.role).toBe("member");

    // 2 回目は、もうお受けになれません
    const again = await acceptInvitationFlow({
      ports: guest.ports,
      user: guest.user,
      token,
      limiter: limits.inviteAccept,
      ip: "127.0.0.1",
      now: NOW,
    });
    expect(again.ok).toBe(false);
  });

  it("ご招待の口を直に撃っても、役割と宛先の取り違えは通らない", async () => {
    // flow の守りが外れても、データベースの関数が同じ 3 つを止めます
    // （見本のしくみの側は test/flows/invitations.test.ts が同じ 3 件を撃っています）。
    const ctx = await ctxFor(owner, shiosai);
    const invited = await createInvitationFlow({
      ctx,
      raw: { email: mail("outsider"), role: "member" },
      limiter: limits.invite,
      messages: messagesFor("ja"),
    });
    expect(invited.ok).toBe(true);
    if (!invited.ok) return;

    const invitationId = invited.value.invitation.id;

    // 宛先の違う方（guest）は、お受けになれません
    expect(await guest.ports.data.acceptInvitation(invitationId, guest.user.id, "member")).toBe(
      "not_pending",
    );

    // 宛先の方をお迎えしても、ご招待の役割と違う役割では通りません
    const outsider = await seatActor(mail("outsider"));
    expect(
      await outsider.ports.data.acceptInvitation(invitationId, outsider.user.id, "owner"),
    ).toBe("not_pending");

    // ほかの方の代わりにお受けになることもできません（ST001）
    await expect(
      outsider.ports.data.acceptInvitation(invitationId, guest.user.id, "member"),
    ).rejects.toThrow("data: acceptInvitation");

    // ご招待は、使われないまま pending で残ります
    const still = await service
      .from("invitations")
      .select("status")
      .eq("id", invitationId)
      .maybeSingle();
    expect((still.data as { status?: string } | null)?.status).toBe("pending");

    // 役割を合わせれば、そのとおりに入ります
    expect(
      await outsider.ports.data.acceptInvitation(invitationId, outsider.user.id, "member"),
    ).toBe("ok");
    expect((await outsider.ports.data.getMembership(shiosai, outsider.user.id))?.role).toBe(
      "member",
    );

    // 片づけます（このあとの検査は、しおさい設計室の人数を当てにしています）
    expect(await owner.ports.data.removeMemberGuarded(shiosai, outsider.user.id)).toBe("ok");
    await service.auth.admin.deleteUser(outsider.user.id);
  }, 30_000);

  it("メンバーの一覧に、お名前とメールアドレスが並ぶ", async () => {
    const members = await owner.ports.data.listMembers(shiosai);
    expect(members.map((member) => member.email).sort()).toEqual([guest.email, owner.email].sort());
    expect(members.every((member) => member.name !== "")).toBe(true);
  });

  it("オーナーは、メンバーの役割を変えられる", async () => {
    const ctx = await ctxFor(owner, shiosai);
    const changed = await setMemberRoleFlow({
      ctx,
      raw: { userId: guest.user.id, role: "admin" },
    });
    expect(changed.ok).toBe(true);

    const membership = await owner.ports.data.getMembership(shiosai, guest.user.id);
    expect(membership?.role).toBe("admin");
  });

  it("ご招待の一覧は、オーナーと管理者だけがご覧になれる", async () => {
    const ownerView = await listInvitationsFlow({ ctx: await ctxFor(owner, shiosai) });
    expect(ownerView.ok).toBe(true);

    // いまは管理者なので、こちらもご覧になれます
    const guestView = await listInvitationsFlow({ ctx: await ctxFor(guest, shiosai) });
    expect(guestView.ok).toBe(true);
  });

  it("メンバーの方は、ほかの方がお作りになったものを消せない", async () => {
    // いったんメンバーにお戻りいただきます
    const ownerCtx = await ctxFor(owner, shiosai);
    await setMemberRoleFlow({ ctx: ownerCtx, raw: { userId: guest.user.id, role: "member" } });

    const projects = await owner.ports.data.listProjects(shiosai);
    const target = projects[0];
    expect(target).toBeDefined();
    if (target === undefined) return;

    const guestCtx = await ctxFor(guest, shiosai);
    const denied = await deleteProjectFlow({ ctx: guestCtx, raw: { projectId: target.id } });
    expect(denied.ok).toBe(false);
    if (denied.ok) return;
    expect(denied.code).toBe("forbidden");

    // 行は残っています（決まりの側でも止まっていることの確かめです）
    const direct = await guest.client.from("projects").delete().eq("id", target.id).select("id");
    expect(direct.data ?? []).toEqual([]);
    expect(await owner.ports.data.getProject(shiosai, target.id)).not.toBeNull();
  });

  it("ご自身がお作りになったものは、メンバーの方でも消せる", async () => {
    const guestCtx = await ctxFor(guest, shiosai);
    const projects = await owner.ports.data.listProjects(shiosai);

    // 3 件のうち 1 件を消してから、guest の方にお作りいただきます
    const first = projects[0];
    if (first !== undefined) {
      await deleteProjectFlow({ ctx: await ctxFor(owner, shiosai), raw: { projectId: first.id } });
    }

    const made = await createProjectFlow({
      ctx: await ctxFor(guest, shiosai),
      raw: { name: "潮見表の整理", note: "" },
    });
    expect(made.ok).toBe(true);
    if (!made.ok) return;

    const removed = await deleteProjectFlow({ ctx: guestCtx, raw: { projectId: made.value.id } });
    expect(removed.ok).toBe(true);
    expect(await owner.ports.data.getProject(shiosai, made.value.id)).toBeNull();
  });

  it("ほかの組織の ID をお渡しになっても、触れない", async () => {
    const made = await createProjectFlow({
      ctx: await ctxFor(guest, nagisa),
      raw: { name: "よその作り物", note: "" },
    });
    expect(made.ok).toBe(true);
    if (!made.ok) return;

    // しおさい設計室の関門で、なぎさ工房の行を消そうとしても届きません
    const ctx = await ctxFor(owner, shiosai);
    const denied = await deleteProjectFlow({ ctx, raw: { projectId: made.value.id } });
    expect(denied.ok).toBe(false);
    if (denied.ok) return;
    expect(denied.code).toBe("not_found");

    expect(await owner.ports.data.getProject(shiosai, made.value.id)).toBeNull();
    // 組織の関門そのものも通れません
    const outside = await buildCtx({
      ...depsFor(owner),
      user: owner.user,
      organizationId: nagisa,
      lang: "ja",
      now: NOW,
    });
    expect(outside.ok).toBe(false);
  });

  it("最後のオーナーは、ご自身では退会できない", async () => {
    const ctx = await ctxFor(owner, shiosai);
    const denied = await leaveOrganizationFlow({ ctx });
    expect(denied.ok).toBe(false);
    if (denied.ok) return;
    expect(denied.code).toBe("last_owner");

    // 立場の足りない道（表を直に消す）でも、引き金がお止めします
    const direct = await owner.client
      .from("memberships")
      .delete()
      .eq("organization_id", shiosai)
      .eq("user_id", owner.user.id)
      .select("user_id");
    expect(direct.error?.code).toBe("ST003");
  });

  it("uuid の形でない ID は、データベースに投げずに「見つからない」を返す", async () => {
    expect(await owner.ports.data.getProfile("abc")).toBeNull();
    expect(await owner.ports.data.getOrganization("abc")).toBeNull();
    expect(await owner.ports.data.getMembership("abc", owner.user.id)).toBeNull();
    expect(await owner.ports.data.getProject(shiosai, "abc")).toBeNull();
    expect(await owner.ports.data.getSubscription("abc")).toBeNull();
    expect(await owner.ports.data.getBillingSubscription("abc")).toBeNull();
    expect(await owner.ports.data.listProjects("abc")).toEqual([]);
    expect(await owner.ports.data.listMembers("abc")).toEqual([]);
    expect(await owner.ports.data.listInvitations("abc")).toEqual([]);
    expect(await owner.ports.data.countProjects("abc")).toBe(0);
    expect(await owner.ports.data.countOwners("abc")).toBe(0);
    expect(await owner.ports.data.changeMemberRole("abc", owner.user.id, "admin")).toBe("not_found");
    expect(await owner.ports.data.removeMemberGuarded("abc", owner.user.id)).toBe("not_found");
    expect(await owner.ports.data.acceptInvitation("abc", owner.user.id, "member")).toBe(
      "not_pending",
    );
  });

  it("ご契約の決済の番号は、一員の方の鍵では読めない", async () => {
    await owner.ports.data.upsertSubscription({
      organizationId: shiosai,
      planId: "standard",
      status: "active",
      stripeSubscriptionId: `sub_${RUN}`,
      currentPeriodEnd: "2026-10-20T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: "2026-09-20T00:00:00.000Z",
    });

    // 列そのものが開かれていません（* でも読めません）
    const denied = await owner.client
      .from("subscriptions")
      .select("stripe_subscription_id")
      .eq("organization_id", shiosai);
    expect(denied.error).not.toBeNull();
    expect(await owner.client.from("subscriptions").select("*").eq("organization_id", shiosai)).
      toHaveProperty("error.code");

    // 開かれている 6 つの列は、そのままご覧になれます
    const allowed = await owner.client
      .from("subscriptions")
      .select("organization_id, plan_id, status, current_period_end, cancel_at_period_end, updated_at")
      .eq("organization_id", shiosai)
      .maybeSingle();
    expect(allowed.error).toBeNull();
    expect((allowed.data as { plan_id?: string } | null)?.plan_id).toBe("standard");

    // 決済の通知の側（service role）では、番号まで読めます
    const row = await owner.ports.data.getBillingSubscription(shiosai);
    expect(row?.stripeSubscriptionId).toBe(`sub_${RUN}`);
  });

  it("画面がご覧になるご契約の口は、利用者の鍵で読む", async () => {
    // 一員の方には、プランと状態と期間だけが見えます
    const mine = await owner.ports.data.getSubscription(shiosai);
    expect(mine?.planId).toBe("standard");
    expect(mine?.status).toBe("active");
    // 決済の契約の番号は、この口では必ず空です
    expect(mine?.stripeSubscriptionId).toBeNull();

    // ほかの方も、一員でいらっしゃるあいだはご覧になれます
    const byMember = await guest.ports.data.getSubscription(shiosai);
    expect(byMember?.planId).toBe("standard");
    expect(byMember?.stripeSubscriptionId).toBeNull();

    // 一員でない組織の ID をお渡しになっても、行の出入りの決まりで 0 行になります
    expect(await owner.ports.data.getSubscription(nagisa)).toBeNull();
  });

  it("立場が足りないときの rpc は、握りつぶさずに例外になる", async () => {
    // ST001: メンバーの方は、役割を変えられません
    await expect(
      guest.ports.data.changeMemberRole(shiosai, owner.user.id, "member"),
    ).rejects.toThrow("data: changeMemberRole");
    await expect(guest.ports.data.removeMemberGuarded(shiosai, owner.user.id)).rejects.toThrow(
      "data: removeMemberGuarded",
    );

    // ST002: 管理者の方でも、オーナーの行には触れません
    expect(await owner.ports.data.changeMemberRole(shiosai, guest.user.id, "admin")).toBe("ok");
    await expect(
      guest.ports.data.changeMemberRole(shiosai, owner.user.id, "member"),
    ).rejects.toThrow("data: changeMemberRole");
    await expect(guest.ports.data.removeMemberGuarded(shiosai, owner.user.id)).rejects.toThrow(
      "data: removeMemberGuarded",
    );
    // オーナーに上げることもできません
    await expect(
      guest.ports.data.changeMemberRole(shiosai, guest.user.id, "owner"),
    ).rejects.toThrow("data: changeMemberRole");

    // 役割をお戻しします（このあとの検査のためです）
    expect(await owner.ports.data.changeMemberRole(shiosai, guest.user.id, "member")).toBe("ok");
    // オーナーの行は、どちらの道でもそのままです
    expect((await owner.ports.data.getMembership(shiosai, owner.user.id))?.role).toBe("owner");
  });

  it("ご契約が入ると、上限が増える", async () => {
    const ctx = await ctxFor(owner, shiosai);
    expect(ctx.billing.planId).toBe("standard");

    const made = await createProjectFlow({ ctx, raw: { name: "追加の 1 件", note: "" } });
    expect(made.ok).toBe(true);
  });

  it("サーバーだけの表と口は、一員の方の鍵では通らない", async () => {
    const events = await owner.client.from("stripe_events").select("id");
    expect(events.error).not.toBeNull();

    const customers = await owner.client.from("stripe_customers").select("organization_id");
    expect(customers.error).not.toBeNull();

    // 決済の通知が使う 3 つは、service role でだけ通ります
    expect(await owner.ports.data.recordStripeEvent({
      id: `evt_${RUN}`,
      type: "checkout.session.completed",
      receivedAt: NOW.toISOString(),
    })).toBe(true);
    expect(await owner.ports.data.hasStripeEvent(`evt_${RUN}`)).toBe(true);
    // 同じ通知をもう一度いただいても、入りません
    expect(await owner.ports.data.recordStripeEvent({
      id: `evt_${RUN}`,
      type: "checkout.session.completed",
      receivedAt: NOW.toISOString(),
    })).toBe(false);

    await owner.ports.data.setStripeCustomer(shiosai, `cus_${RUN}`);
    expect(await owner.ports.data.findOrganizationByStripeCustomer(`cus_${RUN}`)).toBe(shiosai);
  });

  it("決済の通知が 2 本の接続から同時に届いても、あとに残るのは新しいほうの状態", async () => {
    /**
     * 本物の置き場では、2 つの通知が**別々の接続**として同時に走ります。
     * 「いまの行を読む → 比べる → 書く」を 2 回に分けていると、どちらも同じ古い行を読み、
     * 古いほうがあとから書けてしまいます（ご解約のあとも有料のプランの上限のままです）。
     * ここでは本当に 2 本つないで、届く順を入れ替えても結果が変わらないことを見ます。
     */
    const BASE = "2026-09-20T11:00:00.000Z";
    const OLD = "2026-09-20T12:00:00.000Z";
    const NEW = "2026-09-20T12:00:30.000Z";
    const SUB = `sub_race_${RUN}`;

    // つなぎ役も、その下のつなぎ口も別々にします（同じ接続を使い回しません）
    const left = createSupabaseData({
      client: newClient(ANON_KEY),
      service: () => newClient(SERVICE_KEY),
    });
    const right = createSupabaseData({
      client: newClient(ANON_KEY),
      service: () => newClient(SERVICE_KEY),
    });

    for (const order of ["古い順", "新しい順"] as const) {
      // はじめの状態にお戻しします（ご契約が 1 本、生きている状態です）
      await owner.ports.data.upsertSubscription({
        organizationId: nagisa,
        planId: "standard",
        status: "active",
        stripeSubscriptionId: SUB,
        currentPeriodEnd: "2026-10-20T00:00:00.000Z",
        cancelAtPeriodEnd: false,
        updatedAt: BASE,
      });

      // 古いほう: お支払いの失敗（取り直した時刻は 12:00:00）
      const stale = () =>
        left.applySubscriptionChange({
          organizationId: nagisa,
          row: {
            planId: "standard",
            status: "past_due",
            stripeSubscriptionId: SUB,
            currentPeriodEnd: "2026-10-20T00:00:00.000Z",
            cancelAtPeriodEnd: false,
            updatedAt: OLD,
          },
          now: OLD,
        });

      // 新しいほう: ご解約（受け取った時刻は 12:00:30）
      const fresh = () =>
        right.applySubscriptionChange({ organizationId: nagisa, row: null, now: NEW });

      const both = order === "古い順" ? [stale, fresh] : [fresh, stale];
      await Promise.all(both.map((send) => send()));

      const row = await owner.ports.data.getBillingSubscription(nagisa);
      expect(row?.status, order).toBe("canceled");
      expect(row?.planId, order).toBe("free");
      expect(new Date(row?.updatedAt ?? 0).toISOString(), order).toBe(NEW);
      // あとからお調べになれるよう、決済の契約の番号と期間の終わりは残ります
      expect(row?.stripeSubscriptionId, order).toBe(SUB);
      expect(new Date(row?.currentPeriodEnd ?? 0).toISOString(), order).toBe(
        "2026-10-20T00:00:00.000Z",
      );
    }

    // 古い通知は、あとから届いても表を触りません
    expect(
      await left.applySubscriptionChange({
        organizationId: nagisa,
        row: {
          planId: "business",
          status: "active",
          stripeSubscriptionId: SUB,
          currentPeriodEnd: "2026-10-20T00:00:00.000Z",
          cancelAtPeriodEnd: false,
          updatedAt: OLD,
        },
        now: OLD,
      }),
    ).toBe(false);
    expect((await owner.ports.data.getBillingSubscription(nagisa))?.planId).toBe("free");

    // 一度もご契約のない組織には、ご解約の行を作りません
    await service.from("subscriptions").delete().eq("organization_id", nagisa);
    expect(
      await left.applySubscriptionChange({ organizationId: nagisa, row: null, now: NEW }),
    ).toBe(false);
    expect(await owner.ports.data.getBillingSubscription(nagisa)).toBeNull();
  });

  it("決済の通知の関数は、時刻の無い行を例外にせず、書かずに false を返す", async () => {
    // 例外にすると受け口が 500 を返し続け、決済の側の送り直しが収束しません
    const before = await owner.ports.data.getBillingSubscription(shiosai);
    const result = await service.rpc("apply_subscription_change", {
      p_organization_id: shiosai,
      p_row: { plan_id: "business", status: "active" },
      p_now: NOW.toISOString(),
    });
    expect(result.error).toBeNull();
    expect(result.data).toBe(false);
    expect(await owner.ports.data.getBillingSubscription(shiosai)).toEqual(before);
  });

  it("決済の通知の関数は、一員の方の鍵では呼べない", async () => {
    // service role だけに開いています（ログイン中のどなたでも呼べては困ります）
    const denied = await owner.client.rpc("apply_subscription_change", {
      p_organization_id: shiosai,
      p_row: null,
      p_now: NOW.toISOString(),
    });
    expect(denied.error).not.toBeNull();
  });

  it("ご契約が続いているあいだは、組織を消せない", async () => {
    await expect(owner.ports.data.deleteOrganization(shiosai)).rejects.toThrow(
      "data: deleteOrganization",
    );
  });

  it("退会された方がお作りになったものは、作成者の欄が空で返る", async () => {
    const leaver = await seatActor(mail("leaver"));

    const org = await createOrganizationFlow({
      ctx: { ...depsFor(leaver), user: leaver.user, lang: "ja", now: NOW },
      raw: { name: "ひとりの工房" },
    });
    expect(org.ok).toBe(true);
    if (!org.ok) return;

    const made = await createProjectFlow({
      ctx: await ctxFor(leaver, org.value.id),
      raw: { name: "置き土産", note: "" },
    });
    expect(made.ok).toBe(true);
    if (!made.ok) return;
    expect(made.value.createdBy).toBe(leaver.user.id);

    const removed = await service.auth.admin.deleteUser(leaver.user.id);
    expect(removed.error).toBeNull();

    // 行は残り、作成者の欄だけが空になります（service role で確かめます）
    const after = await service
      .from("projects")
      .select("id, organization_id, name, note, created_by, created_at, updated_at")
      .eq("id", made.value.id)
      .maybeSingle();
    expect(after.error).toBeNull();
    expect((after.data as { created_by: string | null } | null)?.created_by).toBeNull();
  });

  it("まだご登録のないメールアドレスへのログインのリンクは、お送りしたときと同じお返事", async () => {
    // お作りしない決まり（shouldCreateUser: false）のため認証の口は誤りを返しますが、
    // つなぎ役は「お送りしました」と同じお返事に包みます。
    const unknown = await owner.ports.auth.sendMagicLink(
      mail("nobody"),
      `${SITE_ORIGIN}/auth/callback`,
    );
    expect(unknown).toEqual({ ok: true });
  });

  it("すでにご登録のメールアドレスでも、ご登録の有無は外に出ない", async () => {
    // ご登録は、いつもまっさらなつなぎ口から承ります
    // （ご登録のあとはセッションを残さないため、ほかの検査の方を巻き込まないようにします）。
    const ports = portsFor(newClient(ANON_KEY));

    // はじめてのメールアドレスは、そのままお受けします
    const fresh = await ports.auth.signUpWithPassword(
      mail("fresh"),
      PASSWORD,
      `${SITE_ORIGIN}/auth/callback`,
    );
    expect(fresh).toEqual({ ok: true });

    // すでにご登録のメールアドレスのときに、認証の口がお返しするものは
    // 設定（確認のメールをお使いかどうか）で変わります。
    //   中身を伏せたお返事 … そのまま ok
    //   すでにご登録の旨   … email_taken（画面の流れが「お送りしました」に伏せます）
    // **この 2 とおり以外にはなりません。**
    // unavailable などに落ちると、符号の写しができていないことになります。
    const taken = await ports.auth.signUpWithPassword(
      owner.email,
      PASSWORD,
      `${SITE_ORIGIN}/auth/callback`,
    );
    expect(taken.ok ? "ok" : taken.code).toMatch(/^(ok|email_taken)$/);

    // 画面の流れまで通すと、どちらの場合も同じお返事になります
    const flow = await signUpFlow({
      ports,
      siteOrigin: SITE_ORIGIN,
      raw: { email: owner.email, password: PASSWORD },
      limiter: limits.login,
      ipLimiter: limits.loginIp,
      ip: "127.0.0.1",
      now: NOW,
    });
    expect(flow.ok && flow.value.sent).toBe(true);
  });

  it("見本のデータづくりの口は、本物のつなぎ役では使えない", async () => {
    // どちらも service role で表を直に書く口で、画面の流れは 1 度も使いません。
    // 本物で残しておくと、決まりを通らない書き込みの道が開いたままになります。
    await expect(
      owner.ports.data.createOrganizationWithOwner({
        name: "使わない組織",
        userId: owner.user.id,
      }),
    ).rejects.toThrow("data: createOrganizationWithOwner");

    await expect(owner.ports.data.addMember(shiosai, guest.user.id, "member")).rejects.toThrow(
      "data: addMember",
    );

    // 行は 1 つも増えていません
    const organizations = await owner.ports.data.listOrganizationsForUser(owner.user.id);
    expect(organizations.map((row) => row.organization.name)).not.toContain("使わない組織");
  });

  it("1 行も変わらない書き込みは、黙って終わらない", async () => {
    // その組織にいらっしゃらない方の役割は、変えられません
    await expect(
      owner.ports.data.setMemberRole(shiosai, "00000000-0000-4000-8000-000000000000", "admin"),
    ).rejects.toThrow("data: setMemberRole");

    // すでにお受けいただいた招待は、取り消せません
    const invitations = await owner.ports.data.listInvitations(shiosai);
    const accepted = invitations.find((row) => row.status === "accepted");
    expect(accepted).toBeDefined();
    if (accepted === undefined) return;

    await expect(owner.ports.data.revokeInvitation(shiosai, accepted.id)).rejects.toThrow(
      "data: revokeInvitation",
    );
    // 状態は、お受けいただいたままです
    const after = await owner.ports.data.listInvitations(shiosai);
    expect(after.find((row) => row.id === accepted.id)?.status).toBe("accepted");
  });

  it("ご登録の直後に、セッションを残さない", async () => {
    // ご登録の直後にそのまま入れてしまうと、「入れたかどうか」で
    // そのメールアドレスのご登録の有無が分かってしまいます。
    // 確認のメールをお使いでない設定では認証の口がその場でセッションをお返しするので、
    // つなぎ役がその場で閉じます（ログインは、あらためてログインの画面から承ります）。
    const client = newClient(ANON_KEY);
    const auth = createSupabaseAuth({ client, googleEnabled: false });

    const created = await auth.signUpWithPassword(
      mail("nosession"),
      PASSWORD,
      `${SITE_ORIGIN}/auth/callback`,
    );
    expect(created).toEqual({ ok: true });

    // 確認のメールをお使いの設定でも、お使いでない設定でも、ここは空のままです
    expect((await client.auth.getSession()).data.session).toBeNull();
    expect(await auth.getUser()).toBeNull();

    // すでにご登録のメールアドレスでも、同じく残りません
    const again = createSupabaseAuth({ client: newClient(ANON_KEY), googleEnabled: false });
    await again.signUpWithPassword(owner.email, PASSWORD, `${SITE_ORIGIN}/auth/callback`);
    expect(await again.getUser()).toBeNull();
  });

  it("合言葉が違うときは、その旨の符号を返す", async () => {
    const client = newClient(ANON_KEY);
    const auth = createSupabaseAuth({ client, googleEnabled: false });

    const wrong = await auth.signInWithPassword(owner.email, "chigau-aikotoba-0000");
    expect(wrong.ok).toBe(false);
    if (wrong.ok) return;
    expect(wrong.code).toBe("bad_credentials");
  });

  it("Google の入り口は、環境変数がそろっているときだけお出しする", async () => {
    const off = createSupabaseAuth({ client: newClient(ANON_KEY), googleEnabled: false });
    expect(await off.oauthStartUrl("google", `${SITE_ORIGIN}/auth/callback`)).toBeNull();

    const on = createSupabaseAuth({ client: newClient(ANON_KEY), googleEnabled: true });
    const url = await on.oauthStartUrl("google", `${SITE_ORIGIN}/auth/callback`);
    expect(url).not.toBeNull();
    if (url === null) return;

    // お戻りの中身をすり替えられない形（PKCE）で始まり、戻り先は土台から組みます
    const parsed = new URL(url);
    expect(parsed.searchParams.get("provider")).toBe("google");
    expect(parsed.searchParams.get("code_challenge")).not.toBeNull();
    expect(parsed.searchParams.get("redirect_to")).toBe(`${SITE_ORIGIN}/auth/callback`);
  });

  it("知らない種類のリンクは、そのまま渡さずにお止めする", async () => {
    const auth = createSupabaseAuth({ client: newClient(ANON_KEY), googleEnabled: false });

    expect(await auth.completeSignIn({})).toEqual({ ok: false, code: "unavailable" });
    expect(await auth.completeSignIn({ tokenHash: "abc", type: "sql" })).toEqual({
      ok: false,
      code: "unavailable",
    });

    const badCode = await auth.completeSignIn({ code: "not-a-real-code" });
    expect(badCode.ok).toBe(false);
  });

  it("管理の一覧は、どの組織にも属さない立場で読める", async () => {
    const organizations = await owner.ports.data.adminListOrganizations(100, 0);
    const found = organizations.find((row) => row.organization.id === shiosai);
    expect(found).toBeDefined();
    expect(found?.memberCount).toBeGreaterThanOrEqual(2);
    expect(found?.planId).toBe("standard");

    const profiles = await owner.ports.data.adminListProfiles(100, 0);
    expect(profiles.some((profile) => profile.email === owner.email)).toBe(true);

    const subscriptions = await owner.ports.data.adminListSubscriptions(100, 0);
    const contract = subscriptions.find((row) => row.organizationId === shiosai);
    expect(contract).toBeDefined();
    // 組織のお名前は、ご契約の行が自分で持ちます（同じページに組織が並ぶとはかぎりません）
    expect(contract?.organizationName).toBe("しおさい設計室");
    // 決済の契約の番号は、欄そのものがありません（列を選ばずに読んでいます）
    expect(JSON.stringify(subscriptions)).not.toContain("sub_");
    expect(Object.keys(contract ?? {})).not.toContain("stripeSubscriptionId");

    // 0 件以下をお求めになったときは、何もお返ししません
    expect(await owner.ports.data.adminListOrganizations(0, 0)).toEqual([]);
    expect(await owner.ports.data.adminListProfiles(0, 0)).toEqual([]);
    expect(await owner.ports.data.adminListSubscriptions(-1, 0)).toEqual([]);
  });

  it("管理の一覧の件数は、1 回のお返事の上限を超えても数え落とさない", async () => {
    // データベースは 1 回のお返事に上限（config.toml の max_rows = 1000）を置いています。
    // 数えるための問い合わせがそこで切られると、件数が 1000 で止まってしまいます。
    const counter = await seatActor(mail("counter"));
    const created = await createOrganizationFlow({
      ctx: { ...depsFor(counter), user: counter.user, lang: "ja", now: NOW },
      raw: { name: "数えきれない工房" },
    });
    expect(created.ok).toBe(true);
    if (!created.ok) return;

    const rows = Array.from({ length: 1001 }, (_, index) => ({
      organization_id: created.value.id,
      name: `見本の作り物 ${index + 1}`,
      note: "",
      created_by: counter.user.id,
    }));
    const inserted = await service.from("projects").insert(rows);
    expect(inserted.error).toBeNull();

    const list = await owner.ports.data.adminListOrganizations(100, 0);
    const found = list.find((row) => row.organization.id === created.value.id);
    expect(found?.projectCount).toBe(1001);
    expect(found?.memberCount).toBe(1);
  });
});
