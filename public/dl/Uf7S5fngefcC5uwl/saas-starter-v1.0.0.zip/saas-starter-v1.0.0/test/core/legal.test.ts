/**
 * 法務のひな形（特定商取引法に基づく表記・利用規約・プライバシーポリシー）の検査です。
 *
 * ここで守っているのは 4 つです。
 *   1. 素のテキストを、画面にそのまま写せる形（h2・p・ul・dl）に読み替えられる
 *   2. 書き忘れ（空のままの項目）が、画面で分かる
 *   3. 6 つの文面に、必要な見出しがすべてある
 *   4. 見本に、実在の会社・住所・電話番号と、内部の呼び名が混じっていない
 */
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { describe, expect, it, vi } from "vitest";
import { LEGAL, type LegalConfig } from "../../legal.config";
import {
  LEGAL_DOCS,
  LEGAL_KEYS,
  legalFileName,
  missingLegalKeys,
  parseLegal,
  type LegalDoc,
} from "../../src/core/legal";
import { legalBlocks } from "../../src/server/legal";
import type { Lang } from "../../src/core/i18n";
import {
  INTERNAL_PATHS,
  INTERNAL_WORDS,
  REAL_WORLD_NAMES,
  WORK_IN_PROGRESS_MARKS,
} from "../helpers/forbidden";

function sourceOf(doc: LegalDoc, lang: Lang): string {
  return readFileSync(new URL(`../../legal/${legalFileName(doc, lang)}`, import.meta.url), "utf8");
}

/**
 * 英語の 3 枚に、そのまま差し込んでいる項目です。
 * 事業者のお名前・ご住所・お電話・メールアドレスは、訳すものではありません。
 */
const INTERPOLATED_IN_EN: readonly (keyof LegalConfig)[] = [
  "serviceName",
  "sellerName",
  "representative",
  "address",
  "phone",
  "email",
  "privacyContact",
];

/**
 * 英語の 3 枚に、**手で書き下ろしている**項目です（差し込んでいません）。
 *
 * 日本語だけを書き換えると、英語のページだけが古いまま残ります。
 * 下のハッシュがずれたら、legal/*.en.txt の 3 枚も手で直してください。
 * updatedOn は英語の文面には出ませんが、日付を新しくなさるということは
 * 文面を直されたということですので、あわせて 3 枚の見直しをお願いしています。
 */
const HAND_WRITTEN_IN_EN: readonly (keyof LegalConfig)[] = [
  "contactHours",
  "priceNote",
  "extraCharges",
  "paymentMethods",
  "paymentTiming",
  "deliveryTiming",
  "refundPolicy",
  "governingLaw",
  "updatedOn",
];

/**
 * 上の 9 つの値をつないだものの、SHA-256 です。
 * 日本語を書き換えると、ここで落ちます（英語の 3 枚の見直しのお願いです）。
 */
const HAND_WRITTEN_HASH = "85992d55bb5f34ba70f875573e12de38c543218bb33b94b48893cef6e33a32d0";

/**
 * ひな形の文面に、1 つも出てきてはいけない言葉です。
 *
 * 内部の呼び名・手元の道すじ・書きかけの印・実在の地名は、
 * `test/helpers/forbidden.ts` が文字コードから組み立てたものをそのまま使います
 * （字のまま書くと、この検査のファイル自身が配布物の見張りに引っかかります）。
 * ここに書き足しているのは、法務の文面でだけ困る 4 つです。
 */
const FORBIDDEN: readonly string[] = [
  ...INTERNAL_WORDS,
  ...INTERNAL_PATHS,
  ...WORK_IN_PROGRESS_MARKS,
  ...REAL_WORLD_NAMES,
  "株式会社",
  "合同会社",
  "suminawa",
  "墨縄",
];

/** 特定商取引法に基づく表記に、必ず要る見出しです */
const TOKUSHOHO_HEADINGS: readonly string[] = [
  "販売事業者",
  "運営統括責任者",
  "所在地",
  "電話番号",
  "メールアドレス",
  "販売価格",
  "商品代金以外の必要料金",
  "お支払い方法",
  "お支払いの時期",
  "サービスのご提供時期",
  "返品・キャンセルについて",
  "動作環境",
];

const TERMS_HEADINGS: readonly string[] = [
  "第 1 条（適用）",
  "第 2 条（アカウントの登録）",
  "第 3 条（禁止事項）",
  "第 4 条（料金と支払い）",
  "第 5 条（サービスの停止）",
  "第 6 条（免責）",
  "第 7 条（お客さまのデータの取り扱い）",
  "第 8 条（規約の変更）",
  "第 9 条（準拠法と管轄）",
];

const PRIVACY_HEADINGS: readonly string[] = [
  "取得する情報",
  "利用の目的",
  "第三者への提供",
  "外部のサービスの利用",
  "保管の期間",
  "開示・訂正・削除のご請求",
  "Cookie の利用",
  "お問い合わせ先",
];

describe("配るときに、6 つの文面がついてくる形", () => {
  const server = readFileSync(new URL("../../src/server/legal.ts", import.meta.url), "utf8");
  const nextConfig = readFileSync(new URL("../../next.config.ts", import.meta.url), "utf8");
  const page = readFileSync(new URL("../../app/legal/_document.tsx", import.meta.url), "utf8");

  it("読みに行く先が、6 行の静的な表になっている", () => {
    // ファイルの名前をその場で組み立てると、組み立ての道具は
    // どのファイルのことか分からず、配る先に付いてくるかどうかが運任せになります。
    // 6 つとも名前まで書き切っておくと、道具が「この 6 つも要る」と気づけます。
    for (const doc of LEGAL_DOCS) {
      for (const lang of ["ja", "en"] as const) {
        const line = `join(process.cwd(), "legal", "${legalFileName(doc, lang)}")`;
        expect(server, line).toContain(line);
      }
    }
  });

  it("ファイルの名前を、その場で組み立てていない", () => {
    expect(server).not.toContain("legalFileName(");
    // 差し込みでファイルの名前を作る形（`${...}.txt`）も残していません
    expect(server).not.toMatch(/\$\{[^}]*\}\.txt/);
  });

  it("組み立ての取り込みに、法務のページと 6 つの文面が書いてある", () => {
    expect(nextConfig).toContain("outputFileTracingIncludes");
    expect(nextConfig).toContain('"/legal/*": ["./legal/*.txt"]');
  });

  it("6 つとも、実際に読めて段落になる", () => {
    for (const doc of LEGAL_DOCS) {
      for (const lang of ["ja", "en"] as const) {
        const blocks = legalBlocks(doc, lang, { blank: "（未記入）", remember: false });
        expect(blocks.length, `${doc}.${lang}`).toBeGreaterThanOrEqual(5);
      }
    }
  });

  it("表に無い言語のときは、500 にせず日本語の文面でお出しする", () => {
    // 言語をお足しになると、SOURCES への 3 行だけが抜けます。
    // そこで投げると、ほかの画面は出るのに法務の 3 枚だけが 500 になります。
    const warned = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      const fresh = { blank: "（未記入）", remember: false };
      const unknown = legalBlocks("terms", "fr" as Lang, fresh);
      expect(unknown).toEqual(legalBlocks("terms", "ja", fresh));
      // 気づかないまま公開しないよう、記録には 1 行残します
      expect(warned).toHaveBeenCalledTimes(1);
      expect(String(warned.mock.calls[0]?.[0] ?? "")).toContain("terms.fr");
    } finally {
      warned.mockRestore();
    }
  });

  it("覚えておくのは、覚えるようお願いしたときだけ", () => {
    // お手元でお書きかえのあいだに覚えてしまうと、立ち上げ直すまで画面が変わりません
    const options = { blank: "（未記入）", remember: true };
    const first = legalBlocks("terms", "ja", options);
    expect(legalBlocks("terms", "ja", options)).toBe(first);

    const fresh = { blank: "（未記入）", remember: false };
    expect(legalBlocks("privacy", "ja", fresh)).not.toBe(legalBlocks("privacy", "ja", fresh));
  });

  it("画面は、本番のときだけ覚えておくようお願いしている", () => {
    expect(page).toContain("remember: isProduction()");
  });
});

describe("parseLegal", () => {
  it("見出しと段落に分ける", () => {
    expect(parseLegal("## 見出し\n\n本文です。", LEGAL)).toEqual([
      { kind: "h2", text: "見出し" },
      { kind: "p", text: "本文です。" },
    ]);
  });

  it("続いた「- 」の行を、1 つの箇条書きにまとめる", () => {
    expect(parseLegal("- ねこ\n- いぬ", LEGAL)).toEqual([
      { kind: "ul", items: ["ねこ", "いぬ"] },
    ]);
  });

  it("「用語: 本文」の並びを、定義の並びにして差し込む", () => {
    expect(parseLegal("所在地: {{address}}\n電話番号: {{phone}}", LEGAL)).toEqual([
      {
        kind: "dl",
        rows: [
          { term: "所在地", text: LEGAL.address },
          { term: "電話番号", text: LEGAL.phone },
        ],
      },
    ]);
  });

  it("空行をはさむと、別の固まりになる", () => {
    expect(parseLegal("- ねこ\n\n- いぬ", LEGAL)).toEqual([
      { kind: "ul", items: ["ねこ"] },
      { kind: "ul", items: ["いぬ"] },
    ]);
  });

  it("買い手あての覚え書き（# で始まる行）は、画面に出さない", () => {
    expect(parseLegal("# ここは書き換えてください\n\n本文です。", LEGAL)).toEqual([
      { kind: "p", text: "本文です。" },
    ]);
  });

  it("知らない差し込みがあれば、黙って空にせず知らせる", () => {
    expect(() => parseLegal("所在地: {{unknown}}", LEGAL)).toThrow(/unknown/);
  });

  it("空のままの項目は、「（未記入）」と出す", () => {
    const blank: LegalConfig = { ...LEGAL, address: "", phone: "   " };
    expect(parseLegal("所在地: {{address}}\n電話番号: {{phone}}", blank)).toEqual([
      {
        kind: "dl",
        rows: [
          { term: "所在地", text: "（未記入）" },
          { term: "電話番号", text: "（未記入）" },
        ],
      },
    ]);
  });

  it("空のままの項目の出し方は、言語に合わせて変えられる", () => {
    const blank: LegalConfig = { ...LEGAL, address: "" };
    expect(parseLegal("Address: {{address}}", blank, { blank: "(not filled in)" })).toEqual([
      { kind: "dl", rows: [{ term: "Address", text: "(not filled in)" }] },
    ]);
  });
});

describe("missingLegalKeys", () => {
  it("空のままの項目だけを返す", () => {
    expect(missingLegalKeys({ ...LEGAL, phone: "", email: "   " })).toEqual(["phone", "email"]);
  });

  it("見本は、すべて埋まっている", () => {
    expect(missingLegalKeys(LEGAL)).toEqual([]);
    for (const key of LEGAL_KEYS) expect(LEGAL[key].trim(), key).not.toBe("");
  });

  it("LEGAL_KEYS に、設定の項目がすべて入っている", () => {
    expect([...LEGAL_KEYS].sort()).toEqual(Object.keys(LEGAL).sort());
  });
});

describe("6 つの文面", () => {
  const FILES = LEGAL_DOCS.flatMap((doc) =>
    (["ja", "en"] as const).map((lang) => ({ doc, lang, name: legalFileName(doc, lang) })),
  );

  it("名前の付け方が「種類.言語.txt」である", () => {
    expect(legalFileName("tokushoho", "ja")).toBe("tokushoho.ja.txt");
    expect(FILES).toHaveLength(6);
  });

  it("6 つとも読めて、例外なく段落に分かれる", () => {
    for (const file of FILES) {
      const blocks = parseLegal(sourceOf(file.doc, file.lang), LEGAL);
      expect(blocks.length, file.name).toBeGreaterThanOrEqual(5);
    }
  });

  it("お客さまに見える文に、差し込みの記号が残らない", () => {
    for (const file of FILES) {
      const blocks = parseLegal(sourceOf(file.doc, file.lang), LEGAL);
      expect(JSON.stringify(blocks), file.name).not.toContain("{{");
    }
  });

  it("ひな形のお断りは、ファイルの頭の覚え書きに書き、画面には出さない", () => {
    // お客さま（サービスの利用者）に「これはひな形です」とお見せする用はありません。
    // 気づいていただきたいのは、この土台をお買い上げくださった方です。
    for (const file of FILES) {
      const source = sourceOf(file.doc, file.lang);
      const head = source.split("\n").filter((line) => line.startsWith("# ")).join("\n");

      expect(head, file.name).toMatch(file.lang === "ja" ? /専門家/ : /lawyer/);
      expect(head, file.name).toMatch(file.lang === "ja" ? /ひな形/ : /template/);

      const shown = JSON.stringify(parseLegal(source, LEGAL));
      expect(shown, file.name).not.toContain("ひな形");
      expect(shown, file.name).not.toContain("template");
    }
  });

  it("英語の 3 枚は、日本語が正であることを最後に添えている", () => {
    for (const doc of LEGAL_DOCS) {
      const blocks = parseLegal(sourceOf(doc, "en"), LEGAL);
      const last = blocks[blocks.length - 1];
      expect(JSON.stringify(last), doc).toContain("the Japanese text prevails");
    }
  });

  it("特定商取引法の表記に、12 の項目がすべてある", () => {
    const headings = parseLegal(sourceOf("tokushoho", "ja"), LEGAL)
      .filter((block) => block.kind === "h2")
      .map((block) => block.text);
    const missing = TOKUSHOHO_HEADINGS.filter((heading) => !headings.includes(heading));
    expect(missing).toEqual([]);
  });

  it("特定商取引法の表記が、月々のご契約のことを書いている（自動更新・解約・日割り）", () => {
    const shown = JSON.stringify(parseLegal(sourceOf("tokushoho", "ja"), LEGAL));
    for (const word of ["自動で更新", "解約", "日割り"]) expect(shown, word).toContain(word);
  });

  it("利用規約に、9 つの条がすべてある", () => {
    const headings = parseLegal(sourceOf("terms", "ja"), LEGAL)
      .filter((block) => block.kind === "h2")
      .map((block) => block.text);
    expect(headings).toEqual([...TERMS_HEADINGS]);
  });

  it("プライバシーポリシーに、8 つの見出しがすべてある", () => {
    const headings = parseLegal(sourceOf("privacy", "ja"), LEGAL)
      .filter((block) => block.kind === "h2")
      .map((block) => block.text);
    const missing = PRIVACY_HEADINGS.filter(
      (heading) => !headings.some((found) => found.startsWith(heading)),
    );
    expect(missing).toEqual([]);
  });

  it("プライバシーポリシーが、この土台が実際に扱うものだけを書いている", () => {
    const shown = JSON.stringify(parseLegal(sourceOf("privacy", "ja"), LEGAL));
    // 預かるもの・預けるお相手は、書いてあるとおりです
    for (const word of ["Supabase", "Stripe", "Resend", "メールアドレス"]) {
      expect(shown, word).toContain(word);
    }
    // 作っていない機能を、あるように書きません（「使っておりません」と書くのはかまいません）
    for (const word of ["アクセス解析", "広告の配信", "同意バナー", "Google Analytics"]) {
      expect(shown, word).not.toContain(word);
    }
  });

  it("プライバシーポリシーが、この土台に無い機能を約束していない", () => {
    // 画面から消せるのは組織だけで、アカウントそのものを消す画面はありません。
    // 「アカウントを削除したら消去します」と書くと、できないお約束になります。
    const ja = sourceOf("privacy", "ja");
    expect(ja).not.toContain("アカウントまたは組織を削除なさった場合");
    expect(ja).toContain("組織を削除なさった場合は、法令で保存が求められるものを除き、消去いたします。");
    expect(ja).toContain(
      "アカウントの削除をご希望の場合は、下記のお問い合わせ先までご連絡ください。",
    );

    const en = sourceOf("privacy", "en");
    expect(en).not.toContain("When you delete your account or your organization");
    expect(en).toContain("ask us");
  });

  it("利用規約が、解約したあとのデータの行き先まで書いている", () => {
    // 「解約したら消えるのか」は、お申し込みの前にいちばん気になるところです。
    const ja = sourceOf("terms", "ja");
    expect(ja).toContain("解約後も、ご登録のデータは消去いたしません。");
    expect(ja).toContain("無料のプランの上限でお使いいただけます。");

    const en = sourceOf("terms", "en");
    expect(en.toLowerCase()).toContain("free plan");
  });

  it("販売価格の書き方が、実際にお値段が載っている場所を指している", () => {
    // 料金だけの独立したページはありません。トップページの「料金」に並んでいます。
    expect(LEGAL.priceNote).toContain("トップページ");
    expect(LEGAL.priceNote).toContain("料金");
    expect(LEGAL.priceNote).not.toContain("ページに記載しております");

    const en = sourceOf("tokushoho", "en");
    expect(en.toLowerCase()).toContain("home page");
    expect(en.toLowerCase()).not.toContain("pricing page");
  });

  it("差し込む 7 つと、手で写す 9 つで、設定の項目がすべて説明できている", () => {
    expect([...INTERPOLATED_IN_EN, ...HAND_WRITTEN_IN_EN].sort()).toEqual([...LEGAL_KEYS].sort());
  });

  it("英語の 3 枚に差し込んでいるのは、訳す必要のない 7 つだけ", () => {
    const english = LEGAL_DOCS.map((doc) => sourceOf(doc, "en")).join("\n");
    for (const key of INTERPOLATED_IN_EN) expect(english, key).toContain(`{{${key}}}`);
    for (const key of HAND_WRITTEN_IN_EN) expect(english, key).not.toContain(`{{${key}}}`);
  });

  it("手で写している 9 つの値が、日本語だけ変わっていない", () => {
    const source = HAND_WRITTEN_IN_EN.map((key) => `${key}=${LEGAL[key]}`).join("\n");
    const digest = createHash("sha256").update(source, "utf8").digest("hex");

    expect(
      digest,
      "legal.config.ts の値を変えられたようです。legal/*.en.txt の 3 枚も手で直してから、" +
        "この番人のハッシュを新しい値に置き換えてください（英語のページだけが古いまま残るのを防ぐためです）。",
    ).toBe(HAND_WRITTEN_HASH);
  });

  it("実在の会社・住所・電話番号と、内部の呼び名が入っていない", () => {
    const offenders: string[] = [];
    for (const file of FILES) {
      const source = sourceOf(file.doc, file.lang);
      for (const word of FORBIDDEN) {
        if (source.includes(word)) offenders.push(`${file.name}: ${word}`);
      }
      if (/0\d{1,3}-\d{2,4}-\d{3,4}/.test(source)) offenders.push(`${file.name}: 電話番号`);
      if (/〒\d{3}-\d{4}/.test(source)) offenders.push(`${file.name}: 郵便番号`);
    }
    expect(offenders).toEqual([]);
  });

  it("見本のメールアドレスは、example.com のものだけ", () => {
    for (const file of FILES) {
      for (const found of sourceOf(file.doc, file.lang).match(/[\w.+-]+@[\w.-]+/g) ?? []) {
        expect(found.endsWith("@example.com"), `${file.name}: ${found}`).toBe(true);
      }
    }
  });
});
