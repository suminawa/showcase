/**
 * 配布 zip の中身と、README に書いた決まりが、本当のコードと合っているかを見張ります。
 *
 * ここが緑なら、買い手のお手元に届く zip は
 *   ① 要るものがそろっていて、
 *   ② 入ってはいけないもの（内部の語・手元の道すじ・本物の .env・生の制御文字）が入っておらず、
 *   ③ README に書いたコマンドと環境変数が、package.json と .env.example と同じ
 * ということになります。
 *
 * 生の制御文字は `test/no-control-chars.test.ts` も見ていますが、あちらは
 * **配るファイルの一覧**を、種類で飛ばさずに歩きます。
 *
 * ## 配る側だけの決まりについて
 *
 * この中のいくつかは、**この土台を配るため**の決まりです
 * （見本の文に実在の地名が混ざっていないか、依存パッケージが決めた数のままか、など）。
 * お買い上げののち、自社の住所をお入れになったり、Tailwind をお足しになったりすると、
 * そのままでは赤くなってしまいます。そちらは `npm run release:check` のときだけ回し、
 * `npm test` には**お客さまのアプリについての確かめ**だけを残しています。
 */
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, readdirSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  RELEASE_REQUIRED,
  createRelease,
  releaseFileList,
  releaseFolderName,
  releaseMissing,
} from "../scripts/release.mjs";
import {
  INTERNAL_PATHS,
  INTERNAL_WORDS,
  REAL_WORLD_NAMES,
  WORK_IN_PROGRESS_MARKS,
  foundWords,
  hasRawControlChar,
} from "./helpers/forbidden";

const ROOT = fileURLToPath(new URL("../", import.meta.url));

function read(relative: string): string {
  return readFileSync(join(ROOT, relative), "utf8");
}

const readmeJa = read("README.ja.md");
const readmeEn = read("README.en.md");
const license = read("LICENSE.md");
const changelog = read("CHANGELOG.md");
const envExample = read(".env.example");
const packageJson = JSON.parse(read("package.json")) as {
  version: string;
  scripts: Record<string, string>;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
};

/**
 * その入れ物の下の検査の件数を数えます（`it(` で始まる行の数です）。
 * vitest の中から vitest を回さずに、README に書いた件数を見張るための数え方です。
 */
function countTests(dir: string, skip: ReadonlySet<string>): number {
  let found = 0;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      found += countTests(join(dir, entry.name), skip);
      continue;
    }
    if (!entry.name.endsWith(".test.ts") || skip.has(entry.name)) continue;
    const text = readFileSync(join(dir, entry.name), "utf8");
    found += (text.match(/^\s*it\(/gm) ?? []).length;
  }
  return found;
}

const RELEASE_LIST = releaseFileList(ROOT);

/**
 * 配る側（この土台をお届けする側）の決まりを回すかどうかです。
 *
 * `npm run release:check` と `npm run release` が `RELEASE_GATE=1` を立てます。
 * お客さまの `npm test` では立っていないので、下の 6 件は何も確かめずに終わります。
 * **お客さまのアプリを止めるための決まりではありません。**
 */
const RELEASE_GATE = process.env.RELEASE_GATE === "1";

/** 中身を字で読むファイルの種類です（画像や書庫は入っていません） */
const TEXT_EXTENSIONS = [
  ".ts",
  ".tsx",
  ".mjs",
  ".js",
  ".json",
  ".sql",
  ".css",
  ".md",
  ".txt",
  ".toml",
  ".html",
  ".rsc",
  ".example",
  ".gitignore",
];

function isTextFile(relative: string): boolean {
  return TEXT_EXTENSIONS.some((extension) => relative.endsWith(extension));
}

// ---- 1. zip に入るファイルの一覧 ---------------------------------------------

describe("配布 zip に入るもの", () => {
  it("要るものが 1 つも欠けていない", () => {
    expect(releaseMissing(ROOT)).toEqual([]);
    for (const required of RELEASE_REQUIRED) {
      expect(RELEASE_LIST, required).toContain(required);
    }
  });

  it("画面・流れ・つなぎ役・検査・道具が、ひととおり入っている", () => {
    for (const required of [
      "app/page.tsx",
      "app/layout.tsx",
      "app/globals.css",
      "app/admin/page.tsx",
      "app/api/stripe/webhook/route.ts",
      "src/core/permissions.ts",
      "src/ports/data.ts",
      "src/adapters/fake/data.ts",
      "src/adapters/supabase/data.ts",
      "src/adapters/stripe/webhook.ts",
      "src/server/ports.ts",
      "src/server/flows/billing.ts",
      "supabase/config.toml",
      "supabase/tests/rls_test.sql",
      "supabase/templates/confirmation.html",
      "scripts/check-bundle.mjs",
      "scripts/run-rls.mjs",
      "scripts/release.mjs",
      "test/package-files.test.ts",
      "test/helpers/forbidden.ts",
    ]) {
      expect(RELEASE_LIST, required).toContain(required);
    }
  });

  it("入れてはいけないものが入っていない", () => {
    for (const relative of RELEASE_LIST) {
      const parts = relative.split("/");
      for (const part of parts) {
        for (const banned of [
          "node_modules",
          ".next",
          ".git",
          ".vercel",
          ".DS_Store",
          "release",
          "next-env.d.ts",
          "tsconfig.tsbuildinfo",
          ".branches",
          ".temp",
        ]) {
          expect(part, relative).not.toBe(banned);
        }
      }

      const name = parts[parts.length - 1] ?? "";
      if (name.startsWith(".env")) expect(name, relative).toBe(".env.example");
    }
  });

  it("package-lock.json は入れる（お手元で同じ版が入るようにするため）", () => {
    expect(RELEASE_LIST).toContain("package-lock.json");
  });

  it("並びは決まっていて、同じ道すじが 2 回入らない", () => {
    expect(releaseFileList(ROOT)).toEqual(RELEASE_LIST);
    expect(new Set(RELEASE_LIST).size).toBe(RELEASE_LIST.length);
  });

  it("いちばん外側のフォルダの名前は saas-starter-v… である", () => {
    expect(releaseFolderName(ROOT)).toBe(`saas-starter-v${packageJson.version}`);
    expect(releaseFolderName(ROOT).startsWith("saas-starter-v")).toBe(true);
  });
});

// ---- 2. 実際に zip を作って、中身を読み直す ------------------------------------

/** zip・unzip がこの手元にあるか（無ければ、その 1 件だけを飛ばします） */
function hasZipTools(): boolean {
  try {
    execFileSync("zip", ["-h"], { stdio: "ignore" });
    execFileSync("unzip", ["-h"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

describe("実際に作った zip", () => {
  it("中身が、一覧のとおり 1 つのフォルダに収まっている", (context) => {
    if (!hasZipTools()) {
      context.skip();
      return;
    }

    const dir = mkdtempSync(join(tmpdir(), "saas-release-"));
    try {
      const made = createRelease(ROOT, join(dir, "check.zip"));
      expect(made.bytes).toBeGreaterThan(0);
      expect(made.files).toBe(RELEASE_LIST.length);

      const listed = execFileSync("unzip", ["-Z1", made.zipPath], { encoding: "utf8" })
        .split("\n")
        .map((line) => line.trim())
        .filter((line) => line !== "" && !line.endsWith("/"));

      const folder = releaseFolderName(ROOT);
      expect(listed).toEqual(RELEASE_LIST.map((relative) => `${folder}/${relative}`));
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

// ---- 3. zip に入るどのファイルにも、内部の語・生の制御文字が無い --------------------

describe("配る前の見張り", () => {
  it("見に行く先に、配布するファイルが並んでいる", () => {
    expect(RELEASE_LIST.length).toBeGreaterThan(100);
  });

  it("内部の語・手元の道すじ・書きかけの印が、1 つも入っていない", () => {
    // 配る側の決まりです（書きかけの印や、お手元の道すじは、お客さまのアプリでは自由です）
    if (!RELEASE_GATE) return;
    const offenders: string[] = [];
    for (const relative of RELEASE_LIST) {
      if (!isTextFile(relative)) continue;
      const text = read(relative);
      for (const words of [INTERNAL_WORDS, INTERNAL_PATHS, WORK_IN_PROGRESS_MARKS]) {
        for (const found of foundWords(text, words)) offenders.push(`${relative}: ${found}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it("見本の文に、実在の会社名・人名・市名が混ざっていない", () => {
    // 配る側の決まりです（お客さまは、legal.config.ts に自社の住所をお書きになります）
    if (!RELEASE_GATE) return;
    const offenders: string[] = [];
    for (const relative of RELEASE_LIST) {
      if (!isTextFile(relative)) continue;
      for (const found of foundWords(read(relative), REAL_WORLD_NAMES)) {
        offenders.push(`${relative}: ${found}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it("生の制御文字が、1 つも入っていない", () => {
    const offenders = RELEASE_LIST.filter(
      (relative) => isTextFile(relative) && hasRawControlChar(read(relative)),
    );
    expect(offenders).toEqual([]);
  });
});

// ---- 4. README の章立て -------------------------------------------------------

/** README の見出し（`## …`）を、出てくる順に並べます */
function headings(readme: string): string[] {
  return readme
    .split("\n")
    .filter((line) => line.startsWith("## "))
    .map((line) => line.trim());
}

/** README の 1 章ぶんを取り出します（次の `## ` の手前まで） */
function section(readme: string, heading: string): string {
  const after = readme.split(`\n${heading}\n`)[1];
  expect(after, heading).toBeDefined();
  return (after ?? "").split("\n## ")[0] ?? "";
}

const JA_HEADINGS = [
  "## 1. 何ができるか",
  "## 2. 作らなかったもの",
  "## 3. zip の中身",
  "## 4. まず見本モードで触る",
  "## 5. フォルダの地図",
  "## 6. Supabase につなぐ",
  "## 7. Stripe につなぐ",
  "## 8. メール",
  "## 9. 法務のひな形",
  "## 10. プランを変える",
  "## 11. 機能を足す",
  "## 12. 見た目を変える",
  "## 13. 言語",
  "## 14. 運営の画面",
  "## 15. 守りの決まり",
  "## 16. 検査",
  "## 17. 本番に置く前の点検",
  "## 18. 費用の目安",
  "## 19. 困ったとき",
  "## 20. ほかのキットと組み合わせる",
  "## 21. ライセンスとサポート",
];

describe("README の章立て", () => {
  it("日本語の README に、決めた章が決めた順で並んでいる", () => {
    const found = headings(readmeJa);
    let at = -1;
    for (const heading of JA_HEADINGS) {
      const index = found.indexOf(heading);
      expect(index, heading).toBeGreaterThan(at);
      at = index;
    }
  });

  it("英語の README の章の数が、日本語と同じ", () => {
    expect(headings(readmeEn).length).toBe(headings(readmeJa).length);
    expect(headings(readmeEn).length).toBe(JA_HEADINGS.length);
  });

  it("法務のひな形の章に、保証しない旨と専門家へのご案内がある", () => {
    const legal = section(readmeJa, "## 9. 法務のひな形");
    expect(legal).toContain("保証");
    expect(legal.includes("弁護士") || legal.includes("専門家")).toBe(true);
  });

  it("費用の章に、出どころの URL が 4 つ以上ある", () => {
    const cost = section(readmeJa, "## 18. 費用の目安");
    const links = cost.match(/https:\/\/[^\s)）」`]+/g) ?? [];
    expect(new Set(links).size).toBeGreaterThanOrEqual(4);
  });
});

// ---- 5. README とコードのつき合わせ ---------------------------------------------

describe("README と、本当のコード", () => {
  it("README が書いている npm のコマンドは、すべて package.json にある", () => {
    // README との突き合わせは、配る側の決まりです（お客さまが release 系の 2 つをお外しになっても赤くしません）
    if (!RELEASE_GATE) return;
    const scripts = Object.keys(packageJson.scripts);
    const offenders: string[] = [];

    for (const [label, readme] of [
      ["README.ja.md", readmeJa],
      ["README.en.md", readmeEn],
    ] as const) {
      for (const found of readme.matchAll(/npm run ([a-z][a-z0-9:-]*)/g)) {
        const name = found[1] ?? "";
        if (!scripts.includes(name)) offenders.push(`${label}: npm run ${name}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it("package.json のコマンドは、どちらの README にも書いてある", () => {
    // 配る側の決まりです（お客さまがコマンドをお足しになっても、README は自由です）
    if (!RELEASE_GATE) return;
    for (const name of Object.keys(packageJson.scripts)) {
      if (name === "test:watch") continue; // 見守りながら回す形は、README では触れていません
      const written = name === "test" ? "npm test" : `npm run ${name}`;
      expect(readmeJa, written).toContain(written);
      expect(readmeEn, written).toContain(written);
    }
  });

  /** .env.example に並んでいる環境変数の名前です */
  function envNames(): string[] {
    return envExample
      .split("\n")
      .map((line) => /^([A-Z][A-Z0-9_]*)=/.exec(line.trim())?.[1])
      .filter((name): name is string => name !== undefined);
  }

  /**
   * この土台の環境変数ではないけれど、README に出てよい名前です。
   * Supabase のコマンドと Node が読むもので、`.env.example` には置きません。
   */
  const OTHER_TOOLS_ENV = [
    "NODE_ENV",
    "SUPABASE_AUTH_EXTERNAL_GOOGLE_CLIENT_ID",
    "SUPABASE_AUTH_EXTERNAL_GOOGLE_SECRET",
  ];

  it(".env.example の環境変数が、どちらの README にも書いてある", () => {
    // 配る側の決まりです（お客さまが環境変数をお足しになっても、README は自由です）
    if (!RELEASE_GATE) return;
    const names = envNames();
    expect(names.length).toBeGreaterThanOrEqual(13);
    for (const name of names) {
      expect(readmeJa, name).toContain(name);
      expect(readmeEn, name).toContain(name);
    }
  });

  it("README に、.env.example に無い環境変数が出てこない", () => {
    // 配る側の決まりです（同上）
    if (!RELEASE_GATE) return;
    const allowed = new Set([...envNames(), ...OTHER_TOOLS_ENV]);
    const offenders: string[] = [];

    for (const [label, readme] of [
      ["README.ja.md", readmeJa],
      ["README.en.md", readmeEn],
    ] as const) {
      for (const found of readme.matchAll(
        /`(STARTER_[A-Z0-9_]+|NEXT_PUBLIC_[A-Z0-9_]+|SUPABASE_[A-Z0-9_]+|STRIPE_[A-Z0-9_]+|RESEND_[A-Z0-9_]+|MAIL_[A-Z0-9_]+|ADMIN_[A-Z0-9_]+)`/g,
      )) {
        const name = found[1] ?? "";
        if (!allowed.has(name)) offenders.push(`${label}: ${name}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it("依存パッケージは、決めた 7 つと 5 つのままである", () => {
    // 配る側の決まりです（お客さまは Tailwind などをお足しになれます。README 12 章）
    if (!RELEASE_GATE) return;
    expect(Object.keys(packageJson.dependencies).sort()).toEqual([
      "@supabase/ssr",
      "@supabase/supabase-js",
      "next",
      "react",
      "react-dom",
      "resend",
      "stripe",
    ]);
    expect(Object.keys(packageJson.devDependencies).sort()).toEqual([
      "@types/node",
      "@types/react",
      "@types/react-dom",
      "typescript",
      "vitest",
    ]);
  });
});

// ---- 6. LICENSE と CHANGELOG ----------------------------------------------------

describe("利用許諾と更新履歴", () => {
  it("利用許諾に、決めた項目が書いてある", () => {
    for (const word of ["再配布", "転売", "14 日", "1.x", "hello@suminawa.dev", "日本法"]) {
      expect(license, word).toContain(word);
    }
  });

  it("利用許諾に、法務のひな形を保証しない項がある", () => {
    expect(license).toContain("ひな形");
    expect(license.includes("弁護士") || license.includes("専門家")).toBe(true);
  });

  it("利用許諾に英訳が添えてあり、食い違いは日本語を優先すると書いてある", () => {
    expect(license).toContain("Licence (SaaS Starter Kit)");
    expect(license).toContain("the Japanese text prevails");
  });

  it("README と更新履歴の検査の件数が、実際の数とそろっている", () => {
    // 配る側の決まりです（お客さまが検査をお足しになっても、README は自由です）
    if (!RELEASE_GATE) return;

    // npm test が回すファイルだけを数えます（Supabase の要る 2 本は外します）
    const skip = new Set(["rls.test.ts", "supabase.test.ts"]);
    const counted = countTests(join(ROOT, "test"), skip);

    // 書いてある数は 5 か所です（README 2 冊に 2 か所ずつと、更新履歴に 1 か所）
    const written = [readmeJa, readmeEn, changelog].flatMap((text) =>
      [...text.matchAll(/(\d{3,4})\s*(?:件|tests)/g)].map((found) => Number(found[1])),
    );
    expect(written.length).toBeGreaterThanOrEqual(5);
    for (const number of written) {
      // 件数の書いてあるところは、検査の件数か、行の出入りの決まりの件数です
      if (number < 100) continue;
      expect(number, `${number} 件と書いてあります（実際は ${counted} 件です）`).toBe(counted);
    }
  });

  it("更新履歴に、この版の節がある", () => {
    // 版の番号と日付の突き合わせは、配る側の決まりです（お客さまが版をお上げになっても赤くしません）
    if (!RELEASE_GATE) return;
    expect(changelog).toContain("## 1.0.0 — 2026-10-06");
    expect(changelog).toContain(`## ${packageJson.version} — 2026-10-06`);
  });
});
