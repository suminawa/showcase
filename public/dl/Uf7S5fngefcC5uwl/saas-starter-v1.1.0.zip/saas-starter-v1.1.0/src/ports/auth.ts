import type { Lang } from "../core/i18n";

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  lang: Lang;
};

export type AuthErrorCode =
  | "bad_credentials"
  | "email_taken"
  | "not_confirmed"
  | "rate_limited"
  | "wrong_browser"
  | "password_rejected"
  | "unavailable";

export type AuthResult = { ok: true } | { ok: false; code: AuthErrorCode };

export type OAuthProvider = "google";

export interface AuthPort {
  /** いまログインしている方。いなければ null */
  getUser(): Promise<SessionUser | null>;
  /** メールのリンク（OTP）をお送りする */
  sendMagicLink(email: string, redirectTo: string): Promise<AuthResult>;
  signInWithPassword(email: string, password: string): Promise<AuthResult>;
  signUpWithPassword(email: string, password: string, redirectTo: string): Promise<AuthResult>;
  signOut(): Promise<void>;
  /** 環境変数がそろっていなければ null。画面はそのときボタンを出さない */
  oauthStartUrl(provider: OAuthProvider, redirectTo: string): Promise<string | null>;
  /** メールのリンク・OAuth から戻ってきたときに、この方のセッションを立てる */
  completeSignIn(input: { code?: string; tokenHash?: string; type?: string }): Promise<AuthResult>;
  /**
   * パスワードの再設定のメールをお送りする。
   * ご登録のないメールアドレスでも、お送りしたときと同じお返事にする（ご登録の有無を漏らさない）。
   * redirectTo は、メールのリンクから戻ってくる先（/auth/callback?next=/reset-password）。
   */
  sendPasswordReset(email: string, redirectTo: string): Promise<AuthResult>;
  /**
   * いまログインしている方のパスワードを変える。
   * 変えたあと、**ほかの端末のセッションをすべて閉じる**（いまの端末だけ残す）。
   */
  updatePassword(password: string): Promise<AuthResult>;
  /**
   * いまログインしている方の、いまのパスワードを確かめる（本人の確かめ直し）。
   * 合っていれば ok、違えば bad_credentials。パスワードをお持ちでない方も bad_credentials。
   */
  verifyPassword(email: string, password: string): Promise<AuthResult>;
  /**
   * いまのセッションが、maxAgeSeconds 以内に**メールで本人と確かめて**立てたものか
   * （再設定のリンク・ログインのリンク）。署名を確かめた中身（JWT の amr）だけを見る。
   * パスワードをお持ちでない方と、再設定のリンクからお戻りの方の、確かめ直しの代わりに使う。
   */
  recentEmailSignIn(maxAgeSeconds: number): Promise<boolean>;
}
