/**
 * 監査ログ（組織の操作の記録）の種類です。
 *
 * 本物のデータベースでは、表の引き金が書きます（supabase/migrations/…_audit_logs.sql）。
 * 画面の流れからは書きません。引き金なら、どの道から表を書き換えても記録が残り、
 * 一員の方が記録を書き足したり消したりすることもできないためです。
 * 見本のしくみ（src/adapters/fake/）は、同じ場面で同じ種類を書きます。
 *
 * この一覧は、SQL の check 制約と同じ顔ぶれです（test/audit.test.ts が突き合わせます）。
 */

export type AuditAction =
  | "member.role_changed"
  | "member.removed"
  | "member.left"
  | "invitation.created"
  | "invitation.revoked"
  | "invitation.accepted"
  | "billing.changed"
  | "account.deleted";

export const AUDIT_ACTIONS: readonly AuditAction[] = [
  "member.role_changed",
  "member.removed",
  "member.left",
  "invitation.created",
  "invitation.revoked",
  "invitation.accepted",
  "billing.changed",
  "account.deleted",
] as const;

export function isAuditAction(value: unknown): value is AuditAction {
  return typeof value === "string" && (AUDIT_ACTIONS as readonly string[]).includes(value);
}

export type AuditLogRow = {
  id: string;
  organizationId: string;
  /** 操作した方。決済の通知など、ログインした方のいない操作と、退会された方は null です */
  actorId: string | null;
  /**
   * 誰の操作か。user はログインした方、system はログインした方のいない操作
   * （決済の通知・service role の処理・Studio での手直し）です。
   */
  actorType: "user" | "system";
  /** 操作した方のお名前。見えないとき（組織を抜けられた方など）は null です */
  actorName: string | null;
  action: AuditAction;
  /** 相手のメールアドレス（ご招待・メンバーの操作）。無いときは空の文字です */
  target: string;
  /** 役割・プラン・状態などの添え書き。値はすべて文字です */
  detail: Record<string, string>;
  createdAt: string;
};

/** 画面にお出しする件数の上限です */
export const AUDIT_LOG_PAGE_SIZE = 100;
