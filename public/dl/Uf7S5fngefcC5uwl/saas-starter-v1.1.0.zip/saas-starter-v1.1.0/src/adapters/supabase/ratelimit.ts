/**
 * 回数の上限を、データベース（rate_limits の表）で数える口です。
 *
 * メモリで数える形は、サーバーが複数台あると台ごとに数え直しになり、
 * Vercel のような置き方では上限がほとんど効きません。ここで数えれば、
 * どの台から来たお申し付けも同じ 1 つの数に足されます。
 *
 * 数えるところと書くところは、SQL の関数 rate_limit_hit の 1 回の呼び出しの中です
 * （同時に 11 回届いても、11 回目は必ず止まります）。
 * この関数を呼べるのは service role だけです（ログインの前に数えるためです）。
 *
 * 誤りの中身は持ち回りません。数えられなかったときは例外にします
 * （黙って通すと、データベースが止まっているあいだ上限が無くなるためです）。
 */
import type { SupabaseClient } from "@supabase/supabase-js";

export type RateLimitCount = (input: {
  key: string;
  limit: number;
  windowSeconds: number;
  now: Date;
}) => Promise<{ allowed: boolean; retryAfterSeconds: number }>;

export function createSupabaseRateLimitCount(service: () => SupabaseClient): RateLimitCount {
  let client: SupabaseClient | null = null;

  return async (input) => {
    client ??= service();
    const { data, error } = await client.rpc("rate_limit_hit", {
      p_key: input.key,
      p_limit: input.limit,
      p_window_seconds: input.windowSeconds,
      p_now: input.now.toISOString(),
    });
    if (error !== null) throw new Error("data: rateLimitHit");

    const row = (typeof data === "object" && data !== null ? data : {}) as Record<string, unknown>;
    if (typeof row.allowed !== "boolean" || typeof row.retry_after_seconds !== "number") {
      throw new Error("data: rateLimitHit");
    }
    return { allowed: row.allowed, retryAfterSeconds: row.retry_after_seconds };
  };
}
