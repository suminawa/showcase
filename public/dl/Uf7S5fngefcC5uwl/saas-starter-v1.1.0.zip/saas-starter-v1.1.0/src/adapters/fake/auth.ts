import type { AuthPort, AuthResult, OAuthProvider, SessionUser } from "../../ports/auth";
import type { FakeStore } from "./store";

/**
 * ログインは「見本の人を選ぶ」だけです（owner・admin・member の 3 人）。
 * セッションは store.sessionUserId 1 つだけで持ちます。
 */
export class FakeAuth implements AuthPort {
  constructor(private readonly store: FakeStore) {}

  /** テストと fake の画面が使う、「見本の人を選ぶ」ための入り口 */
  signInAs(userId: string): void {
    this.store.sessionUserId = userId;
  }

  async getUser(): Promise<SessionUser | null> {
    const userId = this.store.sessionUserId;
    if (userId === null) return null;

    const profile = this.store.profiles.get(userId);
    if (profile !== undefined) {
      return { id: profile.id, email: profile.email, name: profile.name, lang: profile.lang };
    }

    const authUser = [...this.store.authUsers.values()].find((u) => u.id === userId);
    if (authUser !== undefined) {
      return { id: authUser.id, email: authUser.email, name: authUser.email.split("@")[0] ?? "", lang: "ja" };
    }

    return null;
  }

  async sendMagicLink(email: string, redirectTo: string): Promise<AuthResult> {
    this.store.magicLinks.push({ email, redirectTo, sentAt: this.store.nowIso() });
    return { ok: true };
  }

  async signInWithPassword(email: string, password: string): Promise<AuthResult> {
    const user = this.store.authUsers.get(email);
    if (user === undefined || user.password !== password) {
      return { ok: false, code: "bad_credentials" };
    }
    this.store.sessionUserId = user.id;
    return { ok: true };
  }

  async signUpWithPassword(email: string, password: string, _redirectTo: string): Promise<AuthResult> {
    if (this.store.authUsers.has(email)) {
      return { ok: false, code: "email_taken" };
    }
    const id = this.store.nextId("profiles");
    this.store.authUsers.set(email, { id, email, password });
    this.store.sessionUserId = id;
    return { ok: true };
  }

  async signOut(): Promise<void> {
    this.store.sessionUserId = null;
  }

  /** fake モードでは環境変数をそろえられないので、常に null（画面はボタンを出さない） */
  async oauthStartUrl(_provider: OAuthProvider, _redirectTo: string): Promise<string | null> {
    return null;
  }

  /**
   * fake モードでは、メールのリンク・OAuth の本物の行き来を再現しません。
   * すでに signInAs で見本の人を選んである（= セッションがある）ときだけ ok を返します。
   */
  async completeSignIn(_input: { code?: string; tokenHash?: string; type?: string }): Promise<AuthResult> {
    if (this.store.sessionUserId !== null) return { ok: true };
    return { ok: false, code: "unavailable" };
  }

  /** 外へは送らず、store.passwordResets に積むだけです（ご登録の有無にかかわらず ok） */
  async sendPasswordReset(email: string, redirectTo: string): Promise<AuthResult> {
    this.store.passwordResets.push({ email, redirectTo, sentAt: this.store.nowIso() });
    return { ok: true };
  }

  /**
   * いまログインしている方のパスワードを変えます。
   * 見本の方（パスワードを持たない方）も、ここで決めたパスワードでログインできるようになります。
   * いまと同じパスワードは、本物（same_password）と同じくお断りします。
   */
  async updatePassword(password: string): Promise<AuthResult> {
    const user = await this.getUser();
    if (user === null) return { ok: false, code: "unavailable" };

    const existing = this.store.authUsers.get(user.email);
    if (existing !== undefined && existing.password === password) {
      return { ok: false, code: "password_rejected" };
    }
    this.store.authUsers.set(user.email, { id: user.id, email: user.email, password });
    return { ok: true };
  }

  /**
   * いまのパスワードを確かめます。
   * **見本の方は、まだパスワードをお持ちでありません。** そのときは、どの値でも通します
   * （見本のしくみでも「パスワードを変える」と退会をお試しいただけるようにするためです）。
   * 「パスワードを変える」で一度お決めになったあとは、本物と同じく突き合わせます。
   */
  async verifyPassword(email: string, password: string): Promise<AuthResult> {
    const user = this.store.authUsers.get(email);
    if (user === undefined) {
      return this.store.profiles.has(this.store.sessionUserId ?? "")
        ? { ok: true }
        : { ok: false, code: "bad_credentials" };
    }
    return user.password === password ? { ok: true } : { ok: false, code: "bad_credentials" };
  }

  /** 見本のしくみには、メールのリンクでのログインがありません（いつも false） */
  async recentEmailSignIn(_maxAgeSeconds: number): Promise<boolean> {
    return false;
  }
}
