/**
 * 退会（アカウントの削除）の流れです。
 *
 * 組織ごとに、次の 3 とおりに分けてから進めます。
 *   blocking … ほかの方がいらっしゃる組織の、ただ 1 人のオーナー。
 *              先にオーナーを引き継ぐか、組織を削除していただくまで、退会をお止めします。
 *   deleting … その方お 1 人だけの組織。アカウントと一緒に組織も消します。
 *              ご契約が残っていれば、先に決済のしくみの側で解約します。
 *   leaving  … それ以外（ほかにもオーナーがいる・管理者・メンバー）。メンバーの行だけが消えます。
 *
 * データベースの側にも同じ守り（関数 delete_account と引き金 profiles_before_delete）があり、
 * 確かめてから消すまでのあいだにどなたかが加わっても、オーナーのいない組織は残りません。
 */
import { hasOpenSubscription } from "../../core/billing-state";
import { validateEmail } from "../../core/validation";
import type { BillingErrorCode, Organization, Ports, SessionUser } from "../../ports";
import { flowFail, flowOk, type FlowErrorCode, type FlowResult, type UserCtx } from "../context";
import { reauthenticateFlow, type ReauthLimits } from "./auth";

export type AccountDeletionPlan = {
  blocking: Organization[];
  deleting: Organization[];
  leaving: Organization[];
};

const BILLING_CODES: Readonly<Record<BillingErrorCode, FlowErrorCode>> = {
  not_configured: "billing_not_configured",
  no_customer: "billing_no_customer",
  unavailable: "unavailable",
};

/** 退会すると、どの組織がどうなるかです（画面が、押す前にお見せするためにも使います） */
export async function accountDeletionPlanFlow(input: {
  ports: Ports;
  user: SessionUser;
}): Promise<FlowResult<AccountDeletionPlan>> {
  const plan: AccountDeletionPlan = { blocking: [], deleting: [], leaving: [] };
  const rows = await input.ports.data.listOrganizationsForUser(input.user.id);

  for (const { organization, role } of rows) {
    if (role !== "owner") {
      plan.leaving.push(organization);
      continue;
    }

    const members = await input.ports.data.listMembers(organization.id);
    if (members.every((member) => member.userId === input.user.id)) {
      plan.deleting.push(organization);
    } else if ((await input.ports.data.countOwners(organization.id)) <= 1) {
      plan.blocking.push(organization);
    } else {
      plan.leaving.push(organization);
    }
  }

  return flowOk(plan);
}

/**
 * アカウントを消します。
 *
 * 順番がこの流れの要です。**止まりうる確かめを先にすべて済ませ**、決済のしくみの側を解約し、
 * 最後にデータベースの関数 delete_account を 1 回だけ呼びます。
 *   1. メールアドレスの入力と、ご本人の確かめ直し（いまのパスワード、または 10 分以内のメールでの確かめ）
 *   2. 組織ごとの扱い（止めるものがあれば owner_has_members）
 *   3. お 1 人だけの組織のご契約の確かめ（契約の番号が分からない残りのご契約があれば、何もせずに止める）
 *   4. 解約の直前に、組織ごとの扱いをもう一度確かめる
 *   5. 決済のしくみの側で解約し、ご契約の表を解約の形にする（書けなかったら止める）
 *   6. delete_account（お 1 人だけの組織の削除とアカウントの削除が、1 つの取引）
 * 5 のあとで 6 が止まったときは、ご契約だけが解約済みになります。そのときは誤りをお伝えし、
 * アカウントと組織は残ります（もう一度お試しいただけば、解約済みとして 6 から進みます）。
 */
export async function deleteAccountFlow(
  input: ReauthLimits & {
    ctx: UserCtx;
    raw: { confirmEmail: unknown; currentPassword: unknown };
  },
): Promise<FlowResult<{ deleted: true }>> {
  const { ports, user } = input.ctx;

  const confirm = validateEmail(input.raw.confirmEmail, "confirmEmail");
  if (!confirm.ok || confirm.value !== user.email.toLowerCase()) {
    return flowFail("invalid", [{ field: "confirmEmail", code: "mismatch" }]);
  }

  const reauth = await reauthenticateFlow({
    ...input,
    ports,
    email: user.email,
    currentPassword: input.raw.currentPassword,
  });
  if (!reauth.ok) return reauth;

  const planned = await accountDeletionPlanFlow({ ports, user });
  if (!planned.ok) return planned;
  if (planned.value.blocking.length > 0) return flowFail("owner_has_members");

  // お 1 人だけの組織の、残っているご契約を先に洗い出します（ここではまだ何も変えません）
  const toCancel: { organizationId: string; stripeSubscriptionId: string }[] = [];
  for (const organization of planned.value.deleting) {
    // service role で読みます（決済の契約の番号まで要るためです）
    const subscription = await ports.data.getBillingSubscription(organization.id);
    if (subscription === null || !hasOpenSubscription(subscription.status)) continue;
    if (subscription.stripeSubscriptionId === null) {
      // 番号の分からないご契約を、黙って解約済みにはしません（お支払いだけが続いてしまうため）
      console.error("退会: 番号の分からないご契約が残っているため、お止めしました");
      return flowFail("has_subscription");
    }
    toCancel.push({
      organizationId: organization.id,
      stripeSubscriptionId: subscription.stripeSubscriptionId,
    });
  }

  // 解約の直前に、組織の顔ぶれが変わっていないかを確かめ直します
  const again = await accountDeletionPlanFlow({ ports, user });
  if (!again.ok) return again;
  if (again.value.blocking.length > 0) return flowFail("owner_has_members");
  const stillSolo = new Set(again.value.deleting.map((organization) => organization.id));
  if (toCancel.some((item) => !stillSolo.has(item.organizationId))) return flowFail("unavailable");

  const now = input.ctx.now.toISOString();
  for (const item of toCancel) {
    const canceled = await ports.billing.cancelSubscription({
      stripeSubscriptionId: item.stripeSubscriptionId,
    });
    if (!canceled.ok) return flowFail(BILLING_CODES[canceled.code]);

    // 解約の通知を待たずに、表も解約の形にします（組織を消せるようにするためです）
    const written = await ports.data.applySubscriptionChange({
      organizationId: item.organizationId,
      row: null,
      now,
    });
    if (!written) {
      console.error("退会: ご契約の表を解約の形にできませんでした（Stripe の側は解約済みです）");
      return flowFail("unavailable");
    }
  }

  const removed = await ports.data.deleteAccount(user.id);
  if (removed !== "ok") return flowFail(removed);

  await ports.auth.signOut();
  return flowOk({ deleted: true } as const);
}
