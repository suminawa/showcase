/**
 * 監査ログ（組織の操作の記録）を読む流れです。書くのはデータベースの引き金で、ここは読むだけです。
 * 読めるのは、役割の表の audit:read の行にあたる方（オーナーと管理者）です。
 */
import { AUDIT_LOG_PAGE_SIZE } from "../../core/audit";
import { can } from "../../core/permissions";
import type { AuditLogRow } from "../../ports";
import { flowFail, flowOk, type Ctx, type FlowResult } from "../context";

export async function listAuditLogsFlow(input: { ctx: Ctx }): Promise<FlowResult<AuditLogRow[]>> {
  if (!can("audit:read", { role: input.ctx.role })) return flowFail("forbidden");

  const rows = await input.ctx.ports.data.listAuditLogs(
    input.ctx.organization.id,
    AUDIT_LOG_PAGE_SIZE,
  );
  return flowOk(rows);
}
