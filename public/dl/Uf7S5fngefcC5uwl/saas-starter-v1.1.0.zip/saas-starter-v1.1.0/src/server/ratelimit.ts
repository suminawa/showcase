/**
 * ログインと招待の回数の上限です。
 *
 * 数える入れ物は 2 つあります。どちらを使うかは合成の場所（src/server/ports.ts）が決めます。
 *   メモリ     … createMemoryRateLimiter。サーバーが複数台あるときや、再起動したときは
 *                数え直しになります。見本のしくみと、お手元でのお試し向けです。
 *   データベース … createStoreRateLimiter に、rate_limits の表で数える口を渡します。
 *                Supabase をつないだときの既定です。台をまたいでも 1 つの数になります。
 * ほかの入れ物（Upstash Redis など）も、RateLimiter を実装した値を渡すだけで使えます。
 */

import { createHmac } from "node:crypto";

export type RateLimitKey = string;

/**
 * 鍵を HMAC-SHA256（サーバーだけが知る秘密 RATE_LIMIT_PEPPER）で包みます。
 *
 * 鍵にはメールアドレスと IP が入ります。包んでおけば、数える入れ物（rate_limits のテーブル）に
 * 個人の情報が残らず、鍵の長さもそろいます。秘密を混ぜるのは、表の中身を見た人が
 * 「このメールアドレスなら、この鍵」と当てられないようにするためです（ただのハッシュでは当てられます）。
 */
export function hashKey(key: RateLimitKey, pepper: string): string {
  return `rl:${createHmac("sha256", pepper).update(key, "utf8").digest("hex").slice(0, 40)}`;
}

/** どの鍵も hashKey で包んでから数える上限です（合成の場所が、入れ物の種類によらず被せます） */
export function withHashedKeys(inner: RateLimiter, pepper: string): RateLimiter {
  return {
    hit(key: RateLimitKey, now: Date): Promise<RateLimitVerdict> {
      return inner.hit(hashKey(key, pepper), now);
    },
  };
}

export type RateLimitVerdict = {
  allowed: boolean;
  /** 次に試していただけるまでの秒数（通ったときは 0） */
  retryAfterSeconds: number;
};

export interface RateLimiter {
  hit(key: RateLimitKey, now: Date): Promise<RateLimitVerdict>;
}

export type MemoryRateLimiterOptions = {
  /** 窓の中で通す回数 */
  limit: number;
  /** 窓の長さ（秒） */
  windowSeconds: number;
  /** 覚えておく鍵の数の上限。既定 10000。超えたら古い順に捨てます */
  max?: number;
};

type Bucket = { startedAt: number; count: number };

const DEFAULT_MAX_KEYS = 10000;

/** 鍵ごとに「窓の始まり」と「回数」を持つ、固定窓の数え方です */
export function createMemoryRateLimiter(options: MemoryRateLimiterOptions): RateLimiter {
  const maxKeys = options.max ?? DEFAULT_MAX_KEYS;
  const windowMs = options.windowSeconds * 1000;
  const buckets = new Map<RateLimitKey, Bucket>();

  return {
    async hit(key: RateLimitKey, now: Date): Promise<RateLimitVerdict> {
      const at = now.getTime();
      const previous = buckets.get(key);

      // いったん外してから入れ直すと、Map の並びが「最後に使った順」になります
      buckets.delete(key);

      const expired = previous === undefined || at - previous.startedAt >= windowMs;
      const bucket: Bucket = expired
        ? { startedAt: at, count: 1 }
        : { startedAt: previous.startedAt, count: previous.count + 1 };
      buckets.set(key, bucket);

      while (buckets.size > maxKeys) {
        const oldest = buckets.keys().next();
        if (oldest.done === true) break;
        buckets.delete(oldest.value);
      }

      if (bucket.count <= options.limit) return { allowed: true, retryAfterSeconds: 0 };

      const remainMs = bucket.startedAt + windowMs - at;
      return { allowed: false, retryAfterSeconds: Math.max(1, Math.ceil(remainMs / 1000)) };
    },
  };
}

/**
 * 数える口（データベースなど、外の入れ物）です。
 * 「数えて、上限と比べて、書く」を 1 回の呼び出しの中で行うものをお渡しください。
 */
export type RateLimitCount = (input: {
  key: RateLimitKey;
  limit: number;
  windowSeconds: number;
  now: Date;
}) => Promise<RateLimitVerdict>;

/** 外の入れ物で数える上限です。数え方（固定窓）は、メモリのものと同じです */
export function createStoreRateLimiter(
  options: { limit: number; windowSeconds: number },
  count: RateLimitCount,
): RateLimiter {
  return {
    hit(key: RateLimitKey, now: Date): Promise<RateLimitVerdict> {
      return count({ key, limit: options.limit, windowSeconds: options.windowSeconds, now });
    },
  };
}

/** ログイン・登録・メールのリンク: メールアドレスと IP ごとに 10 分で 10 回 */
export const LOGIN_LIMIT = { limit: 10, windowSeconds: 600 };

/**
 * ログイン・登録・メールのリンクの 2 本目の窓: IP ごとに 10 分で 50 回。
 *
 * 1 本目の窓はメールアドレスごとに数えるため、メールアドレスを変えながら
 * 何度も試す形は止められません。メールアドレスを含まないこの窓が、その分を受け持ちます
 * （ご家庭や職場で IP を分け合う方のことを考えて、1 本目より広くしてあります）。
 */
export const LOGIN_IP_LIMIT = { limit: 50, windowSeconds: 600 };

/** 招待の発行: 組織ごとに 1 時間で 20 回 */
export const INVITE_LIMIT = { limit: 20, windowSeconds: 3600 };

/** 招待をお受けいただくとき: IP ごとに 1 時間で 20 回 */
export const INVITE_ACCEPT_LIMIT = { limit: 20, windowSeconds: 3600 };
