/**
 * お名前と言語・パスワード・退会の画面です（組織をまたいで同じ設定です）。
 *
 * 退会のボタンの前に、組織ごとにどうなるか（止める・一緒に消す・退会する）をお見せします。
 * 押せてしまったときも、flow とデータベースの引き金が同じ決まりで止めます。
 */
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { deleteAccountAction, updateProfileAction } from "@/app/_actions/profile";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { accountDeletionPlanFlow } from "@/src/server/flows/account";
import { myProfileFlow, PROFILE_NAME_MAX, RESET_PASSWORD_PATH } from "@/src/server/flows/auth";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../../app.module.css";

export default async function ProfileSettingsPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/settings/profile"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const profile = await myProfileFlow({ ctx });
  const name = profile.ok ? profile.value.name : ctx.user.name;
  const lang = profile.ok ? profile.value.lang : ctx.lang;

  const planned = await accountDeletionPlanFlow({ ports: ctx.ports, user: ctx.user });
  const plan = planned.ok ? planned.value : { blocking: [], deleting: [], leaving: [] };
  const groups = [
    { key: "account.deletingHint", organizations: plan.deleting },
    { key: "account.leavingHint", organizations: plan.leaving },
  ].filter((group) => group.organizations.length > 0);

  return (
    <>
      <div className={styles.head}>
        <h1 className={styles.title}>{t(messages, "settings.profileTitle")}</h1>
        <p className={styles.lead}>{t(messages, "settings.profileLead")}</p>
      </div>

      <div className={styles.sections}>
        <section className={`${ui.card} ${ui.stack}`}>
          <ActionForm
            action={updateProfileAction}
            messages={messages}
            className={ui.stack}
            label={t(messages, "settings.profileTitle")}
          >
            <Field
              name="name"
              label={t(messages, "field.name")}
              defaultValue={name}
              maxLength={PROFILE_NAME_MAX}
              autoComplete="name"
              required
            />
            <Field
              name="lang"
              kind="select"
              label={t(messages, "field.lang")}
              defaultValue={lang}
              options={[
                { value: "ja", label: t(messages, "lang.ja") },
                { value: "en", label: t(messages, "lang.en") },
              ]}
              required
            />
            <div className={ui.row}>
              <SubmitButton tone="primary">{t(messages, "common.save")}</SubmitButton>
            </div>
          </ActionForm>
        </section>

        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "settings.accountTitle")}</h2>
          <dl className={styles.facts}>
            <div className={styles.fact}>
              <dt className={styles.factTerm}>{t(messages, "field.email")}</dt>
              <dd className={styles.factValue}>{ctx.user.email}</dd>
            </div>
          </dl>
          <p className={ui.hint}>{t(messages, "settings.emailHint")}</p>
          <p>
            <Link href={RESET_PASSWORD_PATH}>{t(messages, "settings.passwordLink")}</Link>
          </p>
        </section>

        <section className={`${ui.card} ${ui.stack}`}>
          <h2 className={ui.cardTitle}>{t(messages, "account.deleteTitle")}</h2>
          <p className={ui.hint}>{t(messages, "account.deleteLead")}</p>

          {plan.blocking.length > 0 ? (
            <div className={`${ui.notice} ${ui.noticeWarn}`}>
              <p className={ui.strong}>{t(messages, "account.blockingTitle")}</p>
              <p>{t(messages, "account.blockingHint")}</p>
              <ul>
                {plan.blocking.map((organization) => (
                  <li key={organization.id}>{organization.name}</li>
                ))}
              </ul>
            </div>
          ) : (
            <details className={ui.disclosure}>
              <summary className={ui.summary}>{t(messages, "account.submit")}</summary>
              <div className={`${ui.disclosureBody} ${ui.stack}`}>
                {groups.map((group) => (
                  <div key={group.key} className={ui.stackTight}>
                    <p className={ui.hint}>{t(messages, group.key)}</p>
                    <ul>
                      {group.organizations.map((organization) => (
                        <li key={organization.id}>{organization.name}</li>
                      ))}
                    </ul>
                  </div>
                ))}
                <ActionForm
                  action={deleteAccountAction}
                  messages={messages}
                  className={ui.stack}
                  label={t(messages, "account.deleteTitle")}
                >
                  <Field
                    name="confirmEmail"
                    type="email"
                    label={t(messages, "account.confirmLabel")}
                    hint={t(messages, "account.confirmHint", { email: ctx.user.email })}
                    autoComplete="off"
                    required
                  />
                  <Field
                    name="currentPassword"
                    type="password"
                    label={t(messages, "field.currentPassword")}
                    hint={t(messages, "account.currentHint")}
                    autoComplete="current-password"
                  />
                  <div className={ui.row}>
                    <SubmitButton tone="danger" size="small">
                      {t(messages, "account.submit")}
                    </SubmitButton>
                  </div>
                </ActionForm>
              </div>
            </details>
          )}
        </section>
      </div>
    </>
  );
}
