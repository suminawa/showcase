/**
 * 監査ログ（組織の操作の記録）の画面です。読むだけで、書き換えはできません。
 *
 * ご覧になれるのは、役割の表の audit:read の行にあたる方（オーナーと管理者）です。
 * ほかの方には「見つかりません」をお返しします（この画面があること自体をお知らせしません）。
 * 記録を書くのはデータベースの引き金です（supabase/migrations/…_audit_logs.sql）。
 */
import { notFound, redirect } from "next/navigation";
import type { ReactNode } from "react";
import type { AuditLogRow } from "@/src/core/audit";
import { formatDateTime, t, type Messages } from "@/src/core/i18n";
import { listAuditLogsFlow } from "@/src/server/flows/audit";
import { messagesFor } from "@/src/server/messages";
import { appGate } from "@/src/server/ports";
import { loginPath } from "@/src/server/urls";
import ui from "@/app/_components/ui.module.css";
import styles from "../../app.module.css";

/** 役割・プラン・状態の値を、画面の言葉に写します（知らない値はそのままお出しします） */
function word(messages: Messages, key: string, raw: string): string {
  const found = t(messages, key);
  return found === key ? raw : found;
}

function detailText(row: AuditLogRow, messages: Messages): string {
  const { detail } = row;
  if (row.action === "member.role_changed" && detail.from !== undefined && detail.to !== undefined) {
    return t(messages, "audit.roleChange", {
      from: word(messages, `role.${detail.from}`, detail.from),
      to: word(messages, `role.${detail.to}`, detail.to),
    });
  }
  if (row.action === "billing.changed" && detail.plan !== undefined && detail.status !== undefined) {
    return t(messages, "audit.billingDetail", {
      plan: word(messages, `plan.${detail.plan}.name`, detail.plan),
      status: word(messages, `billing.status.${detail.status}`, detail.status),
    });
  }
  if (detail.role !== undefined) return word(messages, `role.${detail.role}`, detail.role);
  return "";
}

function actorText(row: AuditLogRow, messages: Messages): string {
  if (row.actorName !== null && row.actorName !== "") return row.actorName;
  return row.actorType === "system" ? t(messages, "audit.actorSystem") : t(messages, "audit.actorLeft");
}

export default async function AuditLogPage(): Promise<ReactNode> {
  const gate = await appGate();
  if (gate.status === "guest") redirect(loginPath("/app/settings/audit"));
  if (gate.status === "onboarding") redirect("/onboarding");
  if (gate.status === "not_member") notFound();

  const ctx = gate.ctx;
  const messages = messagesFor(ctx.lang);

  const logs = await listAuditLogsFlow({ ctx });
  if (!logs.ok) notFound();

  return (
    <>
      <div className={styles.head}>
        <h1 className={styles.title}>{t(messages, "audit.title")}</h1>
        <p className={styles.lead}>{t(messages, "audit.lead")}</p>
      </div>

      {logs.value.length === 0 ? (
        <div className={ui.empty}>
          <p className={ui.emptyTitle}>{t(messages, "audit.emptyTitle")}</p>
          <p className={ui.emptyHint}>{t(messages, "audit.emptyHint")}</p>
        </div>
      ) : (
        <ul className={ui.rows}>
          {logs.value.map((row) => {
            const detail = detailText(row, messages);
            return (
              <li className={ui.rowItem} key={row.id}>
                <span className={ui.rowMain}>
                  <span className={ui.rowName}>
                    {word(messages, `audit.action.${row.action}`, row.action)}
                    {row.target === "" ? null : ` ${row.target}`}
                  </span>
                  <span className={ui.rowMeta}>
                    {[actorText(row, messages), detail].filter((part) => part !== "").join(" / ")}
                  </span>
                </span>
                <span className={`${ui.rowActions} ${ui.muted}`}>
                  <time dateTime={row.createdAt}>{formatDateTime(row.createdAt, ctx.lang)}</time>
                </span>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
