/**
 * 設定の画面（プロフィール・組織・お支払い・監査ログ）の行き来です。
 * 関門（ログインと一員かどうか）は、それぞれの画面が自分で通ります。
 *
 * 監査ログの行は、役割の表で audit:read にあたる方（オーナーと管理者）にだけお出しします
 * （関門の答えは 1 回のお申し付けの中で使い回されるので、ここで尋ねても二度は走りません）。
 */
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { can } from "@/src/core/permissions";
import { Nav } from "@/app/_components/Nav";
import { appGate, pageMessages } from "@/src/server/ports";

export default async function SettingsLayout({
  children,
}: {
  children: ReactNode;
}): Promise<ReactNode> {
  const { messages } = await pageMessages();
  const gate = await appGate();
  const mayReadAudit = gate.status === "ok" && can("audit:read", { role: gate.ctx.role });

  return (
    <>
      <Nav
        tone="sub"
        label={t(messages, "settings.navLabel")}
        items={[
          { href: "/app/settings/profile", label: t(messages, "settings.profile") },
          { href: "/app/settings/organization", label: t(messages, "settings.organization") },
          { href: "/app/settings/billing", label: t(messages, "settings.billing") },
          ...(mayReadAudit
            ? [{ href: "/app/settings/audit", label: t(messages, "settings.audit") }]
            : []),
        ]}
      />
      {children}
    </>
  );
}
