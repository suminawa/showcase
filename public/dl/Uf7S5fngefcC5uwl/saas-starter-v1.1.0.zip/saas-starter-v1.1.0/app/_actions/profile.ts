"use server";

/**
 * お名前と言語のお申し付けです。
 * 言語は、次にお開きになったときも同じになるよう cookie にも控えます。
 */
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { toActionState, type ActionState } from "@/src/server/context";
import { deleteAccountFlow } from "@/src/server/flows/account";
import { updateProfileFlow } from "@/src/server/flows/auth";
import {
  clearCurrentOrganizationId,
  clientIp,
  limiters,
  setRequestLang,
  userContext,
} from "@/src/server/ports";

export async function updateProfileAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await userContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const result = await updateProfileFlow({
    ctx: ctx.value,
    raw: { name: form.get("name"), lang: form.get("lang") },
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await setRequestLang(result.value.lang);
  // 言語が変わると、どの画面の文も変わります
  revalidatePath("/app", "layout");

  return toActionState(result, "profile.saved", form);
}

/**
 * 退会（アカウントの削除）です。確かめのため、ご自身のメールアドレスをご入力いただきます。
 * どの組織をどう扱うか（止める・一緒に消す・退会する）は、flow が決めます。
 */
export async function deleteAccountAction(
  _previous: ActionState,
  form: FormData,
): Promise<ActionState> {
  const ctx = await userContext();
  if (!ctx.ok) return toActionState(ctx, undefined, form);

  const limits = limiters();
  const result = await deleteAccountFlow({
    ctx: ctx.value,
    raw: { confirmEmail: form.get("confirmEmail"), currentPassword: form.get("currentPassword") },
    limiter: limits.login,
    ipLimiter: limits.loginIp,
    ip: await clientIp(),
    now: ctx.value.now,
  });
  if (!result.ok) return toActionState(result, undefined, form);

  await clearCurrentOrganizationId();
  redirect("/");
}
