/**
 * パスワードの再設定のメールをお求めいただく画面です（ログインは要りません）。
 *
 * ご登録のないメールアドレスでも、同じ「お送りしました」をお出しします
 * （どなたがご登録済みかを、外から確かめられないようにするためです）。
 * メールのリンクは /auth/callback でセッションを立ててから、/reset-password へお通しします。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { requestPasswordResetAction } from "@/app/_actions/auth";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { isFakeMode, pageMessages } from "@/src/server/ports";
import ui from "@/app/_components/ui.module.css";
import styles from "../auth.module.css";

export default async function ForgotPasswordPage(): Promise<ReactNode> {
  const { messages } = await pageMessages();

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <Link className={styles.brand} href="/">
          {t(messages, "common.appName")}
        </Link>

        <div className={ui.panel}>
          <h1 className={styles.title}>{t(messages, "auth.forgot.title")}</h1>
          <p className={styles.lead}>{t(messages, "auth.forgot.lead")}</p>

          {isFakeMode() ? (
            <p className={`${ui.notice} ${ui.noticeWarn} ${styles.form}`}>
              {t(messages, "auth.forgot.demoHint")}
            </p>
          ) : null}

          <ActionForm
            action={requestPasswordResetAction}
            messages={messages}
            className={styles.form}
            label={t(messages, "auth.forgot.title")}
          >
            <Field
              name="email"
              type="email"
              label={t(messages, "field.email")}
              hint={t(messages, "auth.forgot.linkHint")}
              autoComplete="email"
              required
            />
            <SubmitButton tone="primary">{t(messages, "auth.forgot.submit")}</SubmitButton>
          </ActionForm>
        </div>

        <p className={styles.switch}>
          <Link href="/login">{t(messages, "auth.forgot.toLogin")}</Link>
        </p>
      </div>
    </main>
  );
}
