/**
 * 新しいパスワードをお決めいただく画面です。
 *
 * 再設定のメールのリンクからお戻りの方（/auth/callback がセッションを立てています）と、
 * ログイン中に「パスワードを変える」からお越しの方の、どちらもこの画面です。
 * セッションが無いとき（リンクの期限切れ・別のブラウザ）は、メールの送り直しへご案内します。
 * ログイン中の方には、いまのパスワードの欄を出します（確かめ直し。src/server/flows/auth.ts）。
 */
import Link from "next/link";
import type { ReactNode } from "react";
import { t } from "@/src/core/i18n";
import { updatePasswordAction } from "@/app/_actions/auth";
import { ActionForm } from "@/app/_components/ActionForm";
import { Field } from "@/app/_components/Field";
import { SubmitButton } from "@/app/_components/SubmitButton";
import { REAUTH_MAX_AGE_SECONDS } from "@/src/server/flows/auth";
import { getPorts, isFakeMode, pageMessages } from "@/src/server/ports";
import ui from "@/app/_components/ui.module.css";
import styles from "../auth.module.css";

export default async function ResetPasswordPage(): Promise<ReactNode> {
  const { messages } = await pageMessages();
  const ports = await getPorts();
  const user = await ports.auth.getUser();
  // 再設定のリンクから 10 分以内にお戻りの方は、いまのパスワードを省けます（それ以外の方には欄を出します）
  const fromEmail = user !== null && (await ports.auth.recentEmailSignIn(REAUTH_MAX_AGE_SECONDS));

  return (
    <main className={ui.centered}>
      <div className={ui.centeredWrap}>
        <Link className={styles.brand} href="/">
          {t(messages, "common.appName")}
        </Link>

        <div className={ui.panel}>
          <h1 className={styles.title}>{t(messages, "auth.reset.title")}</h1>

          {user === null ? (
            <>
              <p className={`${ui.notice} ${ui.noticeWarn} ${styles.form}`} role="status">
                {t(messages, "auth.reset.noSession")}
              </p>
              <p className={styles.switch}>
                <Link href="/forgot-password">{t(messages, "auth.reset.again")}</Link>
              </p>
            </>
          ) : (
            <>
              <p className={styles.lead}>{t(messages, "auth.reset.lead")}</p>
              <ActionForm
                action={updatePasswordAction}
                messages={messages}
                className={styles.form}
                label={t(messages, "auth.reset.title")}
              >
                {/* パスワードの管理の道具が、どの方のパスワードかを分かるようにします */}
                <input type="hidden" name="username" value={user.email} autoComplete="username" />
                {fromEmail ? null : (
                  <Field
                    name="currentPassword"
                    type="password"
                    label={t(messages, "field.currentPassword")}
                    hint={t(messages, isFakeMode() ? "auth.reset.demoHint" : "auth.reset.currentHint")}
                    autoComplete="current-password"
                  />
                )}
                <Field
                  name="password"
                  type="password"
                  label={t(messages, "field.newPassword")}
                  hint={t(messages, "auth.signup.passwordHint")}
                  autoComplete="new-password"
                  required
                />
                <Field
                  name="passwordConfirm"
                  type="password"
                  label={t(messages, "field.passwordConfirm")}
                  autoComplete="new-password"
                  required
                />
                <SubmitButton tone="primary">{t(messages, "auth.reset.submit")}</SubmitButton>
              </ActionForm>
              <p className={styles.switch}>
                <Link href="/app">{t(messages, "auth.reset.toApp")}</Link>
              </p>
            </>
          )}
        </div>
      </div>
    </main>
  );
}
