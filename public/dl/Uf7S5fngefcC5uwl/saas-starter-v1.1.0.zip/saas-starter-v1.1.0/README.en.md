# SaaS Starter Kit

A foundation for a membership service. Sign-in, organisations and invitations, per-role permissions, Stripe subscriptions, the settings screens and Japanese legal-notice templates are all in place and working on the day you buy it. It is Next.js 16 with Supabase and Stripe, and it has exactly seven runtime dependencies.

**You can click through every screen before you have a single key.** Leave `STARTER_FAKE=1` in place, run `npm run dev`, and the whole app runs on in-memory demo data without talking to Supabase or Stripe. Start there.

This manual is written to be read in this order.

| Stage | Time | What you should see at the end |
|---|---|---|
| §4 Demo mode | 15 min | Every screen, from sign-in to checkout, with no keys |
| §6 Supabase | 1 hour | Sign-up through invitation, on your own database |
| §7 Stripe | 20 min | A subscription going through on a test card |
| §17 Pre-flight | 30 min | Ready to go live |

The kit ships in Japanese and English. The Japanese manual is `README.ja.md`.

## 1. What it does

There are nineteen routes, all of them already built.

| Route | Screen | Who can open it |
|---|---|---|
| `/` | Marketing page with the plan table | Anyone |
| `/signup` | Sign-up | Anyone |
| `/login` | Sign-in (password, magic link, Google) | Anyone |
| `/forgot-password` | Ask for a password-reset email | Anyone |
| `/reset-password` | Choose a new password (from the reset link, or while signed in) | Returning from the reset link, or signed in |
| `/auth/callback` | Return from an email link or from Google | Anyone |
| `/onboarding` | Create the first organisation | Signed in |
| `/app` | Overview (project count, quota, subscription banner) | Members |
| `/app/projects` | Projects: list, create, edit, delete | Members |
| `/app/settings/profile` | Display name, language, password change, account deletion | Members |
| `/app/settings/organization` | Name, members, invitations, leaving, deletion | Members |
| `/app/settings/billing` | Subscribe and manage billing | Members (only owners can act) |
| `/app/settings/audit` | Audit log (role changes, invitations, billing changes, removals, account deletions) | Owners and admins |
| `/invite/[token]` | Accept an invitation | Signed in |
| `/admin` | Read-only operator overview | Addresses in `ADMIN_EMAILS` |
| `/legal/tokushoho` | Japanese commercial-transactions notice | Anyone |
| `/legal/terms` | Terms of service | Anyone |
| `/legal/privacy` | Privacy policy | Anyone |
| `/api/stripe/webhook` | Stripe webhook endpoint | Stripe only |

One more route, `/fake/checkout`, appears only while demo mode is on.

**There are three roles.** The table lives in exactly one place, `src/core/permissions.ts`, and the screens, the flows and the database policies are all derived from it.

| Action | owner | admin | member |
|---|---|---|---|
| Read, create and edit projects | yes | yes | yes |
| Delete a project | yes | yes | only their own |
| Invite, remove, change roles | yes | yes (never touching an owner) | no |
| Rename the organisation | yes | yes | no |
| Manage billing | yes | no | no |
| Delete the organisation | yes | no | no |
| Read the audit log | yes | yes | no |

Every organisation keeps at least one owner. The last owner cannot be removed or demoted.

Anyone in the organisation can read the billing screen: plan, status, renewal date and project count. Subscribing and managing payment are for owners only.

**There are three plans.** The amounts and quotas live in `plans.config.ts` (§10).

| Plan | Monthly (tax included) | Project quota |
|---|---|---|
| Free | ¥0 | 3 |
| Standard | ¥2,980 | 50 |
| Business | ¥9,800 | unlimited |

**Also in the box**

- Invitations use a 32-byte random token, expire after 7 days and work once. Only the hash is stored.
- Sign-in, password reset and invitation sending are rate limited. Once Supabase is connected the counts live in the database (the `rate_limits` table), so they hold across any number of server instances (§15).
- Password reset (email link → new password) and account deletion screens. Changing your password and deleting your account both ask for your current password again (skippable within 10 minutes of signing in through an email link). Deleting an account also asks you to type your own email address.
- Organisation actions (role changes, invitations, billing changes, removals, account deletions) are written to an audit log by database triggers. Only owners and admins can read it, and nobody can edit it.
- The commercial-transactions notice has an optional field for your qualified-invoice registration number (hidden when empty; §9 and §7-9).
- The interface ships in Japanese and English, follows the light and dark system setting, collapses to one column at 390px, and can be driven from the keyboard alone.
- 681 tests, plus a separate database suite: 49 pgTAP checks, 67 policy tests and 42 adapter tests (§16).

## 2. What we did not build

It is only fair to say what is missing. There are two lists.

### Coming in a free 1.x update

Not in the box yet, but planned within 1.x. If you bought the kit, you get them as a free update.

| Not yet included | What to do for now |
|---|---|
| A change-email screen | The Supabase template (`supabase/templates/email-change.html`) is included. If you need it sooner, read the caveat in §19 and sync `profiles.email` with the service role |
| End-to-end browser tests (E2E) and a CI configuration | Run `npm test`, `npm run test:rls` and `npm run check:bundle` by hand for now (§16) |

### Left out on purpose

| Not included | Why | What to do instead |
|---|---|---|
| Payment providers other than Stripe | Two providers means two ways to keep subscription state | Implement the functions in `src/ports/billing.ts` against the other provider |
| Usage-based billing | What you meter differs for every service, so a template would only get in the way | Use Stripe Meters and add a usage table alongside `subscriptions` |
| One customer on several plans at once | The table holds one row per organisation | Widen it to organisation × product and split the quota check per product |
| Operator impersonation | It is the single feature that does the most damage when it goes wrong | `/admin` is read-only. If you need it, build it so every use is logged |
| Blog and landing-page components | A different kind of page from a members' area | Combine with the LP Template Pack (§20) |
| A mobile app | An entirely separate front end | Use this kit as the API and build the app separately |
| AI features | They need their own cost and safety model | Combine with the AI Concierge Kit (§20) |
| Databases other than Supabase | Row-level security is load-bearing here | Implementing `src/ports/data.ts` is possible, but you also need a replacement for the policies |

## 3. What is in the zip

```
saas-starter-v1.1.0/
  app/              screens and Server Actions
  src/              core, ports, adapters, server (§5)
  supabase/         config.toml, five migrations, the policy tests, the auth email templates
  messages/         interface strings (ja.json, en.json)
  legal/            six legal documents (three Japanese, three English)
  scripts/          check-bundle.mjs, run-rls.mjs, release.mjs
  test/             the vitest suite
  package.json  package-lock.json  tsconfig.json
  next.config.ts  vitest.config.ts  proxy.ts
  plans.config.ts  legal.config.ts
  .env.example  .gitignore
  README.ja.md  README.en.md  LICENSE.md  CHANGELOG.md
```

There is no `node_modules` and no `.next`. There is no real `.env` either, only `.env.example`.

## 4. Start in demo mode

No keys needed. Fifteen minutes to see every screen.

```bash
npm ci
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3020`. `.env.example` already starts with `STARTER_FAKE=1`, so demo mode is on.

**You are done when all of this is true.**

1. `/` shows the plan table: Free, Standard, Business.
2. "Sign in" offers three demo people: **Minato Taro** (owner), **Isono Hanako** (admin) and **Nagisa Ken** (member).
3. Signing in as Minato Taro lands on the overview for the organisation "Shiosai Design Studio", with two projects and a "2 / 3" quota line.
4. `/app/projects` lets you add, edit and delete. Adding a third project takes the count to "3 / 3" and replaces the create form with a notice that the plan's quota has been reached.
5. `/app/settings/organization` lists three members. Creating an invitation shows the link once, on the spot.
6. `/app/settings/billing`: pressing "Choose this plan" goes to the fake checkout at `/fake/checkout`. Confirm it, come back, and the Standard subscription is in place with a quota of 50.
7. Signing in as Nagisa Ken, `/app/settings/billing` still opens but only says that billing is for owners; no subscribe button is offered. The organisation settings lose the invitation form and the rename field as well.
8. As Minato Taro, `/app/settings/audit` lists the sample audit entries (an invitation and a role change). The Profile screen has "Change password" and "Delete your account". Minato Taro is the only owner of an organisation with other members, so deletion is refused with an explanation; Isono Hanako (sole owner of Nagisa Kobo) can delete her account, and that organisation goes with it.

**The rules of demo mode**

- Nothing is sent to Supabase, to Stripe or anywhere else.
- The data lives in server memory. Restart and you are back to the seed.
- There is a single signed-in session on the server. You cannot be two different people in two browsers.
- The Stripe webhook endpoint stays shut and answers 503. The fake checkout does not verify signatures, so leaving the endpoint open would hand anyone a way to rewrite the subscriptions table.
- Nothing leaves the machine. The invitation screen says the email was sent, but **nothing is sent** — and nothing is logged either. The link is shown on the spot; use that.

**Do not run demo mode anywhere public.** Every visitor signs in as the same demo person and sees the same data. In production (`NODE_ENV=production`), `STARTER_FAKE=1` on its own does not turn demo mode on. If you really do want it there, add `STARTER_FAKE_ALLOW_PRODUCTION=1` as well.

## 5. A map of the folders

`src/` has four layers. **The direction of the arrows is the spine of this kit.**

```
app/  ──▶  src/server/  ──▶  src/ports/  ◀──  src/adapters/
                │                               fake / supabase / stripe / mail
                └──────────▶  src/core/  ◀──────────────┘
```

| Where | What it is for | The rule |
|---|---|---|
| `src/core/` | Pure logic: the permission table, input validation, plan quotas, subscription state, invitation tokens, reading the legal text | **It imports nothing** (`node:crypto` is the one exception). Importing `src/ports/` here is a bug |
| `src/ports/` | Four interfaces and nothing else: `AuthPort`, `DataPort`, `BillingPort`, `MailPort` | Supabase and Stripe types never leave through here |
| `src/adapters/` | The implementations: `fake/` (memory), `supabase/`, `stripe/`, `mail/` | They never import the layers above |
| `src/server/flows/` | The business flows, written as **functions that take the ports as an argument** | They touch neither `next/headers` nor `next/navigation`, which is why they test directly |
| `src/server/ports.ts` | Composition root. **The only file that reads environment variables** | It is also the only thing that knows whether you are in demo mode |
| `app/_actions/` | Server Actions: read the form, build the context, call the flow, refresh the page | They never touch a port or an SDK directly |
| `app/` screens | Presentation | Importing `src/adapters/` here is a bug |

Tests enforce the direction (`test/pages.test.ts`, `test/flows/billing.test.ts`). Break it and the suite goes red.

**Every flow checks three things in this order:** are you signed in, are you in this organisation, is your role sufficient. An organisation id that arrives from the browser is never trusted as it stands: `memberships` is re-read every time. The database policies are the second line of the same defence.

## 6. Connecting Supabase

### 6-1. Locally (1 hour)

You need Docker (Docker Desktop or OrbStack) and the Supabase CLI.

```bash
supabase start
supabase db reset
```

Copy the `API URL`, the `anon key` and the `service_role key` printed by `supabase start` into `.env.local`, and **empty** `STARTER_FAKE`.

```
STARTER_FAKE=
NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
NEXT_PUBLIC_SUPABASE_ANON_KEY=…
SUPABASE_SERVICE_ROLE_KEY=…
NEXT_PUBLIC_SITE_URL=http://localhost:3020
```

> **If another Supabase project is already running on this machine, change `project_id` and the four ports (`api`, `db`, `studio`, `inbucket`) in `supabase/config.toml` before you start.** Otherwise you will connect to that other project. `npm run test:rls` checks that it is talking to this kit's project before it runs any SQL, and stops without touching anything if it is not.
>
> The migrations expect to be applied as the `postgres` role, which is what `supabase db reset` does.

Run `npm run dev` and sign up at `/signup`.

**You are done when all of this is true.**

1. After signing up you are told to check your email. **No session is created.**
2. The message is waiting at `http://127.0.0.1:54324` (Inbucket). Following the link signs you in.
3. `/onboarding` lets you create an organisation.
4. An invitation created in `/app/settings/organization` can be accepted in another browser, by another address that has signed up, through that link.
5. Studio (`http://127.0.0.1:54323`) shows rows in `profiles`, `organizations`, `memberships`, `projects` and `invitations`.

> **Leave `enable_confirmations = true` in `supabase/config.toml`.** With it off, the sign-up response differs depending on whether the address is already registered, which lets anyone probe who has an account. Locally the confirmation mail simply piles up in Inbucket, so there is no cost to leaving it on.

### 6-2. A hosted Supabase project (30 minutes)

1. Create a project at [supabase.com](https://supabase.com).
2. Apply the migrations from your machine.

   ```bash
   supabase link --project-ref <your project ref>
   supabase db push
   ```

3. Put the URL and the two keys from "Project Settings → API" into your host's environment variables.
4. Set `Site URL` under "Authentication → URL Configuration" to your production URL, and add `https://<your domain>/auth/callback` to `Redirect URLs`.
5. Paste the four templates from `supabase/templates/` into "Authentication → Emails" (§8).
6. **Set up custom SMTP under "Authentication → Emails → SMTP Settings". This is required.** Supabase's built-in sender is for trying things out: it only delivers to members of your Supabase organisation and is tightly rate limited. Left as it is, your customers' sign-up confirmations, magic links and password-reset emails **will not arrive**. Enter the SMTP host, port, user, password and sender from your email provider, such as Resend (https://supabase.com/docs/guides/auth/auth-smtp ).
7. Double-check that `https://<your domain>/auth/callback` is in `Redirect URLs`. Password-reset emails also pass through it before landing on the new-password screen.

`SUPABASE_SERVICE_ROLE_KEY` is for the server only. It must never reach the browser, and `npm run check:bundle` is what keeps it that way (§16).

After deploying, `npm run build` compiles and `npm run start` serves (on Vercel both happen for you).

### 6-3. Google sign-in (optional)

Alongside passwords and magic links, you can offer a Google button.

1. Create an OAuth client in Google Cloud.
2. Enter the client id and secret under "Authentication → Providers → Google" in Supabase. To try it locally, set `enabled = true` under `[auth.external.google]` in `supabase/config.toml` and supply `SUPABASE_AUTH_EXTERNAL_GOOGLE_CLIENT_ID` and `SUPABASE_AUTH_EXTERNAL_GOOGLE_SECRET`.
3. Give `NEXT_PUBLIC_ENABLE_GOOGLE_LOGIN` a value in this kit. The button appears only when that value is non-empty.

`skip_nonce_check` in `config.toml` is a local convenience. **Set it to `false` in production.**

### 6-4. The tables

| Table | What it holds | Who can see it |
|---|---|---|
| `profiles` | Name, email, language | Your own row, and the rows of people in your organisations |
| `organizations` | Organisation name | Organisations you belong to |
| `memberships` | Who is in which organisation, in which role | Organisations you belong to. **This table is where visibility comes from** |
| `invitations` | Invitations (token hash, expiry, status) | Owners and admins |
| `projects` | Projects, per organisation | Organisations you belong to |
| `subscriptions` | One row per organisation | Members can read. Only the server can write |
| `stripe_customers` | Organisation to Stripe customer id | Nobody |
| `stripe_events` | Ids of webhook events already handled | Nobody |
| `audit_logs` | Record of organisation actions (1.1.0) | Owners and admins can read. Only database triggers write |
| `rate_limits` | Rate-limit counters (1.1.0) | Nobody. Only the service-role function `rate_limit_hit` writes |

There is also `plan_limits`, which stores the quota per plan and which signed-in users may read.

The policies are written through two helpers, `is_member(org)` and `member_role(org)`. Anonymous visitors can do nothing at all in any of the tables.

## 7. Connecting Stripe

The Stripe account is yours. Everything below is in **test mode**; no real money moves.

### 7-1. Keys, prices and the customer portal (6 minutes)

1. Switch the dashboard to **test mode**.
2. Copy the secret key (`sk_test_…`) from "Developers → API keys".
3. Under "Product catalogue", create two products, each with a **monthly, JPY, tax-inclusive** price (the samples are ¥2,980 and ¥9,800). Note both price ids (`price_…`).
4. Open "Settings → Billing → Customer portal" and do three things.
   - **Enable** the portal (without it, the manage-billing screen will not open).
   - **Allow** switching plans.
   - **Register both prices** from step 3 as switch targets.

   **In this kit, plan changes happen only in the customer portal.** While a subscription is live, the app does not offer the subscribe button at all, because offering it would let a second subscription start and bill the customer twice. Skip this step and your customers will not be able to change plans.

### 7-2. Put the keys in place (3 minutes)

In `.env.local`, in the order used by `.env.example`.

```
STARTER_FAKE=
NEXT_PUBLIC_SUPABASE_URL=…
NEXT_PUBLIC_SUPABASE_ANON_KEY=…
SUPABASE_SERVICE_ROLE_KEY=…
STRIPE_SECRET_KEY=sk_test_…
STRIPE_WEBHOOK_SECRET=
STRIPE_PRICE_STANDARD=price_…
STRIPE_PRICE_BUSINESS=price_…
NEXT_PUBLIC_SITE_URL=http://localhost:3020
```

`STRIPE_WEBHOOK_SECRET` is filled in by the next step.

**`STARTER_FAKE` must be empty.** Left at `1`, the kit never calls Stripe, and **the webhook endpoint stays shut** and answers 503.

### 7-3. Forward the events to your machine (2 minutes)

```bash
stripe login
stripe listen --forward-to localhost:3020/api/stripe/webhook --events checkout.session.completed,customer.subscription.created,customer.subscription.updated,customer.subscription.deleted,invoice.payment_failed
```

Put the `whsec_…` that `stripe listen` prints into `STRIPE_WEBHOOK_SECRET`, then start `npm run dev` in another window.

After `Ready!`, confirm that each payment prints a matching `-->` and `<-- [200]` line. If nothing prints, you're missing `--forward-to`.

**That secret changes every time you restart `stripe listen`, and it is not the same as the one you register in the dashboard.** This is the step people trip over.

### 7-4. Subscribe once, end to end (5 minutes)

1. Sign in at `http://localhost:3020` and open `/app/settings/billing`.
2. Press "Choose this plan" on Standard.
3. Pay with a test card.
   - Succeeds: `4242 4242 4242 4242`, any future expiry, any three-digit CVC, any postcode
   - Requires authentication: `4000 0025 0000 3155`
   - Attaches but fails on the invoice, which is how you see `past_due`: `4000 0000 0000 0341`

**Three places to look**

| Where | What correct looks like |
|---|---|
| The `stripe listen` window | `checkout.session.completed` and `customer.subscription.created` (and `.updated`) all answered **200**. Event types the kit ignores, such as `invoice.paid`, are answered 200 too |
| The database | One row in `stripe_customers` for the organisation, one row in `subscriptions` with `plan_id = standard`, `status = active` and a `current_period_end`, and the event id in `stripe_events` |
| The screen | `/app/settings/billing` now reads Standard and the project quota is 50. The subscribe button is gone and "Manage billing" is in its place |

**With the card that requires authentication**, the status stays `incomplete` until the customer finishes the challenge. Until then the screen shows a "waiting for the payment to be confirmed" banner and **the quota stays at the Free-plan level**. Once the payment is confirmed the status becomes `active` and the quota follows.

### 7-5. Change the plan (2 minutes)

1. Press "Manage billing" to go through to the Stripe portal.
2. Choose Business under "Change plan".
3. Coming back, `customer.subscription.updated` arrives with a 200, `plan_id` in `subscriptions` becomes `business`, and the quota becomes unlimited.

If "Change plan" is not offered, the fourth item of §7-1 is not finished.

### 7-6. Cancellation, and the guards (2 minutes)

1. "Manage billing" → cancel. `customer.subscription.deleted` arrives with a 200, `subscriptions` becomes `plan_id = free` and `status = canceled`, and a banner appears.
2. Check the signature handling.

   ```bash
   curl -i -X POST localhost:3020/api/stripe/webhook -d '{}'
   curl -i localhost:3020/api/stripe/webhook
   ```

   The first is a 400 (the signature cannot be verified) and the second a 405. The bodies are one short English line. **The first returns 400 even when the secret is missing**, so that the status code does not reveal whether it is configured.
3. Missing secret: empty `STRIPE_WEBHOOK_SECRET`, restart, and send one more event from the `stripe listen` window. You will see **503 not configured**. It is a 5xx rather than a 4xx so that Stripe retries; put the secret back and the events that queued up arrive after all.
4. Sending a chosen event type:

   ```bash
   stripe trigger customer.subscription.updated
   ```

   **Nothing in your database changes, and that is correct.** This command makes Stripe create a brand-new customer each time. That customer is not in your `stripe_customers`, so there is no organisation to attribute the subscription to, and the kit answers 200 without touching a table. One line appears in the server log, with the first few characters of the customer id and the event type. **If that line ever appears for a real subscription, it means events are not landing.**

### 7-7. Registering the endpoint for production

Add one endpoint under "Developers → Webhooks", with the URL `https://<your domain>/api/stripe/webhook`, and select **these five types only**.

`checkout.session.completed` / `customer.subscription.created` / `customer.subscription.updated` / `customer.subscription.deleted` / `invoice.payment_failed`

Put the signing secret (`whsec_…`) shown after registering into the production `STRIPE_WEBHOOK_SECRET`. **This is the live endpoint's secret and is a different value from the one `stripe listen` printed in §7-3.** Leave the local one in place and live events stop at 400.

### 7-8. How billing is modelled

- A subscription belongs to **an organisation, one row each**. The screens read the `subscriptions` table; they never call Stripe on render.
- Events may arrive out of order, so the kit re-fetches the current state from Stripe before writing. The same `event.id` is never processed twice.
- Access stops on four statuses: `canceled`, `unpaid`, `incomplete_expired` and `incomplete`. **`past_due` does not stop anything**; it shows a banner and leaves the service running. Until a first payment is confirmed, the customer is on the Free-plan quota.
- "Stopping" means falling back to the Free-plan quota. **No data is deleted.** Projects over the quota are still readable; the customer simply cannot create new ones.
- **Hiding the subscribe button, and refusing to delete an organisation, are a different question.** Those two ask whether Stripe still holds a subscription at all — every status except `canceled` and `incomplete_expired`, so six of the eight. `incomplete`, for instance, stops access but may still become active and start billing; letting a second checkout through there gives one customer two subscriptions. The list lives in `hasOpenSubscription` in `src/core/billing-state.ts` and in the database trigger `organizations_guard_delete`, and `test/plan-limits.test.ts` compares the two.
- There are two ways to handle consumption tax. **The sample uses tax-inclusive prices**, and the amounts in `plans.config.ts` are shown as tax-inclusive. To add tax on top instead, enable Stripe Tax and create the prices exclusive of tax — and change the wording on the screens to match.

"Manage billing" is shown even before a first subscription exists. Pressing it then returns the notice that no billing record was found.

**If two subscriptions end up live**

The app hides the subscribe button while Stripe still holds a subscription, and presses within the same ten-minute window collapse into a single checkout (only a press either side of that boundary can open two). Even so, **two windows opened separately and both carried through to payment** can create two subscriptions; that is beyond what the payment layer can prevent. Either ask the customer to cancel one from "Manage billing", or cancel it yourself under "Customers → that customer → Subscriptions". Since `subscriptions` holds one row per organisation, the screen reflects whichever event arrived last.

### 7-9. Qualified invoices (Japan's invoice system)

If you are registered as a qualified invoice issuer, show **the same registration number in two places: the commercial-transactions notice and your Stripe invoices.**

1. Put the number in `invoiceRegistrationNumber` in `legal.config.ts`, as `T` followed by 13 half-width digits. Anything else stops both `npm test` and the notice page. Leave it empty if you are not registered, and the field does not appear at all.
2. In the Stripe Dashboard, under "Settings → Billing → Invoices", add an account tax ID of type "JP TRN" with the same number and make it the **default tax ID shown on invoices**. Default tax IDs are added automatically to invoice and receipt PDFs finalised from then on. A finalised invoice cannot be edited, so do this **before your first customer**.
3. On the same screen, make the business name and address on invoices match `legal.config.ts`.
4. A qualified invoice must show the tax amount per rate. The sample prices here are **tax-inclusive** (10%; see §7-8). Attach the 10% rate to the price with Stripe tax rates or Stripe Tax, and confirm once in test mode that the PDF shows the tax amount.

If you create invoices through the API, create the account tax ID first and pass it in the invoice's `account_tax_ids`. Stripe's guide: https://docs.stripe.com/tax/invoicing/tax-ids

> The field is for display. Whether an invoice meets the requirements depends on how you trade, so please check with a tax accountant.

## 8. Email

Mail comes from two places.

| Sender | Message | Configured in |
|---|---|---|
| This kit | Invitations | `RESEND_API_KEY` and `MAIL_FROM` |
| Supabase | Sign-up confirmation, magic link, password reset, email change | `supabase/config.toml` and `supabase/templates/`. **Production needs custom SMTP** (§6-2). There is no change-email screen yet; only its template ships (§2) |

**Resend is optional.** Without `RESEND_API_KEY`, invitation text goes to the server log. The invitation link is also shown once, on the spot, on the screen that created it, so you can pass it on without reading the log.

To use it, create a key at [resend.com](https://resend.com), verify your sending domain, and set the two variables. `MAIL_FROM` accepts the `SaaS Starter <no-reply@example.com>` form. The key is read on every send, so adding it after the server is running still works.

**The four Supabase messages are supplied in Japanese only.** They are the four HTML files in `supabase/templates/`. Supabase holds one set of templates, so if you need English as well, write both languages into the same message. The subject lines live in `supabase/config.toml`. If you change how long the links stay valid (`otp_expiry`), change the "1 hour" in the template bodies to match.

Every message this kit sends is plain text. It never assembles HTML, which keeps encoding mistakes and injection out of the picture.

## 9. The legal templates

There are six documents in `legal/`: the Japanese commercial-transactions notice, the terms of service and the privacy policy, each in Japanese and English. The values they interpolate are collected in `legal.config.ts`.

> **These templates are not guaranteed to be usable as they are. Please have a lawyer or another qualified professional review them before you publish.** What they need to say depends on how your business is set up.

### How to edit them

0. **Renaming the service means four places.** Change one and the screens, the legal pages and the emails disagree with each other.

   | Where | What it appears in |
   |---|---|
   | `serviceName` in `legal.config.ts` | The body of the three legal documents, and the signature on invitation emails |
   | `common.appName` in `messages/en.json` (and `messages/ja.json`) | Headings and navigation on screen |
   | The four subject lines in `supabase/config.toml` | Sign-up confirmation, magic link, password reset, email change |
   | The four signatures in `supabase/templates/*.html` | The foot of those same four emails |

   Editing only `legal.config.ts` turns `test/adapters/mail.test.ts` red — that is the check telling you `config.toml` and the templates still carry the old name. `common.appName` in the Japanese file is compared against `serviceName` (`test/messages.test.ts`); the English file is free to use a different rendering of the name.

1. Replace the values in `legal.config.ts` with your own: trading name, responsible person, address, telephone number, contact address, how prices are stated, the refund position, the last-updated date, and so on. Fill in `invoiceRegistrationNumber` only if you are a registered qualified invoice issuer (§7-9).
2. Edit the body text in `legal/*.ja.txt` to match your service.
3. Do the same for `legal/*.en.txt`.

**Anything left blank is rendered as "not filled in"**, and a banner at the top of the page says that some fields are still template defaults. That way a forgotten field is obvious the moment the page is opened.

**Japanese is the authoritative version.** The English is a summary translation. When you publish both, edit the Japanese first and then bring the English into line; `test/core/legal.test.ts` watches for fields that drift apart.

Avoid putting "a short word, a colon and a space" (a word of 30 characters or fewer) inside a value. The interpolated line would then be read as a definition list rather than a paragraph.

The three legal pages read `legal/*.txt` from the deployed directory. `outputFileTracingIncludes` in `next.config.ts` is what carries those files into the deployment. Remove it and those three pages alone return 500.

## 10. Changing the plans

**There are two places to edit.**

1. `plans.config.ts` — the plan table on screen, the quota check, and the link to the Stripe price
2. `plan_limits` in `supabase/migrations/…_init.sql` — the quota on the database side

```ts
// plans.config.ts
{
  id: "standard",
  nameKey: "plan.standard.name",
  descriptionKey: "plan.standard.description",
  monthlyYen: 2980,
  projectLimit: 50,          // -1 means unlimited
  priceEnvName: "STRIPE_PRICE_STANDARD",
}
```

```sql
-- plan_limits (null means unlimited)
insert into public.plan_limits (plan_id, project_limit) values
  ('free', 3),
  ('standard', 50),
  ('business', null);
```

To change only the price, edit `monthlyYen` and the Stripe price. **To change a quota, edit both places.** Edit only one and the notice on screen disagrees with what the database enforces. `test/plan-limits.test.ts` compares the two.

**Adding a plan**

1. Add an entry to `plans.config.ts`, with a new name in `priceEnvName`.
2. Add that variable to `.env.example`.
3. Write a migration that adds a row to `plan_limits`, and add the name to the `check` on `subscriptions.plan_id`. A check constraint is replaced rather than edited, so write it like this.

   ```sql
   -- a new migration file; the first one stays as it is
   insert into public.plan_limits (plan_id, project_limit) values ('pro', 200);

   alter table public.subscriptions drop constraint subscriptions_plan_id_check;
   alter table public.subscriptions
     add constraint subscriptions_plan_id_check
     check (plan_id in ('free', 'standard', 'business', 'pro'));
   ```

   `test/plan-limits.test.ts` reads every file under `supabase/migrations/` in name order and takes **the last definition it finds**, so what you add in a later migration counts.
4. Add the name and description keys to `messages/ja.json` and `messages/en.json`.
5. Create the price in Stripe and register it as a switch target in the customer portal.

To retire a plan, move its subscriptions first. A plan name left in the table that the config no longer knows is treated as the Free quota.

## 11. Adding a feature

Here is the order for adding one table. `projects` is the worked example. Follow the same order and the tests will notice if you skip a step.

| Step | What to do | Worked example |
|---|---|---|
| 1 | Add the table in a migration | `projects` in `supabase/migrations/…_init.sql` |
| 2 | Write the row-level policies | `projects_select` and the four others in `…_rls.sql` |
| 3 | Add the policy tests | `supabase/tests/rls_test.sql` and `test/rls.test.ts`. **Raise the count in `select plan(n);` by however many assertions you add** — otherwise pgTAP stops with "planned n but ran m" |
| 4 | Add the methods to the port | `listProjects` and friends in `src/ports/data.ts` |
| 5 | Implement them in the fake | `src/adapters/fake/data.ts` |
| 6 | Implement them for real | `src/adapters/supabase/data.ts` and `rows.ts` |
| 7 | Write the flow | `src/server/flows/projects.ts` |
| 8 | Build the screen and the action | `app/app/projects/page.tsx` and `app/_actions/projects.ts` |

**Steps 2 and 4 go together.** A port method without policies returns zero rows against the real database. It works in demo mode and empties out the moment you connect, which is a confusing way to find out.

**Anything that counts before it writes belongs in a SQL function.** Counting, checking and writing in three separate JavaScript statements lets two simultaneous requests both through. `create_project_guarded` is the example: `security definer` plus `pg_advisory_xact_lock`, so requests pass one at a time.

**Do not skip step 5.** Without the fake implementation, the demo-mode screen throws on the spot, and so does the demo you show your buyers.

### Making it single-user (one fixed organisation)

For a service people use on their own, such as a notes app with no teams, you can keep organisations and roles out of sight. The tables and policies stay as they are; one organisation with one owner already works under the current rules.

1. Set `MAX_ORGS_PER_USER` in `src/server/flows/organizations.ts` to `1`.
2. Match it in the database: in `create_organization_guarded` in `supabase/migrations/20260920000200_functions.sql`, change the `10` in `least(p_max_per_user, 10)` to `1`. If that migration is already applied in production, add a new migration that redefines the function with `create or replace` (`test/plan-limits.test.ts` checks the two numbers agree).
3. Remove "Organization" and "Audit log" from the navigation in `app/app/settings/layout.tsx`, and remove the organisation switcher form from `app/app/layout.tsx`. That also removes the way into the invitation screens.
4. The first organisation is still created on `/onboarding`. Rewording the `onboarding.*` strings to something like "workspace name" hides the word "organisation" entirely.
5. Billing stays per organisation, which, with one organisation per person, is the same as billing per person.

## 12. Changing the look

Colours and shapes are CSS custom properties in `app/globals.css`, all prefixed `--st-`. The same names appear three times: the light palette (`:root`), the dark palette (`@media (prefers-color-scheme: dark)`) and the forced-dark palette (`[data-st-theme="dark"]`). **Change all three together.**

| Property | What it colours |
|---|---|
| `--st-bg` | Page background |
| `--st-surface` | Cards and panels |
| `--st-surface-2` | A recessed surface, such as table headers |
| `--st-border` | Rules and outlines |
| `--st-text` | Body text |
| `--st-text-muted` | Secondary text |
| `--st-accent` | Primary buttons and links |
| `--st-accent-text` | Text on the accent |
| `--st-accent-soft` | A pale accent background |
| `--st-ok` / `--st-ok-soft` | Success |
| `--st-warn` / `--st-warn-soft` | Attention |
| `--st-danger` / `--st-danger-soft` | Error |
| `--st-radius` / `--st-radius-sm` | Corner radii |
| `--st-gap` | Base spacing unit |
| `--st-shadow` | Shadow |
| `--st-font` | Type stack |

Use the three status colours on rules, marks and heading dots — not for body text. Pairing the pale background (`--st-*-soft`) with `--st-text` is what keeps the contrast right in the dark palette.

Classes are CSS Modules. Each screen has its own `*.module.css`, and the shared pieces live in `app/_components/ui.module.css`. There is no CSS framework in the way, so adding Tailwind or anything else is entirely up to you.

When `prefers-reduced-motion: reduce` is set, transitions are turned off.

## 13. Languages

The interface strings are `messages/ja.json` and `messages/en.json`, around 260 keys each. **A key missing from either file fails the suite** (`test/messages.test.ts`).

The language is chosen in this order.

1. The language cookie (`st_lang`)
2. The profile setting
3. The browser preference (`Accept-Language`)
4. Japanese, as the default

The three legal pages, and only those, also respond to `?lang=en`.

**Adding a language**

1. Add it to `Lang` and the language list in `src/core/i18n.ts`.
2. Create `messages/<language>.json` with every key the Japanese file has.
3. Create `messages/error-page.<language>.json` too — the three-key file that the error screen reads on its own.
4. Write a migration that adds the name to the `check` on `profiles.lang`.
5. If you publish the legal pages in it, add three `legal/*.<language>.txt` files.
6. **Add those three to `SOURCES` in `src/server/legal.ts` as well.** That is a static table with the file names written out in full, so the build tracer knows to carry them into the deployment. Forget it and the kit logs one line and serves **the Japanese text** on those three pages instead (it does not return 500).

Currency and date formatting live in `formatYen` and `formatDate` in `src/core/i18n.ts`. If you change currency, change those two and the field names in `plans.config.ts` together.

## 14. The operator page

`/admin` is a read-only overview for whoever runs the service. **It never writes anything.**

Put comma-separated addresses in `ADMIN_EMAILS`. Surrounding spaces and letter case do not matter.

```
ADMIN_EMAILS=you@example.com, ops@example.com
```

**While that variable is unset, `/admin` is a 404.** When it is set, anyone not on the list also gets a 404 — not a 403 and not a redirect to sign-in, so that the page's existence stays invisible from outside.

It shows three lists.

| List | Columns |
|---|---|
| Organisations | Name, member count, project count, created date, plan, status |
| People | Name, email, registered date |
| Subscriptions | Organisation name, period end, plan, status |

Stripe subscription ids, customer ids and invitation tokens are never shown, and there is no search box. **The count is the number of rows on that page**, not the total. Pages hold 50 rows, with previous and next links below.

The page is marked `noindex` and is never cached.

## 15. Security rules

### What the kit does

- **Keys stay on the server.** Every file that reads `SUPABASE_SERVICE_ROLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `RESEND_API_KEY` or `ADMIN_EMAILS` starts with `import "server-only";`. `npm run check:bundle` rebuilds the app and proves none of them reached the browser bundle.
- **The session cookie is not readable from browser JavaScript** (`httpOnly`), and carries `secure` over https and in production.
- **Every flow checks three things in order**: signed in, member of this organisation, sufficient role. An organisation id from the browser is never trusted as given.
- **Row-level security is the second line.** It is enabled on every table, and anonymous visitors can read nothing.
- **Organisation actions are recorded by database triggers.** Nothing in the app writes the audit log, so every path that changes a table leaves a record, and no member can add to or remove from it.
- **Changing a password and deleting an account require re-authentication.** The current password is asked for (counted against the same rate limits as sign-in). It can be skipped only by a session that proved control of the email address (reset link or sign-in link) within the last 10 minutes, judged solely from the `amr` claim of a signature-verified JWT. Changing the password signs out your other sessions. `secure_password_change` is `true` in `supabase/config.toml`; enable "Secure password change" in your hosted project too.
- **Account deletion happens in one transaction, in the `delete_account` database function.** Every check that can fail (re-authentication, organisation roles, subscription ids) runs first, then Stripe cancels, then the function is called once. Only the service role can call it, so a stolen session alone cannot skip re-authentication.
- **The last owner of an organisation that still has other members cannot delete their account.** Both the flow and a database trigger (`profiles_before_delete`) refuse. An organisation with nobody else in it goes with the account, including when the user is deleted directly in Studio; if it still has a live subscription, the trigger refuses (ST005).
- **Deleted users' email addresses do not stay in the audit log.** Deletion blanks every entry whose target was that address. Actions with nobody signed in (billing events, account deletion, edits in Studio) are recorded with the actor "system".
- **Rate-limit keys never contain a raw email address or IP.** The whole key is HMAC-SHA256'd with a server-only secret, `RATE_LIMIT_PEPPER`. In production, `RATE_LIMIT_PEPPER` must be set to at least 32 characters (generate it with `openssl rand -hex 32` or similar); without it, sign-in and similar requests stop with an explanatory error. Locally and in demo mode it may stay empty.
- **A platform limit applies to password changes.** This kit's screen asks for the current password before changing it. However, a stolen session (less than 24 hours since sign-in) can call Supabase's `PUT /auth/v1/user` directly with the anon key and change the password without going through this screen. `secure_password_change` only asks for a nonce once 24 hours have passed since sign-in, and Supabase has no setting to always require it. Mitigations: (1) keep the XSS surface minimal (keep the no-`dangerouslySetInnerHTML` rule and add a Content-Security-Policy), (2) keep the JWT lifetime short (`jwt_expiry` in `supabase/config.toml`, one hour today), and (3) sign out other sessions after a change, which the kit already does. **Account deletion is not affected**: `delete_account` is callable by the service role only, so a session alone cannot reach it.
- **Webhook bodies are verified before they are read**, are capped at 1 MiB, and each `event.id` is recorded so it is handled once.
- **`dangerouslySetInnerHTML` appears nowhere.** Even the legal text is turned into an array of paragraphs before it becomes React elements.
- **Error messages carry nothing internal** — no SQL, no stack, no environment values. A code is mapped to a sentence for the screen.
- **Whether an address is registered cannot be probed.** Sign-up and sign-in answer the same way either way.

### What you need to keep doing

- **Never move `SUPABASE_SERVICE_ROLE_KEY` into a `NEXT_PUBLIC_` name.** That publishes it immediately.
- **Every new table needs policies.** Enabling row-level security without writing any policy gives you a table nobody can read — which you notice straight away. Writing `using (true)` gives you a table everybody can read — which you do not.
- **With Supabase connected, rate limits are counted in the database.** `RATE_LIMIT_STORE=memory` switches to in-memory counting, which restarts per instance and on every restart. On a platform like Vercel, leave `RATE_LIMIT_STORE` empty or set to `postgres`.
- **Set `TRUSTED_PROXY_HOPS` if you put two or more proxies in front of the app.** The client address the rate limiter counts is taken from `x-forwarded-for`, counting back from the end by the number of hops you trust. Unset means one hop, which is what a plain Vercel deployment looks like. Leave it at one behind Cloudflare → nginx → app and **the last entry is your own proxy, so the whole site shares a single bucket** — a modest burst of traffic locks everyone out of signing in. The first entry is whatever the caller typed, so it is never used. A request whose list is shorter than the number of hops did not come through your proxies; none of its values is used, and all such requests share a single bucket. The number of hops is capped at 8.
- **If you add write operations to `/admin`, log them.** It is read-only today, which is why a mistake there cannot spread.
- **Decide how long to keep the audit log.** A year is a reasonable default. `select public.purge_audit_logs(interval '365 days');` (service role only) removes older rows, and the pg_cron example below runs it daily. Keep the retention paragraph of your privacy policy in step.
- **If production logs "could not determine the client IP", fix your proxy settings.** It is logged once per server start; until fixed, the whole site shares a single rate-limit bucket.
- **Run `npm run check:bundle` before every release.** One stray import from a client component into a server file is enough to put a key name in the bundle.

### How rate limits are counted

There are two stores, and the composition root (`limiters()` in `src/server/ports.ts`) picks one.

| `RATE_LIMIT_STORE` | Where the counts live | Suited to |
|---|---|---|
| empty (default) | The database when the Supabase keys are set, memory otherwise | Anywhere |
| `postgres` | The `rate_limits` table, through the `rate_limit_hit` function | Vercel and anything else that runs several instances |
| `memory` | Server memory | A single instance, or trying it out locally |

Demo mode always uses memory, because it never leaves the machine.

In the database, "count, compare, write" happens inside a single call to `rate_limit_hit`. Eleven simultaneous attempts still stop at the eleventh (`supabase/tests/rls_test.sql` checks this). Only the service role may call it. Roughly once every hundred calls it also clears rows whose window started more than a day ago.

To use another store, such as Upstash Redis, implement `RateLimiter` from `src/server/ratelimit.ts` and return it from `limiters()`.

```ts
export interface RateLimiter {
  hit(key: string, now: Date): Promise<{ allowed: boolean; retryAfterSeconds: number }>;
}
```

There are four limits today. What each one counts **by** matters as much as the number.

| What | Counted per | Limit |
|---|---|---|
| Sign-in, sign-up, magic link, password reset | source address **and** email address, as a pair | 10 per 10 minutes |
| Sign-in, sign-up, magic link, password reset | source address | 50 per 10 minutes |
| Invitations sent | organisation | 20 per hour |
| Invitations accepted | source address | 20 per hour |

Because the first counts a pair, **spreading attempts across source addresses restarts the count** for a given email. What absorbs that is the second window, the 50 per source address. Re-entering the current password (password change, account deletion) is counted against the same two windows.

**Scheduled clean-up with pg_cron**

`rate_limit_hit` clears old rows roughly once every hundred calls, which means little clean-up while traffic is light. Enable `pg_cron` under "Database → Extensions" in Supabase and run this once in the SQL editor to clean up daily at 03:00 UTC. Old audit-log rows can be purged the same way.

```sql
select cron.schedule('saas-starter-rate-limits', '0 3 * * *',
  $$ delete from public.rate_limits where window_started_at < now() - interval '1 day' $$);
select cron.schedule('saas-starter-audit-logs', '30 3 * * *',
  $$ select public.purge_audit_logs(interval '365 days') $$);
```

## 16. Tests and checks

```bash
npm test              # vitest, 681 tests; no Docker and no keys required
npm run typecheck     # tsc --noEmit
npm run test:rls      # the database policies; needs Docker and the Supabase CLI
npm run check:bundle  # proves no key reaches the browser; rebuilds twice
npm run release:check # the publisher's own checks; not for your app, see below
npm run release       # runs release:check, then writes the zip to release/
```

`npm run test:watch` re-runs `npm test` as you edit.

**These six commands assume macOS or Linux.** `npm run release:check` sets an environment variable inline (`RELEASE_GATE=1 vitest …`) and `npm run check:bundle` launches `node_modules/.bin/next` directly. On Windows, run them from WSL.

**`npm run typecheck` expects `next-env.d.ts`.** That file is written by `next dev` or `next build` and is not in the zip. Running `typecheck` straight after unzipping works today, but narrowing `include` in `tsconfig.json` can make it fail; run `npm run build` once if it does (§19).

**`npm test` makes no network calls at all.** It runs against the fake implementations and a stubbed Stripe.

**`npm run release:check` belongs to whoever ships this kit, not to you.** It checks that the sample text carries no real place names, that the dependency list is still the agreed seven and five, and that the README and `.env.example` name the same environment variables. **You never have to run it.** Putting your own address in `legal.config.ts`, adding Tailwind, or introducing a new environment variable turns that check red and leaves `npm test` green.

**`npm run test:rls` starts your local Supabase and works against it.** It re-applies the migrations, runs the pgTAP suite in `supabase/tests/rls_test.sql`, and then the vitest suite that signs in as real users and checks what each role can and cannot do. It exits three ways.

| Exit | Meaning |
|---|---|
| 0 | Everything passed |
| 1 | Something failed |
| **2** | **Nothing was checked** — Docker is not running, the CLI is missing, the connection points somewhere else, and so on. The reason is printed on one line |

**Exit 2 is not a pass.** Wiring this into CI means treating 2 as a failure too. The first run takes a few minutes while the pgTAP image is pulled.

**`npm run check:bundle` inspects the real build** and runs outside `npm test`. It rebuilds twice, once in demo mode and once with keys, and reads both `.next/static` and the pre-rendered responses (`.html`, `.rsc`).

It then **starts the build on a free port and reads the responses themselves.** Every page in this kit is rendered per request (see the end of section 16 and section 17), so very little is ever written to disk. The leak this check cares about most — handing a whole subscription row to a client component — only shows up in a live response. It reads `/`, `/login` and `/legal/terms`, plus `/app` and `/app/settings/billing` signed in as the demo owner in demo mode. The port is chosen by the operating system each time, and the server is **always stopped afterwards**, including when something fails partway.

**If it reads nothing at all, or if even one page could not be fetched, it ends red rather than green.** "Looked and found nothing" and "never looked" must not print the same thing. That includes the case where only the signed-in pages (`/app`, `/app/settings/billing`) could not be fetched.

Because it injects canary values in place of the keys, **it deletes `.next` when it finishes. Run `npm run build` again before you ship or deploy.**

`npm run check:bundle -- --scan-only` reads only what is already on disk. It starts no server, so it is **the weaker check**, and it says so in its own output.

`npm run release` writes `release/saas-starter-v1.1.0.zip`. It contains no `node_modules`, no `.next` and no real `.env`.

## 17. Before you go live

The kit assumes Vercel, but anywhere that runs Node.js works the same way.

- [ ] `STARTER_FAKE` is **empty** (in production a `1` would not turn demo mode on anyway, but leave no room for doubt)
- [ ] `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` are all set
- [ ] `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_STANDARD` and `STRIPE_PRICE_BUSINESS` are all set, with live keys and the live endpoint secret
- [ ] `NEXT_PUBLIC_SITE_URL` is your production URL (checkout returns and invitation links are built from it)
- [ ] `Site URL` and `Redirect URLs` in Supabase point at production
- [ ] "Secure password change" is enabled in Supabase
- [ ] `RATE_LIMIT_PEPPER` holds a secret of at least 32 characters (`openssl rand -hex 32` or similar; without it, sign-in stops in production)
- [ ] Custom SMTP is set up in Supabase, and confirmation and reset emails reach addresses outside your Supabase organisation (§6-2)
- [ ] All five migrations are applied (including `rate_limits` and `audit_logs` from 1.1.0)
- [ ] If a reverse proxy sits in front, it **forwards `X-Forwarded-Host` and `X-Forwarded-Proto`** (leave them out and no form submits at all; see the note below)
- [ ] If two or more proxies sit in front, `TRUSTED_PROXY_HOPS` is set to that number (§15)
- [ ] `enable_confirmations` is still `true`
- [ ] The Stripe endpoint is registered with **exactly the five event types**
- [ ] The customer portal is enabled, plan switching is allowed, and both prices are registered
- [ ] `legal.config.ts` and the six files in `legal/` carry your own details (no "still on the template" banner)
- [ ] The quotas in `plans.config.ts` and `plan_limits` agree
- [ ] `ADMIN_EMAILS` is either filled in deliberately or deliberately left empty
- [ ] `npm test`, `npm run typecheck`, `npm run test:rls` and `npm run check:bundle` all pass
- [ ] `npm run build` has been run again after `check:bundle`
- [ ] `RATE_LIMIT_STORE` is empty or `postgres`, if you run more than one instance (`memory` counts per instance)
- [ ] If you are a qualified invoice issuer, the registration number is in both `legal.config.ts` and your Stripe invoices (§7-9)
- [ ] Your platform does not rate limit `/api/stripe/webhook` too tightly

That last one matters. Stripe delivers events in bursts, and a tight platform-level limit drops them. On the other hand, no limit at all leaves the endpoint exposed to guessing. **Signatures are verified at the door, so set the endpoint's request limit at the platform — in your Vercel configuration or your reverse proxy.** The kit deliberately applies no limit of its own there.

> **Deployed without keys, `/app` and `/admin` return 500.** The screen shows an error; the reason goes to the server log only. `/`, `/login` and the three legal pages open without keys.
>
> `/` is rendered on every request, because the plan table is drawn from `plans.config.ts`. It is never cached.
>
> **Behind a reverse proxy, forward `X-Forwarded-Host`.** Every form here is a Next.js Server Action, and Next compares the caller's `Origin` with the `Host` it received (or `X-Forwarded-Host`). If they disagree, the request is rejected. Forget the header and **sign-in, creating an organisation, invitations, projects and billing all fail silently** — the screen says only that something unexpected went wrong, which is a poor place to start debugging. Fix it in the proxy, or declare your production origin with `serverActions.allowedOrigins` in `next.config.ts`.

## 18. What it costs

You can start at zero while you are trying it out. Here is where the money starts, taken from the published price lists.

**The figures below were checked on the official pricing pages in September 2026. Prices change. Check the links before you commit.**

| Service | What is free | Where it starts costing | Source |
|---|---|---|---|
| Supabase | Free ($0): 500 MB of database, 50,000 monthly active users. **Projects pause after a week of inactivity**, and two may be active | Pro is $25/month; Team is $599/month | https://supabase.com/pricing |
| Vercel | Hobby ($0), **for personal, non-commercial use only** | Pro is $20 per seat per month | https://vercel.com/pricing |
| Stripe | No setup fee and no monthly fee | 3.6% per successful domestic card payment in Japan, plus 0.7% for Billing | https://stripe.com/jp/pricing |
| Resend | Free ($0): 3,000 emails a month, 100 a day | Pro from $20/month | https://resend.com/pricing |

**Putting it together**

- While you are trying things out: Supabase Free, Vercel Hobby, Stripe (nothing until you have customers) and Resend Free. **Zero a month.**
- Once you have customers: Vercel needs Pro for commercial use, and Supabase Pro is the sensible choice so that nothing pauses. That is **about $45 a month** to begin with.
- On top of that, Stripe takes 4.3% (3.6% plus 0.7%) of what you collect.

Thirty customers on Standard (¥2,980) come to ¥89,400 a month, with roughly ¥3,844 in Stripe fees. After the $45 of hosting, about ¥78,000 is left (converting at ¥150 to the dollar, roughly the September 2026 level; rates move).

Remember that a Supabase Free project pauses after a week of inactivity. It is worth keeping in mind if you leave a customer demo on the free tier.

## 19. Troubleshooting

| Symptom | Cause | What to do |
|---|---|---|
| Signing in bounces back to the sign-in page | The return URLs disagree | Make `NEXT_PUBLIC_SITE_URL` match `Site URL` and `Redirect URLs` in Supabase |
| The magic link never arrives | A Supabase email setting | Check that link sign-in is enabled under "Authentication → Providers → Email". Locally, mail collects in Inbucket at `http://127.0.0.1:54324` |
| Signing up does not sign you in | By design | Follow the link in the confirmation mail. Turning `enable_confirmations` off leaks who has an account |
| Clicking the confirmation link bounces back to sign-in (`error=wrong_browser`) | The link was opened in a different browser than the one used to sign up (the PKCE cookie is missing) | Reopen the link in the original browser, or sign in below with your password. Requesting a fresh confirmation email also works |
| Pages load but every list is empty | A row-level policy is blocking | Check there is a `memberships` row for that person. A new table needs its policies written too |
| `/app` returns 500 | Keys are missing | Check the three Supabase variables. The reason is in the server log |
| `/admin` returns 404 | `ADMIN_EMAILS` is unset, or that address is not on it | Set the variable and check the signed-in address is listed |
| `/admin` returns 500 | Keys are missing | Same as `/app`. If only `ADMIN_EMAILS` were the problem, you would get a 404 |
| Webhook events never land | Work through it in order | (1) The endpoint's reply — **400** means a missing header or the wrong secret, **503** means no secret or `STARTER_FAKE=1`, **500** means the write failed. (2) The `stripe listen` window. (3) The `stripe_events` rows. (4) Whether that customer is in `stripe_customers` |
| `stripe trigger` changes nothing | That is correct | It creates a new customer every time, and that customer is not in your `stripe_customers`, so the kit answers 200 without touching a table |
| Re-subscribing to the same plan right after cancelling lands on a finished checkout | The key that collapses repeated presses into one is rotated every ten minutes, so within the same window the previous checkout comes back | Wait a few minutes, or choose a different plan in the meantime |
| In production, confirmation or reset emails never arrive | You are still on Supabase's built-in sender | Set up custom SMTP under "Authentication → Emails → SMTP Settings" (§6-2). The built-in sender only delivers to members of your Supabase organisation |
| The reset link says it may have expired | The link is over an hour old, or was opened in a different browser from the one that asked for it | Ask for a new reset email in the same browser |
| Invitation emails never arrive | `RESEND_API_KEY` is set but `MAIL_FROM` is not | Resend is only used when both are present. With just one of them the kit falls back to the console mailer, so look for a `[mail] to=… subject=…` line in the server log (if that line is there, the email did not leave the server) |
| Customers cannot change plan in the portal | A Stripe setting | Under "Settings → Billing → Customer portal", allow plan switching and register both prices |
| Only the three legal pages return 500 | The text files did not come along | Restore `outputFileTracingIncludes` in `next.config.ts` |
| `supabase start` will not start | The ports are taken | Check whether another Supabase is running. Changing `project_id` and the four ports in `supabase/config.toml` lets them run side by side |
| `npm run test:rls` exits 2 | Nothing was checked | Read the one-line reason: Docker is not running, the CLI is missing, or it is connected elsewhere |
| `npm run typecheck` stops on `next-env.d.ts` | That file is generated by the build | It does not happen with the `tsconfig.json` as shipped, but narrowing `include` can bring it back. Run `npm run build` once if it does |
| `npm run build` fails | Environment variables are being read somewhere new | Only `src/server/ports.ts` may read them. Reading them elsewhere fails the build |
| The build runs on fake keys | You just ran `check:bundle` | Run `npm run build` again; `check:bundle` builds with canary values |
| `tsconfig.json` changes by itself | `next dev` rewrites it | It adjusts `jsx` and `include`. Committing the result is fine |
| The delete-account button is missing and "Some organizations need your attention first" appears | You are the only owner of an organisation that has other members | Make someone else an owner in that organisation's settings, or delete the organisation, then try again. Deleting the user directly in Studio is refused by a database trigger (ST003) |
| Changing the password or deleting the account says "For your security, please enter your current password." | Re-authentication | Enter your current password. If you have none (Google or email-link only), sign in again with an email link and retry within 10 minutes |
| The audit-log menu does not appear | Your role is member | Only owners and admins can read the audit log (`audit:read` in the permission table) |
| Changing an email address leaves the member list stale | `profiles.email` does not follow the auth record | The kit has no change-email screen (the template is included). If you add one, only `auth.users.email` changes and the member list keeps the old address. The ST004 trigger blocks writes to `profiles.email`, so treat `auth.users` as the source of truth and sync `profiles.email` with the service role. Invitation matching reads the new address while the "already a member" check reads the old one, so the two disagree until you sync |
| You want to call Supabase from the browser | The session is not readable there | The kit stores the session cookie as `httpOnly`. Adding a browser-side Supabase client means removing that flag, which makes the session readable from browser JavaScript. Decide with that in mind |

## 20. Combining with the other kits

None of these ship inside this zip. Buy them separately and add them as follows.

### LP Template Pack

Replaces the marketing page with something properly designed.

1. Move the template's HTML and CSS into `app/page.tsx`.
2. Keep the plan table drawn from `publicPlans()`. That way the marketing page and the real quotas cannot drift apart when you edit `plans.config.ts`.
3. Put images in `public/`.
4. Point the call-to-action button at `/signup`.

### Dashboard Kit

Adds charts to the `/app` overview.

1. Put the kit's `dist/dashboard.js` and `dashboard.css` in `public/`.
2. Add one mount `div` to `app/app/page.tsx`.
3. Add an endpoint under `app/api/` that returns the figures. **That endpoint must re-read `memberships` too.** An organisation id from the browser is not to be trusted there either.
4. Point the kit's config at that endpoint.

### AI Concierge Kit

Puts a window in your service that answers from your documents.

1. Host the kit separately, or fold it into `app/api/` here.
2. Add the window's snippet to `app/app/layout.tsx`.
3. If you host it separately, add this kit's URL to its `ALLOWED_ORIGINS`.
4. To show it to signed-in members only, mount it under `/app` alone.

## 21. Licence and support

See `LICENSE.md`. Modification, and building it into client work and delivering that work, are unrestricted. Redistributing or reselling the zip or `src/` as a whole, and selling it as a competing product, are not.

Defect reports are handled by email for 14 days after purchase, with a reply within three business days. Updates within 1.x are free.

Contact: hello@suminawa.dev
