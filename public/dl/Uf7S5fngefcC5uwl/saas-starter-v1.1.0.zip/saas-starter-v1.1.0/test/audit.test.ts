/**
 * 監査ログ（組織の操作の記録）の検査です（1.1.0 で足しました）。
 *
 *   1. 見本のしくみが、本物の引き金と同じ場面で同じ種類を書くこと
 *   2. 読めるのはオーナーと管理者だけであること（役割の表と、行の出入りの決まりの両方）
 *   3. 種類の一覧が、TypeScript と SQL の check 制約でそろっていること
 *
 * 本物の引き金が書くところは `npm run test:rls`（pgTAP と test/supabase.test.ts）が確かめます。
 */
import { readFileSync } from "node:fs";
import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts, type FakePorts } from "../src/adapters/fake";
import { toAuditLog } from "../src/adapters/supabase/rows";
import { AUDIT_ACTIONS } from "../src/core/audit";
import { createInviteToken } from "../src/core/invitations";
import { PERMISSION_MATRIX, ROLES } from "../src/core/permissions";
import type { SessionUser } from "../src/ports";
import { buildCtx, type Ctx } from "../src/server/context";
import { listAuditLogsFlow } from "../src/server/flows/audit";
import { applyWebhookFlow } from "../src/server/flows/billing";
import { removeMemberFlow, setMemberRoleFlow } from "../src/server/flows/members";

const NOW = new Date("2026-10-21T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";

const SQL = readFileSync(
  new URL("../supabase/migrations/20261021000200_audit_logs.sql", import.meta.url),
  "utf8",
);

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };

describe("監査ログ（見本のしくみ）", () => {
  let ports: FakePorts;

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
  });

  async function ctxFor(user: SessionUser, organizationId = "org-1"): Promise<Ctx> {
    ports.auth.signInAs(user.id);
    const built = await buildCtx({ ports, siteOrigin: ORIGIN, user, organizationId, lang: "ja", now: NOW });
    if (!built.ok) throw new Error(built.code);
    return built.value;
  }

  /** 見本に入っている 3 行より後に積まれた種類です */
  function newActions(): string[] {
    return ports.store.auditLogs.slice(3).map((row) => row.action);
  }

  it("オーナーには、新しい順に、操作した方のお名前つきでお見せする", async () => {
    const result = await listAuditLogsFlow({ ctx: await ctxFor(OWNER) });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.value.map((row) => row.action)).toEqual([
      "member.role_changed",
      "invitation.accepted",
      "invitation.created",
    ]);
    expect(result.value[0]).toMatchObject({ actorName: "みなと 太郎", target: "admin@example.com" });
  });

  it("管理者も読める。メンバーには forbidden", async () => {
    expect((await listAuditLogsFlow({ ctx: await ctxFor(ADMIN) })).ok).toBe(true);
    expect(await listAuditLogsFlow({ ctx: await ctxFor(MEMBER) })).toEqual({
      ok: false,
      code: "forbidden",
    });
  });

  it("口そのものも、メンバーのセッションには 0 件しか返さない（行の出入りの決まりと同じ）", async () => {
    ports.auth.signInAs("u-member");
    expect(await ports.data.listAuditLogs("org-1", 100)).toEqual([]);
  });

  it("ほかの組織の記録は混ざらない", async () => {
    const result = await listAuditLogsFlow({ ctx: await ctxFor(ADMIN, "org-2") });
    expect(result).toEqual({ ok: true, value: [] });
  });

  it("役割の変更と、組織から外す操作を、操作した方つきで書く", async () => {
    const ctx = await ctxFor(OWNER);
    await setMemberRoleFlow({ ctx, raw: { userId: "u-member", role: "admin" } });
    await removeMemberFlow({ ctx, raw: { userId: "u-member" } });

    expect(ports.store.auditLogs.slice(3)).toEqual([
      expect.objectContaining({
        action: "member.role_changed",
        actorId: "u-owner",
        actorType: "user",
        target: "member@example.com",
        detail: { from: "member", to: "admin" },
      }),
      expect.objectContaining({
        action: "member.removed",
        actorId: "u-owner",
        target: "member@example.com",
        detail: { role: "admin" },
      }),
    ]);
  });

  it("ご自身で抜けたときは member.left", async () => {
    ports.auth.signInAs("u-member");
    await ports.data.removeMemberGuarded("org-1", "u-member");
    expect(newActions()).toEqual(["member.left"]);
  });

  it("招待を送る・取り消す・お受けいただく、を書く", async () => {
    ports.auth.signInAs("u-owner");
    const first = await ports.data.createInvitation({
      organizationId: "org-1",
      email: "guest@example.com",
      role: "member",
      tokenHash: createInviteToken().tokenHash,
      expiresAt: "2026-10-28T00:00:00.000Z",
      invitedBy: "u-owner",
    });
    await ports.data.revokeInvitation("org-1", first.id);
    const second = await ports.data.createInvitation({
      organizationId: "org-1",
      email: "member@example.com",
      role: "member",
      tokenHash: createInviteToken().tokenHash,
      expiresAt: "2026-10-28T00:00:00.000Z",
      invitedBy: "u-owner",
    });
    ports.auth.signInAs("u-member");
    await ports.data.acceptInvitation(second.id, "u-member", "member");

    expect(newActions()).toEqual([
      "invitation.created",
      "invitation.revoked",
      "invitation.created",
      "invitation.accepted",
    ]);
  });

  it("ご契約の変更は、操作した方を空にして書く。同じ状態の通知では書かない", async () => {
    await ports.data.setStripeCustomer("org-1", "cus_1");
    const deliver = (id: string, updatedAt: string) =>
      applyWebhookFlow({
        ports,
        payload: JSON.stringify({
          eventId: id,
          eventType: "customer.subscription.updated",
          change: {
            stripeCustomerId: "cus_1",
            row: {
              planId: "standard",
              status: "active",
              stripeSubscriptionId: "sub_1",
              currentPeriodEnd: "2026-11-21T00:00:00.000Z",
              cancelAtPeriodEnd: false,
              updatedAt,
            },
          },
        }),
        signature: "fake",
        now: NOW,
      });

    await deliver("evt_1", "2026-10-21T00:00:00.000Z");
    await deliver("evt_2", "2026-10-21T00:01:00.000Z");

    expect(ports.store.auditLogs.slice(3)).toEqual([
      expect.objectContaining({
        action: "billing.changed",
        actorId: null,
        actorType: "system",
        detail: { plan: "standard", status: "active", cancelAtPeriodEnd: "false" },
      }),
    ]);
  });

  it("組織を消すと、その組織の記録も一緒に消える", async () => {
    await ports.data.deleteOrganization("org-1");
    expect(ports.store.auditLogs.filter((row) => row.organizationId === "org-1")).toEqual([]);
  });
});

describe("監査ログの SQL", () => {
  it("種類の一覧が、TypeScript（AUDIT_ACTIONS）と check 制約でそろっている", () => {
    const check = /action text not null check \(\s*action in \(([^)]*)\)/.exec(SQL);
    expect(check).not.toBeNull();
    const inSql = [...(check?.[1] ?? "").matchAll(/'([^']+)'/g)].map((found) => found[1]).sort();
    expect(inSql).toEqual([...AUDIT_ACTIONS].sort());
  });

  it("読める役割が、役割の表の audit:read と同じ（オーナーと管理者）", () => {
    const allowed = ROLES.filter((role) => PERMISSION_MATRIX["audit:read"][role] === "yes");
    expect(allowed).toEqual(["owner", "admin"]);
    expect(SQL).toContain("using (public.member_role(organization_id) in ('owner', 'admin'));");
  });

  it("書く決まりを置かず、表への許しも読むことだけ", () => {
    expect(SQL.match(/create policy/g)).toHaveLength(1);
    expect(SQL).toContain("for select to authenticated");
    expect(SQL).toContain("revoke all on table public.audit_logs from anon, authenticated;");
    expect(SQL).toContain("grant select on table public.audit_logs to authenticated;");
  });

  it("引き金の関数は、どれも security definer で search_path を空に固定している", () => {
    const definers = SQL.match(/security definer\s+set search_path = ''/g) ?? [];
    // 記録の補助・引き金 4 つ・退会の関数・古い記録を消す関数で 7 つです
    expect(definers).toHaveLength(7);
  });
});

describe("監査ログの行の写し（Supabase）", () => {
  it("操作した方のお名前と、文字の添え書きを写す", () => {
    expect(
      toAuditLog({
        id: "a1",
        organization_id: "o1",
        actor_id: "u1",
        actor_type: "user",
        action: "billing.changed",
        target: "",
        detail: { plan: "standard", status: "active", cancelAtPeriodEnd: false },
        created_at: "2026-10-21T00:00:00Z",
        profiles: { name: "みなと 太郎" },
      }),
    ).toEqual({
      id: "a1",
      organizationId: "o1",
      actorId: "u1",
      actorType: "user",
      actorName: "みなと 太郎",
      action: "billing.changed",
      target: "",
      detail: { plan: "standard", status: "active", cancelAtPeriodEnd: "false" },
      createdAt: "2026-10-21T00:00:00Z",
    });
  });

  it("操作した方が見えないときは null、知らない種類はお止めする", () => {
    const row = {
      id: "a1",
      organization_id: "o1",
      actor_id: null,
      action: "member.left",
      target: "a@example.com",
      detail: {},
      created_at: "2026-10-21T00:00:00Z",
      profiles: null,
    };
    expect(toAuditLog(row)).toMatchObject({ actorId: null, actorName: null });
    expect(() => toAuditLog({ ...row, action: "member.hacked" })).toThrow(/action/);
  });
});
