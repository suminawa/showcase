/**
 * パスワードの再設定の流れです（1.1.0 で足しました）。
 *   ① 再設定のメールをお求めいただく（ご登録の有無は漏らさない・回数の上限）
 *   ② 新しいパスワードをお決めいただく（確かめの欄・セッションの有無）
 * 見本のしくみ（メモリの偽物）で、外へは何も送らずに一周します。
 */
import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts, type FakePorts } from "../../src/adapters/fake";
import {
  RESET_PASSWORD_PATH,
  requestPasswordResetFlow,
  signInPasswordFlow,
  updatePasswordFlow,
} from "../../src/server/flows/auth";
import {
  createMemoryRateLimiter,
  LOGIN_IP_LIMIT,
  LOGIN_LIMIT,
  type RateLimiter,
} from "../../src/server/ratelimit";

const NOW = new Date("2026-10-21T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";
const IP = "203.0.113.10";

describe("パスワードの再設定", () => {
  let ports: FakePorts;
  let limiter: RateLimiter;
  let ipLimiter: RateLimiter;

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
    limiter = createMemoryRateLimiter(LOGIN_LIMIT);
    ipLimiter = createMemoryRateLimiter(LOGIN_IP_LIMIT);
  });

  function request(email: unknown, now = NOW) {
    return requestPasswordResetFlow({
      ports,
      siteOrigin: ORIGIN,
      raw: { email },
      limiter,
      ipLimiter,
      ip: IP,
      now,
    });
  }

  it("メールのリンクは /auth/callback を通って、新しいパスワードの画面へ戻ってくる", async () => {
    expect(await request("Owner@Example.com")).toEqual({ ok: true, value: { sent: true } });
    expect(ports.store.passwordResets).toEqual([
      {
        email: "owner@example.com",
        redirectTo: `${ORIGIN}/auth/callback?next=${encodeURIComponent(RESET_PASSWORD_PATH)}`,
        sentAt: NOW.toISOString(),
      },
    ]);
  });

  it("ご登録のないメールアドレスでも、同じお返事（ご登録の有無を漏らさない）", async () => {
    expect(await request("nobody@example.com")).toEqual(await request("owner@example.com"));
  });

  it("形の悪いメールアドレスは、お送りせずに invalid", async () => {
    expect(await request("owner(at)example.com")).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "email", code: "bad_email" }],
    });
    expect(ports.store.passwordResets).toEqual([]);
  });

  it("ログインと同じ窓で数え、同じメールアドレスへの 11 回目は止める", async () => {
    for (let i = 0; i < 10; i += 1) expect((await request("owner@example.com")).ok).toBe(true);
    expect(await request("owner@example.com")).toEqual({ ok: false, code: "rate_limited" });
    expect(ports.store.passwordResets).toHaveLength(10);
  });

  it("混み合っているときの符号は、そのままお伝えする", async () => {
    ports.auth.sendPasswordReset = async () => ({ ok: false, code: "rate_limited" });
    expect(await request("owner@example.com")).toEqual({ ok: false, code: "rate_limited" });
  });
});

describe("新しいパスワードを決める（確かめ直しつき）", () => {
  let ports: FakePorts;

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
  });

  function update(raw: { currentPassword?: unknown; password: unknown; passwordConfirm: unknown }) {
    return updatePasswordFlow({
      ports,
      raw: { currentPassword: raw.currentPassword ?? "", password: raw.password, passwordConfirm: raw.passwordConfirm },
      limiter: createMemoryRateLimiter(LOGIN_LIMIT),
      ipLimiter: createMemoryRateLimiter(LOGIN_IP_LIMIT),
      ip: IP,
      now: NOW,
    });
  }

  it("確かめの欄が違うときは、書き換えずに mismatch", async () => {
    ports.auth.signInAs("u-owner");
    const result = await update({ currentPassword: "x", password: "new-password-1", passwordConfirm: "new-password-2" });
    expect(result).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "passwordConfirm", code: "mismatch" }],
    });
    expect(ports.store.authUsers.has("owner@example.com")).toBe(false);
  });

  it("8 文字に満たないパスワードは too_short", async () => {
    ports.auth.signInAs("u-owner");
    expect(await update({ currentPassword: "x", password: "short", passwordConfirm: "short" })).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "password", code: "too_short" }],
    });
  });

  it("セッションが無い（リンクの期限切れ・別のブラウザ）ときは unauthenticated", async () => {
    expect(await update({ password: "new-password-1", passwordConfirm: "new-password-1" })).toEqual({
      ok: false,
      code: "unauthenticated",
    });
  });

  it("ログインしたままの画面では、いまのパスワードが無いと書き換えない（reauth_required）", async () => {
    ports.auth.signInAs("u-owner");
    expect(await update({ password: "new-password-1", passwordConfirm: "new-password-1" })).toEqual({
      ok: false,
      code: "reauth_required",
    });
    expect(ports.store.authUsers.has("owner@example.com")).toBe(false);
  });

  it("10 分以内にメールで確かめたセッション（再設定のリンク）なら、いまのパスワードを省ける", async () => {
    ports.auth.signInAs("u-owner");
    const asked: number[] = [];
    ports.auth.recentEmailSignIn = async (maxAge) => {
      asked.push(maxAge);
      return true;
    };
    expect(await update({ password: "new-password-1", passwordConfirm: "new-password-1" })).toEqual({
      ok: true,
      value: { updated: true },
    });
    expect(asked).toEqual([600]);
  });

  it("いまのパスワードが違えば bad_credentials。お決めいただいたパスワードで次からログインできる", async () => {
    ports.auth.signInAs("u-owner");
    // 見本の方ははじめパスワードを持たないので、1 回目はどの値でも通ります
    expect(
      await update({ currentPassword: "anything", password: "new-password-1", passwordConfirm: "new-password-1" }),
    ).toEqual({ ok: true, value: { updated: true } });

    expect(
      await update({ currentPassword: "wrong-password", password: "new-password-2", passwordConfirm: "new-password-2" }),
    ).toEqual({ ok: false, code: "bad_credentials" });

    await ports.auth.signOut();
    const signedIn = await signInPasswordFlow({
      ports,
      raw: { email: "owner@example.com", password: "new-password-1" },
      limiter: createMemoryRateLimiter(LOGIN_LIMIT),
      ipLimiter: createMemoryRateLimiter(LOGIN_IP_LIMIT),
      ip: IP,
      now: NOW,
    });
    expect(signedIn).toEqual({ ok: true, value: { userId: "u-owner" } });
  });

  it("いまのパスワードの当てずっぽうは、ログインと同じ回数の上限で止める", async () => {
    ports.auth.signInAs("u-owner");
    await update({ currentPassword: "anything", password: "new-password-1", passwordConfirm: "new-password-1" });

    const limiter = createMemoryRateLimiter(LOGIN_LIMIT);
    const ipLimiter = createMemoryRateLimiter(LOGIN_IP_LIMIT);
    const attempt = () =>
      updatePasswordFlow({
        ports,
        raw: { currentPassword: "guess", password: "new-password-2", passwordConfirm: "new-password-2" },
        limiter,
        ipLimiter,
        ip: IP,
        now: NOW,
      });
    for (let i = 0; i < 10; i += 1) expect((await attempt()).ok).toBe(false);
    expect(await attempt()).toEqual({ ok: false, code: "rate_limited" });
  });

  it("いまと同じパスワードは password_rejected", async () => {
    ports.auth.signInAs("u-owner");
    const raw = { currentPassword: "anything", password: "new-password-1", passwordConfirm: "new-password-1" };
    await update(raw);
    expect(await update({ ...raw, currentPassword: "new-password-1" })).toEqual({
      ok: false,
      code: "password_rejected",
    });
  });
});
