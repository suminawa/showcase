/**
 * 退会（アカウントの削除）の流れです（1.1.0 で足しました）。
 *
 * 見本の顔ぶれ（seedDemo）
 *   しおさい設計室: owner みなと 太郎・admin いその 花子・member なぎさ 健
 *   なぎさ工房    : owner いその 花子（お 1 人だけ）
 * を使って、組織ごとの 3 とおり（止める・一緒に消す・退会する）を確かめます。
 */
import { beforeEach, describe, expect, it } from "vitest";
import { createFakePorts, type FakePorts } from "../../src/adapters/fake";
import type { BillingPort, SessionUser } from "../../src/ports";
import type { UserCtx } from "../../src/server/context";
import { accountDeletionPlanFlow, deleteAccountFlow } from "../../src/server/flows/account";
import { createMemoryRateLimiter, LOGIN_IP_LIMIT, LOGIN_LIMIT } from "../../src/server/ratelimit";

const NOW = new Date("2026-10-21T00:00:00.000Z");
const ORIGIN = "http://localhost:3020";

const OWNER: SessionUser = { id: "u-owner", email: "owner@example.com", name: "みなと 太郎", lang: "ja" };
const ADMIN: SessionUser = { id: "u-admin", email: "admin@example.com", name: "いその 花子", lang: "ja" };
const MEMBER: SessionUser = { id: "u-member", email: "member@example.com", name: "なぎさ 健", lang: "ja" };

describe("退会（アカウントの削除）", () => {
  let ports: FakePorts;
  let canceled: string[];

  beforeEach(() => {
    ports = createFakePorts({ now: () => NOW, seeded: true });
    canceled = [];
    const billing: BillingPort = ports.billing;
    ports.billing = {
      createCheckoutUrl: (input) => billing.createCheckoutUrl(input),
      createPortalUrl: (input) => billing.createPortalUrl(input),
      readWebhook: (input) => billing.readWebhook(input),
      async cancelSubscription(input) {
        canceled.push(input.stripeSubscriptionId);
        return { ok: true };
      },
    };
  });

  function ctxFor(user: SessionUser): UserCtx {
    ports.auth.signInAs(user.id);
    return { ports, siteOrigin: ORIGIN, user, lang: "ja", now: NOW };
  }

  /** 退会の流れを呼びます。いまのパスワードは、見本の方なのでどの値でも通ります */
  function remove(user: SessionUser, confirmEmail: string, currentPassword = "current-password") {
    return deleteAccountFlow({
      ctx: ctxFor(user),
      raw: { confirmEmail, currentPassword },
      limiter: createMemoryRateLimiter(LOGIN_LIMIT),
      ipLimiter: createMemoryRateLimiter(LOGIN_IP_LIMIT),
      ip: "203.0.113.10",
      now: NOW,
    });
  }

  /** なぎさ工房（いその 花子お 1 人の組織）に、ご契約を入れておきます */
  async function subscribeNagisa(): Promise<void> {
    await ports.data.setStripeCustomer("org-2", "cus_nagisa");
    await ports.data.upsertSubscription({
      organizationId: "org-2",
      planId: "standard",
      status: "active",
      stripeSubscriptionId: "sub_nagisa",
      currentPeriodEnd: "2026-11-21T00:00:00.000Z",
      cancelAtPeriodEnd: false,
      updatedAt: "2026-10-01T00:00:00.000Z",
    });
  }

  it("組織ごとに、止める・一緒に消す・退会する、の 3 とおりに分ける", async () => {
    const owner = await accountDeletionPlanFlow({ ports, user: OWNER });
    expect(owner.ok && owner.value.blocking.map((o) => o.id)).toEqual(["org-1"]);

    const admin = await accountDeletionPlanFlow({ ports, user: ADMIN });
    expect(admin.ok && admin.value).toMatchObject({
      blocking: [],
      deleting: [{ id: "org-2" }],
      leaving: [{ id: "org-1" }],
    });

    const member = await accountDeletionPlanFlow({ ports, user: MEMBER });
    expect(member.ok && member.value).toMatchObject({ blocking: [], deleting: [], leaving: [{ id: "org-1" }] });
  });

  it("確かめのメールアドレスが違うときは、何も消さずに mismatch", async () => {
    const result = await remove(MEMBER, "someone@example.com");
    expect(result).toEqual({
      ok: false,
      code: "invalid",
      errors: [{ field: "confirmEmail", code: "mismatch" }],
    });
    expect(ports.store.profiles.has("u-member")).toBe(true);
  });

  it("ほかの方がいる組織の、ただ 1 人のオーナーは、owner_has_members で止める", async () => {
    const result = await remove(OWNER, "owner@example.com");
    expect(result).toEqual({ ok: false, code: "owner_has_members" });
    expect(ports.store.profiles.has("u-owner")).toBe(true);
    expect(ports.store.organizations.has("org-1")).toBe(true);
  });

  it("オーナーをほかの方に引き継げば、退会できる（組織とプロジェクトは残る）", async () => {
    await ports.data.changeMemberRole("org-1", "u-admin", "owner");

    const result = await remove(OWNER, "OWNER@example.com");
    expect(result).toEqual({ ok: true, value: { deleted: true } });
    expect(ports.store.organizations.has("org-1")).toBe(true);
    expect(ports.store.memberships.has("org-1:u-owner")).toBe(false);
    // お作りになったプロジェクトは残り、作成者の欄だけが空になります
    const projects = await ports.data.listProjects("org-1");
    expect(projects).toHaveLength(2);
    expect(projects.some((project) => project.createdBy === null)).toBe(true);
  });

  it("お 1 人だけの組織は一緒に消し、残るご契約は先に解約する", async () => {
    await subscribeNagisa();

    const result = await remove(ADMIN, "admin@example.com");

    expect(result).toEqual({ ok: true, value: { deleted: true } });
    expect(canceled).toEqual(["sub_nagisa"]);
    expect(ports.store.organizations.has("org-2")).toBe(false);
    expect(ports.store.subscriptions.has("org-2")).toBe(false);
    // ほかの方もいる組織からは、退会だけです
    expect(ports.store.organizations.has("org-1")).toBe(true);
    expect(ports.store.memberships.has("org-1:u-admin")).toBe(false);
    expect(ports.store.profiles.has("u-admin")).toBe(false);
    // ログインの状態も閉じています
    expect(await ports.auth.getUser()).toBeNull();
  });

  it("ご契約の解約が通らなかったときは、組織もアカウントも消さない", async () => {
    await subscribeNagisa();
    ports.billing.cancelSubscription = async () => ({ ok: false, code: "unavailable" });

    const result = await remove(ADMIN, "admin@example.com");

    expect(result).toEqual({ ok: false, code: "unavailable" });
    expect(ports.store.organizations.has("org-2")).toBe(true);
    expect(ports.store.subscriptions.get("org-2")?.status).toBe("active");
    expect(ports.store.profiles.has("u-admin")).toBe(true);
  });

  it("ご契約の無い、お 1 人だけの組織は、解約を呼ばずに消す", async () => {
    await remove(ADMIN, "admin@example.com");
    expect(canceled).toEqual([]);
    expect(ports.store.organizations.has("org-2")).toBe(false);
  });

  it("残る組織の監査ログに、相手の欄を空にした account.deleted を 1 行残す", async () => {
    await remove(MEMBER, "member@example.com");

    const rows = ports.store.auditLogs.filter((row) => row.action === "account.deleted");
    expect(rows).toEqual([
      expect.objectContaining({
        organizationId: "org-1",
        actorId: null,
        actorType: "system",
        target: "",
        detail: { role: "member" },
      }),
    ]);
    // 退会に連れて消えたメンバーの行は、外した・抜けたとは書きません
    expect(ports.store.auditLogs.some((row) => row.action === "member.removed")).toBe(false);
  });

  it("データベースの守りと同じく、見本の口も最後のオーナーのアカウントは消さない", async () => {
    expect(await ports.data.deleteAccount("u-owner")).toBe("owner_has_members");
    expect(ports.store.profiles.has("u-owner")).toBe(true);
  });

  it("いまのパスワードが空で、最近メールで確かめてもいなければ、何も消さずに reauth_required", async () => {
    expect(await remove(MEMBER, "member@example.com", "")).toEqual({ ok: false, code: "reauth_required" });
    expect(ports.store.profiles.has("u-member")).toBe(true);
  });

  it("いまのパスワードが違えば、何も消さずに bad_credentials", async () => {
    ports.store.authUsers.set("member@example.com", { id: "u-member", email: "member@example.com", password: "right-password" });
    expect(await remove(MEMBER, "member@example.com", "wrong-password")).toEqual({
      ok: false,
      code: "bad_credentials",
    });
    expect(ports.store.profiles.has("u-member")).toBe(true);
  });

  it("番号の分からないご契約が残っているときは、黙って解約済みにせず、何も消さない", async () => {
    await subscribeNagisa();
    const row = ports.store.subscriptions.get("org-2");
    if (row !== undefined) ports.store.subscriptions.set("org-2", { ...row, stripeSubscriptionId: null });

    expect(await remove(ADMIN, "admin@example.com")).toEqual({ ok: false, code: "has_subscription" });
    expect(canceled).toEqual([]);
    expect(ports.store.subscriptions.get("org-2")?.status).toBe("active");
    expect(ports.store.organizations.has("org-2")).toBe(true);
  });

  it("ご契約の表を解約の形にできなかったときは、アカウントを消さない", async () => {
    await subscribeNagisa();
    ports.data.applySubscriptionChange = async () => false;

    expect(await remove(ADMIN, "admin@example.com")).toEqual({ ok: false, code: "unavailable" });
    expect(ports.store.profiles.has("u-admin")).toBe(true);
    expect(ports.store.organizations.has("org-2")).toBe(true);
  });

  it("消す直前にデータベースが止めた理由（最後のオーナー・ご契約）を、そのままの符号でお伝えする", async () => {
    ports.data.deleteAccount = async () => "owner_has_members";
    expect(await remove(MEMBER, "member@example.com")).toEqual({ ok: false, code: "owner_has_members" });

    ports.data.deleteAccount = async () => "has_subscription";
    expect(await remove(MEMBER, "member@example.com")).toEqual({ ok: false, code: "has_subscription" });
    expect(ports.store.profiles.has("u-member")).toBe(true);
  });

  it("10 分以内にメールで確かめたセッションなら、いまのパスワードを省ける", async () => {
    ports.auth.recentEmailSignIn = async () => true;
    expect(await remove(MEMBER, "member@example.com", "")).toEqual({ ok: true, value: { deleted: true } });
  });

  it("退会された方のメールアドレスは、ほかの記録の相手の欄からも消える", async () => {
    // 見本の監査ログには admin@example.com が相手の行が 3 つあります
    await remove(ADMIN, "admin@example.com");
    expect(ports.store.auditLogs.some((row) => row.target === "admin@example.com")).toBe(false);
  });
});
