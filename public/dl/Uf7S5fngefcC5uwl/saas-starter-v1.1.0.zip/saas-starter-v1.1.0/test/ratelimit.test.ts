/**
 * 回数の上限を、データベースで数える形の検査です（1.1.0 で足しました）。
 *
 * 本物の SQL（rate_limit_hit）は `npm run test:rls` の pgTAP が、11 回目が止まることを確かめます。
 * ここでは Docker なしで確かめられるところを見ます。
 *   1. 外の入れ物で数える上限（createStoreRateLimiter）に、SQL と同じ数え方の作りものを渡して、
 *      10 分で 10 回のとき 11 回目が止まること
 *   2. つなぎ役（createSupabaseRateLimitCount）が、関数の名前と引数をそのまま渡し、
 *      お返事を写し、誤りを握りつぶさないこと
 *   3. どちらの入れ物を使うかの決め方（rateLimitStore）
 *   4. SQL の書き方が、ほかの関数と同じ守り（security definer・search_path・service role だけ）であること
 */
import { readFileSync } from "node:fs";
import type { SupabaseClient } from "@supabase/supabase-js";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createSupabaseRateLimitCount } from "../src/adapters/supabase/ratelimit";
import { clientIp, rateLimitPepper, rateLimitStore } from "../src/server/ports";

/** 接続元の IP の読み取りを確かめるため、リクエストのヘッダだけを差し替えます */
const requestHeaders = { current: new Headers() };
vi.mock("next/headers", () => ({
  headers: async () => requestHeaders.current,
  cookies: async () => ({ get: () => undefined, set: () => undefined, delete: () => undefined }),
}));
import {
  createMemoryRateLimiter,
  createStoreRateLimiter,
  hashKey,
  LOGIN_LIMIT,
  withHashedKeys,
  type RateLimitCount,
} from "../src/server/ratelimit";

const SQL = readFileSync(
  new URL("../supabase/migrations/20261021000100_rate_limits.sql", import.meta.url),
  "utf8",
);

const START = new Date("2026-10-21T00:00:00.000Z");

function at(seconds: number): Date {
  return new Date(START.getTime() + seconds * 1000);
}

/**
 * rate_limit_hit と同じ数え方の作りものです（鍵ごとに窓の始まりと回数を持つ固定窓）。
 * 受け取った引数も残しておきます。
 */
function sqlLikeCount(calls: Parameters<RateLimitCount>[0][] = []): RateLimitCount {
  const rows = new Map<string, { startedAt: number; count: number }>();
  return async (input) => {
    calls.push(input);
    const now = input.now.getTime();
    const windowMs = input.windowSeconds * 1000;
    const previous = rows.get(input.key);
    const row =
      previous === undefined || now - previous.startedAt >= windowMs
        ? { startedAt: now, count: 1 }
        : { startedAt: previous.startedAt, count: previous.count + 1 };
    rows.set(input.key, row);

    if (row.count <= input.limit) return { allowed: true, retryAfterSeconds: 0 };
    return {
      allowed: false,
      retryAfterSeconds: Math.max(1, Math.ceil((row.startedAt + windowMs - now) / 1000)),
    };
  };
}

describe("データベースで数える上限", () => {
  it("10 分で 10 回のとき、窓の中の 11 回目は止まる", async () => {
    const limiter = createStoreRateLimiter(LOGIN_LIMIT, sqlLikeCount());

    for (let i = 1; i <= 10; i += 1) {
      expect((await limiter.hit("login:203.0.113.10:a@example.com", at(i))).allowed, `${i}`).toBe(true);
    }
    expect(await limiter.hit("login:203.0.113.10:a@example.com", at(11))).toEqual({
      allowed: false,
      retryAfterSeconds: 590,
    });
  });

  it("メモリの形と、同じ回で同じ答えになる（数え方がそろっている）", async () => {
    const store = createStoreRateLimiter({ limit: 3, windowSeconds: 60 }, sqlLikeCount());
    const memory = createMemoryRateLimiter({ limit: 3, windowSeconds: 60 });

    for (const seconds of [0, 1, 2, 3, 30, 59, 60, 61, 62, 63]) {
      expect(await store.hit("k", at(seconds)), `${seconds}`).toEqual(
        await memory.hit("k", at(seconds)),
      );
    }
  });

  it("窓の長さを過ぎたら、1 から数え直す。鍵が違えば別に数える", async () => {
    const limiter = createStoreRateLimiter(LOGIN_LIMIT, sqlLikeCount());
    for (let i = 0; i < 11; i += 1) await limiter.hit("a", at(i));

    expect((await limiter.hit("b", at(12))).allowed).toBe(true);
    expect((await limiter.hit("a", at(600))).allowed).toBe(true);
  });

  it("上限と窓の長さと時刻を、そのまま数える口へ渡す", async () => {
    const calls: Parameters<RateLimitCount>[0][] = [];
    const limiter = createStoreRateLimiter({ limit: 20, windowSeconds: 3600 }, sqlLikeCount(calls));
    await limiter.hit("invite:org-1", at(5));

    expect(calls).toEqual([{ key: "invite:org-1", limit: 20, windowSeconds: 3600, now: at(5) }]);
  });
});

/** rpc だけを持つつなぎ口です。呼ばれた名前と引数を残します */
function rpcClient(
  reply: { data: unknown; error: unknown },
  calls: [string, Record<string, unknown>][] = [],
): SupabaseClient {
  return {
    rpc: async (name: string, args: Record<string, unknown>) => {
      calls.push([name, args]);
      return reply;
    },
  } as unknown as SupabaseClient;
}

describe("回数の上限のつなぎ役（Supabase）", () => {
  it("rate_limit_hit に、鍵・上限・窓・時刻をそのまま渡し、お返事を写す", async () => {
    const calls: [string, Record<string, unknown>][] = [];
    const count = createSupabaseRateLimitCount(() =>
      rpcClient({ data: { allowed: false, retry_after_seconds: 590 }, error: null }, calls),
    );

    const verdict = await count({ key: "login:x", limit: 10, windowSeconds: 600, now: at(11) });

    expect(verdict).toEqual({ allowed: false, retryAfterSeconds: 590 });
    expect(calls).toEqual([
      [
        "rate_limit_hit",
        { p_key: "login:x", p_limit: 10, p_window_seconds: 600, p_now: at(11).toISOString() },
      ],
    ]);
  });

  it("service role のつなぎ口は、1 つだけ作って使い回す", async () => {
    let made = 0;
    const count = createSupabaseRateLimitCount(() => {
      made += 1;
      return rpcClient({ data: { allowed: true, retry_after_seconds: 0 }, error: null });
    });
    await count({ key: "a", limit: 1, windowSeconds: 1, now: START });
    await count({ key: "a", limit: 1, windowSeconds: 1, now: START });
    expect(made).toBe(1);
  });

  it("数えられなかったときは、黙って通さずに例外にする（誤りの中身は持ち回らない）", async () => {
    const failing = createSupabaseRateLimitCount(() =>
      rpcClient({ data: null, error: { message: "relation rate_limits does not exist" } }),
    );
    await expect(failing({ key: "a", limit: 1, windowSeconds: 1, now: START })).rejects.toThrow(
      /^data: rateLimitHit$/,
    );

    const odd = createSupabaseRateLimitCount(() => rpcClient({ data: { allowed: "yes" }, error: null }));
    await expect(odd({ key: "a", limit: 1, windowSeconds: 1, now: START })).rejects.toThrow(
      "data: rateLimitHit",
    );
  });
});

describe("どちらの入れ物で数えるか（rateLimitStore）", () => {
  const env = process.env as Record<string, string | undefined>;
  const saved = { ...env };

  afterEach(() => {
    for (const name of [
      "STARTER_FAKE",
      "RATE_LIMIT_STORE",
      "NEXT_PUBLIC_SUPABASE_URL",
      "NEXT_PUBLIC_SUPABASE_ANON_KEY",
      "SUPABASE_SERVICE_ROLE_KEY",
    ]) {
      if (saved[name] === undefined) delete env[name];
      else env[name] = saved[name];
    }
  });

  function withSupabase(): void {
    env.STARTER_FAKE = "";
    env.NEXT_PUBLIC_SUPABASE_URL = "http://127.0.0.1:54321";
    env.NEXT_PUBLIC_SUPABASE_ANON_KEY = "anon";
    env.SUPABASE_SERVICE_ROLE_KEY = "service";
  }

  it("Supabase の鍵がそろっていれば、既定はデータベース", () => {
    withSupabase();
    delete env.RATE_LIMIT_STORE;
    expect(rateLimitStore()).toBe("postgres");
  });

  it("RATE_LIMIT_STORE=memory で、メモリを選べる", () => {
    withSupabase();
    env.RATE_LIMIT_STORE = "memory";
    expect(rateLimitStore()).toBe("memory");
  });

  it("鍵が無いときと、見本のしくみでは、メモリ", () => {
    delete env.NEXT_PUBLIC_SUPABASE_URL;
    delete env.RATE_LIMIT_STORE;
    env.STARTER_FAKE = "";
    expect(rateLimitStore()).toBe("memory");

    withSupabase();
    env.STARTER_FAKE = "1";
    env.RATE_LIMIT_STORE = "postgres";
    expect(rateLimitStore()).toBe("memory");
  });
});

describe("回数の上限の SQL", () => {
  it("ほかの関数と同じく、security definer で search_path を空に固定している", () => {
    expect(SQL).toMatch(/security definer\s+set search_path = ''/);
  });

  it("呼べるのは service role だけ（画面の側の鍵からは呼べない）", () => {
    expect(SQL).toContain(
      "revoke all on function public.rate_limit_hit(text, integer, integer, timestamptz)\n  from public, anon, authenticated;",
    );
    expect(SQL).toContain(
      "grant execute on function public.rate_limit_hit(text, integer, integer, timestamptz)\n  to service_role;",
    );
  });

  it("表には行の出入りの決まりを有効にし、決まりを 1 つも置かない", () => {
    expect(SQL).toContain("alter table public.rate_limits enable row level security;");
    expect(SQL).toContain("alter table public.rate_limits force row level security;");
    expect(SQL).not.toContain("create policy");
    expect(SQL).toContain("revoke all on table public.rate_limits from anon, authenticated;");
  });

  it("窓の区切りは、メモリの形と同じ「以上で数え直す」", () => {
    // src/server/ratelimit.ts は `at - previous.startedAt >= windowMs` で数え直します
    expect(SQL).toContain("when p_now - r.window_started_at >= v_window then p_now");
    expect(SQL).toContain("when p_now - r.window_started_at >= v_window then 1");
  });
});

describe("接続元の IP を決められないとき", () => {
  const env = process.env as Record<string, string | undefined>;

  afterEach(() => {
    env.NODE_ENV = "test";
    requestHeaders.current = new Headers();
    delete (globalThis as Record<symbol, unknown>)[Symbol.for("saas-starter/unknown-ip-warned")];
  });

  it("本番では、立ち上げてから 1 回だけ記録に残す（何度起きても 1 回）", async () => {
    env.NODE_ENV = "production";
    const warned = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      expect(await clientIp()).toBe("0.0.0.0");
      expect(await clientIp()).toBe("0.0.0.0");
      expect(warned).toHaveBeenCalledTimes(1);
      expect(String(warned.mock.calls[0]?.[0])).toContain("TRUSTED_PROXY_HOPS");
    } finally {
      warned.mockRestore();
    }
  });

  it("決められたときと、お手元（本番でない）ときは、記録に残さない", async () => {
    const warned = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      expect(await clientIp()).toBe("0.0.0.0");
      env.NODE_ENV = "production";
      requestHeaders.current = new Headers({ "x-forwarded-for": "203.0.113.10" });
      expect(await clientIp()).toBe("203.0.113.10");
      expect(warned).not.toHaveBeenCalled();
    } finally {
      warned.mockRestore();
    }
  });
});

describe("鍵を秘密で包む（RATE_LIMIT_PEPPER）", () => {
  const env = process.env as Record<string, string | undefined>;
  const PEPPER = "a".repeat(64);

  afterEach(() => {
    env.NODE_ENV = "test";
    delete env.RATE_LIMIT_PEPPER;
    delete env.STARTER_FAKE_ALLOW_PRODUCTION;
  });

  it("包んだ鍵に、メールアドレスも IP も残らない。同じ鍵は同じ値、秘密が違えば別の値", () => {
    const key = "login:203.0.113.10:owner@example.com";
    const hashed = hashKey(key, PEPPER);
    expect(hashed).toMatch(/^rl:[0-9a-f]{40}$/);
    expect(hashed).not.toContain("owner");
    expect(hashed).not.toContain("203.0.113.10");
    expect(hashKey(key, PEPPER)).toBe(hashed);
    expect(hashKey(key, "b".repeat(64))).not.toBe(hashed);
    expect(hashKey("login:203.0.113.10:other@example.com", PEPPER)).not.toBe(hashed);
  });

  it("数える入れ物には、包んだ鍵だけが届き、数え方は変わらない（11 回目で止まる）", async () => {
    const calls: Parameters<RateLimitCount>[0][] = [];
    const limiter = withHashedKeys(createStoreRateLimiter(LOGIN_LIMIT, sqlLikeCount(calls)), PEPPER);
    for (let i = 1; i <= 10; i += 1) expect((await limiter.hit("login:ip:a@example.com", at(i))).allowed).toBe(true);
    expect((await limiter.hit("login:ip:a@example.com", at(11))).allowed).toBe(false);
    expect(new Set(calls.map((call) => call.key))).toEqual(new Set([hashKey("login:ip:a@example.com", PEPPER)]));
  });

  it("本番で入れていない・短いときは、理由を添えて止める", () => {
    env.NODE_ENV = "production";
    expect(() => rateLimitPepper()).toThrow(/RATE_LIMIT_PEPPER を 32 文字以上/);
    env.RATE_LIMIT_PEPPER = "short";
    expect(() => rateLimitPepper()).toThrow(/RATE_LIMIT_PEPPER/);
    env.RATE_LIMIT_PEPPER = PEPPER;
    expect(rateLimitPepper()).toBe(PEPPER);
  });

  it("お手元では、入れていなければ決まった値で動く", () => {
    env.NODE_ENV = "test";
    expect(rateLimitPepper()).toMatch(/not-for-production/);
  });
});
