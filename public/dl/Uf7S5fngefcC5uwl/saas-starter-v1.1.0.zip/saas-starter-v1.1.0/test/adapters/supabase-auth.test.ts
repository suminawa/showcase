/**
 * 認証のつなぎ役のうち、本物のデータベースが無くても確かめられるところです。
 * （ログインそのものの往復は test/supabase.test.ts で確かめています）
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import { describe, expect, it, vi } from "vitest";
import { createSupabaseAuth, hasRecentEmailProof } from "../../src/adapters/supabase/auth";

const USER = {
  id: "11111111-1111-4111-8111-111111111111",
  email: "owner@example.com",
  user_metadata: { name: "みなと 太郎" },
};

/** つなぎ口にお渡しした呼び出しを、順に積んでおくところです */
type Call = (string | number | boolean | null | undefined)[];

/**
 * 認証の口だけが動き、profiles の読み取りが決まった答えを返すつなぎ口です。
 * 本物の形のうち、ここで使うところだけを作っています。
 *
 * **引数も残らず覚えておきます。** 引数を 1 つも見ない作りものにすると、
 * 別の表を引いても、別の方の id で引いても緑のままになってしまいます。
 */
function clientWithProfile(
  profile: { data: unknown; error: unknown },
  calls: Call[] = [],
): SupabaseClient {
  return {
    auth: {
      getUser: async () => {
        calls.push(["auth.getUser"]);
        return { data: { user: USER }, error: null };
      },
    },
    from: (table: string) => {
      calls.push(["from", table]);
      return {
        select: (columns: string) => {
          calls.push(["select", columns]);
          return {
            eq: (column: string, value: string) => {
              calls.push(["eq", column, value]);
              return {
                maybeSingle: async () => {
                  calls.push(["maybeSingle"]);
                  return profile;
                },
              };
            },
          };
        },
      };
    },
  } as unknown as SupabaseClient;
}

describe("認証のつなぎ役", () => {
  it("プロフィールを読めたときは、そのお名前と言語を使う", async () => {
    const calls: Call[] = [];
    const auth = createSupabaseAuth({
      client: clientWithProfile({ data: { name: "みなと 太郎", lang: "en" }, error: null }, calls),
      googleEnabled: false,
    });

    expect(await auth.getUser()).toEqual({
      id: USER.id,
      email: "owner@example.com",
      name: "みなと 太郎",
      lang: "en",
    });

    // **どの表を、どの列で、どなたの id で引いたか**まで確かめます。
    // ここを見ていないと、別の表を引いても別の方の id で引いても緑になります。
    expect(calls).toEqual([
      ["auth.getUser"],
      ["from", "profiles"],
      ["select", "name, lang"],
      ["eq", "id", USER.id],
      ["maybeSingle"],
    ]);
  });

  it("プロフィールを読めなかったときは、記録に 1 行だけ残す", async () => {
    // 読めない理由（表が開かれていない・つながらない）は、気づけないと直せません。
    // とはいえ画面は止めず、仮のお名前でお通しします。
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: clientWithProfile({
          data: null,
          error: { code: "42501", message: "permission denied for table profiles" },
        }),
        googleEnabled: false,
      });

      const user = await auth.getUser();
      // ログインの状態そのものは、認証の口から引けています
      expect(user).toEqual({
        id: USER.id,
        email: "owner@example.com",
        name: "みなと 太郎",
        lang: "ja",
      });

      expect(logged).toHaveBeenCalledTimes(1);
      const line = String(logged.mock.calls[0]?.[0] ?? "");
      // 内部の文（表の名前や SQL）は、記録にも持ち回りません
      expect(line).not.toContain("permission denied");
      expect(line).not.toContain("profiles");
    } finally {
      logged.mockRestore();
    }
  });

  it("ログインのリンクをお受けいただけなかったときは、記録に 1 行だけ残す", async () => {
    // この符号は、まだご登録のないメールアドレスへのお求めでも返りますし、
    // Email の設定が無効のときにも返ります。お返事は「お送りしました」の
    // ままにして（ご登録の有無を隠すため）、気づけるように記録だけ残します。
    const logged = vi.spyOn(console, "warn").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: {
          auth: {
            signInWithOtp: async () => ({
              error: {
                code: "otp_disabled",
                status: 422,
                message: "Signups not allowed for otp",
              },
            }),
          },
        } as unknown as SupabaseClient,
        googleEnabled: false,
      });

      // お返事は、お送りしたときと同じです
      expect(await auth.sendMagicLink("owner@example.com", "https://example.com/auth/callback"))
        .toEqual({ ok: true });

      expect(logged).toHaveBeenCalledTimes(1);
      const line = String(logged.mock.calls[0]?.[0] ?? "");
      // メールアドレスは、記録にも残しません
      expect(line).not.toContain("owner@example.com");
      expect(line).toContain("Email");
    } finally {
      logged.mockRestore();
    }
  });

  it("ログインのリンクをお送りできたときは、記録に何も残さない", async () => {
    const logged = vi.spyOn(console, "warn").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: {
          auth: { signInWithOtp: async () => ({ error: null }) },
        } as unknown as SupabaseClient,
        googleEnabled: false,
      });

      expect(await auth.sendMagicLink("owner@example.com", "https://example.com/auth/callback"))
        .toEqual({ ok: true });
      expect(logged).not.toHaveBeenCalled();
    } finally {
      logged.mockRestore();
    }
  });

  it("プロフィールの行がまだ無いときは、記録に残さない", async () => {
    // ご登録の直後で、行を作る前です（誤りではありません）
    const logged = vi.spyOn(console, "error").mockImplementation(() => {});

    try {
      const auth = createSupabaseAuth({
        client: clientWithProfile({ data: null, error: null }),
        googleEnabled: false,
      });

      const user = await auth.getUser();
      expect(user?.name).toBe("みなと 太郎");
      expect(logged).not.toHaveBeenCalled();
    } finally {
      logged.mockRestore();
    }
  });
});

/** 認証の口の誤りの形です（AuthError のうち、つなぎ役が見るところだけです） */
function authError(code: string, status = 400): { code: string; status: number; message: string } {
  return { code, status, message: code };
}

describe("パスワードの再設定と確かめ直しのつなぎ役（1.1.0）", () => {
  function resetClient(replies: { error: unknown }[], calls: unknown[][] = []): SupabaseClient {
    return {
      auth: {
        resetPasswordForEmail: async (email: string, options: unknown) => {
          calls.push([email, options]);
          return replies.shift();
        },
      },
    } as unknown as SupabaseClient;
  }

  it("再設定のメールは、戻り先をそのまま渡す", async () => {
    const calls: unknown[][] = [];
    const auth = createSupabaseAuth({ client: resetClient([{ error: null }], calls), googleEnabled: false });
    const back = "https://example.com/auth/callback?next=%2Freset-password";
    expect(await auth.sendPasswordReset("owner@example.com", back)).toEqual({ ok: true });
    expect(calls[0]).toEqual(["owner@example.com", { redirectTo: back }]);
  });

  it("メールアドレスごとの送りすぎ（ご登録のある方にだけ起きる）は、お送りしたときと同じお返事にする", async () => {
    const auth = createSupabaseAuth({
      client: resetClient([{ error: authError("over_email_send_rate_limit", 429) }]),
      googleEnabled: false,
    });
    expect(await auth.sendPasswordReset("owner@example.com", "https://example.com/x")).toEqual({ ok: true });
  });

  it("接続元ごとの上限だけを rate_limited でお伝えし、ほかは unavailable", async () => {
    const auth = createSupabaseAuth({
      client: resetClient([
        { error: authError("over_request_rate_limit", 429) },
        { error: authError("unexpected_failure", 500) },
      ]),
      googleEnabled: false,
    });
    expect(await auth.sendPasswordReset("a@example.com", "https://example.com/x")).toEqual({
      ok: false,
      code: "rate_limited",
    });
    expect(await auth.sendPasswordReset("a@example.com", "https://example.com/x")).toEqual({
      ok: false,
      code: "unavailable",
    });
  });

  it("新しいパスワードにしたあと、ほかの端末のセッションを閉じる。同じ・弱いものは password_rejected", async () => {
    const replies = [{ error: null }, { error: authError("same_password", 422) }, { error: authError("weak_password", 422) }];
    const calls: unknown[][] = [];
    const auth = createSupabaseAuth({
      client: {
        auth: {
          updateUser: async (attributes: unknown) => {
            calls.push(["updateUser", attributes]);
            return replies.shift();
          },
          signOut: async (options: unknown) => {
            calls.push(["signOut", options]);
            return { error: null };
          },
        },
      } as unknown as SupabaseClient,
      googleEnabled: false,
    });

    expect(await auth.updatePassword("new-password-1")).toEqual({ ok: true });
    expect(calls).toEqual([
      ["updateUser", { password: "new-password-1" }],
      ["signOut", { scope: "others" }],
    ]);
    expect(await auth.updatePassword("new-password-1")).toEqual({ ok: false, code: "password_rejected" });
    expect(await auth.updatePassword("password")).toEqual({ ok: false, code: "password_rejected" });
    // 書き換えられなかったときは、セッションを閉じに行きません
    expect(calls.filter((call) => call[0] === "signOut")).toHaveLength(1);
  });

  it("いまのパスワードの確かめは、違えば bad_credentials（理由の細かい符号は出さない）", async () => {
    const replies = [{ error: null }, { error: authError("invalid_credentials", 400) }, { error: authError("email_not_confirmed", 400) }];
    const auth = createSupabaseAuth({
      client: {
        auth: { signInWithPassword: async () => replies.shift() },
      } as unknown as SupabaseClient,
      googleEnabled: false,
    });
    expect(await auth.verifyPassword("owner@example.com", "right")).toEqual({ ok: true });
    expect(await auth.verifyPassword("owner@example.com", "wrong")).toEqual({ ok: false, code: "bad_credentials" });
    expect(await auth.verifyPassword("owner@example.com", "x")).toEqual({ ok: false, code: "bad_credentials" });
  });

  it("メールでの確かめが最近かどうかは、署名を確かめた中身（getClaims）の amr だけを見る", async () => {
    const now = Math.floor(Date.now() / 1000);
    const claimsClient = (claims: unknown, error: unknown = null) =>
      ({ auth: { getClaims: async () => ({ data: error === null ? { claims } : null, error }) } }) as unknown as SupabaseClient;

    const fresh = createSupabaseAuth({
      client: claimsClient({ amr: [{ method: "recovery", timestamp: now - 30 }] }),
      googleEnabled: false,
    });
    expect(await fresh.recentEmailSignIn(600)).toBe(true);

    const password = createSupabaseAuth({
      client: claimsClient({ amr: [{ method: "password", timestamp: now - 30 }] }),
      googleEnabled: false,
    });
    expect(await password.recentEmailSignIn(600)).toBe(false);

    const broken = createSupabaseAuth({ client: claimsClient(null, new Error("bad jwt")), googleEnabled: false });
    expect(await broken.recentEmailSignIn(600)).toBe(false);
  });

  it("amr の読み方: 古いもの・時刻の無いもの・パスワードは数えない", () => {
    const now = 1_800_000_000;
    expect(hasRecentEmailProof([{ method: "otp", timestamp: now - 600 }], now, 600)).toBe(true);
    expect(hasRecentEmailProof([{ method: "magiclink", timestamp: now - 601 }], now, 600)).toBe(false);
    expect(hasRecentEmailProof(["recovery"], now, 600)).toBe(false);
    expect(hasRecentEmailProof([{ method: "oauth", timestamp: now }], now, 600)).toBe(false);
    expect(hasRecentEmailProof(undefined, now, 600)).toBe(false);
    // 時計のずれを越えて、未来の時刻を名乗るものは信じません
    expect(hasRecentEmailProof([{ method: "recovery", timestamp: now + 3600 }], now, 600)).toBe(false);
  });
});
