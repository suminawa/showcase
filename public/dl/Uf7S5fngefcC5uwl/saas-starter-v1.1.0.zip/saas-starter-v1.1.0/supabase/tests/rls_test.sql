-- 表と関数の「形」を確かめます。
-- 誰が何をできるか（役割ごとの可否）は test/rls.test.ts が実際のログインで確かめます。
-- ここで見るのは、決まりを付け忘れていないか・関数の口が変わっていないかです。
--
-- 回し方: npm run test:rls（この中で supabase test db が呼ばれます）

begin;
select plan(49);

-- ---------------------------------------------------------------------------
-- 表の形
-- ---------------------------------------------------------------------------

select is(
  (select array_agg(tablename::text order by tablename) from pg_tables where schemaname = 'public'),
  array[
    'audit_logs', 'invitations', 'memberships', 'organizations', 'plan_limits', 'profiles',
    'projects', 'rate_limits', 'stripe_customers', 'stripe_events', 'subscriptions'
  ],
  'public の表は、決めた 11 だけです'
);

select bag_eq(
  $$ select c.relname::text
       from pg_class c
       join pg_namespace n on n.oid = c.relnamespace
      where n.nspname = 'public'
        and c.relkind = 'r'
        and c.relrowsecurity
        and c.relforcerowsecurity $$,
  $$ values ('audit_logs'), ('invitations'), ('memberships'), ('organizations'), ('plan_limits'),
            ('profiles'), ('projects'), ('rate_limits'), ('stripe_customers'), ('stripe_events'),
            ('subscriptions') $$,
  '11 の表すべてで、行の出入りの決まりが有効で、表の持ち主にも当たります'
);

-- ---------------------------------------------------------------------------
-- 関数の形（次の Task がこの名前と引数をそのまま呼びます）
-- ---------------------------------------------------------------------------

select bag_eq(
  $$ select p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')'
       from pg_proc p
       join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public' $$,
  $$ values
      ('accept_invitation(p_invitation_id uuid, p_user_id uuid, p_role text)'),
      ('apply_subscription_change(p_organization_id uuid, p_row jsonb, p_now timestamp with time zone)'),
      ('audit_invitations()'),
      ('audit_memberships()'),
      ('audit_subscriptions()'),
      ('change_member_role(p_organization_id uuid, p_user_id uuid, p_role text)'),
      ('create_organization_guarded(p_name text, p_max_per_user integer)'),
      ('create_project_guarded(p_organization_id uuid, p_name text, p_note text, p_created_by uuid, p_limit integer)'),
      ('delete_account(p_user_id uuid)'),
      ('find_invitation_by_hash(p_token_hash text)'),
      ('handle_new_user()'),
      ('invitations_before_update()'),
      ('is_member(org uuid)'),
      ('member_role(org uuid)'),
      ('memberships_guard()'),
      ('organizations_guard_delete()'),
      ('profiles_before_delete()'),
      ('profiles_before_update()'),
      ('projects_before_update()'),
      ('purge_audit_logs(p_older_than interval)'),
      ('rate_limit_hit(p_key text, p_limit integer, p_window_seconds integer, p_now timestamp with time zone)'),
      ('remove_member_guarded(p_organization_id uuid, p_user_id uuid)'),
      ('shares_organization(p_user uuid)'),
      ('write_audit_log(p_organization_id uuid, p_actor_id uuid, p_action text, p_target text, p_detail jsonb)') $$,
  '関数の名前と引数が、約束どおりにそろっています'
);

-- ---------------------------------------------------------------------------
-- 置いていない決まり
-- ---------------------------------------------------------------------------

select is(
  (select count(*) from pg_policies
    where schemaname = 'public' and tablename = 'organizations' and cmd = 'INSERT'),
  0::bigint,
  '組織を作る決まりは置きません（create_organization_guarded だけが作ります）'
);

select is(
  (select count(*) from pg_policies
    where schemaname = 'public'
      and tablename in ('subscriptions', 'stripe_customers', 'stripe_events')
      and cmd <> 'SELECT'),
  0::bigint,
  '課金の 3 つの表には、書き込みの決まりが 1 つもありません'
);

select is(
  (select count(*) from pg_policies
    where schemaname = 'public' and tablename in ('stripe_customers', 'stripe_events')),
  0::bigint,
  '決済のお客さま番号と通知の記録には、決まりが 1 つもありません'
);

select is(
  (select count(*) from pg_policies
    where schemaname = 'public' and tablename = 'plan_limits' and cmd <> 'SELECT'),
  0::bigint,
  'プランの上限の表には、書き込みの決まりがありません'
);

select is(
  (select count(*) from pg_policies
    where schemaname = 'public' and tablename = 'memberships' and cmd = 'INSERT'),
  0::bigint,
  'メンバーの行を増やす決まりは置きません（関数だけが増やします）'
);

select is(
  (select count(*) from pg_policies
    where schemaname = 'public' and tablename = 'audit_logs' and cmd <> 'SELECT'),
  0::bigint,
  '監査ログには、書き込みの決まりが 1 つもありません（書くのは引き金だけです）'
);

select is(
  (select count(*) from pg_policies where schemaname = 'public' and tablename = 'rate_limits'),
  0::bigint,
  '回数の上限の表には、決まりが 1 つもありません（service role の関数だけが書きます）'
);

-- ---------------------------------------------------------------------------
-- security definer の関数
-- ---------------------------------------------------------------------------

select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in ('is_member', 'member_role')
      and p.prosecdef
      and p.proconfig @> array['search_path=""']),
  2::bigint,
  '見え方の補助の 2 つは security definer で、search_path が空に固定です'
);

-- search_path が空なので、関数の中の表と関数はすべて public. まで書いてあります。
-- 呼んだ側の search_path で、別の表にすり替えられません。
select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.prosecdef
      and (p.proconfig is null or not (p.proconfig @> array['search_path=""']))),
  0::bigint,
  'security definer の関数は、すべて search_path を空に固定しています'
);

-- 呼べる関数は 9 つ、引き金の関数とその補助は 11 です。
-- この土台では新しい関数に anon と authenticated が自動で付くので、
-- 取り上げ忘れが 1 つでもあれば、ここで赤くなります。
select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in (
        'is_member', 'member_role', 'shares_organization',
        'create_organization_guarded', 'create_project_guarded',
        'change_member_role', 'remove_member_guarded',
        'find_invitation_by_hash', 'accept_invitation'
      )
      and has_function_privilege('anon', p.oid, 'execute')),
  0::bigint,
  'ログインしていない方は、9 つの関数のどれも呼べません'
);

select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in (
        'is_member', 'member_role', 'shares_organization',
        'create_organization_guarded', 'create_project_guarded',
        'change_member_role', 'remove_member_guarded',
        'find_invitation_by_hash', 'accept_invitation'
      )
      and has_function_privilege('authenticated', p.oid, 'execute')),
  9::bigint,
  'ログイン中の方は、9 つの関数を呼べます'
);

select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in (
        'handle_new_user', 'profiles_before_update', 'projects_before_update',
        'memberships_guard', 'invitations_before_update', 'organizations_guard_delete',
        'audit_memberships', 'audit_invitations', 'audit_subscriptions',
        'profiles_before_delete', 'write_audit_log'
      )
      and (
        has_function_privilege('anon', p.oid, 'execute')
        or has_function_privilege('authenticated', p.oid, 'execute')
      )),
  0::bigint,
  '引き金の関数は、どなたも直には呼べません'
);

-- 決済の通知が呼ぶ関数だけは、ログイン中の方にもお渡ししません。
-- ここを開けると、どなたでもご契約の行（プランと状態）を書き換えられてしまいます。
select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = 'apply_subscription_change'
      and (
        has_function_privilege('anon', p.oid, 'execute')
        or has_function_privilege('authenticated', p.oid, 'execute')
      )),
  0::bigint,
  '決済の通知の関数は、画面の側からは呼べません'
);

select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = 'apply_subscription_change'
      and has_function_privilege('service_role', p.oid, 'execute')),
  1::bigint,
  '決済の通知の関数は、service role だけが呼べます'
);

-- 回数の上限の関数も、service role だけです（ログインの前に、サーバーが数えます）
select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = 'rate_limit_hit'
      and (
        has_function_privilege('anon', p.oid, 'execute')
        or has_function_privilege('authenticated', p.oid, 'execute')
      )),
  0::bigint,
  '回数の上限の関数は、画面の側からは呼べません'
);

-- 退会の関数と、古い記録を消す関数も、service role だけです
-- （画面の側の鍵で退会の関数を呼べると、ご本人の確かめ直しを素通りされます）
select is(
  (select count(*) from pg_proc p
     join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in ('delete_account', 'purge_audit_logs')
      and not has_function_privilege('anon', p.oid, 'execute')
      and not has_function_privilege('authenticated', p.oid, 'execute')
      and has_function_privilege('service_role', p.oid, 'execute')),
  2::bigint,
  '退会の関数と、古い記録を消す関数は、service role だけが呼べます'
);

-- ---------------------------------------------------------------------------
-- 回数の上限（固定窓）: 10 分で 10 回のとき、11 回目は止まる
-- （src/server/ratelimit.ts のメモリの形と同じ数え方です）
-- ---------------------------------------------------------------------------

select is(
  (select count(*) from generate_series(1, 10) g
    where (public.rate_limit_hit(
      'pgtap:login', 10, 600, '2026-10-21T00:00:00Z'::timestamptz + g * interval '1 second'
    ) ->> 'allowed')::boolean),
  10::bigint,
  '窓の中の 10 回目までは通ります'
);

select is(
  public.rate_limit_hit('pgtap:login', 10, 600, '2026-10-21T00:00:11Z'),
  '{"allowed": false, "retry_after_seconds": 590}'::jsonb,
  '11 回目は止まり、窓の終わりまでの秒数をお返しします'
);

select is(
  public.rate_limit_hit('pgtap:other', 10, 600, '2026-10-21T00:00:11Z') ->> 'allowed',
  'true',
  'ほかの鍵は、別に数えます'
);

select is(
  public.rate_limit_hit('pgtap:login', 10, 600, '2026-10-21T00:10:01Z') ->> 'allowed',
  'true',
  '窓の長さを過ぎたら、1 から数え直します'
);

-- ---------------------------------------------------------------------------
-- ログインしていない方（anon）からは、どの表も見えません
-- ここまでの確かめでは表が空なので、まず見本の行を入れます（この取引の中だけです）
-- ---------------------------------------------------------------------------

insert into auth.users (id, email, aud, role)
values ('00000000-0000-4000-8000-000000000001', 'owner-check@example.com', 'authenticated', 'authenticated');

insert into public.organizations (id, name)
values ('00000000-0000-4000-8000-0000000000a1', 'しおさい設計室');

insert into public.memberships (organization_id, user_id, role)
values ('00000000-0000-4000-8000-0000000000a1', '00000000-0000-4000-8000-000000000001', 'owner');

insert into public.invitations (organization_id, email, role, token_hash, expires_at)
values (
  '00000000-0000-4000-8000-0000000000a1',
  'guest@example.com',
  'member',
  repeat('0', 64),
  now() + interval '7 days'
);

insert into public.projects (organization_id, name, created_by)
values (
  '00000000-0000-4000-8000-0000000000a1',
  'はじめてのプロジェクト',
  '00000000-0000-4000-8000-000000000001'
);

insert into public.subscriptions (organization_id, plan_id, status)
values ('00000000-0000-4000-8000-0000000000a1', 'standard', 'active');

insert into public.stripe_customers (organization_id, stripe_customer_id)
values ('00000000-0000-4000-8000-0000000000a1', 'cus_check');

insert into public.stripe_events (id, type)
values ('evt_check', 'checkout.session.completed');

-- 上の見本の行のうち、ご招待とご契約は、引き金が監査ログに書いています
select bag_eq(
  $$ select action from public.audit_logs
      where organization_id = '00000000-0000-4000-8000-0000000000a1' $$,
  $$ values ('invitation.created'), ('billing.changed') $$,
  'ご招待とご契約の変更は、引き金が監査ログに書きます'
);

select is(
  (select array_agg(distinct actor_type) from public.audit_logs),
  array['system'],
  'ログインした方のいない操作は、操作した方を system と書きます'
);

set local role anon;

select is((select count(*) from public.profiles), 0::bigint,
  'ログインしていない方は profiles を読めません');
select is((select count(*) from public.organizations), 0::bigint,
  'ログインしていない方は organizations を読めません');
select is((select count(*) from public.memberships), 0::bigint,
  'ログインしていない方は memberships を読めません');
select is((select count(*) from public.invitations), 0::bigint,
  'ログインしていない方は invitations を読めません');
select is((select count(*) from public.projects), 0::bigint,
  'ログインしていない方は projects を読めません');
-- お金に関わる 4 つの表は、行の決まりの前に、表そのものを開いていません。
-- 読もうとすると 0 行ではなく「許されていません」になります。
select throws_ok(
  $$ select count(*) from public.subscriptions $$,
  '42501', null,
  'ログインしていない方には、subscriptions が開かれていません'
);
select throws_ok(
  $$ select count(*) from public.stripe_customers $$,
  '42501', null,
  'ログインしていない方には、stripe_customers が開かれていません'
);
select throws_ok(
  $$ select count(*) from public.stripe_events $$,
  '42501', null,
  'ログインしていない方には、stripe_events が開かれていません'
);
select throws_ok(
  $$ select count(*) from public.plan_limits $$,
  '42501', null,
  'ログインしていない方には、プランの上限の表が開かれていません'
);

select throws_ok(
  $$ select count(*) from public.audit_logs $$,
  '42501', null,
  'ログインしていない方には、監査ログが開かれていません'
);
select throws_ok(
  $$ select count(*) from public.rate_limits $$,
  '42501', null,
  'ログインしていない方には、回数の上限の表が開かれていません'
);

select throws_ok(
  $$ insert into public.organizations (name) values ('なぎさ工房') $$,
  '42501',
  null,
  'ログインしていない方は組織を作れません'
);

with removed as (delete from public.projects returning 1)
select is((select count(*) from removed), 0::bigint,
  'ログインしていない方が消そうとしても、1 行も消えません');

reset role;

-- ---------------------------------------------------------------------------
-- 退会（アカウントの削除）の守り
-- ---------------------------------------------------------------------------

insert into auth.users (id, email, aud, role)
values ('00000000-0000-4000-8000-000000000002', 'member-check@example.com', 'authenticated', 'authenticated');

insert into public.memberships (organization_id, user_id, role)
values ('00000000-0000-4000-8000-0000000000a1', '00000000-0000-4000-8000-000000000002', 'member');

select throws_ok(
  $$ delete from auth.users where id = '00000000-0000-4000-8000-000000000001' $$,
  'ST003', null,
  'ほかの方がいる組織の、ただ 1 人のオーナーは、アカウントを消せません'
);

select is(
  public.delete_account('00000000-0000-4000-8000-000000000001'),
  'owner_has_members',
  '退会の関数は、最後のオーナーを owner_has_members で返し、何も消しません'
);

-- 退会する方あてのご招待（相手の欄にその方のメールアドレスが入る記録）を置いておきます
insert into public.invitations (organization_id, email, role, token_hash, expires_at)
values (
  '00000000-0000-4000-8000-0000000000a1',
  'member-check@example.com',
  'member',
  repeat('1', 64),
  now() + interval '7 days'
);

delete from auth.users where id = '00000000-0000-4000-8000-000000000002';

select results_eq(
  $$ select action, target, detail ->> 'role' from public.audit_logs
      where organization_id = '00000000-0000-4000-8000-0000000000a1'
        and action = 'account.deleted' $$,
  $$ values ('account.deleted'::text, ''::text, 'member'::text) $$,
  'メンバーの方の退会は、相手の欄を空にして account.deleted を 1 行書きます'
);

select is(
  (select count(*) from public.audit_logs where action in ('member.removed', 'member.left')),
  0::bigint,
  '退会に連れて消えたメンバーの行は、外した・抜けたとは書きません'
);

select is(
  (select count(*) from public.audit_logs where lower(target) = 'member-check@example.com'),
  0::bigint,
  '退会された方のメールアドレスは、ほかの記録の相手の欄からも消えます'
);

-- お 1 人だけの組織: ご契約が残っているあいだは、退会ごと止まります
insert into auth.users (id, email, aud, role)
values ('00000000-0000-4000-8000-000000000003', 'solo-check@example.com', 'authenticated', 'authenticated');
insert into public.organizations (id, name)
values ('00000000-0000-4000-8000-0000000000a2', 'ひとりの見本');
insert into public.memberships (organization_id, user_id, role)
values ('00000000-0000-4000-8000-0000000000a2', '00000000-0000-4000-8000-000000000003', 'owner');
insert into public.subscriptions (organization_id, plan_id, status)
values ('00000000-0000-4000-8000-0000000000a2', 'standard', 'active');

select throws_ok(
  $$ delete from auth.users where id = '00000000-0000-4000-8000-000000000003' $$,
  'ST005', null,
  'お 1 人だけの組織にご契約が残っていれば、Studio から消そうとしても止まります'
);

select is(
  public.delete_account('00000000-0000-4000-8000-000000000003'),
  'has_subscription',
  '退会の関数は、ご契約が残るお 1 人だけの組織を has_subscription で返します'
);

select is(
  (select count(*) from public.profiles where id = '00000000-0000-4000-8000-000000000003'),
  1::bigint,
  '止まったときは、アカウントも組織も何も消えていません'
);

update public.subscriptions set status = 'canceled', plan_id = 'free'
where organization_id = '00000000-0000-4000-8000-0000000000a2';

select is(
  public.delete_account('00000000-0000-4000-8000-000000000003'),
  'ok',
  'ご契約が終わっていれば、退会の関数がお 1 人だけの組織ごと消します'
);

select is(
  (select count(*) from public.organizations where id = '00000000-0000-4000-8000-0000000000a2'),
  0::bigint,
  'お 1 人だけの組織は、オーナーのいないまま残りません'
);

select is(
  public.purge_audit_logs(interval '1 day'),
  0,
  '古い記録を消す関数は、期間より新しい行を消しません'
);

select * from finish();
rollback;
