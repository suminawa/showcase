-- 監査ログ（組織の操作の記録）と、退会（アカウントの削除）の守りです（1.1.0 で足しました）。
--
-- 記録を書くのは、表の引き金だけです。画面の流れからは書きません。
--   - どの道から表を書き換えても（画面・関数・Studio での手直し）、記録が残ります。
--   - 一員の方が、記録を書き足したり、書き換えたり、消したりすることはできません。
-- 読めるのは、その組織のオーナーと管理者だけです
-- （src/core/permissions.ts の audit:read の行と同じです）。
--
-- 記録する操作は 8 つです（src/core/audit.ts の AUDIT_ACTIONS と同じ顔ぶれで、
-- test/audit.test.ts が突き合わせます）。
--   member.role_changed  役割の変更           memberships の更新
--   member.removed       組織から外す          memberships の削除（ほかの方が外したとき）
--   member.left          組織から退会          memberships の削除（ご自身で抜けたとき）
--   invitation.created   招待を送る            invitations の追加
--   invitation.revoked   招待の取り消し        invitations の状態の変更
--   invitation.accepted  招待をお受けいただく  invitations の状態の変更
--   billing.changed      ご契約の変更          subscriptions の追加・プランと状態の変更
--   account.deleted      アカウントの削除      profiles の削除（退会）
--
-- 組織を消すと、その組織の記録も一緒に消えます（on delete cascade）。
-- 操作した方が退会されると、操作した方の欄は空になり、相手の欄にその方のメールアドレスが
-- あれば、それも空にします（行は残ります）。
-- 残しておく期間はお客さまがお決めください。古い行を消す関数 purge_audit_logs を同梱しています
-- （README 15 章。目安は 1 年です）。
--
-- 退会は、関数 delete_account が 1 つの取引の中で行います（お 1 人だけの組織の削除と、
-- アカウントの削除）。呼べるのは service role だけです。

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations (id) on delete cascade,
  -- 操作した方です。ログインした方のいない操作と、退会された方は null です
  actor_id uuid references public.profiles (id) on delete set null,
  -- user … ログインした方の操作 / system … ログインした方のいない操作
  -- （決済の通知・service role の処理・Studio での手直し）
  actor_type text not null default 'user' check (actor_type in ('user', 'system')),
  action text not null check (
    action in (
      'member.role_changed', 'member.removed', 'member.left',
      'invitation.created', 'invitation.revoked', 'invitation.accepted',
      'billing.changed', 'account.deleted'
    )
  ),
  -- 相手のメールアドレスです（その時点の写しです。無いときは空の文字です）
  target text not null default '' check (char_length(target) <= 320),
  -- 役割・プラン・状態などの添え書きです（値はすべて文字です）
  detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

comment on table public.audit_logs is
  '組織の操作の記録。書くのは引き金だけで、読めるのはオーナーと管理者だけです';

create index audit_logs_organization_id_created_at_idx
  on public.audit_logs (organization_id, created_at desc);

alter table public.audit_logs enable row level security;
alter table public.audit_logs force row level security;

create policy audit_logs_select on public.audit_logs
  for select to authenticated
  using (public.member_role(organization_id) in ('owner', 'admin'));

-- 書く決まりは置きません。表そのものへの許しも、読むことだけにします
-- （決まりを 1 行書き落としても、書けるようにはならないためです）。
revoke all on table public.audit_logs from anon, authenticated;
grant select on table public.audit_logs to authenticated;

-- ---------------------------------------------------------------------------
-- 記録を 1 行書く補助です（引き金の中からだけ呼びます）
-- 組織がもう無いとき（組織ごと消している途中）は書きません。
-- ---------------------------------------------------------------------------
create or replace function public.write_audit_log(
  p_organization_id uuid,
  p_actor_id uuid,
  p_action text,
  p_target text,
  p_detail jsonb
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not exists (select 1 from public.organizations o where o.id = p_organization_id) then
    return;
  end if;
  -- 操作した方のプロフィールが無いとき（退会の途中など）は、空にします
  if p_actor_id is not null
    and not exists (select 1 from public.profiles p where p.id = p_actor_id)
  then
    p_actor_id := null;
  end if;

  insert into public.audit_logs (organization_id, actor_id, actor_type, action, target, detail)
  values (
    p_organization_id,
    p_actor_id,
    -- ログインした方のいない操作は、だれの操作か分からない null ではなく system と書きます
    case when auth.uid() is null then 'system' else 'user' end,
    p_action,
    coalesce(p_target, ''),
    coalesce(p_detail, '{}'::jsonb)
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- memberships: 役割の変更・外す・退会
-- ---------------------------------------------------------------------------
create or replace function public.audit_memberships()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_email text;
begin
  if tg_op = 'UPDATE' then
    if new.role is distinct from old.role then
      select p.email into v_email from public.profiles p where p.id = new.user_id;
      perform public.write_audit_log(
        new.organization_id, auth.uid(), 'member.role_changed', v_email,
        jsonb_build_object('from', old.role, 'to', new.role)
      );
    end if;
    return new;
  end if;

  -- 退会（プロフィールごと消えた）ときは、profiles の引き金が account.deleted を書いています
  select p.email into v_email from public.profiles p where p.id = old.user_id;
  if v_email is null then
    return old;
  end if;

  perform public.write_audit_log(
    old.organization_id, auth.uid(),
    case when old.user_id = auth.uid() then 'member.left' else 'member.removed' end,
    v_email,
    jsonb_build_object('role', old.role)
  );
  return old;
end;
$$;

create trigger audit_memberships
  after update or delete on public.memberships
  for each row execute function public.audit_memberships();

-- ---------------------------------------------------------------------------
-- invitations: 招待を送る・取り消す・お受けいただく
-- ---------------------------------------------------------------------------
create or replace function public.audit_invitations()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    perform public.write_audit_log(
      new.organization_id, auth.uid(), 'invitation.created', new.email,
      jsonb_build_object('role', new.role)
    );
  elsif new.status is distinct from old.status and new.status in ('revoked', 'accepted') then
    perform public.write_audit_log(
      new.organization_id, auth.uid(), 'invitation.' || new.status, new.email,
      jsonb_build_object('role', new.role)
    );
  end if;
  return new;
end;
$$;

create trigger audit_invitations
  after insert or update on public.invitations
  for each row execute function public.audit_invitations();

-- ---------------------------------------------------------------------------
-- subscriptions: ご契約のプラン・状態・期間の終わりの解約の予定が変わったとき
-- （書くのは決済の通知＝service role なので、操作した方はふつう空です）
-- ---------------------------------------------------------------------------
create or replace function public.audit_subscriptions()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT'
    or new.plan_id is distinct from old.plan_id
    or new.status is distinct from old.status
    or new.cancel_at_period_end is distinct from old.cancel_at_period_end
  then
    perform public.write_audit_log(
      new.organization_id, auth.uid(), 'billing.changed', '',
      jsonb_build_object(
        'plan', new.plan_id,
        'status', new.status,
        'cancelAtPeriodEnd', new.cancel_at_period_end::text
      )
    );
  end if;
  return new;
end;
$$;

create trigger audit_subscriptions
  after insert or update on public.subscriptions
  for each row execute function public.audit_subscriptions();

-- ---------------------------------------------------------------------------
-- profiles の削除（退会）: 最後の守りと、account.deleted の記録
--
-- 組織ごとに、次のとおりにします。
--   ほかの方がいる組織の、ただ 1 人のオーナー … 退会をお止めします（ST003）
--   その方お 1 人だけの組織                     … 組織ごと消します。ご契約が残っていれば、
--                                                organizations_guard_delete が止めます（ST005）
--   それ以外                                    … account.deleted を記録します
-- 画面の流れ（src/server/flows/account.ts）でも先にお止めしていますが、
-- Studio から直に消したときにも、オーナーのいない組織や、ご契約だけが続く組織が残らないよう、
-- ここが最後の砦です。
--
-- 記録の相手の欄は空にし、ほかの記録に残るその方のメールアドレスも空にします
-- （退会された方のメールアドレスを、組織の記録に残さないためです）。
-- ---------------------------------------------------------------------------
create or replace function public.profiles_before_delete()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_row record;
  v_owners integer;
  v_others integer;
begin
  for v_row in
    select m.organization_id, m.role
    from public.memberships m
    where m.user_id = old.id
    order by m.organization_id
  loop
    -- 役割を変える関数と同じ錠です（同時の役割の変更と、数えるところが食い違わないように）
    perform pg_advisory_xact_lock(
      hashtext('saas_starter:memberships'),
      hashtext(v_row.organization_id::text)
    );

    select count(*) filter (where m.role = 'owner' and m.user_id <> old.id),
           count(*) filter (where m.user_id <> old.id)
      into v_owners, v_others
    from public.memberships m
    where m.organization_id = v_row.organization_id;

    if v_others = 0 then
      -- お 1 人だけの組織です。ご契約が残っていれば、組織の削除の引き金が ST005 で止めます
      delete from public.organizations o where o.id = v_row.organization_id;
      continue;
    end if;

    if v_row.role = 'owner' and v_owners = 0 then
      raise exception 'ほかの方がいる組織の、ただ 1 人のオーナーは退会できません'
        using errcode = 'ST003';
    end if;

    perform public.write_audit_log(
      v_row.organization_id, null, 'account.deleted', '',
      jsonb_build_object('role', v_row.role)
    );
  end loop;

  if old.email <> '' then
    update public.audit_logs a set target = '' where lower(a.target) = lower(old.email);
  end if;

  return old;
end;
$$;

create trigger profiles_before_delete
  before delete on public.profiles
  for each row execute function public.profiles_before_delete();

-- ---------------------------------------------------------------------------
-- 退会: アカウントを 1 つの取引の中で消します（service role だけが呼べます）
--
-- auth.users の行を消すと、profiles → memberships へと連れて消え、
-- 上の引き金が、お 1 人だけの組織の削除と記録を行います。どこかで止まれば、全部が元に戻ります。
-- 戻り値: 'ok' | 'owner_has_members'（ST003）| 'has_subscription'（ST005）
--
-- 画面の側の鍵には渡しません。ご本人の確かめ直し（いまのパスワードなど）を
-- 素通りして、セッションだけで退会できてしまうためです。
-- ---------------------------------------------------------------------------
create or replace function public.delete_account(p_user_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_user_id is null or not exists (select 1 from auth.users u where u.id = p_user_id) then
    raise exception 'そのアカウントは見つかりません' using errcode = '22023';
  end if;

  begin
    delete from auth.users u where u.id = p_user_id;
  exception
    when sqlstate 'ST003' then
      return 'owner_has_members';
    when sqlstate 'ST005' then
      return 'has_subscription';
  end;

  return 'ok';
end;
$$;

comment on function public.delete_account(uuid) is
  '退会。お 1 人だけの組織の削除とアカウントの削除を、1 つの取引の中で行います';

-- ---------------------------------------------------------------------------
-- 古い記録を消します（service role だけが呼べます）。戻り値は消した行の数です。
-- 例: select public.purge_audit_logs(interval '365 days');
-- pg_cron で定期に回す手順は README 15 章にあります。
-- ---------------------------------------------------------------------------
create or replace function public.purge_audit_logs(p_older_than interval)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  if p_older_than is null or p_older_than < interval '1 day' then
    raise exception '1 日より短い期間は指定できません' using errcode = '22023';
  end if;
  delete from public.audit_logs a where a.created_at < now() - p_older_than;
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- 引き金と補助の関数は、どなたからも直には呼べないようにします
revoke all on function public.write_audit_log(uuid, uuid, text, text, jsonb)
  from public, anon, authenticated;
revoke all on function public.audit_memberships() from public, anon, authenticated;
revoke all on function public.audit_invitations() from public, anon, authenticated;
revoke all on function public.audit_subscriptions() from public, anon, authenticated;
revoke all on function public.profiles_before_delete() from public, anon, authenticated;

revoke all on function public.delete_account(uuid) from public, anon, authenticated;
grant execute on function public.delete_account(uuid) to service_role;
revoke all on function public.purge_audit_logs(interval) from public, anon, authenticated;
grant execute on function public.purge_audit_logs(interval) to service_role;
