-- 回数の上限を数える表と関数です（1.1.0 で足しました）。
--
-- メモリで数える形は、サーバーが複数台あると台ごとに数え直しになります。
-- この表で数えれば、どの台から来たお申し付けも同じ 1 つの数に足されます
-- （src/server/ports.ts の rateLimitStore() が、Supabase をつないだときの既定にしています）。
--
-- 数え方は src/server/ratelimit.ts のメモリの形と同じ「固定窓」です。
--   鍵ごとに「窓の始まり」と「回数」を持ち、窓の長さを過ぎたら 1 から数え直します。
--   上限を超えた回は通さず、次に試していただけるまでの秒数をお返しします。
--
-- 呼べるのは service role だけです。ログインの前（ご登録・ログイン・再設定のメール）に
-- 数えるため、ログイン中の方の鍵は使えません。画面の側の鍵からは、表も関数も見えません。

create table public.rate_limits (
  -- 何ごとに数えるか（例: login:<IP>:<メールアドレス>）。
  -- 上の行の形は src/server/flows/ が決めます。メールアドレスが入るので、外へは見せません。
  key text primary key check (char_length(key) between 1 and 400),
  window_started_at timestamptz not null,
  count integer not null check (count >= 1)
);

comment on table public.rate_limits is
  '回数の上限を数える表。書けるのは rate_limit_hit だけで、画面の側からは見えません';

-- 古い行を片づけるときに使います
create index rate_limits_window_started_at_idx on public.rate_limits (window_started_at);

alter table public.rate_limits enable row level security;
alter table public.rate_limits force row level security;
-- 決まりを 1 つも置きません（ログイン中の方からも、ログインしていない方からも見えません）
revoke all on table public.rate_limits from anon, authenticated;

-- 1 回数えます。
-- 戻り値: {"allowed": true|false, "retry_after_seconds": 0 以上の整数}
--
-- 数えるところと書くところは、insert … on conflict の 1 文の中です
-- （同じ鍵に同時に 11 回届いても、行の錠で 1 つずつ足されるので、11 回目は必ず止まります）。
-- p_now は呼ぶ側の時計です（メモリの形と同じく、時刻を引数でお預かりします）。
create or replace function public.rate_limit_hit(
  p_key text,
  p_limit integer,
  p_window_seconds integer,
  p_now timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_window interval;
  v_started timestamptz;
  v_count integer;
begin
  if p_key is null or p_key = '' or p_limit is null or p_limit < 1
    or p_window_seconds is null or p_window_seconds < 1 or p_now is null
  then
    raise exception '回数の上限の引数が正しくありません' using errcode = '22023';
  end if;

  v_window := make_interval(secs => p_window_seconds);

  insert into public.rate_limits as r (key, window_started_at, count)
  values (p_key, p_now, 1)
  on conflict (key) do update
     set window_started_at = case
           when p_now - r.window_started_at >= v_window then p_now
           else r.window_started_at
         end,
         count = case
           when p_now - r.window_started_at >= v_window then 1
           else r.count + 1
         end
  returning r.window_started_at, r.count into v_started, v_count;

  -- 100 回に 1 回ほど、1 日より前に始まった窓の行を片づけます（窓は長くても 1 時間です）。
  -- 確率での片づけです。お申し付けがとても多いときは、pg_cron の定期実行に移してください
  if random() < 0.01 then
    delete from public.rate_limits where window_started_at < p_now - interval '1 day';
  end if;

  if v_count <= p_limit then
    return jsonb_build_object('allowed', true, 'retry_after_seconds', 0);
  end if;

  return jsonb_build_object(
    'allowed', false,
    'retry_after_seconds',
    greatest(1, ceil(extract(epoch from (v_started + v_window - p_now)))::integer)
  );
end;
$$;

comment on function public.rate_limit_hit(text, integer, integer, timestamptz) is
  '回数の上限を 1 回数えます。上限を超えた回は allowed=false';

revoke all on function public.rate_limit_hit(text, integer, integer, timestamptz)
  from public, anon, authenticated;
grant execute on function public.rate_limit_hit(text, integer, integer, timestamptz)
  to service_role;
