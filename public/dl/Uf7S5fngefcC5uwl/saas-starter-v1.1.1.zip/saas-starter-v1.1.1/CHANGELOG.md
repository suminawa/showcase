# 更新履歴

## 1.1.1 — 2026-10-22

セキュリティの修正のための更新です。1.x をお求めの方は無料で更新いただけます。

- Next.js と React をセキュリティ修正版（Next.js 16.4.1 以降・React 19.2.9）に更新しました。同梱の package-lock.json では Next.js 16.4.2 です。画像の処理に使われる sharp も 0.35.5 以上になります。機能の変更はありません
  (Updated Next.js and React to their security releases (Next.js 16.4.1 or later, 16.4.2 in the bundled package-lock.json; React 19.2.9); sharp, used for image processing, now resolves to 0.35.5 or later. No functional changes)
- `npm audit` で見つかった開発用の道具（vitest が使う vite）の脆弱性も、互換のある版に上げて解消しました。お客さまのサイトに載るものには影響しません
  (Also resolved a `npm audit` finding in a development-only tool (vite, used by vitest) with a compatible upgrade. Nothing shipped to your site is affected)
- 新しい版で、vitest の 681 件、pgTAP の 49 件、ログインでの検査の 67 件、つなぎ役の検査の 42 件がすべて通ることを確かめました
  (Confirmed on the new versions: all 681 vitest tests, 49 pgTAP checks, 67 policy tests and 42 adapter tests pass)

**更新のしかた**

コードをお手直しのうえでお使いの方は、`package.json` と `package-lock.json` の 2 つを 1.1.1 のものに差し替え、`npm ci` をお回しください。データベースの移行の SQL はありません。

## 1.1.0 — 2026-10-21

パスワードの再設定・退会・監査ログ・データベースでの回数の上限・インボイスの登録番号を足した版です。1.0.x をお求めの方は無料で更新いただけます。

- パスワードの再設定の画面を足しました。ログインの画面の「パスワードをお忘れの方」から `/forgot-password` でメールをお求めいただき、メールのリンク（`/auth/callback` を通ります）から `/reset-password` で新しいパスワードをお決めいただけます。ご登録のないメールアドレスでも同じお返事をお出しし、ログインと同じ 2 本の回数の上限で数えます。ログイン中の方も、プロフィールの画面の「パスワードを変える」から同じ画面をお使いいただけます。ログイン中の変更では、いまのパスワードで確かめ直し（10 分以内にメールのリンクでログインし直した方は省けます）、変えたあとはほかの端末のセッションを閉じます（ログインから 24 時間以内の盗まれたセッションが Supabase の API を直に呼ぶ道は、Supabase の仕組みの上で閉じきれません。README 15 章に、打てる手とあわせて書いています）。メールアドレスごとの送りすぎ（ご登録のある方にだけ起きる誤り）も、お送りしたときと同じお返事にし、ご登録の有無が分からないようにしています。見本モードでも、メールを送らずに一周できます
  (Added password reset: request an email at `/forgot-password`, follow the link through `/auth/callback`, and choose a new password at `/reset-password`. The response never reveals whether an address is registered, including the per-address send limit that only registered addresses hit, and the same two rate-limit windows as sign-in apply. Signed-in users reach the same screen from "Change password" on the Profile screen; they must re-enter their current password (unless they signed in through an email link within 10 minutes), and other sessions are signed out afterwards (a stolen session less than 24 hours old can still call Supabase's API directly; README §15 explains this platform limit and the mitigations). Demo mode runs the whole flow without sending mail)
- 退会（アカウントの削除）を足しました。プロフィールの画面で、ご自身のメールアドレスと、いまのパスワード（確かめ直し）をご入力いただいてから消します。ほかの方がいる組織のただ 1 人のオーナーの方は、先にオーナーを引き継ぐか組織を削除していただくよう、組織の名前を添えてご案内します。お 1 人だけの組織はアカウントと一緒に消し、ご契約が残っていれば、その場で Stripe のご契約を解約してから消します。止まりうる確かめをすべて先に済ませ、最後にデータベースの関数 `delete_account`（service role だけが呼べます）が、お 1 人だけの組織の削除とアカウントの削除を 1 つの取引の中で行います。Studio から直にアカウントを消したときも、引き金 `profiles_before_delete` が同じ決まりで止め、お 1 人だけの組織を残しません
  (Added account deletion on the Profile screen, confirmed by your email address and your current password. The only owner of an organisation with other members is asked, by organisation name, to hand over ownership or delete it first. Organisations with no other members are deleted with the account, cancelling any live Stripe subscription first. All checks that can fail run first; then the service-role-only `delete_account` database function deletes the solo organisations and the account in one transaction. The `profiles_before_delete` trigger applies the same rules when a user is deleted directly in Studio)
- 回数の上限を、データベースで数えられるようにしました（`rate_limits` のテーブルと、service role だけが呼べる関数 `rate_limit_hit`）。Supabase をつないだときは、こちらが既定です。サーバーが何台に分かれても 1 つの数になり、同時に 11 回届いても 11 回目は止まります。`RATE_LIMIT_STORE=memory` で、これまでのメモリの数え方に戻せます。数える鍵（メールアドレスと IP）は、サーバーだけが知る秘密 `RATE_LIMIT_PEPPER` で HMAC にしてから入れ（**本番では `RATE_LIMIT_PEPPER` を 32 文字以上でお入れください。入れないと、ログインなどが理由つきで止まります**）、本番で接続元の IP を決められないときは、立ち上げてから 1 回だけ記録に残します。README に pg_cron での片づけの手順を足しました
  (Rate limits can now be counted in the database, using a `rate_limits` table and a service-role-only `rate_limit_hit` function. This is the default once Supabase is connected, so limits hold across instances and an eleventh simultaneous attempt is still refused. `RATE_LIMIT_STORE=memory` restores in-memory counting. Rate-limit keys (email address and IP) are HMAC'd with a server-only secret, `RATE_LIMIT_PEPPER` (**set it to at least 32 characters in production; without it, sign-in and similar requests stop with an explanatory error**), a one-time warning is logged in production when the client IP cannot be determined, and the README shows a pg_cron clean-up)
- 監査ログ（`audit_logs` のテーブルと `/app/settings/audit` の画面）を足しました。役割の変更・ご招待（送る・取り消す・お受けいただく）・ご契約の変更・メンバーを外す・退会を、データベースの引き金が記録します。読めるのはオーナーと管理者だけで、どなたも書き換えられません。ログインした方のいない操作は「システム」と記録し、退会された方のメールアドレスは記録から消します。古い行を消す関数 `purge_audit_logs` も同梱しました。権限のテーブルに `audit:read` の行を足しました
  (Added an audit log, the `audit_logs` table and the `/app/settings/audit` screen. Database triggers record role changes, invitations sent, revoked and accepted, billing changes, member removals and account deletions. Only owners and admins can read it and nobody can edit it. Actions with nobody signed in are recorded as "system", a deleted user's email address is removed from the log, and a `purge_audit_logs` function is included. The permission table gains an `audit:read` row)
- `legal.config.ts` に、適格請求書発行事業者の登録番号（`invoiceRegistrationNumber`。`T` と 13 桁）の欄を足しました。入れたときだけ特定商取引法に基づく表記（日本語・英語）に出し、形が違うときは `npm test` と画面の両方が止まります。README に Stripe の請求書の設定（7-9）を足し、`test/core/legal.test.ts` に日英の見出しと差し込みのずれの検査を足しました
  (Added an optional qualified-invoice registration number, `invoiceRegistrationNumber`, to `legal.config.ts`. It appears on the Japanese and English commercial-transactions notice only when set, and a malformed value stops both `npm test` and the page. The README gains a section on Stripe invoice settings (7-9), and `test/core/legal.test.ts` now checks that headings and interpolations agree between Japanese and English)
- プライバシーポリシーのひな形の「保管の期間」を、退会の画面と、退会のあとに残るもの（組織に残した内容と監査ログ、法令で保存が求められるお支払いの記録と Stripe の側の控え）に合わせて書き直しました
  (Rewrote the retention paragraph of the privacy-policy template to describe self-service account deletion and what remains afterwards, including billing records and Stripe's copy kept for the legally required period)
- README の「作らなかったもの」を「次に入れるもの（1.x の無料の更新で）」と「入れない方針のもの」に分けました。本番の Supabase で custom SMTP が要ること（6-2）と、1 人用（組織 1 つ固定）にする手順（11 章）を足しました。画面と README の「合言葉」を「パスワード」に改めました
  (Split "What we did not build" into "Coming in a free 1.x update" and "Left out on purpose", added the custom-SMTP requirement for hosted Supabase (§6-2) and a single-user recipe (§11), and replaced the remaining "合言葉" with "パスワード")
- `supabase/config.toml` の `secure_password_change` を `true` にしました（本番の Supabase でも「Secure password change」を有効にしてください）
  (`secure_password_change` is now `true` in `supabase/config.toml`; enable "Secure password change" in your hosted project as well)
- `test/supabase.test.ts` の基準の時刻を、決め打ちの日付からいまの時刻に替えました（ご招待の期限が 2026-09-27 を過ぎて切れ、`npm run test:rls` が落ちていたためです）
  (`test/supabase.test.ts` now uses the current time instead of a fixed date; invitations created at the fixed date expired after 2026-09-27 and made `npm run test:rls` fail)
- 検査は vitest が 681 件、pgTAP が 49 件、ログインでの検査が 67 件、つなぎ役の検査が 42 件になりました
  (vitest now runs 681 tests; the database suite has 49 pgTAP checks, 67 policy tests and 42 adapter tests)

**コードをお手直しのうえでお使いの方へ（更新の手順）**

1. 移行の SQL を 2 本、この順にあててください。どちらも新しいファイルで、これまでの 3 本には手を入れていません。
   - `supabase/migrations/20261021000100_rate_limits.sql`（回数の上限のテーブルと関数）
   - `supabase/migrations/20261021000200_audit_logs.sql`（監査ログのテーブル・引き金、退会の守りと関数 `delete_account`、古い記録を消す `purge_audit_logs`）

   お手元では `supabase db reset`、本番では `supabase db push` であたります。**`audit_logs` の引き金は、`profiles` を消すときに「ほかの方がいる組織のただ 1 人のオーナー」を止めます。** これまで Studio などからアカウントを直に消していらした場合は、先にオーナーを引き継いでください。
2. 新しく足したファイル（そのまま写してください）: `src/core/audit.ts`・`src/server/flows/account.ts`・`src/server/flows/audit.ts`・`src/adapters/supabase/ratelimit.ts`・`app/(auth)/forgot-password/page.tsx`・`app/(auth)/reset-password/page.tsx`・`app/app/settings/audit/page.tsx`・`test/audit.test.ts`・`test/ratelimit.test.ts`・`test/flows/account.test.ts`・`test/flows/password.test.ts`
3. 書き換えたファイル（お手直しの箇所と見比べてください）:
   - 口の形が増えました: `src/ports/auth.ts`（`sendPasswordReset`・`updatePassword`・`verifyPassword`・`recentEmailSignIn`）・`src/ports/billing.ts`（`cancelSubscription`）・`src/ports/data.ts`（`listAuditLogs`・`deleteAccount`）・`src/ports/index.ts`。**ご自身で口を実装していらっしゃる場合は、この 7 つを足してください**（型の検査が教えてくれます）。`updatePassword` は、書き換えたあとにほかの端末のセッションを閉じる約束です
   - つなぎ役: `src/adapters/fake/`（`auth.ts`・`billing.ts`・`data.ts`・`seed.ts`・`store.ts`）・`src/adapters/supabase/`（`auth.ts`・`data.ts`・`rows.ts`）・`src/adapters/stripe/billing.ts`
   - 決まりと流れ: `src/core/permissions.ts`（`audit:read`）・`src/core/validation.ts`（`mismatch`）・`src/core/legal.ts`・`src/core/i18n.ts`（`formatDateTime`）・`src/server/context.ts`（符号 `owner_has_members`・`password_rejected`）・`src/server/flows/auth.ts`・`src/server/ratelimit.ts`・`src/server/ports.ts`（`rateLimitStore()` と `limiters()`）
   - 画面: `app/(auth)/login/page.tsx`・`app/_actions/auth.ts`・`app/_actions/profile.ts`・`app/app/settings/layout.tsx`・`app/app/settings/profile/page.tsx`
   - 文と法務: `messages/ja.json`・`messages/en.json`（鍵を足し、`error.wrong_browser` と `auth.login.forgot` を書き換え）・`legal.config.ts`（`invoiceRegistrationNumber` を足しました。**お手元の値はそのまま残し、この 1 行だけをお足しください**）・`legal/tokushoho.*.txt`・`legal/privacy.*.txt`
   - そのほか: `.env.example`（`RATE_LIMIT_STORE`・`RATE_LIMIT_PEPPER`）・`supabase/config.toml`（`secure_password_change = true`）・`supabase/tests/rls_test.sql`・`scripts/release.mjs`・`package.json`・`package-lock.json`（版の番号だけです。依存パッケージは変わっていません）
4. 本番の環境変数に `RATE_LIMIT_PEPPER`（`openssl rand -hex 32` などで作った 32 文字以上の秘密）を足してください。
5. 本番の Supabase で custom SMTP をまだ設定していらっしゃらない場合は、README 6-2 の手順で設定してください。再設定のメールも、これがないとお客さまに届きません。

**For buyers who have modified the code:** apply the two new migrations in order (`20261021000100_rate_limits.sql`, then `20261021000200_audit_logs.sql`); the three existing migrations are unchanged. Copy the new files listed above, and compare the changed files with your own edits. If you implement the ports yourself, add `sendPasswordReset`, `updatePassword` (which must sign out other sessions), `verifyPassword` and `recentEmailSignIn` to `AuthPort`, `cancelSubscription` to `BillingPort`, and `listAuditLogs` and `deleteAccount` to `DataPort`. Add `RATE_LIMIT_PEPPER` (at least 32 characters, e.g. from `openssl rand -hex 32`) to your production environment. Set `secure_password_change = true` and enable "Secure password change" in your hosted project. In `legal.config.ts`, keep your values and add only the `invoiceRegistrationNumber` line. Dependencies are unchanged.

## 1.0.2 — 2026-10-19

依存パッケージの安全のための更新です。1.0.0・1.0.1 をお求めの方は無料で更新いただけます。

- 同梱の `package-lock.json` が指す `next` を 16.3.5 から 16.3.8 に上げました。16.3.7 までの版には、`next/og` の画像生成でリモートからコードを実行される恐れ（重大）と、下書き（Draft Mode）の内容が通常の応答に漏れる恐れの報告があります。あわせて `sharp` を 0.35.5 に、`source-map-js` を 1.2.2 に上げました（いずれも `npm audit` が「高」と報告していたものです）。新しい zip を解いて `npm ci` すれば新しい版が入ります。すでにお使いのプロジェクトでは、`package.json` の `next` を `^16.3.8` に書き換えて `npm install` を実行してください
  (Bumped `next` in the bundled lockfile from 16.3.5 to 16.3.8: versions up to 16.3.7 carry a critical advisory for remote code execution through `next/og` image generation and a Draft Mode content leak. Also bumped `sharp` to 0.35.5 and `source-map-js` to 1.2.2, both flagged "high" by `npm audit`. A fresh `npm ci` installs the new versions; in an existing project, change `next` to `^16.3.8` in `package.json` and run `npm install`)
- `npm run release:check` が、配布用の zip を作る前に `npm audit --omit=dev --audit-level=high` を通すようになりました。本番で使う依存に「高」以上の報告があるあいだは zip を作りません
  (`npm run release:check` now runs `npm audit --omit=dev --audit-level=high` before packaging, so no zip is built while a production dependency has a high or critical advisory)

## 1.0.1 — 2026-09-25

小さな手直しです。1.0.0 をお求めの方は無料で更新いただけます。

- ログインの誤り（`error=unavailable`）のうち、確認メールのリンクを登録したときと別のブラウザで開いたときだけの症状を、`wrong_browser` という新しい符号に分けました。ログインの画面には「確認メールのリンクは、登録したときと同じブラウザで開いてください。別のブラウザで開いた場合は、このページから合言葉（パスワード）でログインするか、もう一度登録のメールをお送りください。」と出るようになります（ほかの `unavailable` の場面の文はそのままです）。README のよくあるつまずきの表にも、同じ症状と直し方を足しました
  (Split the login error `error=unavailable` case that is specific to opening the confirmation link in a different browser than the one used to sign up into its own `wrong_browser` code, with a message explaining the fix on the login page. The generic `unavailable` message for other situations is unchanged. The same symptom and fix were added to the README's troubleshooting table)
- README の `stripe listen` の手順に、`Ready!` のあとの確かめ方を足しました。決済のたびに `-->` と `<-- [200]` の行が並ぶことを見て、並ばなければ `--forward-to` の付け忘れだと分かるようにしています
  (Added a verification step after the `stripe listen` command in the README: confirm a matching `-->`/`<-- [200]` line appears for each payment, and that its absence means `--forward-to` is missing)
- 「承ります」の言い回しを、画面・法務のひな形・README から取り除きました（「行えます」「受け付けます」などに言い換えています）
  (Removed the word "承ります" from the app, the legal templates and the README, rephrasing each occurrence in plain 敬体 Japanese)

## 1.0.0 — 2026-09-24

初版。

- 発売前の一周（2026-09-24、本物の Stripe のテストモード）で見つけた 2 点を直してあります
  (Two fixes from the pre-release walkthrough against real Stripe test mode)
  - 「期間の終わりでのご解約」を、新しい版の Stripe が `cancel_at` で知らせてきても、予定ありとして写します
    (Scheduled cancellations reported via `cancel_at` by the current Stripe API are now reflected as `cancel_at_period_end`)
  - README の `stripe listen` に `--events …` を付けました（CLI 1.5x で必須です）
    (The `stripe listen` command in the README now includes `--events`, which the CLI 1.5x requires)
- ログイン・組織・ご招待・プロジェクト・お支払い・法務の 16 の道すじが、そのまま動きます
  (Sixteen working routes: sign-in, organisations, invitations, projects, billing and the legal pages)
- 役割は owner・admin・member の 3 つ。表は `src/core/permissions.ts` の 1 か所にあり、画面と仕事の流れと行の出入りの決まりが、同じ表から決まります
  (Three roles, defined once in `src/core/permissions.ts`, from which the screens, the flows and the database policies are all derived)
- 表は 8 つ。すべてに行の出入りの決まり（RLS）があり、`memberships` を通してだけ見えます。ご契約と決済の 3 つの表に書けるのは service role だけです
  (Eight tables, all with row-level security; visibility flows through `memberships`, and only the service role writes the three billing tables)
- プランは 3 つ（無料・スタンダード ¥2,980・ビジネス ¥9,800）。上限は `plans.config.ts` と `plan_limits` の 2 か所でそろえます
  (Three plans, with quotas kept in step between `plans.config.ts` and `plan_limits`)
- Stripe の Checkout とお支払いの管理の画面、決済の通知 5 種。順不同で届いても最新の状態を取り直してから書き、同じ `event.id` は二度処理しません
  (Stripe Checkout, the customer portal, and five webhook event types; state is re-fetched before writing and each event id is handled once)
- ご招待はトークン 32 バイト・期限 7 日・1 回きり。表に置くのはハッシュだけです
  (Invitations use a 32-byte token, expire in 7 days and work once; only the hash is stored)
- `STARTER_FAKE=1` のあいだは、鍵が 1 つも無くても全部の画面が動きます。外へは何も送りません
  (With `STARTER_FAKE=1` every screen runs without a single key, and nothing leaves the machine)
- 画面の文は日本語と英語。明るい配色と暗い配色、390px 幅で 1 列、キーボードだけで一周できます
  (Japanese and English interface strings, light and dark palettes, a single column at 390px, and full keyboard operation)
- 法務のひな形は 3 種 6 枚（日本語が正、英語は要点の訳）。差し込む値は `legal.config.ts` にまとまっています
  (Three legal documents in two languages, with the interpolated values collected in `legal.config.ts`)
- 運営の方だけの見渡しの画面（`/admin`）。読むだけで、`ADMIN_EMAILS` が未設定のあいだは 404 です
  (A read-only operator overview at `/admin`, which is a 404 until `ADMIN_EMAILS` is set)
- 検査は vitest が 591 件、行の出入りの決まりが pgTAP 26 件とログインでの検査 65 件、つなぎ役の検査 36 件
  (591 vitest tests, plus 26 pgTAP checks, 65 policy tests and 36 adapter tests against a real database)
- ブラウザへ届くものに鍵が無いことを、2 通りに組み立て直し、立てたサーバーのお返事まで読んで確かめます（`npm run check:bundle`）
  (`npm run check:bundle` rebuilds the app both ways, then reads the live responses of a server it starts)
- 依存パッケージは 7 つだけ（`next`・`react`・`react-dom`・`@supabase/supabase-js`・`@supabase/ssr`・`stripe`・`resend`）
  (Seven runtime dependencies and no CSS framework)
- zip の中身: `app/`・`src/`・`supabase/`・`messages/`・`legal/`・`scripts/`・`test/`・設定のファイル 8 つと、4 つの文書
  (In the zip: the app, the source, the database, the strings, the legal text, the scripts, the tests, eight config files and the four documents)
