#!/usr/bin/env node
// 配布 zip を release/ に作る。買い手が貼るのは dist/Code.gs の 1 本だけ。
// src / test / scripts も入れる（「手元で動かす」と改造ができるように）。
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/form-intake-gas-v${pkg.version}.zip`;

if (!existsSync("dist/Code.gs")) {
  console.error("dist が無い。先に npm run build");
  process.exit(1);
}
mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

execFileSync(
  "zip",
  [
    "-r",
    out,
    "dist",
    "samples",
    "src",
    "test",
    "scripts",
    "README.ja.md",
    "LICENSE.md",
    "CHANGELOG.md",
    "package.json",
    "-x",
    "*.DS_Store",
  ],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
