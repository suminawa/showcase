# 業種別 LP テンプレ パックから送る

LP テンプレ パックの `content/saas.ts`（または `shop.ts`）の `form` を、次のようにします。

```ts
form: {
  fields: [
    { name: "name", label: "お名前", required: true },
    { name: "email", label: "メールアドレス", type: "email", required: true },
    { name: "message", label: "ご用件", type: "textarea", required: true },
  ],
  submitLabel: "送信する",
  endpoint: "https://script.google.com/macros/s/XXXXXXXXXXXX/exec",
  contentType: "text",
  honeypot: "homepage",
  messages: {
    sample: "送信先がまだ設定されていません。",
    sending: "送信しています…",
    success: "受け付けました。折り返しご連絡します。",
    failure: "送信できませんでした。時間をおいてお試しください。",
  },
}
```

- `endpoint`: このキットをデプロイしたときに出たウェブアプリの URL。
- `contentType`: 必ず `"text"` にします。`"json"` にすると、ブラウザが送る前に許可を問い合わせ（プリフライト）、Apps Script がそれに答えられないので届きません。
- `honeypot`: 設定シートの「ハニーポットの項目名」と同じ字にします（どちらも既定は `homepage`）。
- 入力欄の `name` が、そのまま受付シートの列名になります。設定シートの「項目の並び」に同じ字を同じ順で並べると、列の順もそろいます。
- 予約フォームにするときは、`{ name: "date", label: "ご希望日", type: "date" }` と `{ name: "slot", label: "時間帯" }` を足します。`type: "date"` の入力欄は `2026-09-14` の形で送られるので、このキットがそのまま読めます。

## 返事の中身を見る

このキットは、受け付けられなかったときも HTTP としては 200 を返します。断った理由は本文の JSON に入れています。

| 返事 | どんなとき |
|---|---|
| `{ "ok": true, "id": "20260914-003" }` | 受け付けたとき |
| `{ "ok": true }` | 見えない欄に字が入っていたとき（迷惑投稿） |
| `{ "ok": false, "reason": "invalid", "message": "「email」を入力してください。" }` | 必須が足りない、メールの形が違う、字数や項目数が多すぎるとき |
| `{ "ok": false, "reason": "full", "message": "選ばれた日時は、すでに受付を終えています。…" }` | 予約枠が満席のとき |
| `{ "ok": false, "reason": "error", "message": "受け付けに失敗しました。…" }` | 設定の間違いなどで処理できなかったとき |

そのため、`lib/form-submit.ts` が HTTP の状態（`response.ok`）だけを見ていると、必須漏れも満席も「送信できました」と出てしまいます。**本文の JSON を読み、`ok` が false なら失敗として扱ってください。**

送ったあとに成功かどうかを決めているところが

```ts
const response = await fetch(endpoint, request);
if (!response.ok) return { ok: false, message: messages.failure };
return { ok: true, message: messages.success };
```

のようになっていたら、こう差し替えます。

```ts
const response = await fetch(endpoint, request);
let answer: { ok?: boolean; message?: string } = {};
try {
  answer = await response.json();
} catch (error) {
  return { ok: false, message: messages.failure };
}
if (!answer.ok) return { ok: false, message: answer.message || messages.failure };
return { ok: true, message: messages.success };
```

- `answer.message` は、そのまま画面に出してよい日本語です。自前の文言で通したいときは `messages.failure` のままにします。
- 迷惑投稿とみなした送信にも `{ "ok": true }`（`id` なし）が返ります。画面には成功として出して構いません。弾かれたと分かると、bot は形を変えて送り直してくるからです。

## 「送信元」の列に URL を入れたいとき

LP テンプレ パックは、入力欄の値だけを送ります。どのページから来たかを残したいときは、`lib/form-submit.ts` の

```ts
const values = { ...args.values };
```

の次の行に

```ts
values.page = location.href;
```

を足してください。足さなければ、受付シートの「送信元」は空のままです。
