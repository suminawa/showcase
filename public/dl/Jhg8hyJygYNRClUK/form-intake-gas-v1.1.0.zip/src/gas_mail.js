/** 自動返信を 1 通送る。1 日の上限に達していたら送らない。 */

/** 今日あと送れるメールの数。読めなければ 1 通ぶんは残っているものとして進む */
export function remainingQuota_() {
  try {
    return MailApp.getRemainingDailyQuota();
  } catch (error) {
    Logger.log("フォーム受付: 残りの送信可能数を読めませんでした: " + error);
    return 1;
  }
}

/**
 * options は reply.js の buildReply が返したもの。
 * 送れたら true、上限に達していて送らなかったら false。
 */
export function sendReply_(options) {
  if (remainingQuota_() <= 0) {
    Logger.log("フォーム受付: MailApp の 1 日の上限に達したため、自動返信を送りませんでした");
    return false;
  }
  MailApp.sendEmail(options);
  return true;
}
