/** Slack / Discord の Webhook と、LINE の push message に 1 通送る。 */
import { buildPayload } from "./message.js";

const LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push";

function post_(url, payload, headers) {
  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  if (headers) options.headers = headers;
  const response = UrlFetchApp.fetch(url, options);
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(status + " が返りました: " + String(response.getContentText()).slice(0, 200));
  }
}

export function postSlack_(url, text) {
  post_(url, buildPayload(text, "slack"));
}

export function postDiscord_(url, text) {
  post_(url, buildPayload(text, "discord"));
}

export function pushLine_(token, to, text) {
  post_(LINE_PUSH_URL, buildPayload(text, "line", { lineTo: to }), { Authorization: "Bearer " + token });
}

/**
 * 設定の通知先すべてに送る。1 つが失敗しても残りには送り、失敗は実行ログに残す。
 * 返り値: 送れた宛先の数
 */
export function notifyAll_(config, text) {
  let sent = 0;
  for (let i = 0; i < config.targets.length; i += 1) {
    const target = config.targets[i];
    try {
      if (target === "slack") postSlack_(config.slackWebhookUrl, text);
      else if (target === "discord") postDiscord_(config.discordWebhookUrl, text);
      else if (target === "line") pushLine_(config.lineToken, config.lineTo, text);
      sent += 1;
    } catch (error) {
      Logger.log("フォーム受付: " + target + " に送れませんでした: " + error);
    }
  }
  return sent;
}
