/**
 * 受付番号の続きと、二重送信の覚え書き。
 * 受付番号はスクリプトのプロパティに 1 つだけ、二重送信の鍵は CacheService に 10 分だけ置く。
 */

/** 同時に届いた送信を待たせる時間 */
const LOCK_WAIT_MS = 10000;

/** 同じ中身の送信を二重送信とみなす間（秒） */
const DEDUPE_SECONDS = 600;

const LAST_RECEIPT_KEY = "lastReceipt";

/**
 * action を 1 つずつ順番に実行する。
 * 受付番号の採番と行の追加をここに入れるので、同時に 2 件届いても番号が重ならない。
 */
export function withLock_(action) {
  const lock = LockService.getScriptLock();
  lock.waitLock(LOCK_WAIT_MS);
  try {
    return action();
  } finally {
    lock.releaseLock();
  }
}

export function readLastReceipt_() {
  const raw = PropertiesService.getScriptProperties().getProperty(LAST_RECEIPT_KEY);
  return raw ? String(raw) : "";
}

export function saveLastReceipt_(receipt) {
  PropertiesService.getScriptProperties().setProperty(LAST_RECEIPT_KEY, String(receipt));
}

/** 送信の中身から鍵を作る。中身そのものは残さず、MD5 の 32 字だけを鍵にする */
export function dedupeKeyOf_(source) {
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, source, Utilities.Charset.UTF_8);
  let hex = "";
  for (let i = 0; i < digest.length; i += 1) {
    const byte = digest[i] < 0 ? digest[i] + 256 : digest[i];
    hex += (byte < 16 ? "0" : "") + byte.toString(16);
  }
  return "dup:" + hex;
}

/** 10 分以内に同じ中身が来ていれば、そのときの受付番号。無ければ空 */
export function readDuplicate_(key) {
  const found = CacheService.getScriptCache().get(key);
  return found ? String(found) : "";
}

export function saveDuplicate_(key, receipt) {
  CacheService.getScriptCache().put(key, String(receipt), DEDUPE_SECONDS);
}
