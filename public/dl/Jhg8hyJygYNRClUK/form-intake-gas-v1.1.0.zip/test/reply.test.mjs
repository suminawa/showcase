import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_CONFIG } from "../src/config.js";
import { buildReply } from "../src/reply.js";

const CONTEXT = {
  receipt: "20260914-001",
  fields: { name: "見本 太郎", email: "taro@example.com", message: "料金と納期を知りたいです。" },
  order: ["name", "email", "message"],
  source: "https://example.com/contact",
};

test("既定の件名と本文に、受付番号と項目一覧が入る", () => {
  const reply = buildReply(DEFAULT_CONFIG, CONTEXT);
  assert.equal(reply.to, "taro@example.com");
  assert.equal(reply.subject, "お問い合わせを受け付けました（受付番号 20260914-001）");
  assert.equal(
    reply.body,
    [
      "お問い合わせいただきありがとうございます。",
      "次の内容で受け付けました。あらためてご連絡します。",
      "",
      "受付番号: 20260914-001",
      "",
      "name: 見本 太郎",
      "email: taro@example.com",
      "message: 料金と納期を知りたいです。",
      "",
      "※ このメールは自動でお送りしています。",
    ].join("\n"),
  );
});

test("差出人名と返信先は、書いてあるときだけ付く", () => {
  const bare = buildReply(DEFAULT_CONFIG, CONTEXT);
  assert.equal(Object.prototype.hasOwnProperty.call(bare, "name"), false);
  assert.equal(Object.prototype.hasOwnProperty.call(bare, "replyTo"), false);

  const config = Object.assign({}, DEFAULT_CONFIG, { senderName: "はなまる商店", replyTo: "info@example.com" });
  const reply = buildReply(config, CONTEXT);
  assert.equal(reply.name, "はなまる商店");
  assert.equal(reply.replyTo, "info@example.com");
});

test("自動返信が FALSE なら送らない", () => {
  assert.equal(buildReply(Object.assign({}, DEFAULT_CONFIG, { autoReply: false }), CONTEXT), null);
});

test("メールの項目が空なら送らない", () => {
  const context = Object.assign({}, CONTEXT, { fields: { name: "見本 太郎" }, order: ["name"] });
  assert.equal(buildReply(DEFAULT_CONFIG, context), null);
  assert.equal(buildReply(Object.assign({}, DEFAULT_CONFIG, { emailField: "" }), CONTEXT), null);
});

test("件名に改行が入っても 1 行にたたむ", () => {
  const config = Object.assign({}, DEFAULT_CONFIG, { replySubject: "受け付けました\n{受付番号}" });
  assert.equal(buildReply(config, CONTEXT).subject, "受け付けました 20260914-001");
});
