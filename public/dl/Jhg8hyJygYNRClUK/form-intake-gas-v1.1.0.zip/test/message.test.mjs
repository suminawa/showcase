import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_CONFIG } from "../src/config.js";
import {
  QUOTA_NOTICE,
  buildErrorText,
  buildFieldList,
  buildNotificationText,
  buildPayload,
  renderTemplate,
} from "../src/message.js";

const CONTEXT = {
  receipt: "20260914-001",
  fields: { name: "見本 太郎", email: "taro@example.com", message: "料金と納期を知りたいです。" },
  order: ["name", "email", "message"],
  source: "https://example.com/contact",
};

test("項目一覧は「項目名: 値」を改行で並べ、空の項目は出さない", () => {
  assert.equal(
    buildFieldList(CONTEXT.fields, CONTEXT.order),
    ["name: 見本 太郎", "email: taro@example.com", "message: 料金と納期を知りたいです。"].join("\n"),
  );
  assert.equal(buildFieldList({ a: "1", b: "", c: "  " }, ["a", "b", "c"]), "a: 1");
});

test("差し込みが置き換わる", () => {
  assert.equal(renderTemplate("【受付】{受付番号}", CONTEXT), "【受付】20260914-001");
  assert.equal(renderTemplate("{送信元}", CONTEXT), "https://example.com/contact");
  assert.equal(renderTemplate("{email} さん", CONTEXT), "taro@example.com さん");
  assert.equal(renderTemplate("{受付番号}/{受付番号}", CONTEXT), "20260914-001/20260914-001");
  assert.equal(
    renderTemplate(DEFAULT_CONFIG.notifyTemplate, CONTEXT),
    ["【受付】20260914-001", "name: 見本 太郎", "email: taro@example.com", "message: 料金と納期を知りたいです。"].join("\n"),
  );
});

test("知らない差し込みはそのまま残す", () => {
  assert.equal(renderTemplate("{電話番号}", CONTEXT), "{電話番号}");
});

test("値の中に差し込みの字があっても、置き換えられない", () => {
  const context = Object.assign({}, CONTEXT, {
    fields: { name: "{受付番号}", email: "taro@example.com" },
    order: ["name", "email"],
  });
  assert.equal(renderTemplate("{name}", context), "{受付番号}");
});

test("自動返信を送れなかった日は、通知の末尾に 1 行足す", () => {
  const plain = buildNotificationText(DEFAULT_CONFIG, CONTEXT);
  assert.equal(plain.indexOf(QUOTA_NOTICE), -1);
  const noticed = buildNotificationText(DEFAULT_CONFIG, Object.assign({}, CONTEXT, { quotaExhausted: true }));
  assert.equal(noticed, plain + "\n\n" + QUOTA_NOTICE);
});

test("エラーは別の見出しで出す", () => {
  const text = buildErrorText(new Error("「設定」シートがありません"), "2026-09-14 10:32:05");
  assert.equal(text.indexOf("【フォーム受付｜エラー】2026-09-14 10:32:05"), 0);
  assert.ok(text.indexOf("「設定」シートがありません") > 0);
  assert.ok(buildErrorText("文字列でも受ける", "2026-09-14 10:32:05").indexOf("文字列でも受ける") > 0);
});

test("宛先ごとに送信データの形が違う", () => {
  assert.deepEqual(buildPayload("やあ", "slack"), { text: "やあ" });
  assert.deepEqual(buildPayload("やあ", "discord"), { content: "やあ" });
  assert.deepEqual(buildPayload("やあ", "line", { lineTo: "U0000" }), {
    to: "U0000",
    messages: [{ type: "text", text: "やあ" }],
  });
  assert.deepEqual(buildPayload("やあ", "line"), { to: "", messages: [{ type: "text", text: "やあ" }] });
});

test("Discord は 1,900 字、LINE は 5,000 字で切る", () => {
  const long = "あ".repeat(6000);
  assert.ok(buildPayload(long, "discord").content.length <= 1900);
  assert.ok(buildPayload(long, "discord").content.endsWith("…（以下省略）"));
  const line = buildPayload(long, "line", { lineTo: "U0000" }).messages[0].text;
  assert.ok(line.length <= 5000);
  assert.ok(line.endsWith("…（以下省略）"));
  assert.equal(buildPayload(long, "slack").text.length, 6000);
});

test("Slack は 39,000 字で切る", () => {
  const long = "あ".repeat(50000);
  const text = buildPayload(long, "slack").text;
  assert.ok(text.length <= 39000);
  assert.ok(text.endsWith("…（以下省略）"));
  // 上限までは 1 字も落とさない
  assert.equal(buildPayload("あ".repeat(39000), "slack").text.length, 39000);
});
