import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSource, MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";
import { readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";
import { createHash } from "node:crypto";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("import 行は落ち、export だけが剥がれる", () => {
  const input = 'import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\n';
  assert.equal(toGasSource(input), "function f() {\n  return 1;\n}");
});

test("export const / export class も剥がれ、中身の行は触らない", () => {
  const input =
    'export const A = 1;\nexport class B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}\n';
  assert.equal(
    toGasSource(input),
    "const A = 1;\nclass B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}",
  );
});

test("SOURCE_ORDER は 16 個で、先頭は gas_main.js、重複が無い", () => {
  assert.equal(SOURCE_ORDER.length, 16);
  assert.equal(SOURCE_ORDER[0], "gas_main.js");
  assert.deepEqual(SOURCE_ORDER.slice().sort(), Array.from(new Set(SOURCE_ORDER)).sort());
});

test("マニフェストは Asia/Tokyo の V8 で、ウェブアプリとして公開する", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
  assert.deepEqual(MANIFEST.webapp, { access: "ANYONE_ANONYMOUS", executeAs: "USER_DEPLOYING" });
  assert.deepEqual(MANIFEST.oauthScopes, [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/script.send_mail",
    "https://www.googleapis.com/auth/script.container.ui",
    "https://www.googleapis.com/auth/userinfo.email",
  ]);
});

test("求める許可は、実際に使うものだけ", () => {
  const code = buildSource(root);
  // メニューと確認の画面を出すのに要る
  assert.ok(code.includes("SpreadsheetApp.getUi()"), "getUi を使っていないのに container.ui を求めている");
  assert.ok(MANIFEST.oauthScopes.indexOf("https://www.googleapis.com/auth/script.container.ui") >= 0);
  // ScriptApp はどこでも使っていないので、script.scriptapp は求めない
  assert.equal(code.includes("ScriptApp"), false, "ScriptApp を使うなら script.scriptapp を戻すこと");
  assert.equal(MANIFEST.oauthScopes.indexOf("https://www.googleapis.com/auth/script.scriptapp"), -1);
});

test("つないだ結果に import / export は残らない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(buildSource(root)), false);
});

test("入口の 7 つが入っている", () => {
  const code = buildSource(root);
  for (const name of [
    "function doPost(",
    "function doGet(",
    "function onOpen()",
    "function sendTestNotification()",
    "function receiveSample()",
    "function checkConfig()",
    "function initializeSheets()",
  ]) {
    assert.ok(code.includes(name), name + " が無い");
  }
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = buildSource(root);
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("SOURCE_ORDER に src の取りこぼしが無い", () => {
  const files = readdirSync(join(root, "src"))
    .filter((name) => name.endsWith(".js"))
    .sort();
  assert.deepEqual(SOURCE_ORDER.slice().sort(), files);
});

test("ParseError はつないだあとも 1 つだけ（instanceof の突き合わせが効く）", () => {
  const code = buildSource(root);
  assert.equal((code.match(/class\s+ParseError\b/g) || []).length, 1);
  assert.equal((code.match(/class\s+ConfigError\b/g) || []).length, 1);
});

// ===== つないだ 1 本を、GAS の偽物を並べた入れ物の中で実際に動かす =====
// GAS に触る src/gas_*.js は単体テストしていないので、入口の道筋だけはここで通す。

/**
 * シート 1 枚。getDataRange で読んだ回数も控える（受付シートを何度も読んでいないかを見るため）。
 * 書き込まれた行は Array.from でこちら側の配列に写し替える（vm の中の配列のままだと比べられない）。
 * getRange(行, 列) は、その位置から書く（初期化が設定の行を最終行の下に、見出しを右端に足すため）。
 * denyWrite なら書き込みで権限の例外を投げる。
 */
function fakeSheet(values, options) {
  const opts = options || {};
  const rows = values.map((row) => Array.from(row));
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  const denied = (c) => {
    if (opts.denyWrite === "protected") {
      throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit.");
    }
    if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
    if (opts.denyHeaderWrite && c > 1) throw new Error("You do not have permission to call SpreadsheetApp.Range.setValues.");
  };
  const sheet = {
    reads: 0,
    rows: rows,
    frozen: 0,
    getLastRow: () => rows.length,
    getLastColumn: () => width(),
    getMaxColumns: () => 26,
    insertColumnsAfter: () => {},
    setFrozenRows: (n) => {
      sheet.frozen = n;
    },
    getDataRange: () => {
      sheet.reads += 1;
      return { getValues: () => rows.map((row) => row.slice()) };
    },
    getRange: (r, c) => ({
      setValues: (written) => {
        denied(c);
        for (let i = 0; i < written.length; i += 1) {
          while (rows.length < r + i) rows.push([]);
          const line = rows[r - 1 + i];
          for (let j = 0; j < written[i].length; j += 1) {
            while (line.length < c - 1 + j) line.push("");
            line[c - 1 + j] = written[i][j];
          }
        }
      },
    }),
    appendRow: (row) => {
      denied();
      rows.push(Array.from(row));
    },
  };
  return sheet;
}

function settingsRows(extra) {
  const base = [
    ["項目", "値"],
    ["通知先", "slack"],
    ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
    ["自動返信", "FALSE"],
  ];
  return extra ? base.concat(extra) : base;
}

const SLOT_ROWS = [
  ["日付", "時間帯", "定員"],
  ["2026-09-14", "10:00", 2],
];

/** つないだ 1 本を偽の GAS の上で 1 回走らせ、入口と、触った跡を返す */
function runBundle(sheets, options) {
  const opts = options || {};
  const trace = { created: [], notified: [], mailed: [], logs: [], alerts: [], menu: [] };
  const props = {};
  const cache = {};
  const book = {
    getSpreadsheetTimeZone: () => "Asia/Tokyo",
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (opts.denyWrite === "protected") {
        throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit.");
      }
      if (opts.denyWrite) throw new Error("You do not have permission to call SpreadsheetApp.Spreadsheet.insertSheet.");
      trace.created.push(name);
      sheets[name] = fakeSheet([], opts);
      return sheets[name];
    },
  };
  const menu = {
    addItem: (label, handler) => {
      trace.menu.push(label + " → " + handler);
      return menu;
    },
    addSeparator: () => {
      trace.menu.push("──");
      return menu;
    },
    addToUi: () => {},
  };
  const sandbox = {
    SpreadsheetApp: {
      getActiveSpreadsheet: () => book,
      getUi: () => ({ alert: (text) => trace.alerts.push(String(text)), createMenu: () => menu }),
    },
    ContentService: {
      MimeType: { JSON: "application/json" },
      createTextOutput: (text) => ({
        setMimeType() {
          return this;
        },
        getContent: () => text,
      }),
    },
    LockService: {
      getScriptLock: () => ({
        waitLock: () => {
          if (opts.lockBusy) throw new Error("Lock timeout: waited too long to acquire a script lock.");
        },
        releaseLock: () => {},
      }),
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (props[key] === undefined ? null : props[key]),
        setProperty: (key, value) => {
          props[key] = value;
        },
      }),
    },
    CacheService: {
      getScriptCache: () => ({
        get: (key) => (cache[key] === undefined ? null : cache[key]),
        put: (key, value) => {
          cache[key] = value;
        },
      }),
    },
    UrlFetchApp: {
      fetch: (url, options) => {
        trace.notified.push({ url: url, payload: options.payload });
        return { getResponseCode: () => 200, getContentText: () => "ok" };
      },
    },
    MailApp: {
      getRemainingDailyQuota: () => 100,
      sendEmail: (options) => trace.mailed.push(options),
    },
    Utilities: {
      DigestAlgorithm: { MD5: "MD5" },
      Charset: { UTF_8: "UTF-8" },
      computeDigest: (algorithm, source) => Array.from(createHash("md5").update(String(source), "utf8").digest()),
    },
    Session: { getActiveUser: () => ({ getEmail: () => "owner@example.com" }) },
    Logger: { log: (text) => trace.logs.push(String(text)) },
  };
  const context = createContext(sandbox);
  runInContext(
    buildSource(root) +
      "\nglobalThis.__entry = { doPost: doPost, doGet: doGet, initializeSheets: initializeSheets, checkConfig: checkConfig, onOpen: onOpen };\n",
    context,
  );
  return { entry: sandbox.__entry, trace: trace, sheets: sheets, book: book };
}

function answerOf(output) {
  return JSON.parse(output.getContent());
}

test("つないだ 1 本は、偽の GAS の上で 1 件受け付けられる", () => {
  const intake = fakeSheet([["受付日時", "受付番号", "name", "email", "message", "送信元", "date", "slot"]]);
  const run = runBundle({ 設定: fakeSheet(settingsRows()), 受付: intake, 枠: fakeSheet(SLOT_ROWS) });
  const answer = answerOf(
    run.entry.doPost({
      postData: {
        type: "text/plain;charset=utf-8",
        contents: JSON.stringify({
          name: "見本 太郎",
          email: "taro@example.com",
          date: "2026-09-14",
          slot: "10:00",
          page: "https://example.com/contact",
        }),
      },
      parameter: {},
    }),
  );
  assert.equal(answer.ok, true);
  assert.match(answer.id, /^\d{8}-001$/);
  assert.deepEqual(intake.rows[0], ["受付日時", "受付番号", "name", "email", "message", "送信元", "date", "slot"]);
  assert.equal(intake.rows.length, 2);
  assert.equal(intake.rows[1][2], "見本 太郎");
  assert.equal(run.trace.notified.length, 1);
  // 受付シートを読むのは 1 回だけ（空きの数え上げと見出しの突き合わせで使い回す）
  assert.equal(intake.reads, 1);
});

test("送信の中身が読めないときは invalid を返し、エラー通知は出さない", () => {
  const run = runBundle({ 設定: fakeSheet(settingsRows()), 受付: fakeSheet([]) });
  // e ごと無いとき（エディタから素で呼んだとき）
  assert.deepEqual(answerOf(run.entry.doPost(undefined)), {
    ok: false,
    reason: "invalid",
    message: "送信の中身がありません。",
  });
  // 中身が空のとき
  assert.equal(answerOf(run.entry.doPost({ postData: { type: "text/plain", contents: "" }, parameter: {} })).reason, "invalid");
  // multipart/form-data で送られたとき（このキットは受けられない）
  const multipart = answerOf(
    run.entry.doPost({
      postData: { type: "multipart/form-data; boundary=x", contents: "--x\r\nContent-Disposition: form-data\r\n--x--" },
      parameter: {},
    }),
  );
  assert.equal(multipart.reason, "invalid");
  assert.equal(multipart.message, "送信の中身を読み取れませんでした（JSON として読めません）。");
  assert.deepEqual(run.trace.notified, []);
  assert.deepEqual(run.trace.mailed, []);
});

test("doGet は、受付シートが無くても作らない", () => {
  const run = runBundle({ 設定: fakeSheet(settingsRows()), 枠: fakeSheet(SLOT_ROWS) });
  const answer = answerOf(run.entry.doGet({ parameter: { date: "2026-09-14" } }));
  assert.deepEqual(answer, {
    ok: true,
    date: "2026-09-14",
    slots: [{ slot: "10:00", capacity: 2, used: 0, remaining: 2 }],
  });
  assert.deepEqual(run.trace.created, []);
  assert.equal(Object.prototype.hasOwnProperty.call(run.sheets, "受付"), false);
});

test("送られてきた数式は、受付シートにただの字として入る（シートは 1 件目で作られる）", () => {
  const run = runBundle({ 設定: fakeSheet(settingsRows([["枠シート名", ""]])) });
  const answer = answerOf(
    run.entry.doPost({
      postData: {
        type: "text/plain;charset=utf-8",
        contents: JSON.stringify({
          name: "=IMPORTDATA(\"https://spam.example/x.csv\")",
          email: "taro@example.com",
          "@SUM(A1)": "-",
        }),
      },
      parameter: {},
    }),
  );
  assert.equal(answer.ok, true);
  assert.deepEqual(run.trace.created, ["受付"]);
  const intake = run.sheets["受付"];
  assert.deepEqual(intake.rows[0], ["受付日時", "受付番号", "name", "email", "message", "送信元", "'@SUM(A1)"]);
  assert.deepEqual(intake.rows[1].slice(2), [
    "'=IMPORTDATA(\"https://spam.example/x.csv\")",
    "taro@example.com",
    "",
    "",
    "'-",
  ]);
});

// ===== 初期化と「設定を確かめる」 =====

/** 1.0 の見本 3 枚（URL はご自身のものに差し替えたもの）と、受付が 1 件入ったブック */
function sampleBook() {
  return {
    設定: fakeSheet(settingsRows([
      ["Discord Webhook URL", ""],
      ["LINE チャネルアクセストークン", ""],
      ["LINE 送信先 ID", ""],
      ["通知の文面", "【受付】{受付番号}\n{項目一覧}"],
      ["必須項目", "email"],
      ["項目の並び", "name,email,message"],
      ["メールの項目名", "email"],
      ["自動返信の件名", "お問い合わせを受け付けました（受付番号 {受付番号}）"],
      ["自動返信の本文", "お問い合わせいただきありがとうございます。"],
      ["差出人名", ""],
      ["返信先", ""],
      ["受付シート名", "受付"],
      ["枠シート名", "枠"],
      ["日付の項目名", "date"],
      ["時間帯の項目名", "slot"],
      ["ハニーポットの項目名", "homepage"],
      ["送信元の項目名", "page"],
    ])),
    受付: fakeSheet([
      ["受付日時", "受付番号", "name", "email", "message", "送信元"],
      ["2026-09-14 10:32:05", "20260914-001", "見本 太郎", "taro@example.com", "料金と納期を知りたいです。", "https://example.com/contact"],
    ]),
    枠: fakeSheet(SLOT_ROWS),
  };
}

test("initializeSheets: 空のブックに 設定・受付・枠 を作り、2 回目は「変更はありません」", () => {
  const run = runBundle({});
  run.entry.initializeSheets();
  assert.deepEqual(run.trace.created, ["設定", "受付", "枠"]);
  assert.ok(run.trace.alerts[0].includes("・シートを作りました: 設定、受付、枠"), run.trace.alerts[0]);
  assert.equal(run.sheets["設定"].rows.length, 21);
  assert.deepEqual(run.sheets["受付"].rows, [["受付日時", "受付番号", "name", "email", "message", "送信元"]]);
  assert.deepEqual(run.sheets["枠"].rows, [["日付", "時間帯", "定員"]]);
  assert.equal(run.sheets["枠"].frozen, 1);

  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[1].startsWith("変更はありません。"), run.trace.alerts[1]);
  assert.deepEqual(run.trace.created, ["設定", "受付", "枠"]);
});

test("checkConfig: 初期化しただけのブックでは、Slack Webhook URL が空だと出る", () => {
  const run = runBundle({});
  run.entry.initializeSheets();
  run.entry.checkConfig();
  const text = run.trace.alerts[1];
  assert.ok(text.startsWith("直すところがあります。"), text);
  assert.ok(text.includes("・「通知先」に slack がありますが、「Slack Webhook URL」が空です。設定シートのその行を埋めてください。"));
});

test("1.0 の見本のブックで初期化を押しても、受付の行の数と中身は変わらない。設定を確かめるは「問題ありません。」", () => {
  const sheets = sampleBook();
  const before = sheets["受付"].rows.map((row) => row.slice());
  const run = runBundle(sheets);
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].startsWith("変更はありません。"), run.trace.alerts[0]);
  assert.deepEqual(run.sheets["受付"].rows, before);
  assert.deepEqual(run.trace.created, []);

  run.entry.checkConfig();
  assert.equal(
    run.trace.alerts[1],
    [
      "問題ありません。",
      "",
      "通知先: slack",
      "受付シート: 「受付」（いま 1 件）",
      "予約枠: 「枠」シートの 1 枠（2026-09-14〜2026-09-14）",
      "必須項目: email",
      "項目の並び: name, email, message",
      "自動返信: 送らない",
      "公開のしかた: README の手順 3。スクリプトを直したときは「新バージョン」で公開し直してください",
    ].join("\n"),
  );
});

test("initializeSheets: 項目の並びが 1 つ増えた受付シートに、既存の見出し・データはそのまま、新しい見出しだけ最終列の右に足す", () => {
  const sheets = sampleBook();
  sheets["設定"] = fakeSheet(
    sheets["設定"].rows.map((row) => (row[0] === "項目の並び" ? [row[0], "name,email,message,phone"] : row)),
  );
  sheets["受付"] = fakeSheet(
    sheets["受付"].rows.concat([
      ["2026-09-14 11:03:12", "20260914-002", "見本 花子", "hanako@example.com", "資料を送ってください。", "https://example.com/contact"],
    ]),
  );
  const before = sheets["受付"].rows.map((row) => row.slice());
  const run = runBundle(sheets);
  run.entry.initializeSheets();
  const after = run.sheets["受付"].rows;
  // 新しい見出しは、それまでの最終列（getLastColumn()）のすぐ右に 1 列だけ足される
  assert.equal(after[0].length, before[0].length + 1);
  assert.equal(after[0][before[0].length], "phone");
  // 既存の見出し・データのセルは 1 つも変わらない（バイト同一）
  for (let i = 0; i < before.length; i += 1) {
    assert.deepEqual(after[i].slice(0, before[i].length), before[i]);
  }
  // 知らせにも足した見出しが出る
  assert.ok(run.trace.alerts[0].includes("・「受付」シートの見出しに足しました: phone"), run.trace.alerts[0]);
});

test("既にあるブックに枠シートが無ければ作らず、ご確認くださいで知らせる", () => {
  const sheets = sampleBook();
  delete sheets["枠"];
  const run = runBundle(sheets);
  run.entry.initializeSheets();
  assert.deepEqual(run.trace.created, []);
  assert.ok(run.trace.alerts[0].includes("ご確認ください:\n・設定「枠シート名」が「枠」ですが、「枠」シートがありません。"));
});

test("編集権限が無いときは、敬体の 1 文で知らせる", () => {
  const run = runBundle({}, { denyWrite: true });
  run.entry.initializeSheets();
  assert.equal(
    run.trace.alerts[0],
    "うまくいきませんでした。次の内容をご確認ください。\n\nシートの作成で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください",
  );
});

test("初期化の途中(見出しの追記)で失敗しても、そこまでにできたことを知らせる", () => {
  const intake = fakeSheet([["受付日時", "受付番号", "name"]], { denyHeaderWrite: true });
  const sheets = { 設定: fakeSheet(settingsRows()), 受付: intake, 枠: fakeSheet(SLOT_ROWS) };
  const run = runBundle(sheets, {});
  run.entry.initializeSheets();
  const text = run.trace.alerts[0];
  assert.ok(text.includes("「設定」に "), text);
  assert.ok(text.includes(" 行を足しました"), text);
  assert.ok(text.includes("そのあと 見出しの追記で止まりました: このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), text);
});

test("編集の保護レンジで止まったときも、権限の 1 文に言い換える", () => {
  const run = runBundle({}, { denyWrite: "protected" });
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].includes("このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください"), run.trace.alerts[0]);
});

test("初期化がロックを取れなかったときは、ほかの処理中の 1 文で知らせる", () => {
  const run = runBundle({}, { lockBusy: true });
  run.entry.initializeSheets();
  assert.equal(run.trace.alerts[0], "ほかの処理が動いています。少し待ってからもう一度お試しください。");
});

test("onOpen: 1 番目が初期化、2 番目が設定を確かめる", () => {
  const run = runBundle({});
  run.entry.onOpen();
  assert.deepEqual(run.trace.menu, [
    "初期化（足りないシート・見出し・設定を足す。データは消しません） → initializeSheets",
    "設定を確かめる → checkConfig",
    "──",
    "テスト送信 → sendTestNotification",
    "見本の受付を 1 件入れる → receiveSample",
  ]);
});
