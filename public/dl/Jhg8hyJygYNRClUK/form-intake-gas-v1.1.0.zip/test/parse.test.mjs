import { test } from "node:test";
import assert from "node:assert/strict";
import { ParseError, parseBody } from "../src/parse.js";

function jsonEvent(type, body) {
  return { postData: { type: type, contents: typeof body === "string" ? body : JSON.stringify(body) }, parameter: {} };
}

test("application/json で送られた JSON を読む", () => {
  const parsed = parseBody(jsonEvent("application/json", { name: "見本 太郎", email: "taro@example.com" }));
  assert.deepEqual(parsed.fields, { name: "見本 太郎", email: "taro@example.com" });
  assert.deepEqual(parsed.order, ["name", "email"]);
});

test("text/plain の中身が JSON でも読む（プリフライトを避ける送り方）", () => {
  const parsed = parseBody(jsonEvent("text/plain;charset=utf-8", { message: "こんにちは" }));
  assert.deepEqual(parsed.fields, { message: "こんにちは" });
});

test("application/x-www-form-urlencoded を読む", () => {
  const parsed = parseBody({
    postData: { type: "application/x-www-form-urlencoded", contents: "name=%E8%A6%8B%E6%9C%AC&message=a+b&empty=" },
    parameter: {},
  });
  assert.deepEqual(parsed.fields, { name: "見本", message: "a b", empty: "" });
  assert.deepEqual(parsed.order, ["name", "message", "empty"]);
});

test("素の <form method=\"post\"> は e.parameter から読む", () => {
  const parsed = parseBody({ parameter: { name: "見本 太郎", message: "ご用件" } });
  assert.deepEqual(parsed.fields, { name: "見本 太郎", message: "ご用件" });
  assert.deepEqual(parsed.order, ["name", "message"]);
});

test("壊れた JSON は ParseError", () => {
  assert.throws(() => parseBody(jsonEvent("application/json", "{ name: ")), ParseError);
  assert.throws(() => parseBody(jsonEvent("text/plain", "{ name: ")), /JSON として読めません/);
});

test("項目の組でない JSON は ParseError", () => {
  assert.throws(() => parseBody(jsonEvent("application/json", [1, 2])), /項目名と値の組/);
  assert.throws(() => parseBody(jsonEvent("application/json", "\"ただの文字列\"")), /項目名と値の組/);
});

test("中身が無ければ ParseError", () => {
  assert.throws(() => parseBody(undefined), /送信の中身がありません/);
  assert.throws(() => parseBody({}), /送信の中身がありません/);
  assert.throws(() => parseBody({ postData: { type: "application/json", contents: "" }, parameter: {} }), /送信の中身がありません/);
});

test("値は文字にそろえ、前後の空白を落とす", () => {
  const parsed = parseBody(
    jsonEvent("application/json", {
      name: "  見本 太郎  ",
      count: 3,
      agree: true,
      tags: ["a", "b"],
      nothing: null,
      "  ": "名前が空の項目は捨てる",
    }),
  );
  assert.deepEqual(parsed.fields, {
    name: "見本 太郎",
    count: "3",
    agree: "true",
    tags: "a, b",
    nothing: "",
  });
  assert.deepEqual(parsed.order, ["name", "count", "agree", "tags", "nothing"]);
});
