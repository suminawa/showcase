import { test } from "node:test";
import assert from "node:assert/strict";
import { CONFIG_KEYS, ConfigError, DEFAULT_CONFIG, DEFAULT_REPLY_BODY, parseConfig } from "../src/config.js";

const SLACK = "https://hooks.slack.com/services/T000/B000/xxxx";
const DISCORD = "https://discord.com/api/webhooks/000/xxxx";

function rows(extra) {
  const base = [
    ["項目", "値"],
    ["通知先", "slack"],
    ["Slack Webhook URL", SLACK],
  ];
  return extra ? base.concat(extra) : base;
}

test("Slack の URL だけあれば、残りは既定値", () => {
  const config = parseConfig(rows());
  assert.deepEqual(config.targets, ["slack"]);
  assert.equal(config.slackWebhookUrl, SLACK);
  assert.equal(config.discordWebhookUrl, "");
  assert.equal(config.notifyTemplate, "【受付】{受付番号}\n{項目一覧}");
  assert.deepEqual(config.requiredFields, ["email"]);
  assert.deepEqual(config.fieldOrder, ["name", "email", "message"]);
  assert.equal(config.emailField, "email");
  assert.equal(config.autoReply, true);
  assert.equal(config.replySubject, "お問い合わせを受け付けました（受付番号 {受付番号}）");
  assert.equal(config.replyBody, DEFAULT_REPLY_BODY);
  assert.equal(config.senderName, "");
  assert.equal(config.replyTo, "");
  assert.equal(config.intakeSheetName, "受付");
  assert.equal(config.slotSheetName, "枠");
  assert.equal(config.dateField, "date");
  assert.equal(config.slotField, "slot");
  assert.equal(config.honeypotField, "homepage");
  assert.equal(config.pageField, "page");
});

test("通知先は複数書ける。大文字と全角読点も読む", () => {
  const config = parseConfig([
    ["通知先", "Slack、discord"],
    ["Slack Webhook URL", SLACK],
    ["Discord Webhook URL", DISCORD],
  ]);
  assert.deepEqual(config.targets, ["slack", "discord"]);
});

test("通知先が空なら通知しない。行ごと無ければ既定の slack", () => {
  assert.deepEqual(parseConfig([["通知先", ""]]).targets, []);
  assert.deepEqual(parseConfig([["受付シート名", "受付"], ["Slack Webhook URL", SLACK]]).targets, ["slack"]);
});

test("通知先に書いた宛先の設定が無ければ、どの行を直せばよいか言う", () => {
  assert.throws(() => parseConfig([["通知先", "slack"]]), /「Slack Webhook URL」が空です/);
  assert.throws(() => parseConfig([["通知先", "discord"]]), /「Discord Webhook URL」が空です/);
  assert.throws(() => parseConfig([["通知先", "line"]]), /「LINE チャネルアクセストークン」が空です/);
  assert.throws(
    () => parseConfig([["通知先", "line"], ["LINE チャネルアクセストークン", "abcdef"]]),
    /「LINE 送信先 ID」が空です/,
  );
  assert.throws(() => parseConfig([["通知先", "line"]]), ConfigError);
  assert.throws(() => parseConfig([["通知先", "メール"]]), /slack \/ discord \/ line/);
});

test("Webhook URL は https:// で始まる。エラーの文に URL そのものは出さない", () => {
  assert.throws(() => parseConfig([["通知先", "slack"], ["Slack Webhook URL", "hooks.slack.com/x"]]), (error) => {
    assert.ok(error instanceof ConfigError);
    assert.equal(error.message, "「Slack Webhook URL」は https:// で始まる URL です。設定シートのその行を確かめてください。");
    assert.equal(error.message.indexOf("hooks.slack.com"), -1);
    return true;
  });
});

test("使わない宛先の行は、URL でなくても止めない", () => {
  // 通知先が slack だけなら、Discord の行はメモ書きのままでよい
  const config = parseConfig([
    ["通知先", "slack"],
    ["Slack Webhook URL", SLACK],
    ["Discord Webhook URL", "あとで設定する"],
  ]);
  assert.deepEqual(config.targets, ["slack"]);
  assert.equal(config.discordWebhookUrl, "あとで設定する");
  // 通知先に入れたとたん、確かめる
  assert.throws(
    () => parseConfig([["通知先", "discord"], ["Discord Webhook URL", "discord.com/api/webhooks/000/xxxx"]]),
    /「Discord Webhook URL」は https:\/\/ で始まる URL です/,
  );
});

test("自動返信はチェックボックスでも TRUE / FALSE の文字でも読める", () => {
  assert.equal(parseConfig(rows([["自動返信", false]])).autoReply, false);
  assert.equal(parseConfig(rows([["自動返信", "FALSE"]])).autoReply, false);
  assert.equal(parseConfig(rows([["自動返信", "いいえ"]])).autoReply, false);
  assert.equal(parseConfig(rows([["自動返信", true]])).autoReply, true);
  assert.equal(parseConfig(rows([["自動返信", "TRUE"]])).autoReply, true);
  assert.throws(() => parseConfig(rows([["自動返信", "たぶん"]])), /「自動返信」は TRUE か FALSE で書いてください/);
});

test("働きを止められる項目は、空にすると止まる", () => {
  const config = parseConfig(
    rows([
      ["必須項目", ""],
      ["項目の並び", ""],
      ["枠シート名", ""],
      ["日付の項目名", ""],
      ["時間帯の項目名", ""],
      ["ハニーポットの項目名", ""],
      ["送信元の項目名", ""],
    ]),
  );
  assert.deepEqual(config.requiredFields, []);
  assert.deepEqual(config.fieldOrder, []);
  assert.equal(config.slotSheetName, "");
  assert.equal(config.dateField, "");
  assert.equal(config.slotField, "");
  assert.equal(config.honeypotField, "");
  assert.equal(config.pageField, "");
});

test("それ以外の項目は、空にすると既定値に戻る", () => {
  const config = parseConfig(
    rows([
      ["通知の文面", ""],
      ["受付シート名", "   "],
      ["自動返信の本文", ""],
      ["メールの項目名", ""],
      ["自動返信の件名", ""],
      ["差出人名", ""],
      ["返信先", ""],
    ]),
  );
  assert.equal(config.notifyTemplate, DEFAULT_CONFIG.notifyTemplate);
  assert.equal(config.intakeSheetName, "受付");
  assert.equal(config.replyBody, DEFAULT_REPLY_BODY);
  assert.equal(config.emailField, DEFAULT_CONFIG.emailField);
  assert.equal(config.replySubject, DEFAULT_CONFIG.replySubject);
  // 差出人名と返信先は、もともと既定値が空なので空に戻る（働きを止められる 8 つには入らない）
  assert.equal(config.senderName, "");
  assert.equal(config.replyTo, "");
});

test("キーの半角括弧・余分な空白・大文字小文字は吸収し、知らない行は無視する", () => {
  const config = parseConfig([
    ["通知先", "slack"],
    ["slack webhook url", SLACK],
    ["メモ", "ここは自由に書いてよい"],
    [],
    [""],
    ["受付シート名", "問い合わせ"],
  ]);
  assert.equal(config.slackWebhookUrl, SLACK);
  assert.equal(config.intakeSheetName, "問い合わせ");
});

test("差出人名・返信先・文面は書き換えられる", () => {
  const config = parseConfig(
    rows([
      ["通知の文面", "【{送信元}】{受付番号}\n{email}"],
      ["自動返信の件名", "受け付けました（{受付番号}）"],
      ["自動返信の本文", "{受付番号}\n{項目一覧}"],
      ["差出人名", "はなまる商店"],
      ["返信先", "info@example.com"],
      ["必須項目", "name,email"],
      ["項目の並び", "name、email、message、date、slot"],
    ]),
  );
  assert.equal(config.notifyTemplate, "【{送信元}】{受付番号}\n{email}");
  assert.equal(config.replySubject, "受け付けました（{受付番号}）");
  assert.equal(config.replyBody, "{受付番号}\n{項目一覧}");
  assert.equal(config.senderName, "はなまる商店");
  assert.equal(config.replyTo, "info@example.com");
  assert.deepEqual(config.requiredFields, ["name", "email"]);
  assert.deepEqual(config.fieldOrder, ["name", "email", "message", "date", "slot"]);
});

test("CONFIG_KEYS は設定シートに並べる 20 個", () => {
  assert.deepEqual(CONFIG_KEYS, [
    "通知先",
    "Slack Webhook URL",
    "Discord Webhook URL",
    "LINE チャネルアクセストークン",
    "LINE 送信先 ID",
    "通知の文面",
    "必須項目",
    "項目の並び",
    "メールの項目名",
    "自動返信",
    "自動返信の件名",
    "自動返信の本文",
    "差出人名",
    "返信先",
    "受付シート名",
    "枠シート名",
    "日付の項目名",
    "時間帯の項目名",
    "ハニーポットの項目名",
    "送信元の項目名",
  ]);
});
