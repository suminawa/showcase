import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CONFIG_KEYS, DEFAULT_ROWS, configKeyOf } from "../src/config.js";
import { SETTINGS_TAB, checkNotes, findProblems, planInit, sheetNamesFor, summaryLines } from "../src/check.js";
import { initReport } from "../src/setup.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const REAL_URL = "https://hooks.slack.com/services/T000/B000/xxxx";

/** 見本 CSV を行と列に割る（"..." の中のカンマと改行は区切りにしない）。docs.test.mjs と同じ */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function sample(name) {
  return rowsOf(readFileSync(join(root, "samples", name), "utf8"));
}

/** 1.0 の見本 3 枚を読み込んだブック。withRealUrl なら Slack Webhook URL を見本の URL から差し替える */
function sampleBook(withRealUrl) {
  const settings = sample("settings-sample.csv").map((row) => (withRealUrl && row[0] === "Slack Webhook URL" ? [row[0], REAL_URL] : row));
  return { timeZone: "Asia/Tokyo", sheets: { 設定: settings, 受付: sample("intake-sample.csv"), 枠: sample("slots-sample.csv") } };
}

function withSetting(key, value) {
  const base = sampleBook(true);
  base.sheets.設定 = base.sheets.設定.map((row) => (row[0] === key ? [key, value] : row));
  return base;
}

/** plan を 2 次元配列に当てる（足すだけ）。GAS 側の applyInit_ と同じ置き方 */
function applyPlan(snapshot, plan) {
  const sheets = {};
  for (const name of Object.keys(snapshot.sheets)) sheets[name] = snapshot.sheets[name].map((row) => row.slice());
  if (plan.appendSettings.rows.length > 0) {
    sheets[plan.appendSettings.sheet] = sheets[plan.appendSettings.sheet].concat(plan.appendSettings.rows.map((row) => row.slice()));
  }
  for (const made of plan.createSheets) sheets[made.name] = made.rows.map((row) => row.slice());
  for (const entry of plan.appendHeaders) {
    const rows = sheets[entry.sheet];
    const width = Math.max(...rows.map((row) => row.length));
    rows[0] = rows[0].concat(new Array(width - rows[0].length).fill("")).concat(entry.names);
  }
  return Object.assign({}, snapshot, { sheets: sheets });
}

function isEmptyPlan(plan) {
  return plan.createSheets.length === 0 && plan.appendHeaders.length === 0 && plan.appendSettings.rows.length === 0;
}

test("DEFAULT_ROWS は CONFIG_KEYS の順の 20 行で、空なのは URL・トークン・差出人名・返信先だけ", () => {
  assert.deepEqual(DEFAULT_ROWS.map((row) => row[0]), CONFIG_KEYS);
  assert.deepEqual(DEFAULT_ROWS.filter((row) => row[1] === "").map((row) => row[0]), [
    "Slack Webhook URL",
    "Discord Webhook URL",
    "LINE チャネルアクセストークン",
    "LINE 送信先 ID",
    "差出人名",
    "返信先",
  ]);
  // 空で書くと働きを止める 8 つは、既定値が入る
  for (const key of ["通知先", "必須項目", "項目の並び", "枠シート名", "日付の項目名", "時間帯の項目名", "ハニーポットの項目名", "送信元の項目名"]) {
    assert.notEqual(DEFAULT_ROWS.find((row) => row[0] === key)[1], "", key);
  }
  assert.equal(configKeyOf("slackwebhookurl"), configKeyOf("Slack Webhook URL"));
});

test("planInit: 空のブック → 設定・受付・枠を作り、2 回目は足すものが無い", () => {
  const empty = { timeZone: "Asia/Tokyo", sheets: {} };
  const plan = planInit(empty);
  assert.deepEqual(plan.createSheets.map((sheet) => sheet.name), ["設定", "受付", "枠"]);
  assert.deepEqual(plan.createSheets[0].rows, [["項目", "値"]].concat(DEFAULT_ROWS));
  assert.deepEqual(plan.createSheets[1].rows, [sample("intake-sample.csv")[0]], "見本の受付シートの見出しと同じ");
  assert.deepEqual(plan.createSheets[2].rows, [["日付", "時間帯", "定員"]]);
  assert.equal(plan.nextStep, "次は「設定」シートに通知先の URL かトークンを書き、「設定を確かめる」を実行してください。そのあと README の手順 3 で、ウェブアプリとして公開します。");
  assert.equal(isEmptyPlan(planInit(applyPlan(empty, plan))), true);
});

test("planInit: 1.0 の見本のブック → 足すものが無い", () => {
  const plan = planInit(sampleBook(false));
  assert.equal(isEmptyPlan(plan), true);
  assert.deepEqual(plan.notes, []);
  assert.equal(initReport(plan, plan.nextStep), "変更はありません。シート・見出し・設定の行はそろっています。\n\n次は「設定を確かめる」を実行してください。");
});

test("planInit: 「項目の並び」に phone を足してから押すと、受付シートの右端に phone だけを足す", () => {
  const plan = planInit(withSetting("項目の並び", "name,email,message,phone"));
  assert.equal(
    initReport(plan, plan.nextStep),
    "初期化しました。足したものは次のとおりです（すでにあったデータは変えていません）。\n\n・「受付」シートの見出しに足しました: phone\n\n次は「設定を確かめる」を実行してください。",
  );
});

test("planInit: 設定の行を 3 つと見出しを 1 つ消したブック → その 4 つだけを既定値で足し、2 回目は空", () => {
  const removed = ["必須項目", "枠シート名", "送信元の項目名"];
  const base = sampleBook(true);
  base.sheets.設定 = base.sheets.設定.filter((row) => removed.indexOf(row[0]) < 0);
  base.sheets.受付 = [["受付日時", "受付番号", "name", "email", "送信元"], ["2026-09-14 10:32:05", "20260914-001", "見本 太郎", "taro@example.com", "https://example.com/contact"]];
  const plan = planInit(base);
  assert.deepEqual(plan.createSheets, []);
  assert.deepEqual(plan.appendSettings.rows, [["必須項目", "email"], ["枠シート名", "枠"], ["送信元の項目名", "page"]]);
  assert.deepEqual(plan.appendHeaders, [{ sheet: "受付", names: ["message"] }]);
  const applied = applyPlan(base, plan);
  assert.deepEqual(applied.sheets.受付[1], base.sheets.受付[1], "受付の行は変えない");
  assert.equal(isEmptyPlan(planInit(applied)), true);
});

test("planInit: 消された 受付日時・受付番号・送信元 は足し直さず、ご確認くださいに出す", () => {
  const base = sampleBook(true);
  base.sheets.受付 = [["受付日時", "name", "email", "message", "送信元"]];
  const plan = planInit(base);
  assert.deepEqual(plan.appendHeaders, []);
  assert.deepEqual(plan.notes, ["「受付」シートに「受付番号」の列がありません（消した列は足し直しません）。受付番号を残したいときは、1 行目の右端に「受付番号」と書いてください。"]);
});

test("planInit: 設定シートがあるブックでは、枠シートを作らない（空の枠シートにも書かない）", () => {
  const base = sampleBook(true);
  delete base.sheets.枠;
  const plan = planInit(base);
  assert.deepEqual(plan.createSheets, []);
  assert.deepEqual(plan.notes, [
    "設定「枠シート名」が「枠」ですが、「枠」シートがありません。いまは予約枠を使わずに受け付けています（定員は効いていません）。使うなら「枠」シートを作り 1 行目に 日付・時間帯・定員 と書き、使わないなら設定「枠シート名」の値を空にしてください。",
  ]);
  base.sheets.枠 = [];
  assert.deepEqual(planInit(base).createSheets, []);
  assert.ok(planInit(base).notes[0].includes("「枠」シートが空です"));
  // 予約枠を使わない設定なら何も言わない
  const off = withSetting("枠シート名", "");
  delete off.sheets.枠;
  assert.deepEqual(planInit(off).notes, []);
  assert.deepEqual(sheetNamesFor(off.sheets.設定), ["受付"]);
  assert.deepEqual(sheetNamesFor(undefined), ["受付", "枠"]);
});

test("planInit: 枠シートの見出しの不足は右端に足し、タイムゾーンは変えずに案内する", () => {
  const base = sampleBook(true);
  base.timeZone = "America/New_York";
  base.sheets.枠 = [["日付", "時間帯"], ["2026-09-14", "10:00"]];
  const plan = planInit(base);
  assert.deepEqual(plan.appendHeaders, [{ sheet: "枠", names: ["定員"] }]);
  assert.deepEqual(plan.notes, ["スプレッドシートのタイムゾーンが America/New_York です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと受付日時と予約の日付が 1 日ずれます）。"]);
});

test("findProblems: 見本（URL をご自身のものに差し替えたもの）→ 0 件。見本の URL のままなら 1 件", () => {
  assert.deepEqual(findProblems(sampleBook(true)), []);
  assert.deepEqual(findProblems(sampleBook(false)), ["「設定」シートの「Slack Webhook URL」が見本の URL のままです。README の手順 2 で作ったご自身の URL に貼り替えてください。"]);
});

test("findProblems: 表の各行について、その文が 1 回だけ出る", () => {
  const noSlot = sampleBook(true);
  delete noSlot.sheets.枠;
  const badHeader = sampleBook(true);
  badHeader.sheets.枠 = [["日付", "時間帯"]];
  const badRows = sampleBook(true);
  badRows.sheets.枠 = [["日付", "時間帯", "定員"], ["2026-09-14", "10:00", 2], ["", "", ""], ["9月14日", "13:00", 2], ["2026-09-15", "10:00", ""], ["2026-09-15", "13:00", "二"]];
  const lineHalf = withSetting("通知先", "line");
  lineHalf.sheets.設定 = lineHalf.sheets.設定.map((row) => (row[0] === "LINE 送信先 ID" ? [row[0], "U0123"] : row));
  const cases = [
    [Object.assign(sampleBook(true), { timeZone: "Asia/Seoul" }), "スプレッドシートのタイムゾーンが Asia/Seoul です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと受付日時と予約の日付が 1 日ずれます）。"],
    [{ timeZone: "Asia/Tokyo", sheets: {} }, "「設定」シートがありません。メニュー「フォーム受付」→「初期化」を実行してください。"],
    [withSetting("通知先", "slack, メール"), "「設定」シートの「通知先」に書けるのは slack / discord / line です（いまは「メール」）。"],
    [withSetting("通知先", "slack,discord"), "「通知先」に discord がありますが、「Discord Webhook URL」が空です。設定シートのその行を埋めてください。"],
    [withSetting("Slack Webhook URL", "hooks.slack.com/services/T/B/x"), "「設定」シートの「Slack Webhook URL」は https:// で始まる URL です。前後に余分な字が入っていないかも確かめてください。"],
    [withSetting("Slack Webhook URL", "https://discord.com/api/webhooks/1/abc"), "「Slack Webhook URL」は Discord の URL です。Discord に送るなら「Discord Webhook URL」の行に貼り、「Slack Webhook URL」には Slack で作った URL を貼ってください。"],
    [lineHalf, "「LINE 送信先 ID」が書いてありますが、「LINE チャネルアクセストークン」が空です。"],
    [withSetting("自動返信", "送る"), "「設定」シートの「自動返信」は TRUE か FALSE にしてください（いまは「送る」）。"],
    [withSetting("必須項目", "email, homepage"), "「必須項目」に、迷惑投稿よけの見えない欄 homepage が入っています。この欄は人が入力しないので、すべての送信を受け付けなくなります。「必須項目」から外してください。"],
    [withSetting("項目の並び", "name,email,受付番号"), "「項目の並び」に「受付番号」があります。受付日時・受付番号・送信元はこのキットが使う見出しなので、フォームの入力欄には別の名前を付けてください。"],
    [noSlot, "設定「枠シート名」が「枠」ですが、「枠」シートがありません。いまは予約枠を使わずに受け付けています（定員は効いていません）。使うなら「枠」シートを作り 1 行目に 日付・時間帯・定員 と書き、使わないなら設定「枠シート名」の値を空にしてください。"],
    [badHeader, "「枠」シートの 1 行目に「定員」の列がありません。「初期化」を実行すると右端に足します。"],
    [badRows, "「枠」シートの 4 行目の日付を読めません。2026-09-14 の形で入れ直してください。"],
    [badRows, "「枠」シートの 5 行目は、日付・時間帯・定員のどれかが空のため使われていません。3 つとも書いてください。"],
    [badRows, "「枠」シートの 6 行目の定員は 0 以上の数にしてください（いまは「二」）。"],
    [withSetting("時間帯の項目名", ""), "予約枠を使うときは「日付の項目名」と「時間帯の項目名」を両方書いてください（いまは「時間帯の項目名」が空です）。"],
  ];
  for (const [snapshot, message] of cases) {
    const found = findProblems(snapshot);
    assert.equal(found.filter((line) => line === message).length, 1, message + "\n" + found.join("\n"));
  }
  assert.equal(findProblems(badRows).length, 3, "空の行と読める行は数えない");
});

test("findProblems: URL とトークンの値は文に出さない", () => {
  const base = withSetting("通知先", "slack,line");
  base.sheets.設定 = base.sheets.設定.map((row) => {
    if (row[0] === "Slack Webhook URL") return [row[0], "http://secret.example/hook"];
    if (row[0] === "LINE チャネルアクセストークン") return [row[0], "secret-token"];
    return row;
  });
  const text = findProblems(base).join("\n");
  assert.equal(text.includes("secret"), false);
  assert.ok(text.includes("「LINE チャネルアクセストークン」が書いてありますが、「LINE 送信先 ID」が空です。"));
});

test("checkNotes: 設定の行が無い項目・メールの項目名が必須でない・受付シートがまだ無い", () => {
  const base = withSetting("必須項目", "name");
  base.sheets.設定 = base.sheets.設定.filter((row) => row[0] !== "差出人名" && row[0] !== "返信先");
  delete base.sheets.受付;
  assert.deepEqual(checkNotes(base), [
    "「設定」シートに「差出人名」「返信先」の行がありません。行が無い項目は既定値で動きます。「初期化」を実行すると、既定値の行を足します。",
    "「メールの項目名」の email が「必須項目」に入っていないため、メールアドレスの無い送信には自動返信を送りません。",
    "「受付」シートはまだありません。1 件目の受付で作ります（いま作るなら「初期化」）。",
  ]);
  assert.deepEqual(checkNotes(sampleBook(true)), []);
});

test("summaryLines: 見本のブックの 7 行（1.0 の checkConfig の行を引き継ぐ）", () => {
  assert.deepEqual(summaryLines(sampleBook(true), { quota: 98 }), [
    "通知先: slack",
    "受付シート: 「受付」（いま 0 件）",
    "予約枠: 「枠」シートの 5 枠（2026-09-14〜2026-09-15）",
    "必須項目: email",
    "項目の並び: name, email, message",
    "自動返信: 送る（宛先は「email」の値）。今日あと送れるメール: 98 通",
    "公開のしかた: README の手順 3。スクリプトを直したときは「新バージョン」で公開し直してください",
  ]);
  const off = withSetting("枠シート名", "");
  off.sheets.設定 = off.sheets.設定.map((row) => (row[0] === "自動返信" ? [row[0], "FALSE"] : row));
  const lines = summaryLines(off, { quota: 0 });
  assert.equal(lines[2], "予約枠: 使っていません（設定「枠シート名」が空です）");
  assert.equal(lines[5], "自動返信: 送らない");
  assert.equal(SETTINGS_TAB, "設定");
});
