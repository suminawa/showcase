import { test } from "node:test";
import assert from "node:assert/strict";
import { compactDate, formatStamp, toDateKey } from "../src/dates.js";

test("セルの日付も文字の日付も YYYY-MM-DD にする", () => {
  // 日付セルは UTC の 0 時で来る。+9 時間ずらしてから年月日を取り出す
  assert.equal(toDateKey(new Date("2026-09-14T00:00:00Z")), "2026-09-14");
  assert.equal(toDateKey(new Date("2026-09-13T15:00:00Z")), "2026-09-14");
  assert.equal(toDateKey("2026-09-14"), "2026-09-14");
  assert.equal(toDateKey("2026/9/14"), "2026-09-14");
  assert.equal(toDateKey("2026年9月14日"), "2026-09-14");
  assert.equal(toDateKey(" 2026-09-14 "), "2026-09-14");
});

test("読めない値は null", () => {
  assert.equal(toDateKey(""), null);
  assert.equal(toDateKey(null), null);
  assert.equal(toDateKey(undefined), null);
  assert.equal(toDateKey("来週"), null);
  assert.equal(toDateKey("2026-02-30"), null);
  assert.equal(toDateKey("2026-13-01"), null);
  assert.equal(toDateKey(new Date("こわれている")), null);
});

test("受付日時は Asia/Tokyo の YYYY-MM-DD HH:MM:SS", () => {
  assert.equal(formatStamp(new Date("2026-09-14T01:32:05Z")), "2026-09-14 10:32:05");
  assert.equal(formatStamp(new Date("2026-09-13T15:00:00Z")), "2026-09-14 00:00:00");
  assert.equal(formatStamp(new Date("2026-09-14T14:59:59Z")), "2026-09-14 23:59:59");
  assert.throws(() => formatStamp("2026-09-14"), /日時を読めません/);
});

test("受付番号の前半は YYYYMMDD", () => {
  assert.equal(compactDate("2026-09-14"), "20260914");
  assert.equal(compactDate("2026-01-01"), "20260101");
});
