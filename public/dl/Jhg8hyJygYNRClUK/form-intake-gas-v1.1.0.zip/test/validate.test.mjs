import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_CONFIG } from "../src/config.js";
import { MAX_FIELD_COUNT, MAX_FIELD_LENGTH, stripInternal, validateSubmission } from "../src/validate.js";

function parsed(fields) {
  return { fields: fields, order: Object.keys(fields) };
}

const CONFIG = DEFAULT_CONFIG;

test("必須がそろっていれば ok", () => {
  const result = validateSubmission(parsed({ name: "見本 太郎", email: "taro@example.com" }), CONFIG);
  assert.deepEqual(result, { ok: true, reason: "", message: "" });
});

test("必須が足りなければ、足りない項目を全部言う", () => {
  const config = Object.assign({}, CONFIG, { requiredFields: ["name", "email"] });
  const result = validateSubmission(parsed({ name: "  ", email: "" }), config);
  assert.equal(result.ok, false);
  assert.equal(result.reason, "invalid");
  assert.equal(result.message, "「name」「email」を入力してください。");
});

test("メールアドレスの形を見る", () => {
  assert.equal(validateSubmission(parsed({ email: "taro@example.com" }), CONFIG).ok, true);
  assert.equal(validateSubmission(parsed({ email: "taro+form@example.co.jp" }), CONFIG).ok, true);
  const result = validateSubmission(parsed({ email: "taro(at)example.com" }), CONFIG);
  assert.equal(result.reason, "invalid");
  assert.equal(result.message, "メールアドレスの形を確かめてください。");
  // 必須でなく空なら、形は見ない
  const optional = Object.assign({}, CONFIG, { requiredFields: [] });
  assert.equal(validateSubmission(parsed({ email: "" }), optional).ok, true);
});

test("1 項目は 2,000 字まで", () => {
  assert.equal(MAX_FIELD_LENGTH, 2000);
  const fields = { email: "taro@example.com", message: "あ".repeat(2001) };
  const result = validateSubmission(parsed(fields), CONFIG);
  assert.equal(result.reason, "invalid");
  assert.equal(result.message, "「message」が長すぎます（2,000 字までです）。");
  assert.equal(validateSubmission(parsed({ email: "taro@example.com", message: "あ".repeat(2000) }), CONFIG).ok, true);
});

test("字数は見た目どおりに数える。絵文字も 1 字", () => {
  const email = "taro@example.com";
  // 🙂 は JavaScript の length では 2 字になるが、ここでは 1 字として数える
  assert.equal("🙂".repeat(2000).length, 4000);
  assert.equal(validateSubmission(parsed({ email: email, message: "🙂".repeat(2000) }), CONFIG).ok, true);
  const over = validateSubmission(parsed({ email: email, message: "🙂".repeat(2001) }), CONFIG);
  assert.equal(over.reason, "invalid");
  assert.equal(over.message, "「message」が長すぎます（2,000 字までです）。");
});

test("1 回の送信は 30 項目まで", () => {
  assert.equal(MAX_FIELD_COUNT, 30);
  const fields = { email: "taro@example.com" };
  for (let i = 0; i < 30; i += 1) fields["f" + i] = "x";
  const result = validateSubmission(parsed(fields), CONFIG);
  assert.equal(result.reason, "invalid");
  assert.equal(result.message, "項目が多すぎます（30 個までです）。");
});

test("ハニーポットに字が入っていたら迷惑投稿", () => {
  const result = validateSubmission(parsed({ email: "bot@example.com", homepage: "https://spam.example" }), CONFIG);
  assert.deepEqual(result, { ok: false, reason: "spam", message: "" });
  // 空のまま送られてくるのがふつう
  assert.equal(validateSubmission(parsed({ email: "taro@example.com", homepage: "" }), CONFIG).ok, true);
  // ハニーポットを使わない設定では、ただの項目として扱う
  const off = Object.assign({}, CONFIG, { honeypotField: "" });
  assert.equal(validateSubmission(parsed({ email: "taro@example.com", homepage: "x" }), off).ok, true);
});

test("ハニーポットの項目は捨て、送信元の項目は分ける", () => {
  const result = stripInternal(
    parsed({ name: "見本 太郎", homepage: "", email: "taro@example.com", page: "https://example.com/contact" }),
    CONFIG,
  );
  assert.deepEqual(result.fields, { name: "見本 太郎", email: "taro@example.com" });
  assert.deepEqual(result.order, ["name", "email"]);
  assert.equal(result.source, "https://example.com/contact");

  const off = Object.assign({}, CONFIG, { honeypotField: "", pageField: "" });
  const kept = stripInternal(parsed({ homepage: "x", page: "y" }), off);
  assert.deepEqual(kept.order, ["homepage", "page"]);
  assert.equal(kept.source, "");
});
