import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_CONFIG } from "../src/config.js";
import {
  availabilityOf,
  checkAvailability,
  countReservations,
  normalizeSlot,
  parseSlots,
  slotKeyOf,
} from "../src/slots.js";

const SLOT_VALUES = [
  ["日付", "時間帯", "定員"],
  ["2026-09-14", "10:00", 2],
  ["2026/9/14", "13:00", "１"],
  [new Date("2026-09-15T00:00:00Z"), "10:00", 1],
  ["来週", "10:00", 1],
  ["2026-09-16", "", 1],
  ["2026-09-16", "10:00", "たくさん"],
];

const INTAKE_VALUES = [
  ["受付日時", "受付番号", "name", "date", "slot", "送信元"],
  ["2026-09-10 09:00:00", "20260910-001", "見本 太郎", "2026-09-14", "10:00", ""],
  ["2026-09-10 09:10:00", "20260910-002", "見本 花子", "2026-09-14", "10:00 ", ""],
  ["2026-09-10 09:20:00", "20260910-003", "見本 次郎", "2026/9/14", "13:00", ""],
  ["2026-09-10 09:30:00", "20260910-004", "見本 三郎", "", "", ""],
];

test("枠シートを読む。日付の揺れと全角の定員も読み、読めない行は飛ばす", () => {
  assert.deepEqual(parseSlots(SLOT_VALUES), [
    { dateKey: "2026-09-14", slot: "10:00", capacity: 2, rowNumber: 2 },
    { dateKey: "2026-09-14", slot: "13:00", capacity: 1, rowNumber: 3 },
    { dateKey: "2026-09-15", slot: "10:00", capacity: 1, rowNumber: 4 },
  ]);
});

test("定員が空の行は飛ばす。0 と書いた行は「受け付けない枠」として残す", () => {
  const values = [
    ["日付", "時間帯", "定員"],
    ["2026-09-14", "10:00", ""],
    ["2026-09-14", "13:00", 0],
  ];
  const slots = parseSlots(values);
  assert.deepEqual(slots, [{ dateKey: "2026-09-14", slot: "13:00", capacity: 0, rowNumber: 3 }]);
  // 定員が空の枠は「枠に無い日時」と同じ扱いになり、受け付けない
  assert.equal(checkAvailability(slots, {}, "2026-09-14", "10:00").reason, "full");
  assert.equal(checkAvailability(slots, {}, "2026-09-14", "13:00").reason, "full");
  // 残り数の一覧にも、定員が空の枠は出さない
  assert.deepEqual(availabilityOf(slots, {}, "2026-09-14"), [
    { slot: "13:00", capacity: 0, used: 0, remaining: 0 },
  ]);
});

test("見出しが足りない枠シートは、枠が無いものとして扱う", () => {
  assert.deepEqual(parseSlots([["日付", "時間帯"], ["2026-09-14", "10:00"]]), []);
  assert.deepEqual(parseSlots([]), []);
  assert.deepEqual(parseSlots(null), []);
});

test("受付シートから、日付 × 時間帯の受付数を数える", () => {
  const counts = countReservations(INTAKE_VALUES, DEFAULT_CONFIG);
  assert.equal(counts[slotKeyOf("2026-09-14", "10:00")], 2);
  assert.equal(counts[slotKeyOf("2026-09-14", "13:00")], 1);
  assert.equal(counts[slotKeyOf("2026-09-15", "10:00")], undefined);
});

test("時間帯の空白の差は吸収する", () => {
  assert.equal(normalizeSlot("10:00 "), "10:00");
  assert.equal(normalizeSlot(" 10:00　〜 11:00"), "10:00〜11:00");
  assert.equal(slotKeyOf("2026-09-14", "10:00 "), "2026-09-14|10:00");
});

test("空きがあれば受け付ける", () => {
  const slots = parseSlots(SLOT_VALUES);
  const counts = countReservations(INTAKE_VALUES, DEFAULT_CONFIG);
  assert.deepEqual(checkAvailability(slots, counts, "2026-09-15", "10:00"), { ok: true, reason: "", message: "" });
});

test("定員まで埋まっていたら満席", () => {
  const slots = parseSlots(SLOT_VALUES);
  const counts = countReservations(INTAKE_VALUES, DEFAULT_CONFIG);
  const full = checkAvailability(slots, counts, "2026-09-14", "10:00");
  assert.equal(full.ok, false);
  assert.equal(full.reason, "full");
  assert.equal(full.message, "選ばれた日時は、すでに受付を終えています。別の日時をお選びください。");
  assert.equal(checkAvailability(slots, counts, "2026/9/14", "13:00").reason, "full");
});

test("枠シートに無い日付・時間帯は受け付けない", () => {
  const slots = parseSlots(SLOT_VALUES);
  assert.equal(checkAvailability(slots, {}, "2026-09-20", "10:00").reason, "full");
  assert.equal(checkAvailability(slots, {}, "2026-09-14", "18:00").reason, "full");
});

test("日付も時間帯も空なら予約ではないので通す。片方だけなら invalid", () => {
  const slots = parseSlots(SLOT_VALUES);
  assert.equal(checkAvailability(slots, {}, "", "").ok, true);
  assert.equal(checkAvailability(slots, {}, undefined, undefined).ok, true);
  const half = checkAvailability(slots, {}, "2026-09-14", "");
  assert.equal(half.reason, "invalid");
  assert.equal(half.message, "日付と時間帯の両方をお選びください。");
  assert.equal(checkAvailability(slots, {}, "来週", "10:00").reason, "invalid");
});

test("その日の枠ごとの残り数を出す", () => {
  const slots = parseSlots(SLOT_VALUES);
  const counts = countReservations(INTAKE_VALUES, DEFAULT_CONFIG);
  assert.deepEqual(availabilityOf(slots, counts, "2026-09-14"), [
    { slot: "10:00", capacity: 2, used: 2, remaining: 0 },
    { slot: "13:00", capacity: 1, used: 1, remaining: 0 },
  ]);
  assert.deepEqual(availabilityOf(slots, counts, "2026-09-15"), [
    { slot: "10:00", capacity: 1, used: 0, remaining: 1 },
  ]);
  assert.deepEqual(availabilityOf(slots, counts, "2026-09-30"), []);
});
