import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CONFIG_KEYS, DEFAULT_CONFIG, DEFAULT_ROWS, parseConfig } from "../src/config.js";
import { parseBody } from "../src/parse.js";
import { stripInternal } from "../src/validate.js";
import { buildHeader, buildRow } from "../src/rows.js";
import { availabilityOf, countReservations, parseSlots } from "../src/slots.js";
import { buildNotificationText } from "../src/message.js";
import { buildReply } from "../src/reply.js";
import { CHECK_MENU_LABEL, INIT_MENU_LABEL } from "../src/setup.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 見本 CSV を行と列に割る。"..." の中のカンマと改行は区切りにしない */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += ch;
    }
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function read(name) {
  return readFileSync(join(root, name), "utf8");
}

/** README の設定表の 1 列目（項目名）を、書いてある順に取り出す */
function settingsTableKeys(readme) {
  const keys = [];
  const lines = readme.split("\n");
  let inside = false;
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (line.indexOf("| 項目 | 既定値 | 意味 |") === 0) {
      inside = true;
      continue;
    }
    if (!inside) continue;
    if (line.indexOf("|") !== 0) break;
    if (/^\|\s*-/.test(line)) continue;
    keys.push(line.split("|")[1].trim());
  }
  return keys;
}

/** form-sample.html の、README に載せている送信のコード */
function sampleScript(html) {
  const open = "// ===== ここから README と同じ =====";
  const close = "// ===== ここまで =====";
  return html.slice(html.indexOf(open) + open.length, html.indexOf(close)).trim();
}

const SAMPLE_RECEIPT = "20260914-001";
const SAMPLE_STAMP = "2026-09-14 10:32:05";
const SAMPLE_BODY = {
  name: "見本 太郎",
  email: "taro@example.com",
  message: "料金と納期を知りたいです。",
  page: "https://example.com/contact",
};

function sampleContext(config) {
  const parsed = parseBody({
    postData: { type: "text/plain;charset=utf-8", contents: JSON.stringify(SAMPLE_BODY) },
    parameter: {},
  });
  const clean = stripInternal(parsed, config);
  return {
    receipt: SAMPLE_RECEIPT,
    fields: clean.fields,
    order: clean.order,
    source: clean.source,
    quotaExhausted: false,
  };
}

test("README の設定表と CONFIG_KEYS と見本の設定シートは、同じ 20 項目が同じ順に並ぶ", () => {
  const csvKeys = rowsOf(read("samples/settings-sample.csv"))
    .slice(1)
    .map((row) => row[0]);
  assert.deepEqual(csvKeys, CONFIG_KEYS);
  assert.deepEqual(settingsTableKeys(read("README.ja.md")), CONFIG_KEYS);
});

test("見本の設定シートを読むと、Slack の URL 以外は既定値になる", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  assert.deepEqual(
    config,
    Object.assign({}, DEFAULT_CONFIG, {
      slackWebhookUrl: "https://hooks.slack.com/services/XXXXXXXXX/YYYYYYYYY/ZZZZZZZZZZZZ",
    }),
  );
});

test("見本の受付シートの見出しは、見本の設定から作られる見出しと同じ", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const header = rowsOf(read("samples/intake-sample.csv"))[0];
  assert.deepEqual(header, buildHeader(config, []));
  assert.deepEqual(header, ["受付日時", "受付番号", "name", "email", "message", "送信元"]);
});

test("見本の枠シートは枠として読め、残り数を出せる", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const slots = parseSlots(rowsOf(read("samples/slots-sample.csv")));
  assert.equal(slots.length, 5);
  assert.deepEqual(slots[0], { dateKey: "2026-09-14", slot: "10:00", capacity: 2, rowNumber: 2 });
  const counts = countReservations([], config);
  assert.deepEqual(availabilityOf(slots, counts, "2026-09-15"), [
    { slot: "10:00", capacity: 2, used: 0, remaining: 2 },
    { slot: "13:00", capacity: 2, used: 0, remaining: 2 },
  ]);
});

test("見本の 1 件から、README に載せた受付シートの行が出る", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const context = sampleContext(config);
  const built = buildRow(rowsOf(read("samples/intake-sample.csv"))[0], {
    stamp: SAMPLE_STAMP,
    receipt: SAMPLE_RECEIPT,
    fields: context.fields,
    order: context.order,
    source: context.source,
  });
  assert.deepEqual(built.added, []);
  assert.deepEqual(built.row, [
    SAMPLE_STAMP,
    SAMPLE_RECEIPT,
    "見本 太郎",
    "taro@example.com",
    "料金と納期を知りたいです。",
    "https://example.com/contact",
  ]);
  const readme = read("README.ja.md");
  assert.ok(readme.includes("| " + built.row.join(" | ") + " |"), "README の受付シートの行が食い違っている");
});

test("README に載せた通知と自動返信は、実際に出るものと同じ", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const context = sampleContext(config);
  const readme = read("README.ja.md");

  const notification = buildNotificationText(config, context);
  assert.equal(
    notification,
    [
      "【受付】20260914-001",
      "name: 見本 太郎",
      "email: taro@example.com",
      "message: 料金と納期を知りたいです。",
    ].join("\n"),
  );
  assert.ok(readme.includes(notification), "README の通知の例が食い違っている");

  const reply = buildReply(config, context);
  assert.ok(readme.includes("件名: " + reply.subject), "README の自動返信の件名が食い違っている");
  assert.ok(readme.includes(reply.body), "README の自動返信の本文が食い違っている");
});

test("見本のフォームの送り方は、README に載せたものと同じ", () => {
  const html = read("samples/form-sample.html");
  const script = sampleScript(html);
  assert.ok(script.includes('"Content-Type": "text/plain;charset=utf-8"'), "text/plain で送っていない");
  assert.ok(html.includes('name="homepage"'), "見えない欄が無い");
  assert.ok(read("README.ja.md").includes(script), "README の送信のコードが食い違っている");
});

test("README にメニューの 2 つの字がそのまま載り、「更新のお知らせ 1.1」の節が「よくあるつまずき」の前にある", () => {
  const readme = read("README.ja.md");
  assert.ok(readme.includes(INIT_MENU_LABEL));
  assert.ok(readme.includes("**" + CHECK_MENU_LABEL + "**"));
  const notice = readme.indexOf("## 更新のお知らせ 1.1");
  assert.ok(notice > 0 && notice < readme.indexOf("## よくあるつまずき"));
  // 1.1 の直し（通知の字）は doPost の中で効くので、ウェブアプリを「新バージョン」で公開し直さないと届かない
  const upgrade = readme.slice(notice, readme.indexOf("## よくあるつまずき"));
  assert.ok(upgrade.includes("4. デプロイ →「デプロイを管理」→ 鉛筆 → バージョンを「新バージョン」→ デプロイ、で公開し直します"), "上げ方に公開し直しの手順が無い");
  assert.ok(upgrade.includes("- Slack・Discord の通知: フォームに書かれた字や「通知の文面」に `<!channel>` や `@everyone` のような字が入っていても、全員や特定の人への呼び出しにならないようにしました"));
  assert.equal(upgrade.includes("公開し直しは要りません"), false, "公開し直しが要らないと書いてある");
  const templates = readme.slice(readme.indexOf("## 文面テンプレ"), readme.indexOf("## 予約枠"));
  assert.ok(templates.includes("「通知の文面」に `<!channel>` や `<@U…>`、`@everyone` と書いても、Slack・Discord で呼び出し（メンション）として働くことはありません。"));
  // 置き方は 5 つの手順。check.js の文は「README の手順 2」（通知先）と「README の手順 3」（公開）を指している
  for (const step of ["## 手順 1　", "## 手順 2　通知先", "## 手順 3　ウェブアプリとして公開する", "## 手順 4　フォームに URL を貼る", "## 手順 5　動作確認"]) {
    assert.ok(readme.includes(step), step);
  }
  assert.equal(readme.includes("## 手順 6"), false);
  assert.ok(readme.includes("枠シートが無いと、予約枠は使われず、定員は効きません。「設定を確かめる」でお知らせします。"));
  const main = read("src/gas_main.js");
  assert.ok(main.includes('.addItem("' + INIT_MENU_LABEL + '", "initializeSheets")'));
  assert.ok(main.includes('.addItem("' + CHECK_MENU_LABEL + '", "checkConfig")'));
});

test("版がそろっている（package.json・README の題・CHANGELOG の先頭）", () => {
  const version = JSON.parse(read("package.json")).version;
  assert.equal(version, "1.1.0");
  assert.ok(read("README.ja.md").startsWith("# フォーム受付 GAS キット v" + version + "\n"));
  assert.equal(read("CHANGELOG.md").match(/^## (\d+\.\d+\.\d+)/m)[1], version);
});

test("初期化で足す設定の行は、見本の設定シートと Slack Webhook URL 以外が同じ", () => {
  const csv = rowsOf(read("samples/settings-sample.csv")).slice(1);
  assert.deepEqual(
    DEFAULT_ROWS.filter((row) => row[0] !== "Slack Webhook URL"),
    csv.filter((row) => row[0] !== "Slack Webhook URL"),
  );
});

test("公開する文（src・samples・README・CHANGELOG・LICENSE）に「承ります」を使わない", () => {
  const files = readdirSync(join(root, "src"))
    .map((name) => "src/" + name)
    .concat(readdirSync(join(root, "samples")).map((name) => "samples/" + name), ["README.ja.md", "CHANGELOG.md", "LICENSE.md"]);
  for (const file of files) assert.equal(read(file).includes("承ります"), false, file);
});
