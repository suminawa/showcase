import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 純粋な処理。GAS のグローバルに触らず、Node でそのままテストできる */
export const PURE = [
  "dates.js",
  "parse.js",
  "config.js",
  "validate.js",
  "receipt.js",
  "rows.js",
  "slots.js",
  "message.js",
  "reply.js",
  "setup.js",
  "check.js",
];

/** GAS に触る接続。単体テストはしない */
export const GLUE = ["gas_store.js", "gas_sheets.js", "gas_notify.js", "gas_mail.js", "gas_main.js"];

const GAS_GLOBALS = [
  "SpreadsheetApp",
  "UrlFetchApp",
  "PropertiesService",
  "CacheService",
  "LockService",
  "MailApp",
  "ContentService",
  "ScriptApp",
  "Logger",
  "Utilities",
  "Session",
];

function sourceOf(name) {
  return readFileSync(join(root, "src", name), "utf8");
}

test("純粋な処理は GAS のグローバルに触らない", () => {
  for (const name of PURE) {
    if (!existsSync(join(root, "src", name))) continue;
    const source = sourceOf(name);
    for (const global of GAS_GLOBALS) {
      assert.equal(source.includes(global), false, name + " が " + global + " に触っている");
    }
  }
});

test("純粋な処理は GAS 側のファイルを読み込まない", () => {
  for (const name of PURE) {
    if (!existsSync(join(root, "src", name))) continue;
    assert.equal(/from\s+["']\.\/gas_/.test(sourceOf(name)), false, name + " が gas_ を読み込んでいる");
  }
});

test("src に置いてよいのは、純粋な処理か GAS 側かのどちらかだけ", () => {
  for (const name of readdirSync(join(root, "src")).filter((file) => file.endsWith(".js"))) {
    assert.ok(PURE.indexOf(name) >= 0 || GLUE.indexOf(name) >= 0, name + " が一覧に無い");
  }
});

test("src にあるのは純粋な処理と GAS 側の 2 種類だけ", () => {
  const files = readdirSync(join(root, "src"))
    .filter((name) => name.endsWith(".js"))
    .sort();
  assert.deepEqual(files, PURE.concat(GLUE).sort());
});

test("入口の 7 つが gas_main.js にある", () => {
  const source = sourceOf("gas_main.js");
  for (const name of ["doPost", "doGet", "onOpen", "sendTestNotification", "receiveSample", "checkConfig", "initializeSheets"]) {
    assert.ok(source.includes("export function " + name + "("), name + " が無い");
  }
});
