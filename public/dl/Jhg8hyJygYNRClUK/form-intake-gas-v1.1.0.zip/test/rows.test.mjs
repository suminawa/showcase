import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_CONFIG } from "../src/config.js";
import { buildHeader, buildRow, fieldNamesOf } from "../src/rows.js";

const ENTRY = {
  stamp: "2026-09-14 10:32:05",
  receipt: "20260914-001",
  fields: { name: "見本 太郎", email: "taro@example.com", message: "料金と納期を知りたいです。" },
  order: ["name", "email", "message"],
  source: "https://example.com/contact",
};

test("シートが空なら、項目の並びのとおりに見出しを作る", () => {
  assert.deepEqual(fieldNamesOf(DEFAULT_CONFIG, []), ["name", "email", "message"]);
  assert.deepEqual(buildHeader(DEFAULT_CONFIG, []), ["受付日時", "受付番号", "name", "email", "message", "送信元"]);
});

test("項目の並びが空なら、送られてきた順に並べる（送信元とハニーポットは列にしない）", () => {
  const config = Object.assign({}, DEFAULT_CONFIG, { fieldOrder: [] });
  assert.deepEqual(buildHeader(config, ["email", "name", "page", "homepage"]), [
    "受付日時",
    "受付番号",
    "email",
    "name",
    "送信元",
  ]);
});

test("既にある見出しの順に当てはめる（買い手が並べ替えていてもよい）", () => {
  const header = ["受付番号", "message", "受付日時", "email", "送信元", "name"];
  const built = buildRow(header, ENTRY);
  assert.deepEqual(built.header, header);
  assert.deepEqual(built.row, [
    "20260914-001",
    "料金と納期を知りたいです。",
    "2026-09-14 10:32:05",
    "taro@example.com",
    "https://example.com/contact",
    "見本 太郎",
  ]);
  assert.deepEqual(built.added, []);
});

test("見出しに無い項目は末尾に足す", () => {
  const header = ["受付日時", "受付番号", "name", "送信元"];
  const built = buildRow(header, ENTRY);
  assert.deepEqual(built.header, ["受付日時", "受付番号", "name", "送信元", "email", "message"]);
  assert.deepEqual(built.row, [
    "2026-09-14 10:32:05",
    "20260914-001",
    "見本 太郎",
    "https://example.com/contact",
    "taro@example.com",
    "料金と納期を知りたいです。",
  ]);
  assert.deepEqual(built.added, ["email", "message"]);
});

test("数式になる先頭文字には ' を付けて、ただの字として保存する", () => {
  const header = ["受付日時", "受付番号", "name", "memo", "tel", "送信元"];
  const built = buildRow(header, {
    stamp: "2026-09-14 10:32:05",
    receipt: "20260914-001",
    fields: {
      name: "見本 太郎",
      memo: "=IMPORTDATA(\"https://spam.example/x.csv\")",
      tel: "+1;@SUM(A1)",
      "=HYPERLINK(\"https://spam.example\",\"請求書\")": "-",
    },
    order: ["name", "memo", "tel", "=HYPERLINK(\"https://spam.example\",\"請求書\")"],
    source: "-1+1",
  });
  assert.deepEqual(built.header, [
    "受付日時",
    "受付番号",
    "name",
    "memo",
    "tel",
    "送信元",
    "'=HYPERLINK(\"https://spam.example\",\"請求書\")",
  ]);
  assert.deepEqual(built.row, [
    "2026-09-14 10:32:05",
    "20260914-001",
    "見本 太郎",
    "'=IMPORTDATA(\"https://spam.example/x.csv\")",
    "'+1;@SUM(A1)",
    "'-1+1",
    "'-",
  ]);
  // 足した見出しの控えは、突き合わせに使う元の字のまま
  assert.deepEqual(built.added, ['=HYPERLINK("https://spam.example","請求書")']);
});

test("ふつうの字は何も足さない。タブと復帰も数式よけの対象", () => {
  const header = ["受付日時", "受付番号", "plain", "tabbed", "cr", "送信元"];
  const built = buildRow(header, {
    stamp: "2026-09-14 10:32:05",
    receipt: "20260914-001",
    fields: { plain: "1 + 1 は 2 です", tabbed: "\t=1", cr: "\r=1" },
    order: ["plain", "tabbed", "cr"],
    source: "https://example.com/contact",
  });
  assert.deepEqual(built.header, header);
  assert.deepEqual(built.row.slice(2), ["1 + 1 は 2 です", "'\t=1", "'\r=1", "https://example.com/contact"]);
});

test("数式よけを通しても、予約枠の突き合わせに使う日付と時間帯は変わらない", () => {
  const header = ["受付日時", "受付番号", "date", "slot", "送信元"];
  const built = buildRow(header, {
    stamp: "2026-09-14 10:32:05",
    receipt: "20260914-001",
    fields: { date: "2026-09-14", slot: "10:00" },
    order: ["date", "slot"],
    source: "",
  });
  assert.deepEqual(built.row, ["2026-09-14 10:32:05", "20260914-001", "2026-09-14", "10:00", ""]);
});

test("見出しから消された固定の列は足し直さない。値の無い項目は空のまま", () => {
  const built = buildRow(["受付日時", "受付番号", "name", "email", "message", "tel"], ENTRY);
  assert.deepEqual(built.header, ["受付日時", "受付番号", "name", "email", "message", "tel"]);
  assert.deepEqual(built.row, [
    "2026-09-14 10:32:05",
    "20260914-001",
    "見本 太郎",
    "taro@example.com",
    "料金と納期を知りたいです。",
    "",
  ]);
  assert.deepEqual(built.added, []);
});
