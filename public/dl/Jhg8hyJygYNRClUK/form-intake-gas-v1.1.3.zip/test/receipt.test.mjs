import { test } from "node:test";
import assert from "node:assert/strict";
import { dedupeSourceOf, formatReceipt, laterReceipt, nextReceipt, parseReceipt } from "../src/receipt.js";

test("受付番号は YYYYMMDD-NNN", () => {
  assert.equal(formatReceipt("2026-09-14", 1), "20260914-001");
  assert.equal(formatReceipt("2026-09-14", 12), "20260914-012");
  assert.equal(formatReceipt("2026-09-14", 999), "20260914-999");
});

test("1000 件目からは桁が増える", () => {
  assert.equal(formatReceipt("2026-09-14", 1000), "20260914-1000");
});

test("受付番号を読み戻せる", () => {
  assert.deepEqual(parseReceipt("20260914-003"), { dateKey: "2026-09-14", sequence: 3 });
  assert.equal(parseReceipt(""), null);
  assert.equal(parseReceipt("こわれている"), null);
  assert.equal(parseReceipt(null), null);
});

test("同じ日なら 1 つ進む", () => {
  assert.equal(nextReceipt("20260914-003", "2026-09-14"), "20260914-004");
  assert.equal(nextReceipt("20260914-999", "2026-09-14"), "20260914-1000");
});

test("日が変われば 001 に戻り、前回が無くても壊れていても 001 から始まる", () => {
  assert.equal(nextReceipt("20260913-009", "2026-09-14"), "20260914-001");
  assert.equal(nextReceipt("", "2026-09-14"), "20260914-001");
  assert.equal(nextReceipt("こわれている", "2026-09-14"), "20260914-001");
});

test("二重送信の鍵のもとは、項目の順が違っても同じ字になる", () => {
  const a = dedupeSourceOf({ email: "taro@example.com", message: "やあ" }, ["email", "message"]);
  const b = dedupeSourceOf({ message: "やあ", email: "taro@example.com" }, ["message", "email"]);
  assert.equal(a, b);
  assert.equal(a, "email=taro@example.com\nmessage=やあ");
  // 1 字でも違えば別の送信
  assert.notEqual(a, dedupeSourceOf({ email: "taro@example.com", message: "やあ。" }, ["email", "message"]));
});

test("1.1.3 laterReceipt: 2 つのうち新しい方（日付、同じ日なら連番の大きい方）。読めない方は捨てる", () => {
  assert.equal(laterReceipt("20260914-003", "20260914-010"), "20260914-010");
  assert.equal(laterReceipt("20260915-001", "20260914-999"), "20260915-001");
  assert.equal(laterReceipt("", "20260914-002"), "20260914-002");
  assert.equal(laterReceipt("20260914-002", "見出し"), "20260914-002");
  assert.equal(laterReceipt("", ""), "");
  // 覚えた番号が消えても、シートの最後の番号の続きから振る
  assert.equal(nextReceipt(laterReceipt("", "20260914-007"), "2026-09-14"), "20260914-008");
});
