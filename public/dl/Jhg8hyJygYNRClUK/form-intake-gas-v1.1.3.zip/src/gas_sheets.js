/** スプレッドシートから設定・受付・枠を読み書きする。初期化では、足りないシート・見出し・設定の行だけを足す。 */
import { sheetNamesFor } from "./check.js";
import { ConfigError, SAVED_SECRET_MARK, parseConfig, secretsInSheet, withSecrets } from "./config.js";
import { initFailureText } from "./setup.js";
import { NOTIFY_HEADER } from "./rows.js";
import { readSecrets_, saveSecret_ } from "./gas_store.js";

const SETTINGS_SHEET = "設定";

/** 書き込みの権限が無いときに出す 1 文 */
const PERMISSION_TEXT = "このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください";

function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

export function readConfig_() {
  const book = book_();
  const timeZone = book.getSpreadsheetTimeZone();
  if (timeZone !== "Asia/Tokyo") {
    throw new ConfigError(
      "スプレッドシートのタイムゾーンが " +
        timeZone +
        " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。",
    );
  }
  const sheet = book.getSheetByName(SETTINGS_SHEET);
  if (!sheet) throw new ConfigError("「設定」シートがありません。メニュー「フォーム受付」→「初期化」を実行してください。");
  return parseConfig(withSecrets(sheet.getDataRange().getValues(), readSecrets_()));
}

/**
 * 設定が壊れていてもエラーだけは届くように、通知先の行だけを検証せずに読む。
 * 返り値は notifyAll_ に渡せる形。読めなければ null。
 */
export function readRawTargets_() {
  try {
    const sheet = book_().getSheetByName(SETTINGS_SHEET);
    if (!sheet) return null;
    const rows = withSecrets(sheet.getDataRange().getValues(), readSecrets_());
    const found = { targets: [], slackWebhookUrl: "", discordWebhookUrl: "", lineToken: "", lineTo: "", notifyMailTo: "" };
    const known = ["mail", "slack", "discord", "line"];
    let contact = "";
    let replyTo = "";
    for (let i = 0; i < rows.length; i += 1) {
      const key = String(rows[i][0]).replace(/\s+/g, "").toLowerCase();
      const value = String(rows[i][1] === null || rows[i][1] === undefined ? "" : rows[i][1]).trim();
      if (key === "通知先") {
        const parts = value.toLowerCase().split(/[,、]/);
        for (let j = 0; j < parts.length; j += 1) {
          const name = parts[j].trim();
          if (known.indexOf(name) >= 0 && found.targets.indexOf(name) < 0) found.targets.push(name);
        }
      }
      if (key === "slackwebhookurl") found.slackWebhookUrl = value;
      if (key === "discordwebhookurl") found.discordWebhookUrl = value;
      if (key === "lineチャネルアクセストークン") found.lineToken = value;
      if (key === "line送信先id") found.lineTo = value;
      if (key === "連絡先メール") contact = value;
      if (key === "返信先") replyTo = value;
    }
    found.notifyMailTo = contact !== "" ? contact : replyTo;
    if (found.notifyMailTo === "") found.targets = found.targets.filter((name) => name !== "mail");
    return found.targets.length === 0 ? null : found;
  } catch (error) {
    return null;
  }
}

/** 受付シート。無ければ作る */
export function intakeSheet_(sheetName) {
  const book = book_();
  const sheet = book.getSheetByName(sheetName);
  return sheet ? sheet : book.insertSheet(sheetName);
}

/**
 * 受付シートの全部の値。シートがまだ無いか、1 行も無ければ空の配列。
 * ここでは作らない（doGet で読んだだけのときに、空のシートが増えないようにする）。
 * シートを作るのは、1 件目を書き込む appendIntakeRow_ のとき。
 */
export function readIntakeValues_(sheetName) {
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getDataRange().getValues();
}

/**
 * 受付シートの見出しと最後の行だけ（[見出し, 最後の行]。行が無ければ [見出し]、シートが無いか空なら []）。
 * 予約枠を使わないときは全部の行を数えなくてよいので、受付が数千行あっても読む量を増やさない
 */
export function readIntakeEdge_(sheetName) {
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() === 0) return [];
  const width = sheet.getLastColumn();
  const header = sheet.getRange(1, 1, 1, width).getValues()[0];
  const lastRow = sheet.getLastRow();
  return lastRow === 1 ? [header] : [header, sheet.getRange(lastRow, 1, 1, width).getValues()[0]];
}

/** 枠シートの全部の値。シートが無い / 予約枠を使わない設定なら null */
export function readSlotValues_(sheetName) {
  if (sheetName === "") return null;
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() === 0) return null;
  return sheet.getDataRange().getValues();
}

/**
 * 末尾に 1 行足し、その行の番号を返す（ロックの中で呼ぶので、ほかの受付と行が入れ替わらない）。
 * シートが空のとき、または見出しを足したときだけ 1 行目を書き直す（既にある見出しは動かさない）。
 */
export function appendIntakeRow_(sheetName, header, row, writeHeader) {
  const sheet = intakeSheet_(sheetName);
  if (header.length > sheet.getMaxColumns()) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), header.length - sheet.getMaxColumns());
  }
  if (sheet.getLastRow() === 0 || writeHeader === true) {
    sheet.getRange(1, 1, 1, header.length).setValues([header]);
  }
  sheet.appendRow(row);
  return sheet.getLastRow();
}

/**
 * 受付シートの rowNumber 行目の「通知」の列に text を書く。
 * 列が無ければ（1.1.1 までのシートで初期化を押していないとき）、1 行目の右端に見出しを足してから書く
 */
export function markNotifyCell_(sheetName, rowNumber, text) {
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet) return;
  const width = sheet.getLastColumn();
  const header = width === 0 ? [] : sheet.getRange(1, 1, 1, width).getValues()[0];
  let at = -1;
  for (let i = 0; i < header.length; i += 1) if (String(header[i]).trim() === NOTIFY_HEADER) at = i;
  if (at < 0) {
    at = width;
    if (at + 1 > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), at + 1 - sheet.getMaxColumns());
    sheet.getRange(1, at + 1).setValue(NOTIFY_HEADER);
  }
  sheet.getRange(rowNumber, at + 1).setValue(text);
}

/** シートの値。1 行も無ければ [] */
function sheetValues_(sheet) {
  return sheet.getLastRow() === 0 ? [] : sheet.getDataRange().getValues();
}

/**
 * 初期化と「設定を確かめる」が読むもの。読むだけで、何も書かない（シートも作らない）。
 * sheets には「設定」「受付シート名」「枠シート名」のシートのうち、あるものだけを載せる。
 */
export function readSetupSnapshot_() {
  const book = book_();
  const sheets = {};
  const settings = book.getSheetByName(SETTINGS_SHEET);
  if (settings) sheets[SETTINGS_SHEET] = sheetValues_(settings);
  const names = sheetNamesFor(sheets[SETTINGS_SHEET]);
  for (let i = 0; i < names.length; i += 1) {
    const sheet = book.getSheetByName(names[i]);
    if (sheet) sheets[names[i]] = sheetValues_(sheet);
  }
  return { timeZone: book.getSpreadsheetTimeZone(), sheets: sheets, secrets: readSecrets_() };
}

/**
 * 「鍵を保存」: 設定シートに書いてある URL・トークンをスクリプト プロパティへ移し、セルには SAVED_SECRET_MARK を書く。
 * プロパティに書いてからセルを書き換える（途中で止まっても鍵を失わない）。返り値は移した鍵の名前
 */
export function moveSecretsToProperties_() {
  const sheet = book_().getSheetByName(SETTINGS_SHEET);
  if (!sheet) throw new ConfigError("「設定」シートがありません。メニュー「フォーム受付」→「初期化」を実行してください。");
  const found = secretsInSheet(sheetValues_(sheet));
  const moved = [];
  try {
    for (let i = 0; i < found.length; i += 1) {
      saveSecret_(found[i].key, found[i].value);
      sheet.getRange(found[i].row + 1, 2, 1, 1).setValues([[SAVED_SECRET_MARK]]);
      moved.push(found[i].key);
    }
  } catch (error) {
    throw initPermissionError_(error);
  }
  return moved;
}

/** 権限の例外を敬体の 1 文に言い換える。ほかはそのまま */
export function initPermissionError_(error) {
  const message = String(error && error.message ? error.message : error);
  if (/permission|権限|does not have|not have access|protected|保護/i.test(message)) return new Error(PERMISSION_TEXT);
  return error;
}

/** 「3,0」のような数とカンマだけの値は、Sheets が数と読み替えないよう ' を付けて字のまま置く */
function settingCell_(value) {
  const text = value === null || value === undefined ? "" : String(value);
  return /^[\d０-９\s]+([,、][\d０-９\s]+)+$/.test(text) ? "'" + text : text;
}

/** 行の長さをそろえる（setValues は長さの違う行を受け取らない） */
function squaredRows_(rows) {
  let width = 0;
  for (let i = 0; i < rows.length; i += 1) width = Math.max(width, rows[i].length);
  return rows.map((row) => {
    const line = row.map(settingCell_);
    while (line.length < width) line.push("");
    return line;
  });
}

/**
 * check.js の planInit が決めたものを足す。既にあるセルには 1 つも書かない。
 * 設定の行 → シート（作る・空のシートに書く）→ 見出し（1 行目のいまの右端の右）の順。
 */
export function applyInit_(plan) {
  const book = book_();
  const done = [];
  try {
    const settingRows = plan.appendSettings.rows;
    if (settingRows.length > 0) {
      const sheet = book.getSheetByName(plan.appendSettings.sheet);
      sheet.getRange(sheet.getLastRow() + 1, 1, settingRows.length, 2).setValues(squaredRows_(settingRows));
      done.push("「" + plan.appendSettings.sheet + "」に " + settingRows.length + " 行を足しました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "設定への書き込み", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.createSheets.length; i += 1) {
      const made = plan.createSheets[i];
      const sheet = made.exists === true ? book.getSheetByName(made.name) : book.insertSheet(made.name);
      const rows = squaredRows_(made.rows);
      sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
      if (made.freeze === true) sheet.setFrozenRows(1);
      done.push(made.exists === true ? "空だった「" + made.name + "」シートに見出しを書きました" : "「" + made.name + "」シートを作りました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "シートの作成", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.appendHeaders.length; i += 1) {
      const entry = plan.appendHeaders[i];
      const sheet = book.getSheetByName(entry.sheet);
      const start = sheet.getLastColumn() + 1;
      const last = start + entry.names.length - 1;
      if (last > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), last - sheet.getMaxColumns());
      sheet.getRange(1, start, 1, entry.names.length).setValues([entry.names]);
      done.push("「" + entry.sheet + "」シートの見出しに足しました: " + entry.names.join("、"));
    }
  } catch (error) {
    throw new Error(initFailureText(done, "見出しの追記", initPermissionError_(error)));
  }
}
