/**
 * 受付番号の続きと、二重送信・回数の上限の覚え書き。
 * 受付番号はスクリプトのプロパティに 1 つだけ、二重送信の鍵は CacheService に 10 分だけ置く。
 * 回数の上限の時刻も CacheService に置く（1 分と 1 時間で消える）。
 */
import { SECRET_KEYS, secretPropertyName } from "./config.js";
import { rateCheck } from "./validate.js";

/** 同時に届いた送信を待たせる時間 */
const LOCK_WAIT_MS = 10000;

/** 同じ中身の送信を二重送信とみなす間（秒） */
const DEDUPE_SECONDS = 600;

const LAST_RECEIPT_KEY = "lastReceipt";

/**
 * action を 1 つずつ順番に実行する。
 * 受付番号の採番と行の追加をここに入れるので、同時に 2 件届いても番号が重ならない。
 */
export function withLock_(action) {
  const lock = LockService.getScriptLock();
  lock.waitLock(LOCK_WAIT_MS);
  try {
    return action();
  } finally {
    lock.releaseLock();
  }
}

export function readLastReceipt_() {
  const raw = PropertiesService.getScriptProperties().getProperty(LAST_RECEIPT_KEY);
  return raw ? String(raw) : "";
}

export function saveLastReceipt_(receipt) {
  PropertiesService.getScriptProperties().setProperty(LAST_RECEIPT_KEY, String(receipt));
}

/** 「鍵を保存」で移した URL・トークン。{ 鍵の名前: 値 }（保存していない鍵は載せない） */
export function readSecrets_() {
  const store = PropertiesService.getScriptProperties();
  const secrets = {};
  for (let i = 0; i < SECRET_KEYS.length; i += 1) {
    const value = store.getProperty(secretPropertyName(SECRET_KEYS[i]));
    if (value) secrets[SECRET_KEYS[i]] = String(value);
  }
  return secrets;
}

export function saveSecret_(key, value) {
  PropertiesService.getScriptProperties().setProperty(secretPropertyName(key), value);
}

/** MD5 の 32 字。中身そのものは残さず、鍵にだけ使う */
function digestHex_(source) {
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, source, Utilities.Charset.UTF_8);
  let hex = "";
  for (let i = 0; i < digest.length; i += 1) {
    const byte = digest[i] < 0 ? digest[i] + 256 : digest[i];
    hex += (byte < 16 ? "0" : "") + byte.toString(16);
  }
  return hex;
}

/** 送信の中身から鍵を作る。中身そのものは残さず、MD5 の 32 字だけを鍵にする */
export function dedupeKeyOf_(source) {
  return "dup:" + digestHex_(source);
}

const MINUTE_MS = 60000;
const HOUR_MS = 3600000;
const RATE_ALL_KEY = "rate:all";

function readStamps_(key) {
  const raw = CacheService.getScriptCache().get(key);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    return [];
  }
}

function saveStamps_(key, stamps, seconds) {
  CacheService.getScriptCache().put(key, JSON.stringify(stamps), seconds);
}

/**
 * 回数の上限を超えたか。全体（1 分）と、同じメールアドレス（1 時間）の 2 つを数える。
 * 時刻は CacheService に置き、メールアドレスは MD5 の鍵にして、字のままは残さない。ロックの中で呼ぶ
 */
export function overLimit_(config, fields, nowMs) {
  let limited = false;
  if (config.totalLimitPerMinute > 0) {
    const all = rateCheck(readStamps_(RATE_ALL_KEY), nowMs, MINUTE_MS, config.totalLimitPerMinute);
    saveStamps_(RATE_ALL_KEY, all.stamps, 120);
    limited = all.limited;
  }
  const raw = config.emailField === "" ? "" : fields[config.emailField];
  const email = raw === undefined || raw === null ? "" : String(raw).trim().toLowerCase();
  if (email !== "" && config.mailLimitPerHour > 0) {
    const key = "rate:mail:" + digestHex_(email);
    const mine = rateCheck(readStamps_(key), nowMs, HOUR_MS, config.mailLimitPerHour);
    saveStamps_(key, mine.stamps, 3600);
    limited = limited || mine.limited;
  }
  return limited;
}

/** 10 分以内に同じ中身が来ていれば、そのときの受付番号。無ければ空 */
export function readDuplicate_(key) {
  const found = CacheService.getScriptCache().get(key);
  return found ? String(found) : "";
}

export function saveDuplicate_(key, receipt) {
  CacheService.getScriptCache().put(key, String(receipt), DEDUPE_SECONDS);
}
