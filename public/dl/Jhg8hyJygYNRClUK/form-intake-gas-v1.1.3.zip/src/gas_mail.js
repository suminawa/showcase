/** 自動返信と、通知先 mail のメールを送る。1 日の上限に達していたら送らない。 */

/** 通知先 mail のメールの差出人名 */
const NOTIFY_SENDER_NAME = "フォーム受付";

/** 今日あと送れるメールの数。読めなければ 1 通ぶんは残っているものとして進む */
export function remainingQuota_() {
  try {
    return MailApp.getRemainingDailyQuota();
  } catch (error) {
    Logger.log("フォーム受付: 残りの送信可能数を読めませんでした: " + error);
    return 1;
  }
}

/**
 * options は reply.js の buildReply が返したもの。
 * 送れたら true、上限に達していて送らなかったら false。
 * reserve は残しておく通数（通知先 mail のときは 1。最後の 1 通は、お客さまへの自動返信よりお店への通知に使う）
 */
export function sendReply_(options, reserve) {
  if (remainingQuota_() <= (reserve > 0 ? reserve : 0)) {
    Logger.log("フォーム受付: MailApp の 1 日の上限に達したため、自動返信を送りませんでした");
    return false;
  }
  MailApp.sendEmail(options);
  return true;
}

/** 通知先 mail の 1 通。上限に達していたら投げる（notifyAll_ が「送れなかった通知先」として扱う） */
export function sendNotifyMail_(to, subject, body) {
  if (remainingQuota_() <= 0) throw new Error("今日送れるメールの数の上限に達しました");
  MailApp.sendEmail({ to: to, subject: subject, body: body, name: NOTIFY_SENDER_NAME });
}
