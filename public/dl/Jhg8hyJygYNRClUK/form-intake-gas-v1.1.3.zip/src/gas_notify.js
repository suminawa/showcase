/** メール・Slack / Discord の Webhook・LINE の push message に 1 通送る。Turnstile の確かめもここ（外への通信）。 */
import { buildPayload } from "./message.js";
import { turnstileVerdict } from "./validate.js";
import { sendNotifyMail_ } from "./gas_mail.js";

const LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push";
const TURNSTILE_VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";

/** 通知先 mail の件名が渡されなかったとき */
const DEFAULT_MAIL_SUBJECT = "【フォーム受付】通知";

function post_(url, payload, headers) {
  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  if (headers) options.headers = headers;
  const response = UrlFetchApp.fetch(url, options);
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(status + " が返りました: " + String(response.getContentText()).slice(0, 200));
  }
}

export function postSlack_(url, text) {
  post_(url, buildPayload(text, "slack"));
}

export function postDiscord_(url, text) {
  post_(url, buildPayload(text, "discord"));
}

export function pushLine_(token, to, text) {
  post_(LINE_PUSH_URL, buildPayload(text, "line", { lineTo: to }), { Authorization: "Bearer " + token });
}

/**
 * Turnstile のトークンを Cloudflare に確かめる。通らない・確かめられないときは false（通信の失敗も通さない）。
 * シークレットとトークンは実行ログに出さない
 */
export function verifyTurnstile_(secret, token) {
  try {
    const response = UrlFetchApp.fetch(TURNSTILE_VERIFY_URL, {
      method: "post",
      payload: { secret: secret, response: token },
      muteHttpExceptions: true,
    });
    return turnstileVerdict(response.getResponseCode(), String(response.getContentText()));
  } catch (error) {
    Logger.log("フォーム受付: Turnstile に確かめられませんでした: " + error);
    return false;
  }
}

/**
 * 設定の通知先すべてに送る。1 つが失敗しても残りには送り、失敗は実行ログに残す。
 * failures（配列）を渡すと、失敗した通知先を { target, message } で足す（テスト送信が使う）。
 * subject は通知先 mail の件名。
 * 返り値: 送れた宛先の数
 */
export function notifyAll_(config, text, failures, subject) {
  let sent = 0;
  for (let i = 0; i < config.targets.length; i += 1) {
    const target = config.targets[i];
    try {
      if (target === "mail") sendNotifyMail_(config.notifyMailTo, subject || DEFAULT_MAIL_SUBJECT, text);
      else if (target === "slack") postSlack_(config.slackWebhookUrl, text);
      else if (target === "discord") postDiscord_(config.discordWebhookUrl, text);
      else if (target === "line") pushLine_(config.lineToken, config.lineTo, text);
      sent += 1;
    } catch (error) {
      Logger.log("フォーム受付: " + target + " に送れませんでした: " + error);
      if (failures) failures.push({ target: target, message: String(error && error.message ? error.message : error) });
    }
  }
  return sent;
}
