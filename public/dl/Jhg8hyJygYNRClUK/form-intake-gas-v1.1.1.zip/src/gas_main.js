/**
 * 入口。サイトのフォームからの POST は doPost、枠の空きの問い合わせは doGet が受ける。
 * dist/Code.gs の先頭に来るファイル。エディタから手で動かすときは、メニューの
 * 「見本の受付を 1 件入れる」を使う（doPost は e が無いと動かない）。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { ParseError, parseBody } from "./parse.js";
import { stripInternal, validateSubmission } from "./validate.js";
import { dedupeSourceOf, nextReceipt } from "./receipt.js";
import { buildHeader, buildRow } from "./rows.js";
import { availabilityOf, checkAvailability, countReservations, parseSlots } from "./slots.js";
import { buildErrorText, buildNotificationText } from "./message.js";
import { buildReply } from "./reply.js";
import { checkNotes, findProblems, planInit, summaryLines } from "./check.js";
import { checkReport, initReport } from "./setup.js";
import { appendIntakeRow_, applyInit_, readConfig_, readIntakeValues_, readRawTargets_, readSetupSnapshot_, readSlotValues_ } from "./gas_sheets.js";
import { dedupeKeyOf_, readDuplicate_, readLastReceipt_, saveDuplicate_, saveLastReceipt_, withLock_ } from "./gas_store.js";
import { notifyAll_ } from "./gas_notify.js";
import { remainingQuota_, sendReply_ } from "./gas_mail.js";

/** フォームに返す短い文。中の事情は見せない */
const ERROR_MESSAGE = "受け付けに失敗しました。少し待ってから、もう一度お試しください。";

function jsonOutput_(payload) {
  return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(ContentService.MimeType.JSON);
}

/** サイトのフォームからの POST を受ける */
export function doPost(e) {
  return jsonOutput_(receive_(e, false).answer);
}

/**
 * 受け付けの本体。answer はフォームに返す JSON の中身。
 * sample が true（メニューの見本の受付）のときは、自動返信を送らず、送るはずだったかを replySkipped で返す。
 */
function receive_(e, sample) {
  const now = new Date();
  const stamp = formatStamp(now);
  let config = null;
  try {
    config = readConfig_();
    const parsed = parseBody(e);

    const checked = validateSubmission(parsed, config);
    if (checked.ok !== true) {
      if (checked.reason === "spam") {
        // 迷惑投稿には成功したふりをする。弾かれたと分かると、bot は形を変えて送り直してくる
        Logger.log("フォーム受付: ハニーポットに字が入っていたので捨てました");
        return { answer: { ok: true } };
      }
      return { answer: { ok: false, reason: checked.reason, message: checked.message } };
    }

    const clean = stripInternal(parsed, config);
    const dedupeKey = dedupeKeyOf_(dedupeSourceOf(clean.fields, clean.order));

    // ここから先は 1 件ずつ。受付番号が重ならないよう、採番と書き込みをひとまとめにする
    const stored = withLock_(function () {
      const seen = readDuplicate_(dedupeKey);
      if (seen !== "") return { ok: true, receipt: seen, repeated: true };

      // 受付シートは 1 回だけ読み、空きの数え上げと見出しの突き合わせの両方に使い回す
      const values = readIntakeValues_(config.intakeSheetName);
      const slotValues = readSlotValues_(config.slotSheetName);
      if (slotValues !== null) {
        const availability = checkAvailability(
          parseSlots(slotValues),
          countReservations(values, config),
          config.dateField === "" ? "" : clean.fields[config.dateField],
          config.slotField === "" ? "" : clean.fields[config.slotField],
        );
        if (availability.ok !== true) {
          return { ok: false, reason: availability.reason, message: availability.message };
        }
      }

      const receipt = nextReceipt(readLastReceipt_(), toDateKey(now));
      const header = values.length === 0 ? buildHeader(config, clean.order) : values[0];
      const built = buildRow(header, {
        stamp: stamp,
        receipt: receipt,
        fields: clean.fields,
        order: clean.order,
        source: clean.source,
      });
      appendIntakeRow_(
        config.intakeSheetName,
        built.header,
        built.row,
        values.length === 0 || built.added.length > 0,
      );
      saveLastReceipt_(receipt);
      saveDuplicate_(dedupeKey, receipt);
      return { ok: true, receipt: receipt, repeated: false };
    });

    if (stored.ok !== true) {
      Logger.log("フォーム受付: 受け付けませんでした（" + stored.reason + "）");
      return { answer: { ok: false, reason: stored.reason, message: stored.message } };
    }
    if (stored.repeated === true) {
      Logger.log("フォーム受付: 10 分以内の同じ送信なので、受付番号 " + stored.receipt + " をそのまま返しました");
      return { answer: { ok: true, id: stored.receipt } };
    }

    const context = {
      receipt: stored.receipt,
      fields: clean.fields,
      order: clean.order,
      source: clean.source,
      quotaExhausted: false,
    };
    const reply = buildReply(config, context);
    // 見本の宛先は架空のアドレスなので、見本のときは送らない
    if (reply !== null && sample !== true) context.quotaExhausted = sendReply_(reply) === false;
    notifyAll_(config, buildNotificationText(config, context));
    return { answer: { ok: true, id: stored.receipt }, replySkipped: reply !== null && sample === true };
  } catch (error) {
    // 送信の中身が読めないのは送り手側の話。設定の壊れではないので、通知は出さずに invalid を返す
    if (error instanceof ParseError) {
      Logger.log("フォーム受付: 送信の中身を読み取れませんでした（" + error.message + "）");
      return { answer: { ok: false, reason: "invalid", message: error.message } };
    }
    Logger.log("フォーム受付: " + error);
    reportError_(error, stamp, config);
    return { answer: { ok: false, reason: "error", message: ERROR_MESSAGE } };
  }
}

/** 予約枠の残り数を返す。?date=2026-09-14 */
export function doGet(e) {
  try {
    const config = readConfig_();
    const parameter = e && e.parameter ? e.parameter : {};
    const dateKey = toDateKey(parameter.date);
    if (dateKey === null) {
      return jsonOutput_({ ok: false, reason: "invalid", message: "date=2026-09-14 の形で日付を付けてください。" });
    }
    const slotValues = readSlotValues_(config.slotSheetName);
    if (slotValues === null) {
      return jsonOutput_({ ok: false, reason: "invalid", message: "予約枠を使っていません。" });
    }
    const slots = availabilityOf(
      parseSlots(slotValues),
      countReservations(readIntakeValues_(config.intakeSheetName), config),
      dateKey,
    );
    return jsonOutput_({ ok: true, date: dateKey, slots: slots });
  } catch (error) {
    Logger.log("フォーム受付: " + error);
    return jsonOutput_({ ok: false, reason: "error", message: ERROR_MESSAGE });
  }
}

/** 失敗を通知先へ 1 通流す。設定が壊れているときは、通知先の行だけを読み直す */
export function reportError_(error, stamp, config) {
  try {
    const destination = config ? config : readRawTargets_();
    if (!destination || destination.targets.length === 0) return;
    notifyAll_(destination, buildErrorText(error, stamp));
  } catch (sendError) {
    Logger.log("フォーム受付: エラー通知も送れませんでした: " + sendError);
  }
}

/** 通知先が合っているかだけを確かめる 1 通 */
export function sendTestNotification() {
  const ui = SpreadsheetApp.getUi();
  const stamp = formatStamp(new Date());
  let config = null;
  try {
    config = readConfig_();
    if (config.targets.length === 0) {
      ui.alert("「通知先」が空です。設定シートに slack / discord / line を書いてください。");
      return;
    }
    const sent = notifyAll_(
      config,
      "【フォーム受付】テスト送信です。この文が見えていれば、通知先の設定は合っています。",
    );
    ui.alert(sent + " か所に送りました。届いていなければ、設定シートの URL とトークンを確かめてください。");
  } catch (error) {
    reportError_(error, stamp, config);
    ui.alert(String(error && error.message ? error.message : error));
  }
}

/** 見本の受付の宛先。架空のアドレスで、実行した方のアドレスは使わない */
const SAMPLE_EMAIL = "taro@example.com";

/**
 * 見本の受付を 1 件入れる。フォームから送るのと同じ道を通る。
 * 宛先は架空のアドレスなので、自動返信は送らない（通知は設定どおり届く）。
 */
export function receiveSample() {
  const body = {
    name: "見本 太郎",
    email: SAMPLE_EMAIL,
    message: "これは動作確認の見本です。受付シートに 1 行入り、通知が届けば、設定は合っています。",
    page: "https://example.com/contact",
  };
  const result = receive_(
    {
      postData: { type: "text/plain;charset=utf-8", contents: JSON.stringify(body) },
      parameter: {},
    },
    true,
  );
  Logger.log("フォーム受付: 見本の受付 " + JSON.stringify(result.answer));
  SpreadsheetApp.getUi().alert(sampleReport_(result));
}

/** 見本の受付のあとに出す文 */
function sampleReport_(result) {
  const answer = result.answer;
  if (answer.ok !== true) {
    return "見本の受付は入りませんでした。次の内容をご確認ください。\n\n" + String(answer.message || answer.reason || "");
  }
  const lines = [
    "見本の受付を 1 件入れました（受付番号 " + answer.id + "）。",
    "受付シートの最後の行と、通知先に届いた通知をご確認ください。10 分以内に続けて押したときは、同じ受付番号のまま、行は増えません。",
  ];
  if (result.replySkipped === true) {
    lines.push(
      "",
      "見本の宛先は架空のアドレス（" + SAMPLE_EMAIL + "）のため、自動返信は送っていません。自動返信を確かめるときは、サイトのフォームから、ご自身のメールアドレスで 1 件お送りください。",
    );
  }
  return lines.join("\n");
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + String(error && error.message ? error.message : error);
}

/** ロックが取れなかったときの敬体の 1 文。ほかはそのまま */
function initLockAwareText_(error) {
  const message = String(error && error.message ? error.message : error);
  if (/lock/i.test(message)) return "ほかの処理が動いています。少し待ってからもう一度お試しください。";
  return failureText_(error);
}

/**
 * 足りないシート・見出し・設定の行だけを足す。何度押してもよく、既にある受付と設定の値は変えない。
 * doPost と同時に走ると書き込みが混ざるおそれがあるので、doPost と同じロックの中で行う。
 */
export function initializeSheets() {
  const ui = SpreadsheetApp.getUi();
  try {
    const plan = withLock_(function () {
      const built = planInit(readSetupSnapshot_());
      applyInit_(built);
      return built;
    });
    ui.alert(initReport(plan, plan.nextStep));
  } catch (error) {
    ui.alert(initLockAwareText_(error));
  }
}

/** 直すところを全部並べる。無ければ、いまの設定でこれから何が起きるかを短く出す */
export function checkConfig() {
  const ui = SpreadsheetApp.getUi();
  try {
    const snapshot = readSetupSnapshot_();
    const problems = findProblems(snapshot);
    const summary = problems.length === 0 ? summaryLines(snapshot, { quota: remainingQuota_() }) : [];
    ui.alert(checkReport(problems, summary, "", checkNotes(snapshot)));
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/** シートを開いたときにメニューを足す */
export function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("フォーム受付")
    .addItem("初期化（足りないシート・見出し・設定を足す。データは消しません）", "initializeSheets")
    .addItem("設定を確かめる", "checkConfig")
    .addSeparator()
    .addItem("テスト送信", "sendTestNotification")
    .addItem("見本の受付を 1 件入れる", "receiveSample")
    .addToUi();
}
