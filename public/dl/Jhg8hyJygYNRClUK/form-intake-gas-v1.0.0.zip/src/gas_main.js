/**
 * 入口。サイトのフォームからの POST は doPost、枠の空きの問い合わせは doGet が受ける。
 * dist/Code.gs の先頭に来るファイル。エディタから手で動かすときは、メニューの
 * 「見本の受付を 1 件入れる」を使う（doPost は e が無いと動かない）。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { ParseError, parseBody } from "./parse.js";
import { stripInternal, validateSubmission } from "./validate.js";
import { dedupeSourceOf, nextReceipt } from "./receipt.js";
import { buildHeader, buildRow } from "./rows.js";
import { availabilityOf, checkAvailability, countReservations, parseSlots } from "./slots.js";
import { buildErrorText, buildNotificationText } from "./message.js";
import { buildReply } from "./reply.js";
import { appendIntakeRow_, readConfig_, readIntakeValues_, readRawTargets_, readSlotValues_ } from "./gas_sheets.js";
import { dedupeKeyOf_, readDuplicate_, readLastReceipt_, saveDuplicate_, saveLastReceipt_, withLock_ } from "./gas_store.js";
import { notifyAll_ } from "./gas_notify.js";
import { remainingQuota_, sendReply_ } from "./gas_mail.js";

/** フォームに返す短い文。中の事情は見せない */
const ERROR_MESSAGE = "受け付けに失敗しました。少し待ってから、もう一度お試しください。";

function jsonOutput_(payload) {
  return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(ContentService.MimeType.JSON);
}

/** サイトのフォームからの POST を受ける */
export function doPost(e) {
  const now = new Date();
  const stamp = formatStamp(now);
  let config = null;
  try {
    config = readConfig_();
    const parsed = parseBody(e);

    const checked = validateSubmission(parsed, config);
    if (checked.ok !== true) {
      if (checked.reason === "spam") {
        // 迷惑投稿には成功したふりをする。弾かれたと分かると、bot は形を変えて送り直してくる
        Logger.log("フォーム受付: ハニーポットに字が入っていたので捨てました");
        return jsonOutput_({ ok: true });
      }
      return jsonOutput_({ ok: false, reason: checked.reason, message: checked.message });
    }

    const clean = stripInternal(parsed, config);
    const dedupeKey = dedupeKeyOf_(dedupeSourceOf(clean.fields, clean.order));

    // ここから先は 1 件ずつ。受付番号が重ならないよう、採番と書き込みをひとまとめにする
    const stored = withLock_(function () {
      const seen = readDuplicate_(dedupeKey);
      if (seen !== "") return { ok: true, receipt: seen, repeated: true };

      // 受付シートは 1 回だけ読み、空きの数え上げと見出しの突き合わせの両方に使い回す
      const values = readIntakeValues_(config.intakeSheetName);
      const slotValues = readSlotValues_(config.slotSheetName);
      if (slotValues !== null) {
        const availability = checkAvailability(
          parseSlots(slotValues),
          countReservations(values, config),
          config.dateField === "" ? "" : clean.fields[config.dateField],
          config.slotField === "" ? "" : clean.fields[config.slotField],
        );
        if (availability.ok !== true) {
          return { ok: false, reason: availability.reason, message: availability.message };
        }
      }

      const receipt = nextReceipt(readLastReceipt_(), toDateKey(now));
      const header = values.length === 0 ? buildHeader(config, clean.order) : values[0];
      const built = buildRow(header, {
        stamp: stamp,
        receipt: receipt,
        fields: clean.fields,
        order: clean.order,
        source: clean.source,
      });
      appendIntakeRow_(
        config.intakeSheetName,
        built.header,
        built.row,
        values.length === 0 || built.added.length > 0,
      );
      saveLastReceipt_(receipt);
      saveDuplicate_(dedupeKey, receipt);
      return { ok: true, receipt: receipt, repeated: false };
    });

    if (stored.ok !== true) {
      Logger.log("フォーム受付: 受け付けませんでした（" + stored.reason + "）");
      return jsonOutput_({ ok: false, reason: stored.reason, message: stored.message });
    }
    if (stored.repeated === true) {
      Logger.log("フォーム受付: 10 分以内の同じ送信なので、受付番号 " + stored.receipt + " をそのまま返しました");
      return jsonOutput_({ ok: true, id: stored.receipt });
    }

    const context = {
      receipt: stored.receipt,
      fields: clean.fields,
      order: clean.order,
      source: clean.source,
      quotaExhausted: false,
    };
    const reply = buildReply(config, context);
    if (reply !== null) context.quotaExhausted = sendReply_(reply) === false;
    notifyAll_(config, buildNotificationText(config, context));
    return jsonOutput_({ ok: true, id: stored.receipt });
  } catch (error) {
    // 送信の中身が読めないのは送り手側の話。設定の壊れではないので、通知は出さずに invalid を返す
    if (error instanceof ParseError) {
      Logger.log("フォーム受付: 送信の中身を読み取れませんでした（" + error.message + "）");
      return jsonOutput_({ ok: false, reason: "invalid", message: error.message });
    }
    Logger.log("フォーム受付: " + error);
    reportError_(error, stamp, config);
    return jsonOutput_({ ok: false, reason: "error", message: ERROR_MESSAGE });
  }
}

/** 予約枠の残り数を返す。?date=2026-09-14 */
export function doGet(e) {
  try {
    const config = readConfig_();
    const parameter = e && e.parameter ? e.parameter : {};
    const dateKey = toDateKey(parameter.date);
    if (dateKey === null) {
      return jsonOutput_({ ok: false, reason: "invalid", message: "date=2026-09-14 の形で日付を付けてください。" });
    }
    const slotValues = readSlotValues_(config.slotSheetName);
    if (slotValues === null) {
      return jsonOutput_({ ok: false, reason: "invalid", message: "予約枠を使っていません。" });
    }
    const slots = availabilityOf(
      parseSlots(slotValues),
      countReservations(readIntakeValues_(config.intakeSheetName), config),
      dateKey,
    );
    return jsonOutput_({ ok: true, date: dateKey, slots: slots });
  } catch (error) {
    Logger.log("フォーム受付: " + error);
    return jsonOutput_({ ok: false, reason: "error", message: ERROR_MESSAGE });
  }
}

/** 失敗を通知先へ 1 通流す。設定が壊れているときは、通知先の行だけを読み直す */
export function reportError_(error, stamp, config) {
  try {
    const destination = config ? config : readRawTargets_();
    if (!destination || destination.targets.length === 0) return;
    notifyAll_(destination, buildErrorText(error, stamp));
  } catch (sendError) {
    Logger.log("フォーム受付: エラー通知も送れませんでした: " + sendError);
  }
}

/** 実行しているアカウントのメールアドレス。読めなければ空 */
function ownerEmail_() {
  try {
    const email = Session.getActiveUser().getEmail();
    return email ? String(email) : "";
  } catch (error) {
    return "";
  }
}

/** 通知先が合っているかだけを確かめる 1 通 */
export function sendTestNotification() {
  const ui = SpreadsheetApp.getUi();
  const stamp = formatStamp(new Date());
  let config = null;
  try {
    config = readConfig_();
    if (config.targets.length === 0) {
      ui.alert("「通知先」が空です。設定シートに slack / discord / line を書いてください。");
      return;
    }
    const sent = notifyAll_(
      config,
      "【フォーム受付】テスト送信です。この文が見えていれば、通知先の設定は合っています。",
    );
    ui.alert(sent + " か所に送りました。届いていなければ、設定シートの URL とトークンを確かめてください。");
  } catch (error) {
    reportError_(error, stamp, config);
    ui.alert(String(error && error.message ? error.message : error));
  }
}

/** 見本の受付を 1 件入れる。フォームから送るのと同じ道を通る */
export function receiveSample() {
  const email = ownerEmail_();
  const body = {
    name: "見本 太郎",
    email: email === "" ? "sample@example.com" : email,
    message: "これは動作確認の見本です。受付シートに 1 行入り、通知と自動返信が届けば、設定は合っています。",
    page: "https://example.com/contact",
  };
  const output = doPost({
    postData: { type: "text/plain;charset=utf-8", contents: JSON.stringify(body) },
    parameter: {},
  });
  const answer = output.getContent();
  Logger.log("フォーム受付: 見本の受付 " + answer);
  SpreadsheetApp.getUi().alert("見本の受付を送りました。\n\n返り値: " + answer);
}

/** 設定シートを読んで、いまの設定を一覧で出す */
export function checkConfig() {
  const ui = SpreadsheetApp.getUi();
  try {
    const config = readConfig_();
    const lines = [
      "通知先: " + (config.targets.length === 0 ? "（通知しない）" : config.targets.join(", ")),
      "受付シート名: " + config.intakeSheetName,
      "枠シート名: " + (config.slotSheetName === "" ? "（予約枠を使わない）" : config.slotSheetName),
      "必須項目: " + (config.requiredFields.length === 0 ? "（なし）" : config.requiredFields.join(", ")),
      "項目の並び: " + (config.fieldOrder.length === 0 ? "（送られてきた順）" : config.fieldOrder.join(", ")),
      "自動返信: " + (config.autoReply ? "送る（宛先は「" + config.emailField + "」の値）" : "送らない"),
      "今日あと送れるメール: " + remainingQuota_() + " 通",
    ];
    ui.alert("設定は読めました\n\n" + lines.join("\n"));
  } catch (error) {
    ui.alert("設定に直すところがあります\n\n" + String(error && error.message ? error.message : error));
  }
}

/** シートを開いたときにメニューを足す */
export function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("フォーム受付")
    .addItem("テスト送信", "sendTestNotification")
    .addItem("見本の受付を 1 件入れる", "receiveSample")
    .addItem("設定を確かめる", "checkConfig")
    .addToUi();
}
