/** スプレッドシートから設定・受付・枠を読み書きする。 */
import { ConfigError, parseConfig } from "./config.js";

const SETTINGS_SHEET = "設定";

function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

export function readConfig_() {
  const book = book_();
  const timeZone = book.getSpreadsheetTimeZone();
  if (timeZone !== "Asia/Tokyo") {
    throw new ConfigError(
      "スプレッドシートのタイムゾーンが " +
        timeZone +
        " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。",
    );
  }
  const sheet = book.getSheetByName(SETTINGS_SHEET);
  if (!sheet) throw new ConfigError("「設定」シートがありません。README.ja.md の手順 1 を見てください。");
  return parseConfig(sheet.getDataRange().getValues());
}

/**
 * 設定が壊れていてもエラーだけは届くように、通知先の行だけを検証せずに読む。
 * 返り値は notifyAll_ に渡せる形。読めなければ null。
 */
export function readRawTargets_() {
  try {
    const sheet = book_().getSheetByName(SETTINGS_SHEET);
    if (!sheet) return null;
    const rows = sheet.getDataRange().getValues();
    const found = { targets: [], slackWebhookUrl: "", discordWebhookUrl: "", lineToken: "", lineTo: "" };
    const known = ["slack", "discord", "line"];
    for (let i = 0; i < rows.length; i += 1) {
      const key = String(rows[i][0]).replace(/\s+/g, "").toLowerCase();
      const value = String(rows[i][1] === null || rows[i][1] === undefined ? "" : rows[i][1]).trim();
      if (key === "通知先") {
        const parts = value.toLowerCase().split(/[,、]/);
        for (let j = 0; j < parts.length; j += 1) {
          const name = parts[j].trim();
          if (known.indexOf(name) >= 0 && found.targets.indexOf(name) < 0) found.targets.push(name);
        }
      }
      if (key === "slackwebhookurl") found.slackWebhookUrl = value;
      if (key === "discordwebhookurl") found.discordWebhookUrl = value;
      if (key === "lineチャネルアクセストークン") found.lineToken = value;
      if (key === "line送信先id") found.lineTo = value;
    }
    return found.targets.length === 0 ? null : found;
  } catch (error) {
    return null;
  }
}

/** 受付シート。無ければ作る */
export function intakeSheet_(sheetName) {
  const book = book_();
  const sheet = book.getSheetByName(sheetName);
  return sheet ? sheet : book.insertSheet(sheetName);
}

/**
 * 受付シートの全部の値。シートがまだ無いか、1 行も無ければ空の配列。
 * ここでは作らない（doGet で読んだだけのときに、空のシートが増えないようにする）。
 * シートを作るのは、1 件目を書き込む appendIntakeRow_ のとき。
 */
export function readIntakeValues_(sheetName) {
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() === 0) return [];
  return sheet.getDataRange().getValues();
}

/** 枠シートの全部の値。シートが無い / 予約枠を使わない設定なら null */
export function readSlotValues_(sheetName) {
  if (sheetName === "") return null;
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() === 0) return null;
  return sheet.getDataRange().getValues();
}

/**
 * 末尾に 1 行足す。
 * シートが空のとき、または見出しを足したときだけ 1 行目を書き直す（既にある見出しは動かさない）。
 */
export function appendIntakeRow_(sheetName, header, row, writeHeader) {
  const sheet = intakeSheet_(sheetName);
  if (header.length > sheet.getMaxColumns()) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), header.length - sheet.getMaxColumns());
  }
  if (sheet.getLastRow() === 0 || writeHeader === true) {
    sheet.getRange(1, 1, 1, header.length).setValues([header]);
  }
  sheet.appendRow(row);
}
