import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CONFIG_KEYS, DEFAULT_CONFIG, parseConfig } from "../src/config.js";
import { parseBody } from "../src/parse.js";
import { stripInternal } from "../src/validate.js";
import { buildHeader, buildRow } from "../src/rows.js";
import { availabilityOf, countReservations, parseSlots } from "../src/slots.js";
import { buildNotificationText } from "../src/message.js";
import { buildReply } from "../src/reply.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 見本 CSV を行と列に割る。"..." の中のカンマと改行は区切りにしない */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += ch;
    }
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function read(name) {
  return readFileSync(join(root, name), "utf8");
}

/** README の設定表の 1 列目（項目名）を、書いてある順に取り出す */
function settingsTableKeys(readme) {
  const keys = [];
  const lines = readme.split("\n");
  let inside = false;
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (line.indexOf("| 項目 | 既定値 | 意味 |") === 0) {
      inside = true;
      continue;
    }
    if (!inside) continue;
    if (line.indexOf("|") !== 0) break;
    if (/^\|\s*-/.test(line)) continue;
    keys.push(line.split("|")[1].trim());
  }
  return keys;
}

/** form-sample.html の、README に載せている送信のコード */
function sampleScript(html) {
  const open = "// ===== ここから README と同じ =====";
  const close = "// ===== ここまで =====";
  return html.slice(html.indexOf(open) + open.length, html.indexOf(close)).trim();
}

const SAMPLE_RECEIPT = "20260914-001";
const SAMPLE_STAMP = "2026-09-14 10:32:05";
const SAMPLE_BODY = {
  name: "見本 太郎",
  email: "taro@example.com",
  message: "料金と納期を知りたいです。",
  page: "https://example.com/contact",
};

function sampleContext(config) {
  const parsed = parseBody({
    postData: { type: "text/plain;charset=utf-8", contents: JSON.stringify(SAMPLE_BODY) },
    parameter: {},
  });
  const clean = stripInternal(parsed, config);
  return {
    receipt: SAMPLE_RECEIPT,
    fields: clean.fields,
    order: clean.order,
    source: clean.source,
    quotaExhausted: false,
  };
}

test("README の設定表と CONFIG_KEYS と見本の設定シートは、同じ 20 項目が同じ順に並ぶ", () => {
  const csvKeys = rowsOf(read("samples/settings-sample.csv"))
    .slice(1)
    .map((row) => row[0]);
  assert.deepEqual(csvKeys, CONFIG_KEYS);
  assert.deepEqual(settingsTableKeys(read("README.ja.md")), CONFIG_KEYS);
});

test("見本の設定シートを読むと、Slack の URL 以外は既定値になる", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  assert.deepEqual(
    config,
    Object.assign({}, DEFAULT_CONFIG, {
      slackWebhookUrl: "https://hooks.slack.com/services/XXXXXXXXX/YYYYYYYYY/ZZZZZZZZZZZZ",
    }),
  );
});

test("見本の受付シートの見出しは、見本の設定から作られる見出しと同じ", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const header = rowsOf(read("samples/intake-sample.csv"))[0];
  assert.deepEqual(header, buildHeader(config, []));
  assert.deepEqual(header, ["受付日時", "受付番号", "name", "email", "message", "送信元"]);
});

test("見本の枠シートは枠として読め、残り数を出せる", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const slots = parseSlots(rowsOf(read("samples/slots-sample.csv")));
  assert.equal(slots.length, 5);
  assert.deepEqual(slots[0], { dateKey: "2026-09-14", slot: "10:00", capacity: 2, rowNumber: 2 });
  const counts = countReservations([], config);
  assert.deepEqual(availabilityOf(slots, counts, "2026-09-15"), [
    { slot: "10:00", capacity: 2, used: 0, remaining: 2 },
    { slot: "13:00", capacity: 2, used: 0, remaining: 2 },
  ]);
});

test("見本の 1 件から、README に載せた受付シートの行が出る", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const context = sampleContext(config);
  const built = buildRow(rowsOf(read("samples/intake-sample.csv"))[0], {
    stamp: SAMPLE_STAMP,
    receipt: SAMPLE_RECEIPT,
    fields: context.fields,
    order: context.order,
    source: context.source,
  });
  assert.deepEqual(built.added, []);
  assert.deepEqual(built.row, [
    SAMPLE_STAMP,
    SAMPLE_RECEIPT,
    "見本 太郎",
    "taro@example.com",
    "料金と納期を知りたいです。",
    "https://example.com/contact",
  ]);
  const readme = read("README.ja.md");
  assert.ok(readme.includes("| " + built.row.join(" | ") + " |"), "README の受付シートの行が食い違っている");
});

test("README に載せた通知と自動返信は、実際に出るものと同じ", () => {
  const config = parseConfig(rowsOf(read("samples/settings-sample.csv")));
  const context = sampleContext(config);
  const readme = read("README.ja.md");

  const notification = buildNotificationText(config, context);
  assert.equal(
    notification,
    [
      "【受付】20260914-001",
      "name: 見本 太郎",
      "email: taro@example.com",
      "message: 料金と納期を知りたいです。",
    ].join("\n"),
  );
  assert.ok(readme.includes(notification), "README の通知の例が食い違っている");

  const reply = buildReply(config, context);
  assert.ok(readme.includes("件名: " + reply.subject), "README の自動返信の件名が食い違っている");
  assert.ok(readme.includes(reply.body), "README の自動返信の本文が食い違っている");
});

test("見本のフォームの送り方は、README に載せたものと同じ", () => {
  const html = read("samples/form-sample.html");
  const script = sampleScript(html);
  assert.ok(script.includes('"Content-Type": "text/plain;charset=utf-8"'), "text/plain で送っていない");
  assert.ok(html.includes('name="homepage"'), "見えない欄が無い");
  assert.ok(read("README.ja.md").includes(script), "README の送信のコードが食い違っている");
});
