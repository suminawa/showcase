import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSource, MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";
import { readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";
import { createHash } from "node:crypto";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

test("import 行は落ち、export だけが剥がれる", () => {
  const input = 'import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\n';
  assert.equal(toGasSource(input), "function f() {\n  return 1;\n}");
});

test("export const / export class も剥がれ、中身の行は触らない", () => {
  const input =
    'export const A = 1;\nexport class B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}\n';
  assert.equal(
    toGasSource(input),
    "const A = 1;\nclass B extends Error {}\nfunction c_() {\n  const exported = 2;\n  return exported;\n}",
  );
});

test("SOURCE_ORDER は 14 個で、先頭は gas_main.js、重複が無い", () => {
  assert.equal(SOURCE_ORDER.length, 14);
  assert.equal(SOURCE_ORDER[0], "gas_main.js");
  assert.deepEqual(SOURCE_ORDER.slice().sort(), Array.from(new Set(SOURCE_ORDER)).sort());
});

test("マニフェストは Asia/Tokyo の V8 で、ウェブアプリとして公開する", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
  assert.deepEqual(MANIFEST.webapp, { access: "ANYONE_ANONYMOUS", executeAs: "USER_DEPLOYING" });
  assert.deepEqual(MANIFEST.oauthScopes, [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/script.send_mail",
    "https://www.googleapis.com/auth/script.container.ui",
    "https://www.googleapis.com/auth/userinfo.email",
  ]);
});

test("求める許可は、実際に使うものだけ", () => {
  const code = buildSource(root);
  // メニューと確認の画面を出すのに要る
  assert.ok(code.includes("SpreadsheetApp.getUi()"), "getUi を使っていないのに container.ui を求めている");
  assert.ok(MANIFEST.oauthScopes.indexOf("https://www.googleapis.com/auth/script.container.ui") >= 0);
  // ScriptApp はどこでも使っていないので、script.scriptapp は求めない
  assert.equal(code.includes("ScriptApp"), false, "ScriptApp を使うなら script.scriptapp を戻すこと");
  assert.equal(MANIFEST.oauthScopes.indexOf("https://www.googleapis.com/auth/script.scriptapp"), -1);
});

test("つないだ結果に import / export は残らない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(buildSource(root)), false);
});

test("入口の 6 つが入っている", () => {
  const code = buildSource(root);
  for (const name of [
    "function doPost(",
    "function doGet(",
    "function onOpen()",
    "function sendTestNotification()",
    "function receiveSample()",
    "function checkConfig()",
  ]) {
    assert.ok(code.includes(name), name + " が無い");
  }
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = buildSource(root);
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("SOURCE_ORDER に src の取りこぼしが無い", () => {
  const files = readdirSync(join(root, "src"))
    .filter((name) => name.endsWith(".js"))
    .sort();
  assert.deepEqual(SOURCE_ORDER.slice().sort(), files);
});

test("ParseError はつないだあとも 1 つだけ（instanceof の突き合わせが効く）", () => {
  const code = buildSource(root);
  assert.equal((code.match(/class\s+ParseError\b/g) || []).length, 1);
  assert.equal((code.match(/class\s+ConfigError\b/g) || []).length, 1);
});

// ===== つないだ 1 本を、GAS の偽物を並べた入れ物の中で実際に動かす =====
// GAS に触る src/gas_*.js は単体テストしていないので、入口の道筋だけはここで通す。

/**
 * シート 1 枚。getDataRange で読んだ回数も控える（受付シートを何度も読んでいないかを見るため）。
 * 書き込まれた行は Array.from でこちら側の配列に写し替える（vm の中の配列のままだと比べられない）。
 */
function fakeSheet(values) {
  const rows = values.map((row) => Array.from(row));
  const sheet = {
    reads: 0,
    rows: rows,
    getLastRow: () => rows.length,
    getMaxColumns: () => 26,
    insertColumnsAfter: () => {},
    getDataRange: () => {
      sheet.reads += 1;
      return { getValues: () => rows.map((row) => row.slice()) };
    },
    getRange: () => ({
      setValues: (written) => {
        rows[0] = Array.from(written[0]);
      },
    }),
    appendRow: (row) => {
      rows.push(Array.from(row));
    },
  };
  return sheet;
}

function settingsRows(extra) {
  const base = [
    ["項目", "値"],
    ["通知先", "slack"],
    ["Slack Webhook URL", "https://hooks.slack.com/services/T000/B000/xxxx"],
    ["自動返信", "FALSE"],
  ];
  return extra ? base.concat(extra) : base;
}

const SLOT_ROWS = [
  ["日付", "時間帯", "定員"],
  ["2026-09-14", "10:00", 2],
];

/** つないだ 1 本を偽の GAS の上で 1 回走らせ、入口と、触った跡を返す */
function runBundle(sheets) {
  const trace = { created: [], notified: [], mailed: [], logs: [], alerts: [] };
  const props = {};
  const cache = {};
  const book = {
    getSpreadsheetTimeZone: () => "Asia/Tokyo",
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      trace.created.push(name);
      sheets[name] = fakeSheet([]);
      return sheets[name];
    },
  };
  const sandbox = {
    SpreadsheetApp: {
      getActiveSpreadsheet: () => book,
      getUi: () => ({ alert: (text) => trace.alerts.push(String(text)) }),
    },
    ContentService: {
      MimeType: { JSON: "application/json" },
      createTextOutput: (text) => ({
        setMimeType() {
          return this;
        },
        getContent: () => text,
      }),
    },
    LockService: { getScriptLock: () => ({ waitLock: () => {}, releaseLock: () => {} }) },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (props[key] === undefined ? null : props[key]),
        setProperty: (key, value) => {
          props[key] = value;
        },
      }),
    },
    CacheService: {
      getScriptCache: () => ({
        get: (key) => (cache[key] === undefined ? null : cache[key]),
        put: (key, value) => {
          cache[key] = value;
        },
      }),
    },
    UrlFetchApp: {
      fetch: (url, options) => {
        trace.notified.push({ url: url, payload: options.payload });
        return { getResponseCode: () => 200, getContentText: () => "ok" };
      },
    },
    MailApp: {
      getRemainingDailyQuota: () => 100,
      sendEmail: (options) => trace.mailed.push(options),
    },
    Utilities: {
      DigestAlgorithm: { MD5: "MD5" },
      Charset: { UTF_8: "UTF-8" },
      computeDigest: (algorithm, source) => Array.from(createHash("md5").update(String(source), "utf8").digest()),
    },
    Session: { getActiveUser: () => ({ getEmail: () => "owner@example.com" }) },
    Logger: { log: (text) => trace.logs.push(String(text)) },
  };
  const context = createContext(sandbox);
  runInContext(buildSource(root) + "\nglobalThis.__entry = { doPost: doPost, doGet: doGet };\n", context);
  return { entry: sandbox.__entry, trace: trace, sheets: sheets, book: book };
}

function answerOf(output) {
  return JSON.parse(output.getContent());
}

test("つないだ 1 本は、偽の GAS の上で 1 件受け付けられる", () => {
  const intake = fakeSheet([["受付日時", "受付番号", "name", "email", "message", "送信元", "date", "slot"]]);
  const run = runBundle({ 設定: fakeSheet(settingsRows()), 受付: intake, 枠: fakeSheet(SLOT_ROWS) });
  const answer = answerOf(
    run.entry.doPost({
      postData: {
        type: "text/plain;charset=utf-8",
        contents: JSON.stringify({
          name: "見本 太郎",
          email: "taro@example.com",
          date: "2026-09-14",
          slot: "10:00",
          page: "https://example.com/contact",
        }),
      },
      parameter: {},
    }),
  );
  assert.equal(answer.ok, true);
  assert.match(answer.id, /^\d{8}-001$/);
  assert.deepEqual(intake.rows[0], ["受付日時", "受付番号", "name", "email", "message", "送信元", "date", "slot"]);
  assert.equal(intake.rows.length, 2);
  assert.equal(intake.rows[1][2], "見本 太郎");
  assert.equal(run.trace.notified.length, 1);
  // 受付シートを読むのは 1 回だけ（空きの数え上げと見出しの突き合わせで使い回す）
  assert.equal(intake.reads, 1);
});

test("送信の中身が読めないときは invalid を返し、エラー通知は出さない", () => {
  const run = runBundle({ 設定: fakeSheet(settingsRows()), 受付: fakeSheet([]) });
  // e ごと無いとき（エディタから素で呼んだとき）
  assert.deepEqual(answerOf(run.entry.doPost(undefined)), {
    ok: false,
    reason: "invalid",
    message: "送信の中身がありません。",
  });
  // 中身が空のとき
  assert.equal(answerOf(run.entry.doPost({ postData: { type: "text/plain", contents: "" }, parameter: {} })).reason, "invalid");
  // multipart/form-data で送られたとき（このキットは受けられない）
  const multipart = answerOf(
    run.entry.doPost({
      postData: { type: "multipart/form-data; boundary=x", contents: "--x\r\nContent-Disposition: form-data\r\n--x--" },
      parameter: {},
    }),
  );
  assert.equal(multipart.reason, "invalid");
  assert.equal(multipart.message, "送信の中身を読み取れませんでした（JSON として読めません）。");
  assert.deepEqual(run.trace.notified, []);
  assert.deepEqual(run.trace.mailed, []);
});

test("doGet は、受付シートが無くても作らない", () => {
  const run = runBundle({ 設定: fakeSheet(settingsRows()), 枠: fakeSheet(SLOT_ROWS) });
  const answer = answerOf(run.entry.doGet({ parameter: { date: "2026-09-14" } }));
  assert.deepEqual(answer, {
    ok: true,
    date: "2026-09-14",
    slots: [{ slot: "10:00", capacity: 2, used: 0, remaining: 2 }],
  });
  assert.deepEqual(run.trace.created, []);
  assert.equal(Object.prototype.hasOwnProperty.call(run.sheets, "受付"), false);
});

test("送られてきた数式は、受付シートにただの字として入る（シートは 1 件目で作られる）", () => {
  const run = runBundle({ 設定: fakeSheet(settingsRows([["枠シート名", ""]])) });
  const answer = answerOf(
    run.entry.doPost({
      postData: {
        type: "text/plain;charset=utf-8",
        contents: JSON.stringify({
          name: "=IMPORTDATA(\"https://spam.example/x.csv\")",
          email: "taro@example.com",
          "@SUM(A1)": "-",
        }),
      },
      parameter: {},
    }),
  );
  assert.equal(answer.ok, true);
  assert.deepEqual(run.trace.created, ["受付"]);
  const intake = run.sheets["受付"];
  assert.deepEqual(intake.rows[0], ["受付日時", "受付番号", "name", "email", "message", "送信元", "'@SUM(A1)"]);
  assert.deepEqual(intake.rows[1].slice(2), [
    "'=IMPORTDATA(\"https://spam.example/x.csv\")",
    "taro@example.com",
    "",
    "",
    "'-",
  ]);
});
