#!/usr/bin/env node
// 配布 zip を release/ に作る。買い手が貼るのは dist/Code.gs の 1 本だけ。
// src / test / scripts も入れる（「手元で動かす」と改造ができるように）。
// 元: AI 問い合わせ整理キット 1.0.0 の scripts/release.mjs（zip の名前だけ変えた）
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/survey-analysis-gas-v${pkg.version}.zip`;

for (const required of ["dist/Code.gs", "dist/appsscript.json", "README.ja.md", "LICENSE.md", "CHANGELOG.md"]) {
  if (!existsSync(required)) {
    console.error(required + " が無い。先に npm run build（README などは Task 7 で作る）");
    process.exit(1);
  }
}
mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

execFileSync(
  "zip",
  ["-r", out, "dist", "samples", "src", "test", "scripts", "README.ja.md", "LICENSE.md", "CHANGELOG.md", "package.json", "-x", "*.DS_Store"],
  { stdio: "inherit" },
);
console.log(`wrote ${out}`);
