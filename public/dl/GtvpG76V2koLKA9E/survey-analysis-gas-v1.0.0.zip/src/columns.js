/**
 * どのシートの、どの列を読むか（純粋）。設定で名指しがあればそれを使い、無ければ見出しから推測する。
 * 名前・メール・電話・住所の列は、設定で名指ししても回答の列にしない（Claude に送らないため）。
 * 同じ見出しの列が 2 つ以上あれば（フォームで種類を変えて作り直した質問・見本を読み込み直して足した質問）、
 * 1 つの列として読み、行ごとに右の空でない値を使う（cellOf）。
 */
import { ANSWER_COLUMN_MAX, SHEET_QUESTIONS, SHEET_RESULTS, SHEET_SAMPLES, SHEET_SETTINGS, SHEET_SUMMARY } from "./config.js";

export const ANSWER_WORDS = ["ご意見", "ご感想", "感想", "コメント", "ご要望", "要望", "自由", "気になった", "良かった", "理由", "レビュー", "口コミ", "本文"];
export const DATE_WORDS = ["タイムスタンプ", "日付", "日時", "投稿日"];
export const RATING_WORDS = ["満足度", "評価", "星", "点数", "おすすめ度"];
/** 「店」は「来店のきっかけ」のような質問を拾わないよう、見出しの終わりにあるときだけ店舗の列とみなす（storeLike_） */
export const STORE_WORDS = ["店舗", "院", "教室", "店名"];
export const PERSONAL_WORDS = ["お名前", "氏名", "メール", "電話", "住所"];
/** 設定の「日付の列」「評価の列」「店舗の列」にこう書くと、推測もせずに使わない */
export const NONE_WORD = "なし";
/** 「見本を読み込む」が前の質問を移すシートの名前の頭（「質問（前）」「質問（前 2）」…） */
export const OLD_QUESTIONS_PREFIX = "質問（前";

function columnText_(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function hasWord_(name, words) {
  for (let i = 0; i < words.length; i += 1) if (name.indexOf(words[i]) >= 0) return true;
  return false;
}

function storeLike_(name) {
  return hasWord_(name, STORE_WORDS) || /店$/.test(name);
}

/** 名前や連絡先の列か */
export function isPersonalColumn(name) {
  return hasWord_(columnText_(name), PERSONAL_WORDS);
}

/**
 * 見出しだけから推測する。返り値 { answers: [見出し], date, rating, store, reasons: [文] }（無い役は ""）。
 * reasons は、回答らしい見出しだが名前や連絡先を含むので外した列の説明。
 */
export function guessColumns(header) {
  const names = (Array.isArray(header) ? header : []).map(columnText_);
  const answers = [];
  const reasons = [];
  for (let i = 0; i < names.length; i += 1) {
    const name = names[i];
    if (name === "" || !hasWord_(name, ANSWER_WORDS) || answers.indexOf(name) >= 0) continue;
    if (isPersonalColumn(name)) {
      const reason = "「" + name + "」は名前や連絡先を含む列なので、回答の列にしません。";
      if (reasons.indexOf(reason) < 0) reasons.push(reason);
      continue;
    }
    if (answers.length < ANSWER_COLUMN_MAX) answers.push(name);
  }
  const taken = answers.slice();
  function first(test) {
    for (let i = 0; i < names.length; i += 1) {
      const name = names[i];
      if (name === "" || taken.indexOf(name) >= 0 || isPersonalColumn(name)) continue;
      if (test(name)) {
        taken.push(name);
        return name;
      }
    }
    return "";
  }
  const date = first((name) => hasWord_(name, DATE_WORDS));
  const rating = first((name) => hasWord_(name, RATING_WORDS));
  const store = first(storeLike_);
  return { answers: answers, date: date, rating: rating, store: store, reasons: reasons };
}

/**
 * 見出しで決まらないときの最後の手: skip（列の番号）と名前・連絡先の列を除き、2 行目以降の文字の長さの平均が
 * 最も長い列の番号。文字の値が 1 つも無ければ -1。
 */
export function guessByLength(header, dataRows, skip) {
  const names = (Array.isArray(header) ? header : []).map(columnText_);
  const rows = Array.isArray(dataRows) ? dataRows : [];
  let best = -1;
  let bestAverage = 0;
  for (let c = 0; c < names.length; c += 1) {
    if ((skip || []).indexOf(c) >= 0 || isPersonalColumn(names[c])) continue;
    let total = 0;
    let count = 0;
    for (let r = 0; r < rows.length; r += 1) {
      const value = Array.isArray(rows[r]) ? rows[r][c] : undefined;
      if (typeof value !== "string" || value.trim() === "") continue;
      total += value.trim().length;
      count += 1;
    }
    const average = count === 0 ? 0 : total / count;
    if (average > bestAverage) {
      best = c;
      bestAverage = average;
    }
  }
  return best;
}

/**
 * 回答シートの名前を決める。設定に名前があればそれ（無ければ ""）。
 * 空なら「フォームの回答」で始まるシート → 「回答」 → キットのシート（設定・分析結果・まとめ・質問・前の質問・見本の回答）を
 * 除いた左端のシート。
 */
export function pickAnswerSheet(config, sheetNames) {
  const names = Array.isArray(sheetNames) ? sheetNames : [];
  if (config.sheetName !== "") return names.indexOf(config.sheetName) >= 0 ? config.sheetName : "";
  for (let i = 0; i < names.length; i += 1) if (String(names[i]).indexOf("フォームの回答") === 0) return names[i];
  if (names.indexOf("回答") >= 0) return "回答";
  const kit = [SHEET_SETTINGS, SHEET_RESULTS, SHEET_SUMMARY, SHEET_QUESTIONS, SHEET_SAMPLES];
  for (let i = 0; i < names.length; i += 1) {
    const name = String(names[i]);
    if (kit.indexOf(name) < 0 && name.indexOf(OLD_QUESTIONS_PREFIX) !== 0) return names[i];
  }
  return "";
}

/** 見出しが name の列の番号（左から）。name が空なら [] */
function indicesOf_(names, name) {
  const out = [];
  if (name === "") return out;
  for (let i = 0; i < names.length; i += 1) if (names[i] === name) out.push(i);
  return out;
}

/** その行の、列（resolveColumns の返り値の 1 つ）の値。同じ見出しの列が 2 つ以上なら、右から見て最初の空でない値 */
export function cellOf(row, column) {
  const cells = Array.isArray(row) ? row : [];
  for (let i = column.indices.length - 1; i >= 0; i -= 1) {
    const value = cells[column.indices[i]];
    if (columnText_(value) !== "") return value;
  }
  return "";
}

/**
 * 設定と推測を合わせて、読む列を決める。values は回答シートの値（1 行目が見出し）。
 * 返り値 { sheetName, answers: [{ name, index, indices }], answerSource: "設定" | "見出しから推測" | "文字数から推測" | "",
 *          date, rating, store: { name, index, indices, guessed } | null, problems: [文], notes: [文] }
 * indices はその見出しの列すべて（左から）、index はその左端。値は cellOf で読む。
 */
export function resolveColumns(sheetName, values, config) {
  const header = Array.isArray(values) && values.length > 0 ? values[0] : [];
  const names = header.map(columnText_);
  const guess = guessColumns(header);
  const problems = [];
  const where = "「" + sheetName + "」シートの 1 行目";

  const answers = [];
  let answerSource = "";
  const taken = [];
  if (config.answerColumns.length > 0) {
    answerSource = "設定";
    for (let i = 0; i < config.answerColumns.length; i += 1) {
      const name = config.answerColumns[i];
      const indices = indicesOf_(names, name);
      if (indices.length === 0) problems.push("設定「回答の列」の「" + name + "」が、" + where + "にありません。見出しの名前をそのまま書くか、空にして見出しから推測させてください。");
      else if (isPersonalColumn(name)) problems.push("設定「回答の列」の「" + name + "」は名前や連絡先の列なので、回答の列にできません。自由記述の列の見出しを書いてください。");
      else if (taken.indexOf(name) < 0) {
        taken.push(name);
        answers.push({ name: name, index: indices[0], indices: indices });
      }
    }
  } else if (guess.answers.length > 0) {
    answerSource = "見出しから推測";
    for (let i = 0; i < guess.answers.length; i += 1) {
      const indices = indicesOf_(names, guess.answers[i]);
      answers.push({ name: guess.answers[i], index: indices[0], indices: indices });
    }
  }

  function role(settingValue, guessed, key) {
    if (settingValue === NONE_WORD) return null;
    if (settingValue !== "") {
      const indices = indicesOf_(names, settingValue);
      if (indices.length === 0) {
        problems.push("設定「" + key + "」の「" + settingValue + "」が、" + where + "にありません。見出しの名前をそのまま書くか、使わないときは「" + NONE_WORD + "」と書いてください。");
        return null;
      }
      return { name: settingValue, index: indices[0], indices: indices, guessed: false };
    }
    if (guessed === "") return null;
    const indices = indicesOf_(names, guessed);
    return { name: guessed, index: indices[0], indices: indices, guessed: true };
  }
  const date = role(config.dateColumn, guess.date, "日付の列");
  const rating = role(config.ratingColumn, guess.rating, "評価の列");
  const store = role(config.storeColumn, guess.store, "店舗の列");

  if (answers.length === 0 && config.answerColumns.length === 0) {
    let skip = [];
    for (const column of [date, rating, store]) if (column !== null) skip = skip.concat(column.indices);
    const index = guessByLength(header, values.slice(1), skip);
    if (index >= 0) {
      answerSource = "文字数から推測";
      // 見出しが空の列は、ほかの空の見出しの列とまとめない
      const indices = names[index] === "" ? [index] : indicesOf_(names, names[index]);
      answers.push({ name: names[index], index: indices[0], indices: indices });
    } else {
      problems.push("「" + sheetName + "」シートに回答の列が見つかりません。設定「回答の列」に、自由記述の列の見出しを書いてください。");
    }
  }
  return { sheetName: sheetName, answers: answers, answerSource: answerSource, date: date, rating: rating, store: store, problems: problems, notes: guess.reasons };
}
