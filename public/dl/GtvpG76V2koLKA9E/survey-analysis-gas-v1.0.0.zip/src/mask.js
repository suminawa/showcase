/**
 * Claude に送る前の伏せ字（純粋）。替えるのはメールアドレスと電話番号だけ。人の名前は伏せない（設計書 §7-4）。
 * 日付（2026-09-30）・時刻・金額（3,000円）・郵便番号（123-4567）は替えない。
 */

export const MAIL_MARK = "〔メール〕";
export const PHONE_MARK = "〔電話〕";

const EMAIL_PATTERN = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
/** 前後が数字でないところで、0 か +81 で始まる番号。桁数（10〜11）は置き換えるときに数える */
const PHONE_PATTERN = /(?<!\d)(\+81[-\s]?|0)\d{1,4}[-\s(]?\d{1,4}[-\s)]?\d{3,4}(?!\d)/g;

/** 全角の数字・＋・＠・ハイフンの仲間を半角に。数字にはさまれた長音「ー」もハイフンにする */
export function toHalfWidth(text) {
  return String(text)
    .replace(/[０-９]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/＋/g, "+")
    .replace(/＠/g, "@")
    .replace(/[－‐‑–—−]/g, "-")
    .replace(/(\d)ー(?=\d)/g, "$1-");
}

/** 番号の数字の桁（+81 は先頭の 0 に数え直す） */
function phoneDigits_(matched) {
  const digits = matched.replace(/\D/g, "");
  return matched.indexOf("+81") === 0 ? digits.length - 1 : digits.length;
}

export function maskText(text) {
  return toHalfWidth(text)
    .replace(EMAIL_PATTERN, MAIL_MARK)
    .replace(PHONE_PATTERN, (matched) => {
      const digits = phoneDigits_(matched);
      return digits === 10 || digits === 11 ? PHONE_MARK : matched;
    });
}
