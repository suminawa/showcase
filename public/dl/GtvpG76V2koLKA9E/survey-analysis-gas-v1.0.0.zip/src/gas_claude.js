/**
 * Messages API を UrlFetchApp で呼ぶ。429 / 5xx / 529 は 2 秒待って 1 回だけやり直す。
 * 接続できない（時間切れ・名前が引けないなど）ときは muteHttpExceptions でも例外になるので、status 0 の ClaudeError にする。
 * 鍵はここに渡ってくるだけで、ログにもエラー文にも出さない。
 * 元: AI 問い合わせ整理キット 1.0.0 の src/gas_claude.js。変えたのは messageFor_ の文（401 はキーを貼り直す案内、
 * 429 / 5xx は「ここで止めました」）と、月の上限額（400 の本文に Anthropic の文面 credit balance / usage limit / spend limit）の見分け、接続できないときの文。
 */
import { ANTHROPIC_VERSION, MESSAGES_URL } from "./prompt.js";

const RETRY_WAIT_MS = 2000;
const RETRYABLE = [408, 409, 429, 500, 502, 503, 504, 529];

export class ClaudeError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ClaudeError";
    this.status = status;
    /** Console で決めた月の上限額に達した（400 の一種） */
    this.spendLimit = false;
  }
}

export function isRetryable_(status) {
  return RETRYABLE.indexOf(status) >= 0;
}

function messageFor_(status) {
  if (status === 401) return "API キーが受け付けられませんでした。メニュー「初期化」を押すと、キーを貼る欄が出ます。";
  if (status === 403) return "この API キーでは使えない機能です。Anthropic Console の設定を確かめてください。";
  if (status === 400 || status === 404) return "リクエストが受け付けられませんでした（" + status + "）。「モデル」の設定を確かめてください。";
  if (isRetryable_(status)) return "API が混み合っているため、ここで止めました。数分おいて「分析する」を押すと続きから分析します。";
  return "API から " + status + " が返りました。「モデル」の設定と Anthropic Console の状態を確かめてください。";
}

const SPEND_LIMIT_PATTERN = /credit balance|usage limit|spend(ing)? limit/i;
const SPEND_LIMIT_TEXT = "Anthropic Console で決めた月の上限額に達しました。Console で上限を上げるか、来月までお待ちください。";

/** 接続できなかったときの status */
export const UNREACHABLE = 0;

function fetch_(apiKey, body) {
  try {
    return UrlFetchApp.fetch(MESSAGES_URL, {
      method: "post",
      contentType: "application/json",
      headers: { "x-api-key": apiKey, "anthropic-version": ANTHROPIC_VERSION },
      payload: JSON.stringify(body),
      muteHttpExceptions: true,
    });
  } catch (error) {
    // 例外の文には URL しか入らないが、念のため文面はこちらで決める（鍵を出さない）
    throw new ClaudeError("Claude の API に接続できませんでした（時間切れか、通信の不調です）。少しおいてもう一度お試しください。", UNREACHABLE);
  }
}

/** 返り値 { text, usage, stopReason }。text は最初の text ブロック（無ければ ""） */
export function callClaude_(apiKey, body) {
  let response = fetch_(apiKey, body);
  let status = response.getResponseCode();
  if (isRetryable_(status)) {
    Utilities.sleep(RETRY_WAIT_MS);
    response = fetch_(apiKey, body);
    status = response.getResponseCode();
  }
  if (status < 200 || status >= 300) {
    // 上限額は Anthropic の文面だけで見分ける。「limit」を含むだけのふつうの 400（文脈の長さなど）は、その回を飛ばす扱い
    if (status === 400 && SPEND_LIMIT_PATTERN.test(String(response.getContentText()))) {
      const limited = new ClaudeError(SPEND_LIMIT_TEXT, status);
      limited.spendLimit = true;
      throw limited;
    }
    throw new ClaudeError(messageFor_(status), status);
  }
  let json;
  try {
    json = JSON.parse(response.getContentText());
  } catch (error) {
    // 2xx なのに JSON でない（途中の proxy の応答など）。次回にやり直す扱いにする
    throw new ClaudeError("API の応答を読み取れませんでした。少しおいてもう一度お試しください。", 502);
  }
  if (json === null || typeof json !== "object") {
    throw new ClaudeError("API の応答を読み取れませんでした。少しおいてもう一度お試しください。", 502);
  }
  let text = "";
  const content = Array.isArray(json.content) ? json.content : [];
  for (let i = 0; i < content.length; i += 1) {
    if (content[i].type === "text") {
      text = String(content[i].text);
      break;
    }
  }
  return { text: text, usage: json.usage ? json.usage : null, stopReason: json.stop_reason ? String(json.stop_reason) : "" };
}
