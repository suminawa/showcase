/**
 * スクリプト プロパティに置く覚え書き: API キー・401 の印・1 日の件数・今月のトークン数と分析した件数・エラー通知の日付・
 * 最後にフォームを作ったときの質問シートの指紋。
 * 回答の中身は何も残さない。
 * 元: AI 問い合わせ整理キット 1.0.0 の src/gas_store.js（withLock_ と件数・利用の読み書き）。キーの保存と 401 の印を足した。
 */
import { emptyUsage } from "./usage.js";

/** 同時に走った実行を待たせる時間（トリガーとメニューが重なったとき） */
const LOCK_WAIT_MS = 30000;
const API_KEY_PROPERTY = "ANTHROPIC_API_KEY";
const KEY_REJECTED_KEY = "keyRejected";
const LAST_ERROR_NOTICE_KEY = "lastErrorNotice";
/** 最後にフォームを作ったときの質問シートの指紋（直したのに反映していないことを「設定を確かめる」で知らせる） */
const FORM_SOURCE_HASH_KEY = "formSourceHash";

function props_() {
  return PropertiesService.getScriptProperties();
}

/**
 * action を 1 つずつ順番に実行する（1 日の件数と分析結果の行が重ならないように）。
 * 待っても取れなければ { busy: true } を返す（waitLock は tryLock と違って例外を投げる）。
 */
export function withLock_(action) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(LOCK_WAIT_MS);
  } catch (error) {
    Logger.log("お客さまアンケート: ほかの処理（分析・まとめ・フォームの作成）が動いているため、今回は何もしません");
    return { busy: true };
  }
  try {
    return action();
  } finally {
    lock.releaseLock();
  }
}

/** 鍵はここからだけ読む。無ければ空 */
export function readApiKey_() {
  const raw = props_().getProperty(API_KEY_PROPERTY);
  return raw ? String(raw).trim() : "";
}

/** 初期化の欄に貼られたキーを保存し、401 の印を消す（2xx が返ったときも clearKeyRejected_ で消す） */
export function saveApiKey_(key) {
  props_().setProperty(API_KEY_PROPERTY, String(key).trim());
  props_().deleteProperty(KEY_REJECTED_KEY);
}

export function readKeyRejected_() {
  return props_().getProperty(KEY_REJECTED_KEY) === "true";
}

export function markKeyRejected_() {
  props_().setProperty(KEY_REJECTED_KEY, "true");
}

/** Claude から答えが返ったら 401 の印を消す（キーをスクリプト プロパティで入れ替えたときも、古い 401 を言い続けないように） */
export function clearKeyRejected_() {
  if (props_().getProperty(KEY_REJECTED_KEY) !== null) props_().deleteProperty(KEY_REJECTED_KEY);
}

/** 同じエラーを 1 日に何通も送らないための覚え書き（「日付 + エラー文の先頭」） */
export function readLastErrorNotice_() {
  const raw = props_().getProperty(LAST_ERROR_NOTICE_KEY);
  return raw ? String(raw) : "";
}

export function saveLastErrorNotice_(notice) {
  props_().setProperty(LAST_ERROR_NOTICE_KEY, String(notice));
}

function readNumber_(key) {
  const number = Number(props_().getProperty(key));
  return Number.isFinite(number) ? number : 0;
}

export function readDailyCount_(dateKey) {
  return readNumber_("count:" + dateKey);
}

export function saveDailyCount_(dateKey, count) {
  props_().setProperty("count:" + dateKey, String(count));
}

/** 今月分析した回答の数（「今月の AI 利用」に出す） */
export function readMonthAnalyzed_(monthKey) {
  return readNumber_("analyzed:" + monthKey);
}

export function saveMonthAnalyzed_(monthKey, count) {
  props_().setProperty("analyzed:" + monthKey, String(count));
}

export function readMonthUsage_(monthKey) {
  const raw = props_().getProperty("usage:" + monthKey);
  if (!raw) return emptyUsage();
  try {
    const parsed = JSON.parse(raw);
    const base = emptyUsage();
    for (const key in base) {
      if (Object.prototype.hasOwnProperty.call(parsed, key)) base[key] = Number(parsed[key]) || 0;
    }
    return base;
  } catch (error) {
    return emptyUsage();
  }
}

export function saveMonthUsage_(monthKey, total) {
  props_().setProperty("usage:" + monthKey, JSON.stringify(total));
}

export function readFormSourceHash_() {
  const raw = props_().getProperty(FORM_SOURCE_HASH_KEY);
  return raw ? String(raw) : "";
}

export function saveFormSourceHash_(hash) {
  props_().setProperty(FORM_SOURCE_HASH_KEY, String(hash));
}
