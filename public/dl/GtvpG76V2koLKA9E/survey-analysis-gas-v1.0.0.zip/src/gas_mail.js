/**
 * まとめをメールで送る。1 日の上限に達していたら送らない。
 * 元: フォーム受付 GAS キット 1.1.0 の src/gas_mail.js の remainingQuota_。
 */

/** 今日あと送れるメールの数。読めなければ 1 通ぶんは残っているものとして進む */
export function remainingQuota_() {
  try {
    return MailApp.getRemainingDailyQuota();
  } catch (error) {
    Logger.log("お客さまアンケート: 残りの送信可能数を読めませんでした: " + error);
    return 1;
  }
}

/**
 * まとめのメールを 1 通（宛先はカンマ区切りでまとめて）。mailTo が空なら自分に。
 * 送れたら true、上限か失敗で送れなかったら false。
 */
export function sendDigestMail_(mailTo, subject, body) {
  try {
    const to = mailTo.length > 0 ? mailTo.join(",") : Session.getEffectiveUser().getEmail();
    if (to === "") return false;
    if (remainingQuota_() < (mailTo.length > 0 ? mailTo.length : 1)) {
      Logger.log("お客さまアンケート: MailApp の 1 日の上限に達したため、まとめのメールを送りませんでした");
      return false;
    }
    MailApp.sendEmail({ to: to, subject: subject, body: body });
    return true;
  } catch (error) {
    Logger.log("お客さまアンケート: まとめのメールを送れませんでした: " + error);
    return false;
  }
}
