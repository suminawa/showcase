/**
 * Google フォームを作る・直す（FormApp）。何をするかは form_plan.js が決め、ここはフォームに当てるだけ。
 * 触るのは設定の「フォーム ID」のフォーム 1 つだけで、ほかのフォームは開かない。
 * メールアドレスを集めない・ログインを求めない（設計書 §3-5・§7-3。Workspace のアカウントでも組織の外の人が答えられるように）。
 */

/** 回答のシートが見つからないときに、探し直す前に待つ時間 */
const DESTINATION_RETRY_MS = 2000;
/** form_plan.js の ITEM_KINDS と同じ名前 */
const FORM_KINDS = ["MULTIPLE_CHOICE", "CHECKBOX", "SCALE", "PARAGRAPH_TEXT"];

/** フォームの質問の型の名前（FORM_KINDS のどれか。ほかの型ならその名前） */
function kindName_(item) {
  const type = item.getType();
  for (let i = 0; i < FORM_KINDS.length; i += 1) if (type === FormApp.ItemType[FORM_KINDS[i]]) return FORM_KINDS[i];
  return String(type);
}

/**
 * 設定の「フォーム ID」のフォームの様子。返り値 { state: "none" | "ok" | "missing" | "elsewhere", form, linked,
 * accepting, items: [{ id, title, kind }], responses }。
 * elsewhere は、ほかのスプレッドシートにつながっているフォーム（スプレッドシートを丸ごとコピーした場合）。
 * 送り先がまだ無いフォームは ok（linked: false）として、このスプレッドシートにつなぎ直す（2 つ目を作らない）。
 * items は getItems() の一覧（null は来ない）。質問シートの項目 ID がここに無ければ（フォームの側で消した）、planForm が
 * 新しく作る（create）ので、getItemById の null は読んでから当てるまでに消えたときだけ applyPlan_ で起きる。
 */
export function readFormState_(formId) {
  const empty = { state: "none", form: null, linked: false, accepting: true, items: [], responses: 0 };
  if (formId === "") return empty;
  let form;
  try {
    form = FormApp.openById(formId);
  } catch (error) {
    Logger.log("お客さまアンケート: フォームを開けませんでした: " + error);
    return Object.assign({}, empty, { state: "missing" });
  }
  let destination = "";
  try {
    destination = String(form.getDestinationId());
  } catch (error) {
    destination = "";
  }
  if (destination !== "" && destination !== SpreadsheetApp.getActiveSpreadsheet().getId()) return Object.assign({}, empty, { state: "elsewhere", form: form });
  const items = form.getItems().map((item) => ({ id: String(item.getId()), title: item.getTitle(), kind: kindName_(item) }));
  return { state: "ok", form: form, linked: destination !== "", accepting: form.isAcceptingResponses(), items: items, responses: form.getResponses().length };
}

/**
 * 2025 年からのフォームには「公開」の段階がある。関数がある環境だけで公開にする。
 * 関数があっても古いフォームでは例外になることがあるので、そのときは公開の設定をせずに進める（それまでと同じ動き）
 */
function publish_(form) {
  if (typeof form.setPublished !== "function") return;
  try {
    form.setPublished(true);
  } catch (error) {
    Logger.log("お客さまアンケート: フォームを公開の状態にできませんでした（古い形式のフォーム）: " + error);
  }
}

/**
 * 作るときも直すときも、毎回そろえる設定。texts は form_plan.js の formTexts。
 * 公開してから回答の受け付けをオンにする（公開の段階があるフォームは、公開するまで回答を受け付けない）。
 */
export function applyFormSettings_(form, texts) {
  form.setTitle(texts.title);
  form.setDescription(texts.description);
  form.setConfirmationMessage(texts.confirmation);
  form.setCollectEmail(false);
  requireNoLogin_(form);
  form.setLimitOneResponsePerUser(false);
  form.setAllowResponseEdits(false);
  form.setShowLinkToRespondAgain(false);
  publish_(form);
  form.setAcceptingResponses(true);
}

/**
 * Workspace のアカウントでは、組織の中の人だけが答えられる設定が既定で入ることがある。お店のお客さまが
 * ログインなしで答えられるように外す。個人の Google アカウントでは使えない設定で、例外になるので何もしない
 */
function requireNoLogin_(form) {
  try {
    form.setRequireLogin(false);
  } catch (error) {
    // 個人のアカウント（組織の制限が無い）。そのままで、だれでも答えられる
  }
}

/** 質問を足す。返り値は種類つきの質問（ScaleItem など）で、as…Item() も moveItem も通らない */
function addItem_(form, type) {
  if (type === "複数") return form.addCheckboxItem();
  if (type === "5 段階") return form.addScaleItem();
  if (type === "自由記述") return form.addParagraphTextItem();
  return form.addMultipleChoiceItem();
}

/** 質問の中身を書く。item は汎用の Item（getItemById で取ったもの）。返り値は、前にあった選択肢を消したか */
function setQuestion_(item, question) {
  const type = question.type;
  const typed = type === "複数" ? item.asCheckboxItem() : type === "5 段階" ? item.asScaleItem() : type === "自由記述" ? item.asParagraphTextItem() : item.asMultipleChoiceItem();
  typed.setTitle(question.title);
  typed.setHelpText(question.help);
  typed.setRequired(question.required);
  if (type === "5 段階") {
    typed.setBounds(1, 5);
    typed.setLabels(question.labels.length === 2 ? question.labels[0] : "", question.labels.length === 2 ? question.labels[1] : "");
    return false;
  }
  if (type === "自由記述") return false;
  const before = typed.getChoices().map((choice) => choice.getValue());
  typed.setChoiceValues(question.choices);
  return before.some((value) => question.choices.indexOf(value) < 0);
}

/**
 * planForm の結果をフォームに当てる。返り値 { choicesRemoved }。
 * 種類が違う質問（recreate）は消して作り直す（Forms は質問の種類を変えられない）。最後に並びの順へ並べ直す。
 * onId(row, id) は質問を足すたびに、中身を書く前に呼ぶ（途中で止まっても、足した質問の項目 ID が質問シートに残り、
 * 次に押したときに同じ質問をもう 1 つ足さないように）。
 * 項目 ID の質問がフォームに無いとき（読んだあとにフォームの側で消された）は、新しく作る。
 */
export function applyPlan_(form, plan, onId) {
  const built = [];
  let choicesRemoved = false;
  for (let i = 0; i < plan.items.length; i += 1) {
    const entry = plan.items[i];
    let item = entry.action === "create" ? null : form.getItemById(Number(entry.itemId));
    if (item !== null && entry.action === "update") {
      if (setQuestion_(item, entry.question)) choicesRemoved = true;
    } else {
      if (item !== null) form.deleteItem(item);
      // add…Item() の返す種類つきの質問には as…Item() が無く、moveItem にも渡せないので、汎用の Item を ID で取り直す
      item = form.getItemById(addItem_(form, entry.question.type).getId());
      onId(entry.question.row, item.getId());
      setQuestion_(item, entry.question);
    }
    built.push(item);
  }
  for (let i = 0; i < plan.remove.length; i += 1) {
    const item = form.getItemById(Number(plan.remove[i].id));
    if (item !== null) form.deleteItem(item);
  }
  for (let i = 0; i < built.length; i += 1) form.moveItem(built[i], i);
  return { choicesRemoved: choicesRemoved };
}

/** このフォームの回答が溜まるシートの名前（「フォームの回答 1」とは限らないので、getFormUrl で探す）。無ければ "" */
function findResponseSheet_(book, form) {
  const sheets = book.getSheets();
  const id = String(form.getId());
  const urls = [form.getEditUrl(), form.getPublishedUrl()];
  for (let i = 0; i < sheets.length; i += 1) {
    const url = sheets[i].getFormUrl();
    if (url === null || url === undefined) continue;
    // getFormUrl の形は版で違いうるので、フォーム ID を含むか、編集・回答の URL と同じなら、このフォームのシートとみなす
    if (String(url).indexOf(id) >= 0 || urls.indexOf(String(url)) >= 0) return sheets[i].getName();
  }
  return "";
}

/**
 * 回答の送り先をこのスプレッドシートにして、回答のシートの名前を返す（見つからなければ ""）。
 * linked が true（すでにつながっている）なら setDestination は呼ばない（2 枚目の回答シートを作らないため）。
 */
export function linkDestination_(form, linked) {
  const book = SpreadsheetApp.getActiveSpreadsheet();
  if (!linked) form.setDestination(FormApp.DestinationType.SPREADSHEET, book.getId());
  SpreadsheetApp.flush();
  let name = findResponseSheet_(book, form);
  if (name === "") {
    Utilities.sleep(DESTINATION_RETRY_MS);
    SpreadsheetApp.flush();
    name = findResponseSheet_(book, form);
  }
  return name;
}

/** 答える人に渡す URL（forms.gle の短縮 URL。短縮に失敗したら長い URL のまま） */
export function shortUrl_(form) {
  const url = form.getPublishedUrl();
  try {
    return form.shortenFormUrl(url);
  } catch (error) {
    Logger.log("お客さまアンケート: URL を短くできませんでした: " + error);
    return url;
  }
}

/** 設定の「フォーム ID」が無ければ新しく作る */
export function createForm_(title) {
  return FormApp.create(title);
}
