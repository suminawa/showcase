/**
 * 回答シートの行を、分析に回す 1 件ずつの回答にする（純粋）。
 * 各行のキーは「日付 + 回答の値」の指紋（FNV-1a 32bit）。行を並べ替えても、同じ回答を 2 回分析しない。
 * キーには見出しを入れない（質問の文を直しても・回答の列を足しても、前の回答のキーが変わって送り直しにならないように）。
 */
import { cellOf } from "./columns.js";
import { toDateKey } from "./dates.js";
import { maskText, toHalfWidth } from "./mask.js";

/** 前後の空白と句読点を落として、これに当たれば「回答なし」 */
export const EMPTY_WORDS = ["特になし", "なし", "無し", "ない", "とくになし", "-", "ー", "n/a", "none"];
/** 分析結果の「回答（抜粋）」の長さ */
export const EXCERPT_LENGTH = 60;

function responseText_(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

export function isEmptyAnswer(value) {
  const text = responseText_(value)
    .replace(/^[\s。、．.，,！!？?]+|[\s。、．.，,！!？?]+$/g, "")
    .toLowerCase();
  if (text.length <= 1) return true;
  return EMPTY_WORDS.indexOf(text) >= 0;
}

/** FNV-1a 32bit を 16 進 8 桁に。"k" を付けて分析結果の「キー」にする */
export function responseKey(dateKey, text) {
  const source = String(dateKey) + "\n" + String(text);
  let hash = 0x811c9dc5;
  for (let i = 0; i < source.length; i += 1) {
    hash ^= source.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return "k" + ("0000000" + hash.toString(16)).slice(-8);
}

/**
 * 回答の列が 1 つなら値そのまま、2 つ以上なら「【見出し】値」を改行でつなぐ（空の列は入れない）。
 * labeled を渡すとそれに従う（回答の列が 2 つある表で、片方だけを送るときも見出しを付けるため）。
 */
export function joinAnswers(parts, labeled) {
  const withLabel = labeled === undefined ? parts.length > 1 : labeled;
  const filled = parts.filter((part) => responseText_(part.value) !== "");
  if (!withLabel) return filled.map((part) => responseText_(part.value)).join("\n");
  return filled.map((part) => "【" + part.name + "】" + responseText_(part.value)).join("\n");
}

/** 評価のセルを数に。「5」「５」「4 - 満足」は数、範囲（0〜評価の最大）の外と数でないものは "" */
export function ratingOf(value, ratingMax) {
  let number;
  if (typeof value === "number") number = value;
  else {
    const matched = toHalfWidth(responseText_(value)).match(/^(\d+(?:\.\d+)?)/);
    number = matched ? Number(matched[1]) : NaN;
  }
  if (!Number.isFinite(number) || number < 0 || number > ratingMax) return "";
  return number;
}

function blankRow_(row) {
  const cells = Array.isArray(row) ? row : [];
  for (let i = 0; i < cells.length; i += 1) if (responseText_(cells[i]) !== "") return false;
  return true;
}

/**
 * キーにする本文: 回答の列の値を、回答シートの左からの順に（設定「回答の列」の順ではなく）改行でつなぐ。空の値と見出しは入れない。
 * 回答の列が 1 つなら値そのもの（見出しを付けていたころと同じキーになる）。
 */
function keyText_(row, answers) {
  const ordered = answers.slice().sort((a, b) => a.index - b.index);
  const values = [];
  for (let i = 0; i < ordered.length; i += 1) {
    const value = responseText_(cellOf(row, ordered[i]));
    if (value !== "") values.push(value);
  }
  return values.join("\n");
}

/**
 * values: 回答シートの値（1 行目が見出し）。columns: columns.js の resolveColumns の返り値。
 * 返り値 [{ key, row, date, rating, store, text, empty }]（row はシートの行番号）。text は Claude に送る形（列が 2 つ以上なら見出しつき）。
 * 日付の列が無いときは、キーに日付を入れず（分析した日で変わらないように）、date は todayKey。
 * 同じ日に同じ回答が 2 つあれば、2 つ目からはキーに「#2」などを足して別の回答として数える。
 */
export function toResponses(values, columns, config, todayKey) {
  const out = [];
  const seen = {};
  const rows = Array.isArray(values) ? values : [];
  for (let i = 1; i < rows.length; i += 1) {
    const row = Array.isArray(rows[i]) ? rows[i] : [];
    if (blankRow_(row)) continue;
    const parts = columns.answers.map((column) => ({ name: column.name, value: responseText_(cellOf(row, column)) }));
    const filled = parts.filter((part) => !isEmptyAnswer(part.value));
    const raw = joinAnswers(parts);
    const keyText = keyText_(row, columns.answers);
    const dateValue = columns.date === null ? null : toDateKey(cellOf(row, columns.date));
    const keyDate = columns.date === null ? "" : dateValue === null ? "" : dateValue;
    const base = responseKey(keyDate, keyText);
    seen[base] = (seen[base] || 0) + 1;
    out.push({
      key: seen[base] === 1 ? base : responseKey(keyDate, keyText + "#" + seen[base]),
      row: i + 1,
      date: dateValue === null ? todayKey : dateValue,
      rating: columns.rating === null ? "" : ratingOf(cellOf(row, columns.rating), config.ratingMax),
      store: columns.store === null ? "" : responseText_(cellOf(row, columns.store)),
      text: filled.length === 0 ? raw : joinAnswers(filled, parts.length > 1),
      empty: filled.length === 0,
    });
  }
  return out;
}

/** Claude に送る形: 伏せ字（設定が TRUE のとき）→ 回答の上限文字数で切る */
export function sendableText(text, config) {
  const masked = config.mask ? maskText(text) : String(text);
  return masked.slice(0, config.answerLimit);
}

/** 分析結果の「回答（抜粋）」。伏せ字にしたあとの先頭 60 字 */
export function excerptOf(text, config) {
  return sendableText(text, config).slice(0, EXCERPT_LENGTH);
}

/**
 * 分析に回す回答。index は rows.js の indexResults の返り値。
 * キーが分析結果に無いもの（overwriteRow: null）と、「やり直す」に ✓ のある行（overwriteRow: その行番号）。
 */
export function selectPending(responses, index) {
  const out = [];
  for (let i = 0; i < responses.length; i += 1) {
    const found = Object.prototype.hasOwnProperty.call(index.keys, responses[i].key) ? index.keys[responses[i].key] : null;
    if (found === null) out.push({ response: responses[i], overwriteRow: null });
    else if (found.redo === true) out.push({ response: responses[i], overwriteRow: found.row });
  }
  return out;
}

/** size 件ずつに分ける */
export function batches(items, size) {
  const out = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}
