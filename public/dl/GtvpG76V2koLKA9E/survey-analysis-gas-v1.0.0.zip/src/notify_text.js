/**
 * 人に見せる文（純粋）: 週 1 回の通知の本文とメールの件名、エラーの通知、「分析する」「まとめを作る」の alert。
 * 通知には回答の本文と要約を載せない（Slack などスプレッドシートの外に出るため）。載せるのは数・要望のまとまりの名前・今週の 3 つだけ。
 */
import { SUMMARY_FAILED_TEXT } from "./summary_prompt.js";

function periodLabel_(from, to) {
  return from + "〜" + (from.slice(0, 4) === to.slice(0, 4) ? to.slice(5) : to);
}

function shopName_(config) {
  return config.storeName === "" ? "当店" : config.storeName;
}

export function digestSubject(agg, config) {
  return "【" + shopName_(config) + "】お客さまの声のまとめ（" + periodLabel_(agg.from, agg.to) + "）";
}

/**
 * 週 1 回の通知。sheetUrl は「まとめ」シートの URL。pending はまだ分析していない回答の件数（省くと 0）。
 * 週 1 回の分析は 3 分で切り上げるので、回答の多いお店では分析が追いつかない。そのときに件数を知らせる
 */
export function buildDigestText(agg, summary, config, sheetUrl, pending) {
  const lines = [digestSubject(agg, config)];
  const parts = ["回答 " + agg.total + " 件"];
  if (agg.negativeRate !== null) parts.push("悪いの割合 " + agg.negativeRate + "%" + (agg.previous === null ? "" : "（前の期間 " + agg.previous.negativeRate + "%）"));
  if (agg.ratingAverage !== null) parts.push("評価の平均 " + agg.ratingAverage);
  lines.push(parts.join("｜"));
  const top = agg.categories
    .filter((category) => category.count > 0)
    .map((category, i) => ({ category: category, i: i }))
    .sort((a, b) => (b.category.count !== a.category.count ? b.category.count - a.category.count : a.i - b.i))
    .slice(0, 3);
  if (top.length > 0) lines.push("多い分類: " + top.map((entry) => entry.category.name + " " + entry.category.count + " 件").join("・"));
  if (summary.themes.length > 0) lines.push("多い要望: " + summary.themes.slice(0, 3).map((theme) => theme.title + "（" + theme.count + " 件）").join("・"));
  lines.push("今週の 3 つ:");
  if (summary.actions.length === 0) lines.push(summary.actionsNote);
  for (let i = 0; i < summary.actions.length; i += 1) lines.push(i + 1 + ". " + summary.actions[i].text);
  lines.push("すぐに読んでほしい回答: " + agg.attention.length + " 件");
  if (pending > 0) lines.push("まだ分析していない回答が " + pending + " 件あります。続きは次の実行で分析します（毎日分けて分析するには、README の「週に 1 回送る」をご覧ください）。");
  lines.push("くわしくは「まとめ」シートをご覧ください: " + sheetUrl);
  return lines.join("\n");
}

/** トリガーからの実行が失敗したときの通知 */
export function buildErrorText(error, stamp) {
  const detail = error && error.message ? error.message : String(error);
  return "【お客さまアンケート｜エラー】" + stamp + "\n自動の実行が止まりました: " + detail + "\nメニュー「設定を確かめる」で、直すところを確かめてください。";
}

/** 送れなかった宛先ごとの 1 文 */
export function deliveryFailureLines(failed) {
  return failed.map((target) => {
    if (target === "mail") return "mail には送れませんでした。「送り先メール」と、今日の送信数の上限をご確認ください。";
    if (target === "line") return "line には送れませんでした。LINE のチャネルアクセストークンと送信先 ID をご確認ください。";
    return target + " には送れませんでした。Webhook URL をご確認ください。";
  });
}

/**
 * 「分析する」の alert。stats = { analyzed, empty, remaining, stop: "" | "time" | "daily" | "error",
 *   perDay, skipped, skipMessage, errorMessage, samples }
 */
export function analysisReport(stats) {
  const lines = [];
  if (stats.analyzed === 0 && stats.remaining === 0 && stats.stop === "") return "新しい回答はありません。分析結果はそろっています。";
  if (stats.analyzed > 0 || stats.stop === "") {
    lines.push((stats.samples ? "見本の答えで " : "新しく ") + stats.analyzed + " 件を分析しました" + (stats.empty > 0 ? "（回答なし " + stats.empty + " 件を含みます）" : "") + "。残り " + stats.remaining + " 件。");
  }
  if (stats.stop === "time") lines.push("残り " + stats.remaining + " 件は、もう一度「分析する」を押すと続きから分析します。");
  if (stats.stop === "daily") lines.push("今日の上限（" + stats.perDay + " 件）に達しました。残りは明日「分析する」を押すと続きから分析します。");
  if (stats.stop === "error") lines.push(stats.errorMessage);
  if (stats.skipped > 0) lines.push(stats.skipMessage + stats.skipped + " 件は次回もう一度試します。");
  return lines.join("\n");
}

/** 「まとめを作る」の alert。pending は未分析の件数、failed は送れなかった宛先 */
export function summaryReport(agg, summary, pending, failed) {
  const lines = ["まとめを作りました（回答 " + agg.total + " 件、要望のまとまり " + summary.themes.length + " 個）。「まとめ」シートをご覧ください。"];
  if (summary.actionsNote === SUMMARY_FAILED_TEXT) lines.push(SUMMARY_FAILED_TEXT);
  if (pending > 0) lines.push("まだ分析していない回答が " + pending + " 件あります。先に「分析する」を押すと、まとめに入ります。");
  return lines.concat(deliveryFailureLines(failed)).join("\n");
}
