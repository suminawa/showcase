/**
 * スプレッドシートを読み書きする。書くのはキットが作ったシート（設定・分析結果・まとめ・質問・見本の回答）だけで、
 * 回答シートには書かない。初期化では、足りないシート・見出し・設定の行だけを足す。
 * readSetupSnapshot_・initPermissionError_・settingCell_・squaredRows_・applyInit_ の元: 期限アラート GAS キット 1.1.0 の src/gas_sheets.js。
 */
import { ConfigError, SHEET_QUESTIONS, SHEET_RESULTS, SHEET_SAMPLES, SHEET_SETTINGS, SHEET_SUMMARY, configKeyOf } from "./config.js";
import { sheetNamesFor } from "./check.js";
import { mergeHeader } from "./rows.js";
import { initFailureText } from "./setup.js";

/** 書き込みの権限が無いときに出す 1 文 */
const PERMISSION_TEXT = "このスプレッドシートの編集権限がありません。所有者に共有の設定（編集者）を依頼してください";
const NOT_WRITABLE =
  "「分析結果」シートに書き込めません（シートかセルが保護されているか、このアカウントに編集の権限がありません）。保護を外すか、スプレッドシートの持ち主のアカウントで動かしてください。";
const HEADER_COLOR = "#eeeeee";
const WORSE_COLOR = "#f4cccc";

function book_() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

/** シートの値。1 行も無ければ [] */
function sheetValues_(sheet) {
  return sheet.getLastRow() === 0 ? [] : sheet.getDataRange().getValues();
}

export function hasSheet_(name) {
  return book_().getSheetByName(name) !== null;
}

/** 設定シートの値（無ければ []）。エラー通知の宛先を、設定が壊れていても読むために使う */
export function readSettingsValues_() {
  const sheet = book_().getSheetByName(SHEET_SETTINGS);
  return sheet ? sheetValues_(sheet) : [];
}

/**
 * 初期化・設定を確かめる・分析する・まとめを作る が読むもの。読むだけで、何も書かない。
 * sheets には「設定」「分析結果」「質問」と回答シートのうち、あるものだけを載せる。
 * hasTrigger・apiKeyTail・keyRejected・usage・form・formSourceHash は gas_main.js が埋める。
 */
export function readSetupSnapshot_(today) {
  const book = book_();
  const all = book.getSheets();
  const names = [];
  for (let i = 0; i < all.length; i += 1) names.push(all[i].getName());
  const sheets = {};
  const wanted = [SHEET_SETTINGS, SHEET_RESULTS, SHEET_QUESTIONS];
  for (let i = 0; i < wanted.length; i += 1) {
    const sheet = book.getSheetByName(wanted[i]);
    if (sheet) sheets[wanted[i]] = sheetValues_(sheet);
  }
  const answers = sheetNamesFor(sheets[SHEET_SETTINGS], names);
  for (let i = 0; i < answers.length; i += 1) {
    const sheet = book.getSheetByName(answers[i]);
    if (sheet) sheets[answers[i]] = sheetValues_(sheet);
  }
  return { timeZone: book.getSpreadsheetTimeZone(), today: today, sheetNames: names, sheets: sheets, hasTrigger: false, apiKeyTail: "", keyRejected: false, usage: null, form: null, formSourceHash: "" };
}

/** 権限の例外を敬体の 1 文に言い換える。ほかはそのまま */
export function initPermissionError_(error) {
  const message = String(error && error.message ? error.message : error);
  if (/permission|権限|does not have|not have access|protected|保護/i.test(message)) return new Error(PERMISSION_TEXT);
  return error;
}

/**
 * 設定に書く値を、Sheets に読み替えさせない形にする（' はセルに出ない）。
 * 先頭が = + - @ ' の値（「+α のご要望」のような質問文から書き戻す回答の列など）は数式として、「3,0」のような数とカンマだけの値は数として読まれるので、
 * どちらも先頭に ' を付けて字のまま置く。
 */
function settingCell_(value) {
  const text = value === null || value === undefined ? "" : String(value);
  if (/^[=+\-@']/.test(text)) return "'" + text;
  return /^[\d０-９\s]+([,、][\d０-９\s]+)+$/.test(text) ? "'" + text : text;
}

/** 行の長さをそろえる（setValues は長さの違う行を受け取らない） */
function squaredRows_(rows) {
  let width = 0;
  for (let i = 0; i < rows.length; i += 1) width = Math.max(width, rows[i].length);
  return rows.map((row) => {
    const line = row.map(settingCell_);
    while (line.length < width) line.push("");
    return line;
  });
}

/**
 * check.js の planInit が決めたものを足す。既にあるセルには 1 つも書かない。
 * 設定の行 → シート（作る・空のシートに書く）→ 見出し（1 行目のいまの右端の右）の順。
 */
export function applyInit_(plan) {
  const book = book_();
  const done = [];
  try {
    const settingRows = plan.appendSettings.rows;
    if (settingRows.length > 0) {
      const sheet = book.getSheetByName(plan.appendSettings.sheet);
      sheet.getRange(sheet.getLastRow() + 1, 1, settingRows.length, 2).setValues(squaredRows_(settingRows));
      done.push("「" + plan.appendSettings.sheet + "」に " + settingRows.length + " 行を足しました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "設定への書き込み", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.createSheets.length; i += 1) {
      const made = plan.createSheets[i];
      const sheet = made.exists === true ? book.getSheetByName(made.name) : book.insertSheet(made.name);
      const rows = squaredRows_(made.rows);
      sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
      if (made.freeze === true) sheet.setFrozenRows(1);
      done.push(made.exists === true ? "空だった「" + made.name + "」シートに見出しを書きました" : "「" + made.name + "」シートを作りました");
    }
  } catch (error) {
    throw new Error(initFailureText(done, "シートの作成", initPermissionError_(error)));
  }
  try {
    for (let i = 0; i < plan.appendHeaders.length; i += 1) {
      const entry = plan.appendHeaders[i];
      const sheet = book.getSheetByName(entry.sheet);
      const start = sheet.getLastColumn() + 1;
      const last = start + entry.names.length - 1;
      if (last > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), last - sheet.getMaxColumns());
      sheet.getRange(1, start, 1, entry.names.length).setValues([entry.names]);
      done.push("「" + entry.sheet + "」シートの見出しに足しました: " + entry.names.join("、"));
    }
  } catch (error) {
    throw new Error(initFailureText(done, "見出しの追記", initPermissionError_(error)));
  }
}

function resultSheet_() {
  const book = book_();
  const sheet = book.getSheetByName(SHEET_RESULTS);
  if (sheet) return sheet;
  const made = book.insertSheet(SHEET_RESULTS);
  made.setFrozenRows(1);
  return made;
}

/**
 * Claude に送る前に、見出しの行を書いて「書き込めるか」を確かめる（書けないまま API を使い続けないように）。
 * シートが無ければ作る。返り値は、足りない標準の列を末尾に足した見出し。書けなければ ConfigError。
 */
export function prepareResultSheet_(header) {
  const merged = mergeHeader(header).header;
  try {
    const sheet = resultSheet_();
    if (merged.length > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), merged.length - sheet.getMaxColumns());
    sheet.getRange(1, 1, 1, merged.length).setValues([merged]);
  } catch (error) {
    Logger.log("お客さまアンケート: " + error);
    throw new ConfigError(NOT_WRITABLE);
  }
  return merged;
}

/**
 * フォームに触る前に、「設定」と「質問」に書けるかを確かめる（1 行目の見出しを同じ値で書き直す）。
 * 書けないままフォームを作ると、フォーム ID と項目 ID を残せず、次に押したときに 2 つ目のフォームや同じ質問ができるため。
 */
export function checkFormWritable_() {
  const names = [SHEET_SETTINGS, SHEET_QUESTIONS];
  for (let i = 0; i < names.length; i += 1) {
    try {
      const sheet = book_().getSheetByName(names[i]);
      const range = sheet.getRange(1, 1, 1, Math.max(1, sheet.getLastColumn()));
      range.setValues(range.getValues());
    } catch (error) {
      Logger.log("お客さまアンケート: " + error);
      throw new ConfigError("「" + names[i] + "」シートに書き込めません（シートかセルが保護されているか、このアカウントに編集の権限がありません）。保護を外すか、スプレッドシートの持ち主のアカウントで動かしてください。フォームには、まだ触っていません。");
    }
  }
}

/**
 * 分析結果の末尾に、まとめて書く（1 回の API 呼び出しごと）。「やり直す」の列はチェックボックスにする。
 * シートの行が足りなければ先に足す（新しいシートは 1,000 行で、その外には書けない）。
 */
export function appendResults_(header, rows) {
  if (rows.length === 0) return;
  const sheet = resultSheet_();
  const start = sheet.getLastRow() + 1;
  const last = start + rows.length - 1;
  if (last > sheet.getMaxRows()) sheet.insertRowsAfter(sheet.getMaxRows(), last - sheet.getMaxRows());
  sheet.getRange(start, 1, rows.length, header.length).setValues(rows);
  const redoAt = header.indexOf("やり直す");
  if (redoAt >= 0) sheet.getRange(start, redoAt + 1, rows.length, 1).insertCheckboxes();
}

/** 「やり直す」の行を上書きする（✓ も外れる） */
export function overwriteResult_(rowNumber, header, row) {
  resultSheet_().getRange(rowNumber, 1, 1, header.length).setValues([row]);
}

export function resultSheetGid_() {
  return resultSheet_().getSheetId();
}

/** シートの 1 行 1 列目の見出し（無ければ ""）。フォームの回答シートの「タイムスタンプ」を読む（読むだけで、書かない） */
export function readFirstHeader_(sheetName) {
  const sheet = book_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() === 0) return "";
  const value = sheet.getRange(1, 1, 1, 1).getValues()[0][0];
  return value === null || value === undefined ? "" : String(value).trim();
}

/**
 * まとめシートを消して書き直す。blocks は summary_sheet.js の summaryBlocks の返り値。
 * 返り値は、まとめシートを開く URL（通知に載せる）。
 */
export function writeSummary_(blocks) {
  const book = book_();
  let sheet = book.getSheetByName(SHEET_SUMMARY);
  if (!sheet) sheet = book.insertSheet(SHEET_SUMMARY);
  sheet.clear();
  const width = blocks.values[0].length;
  sheet.getRange(1, 1, blocks.values.length, width).setValues(blocks.values);
  sheet.getRange(1, 1, 1, 1).setFontSize(14);
  for (let i = 0; i < blocks.boldRows.length; i += 1) sheet.getRange(blocks.boldRows[i] + 1, 1, 1, width).setFontWeight("bold");
  for (let i = 0; i < blocks.headerRows.length; i += 1) {
    const range = sheet.getRange(blocks.headerRows[i] + 1, 1, 1, width);
    range.setFontWeight("bold");
    range.setBackground(HEADER_COLOR);
  }
  for (let i = 0; i < blocks.redCells.length; i += 1) sheet.getRange(blocks.redCells[i][0] + 1, blocks.redCells[i][1] + 1, 1, 1).setBackground(WORSE_COLOR);
  return book.getUrl() + "#gid=" + sheet.getSheetId();
}

/** 見本の回答シートを消して書き直す */
export function writeSamples_(values) {
  const book = book_();
  let sheet = book.getSheetByName(SHEET_SAMPLES);
  if (!sheet) sheet = book.insertSheet(SHEET_SAMPLES);
  sheet.clear();
  sheet.getRange(1, 1, values.length, values[0].length).setValues(values);
  sheet.setFrozenRows(1);
}

/**
 * 質問シートを書き直す。質問の行があるシートは「質問（前）」（重なれば「質問（前 2）」…）に名前を変えて残し、
 * 新しい「質問」シートに書く。見出しだけのシートは消して書き直す。
 */
export function writeQuestions_(values) {
  const book = book_();
  let sheet = book.getSheetByName(SHEET_QUESTIONS);
  if (sheet && sheet.getLastRow() > 1) {
    let name = "質問（前）";
    for (let n = 2; book.getSheetByName(name) !== null; n += 1) name = "質問（前 " + n + "）";
    sheet.setName(name);
    sheet = null;
  }
  if (!sheet) sheet = book.insertSheet(SHEET_QUESTIONS);
  else sheet.clear();
  sheet.getRange(1, 1, values.length, values[0].length).setValues(values);
  sheet.setFrozenRows(1);
}

/** 質問シートの「項目 ID」の列に書く。ids = [{ row: シートの行番号, id }] */
export function writeQuestionIds_(ids) {
  const sheet = book_().getSheetByName(SHEET_QUESTIONS);
  const header = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map((cell) => String(cell).trim());
  const at = header.indexOf("項目 ID");
  if (at < 0) return;
  for (let i = 0; i < ids.length; i += 1) sheet.getRange(ids[i].row, at + 1, 1, 1).setValues([["'" + String(ids[i].id)]]);
}

/**
 * 設定シートの値を書き換える（無い項目は末尾に足す）。pairs = [[項目, 値]]。
 * 返り値は元の値 [[項目, 元の値]]（無かった項目は ""）。
 */
export function writeSettings_(pairs) {
  const sheet = book_().getSheetByName(SHEET_SETTINGS);
  const values = sheetValues_(sheet);
  const old = [];
  for (let i = 0; i < pairs.length; i += 1) {
    let at = -1;
    for (let r = 0; r < values.length; r += 1) if (configKeyOf(String(values[r][0])) === configKeyOf(pairs[i][0])) at = r;
    if (at < 0) {
      old.push([pairs[i][0], ""]);
      sheet.getRange(sheet.getLastRow() + 1, 1, 1, 2).setValues([[pairs[i][0], settingCell_(pairs[i][1])]]);
    } else {
      old.push([pairs[i][0], values[at][1] === null || values[at][1] === undefined ? "" : String(values[at][1])]);
      sheet.getRange(at + 1, 2, 1, 1).setValues([[settingCell_(pairs[i][1])]]);
    }
  }
  return old;
}
