/**
 * 「分析結果」シートの見出し（14 列）と 1 行、読み戻し。
 * 見出しは名前で探すので、買い手が列を並べ替えていても正しい場所に書く。無い標準の列は末尾に足す。
 * 回答と Claude から来た字は safeCell を通す（数式として動いたり、数や日付に読み替えられたりしないように）。
 * 元: AI 問い合わせ整理キット 1.0.0 の src/rows.js の作り（safeCell_ は同じ中身で、名前だけ export 用に変えた）。
 */
import { toDateKey } from "./dates.js";

export const HEADERS = ["キー", "行", "日付", "評価", "店舗", "回答（抜粋）", "分類", "感情", "要望", "要約", "要対応", "やり直す", "分析日時", "モデル"];

export const CHECK_MARK = "✓";

function rowText_(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

/**
 * Sheets は書いた文字を、人が打ち込んだときと同じように読み替える（数式・数・日付・割合・TRUE/FALSE）。
 * そう読まれうる字は先頭に ' を付けて文字のまま残す（' はセルに出ない。先頭の 0 も消えない）。
 */
export function safeCell(value) {
  const text = value === undefined || value === null ? "" : String(value);
  if (/^[=+\-@\t\r']/.test(text)) return "'" + text;
  const trimmed = text.trim();
  if (/^(true|false)$/i.test(trimmed)) return "'" + text;
  // 数字を含み、数字と区切り（. , / : - 空白 % ¥ $ 年月日時分秒 午前午後 AM PM e）だけでできている字は、数か日付か時刻に読まれうる
  if (/\d/.test(trimmed) && /^[\d\s.,\/:%¥$年月日時分秒午前後eE-]+$|^[\d\s.,\/:]+\s*(am|pm)$/i.test(trimmed)) return "'" + text;
  return text;
}

/** 既にある見出しに、無い標準の列を末尾に足す。返り値 { header, added } */
export function mergeHeader(header) {
  const names = (Array.isArray(header) ? header : []).map(rowText_);
  const added = [];
  for (let i = 0; i < HEADERS.length; i += 1) {
    if (names.indexOf(HEADERS[i]) < 0) {
      names.push(HEADERS[i]);
      added.push(HEADERS[i]);
    }
  }
  return { header: names, added: added };
}

/** 見出しの名前 → その列に入れる値 */
function resultValue_(name, entry) {
  const a = entry.answer;
  switch (name) {
    case "キー":
      return entry.key;
    case "行":
      return entry.row;
    case "日付":
      return entry.date;
    case "評価":
      return entry.rating;
    case "店舗":
      return safeCell(entry.store);
    case "回答（抜粋）":
      return safeCell(entry.excerpt);
    case "分類":
      return safeCell(a.category);
    case "感情":
      return a.sentiment;
    case "要望":
      return safeCell(a.request);
    case "要約":
      return safeCell(a.summary);
    case "要対応":
      return a.attention === true ? CHECK_MARK : "";
    case "やり直す":
      return false;
    case "分析日時":
      return entry.stamp;
    case "モデル":
      return entry.model;
    default:
      return "";
  }
}

/**
 * entry = { key, row, date, rating, store, excerpt, answer: { category, sentiment, request, summary, attention }, stamp, model }。
 * 返り値 { header, row, added }。header は足した見出しまで入った最終形で、そのままシートに書ける。
 */
export function buildResultRow(header, entry) {
  const merged = mergeHeader(header);
  const row = [];
  for (let i = 0; i < merged.header.length; i += 1) row.push(resultValue_(merged.header[i], entry));
  return { header: merged.header, row: row, added: merged.added };
}

function checked_(value) {
  if (value === true) return true;
  const text = rowText_(value).toUpperCase();
  return text === "TRUE" || text === CHECK_MARK;
}

/** 分析結果の値（1 行目が見出し）から、キー → { row, redo }。シートが無いか空なら keys は空 */
export function indexResults(values) {
  const rows = Array.isArray(values) ? values : [];
  const header = rows.length === 0 ? [] : rows[0].map(rowText_);
  const keyAt = header.indexOf("キー");
  const redoAt = header.indexOf("やり直す");
  const keys = {};
  if (keyAt < 0) return { header: header, keys: keys };
  for (let i = 1; i < rows.length; i += 1) {
    const key = rowText_(rows[i][keyAt]);
    if (key === "" || Object.prototype.hasOwnProperty.call(keys, key)) continue;
    keys[key] = { row: i + 1, redo: redoAt >= 0 && checked_(rows[i][redoAt]) };
  }
  return { header: header, keys: keys };
}

/**
 * まとめ（summary.js）が数える形に読み戻す。人が直した値をそのまま使う。
 * 返り値 [{ row, key, date, rating, store, excerpt, category, sentiment, request, summary, attention }]。
 * date は "YYYY-MM-DD"（Sheets が日付に読み替えた値も戻す）。読めない日付の行は date: null。
 */
export function resultRecords(values) {
  const rows = Array.isArray(values) ? values : [];
  if (rows.length === 0) return [];
  const header = rows[0].map(rowText_);
  const at = (name) => header.indexOf(name);
  const cell = (row, name) => (at(name) < 0 ? "" : row[at(name)]);
  const out = [];
  for (let i = 1; i < rows.length; i += 1) {
    const row = rows[i];
    if (rowText_(cell(row, "キー")) === "" && rowText_(cell(row, "分類")) === "") continue;
    const rating = cell(row, "評価");
    out.push({
      row: i + 1,
      key: rowText_(cell(row, "キー")),
      date: toDateKey(cell(row, "日付")),
      rating: typeof rating === "number" ? rating : rowText_(rating) === "" || Number.isNaN(Number(rowText_(rating))) ? "" : Number(rowText_(rating)),
      store: rowText_(cell(row, "店舗")),
      excerpt: rowText_(cell(row, "回答（抜粋）")),
      category: rowText_(cell(row, "分類")),
      sentiment: rowText_(cell(row, "感情")),
      request: rowText_(cell(row, "要望")),
      summary: rowText_(cell(row, "要約")),
      attention: checked_(cell(row, "要対応")),
    });
  }
  return out;
}
