/**
 * 「フォームを作る」の決めるところ（純粋）: 質問シートの各行をフォームの質問にどう当てるか（planForm）、
 * 設定に書き戻す行（writebackFor・作った直後の formIdRows）、フォームの題・説明・送信後の文（formTexts）、終わりの alert（formReport）。
 * gas_form.js はこの結果をフォームに当てるだけ。
 */
import { columnsFromQuestions } from "./questions.js";

/** 質問の種類 → フォームの質問の型（Apps Script の ItemType の名前）。はい・いいえ は 2 択の選択で作る */
export const ITEM_KINDS = {
  "選択": "MULTIPLE_CHOICE",
  "はい・いいえ": "MULTIPLE_CHOICE",
  "複数": "CHECKBOX",
  "5 段階": "SCALE",
  "自由記述": "PARAGRAPH_TEXT",
};

export function kindOf(type) {
  return Object.prototype.hasOwnProperty.call(ITEM_KINDS, type) ? ITEM_KINDS[type] : "";
}

/**
 * existingItems: いまのフォームの質問 [{ id, title, kind }]（新しく作るときは []）。
 * questions: questions.js の parseQuestions の questions（並びの順）。options: { removeDeleted }。
 * 返り値 { items: [{ action: "create" | "update" | "recreate", question, itemId }]（並びの順）,
 *          remove: [{ id, title }], keep: [{ id, title }], counts: { create, update, recreate, keep, remove } }
 */
export function planForm(existingItems, questions, options) {
  const existing = {};
  for (let i = 0; i < existingItems.length; i += 1) existing[String(existingItems[i].id)] = existingItems[i];
  const used = {};
  const items = [];
  const counts = { create: 0, update: 0, recreate: 0, keep: 0, remove: 0 };
  for (let i = 0; i < questions.length; i += 1) {
    const q = questions[i];
    const found = q.itemId !== "" && Object.prototype.hasOwnProperty.call(existing, q.itemId) && used[q.itemId] !== true ? existing[q.itemId] : null;
    if (found === null) {
      items.push({ action: "create", question: q, itemId: "" });
      counts.create += 1;
      continue;
    }
    used[q.itemId] = true;
    const action = found.kind === kindOf(q.type) ? "update" : "recreate";
    items.push({ action: action, question: q, itemId: String(found.id) });
    counts[action] += 1;
  }
  const remove = [];
  const keep = [];
  for (let i = 0; i < existingItems.length; i += 1) {
    const item = existingItems[i];
    if (used[String(item.id)] === true) continue;
    (options.removeDeleted === true ? remove : keep).push({ id: String(item.id), title: item.title });
  }
  counts.remove = remove.length;
  counts.keep = keep.length;
  return { items: items, remove: remove, keep: keep, counts: counts };
}

/** フォームの題・説明・送信後のメッセージ。題の {店名} は店名（空なら「当店」）に置き換える */
export function formTexts(config) {
  const name = config.storeName === "" ? "当店" : config.storeName;
  return {
    title: config.formTitle.replace(/\{店名\}/g, name).trim(),
    description: config.formDescription,
    confirmation: config.confirmationMessage,
  };
}

/**
 * フォームを作ったらすぐ設定に書く 2 行（このあとで止まっても、次に押すと同じフォームを直せるように）。
 * form = { editUrl, id }
 */
export function formIdRows(form) {
  return [
    ["フォームの編集 URL", form.editUrl],
    ["フォーム ID", String(form.id)],
  ];
}

/**
 * フォームを作ったあと設定に書き戻す行 [[項目, 値]]。無い役は「なし」（推測で別の列を拾わないように）。
 * form = { url, editUrl, id }。dateHeader は見つけた回答シートの 1 列目の見出し（アカウントの言語で「Timestamp」などに
 * なる）。空なら「タイムスタンプ」。
 */
export function writebackFor(questions, sheetName, form, dateHeader) {
  const columns = columnsFromQuestions(questions);
  const date = dateHeader === undefined || dateHeader === null || String(dateHeader).trim() === "" ? columns.date : String(dateHeader).trim();
  return [
    ["回答シート", sheetName],
    ["回答の列", columns.answers.join(", ")],
    ["日付の列", date],
    ["評価の列", columns.rating === "" ? "なし" : columns.rating],
    ["評価の最大", "5"],
    ["店舗の列", columns.store === "" ? "なし" : columns.store],
    ["フォームの URL", form.url],
  ].concat(formIdRows(form));
}

/** 書き戻しで値が変わった行（元が空でなく、新しい値と違うもの）。キットが書く 3 行は数えない */
export function overwrittenRows(old, pairs) {
  const own = ["フォームの URL", "フォームの編集 URL", "フォーム ID"];
  const out = [];
  for (let i = 0; i < pairs.length; i += 1) {
    if (own.indexOf(pairs[i][0]) >= 0) continue;
    const before = old[i] === undefined ? "" : String(old[i][1]);
    if (before !== "" && before !== String(pairs[i][1])) out.push([pairs[i][0], before]);
  }
  return out;
}

/**
 * 終わりの alert。result = { created, counts, keep: [題], removed: [題], url, sheetName, sheetFound,
 *   choicesRemoved, overwritten: [[項目, 前の値]] }
 */
export function formReport(result) {
  const c = result.counts;
  const lines = [
    result.created
      ? "フォームを作りました。"
      : "フォームを直しました（質問の追加 " + c.create + "・変更 " + c.update + "・作り直し " + c.recreate + "・残した質問 " + c.keep + "）。",
    "",
    "答える人に渡す URL: " + result.url,
    "（設定シートの「フォームの URL」にも書きました）",
    "",
    "QR コードは、この URL を Chrome で開き、アドレスバーの右の［このページを共有］→［QR コードを作成］→［ダウンロード］で作れます（README の手順 5）。",
  ];
  if (result.sheetFound) lines.push("回答は「" + result.sheetName + "」シートに溜まります。回答が来たら「分析する」を押してください。");
  else lines.push("フォームはできましたが、回答のシートが見つかりませんでした。スプレッドシートを開き直してから、もう一度「フォームを作る」を押してください（2 つ目のフォームはできません）。");
  lines.push("フォームを直すときは、「質問」シートを直してから、もう一度「フォームを作る」を押してください（同じフォームが直ります）。");
  const extra = [];
  if (result.keep.length > 0) extra.push("フォームに残した質問: " + result.keep.join("、") + "（質問シートから消しても、フォームからは消していません）");
  if (result.removed.length > 0) extra.push("フォームから消した質問: " + result.removed.join("、") + "（回答シートの列とこれまでの回答は残ります）");
  if (c.recreate > 0) extra.push("種類を変えた質問は作り直しました。回答シートには新しい列ができ、古い列とこれまでの回答は残ります。");
  if (result.choicesRemoved) extra.push("選択肢を消した質問があります。前の回答はシートに残りますが、フォームの「回答」タブの集計からは見えにくくなります。");
  if (result.overwritten.length > 0) extra.push("設定を書き換えました（前の値: " + result.overwritten.map((pair) => pair[0] + "「" + pair[1] + "」").join("、") + "）。");
  return lines.concat(extra.length > 0 ? [""].concat(extra) : []).join("\n");
}


/** 「フォームを作る」の確認と止める文 */
export const FORM_MENU_TITLE = "フォームを作る";
export const NO_QUESTIONS_TEXT = "「質問」シートがありません。先に「見本を読み込む」で業種の見本を読み込むか、「初期化」で見出しを作ってから質問を書いてください。";
export const FORM_REOPEN_TEXT = "設定のフォーム ID のフォームを開けませんでした（またはほかのスプレッドシートにつながっています）。新しいフォームを作ります。よろしいですか？";
export const SWITCH_FROM_SAMPLES_TEXT = "設定の「回答シート」を、見本の回答からフォームの回答に切り替えます。よろしいですか？";

/** フォームから質問を消す前の確認 */
export function removeConfirmText(remove) {
  return "次の質問をフォームから消します。回答シートの列とこれまでの回答は残ります。よろしいですか？\n" + remove.map((item) => "・" + item.title).join("\n");
}

/** 質問シートに直すところがあるとき（フォームには触らない） */
export function questionProblemsText(problems) {
  return "フォームに触る前に、質問シートの直すところがあります。\n\n" + problems.map((line) => "・" + line).join("\n") + "\n\n直したら、もう一度「フォームを作る」を押してください。";
}
