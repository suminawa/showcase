/**
 * 初期化（何を足すか）と「設定を確かめる」（何を直すか・これから何が起きるか）を決める。純粋な処理。
 * 形は期限アラート GAS キット 1.1.0 の src/check.js。受け取るのはシートの値をそのまま写した snapshot
 * （gas_sheets.js の readSetupSnapshot_ が作る）:
 *   { timeZone, today: "YYYY-MM-DD", sheetNames: [左からのシート名], sheets: { シート名: 2 次元配列 },
 *     hasTrigger, apiKeyTail: "" | 末尾 4 字, keyRejected, usage: usage.js の合計,
 *     form: { state: "none" | "ok" | "missing" | "elsewhere", accepting, items: [{ id, title, kind }], responses },
 *     formSourceHash: 最後にフォームを作ったときの質問シートの指紋（無ければ ""） }
 * sheets に載せるのは「設定」「分析結果」「質問」と回答シートのうち、あるものだけ。空のシート（1 行も無い）は []。
 * form と formSourceHash は gas_main.js が埋める（無ければ、フォームはまだ無いものとして扱う）。
 */
import { DEFAULT_ROWS, NO_ANSWER_CATEGORY, SHEET_QUESTIONS, SHEET_RESULTS, SHEET_SAMPLES, SHEET_SETTINGS, configKeyOf, readConfigRows } from "./config.js";
import { QUESTION_HEADERS, parseQuestions, questionsHash } from "./questions.js";
import { cellOf, pickAnswerSheet, resolveColumns } from "./columns.js";
import { ratingOf, selectPending, toResponses } from "./responses.js";
import { HEADERS, indexResults, resultRecords } from "./rows.js";
import { estimateYen } from "./usage.js";
import { missingHeaders, missingSettingRows } from "./setup.js";

export const KEY_PROMPT_TITLE = "Anthropic の API キー";
export const KEY_PROMPT_TEXT = "Anthropic の API キーを貼ってください（sk-ant- で始まる文字です）。キーはこのスプレッドシートのスクリプトの中だけに保存され、シートには書きません。あとで入れる場合は［キャンセル］を押してください。";
export const KEY_LATER_TEXT = "API キーはあとで入れられます。もう一度「初期化」を押すと、この欄が出ます。";
const KEY_MIN_LENGTH = 20;

/** 貼られたキーの形を見る。良ければ ""、違えば 1 文 */
export function apiKeyProblem(text) {
  const key = String(text === null || text === undefined ? "" : text).trim();
  if (/^sk-ant-\S+$/.test(key) && key.length >= KEY_MIN_LENGTH) return "";
  return "キーの形が違うようです。sk-ant- で始まる文字をそのまま貼ってください。";
}

/** キーは末尾 4 字だけを見せる */
export function apiKeyTail(key) {
  return String(key).slice(-4);
}

export function keySavedText(tail) {
  return "API キーを保存しました（末尾 …" + tail + "）。次は「設定を確かめる」を実行してください。";
}

/** 初期化の最後にキーを貼る欄を出すか（キーが無いか、前回 401 だった） */
export function needsKeyPrompt(snapshot) {
  return snapshot.apiKeyTail === "" || snapshot.keyRejected === true;
}

function timeZoneText_(timeZone) {
  return "スプレッドシートのタイムゾーンが " + timeZone + " です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。";
}

/** 初期化のあとの設定シートの行（無ければ既定の全行） */
function effectiveSettings_(snapshot) {
  const values = snapshot.sheets[SHEET_SETTINGS];
  if (values === undefined || values.length === 0) return [["項目", "値"]].concat(DEFAULT_ROWS);
  return values;
}

/** readSetupSnapshot_ が読む回答シートの名前（あれば 1 つ）。設定シートの値と、ブックのシート名から決める */
export function sheetNamesFor(settingsValues, sheetNames) {
  const rows = settingsValues === undefined || settingsValues === null || settingsValues.length === 0 ? [] : settingsValues;
  const name = pickAnswerSheet(readConfigRows(rows).config, sheetNames);
  return name === "" ? [] : [name];
}

/**
 * 回答シートを読んだ結果。分析する・まとめを作る・設定を確かめる で同じものを使う。
 * 返り値 { sheetName, values, columns, responses, index, pending, problems }
 */
export function answerState(snapshot, config) {
  const index = indexResults(snapshot.sheets[SHEET_RESULTS] === undefined ? [] : snapshot.sheets[SHEET_RESULTS]);
  const state = { sheetName: "", values: [], columns: null, responses: [], index: index, pending: [], problems: [] };
  const name = pickAnswerSheet(config, snapshot.sheetNames);
  if (name === "") {
    state.problems.push(
      config.sheetName !== ""
        ? "設定「回答シート」の「" + config.sheetName + "」シートがありません。シートの名前をそのまま書くか、空にして自動で探させてください。"
        : "回答シートが見つかりません。Google フォームの回答をこのスプレッドシートにつなぐか、設定「回答シート」に回答の入ったシートの名前を書いてください。",
    );
    return state;
  }
  state.sheetName = name;
  state.values = snapshot.sheets[name] === undefined ? [] : snapshot.sheets[name];
  if (state.values.length === 0) {
    state.problems.push("「" + name + "」シートに見出しがありません。1 行目に質問の見出しがあるシートを、設定「回答シート」に書いてください。");
    return state;
  }
  state.columns = resolveColumns(name, state.values, config);
  state.problems = state.problems.concat(state.columns.problems);
  if (state.columns.answers.length === 0) return state;
  state.responses = toResponses(state.values, state.columns, config, snapshot.today);
  state.pending = selectPending(state.responses, index);
  return state;
}

/** 初期化で足すもの。返り値は setup.js の Plan に、次の一歩の文 nextStep を足したもの */
export function planInit(snapshot) {
  const plan = { createSheets: [], appendHeaders: [], appendSettings: { sheet: SHEET_SETTINGS, rows: [], blank: false }, notes: [], nextStep: "" };
  const settings = snapshot.sheets[SHEET_SETTINGS];
  if (settings === undefined || settings.length === 0) {
    plan.createSheets.push({ name: SHEET_SETTINGS, rows: [["項目", "値"]].concat(DEFAULT_ROWS), freeze: true, exists: settings !== undefined });
  } else {
    plan.appendSettings.rows = missingSettingRows(settings, DEFAULT_ROWS, configKeyOf);
  }
  const results = snapshot.sheets[SHEET_RESULTS];
  if (results === undefined || results.length === 0) {
    plan.createSheets.push({ name: SHEET_RESULTS, rows: [HEADERS.slice()], freeze: true, exists: results !== undefined });
  } else {
    const missing = missingHeaders(results[0], HEADERS);
    if (missing.length > 0) plan.appendHeaders.push({ sheet: SHEET_RESULTS, names: missing });
  }
  const questions = snapshot.sheets[SHEET_QUESTIONS];
  if (questions === undefined || questions.length === 0) {
    plan.createSheets.push({ name: SHEET_QUESTIONS, rows: [QUESTION_HEADERS.slice()], freeze: true, exists: questions !== undefined });
  } else {
    const missing = missingHeaders(questions[0], QUESTION_HEADERS);
    if (missing.length > 0) plan.appendHeaders.push({ sheet: SHEET_QUESTIONS, names: missing });
  }
  if (snapshot.timeZone !== "Asia/Tokyo") plan.notes.push(timeZoneText_(snapshot.timeZone));
  const state = answerState(snapshot, readConfigRows(effectiveSettings_(snapshot)).config);
  if (state.problems.length > 0) plan.notes.push(state.problems[0]);
  plan.nextStep = needsKeyPrompt(snapshot) ? "続けて、API キーを貼る欄を出します。" : "次は「設定を確かめる」を実行してください。";
  return plan;
}

/** 設定の行ごとの誤りを、最初の 1 つで止めずに全部集める */
export function collectConfigProblems(rows) {
  return readConfigRows(rows).problems;
}

/** 評価の列の値が、半分以上数として読めなければ 1 文 */
function ratingProblem_(state, config) {
  const rating = state.columns === null ? null : state.columns.rating;
  if (rating === null) return "";
  let filled = 0;
  let unreadable = 0;
  for (let i = 1; i < state.values.length; i += 1) {
    const value = cellOf(state.values[i], rating);
    if (value === null || value === undefined || String(value).trim() === "") continue;
    filled += 1;
    if (ratingOf(value, config.ratingMax) === "") unreadable += 1;
  }
  if (filled === 0 || unreadable * 2 < filled) return "";
  return "「" + state.sheetName + "」シートの評価の列「" + rating.name + "」は、半分以上の行が数（0〜" + config.ratingMax + "）として読めません。数の入った列の見出しを設定「評価の列」に書くか、使わないときは「なし」と書いてください（0〜10 の評価なら、設定「評価の最大」を 10 にしてください）。";
}

/** 見本の回答を読む設定で、キーがまだ無いか（同梱の答えで再生する） */
function samplesWithoutKey_(snapshot, state) {
  return snapshot.apiKeyTail === "" && state.sheetName === SHEET_SAMPLES;
}

/** 質問シートに質問の行があるか（見出しだけなら、フォームを使わない人として検査しない） */
function hasQuestionRows_(snapshot) {
  const values = snapshot.sheets[SHEET_QUESTIONS];
  return values !== undefined && values.length > 1;
}

function formOf_(snapshot) {
  return snapshot.form === undefined || snapshot.form === null ? { state: "none", accepting: true, items: [], responses: 0 } : snapshot.form;
}

/** フォームの状態の誤り（フォーム ID のフォームが開けない・ほかのスプレッドシートにつながっている・回答を受け付けていない） */
function formProblems_(snapshot) {
  const form = formOf_(snapshot);
  if (form.state === "missing") return ["設定の「フォーム ID」のフォームを開けませんでした（消したか、ゴミ箱にあるか、このアカウントに権限がありません）。「フォームを作る」を押すと、確認のうえ新しく作ります。"];
  if (form.state === "elsewhere") return ["設定の「フォーム ID」のフォームは、ほかのスプレッドシートにつながっています。「フォームを作る」を押すと、確認のうえこのスプレッドシート用に新しく作ります。"];
  if (form.state === "ok" && form.accepting === false) return ["フォームが回答を受け付けていません。フォームの編集画面の「回答」タブで「回答を受付中」をオンにしてください。"];
  return [];
}

/** 設定を確かめるの「直すところ」。最初の 1 つで止めずに全部 */
export function findProblems(snapshot) {
  const problems = [];
  if (hasQuestionRows_(snapshot)) {
    const parsed = parseQuestions(snapshot.sheets[SHEET_QUESTIONS]);
    for (let i = 0; i < parsed.problems.length; i += 1) problems.push(parsed.problems[i]);
  }
  for (const line of formProblems_(snapshot)) problems.push(line);
  if (snapshot.timeZone !== "Asia/Tokyo") problems.push(timeZoneText_(snapshot.timeZone));
  const settings = snapshot.sheets[SHEET_SETTINGS];
  if (settings === undefined) {
    problems.push("「設定」シートがありません。メニュー「お客さまアンケート」→「初期化」を実行してください。");
    return problems;
  }
  const read = readConfigRows(settings);
  const state = answerState(snapshot, read.config);
  const all = problems.concat(read.problems, state.problems);
  const rating = ratingProblem_(state, read.config);
  if (rating !== "") all.push(rating);
  if (snapshot.apiKeyTail === "" && !samplesWithoutKey_(snapshot, state)) all.push("API キーが入っていません。メニュー「初期化」を押すと、キーを貼る欄が出ます。");
  if (snapshot.keyRejected === true) all.push("前回、API キーが受け付けられませんでした（401）。メニュー「初期化」を押すと、キーを貼り直す欄が出ます。");
  return all;
}

/** 誤りではないが知っておくとよいこと（「ご参考:」の下に並べる） */
export function checkNotes(snapshot) {
  const notes = [];
  if (hasQuestionRows_(snapshot)) {
    const values = snapshot.sheets[SHEET_QUESTIONS];
    const parsed = parseQuestions(values);
    const stored = snapshot.formSourceHash === undefined ? "" : snapshot.formSourceHash;
    if (stored !== "" && stored !== questionsHash(values)) notes.push("質問シートが、最後にフォームを作ったときから変わっています。反映するには「フォームを作る」を押してください。");
    const form = formOf_(snapshot);
    if (form.state === "ok") {
      const ids = parsed.questions.map((q) => q.itemId);
      const only = form.items.filter((item) => ids.indexOf(String(item.id)) < 0).map((item) => "「" + item.title + "」");
      if (only.length > 0) notes.push("フォームにだけ残っている質問があります: " + only.join("") + "。フォームからも消すときは、設定「質問を減らしても消す」を はい にして「フォームを作る」を押してください。");
    }
    for (let i = 0; i < parsed.notes.length; i += 1) notes.push(parsed.notes[i]);
  }
  const settings = snapshot.sheets[SHEET_SETTINGS];
  if (settings === undefined) return notes;
  const missing = missingSettingRows(settings, DEFAULT_ROWS, configKeyOf);
  if (missing.length > 0) {
    notes.push("「設定」シートに" + missing.map((row) => "「" + row[0] + "」").join("") + "の行がありません。既定値で動きます。「初期化」を実行すると、既定値の行を足します。");
  }
  const config = readConfigRows(settings).config;
  const state = answerState(snapshot, config);
  if (state.columns !== null) for (let i = 0; i < state.columns.notes.length; i += 1) notes.push(state.columns.notes[i]);
  const records = resultRecords(snapshot.sheets[SHEET_RESULTS] === undefined ? [] : snapshot.sheets[SHEET_RESULTS]);
  const old = records.filter((record) => record.category !== NO_ANSWER_CATEGORY && record.category !== "" && config.categories.indexOf(record.category) < 0).length;
  if (old > 0) notes.push("分類を変える前に分析した行が " + old + " 件あります。そろえるときは、その行の「やり直す」に ✓ を入れて「分析する」を押してください。");
  if (state.pending.length > 0) notes.push("まだ分析していない回答が " + state.pending.length + " 件あります。「分析する」を押すと分析します。");
  if (samplesWithoutKey_(snapshot, state)) notes.push("API キーが入っていないので、見本の回答は同梱の答えで分析とまとめを再生します。ご自身の回答を分析する前に、「初期化」でキーを貼ってください。");
  if (snapshot.hasTrigger === false) notes.push("毎週月曜 8 時の自動実行は入っていません。使うときはメニュー「毎週送る（入れる / 外す）」を押してください。");
  return notes;
}

function columnLabel_(column) {
  return column === null ? "なし" : column.name;
}

/** 直すところが無いときの「これから起きること」。findProblems が 0 件のときだけ呼ぶ */
export function summaryLines(snapshot) {
  const config = readConfigRows(snapshot.sheets[SHEET_SETTINGS]).config;
  const state = answerState(snapshot, config);
  const columns = state.columns;
  const analyzed = state.responses.filter((response) => Object.prototype.hasOwnProperty.call(state.index.keys, response.key)).length;
  const scale = config.ratingMax === 10 ? "0〜10" : "5 段階";
  const yen = estimateYen(snapshot.usage, config.model, 150);
  const form = formOf_(snapshot);
  const source = config.formId !== "" ? "質問シートから" : columns.answerSource === "設定" ? "" : columns.answerSource;
  const lines = [];
  if (config.formUrl !== "") lines.push("フォーム: " + config.formUrl + (form.state === "ok" ? "（回答 " + form.responses + " 件）" : ""));
  return lines.concat([
    "読む回答シート: 「" + state.sheetName + "」",
    "回答の列: " + columns.answers.map((column) => column.name).join("・") + (source === "" ? "" : "（" + source + "）"),
    "日付の列: " + columnLabel_(columns.date) + "｜評価の列: " + columnLabel_(columns.rating) + (columns.rating === null ? "" : "（" + scale + "）") + "｜店舗の列: " + columnLabel_(columns.store),
    "回答: " + state.responses.length + " 件（分析済み " + analyzed + " 件、残り " + state.pending.length + " 件）",
    "分類: " + config.categories.join("・"),
    "モデル: " + config.model + "（1 回 " + config.batchSize + " 件、1 日 " + config.perDay + " 件まで）",
    "伏せ字: " + (config.mask ? "メールアドレスと電話番号を〔メール〕〔電話〕に替えてから送ります" : "しません（回答をそのまま送ります）"),
    "まとめ: " + (config.periodDays === 0 ? "全期間" : "直近 " + config.periodDays + " 日") + "、送り先: " + (config.targets.length === 0 ? "なし（シートだけ）" : config.targets.join(", ")),
    "API キー: " +
      (snapshot.apiKeyTail === ""
        ? "入っていません（見本の回答は同梱の答えで再生します）"
        : "入っています（末尾 …" + snapshot.apiKeyTail + "）。入れ替えるときは、Apps Script のプロジェクトの設定 → スクリプト プロパティで書き換えてください。"),
    "今月の AI 利用の目安: " + (yen === null ? "このモデルの単価が分からないため出せません" : yen + " 円（Anthropic Console の使用量が正です）"),
  ]);
}
