/**
 * 「質問」シート（1 行 1 質問、8 列）を読んで検査する（純粋）。問題があればフォームに触らず、全部を並べて止める。
 * 分析での使い道（集計）もここで決め、フォームを作ったあと設定に書き戻す列（columnsFromQuestions）を出す。
 */
import { isPersonalColumn } from "./columns.js";
import { responseKey } from "./responses.js";

export const QUESTION_HEADERS = ["並び", "質問", "種類", "選択肢", "必須", "説明", "集計", "項目 ID"];
export const QUESTION_TYPES = ["選択", "複数", "5 段階", "自由記述", "はい・いいえ"];
export const QUESTION_USES = ["回答", "評価", "店舗", "使わない"];
export const QUESTION_MAX = 50;
export const CHOICE_MIN = 2;
export const CHOICE_MAX = 30;
export const ANSWER_USE_MAX = 3;
/** 回答シートの 1 列目の見出し（Google フォームが付ける） */
export const TIMESTAMP_HEADER = "タイムスタンプ";

/** 種類の揺れ（空白・中黒・スラッシュを落とした形）→ 正しい種類 */
const TYPE_ALIASES = {
  "選択": "選択",
  "ラジオ": "選択",
  "1つ選ぶ": "選択",
  "複数": "複数",
  "複数選択": "複数",
  "チェックボックス": "複数",
  "5段階": "5 段階",
  "段階": "5 段階",
  "目盛り": "5 段階",
  "自由記述": "自由記述",
  "自由": "自由記述",
  "記述": "自由記述",
  "文章": "自由記述",
  "段落": "自由記述",
  "はいいいえ": "はい・いいえ",
};

function questionText_(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

/** 種類のセル → 正しい種類。読めなければ "" */
export function typeOf(value) {
  const key = questionText_(value)
    .replace(/[０-９]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/[\s　・/／]/g, "");
  return Object.prototype.hasOwnProperty.call(TYPE_ALIASES, key) ? TYPE_ALIASES[key] : "";
}

/** 選択肢のセル → 選択肢の一覧（セル内の改行・「｜」・「|」で区切る。空と重なりは落とす） */
export function splitChoices(value) {
  const out = [];
  const parts = questionText_(value).split(/\r?\n|｜|\|/);
  for (let i = 0; i < parts.length; i += 1) {
    const part = parts[i].trim();
    if (part !== "" && out.indexOf(part) < 0) out.push(part);
  }
  return out;
}

/** 必須のセル → true / false。空は false。読めなければ null */
export function yesNoOf(value) {
  if (typeof value === "boolean") return value;
  const text = questionText_(value).toLowerCase();
  if (text === "") return false;
  if (["はい", "true", "yes", "○", "1", "必須"].indexOf(text) >= 0) return true;
  if (["いいえ", "false", "no", "×", "0", "任意"].indexOf(text) >= 0) return false;
  return null;
}

/**
 * values: 質問シートの値（1 行目が見出し）。
 * 返り値 { questions: Question[], problems: [文], notes: [文] }。questions は並びの順。
 * Question = { row, order, title, type, choices, labels, required, help, use, itemId }
 *   choices: 選択・複数・はい・いいえ の選択肢、labels: 5 段階の [左, 右]（無ければ []）、
 *   use: 回答 / 評価 / 店舗 / 使わない（空の集計は自動で決めたもの）
 */
export function parseQuestions(values) {
  const rows = Array.isArray(values) ? values : [];
  const problems = [];
  const notes = [];
  const header = rows.length === 0 ? [] : rows[0].map(questionText_);
  const at = {};
  for (let i = 0; i < QUESTION_HEADERS.length; i += 1) at[QUESTION_HEADERS[i]] = header.indexOf(QUESTION_HEADERS[i]);
  const lacking = QUESTION_HEADERS.filter((name) => at[name] < 0);
  if (lacking.length > 0) {
    problems.push("質問シートの 1 行目に" + lacking.map((name) => "「" + name + "」").join("") + "の列がありません。メニュー「初期化」を実行すると見出しを足します。");
    if (at["質問"] < 0) return { questions: [], problems: problems, notes: notes };
  }
  const cell = (row, name) => (at[name] < 0 ? "" : row[at[name]]);

  const questions = [];
  const seen = {};
  for (let r = 1; r < rows.length; r += 1) {
    const row = Array.isArray(rows[r]) ? rows[r] : [];
    const title = questionText_(cell(row, "質問"));
    if (title === "") continue;
    const rowNumber = r + 1;
    const where = "質問シートの " + rowNumber + " 行目: ";
    const typeText = questionText_(cell(row, "種類"));
    const type = typeOf(typeText);
    if (type === "") problems.push(where + "種類「" + typeText + "」を読めません。選択 / 複数 / 5 段階 / 自由記述 / はい・いいえ のどれかにしてください。");
    if (title === TIMESTAMP_HEADER) problems.push(where + "「" + TIMESTAMP_HEADER + "」は回答シートの 1 列目の見出しに使われるので、質問の文にできません。");
    if (Object.prototype.hasOwnProperty.call(seen, title)) {
      problems.push(where + "「" + title + "」と同じ文の質問が " + seen[title] + " 行目にもあります。回答シートの見出しが重なるので、どちらかの文を変えてください。");
    } else seen[title] = rowNumber;

    const written = splitChoices(cell(row, "選択肢"));
    let choices = [];
    let labels = [];
    if (type === "選択" || type === "複数") {
      choices = written;
      if (written.length === 0) problems.push(where + "種類が「" + type + "」ですが、選択肢がありません。セル内で改行して 2 つ以上書いてください。");
      else if (written.length < CHOICE_MIN) problems.push(where + "種類が「" + type + "」ですが、選択肢が 1 つしかありません。セル内で改行して 2 つ以上書いてください。");
      else if (written.length > CHOICE_MAX) problems.push(where + "選択肢は " + CHOICE_MAX + " 個までにしてください（いまは " + written.length + " 個）。");
    } else if (type === "はい・いいえ") {
      choices = ["はい", "いいえ"];
    } else if (type === "5 段階") {
      if (written.length === 2) labels = written;
      else if (written.length !== 0) problems.push(where + "5 段階の選択肢は「左の言葉｜右の言葉」の形で書くか、空にしてください（例: 不満｜満足）。");
    }

    const required = yesNoOf(cell(row, "必須"));
    if (required === null) problems.push(where + "必須は「はい」か「いいえ」にしてください（いまは「" + questionText_(cell(row, "必須")) + "」）。");

    const useText = questionText_(cell(row, "集計"));
    let use = "";
    if (useText !== "" && useText !== "自動") {
      if (QUESTION_USES.indexOf(useText) < 0) problems.push(where + "集計は 空 / 回答 / 評価 / 店舗 / 使わない のどれかにしてください（いまは「" + useText + "」）。");
      else use = useText;
    }
    if (use === "評価" && type !== "5 段階" && type !== "") problems.push(where + "集計「評価」は、種類が「5 段階」の質問にだけ付けられます。");
    if (use === "店舗" && type !== "選択" && type !== "") problems.push(where + "集計「店舗」は、種類が「選択」の質問にだけ付けられます。");

    const orderText = questionText_(cell(row, "並び"));
    const order = orderText === "" || !Number.isFinite(Number(orderText)) ? null : Number(orderText);
    questions.push({ row: rowNumber, order: order, title: title, type: type, choices: choices, labels: labels, required: required === true, help: questionText_(cell(row, "説明")), use: use, itemId: questionText_(cell(row, "項目 ID")) });
  }

  if (questions.length === 0) problems.push("質問シートに質問がありません。2 行目から、1 行に 1 つずつ質問を書いてください。");
  if (questions.length > QUESTION_MAX) problems.push("質問は " + QUESTION_MAX + " 個までにしてください（いまは " + questions.length + " 個）。");

  // 並び: 数が書いてあればその数、空なら行の順（書いてある数と同じなら行の順で後ろ）
  const keyed = questions.map((q, i) => ({ q: q, key: q.order === null ? i + 1 : q.order, i: i }));
  keyed.sort((a, b) => (a.key !== b.key ? a.key - b.key : a.i - b.i));
  const sorted = keyed.map((entry) => entry.q);

  // 集計の自動: 自由記述 → 回答（3 つまで）、最初の 5 段階 → 評価、質問に「店舗」「店」「院」を含む最初の選択 → 店舗
  const explicit = (name) => sorted.filter((q) => q.use === name);
  if (explicit("回答").length > ANSWER_USE_MAX) problems.push("集計「回答」は " + ANSWER_USE_MAX + " つまでにしてください（いまは " + explicit("回答").length + " つ）。");
  if (explicit("評価").length > 1) problems.push("集計「評価」は 1 つだけにしてください（いまは " + explicit("評価").length + " つ）。");
  if (explicit("店舗").length > 1) problems.push("集計「店舗」は 1 つだけにしてください（いまは " + explicit("店舗").length + " つ）。");
  let answers = explicit("回答").length;
  let hasRating = explicit("評価").length > 0;
  let hasStore = explicit("店舗").length > 0;
  for (let i = 0; i < sorted.length; i += 1) {
    const q = sorted[i];
    const personal = q.type === "自由記述" && isPersonalColumn(q.title);
    if (personal) notes.push("質問シートの " + q.row + " 行目「" + q.title + "」: 名前や連絡先を聞く質問は、分析には使いません（Claude に送りません）。アンケートに要らなければ消してください。");
    if (q.use !== "") continue;
    if (q.type === "自由記述" && !personal && answers < ANSWER_USE_MAX) {
      q.use = "回答";
      answers += 1;
    } else if (q.type === "5 段階" && !hasRating) {
      q.use = "評価";
      hasRating = true;
    } else if (q.type === "選択" && !hasStore && /店舗|店|院/.test(q.title)) {
      q.use = "店舗";
      hasStore = true;
    } else q.use = "使わない";
  }
  return { questions: sorted, problems: problems, notes: notes };
}

/** 集計から、分析で読む列（回答シートの見出し）を決める。無い役は "" */
export function columnsFromQuestions(questions) {
  const pick = (use) => questions.filter((q) => q.use === use).map((q) => q.title);
  const rating = pick("評価");
  const store = pick("店舗");
  return { answers: pick("回答"), date: TIMESTAMP_HEADER, rating: rating.length > 0 ? rating[0] : "", store: store.length > 0 ? store[0] : "" };
}

/** 質問シートの中身の指紋（項目 ID を除く）。フォームを作ったあとに質問シートを直したかを見る */
export function questionsHash(values) {
  const rows = Array.isArray(values) ? values : [];
  const header = rows.length === 0 ? [] : rows[0].map(questionText_);
  const idAt = header.indexOf("項目 ID");
  const kept = rows.map((row) => (Array.isArray(row) ? row : []).filter((cell, i) => i !== idAt).map(questionText_).join("\t"));
  return responseKey("", kept.join("\n"));
}

/**
 * 見本の質問（presets.js の形 { title, type, choices, required, help, use }）を、質問シートの値にする。
 * 選択肢はセル内の改行、5 段階の目盛りの言葉は「左｜右」、項目 ID は空。
 */
export function questionSheetValues(questions) {
  const values = [QUESTION_HEADERS.slice()];
  for (let i = 0; i < questions.length; i += 1) {
    const q = questions[i];
    const choices = q.type === "5 段階" ? (q.labels && q.labels.length === 2 ? q.labels.join("｜") : "") : q.type === "はい・いいえ" ? "" : (q.choices || []).join("\n");
    values.push([i + 1, q.title, q.type, choices, q.required ? "はい" : "いいえ", q.help || "", q.use || "", ""]);
  }
  return values;
}
