/**
 * 業種の見本 3 つ（純粋）: 質問 6 問・分析の分類 8 つ・業種・フォームのタイトル（設計書 §9-2）。
 * 「見本を読み込む」が質問シートと設定に書く。質問の形は questions.js の questionSheetValues が受け取る形。
 */
import { DEFAULT_FORM_DESCRIPTION } from "./config.js";

function question_(title, type, choices, required, use, labels) {
  return { title: title, type: type, choices: choices || [], labels: labels || [], required: required === true, help: "", use: use || "" };
}

/** クリニックの説明に足す 1 文（要配慮個人情報を Claude に送らないため。設計書 §9-2） */
export const CLINIC_DESCRIPTION_NOTE = "症状や治療の内容など、体のことはお書きにならないでください。診療のご相談は受付でお伺いします。";

export const PRESETS = {
  food: {
    key: "food",
    number: 1,
    label: "飲食（カフェ・レストラン）",
    industry: "飲食店",
    categories: ["味", "提供時間", "接客", "価格", "量", "清潔さ", "雰囲気", "その他"],
    formTitle: "{店名} ご来店アンケート",
    description: DEFAULT_FORM_DESCRIPTION,
    questions: [
      question_("本日のご満足度をお聞かせください", "5 段階", [], true, "評価", ["不満", "満足"]),
      question_("ご利用の店舗", "選択", ["駅前店", "本町店"], false, "店舗"),
      question_("ご来店は何回目ですか", "選択", ["はじめて", "2〜4 回目", "5 回目以上"], false, "使わない"),
      question_("良かった点をお聞かせください", "自由記述", [], false, "回答"),
      question_("気になった点・ご要望をお聞かせください", "自由記述", [], false, "回答"),
      question_("また来たいと思われましたか", "はい・いいえ", [], false, "使わない"),
    ],
  },
  salon: {
    key: "salon",
    number: 2,
    label: "サロン・美容",
    industry: "美容室",
    categories: ["仕上がり", "カウンセリング", "接客", "待ち時間", "価格", "予約・手続き", "清潔さ", "その他"],
    formTitle: "{店名} ご来店アンケート",
    description: DEFAULT_FORM_DESCRIPTION,
    questions: [
      question_("今回のご満足度（1〜5）", "5 段階", [], true, "評価"),
      question_("ご利用の店舗", "選択", ["駅前店", "本町店"], false, "店舗"),
      question_("本日のメニュー", "複数", ["カット", "カラー", "パーマ", "トリートメント", "ヘッドスパ", "その他"], false, ""),
      question_("良かった点・気になった点を自由にお書きください", "自由記述", [], false, "回答"),
      question_("ご要望があればお書きください（任意）", "自由記述", [], false, "回答"),
      question_("次回もご予約をお考えですか", "はい・いいえ", [], false, "使わない"),
    ],
  },
  clinic: {
    key: "clinic",
    number: 3,
    label: "クリニック",
    industry: "クリニック",
    categories: ["説明", "待ち時間", "受付・会計", "接客", "予約", "清潔さ", "設備・環境", "その他"],
    formTitle: "{店名} ご来院アンケート",
    description: DEFAULT_FORM_DESCRIPTION + CLINIC_DESCRIPTION_NOTE,
    questions: [
      question_("本日のご満足度をお聞かせください", "5 段階", [], true, "評価"),
      question_("ご来院の目的", "選択", ["初診", "再診", "健診や予防", "その他"], false, "使わない"),
      question_("待ち時間はいかがでしたか", "選択", ["短かった", "ふつう", "長かった"], false, "使わない"),
      question_("医師やスタッフの説明は分かりやすかったですか", "5 段階", [], false, "使わない", ["分かりにくい", "分かりやすい"]),
      question_("良かった点をお聞かせください", "自由記述", [], false, "回答"),
      question_("気になった点・ご要望をお聞かせください", "自由記述", [], false, "回答"),
    ],
  },
};

export const PRESET_KEYS = ["food", "salon", "clinic"];

/** 「見本を読み込む」で出す文 */
export const PRESET_PROMPT_TEXT = "読み込む業種の番号を入れてください。\n1 飲食（カフェ・レストラン）\n2 サロン・美容\n3 クリニック";
export const PRESET_RETRY_TEXT = "1〜3 の番号を入れてください。";

/** 入力された番号（全角も読む）→ 見本。1〜3 以外は null */
export function presetByNumber(text) {
  const number = Number(String(text === null || text === undefined ? "" : text).trim().replace(/[０-９]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0)));
  for (let i = 0; i < PRESET_KEYS.length; i += 1) if (PRESETS[PRESET_KEYS[i]].number === number) return PRESETS[PRESET_KEYS[i]];
  return null;
}

/** 見本の回答シートの見出し（フォームの回答シートと同じ形） */
export function presetHeader(preset) {
  return ["タイムスタンプ"].concat(preset.questions.map((q) => q.title));
}
