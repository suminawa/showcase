/**
 * 日付と時刻の扱い。GAS のグローバルには触らないので、Node でそのままテストできる。
 * 日付キーは "YYYY-MM-DD"（Asia/Tokyo）で統一する。
 * 元: AI 問い合わせ整理キット 1.0.0 の src/dates.js（toDateKey・formatStamp）。
 * 足したもの: 時刻つきの字（"2026/10/04 9:15:00"）も日付として読む 1 行と、addDays。
 */

/** Asia/Tokyo は夏時間が無いので、UTC からの +9 時間は年中変わらない */
const JST_OFFSET_MINUTES = 540;

/** Date かどうか。別の realm（node:vm やテストの偽の GAS）から来た Date も見分けられるよう、instanceof は使わない */
function isDate_(value) {
  return Object.prototype.toString.call(value) === "[object Date]";
}

function pad2_(value) {
  return value < 10 ? "0" + value : String(value);
}

/** Date を Asia/Tokyo にずらした Date にする。Date でなければ null */
function shifted_(value, offsetMinutes) {
  const offset = offsetMinutes === undefined ? JST_OFFSET_MINUTES : offsetMinutes;
  if (!isDate_(value) || Number.isNaN(value.getTime())) return null;
  return new Date(value.getTime() + offset * 60000);
}

/**
 * セルの値（Date・文字列・空）を "YYYY-MM-DD" にする。読めなければ null。
 * 日付セルは Date で来るので、+9 時間ずらしてから年月日を取り出す。
 */
export function toDateKey(value, offsetMinutes) {
  if (value === null || value === undefined || value === "") return null;
  if (isDate_(value)) {
    const at = shifted_(value, offsetMinutes);
    if (at === null) return null;
    return at.getUTCFullYear() + "-" + pad2_(at.getUTCMonth() + 1) + "-" + pad2_(at.getUTCDate());
  }
  // フォームの回答を CSV で貼ると、タイムスタンプが時刻つきの字で入る。時刻は落として日付だけを読む
  const text = String(value).trim().replace(/\s+\d{1,2}:\d{2}(:\d{2})?$/, "");
  const matched = text.match(/^(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})日?$/);
  if (!matched) return null;
  const year = Number(matched[1]);
  const month = Number(matched[2]);
  const day = Number(matched[3]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  // Date.UTC(2026, 1, 30) は 3/2 に繰り上がるだけで NaN にならないので、年月日で照合する
  const probe = new Date(Date.UTC(year, month - 1, day));
  if (probe.getUTCMonth() + 1 !== month || probe.getUTCDate() !== day) return null;
  return year + "-" + pad2_(month) + "-" + pad2_(day);
}

/** 日時の字。"2026-10-04 21:10:05"（Asia/Tokyo） */
export function formatStamp(value, offsetMinutes) {
  const at = shifted_(value, offsetMinutes);
  if (at === null) throw new Error("日時を読めません: " + String(value));
  return (
    at.getUTCFullYear() +
    "-" +
    pad2_(at.getUTCMonth() + 1) +
    "-" +
    pad2_(at.getUTCDate()) +
    " " +
    pad2_(at.getUTCHours()) +
    ":" +
    pad2_(at.getUTCMinutes()) +
    ":" +
    pad2_(at.getUTCSeconds())
  );
}

/** "2026-10-04" に days 日を足した日付キー（負の数なら前の日） */
export function addDays(dateKey, days) {
  const parts = String(dateKey).split("-");
  const at = new Date(Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]) + days));
  return at.getUTCFullYear() + "-" + pad2_(at.getUTCMonth() + 1) + "-" + pad2_(at.getUTCDate());
}
