/**
 * まとめの数えるところ（純粋。API を使わない）。「分析結果」シートから読み戻した行（rows.js の resultRecords）を数える。
 * 人が分類や感情を直した行は、直した値で数える。
 */
import { addDays } from "./dates.js";
import { NO_ANSWER_CATEGORY } from "./config.js";
import { SENTIMENTS } from "./schema.js";

export const REQUEST_LIST_MAX = 300;
export const ATTENTION_LIST_MAX = 10;

/** 期間の前の、同じ日数の期間 */
export function previousPeriod(from, days) {
  return { from: addDays(from, -days), to: addDays(from, -1) };
}

/** 「良い」「ふつう」「悪い」以外（手で書き替えた字など）は「ふつう」として数える */
function sentimentOf_(value) {
  return SENTIMENTS.indexOf(value) >= 0 ? value : "ふつう";
}

/** 評価の平均（小数 1 桁）。評価のある行が無ければ null */
function averageOf_(records) {
  let total = 0;
  let count = 0;
  for (let i = 0; i < records.length; i += 1) {
    if (typeof records[i].rating !== "number") continue;
    total += records[i].rating;
    count += 1;
  }
  return count === 0 ? null : Math.round((total / count) * 10) / 10;
}

/** 悪いの割合（整数の %）。件数が 0 なら null */
function rateOf_(bad, total) {
  return total === 0 ? null : Math.round((bad * 100) / total);
}

function newestFirst_(a, b) {
  const left = a.date === null ? "" : a.date;
  const right = b.date === null ? "" : b.date;
  if (left !== right) return left < right ? 1 : -1;
  return b.row - a.row;
}

function tally_(records) {
  const counts = { 良い: 0, ふつう: 0, 悪い: 0 };
  for (let i = 0; i < records.length; i += 1) counts[sentimentOf_(records[i].sentiment)] += 1;
  return counts;
}

/** 要望のある行の一覧（新しい順に最大 300）。id は q1 から */
export function requestList(records) {
  const withRequest = records.filter((record) => record.request !== "").sort(newestFirst_).slice(0, REQUEST_LIST_MAX);
  return withRequest.map((record, i) => ({ id: "q" + (i + 1), request: record.request, category: record.category, sentiment: sentimentOf_(record.sentiment), summary: record.summary, row: record.row }));
}

function inPeriod_(records, from, to) {
  return records.filter((record) => record.date !== null && record.date >= from && record.date <= to);
}

/**
 * records: rows.js の resultRecords の返り値。today: "YYYY-MM-DD"。
 * 返り値 { from, to, periodDays, total, noAnswer, sentiments, negativeRate, ratingAverage, hasRating,
 *          categories: [{ name, count, good, neutral, bad, badRate, ratingAverage, prevBadRate }],
 *          stores: [{ name, count, good, bad, ratingAverage }], attention: [{ row, date, category, summary }],
 *          previous: { total, negativeRate, ratingAverage } | null, requests: requestList の返り値 }
 */
export function aggregate(records, config, today) {
  const days = config.periodDays;
  let from = days === 0 ? today : addDays(today, -(days - 1));
  if (days === 0) {
    for (let i = 0; i < records.length; i += 1) if (records[i].date !== null && records[i].date < from) from = records[i].date;
  }
  const period = days === 0 ? records.slice() : inPeriod_(records, from, today);
  const answered = period.filter((record) => record.category !== NO_ANSWER_CATEGORY);
  const sentiments = tally_(answered);

  let previousAnswered = [];
  if (days > 0) {
    const before = previousPeriod(from, days);
    previousAnswered = inPeriod_(records, before.from, before.to).filter((record) => record.category !== NO_ANSWER_CATEGORY);
  }
  const previousSentiments = tally_(previousAnswered);
  const previous =
    previousAnswered.length === 0
      ? null
      : { total: previousAnswered.length, negativeRate: rateOf_(previousSentiments["悪い"], previousAnswered.length), ratingAverage: averageOf_(previousAnswered) };

  const names = config.categories.slice();
  for (let i = 0; i < answered.length; i += 1) if (names.indexOf(answered[i].category) < 0) names.push(answered[i].category);
  const categories = [];
  for (let i = 0; i < names.length; i += 1) {
    const inCategory = answered.filter((record) => record.category === names[i]);
    if (inCategory.length === 0 && config.categories.indexOf(names[i]) < 0) continue;
    const counts = tally_(inCategory);
    const before = previousAnswered.filter((record) => record.category === names[i]);
    categories.push({
      name: names[i],
      count: inCategory.length,
      good: counts["良い"],
      neutral: counts["ふつう"],
      bad: counts["悪い"],
      badRate: rateOf_(counts["悪い"], inCategory.length),
      ratingAverage: averageOf_(inCategory),
      prevBadRate: rateOf_(tally_(before)["悪い"], before.length),
    });
  }

  const stores = [];
  const storeNames = [];
  for (let i = 0; i < answered.length; i += 1) if (answered[i].store !== "" && storeNames.indexOf(answered[i].store) < 0) storeNames.push(answered[i].store);
  for (let i = 0; i < storeNames.length; i += 1) {
    const inStore = answered.filter((record) => record.store === storeNames[i]);
    const counts = tally_(inStore);
    stores.push({ name: storeNames[i], count: inStore.length, good: counts["良い"], bad: counts["悪い"], ratingAverage: averageOf_(inStore) });
  }

  const attention = answered
    .filter((record) => record.attention === true)
    .sort(newestFirst_)
    .slice(0, ATTENTION_LIST_MAX)
    .map((record) => ({ row: record.row, date: record.date, category: record.category, summary: record.summary }));

  return {
    from: from,
    to: today,
    periodDays: days,
    total: answered.length,
    noAnswer: period.length - answered.length,
    sentiments: sentiments,
    negativeRate: rateOf_(sentiments["悪い"], answered.length),
    ratingAverage: averageOf_(answered),
    hasRating: answered.some((record) => typeof record.rating === "number"),
    categories: categories,
    stores: stores,
    attention: attention,
    previous: previous,
    requests: requestList(answered),
  };
}
