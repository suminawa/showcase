/**
 * 入口。メニューから onOpen・initializeSheets・checkSettings・loadSamples・buildForm・analyzeNow・buildSummaryNow・toggleWeekly・showUsage。
 * 週 1 回のトリガーは runWeekly（分析する → まとめを作る → 送る）、README の「エディタからトリガーを足す」は runDaily（分析だけ）。
 * dist/Code.gs の先頭に来るファイル。top-level では、ほかのファイルの定数を使わない（束ねる順で後ろにあるため）。
 */
import { formatStamp, toDateKey } from "./dates.js";
import { ConfigError, DEFAULT_CATEGORIES, DEFAULT_FORM_DESCRIPTION, DEFAULT_FORM_TITLE, NO_ANSWER_CATEGORY, SHEET_QUESTIONS, SHEET_RESULTS, SHEET_SAMPLES, SHEET_SETTINGS, parseConfig, readConfigRows } from "./config.js";
import { parseQuestions, questionSheetValues, questionsHash } from "./questions.js";
import { FORM_MENU_TITLE, FORM_REOPEN_TEXT, NO_QUESTIONS_TEXT, SWITCH_FROM_SAMPLES_TEXT, formIdRows, formReport, formTexts, overwrittenRows, planForm, questionProblemsText, removeConfirmText, writebackFor } from "./form_plan.js";
import { PRESET_PROMPT_TEXT, PRESET_RETRY_TEXT, presetByNumber } from "./presets.js";
import { batches, excerptOf, sendableText } from "./responses.js";
import { buildResultRow, resultRecords } from "./rows.js";
import { buildRequest } from "./prompt.js";
import { fallbackResult, parseBatch } from "./schema.js";
import { aggregate } from "./summary.js";
import { buildSummaryRequest, failedSummary, needsSummaryCall, parseSummary, quietSummary } from "./summary_prompt.js";
import { summaryBlocks } from "./summary_sheet.js";
import { analysisReport, buildDigestText, buildErrorText, digestSubject, summaryReport } from "./notify_text.js";
import { addUsage, formatUsage } from "./usage.js";
import { sampleKeyForHeader, sampleResultFor, sampleSettingRows, sampleSummaryText, sampleValues, samplesLoadedText } from "./samples.js";
import { KEY_LATER_TEXT, KEY_PROMPT_TEXT, KEY_PROMPT_TITLE, answerState, apiKeyProblem, apiKeyTail, checkNotes, findProblems, keySavedText, needsKeyPrompt, planInit, summaryLines } from "./check.js";
import { CHECK_MENU_LABEL, INIT_MENU_LABEL, checkReport, initReport } from "./setup.js";
import { clearKeyRejected_, markKeyRejected_, readApiKey_, readDailyCount_, readFormSourceHash_, readKeyRejected_, readLastErrorNotice_, readMonthAnalyzed_, readMonthUsage_, saveApiKey_, saveDailyCount_, saveFormSourceHash_, saveLastErrorNotice_, saveMonthAnalyzed_, saveMonthUsage_, withLock_ } from "./gas_store.js";
import { appendResults_, applyInit_, checkFormWritable_, hasSheet_, overwriteResult_, prepareResultSheet_, readFirstHeader_, readSettingsValues_, readSetupSnapshot_, resultSheetGid_, writeQuestionIds_, writeQuestions_, writeSamples_, writeSettings_, writeSummary_ } from "./gas_sheets.js";
import { applyFormSettings_, applyPlan_, createForm_, linkDestination_, readFormState_, shortUrl_ } from "./gas_form.js";
import { ClaudeError, callClaude_ } from "./gas_claude.js";
import { notifyAll_ } from "./gas_notify.js";
import { sendDigestMail_ } from "./gas_mail.js";

const MENU_TITLE = "お客さまアンケート";
const SAMPLES_TITLE = "見本を読み込む";
const WEEKLY_FUNCTION = "runWeekly";
/**
 * Apps Script の 1 回の実行は 6 分まで。強制終了は finally も通らないので、その手前で切り上げる。
 * 時間は、1 回分の最初の呼び出しの前と、1 回分の中で割る・送り直す前に見る（1 回の呼び出しは 1 分ほどかかることがある）
 */
const DEADLINE_MS = 4.5 * 60000;
/** 週 1 回の実行では、分析は 3 分で切り上げる（残りの時間で、まとめを作って送る） */
const WEEKLY_ANALYSIS_MS = 3 * 60000;
/** まとめの API は、実行の始まりから 4 分を過ぎていたら呼ばない（表だけのまとめを作って送る。6 分で送信ごと落ちないように） */
const SUMMARY_CALL_MS = 4 * 60000;
/** ロックは分析・まとめ・フォームの作成で分け合う。どれかが動いているあいだに押されたとき */
const BUSY_MESSAGE = "ほかの処理（分析・まとめ・フォームの作成）が動いています。少しあとでお試しください。";
/** 「フォームを作る」で、確認の画面を出してロックを取り直す回数の上限（確認は多くて 3 つ。あいだに質問シートが変わると聞き直す） */
const FORM_ROUNDS = 5;
const FORM_CHANGED_TEXT = "確認のあいだに「質問」シートかフォームが何度も変わったため、フォームには触らずに止めました。もう一度「フォームを作る」を押してください。";
/** 見本の答えで再生した行の「モデル」 */
const SAMPLE_MODEL = "見本";
const NO_KEY_TEXT = "API キーが入っていません。メニュー「初期化」を押すと、キーを貼る欄が出ます。";
const NO_SETTINGS_TEXT = "「設定」シートがありません。メニュー「お客さまアンケート」→「初期化」を実行してください。";

function messageOf_(error) {
  return String(error && error.message ? error.message : error);
}

/** 失敗の文。敬体の前置きに、原因の文を添える */
function failureText_(error) {
  return "うまくいきませんでした。次の内容をご確認ください。\n\n" + messageOf_(error);
}

/** 読むもの一式（シートの値・キーの末尾・401 の印・今月の利用・最後にフォームを作ったときの質問シートの指紋） */
function fullSnapshot_(today) {
  const snapshot = readSetupSnapshot_(today);
  const key = readApiKey_();
  snapshot.apiKeyTail = key === "" ? "" : apiKeyTail(key);
  snapshot.keyRejected = readKeyRejected_();
  snapshot.usage = readMonthUsage_(today.slice(0, 7));
  snapshot.formSourceHash = readFormSourceHash_();
  snapshot.form = readFormState_(readConfigRows(snapshot.sheets[SHEET_SETTINGS] === undefined ? [] : snapshot.sheets[SHEET_SETTINGS]).config.formId);
  return snapshot;
}

/** 設定と回答シートを読んで、分析とまとめに使えるか確かめる。返り値 { snapshot, config, state, apiKey, useSamples } */
function prepareRun_(dateKey) {
  const snapshot = readSetupSnapshot_(dateKey);
  if (snapshot.sheets[SHEET_SETTINGS] === undefined) throw new ConfigError(NO_SETTINGS_TEXT);
  const config = parseConfig(snapshot.sheets[SHEET_SETTINGS]);
  const state = answerState(snapshot, config);
  const apiKey = readApiKey_();
  // キーが無いときだけ、見本の回答は同梱の答えで再生する（鍵を入れる前に画面を確かめられるように）
  const useSamples = apiKey === "" && state.sheetName === SHEET_SAMPLES;
  return { snapshot: snapshot, config: config, state: state, apiKey: apiKey, useSamples: useSamples };
}

/** Claude を 1 回呼ぶ。答えが返ったら（2xx）、前に立てた 401 の印を消す */
function askClaude_(apiKey, body) {
  const result = callClaude_(apiKey, body);
  clearKeyRejected_();
  return result;
}

/**
 * 1 回分（最大 20 件）を Claude に聞く。返り値 { error, timedOut }。
 * 呼び出しのたびに record(usage) を呼び（払った分をその場で残す）、答えが返るたびに deliver(group の番号の一覧, 答えの一覧) を呼ぶ
 * （その場で書いて数える）。6 分で強制終了されても、それまでの行と利用が残るように。
 * 答えの無い id は、その場で 1 回だけ送り直す。max_tokens で切れたら半分ずつに割って送り直す（1 段だけ）。
 * それでも無い回答は fallbackResult（要対応の「読み取れませんでした」）で書く。
 * 割る・送り直す前に overdue() を見て、切り上げの時刻を過ぎていたら送らずに返す（timedOut。答えの無い分は書かないので次回また送る）。
 * 途中の呼び出しが ClaudeError なら投げずに error に入れる（それまでに書いた分はそのまま）。ほかの例外はそのまま投げる。
 */
function askGroup_(apiKey, config, group, overdue, deliver, record) {
  const items = group.map((pending, i) => ({ id: "r" + (i + 1), at: i, rating: pending.response.rating, text: sendableText(pending.response.text, config) }));
  let timedOut = false;
  function call(list) {
    const result = askClaude_(apiKey, buildRequest(config, list));
    record(result.usage);
    return result;
  }
  function give(list, answers) {
    if (list.length > 0) deliver(list.map((item) => item.at), answers);
  }
  function stopIfLate() {
    if (overdue()) timedOut = true;
    return timedOut;
  }
  function ask(list, canSplit) {
    const result = call(list);
    if (result.stopReason === "max_tokens") {
      Logger.log("お客さまアンケート: 答えが長すぎて途中で切れました（" + list.length + " 件）。「回答の上限文字数」か「1 回に送る件数」を下げると収まりやすくなります");
      if (!canSplit || list.length < 2) {
        give(list, list.map(() => fallbackResult()));
        return;
      }
      const half = Math.ceil(list.length / 2);
      const halves = [list.slice(0, half), list.slice(half)];
      for (let i = 0; i < halves.length; i += 1) {
        if (stopIfLate()) return;
        ask(halves[i], false);
      }
      return;
    }
    const parsed = parseBatch(result.text, list.map((item) => item.id), config);
    const answered = list.filter((item) => Object.prototype.hasOwnProperty.call(parsed.answers, item.id));
    give(answered, answered.map((item) => parsed.answers[item.id]));
    if (parsed.missing.length === 0) return;
    const retry = list.filter((item) => parsed.missing.indexOf(item.id) >= 0);
    if (stopIfLate()) return;
    const again = call(retry);
    if (again.stopReason === "max_tokens") {
      give(retry, retry.map(() => fallbackResult()));
      return;
    }
    const second = parseBatch(again.text, parsed.missing, config);
    give(retry, retry.map((item) => (Object.prototype.hasOwnProperty.call(second.answers, item.id) ? second.answers[item.id] : fallbackResult())));
  }
  let error = null;
  try {
    ask(items, true);
  } catch (thrown) {
    if (!(thrown instanceof ClaudeError)) throw thrown;
    error = thrown;
  }
  return { error: error, timedOut: timedOut };
}

/**
 * 1 回の「分析する」。返り値 { stats, message, error }。error は設定の誤りなどで始められなかったとき。
 * 行は 1 回の API 呼び出しごとに書く（6 分で切れても、書いた分は残る）。今月の利用・1 日の件数・今月の件数は、
 * 書く前に残す（書けずに止まっても、払った分は数える）。limitMs は切り上げるまでの時間（省くと 4 分半）。
 */
export function runAnalysis_(now, limitMs) {
  const dateKey = toDateKey(now);
  const monthKey = dateKey.slice(0, 7);
  const stamp = formatStamp(now).slice(0, 16);
  const limit = limitMs === undefined ? DEADLINE_MS : limitMs;
  const overdue = () => new Date().getTime() - now.getTime() > limit;
  try {
    const outcome = withLock_(function () {
      const run = prepareRun_(dateKey);
      const config = run.config;
      const state = run.state;
      if (state.problems.length > 0) throw new ConfigError(state.problems[0]);
      if (run.apiKey === "" && !run.useSamples) throw new ConfigError(NO_KEY_TEXT);
      const stats = { analyzed: 0, empty: 0, remaining: state.pending.length, stop: "", perDay: config.perDay, skipped: 0, skipMessage: "", errorMessage: "", keyBlocked: false, samples: run.useSamples };
      if (state.pending.length === 0) return { stats: stats, message: analysisReport(stats) };

      // Claude に送る前に、書き込めるかを確かめる（保護されたシートに書けないまま API を使い続けないように）
      const header = prepareResultSheet_(state.index.header);
      const model = run.useSamples ? SAMPLE_MODEL : config.model;
      function write(pendings, answers) {
        const fresh = [];
        for (let i = 0; i < pendings.length; i += 1) {
          const response = pendings[i].response;
          const built = buildResultRow(header, { key: response.key, row: response.row, date: response.date, rating: response.rating, store: response.store, excerpt: excerptOf(response.text, config), answer: answers[i], stamp: stamp, model: model });
          if (pendings[i].overwriteRow === null) fresh.push(built.row);
          else overwriteResult_(pendings[i].overwriteRow, header, built.row);
        }
        appendResults_(header, fresh);
      }

      // 空の回答（特になし など）は API に送らず「（回答なし）」で書く
      const empties = state.pending.filter((pending) => pending.response.empty);
      write(empties, empties.map(() => ({ category: NO_ANSWER_CATEGORY, sentiment: "ふつう", request: "", summary: "", attention: false })));
      stats.empty = empties.length;
      stats.analyzed += empties.length;
      stats.remaining -= empties.length;

      const groups = batches(state.pending.filter((pending) => !pending.response.empty), config.batchSize);
      let daily = readDailyCount_(dateKey);
      let usage = readMonthUsage_(monthKey);
      let analyzedMonth = readMonthAnalyzed_(monthKey);
      // 呼び出しのたびに今月の利用を残す（6 分で強制終了されると finally も通らないので、払った分が抜けないように）
      function record(used) {
        if (used === null || used === undefined) return;
        usage = addUsage(usage, used);
        saveMonthUsage_(monthKey, usage);
      }
      for (let g = 0; g < groups.length; g += 1) {
        if (overdue()) {
          stats.stop = "time";
          break;
        }
        let group = groups[g];
        if (!run.useSamples) {
          if (daily >= config.perDay) {
            stats.stop = "daily";
            break;
          }
          group = group.slice(0, config.perDay - daily);
        }
        let delivered = 0;
        // 答えが返った分から、数えて残してから書く（書けずに止まっても、1 日の上限と今月の件数は抜けない）。残りは次回また送る
        const deliver = function (at, answers) {
          const done = at.map((i) => group[i]);
          delivered += done.length;
          stats.analyzed += done.length;
          stats.remaining -= done.length;
          if (!run.useSamples) {
            daily += done.length;
            analyzedMonth += done.length;
            saveDailyCount_(dateKey, daily);
            saveMonthAnalyzed_(monthKey, analyzedMonth);
          }
          write(done, answers);
        };
        let asked;
        if (run.useSamples) {
          deliver(group.map((pending, i) => i), group.map((pending) => sampleResultFor(pending.response.text) || fallbackResult()));
          asked = { error: null, timedOut: false };
        } else {
          asked = askGroup_(run.apiKey, config, group, overdue, deliver, record);
        }
        if (asked.timedOut) {
          stats.stop = "time";
          break;
        }
        const error = asked.error;
        if (error === null) continue;
        if ((error.status === 400 || error.status === 404) && error.spendLimit !== true) {
          // この回だけの問題（壊れた字が混ざっているなど）か、モデル名の誤り。答えの無い分は書かないので次回また試す
          stats.skipped += group.length - delivered;
          stats.skipMessage = error.message;
          continue;
        }
        if (error.status === 401) markKeyRejected_();
        stats.stop = "error";
        stats.errorMessage = error.message;
        // キーが受け付けられない・月の上限額に達したときは、このあとのまとめでも API を呼ばない
        stats.keyBlocked = error.status === 401 || error.spendLimit === true;
        break;
      }
      if (stats.stop === "" && !run.useSamples && stats.remaining > stats.skipped && daily >= config.perDay) stats.stop = "daily";
      const message = analysisReport(stats);
      Logger.log("お客さまアンケート: " + message.replace(/\n/g, " "));
      return { stats: stats, message: message };
    });
    // ロックが取れなかったとき。失敗ではないので、通知もしない
    if (outcome.busy === true) return { stats: null, message: BUSY_MESSAGE };
    return outcome;
  } catch (error) {
    Logger.log("お客さまアンケート: " + error);
    return { stats: null, message: "分析を実行できませんでした。\n" + messageOf_(error), error: error };
  }
}

/** まとめを送り先へ。pending はまだ分析していない回答の件数。返り値は送れなかった宛先 */
function sendDigest_(config, agg, summary, sheetUrl, pending) {
  const text = buildDigestText(agg, summary, config, sheetUrl, pending);
  const failed = [];
  if (config.targets.indexOf("mail") >= 0 && !sendDigestMail_(config.mailTo, digestSubject(agg, config), text)) failed.push("mail");
  return failed.concat(notifyAll_(config, text).failed);
}

/**
 * 1 回の「まとめを作る」。返り値 { message, error }。
 * blockedMessage が空でなければ API を呼ばず、表だけでまとめを作ってその文を添える（直前の分析でキーが止められたとき）。
 * now（実行の始まり）から 4 分を過ぎていたら API を呼ばず、表だけでまとめを作る（週 1 回の実行で、分析に時間を使ったとき）。
 */
export function runSummary_(now, blockedMessage) {
  const dateKey = toDateKey(now);
  const monthKey = dateKey.slice(0, 7);
  const stamp = formatStamp(now).slice(0, 16);
  try {
    const outcome = withLock_(function () {
      const run = prepareRun_(dateKey);
      const config = run.config;
      const results = run.snapshot.sheets[SHEET_RESULTS];
      const agg = aggregate(resultRecords(results === undefined ? [] : results), config, dateKey);
      let summary;
      let extra = "";
      if (!needsSummaryCall(agg)) summary = quietSummary();
      else if (run.useSamples) summary = parseSummary(sampleSummaryText(agg, sampleKeyForHeader(run.state.values[0])), agg);
      else if (run.apiKey === "") throw new ConfigError(NO_KEY_TEXT);
      else if (blockedMessage) {
        summary = failedSummary();
        extra = blockedMessage;
      } else if (new Date().getTime() - now.getTime() > SUMMARY_CALL_MS) {
        // まとめの 1 回で 6 分を越えると、まとめも送信も落ちる。数える部分だけで作って送る
        Logger.log("お客さまアンケート: 分析に時間を使ったため、今週の 3 つは作らずにまとめを作ります");
        summary = failedSummary();
      } else {
        try {
          const result = askClaude_(run.apiKey, buildSummaryRequest(config, agg));
          if (result.usage !== null) saveMonthUsage_(monthKey, addUsage(readMonthUsage_(monthKey), result.usage));
          summary = result.stopReason === "max_tokens" ? failedSummary() : parseSummary(result.text, agg);
        } catch (error) {
          if (!(error instanceof ClaudeError)) throw error;
          if (error.status === 401) markKeyRejected_();
          // 数える部分は API が無くても出るので、表だけでまとめを作る
          summary = failedSummary();
          extra = error.message;
        }
      }
      const model = run.useSamples ? SAMPLE_MODEL : config.model;
      const sheetUrl = writeSummary_(summaryBlocks(agg, summary, { storeName: config.storeName, stamp: stamp, model: model, gid: resultSheetGid_() }));
      const pending = run.state.problems.length > 0 ? 0 : run.state.pending.length;
      const failed = config.targets.length > 0 ? sendDigest_(config, agg, summary, sheetUrl, pending) : [];
      const message = summaryReport(agg, summary, pending, failed) + (extra === "" ? "" : "\n" + extra);
      Logger.log("お客さまアンケート: " + message.replace(/\n/g, " "));
      return { message: message };
    });
    if (outcome.busy === true) return { message: BUSY_MESSAGE };
    return outcome;
  } catch (error) {
    Logger.log("お客さまアンケート: " + error);
    return { message: "まとめを作れませんでした。\n" + messageOf_(error), error: error };
  }
}

/**
 * トリガーからの失敗を送り先へ知らせる。同じエラーは 1 日 1 通まで（違うエラーは同じ日でも送る）。
 * 設定が壊れていても送り先の行は読む（readConfigRows は誤りがあっても読む）。
 * 元: AI 問い合わせ整理キット 1.0.0 の reportError_（lastErrorNotice）。
 */
export function reportError_(error, stamp) {
  try {
    const config = readConfigRows(readSettingsValues_()).config;
    if (config.targets.length === 0) return;
    const detail = messageOf_(error);
    const notice = String(stamp).slice(0, 10) + " " + detail.slice(0, 40);
    if (readLastErrorNotice_() === notice) {
      Logger.log("お客さまアンケート: 同じエラーは 1 日 1 通だけ通知します。今回は実行ログだけに残します");
      return;
    }
    saveLastErrorNotice_(notice);
    const text = buildErrorText(error, stamp);
    if (config.targets.indexOf("mail") >= 0) sendDigestMail_(config.mailTo, "【お客さまアンケート】自動の実行が止まりました", text);
    notifyAll_(config, text);
  } catch (sendError) {
    Logger.log("お客さまアンケート: エラー通知も送れませんでした: " + sendError);
  }
}

/** メニュー「分析する（未処理だけ）」 */
export function analyzeNow() {
  SpreadsheetApp.getUi().alert(runAnalysis_(new Date()).message);
}

/** メニュー「まとめを作る」 */
export function buildSummaryNow() {
  SpreadsheetApp.getUi().alert(runSummary_(new Date()).message);
}

/**
 * 週 1 回のトリガー。getUi は呼ばない（トリガーからだと例外になる）。
 * 分析は 3 分で切り上げ、残りの時間でまとめを作って送る（残りの回答は次の「分析する」か次の週に回す）
 */
export function runWeekly() {
  const now = new Date();
  const stamp = formatStamp(now);
  const analysis = runAnalysis_(now, WEEKLY_ANALYSIS_MS);
  if (analysis.error !== undefined) {
    reportError_(analysis.error, stamp);
    return;
  }
  if (analysis.stats !== null && analysis.stats.stop === "error") reportError_(new Error(analysis.stats.errorMessage), stamp);
  // 401 や月の上限額で止まったキーで、まとめのためにもう一度呼ばない
  const blocked = analysis.stats !== null && analysis.stats.keyBlocked === true ? analysis.stats.errorMessage : "";
  const summary = runSummary_(now, blocked);
  if (summary.error !== undefined) reportError_(summary.error, stamp);
}

/** 毎日「分析する」だけを動かしたい人向け（README の「エディタからトリガーを足す」） */
export function runDaily() {
  const now = new Date();
  const analysis = runAnalysis_(now);
  if (analysis.error !== undefined) reportError_(analysis.error, formatStamp(now));
  else if (analysis.stats !== null && analysis.stats.stop === "error") reportError_(new Error(analysis.stats.errorMessage), formatStamp(now));
}

/** 足りないシート・見出し・設定の行だけを足す。最後に、キーが無いか前回 401 なら、キーを貼る欄を出す */
export function initializeSheets() {
  const ui = SpreadsheetApp.getUi();
  try {
    const snapshot = fullSnapshot_(toDateKey(new Date()));
    const plan = planInit(snapshot);
    applyInit_(plan);
    ui.alert(initReport(plan, plan.nextStep));
    if (!needsKeyPrompt(snapshot)) return;
    const response = ui.prompt(KEY_PROMPT_TITLE, KEY_PROMPT_TEXT, ui.ButtonSet.OK_CANCEL);
    if (response.getSelectedButton() !== ui.Button.OK) {
      ui.alert(KEY_LATER_TEXT);
      return;
    }
    const key = String(response.getResponseText()).trim();
    const problem = apiKeyProblem(key);
    if (problem !== "") {
      ui.alert(problem + "\n" + KEY_LATER_TEXT);
      return;
    }
    saveApiKey_(key);
    ui.alert(keySavedText(apiKeyTail(key)));
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

function weeklyTriggers_() {
  return ScriptApp.getProjectTriggers().filter((trigger) => trigger.getHandlerFunction() === WEEKLY_FUNCTION);
}

/** 直すところを全部並べる。無ければ、これから何が起きるかを短く出す */
export function checkSettings() {
  const ui = SpreadsheetApp.getUi();
  try {
    const snapshot = fullSnapshot_(toDateKey(new Date()));
    snapshot.hasTrigger = weeklyTriggers_().length > 0;
    const problems = findProblems(snapshot);
    ui.alert(checkReport(problems, problems.length === 0 ? summaryLines(snapshot) : [], "", checkNotes(snapshot)));
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/** 業種の番号を聞く。［キャンセル］なら null。1〜3 以外はもう一度聞く */
function askPreset_(ui) {
  let text = PRESET_PROMPT_TEXT;
  for (;;) {
    const response = ui.prompt(SAMPLES_TITLE, text, ui.ButtonSet.OK_CANCEL);
    if (response.getSelectedButton() !== ui.Button.OK) return null;
    const preset = presetByNumber(response.getResponseText());
    if (preset !== null) return preset;
    text = PRESET_RETRY_TEXT + "\n\n" + PRESET_PROMPT_TEXT;
  }
}

/**
 * 業種の見本（質問・分類・業種・フォームのタイトル・見本の回答）を読み込む（設計書 §8-2）。
 * フォームを作ってあり、回答シートがフォームの回答を向いているときは、回答シートを見本に切り替えない。
 */
export function loadSamples() {
  const ui = SpreadsheetApp.getUi();
  try {
    if (!hasSheet_(SHEET_SETTINGS)) {
      ui.alert(NO_SETTINGS_TEXT);
      return;
    }
    const preset = askPreset_(ui);
    if (preset === null) return;
    const today = toDateKey(new Date());
    const snapshot = readSetupSnapshot_(today);
    const questions = snapshot.sheets[SHEET_QUESTIONS];
    if (questions !== undefined && questions.length > 1) {
      const replace = ui.alert(SAMPLES_TITLE, "「質問」シートを見本の質問で置き換えます。いまの質問は「質問（前）」シートに移します。よろしいですか？", ui.ButtonSet.OK_CANCEL);
      if (replace !== ui.Button.OK) return;
    }
    writeQuestions_(questionSheetValues(preset.questions));
    const config = readConfigRows(snapshot.sheets[SHEET_SETTINGS]).config;
    let pairs = [["業種", preset.industry]];
    let categoriesKept = false;
    if (config.categories.join(",") === DEFAULT_CATEGORIES.join(",")) pairs.push(["分類", preset.categories.join(", ")]);
    else if (ui.alert(SAMPLES_TITLE, "設定の「分類」を見本の分類（" + preset.categories.join("、") + "）に替えます。よろしいですか？", ui.ButtonSet.OK_CANCEL) === ui.Button.OK) pairs.push(["分類", preset.categories.join(", ")]);
    else categoriesKept = true;
    if (config.formTitle === DEFAULT_FORM_TITLE) pairs.push(["フォームのタイトル", preset.formTitle]);
    if (config.formDescription === DEFAULT_FORM_DESCRIPTION && preset.description !== DEFAULT_FORM_DESCRIPTION) pairs.push(["フォームの説明", preset.description]);
    writeSamples_(sampleValues(preset.key, today));
    const formExists = config.formId !== "";
    // 本物の回答を読んでいる人の設定を、見本で上書きしない
    const switched = !(formExists && config.sheetName !== "" && config.sheetName !== SHEET_SAMPLES);
    if (switched) pairs = pairs.concat(sampleSettingRows(preset.key));
    writeSettings_(pairs);
    ui.alert(samplesLoadedText(preset, { switched: switched, formExists: formExists, categoriesKept: categoriesKept }));
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/**
 * メニュー「フォームを作る」（設計書 §3-5）。キーは要らない（Claude を使わない）。
 * 質問シートに直すところがあればフォームに触らない。設定の「フォーム ID」のフォームがあれば直し、無ければ作る。
 * 確認の画面と終わりの alert はロックの外で出す（読んでいるあいだ、分析や週 1 回のトリガーを待たせない）。
 * 確認が要るときはロックを返して聞き、答えを持ってロックを取り直し、シートとフォームを読み直してから当てる。
 */
export function buildForm() {
  const ui = SpreadsheetApp.getUi();
  try {
    // switchSamples・reopen: OK をもらった確認。remove: 消してよいと OK をもらった項目 ID。keepRemoved: 消すのを断られた
    const granted = { switchSamples: false, reopen: false, remove: [], keepRemoved: false };
    for (let round = 0; round < FORM_ROUNDS; round += 1) {
      const outcome = withLock_(function () {
        return buildFormLocked_(granted);
      });
      if (outcome.busy === true) {
        ui.alert(BUSY_MESSAGE);
        return;
      }
      if (outcome.ask === undefined) {
        ui.alert(outcome.message);
        return;
      }
      const ok = ui.alert(FORM_MENU_TITLE, outcome.ask.text, ui.ButtonSet.OK_CANCEL) === ui.Button.OK;
      if (outcome.ask.kind === "remove") {
        // ［キャンセル］なら消さずに残して進める
        if (ok) granted.remove = outcome.ask.ids;
        else granted.keepRemoved = true;
      } else if (ok) {
        granted[outcome.ask.kind] = true;
      } else {
        return;
      }
    }
    ui.alert(FORM_CHANGED_TEXT);
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/**
 * ロックの中で読み直して、確認が足りなければ { ask: { kind, text, ids } } を返す（何も変えない）。
 * そろっていればフォームに当てて { message }（終わりの alert の文）を返す。止めるときも { message }。
 */
function buildFormLocked_(granted) {
  const snapshot = readSetupSnapshot_(toDateKey(new Date()));
  if (snapshot.sheets[SHEET_SETTINGS] === undefined) return { message: NO_SETTINGS_TEXT };
  const values = snapshot.sheets[SHEET_QUESTIONS];
  if (values === undefined || values.length < 2) return { message: NO_QUESTIONS_TEXT };
  const parsed = parseQuestions(values);
  if (parsed.problems.length > 0) return { message: questionProblemsText(parsed.problems) };
  const config = readConfigRows(snapshot.sheets[SHEET_SETTINGS]).config;
  if (config.sheetName === SHEET_SAMPLES && !granted.switchSamples) return { ask: { kind: "switchSamples", text: SWITCH_FROM_SAMPLES_TEXT } };
  const state = readFormState_(config.formId);
  if ((state.state === "missing" || state.state === "elsewhere") && !granted.reopen) return { ask: { kind: "reopen", text: FORM_REOPEN_TEXT } };
  const current = state.state === "ok";
  const plan = planForm(current ? state.items : [], parsed.questions, { removeDeleted: config.removeDeleted && !granted.keepRemoved });
  // 消す質問が、OK をもらったときから増えていたら聞き直す
  if (plan.remove.some((item) => granted.remove.indexOf(item.id) < 0)) return { ask: { kind: "remove", text: removeConfirmText(plan.remove), ids: plan.remove.map((item) => item.id) } };

  checkFormWritable_();
  const texts = formTexts(config);
  let form = state.form;
  if (!current) {
    form = createForm_(texts.title);
    // 作ったらすぐ ID を残す（このあとで止まっても、次に押すと同じフォームを直す。2 つ目を作らない）
    writeSettings_(formIdRows({ editUrl: form.getEditUrl(), id: form.getId() }));
  }
  applyFormSettings_(form, texts);
  // 質問を 1 つ足すごとに項目 ID を書く（途中で止まっても、次に押したときに同じ質問を足さない）
  const applied = applyPlan_(form, plan, function (row, id) {
    writeQuestionIds_([{ row: row, id: id }]);
  });
  const sheetName = linkDestination_(form, current && state.linked);
  const url = shortUrl_(form);
  // 回答シートの 1 列目の見出しはアカウントの言語で変わる（英語なら Timestamp）ので、見つけたシートから読む
  const dateHeader = sheetName === "" ? "" : readFirstHeader_(sheetName);
  const all = writebackFor(parsed.questions, sheetName, { url: url, editUrl: form.getEditUrl(), id: form.getId() }, dateHeader);
  // 回答のシートが見つからないときは、フォームの 3 行だけを書く（同じフォームを次に直せるように）
  const pairs = sheetName === "" ? all.slice(-3) : all;
  const old = writeSettings_(pairs);
  saveFormSourceHash_(questionsHash(values));
  return {
    message: formReport({
      created: !current,
      counts: plan.counts,
      keep: plan.keep.map((item) => item.title),
      removed: plan.remove.map((item) => item.title),
      url: url,
      sheetName: sheetName,
      sheetFound: sheetName !== "",
      choicesRemoved: applied.choicesRemoved && state.responses > 0,
      overwritten: overwrittenRows(old, pairs),
    }),
  };
}

/** メニュー「今月の AI 利用」 */
export function showUsage() {
  const ui = SpreadsheetApp.getUi();
  try {
    const monthKey = toDateKey(new Date()).slice(0, 7);
    const config = readConfigRows(readSettingsValues_()).config;
    ui.alert(formatUsage(readMonthUsage_(monthKey), config.model, monthKey) + "\n今月分析した回答: " + readMonthAnalyzed_(monthKey) + " 件");
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/** メニュー「毎週送る（入れる / 外す）」。押すたびに入れる・外すを切り替える（毎週月曜 8 時） */
export function toggleWeekly() {
  const ui = SpreadsheetApp.getUi();
  try {
    const existing = weeklyTriggers_();
    if (existing.length > 0) {
      for (let i = 0; i < existing.length; i += 1) ScriptApp.deleteTrigger(existing[i]);
      ui.alert("毎週の自動実行を外しました。「分析する」と「まとめを作る」は、メニューからいつでも使えます。");
      return;
    }
    ScriptApp.newTrigger(WEEKLY_FUNCTION).timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(8).inTimezone("Asia/Tokyo").create();
    ui.alert("毎週月曜 8 時に、分析とまとめと送信をするようにしました。止めるときは、同じメニューをもう一度押してください。");
  } catch (error) {
    ui.alert(failureText_(error));
  }
}

/** シートを開いたときにメニューを足す */
export function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu(MENU_TITLE)
    .addItem(INIT_MENU_LABEL, "initializeSheets")
    .addItem(CHECK_MENU_LABEL, "checkSettings")
    .addSeparator()
    .addItem("見本を読み込む", "loadSamples")
    .addItem("フォームを作る", "buildForm")
    .addSeparator()
    .addItem("分析する（未処理だけ）", "analyzeNow")
    .addItem("まとめを作る", "buildSummaryNow")
    .addSeparator()
    .addItem("毎週送る（入れる / 外す）", "toggleWeekly")
    .addItem("今月の AI 利用", "showUsage")
    .addToUi();
}
