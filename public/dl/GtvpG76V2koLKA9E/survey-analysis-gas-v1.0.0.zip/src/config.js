/**
 * 「設定」シート（「項目」「値」の 2 列）を読んで、検証済みの設定にする。
 * 行が無いか空欄なら既定値、知らない行は無視する（買い手がメモ行を足しても壊れない）。
 * 誤りは最初の 1 つで止めずに全部集める（readConfigRows）。分析とまとめは parseConfig（誤りがあれば最初の 1 つで止める）を使う。
 * 項目名の空白・半角括弧・大文字小文字の揺れは、AI 問い合わせ整理キットの normalizeKey_ と同じにそろえる。
 */

export class ConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = "ConfigError";
  }
}

/** シートの名前（キットが作るもの） */
export const SHEET_SETTINGS = "設定";
export const SHEET_RESULTS = "分析結果";
export const SHEET_SUMMARY = "まとめ";
export const SHEET_SAMPLES = "見本の回答";
export const SHEET_QUESTIONS = "質問";

/** 設定シートに並べるキー。README.ja.md の表はこの並びと一致させる（docs.test.mjs） */
export const CONFIG_KEYS = [
  "店名",
  "業種",
  "フォームのタイトル",
  "フォームの説明",
  "送信後のメッセージ",
  "質問を減らしても消す",
  "フォームの URL",
  "フォームの編集 URL",
  "フォーム ID",
  "回答シート",
  "回答の列",
  "日付の列",
  "評価の列",
  "評価の最大",
  "店舗の列",
  "分類",
  "伏せ字にする",
  "モデル",
  "1 回に送る件数",
  "1 日の上限",
  "回答の上限文字数",
  "まとめの期間（日）",
  "まとめの送り先",
  "送り先メール",
  "Slack Webhook URL",
  "Discord Webhook URL",
  "LINE チャネルアクセストークン",
  "LINE 送信先 ID",
];

/** 分類に使えない名前（回答が空の行に付ける印） */
export const NO_ANSWER_CATEGORY = "（回答なし）";
export const OTHER_CATEGORY = "その他";
export const CATEGORY_MAX = 12;
export const ANSWER_COLUMN_MAX = 3;
export const MAIL_TO_MAX = 5;

export const DEFAULT_CATEGORIES = ["接客", "待ち時間", "価格", "品質", "清潔さ", "予約・手続き", "その他"];

/** 既定の分類ごとの目安。system に入れて、分け方をそろえる。業種の見本（presets.js）の分類の目安もここに置く */
export const CATEGORY_HINTS = {
  "接客": "スタッフの対応・言葉づかい・説明・気づかい",
  "待ち時間": "予約時刻からの待ち、会計や受付の待ち、提供までの時間",
  "価格": "料金の高い安い、料金の分かりやすさ、支払い方法",
  "品質": "施術・料理・商品・治療の仕上がりや中身",
  "清潔さ": "店内・トイレ・器具・スタッフの身だしなみの清潔さ",
  "予約・手続き": "予約の取りやすさ、予約方法、受付や書類の手続き、キャンセル",
  "その他": "上のどれにも当てはまらないもの（立地・駐車場・設備・雰囲気など）",
  "味": "料理や飲み物の味・温度・おいしさ",
  "提供時間": "注文から料理や飲み物が出るまでの時間",
  "量": "料理の量・盛り付けの多さ少なさ",
  "雰囲気": "店内の雰囲気・音楽・明るさ・居心地",
  "仕上がり": "カット・カラー・パーマ・施術の仕上がりともち",
  "カウンセリング": "施術の前の相談・希望の聞き取り・提案",
  "説明": "医師やスタッフの説明の分かりやすさ・丁寧さ",
  "受付・会計": "受付や会計の対応・手続き・支払い",
  "予約": "予約の取りやすさ・予約方法・日時の変更",
  "設備・環境": "待合室・駐車場・設備・院内の環境",
};

/** フォームの説明の既定文（設計書 §3-5） */
export const DEFAULT_FORM_DESCRIPTION =
  "本日はご来店いただき、ありがとうございました。今後のサービスづくりのため、1 分ほどのアンケートにご協力ください。いただいた回答は、サービス改善のため AI を使って集計します。回答欄には、お名前や連絡先を書かないでください。";
export const DEFAULT_FORM_TITLE = "{店名} ご来店アンケート";
export const DEFAULT_CONFIRMATION = "ご回答ありがとうございました。いただいた声はスタッフ全員で読み、よりよいお店づくりに活かします。";

export const DELIVERY_TARGETS = ["mail", "slack", "discord", "line"];

export const DEFAULT_CONFIG = {
  storeName: "",
  industry: "",
  formTitle: DEFAULT_FORM_TITLE,
  formDescription: DEFAULT_FORM_DESCRIPTION,
  confirmationMessage: DEFAULT_CONFIRMATION,
  removeDeleted: false,
  formUrl: "",
  formEditUrl: "",
  formId: "",
  sheetName: "",
  answerColumns: [],
  dateColumn: "",
  ratingColumn: "",
  ratingMax: 5,
  storeColumn: "",
  categories: DEFAULT_CATEGORIES.slice(),
  mask: true,
  model: "claude-sonnet-5",
  batchSize: 20,
  perDay: 500,
  answerLimit: 1000,
  periodDays: 7,
  targets: [],
  mailTo: [],
  slackWebhookUrl: "",
  discordWebhookUrl: "",
  lineToken: "",
  lineTo: "",
};

/**
 * 初期化で足す設定の行（CONFIG_KEYS の順に [項目, 値]）。Webhook と LINE の 4 行と、キットが書く 3 行
 * （フォームの URL・編集 URL・ID）は空、ほかは既定値
 */
export const DEFAULT_ROWS = [
  ["店名", ""],
  ["業種", ""],
  ["フォームのタイトル", DEFAULT_FORM_TITLE],
  ["フォームの説明", DEFAULT_FORM_DESCRIPTION],
  ["送信後のメッセージ", DEFAULT_CONFIRMATION],
  ["質問を減らしても消す", "いいえ"],
  ["フォームの URL", ""],
  ["フォームの編集 URL", ""],
  ["フォーム ID", ""],
  ["回答シート", ""],
  ["回答の列", ""],
  ["日付の列", ""],
  ["評価の列", ""],
  ["評価の最大", "5"],
  ["店舗の列", ""],
  ["分類", DEFAULT_CATEGORIES.join(", ")],
  ["伏せ字にする", "TRUE"],
  ["モデル", "claude-sonnet-5"],
  ["1 回に送る件数", "20"],
  ["1 日の上限", "500"],
  ["回答の上限文字数", "1000"],
  ["まとめの期間（日）", "7"],
  ["まとめの送り先", ""],
  ["送り先メール", ""],
  ["Slack Webhook URL", ""],
  ["Discord Webhook URL", ""],
  ["LINE チャネルアクセストークン", ""],
  ["LINE 送信先 ID", ""],
];

/** 見本の Webhook URL（README の例）に入っている印 */
export const SAMPLE_URL_MARK = "XXXXXXXXX/YYYYYYYYY";

/** 数の項目: [項目, 設定のキー, 下限, 上限] */
const NUMBER_KEYS = [
  ["1 回に送る件数", "batchSize", 5, 50],
  ["1 日の上限", "perDay", 1, 5000],
  ["回答の上限文字数", "answerLimit", 200, 5000],
  ["まとめの期間（日）", "periodDays", 0, 365],
];

/** 半角括弧・空白・大文字小文字の揺れを吸収して、キーを突き合わせられる形にする */
function normalizeKey_(key) {
  return String(key)
    .replace(/[(]/g, "（")
    .replace(/[)]/g, "）")
    .replace(/\s+/g, "")
    .toLowerCase();
}

/** 初期化（setup.js の missingSettingRows）と「設定を確かめる」が、読み取りと同じそろえ方で項目名を比べるための入口 */
export function configKeyOf(key) {
  return normalizeKey_(key);
}

function configText_(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

/** カンマ（半角・全角・読点）で区切って、空の要素を落とす（重なりは残す。分類の重なりを知らせるため） */
function splitList_(text) {
  const out = [];
  const parts = configText_(text).split(/[,、，]/);
  for (let i = 0; i < parts.length; i += 1) {
    const part = parts[i].trim();
    if (part !== "") out.push(part);
  }
  return out;
}

function unique_(list) {
  const out = [];
  for (let i = 0; i < list.length; i += 1) if (out.indexOf(list[i]) < 0) out.push(list[i]);
  return out;
}

function booleanOf_(value) {
  if (typeof value === "boolean") return value;
  const text = configText_(value).toLowerCase();
  if (["true", "yes", "1", "はい", "する", "○", "on"].indexOf(text) >= 0) return true;
  if (["false", "no", "0", "いいえ", "しない", "×", "off"].indexOf(text) >= 0) return false;
  return null;
}

/** まとめやプロンプトで使う店の呼び名。「みなと美容室（美容室）」「当店」 */
export function storeLabel(config) {
  const name = config.storeName === "" ? "当店" : config.storeName;
  return config.industry === "" ? name : name + "（" + config.industry + "）";
}

/**
 * rows: [[項目, 値], ...]（見出し行が混ざっていてもよい）。
 * 返り値 { config, problems }。誤りのある項目は既定値にしたうえで、problems に 1 文ずつ入れる。
 */
export function readConfigRows(rows) {
  const raw = {};
  const source = Array.isArray(rows) ? rows : [];
  for (let i = 0; i < source.length; i += 1) {
    const row = Array.isArray(source[i]) ? source[i] : [];
    const key = normalizeKey_(configText_(row[0]));
    if (key === "") continue;
    raw[key] = row[1] === null || row[1] === undefined ? "" : row[1];
  }
  const problems = [];

  function rawOf(key) {
    const normalized = normalizeKey_(key);
    return Object.prototype.hasOwnProperty.call(raw, normalized) ? raw[normalized] : undefined;
  }
  function textOf(key) {
    return configText_(rawOf(key));
  }
  function wrong(key, how, example) {
    problems.push("「設定」シートの「" + key + "」は" + how + "（いまは「" + textOf(key) + "」）。" + (example === undefined ? "" : example));
  }

  const config = {};
  for (const name in DEFAULT_CONFIG) config[name] = Array.isArray(DEFAULT_CONFIG[name]) ? DEFAULT_CONFIG[name].slice() : DEFAULT_CONFIG[name];

  config.storeName = textOf("店名");
  config.industry = textOf("業種");
  if (textOf("フォームのタイトル") !== "") config.formTitle = textOf("フォームのタイトル");
  if (textOf("フォームの説明") !== "") config.formDescription = textOf("フォームの説明");
  if (textOf("送信後のメッセージ") !== "") config.confirmationMessage = textOf("送信後のメッセージ");
  if (textOf("質問を減らしても消す") !== "") {
    const remove = booleanOf_(rawOf("質問を減らしても消す"));
    if (remove === null) wrong("質問を減らしても消す", " はい か いいえ にしてください");
    else config.removeDeleted = remove;
  }
  config.formUrl = textOf("フォームの URL");
  config.formEditUrl = textOf("フォームの編集 URL");
  config.formId = textOf("フォーム ID");
  config.sheetName = textOf("回答シート");
  config.answerColumns = unique_(splitList_(rawOf("回答の列")));
  if (config.answerColumns.length > ANSWER_COLUMN_MAX) {
    wrong("回答の列", " " + ANSWER_COLUMN_MAX + " 列までにしてください");
    config.answerColumns = config.answerColumns.slice(0, ANSWER_COLUMN_MAX);
  }
  config.dateColumn = textOf("日付の列");
  config.ratingColumn = textOf("評価の列");
  config.storeColumn = textOf("店舗の列");

  if (textOf("評価の最大") !== "") {
    const max = Number(textOf("評価の最大"));
    if (max === 5 || max === 10) config.ratingMax = max;
    else wrong("評価の最大", " 5 か 10 にしてください");
  }

  if (textOf("分類") !== "") {
    const written = splitList_(rawOf("分類"));
    const seen = [];
    for (let i = 0; i < written.length; i += 1) {
      if (seen.indexOf(written[i]) >= 0 && problems.indexOf("「設定」シートの「分類」に「" + written[i] + "」が 2 つあります。1 つにしてください。") < 0) {
        problems.push("「設定」シートの「分類」に「" + written[i] + "」が 2 つあります。1 つにしてください。");
      }
      if (written[i] === NO_ANSWER_CATEGORY) problems.push("「設定」シートの「分類」に「" + NO_ANSWER_CATEGORY + "」は使えません（回答が空の行の印です）。別の名前にしてください。");
      seen.push(written[i]);
    }
    const categories = unique_(written).filter((name) => name !== NO_ANSWER_CATEGORY);
    if (categories.indexOf(OTHER_CATEGORY) < 0) categories.push(OTHER_CATEGORY);
    if (categories.length > CATEGORY_MAX) {
      problems.push("「設定」シートの「分類」は「その他」を含めて " + CATEGORY_MAX + " 個までにしてください（いまは " + categories.length + " 個）。");
    }
    config.categories = categories.length > CATEGORY_MAX ? categories.filter((name) => name !== OTHER_CATEGORY).slice(0, CATEGORY_MAX - 1).concat([OTHER_CATEGORY]) : categories;
  }

  if (rawOf("伏せ字にする") !== undefined && textOf("伏せ字にする") !== "") {
    const mask = booleanOf_(rawOf("伏せ字にする"));
    if (mask === null) wrong("伏せ字にする", " TRUE か FALSE にしてください");
    else config.mask = mask;
  }

  if (textOf("モデル") !== "") {
    if (textOf("モデル").indexOf("claude-") === 0) config.model = textOf("モデル");
    else wrong("モデル", " claude- で始まる名前にしてください", "例: claude-sonnet-5");
  }

  for (let i = 0; i < NUMBER_KEYS.length; i += 1) {
    const spec = NUMBER_KEYS[i];
    if (textOf(spec[0]) === "") continue;
    const number = Number(textOf(spec[0]));
    if (Number.isInteger(number) && number >= spec[2] && number <= spec[3]) config[spec[1]] = number;
    else wrong(spec[0], " " + spec[2] + "〜" + spec[3] + " の整数にしてください");
  }

  const targets = [];
  const wanted = splitList_(rawOf("まとめの送り先"));
  for (let i = 0; i < wanted.length; i += 1) {
    const name = wanted[i].toLowerCase();
    if (DELIVERY_TARGETS.indexOf(name) < 0) {
      problems.push("「設定」シートの「まとめの送り先」に書けるのは mail / slack / discord / line です（いまは「" + wanted[i] + "」）。");
    } else if (targets.indexOf(name) < 0) targets.push(name);
  }
  config.targets = targets;

  const mailTo = unique_(splitList_(rawOf("送り先メール")));
  for (let i = 0; i < mailTo.length; i += 1) {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mailTo[i])) {
      problems.push("「設定」シートの「送り先メール」の「" + mailTo[i] + "」はメールアドレスの形ではありません。");
    }
  }
  if (mailTo.length > MAIL_TO_MAX) wrong("送り先メール", " " + MAIL_TO_MAX + " 人までにしてください");
  config.mailTo = mailTo.slice(0, MAIL_TO_MAX);

  config.slackWebhookUrl = textOf("Slack Webhook URL");
  config.discordWebhookUrl = textOf("Discord Webhook URL");
  config.lineToken = textOf("LINE チャネルアクセストークン");
  config.lineTo = textOf("LINE 送信先 ID");
  // URL とトークンは人に見せない鍵なので、文には出さない
  const hooks = [
    ["slack", "Slack Webhook URL", config.slackWebhookUrl],
    ["discord", "Discord Webhook URL", config.discordWebhookUrl],
  ];
  for (let i = 0; i < hooks.length; i += 1) {
    const target = hooks[i][0];
    const key = hooks[i][1];
    const url = hooks[i][2];
    if (targets.indexOf(target) < 0) continue;
    if (url === "") problems.push("「まとめの送り先」に " + target + " がありますが、「" + key + "」が空です。設定シートのその行を埋めてください。");
    else if (url.indexOf("https://") !== 0) problems.push("「設定」シートの「" + key + "」は https:// で始まる URL です。前後に余分な字が入っていないかも確かめてください。");
    else if (url.indexOf(SAMPLE_URL_MARK) >= 0) problems.push("「設定」シートの「" + key + "」が見本の URL のままです。ご自身の URL に貼り替えてください。");
  }
  if (targets.indexOf("line") >= 0) {
    if (config.lineToken === "") problems.push("「まとめの送り先」に line がありますが、「LINE チャネルアクセストークン」が空です。設定シートのその行を埋めてください。");
    if (config.lineTo === "") problems.push("「まとめの送り先」に line がありますが、「LINE 送信先 ID」が空です。設定シートのその行を埋めてください。");
  }
  return { config: config, problems: problems };
}

/** 誤りがあれば最初の 1 つで ConfigError。分析とまとめの入口で使う */
export function parseConfig(rows) {
  const read = readConfigRows(rows);
  if (read.problems.length > 0) throw new ConfigError(read.problems[0] + "メニュー「設定を確かめる」で、直すところを全部確かめられます。");
  return read.config;
}
