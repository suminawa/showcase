/**
 * 「まとめ」シートの中身（純粋）。2 次元の値と、太字・灰色・薄い赤にするセルの一覧を作る。
 * gas_sheets.js の writeSummary_ は、シートを消してこれを書くだけ。
 * 色は条件付き書式でなく、書くときに決める（消すたびに条件付き書式が溜まらないように）。
 */
import { safeCell } from "./rows.js";

export const SUMMARY_WIDTH = 7;
/** 悪いの割合が前の期間よりこれだけ（ポイント）以上高いと、薄い赤 */
export const WORSE_POINTS = 10;
export const EMPTY_TABLE_TEXT = "この期間はありません";
export const SUMMARY_FOOTNOTES = [
  "（ご参考）この表は「分析結果」シートの値から作っています。分類や感情を手で直した場合は、直した値で数えています。",
  "このシートは「まとめを作る」のたびに作り直します。メモは別のシートにお書きください。",
];

function percent_(rate) {
  return rate === null ? "" : rate + "%";
}

function average_(value) {
  return value === null ? "" : value;
}

function worse_(now, before) {
  return now !== null && before !== null && before !== undefined && now - before >= WORSE_POINTS;
}

/** 全体の 1 行。「件数 27 ｜ 良い 14 ｜ ふつう 5 ｜ 悪い 8（30%。前の期間 22%）｜ 評価の平均 4.1（前の期間 4.3）」 */
export function overallLine(agg) {
  if (agg.total === 0) return EMPTY_TABLE_TEXT;
  const s = agg.sentiments;
  const before = agg.previous;
  let line = "件数 " + agg.total + " ｜ 良い " + s["良い"] + " ｜ ふつう " + s["ふつう"] + " ｜ 悪い " + s["悪い"] + "（" + agg.negativeRate + "%" + (before === null ? "" : "。前の期間 " + before.negativeRate + "%") + "）";
  if (agg.ratingAverage !== null) line += "｜ 評価の平均 " + agg.ratingAverage + (before === null || before.ratingAverage === null ? "" : "（前の期間 " + before.ratingAverage + "）");
  return line;
}

/** 分析結果の行へのリンク（HYPERLINK の式。表示は「行 12」） */
export function rowLink(gid, row) {
  return '=HYPERLINK("#gid=' + gid + "&range=A" + row + '","行 ' + row + '")';
}

/**
 * agg: summary.js の aggregate。summary: summary_prompt.js の parseSummary / quietSummary / failedSummary。
 * meta: { storeName, stamp: "YYYY-MM-DD HH:mm", model, gid }。
 * 返り値 { values, boldRows, headerRows, redCells: [[行, 列]] }（すべて 0 始まり。values の各行は SUMMARY_WIDTH 列）。
 */
export function summaryBlocks(agg, summary, meta) {
  const values = [];
  const boldRows = [];
  const headerRows = [];
  const redCells = [];
  function add(row) {
    values.push(row);
    return values.length - 1;
  }
  function title(text) {
    boldRows.push(add([text]));
  }
  function header(cells) {
    headerRows.push(add(cells));
  }

  boldRows.push(add([safeCell((meta.storeName === "" ? "当店" : meta.storeName) + " お客さまの声のまとめ")]));
  add(["期間 " + agg.from + "〜" + agg.to + "｜回答 " + agg.total + " 件（回答なし " + agg.noAnswer + " 件）｜作成 " + meta.stamp + "｜" + meta.model]);
  add([]);

  title("今週の 3 つ");
  if (summary.actions.length === 0) add([summary.actionsNote]);
  for (let i = 0; i < summary.actions.length; i += 1) add([safeCell(i + 1 + ". " + summary.actions[i].text), safeCell("根拠: " + summary.actions[i].basis)]);
  add([]);

  const overallAt = add(["全体", overallLine(agg)]);
  boldRows.push(overallAt);
  if (agg.previous !== null && worse_(agg.negativeRate, agg.previous.negativeRate)) redCells.push([overallAt, 1]);
  add([]);

  title("分類ごと");
  const counted = agg.categories.filter((category) => category.count > 0);
  if (counted.length === 0) add([EMPTY_TABLE_TEXT]);
  else {
    header(["分類", "件数", "良い", "ふつう", "悪い", "悪いの割合"].concat(agg.hasRating ? ["評価の平均"] : []));
    for (let i = 0; i < counted.length; i += 1) {
      const c = counted[i];
      const at = add([safeCell(c.name), c.count, c.good, c.neutral, c.bad, percent_(c.badRate)].concat(agg.hasRating ? [average_(c.ratingAverage)] : []));
      if (worse_(c.badRate, c.prevBadRate)) redCells.push([at, 5]);
    }
  }
  add([]);

  title("多い要望（上位 10）");
  if (summary.themes.length === 0) add([summary.themesNote === "" ? EMPTY_TABLE_TEXT : summary.themesNote]);
  else {
    header(["順位", "要望", "件数", "例"]);
    for (let i = 0; i < summary.themes.length; i += 1) add([i + 1, safeCell(summary.themes[i].title), summary.themes[i].count, safeCell(summary.themes[i].example)]);
  }
  add([]);

  if (agg.stores.length > 0) {
    title("店舗ごと");
    header(["店舗", "件数", "良い", "悪い"].concat(agg.hasRating ? ["評価の平均"] : []));
    for (let i = 0; i < agg.stores.length; i += 1) {
      const s = agg.stores[i];
      add([safeCell(s.name), s.count, s.good, s.bad].concat(agg.hasRating ? [average_(s.ratingAverage)] : []));
    }
    add([]);
  }

  title("すぐに読んでほしい回答");
  if (agg.attention.length === 0) add([EMPTY_TABLE_TEXT]);
  else {
    header(["日付", "分類", "要約", "分析結果の行"]);
    for (let i = 0; i < agg.attention.length; i += 1) {
      const a = agg.attention[i];
      add([a.date === null ? "" : a.date, safeCell(a.category), safeCell(a.summary), rowLink(meta.gid, a.row)]);
    }
  }
  add([]);
  for (let i = 0; i < SUMMARY_FOOTNOTES.length; i += 1) add([SUMMARY_FOOTNOTES[i]]);

  const square = values.map((row) => {
    const line = row.slice(0, SUMMARY_WIDTH);
    while (line.length < SUMMARY_WIDTH) line.push("");
    return line;
  });
  return { values: square, boldRows: boldRows, headerRows: headerRows, redCells: redCells };
}
