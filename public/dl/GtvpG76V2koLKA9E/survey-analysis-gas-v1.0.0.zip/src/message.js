/**
 * Slack / Discord / LINE それぞれの送信データを作る。
 * 元: AI 問い合わせ整理キット 1.0.0 の src/message.js の buildPayload（本文の組み立ては notify_text.js に置く）。
 */

const SLACK_LIMIT = 39000;
const DISCORD_LIMIT = 1900;
const LINE_LIMIT = 5000;

function truncate_(text, limit) {
  if (text.length <= limit) return text;
  return text.slice(0, limit - 8) + "\n…（以下省略）";
}

/** Slack の本文で特別な意味を持つ & < > を字のままにする（<!channel> のような呼び出しやリンクとして読まれないように） */
function slackEscape_(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * Slack は text、Discord は content、LINE は push message の中身。
 * 本文には Claude が作った文（要望のまとまり・今週の 3 つ）も入るので、Slack は & < > を字のままにし、
 * Discord は @everyone・@here・人やロールへの呼び出しを鳴らさない（allowed_mentions）。
 */
export function buildPayload(text, target, options) {
  if (target === "discord") return { content: truncate_(text, DISCORD_LIMIT), allowed_mentions: { parse: [] } };
  if (target === "line") {
    const to = options === undefined || options === null || options.lineTo === undefined ? "" : String(options.lineTo);
    return { to: to, messages: [{ type: "text", text: truncate_(text, LINE_LIMIT) }] };
  }
  return { text: slackEscape_(truncate_(text, SLACK_LIMIT)) };
}
