/**
 * 分析の 1 回（最大 20 件）で Claude に返させる JSON の型（structured outputs の JSON Schema）と、答えの検証・補正。
 * 型は API が守らせるが、id の照合・分類の一覧・文字数はこちらでも見る（件数の制約はスキーマに書かない）。
 */
import { OTHER_CATEGORY } from "./config.js";

export const SENTIMENTS = ["良い", "ふつう", "悪い"];
export const SUMMARY_LIMIT = 20;
export const REQUEST_LIMIT = 80;
/** 2 回聞いても答えが無かった回答の要約 */
export const UNREAD_SUMMARY = "読み取れませんでした";

export function buildBatchSchema(categories) {
  return {
    type: "object",
    properties: {
      results: {
        type: "array",
        items: {
          type: "object",
          properties: {
            id: { type: "string", description: "回答の id（r1 など）をそのまま" },
            category: { type: "string", enum: categories.slice() },
            sentiment: { type: "string", enum: SENTIMENTS.slice() },
            request: { type: "string", description: "お客さまの要望を 1 文で。無ければ空文字" },
            summary: { type: "string", description: "20 字以内の要約。体言止め" },
            attention: { type: "boolean", description: "すぐに人が読むべき回答なら true" },
          },
          required: ["id", "category", "sentiment", "request", "summary", "attention"],
          additionalProperties: false,
        },
      },
    },
    required: ["results"],
    additionalProperties: false,
  };
}

/** 2 回聞いても答えが無かった回答。要対応にして人に読んでもらう（「やり直す」に ✓ を入れれば次回やり直せる） */
export function fallbackResult() {
  return { category: OTHER_CATEGORY, sentiment: "ふつう", request: "", summary: UNREAD_SUMMARY, attention: true };
}

function schemaText_(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

/** 元: AI 問い合わせ整理キット 1.0.0 の src/schema.js の boolean_ */
function boolean_(value) {
  if (typeof value === "boolean") return value;
  const text = schemaText_(value).toLowerCase();
  return text === "true" || text === "1" || text === "yes";
}

/**
 * Claude の返した文字列 → { answers: { r1: { category, sentiment, request, summary, attention } }, missing: ["r7"] }。
 * 送っていない id は捨て、同じ id が 2 つあれば最初を使う。壊れた JSON は全件 missing。
 */
export function parseBatch(text, sentIds, config) {
  const answers = {};
  let raw = null;
  try {
    raw = JSON.parse(String(text === null || text === undefined ? "" : text));
  } catch (error) {
    raw = null;
  }
  const results = raw !== null && typeof raw === "object" && Array.isArray(raw.results) ? raw.results : [];
  for (let i = 0; i < results.length; i += 1) {
    const item = results[i];
    if (item === null || typeof item !== "object") continue;
    const id = schemaText_(item.id);
    if (sentIds.indexOf(id) < 0 || Object.prototype.hasOwnProperty.call(answers, id)) continue;
    const category = schemaText_(item.category);
    const sentiment = schemaText_(item.sentiment);
    answers[id] = {
      category: config.categories.indexOf(category) >= 0 ? category : OTHER_CATEGORY,
      sentiment: SENTIMENTS.indexOf(sentiment) >= 0 ? sentiment : "ふつう",
      request: schemaText_(item.request).slice(0, REQUEST_LIMIT),
      summary: schemaText_(item.summary).slice(0, SUMMARY_LIMIT),
      attention: boolean_(item.attention),
    };
  }
  const missing = sentIds.filter((id) => !Object.prototype.hasOwnProperty.call(answers, id));
  return { answers: answers, missing: missing };
}
