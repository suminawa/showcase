import { test } from "node:test";
import assert from "node:assert/strict";
import { answerAll, loadBundle } from "./fakes.mjs";
import { DEFAULT_ROWS } from "../src/config.js";
import { HEADERS } from "../src/rows.js";
import { sampleValues } from "../src/samples.js";
import { questionSheetValues } from "../src/questions.js";
import { PRESETS } from "../src/presets.js";

const KEY = "sk-ant-api03-" + "x".repeat(20) + "a1B2";
const SLACK = "https://hooks.slack.com/services/T000/B000/real";
const FORM = "フォームの回答 1";

/** 初期化済みの設定シート（extra で行を足す・上書きする） */
function settings(extra) {
  return [["項目", "値"]].concat(DEFAULT_ROWS, extra || []);
}

/** フォームの回答（見本の 30 件）・設定・空の分析結果がある、キー入りのブック。settingsExtra で設定の行を足す */
function formBook(options) {
  const opts = options || {};
  const sheets = { [FORM]: sampleValues("salon", "2026-10-04"), 設定: settings(opts.settingsExtra), 分析結果: [HEADERS] };
  return loadBundle(Object.assign({ apiKey: KEY, sheets: sheets }, opts));
}

function claudeCalls(run) {
  return run.trace.fetched.filter((f) => f.url.indexOf("api.anthropic.com") >= 0);
}

function sentIds(body) {
  return Array.from(body.messages[0].content[0].text.matchAll(/<回答 id="(r\d+)"/g)).map((m) => m[1]);
}

function column(run, name) {
  const rows = run.sheets["分析結果"].rows;
  const at = rows[0].indexOf(name);
  return rows.slice(1).map((row) => row[at]);
}

test("初期化 → キーを貼る → 分析する: Claude に 2 回（20 件と 9 件）、分析結果に 29 行＋回答なし 1 行", () => {
  const run = loadBundle({ sheets: { [FORM]: sampleValues("salon", "2026-10-04") }, promptReply: { button: "OK", text: " " + KEY + " " } });
  run.entry.initializeSheets();
  assert.ok(run.trace.alerts[0].startsWith("初期化しました。"));
  assert.ok(run.trace.alerts[0].includes("・シートを作りました: 設定、分析結果、質問\n"));
  assert.ok(run.trace.alerts[0].endsWith("続けて、API キーを貼る欄を出します。"));
  assert.equal(run.trace.prompts.length, 1);
  assert.equal(run.props.ANTHROPIC_API_KEY, KEY);
  assert.equal(run.trace.alerts[1], "API キーを保存しました（末尾 …a1B2）。次は「設定を確かめる」を実行してください。");
  assert.deepEqual(run.sheets["分析結果"].rows[0], HEADERS);
  assert.equal(run.sheets[FORM].rows.length, 31, "回答シートには書かない");

  run.entry.analyzeNow();
  const calls = claudeCalls(run);
  assert.equal(calls.length, 2);
  assert.deepEqual(run.trace.claudeBodies.map((body) => sentIds(body).length), [20, 9]);
  assert.equal(calls[0].headers["x-api-key"], KEY);
  assert.equal(calls[0].headers["anthropic-version"], "2023-06-01");
  const sent = run.trace.claudeBodies.map((body) => body.messages[0].content[0].text).join("\n");
  assert.ok(sent.includes("〔メール〕") && sent.includes("〔電話〕"), "伏せ字にしてから送る");
  for (const secret of ["taro.minato@example.com", "03-0000-1234", "駅前店", "本町店", "2026-10-0"]) assert.equal(sent.includes(secret), false, secret + " を送っている");
  assert.equal(run.sheets["分析結果"].rows.length, 31);
  assert.equal(column(run, "分類").filter((c) => c === "（回答なし）").length, 1);
  assert.equal(column(run, "モデル")[0], "claude-sonnet-5");
  assert.equal(column(run, "やり直す").every((cell) => cell === false), true);
  const redoAt = HEADERS.indexOf("やり直す") + 1;
  assert.equal(run.sheets["分析結果"].formats["2," + redoAt].checkbox, true, "やり直すはチェックボックス");
  assert.equal(run.trace.alerts[2], "新しく 30 件を分析しました（回答なし 1 件を含みます）。残り 0 件。");
  assert.equal(run.props["count:2026-10-04"], "29");
  assert.equal(JSON.parse(run.props["usage:2026-10"]).count, 2);
  assert.equal(run.props["analyzed:2026-10"], "29");

  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 2, "2 回目の分析は API を呼ばない");
  assert.equal(run.trace.alerts[3], "新しい回答はありません。分析結果はそろっています。");
});

test("やり直すに ✓ の行だけを送り、同じ行を上書きして ✓ を外す", () => {
  const first = formBook();
  first.entry.analyzeNow();
  const results = first.sheets["分析結果"].rows.map((row) => row.slice());
  const redoAt = results[0].indexOf("やり直す");
  results[5][redoAt] = true;
  const excerpt = results[5][results[0].indexOf("回答（抜粋）")];
  const run = formBook({ sheets: { [FORM]: sampleValues("salon", "2026-10-04"), 設定: settings(), 分析結果: results }, claudeReply: (body) => answerAll(body, { category: "品質", summary: "やり直した要約" }) });
  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 1);
  assert.deepEqual(sentIds(run.trace.claudeBodies[0]), ["r1"]);
  const after = run.sheets["分析結果"].rows;
  assert.equal(after.length, 31, "行は増えない");
  assert.equal(after[5][after[0].indexOf("分類")], "品質");
  assert.equal(after[5][after[0].indexOf("要約")], "やり直した要約");
  assert.equal(after[5][redoAt], false);
  assert.equal(after[5][after[0].indexOf("回答（抜粋）")], excerpt);
  assert.equal(run.trace.alerts[0], "新しく 1 件を分析しました。残り 0 件。");
});

test("max_tokens で切れたら、その 20 件を 10 件ずつに割って送り直す（1 段だけ）", () => {
  const run = formBook({
    claudeReply: (body, n) => (n === 1 ? { text: '{"results":[', stop_reason: "max_tokens" } : answerAll(body)),
  });
  run.entry.analyzeNow();
  assert.deepEqual(run.trace.claudeBodies.map((body) => sentIds(body).length), [20, 10, 10, 9]);
  assert.deepEqual(sentIds(run.trace.claudeBodies[2]), ["r11", "r12", "r13", "r14", "r15", "r16", "r17", "r18", "r19", "r20"]);
  assert.equal(run.sheets["分析結果"].rows.length, 31);
  assert.equal(column(run, "要約").filter((s) => s === "読み取れませんでした").length, 0);
});

test("答えの無い id はその場で 1 回だけ送り直し、それでも無ければ「読み取れませんでした」・要対応で書く", () => {
  const run = formBook({
    claudeReply: (body, n) => {
      const reply = JSON.parse(answerAll(body).text);
      if (n === 1) reply.results = reply.results.filter((r) => r.id !== "r7");
      if (n === 2) reply.results = [];
      return { text: JSON.stringify(reply) };
    },
  });
  run.entry.analyzeNow();
  assert.deepEqual(run.trace.claudeBodies.map((body) => sentIds(body).length), [20, 1, 9]);
  assert.deepEqual(sentIds(run.trace.claudeBodies[1]), ["r7"]);
  const unread = column(run, "要約").indexOf("読み取れませんでした");
  assert.ok(unread >= 0);
  assert.equal(column(run, "要対応")[unread], "✓");
  assert.equal(column(run, "分類")[unread], "その他");
});

test("401 で止まり keyRejected を立てる。設定を確かめるが名指しし、初期化でキーを貼る欄がまた出る", () => {
  const run = formBook({ claudeReply: () => ({ status: 401, body: JSON.stringify({ type: "error", error: { type: "authentication_error" } }) }) });
  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 1, "401 はやり直さない");
  assert.equal(run.props.keyRejected, "true");
  assert.equal(run.trace.alerts[run.trace.alerts.length - 1], "新しく 1 件を分析しました（回答なし 1 件を含みます）。残り 29 件。\nAPI キーが受け付けられませんでした。メニュー「初期化」を押すと、キーを貼る欄が出ます。");
  for (const alert of run.trace.alerts) assert.equal(alert.includes(KEY), false, "キーを画面に出さない");
  run.entry.checkSettings();
  assert.ok(run.trace.alerts[run.trace.alerts.length - 1].includes("前回、API キーが受け付けられませんでした（401）。"));
  run.entry.initializeSheets();
  assert.equal(run.trace.prompts.length, 1, "キーはあるが 401 だったので、貼り直す欄が出る");
});

test("400 はその回を飛ばして次回に回す。月の上限額（400 の本文に credit）はそこで止める", () => {
  const skipped = formBook({ claudeReply: () => ({ status: 400, body: JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "model: not found" } }) }) });
  skipped.entry.analyzeNow();
  assert.equal(claudeCalls(skipped).length, 2, "20 件と 9 件の 2 回とも試す");
  assert.equal(skipped.trace.alerts[0], "新しく 1 件を分析しました（回答なし 1 件を含みます）。残り 29 件。\nリクエストが受け付けられませんでした（400）。「モデル」の設定を確かめてください。29 件は次回もう一度試します。");
  assert.equal(skipped.sheets["分析結果"].rows.length, 2, "飛ばした分は書かない");
  const limited = formBook({ claudeReply: () => ({ status: 400, body: JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "Your credit balance is too low" } }) }) });
  limited.entry.analyzeNow();
  assert.equal(claudeCalls(limited).length, 1);
  assert.ok(limited.trace.alerts[0].endsWith("\nAnthropic Console で決めた月の上限額に達しました。Console で上限を上げるか、来月までお待ちください。"));
});

test("キーなしで見本（業種 2）を読み込むと、API を呼ばずに同梱の答えで分析とまとめを再生する。1〜3 以外の番号は聞き直す", () => {
  const run = loadBundle({ sheets: { シート1: [] }, promptReplies: [{ button: "CANCEL", text: "" }, { button: "OK", text: "9" }, { button: "OK", text: "2" }] });
  run.entry.initializeSheets();
  run.entry.loadSamples();
  assert.equal(run.trace.prompts[1], "読み込む業種の番号を入れてください。\n1 飲食（カフェ・レストラン）\n2 サロン・美容\n3 クリニック");
  assert.ok(run.trace.prompts[2].startsWith("1〜3 の番号を入れてください。\n\n読み込む業種の番号を入れてください。"));
  assert.equal(run.trace.alerts[run.trace.alerts.length - 1], "サロン・美容の見本を読み込みました。「質問」シートを直してから「フォームを作る」を押すと、この質問でフォームができます。キーが無くても、「分析する」「まとめを作る」で見本の回答を使った動きを確かめられます。");
  assert.equal(run.sheets["見本の回答"].rows.length, 31);
  assert.deepEqual(run.sheets["質問"].rows.map((row) => row[1]).slice(1), ["今回のご満足度（1〜5）", "ご利用の店舗", "本日のメニュー", "良かった点・気になった点を自由にお書きください", "ご要望があればお書きください（任意）", "次回もご予約をお考えですか"]);
  const setting = (key) => run.sheets["設定"].rows.find((row) => row[0] === key)[1];
  assert.equal(setting("業種"), "美容室");
  assert.equal(setting("分類"), "仕上がり, カウンセリング, 接客, 待ち時間, 価格, 予約・手続き, 清潔さ, その他");
  assert.equal(setting("回答シート"), "見本の回答");
  run.entry.analyzeNow();
  assert.equal(run.trace.alerts[run.trace.alerts.length - 1], "見本の答えで 30 件を分析しました（回答なし 1 件を含みます）。残り 0 件。");
  assert.equal(column(run, "モデル").every((m) => m === "見本"), true);
  assert.equal(column(run, "分類").filter((c) => c === "仕上がり").length, 6);
  run.entry.buildSummaryNow();
  assert.equal(run.trace.fetched.length, 0, "Claude にも通知先にも送らない");
  const summary = run.sheets["まとめ"].rows.map((row) => row[0]);
  assert.equal(summary[0], "当店 お客さまの声のまとめ");
  assert.equal(summary[summary.indexOf("今週の 3 つ") + 1], "1. 予約時刻からの待ちが続いています。混み合う時間帯は、受付で待ち時間の目安をお伝えしてみてください。");
  assert.ok(run.trace.alerts[run.trace.alerts.length - 1].startsWith("まとめを作りました（回答 15 件、要望のまとまり 7 個）。"));
});

test("見本を読み込み直すと、前の質問は「質問（前）」に移る。フォームの回答を読んでいる設定と、書き換えた分類は変えない（確認の いいえ）", () => {
  const extra = [["フォーム ID", "1FORM"], ["回答シート", "フォームの回答 1"], ["分類", "味, 接客, その他"]];
  const sheets = { [FORM]: sampleValues("salon", "2026-10-04"), 設定: settings(extra), 分析結果: [HEADERS], 質問: questionSheetValues(PRESETS.salon.questions) };
  const run = formBook({ sheets: sheets, promptReplies: [{ button: "OK", text: "1" }], confirms: ["OK", "CANCEL"] });
  run.entry.loadSamples();
  assert.equal(run.trace.alerts[0], "「質問」シートを見本の質問で置き換えます。いまの質問は「質問（前）」シートに移します。よろしいですか？");
  assert.equal(run.trace.alerts[1], "設定の「分類」を見本の分類（味、提供時間、接客、価格、量、清潔さ、雰囲気、その他）に替えます。よろしいですか？");
  assert.ok(run.order.indexOf("質問（前）") >= 0);
  assert.equal(run.sheets["質問"].rows[1][1], "本日のご満足度をお聞かせください");
  const setting = (key) => run.sheets["設定"].rows.filter((row) => row[0] === key).pop()[1];
  assert.equal(setting("回答シート"), "フォームの回答 1");
  assert.equal(setting("分類"), "味, 接客, その他");
  assert.equal(setting("業種"), "飲食店");
  assert.deepEqual(run.trace.alerts[2].split("\n").slice(1), [
    "見本の回答を分析するときは、設定の「回答シート」を「見本の回答」にしてください。",
    "フォームはすでにあるので、次の「フォームを作る」で見本の質問が新しい質問として足されます。前の質問は、設定「質問を減らしても消す」に従います。",
    "設定の「分類」は替えていません。",
  ]);
});

test("まとめを作ると まとめ シートを書き直し、Slack に 1 通（回答の本文と要約は載せない）", () => {
  const run = formBook({
    settingsExtra: [["店名", "サロン みなと"], ["まとめの送り先", "slack"], ["Slack Webhook URL", SLACK]],
    claudeReply: (body) => {
      if (body.output_config.format.schema.properties.themes) {
        return { text: JSON.stringify({ themes: [{ title: "土曜午前の予約枠の追加", ids: ["q1", "q2"] }], actions: [{ text: "土曜午前の予約枠を見直してみてください。", basis: "要望 2 件" }] }) };
      }
      return answerAll(body, { request: "土曜午前の予約枠の追加", summary: "秘密の要約" });
    },
  });
  run.entry.analyzeNow();
  run.entry.buildSummaryNow();
  assert.equal(run.sheets["まとめ"].rows[0][0], "サロン みなと お客さまの声のまとめ");
  const summary = run.trace.claudeBodies[run.trace.claudeBodies.length - 1];
  assert.ok(summary.messages[0].content[0].text.includes("<要望の一覧>"));
  assert.equal(summary.system[0].cache_control, undefined, "まとめはキャッシュを使わない");
  const slack = run.trace.fetched.filter((f) => f.url === SLACK);
  assert.equal(slack.length, 1);
  const text = JSON.parse(slack[0].payload).text;
  assert.ok(text.startsWith("【サロン みなと】お客さまの声のまとめ（2026-09-28〜10-04）\n"));
  assert.ok(text.includes("多い要望: 土曜午前の予約枠の追加（2 件）"));
  assert.ok(text.includes("1. 土曜午前の予約枠を見直してみてください。"));
  assert.ok(text.includes("くわしくは「まとめ」シートをご覧ください: https://docs.google.com/spreadsheets/d/SHEETID/edit#gid="));
  for (const secret of ["秘密の要約", "カットの前に", "〔電話〕"]) assert.equal(text.includes(secret), false, secret);
  assert.ok(run.trace.alerts[run.trace.alerts.length - 1].startsWith("まとめを作りました（回答 15 件、要望のまとまり 1 個）。"));
});

test("トリガーから（runWeekly）は getUi を呼ばずに 分析 → まとめ → 送る。同じ失敗の通知は 1 日 1 通", () => {
  const extra = [["まとめの送り先", "slack"], ["Slack Webhook URL", SLACK]];
  const run = formBook({ settingsExtra: extra, fromTrigger: true });
  run.entry.runWeekly();
  assert.equal(run.trace.getUiCalls, 0);
  assert.equal(run.sheets["分析結果"].rows.length, 31);
  assert.ok(run.sheets["まとめ"].rows.length > 10);
  assert.equal(run.trace.fetched.filter((f) => f.url === SLACK).length, 1);
  assert.equal(JSON.parse(run.trace.fetched.filter((f) => f.url === SLACK)[0].payload).text.includes("まだ分析していない"), false, "分析し終えたら件数の行は出さない");

  const broken = formBook({ settingsExtra: extra, fromTrigger: true, apiKey: undefined });
  broken.entry.runWeekly();
  broken.entry.runDaily();
  const notices = broken.trace.fetched.filter((f) => f.url === SLACK).map((f) => JSON.parse(f.payload).text);
  assert.equal(notices.length, 1, "同じエラーは 1 日 1 通");
  assert.equal(notices[0], "【お客さまアンケート｜エラー】2026-10-04 21:10:00\n自動の実行が止まりました: API キーが入っていません。メニュー「初期化」を押すと、キーを貼る欄が出ます。\nメニュー「設定を確かめる」で、直すところを確かめてください。");
  assert.equal(broken.trace.getUiCalls, 0);
});

test("「毎週送る」は押すたびに、毎週月曜 8 時のトリガーを入れる・外す", () => {
  const run = formBook({});
  run.entry.toggleWeekly();
  assert.deepEqual(run.triggers.map((t) => [t.handler, t.weekDay, t.hour, t.timeZone]), [["runWeekly", "MONDAY", 8, "Asia/Tokyo"]]);
  assert.equal(run.trace.alerts[0], "毎週月曜 8 時に、分析とまとめと送信をするようにしました。止めるときは、同じメニューをもう一度押してください。");
  run.entry.toggleWeekly();
  assert.equal(run.triggers.length, 0);
  assert.ok(run.trace.alerts[1].startsWith("毎週の自動実行を外しました。"));
});

test("分析結果が保護されていたら API を呼ぶ前に止める。ロックが取れなければ何もしない", () => {
  const run = formBook({ protect: ["分析結果"] });
  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 0);
  assert.equal(run.trace.alerts[0], "分析を実行できませんでした。\n「分析結果」シートに書き込めません（シートかセルが保護されているか、このアカウントに編集の権限がありません）。保護を外すか、スプレッドシートの持ち主のアカウントで動かしてください。");
  const busy = formBook({ lockBusy: true });
  busy.entry.analyzeNow();
  assert.equal(busy.trace.fetched.length, 0);
  assert.equal(busy.trace.alerts[0], "ほかの処理（分析・まとめ・フォームの作成）が動いています。少しあとでお試しください。");
});

test("設定を確かめる: 問題が無ければ要約、モデル名を壊すと「モデル」の行を名指し。メニューは 8 つ", () => {
  const ok = formBook();
  ok.entry.checkSettings();
  assert.ok(ok.trace.alerts[0].startsWith("問題ありません。\n\n読む回答シート: 「フォームの回答 1」\n"));
  assert.ok(ok.trace.alerts[0].includes("API キー: 入っています（末尾 …a1B2）。"));
  const broken = formBook({ settingsExtra: [["モデル", "sonnet-5"]] });
  broken.entry.checkSettings();
  assert.ok(broken.trace.alerts[0].startsWith("直すところがあります。\n\n・「設定」シートの「モデル」は claude- で始まる名前にしてください（いまは「sonnet-5」）。"));
  ok.entry.onOpen();
  assert.deepEqual(ok.menu.items.filter((item) => item[0] !== "-").map((item) => item[1]), ["initializeSheets", "checkSettings", "loadSamples", "buildForm", "analyzeNow", "buildSummaryNow", "toggleWeekly", "showUsage"]);
  assert.equal(ok.menu.items[0][0], "初期化（足りないシート・見出し・設定を足す。データは消しません）");
});

test("6 分の強制終了（finally も catch も効かない）でも、終わった回の行・今月の利用・分析した件数は残る", () => {
  const run = formBook({ killAtCall: 2 });
  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 2);
  assert.equal(run.trace.kills, 1);
  assert.deepEqual(run.trace.alerts, [], "強制終了のあとは画面も出せない");
  assert.equal(run.sheets["分析結果"].rows.length, 22, "回答なし 1 行と、1 回目の 20 行");
  assert.equal(run.props["count:2026-10-04"], "20");
  assert.equal(run.props["analyzed:2026-10"], "20", "1 回目の 20 件は今月の件数に入る");
  assert.equal(JSON.parse(run.props["usage:2026-10"]).count, 1, "1 回目の利用は今月の利用に入る");
});

test("1 回分の途中でも、送り直す・半分に割る前に時間を見て切り上げる。答えの返った分は書き、払った分は残す", () => {
  // 1 回の呼び出しに 4 分 36 秒かかる（切り上げの 4 分半を越え、もう 1 回呼ぶと 6 分で切れる）
  const dropR7 = (body, n) => {
    const reply = JSON.parse(answerAll(body).text);
    if (n === 1) reply.results = reply.results.filter((r) => r.id !== "r7");
    return { text: JSON.stringify(reply) };
  };
  const missing = formBook({ claudeMs: 276000, claudeReply: dropR7 });
  missing.entry.analyzeNow();
  assert.equal(claudeCalls(missing).length, 1, "答えの無い r7 を送り直さない");
  assert.equal(missing.trace.kills, 0);
  assert.equal(missing.sheets["分析結果"].rows.length, 21, "回答なし 1 行と、答えの返った 19 行");
  assert.equal(missing.trace.alerts[0], "新しく 20 件を分析しました（回答なし 1 件を含みます）。残り 10 件。\n残り 10 件は、もう一度「分析する」を押すと続きから分析します。");
  assert.equal(missing.props["count:2026-10-04"], "19");
  assert.equal(JSON.parse(missing.props["usage:2026-10"]).count, 1);
  missing.entry.analyzeNow();
  assert.deepEqual(missing.trace.claudeBodies.slice(1).map((body) => sentIds(body).length), [10], "次の実行で r7 と残りの 9 件");
  assert.equal(missing.sheets["分析結果"].rows.length, 31);

  const split = formBook({ claudeMs: 276000, claudeReply: (body, n) => (n === 1 ? { text: '{"results":[', stop_reason: "max_tokens" } : answerAll(body)) });
  split.entry.analyzeNow();
  assert.equal(claudeCalls(split).length, 1, "半分に割って送らない");
  assert.equal(split.trace.kills, 0);
  assert.equal(JSON.parse(split.props["usage:2026-10"]).count, 1, "切れた 1 回目の利用は残す");
  assert.equal(split.sheets["分析結果"].rows.length, 2, "回答なしの 1 行だけ");
  assert.ok(split.trace.alerts[0].endsWith("\n残り 29 件は、もう一度「分析する」を押すと続きから分析します。"), split.trace.alerts[0]);
});

test("runWeekly: 分析の残りが多くても 3 分で切り上げ、まとめを作って送る。まとめの前に 4 分を過ぎていたら、Claude を呼ばずに表だけのまとめを送る", () => {
  const extra = [["まとめの送り先", "slack"], ["Slack Webhook URL", SLACK], ["1 回に送る件数", "5"]];
  const isSummary = (body) => body.output_config.format.schema.properties.themes !== undefined;
  const reply = (body) =>
    isSummary(body)
      ? { text: JSON.stringify({ themes: [{ title: "土曜午前の予約枠の追加", ids: ["q1"] }], actions: [{ text: "土曜午前の予約枠を見直してみてください。", basis: "要望" }] }) }
      : answerAll(body, { request: "土曜午前の予約枠の追加" });
  // 1 回に 75 秒: 0・75・150 秒に始めた 3 回で 3 分を越え、225 秒からまとめ（300 秒で終わる）
  const run = formBook({ settingsExtra: extra, fromTrigger: true, claudeMs: 75000, claudeReply: reply });
  run.entry.runWeekly();
  assert.equal(run.trace.kills, 0, "6 分で切れない");
  assert.deepEqual(run.trace.claudeBodies.filter((body) => !isSummary(body)).map((body) => sentIds(body).length), [5, 5, 5]);
  assert.equal(run.trace.claudeBodies.filter(isSummary).length, 1);
  assert.equal(run.sheets["分析結果"].rows.length, 17, "回答なし 1 行と 15 行");
  const slack = run.trace.fetched.filter((f) => f.url === SLACK).map((f) => JSON.parse(f.payload).text);
  assert.equal(slack.length, 1, "まとめだけ（時間の切り上げはエラーではない）");
  assert.ok(slack[0].includes("\n1. 土曜午前の予約枠を見直してみてください。\n"), slack[0]);
  assert.ok(slack[0].includes("\nまだ分析していない回答が 14 件あります。続きは次の実行で分析します"), slack[0]);
  assert.equal(run.trace.getUiCalls, 0);

  // 1 回に 250 秒: 分析の 1 回で 4 分を越えたので、まとめでは呼ばない
  const slow = formBook({ settingsExtra: extra, fromTrigger: true, claudeMs: 250000, claudeReply: reply });
  slow.entry.runWeekly();
  assert.equal(slow.trace.kills, 0);
  assert.equal(claudeCalls(slow).length, 1, "分析の 1 回だけ");
  const late = slow.trace.fetched.filter((f) => f.url === SLACK).map((f) => JSON.parse(f.payload).text);
  assert.equal(late.length, 1);
  assert.ok(late[0].includes("今週の 3 つ:\n今週の 3 つを作れませんでした。"), late[0]);
  assert.ok(slow.sheets["まとめ"].rows.length > 5, "数える部分のまとめは作る");
});

test("分析結果が 1,000 行（新しいシートの大きさ）に達していても、行を足して書く", () => {
  const filler = Array.from({ length: 999 }, (_, i) => ["old" + i, i + 2, "2026-09-01", 4, "", "前の回答", "接客", "良い", "", "前の要約", "", false, "2026-09-01 10:00", "claude-sonnet-5"]);
  const run = formBook({ sheets: { [FORM]: sampleValues("salon", "2026-10-04"), 設定: settings(), 分析結果: [HEADERS].concat(filler) } });
  assert.equal(run.sheets["分析結果"].getMaxRows(), 1000);
  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 2);
  assert.equal(run.trace.alerts[0], "新しく 30 件を分析しました（回答なし 1 件を含みます）。残り 0 件。");
  assert.equal(run.sheets["分析結果"].rows.length, 1030);
  assert.ok(run.sheets["分析結果"].getMaxRows() >= 1030);
  const redoAt = HEADERS.indexOf("やり直す") + 1;
  assert.equal(run.sheets["分析結果"].formats["1030," + redoAt].checkbox, true);
});

test("行を書けなかった回も、払った分（今月の利用・1 日の件数・今月の件数）は先に残す", () => {
  let run = null;
  run = formBook({
    claudeReply: (body) => {
      // 答えが返るまでのあいだに、だれかが分析結果を保護した
      run.sheets["分析結果"].__protect(true);
      return answerAll(body);
    },
  });
  run.entry.analyzeNow();
  assert.equal(claudeCalls(run).length, 1, "書けなければ次の回は送らない");
  assert.ok(run.trace.alerts[0].startsWith("分析を実行できませんでした。\n"), run.trace.alerts[0]);
  assert.equal(JSON.parse(run.props["usage:2026-10"]).count, 1);
  assert.equal(run.props["count:2026-10-04"], "20");
  assert.equal(run.props["analyzed:2026-10"], "20");
});

test("前回 401 でも、次に Claude から答えが返れば 401 の印を消す（キーをスクリプト プロパティで入れ替えたとき）", () => {
  const run = formBook({ props: { keyRejected: "true" } });
  run.entry.analyzeNow();
  assert.equal(run.props.keyRejected, undefined);
  run.entry.checkSettings();
  assert.ok(run.trace.alerts[1].startsWith("問題ありません。"), run.trace.alerts[1]);
});

test("月の上限額は Anthropic の文面（credit balance・usage limit）だけで見分け、ほかの 400 は飛ばして次回に回す", () => {
  const ordinary = formBook({ claudeReply: () => ({ status: 400, body: JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "prompt is too long: 250000 tokens > 200000 maximum (context limit)" } }) }) });
  ordinary.entry.analyzeNow();
  assert.equal(claudeCalls(ordinary).length, 2, "上限額ではないので、次の回も試す");
  assert.ok(ordinary.trace.alerts[0].endsWith("29 件は次回もう一度試します。"));
  assert.equal(ordinary.trace.alerts[0].includes("上限額"), false);
  const usage = formBook({ claudeReply: () => ({ status: 400, body: JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "You have reached your specified API usage limits. You will regain access on 2026-11-01 at 00:00 UTC." } }) }) });
  usage.entry.analyzeNow();
  assert.equal(claudeCalls(usage).length, 1);
  assert.ok(usage.trace.alerts[0].endsWith("\nAnthropic Console で決めた月の上限額に達しました。Console で上限を上げるか、来月までお待ちください。"));
});

test("半分に割ったあとの 429 では、答えのある 10 件を書いて利用も数え、残りだけを次回に送る", () => {
  const run = formBook({
    claudeReply: (body, n) => {
      if (n === 1) return { text: '{"results":[', stop_reason: "max_tokens" };
      if (n === 3 || n === 4) return { status: 429 };
      return answerAll(body);
    },
  });
  run.entry.analyzeNow();
  assert.deepEqual(run.trace.claudeBodies.map((body) => sentIds(body).length), [20, 10, 10, 10]);
  assert.equal(run.sheets["分析結果"].rows.length, 12, "回答なし 1 行と、答えのある 10 行");
  assert.equal(run.trace.alerts[0], "新しく 11 件を分析しました（回答なし 1 件を含みます）。残り 19 件。\nAPI が混み合っているため、ここで止めました。数分おいて「分析する」を押すと続きから分析します。");
  assert.equal(run.props["count:2026-10-04"], "10");
  assert.equal(run.props["analyzed:2026-10"], "10");
  assert.equal(JSON.parse(run.props["usage:2026-10"]).count, 2, "切れた 1 回目と、答えの返った 2 回目");
  run.entry.analyzeNow();
  assert.deepEqual(run.trace.claudeBodies.slice(4).map((body) => sentIds(body).length), [19], "答えのある 10 件は送り直さない");
  assert.equal(run.sheets["分析結果"].rows.length, 31);
});

test("答えの無い id の送り直しが 400 なら、答えのある 19 件は書き、その 1 件だけ次回に回して次の回へ進む", () => {
  const run = formBook({
    claudeReply: (body, n) => {
      if (n === 2) return { status: 400, body: JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "bad request" } }) };
      const reply = JSON.parse(answerAll(body).text);
      if (n === 1) reply.results = reply.results.filter((r) => r.id !== "r7");
      return { text: JSON.stringify(reply) };
    },
  });
  run.entry.analyzeNow();
  assert.deepEqual(run.trace.claudeBodies.map((body) => sentIds(body).length), [20, 1, 9]);
  assert.equal(run.sheets["分析結果"].rows.length, 30, "回答なし 1 行と 19 行と 9 行");
  assert.equal(column(run, "要約").indexOf("読み取れませんでした"), -1);
  assert.equal(run.trace.alerts[0], "新しく 29 件を分析しました（回答なし 1 件を含みます）。残り 1 件。\nリクエストが受け付けられませんでした（400）。「モデル」の設定を確かめてください。1 件は次回もう一度試します。");
  assert.equal(run.props["analyzed:2026-10"], "28");
  assert.equal(JSON.parse(run.props["usage:2026-10"]).count, 2);
});

test("runWeekly: 分析が 401 か月の上限額で止まったら、まとめでは Claude を呼ばない（表だけのまとめを送る）", () => {
  const extra = [["まとめの送り先", "slack"], ["Slack Webhook URL", SLACK]];
  const firstThen = (failure) => (body, n) => (n === 1 ? answerAll(body, { request: "土曜午前の予約枠の追加" }) : failure);
  const rejected = formBook({ settingsExtra: extra, fromTrigger: true, claudeReply: firstThen({ status: 401, body: JSON.stringify({ type: "error", error: { type: "authentication_error" } }) }) });
  rejected.entry.runWeekly();
  assert.equal(claudeCalls(rejected).length, 2, "受け付けられなかったキーで、まとめのためにもう一度呼ばない");
  assert.ok(rejected.sheets["まとめ"].rows.length > 5, "数える部分のまとめは作る");
  assert.equal(rejected.trace.fetched.filter((f) => f.url === SLACK).length, 2, "エラーの通知とまとめ");
  assert.equal(rejected.trace.getUiCalls, 0);
  const limited = formBook({ settingsExtra: extra, fromTrigger: true, claudeReply: firstThen({ status: 400, body: JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "Your credit balance is too low" } }) }) });
  limited.entry.runWeekly();
  assert.equal(claudeCalls(limited).length, 2, "上限額に達したら、まとめでも呼ばない");
});
