import { test } from "node:test";
import assert from "node:assert/strict";
import { SENTIMENTS, buildBatchSchema, fallbackResult, parseBatch } from "../src/schema.js";
import { DEFAULT_CATEGORIES, DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG);
const GOOD = { id: "r1", category: "接客", sentiment: "良い", request: "土曜午前の予約枠の追加", summary: "説明が丁寧で安心", attention: false };

function reply(results) {
  return JSON.stringify({ results: results });
}

test("JSON Schema は設計書 §4-2 の形。分類の enum は設定の分類、件数の制約は書かない", () => {
  const schema = buildBatchSchema(DEFAULT_CATEGORIES);
  assert.deepEqual(schema.required, ["results"]);
  assert.equal(schema.additionalProperties, false);
  const item = schema.properties.results.items;
  assert.deepEqual(item.required, ["id", "category", "sentiment", "request", "summary", "attention"]);
  assert.equal(item.additionalProperties, false);
  assert.deepEqual(item.properties.category.enum, DEFAULT_CATEGORIES);
  assert.deepEqual(item.properties.sentiment.enum, SENTIMENTS);
  assert.deepEqual(SENTIMENTS, ["良い", "ふつう", "悪い"]);
  assert.equal(item.properties.attention.type, "boolean");
  assert.equal(schema.properties.results.minItems, undefined);
  assert.deepEqual(buildBatchSchema(["仕上がり", "その他"]).properties.results.items.properties.category.enum, ["仕上がり", "その他"]);
});

test("正しい答えはそのまま通る", () => {
  const parsed = parseBatch(reply([GOOD]), ["r1"], config);
  assert.deepEqual(parsed, { answers: { r1: { category: "接客", sentiment: "良い", request: "土曜午前の予約枠の追加", summary: "説明が丁寧で安心", attention: false } }, missing: [] });
});

test("送っていない id は捨て、同じ id が 2 つあれば最初を使う", () => {
  const parsed = parseBatch(reply([GOOD, Object.assign({}, GOOD, { summary: "二つ目" }), Object.assign({}, GOOD, { id: "r99" })]), ["r1", "r2"], config);
  assert.equal(parsed.answers.r1.summary, "説明が丁寧で安心");
  assert.equal(parsed.answers.r99, undefined);
  assert.deepEqual(parsed.missing, ["r2"]);
});

test("分類が一覧に無ければ「その他」、感情が不正なら「ふつう」", () => {
  const parsed = parseBatch(reply([Object.assign({}, GOOD, { category: "謎", sentiment: "最高" })]), ["r1"], config);
  assert.equal(parsed.answers.r1.category, "その他");
  assert.equal(parsed.answers.r1.sentiment, "ふつう");
});

test("要約は 20 字、要望は 80 字で切る。attention は真偽に直す", () => {
  const parsed = parseBatch(reply([Object.assign({}, GOOD, { summary: "あ".repeat(30), request: "い".repeat(100), attention: "true" })]), ["r1"], config);
  assert.equal(parsed.answers.r1.summary.length, 20);
  assert.equal(parsed.answers.r1.request.length, 80);
  assert.equal(parsed.answers.r1.attention, true);
});

test("壊れた JSON・results が配列でない → 全件が missing", () => {
  assert.deepEqual(parseBatch("{not json", ["r1", "r2"], config), { answers: {}, missing: ["r1", "r2"] });
  assert.deepEqual(parseBatch(JSON.stringify({ results: "x" }), ["r1"], config), { answers: {}, missing: ["r1"] });
  assert.deepEqual(parseBatch("", ["r1"], config).missing, ["r1"]);
});

test("2 回聞いても無い回答は「その他」「ふつう」「読み取れませんでした」、要対応", () => {
  assert.deepEqual(fallbackResult(), { category: "その他", sentiment: "ふつう", request: "", summary: "読み取れませんでした", attention: true });
});
