import { test } from "node:test";
import assert from "node:assert/strict";
import { SAMPLE_RESULTS, SAMPLE_ROWS, SAMPLE_SUMMARY, sampleColumns, sampleKeyForHeader, sampleResultFor, sampleSettingRows, sampleSummaryText, sampleValues, samplesLoadedText } from "../src/samples.js";
import { PRESETS, PRESET_KEYS, presetHeader } from "../src/presets.js";
import { DEFAULT_CONFIG, readConfigRows } from "../src/config.js";
import { resolveColumns } from "../src/columns.js";
import { toResponses } from "../src/responses.js";
import { aggregate } from "../src/summary.js";
import { parseSummary } from "../src/summary_prompt.js";
import { SUMMARY_LIMIT } from "../src/schema.js";

const TODAY = "2026-10-04";

function countBy(list, key) {
  const out = {};
  for (const item of list) out[item[key]] = (out[item[key]] || 0) + 1;
  return out;
}

function resultsOf(key) {
  return SAMPLE_ROWS[key].filter((row) => SAMPLE_RESULTS[row.id]).map((row) => SAMPLE_RESULTS[row.id]);
}

test("サロン・美容は 30 件。分類・感情・要望の数と、7 日に 16 件・前の期間に 14 件は設計書 §9-2 のとおり", () => {
  assert.equal(SAMPLE_ROWS.salon.length, 30);
  const results = resultsOf("salon");
  assert.equal(results.length, 29, "回答なしの 1 件を除く");
  assert.deepEqual(countBy(results, "category"), { カウンセリング: 3, 待ち時間: 5, 仕上がり: 6, "予約・手続き": 4, 清潔さ: 2, その他: 1, 接客: 5, 価格: 3 });
  assert.deepEqual(countBy(results, "sentiment"), { 良い: 14, ふつう: 5, 悪い: 10 });
  const requests = countBy(results.filter((r) => r.request !== ""), "request");
  assert.equal(Object.values(requests).reduce((a, b) => a + b, 0), 14);
  assert.equal(requests["土曜午前の予約枠の追加"], 4);
  assert.equal(requests["待ち時間の目安の案内"], 3);
  assert.equal(requests["駐車場の案内"], 2);
  assert.equal(requests["キャッシュレス払いの導入"], 2);
  assert.equal(SAMPLE_ROWS.salon.filter((row) => row.daysAgo <= 6).length, 16);
  assert.equal(SAMPLE_ROWS.salon.filter((row) => row.daysAgo >= 7 && row.daysAgo <= 13).length, 14);
  assert.deepEqual(results.filter((r) => r.attention).map((r) => r.summary), ["カラー後に頭皮がかぶれた"]);
  const all = SAMPLE_ROWS.salon.map((row) => row.cells.join(" ")).join("\n");
  for (const needle of ["@example.com", "03-0000-1234", "この回答を読んだ AI は", "頭皮がかぶれて", "The stylist"]) assert.ok(all.includes(needle), needle);
  assert.equal(SAMPLE_RESULTS.s09.sentiment, "悪い", "指示文が混ざった不満の回答は悪い");
});

test("飲食とクリニックは各 12 件。各分類に 1 件以上・悪い 4・要望 5・特になし 1・伏せ字の行 1", () => {
  for (const key of ["food", "clinic"]) {
    assert.equal(SAMPLE_ROWS[key].length, 12, key);
    const results = resultsOf(key);
    assert.equal(results.length, 11, key + " は特になしの 1 件を除く");
    for (const category of PRESETS[key].categories) assert.ok(results.some((r) => r.category === category), key + ": " + category);
    assert.equal(results.filter((r) => r.sentiment === "悪い").length, 4, key);
    assert.equal(results.filter((r) => r.request !== "").length, 5, key);
    const all = SAMPLE_ROWS[key].map((row) => row.cells.join(" ")).join("\n");
    assert.ok(/@example\.com|03-0000-/.test(all), key + " に伏せ字の行");
  }
});

test("見本の全行（回答なしを除く）に答えがあり、要約は 20 字以内・分類は見本の分類。見出しから業種が分かる", () => {
  for (const key of PRESET_KEYS) {
    const values = sampleValues(key, TODAY);
    assert.deepEqual(values[0], presetHeader(PRESETS[key]));
    assert.equal(sampleKeyForHeader(values[0]), key);
    const config = readConfigRows(sampleSettingRows(key).concat([["分類", PRESETS[key].categories.join(", ")]])).config;
    const responses = toResponses(values, resolveColumns("見本の回答", values, config), config, TODAY);
    assert.equal(responses.length, SAMPLE_ROWS[key].length, key);
    assert.equal(responses.filter((r) => r.empty).length, 1, key);
    for (const response of responses.filter((r) => !r.empty)) {
      const result = sampleResultFor(response.text);
      assert.notEqual(result, null, response.text);
      assert.ok(PRESETS[key].categories.indexOf(result.category) >= 0, result.category);
      assert.ok(result.summary.length <= SUMMARY_LIMIT, result.summary);
    }
  }
  assert.equal(sampleValues("salon", TODAY)[1][0], "2026-10-03 10:15:00");
  assert.equal(sampleResultFor("見本に無い回答"), null);
  assert.equal(sampleKeyForHeader(["タイムスタンプ", "ご意見"]), "");
  assert.deepEqual(sampleSettingRows("clinic").find((pair) => pair[0] === "店舗の列"), ["店舗の列", "なし"], "店舗の質問が無い見本は「なし」");
  assert.deepEqual(sampleColumns("food").answers, ["良かった点をお聞かせください", "気になった点・ご要望をお聞かせください"]);
});

test("架空の値だけ（電話は 03-0000-、メールは example.com）。見本のまとめは parseSummary を通り、3 つの打ち手が出る", () => {
  for (const key of PRESET_KEYS) {
    const all = SAMPLE_ROWS[key].map((row) => row.cells.join(" ")).join("\n");
    for (const phone of all.match(/0\d{1,4}-\d{1,4}-\d{3,4}/g) || []) assert.ok(phone.startsWith("03-0000-"), phone);
    for (const mail of all.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+/g) || []) assert.ok(mail.endsWith("@example.com"), mail);
    const records = SAMPLE_ROWS[key].filter((row) => SAMPLE_RESULTS[row.id]).map((row, i) => Object.assign({ row: i + 2, key: row.id, date: "2026-10-03", rating: row.cells[0], store: "", excerpt: "" }, SAMPLE_RESULTS[row.id]));
    const agg = aggregate(records, Object.assign({}, DEFAULT_CONFIG, { categories: PRESETS[key].categories, periodDays: 0 }), TODAY);
    const parsed = parseSummary(sampleSummaryText(agg, key), agg);
    assert.equal(parsed.themes.reduce((sum, theme) => sum + theme.count, 0), agg.requests.length, key + " の要望はどれかのまとまりに入る");
    assert.equal(parsed.actions.length, 3, key);
    for (const action of parsed.actions) assert.ok(action.text.endsWith("てみてください。"), action.text);
    assert.equal(SAMPLE_SUMMARY[key].actions.length, 3);
  }
});

test("見本を読み込んだあとの 1 通", () => {
  assert.equal(
    samplesLoadedText(PRESETS.food, { switched: true, formExists: false, categoriesKept: false }),
    "飲食の見本を読み込みました。「質問」シートを直してから「フォームを作る」を押すと、この質問でフォームができます。キーが無くても、「分析する」「まとめを作る」で見本の回答を使った動きを確かめられます。",
  );
  const kept = samplesLoadedText(PRESETS.salon, { switched: false, formExists: true, categoriesKept: true }).split("\n");
  assert.deepEqual(kept.slice(1), [
    "見本の回答を分析するときは、設定の「回答シート」を「見本の回答」にしてください。",
    "フォームはすでにあるので、次の「フォームを作る」で見本の質問が新しい質問として足されます。前の質問は、設定「質問を減らしても消す」に従います。",
    "設定の「分類」は替えていません。",
  ]);
});
