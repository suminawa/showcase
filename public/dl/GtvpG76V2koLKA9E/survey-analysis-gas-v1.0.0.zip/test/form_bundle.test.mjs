import { test } from "node:test";
import assert from "node:assert/strict";
import { loadBundle } from "./fakes.mjs";
import { DEFAULT_ROWS } from "../src/config.js";
import { HEADERS } from "../src/rows.js";
import { QUESTION_HEADERS, questionSheetValues } from "../src/questions.js";
import { PRESETS } from "../src/presets.js";

const KEY = "sk-ant-api03-" + "x".repeat(20) + "a1B2";

/** 初期化済みで、質問シートにサロン・美容の見本の質問があるブック */
function book(options) {
  const opts = options || {};
  const settings = [["項目", "値"]].concat(DEFAULT_ROWS, [["店名", "サロン みなと"]], opts.settingsExtra || []);
  const sheets = { 設定: settings, 分析結果: [HEADERS], 質問: opts.questions || questionSheetValues(PRESETS.salon.questions) };
  return loadBundle(Object.assign({ sheets: sheets }, opts));
}

function setting(run, key) {
  const rows = run.sheets["設定"].rows.filter((row) => row[0] === key);
  return rows.length === 0 ? undefined : rows[rows.length - 1][1];
}

function sentIds(body) {
  return Array.from(body.messages[0].content[0].text.matchAll(/<回答 id="(r\d+)"/g)).map((m) => m[1]);
}

function onlyForm(run) {
  const ids = Object.keys(run.forms);
  assert.equal(ids.length, 1, "フォームは 1 つだけ");
  return run.forms[ids[0]].__state;
}

test("見本（業種 2）→ フォームを作る: 質問の種類・選択肢・必須、メールを集めない、送り先はこのスプレッドシート、設定と項目 ID を書き戻す", () => {
  for (const havePublish of [true, false]) {
    const run = loadBundle({ sheets: { 設定: [["項目", "値"]].concat(DEFAULT_ROWS, [["店名", "サロン みなと"]]), 分析結果: [HEADERS], 質問: [QUESTION_HEADERS] }, promptReplies: [{ button: "OK", text: "2" }], formsHavePublish: havePublish });
    run.entry.loadSamples();
    run.entry.buildForm();
    const form = onlyForm(run);
    assert.equal(form.title, "サロン みなと ご来店アンケート");
    assert.ok(form.description.includes("AI を使って集計します"));
    assert.equal(form.collectEmail, false, "メールを集めない");
    assert.equal(form.limitOne, false, "ログインを求めない");
    assert.equal(form.allowEdits, false);
    assert.equal(form.accepting, true);
    assert.equal(form.published, havePublish, "setPublished がある版だけ公開にする");
    assert.deepEqual(form.items.map((item) => [item.kind, item.title, item.required]), [
      ["SCALE", "今回のご満足度（1〜5）", true],
      ["MULTIPLE_CHOICE", "ご利用の店舗", false],
      ["CHECKBOX", "本日のメニュー", false],
      ["PARAGRAPH_TEXT", "良かった点・気になった点を自由にお書きください", false],
      ["PARAGRAPH_TEXT", "ご要望があればお書きください（任意）", false],
      ["MULTIPLE_CHOICE", "次回もご予約をお考えですか", false],
    ]);
    assert.deepEqual(Array.from(form.items[1].choices), ["駅前店", "本町店"]);
    assert.deepEqual(Array.from(form.items[5].choices), ["はい", "いいえ"]);
    assert.deepEqual(Array.from(form.items[0].bounds), [1, 5]);
    assert.equal(form.destination, "SHEETID");
    assert.deepEqual(run.sheets["フォームの回答 1"].rows[0], ["タイムスタンプ"].concat(PRESETS.salon.questions.map((q) => q.title)));
    assert.equal(setting(run, "フォームの URL"), "https://forms.gle/form1");
    assert.equal(setting(run, "フォーム ID"), "FORM1");
    assert.equal(setting(run, "回答シート"), "フォームの回答 1");
    assert.equal(setting(run, "回答の列"), "良かった点・気になった点を自由にお書きください, ご要望があればお書きください（任意）");
    assert.equal(setting(run, "評価の列"), "今回のご満足度（1〜5）");
    assert.equal(setting(run, "店舗の列"), "ご利用の店舗");
    assert.deepEqual(run.sheets["質問"].rows.slice(1).map((row) => row[7]), form.items.map((item) => String(item.id)));
    const alert = run.trace.alerts[run.trace.alerts.length - 1];
    assert.ok(alert.startsWith("フォームを作りました。\n\n答える人に渡す URL: https://forms.gle/form1\n"), alert);
    assert.ok(alert.includes("回答は「フォームの回答 1」シートに溜まります。"));
    assert.ok(run.trace.alerts.some((line) => line === "設定の「回答シート」を、見本の回答からフォームの回答に切り替えます。よろしいですか？"), "見本からの切り替えは確認する");
    assert.deepEqual(run.trace.dialogsUnderLock, [], "確認と終わりの alert はロックの外で出す");
    assert.ok(run.props.formSourceHash.startsWith("k"));
  }
});

test("もう 1 回押しても 2 つ目はできない（同じ ID のフォームを直す）。質問文と選択肢を直すと update だけで、回答シートの見出しも変わる", () => {
  const run = book();
  run.entry.buildForm();
  run.entry.buildForm();
  assert.equal(onlyForm(run).items.length, 6);
  assert.equal(run.trace.alerts[1].split("\n")[0], "フォームを直しました（質問の追加 0・変更 6・作り直し 0・残した質問 0）。");
  assert.equal(run.order.filter((name) => name.indexOf("フォームの回答") === 0).length, 1, "回答シートも 1 枚のまま");
  const questions = run.sheets["質問"].rows;
  questions[2][1] = "ご来店の店舗";
  questions[2][3] = "駅前店";
  questions[3][3] = "カット\nカラー";
  onlyForm(run).responses = 3;
  const before = onlyForm(run).items.map((item) => item.id);
  run.entry.buildForm();
  // 選択肢が 1 つの店舗の行は、フォームに触らず止まる
  assert.ok(run.trace.alerts[2].startsWith("フォームに触る前に、質問シートの直すところがあります。\n\n・質問シートの 3 行目: 種類が「選択」ですが、選択肢が 1 つしかありません。"));
  questions[2][3] = "駅前店\n本町店";
  run.entry.buildForm();
  const form = onlyForm(run);
  assert.deepEqual(form.items.map((item) => item.id), before, "作り直さない");
  assert.equal(form.items[1].title, "ご来店の店舗");
  assert.deepEqual(Array.from(form.items[2].choices), ["カット", "カラー"]);
  assert.equal(run.sheets["フォームの回答 1"].rows[0][2], "ご来店の店舗", "回答シートの見出しも変わる");
  const alert = run.trace.alerts[3];
  assert.ok(alert.startsWith("フォームを直しました（質問の追加 0・変更 6・作り直し 0・残した質問 0）。"));
  assert.ok(alert.includes("選択肢を消した質問があります。"), "回答があるフォームの選択肢を消したことを添える");
});

test("種類を変えた質問は作り直す（回答シートに新しい列ができ、古い列は残る）", () => {
  const run = book();
  run.entry.buildForm();
  const questions = run.sheets["質問"].rows;
  const oldId = questions[6][7];
  questions[6][2] = "自由記述";
  run.entry.buildForm();
  const form = onlyForm(run);
  assert.equal(form.items.length, 6);
  assert.equal(form.items[5].kind, "PARAGRAPH_TEXT");
  assert.notEqual(String(form.items[5].id), oldId);
  assert.equal(run.sheets["質問"].rows[6][7], String(form.items[5].id));
  assert.deepEqual(run.sheets["フォームの回答 1"].rows[0].slice(-2), ["次回もご予約をお考えですか", "次回もご予約をお考えですか"], "古い列と新しい列");
  assert.ok(run.trace.alerts[1].startsWith("フォームを直しました（質問の追加 0・変更 5・作り直し 1・残した質問 0）。"));
  assert.ok(run.trace.alerts[1].includes("種類を変えた質問は作り直しました。"));
});

test("質問シートから消した質問は、既定でフォームに残す。「質問を減らしても消す」が はい なら確認のうえ消す（［キャンセル］なら残す）", () => {
  const run = book({ confirms: ["CANCEL", "OK"] });
  run.entry.buildForm();
  run.sheets["質問"].rows.splice(3, 1);
  run.entry.buildForm();
  assert.equal(onlyForm(run).items.length, 6);
  assert.ok(run.trace.alerts[1].includes("フォームに残した質問: 本日のメニュー（質問シートから消しても、フォームからは消していません）"));
  run.sheets["設定"].rows.push(["質問を減らしても消す", "はい"]);
  run.entry.buildForm();
  assert.equal(run.trace.alerts[2], "次の質問をフォームから消します。回答シートの列とこれまでの回答は残ります。よろしいですか？\n・本日のメニュー");
  assert.equal(onlyForm(run).items.length, 6, "［キャンセル］なら残す");
  assert.ok(run.trace.alerts[3].includes("フォームに残した質問: 本日のメニュー"));
  run.entry.buildForm();
  assert.equal(onlyForm(run).items.length, 5, "［OK］なら消す");
  assert.ok(run.trace.alerts[5].includes("フォームから消した質問: 本日のメニュー（回答シートの列とこれまでの回答は残ります）"));
  assert.ok(run.sheets["フォームの回答 1"].rows[0].indexOf("本日のメニュー") > 0, "回答シートの列は残る");
  assert.deepEqual(run.trace.dialogsUnderLock, [], "確認と終わりの alert はロックの外で出す");
});

test("フォーム ID のフォームを消してあると、確認のうえ新しく作る。［キャンセル］なら何もしない", () => {
  const canceled = book({ settingsExtra: [["フォーム ID", "GONE"]], confirms: ["CANCEL"] });
  canceled.entry.buildForm();
  assert.equal(canceled.trace.alerts[0], "設定のフォーム ID のフォームを開けませんでした（またはほかのスプレッドシートにつながっています）。新しいフォームを作ります。よろしいですか？");
  assert.equal(Object.keys(canceled.forms).length, 0);
  assert.equal(canceled.trace.alerts.length, 1);
  const run = book({ settingsExtra: [["フォーム ID", "GONE"]], confirms: ["OK"] });
  run.entry.buildForm();
  assert.equal(onlyForm(run).items.length, 6);
  assert.equal(setting(run, "フォーム ID"), "FORM1");
  assert.ok(run.trace.alerts[1].startsWith("フォームを作りました。"));
  assert.deepEqual(run.trace.dialogsUnderLock, [], "確認はロックの外で出す");
  // ほかのスプレッドシートにつながったフォーム（丸ごとコピーした場合）も同じ確認
  const copied = book({ settingsExtra: [["フォーム ID", "OTHER1"]], forms: [{ id: "OTHER1", destination: "ANOTHER" }], confirms: ["CANCEL"] });
  copied.entry.buildForm();
  assert.equal(copied.trace.alerts[0], "設定のフォーム ID のフォームを開けませんでした（またはほかのスプレッドシートにつながっています）。新しいフォームを作ります。よろしいですか？");
});

test("回答シートの getFormUrl が遅れても 1 回だけ探し直す。それでも無ければ、フォームの 3 行だけを書き、次に押すと同じフォームで見つける", () => {
  const late = book({ formUrlDelay: 1 });
  late.entry.buildForm();
  assert.equal(setting(late, "回答シート"), "フォームの回答 1");
  const lost = book({ formUrlDelay: 2 });
  lost.entry.buildForm();
  assert.ok(lost.trace.alerts[0].includes("フォームはできましたが、回答のシートが見つかりませんでした。スプレッドシートを開き直してから、もう一度「フォームを作る」を押してください（2 つ目のフォームはできません）。"));
  assert.equal(setting(lost, "フォーム ID"), "FORM1");
  assert.equal(setting(lost, "回答シート"), "", "回答シートの行は書かない");
  lost.entry.buildForm();
  assert.equal(Object.keys(lost.forms).length, 1);
  assert.equal(setting(lost, "回答シート"), "フォームの回答 1");
  assert.equal(lost.order.filter((name) => name.indexOf("フォームの回答") === 0).length, 1);
});

test("フォームを作ったあと「分析する」は、列の対応づけなしでフォームの回答を読む。設定を確かめるにフォームの URL と回答の数", () => {
  const run = book({ apiKey: KEY });
  run.entry.buildForm();
  const sheet = run.sheets["フォームの回答 1"];
  sheet.rows.push([new Date(Date.UTC(2026, 9, 3, 1)), 4, "駅前店", "カット", "説明が丁寧でした。", "土曜の午前も予約したいです。", "はい"]);
  sheet.rows.push([new Date(Date.UTC(2026, 9, 3, 2)), 2, "本町店", "カラー", "30 分待ちました。", "", "いいえ"]);
  run.entry.analyzeNow();
  const bodies = run.trace.claudeBodies;
  assert.equal(bodies.length, 1);
  const text = bodies[0].messages[0].content[0].text;
  assert.ok(text.includes('<回答 id="r1" 評価="4">\n【良かった点・気になった点を自由にお書きください】説明が丁寧でした。\n【ご要望があればお書きください（任意）】土曜の午前も予約したいです。\n</回答>'));
  assert.equal(text.includes("駅前店"), false, "店舗は送らない");
  assert.equal(text.includes("カット"), false, "メニューの選択は送らない");
  assert.equal(run.sheets["分析結果"].rows.length, 3);
  run.entry.checkSettings();
  const check = run.trace.alerts[run.trace.alerts.length - 1];
  assert.ok(check.includes("フォーム: https://forms.gle/form1（回答 0 件）"), check);
  assert.ok(check.includes("（質問シートから）"));
});

test("質問シートが見出しだけなら止める。フォームを作るのに API キーは要らない", () => {
  const run = book({ questions: [QUESTION_HEADERS] });
  run.entry.buildForm();
  assert.equal(run.trace.alerts[0], "「質問」シートがありません。先に「見本を読み込む」で業種の見本を読み込むか、「初期化」で見出しを作ってから質問を書いてください。");
  const noKey = book();
  noKey.entry.buildForm();
  assert.equal(Object.keys(noKey.forms).length, 1);
  assert.equal(noKey.trace.fetched.length, 0, "Claude を使わない");
});

test("途中で止まっても、作ったフォームの ID と足した質問の項目 ID は残る。もう一度押すと、2 つ目のフォームも同じ質問の 2 つ目もできない", () => {
  const run = book({ addItemFailsAt: 2 });
  run.entry.buildForm();
  assert.ok(run.trace.alerts[0].startsWith("うまくいきませんでした。次の内容をご確認ください。"), run.trace.alerts[0]);
  assert.equal(setting(run, "フォーム ID"), "FORM1", "作った直後に ID を書く");
  assert.equal(setting(run, "フォームの編集 URL"), "https://docs.google.com/forms/d/FORM1/edit");
  const first = onlyForm(run).items.map((item) => item.id);
  assert.equal(first.length, 1);
  assert.equal(run.sheets["質問"].rows[1][7], String(first[0]), "足した質問の項目 ID は、その場で書く");
  run.entry.buildForm();
  const form = onlyForm(run);
  assert.deepEqual(form.items.map((item) => item.title), PRESETS.salon.questions.map((q) => q.title), "同じ質問を 2 つ作らない");
  assert.equal(form.items[0].id, first[0]);
  assert.ok(run.trace.alerts[1].startsWith("フォームを直しました（質問の追加 5・変更 1・作り直し 0・残した質問 0）。"), run.trace.alerts[1]);
  assert.equal(setting(run, "回答シート"), "フォームの回答 1");
  assert.equal(run.order.filter((name) => name.indexOf("フォームの回答") === 0).length, 1);
});

test("「質問」か「設定」が保護されていたら、フォームを作る前に止める（ID を残せないまま作らない）", () => {
  for (const name of ["質問", "設定"]) {
    const run = book({ protect: [name] });
    run.entry.buildForm();
    assert.equal(Object.keys(run.forms).length, 0, name);
    assert.equal(
      run.trace.alerts[0],
      "うまくいきませんでした。次の内容をご確認ください。\n\n「" + name + "」シートに書き込めません（シートかセルが保護されているか、このアカウントに編集の権限がありません）。保護を外すか、スプレッドシートの持ち主のアカウントで動かしてください。フォームには、まだ触っていません。",
    );
  }
});

test("確認の画面を読んでいるあいだに質問シートが変わったら、ロックの中で読み直して、消す質問が増えた分を聞き直す", () => {
  let run = null;
  const alsoDelete = () => {
    const rows = run.sheets["質問"].rows;
    rows.splice(rows.findIndex((row) => row[1] === "ご要望があればお書きください（任意）"), 1);
    return "OK";
  };
  run = book({ settingsExtra: [["質問を減らしても消す", "はい"]], confirms: [alsoDelete, "OK"] });
  run.entry.buildForm();
  run.sheets["質問"].rows.splice(3, 1);
  run.entry.buildForm();
  assert.equal(run.trace.alerts[1], "次の質問をフォームから消します。回答シートの列とこれまでの回答は残ります。よろしいですか？\n・本日のメニュー");
  assert.equal(run.trace.alerts[2], "次の質問をフォームから消します。回答シートの列とこれまでの回答は残ります。よろしいですか？\n・本日のメニュー\n・ご要望があればお書きください（任意）");
  assert.deepEqual(onlyForm(run).items.map((item) => item.title), ["今回のご満足度（1〜5）", "ご利用の店舗", "良かった点・気になった点を自由にお書きください", "次回もご予約をお考えですか"]);
  assert.ok(run.trace.alerts[3].includes("フォームから消した質問: 本日のメニュー、ご要望があればお書きください（任意）"), run.trace.alerts[3]);
  assert.equal(run.trace.alerts.length, 4);
  assert.deepEqual(run.trace.dialogsUnderLock, []);
});

test("ロックが取れなければフォームに触らず、ほかの処理が動いていると知らせる", () => {
  const run = book({ lockBusy: true });
  run.entry.buildForm();
  assert.equal(run.trace.alerts[0], "ほかの処理（分析・まとめ・フォームの作成）が動いています。少しあとでお試しください。");
  assert.equal(Object.keys(run.forms).length, 0);
});

test("setPublished があっても例外になる古いフォームでは、公開の設定をせずにフォームを作る", () => {
  const run = book({ publishThrows: true });
  run.entry.buildForm();
  const form = onlyForm(run);
  assert.equal(form.items.length, 6);
  assert.equal(form.published, false);
  assert.ok(run.trace.alerts[0].startsWith("フォームを作りました。"), run.trace.alerts[0]);
  assert.ok(run.trace.logs.some((line) => line.includes("フォームを公開の状態にできませんでした")));
});

test("質問シートの項目 ID の質問がフォームに無い（フォームの側で消した・読んだあとに消えた）ときは、新しく作る", () => {
  const run = book();
  run.entry.buildForm();
  const form = onlyForm(run);
  // フォームの編集画面で「ご利用の店舗」を消した（質問シートには古い項目 ID が残る）
  const storeId = form.items[1].id;
  form.items.splice(1, 1);
  run.entry.buildForm();
  assert.deepEqual(form.items.map((item) => item.title), PRESETS.salon.questions.map((q) => q.title));
  assert.notEqual(form.items[1].id, storeId);
  assert.equal(run.sheets["質問"].rows[2][7], String(form.items[1].id));
  assert.ok(run.trace.alerts[1].startsWith("フォームを直しました（質問の追加 1・変更 5・作り直し 0・残した質問 0）。"), run.trace.alerts[1]);
  // 一覧を読んだあと、当てる前に消えた（getItemById が null を返す）
  let vanish = false;
  const race = book({ onGetItems: (state) => {
    if (!vanish) return;
    vanish = false;
    state.items.splice(2, 1);
  } });
  race.entry.buildForm();
  const menuId = onlyForm(race).items[2].id;
  vanish = true;
  race.entry.buildForm();
  const raced = onlyForm(race);
  assert.ok(race.trace.alerts[1].startsWith("フォームを直しました"), race.trace.alerts[1]);
  assert.deepEqual(raced.items.map((item) => item.title), PRESETS.salon.questions.map((q) => q.title));
  assert.notEqual(raced.items[2].id, menuId);
  assert.equal(race.sheets["質問"].rows[3][7], String(raced.items[2].id));
});

test("短縮 URL に失敗したら、長い URL を設定と終わりの alert に出す", () => {
  const run = book({ shortenFails: true });
  run.entry.buildForm();
  const long = "https://docs.google.com/forms/d/e/FORM1/viewform";
  assert.equal(setting(run, "フォームの URL"), long);
  assert.ok(run.trace.alerts[0].includes("答える人に渡す URL: " + long + "\n"), run.trace.alerts[0]);
  assert.ok(run.trace.logs.some((line) => line.includes("URL を短くできませんでした")));
});

test("設定を確かめる: フォーム ID のフォームが開けない・ほかのスプレッドシートにつながっているときは直すところに出し、フォームには触らない", () => {
  const missing = book({ settingsExtra: [["フォーム ID", "GONE"]] });
  missing.entry.checkSettings();
  assert.ok(missing.trace.alerts[0].startsWith("直すところがあります。"), missing.trace.alerts[0]);
  assert.ok(missing.trace.alerts[0].includes("設定の「フォーム ID」のフォームを開けませんでした（消したか、ゴミ箱にあるか、このアカウントに権限がありません）。「フォームを作る」を押すと、確認のうえ新しく作ります。"));
  assert.equal(Object.keys(missing.forms).length, 0, "新しく作らない");
  const elsewhere = book({ settingsExtra: [["フォーム ID", "OTHER1"]], forms: [{ id: "OTHER1", destination: "ANOTHER" }] });
  elsewhere.entry.checkSettings();
  assert.ok(elsewhere.trace.alerts[0].includes("設定の「フォーム ID」のフォームは、ほかのスプレッドシートにつながっています。「フォームを作る」を押すと、確認のうえこのスプレッドシート用に新しく作ります。"), elsewhere.trace.alerts[0]);
  const other = elsewhere.forms.OTHER1.__state;
  assert.deepEqual([Object.keys(elsewhere.forms).length, other.title, other.destination, other.items.length], [1, "既存のフォーム", "ANOTHER", 0], "ほかのスプレッドシートのフォームは開くだけ");
});

test("Workspace のアカウントでもログインを求めない（setRequireLogin(false)。無い版の例外でも作れる）。公開してから回答の受け付けをオンにする", () => {
  const run = book();
  run.entry.buildForm();
  const form = onlyForm(run);
  assert.equal(form.requireLogin, false, "組織の外のお客さまも答えられる");
  assert.equal(form.published, true);
  assert.equal(form.accepting, true, "公開していないフォームは回答を受け付けないので、公開が先");
  const personal = book({ requireLoginThrows: true });
  personal.entry.buildForm();
  assert.equal(onlyForm(personal).items.length, 6);
  assert.equal(onlyForm(personal).accepting, true);
  assert.ok(personal.trace.alerts[0].startsWith("フォームを作りました。"), personal.trace.alerts[0]);
});

test("質問の文を直してフォームを直しても、分析済みの回答は送り直さない（キーに質問の文を入れない）", () => {
  const run = book({ apiKey: KEY });
  run.entry.buildForm();
  const sheet = run.sheets["フォームの回答 1"];
  sheet.rows.push([new Date(Date.UTC(2026, 9, 3, 1)), 4, "駅前店", "カット", "説明が丁寧でした。", "土曜の午前も予約したいです。", "はい"]);
  sheet.rows.push([new Date(Date.UTC(2026, 9, 3, 2)), 2, "本町店", "カラー", "30 分待ちました。", "", "いいえ"]);
  run.entry.analyzeNow();
  assert.equal(run.trace.claudeBodies.length, 1);
  assert.equal(run.sheets["分析結果"].rows.length, 3);
  run.sheets["質問"].rows[4][1] = "良かった点・気になった点をお聞かせください";
  run.entry.buildForm();
  assert.equal(sheet.rows[0][4], "良かった点・気になった点をお聞かせください", "回答シートの見出しも変わる");
  assert.equal(setting(run, "回答の列"), "良かった点・気になった点をお聞かせください, ご要望があればお書きください（任意）");
  run.entry.analyzeNow();
  assert.equal(run.trace.claudeBodies.length, 1, "送り直さない");
  assert.equal(run.sheets["分析結果"].rows.length, 3, "行も増えない");
  assert.equal(run.trace.alerts[run.trace.alerts.length - 1], "新しい回答はありません。分析結果はそろっています。");
});

test("種類を変えて作り直した質問は、同じ見出しの 2 つの列を 1 つとして読む（新しい列の回答を送る。前の回答は送り直さない）", () => {
  const run = book({ apiKey: KEY });
  run.entry.buildForm();
  const sheet = run.sheets["フォームの回答 1"];
  sheet.rows.push([new Date(Date.UTC(2026, 9, 3, 1)), 4, "駅前店", "カット", "説明が丁寧でした。", "", ""]);
  run.entry.analyzeNow();
  const questions = run.sheets["質問"].rows;
  questions[6][2] = "自由記述";
  questions[6][6] = "回答";
  run.entry.buildForm();
  assert.deepEqual(sheet.rows[0].slice(-2), ["次回もご予約をお考えですか", "次回もご予約をお考えですか"], "古い列と新しい列");
  sheet.rows.push([new Date(Date.UTC(2026, 9, 4, 1)), 5, "本町店", "カラー", "", "", "", "来月も予約します。"]);
  run.entry.analyzeNow();
  assert.equal(run.trace.claudeBodies.length, 2);
  assert.deepEqual(sentIds(run.trace.claudeBodies[1]), ["r1"], "前の回答は送り直さない");
  const text = run.trace.claudeBodies[1].messages[0].content[0].text;
  assert.ok(text.includes("【次回もご予約をお考えですか】来月も予約します。"), text);
  assert.equal(run.sheets["分析結果"].rows.length, 3);
});

test("英語の画面のアカウント（回答シートの 1 列目が Timestamp）でも、日付の列にその見出しを書き戻して分析できる", () => {
  const run = book({ apiKey: KEY, timestampHeader: "Timestamp" });
  run.entry.buildForm();
  assert.equal(setting(run, "日付の列"), "Timestamp");
  run.sheets["フォームの回答 1"].rows.push([new Date(Date.UTC(2026, 9, 3, 1)), 4, "駅前店", "カット", "説明が丁寧でした。", "", "はい"]);
  run.entry.analyzeNow();
  assert.equal(run.trace.claudeBodies.length, 1);
  assert.equal(run.trace.alerts[run.trace.alerts.length - 1], "新しく 1 件を分析しました。残り 0 件。");
});

test("「+α」のように = + - @ で始まる質問文も、設定には字のまま書く（数式として読ませない）", () => {
  // 質問シートでは、お客さまが先頭に ' を付けて字にしている
  const questions = [QUESTION_HEADERS.slice(), [1, "今回のご満足度", "5 段階", "", "はい", "", "", ""], [2, "'+α でご要望があればお書きください", "自由記述", "", "", "", "", ""]];
  const run = book({ apiKey: KEY, questions: questions });
  run.entry.buildForm();
  assert.equal(onlyForm(run).items[1].title, "+α でご要望があればお書きください");
  assert.equal(setting(run, "回答の列"), "+α でご要望があればお書きください");
  run.sheets["フォームの回答 1"].rows.push([new Date(Date.UTC(2026, 9, 3, 1)), 4, "駐車場がほしいです。"]);
  run.entry.analyzeNow();
  assert.equal(run.trace.claudeBodies.length, 1);
});
