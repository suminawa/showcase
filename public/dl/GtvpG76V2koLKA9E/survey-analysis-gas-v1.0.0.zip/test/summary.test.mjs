import { test } from "node:test";
import assert from "node:assert/strict";
import { aggregate, previousPeriod, requestList } from "../src/summary.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG);
let nextRow = 2;
function record(over) {
  nextRow += 1;
  return Object.assign({ row: nextRow, key: "k" + nextRow, date: "2026-10-03", rating: "", store: "", excerpt: "", category: "接客", sentiment: "良い", request: "", summary: "要約", attention: false }, over);
}

test("期間は今日を含む過去 N 日。0 は全期間。前の期間は同じ日数だけ前", () => {
  const records = [record({ date: "2026-09-28" }), record({ date: "2026-10-04" }), record({ date: "2026-09-27" }), record({ date: "2026-09-10" })];
  const week = aggregate(records, config, "2026-10-04");
  assert.equal(week.from, "2026-09-28");
  assert.equal(week.to, "2026-10-04");
  assert.equal(week.total, 2);
  assert.equal(week.previous.total, 1, "9/21〜9/27 の 1 件");
  assert.deepEqual(previousPeriod("2026-09-28", 7), { from: "2026-09-21", to: "2026-09-27" });
  const all = aggregate(records, Object.assign({}, config, { periodDays: 0 }), "2026-10-04");
  assert.equal(all.total, 4);
  assert.equal(all.from, "2026-09-10");
  assert.equal(all.previous, null, "全期間に前の期間は無い");
});

test("分類ごとの 件数・良い・ふつう・悪い・悪いの割合。回答なしは数えず、noAnswer に入れる", () => {
  const records = [
    record({ category: "待ち時間", sentiment: "悪い" }),
    record({ category: "待ち時間", sentiment: "悪い" }),
    record({ category: "待ち時間", sentiment: "ふつう" }),
    record({ category: "接客", sentiment: "良い" }),
    record({ category: "（回答なし）", sentiment: "ふつう" }),
  ];
  const agg = aggregate(records, config, "2026-10-04");
  assert.equal(agg.total, 4);
  assert.equal(agg.noAnswer, 1);
  assert.deepEqual(agg.sentiments, { 良い: 1, ふつう: 1, 悪い: 2 });
  assert.equal(agg.negativeRate, 50);
  const wait = agg.categories.find((c) => c.name === "待ち時間");
  assert.deepEqual(wait, { name: "待ち時間", count: 3, good: 0, neutral: 1, bad: 2, badRate: 67, ratingAverage: null, prevBadRate: null });
  assert.deepEqual(agg.categories.map((c) => c.name), config.categories, "設定の分類はすべて並ぶ（0 件も）");
});

test("評価の平均は評価のある行だけで小数 1 桁。評価の列が無ければ null", () => {
  const agg = aggregate([record({ rating: 5 }), record({ rating: 4 }), record({ rating: 4 }), record({ rating: "" })], config, "2026-10-04");
  assert.equal(agg.ratingAverage, 4.3);
  assert.equal(agg.hasRating, true);
  const none = aggregate([record({})], config, "2026-10-04");
  assert.equal(none.ratingAverage, null);
  assert.equal(none.hasRating, false);
});

test("店舗ごと（出てきた順）と、要対応は新しい順に 10 件まで", () => {
  const records = [record({ store: "駅前店", sentiment: "悪い", rating: 2 }), record({ store: "本町店" }), record({ store: "駅前店", rating: 4 })];
  for (let i = 0; i < 12; i += 1) records.push(record({ attention: true, date: i < 6 ? "2026-10-01" : "2026-10-02", summary: "要対応 " + i }));
  const agg = aggregate(records, config, "2026-10-04");
  assert.deepEqual(agg.stores, [
    { name: "駅前店", count: 2, good: 1, bad: 1, ratingAverage: 3 },
    { name: "本町店", count: 1, good: 1, bad: 0, ratingAverage: null },
  ]);
  assert.equal(agg.attention.length, 10);
  assert.equal(agg.attention[0].summary, "要対応 11");
  assert.equal(agg.attention[0].date, "2026-10-02");
});

test("前の期間の件数・悪いの割合・評価の平均。前の期間に行が無ければ null", () => {
  const records = [record({ date: "2026-10-01", sentiment: "悪い", category: "待ち時間" }), record({ date: "2026-09-25", sentiment: "悪い", rating: 2, category: "待ち時間" }), record({ date: "2026-09-24", rating: 4, category: "待ち時間" })];
  const agg = aggregate(records, config, "2026-10-04");
  assert.deepEqual(agg.previous, { total: 2, negativeRate: 50, ratingAverage: 3 });
  assert.equal(agg.categories.find((c) => c.name === "待ち時間").prevBadRate, 50);
  assert.equal(aggregate([record({})], config, "2026-10-04").previous, null);
});

test("要望の一覧は要望のある行だけ、新しい順に q1 から。300 件で切る", () => {
  const records = [record({ date: "2026-10-01", request: "駐車場の案内" }), record({ date: "2026-10-03", request: "土曜午前の予約枠の追加", sentiment: "謎" }), record({ date: "2026-10-02" })];
  assert.deepEqual(requestList(records).map((r) => [r.id, r.request, r.sentiment]), [["q1", "土曜午前の予約枠の追加", "ふつう"], ["q2", "駐車場の案内", "良い"]]);
  const many = Array.from({ length: 320 }, (_, i) => record({ request: "要望 " + i }));
  assert.equal(requestList(many).length, 300);
});

test("手で直した分類（設定に無い名前）も、その名前で数える", () => {
  const agg = aggregate([record({ category: "駐車場" }), record({ category: "駐車場", sentiment: "悪い" })], config, "2026-10-04");
  const parking = agg.categories.find((c) => c.name === "駐車場");
  assert.equal(parking.count, 2);
  assert.equal(parking.bad, 1);
  assert.equal(agg.categories[agg.categories.length - 1].name, "駐車場", "設定の分類のあとに並ぶ");
});
