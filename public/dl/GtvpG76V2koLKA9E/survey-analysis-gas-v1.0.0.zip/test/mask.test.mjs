import { test } from "node:test";
import assert from "node:assert/strict";
import { MAIL_MARK, PHONE_MARK, maskText, toHalfWidth } from "../src/mask.js";
import { sendableText } from "../src/responses.js";
import { DEFAULT_CONFIG } from "../src/config.js";

test("メールアドレスは〔メール〕に替える", () => {
  assert.equal(MAIL_MARK, "〔メール〕");
  assert.equal(maskText("変更は taro.minato@example.com までお願いします"), "変更は 〔メール〕 までお願いします");
  assert.equal(maskText("a+b@mail.example.co.jp と c_d@example.com"), "〔メール〕 と 〔メール〕");
});

test("固定電話・携帯・+81・区切りなし・かっこつきは〔電話〕", () => {
  assert.equal(PHONE_MARK, "〔電話〕");
  for (const phone of ["03-0000-1234", "090-0000-1234", "+81 90-0000-1234", "+81-3-0000-1234", "0300001234", "03(0000)1234", "0120-000-000"]) {
    assert.equal(maskText("折り返しは " + phone + " へ"), "折り返しは 〔電話〕 へ", phone);
  }
});

test("全角の数字とハイフンは半角にそろえてから替える", () => {
  assert.equal(toHalfWidth("０３－００００－１２３４"), "03-0000-1234");
  assert.equal(toHalfWidth("090ー0000ー1234 と カード"), "090-0000-1234 と カード", "数字にはさまれた長音だけハイフンに");
  assert.equal(maskText("電話 ０９０ー００００ー１２３４"), "電話 〔電話〕");
});

test("日付・金額・郵便番号・時刻・短い番号は替えない", () => {
  const text = "2026-09-30 の 10:30 に 3,000円 を払いました。〒123-4567、060-0001、内線 0123";
  assert.equal(maskText(text), text);
  assert.equal(maskText("予約番号 20261004-001"), "予約番号 20261004-001");
});

test("設定の「伏せ字にする」が FALSE なら替えない。上限文字数で切る", () => {
  const config = Object.assign({}, DEFAULT_CONFIG, { answerLimit: 200 });
  assert.equal(sendableText("連絡先 03-0000-1234", config), "連絡先 〔電話〕");
  assert.equal(sendableText("連絡先 03-0000-1234", Object.assign({}, config, { mask: false })), "連絡先 03-0000-1234");
  assert.equal(sendableText("あ".repeat(300), config).length, 200);
});
