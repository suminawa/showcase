import { test } from "node:test";
import assert from "node:assert/strict";
import { analysisReport, buildDigestText, buildErrorText, deliveryFailureLines, digestSubject, summaryReport } from "../src/notify_text.js";
import { buildPayload } from "../src/message.js";
import { aggregate } from "../src/summary.js";
import { failedSummary, quietSummary } from "../src/summary_prompt.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG, { storeName: "サロン みなと" });
let row = 1;
function record(over) {
  row += 1;
  return Object.assign({ row: row, key: "k" + row, date: "2026-10-03", rating: 4, store: "", excerpt: "秘密の回答の本文", category: "接客", sentiment: "良い", request: "", summary: "秘密の要約", attention: false }, over);
}
const agg = aggregate(
  [
    record({ category: "接客" }),
    record({ category: "接客" }),
    record({ category: "品質", sentiment: "悪い", attention: true }),
    record({ category: "待ち時間", sentiment: "悪い", request: "待ち時間の目安の案内", date: "2026-09-25" }),
    record({ category: "待ち時間", sentiment: "悪い", request: "待ち時間の目安の案内" }),
  ],
  config,
  "2026-10-04",
);
const SUMMARY = {
  themes: [{ title: "待ち時間の目安の案内", ids: ["q1"], count: 1, example: "秘密の要約" }],
  actions: [
    { text: "受付で待ち時間の目安をお伝えしてみてください。", basis: "b" },
    { text: "予約の枠を見直してみてください。", basis: "b" },
  ],
  themesNote: "",
  actionsNote: "",
};

test("通知の本文: 数と要望のまとまりと今週の 3 つ。回答の本文と要約は入らない", () => {
  const text = buildDigestText(agg, SUMMARY, config, "https://docs.google.com/spreadsheets/d/SHEETID/edit#gid=5");
  assert.equal(
    text,
    [
      "【サロン みなと】お客さまの声のまとめ（2026-09-28〜10-04）",
      "回答 4 件｜悪いの割合 50%（前の期間 100%）｜評価の平均 4",
      "多い分類: 接客 2 件・待ち時間 1 件・品質 1 件",
      "多い要望: 待ち時間の目安の案内（1 件）",
      "今週の 3 つ:",
      "1. 受付で待ち時間の目安をお伝えしてみてください。",
      "2. 予約の枠を見直してみてください。",
      "すぐに読んでほしい回答: 1 件",
      "くわしくは「まとめ」シートをご覧ください: https://docs.google.com/spreadsheets/d/SHEETID/edit#gid=5",
    ].join("\n"),
  );
  assert.equal(text.includes("秘密"), false);
  assert.equal(digestSubject(agg, config), "【サロン みなと】お客さまの声のまとめ（2026-09-28〜10-04）");
  assert.ok(buildDigestText(agg, quietSummary(), config, "u").includes("今週の 3 つ:\nこの期間は、改善を求める声はありませんでした。\n"));
  // まだ分析していない回答があれば、URL の前に件数を 1 行（0 件・省いたときは出さない）
  assert.ok(
    buildDigestText(agg, SUMMARY, config, "u", 37).endsWith(
      "すぐに読んでほしい回答: 1 件\nまだ分析していない回答が 37 件あります。続きは次の実行で分析します（毎日分けて分析するには、README の「週に 1 回送る」をご覧ください）。\nくわしくは「まとめ」シートをご覧ください: u",
    ),
  );
  assert.equal(buildDigestText(agg, SUMMARY, config, "u", 0), buildDigestText(agg, SUMMARY, config, "u"));
  assert.equal(buildDigestText(agg, SUMMARY, config, "u", 0).includes("まだ分析していない"), false);
  // LINE は 5,000 字、Discord は 1,900 字で切る（元: 問い合わせ整理の buildPayload）
  assert.ok(buildPayload("x".repeat(6000), "line", { lineTo: "U1" }).messages[0].text.length <= 5000);
  assert.ok(buildPayload("x".repeat(3000), "discord").content.length <= 1900);
  assert.deepEqual(buildPayload("t", "slack"), { text: "t" });
  // Slack は & < > を字のまま出す（<!channel> などの呼び出しや、リンクの書き方として読まれないように）
  assert.deepEqual(buildPayload("<!channel> 駐車場 & 予約 <https://x|y>", "slack"), { text: "&lt;!channel&gt; 駐車場 &amp; 予約 &lt;https://x|y&gt;" });
  // Discord は @everyone・@here・人やロールへの呼び出しを鳴らさない
  assert.deepEqual(buildPayload("@everyone 土曜の予約枠", "discord"), { content: "@everyone 土曜の予約枠", allowed_mentions: { parse: [] } });
});

test("「分析する」の alert: 件数と残り、時間切れ・1 日の上限・エラー・飛ばした分", () => {
  const base = { analyzed: 42, empty: 3, remaining: 0, stop: "", perDay: 500, skipped: 0, skipMessage: "", errorMessage: "", samples: false };
  assert.equal(analysisReport(base), "新しく 42 件を分析しました（回答なし 3 件を含みます）。残り 0 件。");
  assert.equal(analysisReport(Object.assign({}, base, { analyzed: 0, empty: 0 })), "新しい回答はありません。分析結果はそろっています。");
  assert.equal(analysisReport(Object.assign({}, base, { remaining: 58, stop: "time" })), "新しく 42 件を分析しました（回答なし 3 件を含みます）。残り 58 件。\n残り 58 件は、もう一度「分析する」を押すと続きから分析します。");
  assert.ok(analysisReport(Object.assign({}, base, { remaining: 8, stop: "daily" })).endsWith("今日の上限（500 件）に達しました。残りは明日「分析する」を押すと続きから分析します。"));
  assert.equal(analysisReport(Object.assign({}, base, { analyzed: 0, empty: 0, remaining: 29, stop: "error", errorMessage: "API キーが受け付けられませんでした。" })), "API キーが受け付けられませんでした。");
  assert.ok(analysisReport(Object.assign({}, base, { skipped: 20, skipMessage: "リクエストが受け付けられませんでした（400）。「モデル」の設定を確かめてください。" })).endsWith("\nリクエストが受け付けられませんでした（400）。「モデル」の設定を確かめてください。20 件は次回もう一度試します。"));
  assert.ok(analysisReport(Object.assign({}, base, { samples: true })).startsWith("見本の答えで 42 件を分析しました"));
});

test("「まとめを作る」の alert・送れなかった宛先・エラーの通知", () => {
  assert.equal(summaryReport(agg, SUMMARY, 0, []), "まとめを作りました（回答 4 件、要望のまとまり 1 個）。「まとめ」シートをご覧ください。");
  assert.equal(
    summaryReport(agg, failedSummary(), 12, ["slack", "mail"]),
    [
      "まとめを作りました（回答 4 件、要望のまとまり 0 個）。「まとめ」シートをご覧ください。",
      "今週の 3 つを作れませんでした。もう一度「まとめを作る」をお試しください。",
      "まだ分析していない回答が 12 件あります。先に「分析する」を押すと、まとめに入ります。",
      "slack には送れませんでした。Webhook URL をご確認ください。",
      "mail には送れませんでした。「送り先メール」と、今日の送信数の上限をご確認ください。",
    ].join("\n"),
  );
  assert.deepEqual(deliveryFailureLines(["line"]), ["line には送れませんでした。LINE のチャネルアクセストークンと送信先 ID をご確認ください。"]);
  assert.equal(buildErrorText(new Error("API キーが受け付けられませんでした。"), "2026-10-05 08:00:10"), "【お客さまアンケート｜エラー】2026-10-05 08:00:10\n自動の実行が止まりました: API キーが受け付けられませんでした。\nメニュー「設定を確かめる」で、直すところを確かめてください。");
});
