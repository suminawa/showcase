import { test } from "node:test";
import assert from "node:assert/strict";
import { MANIFEST, SOURCE_ORDER, toGasSource } from "../scripts/build.mjs";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** SOURCE_ORDER のうち、まだ無いファイルは飛ばして束ねる（タスクを順に進めている途中でもテストが通るように） */
export function partialSource() {
  return SOURCE_ORDER.filter((n) => existsSync(join(root, "src", n))).map((n) => toGasSource(readFileSync(join(root, "src", n), "utf8"))).join("\n\n");
}

test("import 行は落ち、export だけが剥がれる", () => {
  const input = 'import { a } from "./a.js";\nexport function f() {\n  return 1;\n}\nexport const B = 2;\nexport class C extends Error {}\n';
  assert.equal(toGasSource(input), "function f() {\n  return 1;\n}\nconst B = 2;\nclass C extends Error {}");
});

test("SOURCE_ORDER は 27 個で、先頭は gas_main.js、重複が無い", () => {
  assert.equal(SOURCE_ORDER.length, 27);
  assert.equal(SOURCE_ORDER[0], "gas_main.js");
  assert.deepEqual(SOURCE_ORDER.slice().sort(), Array.from(new Set(SOURCE_ORDER)).sort());
});

test("マニフェストは Asia/Tokyo の V8 で、許可は設計書 §7-2 の 7 つ（シートはこのスプレッドシートだけ）", () => {
  assert.equal(MANIFEST.timeZone, "Asia/Tokyo");
  assert.equal(MANIFEST.runtimeVersion, "V8");
  assert.equal(MANIFEST.webapp, undefined);
  assert.deepEqual(MANIFEST.oauthScopes, [
    "https://www.googleapis.com/auth/spreadsheets.currentonly",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/script.container.ui",
    "https://www.googleapis.com/auth/script.send_mail",
    "https://www.googleapis.com/auth/script.scriptapp",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/forms",
  ]);
});

test("つないだ結果に import / export は残らない", () => {
  assert.equal(/^\s*(import|export)\s/m.test(partialSource()), false);
});

test("1 つの名前空間に並ぶので、同じ名前が 2 つあってはいけない", () => {
  const code = partialSource();
  const pattern = /^(?:function|class|const|let|var)\s+([A-Za-z0-9_$]+)/gm;
  const seen = [];
  const duplicated = [];
  let match = pattern.exec(code);
  while (match !== null) {
    if (seen.indexOf(match[1]) >= 0) duplicated.push(match[1]);
    seen.push(match[1]);
    match = pattern.exec(code);
  }
  assert.deepEqual(duplicated, []);
});

test("src にあるファイルは SOURCE_ORDER に全部入っている", () => {
  const files = readdirSync(join(root, "src"))
    .filter((name) => name.endsWith(".js"))
    .sort();
  for (const name of files) assert.ok(SOURCE_ORDER.indexOf(name) >= 0, name + " が SOURCE_ORDER に無い");
});

test("入口の 11 個が gas_main.js にあり、つないだ結果にも入っている", () => {
  const code = partialSource();
  for (const name of ["onOpen", "initializeSheets", "checkSettings", "loadSamples", "buildForm", "analyzeNow", "buildSummaryNow", "showUsage", "toggleWeekly", "runWeekly", "runDaily"]) {
    assert.ok(code.includes("function " + name + "()"), name + " が無い");
  }
  assert.ok(code.startsWith("/**\n * 入口。"), "gas_main.js が先頭");
});

test("求める許可は、実際に使うものだけ（Gmail・ほかのスプレッドシート・ウェブアプリは使わない）", () => {
  const code = partialSource();
  for (const used of ["SpreadsheetApp.getActiveSpreadsheet()", "SpreadsheetApp.getUi()", "UrlFetchApp.fetch(", "MailApp.sendEmail(", "ScriptApp.newTrigger(", "Session.getEffectiveUser()", "FormApp.create(", "FormApp.openById(", "setDestination("]) {
    assert.ok(code.includes(used), used + " が無い（使わないなら許可を外すこと）");
  }
  for (const unused of ["GmailApp", "SpreadsheetApp.openById", "SpreadsheetApp.openByUrl", "DriveApp", "ContentService", "doPost", "doGet"]) {
    assert.equal(code.includes(unused), false, unused + " は使わない（spreadsheets.currentonly の範囲を越える）");
  }
  // フォームは回答者のメールを集めない・ログインを求めない（設計書 §3-5）。QR の外部サービスに URL を渡さない（§3-6）
  assert.ok(code.includes("setCollectEmail(false)"));
  assert.ok(code.includes("setLimitOneResponsePerUser(false)"));
  assert.ok(code.includes("setRequireLogin(false)"), "Workspace のアカウントでも、組織の外の人が答えられるように");
  assert.equal(code.includes("setCollectEmail(true)"), false);
  assert.equal(/=IMAGE\(|chart\.googleapis|api\.qrserver/i.test(code), false, "QR の外部サービスを使わない");
});

test("キーの値や回答の本文をログに出す行が無い", () => {
  const code = partialSource();
  assert.equal(/Logger\.log\([^)]*apiKey/.test(code), false, "キーをログに出さない");
  assert.equal(/Logger\.log\([^)]*response\.text/.test(code), false, "回答の本文をログに出さない");
});
