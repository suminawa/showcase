import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 純粋な処理。GAS のグローバルに触らず、Node でそのままテストできる */
export const PURE = [
  "setup.js",
  "dates.js",
  "config.js",
  "columns.js",
  "questions.js",
  "form_plan.js",
  "presets.js",
  "mask.js",
  "responses.js",
  "rows.js",
  "schema.js",
  "prompt.js",
  "summary.js",
  "summary_prompt.js",
  "summary_sheet.js",
  "notify_text.js",
  "message.js",
  "usage.js",
  "samples.js",
  "check.js",
];

/** GAS に触る接続。単体テストはせず、bundle テストで偽の GAS の上を通す */
export const GLUE = ["gas_main.js", "gas_store.js", "gas_sheets.js", "gas_claude.js", "gas_notify.js", "gas_mail.js", "gas_form.js"];

const GAS_GLOBALS = [
  "SpreadsheetApp",
  "GmailApp",
  "UrlFetchApp",
  "PropertiesService",
  "CacheService",
  "LockService",
  "MailApp",
  "ContentService",
  "ScriptApp",
  "Logger",
  "Utilities",
  "Session",
  "FormApp",
];

/** 純粋な処理が「いま」の時刻や乱数を勝手に取らないための印。引数つきの new Date(x) は決定的なので許す */
const IMPURE_PATTERNS = [/Date\.now\(/, /new Date\(\s*\)/, /Math\.random\(/];

function sourceOf(name) {
  return readFileSync(join(root, "src", name), "utf8");
}

test("純粋な処理は GAS のグローバルに触らず、「いま」の時刻と乱数を自分で取らず、gas_ を読み込まない", () => {
  for (const name of PURE) {
    if (!existsSync(join(root, "src", name))) continue;
    const source = sourceOf(name);
    for (const global of GAS_GLOBALS) assert.equal(source.includes(global), false, name + " が " + global + " に触っている");
    for (const pattern of IMPURE_PATTERNS) assert.equal(pattern.test(source), false, name + " が " + pattern.source + " を使っている");
    assert.equal(/from\s+["']\.\/gas_/.test(source), false, name + " が gas_ を読み込んでいる");
  }
});

test("src にあるのは純粋な処理と GAS 側の 2 種類だけ。ES2019 の範囲で書く（?. と ?? を使わない）", () => {
  const files = readdirSync(join(root, "src"))
    .filter((name) => name.endsWith(".js"))
    .sort();
  for (const name of files) {
    assert.ok(PURE.indexOf(name) >= 0 || GLUE.indexOf(name) >= 0, name + " が一覧に無い");
    const source = sourceOf(name);
    assert.equal(/\?\.[a-zA-Z_$\[(]/.test(source), false, name + " が ?. を使っている");
    assert.equal(/\?\?/.test(source), false, name + " が ?? を使っている");
  }
});
