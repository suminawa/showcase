import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CHECK_LINE_LIMIT, CHECK_MENU_LABEL, INIT_MENU_LABEL, checkReport, initFailureText, initReport, limitLines, missingHeaders, missingSettingRows } from "../src/setup.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/**
 * src/setup.js は 3 つのキット（期限アラート・フォーム受付・予約ページ）に同じ中身を写して置く。
 * 各キットの検査は自分の写ししか読めないので、先頭のコメントを除いた本文の行数とハッシュを定数で持つ。
 * setup.js を直したら、3 本とも同じに直し、この 2 つの定数を 3 本とも書き換える。
 */
const SETUP_BODY_LINES = 141;
const SETUP_BODY_SHA256 = "a0e5d6d1d797537ac2faeb836bd1c6a49f95abd354350742e75ad15029f3859e";

function emptyPlan() {
  return { createSheets: [], appendHeaders: [], appendSettings: { sheet: "設定", rows: [], blank: false }, notes: [] };
}

/** 読み取りと同じそろえ方の例（空白を落とし、小文字にする） */
function looseKey(text) {
  return String(text).replace(/\s+/g, "").toLowerCase();
}

test("メニューの字は 3 本で同じ", () => {
  assert.equal(INIT_MENU_LABEL, "初期化（足りないシート・見出し・設定を足す。データは消しません）");
  assert.equal(CHECK_MENU_LABEL, "設定を確かめる");
  assert.equal(CHECK_LINE_LIMIT, 15);
});

test("missingHeaders: 空の 1 行目なら全部、一部あれば無いものだけを wanted の順で", () => {
  assert.deepEqual(missingHeaders([], ["件名", "期限", "担当", "状態"]), ["件名", "期限", "担当", "状態"]);
  assert.deepEqual(missingHeaders(["状態", "件名"], ["件名", "期限", "担当", "状態"]), ["期限", "担当"]);
  assert.deepEqual(missingHeaders([" 件名 ", "期限\t", "担当", "状態"], ["件名", "期限", "担当", "状態"]), []);
  assert.deepEqual(missingHeaders(["件名"], ["件名", "担当", "担当", ""]), ["担当"]);
});

test("missingSettingRows: keyOf で同じとみなす行は足さない（空白の抜け・大文字小文字の違い）", () => {
  const wanted = [["Slack Webhook URL", ""], ["しきい値", "3,0"]];
  for (const written of ["Slack Webhook URL", "SlackWebhookURL", "slack webhook url", " Slack  Webhook URL "]) {
    assert.deepEqual(missingSettingRows([["項目", "値"], [written, "https://hooks.slack.com/x"]], wanted, looseKey), [["しきい値", "3,0"]], written);
  }
  // 見出しの「項目」は数えず、空の 1 列目も数えない
  assert.deepEqual(missingSettingRows([["項目", "値"], ["", "メモ"]], wanted, looseKey), wanted);
  // wanted の中の重なりは 1 つにする
  assert.deepEqual(missingSettingRows([], [["しきい値", "3,0"], ["しきい値", "7"]], looseKey), [["しきい値", "3,0"]]);
});

test("limitLines: max 行を越えたら「ほか N 件」", () => {
  assert.deepEqual(limitLines(["a", "b"], 2), ["a", "b"]);
  assert.deepEqual(limitLines(["a", "b", "c", "d"], 2), ["a", "b", "ほか 2 件"]);
});

test("initReport: 足すものが無ければ「変更はありません。」で始まり、次の一歩で終わる", () => {
  const text = initReport(emptyPlan(), "次は「設定を確かめる」を実行してください。");
  assert.equal(text, "変更はありません。シート・見出し・設定の行はそろっています。\n\n次は「設定を確かめる」を実行してください。");
});

test("initReport: 作ったシート・空だったシート・見出し・設定の行・ご確認ください を 1 行ずつ", () => {
  const plan = emptyPlan();
  plan.createSheets.push({ name: "設定", rows: [["項目", "値"]], freeze: true });
  plan.createSheets.push({ name: "期限", rows: [["件名"]], freeze: true });
  plan.createSheets.push({ name: "枠", rows: [["日付"]], freeze: true, exists: true });
  plan.appendHeaders.push({ sheet: "受付", names: ["phone", "address"] });
  plan.appendSettings.rows = [["しきい値", "3,0"], ["文面テンプレ", "・{件名}"]];
  plan.notes.push("「期限」シートの 1 行目に「件名」の列がありません。");
  const text = initReport(plan, "次は「設定を確かめる」を実行してください。");
  assert.equal(
    text,
    [
      "初期化しました。足したものは次のとおりです（すでにあったデータは変えていません）。",
      "",
      "・シートを作りました: 設定、期限",
      "・空だった「枠」シートに見出しを書きました",
      "・「受付」シートの見出しに足しました: phone、address",
      "・「設定」シートに 2 行足しました: しきい値、文面テンプレ（値は既定値です。変えるときは書き換えてください）",
      "",
      "ご確認ください:",
      "・「期限」シートの 1 行目に「件名」の列がありません。",
      "",
      "次は「設定を確かめる」を実行してください。",
    ].join("\n"),
  );
});

test("initReport: 値を空のまま足すキットは、その旨を書く", () => {
  const plan = emptyPlan();
  plan.appendSettings = { sheet: "設定", rows: [["カレンダー ID", ""]], blank: true };
  assert.ok(initReport(plan, "").includes("・「設定」シートに 1 行足しました: カレンダー ID（値は空のままです。空の項目は既定値で動きます）"));
  assert.equal(initReport(plan, "").endsWith("）"), true, "次の一歩が空なら何も足さない");
});

test("checkReport: 誤りが無ければ「問題ありません。」と概要", () => {
  assert.equal(checkReport([], ["通知: slack"], "", []), "問題ありません。\n\n通知: slack");
  assert.equal(checkReport([], [], "", []), "問題ありません。");
});

test("checkReport: 誤りがあれば「直すところがあります。」で始まり「直したら、もう一度」で終わる", () => {
  const text = checkReport(["「設定」シートの「Webhook URL」が空です。"], ["出さない概要"], "", []);
  assert.ok(text.startsWith("直すところがあります。\n\n・「設定」シートの「Webhook URL」が空です。"));
  assert.ok(text.endsWith("直したら、もう一度「設定を確かめる」を実行してください。"));
  assert.equal(text.includes("出さない概要"), false);
});

test("checkReport: 16 件以上は 15 行と「・ほか N 件」", () => {
  const problems = Array.from({ length: 22 }, (_, i) => "誤り " + (i + 1));
  const lines = checkReport(problems, [], "", []).split("\n");
  assert.equal(lines.filter((line) => /^・誤り /.test(line)).length, 15);
  assert.ok(lines.includes("・ほか 7 件"));
});

test("checkReport: 前置き booking: のときは「・」を付けず、前置きで始める", () => {
  const text = checkReport(["booking: 枠シートの 2 行目: 曜日を読み取れません", "「予約」シートがありません。"], [], "booking: ", []);
  assert.ok(text.includes("\nbooking: 枠シートの 2 行目: 曜日を読み取れません\n"));
  assert.ok(text.includes("\nbooking: 「予約」シートがありません。\n"));
  assert.equal(text.includes("・booking"), false);
});

test("checkReport: ご参考 は、どちらの場合も最後に「・」を付けて並べる", () => {
  assert.equal(checkReport([], ["概要"], "", ["トリガーがありません。"]), "問題ありません。\n\n概要\n\nご参考:\n・トリガーがありません。");
  assert.ok(checkReport(["誤り"], [], "", ["参考"]).endsWith("\n\nご参考:\n・参考"));
});

test("initFailureText: 途中まで書けた分をつなげ、止まった場所とエラーを添える", () => {
  const text = initFailureText(["設定に 3 行を足しました"], "見出しの追記", new Error("編集権限がありません"));
  assert.equal(text, "設定に 3 行を足しました。そのあと 見出しの追記で止まりました: 編集権限がありません");
});

test("initFailureText: 何も書けていなければ、止まった場所とエラーだけ", () => {
  const text = initFailureText([], "設定への書き込み", new Error("編集権限がありません"));
  assert.equal(text, "設定への書き込みで止まりました: 編集権限がありません");
});

test("3 本の src/setup.js の本文は同じ（写しがずれていない）", () => {
  const source = readFileSync(join(root, "src", "setup.js"), "utf8");
  const body = source.slice(source.indexOf("*/\n") + 3);
  assert.equal(body.split("\n").length, SETUP_BODY_LINES);
  assert.equal(createHash("sha256").update(body, "utf8").digest("hex"), SETUP_BODY_SHA256);
});
