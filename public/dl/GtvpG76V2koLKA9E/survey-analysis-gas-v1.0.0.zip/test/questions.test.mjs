import { test } from "node:test";
import assert from "node:assert/strict";
import { QUESTION_HEADERS, columnsFromQuestions, parseQuestions, questionSheetValues, questionsHash, splitChoices, typeOf, yesNoOf } from "../src/questions.js";

/** 見出しつきの質問シート。rows は [並び, 質問, 種類, 選択肢, 必須, 説明, 集計, 項目 ID] */
function sheet(rows) {
  return [QUESTION_HEADERS.slice()].concat(rows);
}

test("8 列を読む: 質問・種類・選択肢・必須・説明・集計・項目 ID", () => {
  const parsed = parseQuestions(sheet([[1, "ご利用の店舗", "選択", "駅前店\n本町店", "はい", "いちばん近い店舗", "店舗", "123"]]));
  assert.deepEqual(parsed.problems, []);
  assert.deepEqual(parsed.questions, [{ row: 2, order: 1, title: "ご利用の店舗", type: "選択", choices: ["駅前店", "本町店"], labels: [], required: true, help: "いちばん近い店舗", use: "店舗", itemId: "123" }]);
  // 見出しの並びが違っても名前で読む
  const moved = parseQuestions([["質問", "種類", "並び", "選択肢", "必須", "説明", "集計", "項目 ID"], ["ご感想", "自由記述", "", "", "", "", "", ""]]);
  assert.equal(moved.questions[0].type, "自由記述");
});

test("種類の揺れ（5段階・はいいいえ・自由など）を読む。読めない種類は誤り", () => {
  assert.equal(typeOf("5段階"), "5 段階");
  assert.equal(typeOf("５ 段階"), "5 段階");
  assert.equal(typeOf("はいいいえ"), "はい・いいえ");
  assert.equal(typeOf("はい/いいえ"), "はい・いいえ");
  assert.equal(typeOf("自由"), "自由記述");
  assert.equal(typeOf("記述"), "自由記述");
  assert.equal(typeOf("チェックボックス"), "複数");
  assert.equal(typeOf("プルダウン"), "");
  assert.deepEqual(parseQuestions(sheet([[1, "Q", "プルダウン", "a\nb", "", "", "", ""]])).problems, ["質問シートの 2 行目: 種類「プルダウン」を読めません。選択 / 複数 / 5 段階 / 自由記述 / はい・いいえ のどれかにしてください。"]);
});

test("選択肢はセル内の改行・「｜」・「|」で区切る。5 段階は「左｜右」、はい・いいえ は 2 択", () => {
  assert.deepEqual(splitChoices("カット\r\nカラー｜パーマ|カット| "), ["カット", "カラー", "パーマ"]);
  const parsed = parseQuestions(sheet([[1, "満足度", "5 段階", "不満｜満足", "", "", "", ""], [2, "また来たいか", "はい・いいえ", "", "", "", "", ""]]));
  assert.deepEqual(parsed.questions[0].labels, ["不満", "満足"]);
  assert.deepEqual(parsed.questions[1].choices, ["はい", "いいえ"]);
  assert.deepEqual(parseQuestions(sheet([[1, "満足度", "5 段階", "不満", "", "", "", ""]])).problems, ["質問シートの 2 行目: 5 段階の選択肢は「左の言葉｜右の言葉」の形で書くか、空にしてください（例: 不満｜満足）。"]);
});

test("必須は はい / いいえ / TRUE / FALSE（空 = いいえ）", () => {
  assert.equal(yesNoOf("はい"), true);
  assert.equal(yesNoOf(true), true);
  assert.equal(yesNoOf("TRUE"), true);
  assert.equal(yesNoOf("いいえ"), false);
  assert.equal(yesNoOf(""), false);
  assert.equal(yesNoOf("たぶん"), null);
  assert.deepEqual(parseQuestions(sheet([[1, "Q", "自由記述", "", "たぶん", "", "", ""]])).problems, ["質問シートの 2 行目: 必須は「はい」か「いいえ」にしてください（いまは「たぶん」）。"]);
});

test("並びは書いた数の順、空は何番目の質問かを数として並べる。質問が空の行は飛ばす", () => {
  const parsed = parseQuestions(sheet([[5, "五", "自由記述", "", "", "", "", ""], ["", "", "", "", "", "", "", ""], [1, "一", "自由記述", "", "", "", "", ""], ["", "三", "自由記述", "", "", "", "", ""]]));
  assert.deepEqual(parsed.questions.map((q) => q.title), ["一", "三", "五"], "「三」は 3 番目の質問なので 3 として並ぶ");
  assert.deepEqual(parsed.questions.map((q) => q.row), [4, 5, 2]);
});

test("検査の文を全部集める: 選択肢 1 つ・同じ質問文・読めない種類・回答 4 つ・評価が 5 段階でない・店舗が選択でない", () => {
  const parsed = parseQuestions(
    sheet([
      [1, "店舗", "選択", "駅前店", "", "", "", ""],
      [2, "店舗", "選択", "駅前店\n本町店", "", "", "", ""],
      [3, "Q3", "ラジオボタン", "", "", "", "", ""],
      [4, "A1", "自由記述", "", "", "", "回答", ""],
      [5, "A2", "自由記述", "", "", "", "回答", ""],
      [6, "A3", "自由記述", "", "", "", "回答", ""],
      [7, "A4", "自由記述", "", "", "", "回答", ""],
      [8, "満足", "選択", "よい\nわるい", "", "", "評価", ""],
      [9, "来店", "はい・いいえ", "", "", "", "店舗", ""],
    ]),
  );
  assert.deepEqual(parsed.problems, [
    "質問シートの 2 行目: 種類が「選択」ですが、選択肢が 1 つしかありません。セル内で改行して 2 つ以上書いてください。",
    "質問シートの 3 行目: 「店舗」と同じ文の質問が 2 行目にもあります。回答シートの見出しが重なるので、どちらかの文を変えてください。",
    "質問シートの 4 行目: 種類「ラジオボタン」を読めません。選択 / 複数 / 5 段階 / 自由記述 / はい・いいえ のどれかにしてください。",
    "質問シートの 9 行目: 集計「評価」は、種類が「5 段階」の質問にだけ付けられます。",
    "質問シートの 10 行目: 集計「店舗」は、種類が「選択」の質問にだけ付けられます。",
    "集計「回答」は 3 つまでにしてください（いまは 4 つ）。",
  ]);
  assert.deepEqual(parseQuestions([QUESTION_HEADERS.slice()]).problems, ["質問シートに質問がありません。2 行目から、1 行に 1 つずつ質問を書いてください。"]);
  assert.deepEqual(parseQuestions([["質問", "種類"]]).problems[0], "質問シートの 1 行目に「並び」「選択肢」「必須」「説明」「集計」「項目 ID」の列がありません。メニュー「初期化」を実行すると見出しを足します。");
});

test("集計の自動: 自由記述 → 回答（3 つまで）、最初の 5 段階 → 評価、「店舗」「店」「院」を含む選択 → 店舗。columnsFromQuestions が列を返す", () => {
  const parsed = parseQuestions(
    sheet([
      [1, "満足度", "5 段階", "", "はい", "", "", ""],
      [2, "説明の分かりやすさ", "5 段階", "", "", "", "", ""],
      [3, "ご利用の院", "選択", "東院\n西院", "", "", "", ""],
      [4, "良かった点", "自由記述", "", "", "", "", ""],
      [5, "気になった点", "自由記述", "", "", "", "", ""],
      [6, "ご要望", "自由記述", "", "", "", "", ""],
      [7, "そのほか", "自由記述", "", "", "", "", ""],
    ]),
  );
  assert.deepEqual(parsed.questions.map((q) => q.use), ["評価", "使わない", "店舗", "回答", "回答", "回答", "使わない"]);
  assert.deepEqual(columnsFromQuestions(parsed.questions), { answers: ["良かった点", "気になった点", "ご要望"], date: "タイムスタンプ", rating: "満足度", store: "ご利用の院" });
});

test("名前や連絡先を聞く自由記述は、止めずにご参考。分析には使わない。指紋は項目 ID を除いて取る", () => {
  const values = sheet([[1, "お名前（任意）", "自由記述", "", "", "", "", ""], [2, "ご感想", "自由記述", "", "", "", "", ""]]);
  const parsed = parseQuestions(values);
  assert.deepEqual(parsed.problems, []);
  assert.deepEqual(parsed.notes, ["質問シートの 2 行目「お名前（任意）」: 名前や連絡先を聞く質問は、分析には使いません（Claude に送りません）。アンケートに要らなければ消してください。"]);
  assert.deepEqual(parsed.questions.map((q) => q.use), ["使わない", "回答"]);
  const withIds = values.map((row) => row.slice());
  withIds[1][7] = "555";
  assert.equal(questionsHash(withIds), questionsHash(values));
  withIds[2][1] = "ご感想をどうぞ";
  assert.notEqual(questionsHash(withIds), questionsHash(values));
  assert.deepEqual(questionSheetValues([{ title: "満足度", type: "5 段階", choices: [], labels: ["不満", "満足"], required: true, help: "", use: "評価" }]), [QUESTION_HEADERS, [1, "満足度", "5 段階", "不満｜満足", "はい", "", "評価", ""]]);
});
