/**
 * 偽の GAS。dist/Code.gs と同じ中身（scripts/build.mjs）を node:vm で走らせるための最小のグローバル。
 * 元: AI 問い合わせ整理キット 1.0.0 の test/fakes.mjs。Gmail を外し、名前つきの複数のシート・確認の画面（alert の
 * ボタン・prompt）・MailApp・週 1 回のトリガー・書式（太字・背景・チェックボックス）を足した。
 * 本物の Apps Script の癖のうち、このキットの動きに関わるものは偽物でも再現する（偽物が本物より甘いと、
 * テストが通っても実物で落ちる）。再現している癖:
 * - Sheets は書いた文字を打ち込んだときと同じく読み替える（数・日付・割合・TRUE/FALSE。先頭の ' は文字のまま）
 * - setValues は範囲と値の行数・列数が合わないと例外
 * - 保護されたシート（protect に名前を書く）への書き込みは例外
 * - プロパティは文字列だけ（数を入れても文字列で返る）。1 つ 9KB まで
 * - UrlFetchApp は muteHttpExceptions が無いと 4xx/5xx で例外。接続できないとき（タイムアウトなど）は mute でも例外
 * - トリガーは入れた人ごと。getProjectTriggers() は実行している人のものしか返さない
 * - トリガーからの実行では SpreadsheetApp.getUi() が例外
 * - マニフェストの oauthScopes に無い許可のサービスを呼ぶと例外
 * - FormApp（Task 8 で足した）: 質問の種類は変えられない・setDestination が「フォームの回答 N」を足す・
 *   getFormUrl で回答シートを探す・質問を消しても回答シートの列は残る・add…Item() は種類つきの質問を返し
 *   as…Item() を持たない・moveItem と deleteItem は汎用の Item しか受け付けない・getItemById は無い ID で null
 *   （createSandbox の中の「偽の FormApp」）
 * - ScriptLock を持っているあいだに alert・prompt を出すと trace.dialogsUnderLock に残る（本物は、読んでいるあいだ
 *   ほかの実行を待たせる）
 * - 1 回の実行は 6 分まで。時計（Claude の 1 回に claudeMs、Utilities.sleep の分だけ進む）が 6 分を越えるか killAtCall に
 *   当たると強制終了する。そのあとは GAS の呼び出しがすべて例外になり（キットの catch で拾っても、何も書けない）、
 *   入口は何も返さずに終わる（trace.kills に数える）。本物の強制終了は finally も通らないため
 * - シートの大きさ（行と列の数）は決まっていて、その外の範囲を getRange すると例外（新しいシートは 1,000 行・26 列。
 *   insertRowsAfter・insertColumnsAfter で広げる）
 * - 先頭が = + - @ の文字は数式として読まれる（値は #ERROR!）
 * - FormApp: setRequireLogin（Workspace で組織の外の人を締め出す設定。requireLoginThrows で、無い版の例外）・
 *   公開の段階がある版では、公開していないフォームは回答を受け付けない（setAcceptingResponses(true) が効かない）・
 *   回答シートの 1 列目の見出しはアカウントの言語で変わる（timestampHeader。英語なら Timestamp）
 */
import { createContext, runInContext } from "node:vm";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildSource, MANIFEST } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/** 引数なしの new Date() と Date.now() は 2026-10-04 21:10 JST から始まる偽の時計（テストが日付に依存しないように） */
export const FIXED_NOW = Date.UTC(2026, 9, 4, 12, 10, 0);
/** Apps Script の 1 回の実行の上限 */
export const EXECUTION_LIMIT_MS = 6 * 60000;
/** 6 分の強制終了。キットの catch に拾われても、そのあとの GAS の呼び出しはすべてこれで落ちる */
export class KillError extends Error {}

export const OWNER = "owner@example.com";
const PROPERTY_VALUE_LIMIT = 9 * 1024;
/**
 * setDestination が求めるシートの許可。Task 8 の Step 1 で本物を試し、spreadsheets.currentonly で通らなかったときは
 * "https://www.googleapis.com/auth/spreadsheets" に替える（MANIFEST と一緒に）。
 */
const DESTINATION_SCOPE = "https://www.googleapis.com/auth/spreadsheets.currentonly";

/**
 * 本物の Sheets は、書き込んだ文字を人が打ち込んだときと同じように読み直す。
 * 先頭が ' なら文字（' は残らない）、数に見えれば数、割合は小数、TRUE/FALSE は真偽、日付に見えれば日付（JST）。
 */
export function parseWritten_(value) {
  if (typeof value !== "string") return value;
  if (value.charAt(0) === "'") return value.slice(1);
  const text = value.trim();
  if (/^(true|false)$/i.test(text)) return text.toLowerCase() === "true";
  if (/^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$/.test(text)) return Number(text.replace(/,/g, ""));
  if (/^[+-]?(\d+(\.\d+)?|\.\d+)(e[+-]?\d+)?$/i.test(text)) return Number(text);
  if (/^[+-]?\d+(\.\d+)?%$/.test(text)) return Number(text.slice(0, -1)) / 100;
  let m = text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  if (m) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], (m[4] ? +m[4] : 0) - 9, m[5] ? +m[5] : 0, m[6] ? +m[6] : 0));
  m = text.match(/^(\d{1,2})\/(\d{1,2})$/);
  if (m && +m[1] >= 1 && +m[1] <= 12 && +m[2] >= 1 && +m[2] <= 31) return new Date(Date.UTC(2026, +m[1] - 1, +m[2], -9));
  // 先頭が = + - @ の字は数式として読まれ、読めない式は #ERROR! になる（「+α のご要望」のような質問文も）
  if (/^[=+\-@]./.test(text)) return "#ERROR!";
  return value;
}

/** 新しいシートの大きさ（本物の insertSheet と同じ） */
export const NEW_SHEET_ROWS = 1000;
export const NEW_SHEET_COLUMNS = 26;

/**
 * 名前つきのシート。formats にはセルの書式（太字・背景・字の大きさ・チェックボックス）を「行,列」で残す。
 * 大きさ（getMaxRows・getMaxColumns）は、渡した値が入る大きさか 1,000 行・26 列の大きいほう。
 * __protect(true) は、テストが実行の途中でシートを保護する（GAS の関数ではない）。
 * options.raw が true なら、値を打ち込んだ形として読み替えない（フォームが回答シートに書く見出しは字のまま）。
 */
export function fakeSheet(sheetName, values, options) {
  const opts = Object.assign({ rename: () => {} }, options || {});
  let name = sheetName;
  const rows = (values || []).map((row) => (opts.raw ? Array.from(row) : Array.from(row).map(parseWritten_)));
  const formats = {};
  const denied = (what) => {
    if (opts.protected) throw new Error("You are trying to edit a protected cell or object. Please contact the spreadsheet owner to remove protection if you need to edit. (" + what + ")");
  };
  const width = () => rows.reduce((w, row) => Math.max(w, row.length), 0);
  // 行はフォームの回答（テストが rows に直に足す）でも増えるので、値の入った大きさより小さくはしない
  let maxRows = Math.max(NEW_SHEET_ROWS, rows.length);
  let maxColumns = Math.max(NEW_SHEET_COLUMNS, width());
  const write_ = (r, c, value) => {
    while (rows.length <= r) rows.push([]);
    while (rows[r].length <= c) rows[r].push("");
    rows[r][c] = parseWritten_(value);
  };
  const format_ = (r, c, nr, nc, key, value) => {
    for (let i = 0; i < nr; i += 1) for (let j = 0; j < nc; j += 1) formats[r + i + "," + (c + j)] = Object.assign({}, formats[r + i + "," + (c + j)], { [key]: value });
  };
  const sheet = {
    rows: rows,
    formats: formats,
    frozen: 0,
    getName: () => name,
    setName: (next) => {
      denied("setName");
      sheet.renamedTo = String(next);
      opts.rename(name, String(next));
      name = String(next);
      return sheet;
    },
    /** フォームの回答シートなら、そのフォームの URL（setDestination が決める）。ほかは null */
    getFormUrl: () => (opts.formUrl ? opts.formUrl() : null),
    getSheetId: () => opts.id,
    getLastRow: () => {
      let last = rows.length;
      while (last > 0 && rows[last - 1].every((cell) => cell === "")) last -= 1;
      return last;
    },
    getLastColumn: () => width(),
    getMaxRows: () => Math.max(maxRows, rows.length),
    getMaxColumns: () => Math.max(maxColumns, width()),
    insertRowsAfter: (after, count) => {
      denied("insertRowsAfter");
      maxRows = sheet.getMaxRows() + count;
      return sheet;
    },
    insertColumnsAfter: (after, count) => {
      denied("insertColumnsAfter");
      maxColumns = sheet.getMaxColumns() + count;
      return sheet;
    },
    __protect: (on) => {
      opts.protected = on !== false;
    },
    setFrozenRows: (n) => {
      sheet.frozen = n;
    },
    clear: () => {
      denied("clear");
      rows.length = 0;
      for (const key of Object.keys(formats)) delete formats[key];
    },
    getDataRange: () => ({ getValues: () => rows.slice(0, sheet.getLastRow()).map((row) => { const line = row.slice(); while (line.length < width()) line.push(""); return line; }) }),
    getRange: (r, c, nr, nc) => {
      const height = nr || 1;
      const wide = nc || 1;
      // 本物は、シートの大きさの外の範囲を取ると例外（書き込む前に insertRowsAfter で広げる）
      if (r < 1 || c < 1 || r + height - 1 > sheet.getMaxRows() || c + wide - 1 > sheet.getMaxColumns()) {
        throw new Error("The coordinates of the range are outside the dimensions of the sheet.");
      }
      return {
        getValues: () => {
          const out = [];
          for (let i = 0; i < height; i += 1) {
            const line = [];
            for (let j = 0; j < wide; j += 1) line.push(rows[r - 1 + i] && rows[r - 1 + i][c - 1 + j] !== undefined ? rows[r - 1 + i][c - 1 + j] : "");
            out.push(line);
          }
          return out;
        },
        setValues: (written) => {
          denied("setValues");
          // 本物は、範囲と値の大きさが違うと例外
          if (written.length !== height || written.some((line) => line.length !== wide)) {
            throw new Error("The number of rows or columns in the data does not match the range. (" + height + "x" + wide + ")");
          }
          for (let i = 0; i < written.length; i += 1) for (let j = 0; j < written[i].length; j += 1) write_(r - 1 + i, c - 1 + j, written[i][j]);
        },
        setFontWeight: (value) => format_(r, c, height, wide, "bold", value === "bold"),
        setFontSize: (value) => format_(r, c, height, wide, "size", value),
        setBackground: (value) => format_(r, c, height, wide, "background", value),
        insertCheckboxes: () => {
          denied("insertCheckboxes");
          format_(r, c, height, wide, "checkbox", true);
        },
      };
    },
  };
  return sheet;
}

/**
 * options = {
 *   sheets: { シート名: 値 }（左からの順）, apiKey, props, timeZone,
 *   claudeReply: (body, n) => { text, stop_reason?, status?, body? }（n は 1 から数えた呼び出しの回。無ければ全件「良い」）,
 *   claudeThrows（true なら接続できない）, killAtCall（n 回目の Claude 呼び出しの最中に 6 分の強制終了を真似る。
 *   そのあとの GAS の呼び出しはすべて例外になり、何も書けない）, claudeMs（Claude の 1 回で時計が進む ms。既定 0）,
 *   notifyStatus（Webhook の status）, mailQuota,
 *   lockBusy, protect: [保護するシート名], fromTrigger, scopes, triggers,
 *   forms: [{ id, destination, responses }]（既にあるフォーム）, formsHavePublish（false で setPublished の無い版）,
 *   formUrlDelay（回答シートの getFormUrl が null を返す回数）, shortenFails（短縮 URL に失敗する）,
 *   publishThrows（setPublished はあるが例外を投げる古いフォーム）, addItemFailsAt（n 回目の add…Item() で 1 回だけ例外）,
 *   requireLoginThrows（setRequireLogin が例外になる版）, timestampHeader（回答シートの 1 列目の見出し。既定「タイムスタンプ」）,
 *   onGetItems: (フォームの state) => {}（getItems() が一覧を返したあとに呼ぶ。読んでから当てるまでに質問が消えたときを真似る）,
 *   promptReply: { button: "OK" | "CANCEL", text }（prompt の答え）, promptReplies: [同じ形, ...]（prompt ごとの答えを順に。尽きたら promptReply）,
 *   confirms: ["OK" | "CANCEL" | () => "OK" | "CANCEL", ...]（ボタンつき alert の答えを順に。関数なら、確認の画面を
 *   読んでいるあいだに起きたことを真似てから答える）
 * }
 */
export function createSandbox(options) {
  const opts = options || {};
  const trace = { fetched: [], claudeBodies: [], alerts: [], prompts: [], mails: [], logs: [], scopeErrors: [], getUiCalls: 0, dialogsUnderLock: [], kills: 0 };
  const props = {};
  for (const key of Object.keys(opts.props || {})) props[key] = String(opts.props[key]);
  if (opts.apiKey !== undefined) props.ANTHROPIC_API_KEY = String(opts.apiKey);
  const protect = opts.protect || [];
  const sheets = {};
  const order = [];
  let nextId = 100;
  const rename_ = (from, to) => {
    if (Object.prototype.hasOwnProperty.call(sheets, to)) throw new Error("A sheet with the name \"" + to + "\" already exists. Please enter another name.");
    sheets[to] = sheets[from];
    delete sheets[from];
    order[order.indexOf(from)] = to;
  };
  const addSheet_ = (name, values, extra) => {
    nextId += 1;
    sheets[name] = fakeSheet(name, values, Object.assign({ protected: protect.indexOf(name) >= 0, id: nextId, rename: rename_ }, extra));
    order.push(name);
    return sheets[name];
  };
  for (const name of Object.keys(opts.sheets || {})) addSheet_(name, opts.sheets[name]);
  const scopes = opts.scopes || MANIFEST.oauthScopes;
  const user = OWNER;
  /** トリガーは { owner, handler, weekDay, hour, timeZone } */
  const triggers = (opts.triggers || []).map((t) => Object.assign({}, t));
  const confirms = (opts.confirms || []).slice();
  const promptReplies = (opts.promptReplies || []).slice();
  let claudeCalls = 0;
  let lockHeld = false;

  // 偽の時計と 6 分の強制終了。execute_ が入口の 1 回ごとに始まりを覚え直す
  let clock = FIXED_NOW;
  let executionStart = FIXED_NOW;
  let killed = false;
  class SandboxDate extends Date {
    constructor(...args) {
      if (args.length === 0) super(clock);
      else super(...args);
    }
    static now() {
      return clock;
    }
  }
  const alive_ = () => {
    if (!killed && clock - executionStart > EXECUTION_LIMIT_MS) killed = true;
    if (killed) throw new KillError("Exceeded maximum execution time");
  };
  const tick_ = (ms) => {
    clock += ms > 0 ? ms : 0;
    alive_();
  };

  const need = (scope, what) => {
    if (scopes.indexOf(scope) < 0) {
      trace.scopeErrors.push(what);
      throw new Error("Specified permissions are not sufficient to call " + what + ". Required permissions: " + scope);
    }
  };
  const SHEETS = "https://www.googleapis.com/auth/spreadsheets.currentonly";
  const FETCH = "https://www.googleapis.com/auth/script.external_request";
  const UI = "https://www.googleapis.com/auth/script.container.ui";
  const MAIL = "https://www.googleapis.com/auth/script.send_mail";
  const TRIGGERS = "https://www.googleapis.com/auth/script.scriptapp";
  const EMAIL = "https://www.googleapis.com/auth/userinfo.email";
  const FORMS = "https://www.googleapis.com/auth/forms";

  const book = {
    getId: () => "SHEETID",
    getUrl: () => "https://docs.google.com/spreadsheets/d/SHEETID/edit",
    getSpreadsheetTimeZone: () => opts.timeZone || "Asia/Tokyo",
    getSheets: () => order.map((name) => sheets[name]),
    getSheetByName: (name) => (Object.prototype.hasOwnProperty.call(sheets, name) ? sheets[name] : null),
    insertSheet: (name) => {
      if (Object.prototype.hasOwnProperty.call(sheets, name)) throw new Error("A sheet with the name \"" + name + "\" already exists. Please enter another name.");
      return addSheet_(name, []);
    },
  };
  const menu = { items: [], addItem: (label, fn) => { menu.items.push([label, fn]); return menu; }, addSeparator: () => { menu.items.push(["-", ""]); return menu; }, addToUi: () => {} };
  const Button = { OK: "OK", CANCEL: "CANCEL", YES: "YES", NO: "NO", CLOSE: "CLOSE" };
  const ButtonSet = { OK: "OK", OK_CANCEL: "OK_CANCEL", YES_NO: "YES_NO" };
  const ui = {
    Button: Button,
    ButtonSet: ButtonSet,
    alert: (a, b, c) => {
      if (lockHeld) trace.dialogsUnderLock.push(String(b === undefined ? a : b));
      if (b === undefined) {
        trace.alerts.push(String(a));
        return Button.OK;
      }
      trace.alerts.push(String(b));
      const answer = confirms.length > 0 ? confirms.shift() : Button.OK;
      return typeof answer === "function" ? answer() : answer;
    },
    prompt: (title, text, buttons) => {
      if (lockHeld) trace.dialogsUnderLock.push(String(text));
      trace.prompts.push(String(text));
      const reply = promptReplies.length > 0 ? promptReplies.shift() : opts.promptReply || { button: "CANCEL", text: "" };
      return { getSelectedButton: () => reply.button, getResponseText: () => reply.text };
    },
    createMenu: () => menu,
  };
  const wrapTrigger_ = (t) => ({ getHandlerFunction: () => t.handler, __t: t });

  // ===== 偽の FormApp（設計書 §9-1）=====
  // 本物の癖のうち再現するもの: 質問の種類は変えられない（as…Item() を別の種類に呼ぶと例外）、setDestination は
  // 「フォームの回答 N」（N は空いている番号）を足して 1 行目に「タイムスタンプ」+ 質問文を書き、そのシートの getFormUrl() が
  // このフォームを返す、つないだあとに質問文を変えると見出しも変わる、質問を消しても回答シートの列は残る、
  // setPublished は無い版（formsHavePublish: false）と有る版がある、manifest に forms が無ければ例外。
  // add…Item() が返すのは種類つきの質問（ScaleItem など）で、as…Item() は無い（汎用の Item にだけある）。
  // moveItem・deleteItem は汎用の Item しか受け付けない。getItemById・getItems は汎用の Item を返し、無い ID なら null。
  const forms = {};
  let formCount = 0;
  let itemCount = 1000;
  let formUrlDelay = opts.formUrlDelay || 0;
  let addCalls = 0;
  const ItemType = { MULTIPLE_CHOICE: "MULTIPLE_CHOICE", CHECKBOX: "CHECKBOX", SCALE: "SCALE", PARAGRAPH_TEXT: "PARAGRAPH_TEXT", SECTION_HEADER: "SECTION_HEADER" };
  const typedName_ = { MULTIPLE_CHOICE: "asMultipleChoiceItem", CHECKBOX: "asCheckboxItem", SCALE: "asScaleItem", PARAGRAPH_TEXT: "asParagraphTextItem" };
  const className_ = { MULTIPLE_CHOICE: "MultipleChoiceItem", CHECKBOX: "CheckboxItem", SCALE: "ScaleItem", PARAGRAPH_TEXT: "ParagraphTextItem" };
  const makeForm_ = (title, spec) => {
    formCount += 1;
    const id = spec && spec.id ? spec.id : "FORM" + formCount;
    const state = { id: id, title: String(title), description: "", confirmation: "", collectEmail: true, requireLogin: true, limitOne: true, allowEdits: true, accepting: true, showLink: true, published: false, items: [], destination: spec && spec.destination ? spec.destination : "", sheetName: "", columns: {}, deleted: false, responses: spec && spec.responses ? spec.responses : 0 };
    // 公開の段階がある版（setPublished が例外にならない）では、公開していないフォームは回答を受け付けない
    const publishStage = opts.formsHavePublish !== false && !opts.publishThrows;
    const headerAppend_ = (item) => {
      if (state.sheetName === "") return;
      const sheet = sheets[state.sheetName];
      state.columns[item.id] = sheet.rows[0].length;
      sheet.rows[0].push(item.title);
    };
    /** 種類つきの質問（ScaleItem など）。その種類の関数だけを持ち、as…Item() は無い */
    const typedOf_ = (item) => {
      const typed = {
        toString: () => className_[item.kind],
        getId: () => item.id,
        getIndex: () => state.items.indexOf(item),
        getType: () => ItemType[item.kind],
        getTitle: () => item.title,
        setTitle: (text) => {
          item.title = String(text);
          if (state.sheetName !== "" && state.columns[item.id] !== undefined) sheets[state.sheetName].rows[0][state.columns[item.id]] = item.title;
          return typed;
        },
        getHelpText: () => item.help,
        setHelpText: (text) => {
          item.help = String(text);
          return typed;
        },
        setRequired: (value) => {
          item.required = value === true;
          return typed;
        },
        isRequired: () => item.required,
      };
      if (item.kind === "MULTIPLE_CHOICE" || item.kind === "CHECKBOX") {
        typed.setChoiceValues = (values) => {
          item.choices = values.map(String);
          return typed;
        };
        typed.getChoices = () => item.choices.map((value) => ({ getValue: () => value }));
      }
      if (item.kind === "SCALE") {
        typed.setBounds = (lower, upper) => {
          item.bounds = [lower, upper];
          return typed;
        };
        typed.setLabels = (left, right) => {
          item.labels = [String(left), String(right)];
          return typed;
        };
      }
      return typed;
    };
    /** 汎用の Item（getItemById・getItems が返すもの）。種類つきの質問にするには as…Item() */
    const wrapItem_ = (item) => {
      const wrapped = {
        __item: item,
        __generic: true,
        toString: () => "Item",
        getId: () => item.id,
        getTitle: () => item.title,
        getType: () => ItemType[item.kind],
        getIndex: () => state.items.indexOf(item),
      };
      for (const kind of Object.keys(typedName_)) {
        wrapped[typedName_[kind]] = () => {
          // 本物も、別の種類の質問として扱おうとすると例外になる（種類は変えられない）
          if (item.kind !== kind) throw new Error("Item " + item.id + " is not a " + kind + " item.");
          return typedOf_(item);
        };
      }
      return wrapped;
    };
    const add_ = (kind) => () => {
      need(FORMS, "Form.add" + kind);
      addCalls += 1;
      if (opts.addItemFailsAt === addCalls) throw new Error("We're sorry, a server error occurred. Please wait a bit and try again.");
      itemCount += 1;
      const item = { id: itemCount, kind: kind, title: "", help: "", required: false, choices: [], bounds: null, labels: null };
      state.items.push(item);
      headerAppend_(item);
      // 本物の add…Item() は種類つきの質問を返す（as…Item() も moveItem も通らない）
      return typedOf_(item);
    };
    const find_ = (id) => {
      const item = state.items.find((one) => String(one.id) === String(id));
      if (!item) throw new Error("No item with the given ID could be found: " + id);
      return item;
    };
    /** moveItem・deleteItem は汎用の Item だけを受け付ける（種類つきの質問を渡すと、本物は引数の型の誤りで例外） */
    const genericOnly_ = (wrapped, method, rest) => {
      if (!wrapped || wrapped.__generic !== true) throw new Error("The parameters (FormApp." + String(wrapped) + rest + ") don't match the method signature for FormApp.Form." + method + ".");
    };
    const form = {
      __state: state,
      getId: () => state.id,
      getTitle: () => state.title,
      setTitle: (text) => {
        state.title = String(text);
        return form;
      },
      setDescription: (text) => {
        state.description = String(text);
        return form;
      },
      setConfirmationMessage: (text) => {
        state.confirmation = String(text);
        return form;
      },
      setCollectEmail: (value) => {
        state.collectEmail = value === true;
        return form;
      },
      collectsEmail: () => state.collectEmail,
      // Workspace のアカウントでは、組織の中の人だけに答えさせる設定が既定で入ることがある
      setRequireLogin: (value) => {
        if (opts.requireLoginThrows) throw new Error("Unexpected error while getting the method or property setRequireLogin on object FormApp.Form.");
        state.requireLogin = value === true;
        return form;
      },
      requiresLogin: () => state.requireLogin,
      setLimitOneResponsePerUser: (value) => {
        state.limitOne = value === true;
        return form;
      },
      setAllowResponseEdits: (value) => {
        state.allowEdits = value === true;
        return form;
      },
      setAcceptingResponses: (value) => {
        state.accepting = value === true && (!publishStage || state.published);
        return form;
      },
      isAcceptingResponses: () => state.accepting,
      setShowLinkToRespondAgain: (value) => {
        state.showLink = value === true;
        return form;
      },
      addMultipleChoiceItem: add_("MULTIPLE_CHOICE"),
      addCheckboxItem: add_("CHECKBOX"),
      addScaleItem: add_("SCALE"),
      addParagraphTextItem: add_("PARAGRAPH_TEXT"),
      getItems: () => {
        const list = state.items.map(wrapItem_);
        if (opts.onGetItems) opts.onGetItems(state);
        return list;
      },
      getItemById: (id) => {
        const item = state.items.find((one) => String(one.id) === String(id));
        return item ? wrapItem_(item) : null;
      },
      deleteItem: (wrapped) => {
        genericOnly_(wrapped, "deleteItem", "");
        const item = find_(wrapped.getId());
        state.items.splice(state.items.indexOf(item), 1);
        // 回答シートの列とこれまでの回答は残る
        delete state.columns[item.id];
      },
      moveItem: (wrapped, index) => {
        genericOnly_(wrapped, "moveItem", ",number");
        const item = find_(wrapped.getId());
        state.items.splice(state.items.indexOf(item), 1);
        state.items.splice(index, 0, item);
        return wrapped;
      },
      getEditUrl: () => "https://docs.google.com/forms/d/" + state.id + "/edit",
      getPublishedUrl: () => "https://docs.google.com/forms/d/e/" + state.id + "/viewform",
      shortenFormUrl: (url) => {
        if (opts.shortenFails) throw new Error("Could not shorten " + url);
        return "https://forms.gle/" + state.id.toLowerCase();
      },
      getResponses: () => new Array(state.responses).fill({}),
      getDestinationId: () => {
        if (state.destination === "") throw new Error("The form currently has no response destination.");
        return state.destination;
      },
      setDestination: (type, id) => {
        need(FORMS, "Form.setDestination");
        need(DESTINATION_SCOPE, "Form.setDestination");
        if (type !== "SPREADSHEET") throw new Error("Invalid destination type");
        if (id !== "SHEETID") throw new Error("No spreadsheet with id " + id);
        let n = 1;
        while (Object.prototype.hasOwnProperty.call(sheets, "フォームの回答 " + n)) n += 1;
        state.destination = id;
        state.sheetName = "フォームの回答 " + n;
        const header = [opts.timestampHeader || "タイムスタンプ"];
        state.columns = {};
        for (const item of state.items) {
          state.columns[item.id] = header.length;
          header.push(item.title);
        }
        addSheet_(state.sheetName, [header], {
          raw: true,
          formUrl: () => {
            if (formUrlDelay > 0) {
              formUrlDelay -= 1;
              return null;
            }
            return form.getEditUrl();
          },
        });
        return form;
      },
    };
    if (opts.formsHavePublish !== false) {
      form.setPublished = (value) => {
        if (opts.publishThrows) throw new Error("Unexpected error while getting the method or property setPublished on object FormApp.Form.");
        state.published = value === true;
        return form;
      };
      form.isPublished = () => state.published;
    }
    forms[state.id] = form;
    return form;
  };
  for (const spec of opts.forms || []) makeForm_(spec.title || "既存のフォーム", spec);

  const services = {
    SpreadsheetApp: {
      getActiveSpreadsheet: () => {
        need(SHEETS, "SpreadsheetApp.getActiveSpreadsheet");
        return book;
      },
      flush: () => {},
      getUi: () => {
        trace.getUiCalls += 1;
        if (opts.fromTrigger) throw new Error("Cannot call SpreadsheetApp.getUi() from this context.");
        need(UI, "SpreadsheetApp.getUi");
        return ui;
      },
    },
    UrlFetchApp: {
      fetch: (url, fetchOptions) => {
        need(FETCH, "UrlFetchApp.fetch");
        trace.fetched.push({ url: url, payload: fetchOptions.payload, headers: fetchOptions.headers || {}, muted: fetchOptions.muteHttpExceptions === true });
        let status = 200;
        let body = "ok";
        if (url.indexOf("api.anthropic.com") >= 0) {
          claudeCalls += 1;
          if (opts.claudeThrows) throw new Error("Timeout: " + url);
          if (opts.killAtCall === claudeCalls) {
            killed = true;
            throw new KillError("Exceeded maximum execution time");
          }
          // 答えが返るまでの時間。6 分を越えたら、答えを受け取る前に強制終了（払った分の答えは届かない）
          tick_(opts.claudeMs || 0);
          const request = JSON.parse(fetchOptions.payload);
          trace.claudeBodies.push(request);
          const reply = opts.claudeReply ? opts.claudeReply(request, claudeCalls) : answerAll(request);
          status = reply.status || 200;
          body =
            status === 200
              ? JSON.stringify({ content: [{ type: "text", text: reply.text }], usage: { input_tokens: 3000, output_tokens: 2500, cache_read_input_tokens: 900, cache_creation_input_tokens: 0 }, stop_reason: reply.stop_reason || "end_turn" })
              : reply.body || JSON.stringify({ type: "error", error: { type: "overloaded_error", message: "Overloaded" } });
        } else if (opts.notifyStatus) {
          status = opts.notifyStatus;
          body = "error";
        }
        // 本物は muteHttpExceptions が無いと、4xx/5xx を例外にする
        if (status >= 400 && fetchOptions.muteHttpExceptions !== true) throw new Error("Request failed for " + url + " returned code " + status);
        return { getResponseCode: () => status, getContentText: () => body };
      },
    },
    MailApp: {
      getRemainingDailyQuota: () => {
        need(MAIL, "MailApp.getRemainingDailyQuota");
        return opts.mailQuota === undefined ? 100 : opts.mailQuota;
      },
      sendEmail: (message) => {
        need(MAIL, "MailApp.sendEmail");
        trace.mails.push(message);
      },
    },
    PropertiesService: {
      getScriptProperties: () => ({
        getProperty: (key) => (Object.prototype.hasOwnProperty.call(props, key) ? props[key] : null),
        setProperty: (key, value) => {
          // 本物は文字列にして保存する。1 つ 9KB まで
          const text = String(value);
          if (Buffer.byteLength(key + text, "utf8") > PROPERTY_VALUE_LIMIT) throw new Error("Argument too large: value");
          props[key] = text;
        },
        deleteProperty: (key) => {
          delete props[key];
        },
      }),
    },
    LockService: {
      getScriptLock: () => ({
        waitLock: () => {
          // 本物の waitLock は取れないと例外を投げる（tryLock と違う）
          if (opts.lockBusy) throw new Error("Could not acquire lock");
          lockHeld = true;
        },
        releaseLock: () => {
          lockHeld = false;
        },
      }),
    },
    ScriptApp: {
      WeekDay: { MONDAY: "MONDAY", TUESDAY: "TUESDAY", WEDNESDAY: "WEDNESDAY", THURSDAY: "THURSDAY", FRIDAY: "FRIDAY", SATURDAY: "SATURDAY", SUNDAY: "SUNDAY" },
      getProjectTriggers: () => {
        need(TRIGGERS, "ScriptApp.getProjectTriggers");
        // 本物は、実行している人が入れたトリガーしか返さない
        return triggers.filter((t) => t.owner === user).map(wrapTrigger_);
      },
      deleteTrigger: (wrapped) => {
        need(TRIGGERS, "ScriptApp.deleteTrigger");
        const i = triggers.indexOf(wrapped.__t);
        if (i >= 0) triggers.splice(i, 1);
      },
      newTrigger: (handler) => {
        need(TRIGGERS, "ScriptApp.newTrigger");
        const built = { owner: user, handler: String(handler), weekDay: null, hour: null, timeZone: null };
        const builder = {
          onWeekDay: (day) => {
            built.weekDay = day;
            return builder;
          },
          atHour: (hour) => {
            if (!(hour >= 0 && hour <= 23)) throw new Error("The value passed to atHour must be between 0 and 23.");
            built.hour = hour;
            return builder;
          },
          inTimezone: (zone) => {
            built.timeZone = zone;
            return builder;
          },
          create: () => {
            triggers.push(built);
            return wrapTrigger_(built);
          },
        };
        return { timeBased: () => builder };
      },
    },
    FormApp: {
      ItemType: ItemType,
      DestinationType: { SPREADSHEET: "SPREADSHEET" },
      create: (title) => {
        need(FORMS, "FormApp.create");
        return makeForm_(title);
      },
      openById: (id) => {
        need(FORMS, "FormApp.openById");
        const form = Object.prototype.hasOwnProperty.call(forms, id) ? forms[id] : null;
        if (form === null || form.__state.deleted) throw new Error("No item with the given ID could be found, or you do not have permission to access it.");
        return form;
      },
    },
    Session: {
      getEffectiveUser: () => ({
        getEmail: () => {
          need(EMAIL, "Session.getEffectiveUser().getEmail");
          return user;
        },
      }),
    },
    Utilities: { sleep: (ms) => tick_(ms) },
    Logger: { log: (t) => trace.logs.push(String(t)) },
  };

  // GAS の呼び出しはすべて、強制終了のあとは例外にする（返ってきたシート・範囲・フォームなどの関数も同じ）
  const proxies = new WeakMap();
  const targets = new WeakMap();
  const unwrap_ = (value) => (value !== null && typeof value === "object" && targets.has(value) ? targets.get(value) : value);
  const guard_ = (value) => {
    if (value === null || typeof value !== "object" || value instanceof Date) return value;
    if (Array.isArray(value)) return value.map(guard_);
    if (targets.has(value)) return value;
    if (proxies.has(value)) return proxies.get(value);
    const proxy = new Proxy(value, {
      get: (target, prop) => {
        const member = target[prop];
        if (typeof member !== "function") return guard_(member);
        return (...args) => {
          alive_();
          return guard_(member.apply(target, args.map(unwrap_)));
        };
      },
    });
    proxies.set(value, proxy);
    targets.set(proxy, value);
    return proxy;
  };
  const sandbox = { Date: SandboxDate };
  for (const name of Object.keys(services)) sandbox[name] = guard_(services[name]);

  /** 入口の 1 回（1 回の実行）。強制終了されたら何も返さずに終わる（本物も、呼んだ側には何も返らない） */
  const execute_ = (action) => {
    executionStart = clock;
    killed = false;
    lockHeld = false;
    try {
      return action();
    } catch (error) {
      if (error instanceof KillError || killed) {
        trace.kills += 1;
        return undefined;
      }
      throw error;
    }
  };
  return { sandbox: sandbox, sheets: sheets, order: order, props: props, trace: trace, triggers: triggers, menu: menu, forms: forms, execute: execute_, now: () => clock };
}

/** Claude の既定の答え: 受け取った id すべてに「接客・良い」 */
export function answerAll(request, over) {
  const text = request.messages[0].content[0].text;
  const ids = Array.from(text.matchAll(/<回答 id="(r\d+)"/g)).map((m) => m[1]);
  return { text: JSON.stringify({ results: ids.map((id) => Object.assign({ id: id, category: "接客", sentiment: "良い", request: "", summary: "説明が丁寧", attention: false }, over)) }) };
}

const ENTRY_NAMES = ["onOpen", "initializeSheets", "checkSettings", "loadSamples", "buildForm", "analyzeNow", "buildSummaryNow", "showUsage", "toggleWeekly", "runWeekly", "runDaily"];

/** Code.gs を偽の GAS の上で走らせ、入口の関数を返す */
export function loadBundle(options) {
  const made = createSandbox(options);
  const context = createContext(made.sandbox);
  const exports = ENTRY_NAMES.map((n) => n + ": " + n).join(", ");
  runInContext(buildSource(root) + "\nglobalThis.__entry = { " + exports + " };\n", context);
  const entry = {};
  for (const name of ENTRY_NAMES) entry[name] = (...args) => made.execute(() => made.sandbox.__entry[name](...args));
  return Object.assign({ entry: entry }, made);
}
