import { test } from "node:test";
import assert from "node:assert/strict";
import { CLINIC_DESCRIPTION_NOTE, PRESETS, PRESET_KEYS, presetByNumber, presetHeader } from "../src/presets.js";
import { parseQuestions, questionSheetValues } from "../src/questions.js";
import { CATEGORY_HINTS, CATEGORY_MAX, DEFAULT_FORM_DESCRIPTION } from "../src/config.js";

test("3 つの見本は、それぞれ質問シートにして parseQuestions を問題なしで通る（6 問・メールや名前は聞かない）", () => {
  assert.deepEqual(PRESET_KEYS, ["food", "salon", "clinic"]);
  for (const key of PRESET_KEYS) {
    const parsed = parseQuestions(questionSheetValues(PRESETS[key].questions));
    assert.deepEqual(parsed.problems, [], key);
    assert.deepEqual(parsed.notes, [], key);
    assert.equal(parsed.questions.length, 6, key);
    assert.equal(parsed.questions.filter((q) => q.use === "回答").length, 2, key);
    assert.equal(parsed.questions.filter((q) => q.use === "評価").length, 1, key);
  }
  assert.equal(PRESETS.clinic.description, DEFAULT_FORM_DESCRIPTION + CLINIC_DESCRIPTION_NOTE);
  assert.equal(PRESETS.clinic.formTitle, "{店名} ご来院アンケート");
});

test("分類は 12 個以下で「その他」で終わり、どの分類にも目安がある", () => {
  for (const key of PRESET_KEYS) {
    const categories = PRESETS[key].categories;
    assert.ok(categories.length <= CATEGORY_MAX, key);
    assert.equal(categories[categories.length - 1], "その他", key);
    for (const name of categories) assert.ok(Object.prototype.hasOwnProperty.call(CATEGORY_HINTS, name), key + ": " + name + " の目安");
  }
});

test("番号で選ぶ（全角も読む）。見本の回答シートの見出しは「タイムスタンプ」+ 見本の質問文", () => {
  assert.equal(presetByNumber("1").key, "food");
  assert.equal(presetByNumber(" ２ ").key, "salon");
  assert.equal(presetByNumber("3").key, "clinic");
  assert.equal(presetByNumber("4"), null);
  assert.equal(presetByNumber("飲食"), null);
  for (const key of PRESET_KEYS) assert.deepEqual(presetHeader(PRESETS[key]), ["タイムスタンプ"].concat(PRESETS[key].questions.map((q) => q.title)));
  assert.deepEqual(presetHeader(PRESETS.salon).slice(0, 3), ["タイムスタンプ", "今回のご満足度（1〜5）", "ご利用の店舗"]);
});
