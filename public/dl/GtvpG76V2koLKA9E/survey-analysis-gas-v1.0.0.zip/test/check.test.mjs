import { test } from "node:test";
import assert from "node:assert/strict";
import { KEY_PROMPT_TEXT, answerState, apiKeyProblem, apiKeyTail, checkNotes, collectConfigProblems, findProblems, needsKeyPrompt, planInit, sheetNamesFor, summaryLines } from "../src/check.js";
import { DEFAULT_ROWS, readConfigRows } from "../src/config.js";
import { HEADERS } from "../src/rows.js";
import { QUESTION_HEADERS, questionSheetValues, questionsHash } from "../src/questions.js";
import { PRESETS } from "../src/presets.js";
import { sampleSettingRows, sampleValues } from "../src/samples.js";
import { emptyUsage } from "../src/usage.js";

const TODAY = "2026-10-04";

function snapshotOf(sheets, over) {
  return Object.assign({ timeZone: "Asia/Tokyo", today: TODAY, sheetNames: Object.keys(sheets), sheets: sheets, hasTrigger: true, apiKeyTail: "a1B2", keyRejected: false, usage: emptyUsage() }, over);
}

/** planInit の結果を snapshot に当てる（gas_sheets.js の applyInit_ と同じ足し方） */
function applyPlan(snapshot, plan) {
  const sheets = {};
  for (const name of Object.keys(snapshot.sheets)) sheets[name] = snapshot.sheets[name].map((row) => row.slice());
  const names = snapshot.sheetNames.slice();
  if (plan.appendSettings.rows.length > 0) sheets[plan.appendSettings.sheet] = sheets[plan.appendSettings.sheet].concat(plan.appendSettings.rows);
  for (const made of plan.createSheets) {
    sheets[made.name] = made.rows.map((row) => row.slice());
    if (names.indexOf(made.name) < 0) names.push(made.name);
  }
  for (const entry of plan.appendHeaders) sheets[entry.sheet][0] = sheets[entry.sheet][0].concat(entry.names);
  return Object.assign({}, snapshot, { sheets: sheets, sheetNames: names });
}

/** 見本の回答を「フォームの回答 1」に置いた、設定済みのブック */
function formBook(settingsRows, over) {
  return snapshotOf(
    {
      "フォームの回答 1": sampleValues("salon", TODAY),
      設定: [["項目", "値"]].concat(DEFAULT_ROWS, settingsRows || []),
      分析結果: [HEADERS.slice()],
    },
    over,
  );
}

test("空のブック: 設定（既定の全行）・分析結果（見出し 14 列）・質問（見出し 8 列）を作る。当てたあとにもう一度 → 足すものは無い", () => {
  const empty = snapshotOf({ シート1: [] }, { apiKeyTail: "" });
  const plan = planInit(empty);
  assert.deepEqual(plan.createSheets, [
    { name: "設定", rows: [["項目", "値"]].concat(DEFAULT_ROWS), freeze: true, exists: false },
    { name: "分析結果", rows: [HEADERS], freeze: true, exists: false },
    { name: "質問", rows: [QUESTION_HEADERS], freeze: true, exists: false },
  ]);
  assert.deepEqual(plan.appendHeaders, []);
  assert.deepEqual(plan.appendSettings.rows, []);
  assert.deepEqual(plan.notes, ["「シート1」シートに見出しがありません。1 行目に質問の見出しがあるシートを、設定「回答シート」に書いてください。"]);
  assert.equal(plan.nextStep, "続けて、API キーを貼る欄を出します。");
  const again = planInit(applyPlan(empty, plan));
  assert.deepEqual([again.createSheets, again.appendHeaders, again.appendSettings.rows], [[], [], []]);
  assert.equal(planInit(Object.assign(applyPlan(empty, plan), { apiKeyTail: "a1B2" })).nextStep, "次は「設定を確かめる」を実行してください。");
  assert.equal(needsKeyPrompt(empty), true);
});

test("設定だけある・分析結果と質問の見出しが足りない: 足りない行と列だけ。空の分析結果シートは見出しを書く", () => {
  const book = snapshotOf({ "フォームの回答 1": sampleValues("salon", TODAY), 設定: [["項目", "値"], ["店名", "サロン みなと"], ["まとめの期間(日)", "30"]], 分析結果: [HEADERS.filter((name) => name !== "モデル")], 質問: [QUESTION_HEADERS.slice(0, 7), [1, "ご意見", "自由記述"]] });
  const plan = planInit(book);
  assert.deepEqual(plan.createSheets, []);
  assert.deepEqual(plan.appendHeaders, [{ sheet: "分析結果", names: ["モデル"] }, { sheet: "質問", names: ["項目 ID"] }]);
  assert.deepEqual(plan.appendSettings.rows.map((row) => row[0]), DEFAULT_ROWS.map((row) => row[0]).filter((key) => key !== "店名" && key !== "まとめの期間（日）"));
  assert.deepEqual(plan.notes, []);
  const emptyResults = planInit(snapshotOf({ 設定: [["項目", "値"]].concat(DEFAULT_ROWS), 分析結果: [], 質問: [QUESTION_HEADERS], 回答: [["ご意見"]] }));
  assert.deepEqual(emptyResults.createSheets, [{ name: "分析結果", rows: [HEADERS], freeze: true, exists: true }]);
  const tokyo = planInit(snapshotOf({ 設定: [["項目", "値"]].concat(DEFAULT_ROWS), 分析結果: [HEADERS], 質問: [QUESTION_HEADERS], 回答: [["ご意見"]] }, { timeZone: "America/Los_Angeles" }));
  assert.ok(tokyo.notes[0].startsWith("スプレッドシートのタイムゾーンが America/Los_Angeles です。"));
});

test("直すところは最初の 1 つで止めずに全部集める（URL の値は出さない）", () => {
  const book = formBook([["モデル", "sonnet-5"], ["まとめの送り先", "slack"], ["回答の列", "ご意見"], ["評価の列", "ご利用の店舗"]], { timeZone: "Etc/GMT", apiKeyTail: "" });
  assert.deepEqual(findProblems(book), [
    "スプレッドシートのタイムゾーンが Etc/GMT です。ファイル → 設定 → タイムゾーンを「（GMT+09:00）東京」にしてください（そのままだと日付が 1 日ずれます）。",
    "「設定」シートの「モデル」は claude- で始まる名前にしてください（いまは「sonnet-5」）。例: claude-sonnet-5",
    "「まとめの送り先」に slack がありますが、「Slack Webhook URL」が空です。設定シートのその行を埋めてください。",
    "設定「回答の列」の「ご意見」が、「フォームの回答 1」シートの 1 行目にありません。見出しの名前をそのまま書くか、空にして見出しから推測させてください。",
    "「フォームの回答 1」シートの評価の列「ご利用の店舗」は、半分以上の行が数（0〜5）として読めません。数の入った列の見出しを設定「評価の列」に書くか、使わないときは「なし」と書いてください（0〜10 の評価なら、設定「評価の最大」を 10 にしてください）。",
    "API キーが入っていません。メニュー「初期化」を押すと、キーを貼る欄が出ます。",
  ]);
  assert.deepEqual(findProblems(snapshotOf({ シート1: [] })), ["「設定」シートがありません。メニュー「お客さまアンケート」→「初期化」を実行してください。"]);
  assert.deepEqual(collectConfigProblems([["評価の最大", "3"]]), ["「設定」シートの「評価の最大」は 5 か 10 にしてください（いまは「3」）。"]);
  assert.deepEqual(findProblems(formBook()), [], "見本をフォームの回答として置いた設定済みのブックは 0 件");
});

test("401 のあとは、直すところに出て、初期化でキーを貼る欄が出る。キーの形の確かめ", () => {
  const book = formBook([], { keyRejected: true });
  assert.deepEqual(findProblems(book), ["前回、API キーが受け付けられませんでした（401）。メニュー「初期化」を押すと、キーを貼り直す欄が出ます。"]);
  assert.equal(needsKeyPrompt(book), true);
  assert.equal(needsKeyPrompt(formBook()), false);
  assert.equal(apiKeyProblem("sk-ant-api03-" + "x".repeat(20)), "");
  assert.equal(apiKeyProblem("  sk-ant-api03-" + "x".repeat(20) + "  "), "", "前後の空白は落として見る");
  for (const wrong of ["", "sk-ant-short", "sk-proj-" + "x".repeat(30), "sk-ant-api03 xxxxxxxxxxxxxxxx"]) {
    assert.equal(apiKeyProblem(wrong), "キーの形が違うようです。sk-ant- で始まる文字をそのまま貼ってください。", wrong);
  }
  assert.equal(apiKeyTail("sk-ant-api03-abcdWXYZ"), "WXYZ");
  assert.ok(KEY_PROMPT_TEXT.includes("シートには書きません"));
});

test("ご参考: 足りない設定の行・分類を変える前の行・未分析・見本をキーなしで・自動実行なし", () => {
  const results = [HEADERS.slice(), ["k1", 2, "2026-10-01", 4, "", "", "仕上がり", "良い", "", "", "", false, "", "m"], ["k2", 3, "2026-10-01", 4, "", "", "（回答なし）", "ふつう", "", "", "", false, "", "m"]];
  const book = snapshotOf({ 見本の回答: sampleValues("salon", TODAY), 設定: [["項目", "値"], ["店名", "サロン みなと"]].concat(sampleSettingRows("salon")), 分析結果: results }, { apiKeyTail: "", hasTrigger: false });
  const notes = checkNotes(book);
  assert.ok(notes[0].startsWith("「設定」シートに「業種」「フォームのタイトル」「フォームの説明」"));
  assert.ok(notes[0].endsWith("の行がありません。既定値で動きます。「初期化」を実行すると、既定値の行を足します。"));
  assert.deepEqual(notes.slice(1), [
    "分類を変える前に分析した行が 1 件あります。そろえるときは、その行の「やり直す」に ✓ を入れて「分析する」を押してください。",
    "まだ分析していない回答が 30 件あります。「分析する」を押すと分析します。",
    "API キーが入っていないので、見本の回答は同梱の答えで分析とまとめを再生します。ご自身の回答を分析する前に、「初期化」でキーを貼ってください。",
    "毎週月曜 8 時の自動実行は入っていません。使うときはメニュー「毎週送る（入れる / 外す）」を押してください。",
  ]);
  assert.equal(findProblems(book).some((line) => line.indexOf("API キーが入っていません") >= 0), false, "見本だけならキーなしは誤りにしない");
});

test("問題が無いときの要約: 読むシートと列、件数、分類、モデル、伏せ字、まとめ、キーの末尾、今月の目安", () => {
  const book = formBook([], { usage: { count: 3, input: 100000, output: 40000, cacheRead: 70000, cacheWrite: 700 } });
  assert.deepEqual(sheetNamesFor(book.sheets["設定"], book.sheetNames), ["フォームの回答 1"]);
  assert.equal(answerState(book, readConfigRows(book.sheets["設定"]).config).pending.length, 30);
  assert.deepEqual(summaryLines(book), [
    "読む回答シート: 「フォームの回答 1」",
    "回答の列: 良かった点・気になった点を自由にお書きください・ご要望があればお書きください（任意）（見出しから推測）",
    "日付の列: タイムスタンプ｜評価の列: 今回のご満足度（1〜5）（5 段階）｜店舗の列: ご利用の店舗",
    "回答: 30 件（分析済み 0 件、残り 30 件）",
    "分類: 接客・待ち時間・価格・品質・清潔さ・予約・手続き・その他",
    "モデル: claude-sonnet-5（1 回 20 件、1 日 500 件まで）",
    "伏せ字: メールアドレスと電話番号を〔メール〕〔電話〕に替えてから送ります",
    "まとめ: 直近 7 日、送り先: なし（シートだけ）",
    "API キー: 入っています（末尾 …a1B2）。入れ替えるときは、Apps Script のプロジェクトの設定 → スクリプト プロパティで書き換えてください。",
    "今月の AI 利用の目安: 93 円（Anthropic Console の使用量が正です）",
  ]);
});

test("質問シートとフォーム: 質問の問題・開けないフォーム・受け付けていないフォームは直すところ。見出しだけの質問シートは見ない", () => {
  const broken = questionSheetValues(PRESETS.salon.questions);
  broken[2][3] = "駅前店";
  const book = formBook([["フォーム ID", "1FORM"], ["フォームの URL", "https://forms.gle/abc"]], { form: { state: "missing", accepting: true, items: [], responses: 0 } });
  book.sheets["質問"] = broken;
  const problems = findProblems(book);
  assert.deepEqual(problems.slice(0, 2), [
    "質問シートの 3 行目: 種類が「選択」ですが、選択肢が 1 つしかありません。セル内で改行して 2 つ以上書いてください。",
    "設定の「フォーム ID」のフォームを開けませんでした（消したか、ゴミ箱にあるか、このアカウントに権限がありません）。「フォームを作る」を押すと、確認のうえ新しく作ります。",
  ]);
  assert.deepEqual(findProblems(Object.assign(formBook(), { form: { state: "elsewhere", accepting: true, items: [], responses: 0 } })), ["設定の「フォーム ID」のフォームは、ほかのスプレッドシートにつながっています。「フォームを作る」を押すと、確認のうえこのスプレッドシート用に新しく作ります。"]);
  assert.deepEqual(findProblems(Object.assign(formBook(), { form: { state: "ok", accepting: false, items: [], responses: 3 } })), ["フォームが回答を受け付けていません。フォームの編集画面の「回答」タブで「回答を受付中」をオンにしてください。"]);
  const headerOnly = formBook();
  headerOnly.sheets["質問"] = [QUESTION_HEADERS.slice()];
  assert.deepEqual(findProblems(headerOnly), [], "見出しだけの質問シートは、フォームを使わない人として検査しない");
});

test("ご参考: 質問シートを直したのにフォームに反映していない・フォームにだけある質問・名前を聞く質問。要約の先頭にフォームの URL と回答の数", () => {
  const values = questionSheetValues(PRESETS.salon.questions);
  values.push([7, "お名前（任意）", "自由記述", "", "いいえ", "", "", ""]);
  values[1][7] = "101";
  const book = formBook([["フォーム ID", "1FORM"], ["フォームの URL", "https://forms.gle/abc"]], {
    form: { state: "ok", accepting: true, items: [{ id: 101, title: "今回のご満足度（1〜5）", kind: "SCALE" }, { id: 999, title: "ご来店のきっかけ", kind: "MULTIPLE_CHOICE" }], responses: 30 },
    formSourceHash: "k00000000",
  });
  book.sheets["質問"] = values;
  const notes = checkNotes(book);
  assert.deepEqual(notes.slice(0, 3), [
    "質問シートが、最後にフォームを作ったときから変わっています。反映するには「フォームを作る」を押してください。",
    "フォームにだけ残っている質問があります: 「ご来店のきっかけ」。フォームからも消すときは、設定「質問を減らしても消す」を はい にして「フォームを作る」を押してください。",
    "質問シートの 8 行目「お名前（任意）」: 名前や連絡先を聞く質問は、分析には使いません（Claude に送りません）。アンケートに要らなければ消してください。",
  ]);
  book.formSourceHash = questionsHash(values);
  assert.equal(checkNotes(book).some((line) => line.startsWith("質問シートが、最後に")), false, "同じ指紋なら出さない");
  const lines = summaryLines(Object.assign(book, { sheets: Object.assign({}, book.sheets, { 質問: [QUESTION_HEADERS] }) }));
  assert.equal(lines[0], "フォーム: https://forms.gle/abc（回答 30 件）");
  assert.ok(lines[2].endsWith("（質問シートから）"));
});
