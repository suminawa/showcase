import { test } from "node:test";
import assert from "node:assert/strict";
import { EMPTY_TABLE_TEXT, SUMMARY_FOOTNOTES, SUMMARY_WIDTH, overallLine, rowLink, summaryBlocks } from "../src/summary_sheet.js";
import { aggregate } from "../src/summary.js";
import { quietSummary } from "../src/summary_prompt.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const config = Object.assign({}, DEFAULT_CONFIG);
let row = 1;
function record(over) {
  row += 1;
  return Object.assign({ row: row, key: "k" + row, date: "2026-10-03", rating: 4, store: "駅前店", excerpt: "", category: "接客", sentiment: "良い", request: "", summary: "説明が丁寧", attention: false }, over);
}
const META = { storeName: "サロン みなと", stamp: "2026-10-04 21:10", model: "claude-sonnet-5", gid: 777 };
const SUMMARY = {
  themes: [{ title: "待ち時間の目安の案内", ids: ["q1"], count: 1, example: "30分待った" }],
  actions: [{ text: "受付で待ち時間の目安をお伝えしてみてください。", basis: "待ち時間の悪い 1 件" }],
  themesNote: "",
  actionsNote: "",
};

function firstColumn(blocks) {
  return blocks.values.map((line) => line[0]);
}

test("ブロックの順: 見出し → 期間 → 今週の 3 つ → 全体 → 分類ごと → 多い要望 → 店舗ごと → すぐに読んでほしい回答 → ご参考", () => {
  const agg = aggregate([record({ category: "待ち時間", sentiment: "悪い", request: "待ち時間の目安の案内", summary: "30分待った", attention: true, row: 12 }), record({ store: "本町店" })], config, "2026-10-04");
  const blocks = summaryBlocks(agg, SUMMARY, META);
  const first = firstColumn(blocks);
  const order = ["サロン みなと お客さまの声のまとめ", "今週の 3 つ", "全体", "分類ごと", "多い要望（上位 10）", "店舗ごと", "すぐに読んでほしい回答", SUMMARY_FOOTNOTES[0]];
  let last = -1;
  for (const name of order) {
    const at = first.indexOf(name);
    assert.ok(at > last, name + " の位置");
    last = at;
  }
  assert.equal(blocks.values[1][0], "期間 2026-09-28〜2026-10-04｜回答 2 件（回答なし 0 件）｜作成 2026-10-04 21:10｜claude-sonnet-5");
  assert.deepEqual(blocks.values[first.indexOf("今週の 3 つ") + 1].slice(0, 2), ["1. 受付で待ち時間の目安をお伝えしてみてください。", "根拠: 待ち時間の悪い 1 件"]);
  assert.equal(first[first.length - 1], "このシートは「まとめを作る」のたびに作り直します。メモは別のシートにお書きください。");
  for (const line of blocks.values) assert.equal(line.length, SUMMARY_WIDTH);
  assert.ok(blocks.headerRows.indexOf(first.indexOf("分類") ) >= 0, "表の見出しは灰色");
  assert.ok(blocks.boldRows.indexOf(0) >= 0);
});

test("空の表は見出しを出さず「この期間はありません」の 1 行。今週の 3 つは note を出す", () => {
  const blocks = summaryBlocks(aggregate([], config, "2026-10-04"), quietSummary(), META);
  const first = firstColumn(blocks);
  assert.equal(first[first.indexOf("分類ごと") + 1], EMPTY_TABLE_TEXT);
  assert.equal(first[first.indexOf("多い要望（上位 10）") + 1], EMPTY_TABLE_TEXT);
  assert.equal(first[first.indexOf("すぐに読んでほしい回答") + 1], EMPTY_TABLE_TEXT);
  assert.equal(first[first.indexOf("今週の 3 つ") + 1], "この期間は、改善を求める声はありませんでした。");
  assert.equal(blocks.values[first.indexOf("全体")][1], EMPTY_TABLE_TEXT);
  assert.equal(first.indexOf("分類"), -1);
});

test("店舗の列・評価の列が無ければ、店舗の表と評価の平均の列を出さない", () => {
  const agg = aggregate([record({ store: "", rating: "" })], config, "2026-10-04");
  const blocks = summaryBlocks(agg, SUMMARY, META);
  const first = firstColumn(blocks);
  assert.equal(first.indexOf("店舗ごと"), -1);
  assert.deepEqual(blocks.values[first.indexOf("分類")].slice(0, 7), ["分類", "件数", "良い", "ふつう", "悪い", "悪いの割合", ""]);
  assert.equal(overallLine(agg), "件数 1 ｜ 良い 1 ｜ ふつう 0 ｜ 悪い 0（0%）");
});

test("悪いの割合が前の期間より 10 ポイント以上高いセルは薄い赤。行のリンクは HYPERLINK の式", () => {
  const records = [
    record({ category: "待ち時間", sentiment: "悪い", date: "2026-10-03" }),
    record({ category: "待ち時間", sentiment: "良い", date: "2026-10-03" }),
    record({ category: "待ち時間", sentiment: "良い", date: "2026-09-25" }),
    record({ category: "接客", sentiment: "悪い", date: "2026-09-25", attention: true, row: 30 }),
    record({ category: "接客", sentiment: "悪い", date: "2026-10-02", attention: true, row: 12 }),
  ];
  const agg = aggregate(records, config, "2026-10-04");
  const blocks = summaryBlocks(agg, SUMMARY, META);
  const first = firstColumn(blocks);
  const waitAt = first.indexOf("待ち時間");
  assert.deepEqual(blocks.values[waitAt].slice(0, 7), ["待ち時間", 2, 1, 0, 1, "50%", 4]);
  assert.ok(blocks.redCells.some((cell) => cell[0] === waitAt && cell[1] === 5), "待ち時間は 0% → 50%");
  const overallAt = first.indexOf("全体");
  assert.equal(blocks.values[overallAt][1], "件数 3 ｜ 良い 1 ｜ ふつう 0 ｜ 悪い 2（67%。前の期間 50%）｜ 評価の平均 4（前の期間 4）");
  assert.ok(blocks.redCells.some((cell) => cell[0] === overallAt && cell[1] === 1));
  assert.equal(rowLink(777, 12), '=HYPERLINK("#gid=777&range=A12","行 12")');
  const attentionAt = first.indexOf("日付");
  assert.deepEqual(blocks.values[attentionAt + 1].slice(0, 4), ["2026-10-02", "接客", "説明が丁寧", '=HYPERLINK("#gid=777&range=A12","行 12")']);
});
