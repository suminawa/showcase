import { test } from "node:test";
import assert from "node:assert/strict";
import { formReport, formTexts, kindOf, overwrittenRows, planForm, questionProblemsText, removeConfirmText, writebackFor } from "../src/form_plan.js";
import { QUESTION_HEADERS, parseQuestions } from "../src/questions.js";
import { DEFAULT_CONFIG } from "../src/config.js";

function questionsOf(rows) {
  return parseQuestions([QUESTION_HEADERS.slice()].concat(rows)).questions;
}

const ROWS = [
  [1, "満足度", "5 段階", "", "はい", "", "", "101"],
  [2, "ご利用の店舗", "選択", "駅前店\n本町店", "", "", "", "102"],
  [3, "ご感想", "自由記述", "", "", "", "", ""],
];

test("空のフォーム → 全部 create（並びの順）。質問の種類とフォームの型の対応", () => {
  const plan = planForm([], questionsOf(ROWS), { removeDeleted: false });
  assert.deepEqual(plan.items.map((item) => [item.action, item.question.title, item.itemId]), [["create", "満足度", ""], ["create", "ご利用の店舗", ""], ["create", "ご感想", ""]]);
  assert.deepEqual(plan.counts, { create: 3, update: 0, recreate: 0, keep: 0, remove: 0 });
  assert.equal(kindOf("はい・いいえ"), "MULTIPLE_CHOICE");
  assert.equal(kindOf("複数"), "CHECKBOX");
  assert.equal(kindOf("5 段階"), "SCALE");
  assert.equal(kindOf("自由記述"), "PARAGRAPH_TEXT");
});

test("項目 ID が合い種類が同じ → update、種類が違う → recreate、ID が無い・フォームに無い → create", () => {
  const existing = [
    { id: 101, title: "満足度", kind: "SCALE" },
    { id: 102, title: "ご利用の店舗", kind: "CHECKBOX" },
  ];
  const rows = ROWS.map((row) => row.slice());
  rows[2][7] = "999";
  const plan = planForm(existing, questionsOf(rows), { removeDeleted: false });
  assert.deepEqual(plan.items.map((item) => [item.action, item.itemId]), [["update", "101"], ["recreate", "102"], ["create", ""]]);
  assert.deepEqual(plan.counts, { create: 1, update: 1, recreate: 1, keep: 0, remove: 0 });
});

test("フォームにだけある質問は、既定で keep、「質問を減らしても消す」が はい なら remove", () => {
  const existing = [
    { id: 101, title: "満足度", kind: "SCALE" },
    { id: 102, title: "ご利用の店舗", kind: "MULTIPLE_CHOICE" },
    { id: 103, title: "ご来店のきっかけ", kind: "MULTIPLE_CHOICE" },
  ];
  const kept = planForm(existing, questionsOf(ROWS), { removeDeleted: false });
  assert.deepEqual(kept.keep, [{ id: "103", title: "ご来店のきっかけ" }]);
  assert.deepEqual(kept.remove, []);
  const removed = planForm(existing, questionsOf(ROWS), { removeDeleted: true });
  assert.deepEqual(removed.remove, [{ id: "103", title: "ご来店のきっかけ" }]);
  assert.deepEqual(removed.counts, { create: 1, update: 2, recreate: 0, keep: 0, remove: 1 });
});

test("同じ項目 ID が 2 行にあれば、2 行目は新しく作る（1 つの質問に 2 行を当てない）", () => {
  const rows = ROWS.map((row) => row.slice());
  rows[1][7] = "101";
  rows[1][2] = "5 段階";
  rows[1][3] = "";
  const plan = planForm([{ id: 101, title: "満足度", kind: "SCALE" }], questionsOf(rows), { removeDeleted: false });
  assert.deepEqual(plan.items.map((item) => item.action), ["update", "create", "create"]);
});

test("writebackFor は 回答シート・回答・日付・評価・店舗（無ければ「なし」）・URL・ID を返す。上書きした行を拾う", () => {
  const pairs = writebackFor(questionsOf(ROWS), "フォームの回答 1", { url: "https://forms.gle/abc", editUrl: "https://docs.google.com/forms/d/F1/edit", id: "F1" });
  assert.deepEqual(pairs, [
    ["回答シート", "フォームの回答 1"],
    ["回答の列", "ご感想"],
    ["日付の列", "タイムスタンプ"],
    ["評価の列", "満足度"],
    ["評価の最大", "5"],
    ["店舗の列", "ご利用の店舗"],
    ["フォームの URL", "https://forms.gle/abc"],
    ["フォームの編集 URL", "https://docs.google.com/forms/d/F1/edit"],
    ["フォーム ID", "F1"],
  ]);
  // 日付の列は、見つけた回答シートの 1 列目の見出し（英語の画面のアカウントなら Timestamp）。分からなければ「タイムスタンプ」
  assert.deepEqual(writebackFor(questionsOf(ROWS), "Form Responses 1", { url: "u", editUrl: "e", id: 1 }, "Timestamp").find((pair) => pair[0] === "日付の列"), ["日付の列", "Timestamp"]);
  assert.deepEqual(writebackFor(questionsOf(ROWS), "フォームの回答 1", { url: "u", editUrl: "e", id: 1 }, "").find((pair) => pair[0] === "日付の列"), ["日付の列", "タイムスタンプ"]);
  const noStore = writebackFor(questionsOf([[1, "ご感想", "自由記述", "", "", "", "", ""]]), "フォームの回答 1", { url: "u", editUrl: "e", id: 1 });
  assert.deepEqual(noStore.filter((pair) => pair[1] === "なし").map((pair) => pair[0]), ["評価の列", "店舗の列"]);
  const old = [["回答シート", "口コミ"], ["回答の列", ""], ["日付の列", "タイムスタンプ"], ["評価の列", ""], ["評価の最大", 5], ["店舗の列", ""], ["フォームの URL", "https://forms.gle/old"], ["フォームの編集 URL", ""], ["フォーム ID", "F0"]];
  assert.deepEqual(overwrittenRows(old, pairs), [["回答シート", "口コミ"]], "キットが書く 3 行と、同じ値の行は数えない");
});

test("フォームの題は {店名} を置き換える（空なら「当店」）。説明と送信後の文は設定のまま", () => {
  assert.deepEqual(formTexts(Object.assign({}, DEFAULT_CONFIG, { storeName: "サロン みなと" })), { title: "サロン みなと ご来店アンケート", description: DEFAULT_CONFIG.formDescription, confirmation: DEFAULT_CONFIG.confirmationMessage });
  assert.equal(formTexts(DEFAULT_CONFIG).title, "当店 ご来店アンケート");
  assert.ok(DEFAULT_CONFIG.formDescription.includes("AI を使って集計します"));
  assert.ok(DEFAULT_CONFIG.formDescription.includes("お名前や連絡先を書かないでください"));
});

test("終わりの alert: 作ったとき（設計書 §3-5 の文）と、直したとき（件数と残した質問・作り直し・上書き）", () => {
  const created = formReport({ created: true, counts: { create: 3, update: 0, recreate: 0, keep: 0, remove: 0 }, keep: [], removed: [], url: "https://forms.gle/xxxxxxxx", sheetName: "フォームの回答 1", sheetFound: true, choicesRemoved: false, overwritten: [] });
  assert.equal(
    created,
    [
      "フォームを作りました。",
      "",
      "答える人に渡す URL: https://forms.gle/xxxxxxxx",
      "（設定シートの「フォームの URL」にも書きました）",
      "",
      "QR コードは、この URL を Chrome で開き、アドレスバーの右の［このページを共有］→［QR コードを作成］→［ダウンロード］で作れます（README の手順 5）。",
      "回答は「フォームの回答 1」シートに溜まります。回答が来たら「分析する」を押してください。",
      "フォームを直すときは、「質問」シートを直してから、もう一度「フォームを作る」を押してください（同じフォームが直ります）。",
    ].join("\n"),
  );
  const updated = formReport({ created: false, counts: { create: 1, update: 2, recreate: 1, keep: 1, remove: 0 }, keep: ["ご来店のきっかけ"], removed: [], url: "u", sheetName: "フォームの回答 1", sheetFound: false, choicesRemoved: true, overwritten: [["回答シート", "口コミ"]] }).split("\n");
  assert.equal(updated[0], "フォームを直しました（質問の追加 1・変更 2・作り直し 1・残した質問 1）。");
  assert.ok(updated.includes("フォームはできましたが、回答のシートが見つかりませんでした。スプレッドシートを開き直してから、もう一度「フォームを作る」を押してください（2 つ目のフォームはできません）。"));
  assert.deepEqual(updated.slice(-4), [
    "フォームに残した質問: ご来店のきっかけ（質問シートから消しても、フォームからは消していません）",
    "種類を変えた質問は作り直しました。回答シートには新しい列ができ、古い列とこれまでの回答は残ります。",
    "選択肢を消した質問があります。前の回答はシートに残りますが、フォームの「回答」タブの集計からは見えにくくなります。",
    "設定を書き換えました（前の値: 回答シート「口コミ」）。",
  ]);
  assert.equal(removeConfirmText([{ id: "103", title: "ご来店のきっかけ" }]), "次の質問をフォームから消します。回答シートの列とこれまでの回答は残ります。よろしいですか？\n・ご来店のきっかけ");
  assert.equal(questionProblemsText(["質問シートの 3 行目: …"]), "フォームに触る前に、質問シートの直すところがあります。\n\n・質問シートの 3 行目: …\n\n直したら、もう一度「フォームを作る」を押してください。");
});
