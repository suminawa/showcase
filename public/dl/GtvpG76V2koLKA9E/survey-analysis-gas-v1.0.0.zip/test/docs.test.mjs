import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CONFIG_KEYS, DEFAULT_ROWS } from "../src/config.js";
import { HEADERS } from "../src/rows.js";
import { sampleValues } from "../src/samples.js";
import { QUESTION_HEADERS, questionSheetValues } from "../src/questions.js";
import { PRESETS, PRESET_KEYS } from "../src/presets.js";
import { MANIFEST } from "../scripts/build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

function read(name) {
  return readFileSync(join(root, name), "utf8");
}

/** CSV を行と列に割る（"..." の中のカンマは区切りにしない） */
function rowsOf(csv) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const text = csv.replace(/\r\n/g, "\n").replace(/\n+$/, "");
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  row.push(field);
  rows.push(row);
  return rows;
}

/** README の表（見出し行 head で始まる）の各行を、セルの配列で */
function tableRows(readme, head) {
  const rows = [];
  const lines = readme.split("\n");
  let inside = false;
  for (const line of lines) {
    if (line.indexOf(head) === 0) {
      inside = true;
      continue;
    }
    if (!inside) continue;
    if (line.indexOf("|") !== 0) break;
    if (/^\|\s*-/.test(line)) continue;
    rows.push(line.split("|").slice(1, -1).map((cell) => cell.trim()));
  }
  return rows;
}

function tableKeys(readme, head) {
  return tableRows(readme, head).map((cells) => cells[0]);
}

test("README の設定表は CONFIG_KEYS と同じ 28 項目が同じ順。分析結果の表は HEADERS の 14 列、質問シートの表は QUESTION_HEADERS の 8 列", () => {
  const readme = read("README.ja.md");
  assert.equal(CONFIG_KEYS.length, 28);
  assert.deepEqual(tableKeys(readme, "| 項目 | 既定値 | 意味 |"), CONFIG_KEYS);
  assert.deepEqual(tableKeys(readme, "| 列 | 中身 |"), HEADERS);
  assert.deepEqual(tableKeys(readme, "| 列 | 書き方 |"), QUESTION_HEADERS);
  // 既定値の列は DEFAULT_ROWS と食い違わない（空の既定値は「（空」で始まるか空欄）
  const settingRows = tableRows(readme, "| 項目 | 既定値 | 意味 |");
  for (const [key, value] of DEFAULT_ROWS) {
    const written = settingRows.find((cells) => cells[0] === key)[1];
    if (value === "") assert.ok(written === "" || written.indexOf("（空") === 0 || written === "（キットが書く）", key + ": " + written);
    else assert.equal(written, value, key);
  }
  assert.equal(tableKeys(readme, "| 許可（画面の表示の要旨） | 何に使うか |").length, MANIFEST.oauthScopes.length, "許可の説明は manifest と同じ数");
});

test("samples の CSV は見本と同じ: responses-sample.csv はサロン・美容の回答（2026-10-04 に読み込んだ形）、questions-*.csv は業種の質問シート", () => {
  assert.deepEqual(rowsOf(read("samples/responses-sample.csv")), sampleValues("salon", "2026-10-04").map((row) => row.map(String)));
  for (const key of PRESET_KEYS) {
    assert.deepEqual(rowsOf(read("samples/questions-" + key + ".csv")), questionSheetValues(PRESETS[key].questions).map((row) => row.map(String)), key);
  }
});

test("README・LICENSE・CHANGELOG は敬体で、禁止語・鍵の値・大げさな言葉を含まない", () => {
  for (const name of ["README.ja.md", "LICENSE.md", "CHANGELOG.md"]) {
    const text = read(name);
    assert.equal(/承ります/.test(text), false, name + " に「承ります」");
    assert.equal(/鉋|棟梁|Claude Code/.test(text), false, name + " に内部の呼び名");
    assert.equal(/sk-ant-[A-Za-z0-9]{8,}/.test(text), false, name + " に鍵らしい字");
    assert.equal(/hooks\.slack\.com\/services\/T[0-9A-Z]{4,}/.test(text), false, name + " に本物らしい Webhook URL");
    assert.equal(/業界初|圧倒的|完全に|100%|誰でも簡単/.test(text), false, name + " に大げさな言葉");
    assert.equal(/kintone|キントーン/i.test(text), false, name + " にほかの会社の製品名（比べに使わない）");
    assert.equal(/=IMAGE\(|chart\.googleapis|qrserver/i.test(text), false, name + " に外部の QR サービス");
  }
  const readme = read("README.ja.md");
  assert.ok(readme.includes("hello@suminawa.dev"));
  assert.ok(readme.includes("いただいた回答は、サービス改善のため AI を使って集計します。回答欄には、お名前や連絡先を書かないでください。"));
  assert.ok(readme.includes("「まとめ」シートは「まとめを作る」のたびに作り直します。メモは別のシートにお書きください。"));
  assert.ok(read("CHANGELOG.md").includes("## 1.0.0"));
  assert.ok(read("LICENSE.md").includes("お客さまアンケート キット"));
  assert.equal(JSON.parse(read("package.json")).version, "1.0.0");
  assert.ok(readme.startsWith("# お客さまアンケート キット v1.0.0\n"));
  assert.ok(readme.includes("月額の業務システムを入れるほどではない店のための、Google フォーム + AI"));
  assert.ok(readme.includes("このキットが触るのは、設定の「フォーム ID」のフォーム 1 つだけです"));
  assert.ok(readme.includes("お客さまのメールアドレスを集めず"));
  // エラーの通知は「同じエラーは 1 日 1 通まで」（違うエラーは同じ日でも送る。gas_main.js の reportError_）
  assert.ok(readme.includes("同じエラーのお知らせは 1 日 1 通まで"));
  assert.equal(readme.includes("送り先に 1 日 1 通だけ知らせます"), false);
});
