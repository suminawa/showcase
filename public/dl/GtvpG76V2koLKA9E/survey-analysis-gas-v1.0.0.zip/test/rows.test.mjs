import { test } from "node:test";
import assert from "node:assert/strict";
import { HEADERS, buildResultRow, indexResults, mergeHeader, resultRecords, safeCell } from "../src/rows.js";

const ENTRY = {
  key: "k0000abcd",
  row: 12,
  date: "2026-10-01",
  rating: 4,
  store: "駅前店",
  excerpt: "=HYPERLINK(\"x\") 説明が丁寧",
  answer: { category: "接客", sentiment: "良い", request: "", summary: "10/1", attention: true },
  stamp: "2026-10-04 21:10",
  model: "claude-sonnet-5",
};

test("見出しは 14 列。空のシートなら全部、並べ替えたシートには無い列だけを末尾に足す", () => {
  assert.equal(HEADERS.length, 14);
  assert.deepEqual(mergeHeader([]), { header: HEADERS, added: HEADERS });
  const moved = ["要約", "キー", "分類"];
  const merged = mergeHeader(moved);
  assert.deepEqual(merged.header.slice(0, 3), moved);
  assert.equal(merged.header.length, 14);
  assert.equal(merged.added.indexOf("要約"), -1);
});

test("1 行: 数式に見える字・日付に見える字は ' を付けて字のまま。要対応は ✓、やり直すは FALSE", () => {
  const built = buildResultRow(HEADERS, ENTRY);
  assert.deepEqual(built.row, ["k0000abcd", 12, "2026-10-01", 4, "駅前店", "'=HYPERLINK(\"x\") 説明が丁寧", "接客", "良い", "", "'10/1", "✓", false, "2026-10-04 21:10", "claude-sonnet-5"]);
  assert.equal(safeCell("+81 の番号"), "'+81 の番号");
  assert.equal(safeCell("説明"), "説明");
  // 並べ替えたシートには、その並びで書く
  const moved = buildResultRow(["要約", "キー"], ENTRY);
  assert.deepEqual(moved.row.slice(0, 2), ["'10/1", "k0000abcd"]);
});

test("読み戻し: キー → 行とやり直すの印。人が直した値と、日付に読み替わったセルもそのまま数える", () => {
  const values = [HEADERS, ["k1", 2, new Date(Date.UTC(2026, 9, 1, 0)), 4, "駅前店", "抜粋", "待ち時間", "悪い", "待ち時間の目安", "30分待った", "✓", true, "", "m"], ["k2", 3, "2026-10-02", "", "", "", "品質", "良い", "", "", "", false, "", "m"]];
  assert.deepEqual(indexResults(values).keys, { k1: { row: 2, redo: true }, k2: { row: 3, redo: false } });
  assert.deepEqual(indexResults([]).keys, {});
  const records = resultRecords(values);
  assert.equal(records.length, 2);
  assert.deepEqual(records[0], { row: 2, key: "k1", date: "2026-10-01", rating: 4, store: "駅前店", excerpt: "抜粋", category: "待ち時間", sentiment: "悪い", request: "待ち時間の目安", summary: "30分待った", attention: true });
  assert.equal(records[1].rating, "");
  assert.equal(records[1].attention, false);
});
