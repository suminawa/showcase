import { test } from "node:test";
import assert from "node:assert/strict";
import { PRICES, addUsage, emptyUsage, estimateYen, formatUsage } from "../src/usage.js";

test("使った量は足し合わせる。無い項目は 0 として", () => {
  const total = addUsage(emptyUsage(), { input_tokens: 1000, output_tokens: 300, cache_read_input_tokens: 700, cache_creation_input_tokens: 0 });
  assert.deepEqual(total, { count: 1, input: 1000, output: 300, cacheRead: 700, cacheWrite: 0 });
  const more = addUsage(total, { input_tokens: 500, output_tokens: 100 });
  assert.deepEqual(more, { count: 2, input: 1500, output: 400, cacheRead: 700, cacheWrite: 0 });
});

test("opus 5 の目安: 入力 $5・出力 $25・キャッシュ読み 0.1 倍・書き 2 倍（100 万トークンあたり）、1 ドル 150 円", () => {
  assert.deepEqual(PRICES["claude-opus-5"], { input: 5, output: 25 });
  const total = { count: 100, input: 100000, output: 40000, cacheRead: 70000, cacheWrite: 700 };
  // 0.1×5 + 0.04×25 + 0.07×0.5 + 0.0007×10 = 0.5 + 1.0 + 0.035 + 0.007 = 1.542 ドル → 231.3 円
  assert.equal(estimateYen(total, "claude-opus-5", 150), 231);
  assert.equal(estimateYen(emptyUsage(), "claude-opus-5", 150), 0);
  // 1 時間のキャッシュへの書き込みは入力の 2 倍（5 分の 1.25 倍ではない）
  assert.equal(estimateYen({ count: 1, input: 0, output: 0, cacheRead: 0, cacheWrite: 1000000 }, "claude-opus-5", 150), 1500);
});

test("設定で選べるモデルの単価はそろえてある（README が勧める切り替えでも円が出る）", () => {
  assert.deepEqual(PRICES["claude-sonnet-5"], { input: 2, output: 10 });
  assert.deepEqual(PRICES["claude-haiku-4-5"], { input: 1, output: 5 });
  const total = { count: 100, input: 100000, output: 40000, cacheRead: 70000, cacheWrite: 700 };
  // 0.1×2 + 0.04×10 + 0.07×0.2 + 0.0007×4 = 0.2 + 0.4 + 0.014 + 0.0028 = 0.6168 ドル → 92.52 円
  assert.equal(estimateYen(total, "claude-sonnet-5", 150), 93);
});

test("単価の分からないモデルは null", () => {
  assert.equal(estimateYen({ count: 1, input: 1000, output: 100, cacheRead: 0, cacheWrite: 0 }, "claude-future-9", 150), null);
});

test("今月の利用の文面", () => {
  const total = { count: 100, input: 100000, output: 40000, cacheRead: 70000, cacheWrite: 700 };
  assert.equal(formatUsage(total, "claude-opus-5", "2026-09"), "2026-09 の利用: 100 回\n入力 100,000 トークン（キャッシュから 70,000）、出力 40,000 トークン\n目安 231 円（1 ドル 150 円で換算。Anthropic Console の使用量が正です）");
  assert.equal(formatUsage(total, "claude-future-9", "2026-09"), "2026-09 の利用: 100 回\n入力 100,000 トークン（キャッシュから 70,000）、出力 40,000 トークン\n目安の円は、このモデルの単価が設定に無いため出せません。Anthropic Console の使用量をご覧ください");
});
