import { test } from "node:test";
import assert from "node:assert/strict";
import { CONFIG_KEYS, ConfigError, DEFAULT_CATEGORIES, DEFAULT_CONFIG, DEFAULT_ROWS, configKeyOf, parseConfig, readConfigRows, storeLabel } from "../src/config.js";

function problemsOf(rows) {
  return readConfigRows([["項目", "値"]].concat(rows)).problems;
}

test("行が無ければ既定値。DEFAULT_ROWS は CONFIG_KEYS の順で、読むと既定値と同じになる", () => {
  assert.deepEqual(readConfigRows([]), { config: DEFAULT_CONFIG, problems: [] });
  assert.deepEqual(DEFAULT_ROWS.map((row) => row[0]), CONFIG_KEYS);
  assert.deepEqual(readConfigRows([["項目", "値"]].concat(DEFAULT_ROWS)), { config: DEFAULT_CONFIG, problems: [] });
  assert.equal(DEFAULT_CONFIG.model, "claude-sonnet-5");
  assert.equal(DEFAULT_CONFIG.batchSize, 20);
  assert.deepEqual(DEFAULT_CATEGORIES, ["接客", "待ち時間", "価格", "品質", "清潔さ", "予約・手続き", "その他"]);
  // 項目名の揺れ（空白・半角括弧・大文字小文字）は同じ項目
  assert.equal(configKeyOf("まとめの期間(日)"), configKeyOf("まとめの期間（日）"));
  assert.equal(configKeyOf("slack webhook url"), configKeyOf("Slack Webhook URL"));
  assert.equal(readConfigRows([["まとめの期間(日)", "30"]]).config.periodDays, 30);
});

test("分類: 末尾に「その他」が無ければ足す。13 個は誤り、同じ名前が 2 つも誤り", () => {
  assert.deepEqual(readConfigRows([["分類", "仕上がり、カウンセリング, 待ち時間"]]).config.categories, ["仕上がり", "カウンセリング", "待ち時間", "その他"]);
  const thirteen = Array.from({ length: 12 }, (_, i) => "分類" + (i + 1)).join(",");
  const many = readConfigRows([["分類", thirteen]]);
  assert.deepEqual(many.problems, ["「設定」シートの「分類」は「その他」を含めて 12 個までにしてください（いまは 13 個）。"]);
  assert.equal(many.config.categories.length, 12);
  assert.equal(many.config.categories[11], "その他");
  assert.deepEqual(problemsOf([["分類", "接客, 価格, 接客"]]), ["「設定」シートの「分類」に「接客」が 2 つあります。1 つにしてください。"]);
  assert.deepEqual(problemsOf([["分類", "接客, （回答なし）"]]), ["「設定」シートの「分類」に「（回答なし）」は使えません（回答が空の行の印です）。別の名前にしてください。"]);
});

test("数の項目は範囲の中の整数だけ。範囲外は誤りを出して既定値で読む", () => {
  const read = readConfigRows([["1 回に送る件数", "60"], ["1 日の上限", "0"], ["回答の上限文字数", "1500"], ["まとめの期間（日）", "0"]]);
  assert.deepEqual(read.problems, [
    "「設定」シートの「1 回に送る件数」は 5〜50 の整数にしてください（いまは「60」）。",
    "「設定」シートの「1 日の上限」は 1〜5000 の整数にしてください（いまは「0」）。",
  ]);
  assert.equal(read.config.batchSize, 20);
  assert.equal(read.config.perDay, 500);
  assert.equal(read.config.answerLimit, 1500);
  assert.equal(read.config.periodDays, 0, "0 は全期間");
  assert.equal(readConfigRows([["1 回に送る件数", 10]]).config.batchSize, 10, "セルが数でも読む");
});

test("評価の最大は 5 か 10。伏せ字は TRUE / FALSE", () => {
  assert.equal(readConfigRows([["評価の最大", "10"]]).config.ratingMax, 10);
  assert.deepEqual(problemsOf([["評価の最大", "7"]]), ["「設定」シートの「評価の最大」は 5 か 10 にしてください（いまは「7」）。"]);
  assert.equal(readConfigRows([["伏せ字にする", false]]).config.mask, false);
  assert.equal(readConfigRows([["伏せ字にする", "しない"]]).config.mask, false);
  assert.deepEqual(problemsOf([["伏せ字にする", "たぶん"]]), ["「設定」シートの「伏せ字にする」は TRUE か FALSE にしてください（いまは「たぶん」）。"]);
});

test("まとめの送り先: 綴り違いは誤り。slack なのに URL が空・https でない・見本の URL は誤り。URL の値は文に出さない", () => {
  assert.deepEqual(problemsOf([["まとめの送り先", "slak"]]), ["「設定」シートの「まとめの送り先」に書けるのは mail / slack / discord / line です（いまは「slak」）。"]);
  assert.deepEqual(problemsOf([["まとめの送り先", "slack"]]), ["「まとめの送り先」に slack がありますが、「Slack Webhook URL」が空です。設定シートのその行を埋めてください。"]);
  const http = problemsOf([["まとめの送り先", "discord"], ["Discord Webhook URL", "http://discord.com/api/webhooks/secret"]]);
  assert.deepEqual(http, ["「設定」シートの「Discord Webhook URL」は https:// で始まる URL です。前後に余分な字が入っていないかも確かめてください。"]);
  assert.equal(http[0].includes("secret"), false);
  assert.deepEqual(problemsOf([["まとめの送り先", "slack"], ["Slack Webhook URL", "https://hooks.slack.com/services/XXXXXXXXX/YYYYYYYYY/ZZZZ"]]), ["「設定」シートの「Slack Webhook URL」が見本の URL のままです。ご自身の URL に貼り替えてください。"]);
  assert.deepEqual(problemsOf([["まとめの送り先", "line"], ["LINE チャネルアクセストークン", "t"]]), ["「まとめの送り先」に line がありますが、「LINE 送信先 ID」が空です。設定シートのその行を埋めてください。"]);
  const ok = readConfigRows([["まとめの送り先", "Mail, slack"], ["Slack Webhook URL", "https://hooks.slack.com/services/T0/B0/real"], ["送り先メール", "a@example.com、b@example.com"]]);
  assert.deepEqual(ok.problems, []);
  assert.deepEqual(ok.config.targets, ["mail", "slack"]);
  assert.deepEqual(ok.config.mailTo, ["a@example.com", "b@example.com"]);
  assert.deepEqual(problemsOf([["送り先メール", "a@example"]]), ["「設定」シートの「送り先メール」の「a@example」はメールアドレスの形ではありません。"]);
});

test("モデルは claude- で始まる名前。回答の列は 3 列まで", () => {
  assert.deepEqual(problemsOf([["モデル", "sonnet-5"]]), ["「設定」シートの「モデル」は claude- で始まる名前にしてください（いまは「sonnet-5」）。例: claude-sonnet-5"]);
  assert.equal(readConfigRows([["モデル", "claude-opus-5"]]).config.model, "claude-opus-5");
  const four = readConfigRows([["回答の列", "a, b, c, d"]]);
  assert.deepEqual(four.problems, ["「設定」シートの「回答の列」は 3 列までにしてください（いまは「a, b, c, d」）。"]);
  assert.deepEqual(four.config.answerColumns, ["a", "b", "c"]);
});

test("parseConfig は誤りの最初の 1 つ（CONFIG_KEYS の順）で ConfigError。storeLabel は店名と業種から", () => {
  assert.throws(() => parseConfig([["モデル", "gpt"], ["評価の最大", "3"]]), (error) => error instanceof ConfigError && error.message.startsWith("「設定」シートの「評価の最大」は 5 か 10") && error.message.endsWith("メニュー「設定を確かめる」で、直すところを全部確かめられます。"));
  assert.equal(storeLabel(DEFAULT_CONFIG), "当店");
  assert.equal(storeLabel(Object.assign({}, DEFAULT_CONFIG, { storeName: "サロン みなと", industry: "美容室" })), "サロン みなと（美容室）");
  assert.equal(storeLabel(Object.assign({}, DEFAULT_CONFIG, { storeName: "サロン みなと" })), "サロン みなと");
});

test("フォームの設定: 題・説明・送信後の文の既定、「質問を減らしても消す」は はい / いいえ、キットが書く 3 行は空", () => {
  const config = readConfigRows([]).config;
  assert.equal(config.formTitle, "{店名} ご来店アンケート");
  assert.ok(config.formDescription.startsWith("本日はご来店いただき、ありがとうございました。"));
  assert.equal(config.confirmationMessage, "ご回答ありがとうございました。いただいた声はスタッフ全員で読み、よりよいお店づくりに活かします。");
  assert.equal(config.removeDeleted, false);
  assert.deepEqual([config.formUrl, config.formEditUrl, config.formId], ["", "", ""]);
  assert.equal(readConfigRows([["質問を減らしても消す", "はい"]]).config.removeDeleted, true);
  assert.deepEqual(problemsOf([["質問を減らしても消す", "たぶん"]]), ["「設定」シートの「質問を減らしても消す」は はい か いいえ にしてください（いまは「たぶん」）。"]);
  assert.equal(readConfigRows([["フォーム ID", " 1FAIpQL "]]).config.formId, "1FAIpQL");
  assert.equal(CONFIG_KEYS.length, 28);
});
