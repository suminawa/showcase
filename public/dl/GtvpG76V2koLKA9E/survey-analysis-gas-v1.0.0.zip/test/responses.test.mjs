import { test } from "node:test";
import assert from "node:assert/strict";
import { batches, excerptOf, isEmptyAnswer, joinAnswers, ratingOf, responseKey, selectPending, toResponses } from "../src/responses.js";
import { resolveColumns } from "../src/columns.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const HEADER = ["タイムスタンプ", "今回のご満足度（1〜5）", "ご利用の店舗", "良かった点・気になった点を自由にお書きください", "ご要望があればお書きください（任意）"];
const config = Object.assign({}, DEFAULT_CONFIG);

function responsesOf(rows) {
  const values = [HEADER].concat(rows);
  return toResponses(values, resolveColumns("フォームの回答 1", values, config), config, "2026-10-04");
}

test("キーは同じ日付・同じ本文で同じ、1 字違いで違う。k と 16 進 8 桁", () => {
  const key = responseKey("2026-10-01", "説明が丁寧でした");
  assert.match(key, /^k[0-9a-f]{8}$/);
  assert.equal(responseKey("2026-10-01", "説明が丁寧でした"), key);
  assert.notEqual(responseKey("2026-10-01", "説明が丁寧でした。"), key);
  assert.notEqual(responseKey("2026-10-02", "説明が丁寧でした"), key);
});

test("回答の列が複数なら「【見出し】値」を改行でつなぐ。空の列は入れない。1 列なら値そのまま", () => {
  assert.equal(joinAnswers([{ name: "良かった点", value: "説明" }, { name: "気になった点", value: "" }, { name: "要望", value: "土曜" }]), "【良かった点】説明\n【要望】土曜");
  assert.equal(joinAnswers([{ name: "ご意見", value: " 説明 " }]), "説明");
  const [first] = responsesOf([[new Date(Date.UTC(2026, 9, 1, 1)), 4, "駅前店", "説明が丁寧でした。", "土曜も予約したいです。"]]);
  assert.deepEqual(first, {
    key: first.key,
    row: 2,
    date: "2026-10-01",
    rating: 4,
    store: "駅前店",
    text: "【良かった点・気になった点を自由にお書きください】説明が丁寧でした。\n【ご要望があればお書きください（任意）】土曜も予約したいです。",
    empty: false,
  });
});

test("空の回答（特になし・ー・n/a・空白・1 字）は empty。空の列だけの行は API に送らない印", () => {
  for (const value of ["特になし", "特になし。", " なし ", "無し", "ー", "-", "N/A", "none", "", "良"]) assert.equal(isEmptyAnswer(value), true, value);
  for (const value of ["なしでも大丈夫です", "良い"]) assert.equal(isEmptyAnswer(value), false, value);
  const [row] = responsesOf([["2026/10/02 10:00:00", 5, "本町店", "特になし", ""]]);
  assert.equal(row.empty, true);
  assert.equal(row.text, "【良かった点・気になった点を自由にお書きください】特になし");
  // 片方の列だけが「特になし」なら、その列は落として送る
  assert.equal(responsesOf([["2026-10-02", 5, "", "特になし", "駐車場がほしい"]])[0].text, "【ご要望があればお書きください（任意）】駐車場がほしい");
});

test("評価は 0〜評価の最大の数だけ。全角・「4 - 満足」も読む。抜粋は伏せ字のあとの 60 字", () => {
  assert.equal(ratingOf("４", 5), 4);
  assert.equal(ratingOf("4 - 満足", 5), 4);
  assert.equal(ratingOf(9, 5), "");
  assert.equal(ratingOf(9, 10), 9);
  assert.equal(ratingOf("とても良い", 5), "");
  assert.equal(excerptOf("連絡は taro@example.com へ。" + "あ".repeat(80), config), ("連絡は 〔メール〕 へ。" + "あ".repeat(80)).slice(0, 60));
});

test("日付の列が無ければ分析した日を使い、キーは日付を含まない。空行は飛ばす。同じ日の同じ回答は別のキー", () => {
  const values = [["ご意見"], ["説明が丁寧"], [""], ["説明が丁寧"]];
  const list = toResponses(values, resolveColumns("回答", values, config), config, "2026-10-04");
  assert.equal(list.length, 2);
  assert.equal(list[0].date, "2026-10-04");
  assert.equal(list[0].key, responseKey("", "説明が丁寧"));
  assert.equal(list[1].row, 4);
  assert.notEqual(list[1].key, list[0].key);
});

test("分析済みを飛ばし、やり直すに ✓ の行は上書きの行番号つきで含める。20 件ずつに分ける", () => {
  const list = responsesOf([["2026-10-01", 4, "", "a1", ""], ["2026-10-01", 4, "", "a2", ""], ["2026-10-01", 4, "", "a3", ""]]);
  const index = { header: [], keys: {} };
  index.keys[list[0].key] = { row: 2, redo: false };
  index.keys[list[1].key] = { row: 3, redo: true };
  assert.deepEqual(selectPending(list, index), [
    { response: list[1], overwriteRow: 3 },
    { response: list[2], overwriteRow: null },
  ]);
  const sizes = batches(Array.from({ length: 45 }, (_, i) => i), 20).map((b) => b.length);
  assert.deepEqual(sizes, [20, 20, 5]);
});

function keysOf(values, over) {
  const conf = Object.assign({}, config, over || {});
  return toResponses(values, resolveColumns("フォームの回答 1", values, conf), conf, "2026-10-04").map((r) => r.key);
}

test("キーは見出しを入れず、日付と回答の値（シートの左から）だけで作る。質問の文を直しても・回答の列が増えても・設定の順を変えても、前の回答のキーは変わらない", () => {
  const row = [new Date(Date.UTC(2026, 9, 1, 1)), 4, "駅前店", "説明が丁寧でした。", "土曜も予約したいです。"];
  const before = keysOf([HEADER, row]);
  const reworded = HEADER.slice();
  reworded[3] = "良かった点・気になった点をお聞かせください";
  assert.deepEqual(keysOf([reworded, row]), before, "質問の文を直した");
  // 回答の列が 1 つ → 2 つ（足した列はこれまでの行では空）
  const one = keysOf([["タイムスタンプ", "ご意見"], ["2026-10-01", "説明が丁寧"], ["2026-10-01", "説明が丁寧"]]);
  const two = keysOf([["タイムスタンプ", "ご意見", "ご要望"], ["2026-10-01", "説明が丁寧", ""], ["2026-10-01", "説明が丁寧", ""]]);
  assert.deepEqual(two, one, "回答の列が増えた");
  assert.equal(one[0], responseKey("2026-10-01", "説明が丁寧"), "1 列のときのキーは前と同じ");
  // 設定「回答の列」の順を入れ替えても、つなぐのはシートの左からの順
  const names = [HEADER[3], HEADER[4]];
  assert.deepEqual(keysOf([HEADER, row], { answerColumns: names.slice().reverse() }), keysOf([HEADER, row], { answerColumns: names }));
  // Claude に送る本文には、これまでどおり見出しを付ける
  assert.ok(responsesOf([row])[0].text.startsWith("【良かった点・気になった点を自由にお書きください】"));
});

test("同じ見出しの列が 2 つ以上（種類を変えて作り直した質問）なら、行ごとに右の空でない値を読む", () => {
  const values = [
    ["タイムスタンプ", "満足度", "ご意見", "ご利用の店舗", "満足度", "ご意見", "ご利用の店舗"],
    ["2026-10-01", 4, "前の列の回答", "駅前店", "", "", ""],
    ["2026-10-02", "", "", "", 5, "新しい列の回答", "本町店"],
    ["2026-10-03", 3, "左", "駅前店", 2, "右", "本町店"],
  ];
  const conf = Object.assign({}, config, { answerColumns: ["ご意見"], ratingColumn: "満足度", storeColumn: "ご利用の店舗" });
  const columns = resolveColumns("フォームの回答 1", values, conf);
  assert.deepEqual(columns.answers, [{ name: "ご意見", index: 2, indices: [2, 5] }]);
  assert.deepEqual(columns.rating, { name: "満足度", index: 1, indices: [1, 4], guessed: false });
  const list = toResponses(values, columns, conf, "2026-10-04");
  assert.deepEqual(list.map((r) => [r.text, r.rating, r.store]), [["前の列の回答", 4, "駅前店"], ["新しい列の回答", 5, "本町店"], ["右", 2, "本町店"]]);
  // 見出しから推測するときも、同じ見出しは 1 つの列として読む
  const guessed = resolveColumns("回答", [["ご意見", "ご意見"], ["", "新しい"]], config);
  assert.deepEqual(guessed.answers, [{ name: "ご意見", index: 0, indices: [0, 1] }]);
});
