import { test } from "node:test";
import assert from "node:assert/strict";
import { addDays, formatStamp, toDateKey } from "../src/dates.js";

test("セルの値を日付キーに。Date は JST、時刻つきの字も日付だけを読む", () => {
  assert.equal(toDateKey(new Date(Date.UTC(2026, 9, 3, 15, 30))), "2026-10-04");
  assert.equal(toDateKey("2026/10/04 9:15:00"), "2026-10-04");
  assert.equal(toDateKey("2026-10-04 21:10"), "2026-10-04");
  assert.equal(toDateKey("2026年10月4日"), "2026-10-04");
  assert.equal(toDateKey("2026-02-30"), null);
  assert.equal(toDateKey("先週"), null);
  assert.equal(toDateKey(""), null);
});

test("formatStamp は JST の日時、addDays は月をまたいで足し引きする", () => {
  assert.equal(formatStamp(new Date(Date.UTC(2026, 9, 4, 12, 10, 5))), "2026-10-04 21:10:05");
  assert.equal(addDays("2026-10-04", -6), "2026-09-28");
  assert.equal(addDays("2026-09-28", 7), "2026-10-05");
  assert.equal(addDays("2026-03-01", -1), "2026-02-28");
});
