import { test } from "node:test";
import assert from "node:assert/strict";
import { guessByLength, guessColumns, isPersonalColumn, pickAnswerSheet, resolveColumns } from "../src/columns.js";
import { DEFAULT_CONFIG } from "../src/config.js";

const FORM_HEADER = ["タイムスタンプ", "今回のご満足度（1〜5）", "ご利用の店舗", "良かった点・気になった点を自由にお書きください", "ご要望があればお書きください（任意）", "お名前", "メールアドレス"];

function configWith(over) {
  return Object.assign({}, DEFAULT_CONFIG, over);
}

test("Google フォームの見出しから、回答・日付・評価・店舗を当てる。名前とメールの列は回答にしない", () => {
  assert.deepEqual(guessColumns(FORM_HEADER), {
    answers: ["良かった点・気になった点を自由にお書きください", "ご要望があればお書きください（任意）"],
    date: "タイムスタンプ",
    rating: "今回のご満足度（1〜5）",
    store: "ご利用の店舗",
    reasons: [],
  });
  assert.deepEqual(guessColumns(["ご意見（お名前もどうぞ）", "感想"]).reasons, ["「ご意見（お名前もどうぞ）」は名前や連絡先を含む列なので、回答の列にしません。"]);
  assert.equal(isPersonalColumn("電話番号"), true);
  // 「来店のきっかけ」は店舗の列ではない（「店」は見出しの終わりにあるときだけ）
  assert.equal(guessColumns(["来店のきっかけ", "ご利用の店"]).store, "ご利用の店");
});

test("回答の列は先頭から 3 つまで。同じ見出しは 1 つに数える", () => {
  assert.deepEqual(guessColumns(["ご感想", "ご要望", "コメント", "口コミ"]).answers, ["ご感想", "ご要望", "コメント"]);
  assert.deepEqual(guessColumns(["ご感想", "ご感想", "ご要望", "ご感想"]).answers, ["ご感想", "ご要望"]);
});

test("見出しで決まらなければ、2 行目以降の文字数の平均が最も長い列（日付・評価・店舗・名前の列を除く）", () => {
  const values = [
    ["日付", "評価", "Q1", "Q2", "お名前"],
    ["2026-10-01", 4, "はい", "駅から近くて、スタッフの方も親切でした。", "港 花子さんの長い名前の例です"],
    ["2026-10-02", 5, "いいえ", "予約が取りやすかったです。", "もう一人の長い名前の例です"],
  ];
  assert.equal(guessByLength(values[0], values.slice(1), [0, 1]), 3);
  const resolved = resolveColumns("回答", values, configWith({}));
  assert.equal(resolved.answerSource, "文字数から推測");
  assert.deepEqual(resolved.answers, [{ name: "Q2", index: 3, indices: [3] }]);
  assert.equal(guessByLength(["a"], [[1], [2]], []), -1, "文字の値が無ければ -1");
});

test("設定の名指しは推測に勝つ。「なし」はその役を使わない", () => {
  const resolved = resolveColumns("フォームの回答 1", [FORM_HEADER], configWith({ answerColumns: ["ご要望があればお書きください（任意）"], ratingColumn: "なし", storeColumn: "なし" }));
  assert.equal(resolved.answerSource, "設定");
  assert.deepEqual(resolved.answers, [{ name: "ご要望があればお書きください（任意）", index: 4, indices: [4] }]);
  assert.deepEqual(resolved.date, { name: "タイムスタンプ", index: 0, indices: [0], guessed: true });
  assert.equal(resolved.rating, null);
  assert.equal(resolved.store, null);
  assert.deepEqual(resolved.problems, []);
});

test("名指しした列が見出しに無い・名前や連絡先の列を名指しした、は誤り", () => {
  const resolved = resolveColumns("フォームの回答 1", [FORM_HEADER], configWith({ answerColumns: ["ご意見", "メールアドレス"], dateColumn: "受付日" }));
  assert.deepEqual(resolved.problems, [
    "設定「回答の列」の「ご意見」が、「フォームの回答 1」シートの 1 行目にありません。見出しの名前をそのまま書くか、空にして見出しから推測させてください。",
    "設定「回答の列」の「メールアドレス」は名前や連絡先の列なので、回答の列にできません。自由記述の列の見出しを書いてください。",
    "設定「日付の列」の「受付日」が、「フォームの回答 1」シートの 1 行目にありません。見出しの名前をそのまま書くか、使わないときは「なし」と書いてください。",
  ]);
  assert.deepEqual(resolveColumns("回答", [["日付", "評価"]], configWith({})).problems, ["「回答」シートに回答の列が見つかりません。設定「回答の列」に、自由記述の列の見出しを書いてください。"]);
});

test("回答シートは 設定の名前 → 「フォームの回答」で始まる → 「回答」 → キットのシートを除いた左端", () => {
  assert.equal(pickAnswerSheet(configWith({ sheetName: "口コミ" }), ["設定", "口コミ"]), "口コミ");
  assert.equal(pickAnswerSheet(configWith({ sheetName: "口コミ" }), ["設定"]), "", "名前のシートが無ければ空");
  assert.equal(pickAnswerSheet(configWith({}), ["設定", "回答", "フォームの回答 2"]), "フォームの回答 2");
  assert.equal(pickAnswerSheet(configWith({}), ["設定", "回答"]), "回答");
  assert.equal(pickAnswerSheet(configWith({}), ["設定", "分析結果", "シート1"]), "シート1");
  assert.equal(pickAnswerSheet(configWith({}), ["設定", "分析結果", "まとめ"]), "");
  // 左端を選ぶときは、キットのシート（質問・前の質問・見本の回答も）を選ばない
  const kit = ["設定", "質問", "質問（前）", "質問（前 2）", "見本の回答", "分析結果", "まとめ"];
  assert.equal(pickAnswerSheet(configWith({}), kit), "");
  assert.equal(pickAnswerSheet(configWith({}), kit.concat(["シート1"])), "シート1");
  assert.equal(pickAnswerSheet(configWith({ sheetName: "見本の回答" }), kit), "見本の回答", "名指しなら見本の回答も読む");
});
