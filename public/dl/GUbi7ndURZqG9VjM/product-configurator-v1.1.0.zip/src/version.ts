/** 部品の版。package.json の version と同じ（テストで照らす）。根の要素の data-pc-version にも出す */
export const VERSION = "1.1.0";
