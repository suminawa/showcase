import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { missingNames, referencedNames } from "./names";
import { describeSelection } from "./selection";

const config = resolveConfig({
  groups: [
    { id: "body", label: "色", type: "color", target: ["body-350", "body-500"], options: [{ id: "a", label: "a", color: "#000000" }] },
    { id: "size", label: "容量", type: "variant", options: [{ id: "350", label: "350", show: ["body-350"], hide: ["body-500"] }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"] },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
  ],
});

describe("names", () => {
  it("設定が参照する名前を重複なしで集める", () => {
    expect(referencedNames(config)).toEqual(["body-350", "body-500", "label"]);
  });
  it("モデルに無い名前を返す", () => {
    expect(missingNames(config, ["body-350", "label", "lid"])).toEqual(["body-500"]);
    expect(missingNames(config, ["body-350", "body-500", "label"])).toEqual([]);
  });
});

describe("describeSelection", () => {
  it("読み上げ用に、群の見出しと選んだものを 1 文にする（なし・空の刻印・ロゴの有無も）", () => {
    const full = resolveConfig({
      product: { name: "タンブラー" },
      groups: [
        { id: "body", label: "本体の色", type: "color", target: ["body"], required: true, options: [{ id: "navy", label: "ネイビー", color: "#000000" }] },
        { id: "strap", label: "ストラップ", type: "variant", options: [{ id: "leather", label: "革", show: ["strap"] }] },
        { id: "engrave", label: "刻印", type: "text", target: ["label"] },
        { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
      ],
    });
    expect(describeSelection(full, { body: "navy", strap: null, engrave: "", logo: null })).toBe("タンブラーの 3D 表示。本体の色: ネイビー、ストラップ: なし");
    expect(describeSelection(full, { body: "navy", strap: "leather", engrave: "湊", logo: "1" })).toBe("タンブラーの 3D 表示。本体の色: ネイビー、ストラップ: 革、刻印: 湊、ロゴ: あり");
  });
});
