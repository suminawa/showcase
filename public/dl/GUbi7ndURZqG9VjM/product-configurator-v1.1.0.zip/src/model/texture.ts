/**
 * 売り物: 刻印とロゴを 1 枚のラベル（1024×512）に描く手順。
 * 2D context のうち使うものだけを型にして、DOM なしでテストする。
 */
import type { ResolvedConfig } from "./config";
import type { SelectionState } from "./selection";

export const LABEL_WIDTH = 1024;
export const LABEL_HEIGHT = 512;
/** 文字を置ける横幅（ラベルの左右に余白を残す） */
export const TEXT_MAX_WIDTH = 900;
const FONT_BASE = 160;
const FONT_MIN = 40;
/** 1 行でこれより小さくなるときは、2 行に折り返して大きく保てるかを試す */
const WRAP_BELOW = 96;
/** 2 行のときの行の間隔（文字の大きさに対する倍率）と、上下の余白 */
const LINE_GAP = 1.15;
const PAD_Y = 16;
const CJK = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u;

export interface Draw2D {
  fillStyle: string | CanvasGradient | CanvasPattern;
  font: string;
  textAlign: CanvasTextAlign;
  textBaseline: CanvasTextBaseline;
  fillRect(x: number, y: number, w: number, h: number): void;
  fillText(text: string, x: number, y: number): void;
  measureText(text: string): { width: number };
  drawImage(image: CanvasImageSource, x: number, y: number, w: number, h: number): void;
  clearRect(x: number, y: number, w: number, h: number): void;
}

export interface LabelImage {
  source: CanvasImageSource;
  width: number;
  height: number;
}

export interface LabelInput {
  background: string;
  text?: { value: string; color: string; font: string } | null;
  image?: LabelImage | null;
}

/** 幅に収まる文字の大きさ。base から 4px ずつ下げ、min で止まる */
export function fitFontSize(measure: (font: string) => number, text: string, maxWidth: number, base = FONT_BASE, min = FONT_MIN): number {
  for (let size = base; size > min; size -= 4) {
    if (measure(`bold ${size}px sans-serif`) <= maxWidth) return size;
  }
  return min;
}

/** 縦横比を保って箱に収め、中央に置く */
export function fitRect(w: number, h: number, boxW: number, boxH: number): { x: number; y: number; w: number; h: number } {
  const scale = Math.min(boxW / w, boxH / h);
  const fw = Math.round(w * scale);
  const fh = Math.round(h * scale);
  return { x: Math.round((boxW - fw) / 2), y: Math.round((boxH - fh) / 2), w: fw, h: fh };
}

/**
 * 2 行に分ける位置。真ん中に近い空白で分ける。空白が無ければ、漢字・かなを含む文は字数の真ん中で分ける。
 * 空白の無い英字だけの文は単語の途中で切らない（null）
 */
export function splitLines(text: string): [string, string] | null {
  const chars = [...text.trim()];
  if (chars.length < 2) return null;
  const mid = chars.length / 2;
  let best = -1;
  chars.forEach((c, i) => {
    if (/\s/.test(c) && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
  });
  if (best > 0) return [chars.slice(0, best).join("").trim(), chars.slice(best + 1).join("").trim()];
  if (!CJK.test(text)) return null;
  const at = Math.ceil(mid);
  return [chars.slice(0, at).join(""), chars.slice(at).join("")];
}

export function drawLabel(ctx: Draw2D, input: LabelInput, width = LABEL_WIDTH, height = LABEL_HEIGHT): void {
  ctx.fillStyle = input.background;
  ctx.fillRect(0, 0, width, height);
  const text = input.text?.value.trim() ?? "";
  if (input.text && text !== "") {
    const font = input.text.font;
    const maxWidth = Math.min(TEXT_MAX_WIDTH, width - 60);
    const fit = (lines: string[]) =>
      fitFontSize(
        (probe) => {
          ctx.font = probe.replace("sans-serif", font);
          return Math.max(...lines.map((line) => ctx.measureText(line).width));
        },
        lines[0],
        maxWidth,
      );
    // 画像があるときは文字を下半分に寄せ、画像を上に置く
    const boxTop = input.image ? height / 2 : 0;
    const boxHeight = input.image ? height / 2 : height;
    let lines = [text];
    let size = fit(lines);
    const split = size < WRAP_BELOW ? splitLines(text) : null;
    if (split) {
      // 2 行は横幅と、箱の高さ（上下の余白を除く）の両方に収める
      const twoSize = Math.min(fit(split), Math.floor((boxHeight - PAD_Y * 2) / (2 * LINE_GAP)));
      if (twoSize > size) {
        lines = split;
        size = twoSize;
      }
    }
    ctx.font = `bold ${size}px ${font}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = input.text.color;
    const x = Math.round(width / 2);
    if (lines.length === 1) {
      ctx.fillText(text, x, input.image ? Math.round(height * 0.74) : Math.round(height / 2));
    } else {
      const center = boxTop + boxHeight / 2;
      const offset = (size * LINE_GAP) / 2;
      ctx.fillText(lines[0], x, Math.round(center - offset));
      ctx.fillText(lines[1], x, Math.round(center + offset));
    }
  }
  if (input.image) {
    const box = text !== "" ? { x: 0, y: 0, w: width, h: Math.round(height * 0.5) } : { x: 0, y: 0, w: width, h: height };
    const pad = 32;
    const rect = fitRect(input.image.width, input.image.height, box.w - pad * 2, box.h - pad * 2);
    ctx.drawImage(input.image.source, box.x + pad + rect.x, box.y + pad + rect.y, rect.w, rect.h);
  }
}

/** 対象メッシュ名ごとに、いま描くべきラベル。刻印とロゴが同じ対象なら 1 つにまとめる。何も無ければ入れない */
export function labelInputsOf(
  config: ResolvedConfig,
  state: SelectionState,
  images: Record<string, LabelImage | null | undefined>,
): Record<string, LabelInput> {
  const out: Record<string, LabelInput> = {};
  const ensure = (name: string, background: string): LabelInput => (out[name] ??= { background, text: null, image: null });
  for (const group of config.groups) {
    if (group.type === "text") {
      const value = state[group.id] ?? "";
      if (typeof value !== "string" || value.trim() === "") continue;
      for (const name of group.target) ensure(name, group.background).text = { value, color: group.color, font: group.font };
    } else if (group.type === "image") {
      const image = state[group.id] === null ? null : images[group.id];
      if (!image) continue;
      for (const name of group.target) ensure(name, group.background).image = image;
    }
  }
  return out;
}

/** document.fonts のうち使うものだけ */
export interface FontLoader {
  check(font: string, text?: string): boolean;
  load(font: string, text?: string): Promise<unknown>;
}

/**
 * 刻印の Web フォントがまだ読まれていなければ読み終わるまで待つ。待った（描き直すべき）ときだけ true。
 * 待たずに描くと、初回はフォールバックの書体でラベルが焼かれてしまう
 */
export async function waitForFonts(labels: Record<string, LabelInput>, fonts: FontLoader | undefined): Promise<boolean> {
  if (!fonts) return false;
  // check は書体の指定が読めないと例外を投げるので、まとめて try の中で扱う
  try {
    const pending = Object.values(labels)
      .map((input) => input.text)
      .filter((text): text is NonNullable<LabelInput["text"]> => Boolean(text && text.value.trim() !== ""))
      .map((text) => ({ spec: `bold 64px ${text.font}`, value: text.value }))
      .filter(({ spec, value }) => !fonts.check(spec, value));
    if (pending.length === 0) return false;
    await Promise.all(pending.map(({ spec, value }) => fonts.load(spec, value)));
    return true;
  } catch {
    return false;
  }
}
