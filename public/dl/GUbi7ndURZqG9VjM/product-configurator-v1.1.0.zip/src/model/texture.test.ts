import { describe, expect, it, vi } from "vitest";
import { fakeContext } from "../../test/fake-context";
import { resolveConfig } from "./config";
import { drawLabel, fitFontSize, fitRect, LABEL_HEIGHT, LABEL_WIDTH, labelInputsOf, TEXT_MAX_WIDTH, waitForFonts } from "./texture";

describe("fitFontSize / fitRect", () => {
  it("収まる大きさまで縮め、下限で止まる", () => {
    const measure = (font: string, text: string) => text.length * Number(/(\d+)px/.exec(font)?.[1]) * 0.6;
    expect(fitFontSize((font) => measure(font, "AB"), "AB", 900)).toBe(160);
    expect(fitFontSize((font) => measure(font, "ABCDEFGHIJKL"), "ABCDEFGHIJKL", 900)).toBe(124);
    expect(fitFontSize((font) => measure(font, "A".repeat(60)), "A".repeat(60), 900)).toBe(40);
  });
  it("縦横比を保って箱に収め、中央に置く", () => {
    expect(fitRect(200, 100, 400, 400)).toEqual({ x: 0, y: 100, w: 400, h: 200 });
    expect(fitRect(100, 200, 400, 400)).toEqual({ x: 100, y: 0, w: 200, h: 400 });
  });
});

describe("drawLabel", () => {
  it("背景 → 文字（中央）→ 画像（上に重ねる）の順に描く", () => {
    const ctx = fakeContext();
    drawLabel(ctx, { background: "#ffffff", text: { value: "SUMI", color: "#1c1a15", font: "serif" }, image: { source: {} as CanvasImageSource, width: 200, height: 100 } });
    expect(ctx.calls[0]).toBe(`fillRect 0 0 ${LABEL_WIDTH} ${LABEL_HEIGHT} #ffffff`);
    // 画像があるときは文字を 74 % の高さに置く（379）。y を固定して、値が変わったら気づけるようにする
    expect(ctx.calls[1]).toBe(`fillText "SUMI" 512 ${Math.round(LABEL_HEIGHT * 0.74)} bold 160px serif #1c1a15`);
    expect(ctx.calls[2]).toMatch(/^drawImage /);
    expect(ctx.textAlign).toBe("center");
  });
  it("文字が空なら描かず、画像も無ければ背景だけ", () => {
    const ctx = fakeContext();
    drawLabel(ctx, { background: "#ffffff", text: { value: "  ", color: "#000000", font: "sans-serif" } });
    expect(ctx.calls).toHaveLength(1);
  });
});

describe("labelInputsOf", () => {
  const config = resolveConfig({
    groups: [
      { id: "engrave", label: "刻印", type: "text", target: ["label"], color: "#333333", font: "serif", background: "#f4efe6" },
      { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
      { id: "tag", label: "タグ", type: "text", target: ["tag"] },
    ],
  });
  it("対象メッシュごとに 1 つ。同じ対象の刻印とロゴは重ねる。何も無い対象は入らない", () => {
    const image = { source: {} as CanvasImageSource, width: 10, height: 10 };
    const inputs = labelInputsOf(config, { engrave: "AB", logo: "1", tag: "" }, { logo: image });
    expect(Object.keys(inputs)).toEqual(["label"]);
    expect(inputs.label.background).toBe("#f4efe6");
    expect(inputs.label.text?.value).toBe("AB");
    expect(inputs.label.text?.font).toBe("serif");
    expect(inputs.label.image).toBe(image);
    expect(labelInputsOf(config, { engrave: "", logo: null, tag: "" }, {})).toEqual({});
  });
});

describe("1.1: 刻印の文字数に応じた収め方", () => {
  const draw = (value: string, image = false) => {
    const ctx = fakeContext();
    drawLabel(ctx, {
      background: "#ffffff",
      text: { value, color: "#000000", font: "serif" },
      image: image ? { source: {} as CanvasImageSource, width: 200, height: 100 } : null,
    });
    return ctx.calls
      .filter((c) => c.startsWith("fillText"))
      .map((c) => {
        const m = /^fillText "(.*)" (\d+) (\d+) bold (\d+)px/.exec(c)!;
        return { text: m[1], x: Number(m[2]), y: Number(m[3]), size: Number(m[4]) };
      });
  };
  // 偽物の measureText は 1 字 = 0.6 × 文字の大きさ
  const width = (line: { text: string; size: number }) => line.text.length * 0.6 * line.size;

  it("12 字の英数字（見本の MINATO 2026 など）は 1 行で、横幅の内側に収まる", () => {
    const lines = draw("MINATO 2026X");
    expect(lines).toHaveLength(1);
    expect(width(lines[0])).toBeLessThanOrEqual(TEXT_MAX_WIDTH);
  });

  it("小さくなりすぎる長さは、真ん中に近い空白で 2 行に折り返し、文字を大きく保つ", () => {
    const lines = draw("MINATO SAKURA TOKYO 2026 JAPAN");
    expect(lines.map((l) => l.text)).toEqual(["MINATO SAKURA", "TOKYO 2026 JAPAN"]);
    expect(lines[0].size).toBe(lines[1].size);
    expect(lines[0].size).toBeGreaterThan(fitFontSize((f) => 30 * 0.6 * Number(/(\d+)px/.exec(f)![1]), "x", TEXT_MAX_WIDTH));
    for (const line of lines) expect(width(line)).toBeLessThanOrEqual(TEXT_MAX_WIDTH);
    // 2 行は中央を挟んで上下に並ぶ
    expect(lines[0].y + lines[1].y).toBe(LABEL_HEIGHT);
  });

  it("空白の無い日本語は字数の真ん中で折り返す", () => {
    const lines = draw("あ".repeat(12) + "い".repeat(12));
    expect(lines.map((l) => l.text)).toEqual(["あ".repeat(12), "い".repeat(12)]);
    for (const line of lines) expect(width(line)).toBeLessThanOrEqual(TEXT_MAX_WIDTH);
  });

  it("空白の無い英字は単語の途中で切らず、1 行のまま縮める", () => {
    const lines = draw("A".repeat(30));
    expect(lines).toHaveLength(1);
  });

  it("ロゴと並べるときも、2 行が下半分（ロゴの下）に収まる", () => {
    const lines = draw("あ".repeat(12) + "い".repeat(12), true);
    expect(lines).toHaveLength(2);
    for (const line of lines) {
      expect(line.y - line.size / 2).toBeGreaterThanOrEqual(LABEL_HEIGHT / 2);
      expect(line.y + line.size / 2).toBeLessThanOrEqual(LABEL_HEIGHT);
    }
  });
});

describe("waitForFonts", () => {
  const input = (font: string, value = "湊") => ({ label: { background: "#ffffff", text: { value, color: "#000000", font } } });
  it("まだ読まれていない Web フォントだけ load を待ち、待ったら true（描き直しの合図）", async () => {
    const load = vi.fn(async () => []);
    const fonts = { check: (spec: string) => !spec.includes("Noto"), load };
    expect(await waitForFonts(input("'Noto Serif JP'"), fonts)).toBe(true);
    expect(load).toHaveBeenCalledWith("bold 64px 'Noto Serif JP'", "湊");
    expect(await waitForFonts(input("serif"), fonts)).toBe(false);
    expect(await waitForFonts({}, fonts)).toBe(false);
  });
  it("document.fonts の無い環境と、読み込みの失敗では false", async () => {
    expect(await waitForFonts(input("x"), undefined)).toBe(false);
    expect(await waitForFonts(input("x"), { check: () => false, load: () => Promise.reject(new Error("404")) })).toBe(false);
  });
});
