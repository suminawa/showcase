import { describe, expect, it } from "vitest";
import { DEFAULT_LABELS, DEFAULT_TEXT_PATTERN, isHexColor, resolveConfig, sanitizeMeshName } from "./config";
import { validateText } from "./selection";

const BASE = {
  product: { name: "ステンレスタンブラー", sku: "TB-01" },
  model: { src: "./tumbler.glb" },
  price: { base: 3800, currency: "JPY", note: "税込" },
  groups: [
    { id: "body", label: "本体の色", type: "color", target: ["body-350", "body-500"], required: true,
      options: [{ id: "navy", label: "ネイビー", color: "#243a5e" }, { id: "black", label: "黒", color: "#1c1a15", roughness: 0.9, price: 200 }] },
    { id: "lid", label: "フタ", type: "material", target: ["lid"], required: true,
      options: [{ id: "steel", label: "ステンレス", color: "#b8b8b8", roughness: 0.35, metalness: 0.9 }] },
    { id: "size", label: "容量", type: "variant", required: true,
      options: [{ id: "350", label: "350 ml", show: ["body-350"], hide: ["body-500"] }, { id: "500", label: "500 ml", show: ["body-500"], hide: ["body-350"], price: 400 }] },
    { id: "strap", label: "ストラップ", type: "variant",
      options: [{ id: "leather", label: "革", show: ["strap"], price: 600 }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"], maxChars: 12, pattern: "[A-Za-z0-9 .&-]*", price: 500 },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"], price: 800 },
  ],
};

describe("resolveConfig", () => {
  it("既定値で埋まる", () => {
    const config = resolveConfig(BASE);
    expect(config.product).toEqual({ name: "ステンレスタンブラー", sku: "TB-01" });
    expect(config.model).toEqual({ src: "./tumbler.glb", scale: 1, rotation: [0, 0, 0], camera: { distance: 2.6, elevation: 18, azimuth: -35 } });
    expect(config.scene).toEqual({ background: "#f4efe6", floor: "#e8e2d6", autoRotate: false, src: null });
    expect(config.price).toEqual({ base: 3800, currency: "JPY", note: "税込" });
    expect(config.features).toEqual({ export: true, share: true, copy: true });
    expect(config.labels).toEqual(DEFAULT_LABELS);
    expect(config.groups).toHaveLength(6);
  });

  it("群ごとの既定値: required は先頭、任意は null、色の粗さと金属感、価格 0", () => {
    const config = resolveConfig(BASE);
    const body = config.groups[0];
    expect(body.type).toBe("color");
    if (body.type !== "color") throw new Error();
    expect(body.default).toBe("navy");
    expect(body.options[0]).toEqual({ id: "navy", label: "ネイビー", color: "#243a5e", roughness: null, metalness: null, price: 0 });
    expect(body.options[1].price).toBe(200);
    const strap = config.groups[3];
    if (strap.type !== "variant") throw new Error();
    expect(strap.required).toBe(false);
    expect(strap.default).toBeNull();
    expect(strap.options[0]).toEqual({ id: "leather", label: "革", show: ["strap"], hide: [], price: 600 });
    const engrave = config.groups[4];
    if (engrave.type !== "text") throw new Error();
    expect(engrave).toEqual({ id: "engrave", label: "刻印", type: "text", target: ["label"], maxChars: 12, pattern: "[A-Za-z0-9 .&-]*", patternMessage: null, price: 500, placeholder: "", font: "sans-serif", color: "#1c1a15", background: "#ffffff", hideWhenEmpty: true });
    const logo = config.groups[5];
    if (logo.type !== "image") throw new Error();
    expect(logo).toEqual({ id: "logo", label: "ロゴ", type: "image", target: ["label"], price: 800, maxBytes: 2000000, background: "#ffffff", hideWhenEmpty: true });
  });

  it("model を省くと見本（null）になり、scene と labels は上書きできる", () => {
    const config = resolveConfig({ ...BASE, model: undefined, scene: { background: "#ffffff", autoRotate: true }, labels: { price: "お値段" } });
    expect(config.model.src).toBeNull();
    expect(config.scene.background).toBe("#ffffff");
    expect(config.scene.autoRotate).toBe(true);
    expect(config.labels.price).toBe("お値段");
    expect(config.labels.copy).toBe(DEFAULT_LABELS.copy);
  });

  it("コールバックは 2 つ目の引数から入る", () => {
    const onChange = () => {};
    const config = resolveConfig(BASE, { onChange });
    expect(config.onChange).toBe(onChange);
  });

  it("壊れた設定は日本語で止める", () => {
    expect(() => resolveConfig(null)).toThrow(/product-configurator: 設定/);
    expect(() => resolveConfig({ ...BASE, groups: [] })).toThrow(/groups/);
    expect(() => resolveConfig({ ...BASE, groups: [BASE.groups[0], BASE.groups[0]] })).toThrow(/id が重複/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], type: "tone" }] })).toThrow(/type/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], options: [{ id: "x", label: "x", color: "red" }] }] })).toThrow(/#rrggbb/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[1], options: [{ id: "x", label: "x", color: "#ffffff", roughness: 2, metalness: 0 }] }] })).toThrow(/roughness/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[4], maxChars: 0 }] })).toThrow(/maxChars/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[4], pattern: "[" }] })).toThrow(/pattern/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], options: [{ id: "a", label: "a", color: "#000000", price: 1.5 }] }] })).toThrow(/price/);
    expect(() => resolveConfig({ ...BASE, model: { src: "javascript:alert(1)" } })).toThrow(/model\.src/);
    expect(() => resolveConfig({ ...BASE, model: { src: "./a.glb", scale: 0 } })).toThrow(/scale/);
    expect(() => resolveConfig({ ...BASE, price: { base: -1 } })).toThrow(/price\.base/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], options: [{ id: "a", label: "a", color: "#000000" }, { id: "a", label: "b", color: "#000000" }] }] })).toThrow(/options の id が重複/);
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], required: true, default: "nope" }] })).toThrow(/default/);
  });

  it("isHexColor", () => {
    expect(isHexColor("#1c1a15")).toBe(true);
    expect(isHexColor("#FFF")).toBe(false);
    expect(isHexColor("1c1a15")).toBe(false);
  });
});

describe("1.1: 刻印の既定の pattern・知らないキー・メッシュ名の洗い", () => {
  const text = (extra: Record<string, unknown> = {}) => {
    const config = resolveConfig({ groups: [{ id: "engrave", label: "刻印", type: "text", target: ["label"], ...extra }] });
    const group = config.groups[0];
    if (group.type !== "text") throw new Error();
    return { config, group };
  };

  it("pattern を省くと既定の DEFAULT_TEXT_PATTERN。漢字・かな・英数字・空白・よく使う記号を通し、絵文字やタグは通さない", () => {
    const { config, group } = text();
    expect(group.pattern).toBe(DEFAULT_TEXT_PATTERN);
    for (const ok of ["湊 MINATO", "さくら", "カタカナー々", "ＡＢＣ１２３", "Café & Co.", "O'Neil-2026", "佐藤・鈴木", "全角　空白"]) {
      expect(validateText(group, ok, config.labels), ok).toBeNull();
    }
    for (const ng of ["😀", "<b>", "A\nB", "50%"]) {
      expect(validateText(group, ng, config.labels), ng).toBe(DEFAULT_LABELS.textInvalid);
    }
  });

  it("pattern: null で制限なし。文字列なら買い手の正規表現", () => {
    expect(text({ pattern: null }).group.pattern).toBeNull();
    expect(text({ pattern: "[A-Z]*" }).group.pattern).toBe("[A-Z]*");
  });

  it("既定の誤り文言は特定の文字種を名指ししない。patternMessage で群ごとに変えられる", () => {
    expect(DEFAULT_LABELS.textInvalid).not.toMatch(/英数字/);
    const { config, group } = text({ pattern: "[A-Z]*", patternMessage: "大文字の英字だけです。" });
    expect(group.patternMessage).toBe("大文字の英字だけです。");
    expect(validateText(group, "a", config.labels)).toBe("大文字の英字だけです。");
    expect(text().group.patternMessage).toBeNull();
  });

  it("知らないキーは場所と名前を出して止める（綴りの誤りが既定に落ちて気づけないのを防ぐ）", () => {
    expect(() => resolveConfig({ ...BASE, prodcut: {} })).toThrow("product-configurator: 知らない項目です: prodcut");
    expect(() => resolveConfig({ ...BASE, model: { src: "./a.glb", scal: 2 } })).toThrow("model の知らない項目です: scal");
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], requried: true }] })).toThrow("groups[0] の知らない項目です: requried");
    expect(() => resolveConfig({ ...BASE, groups: [{ ...BASE.groups[0], options: [{ id: "a", label: "a", color: "#000000", prise: 100 }] }] })).toThrow("groups[0] の options[0] の知らない項目です: prise");
    expect(() => resolveConfig({ ...BASE, labels: { prise: "お値段" } })).toThrow("labels の知らない項目です: prise");
    expect(() => resolveConfig({ ...BASE, features: { pdf: true } })).toThrow("features の知らない項目です: pdf");
    // $schema と、mount に渡すコールバックは通す
    expect(() => resolveConfig({ ...BASE, $schema: "./x.json", onChange: () => {} })).not.toThrow();
  });

  it("メッシュ名は GLTFLoader と同じ規則で洗う（Body.001 → Body001、空白 → _）", () => {
    const config = resolveConfig({
      groups: [
        { id: "body", label: "色", type: "color", target: ["Body.001", "My Lid"], options: [{ id: "a", label: "a", color: "#000000" }] },
        { id: "size", label: "容量", type: "variant", options: [{ id: "s", label: "s", show: ["Cup:Small"], hide: ["Cup/Large"] }] },
      ],
    });
    const [body, size] = config.groups;
    if (body.type !== "color" || size.type !== "variant") throw new Error();
    expect(body.target).toEqual(["Body001", "My_Lid"]);
    expect(size.options[0].show).toEqual(["CupSmall"]);
    expect(size.options[0].hide).toEqual(["CupLarge"]);
    expect(sanitizeMeshName("[a] b.c")).toBe("a_bc");
  });
});
