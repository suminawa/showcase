/** 1.1 の振る舞い: 画面外では 3D を読まない・小さい画面で軽くする・版・読み上げ・context lost・タッチの案内 */
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { resolveConfig } from "../model/config";
import { describeSelection } from "../model/selection";
import type { SceneProps } from "../scene/loader";
import { VERSION } from "../version";
import { Configurator } from "./Configurator";

const loadScene = vi.fn();
vi.mock("../scene/loader", async (importOriginal) => ({ ...(await importOriginal<typeof import("../scene/loader")>()), loadScene: (...args: unknown[]) => loadScene(...args) }));

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const config = resolveConfig({
  product: { name: "タンブラー" },
  groups: [
    { id: "body", label: "色", type: "color", target: ["body"], required: true, options: [{ id: "a", label: "紺", color: "#000000" }, { id: "b", label: "黒", color: "#111111", price: 200 }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"] },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
  ],
  scene: { autoRotate: true },
});

/** 偽の 3D。受け取った props と、作られた回数を覚える */
const seen: SceneProps[] = [];
let mounts = 0;
function FakeScene(props: SceneProps) {
  seen.push(props);
  return <div className="fake-scene" />;
}
const lastProps = () => seen[seen.length - 1];

function fakeWebgl(loseContext = vi.fn()) {
  vi.stubGlobal("WebGLRenderingContext", class {});
  vi.spyOn(window.HTMLCanvasElement.prototype, "getContext").mockReturnValue({ getExtension: () => ({ loseContext }) } as never);
  return loseContext;
}

function fakeMedia(matches: (query: string) => boolean) {
  vi.stubGlobal("matchMedia", (query: string) => ({ matches: matches(query), media: query, addEventListener() {}, removeEventListener() {} }));
}

/** IntersectionObserver の偽物。trigger で見える・見えないを知らせる */
function fakeObserver() {
  let callback: IntersectionObserverCallback | null = null;
  const observe = vi.fn();
  vi.stubGlobal(
    "IntersectionObserver",
    class {
      constructor(cb: IntersectionObserverCallback) {
        callback = cb;
      }
      observe = observe;
      disconnect() {}
      unobserve() {}
    },
  );
  return {
    observe,
    trigger: (isIntersecting: boolean) =>
      act(() => {
        callback?.([{ isIntersecting } as IntersectionObserverEntry], {} as IntersectionObserver);
      }),
  };
}

let roots: Root[] = [];
async function mount() {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  roots.push(root);
  await act(async () => {
    root.render(<Configurator config={config} />);
  });
  await act(async () => {});
  return { container };
}

beforeEach(() => {
  seen.length = 0;
  mounts = 0;
  loadScene.mockImplementation(async () => {
    mounts += 1;
    return FakeScene;
  });
});

afterEach(() => {
  for (const root of roots) act(() => root.unmount());
  roots = [];
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = "";
  loadScene.mockReset();
});

describe("1.1", () => {
  it("根の要素に版を data-pc-version で出す。VERSION は package.json と同じ", async () => {
    const { container } = await mount();
    expect(container.querySelector(".pc")!.getAttribute("data-pc-version")).toBe(VERSION);
    const pkg = JSON.parse(readFileSync(resolve(__dirname, "../../package.json"), "utf8")) as { version: string };
    expect(VERSION).toBe(pkg.version);
  });

  it("画面に入るまで 3D の束を読まず、画面外に出たら描画を止める（active）", async () => {
    fakeWebgl();
    const io = fakeObserver();
    await mount();
    expect(io.observe).toHaveBeenCalledTimes(1);
    expect(loadScene).not.toHaveBeenCalled();
    io.trigger(true);
    await act(async () => {});
    expect(loadScene).toHaveBeenCalledTimes(1);
    expect(lastProps().active).toBe(true);
    io.trigger(false);
    expect(lastProps().active).toBe(false);
    // 一度読んだら、出入りしても読み直さない
    io.trigger(true);
    await act(async () => {});
    expect(loadScene).toHaveBeenCalledTimes(1);
  });

  it("IntersectionObserver の無い環境では、すぐに読む", async () => {
    fakeWebgl();
    await mount();
    expect(loadScene).toHaveBeenCalledTimes(1);
    expect(lastProps().active).toBe(true);
  });

  it("幅 60rem 未満では compact（影を軽く・自動回転なし）を 3D に渡す", async () => {
    fakeWebgl();
    fakeMedia((q) => q.includes("max-width"));
    await mount();
    expect(lastProps().compact).toBe(true);
  });

  it("広い画面では compact にしない", async () => {
    fakeWebgl();
    fakeMedia(() => false);
    await mount();
    expect(lastProps().compact).toBe(false);
  });

  it("3D に読み上げ用の説明を渡し、選び直すと説明も変わる", async () => {
    fakeWebgl();
    const { container } = await mount();
    expect(lastProps().description).toBe(describeSelection(config, { body: "a", engrave: "", logo: null }));
    expect(lastProps().description).toBe("タンブラーの 3D 表示。色: 紺");
    const black = [...container.querySelectorAll("button")].find((b) => b.textContent?.startsWith("黒"))!;
    act(() => {
      black.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });
    expect(lastProps().description).toBe("タンブラーの 3D 表示。色: 黒");
  });

  it("試しの WebGL context はすぐ手放す（iOS の context の上限を食わない）", async () => {
    const loseContext = fakeWebgl();
    await mount();
    expect(loseContext).toHaveBeenCalled();
  });

  it("context lost では専用の文言と「もう一度表示する」を出し、押すと 3D を作り直す", async () => {
    fakeWebgl();
    const { container } = await mount();
    const before = seen.length;
    act(() => lastProps().onContextLost?.());
    expect(container.querySelector(".pc-stage-message")!.textContent).toContain(config.labels.contextLost);
    expect(container.querySelector(".fake-scene")).toBeNull();
    const retry = [...container.querySelectorAll("button")].find((b) => b.textContent === config.labels.retry)!;
    act(() => {
      retry.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });
    expect(container.querySelector(".fake-scene")).not.toBeNull();
    expect(seen.length).toBeGreaterThan(before);
  });

  it("タッチの端末では、タッチ用の案内を出す", async () => {
    fakeMedia((q) => q === "(pointer: coarse)");
    const { container } = await mount();
    expect(container.querySelector(".pc-hint")!.textContent).toBe(config.labels.hintTouch);
  });

  it("刻印の入力中は facing を渡す（3D を正面に回す）", async () => {
    fakeWebgl();
    const { container } = await mount();
    expect(lastProps().facing).toBe(false);
    const input = container.querySelector<HTMLInputElement>(".pc-input")!;
    act(() => input.focus());
    expect(lastProps().facing).toBe(true);
    act(() => input.blur());
    expect(lastProps().facing).toBe(false);
  });

  it("ロゴの欄はブラウザ素の英語のボタンではなく、日本語のボタンと「未選択」を出す", async () => {
    const { container } = await mount();
    const button = container.querySelector(".pc-file-button")!;
    expect(button.textContent).toBe(config.labels.imageChoose);
    expect(button.querySelector('input[type="file"]')!.classList.contains("pc-visually-hidden")).toBe(true);
    expect(container.querySelector(".pc-file-name")!.textContent).toBe(config.labels.imageEmpty);
  });
});

describe("1.1 の CSS", () => {
  const css = readFileSync(resolve(__dirname, "../../styles/product-configurator.css"), "utf8");
  it("3D の枠は縦のスクロールを通す（touch-action: pan-y が既定。変数で変えられる）", () => {
    expect(css).toMatch(/\.pc-canvas,\s*\.pc-canvas \*\s*\{\s*touch-action: var\(--pc-touch-action, pan-y\) !important;/);
    expect(css).not.toMatch(/touch-action:\s*none/);
  });
  it("押せるもの（チップ・色・ボタン・ファイル）は高さ 44px 以上", () => {
    expect(css).toMatch(/\.pc-chip, \.pc-swatch, \.pc-button, \.pc-file-button \{[^}]*min-height: 2\.75rem;/);
  });
});
