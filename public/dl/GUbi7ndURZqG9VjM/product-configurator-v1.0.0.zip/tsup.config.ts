import { defineConfig } from "tsup";
import type { Plugin } from "esbuild";

const R3F = ["three", "@react-three/fiber", "@react-three/drei"];

// 素の HTML 用の束はブラウザで動くので、process.env.NODE_ENV を本番に固定する
// （React と three の開発用の分岐が残ると process が無いブラウザで落ちる）
const BROWSER_DEFINE = { "process.env.NODE_ENV": '"production"' };

// 3D の束（3 本目）は React を積まない。1 本目が window.ProductConfigurator に置いた
// React をそのまま使う ── React が 2 つあると hooks と context が壊れる
const REACT_GLOBALS: Record<string, string> = {
  react: "React",
  "react/jsx-runtime": "ReactJsxRuntime",
  "react/jsx-dev-runtime": "ReactJsxRuntime",
  "react-dom": "ReactDOM",
  "react-dom/client": "ReactDOMClient",
};
const reactFromGlobal: Plugin = {
  name: "react-from-global",
  setup(build) {
    build.onResolve({ filter: /^react(-dom)?(\/(jsx-runtime|jsx-dev-runtime|client))?$/ }, (args) => ({
      path: args.path,
      namespace: "react-global",
    }));
    // 読み込みの順が逆だと window.ProductConfigurator がまだ無い。何をすればよいか分かる断りを出す
    build.onLoad({ filter: /.*/, namespace: "react-global" }, (args) => ({
      contents: [
        "var host = window.ProductConfigurator;",
        'if (!host) throw new Error("[product-configurator] product-configurator.global.js を先に読み込んでください（product-configurator-3d.global.js はそのあとです）");',
        `module.exports = host.${REACT_GLOBALS[args.path]};`,
      ].join("\n"),
      loader: "js",
    }));
  },
};

export default defineConfig([
  // 1) npm 用。react も three も外に出す
  {
    entry: { index: "src/index.ts", react: "src/react/index.ts" },
    format: ["esm", "cjs"],
    dts: true,
    sourcemap: false,
    // clean は付けない: 3 本の build は並列に走り、1 本目の clean が 2・3 本目の出力を消しうる。dist は build スクリプトで先に消す
    define: { __PC_DYNAMIC_SCENE__: "true" },
    external: ["react", "react-dom", "react/jsx-runtime", ...R3F, /^three\//],
  },
  // 2) 素の HTML 用（操作列 + 状態）。react を中に積み、three は積まない
  {
    entry: { "product-configurator": "src/vanilla/global.ts" },
    format: ["iife"],
    globalName: "ProductConfigurator",
    minify: true,
    sourcemap: false,
    define: { __PC_DYNAMIC_SCENE__: "false", ...BROWSER_DEFINE },
    external: [...R3F, /^three\//],
    // esbuild は既定で非 ASCII を \uXXXX に逃がす。日本語の文言をそのまま持たせる（サイズも減る）
    esbuildOptions(options) {
      options.charset = "utf8";
    },
  },
  // 3) 素の HTML 用の 3D。1 本目を読んだあと、3D を出すときだけ読む
  {
    entry: { "product-configurator-3d": "src/scene/entry.ts" },
    format: ["iife"],
    globalName: "ProductConfigurator3D",
    minify: true,
    sourcemap: false,
    define: { __PC_DYNAMIC_SCENE__: "false", ...BROWSER_DEFINE },
    esbuildPlugins: [reactFromGlobal],
    // 同上。react-from-global の断り文言（日本語）がそのまま読めるようにする
    esbuildOptions(options) {
      options.charset = "utf8";
    },
  },
]);
