import { defineConfig } from "vitest/config";

export default defineConfig({
  // テストでは 3D の束を動的に読まない（Canvas が要る）。本番のビルドでは tsup の define が true を入れる
  define: { __PC_DYNAMIC_SCENE__: "false" },
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./test/setup.ts"],
    include: ["src/**/*.test.{ts,tsx}"],
  },
});
