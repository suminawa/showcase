import type { ConfiguratorLabels, ResolvedConfig, TextGroup } from "./config";
import { priceOf } from "./price";

/** 群 id → 値。色・素材・パーツは選択肢の id（任意の群は null）。刻印は文字。画像は入っていれば "1"、無ければ null */
export type SelectionState = Record<string, string | null>;

export interface ImageMeta {
  name: string;
  type: string;
  size: number;
}

export interface SelectionJson {
  product: string;
  selection: Record<string, string | null | ImageMeta>;
  price: { base: number; delta: number; total: number; currency: string };
  at: string;
}

export const SHARE_KEY = "pc";

export function defaultSelection(config: ResolvedConfig): SelectionState {
  const state: SelectionState = {};
  for (const group of config.groups) {
    if (group.type === "text") state[group.id] = "";
    else if (group.type === "image") state[group.id] = null;
    else state[group.id] = group.default;
  }
  return state;
}

/** 刻印の検査。問題なければ null、あれば画面に出す文言 */
export function validateText(group: TextGroup, value: string, labels: ConfiguratorLabels): string | null {
  if (value.length > group.maxChars) return labels.textTooLong.replace("{max}", String(group.maxChars));
  if (group.pattern !== null && value !== "" && !new RegExp(`^(?:${group.pattern})$`, "u").test(value)) return labels.textInvalid;
  return null;
}

/** pattern に合わない刻印は捨てる（共有 URL や setSelection から来た文字にも、入力欄と同じ検査をかける） */
function acceptedText(group: TextGroup, value: string): string {
  const sliced = value.slice(0, group.maxChars);
  if (group.pattern !== null && sliced !== "" && !new RegExp(`^(?:${group.pattern})$`, "u").test(sliced)) return "";
  return sliced;
}

/** 知らない群と知らない id を落とし、省いた群は既定のまま、required の群の null は既定に戻し、刻印は上限で切る */
export function normalizeSelection(config: ResolvedConfig, partial: Record<string, unknown>): SelectionState {
  const state = defaultSelection(config);
  for (const group of config.groups) {
    const value = partial[group.id];
    if (group.type === "text") {
      if (typeof value === "string") state[group.id] = acceptedText(group, value);
      continue;
    }
    if (group.type === "image") {
      state[group.id] = value === null || value === undefined ? null : "1";
      continue;
    }
    // 省いた群は既定のまま。null は「なし」（required の群では既定に戻す）
    if (value === undefined) continue;
    if (value === null) {
      state[group.id] = group.required ? group.default : null;
      continue;
    }
    state[group.id] = typeof value === "string" && group.options.some((o) => o.id === value) ? value : group.required ? group.default : null;
  }
  return state;
}

export function selectionJson(
  config: ResolvedConfig,
  state: SelectionState,
  images: Record<string, ImageMeta | null | undefined>,
  at: Date = new Date(),
): SelectionJson {
  const selection: SelectionJson["selection"] = {};
  for (const group of config.groups) {
    if (group.type === "image") selection[group.id] = state[group.id] === null ? null : (images[group.id] ?? null);
    else selection[group.id] = state[group.id] ?? null;
  }
  return { product: config.product.sku, selection, price: priceOf(config, state), at: at.toISOString() };
}

function toBase64Url(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromBase64Url(text: string): string | null {
  try {
    const padded = text.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (text.length % 4)) % 4);
    const binary = atob(padded);
    const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  } catch {
    return null;
  }
}

/** 共有 URL の hash。画像は含めない（ブラウザの中だけのものなので） */
export function encodeShare(config: ResolvedConfig, state: SelectionState): string {
  const picked: Record<string, string | null> = {};
  for (const group of config.groups) {
    if (group.type === "image") continue;
    picked[group.id] = state[group.id] ?? null;
  }
  return `#${SHARE_KEY}=${toBase64Url(JSON.stringify(picked))}`;
}

/** hash から選択を戻す。壊れていれば空。知らない id は normalizeSelection が落とす */
export function decodeShare(config: ResolvedConfig, hash: string): Partial<SelectionState> {
  const match = /(?:^|[#&])pc=([A-Za-z0-9_-]+)/.exec(hash);
  if (!match) return {};
  const text = fromBase64Url(match[1]);
  if (text === null) return {};
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    return {};
  }
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) return {};
  const out: Partial<SelectionState> = {};
  for (const group of config.groups) {
    if (group.type === "image") continue;
    const value = (raw as Record<string, unknown>)[group.id];
    if (group.type === "text") {
      if (typeof value === "string") out[group.id] = acceptedText(group, value);
      continue;
    }
    if (typeof value === "string" && group.options.some((o) => o.id === value)) out[group.id] = value;
    else if (value === null && !group.required) out[group.id] = null;
  }
  return out;
}
