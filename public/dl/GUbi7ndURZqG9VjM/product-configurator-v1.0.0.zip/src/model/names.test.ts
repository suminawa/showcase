import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { missingNames, referencedNames } from "./names";

const config = resolveConfig({
  groups: [
    { id: "body", label: "色", type: "color", target: ["body-350", "body-500"], options: [{ id: "a", label: "a", color: "#000000" }] },
    { id: "size", label: "容量", type: "variant", options: [{ id: "350", label: "350", show: ["body-350"], hide: ["body-500"] }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"] },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
  ],
});

describe("names", () => {
  it("設定が参照する名前を重複なしで集める", () => {
    expect(referencedNames(config)).toEqual(["body-350", "body-500", "label"]);
  });
  it("モデルに無い名前を返す", () => {
    expect(missingNames(config, ["body-350", "label", "lid"])).toEqual(["body-500"]);
    expect(missingNames(config, ["body-350", "body-500", "label"])).toEqual([]);
  });
});
