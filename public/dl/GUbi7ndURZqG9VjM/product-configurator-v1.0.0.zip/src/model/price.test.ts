import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { formatPrice, priceOf } from "./price";
import { defaultSelection } from "./selection";

const config = resolveConfig({
  price: { base: 3800, currency: "JPY" },
  groups: [
    { id: "body", label: "色", type: "color", target: ["body"], required: true, options: [{ id: "navy", label: "n", color: "#000000" }, { id: "black", label: "b", color: "#111111", price: 200 }] },
    { id: "size", label: "容量", type: "variant", required: true, options: [{ id: "350", label: "350" }, { id: "500", label: "500", price: 400 }] },
    { id: "strap", label: "紐", type: "variant", options: [{ id: "leather", label: "革", show: ["strap"], price: 600 }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"], price: 500 },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"], price: 800 },
    { id: "sale", label: "値引き", type: "variant", options: [{ id: "off", label: "-300", price: -300 }] },
  ],
});

describe("priceOf", () => {
  it("既定の選択は差額 0", () => {
    expect(priceOf(config, defaultSelection(config))).toEqual({ base: 3800, delta: 0, total: 3800, currency: "JPY" });
  });
  it("選択肢・刻印・ロゴ・負の差額を足す", () => {
    const state = { body: "black", size: "500", strap: "leather", engrave: "SUMI", logo: "1", sale: "off" };
    expect(priceOf(config, state)).toEqual({ base: 3800, delta: 200 + 400 + 600 + 500 + 800 - 300, total: 6000, currency: "JPY" });
  });
  it("刻印が空、画像が無いときは足さない。知らない id は 0", () => {
    expect(priceOf(config, { body: "navy", size: "350", strap: null, engrave: "", logo: null, sale: "zzz" }).delta).toBe(0);
  });
});

describe("formatPrice", () => {
  it("円は記号と桁区切り、他の通貨も Intl で出す", () => {
    expect(formatPrice(6000, "JPY")).toBe("￥6,000");
    expect(formatPrice(12.5, "USD")).toMatch(/12\.50/);
  });
});
