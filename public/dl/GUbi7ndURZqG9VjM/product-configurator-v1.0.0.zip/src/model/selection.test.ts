import { describe, expect, it } from "vitest";
import { resolveConfig } from "./config";
import { decodeShare, defaultSelection, encodeShare, normalizeSelection, selectionJson, SHARE_KEY, validateText } from "./selection";

const config = resolveConfig({
  product: { name: "タンブラー", sku: "TB-01" },
  price: { base: 3800, currency: "JPY" },
  groups: [
    { id: "body", label: "色", type: "color", target: ["body"], required: true, options: [{ id: "navy", label: "n", color: "#000000" }, { id: "black", label: "b", color: "#111111", price: 200 }] },
    { id: "strap", label: "紐", type: "variant", options: [{ id: "leather", label: "革", show: ["strap"], price: 600 }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"], maxChars: 6, pattern: "[A-Za-z0-9 ]*", price: 500 },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"], price: 800 },
  ],
});

describe("defaultSelection / normalizeSelection", () => {
  it("既定: required は先頭、任意は null、刻印は空、画像は null", () => {
    expect(defaultSelection(config)).toEqual({ body: "navy", strap: null, engrave: "", logo: null });
  });
  it("知らない群と知らない id を落とし、刻印は上限で切る", () => {
    expect(normalizeSelection(config, { body: "black", strap: "zzz", engrave: "ABCDEFGH", logo: "1", extra: "x" })).toEqual({ body: "black", strap: null, engrave: "ABCDEF", logo: "1" });
  });
  it("刻印は pattern に合わない文字を捨てる（共有 URL・setSelection どちらから来ても）", () => {
    expect(normalizeSelection(config, { engrave: "あいう" }).engrave).toBe("");
  });
  it("required の群に null は入らず既定に戻る", () => {
    expect(normalizeSelection(config, { body: null }).body).toBe("navy");
  });
  it("省いた群は既定（default の選択肢）のまま。null は任意の群なら「なし」", () => {
    const withDefault = resolveConfig({ groups: [{ id: "strap", label: "紐", type: "variant", default: "leather", options: [{ id: "leather", label: "革" }] }] });
    expect(normalizeSelection(withDefault, {})).toEqual({ strap: "leather" });
    expect(normalizeSelection(withDefault, { strap: null })).toEqual({ strap: null });
  });
});

describe("validateText", () => {
  const group = config.groups[2];
  if (group.type !== "text") throw new Error();
  it("上限と文字の検査", () => {
    expect(validateText(group, "ABC 12", config.labels)).toBeNull();
    expect(validateText(group, "ABCDEFG", config.labels)).toBe("6 字以内でご入力ください。");
    expect(validateText(group, "あいう", config.labels)).toBe(config.labels.textInvalid);
    expect(validateText(group, "", config.labels)).toBeNull();
  });
});

describe("selectionJson", () => {
  it("画像は名前・種類・大きさだけ。価格も入る", () => {
    const state = { body: "black", strap: "leather", engrave: "SUMI", logo: "1" };
    const json = selectionJson(config, state, { logo: { name: "logo.png", type: "image/png", size: 1234 } }, new Date("2026-10-02T09:00:00.000Z"));
    expect(json).toEqual({
      product: "TB-01",
      selection: { body: "black", strap: "leather", engrave: "SUMI", logo: { name: "logo.png", type: "image/png", size: 1234 } },
      price: { base: 3800, delta: 2100, total: 5900, currency: "JPY" },
      at: "2026-10-02T09:00:00.000Z",
    });
  });
  it("画像が無ければ null", () => {
    expect(selectionJson(config, defaultSelection(config), {}, new Date(0)).selection.logo).toBeNull();
  });
});

describe("encodeShare / decodeShare", () => {
  it("往復する。画像は含めない。知らない id は捨てる", () => {
    const state = { body: "black", strap: "leather", engrave: "SUMI 1", logo: "1" };
    const hash = encodeShare(config, state);
    expect(hash.startsWith(`#${SHARE_KEY}=`)).toBe(true);
    expect(hash).not.toContain("logo");
    expect(decodeShare(config, hash)).toEqual({ body: "black", strap: "leather", engrave: "SUMI 1" });
    expect(decodeShare(config, "#pc=!!!")).toEqual({});
    expect(decodeShare(config, "")).toEqual({});
    // 任意の群の「なし」（null）は残す。default に選択肢を指定した任意の群で、「なし」を選んだことが URL から戻るようにするため
    expect(decodeShare(config, encodeShare(config, { body: "zzz", strap: null, engrave: "", logo: null }))).toEqual({ strap: null, engrave: "" });
  });
  it("pattern に合わない刻印は URL 経由でも捨てる。合う文字はそのまま残る", () => {
    expect(decodeShare(config, encodeShare(config, { body: "navy", strap: null, engrave: 'a"b', logo: null })).engrave).toBe("");
    expect(decodeShare(config, encodeShare(config, { body: "navy", strap: null, engrave: "AB 1", logo: null })).engrave).toBe("AB 1");
  });
});
