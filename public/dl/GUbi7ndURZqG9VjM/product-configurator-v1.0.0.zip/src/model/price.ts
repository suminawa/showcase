import type { ResolvedConfig } from "./config";
import type { SelectionState } from "./selection";

export interface PriceBreakdown {
  base: number;
  delta: number;
  total: number;
  currency: string;
}

/** 選んだ選択肢の差額の合計。刻印は文字があるとき、画像は入っているときだけ足す */
export function priceOf(config: ResolvedConfig, state: SelectionState): PriceBreakdown {
  let delta = 0;
  for (const group of config.groups) {
    const value = state[group.id] ?? null;
    if (group.type === "text") {
      if (typeof value === "string" && value.trim() !== "") delta += group.price;
      continue;
    }
    if (group.type === "image") {
      if (value !== null) delta += group.price;
      continue;
    }
    const option = group.options.find((o) => o.id === value);
    if (option) delta += option.price;
  }
  return { base: config.price.base, delta, total: config.price.base + delta, currency: config.price.currency };
}

export function formatPrice(amount: number, currency: string, locale = "ja-JP"): string {
  try {
    return new Intl.NumberFormat(locale, { style: "currency", currency }).format(amount);
  } catch {
    return `${amount} ${currency}`;
  }
}
