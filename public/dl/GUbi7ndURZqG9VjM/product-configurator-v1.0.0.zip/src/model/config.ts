/** 売り物: 設定の型と検査。three も DOM も読まない */

export type GroupType = "color" | "material" | "variant" | "text" | "image";

export interface ColorOption {
  id: string;
  label: string;
  color: string;
  roughness: number | null;
  metalness: number | null;
  price: number;
}

export interface MaterialOption {
  id: string;
  label: string;
  color: string;
  roughness: number;
  metalness: number;
  price: number;
}

export interface VariantOption {
  id: string;
  label: string;
  show: string[];
  hide: string[];
  price: number;
}

interface GroupBase {
  id: string;
  label: string;
}

export interface ColorGroup extends GroupBase {
  type: "color";
  target: string[];
  required: boolean;
  default: string | null;
  options: ColorOption[];
}

export interface MaterialGroup extends GroupBase {
  type: "material";
  target: string[];
  required: boolean;
  default: string | null;
  options: MaterialOption[];
}

export interface VariantGroup extends GroupBase {
  type: "variant";
  required: boolean;
  default: string | null;
  options: VariantOption[];
}

export interface TextGroup extends GroupBase {
  type: "text";
  target: string[];
  maxChars: number;
  /** 許す文字の正規表現（全体に当てる）。null なら制限なし */
  pattern: string | null;
  price: number;
  placeholder: string;
  font: string;
  color: string;
  /** ラベルの下地の色 */
  background: string;
  /** 何も描くものが無いとき、対象メッシュを隠す */
  hideWhenEmpty: boolean;
}

export interface ImageGroup extends GroupBase {
  type: "image";
  target: string[];
  price: number;
  maxBytes: number;
  background: string;
  hideWhenEmpty: boolean;
}

export type Group = ColorGroup | MaterialGroup | VariantGroup | TextGroup | ImageGroup;
export type OptionGroup = ColorGroup | MaterialGroup | VariantGroup;

export interface ModelConfig {
  /** null なら同梱の見本（タンブラー）を読む */
  src: string | null;
  scale: number;
  rotation: [number, number, number];
  camera: { distance: number; elevation: number; azimuth: number };
}

export interface SceneConfig {
  background: string;
  floor: string;
  autoRotate: boolean;
  /** 3D の束（product-configurator-3d.global.js）の置き場所。null なら <script> で読まれているものを待つ */
  src: string | null;
}

export interface PriceConfig {
  base: number;
  currency: string;
  note: string;
}

export interface ConfiguratorLabels {
  price: string;
  copy: string;
  copied: string;
  export: string;
  share: string;
  shared: string;
  reset: string;
  loading: string;
  loadError: string;
  noWebgl: string;
  sceneMissing: string;
  missing: string;
  none: string;
  textTooLong: string;
  textInvalid: string;
  imageTooLarge: string;
  imageType: string;
  imageClear: string;
  hint: string;
}

export const DEFAULT_LABELS: ConfiguratorLabels = {
  price: "価格",
  copy: "選択内容をコピー",
  copied: "コピーしました",
  export: "PNG で保存",
  share: "共有 URL をコピー",
  shared: "URL をコピーしました",
  reset: "最初に戻す",
  loading: "読み込み中…",
  loadError: "モデルを読み込めませんでした。設定の model.src をご確認ください。",
  noWebgl: "この端末では 3D を表示できません。",
  sceneMissing: "3D の部品（product-configurator-3d.global.js）が見つかりません。設置の手順をご確認ください。",
  missing: "モデルに無い名前",
  none: "なし",
  textTooLong: "{max} 字以内でご入力ください。",
  textInvalid: "使える文字は英数字と記号（. & -）、空白です。",
  imageTooLarge: "画像は {max} 以下にしてください。",
  imageType: "PNG・JPEG・SVG の画像を選んでください。",
  imageClear: "画像を外す",
  hint: "ドラッグで回転、ホイールで拡大縮小、ダブルクリックで戻します。",
};

export interface ExportResult {
  blob: Blob;
  name: string;
}

export interface ConfiguratorCallbacks {
  onChange?: (selection: import("./selection").SelectionJson) => void;
  onExport?: (result: ExportResult) => void;
}

export interface ResolvedConfig extends ConfiguratorCallbacks {
  product: { name: string; sku: string };
  model: ModelConfig;
  scene: SceneConfig;
  price: PriceConfig;
  groups: Group[];
  features: { export: boolean; share: boolean; copy: boolean };
  labels: ConfiguratorLabels;
}

/** 買い手が書く JSON（緩い形）。resolveConfig が ResolvedConfig に整える */
export type ConfiguratorConfig = Record<string, unknown> & ConfiguratorCallbacks;

export const LIMITS = {
  groups: 20,
  options: 30,
  maxChars: 40,
  maxBytes: { min: 1024, max: 10_485_760, default: 2_000_000 },
  scale: { min: 0.01, max: 100 },
  price: 1_000_000,
} as const;

export function fail(message: string): never {
  throw new Error(`product-configurator: ${message}`);
}

export function isHexColor(value: unknown): value is string {
  return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value);
}

function recordOf(value: unknown, where: string): Record<string, unknown> {
  if (value === undefined || value === null) return {};
  if (typeof value !== "object" || Array.isArray(value)) fail(`${where} は { } の形にしてください`);
  return value as Record<string, unknown>;
}

function stringOf(value: unknown, where: string, fallback: string): string {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== "string") fail(`${where} は文字列にしてください`);
  return value;
}

function requiredString(value: unknown, where: string): string {
  if (typeof value !== "string" || value.trim() === "") fail(`${where} を入れてください`);
  return value;
}

function numberOf(value: unknown, where: string, min: number, max: number, fallback: number, integer = false): number {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== "number" || !Number.isFinite(value)) fail(`${where} は数にしてください`);
  if (integer && !Number.isInteger(value)) fail(`${where} は整数にしてください（いまの値: ${value}）`);
  if (value < min || value > max) fail(`${where} は ${min} 〜 ${max} にしてください（いまの値: ${value}）`);
  return value;
}

function booleanOf(value: unknown, where: string, fallback: boolean): boolean {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== "boolean") fail(`${where} は true か false にしてください`);
  return value;
}

function colorOf(value: unknown, where: string, fallback?: string): string {
  if ((value === undefined || value === null) && fallback !== undefined) return fallback;
  if (!isHexColor(value)) fail(`${where} は #rrggbb の色にしてください`);
  return value.toLowerCase();
}

function namesOf(value: unknown, where: string, fallback: string[] = []): string[] {
  if (value === undefined || value === null) return fallback;
  const list = typeof value === "string" ? [value] : value;
  if (!Array.isArray(list) || list.some((item) => typeof item !== "string" || item.trim() === "")) {
    fail(`${where} はメッシュ名の一覧にしてください`);
  }
  return (list as string[]).map((item) => item.trim());
}

/** ページのファイルか http(s) だけ。javascript: や data: は弾く */
export function isSafeSrc(value: string): boolean {
  value = value.trim();
  if (/^https?:\/\//i.test(value)) return true;
  if (/^[a-z][a-z0-9+.-]*:/i.test(value)) return false;
  return value.trim() !== "";
}

function srcOf(value: unknown, where: string): string | null {
  if (value === undefined || value === null) return null;
  if (typeof value !== "string" || !isSafeSrc(value)) fail(`${where} は相対パスか http(s) の URL にしてください`);
  return value;
}

function priceOf(value: unknown, where: string): number {
  return numberOf(value, where, -LIMITS.price, LIMITS.price, 0, true);
}

function optionsOf(raw: unknown, where: string): Record<string, unknown>[] {
  if (!Array.isArray(raw) || raw.length === 0) fail(`${where} の options を 1 つ以上入れてください`);
  if (raw.length > LIMITS.options) fail(`${where} の options は ${LIMITS.options} 個までです`);
  const list = raw.map((item, i) => recordOf(item, `${where} の options[${i}]`));
  const ids = new Set<string>();
  for (const item of list) {
    const id = requiredString(item.id, `${where} の options の id`);
    if (ids.has(id)) fail(`${where} の options の id が重複しています（${id}）`);
    ids.add(id);
  }
  return list;
}

function defaultOf(raw: Record<string, unknown>, where: string, required: boolean, ids: string[]): string | null {
  if (raw.default === undefined || raw.default === null) return required ? ids[0] : null;
  if (typeof raw.default !== "string" || !ids.includes(raw.default)) fail(`${where} の default は options の id にしてください`);
  return raw.default;
}

function groupOf(raw: unknown, index: number): Group {
  const where = `groups[${index}]`;
  const g = recordOf(raw, where);
  const id = requiredString(g.id, `${where} の id`);
  const label = requiredString(g.label, `${where} の label`);
  const type = g.type;
  if (type === "color" || type === "material" || type === "variant") {
    const required = booleanOf(g.required, `${where} の required`, false);
    const list = optionsOf(g.options, where);
    if (type === "color") {
      const options: ColorOption[] = list.map((o, i) => ({
        id: o.id as string,
        label: requiredString(o.label, `${where} の options[${i}] の label`),
        color: colorOf(o.color, `${where} の options[${i}] の color`),
        roughness: o.roughness === undefined ? null : numberOf(o.roughness, `${where} の options[${i}] の roughness`, 0, 1, 0),
        metalness: o.metalness === undefined ? null : numberOf(o.metalness, `${where} の options[${i}] の metalness`, 0, 1, 0),
        price: priceOf(o.price, `${where} の options[${i}] の price`),
      }));
      return { id, label, type, target: namesOf(g.target, `${where} の target`), required, default: defaultOf(g, where, required, options.map((o) => o.id)), options };
    }
    if (type === "material") {
      const options: MaterialOption[] = list.map((o, i) => ({
        id: o.id as string,
        label: requiredString(o.label, `${where} の options[${i}] の label`),
        color: colorOf(o.color, `${where} の options[${i}] の color`),
        roughness: numberOf(o.roughness, `${where} の options[${i}] の roughness`, 0, 1, 0.5),
        metalness: numberOf(o.metalness, `${where} の options[${i}] の metalness`, 0, 1, 0),
        price: priceOf(o.price, `${where} の options[${i}] の price`),
      }));
      return { id, label, type, target: namesOf(g.target, `${where} の target`), required, default: defaultOf(g, where, required, options.map((o) => o.id)), options };
    }
    const options: VariantOption[] = list.map((o, i) => ({
      id: o.id as string,
      label: requiredString(o.label, `${where} の options[${i}] の label`),
      show: namesOf(o.show, `${where} の options[${i}] の show`),
      hide: namesOf(o.hide, `${where} の options[${i}] の hide`),
      price: priceOf(o.price, `${where} の options[${i}] の price`),
    }));
    return { id, label, type, required, default: defaultOf(g, where, required, options.map((o) => o.id)), options };
  }
  if (type === "text") {
    const pattern = g.pattern === undefined || g.pattern === null ? null : stringOf(g.pattern, `${where} の pattern`, "");
    if (pattern !== null) {
      try {
        new RegExp(`^(?:${pattern})$`, "u");
      } catch {
        fail(`${where} の pattern が正規表現として読めません`);
      }
    }
    return {
      id,
      label,
      type,
      target: namesOf(g.target, `${where} の target`),
      maxChars: numberOf(g.maxChars, `${where} の maxChars`, 1, LIMITS.maxChars, 12, true),
      pattern,
      price: priceOf(g.price, `${where} の price`),
      placeholder: stringOf(g.placeholder, `${where} の placeholder`, ""),
      font: stringOf(g.font, `${where} の font`, "sans-serif"),
      color: colorOf(g.color, `${where} の color`, "#1c1a15"),
      background: colorOf(g.background, `${where} の background`, "#ffffff"),
      hideWhenEmpty: booleanOf(g.hideWhenEmpty, `${where} の hideWhenEmpty`, true),
    };
  }
  if (type === "image") {
    return {
      id,
      label,
      type,
      target: namesOf(g.target, `${where} の target`),
      price: priceOf(g.price, `${where} の price`),
      maxBytes: numberOf(g.maxBytes, `${where} の maxBytes`, LIMITS.maxBytes.min, LIMITS.maxBytes.max, LIMITS.maxBytes.default, true),
      background: colorOf(g.background, `${where} の background`, "#ffffff"),
      hideWhenEmpty: booleanOf(g.hideWhenEmpty, `${where} の hideWhenEmpty`, true),
    };
  }
  return fail(`${where} の type は color / material / variant / text / image のどれかにしてください`);
}

function labelsOf(raw: unknown): ConfiguratorLabels {
  const r = recordOf(raw, "labels");
  const out: ConfiguratorLabels = { ...DEFAULT_LABELS };
  for (const key of Object.keys(DEFAULT_LABELS) as (keyof ConfiguratorLabels)[]) {
    out[key] = stringOf(r[key], `labels.${key}`, DEFAULT_LABELS[key]);
  }
  return out;
}

export function resolveConfig(input: unknown, callbacks: ConfiguratorCallbacks = {}): ResolvedConfig {
  if (typeof input !== "object" || input === null || Array.isArray(input)) fail("設定は { } の形にしてください");
  const root = input as Record<string, unknown>;
  const product = recordOf(root.product, "product");
  const model = recordOf(root.model, "model");
  const camera = recordOf(model.camera, "model.camera");
  const scene = recordOf(root.scene, "scene");
  const price = recordOf(root.price, "price");
  const features = recordOf(root.features, "features");
  const rotationRaw = model.rotation === undefined ? [0, 0, 0] : model.rotation;
  if (!Array.isArray(rotationRaw) || rotationRaw.length !== 3 || rotationRaw.some((n) => typeof n !== "number" || !Number.isFinite(n))) {
    fail("model.rotation は数 3 つの一覧にしてください（度）");
  }
  if (!Array.isArray(root.groups) || root.groups.length === 0) fail("groups を 1 つ以上入れてください");
  if (root.groups.length > LIMITS.groups) fail(`groups は ${LIMITS.groups} 個までです`);
  const groups = root.groups.map((g, i) => groupOf(g, i));
  const ids = new Set<string>();
  for (const g of groups) {
    if (ids.has(g.id)) fail(`groups の id が重複しています（${g.id}）`);
    ids.add(g.id);
  }
  const callbackOf = (value: unknown, own: unknown): unknown => (typeof own === "function" ? own : typeof value === "function" ? value : undefined);
  return {
    product: { name: stringOf(product.name, "product.name", "商品"), sku: stringOf(product.sku, "product.sku", "") },
    model: {
      src: srcOf(model.src, "model.src"),
      scale: numberOf(model.scale, "model.scale", LIMITS.scale.min, LIMITS.scale.max, 1),
      rotation: rotationRaw as [number, number, number],
      camera: {
        distance: numberOf(camera.distance, "model.camera.distance", 0.1, 1000, 2.6),
        elevation: numberOf(camera.elevation, "model.camera.elevation", -89, 89, 18),
        azimuth: numberOf(camera.azimuth, "model.camera.azimuth", -360, 360, -35),
      },
    },
    scene: {
      background: colorOf(scene.background, "scene.background", "#f4efe6"),
      floor: colorOf(scene.floor, "scene.floor", "#e8e2d6"),
      autoRotate: booleanOf(scene.autoRotate, "scene.autoRotate", false),
      src: srcOf(scene.src, "scene.src"),
    },
    price: {
      base: numberOf(price.base, "price.base", 0, LIMITS.price * 100, 0, true),
      currency: stringOf(price.currency, "price.currency", "JPY"),
      note: stringOf(price.note, "price.note", ""),
    },
    groups,
    features: {
      export: booleanOf(features.export, "features.export", true),
      share: booleanOf(features.share, "features.share", true),
      copy: booleanOf(features.copy, "features.copy", true),
    },
    labels: labelsOf(root.labels),
    onChange: callbackOf(root.onChange, callbacks.onChange) as ResolvedConfig["onChange"],
    onExport: callbackOf(root.onExport, callbacks.onExport) as ResolvedConfig["onExport"],
  };
}

/** model.src を省いたときに読む見本（page/ と embed/ に同梱） */
export const DEFAULT_MODEL_SRC = "./tumbler.glb";
