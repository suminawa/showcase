/**
 * 売り物: 刻印とロゴを 1 枚のラベル（1024×512）に描く手順。
 * 2D context のうち使うものだけを型にして、DOM なしでテストする。
 */
import type { ResolvedConfig } from "./config";
import type { SelectionState } from "./selection";

export const LABEL_WIDTH = 1024;
export const LABEL_HEIGHT = 512;
const TEXT_MAX_WIDTH = 900;
const FONT_BASE = 160;
const FONT_MIN = 40;

export interface Draw2D {
  fillStyle: string | CanvasGradient | CanvasPattern;
  font: string;
  textAlign: CanvasTextAlign;
  textBaseline: CanvasTextBaseline;
  fillRect(x: number, y: number, w: number, h: number): void;
  fillText(text: string, x: number, y: number): void;
  measureText(text: string): { width: number };
  drawImage(image: CanvasImageSource, x: number, y: number, w: number, h: number): void;
  clearRect(x: number, y: number, w: number, h: number): void;
}

export interface LabelImage {
  source: CanvasImageSource;
  width: number;
  height: number;
}

export interface LabelInput {
  background: string;
  text?: { value: string; color: string; font: string } | null;
  image?: LabelImage | null;
}

/** 幅に収まる文字の大きさ。base から 4px ずつ下げ、min で止まる */
export function fitFontSize(measure: (font: string) => number, text: string, maxWidth: number, base = FONT_BASE, min = FONT_MIN): number {
  for (let size = base; size > min; size -= 4) {
    if (measure(`bold ${size}px sans-serif`) <= maxWidth) return size;
  }
  return min;
}

/** 縦横比を保って箱に収め、中央に置く */
export function fitRect(w: number, h: number, boxW: number, boxH: number): { x: number; y: number; w: number; h: number } {
  const scale = Math.min(boxW / w, boxH / h);
  const fw = Math.round(w * scale);
  const fh = Math.round(h * scale);
  return { x: Math.round((boxW - fw) / 2), y: Math.round((boxH - fh) / 2), w: fw, h: fh };
}

export function drawLabel(ctx: Draw2D, input: LabelInput, width = LABEL_WIDTH, height = LABEL_HEIGHT): void {
  ctx.fillStyle = input.background;
  ctx.fillRect(0, 0, width, height);
  const text = input.text?.value.trim() ?? "";
  if (input.text && text !== "") {
    const font = input.text.font;
    const size = fitFontSize(
      (probe) => {
        ctx.font = probe.replace("sans-serif", font);
        return ctx.measureText(text).width;
      },
      text,
      Math.min(TEXT_MAX_WIDTH, width - 60),
    );
    ctx.font = `bold ${size}px ${font}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = input.text.color;
    // 画像があるときは文字を下に寄せ、画像を上に置く
    const y = input.image ? Math.round(height * 0.74) : Math.round(height / 2);
    ctx.fillText(text, Math.round(width / 2), y);
  }
  if (input.image) {
    const box = text !== "" ? { x: 0, y: 0, w: width, h: Math.round(height * 0.5) } : { x: 0, y: 0, w: width, h: height };
    const pad = 32;
    const rect = fitRect(input.image.width, input.image.height, box.w - pad * 2, box.h - pad * 2);
    ctx.drawImage(input.image.source, box.x + pad + rect.x, box.y + pad + rect.y, rect.w, rect.h);
  }
}

/** 対象メッシュ名ごとに、いま描くべきラベル。刻印とロゴが同じ対象なら 1 つにまとめる。何も無ければ入れない */
export function labelInputsOf(
  config: ResolvedConfig,
  state: SelectionState,
  images: Record<string, LabelImage | null | undefined>,
): Record<string, LabelInput> {
  const out: Record<string, LabelInput> = {};
  const ensure = (name: string, background: string): LabelInput => (out[name] ??= { background, text: null, image: null });
  for (const group of config.groups) {
    if (group.type === "text") {
      const value = state[group.id] ?? "";
      if (typeof value !== "string" || value.trim() === "") continue;
      for (const name of group.target) ensure(name, group.background).text = { value, color: group.color, font: group.font };
    } else if (group.type === "image") {
      const image = state[group.id] === null ? null : images[group.id];
      if (!image) continue;
      for (const name of group.target) ensure(name, group.background).image = image;
    }
  }
  return out;
}
