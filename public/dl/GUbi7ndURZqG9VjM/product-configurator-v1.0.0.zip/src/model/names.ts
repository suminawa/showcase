import type { ResolvedConfig } from "./config";

/** 設定が target / show / hide で参照するメッシュ名（出てきた順、重複なし） */
export function referencedNames(config: ResolvedConfig): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  const add = (name: string) => {
    if (!seen.has(name)) {
      seen.add(name);
      out.push(name);
    }
  };
  for (const group of config.groups) {
    if (group.type === "variant") {
      for (const option of group.options) {
        option.show.forEach(add);
        option.hide.forEach(add);
      }
    } else {
      group.target.forEach(add);
    }
  }
  return out;
}

/** 設定にあってモデルに無い名前 */
export function missingNames(config: ResolvedConfig, meshNames: string[]): string[] {
  const have = new Set(meshNames);
  return referencedNames(config).filter((name) => !have.has(name));
}
