import { describe, expect, it } from "vitest";
import { fakeContext } from "../../test/fake-context";
import { resolveConfig } from "./config";
import { drawLabel, fitFontSize, fitRect, LABEL_HEIGHT, LABEL_WIDTH, labelInputsOf } from "./texture";

describe("fitFontSize / fitRect", () => {
  it("収まる大きさまで縮め、下限で止まる", () => {
    const measure = (font: string, text: string) => text.length * Number(/(\d+)px/.exec(font)?.[1]) * 0.6;
    expect(fitFontSize((font) => measure(font, "AB"), "AB", 900)).toBe(160);
    expect(fitFontSize((font) => measure(font, "ABCDEFGHIJKL"), "ABCDEFGHIJKL", 900)).toBe(124);
    expect(fitFontSize((font) => measure(font, "A".repeat(60)), "A".repeat(60), 900)).toBe(40);
  });
  it("縦横比を保って箱に収め、中央に置く", () => {
    expect(fitRect(200, 100, 400, 400)).toEqual({ x: 0, y: 100, w: 400, h: 200 });
    expect(fitRect(100, 200, 400, 400)).toEqual({ x: 100, y: 0, w: 200, h: 400 });
  });
});

describe("drawLabel", () => {
  it("背景 → 文字（中央）→ 画像（上に重ねる）の順に描く", () => {
    const ctx = fakeContext();
    drawLabel(ctx, { background: "#ffffff", text: { value: "SUMI", color: "#1c1a15", font: "serif" }, image: { source: {} as CanvasImageSource, width: 200, height: 100 } });
    expect(ctx.calls[0]).toBe(`fillRect 0 0 ${LABEL_WIDTH} ${LABEL_HEIGHT} #ffffff`);
    // 画像があるときは文字を 74 % の高さに置く（379）。y を固定して、値が変わったら気づけるようにする
    expect(ctx.calls[1]).toBe(`fillText "SUMI" 512 ${Math.round(LABEL_HEIGHT * 0.74)} bold 160px serif #1c1a15`);
    expect(ctx.calls[2]).toMatch(/^drawImage /);
    expect(ctx.textAlign).toBe("center");
  });
  it("文字が空なら描かず、画像も無ければ背景だけ", () => {
    const ctx = fakeContext();
    drawLabel(ctx, { background: "#ffffff", text: { value: "  ", color: "#000000", font: "sans-serif" } });
    expect(ctx.calls).toHaveLength(1);
  });
});

describe("labelInputsOf", () => {
  const config = resolveConfig({
    groups: [
      { id: "engrave", label: "刻印", type: "text", target: ["label"], color: "#333333", font: "serif", background: "#f4efe6" },
      { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
      { id: "tag", label: "タグ", type: "text", target: ["tag"] },
    ],
  });
  it("対象メッシュごとに 1 つ。同じ対象の刻印とロゴは重ねる。何も無い対象は入らない", () => {
    const image = { source: {} as CanvasImageSource, width: 10, height: 10 };
    const inputs = labelInputsOf(config, { engrave: "AB", logo: "1", tag: "" }, { logo: image });
    expect(Object.keys(inputs)).toEqual(["label"]);
    expect(inputs.label.background).toBe("#f4efe6");
    expect(inputs.label.text?.value).toBe("AB");
    expect(inputs.label.text?.font).toBe("serif");
    expect(inputs.label.image).toBe(image);
    expect(labelInputsOf(config, { engrave: "", logo: null, tag: "" }, {})).toEqual({});
  });
});
