import { useMemo, useRef } from "react";
import { resolveConfig, type ConfiguratorConfig, type ExportResult } from "../model/config";
import type { SelectionJson } from "../model/selection";
import { Configurator, type ConfiguratorApi } from "../ui/Configurator";
import { downloadBlob } from "../ui/export";

export type ProductConfiguratorProps = {
  /** 参照が変わると作り直す（選択も最初に戻る）。定数か useMemo で渡すこと */
  config: ConfiguratorConfig;
  onChange?: (selection: SelectionJson) => void;
  /** 渡すと PNG はダウンロードされず、ここへ来る */
  onExport?: (result: ExportResult) => void;
  className?: string;
  handleRef?: (api: ConfiguratorApi) => void;
};

/** vanilla と同じ Configurator を描くだけの薄いラッパー */
export function ProductConfigurator({ config, onChange, onExport, className, handleRef }: ProductConfiguratorProps) {
  // 呼び返しは毎回の描画で変わりうるので、ref 経由で呼ぶ（config の参照を保つため）
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;
  const onExportRef = useRef(onExport);
  onExportRef.current = onExport;
  const resolved = useMemo(
    () =>
      resolveConfig(config, {
        onChange: (selection) => {
          config.onChange?.(selection);
          onChangeRef.current?.(selection);
        },
        onExport: (result) => {
          if (config.onExport || onExportRef.current) {
            config.onExport?.(result);
            onExportRef.current?.(result);
          } else {
            downloadBlob(result.blob, result.name, document);
          }
        },
      }),
    [config],
  );
  return <Configurator config={resolved} className={className} handleRef={handleRef} />;
}
