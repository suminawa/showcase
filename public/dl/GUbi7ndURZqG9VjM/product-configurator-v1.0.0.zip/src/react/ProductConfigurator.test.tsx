import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { SelectionJson } from "../model/selection";
import { ProductConfigurator } from "./ProductConfigurator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const CONFIG = {
  product: { name: "タンブラー", sku: "TB-01" },
  price: { base: 3800 },
  groups: [{ id: "body", label: "色", type: "color", target: ["body"], options: [{ id: "a", label: "A", color: "#000000" }, { id: "b", label: "B", color: "#111111", price: 200 }] }],
};

const click = (el: Element) =>
  act(() => {
    el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  });

afterEach(() => {
  document.body.innerHTML = "";
});

describe("ProductConfigurator", () => {
  it("同じ config のまま onChange を差し替えても、選択は保たれ、新しい onChange が呼ばれる", () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const first = vi.fn();
    const second = vi.fn();
    act(() => {
      root.render(<ProductConfigurator config={CONFIG} onChange={first} />);
    });
    const b = [...container.querySelectorAll("button")].find((el) => el.textContent?.trim().startsWith("B"))!;
    click(b);
    expect(first).toHaveBeenCalledTimes(1);
    expect((first.mock.calls[0][0] as SelectionJson).price.total).toBe(4000);
    act(() => {
      root.render(<ProductConfigurator config={CONFIG} onChange={second} />);
    });
    expect(container.querySelector(".pc-price-total")!.textContent).toBe("￥4,000");
    const a = [...container.querySelectorAll("button")].find((el) => el.textContent?.trim().startsWith("A"))!;
    click(a);
    expect(second).toHaveBeenCalledTimes(1);
    expect(first).toHaveBeenCalledTimes(1);
    act(() => root.unmount());
  });

  it("config の中の onChange も一緒に呼ぶ", () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const inner = vi.fn();
    const outer = vi.fn();
    const config = { ...CONFIG, onChange: inner };
    act(() => {
      root.render(<ProductConfigurator config={config} onChange={outer} />);
    });
    click([...container.querySelectorAll("button")].find((el) => el.textContent?.trim().startsWith("B"))!);
    expect(inner).toHaveBeenCalledTimes(1);
    expect(outer).toHaveBeenCalledTimes(1);
    act(() => root.unmount());
  });
});
