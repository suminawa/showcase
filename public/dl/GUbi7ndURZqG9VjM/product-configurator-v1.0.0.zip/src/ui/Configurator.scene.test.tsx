import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { resolveConfig } from "../model/config";
import { Configurator } from "./Configurator";

const loadScene = vi.fn();
vi.mock("../scene/loader", async (importOriginal) => ({ ...(await importOriginal<typeof import("../scene/loader")>()), loadScene: (...args: unknown[]) => loadScene(...args) }));

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const config = resolveConfig({ groups: [{ id: "body", label: "色", type: "color", target: ["body"], options: [{ id: "a", label: "A", color: "#000000" }] }] });

function fakeWebgl() {
  vi.stubGlobal("WebGLRenderingContext", class {});
  vi.spyOn(window.HTMLCanvasElement.prototype, "getContext").mockReturnValue({} as never);
}

async function mount() {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  await act(async () => {
    root.render(<Configurator config={config} />);
  });
  return { container, root };
}

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = "";
  loadScene.mockReset();
});

describe("3D の束の読み込み", () => {
  it("読めなければ「読み込めませんでした」を出す", async () => {
    fakeWebgl();
    loadScene.mockRejectedValue(new Error("chunk"));
    const { container, root } = await mount();
    await act(async () => {});
    expect(container.querySelector(".pc-stage-message")!.textContent).toBe(config.labels.loadError);
    act(() => root.unmount());
  });
  it("束が無ければ「見つかりません」を出す", async () => {
    fakeWebgl();
    loadScene.mockResolvedValue(null);
    const { container, root } = await mount();
    await act(async () => {});
    expect(container.querySelector(".pc-stage-message")!.textContent).toBe(config.labels.sceneMissing);
    act(() => root.unmount());
  });
});
