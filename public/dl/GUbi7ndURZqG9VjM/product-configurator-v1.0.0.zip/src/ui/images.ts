import type { ConfiguratorLabels, ImageGroup } from "../model/config";
import type { ImageMeta } from "../model/selection";
import type { LabelImage } from "../model/texture";

/** 受け付ける画像。input[type=file] の accept にもそのまま使う */
export const ACCEPT = "image/png,image/jpeg,image/svg+xml";
const TYPES = new Set(ACCEPT.split(","));

export interface LoadedImage {
  meta: ImageMeta;
  image: LabelImage;
  /** URL.createObjectURL の結果。外すときと unmount で revoke する */
  url: string;
}

export function formatBytes(bytes: number): string {
  if (bytes >= 1_000_000) {
    const mb = bytes / 1_000_000;
    return `${Number.isInteger(mb) ? mb : mb.toFixed(1)} MB`;
  }
  if (bytes >= 1000) return `${Math.round(bytes / 1000)} KB`;
  return `${bytes} B`;
}

/** 問題なければ null、あれば画面に出す文言 */
export function validateImage(file: { type: string; size: number }, group: ImageGroup, labels: ConfiguratorLabels): string | null {
  if (!TYPES.has(file.type)) return labels.imageType;
  if (file.size > group.maxBytes) return labels.imageTooLarge.replace("{max}", formatBytes(group.maxBytes));
  return null;
}

/** ブラウザの中だけで画像を読む（どこにも送らない）。SVG に寸法が無いときは 512 四方とみなす */
export function loadImage(file: File, win: Window & typeof globalThis): Promise<LoadedImage> {
  return new Promise((resolve, reject) => {
    const url = win.URL.createObjectURL(file);
    const image = new win.Image();
    image.onload = () =>
      resolve({
        meta: { name: file.name, type: file.type, size: file.size },
        image: { source: image, width: image.naturalWidth || 512, height: image.naturalHeight || 512 },
        url,
      });
    image.onerror = () => {
      win.URL.revokeObjectURL(url);
      reject(new Error("product-configurator: 画像を読めませんでした"));
    };
    image.src = url;
  });
}
