import { useId, type CSSProperties } from "react";
import type { Group, ResolvedConfig } from "../model/config";
import { formatPrice, type PriceBreakdown } from "../model/price";
import type { ImageMeta, SelectionState } from "../model/selection";
import { ACCEPT, formatBytes } from "./images";

export type PanelProps = {
  config: ResolvedConfig;
  state: SelectionState;
  errors: Record<string, string | null>;
  images: Record<string, ImageMeta | null>;
  price: PriceBreakdown;
  notice: string | null;
  busy: boolean;
  canExport: boolean;
  onSelect(groupId: string, optionId: string | null): void;
  onText(groupId: string, value: string): void;
  onImage(groupId: string, file: File | null): void;
  onCopy(): void;
  onExport(): void;
  onShare(): void;
  onReset(): void;
};

/** 差額の表示。0 なら空 */
function signed(amount: number, currency: string): string {
  if (amount === 0) return "";
  return `${amount > 0 ? "+" : "−"}${formatPrice(Math.abs(amount), currency)}`;
}

export function Panel({ config, state, errors, images, price, notice, busy, canExport, onSelect, onText, onImage, onCopy, onExport, onShare, onReset }: PanelProps) {
  const { labels } = config;
  const currency = config.price.currency;
  // 誤りの id は Panel を 2 つ置いても衝突しないよう、コンポーネントごとに一意な接頭辞を付ける
  const uid = useId();
  const errorId = (groupId: string) => `${uid}-error-${groupId}`;

  const renderOptions = (group: Extract<Group, { options: unknown[] }>) => (
    <div className="pc-options">
      {group.options.map((option) => {
        const pressed = state[group.id] === option.id;
        const isColor = group.type === "color" || group.type === "material";
        return (
          <button
            key={option.id}
            type="button"
            className={isColor ? "pc-swatch" : "pc-chip"}
            aria-pressed={pressed}
            title={option.label}
            style={isColor ? ({ "--pc-swatch": (option as { color: string }).color } as CSSProperties) : undefined}
            onClick={() => onSelect(group.id, option.id)}
          >
            {isColor && <span className="pc-swatch-dot" aria-hidden="true" />}
            <span className="pc-option-label">{option.label}</span>
            {option.price !== 0 && <span className="pc-option-price">{signed(option.price, currency)}</span>}
          </button>
        );
      })}
      {!group.required && (
        <button type="button" className="pc-chip" aria-pressed={state[group.id] === null} onClick={() => onSelect(group.id, null)}>
          <span className="pc-option-label">{labels.none}</span>
        </button>
      )}
    </div>
  );

  const renderGroup = (group: Group) => {
    if (group.type === "text") {
      const value = state[group.id] ?? "";
      const errId = errorId(group.id);
      return (
        <>
          <label className="pc-field">
            <input
              className="pc-input"
              type="text"
              value={value}
              maxLength={group.maxChars}
              placeholder={group.placeholder}
              aria-label={group.label}
              onChange={(event) => onText(group.id, event.target.value)}
              aria-invalid={errors[group.id] ? true : undefined}
              aria-describedby={errors[group.id] ? errId : undefined}
            />
            <span className="pc-count">
              {value.length}/{group.maxChars}
            </span>
            {group.price !== 0 && <span className="pc-option-price">{signed(group.price, currency)}</span>}
          </label>
          {errors[group.id] && (
            <p id={errId} className="pc-error" role="alert">
              {errors[group.id]}
            </p>
          )}
        </>
      );
    }
    if (group.type === "image") {
      const meta = images[group.id] ?? null;
      const errId = errorId(group.id);
      return (
        <>
          <label className="pc-file">
            <input
              type="file"
              accept={ACCEPT}
              aria-label={group.label}
              aria-describedby={errors[group.id] ? errId : undefined}
              onChange={(event) => {
                const file = event.target.files?.[0] ?? null;
                event.target.value = "";
                onImage(group.id, file);
              }}
            />
            {group.price !== 0 && <span className="pc-option-price">{signed(group.price, currency)}</span>}
          </label>
          {meta && (
            <p className="pc-preview">
              {meta.name}（{formatBytes(meta.size)}）
              <button type="button" className="pc-link" onClick={() => onImage(group.id, null)}>
                {labels.imageClear}
              </button>
            </p>
          )}
          {errors[group.id] && (
            <p id={errId} className="pc-error" role="alert">
              {errors[group.id]}
            </p>
          )}
        </>
      );
    }
    return renderOptions(group);
  };

  return (
    <div className="pc-panel">
      <h2 className="pc-title">{config.product.name}</h2>
      {config.groups.map((group) => (
        <fieldset key={group.id} className="pc-group">
          <legend className="pc-group-title">{group.label}</legend>
          {renderGroup(group)}
        </fieldset>
      ))}
      <div className="pc-price" aria-live="polite">
        <span className="pc-price-label">{labels.price}</span>
        <strong className="pc-price-total">{formatPrice(price.total, currency)}</strong>
        {price.delta !== 0 && (
          <span className="pc-price-delta">
            {formatPrice(price.base, currency)} {signed(price.delta, currency)}
          </span>
        )}
        {config.price.note && <span className="pc-price-note">{config.price.note}</span>}
      </div>
      <div className="pc-actions">
        {config.features.copy && (
          <button type="button" className="pc-button" onClick={onCopy}>
            {labels.copy}
          </button>
        )}
        {config.features.export && (
          <button type="button" className="pc-button" onClick={onExport} disabled={!canExport || busy}>
            {labels.export}
          </button>
        )}
        {config.features.share && (
          <button type="button" className="pc-button" onClick={onShare}>
            {labels.share}
          </button>
        )}
        <button type="button" className="pc-button pc-button-quiet" onClick={onReset}>
          {labels.reset}
        </button>
      </div>
      <p className="pc-notice" role="status" aria-live="polite">
        {notice ?? ""}
      </p>
    </div>
  );
}
