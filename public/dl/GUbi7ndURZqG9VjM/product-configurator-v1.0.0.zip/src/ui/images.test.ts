import { describe, expect, it, vi } from "vitest";
import { DEFAULT_LABELS, resolveConfig } from "../model/config";
import { formatBytes, loadImage, validateImage } from "./images";

const config = resolveConfig({ groups: [{ id: "logo", label: "ロゴ", type: "image", target: ["label"], maxBytes: 2048 }] });
const group = config.groups[0];
if (group.type !== "image") throw new Error();

describe("formatBytes", () => {
  it("MB / KB / B", () => {
    expect(formatBytes(2_000_000)).toBe("2 MB");
    expect(formatBytes(1_500_000)).toBe("1.5 MB");
    expect(formatBytes(2048)).toBe("2 KB");
    expect(formatBytes(512)).toBe("512 B");
  });
});

describe("validateImage", () => {
  it("種類と大きさ", () => {
    expect(validateImage({ type: "image/png", size: 100 }, group, DEFAULT_LABELS)).toBeNull();
    expect(validateImage({ type: "image/svg+xml", size: 100 }, group, DEFAULT_LABELS)).toBeNull();
    expect(validateImage({ type: "image/gif", size: 100 }, group, DEFAULT_LABELS)).toBe(DEFAULT_LABELS.imageType);
    expect(validateImage({ type: "image/png", size: 4096 }, group, DEFAULT_LABELS)).toBe("画像は 2 KB 以下にしてください。");
  });
});

describe("loadImage", () => {
  it("object URL を作り、Image が読めたら名前・種類・大きさと元の画像を返す", async () => {
    class FakeImage {
      onload: (() => void) | null = null;
      onerror: (() => void) | null = null;
      naturalWidth = 300;
      naturalHeight = 150;
      set src(_value: string) {
        queueMicrotask(() => this.onload?.());
      }
    }
    const win = {
      URL: { createObjectURL: vi.fn().mockReturnValue("blob:x"), revokeObjectURL: vi.fn() },
      Image: FakeImage,
    } as unknown as Window & typeof globalThis;
    const file = new File(["png"], "logo.png", { type: "image/png" });
    const loaded = await loadImage(file, win);
    expect(loaded.meta).toEqual({ name: "logo.png", type: "image/png", size: 3 });
    expect(loaded.image.width).toBe(300);
    expect(loaded.image.height).toBe(150);
    expect(loaded.url).toBe("blob:x");
  });
  it("読めなければ URL を手放して reject", async () => {
    class FakeImage {
      onload: (() => void) | null = null;
      onerror: (() => void) | null = null;
      set src(_value: string) {
        queueMicrotask(() => this.onerror?.());
      }
    }
    const revoke = vi.fn();
    const win = { URL: { createObjectURL: () => "blob:y", revokeObjectURL: revoke }, Image: FakeImage } as unknown as Window & typeof globalThis;
    await expect(loadImage(new File(["x"], "a.png", { type: "image/png" }), win)).rejects.toThrow();
    expect(revoke).toHaveBeenCalledWith("blob:y");
  });
});
