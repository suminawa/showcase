import { afterEach, describe, expect, it, vi } from "vitest";
import { resolveConfig } from "../model/config";
import { decodeShare } from "../model/selection";
import { copyText, shareUrl } from "./share";

const config = resolveConfig({ groups: [{ id: "body", label: "色", type: "color", target: ["body"], options: [{ id: "a", label: "a", color: "#000000" }, { id: "b", label: "b", color: "#111111" }] }] });

describe("shareUrl", () => {
  it("いまのページに hash を付ける。query は残す", () => {
    const url = shareUrl(config, { body: "b" }, { origin: "https://example.com", pathname: "/item/1", search: "?ref=x" });
    expect(url.startsWith("https://example.com/item/1?ref=x#pc=")).toBe(true);
    expect(decodeShare(config, new URL(url).hash)).toEqual({ body: "b" });
  });
});

describe("copyText", () => {
  afterEach(() => {
    delete (window.navigator as { clipboard?: unknown }).clipboard;
    vi.restoreAllMocks();
  });
  it("clipboard があればそれを使う", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(window.navigator, "clipboard", { value: { writeText }, configurable: true });
    expect(await copyText("abc", window)).toBe(true);
    expect(writeText).toHaveBeenCalledWith("abc");
  });
  it("clipboard が無ければ textarea と execCommand に落ちる", async () => {
    const exec = vi.fn().mockReturnValue(true);
    (document as unknown as { execCommand: unknown }).execCommand = exec;
    expect(await copyText("abc", window)).toBe(true);
    expect(exec).toHaveBeenCalledWith("copy");
    expect(document.querySelector("textarea")).toBeNull();
  });
});
