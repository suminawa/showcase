import type { ResolvedConfig } from "../model/config";
import { encodeShare, type SelectionState } from "../model/selection";

/** いまのページの URL に選択を hash で付ける。画像は含めない（encodeShare が落とす） */
export function shareUrl(
  config: ResolvedConfig,
  state: SelectionState,
  location: { origin: string; pathname: string; search: string },
): string {
  return `${location.origin}${location.pathname}${location.search}${encodeShare(config, state)}`;
}

/** clipboard に書く。使えないブラウザでは textarea を選んで execCommand に落ちる */
export async function copyText(text: string, win: Window & typeof globalThis): Promise<boolean> {
  try {
    if (win.navigator?.clipboard?.writeText) {
      await win.navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // 下の手に落ちる
  }
  try {
    const doc = win.document;
    const area = doc.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    doc.body.append(area);
    area.select();
    const ok = doc.execCommand("copy");
    area.remove();
    return ok;
  } catch {
    return false;
  }
}
