import { describe, expect, it, vi } from "vitest";
import { exportFileName, sanitizeName, snapshotCanvas, toPng } from "./export";

describe("sanitizeName / exportFileName", () => {
  it("記号を落とし、長さを 40 に切り、空なら「商品」", () => {
    expect(sanitizeName('a/b:c*"d')).toBe("a-b-c--d");
    expect(sanitizeName("////")).toBe("商品");
    expect(sanitizeName("あ".repeat(50))).toHaveLength(40);
    expect(exportFileName("ステンレスタンブラー")).toBe("ステンレスタンブラー-カスタマイズ.png");
  });
});

describe("snapshotCanvas / toPng（jsdom には 2D context が無い）", () => {
  it("中身の無い canvas は null", () => {
    // jsdom の canvas は既定で 300×150 なので、空にしてから渡す（getContext まで進ませない）
    const canvas = document.createElement("canvas");
    canvas.width = 0;
    canvas.height = 0;
    expect(snapshotCanvas(canvas, document)).toBeNull();
  });
  it("2D context が取れなければ null", async () => {
    // jsdom の getContext は「未実装」の行を出すので、null を返す偽物に差し替えて出力を静かに保つ
    const spy = vi.spyOn(window.HTMLCanvasElement.prototype, "getContext").mockReturnValue(null);
    const source = document.createElement("canvas");
    source.width = 10;
    source.height = 5;
    expect(await toPng(source, "#ffffff", document)).toBeNull();
    spy.mockRestore();
  });
});
