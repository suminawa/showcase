import { act, StrictMode } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { resolveConfig, type ResolvedConfig } from "../model/config";
import { encodeShare, type SelectionJson } from "../model/selection";
import { Configurator, type ConfiguratorApi } from "./Configurator";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const BASE = {
  product: { name: "ステンレスタンブラー", sku: "TB-01" },
  price: { base: 3800, currency: "JPY", note: "税込" },
  groups: [
    { id: "body", label: "本体の色", type: "color", target: ["body"], required: true,
      options: [{ id: "navy", label: "ネイビー", color: "#243a5e" }, { id: "black", label: "黒", color: "#1c1a15", price: 200 }] },
    { id: "strap", label: "ストラップ", type: "variant", options: [{ id: "leather", label: "革", show: ["strap"], price: 600 }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"], maxChars: 12, pattern: "[A-Za-z0-9 ]*", price: 500 },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"], price: 800, maxBytes: 2048 },
  ],
};

let roots: Root[] = [];

function mount(config: ResolvedConfig = resolveConfig(BASE)) {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  roots.push(root);
  let handle: ConfiguratorApi | null = null;
  act(() => {
    root.render(<Configurator config={config} handleRef={(api) => (handle = api)} />);
  });
  return { container, root, get handle() { return handle as unknown as ConfiguratorApi; } };
}

function mountStrict(config: ResolvedConfig) {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  roots.push(root);
  act(() => {
    root.render(
      <StrictMode>
        <Configurator config={config} />
      </StrictMode>,
    );
  });
  return { container };
}

const click = (el: Element) =>
  act(() => {
    el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  });
const buttonNamed = (c: HTMLElement, text: string) =>
  [...c.querySelectorAll("button")].find((b) => b.textContent?.trim().startsWith(text))!;
const total = (c: HTMLElement) => c.querySelector(".pc-price-total")!.textContent;
const errorText = (c: HTMLElement) => c.querySelector(".pc-error")?.textContent ?? null;

/** 制御された input に値を入れる。ネイティブの setter を呼ばないと React の onChange が走らない */
function typeInto(input: HTMLInputElement, value: string) {
  act(() => {
    const setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")!.set!;
    setValue.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

function chooseFile(input: HTMLInputElement, file: File) {
  Object.defineProperty(input, "files", { value: [file], configurable: true });
  act(() => {
    input.dispatchEvent(new Event("change", { bubbles: true }));
  });
}

beforeEach(() => {
  vi.useFakeTimers();
  window.location.hash = "";
});

afterEach(() => {
  act(() => {
    vi.runOnlyPendingTimers();
  });
  for (const root of roots) act(() => root.unmount());
  roots = [];
  document.body.innerHTML = "";
  delete (window.navigator as { clipboard?: unknown }).clipboard;
  delete (window.URL as { createObjectURL?: unknown }).createObjectURL;
  delete (window.URL as { revokeObjectURL?: unknown }).revokeObjectURL;
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("Configurator", () => {
  it("商品名・群・価格を描き、WebGL の無い環境では断りを出す", () => {
    const { container } = mount();
    expect(container.querySelector(".pc-title")!.textContent).toBe("ステンレスタンブラー");
    expect([...container.querySelectorAll(".pc-group-title")].map((e) => e.textContent)).toEqual(["本体の色", "ストラップ", "刻印", "ロゴ"]);
    expect(total(container)).toBe("￥3,800");
    expect(container.querySelector(".pc-price-note")!.textContent).toBe("税込");
    expect(container.querySelector(".pc-stage-message")!.textContent).toBe("この端末では 3D を表示できません。");
  });

  it("material の群も color と同じく色の見本（.pc-swatch）で出す", () => {
    const withMaterial = resolveConfig({
      ...BASE,
      groups: [
        ...BASE.groups,
        { id: "lid", label: "フタ", type: "material", target: ["lid"], options: [{ id: "steel", label: "ステンレス", color: "#b8b8b8", roughness: 0.35, metalness: 0.9 }] },
      ],
    });
    const { container } = mount(withMaterial);
    expect(buttonNamed(container, "ステンレス").classList.contains("pc-swatch")).toBe(true);
  });

  it("選択肢を押すと価格が変わり、aria-pressed が付き、onChange に選択 JSON が届く", () => {
    const onChange = vi.fn();
    const { container } = mount(resolveConfig(BASE, { onChange }));
    click(buttonNamed(container, "黒"));
    expect(total(container)).toBe("￥4,000");
    expect(buttonNamed(container, "黒").getAttribute("aria-pressed")).toBe("true");
    expect(buttonNamed(container, "ネイビー").getAttribute("aria-pressed")).toBe("false");
    expect(onChange).toHaveBeenCalledTimes(1);
    const json = onChange.mock.calls[0][0] as SelectionJson;
    expect(json.product).toBe("TB-01");
    expect(json.selection.body).toBe("black");
    expect(json.price.total).toBe(4000);
  });

  it("任意の群は「なし」が既定。選ぶと足し、戻すと引く", () => {
    const { container } = mount();
    expect(buttonNamed(container, "なし").getAttribute("aria-pressed")).toBe("true");
    click(buttonNamed(container, "革"));
    expect(total(container)).toBe("￥4,400");
    click(buttonNamed(container, "なし"));
    expect(total(container)).toBe("￥3,800");
  });

  it("刻印: 使える文字だけ受け、上限は maxLength、文字があれば価格に足す", () => {
    const { container } = mount();
    const input = container.querySelector<HTMLInputElement>(".pc-input")!;
    expect(input.maxLength).toBe(12);
    typeInto(input, "SUMI");
    expect(input.value).toBe("SUMI");
    expect(total(container)).toBe("￥4,300");
    typeInto(input, "SUMIあ");
    expect(input.value).toBe("SUMI");
    expect(errorText(container)).toBe("使える文字は英数字と記号（. & -）、空白です。");
    typeInto(input, "SUMI 2");
    expect(errorText(container)).toBeNull();
    expect(container.querySelector(".pc-count")!.textContent).toBe("6/12");
  });

  it("画像: 種類と大きさを検査して断る", () => {
    const { container } = mount();
    const input = container.querySelector<HTMLInputElement>('input[type="file"]')!;
    expect(input.accept).toBe("image/png,image/jpeg,image/svg+xml");
    chooseFile(input, new File(["x"], "a.txt", { type: "text/plain" }));
    expect(errorText(container)).toBe("PNG・JPEG・SVG の画像を選んでください。");
    chooseFile(input, new File([new Uint8Array(4096)], "b.png", { type: "image/png" }));
    expect(errorText(container)).toBe("画像は 2 KB 以下にしてください。");
    expect(total(container)).toBe("￥3,800");
  });

  it("取っ手: getSelection / setSelection / getPrice / reset / shareUrl / subscribe", () => {
    const { container, handle } = mount();
    expect(handle.getSelection().product).toBe("TB-01");
    const seen: SelectionJson[] = [];
    const off = handle.subscribe((s) => seen.push(s));
    act(() => handle.setSelection({ body: "black", strap: "leather", extra: "x" }));
    expect(handle.getPrice().total).toBe(4600);
    expect(total(container)).toBe("￥4,600");
    expect(seen).toHaveLength(1);
    expect(seen[0].selection).toEqual({ body: "black", strap: "leather", engrave: "", logo: null });
    expect(handle.shareUrl()).toContain("#pc=");
    off();
    act(() => handle.reset());
    expect(total(container)).toBe("￥3,800");
    expect(seen).toHaveLength(1);
  });

  it("共有 URL の hash があれば、その選択で始まる", () => {
    const config = resolveConfig(BASE);
    window.location.hash = encodeShare(config, { body: "black", strap: "leather", engrave: "AB", logo: null });
    const { container } = mount(config);
    expect(total(container)).toBe("￥5,100");
    expect(container.querySelector<HTMLInputElement>(".pc-input")!.value).toBe("AB");
  });

  it("コピーは clipboard に選択 JSON を書き、2 秒だけ知らせる", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(window.navigator, "clipboard", { value: { writeText }, configurable: true });
    const { container } = mount();
    await act(async () => {
      buttonNamed(container, "選択内容をコピー").dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });
    expect(writeText).toHaveBeenCalledWith(expect.stringContaining('"product": "TB-01"'));
    expect(container.querySelector(".pc-notice")!.textContent).toBe("コピーしました");
    act(() => {
      vi.advanceTimersByTime(2000);
    });
    expect(container.querySelector(".pc-notice")!.textContent).toBe("");
  });

  it("3D が無いあいだ PNG のボタンは押せず、exportPng は null", async () => {
    const { container, handle } = mount();
    expect(buttonNamed(container, "PNG で保存").disabled).toBe(true);
    expect(await handle.exportPng()).toBeNull();
  });

  it("features で隠せる", () => {
    const { container } = mount(resolveConfig({ ...BASE, features: { export: false, share: false, copy: false } }));
    expect(container.querySelectorAll(".pc-actions button")).toHaveLength(1);
    expect(buttonNamed(container, "最初に戻す")).toBeDefined();
  });

  it("StrictMode でも最初の描画では onChange を呼ばない。そのあと選ぶと 1 回", () => {
    const onChange = vi.fn();
    const { container } = mountStrict(resolveConfig(BASE, { onChange }));
    expect(onChange).toHaveBeenCalledTimes(0);
    click(buttonNamed(container, "黒"));
    expect(onChange).toHaveBeenCalledTimes(1);
  });

  it("StrictMode でも画像を入れられる（mounted の印が二重 effect で false のままにならない）", async () => {
    class FakeImage {
      onload: (() => void) | null = null;
      onerror: (() => void) | null = null;
      naturalWidth = 300;
      naturalHeight = 150;
      set src(_value: string) {
        queueMicrotask(() => this.onload?.());
      }
    }
    vi.stubGlobal("Image", FakeImage);
    Object.defineProperty(window.URL, "createObjectURL", { value: vi.fn(() => "blob:strict"), configurable: true });
    Object.defineProperty(window.URL, "revokeObjectURL", { value: vi.fn(), configurable: true });
    const { container } = mountStrict(resolveConfig(BASE));
    chooseFile(container.querySelector<HTMLInputElement>('input[type="file"]')!, new File(["png"], "logo.png", { type: "image/png" }));
    await act(async () => {});
    expect(container.querySelector(".pc-preview")!.textContent).toContain("logo.png");
    expect(total(container)).toBe("￥4,600");
  });

  it("刻印とロゴの入力に読み上げ用の名前が付き、誤りがあれば aria-describedby で指す", () => {
    const { container } = mount();
    const textInput = container.querySelector<HTMLInputElement>(".pc-input")!;
    const fileInput = container.querySelector<HTMLInputElement>('input[type="file"]')!;
    expect(textInput.getAttribute("aria-label")).toBe("刻印");
    expect(fileInput.getAttribute("aria-label")).toBe("ロゴ");
    expect(textInput.hasAttribute("aria-describedby")).toBe(false);
    expect(fileInput.hasAttribute("aria-describedby")).toBe(false);

    // 誤りの id は Panel ごとに一意な接頭辞が付くので、固定文字列ではなく aria-describedby との一致で確かめる
    typeInto(textInput, "あ");
    const textError = container.querySelector(".pc-error")!;
    expect(textError.id).toContain("error-engrave");
    expect(textInput.getAttribute("aria-describedby")).toBe(textError.id);

    chooseFile(fileInput, new File(["x"], "a.txt", { type: "text/plain" }));
    const fileError = [...container.querySelectorAll(".pc-error")].find((el) => el.id.includes("error-logo"))!;
    expect(fileError.textContent).toBe("PNG・JPEG・SVG の画像を選んでください。");
    expect(fileInput.getAttribute("aria-describedby")).toBe(fileError.id);
  });

  it("画像を選ぶと反映され、外す・reset・unmount でそれぞれ object URL を手放す", async () => {
    class FakeImage {
      onload: (() => void) | null = null;
      onerror: (() => void) | null = null;
      naturalWidth = 300;
      naturalHeight = 150;
      set src(_value: string) {
        queueMicrotask(() => this.onload?.());
      }
    }
    vi.stubGlobal("Image", FakeImage);
    let urlCounter = 0;
    const revokeObjectURL = vi.fn();
    const createObjectURL = vi.fn(() => `blob:${++urlCounter}`);
    Object.defineProperty(window.URL, "createObjectURL", { value: createObjectURL, configurable: true });
    Object.defineProperty(window.URL, "revokeObjectURL", { value: revokeObjectURL, configurable: true });

    const { container, root, handle } = mount();
    const input = container.querySelector<HTMLInputElement>('input[type="file"]')!;
    const png = new File(["png"], "logo.png", { type: "image/png" });

    chooseFile(input, png);
    await act(async () => {});
    expect(container.querySelector(".pc-preview")!.textContent).toContain("logo.png");
    expect(total(container)).toBe("￥4,600");
    expect(handle.getSelection().selection.logo).toEqual({ name: "logo.png", type: "image/png", size: 3 });

    click(buttonNamed(container, "画像を外す"));
    expect(revokeObjectURL).toHaveBeenCalledWith("blob:1");
    expect(total(container)).toBe("￥3,800");

    chooseFile(input, png);
    await act(async () => {});
    act(() => handle.reset());
    expect(revokeObjectURL).toHaveBeenCalledWith("blob:2");

    chooseFile(input, png);
    await act(async () => {});
    act(() => handle.setSelection({ logo: null }));
    expect(container.querySelector(".pc-preview")).toBeNull();
    expect(revokeObjectURL).toHaveBeenCalledWith("blob:3");

    chooseFile(input, png);
    await act(async () => {});
    act(() => root.unmount());
    expect(revokeObjectURL).toHaveBeenCalledWith("blob:4");
  });

  it("config の参照が変わっても、いまの選択は新しい設定に合わせて保たれる", () => {
    const { container, root } = mount(resolveConfig(BASE));
    click(buttonNamed(container, "黒"));
    expect(total(container)).toBe("￥4,000");
    act(() => {
      root.render(<Configurator config={resolveConfig(BASE)} />);
    });
    expect(total(container)).toBe("￥4,000");
  });
});
