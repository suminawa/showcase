/**
 * 売り物: PNG の書き出し。WebGL の canvas をその場で写し取り（preserveDrawingBuffer は付けず、
 * 書き出す回だけ描き直してから読む。呼ぶ側の仕事）、背景を敷いて toBlob する。
 */

/** 書き出す画像の横幅（px） */
export const EXPORT_WIDTH = 1600;

/** ファイル名に使えない記号と制御文字を落とす。中身が無くなったら「商品」 */
export function sanitizeName(name: string): string {
  const cleaned = name
    .replace(/[\x00-\x1f<>:"/\\|?*]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 40);
  if (/^[-\s]*$/.test(cleaned)) return "商品";
  return cleaned;
}

export function exportFileName(productName: string): string {
  return `${sanitizeName(productName)}-カスタマイズ.png`;
}

/**
 * WebGL の canvas を、その場で 2D の canvas へ写し取る。
 * 描き直したあと await を 1 つでも挟むと中身が消えるので、描き直した直後に同期のまま呼ぶこと。
 */
export function snapshotCanvas(canvas: HTMLCanvasElement, doc: Document): HTMLCanvasElement | null {
  if (!canvas.width || !canvas.height) return null;
  const copy = doc.createElement("canvas");
  copy.width = canvas.width;
  copy.height = canvas.height;
  const ctx = copy.getContext("2d");
  if (!ctx) return null;
  ctx.drawImage(canvas, 0, 0);
  return copy;
}

/** 写し取った canvas を、背景を敷いて横幅 width の PNG にする */
export function toPng(source: HTMLCanvasElement, background: string, doc: Document, width = EXPORT_WIDTH): Promise<Blob | null> {
  if (!source.width || !source.height) return Promise.resolve(null);
  const canvas = doc.createElement("canvas");
  canvas.width = width;
  canvas.height = Math.round((source.height * width) / source.width);
  const ctx = canvas.getContext("2d");
  if (!ctx) return Promise.resolve(null);
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob), "image/png");
  });
}

/** blob をファイルとして落とす。a タグは押したらすぐ片づける */
export function downloadBlob(blob: Blob, name: string, doc: Document): void {
  const url = URL.createObjectURL(blob);
  const anchor = doc.createElement("a");
  anchor.href = url;
  anchor.download = name;
  doc.body.append(anchor);
  anchor.click();
  anchor.remove();
  // 押した直後に片づけると保存が始まる前に url が消えるブラウザがあるので、1 拍おく
  setTimeout(() => URL.revokeObjectURL(url), 0);
}
