"use client";

/**
 * 売り物: 状態の根。選択・画像・価格を持ち、3D（Scene）と操作列（Panel）をつなぐ。
 * 描画実装はここ 1 つだけで、vanilla の mount も React のラッパーも同じものを呼ぶ。
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ExportResult, ResolvedConfig } from "../model/config";
import { missingNames } from "../model/names";
import { priceOf, type PriceBreakdown } from "../model/price";
import {
  decodeShare,
  defaultSelection,
  normalizeSelection,
  selectionJson,
  validateText,
  type ImageMeta,
  type SelectionJson,
  type SelectionState,
} from "../model/selection";
import { labelInputsOf, type LabelImage, type LabelInput } from "../model/texture";
import { loadScene, type SceneApi, type SceneComponent } from "../scene/loader";
import { downloadBlob, exportFileName, snapshotCanvas, toPng } from "./export";
import { loadImage, validateImage, type LoadedImage } from "./images";
import { Panel } from "./Panel";
import { copyText, shareUrl as buildShareUrl } from "./share";

export interface ConfiguratorApi {
  getSelection(): SelectionJson;
  setSelection(partial: Record<string, unknown>): void;
  getPrice(): PriceBreakdown;
  reset(): void;
  exportPng(): Promise<ExportResult | null>;
  shareUrl(): string;
  subscribe(listener: (selection: SelectionJson) => void): () => void;
}

export type ConfiguratorProps = {
  config: ResolvedConfig;
  className?: string;
  handleRef?: (api: ConfiguratorApi) => void;
};

type Support = "unknown" | "ok" | "none";
type SceneState = "idle" | "loading" | "ready" | "error" | "unavailable";
type Images = Record<string, LoadedImage | null>;

const NOTICE_MS = 2000;

function hasWebgl(): boolean {
  if (typeof window === "undefined" || typeof window.WebGLRenderingContext === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    return Boolean(canvas.getContext("webgl2") || canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

function prefersReducedMotion(): boolean {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

const metaOf = (images: Images): Record<string, ImageMeta | null> =>
  Object.fromEntries(Object.entries(images).map(([id, image]) => [id, image?.meta ?? null]));
const sourcesOf = (images: Images): Record<string, LabelImage | null> =>
  Object.fromEntries(Object.entries(images).map(([id, image]) => [id, image?.image ?? null]));

/** 対象名 1 つ分のラベル入力が同じか（background・text の値・image の参照がすべて同じか） */
function sameLabelInput(a: LabelInput | undefined, b: LabelInput | undefined): boolean {
  if (a === b) return true;
  if (!a || !b || a.background !== b.background || a.image !== b.image) return false;
  const at = a.text ?? null;
  const bt = b.text ?? null;
  if (at === bt) return true;
  return at !== null && bt !== null && at.value === bt.value && at.color === bt.color && at.font === bt.font;
}

/** 色や刻印の入れ替えなど、texture に関係ない変更で labels を作り直さないための比較（Scene 側の texture の useMemo を無駄に走らせないため） */
function sameLabels(a: Record<string, LabelInput>, b: Record<string, LabelInput>): boolean {
  const namesA = Object.keys(a);
  if (namesA.length !== Object.keys(b).length) return false;
  return namesA.every((name) => sameLabelInput(a[name], b[name]));
}

export function Configurator({ config, className, handleRef }: ConfiguratorProps) {
  const [state, setState] = useState<SelectionState>(() => defaultSelection(config));
  const [images, setImages] = useState<Images>({});
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [support, setSupport] = useState<Support>("unknown");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [scene, setScene] = useState<SceneComponent | null>(null);
  const [sceneState, setSceneState] = useState<SceneState>("idle");
  const [missing, setMissing] = useState<string[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [canExport, setCanExport] = useState(false);

  // 取っ手と unmount の片づけから、いまの値を読むための鏡
  const stateRef = useRef(state);
  stateRef.current = state;
  const imagesRef = useRef(images);
  imagesRef.current = images;
  const sceneApi = useRef<SceneApi | null>(null);
  const listeners = useRef(new Set<(selection: SelectionJson) => void>());
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // unmount 後に届く古い応答を捨てるための印と、画像の群ごとの要求番号（後勝ちを避ける）
  const mounted = useRef(true);
  // StrictMode は effect を setup → cleanup → setup と走らせるので、setup で true に戻す（戻さないと以後の画像がすべて捨てられる）
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const imageRequest = useRef<Record<string, number>>({});
  // labels の前回値。色などラベルに関係ない変更のたびに新しい参照を返すと、Scene 側で texture を作り直してしまうため
  const labelsRef = useRef<Record<string, LabelInput>>({});

  const labels = useMemo(() => {
    const next = labelInputsOf(config, state, sourcesOf(images));
    if (sameLabels(labelsRef.current, next)) return labelsRef.current;
    labelsRef.current = next;
    return next;
  }, [config, state, images]);
  const price = useMemo(() => priceOf(config, state), [config, state]);
  const currentJson = useCallback(() => selectionJson(config, stateRef.current, metaOf(imagesRef.current)), [config]);

  // WebGL と「動きを減らす」は毎回調べる。共有 URL の hash を読むのは最初の 1 回だけ
  // （2 回目以降は config の差し替えとみなし、いまの選択を新しい設定に合わせて正規化する）
  const hashRead = useRef(false);
  useEffect(() => {
    setSupport(hasWebgl() ? "ok" : "none");
    setReducedMotion(prefersReducedMotion());
    if (!hashRead.current) {
      hashRead.current = true;
      if (config.features.share && typeof window !== "undefined") {
        const shared = decodeShare(config, window.location.hash);
        if (Object.keys(shared).length > 0) setState(normalizeSelection(config, shared));
      }
      return;
    }
    // 2 回目以降（config の差し替え）: いまの選択を新しい設定に合わせる
    setState((prev) => normalizeSelection(config, prev));
  }, [config]);

  // 3D の束を読む。unmount したら待つのをやめる
  useEffect(() => {
    if (support !== "ok") return;
    const aborter = new AbortController();
    setSceneState("loading");
    void loadScene(window, aborter.signal, config.scene.src)
      .then((component) => {
        if (aborter.signal.aborted) return;
        if (component) setScene(() => component);
        else setSceneState("unavailable");
      })
      .catch(() => {
        if (!aborter.signal.aborted) setSceneState("error");
      });
    return () => aborter.abort();
  }, [support, config.scene.src]);

  // 変更の知らせ。前回知らせた内容（選択と価格。at は毎回違うので比べない）と同じなら呼ばない。
  // StrictMode は setup → cleanup → setup と 2 回走るが、これで 2 回目も初期値と同じと判って呼ばれない
  const lastNotified = useRef<string | null>(null);
  useEffect(() => {
    const json = currentJson();
    const key = JSON.stringify({ selection: json.selection, price: json.price });
    if (lastNotified.current === null) {
      lastNotified.current = key; // 最初の描画（と StrictMode の 2 回目）では知らせない
      return;
    }
    if (lastNotified.current === key) return;
    lastNotified.current = key;
    config.onChange?.(json);
    for (const listener of listeners.current) listener(json);
  }, [state, images, config, currentJson]);

  useEffect(() => {
    if (missing.length > 0) console.warn(`[product-configurator] ${config.labels.missing}: ${missing.join(", ")}`);
  }, [missing, config.labels.missing]);

  // unmount: 知らせのタイマーと画像の URL を片づける
  useEffect(
    () => () => {
      if (noticeTimer.current) clearTimeout(noticeTimer.current);
      for (const image of Object.values(imagesRef.current)) if (image) URL.revokeObjectURL(image.url);
    },
    [],
  );

  const flash = useCallback((text: string) => {
    setNotice(text);
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(null), NOTICE_MS);
  }, []);

  const select = useCallback(
    (groupId: string, optionId: string | null) => setState((prev) => normalizeSelection(config, { ...prev, [groupId]: optionId })),
    [config],
  );

  const setText = useCallback(
    (groupId: string, value: string) => {
      const group = config.groups.find((g) => g.id === groupId);
      if (!group || group.type !== "text") return;
      const error = validateText(group, value, config.labels);
      setErrors((prev) => ({ ...prev, [groupId]: error }));
      if (error) return;
      setState((prev) => ({ ...prev, [groupId]: value }));
    },
    [config],
  );

  const setImage = useCallback(
    async (groupId: string, file: File | null) => {
      const group = config.groups.find((g) => g.id === groupId);
      if (!group || group.type !== "image") return;
      if (!file) {
        // 読み込み中の要求が外したあとに勝たないよう、番号を進める
        imageRequest.current[groupId] = (imageRequest.current[groupId] ?? 0) + 1;
        const previous = imagesRef.current[groupId];
        if (previous) URL.revokeObjectURL(previous.url);
        setImages((prev) => ({ ...prev, [groupId]: null }));
        setState((prev) => ({ ...prev, [groupId]: null }));
        setErrors((prev) => ({ ...prev, [groupId]: null }));
        return;
      }
      const error = validateImage(file, group, config.labels);
      if (error) {
        setErrors((prev) => ({ ...prev, [groupId]: error }));
        return;
      }
      // この群への何本目の要求かを覚え、あとで「いちばん新しい要求か」を確かめる（後着の 2 枚目に 1 枚目が勝たないように）
      const token = (imageRequest.current[groupId] = (imageRequest.current[groupId] ?? 0) + 1);
      let loaded: LoadedImage;
      try {
        loaded = await loadImage(file, window);
      } catch {
        if (mounted.current && token === imageRequest.current[groupId]) {
          setErrors((prev) => ({ ...prev, [groupId]: config.labels.imageType }));
        }
        return;
      }
      // 遅れて解けた古い要求と、unmount 後に解けた要求は捨てる（読み込んだ URL も手放す）
      if (!mounted.current || token !== imageRequest.current[groupId]) {
        URL.revokeObjectURL(loaded.url);
        return;
      }
      const previous = imagesRef.current[groupId];
      if (previous) URL.revokeObjectURL(previous.url);
      setImages((prev) => ({ ...prev, [groupId]: loaded }));
      setState((prev) => ({ ...prev, [groupId]: "1" }));
      setErrors((prev) => ({ ...prev, [groupId]: null }));
    },
    [config],
  );

  const reset = useCallback(() => {
    for (const id of Object.keys(imageRequest.current)) imageRequest.current[id] += 1;
    for (const image of Object.values(imagesRef.current)) if (image) URL.revokeObjectURL(image.url);
    setImages({});
    setErrors({});
    setState(defaultSelection(config));
  }, [config]);

  const shareUrl = useCallback(() => buildShareUrl(config, stateRef.current, window.location), [config]);

  const exportPng = useCallback(async (): Promise<ExportResult | null> => {
    const api = sceneApi.current;
    if (!api) return null;
    setBusy(true);
    try {
      // 描き直した直後に、await を挟まず同期で写し取る（preserveDrawingBuffer を付けていない）
      api.renderNow();
      const copy = snapshotCanvas(api.canvas, document);
      if (!copy) return null;
      const blob = await toPng(copy, config.scene.background, document);
      if (!blob) return null;
      const result: ExportResult = { blob, name: exportFileName(config.product.name) };
      if (config.onExport) config.onExport(result);
      else downloadBlob(blob, result.name, document);
      return result;
    } finally {
      setBusy(false);
    }
  }, [config]);

  const copy = useCallback(async () => {
    if (await copyText(JSON.stringify(currentJson(), null, 2), window)) flash(config.labels.copied);
  }, [config.labels.copied, currentJson, flash]);

  const share = useCallback(async () => {
    if (await copyText(shareUrl(), window)) flash(config.labels.shared);
  }, [config.labels.shared, flash, shareUrl]);

  const api = useMemo<ConfiguratorApi>(
    () => ({
      getSelection: () => currentJson(),
      setSelection: (partial) => {
        // 画像の群に null が来たら、選択の書き換えだけでなく画像そのもの（と object URL）も外す
        for (const group of config.groups) {
          if (group.type === "image" && group.id in partial && partial[group.id] === null) void setImage(group.id, null);
        }
        setState((prev) => normalizeSelection(config, { ...prev, ...partial }));
      },
      getPrice: () => priceOf(config, stateRef.current),
      reset,
      exportPng,
      shareUrl,
      subscribe: (listener) => {
        listeners.current.add(listener);
        return () => {
          listeners.current.delete(listener);
        };
      },
    }),
    [config, currentJson, exportPng, reset, setImage, shareUrl],
  );
  useEffect(() => {
    handleRef?.(api);
  }, [api, handleRef]);

  const SceneView = scene;
  const stageMessage =
    support === "none"
      ? { text: config.labels.noWebgl, role: "status" as const }
      : sceneState === "loading"
        ? { text: config.labels.loading, role: "status" as const }
        : sceneState === "unavailable"
          ? { text: config.labels.sceneMissing, role: "alert" as const }
          : sceneState === "error"
            ? { text: config.labels.loadError, role: "alert" as const }
            : null;

  return (
    <div className={["pc", className].filter(Boolean).join(" ")}>
      <div className="pc-stage" style={{ background: config.scene.background }}>
        {support === "ok" && SceneView && (
          <SceneView
            config={config}
            state={state}
            labels={labels}
            reducedMotion={reducedMotion}
            onReady={(next) => {
              sceneApi.current = next;
              setCanExport(true);
            }}
            onModel={(info) => {
              setSceneState("ready");
              setMissing(missingNames(config, info.names));
            }}
            onError={() => setSceneState("error")}
            onContextLost={() => {
              sceneApi.current = null;
              setCanExport(false);
              setSceneState("error");
            }}
          />
        )}
        {stageMessage && (
          <p className="pc-stage-message" role={stageMessage.role}>
            {stageMessage.text}
          </p>
        )}
        {missing.length > 0 && (
          <p className="pc-missing">
            {config.labels.missing}: {missing.join(", ")}
          </p>
        )}
        <p className="pc-hint">{config.labels.hint}</p>
      </div>
      <Panel
        config={config}
        state={state}
        errors={errors}
        images={metaOf(images)}
        price={price}
        notice={notice}
        busy={busy}
        canExport={canExport && sceneState === "ready"}
        onSelect={select}
        onText={setText}
        onImage={(groupId, file) => void setImage(groupId, file)}
        onCopy={() => void copy()}
        onExport={() => void exportPng()}
        onShare={() => void share()}
        onReset={reset}
      />
    </div>
  );
}
