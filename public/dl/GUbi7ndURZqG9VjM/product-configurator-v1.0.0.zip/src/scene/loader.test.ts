import { afterEach, describe, expect, it, vi } from "vitest";
import {
  loadedScene,
  loadScene,
  registerScene,
  resetSceneRegistry,
  SCENE_LATE_WAIT_MS,
  SCENE_READY_EVENT,
  type SceneComponent,
} from "./loader";

const Fake: SceneComponent = () => null;
type WithGlobal = { ProductConfigurator3D?: { Scene?: SceneComponent } };

const sceneScripts = () => Array.from(document.querySelectorAll("script[data-pc-scene]"));

afterEach(() => {
  resetSceneRegistry();
  delete (window as unknown as WithGlobal).ProductConfigurator3D;
  for (const script of sceneScripts()) script.remove();
});

describe("loadScene", () => {
  it("登録済みならそれを返す", async () => {
    registerScene(Fake);
    expect(await loadScene(window)).toBe(Fake);
  });

  it("window.ProductConfigurator3D があればそこから拾って登録する", async () => {
    (window as unknown as WithGlobal).ProductConfigurator3D = { Scene: Fake };
    expect(await loadScene(window)).toBe(Fake);
    expect(loadedScene()).toBe(Fake);
  });

  it("まだ無ければ合図を待ち、detail の Scene を受け取る（script defer の順序）", async () => {
    const pending = loadScene(window);
    expect(loadedScene()).toBeNull();
    window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT, { detail: Fake }));
    expect(await pending).toBe(Fake);
    expect(loadedScene()).toBe(Fake);
  });

  it("detail が無い合図なら window の global から拾う", async () => {
    const pending = loadScene(window);
    (window as unknown as WithGlobal).ProductConfigurator3D = { Scene: Fake };
    window.dispatchEvent(new Event(SCENE_READY_EVENT));
    expect(await pending).toBe(Fake);
  });

  it("window が無ければ null", async () => {
    expect(await loadScene()).toBeNull();
  });

  it("signal を abort すると null で解け、合図を聞き続けない（unmount で listener を残さない）", async () => {
    const aborter = new AbortController();
    const pending = loadScene(window, aborter.signal);
    aborter.abort();
    expect(await pending).toBeNull();
    window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT, { detail: Fake }));
    expect(loadedScene()).toBeNull();
  });

  it("abort 済みの signal なら待たずに null", async () => {
    const aborter = new AbortController();
    aborter.abort();
    expect(await loadScene(window, aborter.signal)).toBeNull();
  });

  it("読み込みが終わったら、合図が来なくても待つのをやめる（3D を置いていないサイト）", async () => {
    const pending = loadScene(window);
    window.dispatchEvent(new Event("load"));
    expect(await pending).toBeNull();
    expect(loadedScene()).toBeNull();
  });

  it("読み込みの終わりに間に合わなくても、待ち時間の上限であきらめる", async () => {
    vi.useFakeTimers();
    const pending = loadScene(window);
    vi.advanceTimersByTime(SCENE_LATE_WAIT_MS);
    expect(await pending).toBeNull();
    vi.useRealTimers();
  });

  it("待っている間に束が載れば、上限で拾い上げる", async () => {
    vi.useFakeTimers();
    const pending = loadScene(window);
    // 合図を出さずに window へ置かれた場合（別のやり方で読み込んだとき）
    (window as unknown as WithGlobal).ProductConfigurator3D = { Scene: Fake };
    vi.advanceTimersByTime(SCENE_LATE_WAIT_MS);
    expect(await pending).toBe(Fake);
    expect(loadedScene()).toBe(Fake);
    vi.useRealTimers();
  });

  it("src を渡すと script を 1 本だけ足し、合図で解ける", async () => {
    const pending = loadScene(window, undefined, "./product-configurator-3d.global.js");
    const scripts = sceneScripts() as HTMLScriptElement[];
    expect(scripts).toHaveLength(1);
    expect(scripts[0].getAttribute("src")).toBe("./product-configurator-3d.global.js");
    expect(scripts[0].defer).toBe(true);
    expect(scripts[0].parentElement).toBe(document.head);
    window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT, { detail: Fake }));
    expect(await pending).toBe(Fake);
  });

  it("同じ src は二度足さない（2 つ目の埋め込み・開き直し）", async () => {
    const first = loadScene(window, undefined, "./product-configurator-3d.global.js");
    const second = loadScene(window, undefined, "./product-configurator-3d.global.js");
    expect(sceneScripts()).toHaveLength(1);
    window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT, { detail: Fake }));
    expect(await first).toBe(Fake);
    expect(await second).toBe(Fake);
  });

  it("足した script が読めなければ null で解ける", async () => {
    const pending = loadScene(window, undefined, "./missing-3d.js");
    const script = sceneScripts()[0];
    script.dispatchEvent(new Event("error"));
    expect(await pending).toBeNull();
  });

  it("src を待つ間は、ページの読み込みの終わりで打ち切らない", async () => {
    vi.useFakeTimers();
    const pending = loadScene(window, undefined, "./product-configurator-3d.global.js");
    // 動的に足した script は、ページの読み込みの終わりに間に合わないことがある
    window.dispatchEvent(new Event("load"));
    vi.advanceTimersByTime(SCENE_LATE_WAIT_MS);
    (window as unknown as WithGlobal).ProductConfigurator3D = { Scene: Fake };
    window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT));
    expect(await pending).toBe(Fake);
    vi.useRealTimers();
  });

  it("登録済みなら src を渡されても script を足さない", async () => {
    registerScene(Fake);
    expect(await loadScene(window, undefined, "./product-configurator-3d.global.js")).toBe(Fake);
    expect(sceneScripts()).toHaveLength(0);
  });

  it("あきらめたあとに合図が来ても、待ち続けない（listener を残さない）", async () => {
    vi.useFakeTimers();
    const pending = loadScene(window);
    vi.advanceTimersByTime(SCENE_LATE_WAIT_MS);
    expect(await pending).toBeNull();
    window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT, { detail: Fake }));
    expect(loadedScene()).toBeNull();
    vi.useRealTimers();
  });
});
