/** 視点の計算。three を読まない（1 本目の束と Configurator のテストから使う） */
import type { ModelConfig } from "../model/config";

const DEG = Math.PI / 180;

/** 見る的。モデルはいちばん長い辺が 1 に合わせて底が y=0 に置かれるので、その少し下の中心を見る（scale=1 のとき） */
export const CAMERA_TARGET: [number, number, number] = [0, 0.45, 0];

/** scale に応じた見る的。モデルは model.scale 倍で表示されるので、的の高さも同じ倍率にする */
export function cameraTarget(scale: number): [number, number, number] {
  return [0, CAMERA_TARGET[1] * scale, 0];
}

/** 距離・仰角・方位（度）→ カメラの位置。方位 0 が正面（+Z）、90 が右（+X）。targetY は見る的の高さ（省くと scale=1 の的） */
export function cameraPosition(camera: ModelConfig["camera"], targetY: number = CAMERA_TARGET[1]): [number, number, number] {
  const elevation = camera.elevation * DEG;
  const azimuth = camera.azimuth * DEG;
  return [
    camera.distance * Math.cos(elevation) * Math.sin(azimuth),
    targetY + camera.distance * Math.sin(elevation),
    camera.distance * Math.cos(elevation) * Math.cos(azimuth),
  ];
}
