/** IIFE の入口（2 本目）。<script src="product-configurator-3d.global.js"> で window.ProductConfigurator3D になる */
import Scene from "./Scene";
import { registerScene, SCENE_READY_EVENT } from "./loader";

registerScene(Scene);

// 1 本目（product-configurator.global.js）の loader は別のモジュール実体なので、window の合図で Scene を渡す。
// window.ProductConfigurator3D への代入はこの IIFE が返ったあとなので、detail に載せて先に届ける
if (typeof window !== "undefined") {
  window.dispatchEvent(new CustomEvent(SCENE_READY_EVENT, { detail: Scene }));
}

export { Scene };
export default Scene;
