import { SRGBColorSpace } from "three";
import { describe, expect, it, vi } from "vitest";
import { fakeContext } from "../../test/fake-context";
import { labelTexture } from "./texture-three";

describe("labelTexture", () => {
  it("canvas に描いて、glTF の UV に合わせた texture を返す", () => {
    const ctx = fakeContext();
    const canvas = { width: 0, height: 0, getContext: () => ctx } as unknown as HTMLCanvasElement;
    const doc = { createElement: () => canvas } as unknown as Document;
    const texture = labelTexture({ background: "#f4efe6", text: { value: "AB", color: "#1c1a15", font: "sans-serif" } }, doc);
    expect(texture).not.toBeNull();
    expect(texture!.flipY).toBe(false);
    expect(texture!.colorSpace).toBe(SRGBColorSpace);
    expect(canvas.width).toBe(1024);
    expect(canvas.height).toBe(512);
    expect(ctx.calls[0]).toContain("#f4efe6");
    expect(ctx.calls[1]).toContain('"AB"');
  });
  it("2D context が取れない環境では null", () => {
    // jsdom の getContext は「未実装」の行を出すので、null を返す偽物に差し替えて出力を静かに保つ
    const spy = vi.spyOn(window.HTMLCanvasElement.prototype, "getContext").mockReturnValue(null);
    expect(labelTexture({ background: "#ffffff" }, document)).toBeNull();
    spy.mockRestore();
  });
});
