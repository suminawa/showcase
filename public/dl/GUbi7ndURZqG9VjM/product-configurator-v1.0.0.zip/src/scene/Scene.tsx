"use client";

/*
 * 売り物: 3D。GLB を読み、選択を apply.ts で反映して、照明と床の上で回して見せる。
 * three と R3F を import するのは、このファイルと apply.ts・texture-three.ts・entry.ts だけ（束を分けるため）。
 */
import { OrbitControls } from "@react-three/drei";
import { Canvas, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import { MOUSE, PMREMGenerator, TOUCH, type Group, type Texture } from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

import { DEFAULT_MODEL_SRC } from "../model/config";
import { applySelection, disposeObject, fitObject, indexMeshes, prepareModel, type MeshIndex } from "./apply";
import { cameraPosition, cameraTarget } from "./camera";
import { type SceneApi, type SceneProps } from "./loader";
import { labelTexture } from "./texture-three";

const DEG = Math.PI / 180;
const MOUSE_BUTTONS = { LEFT: MOUSE.ROTATE, MIDDLE: MOUSE.DOLLY, RIGHT: MOUSE.PAN };
const TOUCHES = { ONE: TOUCH.ROTATE, TWO: TOUCH.DOLLY_PAN };

type ModelProps = Pick<SceneProps, "config" | "state" | "labels" | "onModel" | "onError">;

/** GLB を読み、選択を反映する。src が変わったら読み直し、前のものは捨てる */
function Model({ config, state, labels, onModel, onError }: ModelProps) {
  const invalidate = useThree((s) => s.invalidate);
  const [root, setRoot] = useState<Group | null>(null);
  const index = useRef<MeshIndex>(new Map());
  const wrapper = useRef<Group>(null);
  const src = config.model.src ?? DEFAULT_MODEL_SRC;
  // 呼び返しは描くたびに作り直されうるので、ref 経由で呼ぶ
  const onModelRef = useRef(onModel);
  onModelRef.current = onModel;
  const onErrorRef = useRef(onError);
  onErrorRef.current = onError;

  useEffect(() => {
    let cancelled = false;
    let loaded: Group | null = null;
    new GLTFLoader().load(
      src,
      (gltf) => {
        if (cancelled) {
          disposeObject(gltf.scene);
          return;
        }
        loaded = gltf.scene;
        prepareModel(loaded);
        index.current = indexMeshes(loaded);
        setRoot(loaded);
        onModelRef.current?.({ names: [...index.current.keys()] });
      },
      undefined,
      (error) => {
        if (!cancelled) onErrorRef.current?.(error);
      },
    );
    return () => {
      cancelled = true;
      if (loaded) disposeObject(loaded);
      index.current = new Map();
      setRoot(null);
    };
  }, [src]);

  // ラベルの texture。labels が変わるたびに作り直し、前のものは捨てる
  const textures = useMemo(() => {
    const out: Record<string, Texture | null> = {};
    for (const [name, input] of Object.entries(labels)) out[name] = labelTexture(input, document);
    return out;
  }, [labels]);
  useEffect(
    () => () => {
      for (const texture of Object.values(textures)) texture?.dispose();
    },
    [textures],
  );

  useEffect(() => {
    if (!root || !wrapper.current) return;
    applySelection(index.current, config, state, textures);
    // 見えているパーツで測り直す（容量を変えると高さが変わる）。設定の scale はその上に掛ける
    fitObject(wrapper.current, config.model.scale);
    // frameloop="demand" のときは、変えただけでは描き直らないので明示的に起こす
    invalidate();
  }, [root, config, state, textures, invalidate]);

  const rotation = useMemo(
    () => config.model.rotation.map((degrees) => degrees * DEG) as [number, number, number],
    [config.model.rotation],
  );

  return (
    <group ref={wrapper} rotation={rotation}>
      {root && <primitive object={root} />}
    </group>
  );
}

function Ready({ onReady }: { onReady?: (api: SceneApi) => void }) {
  const gl = useThree((state) => state.gl);
  const scene = useThree((state) => state.scene);
  const camera = useThree((state) => state.camera);
  const ref = useRef(onReady);
  ref.current = onReady;
  useEffect(() => {
    ref.current?.({
      // preserveDrawingBuffer を付けていないので、読む直前に描き直す
      renderNow: () => gl.render(scene, camera),
      canvas: gl.domElement,
    });
  }, [camera, gl, scene]);
  return null;
}

/**
 * 金属の映り込み用の環境光。HDR の画像は読まず、three に入っている「部屋」の形から作る（外部ファイルなし）。
 * これが無いと金属感の高い材質（フタのステンレスなど）が黒く見える
 */
function RoomReflections() {
  const gl = useThree((state) => state.gl);
  const scene = useThree((state) => state.scene);
  const invalidate = useThree((state) => state.invalidate);
  useEffect(() => {
    const pmrem = new PMREMGenerator(gl);
    const room = new RoomEnvironment();
    const target = pmrem.fromScene(room, 0.04);
    scene.environment = target.texture;
    scene.environmentIntensity = 0.6;
    invalidate();
    return () => {
      scene.environment = null;
      target.dispose();
      pmrem.dispose();
      room.dispose();
    };
  }, [gl, scene, invalidate]);
  return null;
}

/** ダブルクリックで視点を最初に戻す。makeDefault の controls を R3F の state から取る */
function DoubleClickReset() {
  const controls = useThree((state) => state.controls) as { reset?: () => void } | null;
  const gl = useThree((state) => state.gl);
  useEffect(() => {
    const onDouble = () => controls?.reset?.();
    gl.domElement.addEventListener("dblclick", onDouble);
    return () => gl.domElement.removeEventListener("dblclick", onDouble);
  }, [controls, gl]);
  return null;
}

export default function Scene({ config, state, labels, reducedMotion, onReady, onModel, onError, onContextLost }: SceneProps) {
  const [spinning, setSpinning] = useState(config.scene.autoRotate && !reducedMotion);
  const scale = config.model.scale;
  // 見る的もモデルの大きさ（model.scale 倍）に合わせる。視点の位置もその高さを基準にする
  const target = useMemo(() => cameraTarget(scale), [scale]);
  const position = useMemo(() => cameraPosition(config.model.camera, target[1]), [config.model.camera, target]);
  // 毎回新しいオブジェクトを渡すと R3F がカメラを作り直すので、位置が変わるときだけ作る
  const camera = useMemo(() => ({ fov: 32, near: 0.01, far: 100, position }), [position]);
  const spin = spinning && !reducedMotion;
  // OrbitControls の距離の範囲も scale 倍。設定の距離がそれより遠ければ、そこまで広げる
  const minDistance = 0.8 * scale;
  const maxDistance = Math.max(6 * scale, config.model.camera.distance);
  // 床の半径と影のカメラの範囲も scale 倍（既定の大きさ 1 のときにいまの見た目と同じになる）
  const floorRadius = 2.5 * scale;
  const shadowExtent = 2 * scale;
  const shadowFar = 12 * scale;

  return (
    <Canvas
      className="pc-canvas"
      dpr={[1, 2]}
      shadows="percentage"
      camera={camera}
      gl={{ antialias: true }}
      frameloop={spin ? "always" : "demand"}
      onCreated={({ gl }) => {
        gl.domElement.addEventListener("webglcontextlost", (event) => {
          event.preventDefault();
          onContextLost?.();
        });
      }}
    >
      <color attach="background" args={[config.scene.background]} />
      <ambientLight intensity={0.6} />
      <hemisphereLight args={["#ffffff", config.scene.floor, 0.5]} />
      <directionalLight
        position={[2, 3.5, 2.5]}
        intensity={1.8}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0003}
        shadow-camera-near={0.5}
        shadow-camera-far={shadowFar}
        shadow-camera-left={-shadowExtent}
        shadow-camera-right={shadowExtent}
        shadow-camera-top={shadowExtent}
        shadow-camera-bottom={-shadowExtent}
      />
      <directionalLight position={[-2.5, 1.5, -1.5]} intensity={0.5} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.001, 0]} receiveShadow>
        <circleGeometry args={[floorRadius, 64]} />
        <meshStandardMaterial color={config.scene.floor} roughness={1} />
      </mesh>
      <Model config={config} state={state} labels={labels} onModel={onModel} onError={onError} />
      <RoomReflections />
      <Ready onReady={onReady} />
      <DoubleClickReset />
      <OrbitControls
        makeDefault
        target={target}
        enableDamping={!reducedMotion}
        dampingFactor={0.08}
        autoRotate={spin}
        autoRotateSpeed={1}
        onStart={() => setSpinning(false)}
        enableRotate
        enablePan={false}
        mouseButtons={MOUSE_BUTTONS}
        touches={TOUCHES}
        minDistance={minDistance}
        maxDistance={maxDistance}
        maxPolarAngle={Math.PI / 2.02}
      />
    </Canvas>
  );
}
