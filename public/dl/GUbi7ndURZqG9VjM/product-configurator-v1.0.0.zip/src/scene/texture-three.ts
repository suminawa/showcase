import { CanvasTexture, SRGBColorSpace } from "three";
import { drawLabel, LABEL_HEIGHT, LABEL_WIDTH, type LabelInput } from "../model/texture";

/** ラベルを canvas に描いて three の texture にする。glTF の UV（左上が原点）に合わせて flipY を切る */
export function labelTexture(input: LabelInput, doc: Document): CanvasTexture | null {
  const canvas = doc.createElement("canvas");
  canvas.width = LABEL_WIDTH;
  canvas.height = LABEL_HEIGHT;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  drawLabel(ctx, input);
  const texture = new CanvasTexture(canvas);
  texture.flipY = false;
  texture.colorSpace = SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}
