import { BoxGeometry, Group, Mesh, MeshStandardMaterial, Texture } from "three";
import { describe, expect, it } from "vitest";
import { resolveConfig } from "../model/config";
import { applySelection, disposeObject, fitObject, indexMeshes, prepareModel } from "./apply";

const config = resolveConfig({
  groups: [
    { id: "body", label: "色", type: "color", target: ["body-350", "body-500"], required: true,
      options: [{ id: "navy", label: "n", color: "#243a5e" }, { id: "black", label: "b", color: "#1c1a15", roughness: 0.9 }] },
    { id: "lid", label: "フタ", type: "material", target: ["lid"], required: true,
      options: [{ id: "steel", label: "s", color: "#b8b8b8", roughness: 0.35, metalness: 0.9 }] },
    { id: "size", label: "容量", type: "variant", required: true,
      options: [{ id: "350", label: "350", show: ["body-350"], hide: ["body-500"] }, { id: "500", label: "500", show: ["body-500"], hide: ["body-350"] }] },
    { id: "strap", label: "紐", type: "variant", options: [{ id: "leather", label: "革", show: ["strap"] }] },
    { id: "engrave", label: "刻印", type: "text", target: ["label"] },
    { id: "logo", label: "ロゴ", type: "image", target: ["label"] },
    { id: "badge", label: "バッジ", type: "text", target: ["badge"], hideWhenEmpty: false },
  ],
});

/** 見本と同じ名前の箱。材質は 1 つを共有させる（複製されることを確かめるため） */
function model() {
  const root = new Group();
  const shared = new MeshStandardMaterial({ color: "#ff0000", roughness: 0.5, metalness: 0 });
  for (const name of ["body-350", "body-500", "lid", "strap", "label", "badge"]) {
    const mesh = new Mesh(new BoxGeometry(1, name === "body-500" ? 2 : 1, 1), shared);
    mesh.name = name;
    root.add(mesh);
  }
  prepareModel(root);
  return root;
}

const materialOf = (root: Group, name: string) => (root.getObjectByName(name) as Mesh).material as MeshStandardMaterial;
const state = { body: "navy", lid: "steel", size: "350", strap: null, engrave: "", logo: null, badge: "" };

describe("indexMeshes", () => {
  it("名前で引ける。親の名前_番号 の子は親の名前でも引ける", () => {
    const root = new Group();
    const group = new Group();
    group.name = "lid";
    const child = new Mesh(new BoxGeometry(), new MeshStandardMaterial());
    child.name = "lid_0";
    group.add(child);
    const nameless = new Mesh(new BoxGeometry(), new MeshStandardMaterial());
    group.add(nameless);
    root.add(group);
    const index = indexMeshes(root);
    expect(index.get("lid")).toEqual([child, nameless]);
    expect(index.get("lid_0")).toEqual([child]);
  });
});

describe("prepareModel", () => {
  it("材質をメッシュごとに複製し、影を付ける", () => {
    const root = model();
    expect(materialOf(root, "lid")).not.toBe(materialOf(root, "strap"));
    expect((root.getObjectByName("lid") as Mesh).castShadow).toBe(true);
    expect((root.getObjectByName("lid") as Mesh).receiveShadow).toBe(true);
  });
});

describe("applySelection", () => {
  it("色と素材を対象のメッシュに入れる", () => {
    const root = model();
    applySelection(indexMeshes(root), config, state, {});
    expect(materialOf(root, "body-350").color.getHexString()).toBe("243a5e");
    expect(materialOf(root, "body-500").color.getHexString()).toBe("243a5e");
    expect(materialOf(root, "body-350").roughness).toBe(0.5);
    expect(materialOf(root, "lid").roughness).toBe(0.35);
    expect(materialOf(root, "lid").metalness).toBe(0.9);
    expect(materialOf(root, "strap").color.getHexString()).toBe("ff0000");
  });

  it("色の粗さは指定があるときだけ変え、選び直すと元に戻る", () => {
    const root = model();
    const index = indexMeshes(root);
    applySelection(index, config, { ...state, body: "black" }, {});
    expect(materialOf(root, "body-350").roughness).toBe(0.9);
    applySelection(index, config, state, {});
    expect(materialOf(root, "body-350").roughness).toBe(0.5);
  });

  it("パーツの表示: 選んだ選択肢が見せるものだけ。show に出る名前は選ばれない限り隠す", () => {
    const root = model();
    const index = indexMeshes(root);
    applySelection(index, config, state, {});
    expect(root.getObjectByName("body-350")!.visible).toBe(true);
    expect(root.getObjectByName("body-500")!.visible).toBe(false);
    expect(root.getObjectByName("strap")!.visible).toBe(false);
    applySelection(index, config, { ...state, size: "500", strap: "leather" }, {});
    expect(root.getObjectByName("body-350")!.visible).toBe(false);
    expect(root.getObjectByName("body-500")!.visible).toBe(true);
    expect(root.getObjectByName("strap")!.visible).toBe(true);
  });

  it("ラベル: texture があれば map に入れて表示、無ければ hideWhenEmpty で隠す。元の map に戻る", () => {
    const root = model();
    const index = indexMeshes(root);
    const texture = new Texture();
    applySelection(index, config, state, {});
    expect(root.getObjectByName("label")!.visible).toBe(false);
    expect(root.getObjectByName("badge")!.visible).toBe(true);
    applySelection(index, config, { ...state, engrave: "AB" }, { label: texture });
    expect(root.getObjectByName("label")!.visible).toBe(true);
    expect(materialOf(root, "label").map).toBe(texture);
    applySelection(index, config, state, {});
    expect(materialOf(root, "label").map).toBeNull();
    expect(root.getObjectByName("label")!.visible).toBe(false);
  });

  it("設定にあってモデルに無い名前は無視する（例外にしない）", () => {
    const root = new Group();
    const only = new Mesh(new BoxGeometry(), new MeshStandardMaterial());
    only.name = "lid";
    root.add(only);
    prepareModel(root);
    expect(() => applySelection(indexMeshes(root), config, state, {})).not.toThrow();
  });
});

describe("fitObject", () => {
  it("見えているメッシュだけで測り、いちばん長い辺を 1 にして底を y=0 に置く", () => {
    const root = model();
    const index = indexMeshes(root);
    applySelection(index, config, { ...state, size: "500" }, {});
    expect(fitObject(root).scale).toBeCloseTo(0.5, 6);
    expect(root.position.y).toBeCloseTo(0.5, 6);
    applySelection(index, config, state, {});
    const fit = fitObject(root);
    expect(fit.scale).toBeCloseTo(1, 6);
    expect(fit.height).toBeCloseTo(1, 6);
    expect(root.position.y).toBeCloseTo(0.5, 6);
    expect(root.position.x).toBeCloseTo(0, 6);
  });
  it("何も無ければそのまま", () => {
    const root = new Group();
    expect(fitObject(root)).toEqual({ scale: 1, height: 0 });
  });
});

describe("disposeObject", () => {
  it("geometry と材質を捨てる", () => {
    const root = model();
    let disposed = 0;
    root.traverse((o) => {
      if ((o as Mesh).isMesh) {
        (o as Mesh).geometry.addEventListener("dispose", () => disposed++);
        ((o as Mesh).material as MeshStandardMaterial).addEventListener("dispose", () => disposed++);
      }
    });
    disposeObject(root);
    expect(disposed).toBe(12);
  });
});
