/**
 * 売り物: three の scene に選択を反映する。three だけに依存し、R3F は読まない。
 * メッシュは名前で結びつける。設定にあってモデルに無い名前は、ここでは黙って飛ばす
 * （警告は Configurator が missingNames で 1 回だけ出す）。
 */
import { Box3, Mesh, MeshStandardMaterial, Object3D, Texture, Vector3 } from "three";
import type { ResolvedConfig } from "../model/config";
import type { SelectionState } from "../model/selection";

export type MeshIndex = Map<string, Mesh[]>;

type Original = { map: Texture | null; color: number; roughness: number; metalness: number };
const ORIGINAL = "pcOriginal";

const isMesh = (object: Object3D): object is Mesh => (object as Mesh).isMesh === true;

/** 名前 → メッシュ。名前が空か「親の名前_番号」の子は親の名前でも引ける（GLTFLoader は primitive が複数の mesh を Group + 子に分ける） */
export function indexMeshes(root: Object3D): MeshIndex {
  const index: MeshIndex = new Map();
  const add = (name: string, mesh: Mesh) => {
    if (!name) return;
    const list = index.get(name) ?? [];
    if (!list.includes(mesh)) {
      list.push(mesh);
      index.set(name, list);
    }
  };
  root.traverse((object) => {
    if (!isMesh(object)) return;
    add(object.name, object);
    const parent = object.parent;
    if (parent && parent !== root && parent.name && (object.name === "" || object.name.startsWith(`${parent.name}_`))) {
      add(parent.name, object);
    }
  });
  return index;
}

function standardOf(mesh: Mesh): MeshStandardMaterial | null {
  const material = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
  return material && (material as MeshStandardMaterial).isMeshStandardMaterial ? (material as MeshStandardMaterial) : null;
}

/** 読み込み直後に 1 回。材質をメッシュごとに複製して元の値を覚え、影を付ける */
export function prepareModel(root: Object3D): void {
  root.traverse((object) => {
    if (!isMesh(object)) return;
    object.castShadow = true;
    object.receiveShadow = true;
    object.material = Array.isArray(object.material) ? object.material.map((m) => m.clone()) : object.material.clone();
    const material = standardOf(object);
    if (material) {
      const original: Original = { map: material.map, color: material.color.getHex(), roughness: material.roughness, metalness: material.metalness };
      material.userData[ORIGINAL] = original;
    }
  });
}

function originalOf(material: MeshStandardMaterial): Original | null {
  return (material.userData[ORIGINAL] as Original | undefined) ?? null;
}

/**
 * 選択を反映する。毎回、色・粗さ・金属感を元に戻してから選択肢を当てる（外した選択肢の跡を残さない）。
 * textures は対象メッシュ名 → ラベルの texture。無い名前は元の map に戻す。
 */
export function applySelection(
  index: MeshIndex,
  config: ResolvedConfig,
  state: SelectionState,
  textures: Record<string, Texture | null | undefined>,
): void {
  for (const meshes of index.values()) {
    for (const mesh of meshes) {
      const material = standardOf(mesh);
      const original = material && originalOf(material);
      if (!material || !original) continue;
      material.color.setHex(original.color);
      material.roughness = original.roughness;
      material.metalness = original.metalness;
    }
  }

  // 表示: show に出る名前は「選ばれた選択肢が見せるとき」だけ表示。hide は選ばれたときだけ隠す
  const showable = new Set<string>();
  const show = new Set<string>();
  const hide = new Set<string>();
  for (const group of config.groups) {
    if (group.type !== "variant") continue;
    for (const option of group.options) option.show.forEach((name) => showable.add(name));
    const picked = group.options.find((option) => option.id === state[group.id]);
    picked?.show.forEach((name) => show.add(name));
    picked?.hide.forEach((name) => hide.add(name));
  }
  // ラベルの対象: 何も描くものが無ければ hideWhenEmpty（対象を共有する群がすべて true のとき）で隠す
  const labelTargets = new Map<string, boolean>();
  for (const group of config.groups) {
    if (group.type !== "text" && group.type !== "image") continue;
    for (const name of group.target) labelTargets.set(name, (labelTargets.get(name) ?? true) && group.hideWhenEmpty);
  }
  for (const [name, meshes] of index) {
    let visible = true;
    if (showable.has(name)) visible = show.has(name);
    if (hide.has(name)) visible = false;
    if (labelTargets.get(name) && !textures[name]) visible = false;
    for (const mesh of meshes) mesh.visible = visible;
  }

  for (const group of config.groups) {
    if (group.type !== "color" && group.type !== "material") continue;
    const option = group.options.find((o) => o.id === state[group.id]);
    if (!option) continue;
    for (const name of group.target) {
      for (const mesh of index.get(name) ?? []) {
        const material = standardOf(mesh);
        if (!material) continue;
        material.color.set(option.color);
        if (option.roughness !== null) material.roughness = option.roughness;
        if (option.metalness !== null) material.metalness = option.metalness;
      }
    }
  }

  // map は変わるときだけ触る（needsUpdate は shader を作り直すので、毎回は付けない）
  for (const name of labelTargets.keys()) {
    for (const mesh of index.get(name) ?? []) {
      const material = standardOf(mesh);
      const original = material && originalOf(material);
      if (!material || !original) continue;
      const next = textures[name] ?? original.map;
      if (material.map !== next) {
        material.map = next;
        material.needsUpdate = true;
      }
    }
  }
}

/** 見えているメッシュの箱を測り、いちばん長い辺が size になるよう拡大縮小して、中心を原点・底を y=0 に置く */
export function fitObject(root: Object3D, size = 1): { scale: number; height: number } {
  root.scale.setScalar(1);
  root.position.set(0, 0, 0);
  root.updateMatrixWorld(true);
  const box = new Box3();
  const part = new Box3();
  root.traverse((object) => {
    if (!isMesh(object) || !object.visible) return;
    if (!object.geometry.boundingBox) object.geometry.computeBoundingBox();
    part.copy(object.geometry.boundingBox as Box3).applyMatrix4(object.matrixWorld);
    box.union(part);
  });
  if (box.isEmpty()) return { scale: 1, height: 0 };
  const dims = box.getSize(new Vector3());
  const longest = Math.max(dims.x, dims.y, dims.z) || 1;
  const scale = size / longest;
  const center = box.getCenter(new Vector3());
  root.scale.setScalar(scale);
  root.position.set(-center.x * scale, -box.min.y * scale, -center.z * scale);
  root.updateMatrixWorld(true);
  return { scale, height: dims.y * scale };
}

/** geometry・材質・元の map を捨てる（モデルを差し替えるときと unmount のとき） */
export function disposeObject(root: Object3D): void {
  root.traverse((object) => {
    if (!isMesh(object)) return;
    object.geometry.dispose();
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) {
      const standard = material as MeshStandardMaterial;
      originalOf(standard)?.map?.dispose();
      material.dispose();
    }
  });
}
