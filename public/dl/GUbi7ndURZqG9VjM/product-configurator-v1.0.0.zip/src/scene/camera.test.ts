import { describe, expect, it } from "vitest";
import { CAMERA_TARGET, cameraPosition, cameraTarget } from "./camera";

const close = (actual: number[], expected: number[]) => actual.forEach((n, i) => expect(n).toBeCloseTo(expected[i], 6));

describe("cameraPosition", () => {
  it("方位 0・仰角 0 は正面(+Z)、的の高さ", () => {
    close(cameraPosition({ distance: 2, elevation: 0, azimuth: 0 }), [0, CAMERA_TARGET[1], 2]);
  });
  it("方位 90 は右（+X）、仰角 90 は真上", () => {
    close(cameraPosition({ distance: 2, elevation: 0, azimuth: 90 }), [2, CAMERA_TARGET[1], 0]);
    close(cameraPosition({ distance: 2, elevation: 90, azimuth: 0 }), [0, CAMERA_TARGET[1] + 2, 0]);
  });
  it("targetY を渡すと、その高さを基準にする（model.scale に合わせた的のため）", () => {
    close(cameraPosition({ distance: 2, elevation: 0, azimuth: 0 }, 0.9), [0, 0.9, 2]);
  });
});

describe("cameraTarget", () => {
  it("scale 倍の高さを見る", () => {
    close(cameraTarget(2), [0, 0.9, 0]);
    close(cameraTarget(1), CAMERA_TARGET);
  });
});
