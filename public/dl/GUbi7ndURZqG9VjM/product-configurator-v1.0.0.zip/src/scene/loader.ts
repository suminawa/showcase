/**
 * 売り物: 3D の束の受け渡し。ここには three も R3F も出てこない ──
 * 1 本目の束（操作列と価格）に three を入れないため。
 *
 * 素の HTML では <script src="product-configurator-3d.global.js"> が window.ProductConfigurator3D に
 * 置いたものを拾う。npm（ESM / CJS）では動的 import で読む。
 * どちらを使うかはビルド時の __PC_DYNAMIC_SCENE__ が決める。
 */
import type { ComponentType } from "react";
import type { ResolvedConfig } from "../model/config";
import type { SelectionState } from "../model/selection";
import type { LabelInput } from "../model/texture";

declare const __PC_DYNAMIC_SCENE__: boolean;

/** 3D の側から呼び出し側へ渡す取っ手。PNG を書き出す回だけ描き直してから canvas を読む */
export type SceneApi = { renderNow(): void; canvas: HTMLCanvasElement };

/** モデルを読み終えたときの知らせ。names はメッシュ名（設定と照合して無い名前を警告する） */
export type ModelInfo = { names: string[] };

export type SceneProps = {
  config: ResolvedConfig;
  state: SelectionState;
  /** 対象メッシュ名 → いま描くべきラベル（labelInputsOf の結果） */
  labels: Record<string, LabelInput>;
  /** 動きを減らす設定のとき true。自動回転と慣性を止める */
  reducedMotion: boolean;
  onReady?: (api: SceneApi) => void;
  onModel?: (info: ModelInfo) => void;
  onError?: (error: unknown) => void;
  onContextLost?: () => void;
};

export type SceneComponent = ComponentType<SceneProps>;

let registered: SceneComponent | null = null;

export function registerScene(component: SceneComponent): void {
  registered = component;
}

export function loadedScene(): SceneComponent | null {
  return registered;
}

/** テスト専用。登録を空に戻す */
export function resetSceneRegistry(): void {
  registered = null;
}

type GlobalWithScene = { ProductConfigurator3D?: { Scene?: SceneComponent } };

/** 3D の束（product-configurator-3d.global.js）が読み終わったときに window へ流す合図。detail に Scene が載る */
export const SCENE_READY_EVENT = "product-configurator:scene-ready";

function sceneFromGlobal(win?: Window): SceneComponent | null {
  const global = win as unknown as GlobalWithScene | undefined;
  return global?.ProductConfigurator3D?.Scene ?? null;
}

/** 3D の束の合図を待つ上限（ms）。読み込みの最中に呼ばれたとき */
export const SCENE_WAIT_MS = 8000;
/** 読み込みが終わってから呼ばれたときの上限（ms）。script はもう走ったあとなので短くてよい */
export const SCENE_LATE_WAIT_MS = 1500;

/** 自分で足した 3D の束の script に付ける印。同じ src を二度足さないために見る */
export const SCENE_SCRIPT_MARK = "data-pc-scene";

/** すでに足してある同じ src の script。無ければ null */
function findSceneScript(doc: Document, src: string): HTMLScriptElement | null {
  const list = doc.querySelectorAll<HTMLScriptElement>(`script[${SCENE_SCRIPT_MARK}]`);
  for (const script of Array.from(list)) {
    if (script.getAttribute("src") === src) return script;
  }
  return null;
}

/**
 * 3D の束の script を head に 1 回だけ足す。すでにある（別の埋め込みが足した・
 * 2 回目に開いた）ときは足さずにそれを返す。
 */
function ensureSceneScript(win: Window, src: string): HTMLScriptElement | null {
  const doc = win.document;
  if (!doc?.head) return null;
  const existing = findSceneScript(doc, src);
  if (existing) return existing;
  const script = doc.createElement("script");
  // src は resolveConfig が相対パスか http(s) だけに絞ってある
  script.src = src;
  script.defer = true;
  script.setAttribute(SCENE_SCRIPT_MARK, "");
  doc.head.append(script);
  return script;
}

export async function loadScene(
  win?: Window,
  signal?: AbortSignal,
  src?: string | null,
): Promise<SceneComponent | null> {
  if (registered) return registered;
  const fromGlobal = sceneFromGlobal(win);
  if (fromGlobal) {
    registered = fromGlobal;
    return registered;
  }
  if (typeof __PC_DYNAMIC_SCENE__ !== "undefined" && __PC_DYNAMIC_SCENE__) {
    const module = await import("./Scene");
    registered = module.default;
    return registered;
  }
  if (!win || signal?.aborted) return null;
  // 置き場所を渡されていれば、ここで初めて読み込む（ページの <script> に書かない置き方）
  const script = src ? ensureSceneScript(win, src) : null;
  // 3D の束がまだ読み込み中（<script defer> や、あとから足した script）なら登録の合図を待つ。
  // 1 本目と 3D の束は別のモジュール実体なので、この registry は共有されない。
  // 呼び出し側が signal を abort したら（unmount など）待つのをやめ、listener を残さない。
  // 3D の束を置いていないサイトでは合図が来ないので、読み込みの終わりか待ち時間の上限で
  // null に落とす（「読み込み中…」のまま止まらないように）
  // 自分で足した script は、ページの読み込みが終わったあとに走り出す。
  // その回は短いほうの上限（1.5 秒）では足りないので、長いほうで待つ
  const waitMs =
    script === null && win.document?.readyState === "complete" ? SCENE_LATE_WAIT_MS : SCENE_WAIT_MS;
  return new Promise((resolve) => {
    let timer: ReturnType<typeof setTimeout> | null = null;
    const settle = (value: SceneComponent | null) => {
      win.removeEventListener(SCENE_READY_EVENT, onReady);
      win.removeEventListener("load", onLoad);
      script?.removeEventListener("error", onFailed);
      signal?.removeEventListener("abort", onAbort);
      if (timer !== null) clearTimeout(timer);
      resolve(value);
    };
    const onReady = (event: Event) => {
      const detail = (event as CustomEvent<SceneComponent | undefined>).detail;
      registered = detail ?? sceneFromGlobal(win);
      settle(registered);
    };
    const onAbort = () => settle(null);
    const found = () => {
      const scene = sceneFromGlobal(win);
      if (scene) registered = scene;
      return scene;
    };
    const onLoad = () => settle(found());
    // 足した script が読めなかった（置き場所が違う・404）。待たずに 2D だけで続ける
    const onFailed = () => settle(found());
    timer = setTimeout(() => settle(found()), waitMs);
    win.addEventListener(SCENE_READY_EVENT, onReady);
    // 自分で足した script を待つ間は、ページの読み込みの終わりでは打ち切らない
    if (script === null) win.addEventListener("load", onLoad);
    script?.addEventListener("error", onFailed);
    signal?.addEventListener("abort", onAbort);
  });
}
