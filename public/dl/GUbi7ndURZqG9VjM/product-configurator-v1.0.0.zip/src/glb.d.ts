declare module "../scripts/*.mjs" {
  export type Geometry = { positions: number[]; normals: number[]; uvs: number[]; indices: number[] };
  export type Part = { name: string; material: number; geometry: Geometry; rotation?: number[]; translation?: number[] };
  export type Material = { name: string; baseColorFactor: number[]; metallicFactor: number; roughnessFactor: number };
  export function lathe(profile: number[][], segments: number, thetaStart?: number, thetaEnd?: number): Geometry;
  export function torus(R: number, r: number, segments: number, tube: number): Geometry;
  export function buildTumbler(): { parts: Part[]; materials: Material[] };
  export function encodeGlb(doc: { parts: Part[]; materials: Material[] }): Buffer;
}
