export {
  DEFAULT_LABELS,
  LIMITS,
  isHexColor,
  isSafeSrc,
  resolveConfig,
  type ColorGroup,
  type ColorOption,
  type ConfiguratorCallbacks,
  type ConfiguratorConfig,
  type ConfiguratorLabels,
  type ExportResult,
  type Group,
  type GroupType,
  type ImageGroup,
  type MaterialGroup,
  type MaterialOption,
  type ModelConfig,
  type OptionGroup,
  type PriceConfig,
  type ResolvedConfig,
  type SceneConfig,
  type TextGroup,
  type VariantGroup,
  type VariantOption,
} from "./model/config";
export { formatPrice, priceOf, type PriceBreakdown } from "./model/price";
export { decodeShare, defaultSelection, encodeShare, normalizeSelection, selectionJson, SHARE_KEY, validateText, type ImageMeta, type SelectionJson, type SelectionState } from "./model/selection";
export { missingNames, referencedNames } from "./model/names";
export { drawLabel, fitFontSize, fitRect, LABEL_HEIGHT, LABEL_WIDTH, labelInputsOf, type Draw2D, type LabelImage, type LabelInput } from "./model/texture";
export { DEFAULT_MODEL_SRC } from "./model/config";
export { CAMERA_TARGET, cameraPosition } from "./scene/camera";
export {
  loadScene,
  registerScene,
  SCENE_READY_EVENT,
  type ModelInfo,
  type SceneApi,
  type SceneComponent,
  type SceneProps,
} from "./scene/loader";
export { Configurator, type ConfiguratorApi, type ConfiguratorProps } from "./ui/Configurator";
export { copyText, shareUrl } from "./ui/share";
export { EXPORT_WIDTH, exportFileName, sanitizeName } from "./ui/export";
export { ACCEPT, formatBytes, validateImage, type LoadedImage } from "./ui/images";
export { mount, type ConfiguratorHandle } from "./vanilla/mount";
