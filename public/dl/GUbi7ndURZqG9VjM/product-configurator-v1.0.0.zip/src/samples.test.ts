import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { buildTumbler, encodeGlb, lathe, torus } from "../scripts/glb.mjs";
import { resolveConfig } from "./model/config";
import { missingNames } from "./model/names";

type Json = {
  asset: { version: string };
  scenes: { nodes: number[] }[];
  nodes: { name: string; mesh: number; rotation?: number[]; translation?: number[] }[];
  meshes: { name: string; primitives: { attributes: Record<string, number>; indices: number; material: number }[] }[];
  materials: { name: string }[];
  accessors: { bufferView: number; componentType: number; count: number; type: string; min?: number[]; max?: number[] }[];
  bufferViews: { byteOffset: number; byteLength: number }[];
};

function parseGlb(buffer: Buffer) {
  const magic = buffer.readUInt32LE(0);
  const version = buffer.readUInt32LE(4);
  const length = buffer.readUInt32LE(8);
  const jsonLength = buffer.readUInt32LE(12);
  const jsonType = buffer.readUInt32LE(16);
  const json = JSON.parse(buffer.subarray(20, 20 + jsonLength).toString("utf8")) as Json;
  const binOffset = 20 + jsonLength;
  const binLength = buffer.readUInt32LE(binOffset);
  const binType = buffer.readUInt32LE(binOffset + 4);
  // 新しい ArrayBuffer に写す（Buffer は共有プールの途中を指すことがあり、Float32Array の 4 バイト境界に乗らない）
  const bin = new Uint8Array(binLength);
  bin.set(buffer.subarray(binOffset + 8, binOffset + 8 + binLength));
  return { magic, version, length, jsonType, json, binType, bin };
}

function accessorData(json: Json, bin: Uint8Array, index: number): Float32Array | Uint16Array | Uint32Array {
  const accessor = json.accessors[index];
  const view = json.bufferViews[accessor.bufferView];
  const comps = { SCALAR: 1, VEC2: 2, VEC3: 3 }[accessor.type as "SCALAR" | "VEC2" | "VEC3"];
  const Ctor = accessor.componentType === 5126 ? Float32Array : accessor.componentType === 5125 ? Uint32Array : Uint16Array;
  return new Ctor(bin.buffer as ArrayBuffer, view.byteOffset, accessor.count * comps);
}

const NAMES = ["body-350", "body-500", "lid", "strap", "label"];

describe("lathe / torus", () => {
  it("辺ごとに頂点を分け、面の数は 辺 × segments × 2", () => {
    const g = lathe([[0, 0], [1, 0], [1, 2]], 8);
    expect(g.positions).toHaveLength(2 * 9 * 2 * 3);
    expect(g.indices).toHaveLength(2 * 8 * 2 * 3);
    expect(g.uvs).toHaveLength(2 * 9 * 2 * 2);
  });
  it("外壁の法線は外向き、上面は上向き", () => {
    const g = lathe([[1, 0], [1, 2], [0, 2]], 4);
    // 辺 1（外壁）の最初の頂点は θ=0 → 法線 (0,0,1)
    expect(g.normals.slice(0, 3)).toEqual([0, 0, 1]);
    // 辺 2（上面）の最初の頂点 → 法線 (0,1,0)
    const second = 5 * 2 * 3;
    expect(g.normals.slice(second, second + 3).map((n) => Math.round(n * 1000) / 1000)).toEqual([0, 1, 0]);
  });
  it("torus は (segments+1)(tube+1) 頂点", () => {
    const g = torus(2, 0.5, 8, 4);
    expect(g.positions).toHaveLength(9 * 5 * 3);
    expect(g.indices).toHaveLength(8 * 4 * 6);
  });
});

describe("encodeGlb(buildTumbler())", () => {
  const glb = encodeGlb(buildTumbler());
  const parsed = parseGlb(glb);
  const { json, bin } = parsed;

  it("GLB の頭と 2 つの塊", () => {
    expect(parsed.magic).toBe(0x46546c67);
    expect(parsed.version).toBe(2);
    expect(parsed.length).toBe(glb.byteLength);
    expect(parsed.jsonType).toBe(0x4e4f534a);
    expect(parsed.binType).toBe(0x004e4942);
    expect(glb.byteLength % 4).toBe(0);
    expect(glb.byteLength).toBeLessThan(200_000);
  });

  it("5 つの名前付きメッシュ。位置・法線・UV・index がそろい、POSITION に min/max がある", () => {
    expect(json.asset.version).toBe("2.0");
    expect(json.nodes.map((n) => n.name)).toEqual(NAMES);
    expect(json.meshes.map((m) => m.name)).toEqual(NAMES);
    expect(json.scenes[0].nodes).toEqual([0, 1, 2, 3, 4]);
    for (const mesh of json.meshes) {
      const prim = mesh.primitives[0];
      expect(Object.keys(prim.attributes).sort()).toEqual(["NORMAL", "POSITION", "TEXCOORD_0"]);
      expect(json.accessors[prim.attributes.POSITION].min).toHaveLength(3);
      expect(json.accessors[prim.attributes.POSITION].max).toHaveLength(3);
      expect(json.materials[prim.material]).toBeDefined();
    }
    expect(json.meshes[0].primitives[0].material).toBe(json.meshes[1].primitives[0].material);
  });

  it("三角形の向きが法線と合う（表が外）", () => {
    for (const mesh of json.meshes) {
      const prim = mesh.primitives[0];
      const pos = accessorData(json, bin, prim.attributes.POSITION);
      const nor = accessorData(json, bin, prim.attributes.NORMAL);
      const idx = accessorData(json, bin, prim.indices);
      const p = (i: number) => [pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]];
      const n = (i: number) => [nor[i * 3], nor[i * 3 + 1], nor[i * 3 + 2]];
      let positive = 0;
      for (let t = 0; t < idx.length; t += 3) {
        const [a, b, c] = [p(idx[t]), p(idx[t + 1]), p(idx[t + 2])];
        const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
        const ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
        const g = [ab[1] * ac[2] - ab[2] * ac[1], ab[2] * ac[0] - ab[0] * ac[2], ab[0] * ac[1] - ab[1] * ac[0]];
        const [na, nb, nc] = [n(idx[t]), n(idx[t + 1]), n(idx[t + 2])];
        const sum = [na[0] + nb[0] + nc[0], na[1] + nb[1] + nc[1], na[2] + nb[2] + nc[2]];
        const d = g[0] * sum[0] + g[1] * sum[1] + g[2] * sum[2];
        expect(d, `${mesh.name} の三角形 ${t / 3}`).toBeGreaterThanOrEqual(-1e-12);
        if (d > 1e-12) positive++;
      }
      expect(positive).toBeGreaterThan(0);
    }
  });

  it("label の UV は上が v=0、正面から見て左が u=0", () => {
    const prim = json.meshes[4].primitives[0];
    const pos = accessorData(json, bin, prim.attributes.POSITION);
    const uv = accessorData(json, bin, prim.attributes.TEXCOORD_0);
    const top: number[] = [];
    const bottom: number[] = [];
    const leftX: number[] = [];
    const rightX: number[] = [];
    for (let v = 0; v < pos.length / 3; v++) {
      const [x, y, z] = [pos[v * 3], pos[v * 3 + 1], pos[v * 3 + 2]];
      expect(z).toBeGreaterThan(0);
      (uv[v * 2 + 1] === 0 ? top : bottom).push(y);
      if (uv[v * 2] === 0) leftX.push(x);
      if (uv[v * 2] === 1) rightX.push(x);
    }
    expect(Math.min(...top)).toBeGreaterThan(Math.max(...bottom));
    expect(Math.max(...leftX)).toBeLessThan(0);
    expect(Math.min(...rightX)).toBeGreaterThan(0);
  });

  it("body-350 は body-500 より短く、どちらも上端が同じ（フタが共通）", () => {
    const top = (i: number) => json.accessors[json.meshes[i].primitives[0].attributes.POSITION].max![1];
    const bottom = (i: number) => json.accessors[json.meshes[i].primitives[0].attributes.POSITION].min![1];
    expect(top(0)).toBeCloseTo(top(1), 6);
    expect(bottom(0)).toBeGreaterThan(bottom(1));
    expect(bottom(1)).toBeCloseTo(0, 6);
  });

  it("strap は回して置く（フタの横に縦の輪）", () => {
    expect(json.nodes[3].rotation!.map((n) => Math.round(n * 1000) / 1000)).toEqual([0.707, 0, 0, 0.707]);
    expect(json.nodes[3].translation![0]).toBeGreaterThan(0.037);
  });

  it("samples/tumbler.glb は生成物と同じ（npm run samples 済み）", () => {
    const onDisk = readFileSync(resolve(__dirname, "../samples/tumbler.glb"));
    expect(onDisk.equals(glb)).toBe(true);
  });
});

describe("samples の設定", () => {
  const load = (name: string) => JSON.parse(readFileSync(resolve(__dirname, `../samples/${name}`), "utf8")) as unknown;

  it("tumbler.config.json は検査を通り、GLB にある名前だけを参照する", () => {
    const config = resolveConfig(load("tumbler.config.json"));
    expect(missingNames(config, NAMES)).toEqual([]);
    expect(config.groups.map((g) => g.type)).toEqual(["color", "material", "variant", "variant", "text", "image"]);
    expect(config.model.src).toBe("./tumbler.glb");
    expect(config.price.base).toBe(3800);
  });

  it("tumbler-simple.config.json も通る（色と容量だけ、共有とコピーは切る）", () => {
    const config = resolveConfig(load("tumbler-simple.config.json"));
    expect(missingNames(config, NAMES)).toEqual([]);
    expect(config.groups).toHaveLength(2);
    expect(config.features).toEqual({ export: true, share: false, copy: false });
  });
});
