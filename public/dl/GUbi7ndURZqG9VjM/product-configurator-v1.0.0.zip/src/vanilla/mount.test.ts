import { act } from "react";
import { describe, expect, it } from "vitest";
import { mount, type ConfiguratorHandle } from "./mount";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const CONFIG = {
  product: { name: "タンブラー", sku: "TB-01" },
  price: { base: 3800 },
  groups: [{ id: "body", label: "色", type: "color", target: ["body"], options: [{ id: "a", label: "A", color: "#000000" }, { id: "b", label: "B", color: "#111111", price: 200 }] }],
};

function mountIn(root: HTMLElement, config?: typeof CONFIG): ConfiguratorHandle {
  let handle!: ConfiguratorHandle;
  act(() => {
    handle = mount(root, config);
  });
  return handle;
}

describe("mount", () => {
  it("描いて取っ手を返し、destroy で消える", () => {
    const root = document.createElement("div");
    document.body.append(root);
    const handle = mountIn(root, CONFIG);
    expect(root.querySelector(".pc")).not.toBeNull();
    expect(handle.getPrice().total).toBe(3800);
    act(() => handle.setSelection({ body: "b" }));
    expect(handle.getPrice().total).toBe(4000);
    expect(handle.getSelection().selection.body).toBe("b");
    act(() => handle.destroy());
    expect(root.querySelector(".pc")).toBeNull();
    root.remove();
  });

  it("設定を省くと data-config の JSON を読む", () => {
    const root = document.createElement("div");
    root.dataset.config = JSON.stringify(CONFIG);
    document.body.append(root);
    const handle = mountIn(root);
    expect(root.querySelector(".pc-title")!.textContent).toBe("タンブラー");
    act(() => handle.destroy());
    root.remove();
  });

  it("設定が無い・JSON でない・壊れている、は日本語で止める", () => {
    const root = document.createElement("div");
    expect(() => mount(root)).toThrow(/data-config/);
    root.dataset.config = "{";
    expect(() => mount(root)).toThrow(/JSON/);
    expect(() => mount(root, { groups: [] })).toThrow(/groups/);
  });
});
