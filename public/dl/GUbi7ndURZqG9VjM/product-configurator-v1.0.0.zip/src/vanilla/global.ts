// IIFE の入口（1 本目）。<script src="product-configurator.global.js"> で window.ProductConfigurator になる
export { DEFAULT_LABELS, DEFAULT_MODEL_SRC, resolveConfig } from "../model/config";
export { decodeShare, defaultSelection, encodeShare, normalizeSelection, selectionJson } from "../model/selection";
export { formatPrice, priceOf } from "../model/price";
export { mount } from "./mount";

// 3D の束（product-configurator-3d.global.js）が同じ React を使うための受け渡し。直接使うものではない
import React from "react";
import ReactJsxRuntime from "react/jsx-runtime";
import ReactDOM from "react-dom";
import ReactDOMClient from "react-dom/client";
export { React, ReactJsxRuntime, ReactDOM, ReactDOMClient };
