import { createElement } from "react";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";
import { fail, resolveConfig, type ConfiguratorConfig } from "../model/config";
import { Configurator, type ConfiguratorApi } from "../ui/Configurator";

export type ConfiguratorHandle = ConfiguratorApi & {
  /** 中身を消して、listener とタイマーと画像の URL を片づける */
  destroy(): void;
};

/** 設定が無ければ root の data-config（JSON）を読む */
function configOf(root: HTMLElement, config?: ConfiguratorConfig): unknown {
  if (config !== undefined) return config;
  const raw = root.dataset.config;
  if (raw === undefined) fail("設定を渡すか、要素に data-config（JSON）を付けてください");
  try {
    return JSON.parse(raw);
  } catch {
    return fail("data-config が JSON として読めません");
  }
}

/**
 * コンフィギュレーターを root の中に描く。描画実装は Configurator 1 つだけで、React ラッパーも同じものを呼ぶ。
 * root.render は既定では次の描画まで待つので、取っ手をその場で返せるよう flushSync で流し込む。
 */
export function mount(root: HTMLElement, config?: ConfiguratorConfig): ConfiguratorHandle {
  const resolved = resolveConfig(configOf(root, config));
  const reactRoot = createRoot(root);
  let api: ConfiguratorApi | null = null;
  flushSync(() => {
    reactRoot.render(
      createElement(Configurator, {
        config: resolved,
        handleRef: (next: ConfiguratorApi) => {
          api = next;
        },
      }),
    );
  });
  if (!api) fail("コンフィギュレーターを描けませんでした");
  const current: ConfiguratorApi = api;
  return {
    getSelection: () => current.getSelection(),
    setSelection: (partial) => current.setSelection(partial),
    getPrice: () => current.getPrice(),
    reset: () => current.reset(),
    exportPng: () => current.exportPng(),
    shareUrl: () => current.shareUrl(),
    subscribe: (listener) => current.subscribe(listener),
    destroy: () => reactRoot.unmount(),
  };
}
