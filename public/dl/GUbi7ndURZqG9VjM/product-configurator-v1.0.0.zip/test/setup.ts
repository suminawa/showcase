/**
 * テストの下ごしらえ。Node 22 以降は globalThis.localStorage を実験的に持っていて、
 * --localstorage-file を渡さないと読み書きで失敗する。vitest の jsdom 環境はすでにある
 * 鍵を上書きしないため、jsdom の Storage が隠れてしまう。ここで記憶だけの Storage に差し替える。
 */
import { beforeEach } from "vitest";

class MemoryStorage implements Storage {
  private map = new Map<string, string>();
  get length(): number {
    return this.map.size;
  }
  clear(): void {
    this.map.clear();
  }
  getItem(key: string): string | null {
    return this.map.has(key) ? (this.map.get(key) as string) : null;
  }
  key(index: number): string | null {
    return Array.from(this.map.keys())[index] ?? null;
  }
  removeItem(key: string): void {
    this.map.delete(key);
  }
  setItem(key: string, value: string): void {
    this.map.set(key, String(value));
  }
}

const storage = new MemoryStorage();

Object.defineProperty(globalThis, "localStorage", {
  value: storage,
  configurable: true,
  writable: true,
});

// 1 つのテストが書いた保存データを次のテストへ持ち越さない
// （テストファイルごとの beforeEach の書き忘れで、隣のテストが落ちるのを防ぐ）
beforeEach(() => {
  storage.clear();
});
