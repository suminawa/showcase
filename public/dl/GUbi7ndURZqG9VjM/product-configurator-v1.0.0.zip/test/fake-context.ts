import type { Draw2D } from "../src/model/texture";

export interface FakeContext extends Draw2D {
  calls: string[];
}

/** 描いた手順を文字で記録する 2D context の偽物。measureText は 1 字 = フォントサイズの 0.6 倍 */
export function fakeContext(): FakeContext {
  const ctx: FakeContext = {
    calls: [],
    fillStyle: "#000000",
    font: "10px sans-serif",
    textAlign: "start",
    textBaseline: "alphabetic",
    fillRect(x, y, w, h) {
      ctx.calls.push(`fillRect ${x} ${y} ${w} ${h} ${String(ctx.fillStyle)}`);
    },
    fillText(text, x, y) {
      ctx.calls.push(`fillText "${text}" ${x} ${y} ${ctx.font} ${String(ctx.fillStyle)}`);
    },
    measureText(text) {
      const size = Number(/(\d+)px/.exec(ctx.font)?.[1] ?? 10);
      return { width: text.length * size * 0.6 };
    },
    drawImage(_image, x, y, w, h) {
      ctx.calls.push(`drawImage ${x} ${y} ${w} ${h}`);
    },
    clearRect(x, y, w, h) {
      ctx.calls.push(`clearRect ${x} ${y} ${w} ${h}`);
    },
  };
  return ctx;
}
