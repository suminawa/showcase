#!/usr/bin/env node
// dist を含む配布 zip を release/ に作る。「手元で動かす」ができるようテストファイルも含める。
import { execFileSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync } from "node:fs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const out = `release/product-configurator-v${pkg.version}.zip`;

for (const file of ["dist/product-configurator.global.js", "dist/product-configurator-3d.global.js", "dist/index.js", "dist/react.js"]) {
  if (!existsSync(file)) {
    console.error(`${file} がありません。先に npm run build を実行してください`);
    process.exit(1);
  }
}
if (!existsSync("samples/tumbler.glb")) {
  console.error("samples/tumbler.glb がありません。先に npm run samples を実行してください");
  process.exit(1);
}
mkdirSync("release", { recursive: true });
if (existsSync(out)) rmSync(out);

// embed/ と page/: コピペで置ける平らな置き方。page/index.html と embed/embed-snippet.html は
// ./product-configurator.global.js のように同じ階層から読むので、ここで束と見本を平らに揃える。
// demo/ は ../dist と ../samples を読むのでそのまま動く（demo/embed-snippet.html だけは zip に入れない）
const runtime = [
  ["dist/product-configurator.global.js", "product-configurator.global.js"],
  ["dist/product-configurator-3d.global.js", "product-configurator-3d.global.js"],
  ["styles/product-configurator.css", "product-configurator.css"],
  ["samples/tumbler.glb", "tumbler.glb"],
  ["samples/tumbler.config.json", "tumbler.config.json"],
  ["samples/tumbler-simple.config.json", "tumbler-simple.config.json"],
];
rmSync("embed", { recursive: true, force: true });
mkdirSync("embed", { recursive: true });
for (const [from, to] of runtime) {
  copyFileSync(from, `embed/${to}`);
  copyFileSync(from, `page/${to}`);
}
copyFileSync("demo/embed-snippet.html", "embed/embed-snippet.html");

// npm で入れる人のために tgz を作り、zip の根に同梱する（README の 2-2 が指す名前）
const tgz = `suminawa-product-configurator-${pkg.version}.tgz`;
if (existsSync(tgz)) rmSync(tgz);
execFileSync("npm", ["pack"], { stdio: "inherit" });
if (!existsSync(tgz)) {
  console.error(`${tgz} ができていません`);
  process.exit(1);
}

execFileSync(
  "zip",
  [
    "-r",
    out,
    "dist",
    "demo",
    "page",
    "embed",
    "styles",
    "src",
    "samples",
    "scripts",
    "test",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "tsup.config.ts",
    "vitest.config.ts",
    ".gitignore",
    "README.ja.md",
    "LICENSE.md",
    "CHANGELOG.md",
    tgz,
    "-x",
    "*.DS_Store",
    "demo/embed-snippet.html",
  ],
  { stdio: "inherit" },
);
console.log(`${out} を書き出しました`);
