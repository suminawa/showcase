#!/usr/bin/env node
// 見本の GLB を samples/ に書く。決定的なので、書き直しても差分は出ない
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { buildTumbler, encodeGlb } from "./glb.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
mkdirSync(resolve(root, "samples"), { recursive: true });
const glb = encodeGlb(buildTumbler());
const out = resolve(root, "samples/tumbler.glb");
writeFileSync(out, glb);
console.log(`samples/tumbler.glb を書き出しました（${glb.byteLength} バイト）`);
