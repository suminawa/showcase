// 見本の GLB（glTF 2.0 binary）を three に頼らず組み立てる。
// 座標は m、原点は底の中心、Y が上、正面は +Z。x = r·sinθ, z = r·cosθ（θ が増えると正面から見て右）。
const TAU = Math.PI * 2;
const DEG = Math.PI / 180;

/**
 * [r, y] の折れ線を Y 軸まわりに回す。辺ごとに頂点を分けるので角は立ち、回転方向は滑らか。
 * uv: u は θ の割合、v は辺の始点で 1・終点で 0（glTF は画像の左上が (0,0) なので、上へ向かう辺は上が 0）。
 */
export function lathe(profile, segments, thetaStart = 0, thetaEnd = TAU) {
  const positions = [];
  const normals = [];
  const uvs = [];
  const indices = [];
  for (let k = 0; k + 1 < profile.length; k++) {
    const [r0, y0] = profile[k];
    const [r1, y1] = profile[k + 1];
    const dr = r1 - r0;
    const dy = y1 - y0;
    const len = Math.hypot(dr, dy) || 1;
    // 辺に直交する向き。上へ向かう外壁なら外向き、内へ向かう上面なら上向きになる
    const nr = dy / len;
    const ny = -dr / len || 0; // dr が +0（垂直な辺）だと -dr が -0 になるので 0 に戻す
    const base = positions.length / 3;
    for (let i = 0; i <= segments; i++) {
      const t = i / segments;
      const theta = thetaStart + (thetaEnd - thetaStart) * t;
      const s = Math.sin(theta);
      const c = Math.cos(theta);
      for (const [r, y, v] of [[r0, y0, 1], [r1, y1, 0]]) {
        positions.push(r * s, y, r * c);
        normals.push(nr * s, ny, nr * c);
        uvs.push(t, v);
      }
    }
    for (let i = 0; i < segments; i++) {
      const a = base + i * 2;
      const b = base + (i + 1) * 2;
      const c = b + 1;
      const d = a + 1;
      indices.push(a, b, c, a, c, d);
    }
  }
  return { positions, normals, uvs, indices };
}

/** 輪（大きい半径 R、管の半径 r）。輪の軸は Y */
export function torus(R, r, segments, tube) {
  const positions = [];
  const normals = [];
  const uvs = [];
  const indices = [];
  for (let i = 0; i <= segments; i++) {
    const phi = (i / segments) * TAU;
    const sp = Math.sin(phi);
    const cp = Math.cos(phi);
    for (let j = 0; j <= tube; j++) {
      const psi = (j / tube) * TAU;
      const cs = Math.cos(psi);
      const sn = Math.sin(psi);
      positions.push((R + r * cs) * sp, r * sn, (R + r * cs) * cp);
      normals.push(cs * sp, sn, cs * cp);
      uvs.push(i / segments, j / tube);
    }
  }
  const at = (i, j) => i * (tube + 1) + j;
  for (let i = 0; i < segments; i++) {
    for (let j = 0; j < tube; j++) {
      const a = at(i, j);
      const b = at(i + 1, j);
      const c = at(i + 1, j + 1);
      const d = at(i, j + 1);
      indices.push(a, b, c, a, c, d);
    }
  }
  return { positions, normals, uvs, indices };
}

const BODY_R = 0.037;
const INNER_R = 0.034;
const TOP = 0.2;
const SEG = 64;

/** 底が bottom、上端が TOP の二重壁のカップ。350 ml は底を 5 cm 上げて短くする（上端とフタは共通） */
function bodyProfile(bottom) {
  return [
    [0, bottom],
    [BODY_R, bottom],
    [BODY_R, TOP],
    [INNER_R, TOP],
    [INNER_R, bottom + 0.006],
    [0, bottom + 0.006],
  ];
}

export function buildTumbler() {
  const materials = [
    { name: "body", baseColorFactor: [0.02, 0.045, 0.11, 1], metallicFactor: 0.25, roughnessFactor: 0.45 },
    { name: "lid", baseColorFactor: [0.48, 0.48, 0.48, 1], metallicFactor: 0.9, roughnessFactor: 0.35 },
    { name: "strap", baseColorFactor: [0.11, 0.04, 0.015, 1], metallicFactor: 0, roughnessFactor: 0.8 },
    { name: "label", baseColorFactor: [1, 1, 1, 1], metallicFactor: 0, roughnessFactor: 0.8 },
  ];
  const parts = [
    { name: "body-350", material: 0, geometry: lathe(bodyProfile(0.05), SEG) },
    { name: "body-500", material: 0, geometry: lathe(bodyProfile(0), SEG) },
    {
      name: "lid",
      material: 1,
      geometry: lathe(
        [[0, TOP], [0.038, TOP], [0.038, TOP + 0.012], [0.012, TOP + 0.012], [0.012, TOP + 0.022], [0, TOP + 0.022]],
        SEG,
      ),
    },
    {
      name: "strap",
      material: 2,
      geometry: torus(0.02, 0.003, 48, 12),
      // X 軸まわりに 90 度回して、輪を正面から見える向き（XY 平面）に立て、フタの横に掛ける
      rotation: [Math.SQRT1_2, 0, 0, Math.SQRT1_2],
      translation: [BODY_R + 0.021, TOP + 0.006, 0],
    },
    {
      name: "label",
      material: 3,
      // 本体の外壁の 0.5 mm 外に、正面 ±70 度・高さ 4.5 cm の帯（およそ 2:1。ラベル画像 1024×512 に合う）
      geometry: lathe([[BODY_R + 0.0005, 0.095], [BODY_R + 0.0005, 0.14]], 48, -70 * DEG, 70 * DEG),
    },
  ];
  return { parts, materials };
}

const pad4 = (n) => (4 - (n % 4)) % 4;

export function encodeGlb({ parts, materials }) {
  const chunks = [];
  let byteLength = 0;
  const bufferViews = [];
  const accessors = [];
  const meshes = [];
  const nodes = [];
  const pushView = (buffer, target) => {
    const padding = pad4(byteLength);
    if (padding) {
      chunks.push(Buffer.alloc(padding));
      byteLength += padding;
    }
    bufferViews.push({ buffer: 0, byteOffset: byteLength, byteLength: buffer.byteLength, target });
    chunks.push(buffer);
    byteLength += buffer.byteLength;
    return bufferViews.length - 1;
  };
  const pushAccessor = (bufferView, componentType, count, type, extra = {}) => {
    accessors.push({ bufferView, componentType, count, type, ...extra });
    return accessors.length - 1;
  };
  parts.forEach((part, i) => {
    const { positions, normals, uvs, indices } = part.geometry;
    const vertexCount = positions.length / 3;
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (let v = 0; v < vertexCount; v++) {
      for (let k = 0; k < 3; k++) {
        const x = positions[v * 3 + k];
        if (x < min[k]) min[k] = x;
        if (x > max[k]) max[k] = x;
      }
    }
    const idx = vertexCount > 65535 ? new Uint32Array(indices) : new Uint16Array(indices);
    const position = pushAccessor(pushView(Buffer.from(new Float32Array(positions).buffer), 34962), 5126, vertexCount, "VEC3", { min, max });
    const normal = pushAccessor(pushView(Buffer.from(new Float32Array(normals).buffer), 34962), 5126, vertexCount, "VEC3");
    const texcoord = pushAccessor(pushView(Buffer.from(new Float32Array(uvs).buffer), 34962), 5126, vertexCount, "VEC2");
    const index = pushAccessor(pushView(Buffer.from(idx.buffer), 34963), idx instanceof Uint32Array ? 5125 : 5123, indices.length, "SCALAR");
    meshes.push({
      name: part.name,
      primitives: [{ attributes: { POSITION: position, NORMAL: normal, TEXCOORD_0: texcoord }, indices: index, material: part.material }],
    });
    const node = { name: part.name, mesh: i };
    if (part.rotation) node.rotation = part.rotation;
    if (part.translation) node.translation = part.translation;
    nodes.push(node);
  });
  const bin = Buffer.concat(chunks);
  const json = {
    asset: { version: "2.0", generator: "product-configurator sample" },
    scene: 0,
    scenes: [{ nodes: nodes.map((_, i) => i) }],
    nodes,
    meshes,
    materials: materials.map((m) => ({
      name: m.name,
      pbrMetallicRoughness: { baseColorFactor: m.baseColorFactor, metallicFactor: m.metallicFactor, roughnessFactor: m.roughnessFactor },
    })),
    accessors,
    bufferViews,
    buffers: [{ byteLength: bin.byteLength }],
  };
  const jsonBuffer = Buffer.from(JSON.stringify(json), "utf8");
  const jsonPadded = Buffer.concat([jsonBuffer, Buffer.alloc(pad4(jsonBuffer.byteLength), 0x20)]);
  const binPadded = Buffer.concat([bin, Buffer.alloc(pad4(bin.byteLength))]);
  const header = Buffer.alloc(12);
  header.writeUInt32LE(0x46546c67, 0);
  header.writeUInt32LE(2, 4);
  header.writeUInt32LE(12 + 8 + jsonPadded.byteLength + 8 + binPadded.byteLength, 8);
  const jsonHeader = Buffer.alloc(8);
  jsonHeader.writeUInt32LE(jsonPadded.byteLength, 0);
  jsonHeader.writeUInt32LE(0x4e4f534a, 4);
  const binHeader = Buffer.alloc(8);
  binHeader.writeUInt32LE(binPadded.byteLength, 0);
  binHeader.writeUInt32LE(0x004e4942, 4);
  return Buffer.concat([header, jsonHeader, jsonPadded, binHeader, binPadded]);
}
