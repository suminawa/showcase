# 3D 商品コンフィギュレーター

商品ページに置ける、3D の商品コンフィギュレーターです。GLB の商品モデルを回して見せ、色・素材・パーツ・刻印・ロゴをお客さまに選んでいただき、価格をその場で表示します。選んだ内容は JSON・PNG・共有 URL で取り出せるので、注文フォームやお問い合わせにそのまま添えられます。

- 設定は JSON 1 つ。プログラムを書かずに、選択肢と価格を組めます
- 3D のモデルは glTF（.glb）。Blender などで書き出した自社商品をそのまま読み込みます
- ロゴの画像はお客さまのブラウザの中だけで扱い、サーバーには送りません
- 素の HTML（script 2 本）、npm、React / Next.js の 3 通りの置き方に対応

## 1. 動く見本

`page/index.html` が単体で動く見本です。フォルダで簡易サーバーを起動してからお開きください（ファイルを直接開くと、ブラウザの決まりで 3D のデータを読めません）。

```bash
npx serve page
```

見本の商品はステンレスタンブラー（`page/tumbler.glb`）で、設定は `page/tumbler.config.json` です。

## 2. 置き方

### 2-1. 素の HTML（いちばん簡単）

`embed/` の 7 つのファイル（`product-configurator.global.js` `product-configurator-3d.global.js` `product-configurator.css`、見本 3 つ、貼り付け用の断片 `embed-snippet.html`）をサイトの同じフォルダに置き、次の断片を商品ページに貼ります。

```html
<link rel="stylesheet" href="./product-configurator.css">
<div id="configurator"></div>
<script src="./product-configurator.global.js"></script>
<script>
  ProductConfigurator.mount(document.getElementById("configurator"), {
    product: { name: "ステンレスタンブラー", sku: "TB-01" },
    model: { src: "./tumbler.glb" },
    scene: { src: "./product-configurator-3d.global.js" },
    price: { base: 3800, currency: "JPY", note: "税込" },
    groups: [ /* 3 章の設定 */ ]
  });
</script>
```

3D の部品（`product-configurator-3d.global.js`、およそ 1 MB）は `scene.src` に置き場所を書いておくと、ページを開いたあとに読み込みます。`<script defer src="./product-configurator-3d.global.js">` を先に書いておく置き方でも構いません。

設定を要素に書く置き方もできます。`<div id="configurator" data-config='{ … }'></div>` として `ProductConfigurator.mount(要素)` と呼ぶだけです。

素の HTML の置き方は React を内側に持っているので、ページ側の React の有無や版に左右されません。

#### スマホと表示の速さ

- 3D の部品とモデルは、3D の枠が画面に近づいてから読み込みます。画面の外にあるあいだは描画を止めます。
- 幅 60rem 未満の画面では、影を軽くし、自動回転（`scene.autoRotate`）をしません。
- 3D の枠の上で縦になぞると、ページがそのままスクロールします。横になぞると回り、2 本指で拡大縮小と回転ができます（7 章の `--pc-touch-action` で変えられます）。
- 狭い画面では価格を画面の下に留め、広い画面では 3D の枠を上に留めます。

### 2-2. npm（Vite など）

zip の根にある `suminawa-product-configurator-1.1.0.tgz` を、お使いのプロジェクトで入れます。

```bash
npm install ./suminawa-product-configurator-1.1.0.tgz
```

`react` と `react-dom` は **19（19.0〜19.2）** をご自身のプロジェクトに入れてください（peer 依存で、`npm install` では一緒に入りません）。3D の描画に使う @react-three/fiber 9 が React 19 を必要とするため、React 18 のプロジェクトでは入りません。React 18 のままお使いになるときは、2-1 の素の HTML の置き方をお選びください。three.js は一緒に入ります。

```ts
import { mount } from "@suminawa/product-configurator";
import "@suminawa/product-configurator/styles.css";

const handle = mount(document.getElementById("configurator")!, config);
```

3D の部品は最初に必要になったときに動的に読み込まれます（three.js は依存として一緒に入ります）。

### 2-3. React / Next.js

```tsx
"use client";
import { ProductConfigurator } from "@suminawa/product-configurator/react";
import "@suminawa/product-configurator/styles.css";

const CONFIG = { /* 3 章の設定 */ };

export function Tool() {
  return <ProductConfigurator config={CONFIG} onChange={(selection) => console.log(selection)} />;
}
```

参照が変わると、いまの選択を新しい設定に合わせて引き継ぎます（知らない選択肢は既定に戻ります）。毎描画で新しいオブジェクトを渡すと無駄な計算になるので、定数か `useMemo` で渡してください。Next.js の App Router では `dynamic(() => import(...), { ssr: false })` で読み込むと、サーバー側で three.js を読まずに済みます。

## 3. 設定

すべての項目と既定値です。`product` `price` `groups` 以外は省けます。

| 項目 | 内容 | 既定値 |
| --- | --- | --- |
| `product.name` | 商品名。操作列の見出しと PNG のファイル名に使う | `"商品"` |
| `product.sku` | 品番。選択 JSON の `product` に入る | `""` |
| `model.src` | GLB の場所（相対パスか https）。省くと同梱の見本 `./tumbler.glb` | `null` |
| `model.scale` | 表示の大きさの倍率（0.01〜100） | `1` |
| `model.rotation` | 最初の向き（度。x, y, z） | `[0, 0, 0]` |
| `model.camera` | 視点。`distance`（距離）`elevation`（仰角）`azimuth`（方位。0 が正面） | `{ distance: 2.6, elevation: 18, azimuth: -35 }` |
| `scene.background` | 3D の背景色（#rrggbb） | `"#f4efe6"` |
| `scene.floor` | 床の色 | `"#e8e2d6"` |
| `scene.autoRotate` | 触るまで自動で回す | `false` |
| `scene.src` | 3D の部品の置き場所（素の HTML で、あとから読ませるとき） | `null` |
| `price.base` | 基本価格（整数） | `0` |
| `price.currency` | 通貨（ISO 4217。表示は `Intl` に従う） | `"JPY"` |
| `price.note` | 価格の注記（「税込」など） | `""` |
| `groups` | 選択肢の群（1〜20 個）。下の 3-1 | ── |
| `features.export` / `share` / `copy` | PNG・共有 URL・JSON コピーのボタンを出す | すべて `true` |
| `labels.*` | 画面の文言の上書き。項目は `DEFAULT_LABELS`（タッチ用の案内 `hintTouch`、ロゴのボタン `imageChoose` など） | 日本語の既定 |
| `onChange(selection)` | 選択が変わるたびに呼ばれる（4 章の JSON） | ── |
| `onExport({ blob, name })` | 渡すと PNG はダウンロードされず、ここへ来る | ── |

### 3-1. 群（groups）

群は 5 種類です。`id`（半角の一意な名前）と `label`（画面の見出し）と `type` は必ず入れます。

| type | 何を変えるか | 固有の項目 |
| --- | --- | --- |
| `color` | 対象メッシュの色。粗さ・金属感も変えられる | `target`（メッシュ名の一覧）`required` `default` `options[]`: `{ id, label, color, roughness?, metalness?, price? }` |
| `material` | 対象メッシュの材質（色・粗さ・金属感の組） | `target` `required` `default` `options[]`: `{ id, label, color, roughness, metalness, price? }` |
| `variant` | パーツの表示。選んだ選択肢の `show` を出し `hide` を隠す | `required` `default` `options[]`: `{ id, label, show?, hide?, price? }` |
| `text` | 刻印。対象メッシュに文字を描いたラベルを貼る | `target` `maxChars`（1〜40、既定 12）`pattern`（許す文字の正規表現。3-3）`patternMessage`（`pattern` に合わないときの文言）`placeholder` `font` `color` `background` `hideWhenEmpty` `price` |
| `image` | ロゴ。対象メッシュに画像を貼る | `target` `maxBytes`（既定 2,000,000）`background` `hideWhenEmpty` `price` |

- `required` が `true` の群は必ずどれかが選ばれます（`default` を省くと先頭）。`false` なら「なし」を選べます。
- `price` は基本価格への差額（整数。負の値も可）。刻印は文字があるとき、ロゴは画像を入れたときだけ足します。
- `variant` の `show` に出てくるメッシュは、選ばれた選択肢が見せるときだけ表示されます。
- 刻印とロゴが同じ `target` を持つときは 1 枚のラベルにまとめて描きます（ロゴが上、文字が下）。
- 刻印は文字数に合わせて縮めて 1 行に収めます。小さくなりすぎるときは 2 行に折り返します（空白があればそこで、漢字・かなの文は字数の真ん中で）。
- 設定に知らない項目があると、場所と名前を示して止まります（例: `groups[0] の知らない項目です: requried`）。綴りの誤りが黙って既定値に置き換わらないようにするためです。`$schema` は書いても構いません。

### 3-2. 見本の設定

`samples/tumbler.config.json`（全部入り）と `samples/tumbler-simple.config.json`（色と容量だけ）をご覧ください。

### 3-3. 刻印に使える文字（`pattern`）

`pattern` を省くと、漢字・ひらがな・カタカナ・英字・数字（全角を含む）、半角と全角の空白、刻印でよく使う記号（`. , & ' ! ? ( ) / ・ 、 。 -`）を受け付けます。絵文字・改行・`<` `>` `%` などは受け付けません。この既定は `DEFAULT_TEXT_PATTERN` として取り出せます。

刻印できる文字が決まっている商品では、設定で変えてください。`pattern` は入力全体に当てる正規表現です。合わない文字が入ると入力を受け付けず、`patternMessage`（省くと `labels.textInvalid`）を表示します。

```json
{
  "id": "engrave",
  "label": "刻印（英数字 12 字まで）",
  "type": "text",
  "target": ["label"],
  "maxChars": 12,
  "pattern": "[A-Za-z0-9 .&-]*",
  "patternMessage": "英数字と記号（. & -）、空白でご入力ください。"
}
```

- ひらがなとカタカナだけ: `"[\\p{Script=Hiragana}\\p{Script=Katakana}ー 　]*"`
- 制限なし: `"pattern": null`（絵文字も通ります。刻印の機械が扱えるかをご確認ください）

## 4. 選んだ内容の取り出し

### 4-1. 選択 JSON

`onChange`・「選択内容をコピー」・取っ手の `getSelection()` は、同じ形の JSON を返します。

```json
{
  "product": "TB-01",
  "selection": { "body": "navy", "lid": "steel", "size": "500", "strap": null, "engrave": "MINATO", "logo": { "name": "logo.png", "type": "image/png", "size": 12345 } },
  "price": { "base": 3800, "delta": 900, "total": 4700, "currency": "JPY" },
  "at": "2026-10-02T09:00:00.000Z"
}
```

ロゴは名前・種類・大きさだけで、画像そのものは含みません（ブラウザの外に出さないため）。注文で画像が必要なときは、フォームのファイル欄で別途お受け取りください。

### 4-2. PNG

「PNG で保存」でいま見えている 3D を、横 1600 px で描き直して PNG にします（スマホでも画面の大きさに引きずられず、くっきりした画像になります）。`onExport` を渡すとダウンロードせずに `{ blob, name }` を受け取れます。

### 4-3. 共有 URL

「共有 URL をコピー」で、いまのページの URL に `#pc=…` を付けたものをコピーします。開くと同じ選択で始まります（ロゴは含みません）。

### 4-4. カートや注文フォームへの受け渡し

選んだ内容は `onChange` で受け取り、注文フォームの隠し項目に入れると、注文と一緒に届きます。

```html
<form action="/order" method="post">
  <div id="configurator"></div>
  <input type="hidden" name="configuration" id="configuration">
  <input type="hidden" name="total" id="total">
  <input type="file" name="logo" accept="image/png,image/jpeg,image/svg+xml">
  <button>この内容で注文する</button>
</form>
<script>
  const handle = ProductConfigurator.mount(document.getElementById("configurator"), {
    /* 3 章の設定 */
    onChange(selection) {
      document.getElementById("configuration").value = JSON.stringify(selection.selection);
      document.getElementById("total").value = selection.price.total;
    },
  });
  // 何も触らずに送られたときのために、最初の選択も入れておく
  document.getElementById("configuration").value = JSON.stringify(handle.getSelection().selection);
  document.getElementById("total").value = handle.getPrice().total;
</script>
```

- 手順: (1) 注文フォームに隠し項目を 2 つ足す → (2) `onChange` で書き込む → (3) 受け取り側で `configuration` を注文の備考に残す。
- 金額はお客さまのブラウザで計算したものです。受け取り側では、設定の価格表で計算し直してから請求してください。
- ロゴの画像そのものは選択 JSON に入りません（4-1）。画像が要るときは、例のようにファイル欄で別に受け取ってください。
- Shopify のカートに入れる置き方は、別売りの Shopify 版で用意しています。

## 5. 取っ手（JavaScript から動かす）

`mount()` の戻り値と、React の `handleRef` に届くものは同じです。

| 呼び方 | 内容 |
| --- | --- |
| `getSelection()` | 4-1 の JSON |
| `setSelection({ body: "black", size: "500" })` | 選択を変える（知らない id は無視） |
| `getPrice()` | `{ base, delta, total, currency }` |
| `reset()` | 最初の選択に戻す |
| `exportPng()` | PNG を作る（`Promise<{ blob, name } | null>`） |
| `shareUrl()` | 共有 URL の文字列 |
| `subscribe(listener)` | 変更のたびに呼ぶ。戻り値で解除 |
| `destroy()` | 消す（`mount()` の戻り値だけ） |

部品の版は `VERSION`（素の HTML では `ProductConfigurator.VERSION`）と、根の要素の `data-pc-version` 属性で確かめられます。

## 6. 3D モデルの用意

- 形式は glTF バイナリ（`.glb`）。DRACO などの圧縮は使わず、そのまま書き出してください。テクスチャは中に埋め込めます。
- 設定で触るパーツには、Blender のオブジェクト名で名前を付けてください（例: `body` `lid`）。設定の `target` `show` `hide` はこの名前で結びつきます。設定にあってモデルに無い名前は、画面の左上に小さく表示して知らせます（止まりません）。
- three.js はモデルを読むときに名前の空白を `_` に変え、`.` `:` `/` `[` `]` を消します（Blender の既定の `Body.001` は `Body001` になります）。設定の名前にも同じ変換をかけてから照らすので、Blender での名前をそのまま書いて構いません。
- 刻印・ロゴを貼るパーツは、UV を持つ面にしてください（ラベル 1 枚は 2:1 の画像です）。ラベルは対象の面の画像（テクスチャ）を置き換えるので、刻印専用の面（本体とは別のオブジェクト）を用意してください。
- 円筒に巻くラベルは、正面から読める幅（中心から左右 40 度ほど）に収めてください。広く巻くと、端の文字が側面に回り込んで読めなくなります（見本のタンブラーは左右 40 度・高さ 2.6 cm です）。
- 大きさは自動で合わせます（いちばん長い辺を 1 として床に置く）。`model.scale` と `model.rotation` で調整できます。
- 色を変えるパーツの材質は、Principled BSDF（金属感・粗さ）で書き出してください。
- 1 つのパーツには 1 つの材質を割り当ててください。1 つのオブジェクトに複数の材質スロットがあると、書き出しでパーツが `名前_0` `名前_1` のように分かれます（設定の `target` には元の名前を書けば、その両方に当たります）。

## 7. 見た目の調整

CSS 変数 `--pc-bg` `--pc-fg` `--pc-muted` `--pc-brand` `--pc-on-brand` `--pc-line` `--pc-control-line` `--pc-surface` `--pc-radius` `--pc-font` を `.pc` かその祖先に書くと色と間隔が変わります。3D の背景と床の色は設定の `scene` で渡します。

| 変数 | 内容 | 既定値 |
| --- | --- | --- |
| `--pc-control-line` | 選んでいないチップ・ボタン・入力欄の枠 | `rgba(28, 26, 21, 0.55)` |
| `--pc-touch-action` | 3D の枠の上での指の動き。`pan-y` は縦のスクロールを通す。`none` にすると縦の動きも 3D が受け、ページはスクロールしない | `pan-y` |
| `--pc-sticky-top` | 広い画面で 3D の枠を留める上からの位置（固定ヘッダーがあるときはその高さ） | `1rem` |

調整は設定と CSS 変数（とご自身の CSS での上書き）で行ってください。`dist/` `styles/` `embed/` のファイルを直接書き換えると、1.x の更新で置き換わり、変更が消えます。

## 8. よくある質問

- **3D が出ず「3D の部品が見つかりません」と出る** ── `product-configurator-3d.global.js` の置き場所が `scene.src` と合っていません。1 本目より先に読ませていないかもご確認ください。
- **色が変わらないパーツがある** ── メッシュ名が設定と違います。画面左上の「モデルに無い名前」をご覧ください。
- **刻印が裏返って見える** ── ラベルを貼る面の UV が左右逆です。Blender で UV を水平に反転してください。
- **スマホで重い** ── モデルの頂点数を減らすか、テクスチャを 1024 px 以下にしてください。3D の部品はおよそ 1 MB です。
- **設定に書いた名前（`Body.001` など）が「モデルに無い名前」に出る** ── 表示は 6 章の変換をかけたあとの名前（`Body001`）です。Blender のオブジェクト名と、書き出した GLB の中の名前をご確認ください。
- **刻印を入れたら、元の模様が消えた** ── ラベルは対象の面の画像を置き換えます。刻印専用の面を別に作り、そちらを `target` にしてください。
- **「3D の表示が一時的に止まりました」と出る** ── 端末が 3D の描画を打ち切りました（ほかのタブで 3D を多く開いたときなど）。「3D をもう一度表示する」を押すと作り直します。
- **「知らない項目です」と出て止まる** ── 設定の項目名の綴りをご確認ください（3 章の表にある名前だけが使えます）。
- **WebGL の無い環境** ── 3D の枠に断りを出し、操作列と価格はそのまま使えます。

## 9. 手元で動かす

```bash
npm install
npm test
npm run build
npm run samples
npm run release
```

`release/product-configurator-v1.1.1.zip` ができます。

## 10. ライセンス

`LICENSE.md` をご覧ください。改変は自由で、クライアントのサイトへの組み込み納品もできます。再配布・転売はできません。

## 11. 困ったら

hello@suminawa.dev までご連絡ください。3 営業日以内にお返事します。
