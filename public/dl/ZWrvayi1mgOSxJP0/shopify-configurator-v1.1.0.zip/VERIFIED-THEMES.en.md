# Verified themes (3D Configurator for Shopify)

This is the separate file for "Verified themes" in `README.en.md`. Only the themes in these tables have been checked on a real store.

<!-- verified-themes:start -->

The checks were made on 2026-09-29. Versions of this kit were installed one after another on three themes of a Shopify development store. The versions are named after the commits they were built from: `b9e2bf7`, `f0357e2`, `a19447b` and `e49946f`. How this zip differs from the newest one, `e49946f`, is listed under "Changed after the checks" below. The checks with these four versions were operated with a browser automation tool and with scripts run in the page. The only part operated by a person with mouse and keyboard is "Test order made by hand" below. The store currency was Japanese yen, the store language and the admin language were Japanese, and the cart mode was "Configurator button".

### Checked with version b9e2bf7 (the variant mode sample)

The screens were desktop width (912 to 1,040 px) and the mobile view of the theme editor.

| What was checked | Generated Data Theme 1.0.0 (the development store's default theme) | Dawn 16.0.0 | Horizon 4.2.0 |
| --- | --- | --- | --- |
| The section file can be saved in the code editor | Saved. The editor showed 0 errors and 0 warnings | Saved. 0 errors, 0 warnings | Saved. 0 errors, 2 warnings (both ValidScopedCSSClass about the `page-width` class; they do not affect behavior) |
| A section placed with the earlier version keeps working after the files are replaced | Checked | Checked | Checked |
| The 3D appears and the console shows no errors | Checked | Checked | Checked |
| The price appears as `¥3,800` to `¥4,700` with the half-width sign, written the same way as the price the theme shows on the cart page | Checked | Checked | Checked |
| The 3D and the price change with the choices | Checked | Checked | Checked |
| The lines on the cart page (`刻印の有無: あり`, `フタ: マットブラック`, `刻印の文字: MINATO`) | Checked | Checked | Checked (for options, only the values are listed, without the names) |
| The keys in `/cart.js` (`フタ`, `刻印の文字`, `_configurator`, `_preview`) | Checked | Checked | Checked |
| Opening the `_preview` URL gives the same choices | Checked | Checked | Checked |
| The lines in the cart drawer | Not looked at | Checked with version f0357e2 (see the list below) | Checked |
| With a settings error, only the short message appears on the storefront and one warning line appears in the console | Checked | Checked | Checked |
| With a settings error, the list of errors appears in the theme editor | Not looked at | Checked | Not looked at |
| Nothing overflows sideways in the mobile view of the theme editor | Checked (down to the price and "Add to cart") | Checked (down to the price and "Add to cart") | Checked down to the options and buttons. The price and "Add to cart" were checked with version f0357e2 (at a screen width of 406 px; see the list below) |
| The text, cart lines and `/cart.js` keys with the section's "Language" set to English | Not looked at | Checked (by editing the value in the template file, not through the field in the theme editor) | Not looked at |
| The section name in the theme editor ("3D Configurator" in the list for adding a section) and the setting labels and notes | Checked | Not looked at | Not looked at |

### Checked with version f0357e2

In the checks with this version, most presses of "カートに入れる" (add to cart) and the values put into the quantity field were operated from a script in the page. "Copy selection", "Copy share URL" and "Save as PNG" were pressed by screen position, and the copied text and the saved file were received inside the page and checked there. The real clipboard and download folder were not written.

On all three themes, saving the section (0 errors in the editor; the only warnings were the 2 on Horizon), the 3D, the price `¥3,800`, the cart lines and the `/cart.js` keys were checked again. The unused price field carrying `hidden` and `aria-hidden="true"` was also seen on all three themes. What else was checked, and on which theme, is as follows.

| What was checked | Theme | What was seen |
| --- | --- | --- |
| Reference price mode display | Dawn 16.0.0. On Horizon 4.2.0 and Generated Data Theme 1.0.0, only the display with nothing chosen | The label "参考価格" (reference price), the initial price `¥3,800`, the price differences next to the options (`+￥200` and so on; the yen sign is full-width), and the note. On Dawn, the price after choosing everything was `¥6,800` |
| Adding to the cart in reference price mode | Dawn 16.0.0 | The price in `/cart.js` is the variant price (3,800 yen) and `_reference_price` is `¥6,800`. The cart page shows only the unit price `¥3,800` and the total; the reference price does not appear |
| Adding to the cart with quantity 3 | Dawn 16.0.0 | Quantity 3, total `¥11,400`. `_reference_price` stays at `¥6,800`, the amount for one item |
| A logo (`image`) group | Dawn 16.0.0 | Choosing a PNG image shows it on the 3D and adds the difference to the price. The cart line holds the file name and the request text. The image is not sent anywhere. The `_preview` URL does not include the logo |
| Adding with an optional group left at "None" | Dawn 16.0.0 | No line for that group, and nothing for it in `_configurator` |
| One group set to `false` in `shopify.properties` | Dawn 16.0.0 | No line for that group. It stays in `_configurator` |
| A sold-out combination | Dawn 16.0.0 | "在庫切れです" (sold out) appears under the price and the button can't be pressed. After changing the combination it can be pressed. The option buttons carry no sold-out mark |
| Cart drawer | Dawn 16.0.0 | Pressing "カートに入れる" (add to cart) goes to `/cart` and the drawer does not open. Opening the drawer with the cart icon shows the lines for the choices |
| Section settings (checked by editing the values in the template file) | Dawn 16.0.0 | "Show quantity" off, "Button label", 3D heights 480 / 360, "Show errors in editor" off (the short message appears in place of the list). "Language" fixed to Japanese (the store language is Japanese, so no difference from "Match the store language" can be seen) |
| "Copy selection", "Copy share URL", "Save as PNG", "Start over" | Dawn 16.0.0 | "Copy selection": "コピーしました" (copied) appears under the button and JSON of the choices is handed over (with 0 for the prices). "Copy share URL": "URL をコピーしました" (URL copied) appears and the product URL with `#pc=…` added is handed over. "Save as PNG": a save is started under the name "ステンレスタンブラー-カスタマイズ.png"; nothing appears on the screen afterwards. "Start over": the choices and the price return to the initial ones, `¥3,800` |
| Mobile width (406 px) | Horizon 4.2.0 | The reference price, the note, the quantity and "カートに入れる" fit the width. The button is shown enabled (it was not pressed) |
| Wide screen (page width 1,200 px) | Dawn 16.0.0, Horizon 4.2.0 | Nothing overflows sideways |
| Saving the section with a 189-character setting note | All three themes | Saved |

### Checked with versions a19447b and e49946f

The checks with these two versions were made in the following way on all three themes. Nothing was checked by operating the mouse and keyboard by hand.

- Choosing the options, entering the engraving text and pressing "カートに入れる" (add to cart) were called from a script run in the page. The quantity was not changed (it stayed at 1).
- The logo image (version e49946f only) was a PNG generated in the page and put into the file input from a script. The file dialog was not opened.
- The cart contents were read by fetching `/cart.js` from a script in the page. The cart page as shown on the screen was not looked at with these two versions.
- The prices, the list of buttons, the notes and the settings were read from the text of the elements by a script in the page.
- Whether the 3D appears was judged by the presence of a `canvas` element. Only in some cases was it also seen in a screenshot.
- The theme files were replaced in the code editor with real mouse clicks and keystrokes (select all, paste, save).
- The draft themes were viewed in preview.

| What was checked | Version | Theme | What was seen |
| --- | --- | --- | --- |
| Where the kit's three JS files are read from | a19447b | All three themes | All three come from the same folder on the store's host (`/cdn/shop/t/(number)/assets/`), with `?v=…` at the end of the URL. The rule about the place did not stop a correctly installed theme |
| Normal behavior | a19447b, e49946f | All three themes | A `canvas` element is present. The price text goes from `¥3,800` to `¥4,700`. `/cart.js` holds the variant "サンド / 500 ml / あり", quantity 1, the lines `フタ: ステンレス` and `刻印の文字: MINATO`, and the keys `_configurator` and `_preview`. 0 errors in the console |
| `model.src` on another host | a19447b | Dawn 16.0.0 | A settings error. Only the short message appears on the storefront and no request goes to that host. The list in the theme editor names the host and mentions `model.allowExternal` |
| `model.allowExternal` set to `true` | a19447b | Dawn 16.0.0 (storefront only; the theme editor was not looked at) | The GLB on the other host is loaded (200) and a `canvas` element is present |
| An engraving `pattern` not of the accepted form (`([A-Za-z0-9]+)+`) | a19447b | Dawn 16.0.0 | A settings error. The list in the theme editor shows the accepted form |
| An engraving `pattern` with a reversed range (`[z-a]*`) | a19447b | Dawn 16.0.0 | A settings error. The message was the same as for a wrong form (this zip changes it to a separate message) |
| The core file (`product-configurator.global.js`) present but without the core in it (checked by replacing the file's contents) | a19447b | Dawn 16.0.0 | Only the short message appears on the storefront. The list in the theme editor says "product-configurator.global.js が読み込まれていません。" (is not loaded). One warning with the same text in the console |
| Settings error texts appearing in the console | a19447b | Dawn 16.0.0 | In the storefront's console, the same text as in the theme editor's list appears as a warning prefixed with `[suminawa-configurator]` |
| Markup-like text (`</script><img src=x onerror=alert(1)>`) in the product title and a group label | a19447b | Dawn 16.0.0 (preview) | Both the title and the label are shown as text (read from the text of the elements, and also seen in screenshots). No alert appears and no image element is created. The two JSON blocks in the page source contain no raw `<` or `>` (recorded by code points; `<` is written as `\u003c` and `>` as `\u003e`) |
| Reference price mode (silver / stainless steel / 500 ml / engraving) | a19447b | Dawn 16.0.0 | The reference price text is `¥4,900`. `_reference_price` in `/cart.js` is also `¥4,900`, and the price in `/cart.js` is the variant price |
| The "Copy selection" button not shown by default | e49946f | All three themes | Not shown. "Save as PNG", "Copy share URL" and "Start over" are shown |
| `"features": { "copy": true }` added | e49946f | Dawn 16.0.0 | Four buttons appear, including "Copy selection" |
| The short labels and the note of the sample settings (reference price mode) | e49946f | Dawn 16.0.0 | The group labels are "刻印の文字" and "ロゴ入れ". The line in `/cart.js` is `ロゴ入れ: logo-test.png（ご注文後にメールでお送りください）`. The note is the sample's text |
| The default note when `referenceNote` is omitted | e49946f | Dawn 16.0.0 | "カートとお支払いの画面には、基本の価格が出ます。お選びの内容による差額は、ご注文のあとにご案内します。お支払い金額は、ご注文確認のご連絡で確定します。" (the Japanese default note) |

### Test order made by hand (version e49946f)

On 2026-09-29, on the published Generated Data Theme 1.0.0, a person operated the storefront with mouse and keyboard and went through to completed payment with the test payment gateway (Bogus Gateway). The store currency was Japanese yen, the store language was Japanese, and the sample was the variant mode one.

- What the person reported: they tried everything through to completed payment and found no problems other than the following two. Few countries could be chosen at checkout, and no product image appeared in the product list or the cart (both come from the store's settings and the product's registration, and are covered in "10. FAQ"). No individual report was received on rotating the 3D, "Save as PNG", or pasting and opening the share URL.
- What was seen in the order details in the admin: the "test order" notice. The product line was "ステンレスタンブラー ／ ネイビー / 500 ml / あり", unit price 4,700 yen, quantity 1. The visible lines were `フタ: マットブラック` and `刻印の文字: MINATO`. `_configurator` was `body=navy;lid=black;size=500;engrave=MINATO`. `_preview` was the product URL with `#pc=…` added. The order was marked paid.
- The result of opening the `_preview` URL kept on the order: reading the elements of the page by script, the chosen options were navy / matte black / 500 ml, the engraving field held `MINATO`, the price was `¥4,700`, and a `canvas` element was present, the same as the order. In this step the 3D picture itself was not looked at on the screen.
- The admin shows that the order confirmation email was sent. The contents of the email were not looked at.

Not yet checked on any theme:

- Orders: a test order in reference price mode and the checkout screen in that case (`_reference_price` being kept in the order). How the lines appear in the order confirmation email. A test order on themes other than Generated Data Theme 1.0.0
- Currencies: display in the store's money format for currencies other than Japanese yen. Display when the display currency differs from the store currency (Shopify Markets)
- Unavailable combinations: the display for a combination with no variant
- Settings keys: per-option mapping in `shopify.values`, `features.export` and `features.share` set to `false`, `model.scale` and `model.rotation`, `product.name` and `product.sku`, and the default note when no group has a price difference
- Section settings: "Price mode" set to reference price (reference price mode was checked through `priceMode` in the metafield). The difference between "Language" fixed to Japanese and "Match the store language" (on a Japanese store no difference can be seen)
- Cart modes: theme buy button mode (Appendix A). It was stopped after adding the snippet and has not been run to the end. In `snippets/buy-buttons.liquid` of Dawn 16.0.0, the `form 'product'` tag was seen to span seven lines. Staying on the page with the `suminawa-configurator:added` event
- Situations that were not seen to happen: the message when the core file (`product-configurator.global.js`) itself is missing (404) (the case where the file is present but without the core in it was checked). The place for the 3D being hidden when drawing the 3D fails partway. A settings error when the 3D module is in a different place from the kit's script. Settings not being read when they are in an element other than `<script type="application/json">`
- Ways to install: pushing with Shopify CLI. Uploading the GLB to the product's "Media"
- Theme editor: the full text of the setting options when opened (only the text cut off by the field width was seen)
- Screen width: screens where the page is wider than 1,200 px
- Operation by hand: the things with no individual report in the test order made by hand (rotating the 3D, "Save as PNG", pasting and opening the share URL, the lines shown on the cart page). Operating by hand with the version in this zip installed (the test order made by hand used version e49946f)
- Everything under "Changed after the checks" below

Theme blocks that are hidden (the names are those shown with the admin in Japanese):

| Theme | Hidden blocks |
| --- | --- |
| Generated Data Theme 1.0.0 | 「商品価格」 (price), 「バリエーションピッカー」 (variant picker), 「購入ボタン」 (buy buttons) |
| Dawn 16.0.0 | 「商品価格」 (price), 「バリエーションピッカー」 (variant picker), 「数量セレクター」 (quantity selector), 「購入ボタン」 (buy buttons). The quantity selector is visible from the start; if you leave it, there are two quantity fields |
| Horizon 4.2.0 | 「価格」 (price), found in 「ヘッダー」 (header) inside 「詳細」 (details), and 「バリエーションピッカー」 (variant picker) and 「購入ボタン」 (buy buttons) inside 「詳細」. The quantity field is part of the buy buttons block |

On Horizon 4.2.0, while the buy buttons block was visible, a buy bar appeared at the bottom of the screen. Even with "Sand / Matte black / 500 ml / with engraving" (4,700 yen) chosen in the configurator, the bar stayed on the default variant, "Navy / 350 ml / no engraving" (3,800 yen). Pressing the button on the bar added that default variant to the cart with quantity 1 and none of the lines for the choices. A variant different from the combination the customer chose goes into the cart, at a different price. After the buy buttons block was hidden, the bar no longer appeared. Always hide that block.

Earlier checks: on the same day, both a US dollar / English store and a Japanese yen / Japanese store were checked with the files of a still earlier version. The names of the blocks to hide and the result of pressing Horizon's buy bar are from those records.

Changed after the checks (the differences between version e49946f and this zip; none of these has yet been checked on a real store):

- When an engraving `pattern` has the right form but can't be read as a regular expression (such as `[z-a]*`, a reversed range), a message saying so and naming the usual cause is shown, not the message about the form
- When `features` in the settings is `null`, it is treated as if it were not written (the "Copy selection" button is not shown)

In the 1.0.0 zip, apart from these two, no change was made from version e49946f to what customers see or to what goes into the cart. The files in the 1.0.0 zip that differed from version e49946f are `theme/assets/suminawa-configurator.js`, `src/config.ts`, `README.ja.md`, `README.en.md`, `CHANGELOG.md` and `BUILD.txt`.

Changed in 1.1.0 (these also count as "Changed after the checks"; none of these has yet been checked on a real store. They were checked on the sample product page without Shopify, `page/mock-product.html`, with a browser automation tool (Chromium; finger input was sent through the browser's developer interface)):

- The bundled 3D module is now 1.1.0 (default allowed engraving characters, shrinking and wrapping long engravings, the rebuilt sample model, turning to the front when the engraving field is entered, loading once near the screen and stopping drawing off screen, finger behavior on phones, shadows and auto-rotation on narrow screens, stopping on unknown setting items, mesh name conversion, and the accessible name on the 3D frame)
- While the settings have an error, customers see a short note and a standard purchase form (variant, requests, quantity, add to cart). The form posts to `/cart/add` as an ordinary form
- A mark on options that would be sold out, and a note on which options can be bought
- `data-sc-version` on the section, and a notice when `_preview` would exceed 250 characters
- The sample settings leave `pattern` out for engraving and use the 3D module's default. `patternMessage` can be written per language

<!-- verified-themes:end -->
