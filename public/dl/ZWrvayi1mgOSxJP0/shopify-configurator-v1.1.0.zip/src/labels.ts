/** 画面の文言。核の文言（DEFAULT_LABELS）の英訳と、つなぎが足す文言（ja / en） */
import type { ConfiguratorLabels } from "@core/config";
import type { Lang } from "./types";

/** 核の DEFAULT_LABELS の全キーの英訳。日本語は核の既定のまま使う */
export const CORE_LABELS_EN: ConfiguratorLabels = {
  price: "Price",
  copy: "Copy selection",
  copied: "Copied",
  export: "Save as PNG",
  share: "Copy share URL",
  shared: "URL copied",
  reset: "Start over",
  loading: "Loading…",
  loadError: "We couldn't load the 3D model. Please check model.src in the settings.",
  noWebgl: "3D can't be displayed on this device.",
  sceneMissing: "The 3D module (product-configurator-3d.global.js) wasn't found. Please check the installation steps.",
  missing: "Not in the model",
  none: "None",
  textTooLong: "Please enter up to {max} characters.",
  textInvalid: "This contains characters that can't be used (emoji and some symbols can't be engraved).",
  imageTooLarge: "Please choose an image of {max} or smaller.",
  imageType: "Please choose a PNG, JPEG or SVG image.",
  imageClear: "Remove image",
  hint: "Drag to rotate, scroll to zoom, double-click to reset.",
  hintTouch: "Swipe sideways to rotate. Use two fingers to zoom and rotate.",
  contextLost: "The 3D display has stopped for a moment.",
  retry: "Show the 3D again",
  imageChoose: "Choose image",
  imageEmpty: "None selected",
  sceneLabel: "3D view of {product}. {selection}",
};

/** 核の mount に渡す labels。日本語は核の既定なので空 */
export function coreLabelsFor(lang: Lang): Partial<ConfiguratorLabels> {
  return lang === "en" ? { ...CORE_LABELS_EN } : {};
}

export interface AdapterLabels {
  price: string;
  referencePrice: string;
  /** 参考価格方式の既定の注記（差額を持つ群があるとき） */
  referenceNote: string;
  /** 参考価格方式の既定の注記（差額を持つ群が無いとき。差額の案内は要らない） */
  referenceNoteNoDifference: string;
  referenceCurrency: string;
  quantity: string;
  addToCart: string;
  adding: string;
  unavailable: string;
  soldOut: string;
  cartFailed: string;
  cartSoldOut: string;
  logoSuffix: string;
  errorsTitle: string;
  warningsTitle: string;
  themeFormMissing: string;
  empty: string;
  /** 設定の誤りで動かせないとき、標準の購入フォームの上に出す一言（誤りの中身は出さない） */
  storefrontUnavailable: string;
  /** 標準の購入フォームの、バリエーションを選ぶ欄の見出し */
  fallbackVariant: string;
  /** 標準の購入フォームの、ご希望の欄の見出し（そのまま注文の行の名前になる） */
  fallbackRequest: string;
  /** 選択肢に付ける印 */
  stockSoldOut: string;
  stockNone: string;
  /** いまの組み合わせが買えないとき、変えれば買える選択肢の案内。{options} に選択肢が入る */
  alternatives: string;
  previewTooLong: string;
}

export const ADAPTER_LABELS: Record<Lang, AdapterLabels> = {
  ja: {
    price: "価格",
    referencePrice: "参考価格",
    referenceNote: "カートとお支払いの画面には、基本の価格が出ます。お選びの内容による差額は、ご注文のあとにご案内します。お支払い金額は、ご注文確認のご連絡で確定します。",
    referenceNoteNoDifference: "お支払い金額は、ご注文確認のご連絡で確定します。",
    referenceCurrency: "参考価格は {currency} でご案内します。",
    quantity: "数量",
    addToCart: "カートに入れる",
    adding: "カートに入れています…",
    unavailable: "この組み合わせはお選びいただけません",
    soldOut: "在庫切れです",
    cartFailed: "カートに入れられませんでした。時間をおいてお試しください。",
    cartSoldOut: "在庫が足りないため、カートに入れられませんでした。数量か組み合わせを変えてお試しください。",
    logoSuffix: "（ご注文後にメールでお送りください）",
    errorsTitle: "3D コンフィギュレーターの設定に直すところがあります（この表示はテーマエディタの中だけに出ます）",
    warningsTitle: "3D コンフィギュレーターの設定のお知らせ（この表示はテーマエディタの中だけに出ます）",
    themeFormMissing:
      "カートの方式が「テーマの購入ボタン」ですが、購入ボタンのフォームの中に suminawa-configurator-properties が見つかりません。いまはコンフィギュレーターのボタンを出しています。",
    empty: "メタフィールド custom.configurator に設定が入っていません。",
    storefrontUnavailable: "ただいま 3D のカスタマイズ画面を表示できません。下のフォームからご注文いただけます。",
    fallbackVariant: "種類",
    fallbackRequest: "ご希望（刻印の文字など）",
    stockSoldOut: "在庫切れ",
    stockNone: "お取り扱いなし",
    alternatives: "{options}でしたらお求めいただけます。",
    previewTooLong:
      "注文詳細に残す _preview（同じ 3D を開ける URL）が 250 字を超えたため、この選択では注文に残りません。ほかの行（選んだ内容と _configurator）は残ります。商品の URL（handle）を短くするか、刻印の字数（maxChars）を減らすと残せます。",
  },
  en: {
    price: "Price",
    referencePrice: "Reference price",
    referenceNote: "The cart and checkout show the base price. We'll let you know the difference for your choices after you order. The final amount will be confirmed in our order confirmation.",
    referenceNoteNoDifference: "The final amount will be confirmed in our order confirmation.",
    referenceCurrency: "The reference price is shown in {currency}.",
    quantity: "Quantity",
    addToCart: "Add to cart",
    adding: "Adding to cart…",
    unavailable: "This combination isn't available",
    soldOut: "Sold out",
    cartFailed: "We couldn't add this to your cart. Please try again later.",
    cartSoldOut: "There isn't enough stock to add this to your cart. Please change the quantity or the combination.",
    logoSuffix: " (please email the file to us after ordering)",
    errorsTitle: "The 3D configurator settings need attention (shown only in the theme editor)",
    warningsTitle: "Notes on the 3D configurator settings (shown only in the theme editor)",
    themeFormMissing:
      "The cart mode is \"theme buy button\", but suminawa-configurator-properties wasn't found inside the buy button form. The configurator's own button is shown instead.",
    empty: "The metafield custom.configurator has no settings.",
    storefrontUnavailable: "The 3D customizer can't be shown right now. You can still order with the form below.",
    fallbackVariant: "Option",
    fallbackRequest: "Requests (engraving text, etc.)",
    stockSoldOut: "Sold out",
    stockNone: "Unavailable",
    alternatives: "Available with {options}.",
    previewTooLong:
      "_preview (the URL that reopens the same 3D) would be longer than 250 characters, so it is not stored on the order for this selection. The other lines (the choices and _configurator) are still stored. Shorten the product URL (handle) or lower the engraving's maxChars to keep it.",
  },
};

/** 店の人向けの文を言語で選ぶ */
export function t(lang: Lang, ja: string, en: string): string {
  return lang === "ja" ? ja : en;
}
