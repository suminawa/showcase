# 3D Configurator for Shopify

A theme component that adds a 3D product configurator to your Shopify product page: customers rotate the product and choose colors, materials, parts and engraving. It is not an app, so there is no app review and no monthly fee. Add one section and five assets in the theme code editor, put one JSON setting into a product metafield, and it works.

- What the customer chose goes into the cart line (line-item properties) and stays in the order details
- The amount charged is the price of the product variant (see "5. Price modes")
- The customer-facing text is in English and Japanese (it follows the storefront language automatically; see "7. Section settings")
- Prices are shown in the store currency, in the store's money format (`¥4,700` for a yen store, `$47.00` for a US dollar store), written the same way as the prices the theme shows
- No server, no external service, no API key. The kit communicates with the store itself (the cart), the host that serves the theme's assets (the kit's own files), and the place the GLB in `model.src` points to. Unless you add a setting, `model.src` accepts only Shopify's file host (`cdn.shopify.com`) and the store's own host ("4-1. 3D settings"). If the GLB file itself points to files in other places, the browser connects to those places too (Appendix C)
- By default, engraving accepts kanji, hiragana, katakana, letters and digits (the allowed characters can be changed in the settings, see "4-1. 3D settings")
- How to prepare the 3D model (GLB) and what to watch for is in "Appendix D. Preparing the GLB"
- Requires an Online Store 2.0 theme (the themes checked on a real store are listed in "Verified themes" just below)

## Verified themes

The themes checked on a real store, with the versions, what was checked, what has not been checked yet, and the blocks to hide on each theme, are in the separate file `VERIFIED-THEMES.en.md`. The kit is built to install the same way on any Online Store 2.0 theme, but other themes have not been checked.

## 1. What's in the zip

| Path | Contents |
| --- | --- |
| `theme/sections/suminawa-configurator.liquid` | The section you place on the product page |
| `theme/snippets/suminawa-configurator-properties.liquid` | Snippet for the theme buy button mode (Appendix A) |
| `theme/assets/product-configurator.global.js` | The configurator |
| `theme/assets/product-configurator-3d.global.js` | The 3D view (about 1 MB, loaded when shown) |
| `theme/assets/product-configurator.css` | Configurator styles |
| `theme/assets/suminawa-configurator.js` | The Shopify adapter (price and cart) |
| `theme/assets/suminawa-configurator.css` | Adapter styles |
| `samples/tumbler.metafield.json` | Sample settings (variant mode) |
| `samples/tumbler-reference.metafield.json` | Sample settings (reference price mode, with price differences) |
| `samples/tumbler.glb` | Sample 3D model (stainless tumbler) |
| `page/mock-product.html` | A sample product page that runs without Shopify |
| `src/` | Adapter source code (TypeScript, free to modify) |
| `VERIFIED-THEMES.ja.md` / `VERIFIED-THEMES.en.md` | The themes checked on a real store, and the records |
| `BUILD.txt` | The version of this zip and the commit it was built from |

## 2. Try it without Shopify

Start a simple server in the unzipped folder and open `page/mock-product.html`. Opening the file directly can't load the 3D data because of browser rules.

```bash
npx serve .
# open /page/mock-product.html?lang=en at the URL shown
```

Choose a color, size and engraving, then press "Add to cart": what the cart would receive is shown at the bottom of the page (the cart is not real).

## 3. Installation

1. **Upload the GLB**: In the admin, go to "Content → Files", upload your `.glb` and copy its URL. The URL starts with `https://cdn.shopify.com/`; for a `.glb` it looks like `https://cdn.shopify.com/3d/models/o/(letters and digits)/(file name).glb`, which is different from the `/s/files/...` form used for images. For how to export the GLB and which formats can't be read, see "Appendix D. Preparing the GLB".
2. **Define the metafield**: In "Settings → Custom data → Products", add a new definition and set its type to "JSON". You can choose any name, but the key is generated from the name, so **before saving, check that the "Namespace and key" field shown under the name reads `custom.configurator`**. If it doesn't, edit that field to `custom.configurator` and then save. If you saved it with a different key, create the definition again with the right key.
3. **Enter the settings**: In the product editor, paste JSON based on `samples/tumbler.metafield.json` into the metafield. Set `model.src` to the URL from step 1 and match `shopify.options` to the product option names ("4. Settings"). Even if you created your products with a bulk import, paste this setting in the product editor.
4. **Add the files**: From "Online Store → Themes", open the code editor for your theme. It shows the theme's folders and files on the left. (Button names in this screen change with Shopify updates, so the steps below describe what to do rather than which button to press.)
   - First, add the five files in `theme/assets` to the `assets` folder, one at a time: create a new file with the same name, paste the contents as they are and save. Two of them have large contents, `product-configurator-3d.global.js` (972 KB) and `product-configurator.global.js` (222 KB), so select the whole file before copying. When you finish, check that all five names appear in the `assets` folder.
   - Next, in the `sections` folder, create a new file named `suminawa-configurator.liquid`, paste the contents of `theme/sections/suminawa-configurator.liquid` as they are, and save. If you add the section first, the editor reports errors saying the asset files are missing, so add the assets first.
   - If you use Shopify CLI, you can push the files with a command instead of pasting (shown right after these steps).
   - Only if you use the theme buy button mode (Appendix A), add `suminawa-configurator-properties.liquid` to the `snippets` folder the same way.
5. **Place it**: In the theme editor, open the product template, add a section and choose "3D Configurator".
   - The new section is added at the bottom of the template, below sections such as related products. In the list on the left, drag it up so that it sits right above or below the section that shows the product information.
   - So that the price and button don't appear twice, hide the theme's own **price, variant picker, quantity field and buy button** blocks, using the eye icon next to each block (no code changes needed). Block names and places differ between themes. For the names and places on the checked themes, see the tables in `VERIFIED-THEMES.en.md`.
   - The configurator shows its own quantity field (when the section setting "Show quantity" is on, which is the default). The configurator's button does not use the value of the theme's quantity field. If the theme's quantity field is visible, hide it.
   - If the theme's buy button is left visible, some themes keep a place where the product can be added to the cart without the choices made in the configurator. After hiding the blocks, check that no buy button or buy bar from the theme remains on the product page.
   - The variant picker is hidden too because the theme's own picker is not used with the configurator's button. In variant mode, the combination chosen in the configurator decides the variant that goes into the cart. In reference price mode, the variant that was selected when the product page opened goes into the cart ("5. Price modes").
   - Only when you set the cart mode to "Theme buy button", hide just the price block (Appendix A).
6. **Check it**: On the product page, choose options and press "Add to cart"; the cart line should show what was chosen. Then place one test order with the test payment gateway (Bogus Gateway) and check that `_configurator` and `_preview` are kept in the order details. Before opening the `_preview` URL, see "Handling what is stored on the order" (section 6). After you save the metafield, it can take some tens of seconds before the product page shows it. If the page still shows the earlier content, wait a little and reload.

Products with an empty metafield show nothing, so the same product template can be shared with products that have no 3D.

**Replacing an already installed kit with a new version**: In the theme code editor, open the file with the same name, replace its whole contents with the contents of the new version, and save. Do the asset files first, then the section. The editor may reopen files that were open before. Before pasting, check that the file name shown on the screen is the file you mean to replace. The reliable way to open a file is to type its name with the folder, such as `assets/suminawa-configurator.js`, into the editor's file name search. After the files are replaced, a section already placed on the product template keeps working and keeps its setting values. A section already placed keeps the name it had when it was placed (the name is written into the template). Newly placed sections show the new name.

With Shopify CLI, copy the contents of `theme/` into your local theme folder and push only the added files:

```bash
shopify theme push --only sections/suminawa-configurator.liquid --only "assets/product-configurator*" --only "assets/suminawa-configurator*"
```

**If "Files" does not accept `.glb`**: upload the model to the product's "Media" as a 3D model and put that GLB URL in `model.src`. Depending on the theme, the 3D model may then also appear in the product media; move it to the end of the media list if you prefer.

## 4. Settings (metafield `custom.configurator`)

The 3D settings plus one `shopify` block. `samples/tumbler.metafield.json` is a complete example.

### 4-1. 3D settings

| Key | Meaning |
| --- | --- |
| `model.src` | GLB URL starting with `https://` or `//` (required). The host must be `cdn.shopify.com` or the store's own host |
| `model.allowExternal` | Set to `true` to accept a GLB on another host (default `false`). Customers' browsers will then connect to that host |
| `model.camera` | Viewpoint: `distance`, `elevation`, `azimuth` |
| `model.scale` / `model.rotation` | Scale factor / initial rotation (degrees) |
| `scene.background` / `scene.floor` / `scene.autoRotate` | Background color, floor color, auto-rotate until touched |
| `price.note` | Note next to the price ("Tax included") |
| `product.name` / `product.sku` | Default to the product title and the SKU of the selected variant |
| `groups` | Option groups (1–20), see below |
| `features.export` / `share` / `copy` | Whether to show the "Save as PNG", "Copy share URL" and "Copy selection" buttons. By default the PNG and share URL buttons are shown and the copy button is not, because the copied JSON holds 0 for the prices and does not match the price on the screen. To show it, write `"features": { "copy": true }` |

`price.base` and `price.currency` are not used (the Shopify price and currency are used).

| `type` | Changes | Keys |
| --- | --- | --- |
| `color` | Part color | `target` (mesh names) `required` `default` `options[]`: `{ id, label, color, roughness?, metalness?, price? }` |
| `material` | Part material | `target` `required` `default` `options[]`: `{ id, label, color, roughness, metalness, price? }` |
| `variant` | Show / hide parts | `required` `default` `options[]`: `{ id, label, show?, hide?, price? }` |
| `text` | Engraving | `target` `maxChars` `pattern` `placeholder` `font` `color` `background` `price`. `pattern` is accepted only as one set of allowed characters in `[ ]` followed by `*` or `+` (for letters and digits only, `[A-Za-z0-9 .&-]*`). Write ranges from the smaller end, as in `a-z` (`z-a` can't be read). If left out, the default applies (see "Characters allowed in engraving" below). `patternMessage` is the message for characters that don't match |
| `image` | Logo | `target` `maxBytes` `background` `price`. PNG, JPEG and SVG images are accepted, and the only size limit is `maxBytes` (bytes). There is no setting to restrict the types and no limit on pixel dimensions |

**Characters allowed in engraving**: If you leave out `pattern`, the 3D module's default applies. It accepts kanji, hiragana, katakana (half-width too), letters, digits, spaces (full-width too) and common symbols (`.` `,` `&` `'` `!` `?` `(` `)` `/` `・` `、` `。` `-`), and rejects emoji, symbols such as `<` `>` `%`, and invisible characters. The sample settings leave `pattern` out too.

You can change the allowed characters to match your store's engraving rules. For letters and digits only, write `"pattern": "[A-Za-z0-9 .&-]*"` and put the message for characters that don't match in the group's `patternMessage` (for example `"patternMessage": { "ja": "英数字と記号（. & -）、空白で入力してください。", "en": "Please use letters, numbers, spaces and the symbols . & -" }`). Without it, "This contains characters that can't be used (emoji and some symbols can't be engraved)." is shown. `maxChars` counts some rare kanji (such as "𠮷") as 2 characters. A long engraving is shrunk, and wrapped onto two lines when it would get too small. With the sample model, up to 12 characters can be read from the front. When the customer enters the engraving field, the 3D turns to face the engraving surface.

If the settings contain an item not in this table (including a misspelling such as `requried`), they stop as a settings error, and the theme editor shows where and what it is (for example `groups[0] の知らない項目です: requried`). While there is an error, customers see the standard purchase form ("8. How settings errors appear").

Labels (`label`, `placeholder`, `patternMessage`, `price.note`) can be `"Body color"` or `{ "ja": "本体の色", "en": "Body color" }`. If you write only one language, it is used for both.

### 4-2. The `shopify` block

| Key | Meaning |
| --- | --- |
| `priceMode` | `variant` or `reference`. Defaults to the section setting |
| `options` | Group id → product option name, e.g. `{ "body": "Color", "size": "Size", "engrave": "Engraving option" }` |
| `values` | Group id → { option id → option value }. If omitted, the option's Japanese label (or its only label) is matched. Engraving and logo use `{ "filled": "Yes", "empty": "No" }`; "none" of an optional group is `empty` |
| `properties` | Group id → `false` hides that group from the visible cart lines |
| `referenceNote` | Overrides the reference price note (can't be empty) |

## 5. Price modes

**The amount actually charged is only the price of the variant in the cart.** Shopify does not let a theme change prices, so there are two modes.

- **Variant mode (`variant`, recommended)**: Link groups to product options and show the price of the matching variant. Differences such as engraving can be linked to an option like "Engraving option (Yes / No)". A group with a price difference that is not linked is reported as a settings error (so customers never see a difference that can't be charged). Shopify products have up to three options, so up to three groups can be linked. When a combination has no variant or is sold out, the button is disabled with the reason. The reason appears under the price after the combination is chosen. When changing one linked group would make it available, the options are named too, as in "Sold out. Available with Navy or 350 ml." Option buttons that would lead to a sold-out (or missing) combination carry a "Sold out" ("Unavailable") mark.
- **Reference price mode (`reference`)**: Shows the variant price plus the group differences as a "Reference price", always with a note (default "The cart and checkout show the base price. We'll let you know the difference for your choices after you order. The final amount will be confirmed in our order confirmation."). When no group has a price difference, the default note is only the last sentence ("The final amount will be confirmed in our order confirmation."). **This mode is meant for products with a single variant** (with more than one, the theme editor shows a note saying so). The variant that goes into the cart is the one selected on the product page when it loaded, for the "Configurator button" cart mode, or the one currently in the form when the buy button is pressed (following the theme's own variant picker), for the "Theme buy button" mode (Appendix A). The reference price is kept as `_reference_price` in the order details. Collect the difference by editing the order or with a draft order invoice. Do not decide the amount from `_reference_price` alone; work it out from `_configurator` and your own price table, as described in "Handling what is stored on the order" (section 6). Because each order needs an adjustment, this suits small differences or made-to-order shops.

  **In reference price mode, the amount shown in the cart and at checkout is only the variant price.** What goes into the cart is the variant, and Shopify charges the price of the variant in the cart (the price in `/cart.js`, which returns the cart contents, was seen to be the variant price; the checkout screen in reference price mode has not been seen). For example, a customer who saw a reference price of `¥6,800` on the product page sees in the cart, and pays at checkout, the variant price of `¥3,800`. The difference of `¥3,000` is collected separately by the store after the order (by editing the order or with a draft order invoice). `_reference_price` is the amount for one item; with quantity 3 it is still `¥6,800`. The difference to collect is the difference for one item multiplied by the quantity.

With Shopify Markets, when the display currency differs from the store currency, variant mode shows Shopify's converted price as is. Reference price mode shows neither the per-option price differences nor the reference price total, only "The reference price is shown in (store currency)."

The price and the reference price are shown in the store's money format, written the same way as the prices the theme shows. When the display currency differs from the store currency, or the store's format can't be reproduced faithfully as plain text (for example, when it contains digits inside tags), the browser's format is used.

In reference price mode, the price differences next to the options are written by the 3D configurator itself in the browser's format. The currency symbol, its position, and the decimal and thousands separators can therefore look different from the reference price total (for example, a total of `4.700,00 €` with a difference of `+€5.00`; a total of `¥4,700` with a difference of `+￥500`). On a yen store the total shows the half-width `¥` and the differences show the full-width `￥`. The position of the symbol and the separators are the same for the total and the differences when the store's money format is one currency symbol character directly followed by `{{amount}}` or `{{amount_no_decimals}}` (such as `${{amount}}` or `¥{{amount_no_decimals}}`). For stores with any other format (such as `{{amount}} kr`, `Rs.{{amount}}` or `{{amount_with_comma_separator}} €`), we recommend variant mode, or leaving out the per-option price differences (`price`). In reference price mode with price differences, when the store's format is not of that form, a note is shown in the theme editor.

## 6. What goes into the cart and the order

| Line | Example | Shown in |
| --- | --- | --- |
| Group label | `Lid: Stainless steel`, `Engraving text: MINATO`, `Logo: logo.png (please email the file to us after ordering)` | Cart, checkout, order details |
| `_configurator` | `body=navy;lid=steel;size=500;engrave=MINATO` | Order details only |
| `_preview` | Product URL + `#pc=…` (opens the same 3D; before opening it, see "Handling what is stored on the order" below) | Order details only |
| `_reference_price` | The same text as the reference price shown on the screen. It is in the store's money format, for example `$47.00` for a US dollar store or `¥4,700` for a yen store (reference price mode only; when deciding the amount to charge, see "Handling what is stored on the order" below) | Order details only |

- Line labels and values are kept in the language the customer was viewing. The examples above are for an English storefront; on a Japanese storefront they read `フタ: ステンレス` and `刻印の文字: MINATO`. The "Language" setting in "7. Section settings" decides which one is used.
- **Give the product option and the engraving group different names.** When the presence of engraving is linked to a product option, the cart shows two lines: the option line (`Engraving option: Yes`) and the line with the entered text (`Engraving text: MINATO`). If the option name and the group label are both "Engraving", two lines with the same label appear. The line label comes from the group's `label`; the option name is set on the product.
- The variant name (such as "Sand / 500 ml / Yes") shows the option values as registered on the product. The configurator's language setting does not change it.
- Amounts follow the store currency. The price differences (`price`) in the sample settings are numbers meant for a yen store, so rewrite them for other currencies.
- Groups linked to variants (color, size…) are not repeated as visible lines, because the variant name already shows them. Optional groups left empty are not shown.
- Each value is up to 250 characters; line breaks become spaces. A `_preview` longer than 250 characters would be an unusable URL, so it is not stored on that order (the other lines are). In that case a notice appears in the theme editor (not on the storefront). Shorten the product URL (handle) or lower the engraving's `maxChars` to keep it.
- The logo image stays in the customer's browser and is not attached to the order. Only the file name is kept, with a request to email the file. The share URL and `_preview` do not carry the logo image either. The 3D shown when `_preview` is opened has no logo.
- After a logo image is chosen, the browser's "No file chosen" text stays next to the file button. The name of the chosen file appears on the line below it.
- After "Save as PNG" is pressed, nothing appears on the screen (the file is saved).
- The "Copy share URL" button copies the URL of the page at that moment (including the part from `?` onward) with the choices added. If the URL carries tracking text from ads and the like, that is copied too. `_preview`, which is kept on the order, is built from the product URL, so it carries no tracking text.

### Handling what is stored on the order

- **The lines stored on the order are values sent by the customer's browser.** The visible lines, and `_configurator`, `_preview` and `_reference_price`, can all be altered by someone who calls the cart directly. The rules on which characters and how many can be engraved are a convenience on the screen, not a guarantee of what is stored on the order.
- **The amount charged and the item to fulfil are decided by the variant.** In reference price mode, what the customer pays at checkout is only the variant price. The store collects the difference separately, by editing the order or with a draft order invoice. Work out the difference for one item from the contents of `_configurator` and your own price table, and multiply it by the quantity. `_reference_price` is the amount for one item and is a value sent by the customer's browser. Do not invoice from `_reference_price` alone.
- **Before opening `_preview`, check that the URL starts with your own store's domain.** If what it shows disagrees with the visible lines of the order, contact the customer.
- **Check the engraving text yourself before production.**
- **Templates that print or display the lines must escape the values.** In order notification emails, packing slips, apps and the like, do not output the line values into HTML as they are.
- **Don't set `pattern` to `null` for engraving groups.** With `null`, invisible characters and characters that change the text direction are accepted within the length limit. The default used when `pattern` is left out rejects them.

## 7. Section settings (theme editor)

| Setting | Meaning | Default |
| --- | --- | --- |
| Language | Match the store language / Japanese / English. Sets the language of the customer-facing text and of the cart line labels and values | Match the store language |
| 3D height (desktop / mobile) | px | 560 / 420 |
| Price mode | Used when the metafield omits `priceMode` (Variant price / Reference price) | Variant price |
| Cart mode | Configurator button / Theme buy button (Appendix A) | Configurator button |
| Show quantity | | On |
| Button label | Empty means "Add to cart" | Empty |
| Show errors in editor | Lists settings errors inside the theme editor. Never shown to customers | On |

- **How "Language" is chosen**: With "Match the store language", Japanese is used when the storefront language the customer is viewing is Japanese, and English is used for every other language. To use Japanese on a storefront in another language, choose "Japanese" to fix it.
- **Names and labels in the settings panel**: The section is named "3D Configurator", and the setting labels show Japanese and English side by side, such as "言語 / Language". They do not switch with the admin language. Switching would require editing the theme's translation files (`locales`), and the kit is built not to touch the theme's own files. Shopify's theme check tool examines how the section file is written. This section passes theme check with no errors. Theme check does not cover the checks made when the file is saved in the admin (such as the length of labels). The lengths of the labels and options are checked by the kit's own tests.

"Add to cart" adds the item and then goes to `/cart`. If your theme opens a cart drawer instead, listen for the `suminawa-configurator:added` event and call `preventDefault()` to stay on the page (`event.detail` is the added line).

**Loading the 3D, and behavior on phones** (all handled by the bundled 3D module):

- The 3D module (about 1 MB) and the GLB are loaded once the 3D frame comes near the screen, so customers who never look at the 3D don't pay for it in data and page weight. While the 3D frame is off screen, drawing stops.
- On phones, sliding vertically over the 3D scrolls the page and a sideways swipe rotates the 3D. Two fingers zoom and rotate. The hint under the 3D switches to a touch version ("Swipe sideways to rotate. Use two fingers to zoom and rotate."). The finger behavior can be changed with the CSS variable `--pc-touch-action`.
- On screens narrower than 60rem (about 960 px), shadows are lighter and the 3D does not rotate by itself even when `scene.autoRotate` is `true`, because constant drawing uses battery and heats the device.
- On wide screens, the 3D frame stays at the top while the page scrolls. If a theme with a fixed header hides the frame under the header, set `--pc-sticky-top` to the header height in the theme's CSS.
- The 3D frame gets an accessible name with the product name and the current choices for screen readers. It can be reached with Tab and rotated with the left and right arrow keys.

## 8. How settings errors appear

If the metafield JSON has an error, the configurator does not run. This is how it appears:

| Place | What appears |
| --- | --- |
| Theme editor | A red box in place of the section lists what to fix. When the section setting "Show errors in editor" is off, the same short message as on the storefront is shown in place of the list |
| Storefront | No 3D is shown. The details of the error are not shown on the screen; a short message, "The 3D customizer can't be shown right now. You can still order with the form below.", and a standard purchase form appear instead. In the "Theme buy button" cart mode, the theme's button can be used, so neither the message nor the form is shown and the whole section is hidden |
| Browser console | One warning line starting with `[suminawa-configurator]`. This line carries the same error text as the list in the theme editor. The console is the browser's screen for developers, which customers do not normally open. On a customer's screen too, it can be read by opening it. The error text can contain values written in the settings (such as a host name or a `pattern`). It never contains what a customer typed |

The same applies when `product-configurator.global.js` in the assets is not loaded.

**Sales don't stop while the settings have an error.** In the "Configurator button" cart mode the theme's price and buy button are hidden, so a standard purchase form is shown in place of the configurator. It has the product's variants (name and price; sold-out ones can't be chosen), a "Requests (engraving text, etc.)" field, a quantity field (when it is on in the section settings) and an "Add to cart" button. The button posts to `/cart/add` like an ordinary product form and goes to the cart. What the customer writes under "Requests" is stored in the cart and the order as a "Requests (engraving text, etc.)" line. `_configurator` and `_preview` are not stored in this case, so check the engraving text with the customer from the order.

- Every time you change the metafield, open the product page and check that the 3D, the price and the button appear. After you save, it can take some tens of seconds before the product page shows the change. Right after saving, the earlier content may still appear, so wait a little and reload before you judge.
- If you'd rather sell with the theme's own price and button than with the standard purchase form, make the theme's price, variant picker and buy button blocks visible again and empty the metafield. With an empty metafield, the section shows nothing (neither the message nor the form).

Notes such as "a combination has no variant" do not stop the configurator and are shown only in the theme editor.

## 9. After updating your theme

Updating to a new theme version may not carry over added files. After an update, repeat steps 4 and 5 of "3. Installation". The steps for replacing the kit itself with a new version are at the end of "3. Installation". All file names start with `suminawa-configurator` or `product-configurator`, so they never collide with the theme's own files.

## 10. FAQ

- **The section shows nothing, or shows "The 3D customizer can't be shown" with a standard purchase form** — The product's `custom.configurator` metafield is empty or has an error, or `product-configurator.global.js` is missing from the theme's assets. Open the theme editor to see the list of errors ("8. How settings errors appear"). In addition, if an app rewrites the theme's scripts (inlining them into the page, combining them into one, loading them later, serving them from another place, and so on), the kit can't confirm where its own script came from and does not start. In such an app, exclude the files whose names start with `suminawa-configurator` and `product-configurator` from rewriting. An app that has no setting for exclusions can't be used together with this kit.
- **"We couldn't load the 3D model"** — Open the `model.src` URL in your browser and check that the GLB downloads.
- **"This combination isn't available"** — The product has no variant for that combination. Check the option values (spelling, spaces) and `shopify.values`.
- **The chosen options don't appear in the cart** — Check that your theme's cart shows line-item properties. Even with a theme that doesn't show them in the cart, they are kept in the order details.
- **The cart lines are in English** — English is used when the storefront language is not Japanese. Set the section's "Language" to "Japanese" to fix it ("7. Section settings").
- **Turning the mouse wheel over the 3D zooms the 3D and the page does not scroll** — Over the 3D, the wheel is used to zoom the 3D. To scroll the page, move the pointer outside the 3D. This can't be changed in the settings.
- **No product image appears in product lists or the cart** — The images shown in product lists, the cart and order emails are the product's own images registered in Shopify. The kit does not add product images. Register product images separately from the 3D model.
- **Few countries can be chosen at checkout** — The countries offered at checkout come from the store's shipping settings and markets, not from the kit.
- **The browser console shows `THREE.Clock: This module has been deprecated.`** — This warning comes from the bundled 3D library and does not affect how the configurator works.
- **Preparing a 3D model** — See "Appendix D. Preparing the GLB".
- **On a phone, sliding vertically over the 3D doesn't rotate it** — On phones, vertical movement scrolls the page and a sideways swipe rotates the 3D. Two fingers zoom and rotate (see "Loading the 3D, and behavior on phones" in "7. Section settings").
- **Which version of the kit is installed in the store?** — Look at `data-sc-version` on the section element in the product page source or the browser's developer tools (it shows something like `1.1.0`). The version of the bundled 3D module is in `data-pc-version` on the element inside it. In the theme code editor, it is also on line 2 of `sections/suminawa-configurator.liquid`.

## Appendix A. Theme buy button mode

Use this when you want to keep the theme's own buy button. It needs one line of code. The steps below follow the file layout of Dawn, Shopify's free theme (`snippets/buy-buttons.liquid`). This mode has not been run to the end on a real store with any theme (see "Verified themes").

1. Add `snippets/suminawa-configurator-properties.liquid` in the theme code editor (step 4 of "3. Installation"). Until you add the line in step 2, the editor may show a warning about an unused snippet.
2. Open `snippets/buy-buttons.liquid` and find the tag that starts with `form 'product'`. The tag may span several lines and ends with `-%}` or `%}`. Add this line **right below the line where the tag ends**, as the first line inside the form. Adding it on a line in the middle of the tag breaks the tag.

   ```liquid
   {%- render 'suminawa-configurator-properties' -%}
   ```

3. Set the section's "Cart mode" to "Theme buy button". Keep the theme's buy button block and variant picker block visible, and hide only the price block.

The configurator writes the choices into the form as hidden `properties[...]` fields and sets the form's `id` to the matching variant. When there is no matching variant, the buy button is disabled. In reference price mode, the variant in the form at the moment the buy button is pressed is the one added to the cart.

**Plan on this mode not working with your theme.** Some themes redraw the purchase form when the customer picks another variant, which removes what the configurator wrote into it. Pressing the buy button then adds the item without the choice lines. If you use it, pick another variant, make a test order, and check that `_configurator` is stored in the order details. For everyday use, the configurator's own button is recommended. Forms differ between themes, so in your theme, find the file that contains the product form and add the same line there.

## Appendix B. Rebuilding the adapter

`src/` is the source of the adapter (`suminawa-configurator.js`). After editing, rebuild with one line (Node.js 20 or later):

```bash
npx esbuild src/entry.ts --bundle --format=iife --minify --charset=utf8 --target=es2020 --outfile=theme/assets/suminawa-configurator.js
```

## Appendix C. When the theme sets a Content Security Policy

On a store where the theme or an app sets a Content-Security-Policy, the kit needs the following to work. This table was made by reading the kit's code; the kit has not been run on a store with a real Content-Security-Policy.

| Directive | What is needed | Why |
| --- | --- | --- |
| `style-src` | `'unsafe-inline'` | The section passes the 3D heights through the element's `style` attribute |
| `img-src` | `blob:` and the host where the GLB is placed; also `data:` when the GLB holds its images as `data:` URLs | To read the images applied to the 3D |
| `connect-src` | `blob:` and the host where the GLB is placed | To read the GLB |
| `script-src` | The host of the theme's assets | To read the kit's three JS files |

The kit does not use `eval`, Web Workers or WebAssembly. A GLB file may itself point to images or data in other places. In that case the browser also connects to those places. Export the GLB with its images and data included (as one self-contained `.glb`).

## Appendix D. Preparing the GLB

The configurator reads one 3D model in glTF binary (`.glb`) format. The settings link colors, materials, show/hide and engraving to the model by the names of its parts.

**Exporting (Blender)**

1. Make each part whose color or material changes, each part that is shown or hidden, and each surface that carries engraving or a logo a separate object, and give it a name. Use these names in `target`, `show` and `hide`.
2. Give the engraving/logo surface UVs. The engraving image (2 wide : 1 high) fills the 0–1 UV range. On a curved surface, keep the width within what can be seen from the front; with UVs that wrap far around, the ends of a long engraving turn away and can't be read.
3. Use "File → Export → glTF 2.0" with the format set to "glTF Binary (.glb)". Leave compression (Draco) off. Keep images as PNG or JPEG.

**Naming rules**: When the 3D is loaded, some characters in names change. Spaces become `_`, and `.` `:` `/` `[` `]` are removed. For example, Blender's `Body.001` becomes `Body001` and `Lid Top` becomes `Lid_Top`. The names in the settings get the same conversion before they are matched, so you can write Blender's names (`Body.001`) as they are. If two objects share a name, the second one gets `_1` appended. Names made only of letters, digits, `-` and `_`, with no duplicates, avoid surprises. An object with several materials is split inside the file when exported, but writing the object's name in the settings reaches all of it.

**Unsupported formats**: GLB files compressed with Draco, GLB files using KTX2 (Basis Universal) images, and GLB files compressed with meshopt are not supported. They either fail with "We couldn't load the 3D model" or show without images. Files made lighter with tools such as gltf-transform are the same if they use these compressions.

**Keep images inside the file**: Exporting as `.glb` puts the images inside the file. A `.gltf` file with separate image files can't be used (you upload one file to Shopify's "Files").

**Size guide**: Customers load the GLB on phones too, so keep it at 5 MB or less, ideally 2 MB or less. As a guide, keep the whole model within 100,000 triangles and images within 2,048 px on a side (these are not limits in the kit; larger files take longer to load and may not display on older phones). The sample `samples/tumbler.glb` is 109 KB.

**When "Not in the model" appears**: If a name in the settings is not in the model, a line such as "Not in the model: body-500, strap" appears under the 3D, and `[product-configurator] Not in the model: …` is left in the browser console (on the Japanese screen it reads `モデルに無い名前`). Colors and show/hide for that name have no effect. Customers see this line too, so fix it before publishing. The names shown are after the conversion in the naming rules above. Check the spelling and the names inside the model.

**Trying with the sample**: The bundled `samples/tumbler.glb` is a sample whose parts are named `body-350`, `body-500`, `lid`, `strap` and `label`. Open it in Blender with "Import → glTF 2.0" to see how the names are set. When switching to your own GLB, first change only `model.src` in the sample settings, open the product page, and then match the names shown under "Not in the model" on the settings side or the model side.

## License and support

See `LICENSE.md`. You may modify the files and deliver them as part of a client's store. Redistribution and resale are not allowed.

If you need help, email hello@suminawa.dev. We reply within three business days.

Shopify is a trademark of Shopify Inc. This product is not an official Shopify product and is not affiliated with Shopify. The 3D view uses three.js and React Three Fiber, and the configurator UI uses React. The bundled JS includes 14 open-source packages, all under the MIT License. Their names, versions, copyright lines and the full license text are in `THIRD-PARTY-NOTICES.md`.
