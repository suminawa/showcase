# 3D Configurator for Shopify

A theme component that adds a 3D product configurator to your Shopify product page: customers rotate the product and choose colors, materials, parts and engraving. It is not an app, so there is no app review and no monthly fee. Add one section and five assets in the theme code editor, put one JSON setting into a product metafield, and it works.

- What the customer chose goes into the cart line (line-item properties) and stays in the order details
- The amount charged is the price of the product variant (see "5. Price modes")
- The customer-facing text is in English and Japanese (it follows the storefront language automatically; see "7. Section settings")
- Prices are shown in the store currency, in the store's money format (`¥4,700` for a yen store, `$47.00` for a US dollar store), written the same way as the prices the theme shows
- No server, no external service, no API key. The kit communicates with the store itself (the cart), the host that serves the theme's assets (the kit's own files), and the place the GLB in `model.src` points to. Unless you add a setting, `model.src` accepts only Shopify's file host (`cdn.shopify.com`) and the store's own host ("4-1. 3D settings"). If the GLB file itself points to files in other places, the browser connects to those places too (Appendix C)
- Requires an Online Store 2.0 theme (the themes checked on a real store are listed in "Verified themes" just below)

## Verified themes

Only the themes in this table have been checked on a real store. The kit is built to install the same way on any Online Store 2.0 theme, but other themes have not been checked.

<!-- verified-themes:start -->

The checks were made on 2026-09-29. Versions of this kit were installed one after another on three themes of a Shopify development store. The versions are named after the commits they were built from: `b9e2bf7`, `f0357e2`, `a19447b` and `e49946f`. How this zip differs from the newest one, `e49946f`, is listed under "Changed after the checks" below. The checks with these four versions were operated with a browser automation tool and with scripts run in the page. The only part operated by a person with mouse and keyboard is "Test order made by hand" below. The store currency was Japanese yen, the store language and the admin language were Japanese, and the cart mode was "Configurator button".

### Checked with version b9e2bf7 (the variant mode sample)

The screens were desktop width (912 to 1,040 px) and the mobile view of the theme editor.

| What was checked | Generated Data Theme 1.0.0 (the development store's default theme) | Dawn 16.0.0 | Horizon 4.2.0 |
| --- | --- | --- | --- |
| The section file can be saved in the code editor | Saved. The editor showed 0 errors and 0 warnings | Saved. 0 errors, 0 warnings | Saved. 0 errors, 2 warnings (both ValidScopedCSSClass about the `page-width` class; they do not affect behavior) |
| A section placed with the earlier version keeps working after the files are replaced | Checked | Checked | Checked |
| The 3D appears and the console shows no errors | Checked | Checked | Checked |
| The price appears as `¥3,800` to `¥4,700` with the half-width sign, written the same way as the price the theme shows on the cart page | Checked | Checked | Checked |
| The 3D and the price change with the choices | Checked | Checked | Checked |
| The lines on the cart page (`刻印の有無: あり`, `フタ: マットブラック`, `刻印の文字: MINATO`) | Checked | Checked | Checked (for options, only the values are listed, without the names) |
| The keys in `/cart.js` (`フタ`, `刻印の文字`, `_configurator`, `_preview`) | Checked | Checked | Checked |
| Opening the `_preview` URL gives the same choices | Checked | Checked | Checked |
| The lines in the cart drawer | Not looked at | Checked with version f0357e2 (see the list below) | Checked |
| With a settings error, only the short message appears on the storefront and one warning line appears in the console | Checked | Checked | Checked |
| With a settings error, the list of errors appears in the theme editor | Not looked at | Checked | Not looked at |
| Nothing overflows sideways in the mobile view of the theme editor | Checked (down to the price and "Add to cart") | Checked (down to the price and "Add to cart") | Checked down to the options and buttons. The price and "Add to cart" were checked with version f0357e2 (at a screen width of 406 px; see the list below) |
| The text, cart lines and `/cart.js` keys with the section's "Language" set to English | Not looked at | Checked (by editing the value in the template file, not through the field in the theme editor) | Not looked at |
| The section name in the theme editor ("3D Configurator" in the list for adding a section) and the setting labels and notes | Checked | Not looked at | Not looked at |

### Checked with version f0357e2

In the checks with this version, most presses of "カートに入れる" (add to cart) and the values put into the quantity field were operated from a script in the page. "Copy selection", "Copy share URL" and "Save as PNG" were pressed by screen position, and the copied text and the saved file were received inside the page and checked there. The real clipboard and download folder were not written.

On all three themes, saving the section (0 errors in the editor; the only warnings were the 2 on Horizon), the 3D, the price `¥3,800`, the cart lines and the `/cart.js` keys were checked again. The unused price field carrying `hidden` and `aria-hidden="true"` was also seen on all three themes. What else was checked, and on which theme, is as follows.

| What was checked | Theme | What was seen |
| --- | --- | --- |
| Reference price mode display | Dawn 16.0.0. On Horizon 4.2.0 and Generated Data Theme 1.0.0, only the display with nothing chosen | The label "参考価格" (reference price), the initial price `¥3,800`, the price differences next to the options (`+￥200` and so on; the yen sign is full-width), and the note. On Dawn, the price after choosing everything was `¥6,800` |
| Adding to the cart in reference price mode | Dawn 16.0.0 | The price in `/cart.js` is the variant price (3,800 yen) and `_reference_price` is `¥6,800`. The cart page shows only the unit price `¥3,800` and the total; the reference price does not appear |
| Adding to the cart with quantity 3 | Dawn 16.0.0 | Quantity 3, total `¥11,400`. `_reference_price` stays at `¥6,800`, the amount for one item |
| A logo (`image`) group | Dawn 16.0.0 | Choosing a PNG image shows it on the 3D and adds the difference to the price. The cart line holds the file name and the request text. The image is not sent anywhere. The `_preview` URL does not include the logo |
| Adding with an optional group left at "None" | Dawn 16.0.0 | No line for that group, and nothing for it in `_configurator` |
| One group set to `false` in `shopify.properties` | Dawn 16.0.0 | No line for that group. It stays in `_configurator` |
| A sold-out combination | Dawn 16.0.0 | "在庫切れです" (sold out) appears under the price and the button can't be pressed. After changing the combination it can be pressed. The option buttons carry no sold-out mark |
| Cart drawer | Dawn 16.0.0 | Pressing "カートに入れる" (add to cart) goes to `/cart` and the drawer does not open. Opening the drawer with the cart icon shows the lines for the choices |
| Section settings (checked by editing the values in the template file) | Dawn 16.0.0 | "Show quantity" off, "Button label", 3D heights 480 / 360, "Show errors in editor" off (the short message appears in place of the list). "Language" fixed to Japanese (the store language is Japanese, so no difference from "Match the store language" can be seen) |
| "Copy selection", "Copy share URL", "Save as PNG", "Start over" | Dawn 16.0.0 | "Copy selection": "コピーしました" (copied) appears under the button and JSON of the choices is handed over (with 0 for the prices). "Copy share URL": "URL をコピーしました" (URL copied) appears and the product URL with `#pc=…` added is handed over. "Save as PNG": a save is started under the name "ステンレスタンブラー-カスタマイズ.png"; nothing appears on the screen afterwards. "Start over": the choices and the price return to the initial ones, `¥3,800` |
| Mobile width (406 px) | Horizon 4.2.0 | The reference price, the note, the quantity and "カートに入れる" fit the width. The button is shown enabled (it was not pressed) |
| Wide screen (page width 1,200 px) | Dawn 16.0.0, Horizon 4.2.0 | Nothing overflows sideways |
| Saving the section with a 189-character setting note | All three themes | Saved |

### Checked with versions a19447b and e49946f

The checks with these two versions were made in the following way on all three themes. Nothing was checked by operating the mouse and keyboard by hand.

- Choosing the options, entering the engraving text and pressing "カートに入れる" (add to cart) were called from a script run in the page. The quantity was not changed (it stayed at 1).
- The logo image (version e49946f only) was a PNG generated in the page and put into the file input from a script. The file dialog was not opened.
- The cart contents were read by fetching `/cart.js` from a script in the page. The cart page as shown on the screen was not looked at with these two versions.
- The prices, the list of buttons, the notes and the settings were read from the text of the elements by a script in the page.
- Whether the 3D appears was judged by the presence of a `canvas` element. Only in some cases was it also seen in a screenshot.
- The theme files were replaced in the code editor with real mouse clicks and keystrokes (select all, paste, save).
- The draft themes were viewed in preview.

| What was checked | Version | Theme | What was seen |
| --- | --- | --- | --- |
| Where the kit's three JS files are read from | a19447b | All three themes | All three come from the same folder on the store's host (`/cdn/shop/t/(number)/assets/`), with `?v=…` at the end of the URL. The rule about the place did not stop a correctly installed theme |
| Normal behavior | a19447b, e49946f | All three themes | A `canvas` element is present. The price text goes from `¥3,800` to `¥4,700`. `/cart.js` holds the variant "サンド / 500 ml / あり", quantity 1, the lines `フタ: ステンレス` and `刻印の文字: MINATO`, and the keys `_configurator` and `_preview`. 0 errors in the console |
| `model.src` on another host | a19447b | Dawn 16.0.0 | A settings error. Only the short message appears on the storefront and no request goes to that host. The list in the theme editor names the host and mentions `model.allowExternal` |
| `model.allowExternal` set to `true` | a19447b | Dawn 16.0.0 (storefront only; the theme editor was not looked at) | The GLB on the other host is loaded (200) and a `canvas` element is present |
| An engraving `pattern` not of the accepted form (`([A-Za-z0-9]+)+`) | a19447b | Dawn 16.0.0 | A settings error. The list in the theme editor shows the accepted form |
| An engraving `pattern` with a reversed range (`[z-a]*`) | a19447b | Dawn 16.0.0 | A settings error. The message was the same as for a wrong form (this zip changes it to a separate message) |
| The core file (`product-configurator.global.js`) present but without the core in it (checked by replacing the file's contents) | a19447b | Dawn 16.0.0 | Only the short message appears on the storefront. The list in the theme editor says "product-configurator.global.js が読み込まれていません。" (is not loaded). One warning with the same text in the console |
| Settings error texts appearing in the console | a19447b | Dawn 16.0.0 | In the storefront's console, the same text as in the theme editor's list appears as a warning prefixed with `[suminawa-configurator]` |
| Markup-like text (`</script><img src=x onerror=alert(1)>`) in the product title and a group label | a19447b | Dawn 16.0.0 (preview) | Both the title and the label are shown as text (read from the text of the elements, and also seen in screenshots). No alert appears and no image element is created. The two JSON blocks in the page source contain no raw `<` or `>` (recorded by code points; `<` is written as `\u003c` and `>` as `\u003e`) |
| Reference price mode (silver / stainless steel / 500 ml / engraving) | a19447b | Dawn 16.0.0 | The reference price text is `¥4,900`. `_reference_price` in `/cart.js` is also `¥4,900`, and the price in `/cart.js` is the variant price |
| The "Copy selection" button not shown by default | e49946f | All three themes | Not shown. "Save as PNG", "Copy share URL" and "Start over" are shown |
| `"features": { "copy": true }` added | e49946f | Dawn 16.0.0 | Four buttons appear, including "Copy selection" |
| The short labels and the note of the sample settings (reference price mode) | e49946f | Dawn 16.0.0 | The group labels are "刻印の文字" and "ロゴ入れ". The line in `/cart.js` is `ロゴ入れ: logo-test.png（ご注文後にメールでお送りください）`. The note is the sample's text |
| The default note when `referenceNote` is omitted | e49946f | Dawn 16.0.0 | "カートとお支払いの画面には、基本の価格が出ます。お選びの内容による差額は、ご注文のあとにご案内します。お支払い金額は、ご注文確認のご連絡で確定します。" (the Japanese default note) |

### Test order made by hand (version e49946f)

On 2026-09-29, on the published Generated Data Theme 1.0.0, a person operated the storefront with mouse and keyboard and went through to completed payment with the test payment gateway (Bogus Gateway). The store currency was Japanese yen, the store language was Japanese, and the sample was the variant mode one.

- What the person reported: they tried everything through to completed payment and found no problems other than the following two. Few countries could be chosen at checkout, and no product image appeared in the product list or the cart (both come from the store's settings and the product's registration, and are covered in "10. FAQ"). No individual report was received on rotating the 3D, "Save as PNG", or pasting and opening the share URL.
- What was seen in the order details in the admin: the "test order" notice. The product line was "ステンレスタンブラー ／ ネイビー / 500 ml / あり", unit price 4,700 yen, quantity 1. The visible lines were `フタ: マットブラック` and `刻印の文字: MINATO`. `_configurator` was `body=navy;lid=black;size=500;engrave=MINATO`. `_preview` was the product URL with `#pc=…` added. The order was marked paid.
- The result of opening the `_preview` URL kept on the order: reading the elements of the page by script, the chosen options were navy / matte black / 500 ml, the engraving field held `MINATO`, the price was `¥4,700`, and a `canvas` element was present, the same as the order. In this step the 3D picture itself was not looked at on the screen.
- The admin shows that the order confirmation email was sent. The contents of the email were not looked at.

Not yet checked on any theme:

- Orders: a test order in reference price mode and the checkout screen in that case (`_reference_price` being kept in the order). How the lines appear in the order confirmation email. A test order on themes other than Generated Data Theme 1.0.0
- Currencies: display in the store's money format for currencies other than Japanese yen. Display when the display currency differs from the store currency (Shopify Markets)
- Unavailable combinations: the display for a combination with no variant
- Settings keys: per-option mapping in `shopify.values`, `features.export` and `features.share` set to `false`, `model.scale` and `model.rotation`, `product.name` and `product.sku`, and the default note when no group has a price difference
- Section settings: "Price mode" set to reference price (reference price mode was checked through `priceMode` in the metafield). The difference between "Language" fixed to Japanese and "Match the store language" (on a Japanese store no difference can be seen)
- Cart modes: theme buy button mode (Appendix A). It was stopped after adding the snippet and has not been run to the end. In `snippets/buy-buttons.liquid` of Dawn 16.0.0, the `form 'product'` tag was seen to span seven lines. Staying on the page with the `suminawa-configurator:added` event
- Situations that were not seen to happen: the message when the core file (`product-configurator.global.js`) itself is missing (404) (the case where the file is present but without the core in it was checked). The place for the 3D being hidden when drawing the 3D fails partway. A settings error when the 3D module is in a different place from the kit's script. Settings not being read when they are in an element other than `<script type="application/json">`
- Ways to install: pushing with Shopify CLI. Uploading the GLB to the product's "Media"
- Theme editor: the full text of the setting options when opened (only the text cut off by the field width was seen)
- Screen width: screens where the page is wider than 1,200 px
- Operation by hand: the things with no individual report in the test order made by hand (rotating the 3D, "Save as PNG", pasting and opening the share URL, the lines shown on the cart page). Operating by hand with the version in this zip installed (the test order made by hand used version e49946f)
- Everything under "Changed after the checks" below

Theme blocks that are hidden (the names are those shown with the admin in Japanese):

| Theme | Hidden blocks |
| --- | --- |
| Generated Data Theme 1.0.0 | 「商品価格」 (price), 「バリエーションピッカー」 (variant picker), 「購入ボタン」 (buy buttons) |
| Dawn 16.0.0 | 「商品価格」 (price), 「バリエーションピッカー」 (variant picker), 「数量セレクター」 (quantity selector), 「購入ボタン」 (buy buttons). The quantity selector is visible from the start; if you leave it, there are two quantity fields |
| Horizon 4.2.0 | 「価格」 (price), found in 「ヘッダー」 (header) inside 「詳細」 (details), and 「バリエーションピッカー」 (variant picker) and 「購入ボタン」 (buy buttons) inside 「詳細」. The quantity field is part of the buy buttons block |

On Horizon 4.2.0, while the buy buttons block was visible, a buy bar appeared at the bottom of the screen. Even with "Sand / Matte black / 500 ml / with engraving" (4,700 yen) chosen in the configurator, the bar stayed on the default variant, "Navy / 350 ml / no engraving" (3,800 yen). Pressing the button on the bar added that default variant to the cart with quantity 1 and none of the lines for the choices. A variant different from the combination the customer chose goes into the cart, at a different price. After the buy buttons block was hidden, the bar no longer appeared. Always hide that block.

Earlier checks: on the same day, both a US dollar / English store and a Japanese yen / Japanese store were checked with the files of a still earlier version. The names of the blocks to hide and the result of pressing Horizon's buy bar are from those records.

Changed after the checks (the differences between version e49946f and this zip; none of these has yet been checked on a real store):

- When an engraving `pattern` has the right form but can't be read as a regular expression (such as `[z-a]*`, a reversed range), a message saying so and naming the usual cause is shown, not the message about the form
- When `features` in the settings is `null`, it is treated as if it were not written (the "Copy selection" button is not shown)

Apart from these two, no change was made from version e49946f to what customers see or to what goes into the cart. The files in this zip that differ from version e49946f are `theme/assets/suminawa-configurator.js`, `src/config.ts`, `README.ja.md`, `README.en.md`, `CHANGELOG.md` and `BUILD.txt`.

<!-- verified-themes:end -->

## 1. What's in the zip

| Path | Contents |
| --- | --- |
| `theme/sections/suminawa-configurator.liquid` | The section you place on the product page |
| `theme/snippets/suminawa-configurator-properties.liquid` | Snippet for the theme buy button mode (Appendix A) |
| `theme/assets/product-configurator.global.js` | The configurator |
| `theme/assets/product-configurator-3d.global.js` | The 3D view (about 1 MB, loaded when shown) |
| `theme/assets/product-configurator.css` | Configurator styles |
| `theme/assets/suminawa-configurator.js` | The Shopify adapter (price and cart) |
| `theme/assets/suminawa-configurator.css` | Adapter styles |
| `samples/tumbler.metafield.json` | Sample settings (variant mode) |
| `samples/tumbler-reference.metafield.json` | Sample settings (reference price mode, with price differences) |
| `samples/tumbler.glb` | Sample 3D model (stainless tumbler) |
| `page/mock-product.html` | A sample product page that runs without Shopify |
| `src/` | Adapter source code (TypeScript, free to modify) |
| `BUILD.txt` | The version of this zip and the commit it was built from |

## 2. Try it without Shopify

Start a simple server in the unzipped folder and open `page/mock-product.html`. Opening the file directly can't load the 3D data because of browser rules.

```bash
npx serve .
# open /page/mock-product.html?lang=en at the URL shown
```

Choose a color, size and engraving, then press "Add to cart": what the cart would receive is shown at the bottom of the page (the cart is not real).

## 3. Installation

1. **Upload the GLB**: In the admin, go to "Content → Files", upload your `.glb` and copy its URL. The URL starts with `https://cdn.shopify.com/`; for a `.glb` it looks like `https://cdn.shopify.com/3d/models/o/(letters and digits)/(file name).glb`, which is different from the `/s/files/...` form used for images.
2. **Define the metafield**: In "Settings → Custom data → Products", add a new definition and set its type to "JSON". You can choose any name, but the key is generated from the name, so **before saving, check that the "Namespace and key" field shown under the name reads `custom.configurator`**. If it doesn't, edit that field to `custom.configurator` and then save. If you saved it with a different key, create the definition again with the right key.
3. **Enter the settings**: In the product editor, paste JSON based on `samples/tumbler.metafield.json` into the metafield. Set `model.src` to the URL from step 1 and match `shopify.options` to the product option names ("4. Settings"). Even if you created your products with a bulk import, paste this setting in the product editor.
4. **Add the files**: From "Online Store → Themes", open the code editor for your theme. It shows the theme's folders and files on the left. (Button names in this screen change with Shopify updates, so the steps below describe what to do rather than which button to press.)
   - First, add the five files in `theme/assets` to the `assets` folder, one at a time: create a new file with the same name, paste the contents as they are and save. Two of them have large contents, `product-configurator-3d.global.js` (969 KB) and `product-configurator.global.js` (219 KB), so select the whole file before copying. When you finish, check that all five names appear in the `assets` folder.
   - Next, in the `sections` folder, create a new file named `suminawa-configurator.liquid`, paste the contents of `theme/sections/suminawa-configurator.liquid` as they are, and save. If you add the section first, the editor reports errors saying the asset files are missing, so add the assets first.
   - If you use Shopify CLI, you can push the files with a command instead of pasting (shown right after these steps).
   - Only if you use the theme buy button mode (Appendix A), add `suminawa-configurator-properties.liquid` to the `snippets` folder the same way.
5. **Place it**: In the theme editor, open the product template, add a section and choose "3D Configurator".
   - The new section is added at the bottom of the template, below sections such as related products. In the list on the left, drag it up so that it sits right above or below the section that shows the product information.
   - So that the price and button don't appear twice, hide the theme's own **price, variant picker, quantity field and buy button** blocks, using the eye icon next to each block (no code changes needed). Block names and places differ between themes. For the names and places on the checked themes, see the tables in "Verified themes".
   - The configurator shows its own quantity field (when the section setting "Show quantity" is on, which is the default). The configurator's button does not use the value of the theme's quantity field. If the theme's quantity field is visible, hide it.
   - If the theme's buy button is left visible, some themes keep a place where the product can be added to the cart without the choices made in the configurator. After hiding the blocks, check that no buy button or buy bar from the theme remains on the product page.
   - The variant picker is hidden too because the theme's own picker is not used with the configurator's button. In variant mode, the combination chosen in the configurator decides the variant that goes into the cart. In reference price mode, the variant that was selected when the product page opened goes into the cart ("5. Price modes").
   - Only when you set the cart mode to "Theme buy button", hide just the price block (Appendix A).
6. **Check it**: On the product page, choose options and press "Add to cart"; the cart line should show what was chosen. Then place one test order with the test payment gateway (Bogus Gateway) and check that `_configurator` and `_preview` are kept in the order details. Before opening the `_preview` URL, see "Handling what is stored on the order" (section 6). After you save the metafield, it can take some tens of seconds before the product page shows it. If the page still shows the earlier content, wait a little and reload.

Products with an empty metafield show nothing, so the same product template can be shared with products that have no 3D.

**Replacing an already installed kit with a new version**: In the theme code editor, open the file with the same name, replace its whole contents with the contents of the new version, and save. Do the asset files first, then the section. The editor may reopen files that were open before. Before pasting, check that the file name shown on the screen is the file you mean to replace. The reliable way to open a file is to type its name with the folder, such as `assets/suminawa-configurator.js`, into the editor's file name search. After the files are replaced, a section already placed on the product template keeps working and keeps its setting values. A section already placed keeps the name it had when it was placed (the name is written into the template). Newly placed sections show the new name.

With Shopify CLI, copy the contents of `theme/` into your local theme folder and push only the added files:

```bash
shopify theme push --only sections/suminawa-configurator.liquid --only "assets/product-configurator*" --only "assets/suminawa-configurator*"
```

**If "Files" does not accept `.glb`**: upload the model to the product's "Media" as a 3D model and put that GLB URL in `model.src`. Depending on the theme, the 3D model may then also appear in the product media; move it to the end of the media list if you prefer.

## 4. Settings (metafield `custom.configurator`)

The 3D settings plus one `shopify` block. `samples/tumbler.metafield.json` is a complete example.

### 4-1. 3D settings

| Key | Meaning |
| --- | --- |
| `model.src` | GLB URL starting with `https://` or `//` (required). The host must be `cdn.shopify.com` or the store's own host |
| `model.allowExternal` | Set to `true` to accept a GLB on another host (default `false`). Customers' browsers will then connect to that host |
| `model.camera` | Viewpoint: `distance`, `elevation`, `azimuth` |
| `model.scale` / `model.rotation` | Scale factor / initial rotation (degrees) |
| `scene.background` / `scene.floor` / `scene.autoRotate` | Background color, floor color, auto-rotate until touched |
| `price.note` | Note next to the price ("Tax included") |
| `product.name` / `product.sku` | Default to the product title and the SKU of the selected variant |
| `groups` | Option groups (1–20), see below |
| `features.export` / `share` / `copy` | Whether to show the "Save as PNG", "Copy share URL" and "Copy selection" buttons. By default the PNG and share URL buttons are shown and the copy button is not, because the copied JSON holds 0 for the prices and does not match the price on the screen. To show it, write `"features": { "copy": true }` |

`price.base` and `price.currency` are not used (the Shopify price and currency are used).

| `type` | Changes | Keys |
| --- | --- | --- |
| `color` | Part color | `target` (mesh names) `required` `default` `options[]`: `{ id, label, color, roughness?, metalness?, price? }` |
| `material` | Part material | `target` `required` `default` `options[]`: `{ id, label, color, roughness, metalness, price? }` |
| `variant` | Show / hide parts | `required` `default` `options[]`: `{ id, label, show?, hide?, price? }` |
| `text` | Engraving | `target` `maxChars` `pattern` `placeholder` `font` `color` `background` `price`. `pattern` is accepted only as one set of allowed characters in `[ ]` followed by `*` or `+` (for example `[A-Za-z0-9 .&-]*`). Write ranges from the smaller end, as in `a-z` (`z-a` can't be read). Always set it |
| `image` | Logo | `target` `maxBytes` `background` `price`. PNG, JPEG and SVG images are accepted, and the only size limit is `maxBytes` (bytes). There is no setting to restrict the types and no limit on pixel dimensions |

Labels (`label`, `placeholder`, `price.note`) can be `"Body color"` or `{ "ja": "本体の色", "en": "Body color" }`. If you write only one language, it is used for both.

### 4-2. The `shopify` block

| Key | Meaning |
| --- | --- |
| `priceMode` | `variant` or `reference`. Defaults to the section setting |
| `options` | Group id → product option name, e.g. `{ "body": "Color", "size": "Size", "engrave": "Engraving option" }` |
| `values` | Group id → { option id → option value }. If omitted, the option's Japanese label (or its only label) is matched. Engraving and logo use `{ "filled": "Yes", "empty": "No" }`; "none" of an optional group is `empty` |
| `properties` | Group id → `false` hides that group from the visible cart lines |
| `referenceNote` | Overrides the reference price note (can't be empty) |

## 5. Price modes

**The amount actually charged is only the price of the variant in the cart.** Shopify does not let a theme change prices, so there are two modes.

- **Variant mode (`variant`, recommended)**: Link groups to product options and show the price of the matching variant. Differences such as engraving can be linked to an option like "Engraving option (Yes / No)". A group with a price difference that is not linked is reported as a settings error (so customers never see a difference that can't be charged). Shopify products have up to three options, so up to three groups can be linked. When a combination has no variant or is sold out, the button is disabled with the reason. The reason appears under the price after the combination is chosen. The option buttons carry no sold-out mark.
- **Reference price mode (`reference`)**: Shows the variant price plus the group differences as a "Reference price", always with a note (default "The cart and checkout show the base price. We'll let you know the difference for your choices after you order. The final amount will be confirmed in our order confirmation."). When no group has a price difference, the default note is only the last sentence ("The final amount will be confirmed in our order confirmation."). **This mode is meant for products with a single variant** (with more than one, the theme editor shows a note saying so). The variant that goes into the cart is the one selected on the product page when it loaded, for the "Configurator button" cart mode, or the one currently in the form when the buy button is pressed (following the theme's own variant picker), for the "Theme buy button" mode (Appendix A). The reference price is kept as `_reference_price` in the order details. Collect the difference by editing the order or with a draft order invoice. Do not decide the amount from `_reference_price` alone; work it out from `_configurator` and your own price table, as described in "Handling what is stored on the order" (section 6). Because each order needs an adjustment, this suits small differences or made-to-order shops.

  **In reference price mode, the amount shown in the cart and at checkout is only the variant price.** What goes into the cart is the variant, and Shopify charges the price of the variant in the cart (the price in `/cart.js`, which returns the cart contents, was seen to be the variant price; the checkout screen in reference price mode has not been seen). For example, a customer who saw a reference price of `¥6,800` on the product page sees in the cart, and pays at checkout, the variant price of `¥3,800`. The difference of `¥3,000` is collected separately by the store after the order (by editing the order or with a draft order invoice). `_reference_price` is the amount for one item; with quantity 3 it is still `¥6,800`. The difference to collect is the difference for one item multiplied by the quantity.

With Shopify Markets, when the display currency differs from the store currency, variant mode shows Shopify's converted price as is. Reference price mode shows neither the per-option price differences nor the reference price total, only "The reference price is shown in (store currency)."

The price and the reference price are shown in the store's money format, written the same way as the prices the theme shows. When the display currency differs from the store currency, or the store's format can't be reproduced faithfully as plain text (for example, when it contains digits inside tags), the browser's format is used.

In reference price mode, the price differences next to the options are written by the 3D configurator itself in the browser's format. The currency symbol, its position, and the decimal and thousands separators can therefore look different from the reference price total (for example, a total of `4.700,00 €` with a difference of `+€5.00`; a total of `¥4,700` with a difference of `+￥500`). On a yen store the total shows the half-width `¥` and the differences show the full-width `￥`. The position of the symbol and the separators are the same for the total and the differences when the store's money format is one currency symbol character directly followed by `{{amount}}` or `{{amount_no_decimals}}` (such as `${{amount}}` or `¥{{amount_no_decimals}}`). For stores with any other format (such as `{{amount}} kr`, `Rs.{{amount}}` or `{{amount_with_comma_separator}} €`), we recommend variant mode, or leaving out the per-option price differences (`price`). In reference price mode with price differences, when the store's format is not of that form, a note is shown in the theme editor.

## 6. What goes into the cart and the order

| Line | Example | Shown in |
| --- | --- | --- |
| Group label | `Lid: Stainless steel`, `Engraving text: MINATO`, `Logo: logo.png (please email the file to us after ordering)` | Cart, checkout, order details |
| `_configurator` | `body=navy;lid=steel;size=500;engrave=MINATO` | Order details only |
| `_preview` | Product URL + `#pc=…` (opens the same 3D; before opening it, see "Handling what is stored on the order" below) | Order details only |
| `_reference_price` | The same text as the reference price shown on the screen. It is in the store's money format, for example `$47.00` for a US dollar store or `¥4,700` for a yen store (reference price mode only; when deciding the amount to charge, see "Handling what is stored on the order" below) | Order details only |

- Line labels and values are kept in the language the customer was viewing. The examples above are for an English storefront; on a Japanese storefront they read `フタ: ステンレス` and `刻印の文字: MINATO`. The "Language" setting in "7. Section settings" decides which one is used.
- **Give the product option and the engraving group different names.** When the presence of engraving is linked to a product option, the cart shows two lines: the option line (`Engraving option: Yes`) and the line with the entered text (`Engraving text: MINATO`). If the option name and the group label are both "Engraving", two lines with the same label appear. The line label comes from the group's `label`; the option name is set on the product.
- The variant name (such as "Sand / 500 ml / Yes") shows the option values as registered on the product. The configurator's language setting does not change it.
- Amounts follow the store currency. The price differences (`price`) in the sample settings are numbers meant for a yen store, so rewrite them for other currencies.
- Groups linked to variants (color, size…) are not repeated as visible lines, because the variant name already shows them. Optional groups left empty are not shown.
- Each value is up to 250 characters; line breaks become spaces.
- The logo image stays in the customer's browser and is not attached to the order. Only the file name is kept, with a request to email the file. The share URL and `_preview` do not carry the logo image either. The 3D shown when `_preview` is opened has no logo.
- After a logo image is chosen, the browser's "No file chosen" text stays next to the file button. The name of the chosen file appears on the line below it.
- After "Save as PNG" is pressed, nothing appears on the screen (the file is saved).
- The "Copy share URL" button copies the URL of the page at that moment (including the part from `?` onward) with the choices added. If the URL carries tracking text from ads and the like, that is copied too. `_preview`, which is kept on the order, is built from the product URL, so it carries no tracking text.

### Handling what is stored on the order

- **The lines stored on the order are values sent by the customer's browser.** The visible lines, and `_configurator`, `_preview` and `_reference_price`, can all be altered by someone who calls the cart directly. The rules on which characters and how many can be engraved are a convenience on the screen, not a guarantee of what is stored on the order.
- **The amount charged and the item to fulfil are decided by the variant.** In reference price mode, what the customer pays at checkout is only the variant price. The store collects the difference separately, by editing the order or with a draft order invoice. Work out the difference for one item from the contents of `_configurator` and your own price table, and multiply it by the quantity. `_reference_price` is the amount for one item and is a value sent by the customer's browser. Do not invoice from `_reference_price` alone.
- **Before opening `_preview`, check that the URL starts with your own store's domain.** If what it shows disagrees with the visible lines of the order, contact the customer.
- **Check the engraving text yourself before production.**
- **Templates that print or display the lines must escape the values.** In order notification emails, packing slips, apps and the like, do not output the line values into HTML as they are.
- **Always set a `pattern` for engraving groups.** Without a `pattern`, invisible characters and characters that change the text direction are accepted within the length limit.

## 7. Section settings (theme editor)

| Setting | Meaning | Default |
| --- | --- | --- |
| Language | Match the store language / Japanese / English. Sets the language of the customer-facing text and of the cart line labels and values | Match the store language |
| 3D height (desktop / mobile) | px | 560 / 420 |
| Price mode | Used when the metafield omits `priceMode` (Variant price / Reference price) | Variant price |
| Cart mode | Configurator button / Theme buy button (Appendix A) | Configurator button |
| Show quantity | | On |
| Button label | Empty means "Add to cart" | Empty |
| Show errors in editor | Lists settings errors inside the theme editor. Never shown to customers | On |

- **How "Language" is chosen**: With "Match the store language", Japanese is used when the storefront language the customer is viewing is Japanese, and English is used for every other language. To use Japanese on a storefront in another language, choose "Japanese" to fix it.
- **Names and labels in the settings panel**: The section is named "3D Configurator", and the setting labels show Japanese and English side by side, such as "言語 / Language". They do not switch with the admin language. Switching would require editing the theme's translation files (`locales`), and the kit is built not to touch the theme's own files. Shopify's theme check tool examines how the section file is written. This section passes theme check with no errors. Theme check does not cover the checks made when the file is saved in the admin (such as the length of labels). The lengths of the labels and options are checked by the kit's own tests.

"Add to cart" adds the item and then goes to `/cart`. If your theme opens a cart drawer instead, listen for the `suminawa-configurator:added` event and call `preventDefault()` to stay on the page (`event.detail` is the added line).

## 8. How settings errors appear

If the metafield JSON has an error, the configurator does not run. This is how it appears:

| Place | What appears |
| --- | --- |
| Theme editor | A red box in place of the section lists what to fix. When the section setting "Show errors in editor" is off, the same short message as on the storefront is shown in place of the list |
| Storefront | No 3D, price or button is shown. The details of the error are not shown on the screen; only a short message appears: "The product customizer can't be shown at the moment. Please contact us." In the "Theme buy button" cart mode, no message is shown and the whole section is hidden |
| Browser console | One warning line starting with `[suminawa-configurator]`. This line carries the same error text as the list in the theme editor. The console is the browser's screen for developers, which customers do not normally open. On a customer's screen too, it can be read by opening it. The error text can contain values written in the settings (such as a host name or a `pattern`). It never contains what a customer typed |

The same applies when `product-configurator.global.js` in the assets is not loaded.

**In the "Configurator button" cart mode, while the settings have an error, the product can't be bought from its product page.** The theme's price and buy button are hidden, so when the configurator does not run, neither a price nor a cart button is shown.

- Every time you change the metafield, open the product page and check that the 3D, the price and the button appear. After you save, it can take some tens of seconds before the product page shows the change. Right after saving, the earlier content may still appear, so wait a little and reload before you judge.
- If you need to keep selling while you fix the settings, make the theme's price, variant picker and buy button blocks visible again. If you empty the metafield, the section shows nothing (the message is not shown either).

Notes such as "a combination has no variant" do not stop the configurator and are shown only in the theme editor.

## 9. After updating your theme

Updating to a new theme version may not carry over added files. After an update, repeat steps 4 and 5 of "3. Installation". The steps for replacing the kit itself with a new version are at the end of "3. Installation". All file names start with `suminawa-configurator` or `product-configurator`, so they never collide with the theme's own files.

## 10. FAQ

- **The section shows nothing, or shows "The product customizer can't be shown"** — The product's `custom.configurator` metafield is empty or has an error, or `product-configurator.global.js` is missing from the theme's assets. Open the theme editor to see the list of errors ("8. How settings errors appear"). In addition, if an app rewrites the theme's scripts (inlining them into the page, combining them into one, loading them later, serving them from another place, and so on), the kit can't confirm where its own script came from and does not start. In such an app, exclude the files whose names start with `suminawa-configurator` and `product-configurator` from rewriting. An app that has no setting for exclusions can't be used together with this kit.
- **"We couldn't load the 3D model"** — Open the `model.src` URL in your browser and check that the GLB downloads.
- **"This combination isn't available"** — The product has no variant for that combination. Check the option values (spelling, spaces) and `shopify.values`.
- **The chosen options don't appear in the cart** — Check that your theme's cart shows line-item properties. Even with a theme that doesn't show them in the cart, they are kept in the order details.
- **The cart lines are in English** — English is used when the storefront language is not Japanese. Set the section's "Language" to "Japanese" to fix it ("7. Section settings").
- **Turning the mouse wheel over the 3D zooms the 3D and the page does not scroll** — Over the 3D, the wheel is used to zoom the 3D. To scroll the page, move the pointer outside the 3D. This can't be changed in the settings.
- **No product image appears in product lists or the cart** — The images shown in product lists, the cart and order emails are the product's own images registered in Shopify. The kit does not add product images. Register product images separately from the 3D model.
- **Few countries can be chosen at checkout** — The countries offered at checkout come from the store's shipping settings and markets, not from the kit.
- **The browser console shows `THREE.Clock: This module has been deprecated.`** — This warning comes from the bundled 3D library and does not affect how the configurator works.
- **Preparing a 3D model** — Name the parts you want to change with their Blender object names and export as binary glTF (`.glb`). `target`, `show` and `hide` refer to these names.

## Appendix A. Theme buy button mode

Use this when you want to keep the theme's own buy button. It needs one line of code. The steps below follow the file layout of Dawn, Shopify's free theme (`snippets/buy-buttons.liquid`). This mode has not been run to the end on a real store with any theme (see "Verified themes").

1. Add `snippets/suminawa-configurator-properties.liquid` in the theme code editor (step 4 of "3. Installation"). Until you add the line in step 2, the editor may show a warning about an unused snippet.
2. Open `snippets/buy-buttons.liquid` and find the tag that starts with `form 'product'`. The tag may span several lines and ends with `-%}` or `%}`. Add this line **right below the line where the tag ends**, as the first line inside the form. Adding it on a line in the middle of the tag breaks the tag.

   ```liquid
   {%- render 'suminawa-configurator-properties' -%}
   ```

3. Set the section's "Cart mode" to "Theme buy button". Keep the theme's buy button block and variant picker block visible, and hide only the price block.

The configurator writes the choices into the form as hidden `properties[...]` fields and sets the form's `id` to the matching variant. When there is no matching variant, the buy button is disabled. In reference price mode, the variant in the form at the moment the buy button is pressed is the one added to the cart. Forms differ between themes, so in your theme, find the file that contains the product form and add the same line there.

## Appendix B. Rebuilding the adapter

`src/` is the source of the adapter (`suminawa-configurator.js`). After editing, rebuild with one line (Node.js 20 or later):

```bash
npx esbuild src/entry.ts --bundle --format=iife --minify --charset=utf8 --target=es2020 --outfile=theme/assets/suminawa-configurator.js
```

## Appendix C. When the theme sets a Content Security Policy

On a store where the theme or an app sets a Content-Security-Policy, the kit needs the following to work. This table was made by reading the kit's code; the kit has not been run on a store with a real Content-Security-Policy.

| Directive | What is needed | Why |
| --- | --- | --- |
| `style-src` | `'unsafe-inline'` | The section passes the 3D heights through the element's `style` attribute |
| `img-src` | `blob:` and the host where the GLB is placed; also `data:` when the GLB holds its images as `data:` URLs | To read the images applied to the 3D |
| `connect-src` | `blob:` and the host where the GLB is placed | To read the GLB |
| `script-src` | The host of the theme's assets | To read the kit's three JS files |

The kit does not use `eval`, Web Workers or WebAssembly. A GLB file may itself point to images or data in other places. In that case the browser also connects to those places. Export the GLB with its images and data included (as one self-contained `.glb`).

## License and support

See `LICENSE.md`. You may modify the files and deliver them as part of a client's store. Redistribution and resale are not allowed.

If you need help, email hello@suminawa.dev. We reply within three business days.

Shopify is a trademark of Shopify Inc. This product is not an official Shopify product and is not affiliated with Shopify. The 3D view uses three.js and React Three Fiber, and the configurator UI uses React. The bundled JS includes 14 open-source packages, all under the MIT License. Their names, versions, copyright lines and the full license text are in `THIRD-PARTY-NOTICES.md`.
