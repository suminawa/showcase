# 3D Configurator for Shopify

A theme component that adds a 3D product configurator to your Shopify product page: customers rotate the product and choose colors, materials, parts and engraving. It is not an app, so there is no app review and no monthly fee. Add one section and five assets with "Edit code", put one JSON setting into a product metafield, and it works.

- What the customer chose goes into the cart line (line-item properties) and stays in the order details
- The amount charged is the price of the product variant (see "5. Price modes")
- The interface is in English and Japanese (it follows the store language automatically)
- No server, no external service, no API key. Settings and models stay inside Shopify
- Requires an Online Store 2.0 theme (tested with Dawn)

## 1. What's in the zip

| Path | Contents |
| --- | --- |
| `theme/sections/suminawa-configurator.liquid` | The section you place on the product page |
| `theme/snippets/suminawa-configurator-properties.liquid` | Snippet for the theme buy button mode (Appendix A) |
| `theme/assets/product-configurator.global.js` | The configurator |
| `theme/assets/product-configurator-3d.global.js` | The 3D view (about 1 MB, loaded when shown) |
| `theme/assets/product-configurator.css` | Configurator styles |
| `theme/assets/suminawa-configurator.js` | The Shopify adapter (price and cart) |
| `theme/assets/suminawa-configurator.css` | Adapter styles |
| `samples/tumbler.metafield.json` | Sample settings (variant mode) |
| `samples/tumbler-reference.metafield.json` | Sample settings (reference price mode, with price differences) |
| `samples/tumbler.glb` | Sample 3D model (stainless tumbler) |
| `page/mock-product.html` | A sample product page that runs without Shopify |
| `src/` | Adapter source code (TypeScript, free to modify) |

## 2. Try it without Shopify

Start a simple server in the unzipped folder and open `page/mock-product.html`. Opening the file directly can't load the 3D data because of browser rules.

```bash
npx serve .
# open /page/mock-product.html?lang=en at the URL shown
```

Choose a color, size and engraving, then press "Add to cart": what the cart would receive is shown at the bottom of the page (the cart is not real).

## 3. Installation

1. **Upload the GLB**: In the admin, go to "Content → Files", upload your `.glb` and copy its URL (`https://cdn.shopify.com/s/files/...`).
2. **Define the metafield**: In "Settings → Custom data → Products", add a definition named "3D configurator" with namespace and key `custom.configurator` and type "JSON".
3. **Enter the settings**: In the product editor, paste JSON based on `samples/tumbler.metafield.json` into the metafield. Set `model.src` to the URL from step 1 and match `shopify.options` to the product option names ("4. Settings").
4. **Add the files**: Open "Online Store → Themes → … → Edit code".
   - In `sections`, choose "Add a new section", name it `suminawa-configurator`, paste the contents of `theme/sections/suminawa-configurator.liquid` and save.
   - In `assets`, choose "Add a new asset" and upload the five files in `theme/assets`.
   - Only if you use the theme buy button mode (Appendix A), add `suminawa-configurator-properties` to `snippets` the same way.
5. **Place it**: In the theme editor, open the product template and choose "Add section → 3D configurator". In Dawn, hide the "Price" and "Buy buttons" blocks of the "Product information" section so the price and button don't appear twice (no code changes needed). You may also hide the "Variant picker" block for a product with a single variant, but keep it visible when the product has more than one (reference price mode is meant for single-variant products; see "5. Price modes").
6. **Check it**: On the product page, choose options and press "Add to cart"; the cart line should show what was chosen. Then place one test order with the test payment gateway (Bogus Gateway) and check that `_configurator` and `_preview` are kept in the order details. Opening the `_preview` URL shows the same 3D the customer chose.

Products with an empty metafield show nothing, so the same product template can be shared with products that have no 3D.

With Shopify CLI, copy the contents of `theme/` into your local theme folder and push only the added files:

```bash
shopify theme push --only sections/suminawa-configurator.liquid --only "assets/product-configurator*" --only "assets/suminawa-configurator*"
```

**If "Files" does not accept `.glb`**: upload the model to the product's "Media" as a 3D model and put that GLB URL in `model.src`. Dawn will then also show the 3D model in the product media; move it to the end of the media list if you prefer.

## 4. Settings (metafield `custom.configurator`)

The 3D settings plus one `shopify` block. `samples/tumbler.metafield.json` is a complete example.

### 4-1. 3D settings

| Key | Meaning |
| --- | --- |
| `model.src` | GLB URL starting with `https://` or `//` (required) |
| `model.camera` | Viewpoint: `distance`, `elevation`, `azimuth` |
| `model.scale` / `model.rotation` | Scale factor / initial rotation (degrees) |
| `scene.background` / `scene.floor` / `scene.autoRotate` | Background color, floor color, auto-rotate until touched |
| `price.note` | Note next to the price ("Tax included") |
| `product.name` / `product.sku` | Default to the product title and the SKU of the selected variant |
| `groups` | Option groups (1–20), see below |
| `features.export` / `share` / `copy` | Show the PNG, share URL and copy buttons (all on by default) |

`price.base` and `price.currency` are not used (the Shopify price and currency are used).

| `type` | Changes | Keys |
| --- | --- | --- |
| `color` | Part color | `target` (mesh names) `required` `default` `options[]`: `{ id, label, color, roughness?, metalness?, price? }` |
| `material` | Part material | `target` `required` `default` `options[]`: `{ id, label, color, roughness, metalness, price? }` |
| `variant` | Show / hide parts | `required` `default` `options[]`: `{ id, label, show?, hide?, price? }` |
| `text` | Engraving | `target` `maxChars` `pattern` `placeholder` `font` `color` `background` `price` |
| `image` | Logo | `target` `maxBytes` `background` `price` |

Labels (`label`, `placeholder`, `price.note`) can be `"Body color"` or `{ "ja": "本体の色", "en": "Body color" }`. If you write only one language, it is used for both.

### 4-2. The `shopify` block

| Key | Meaning |
| --- | --- |
| `priceMode` | `variant` or `reference`. Defaults to the section setting |
| `options` | Group id → product option name, e.g. `{ "body": "Color", "size": "Size", "engrave": "Engraving" }` |
| `values` | Group id → { option id → option value }. If omitted, the option's Japanese label (or its only label) is matched. Engraving and logo use `{ "filled": "Yes", "empty": "No" }`; "none" of an optional group is `empty` |
| `properties` | Group id → `false` hides that group from the visible cart lines |
| `referenceNote` | Overrides the reference price note (can't be empty) |

## 5. Price modes

**The amount actually charged is only the price of the variant in the cart.** Shopify does not let a theme change prices, so there are two modes.

- **Variant mode (`variant`, recommended)**: Link groups to product options and show the price of the matching variant. Differences such as engraving can be linked to an option like "Engraving (Yes / No)". A group with a price difference that is not linked is reported as a settings error (so customers never see a difference that can't be charged). Shopify products have up to three options, so up to three groups can be linked. When a combination has no variant or is sold out, the button is disabled with the reason.
- **Reference price mode (`reference`)**: Shows the variant price plus the group differences as a "Reference price", always with a note (default "The final amount will be confirmed in our order confirmation."). **This mode is meant for products with a single variant** (with more than one, the theme editor shows a note saying so). The variant that goes into the cart is the one selected on the product page when it loaded, for the "Configurator button" cart mode, or the one currently in the form when the buy button is pressed (following Dawn's own variant picker), for the "Theme buy button" mode (Appendix A). The reference price is kept as `_reference_price` in the order details. Collect the difference by editing the order or with a draft order invoice. Because each order needs an adjustment, this suits small differences or made-to-order shops.

With Shopify Markets, when the display currency differs from the store currency, variant mode shows Shopify's converted price as is. Reference price mode shows neither the per-option price differences nor the reference price total, only "The reference price is shown in (store currency)."

## 6. What goes into the cart and the order

| Line | Example | Shown in |
| --- | --- | --- |
| Group label | `Lid: Stainless steel`, `Engraving: MINATO`, `Logo: logo.png (please email the file to us after ordering)` | Cart, checkout, order details |
| `_configurator` | `body=navy;lid=steel;size=500;engrave=MINATO` | Order details only |
| `_preview` | Product URL + `#pc=…` (opens the same 3D) | Order details only |
| `_reference_price` | `¥4,700` (reference price mode only) | Order details only |

- Groups linked to variants (color, size…) are not repeated as visible lines, because the variant name already shows them. Optional groups left empty are not shown.
- Each value is up to 250 characters; line breaks become spaces.
- The logo image stays in the customer's browser and is not attached to the order. Only the file name is kept, with a request to email the file.

## 7. Section settings (theme editor)

| Setting | Meaning | Default |
| --- | --- | --- |
| Language | Match the store language / Japanese / English | Store language |
| 3D height (desktop / mobile) | px | 560 / 420 |
| Price mode | Used when the metafield omits `priceMode` | Variant |
| Cart mode | Configurator button / Theme buy button (Appendix A) | Configurator button |
| Show quantity | | On |
| Button label | Empty means "Add to cart" | Empty |
| Show settings errors in the theme editor | Never shown to customers | On |

"Add to cart" adds the item and then goes to `/cart`. If your theme opens a cart drawer instead, listen for the `suminawa-configurator:added` event and call `preventDefault()` to stay on the page (`event.detail` is the added line).

## 8. How settings errors appear

If the metafield JSON has an error, the list of fixes is shown in place of the section, only inside the theme editor. On the live store the section is hidden and one line is written to the browser console, so customers never see error messages. Notes such as "a combination has no variant" do not stop the configurator and are shown only in the theme editor.

## 9. After updating your theme

Updating to a new theme version may not carry over added files. After an update, repeat steps 4 and 5 of "3. Installation". All file names start with `suminawa-configurator` or `product-configurator`, so they never collide with the theme's own files.

## 10. FAQ

- **The section shows nothing** — The product's `custom.configurator` metafield is empty or has an error. Open the theme editor to see the list of errors.
- **"We couldn't load the 3D model"** — Open the `model.src` URL in your browser and check that the GLB downloads.
- **"This combination isn't available"** — The product has no variant for that combination. Check the option values (spelling, spaces) and `shopify.values`.
- **The chosen options don't appear in the cart** — Check that your theme's cart shows line-item properties (Dawn does).
- **Preparing a 3D model** — Name the parts you want to change with their Blender object names and export as binary glTF (`.glb`). `target`, `show` and `hide` refer to these names.

## Appendix A. Theme buy button mode

Use this when you want to keep Dawn's own buy button. It needs one line of code.

1. Add `snippets/suminawa-configurator-properties.liquid` with "Edit code" (step 4 of "3. Installation").
2. Open `snippets/buy-buttons.liquid` and add this line right below the product form tag (the line starting with `form 'product'`):

   ```liquid
   {%- render 'suminawa-configurator-properties' -%}
   ```

3. Set the section's "Cart mode" to "Theme buy button". Keep the "Buy buttons" and "Variant picker" blocks visible, and hide only the "Price" block. In this mode, the variant selected in the form at the moment the buy button is pressed is the one added to the cart.

The configurator writes the choices into the form as hidden `properties[...]` fields and sets the form's `id` to the matching variant. When there is no matching variant, the buy button is disabled. Forms differ between themes, so this mode is tested with Dawn only.

## Appendix B. Rebuilding the adapter

`src/` is the source of the adapter (`suminawa-configurator.js`). After editing, rebuild with one line (Node.js 20 or later):

```bash
npx esbuild src/entry.ts --bundle --format=iife --minify --charset=utf8 --target=es2020 --outfile=theme/assets/suminawa-configurator.js
```

## License and support

See `LICENSE.md`. You may modify the files and deliver them as part of a client's store. Redistribution and resale are not allowed.

If you need help, email hello@suminawa.dev. We reply within three business days.

Shopify is a trademark of Shopify Inc. This product is not an official Shopify product and is not affiliated with Shopify. The 3D view uses three.js, and the configurator UI uses React (both MIT License; full texts in `THIRD-PARTY-NOTICES.md`).
