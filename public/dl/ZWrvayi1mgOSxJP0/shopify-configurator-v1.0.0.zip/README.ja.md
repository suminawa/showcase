# 3D コンフィギュレーター for Shopify

Shopify の商品ページに、3D で回せて色・素材・パーツ・刻印を選べるコンフィギュレーターを置くテーマ部品です。アプリではないので、Shopify の審査も月額料金も要りません。管理画面の「コードを編集」で section 1 つと assets 5 つを足し、商品メタフィールドに設定の JSON を 1 つ入れれば動きます。

- お客さまが選んだ内容は、カートの行（line-item properties）に載り、注文詳細に残ります
- 請求される金額は、商品のバリエーションの価格です（「5. 価格の方式」）
- 画面の文言は日本語と英語（ストアの言語に合わせて自動で切り替わります）
- サーバー・外部サービス・API キーは要りません。設定もモデルも Shopify の中に置きます
- 前提: Online Store 2.0 のテーマ（Dawn で動作を確かめています）

## 1. 同梱物

| 場所 | 中身 |
| --- | --- |
| `theme/sections/suminawa-configurator.liquid` | section（商品ページに置く部品） |
| `theme/snippets/suminawa-configurator-properties.liquid` | テーマの購入ボタンに載せる方式で使う snippet（付録 A） |
| `theme/assets/product-configurator.global.js` | 3D コンフィギュレーターの本体 |
| `theme/assets/product-configurator-3d.global.js` | 3D の表示部分（およそ 1 MB。表示するときに読み込みます） |
| `theme/assets/product-configurator.css` | 本体の見た目 |
| `theme/assets/suminawa-configurator.js` | Shopify とのつなぎ（価格・カート） |
| `theme/assets/suminawa-configurator.css` | つなぎの見た目 |
| `samples/tumbler.metafield.json` | 設定の見本（バリエーション方式） |
| `samples/tumbler-reference.metafield.json` | 設定の見本（参考価格方式・差額つき） |
| `samples/tumbler.glb` | 見本の 3D モデル（ステンレスタンブラー） |
| `page/mock-product.html` | Shopify 無しで動きを確かめられる見本の商品ページ |
| `src/` | つなぎの元のコード（TypeScript。改変は自由です） |

## 2. 動く見本（Shopify 無しで）

zip を展開したフォルダで簡易サーバーを起動し、`page/mock-product.html` を開きます。ファイルを直接開くと、ブラウザの決まりで 3D のデータを読めません。

```bash
npx serve .
# 表示された URL の /page/mock-product.html を開く（英語は ?lang=en）
```

色・容量・刻印を選んで「カートに入れる」を押すと、カートに届く内容がページの下に出ます（カートは本物ではありません）。

## 3. 設置の手順

1. **GLB を上げる**: 管理画面の「コンテンツ → ファイル」に `.glb` を上げ、ファイルの URL（`https://cdn.shopify.com/s/files/...`）を控えます。
2. **メタフィールドを定義する**: 「設定 → カスタムデータ → 商品」で「定義を追加する」を押し、名前「3D コンフィギュレーター」、ネームスペースとキー `custom.configurator`、種類「JSON」で保存します。
3. **設定を入れる**: 商品の編集画面の下にあるメタフィールド欄に、`samples/tumbler.metafield.json` を元にした JSON を貼ります。`model.src` を 1 で控えた URL に、`shopify.options` を商品のオプション名に合わせます（「4. 設定」）。
4. **ファイルを足す**: 「オンラインストア → テーマ → …（その他の操作）→ コードを編集」を開きます。
   - `sections` フォルダで「新しいセクションを追加する」を押し、名前を `suminawa-configurator` にして、`theme/sections/suminawa-configurator.liquid` の中身を貼って保存します。
   - `assets` フォルダで「アセットを追加する」を押し、`theme/assets` の 5 ファイルを上げます。
   - テーマの購入ボタンに載せる方式（付録 A）を使うときだけ、`snippets` に `suminawa-configurator-properties` を同じように足します。
5. **置く**: テーマエディタで商品テンプレートを開き、「セクションを追加 → 3D コンフィギュレーター」を選びます。Dawn では「商品情報」セクションの「価格」「購入ボタン」ブロックを非表示にしてください（価格とボタンが二重に出るのを防ぎます。コードは触りません）。「バリエーションの選択」ブロックは、バリエーションが 1 つだけの商品では非表示にして構いませんが、複数あるときは残してください（参考価格方式はバリエーションが 1 つの商品向けです。「5. 価格の方式」）。
6. **確かめる**: 商品ページで選んで「カートに入れる」を押し、カートの行に選んだ内容が出ることを確かめます。続けて、テスト用の決済（Bogus Gateway）でテスト注文を 1 件作り、管理画面の注文詳細に `_configurator` と `_preview` が残っていることを確かめてください。`_preview` の URL を開くと、お客さまが選んだのと同じ 3D が出ます。

メタフィールドが空の商品では、section は何も表示しません。3D の無い商品と同じ商品テンプレートを使えます。

Shopify CLI をお使いの場合は、手元のテーマのフォルダに `theme/` の中身を写してから、足したファイルだけを送れます。

```bash
shopify theme push --only sections/suminawa-configurator.liquid --only "assets/product-configurator*" --only "assets/suminawa-configurator*"
```

**「ファイル」に `.glb` を上げられないとき**: 商品の「メディア」に 3D モデルとして上げ、その GLB の URL を `model.src` に書いてください。この場合、Dawn の商品画像の欄にも 3D が出るので、気になる場合はメディアの並びで後ろに回してください。

## 4. 設定（メタフィールド `custom.configurator`）

3D の設定に、Shopify 用の `shopify` の塊を 1 つ足した JSON です。`samples/tumbler.metafield.json` が全体の見本です。

### 4-1. 3D の設定

| 項目 | 内容 |
| --- | --- |
| `model.src` | GLB の URL。`https://` か `//` で始まるもの（必須） |
| `model.camera` | 視点。`distance`（距離）`elevation`（仰角）`azimuth`（方位） |
| `model.scale` / `model.rotation` | 大きさの倍率 / 最初の向き（度） |
| `scene.background` / `scene.floor` / `scene.autoRotate` | 背景色・床の色・触るまで自動で回すか |
| `price.note` | 価格の横の注記（「税込」など） |
| `product.name` / `product.sku` | 省くと商品名と、選ばれているバリエーションの SKU |
| `groups` | 選択肢の群（1〜20 個）。下の表 |
| `features.export` / `share` / `copy` | PNG・共有 URL・JSON コピーのボタンを出すか（既定はすべて出す） |

`price.base` と `price.currency` は使いません（Shopify の価格と通貨を使います）。

| `type` | 何を変えるか | 固有の項目 |
| --- | --- | --- |
| `color` | パーツの色 | `target`（メッシュ名）`required` `default` `options[]`: `{ id, label, color, roughness?, metalness?, price? }` |
| `material` | パーツの材質 | `target` `required` `default` `options[]`: `{ id, label, color, roughness, metalness, price? }` |
| `variant` | パーツの出し分け | `required` `default` `options[]`: `{ id, label, show?, hide?, price? }` |
| `text` | 刻印 | `target` `maxChars` `pattern` `placeholder` `font` `color` `background` `price` |
| `image` | ロゴ | `target` `maxBytes` `background` `price` |

見出し（`label`・`placeholder`・`price.note`）は `"本体の色"` とも `{ "ja": "本体の色", "en": "Body color" }` とも書けます。片方だけ書けば、両方の言語でそれを出します。

### 4-2. `shopify` の塊

| 項目 | 内容 |
| --- | --- |
| `priceMode` | `variant`（バリエーション方式）か `reference`（参考価格方式）。省くと section の設定 |
| `options` | 群の id → 商品のオプション名。例 `{ "body": "カラー", "size": "容量", "engrave": "刻印" }` |
| `values` | 群の id → { 選択肢の id → オプションの値 }。省くと選択肢の日本語の見出しと照らします。刻印・ロゴは `{ "filled": "あり", "empty": "なし" }`。任意の群の「なし」は `empty` |
| `properties` | 群の id → `false` で、カートの見える行に出しません |
| `referenceNote` | 参考価格方式の注記の上書き（空にはできません） |

## 5. 価格の方式

**実際に請求される金額は、カートに入ったバリエーションの価格だけです。** テーマから価格を変えることは Shopify の仕組み上できないため、2 つの方式を用意しています。

- **バリエーション方式（`variant`、おすすめ）**: 群を商品のオプションに結びつけ、選んだ組み合わせのバリエーションの価格を出します。刻印の有無のような違いも、オプション「刻印（あり / なし）」に結べます。差額を持つのに結びついていない群があると、設定の誤りとして止めます（請求できない差額を見せないため）。Shopify の商品のオプションは 3 つまでなので、結べる群も 3 つまでです。組み合わせにバリエーションが無いときや在庫切れのときは、ボタンを押せなくして理由を出します。
- **参考価格方式（`reference`）**: バリエーションの価格に群の差額を足して「参考価格」として出し、注記（既定「お支払い金額は、ご注文確認のご連絡で確定します。」）を必ず添えます。**バリエーションが 1 つだけの商品向けです**（複数あると、テーマエディタに「バリエーションが 1 つだけの商品向けです」とのお知らせが出ます）。カートに入るバリエーションは、カートの方式が「コンフィギュレーターのボタン」なら商品ページを開いたときに選ばれていたもの、「テーマの購入ボタン」（付録 A）なら購入ボタンを押した時点でフォームに入っているもの（Dawn のバリエーションの選択に従います）です。参考価格は注文詳細の `_reference_price` に残ります。差額は、注文の編集か下書き注文の請求書でお受け取りください。注文ごとに金額の調整が要るので、差額が小さい商品や受注生産の店に向いています。

Shopify マーケットで表示の通貨が店の通貨と違うとき、バリエーション方式は Shopify が換算した価格をそのまま出します。参考価格方式は、選択肢ごとの差額の内訳も参考価格の合計も出さず、「参考価格は（店の通貨）でご案内します。」とだけ表示します。

## 6. カートと注文に残る内容

| 行 | 例 | どこに出るか |
| --- | --- | --- |
| 群の見出し | `フタ: ステンレス`、`刻印: MINATO`、`ロゴ入れ: logo.png（ご注文後にメールでお送りください）` | カート・チェックアウト・注文詳細 |
| `_configurator` | `body=navy;lid=steel;size=500;engrave=MINATO` | 注文詳細だけ |
| `_preview` | 商品の URL + `#pc=…`（開くと同じ 3D） | 注文詳細だけ |
| `_reference_price` | `¥4,700`（参考価格方式だけ） | 注文詳細だけ |

- バリエーションに結びついた色・容量などは、バリエーション名と二重になるので見える行には出しません。選んでいない任意の群も出しません。
- 値は 1 つ 250 字までで、改行は空白にします。
- ロゴの画像はお客さまのブラウザの中だけで扱い、注文には添付されません。ファイル名だけを残し、「ご注文後にメールでお送りください」と添えます。

## 7. section の設定（テーマエディタ）

| 設定 | 内容 | 既定 |
| --- | --- | --- |
| 言語 | ストアの言語に合わせる / 日本語 / 英語 | ストアの言語 |
| 3D の高さ（パソコン / スマートフォン） | px | 560 / 420 |
| 価格の方式 | メタフィールドで `priceMode` を省いたときの方式 | バリエーション |
| カートの方式 | コンフィギュレーターのボタン / テーマの購入ボタン（付録 A） | コンフィギュレーターのボタン |
| 数量の欄を出す | | オン |
| ボタンの文言 | 空のときは「カートに入れる」 | 空 |
| 設定の誤りをテーマエディタに出す | お客さまの画面には出ません | オン |

「カートに入れる」を押すと、カートに入れてから `/cart` へ移ります。カートの引き出しを開きたいテーマでは、`suminawa-configurator:added` のイベントを受けて `preventDefault()` を呼ぶと、移らずにそちらで処理できます（`event.detail` はカートに入れた行です）。

## 8. 設定の誤りの見え方

メタフィールドの JSON に誤りがあると、テーマエディタの中でだけ、section の場所に直すところを一覧で出します。公開中のページでは section ごと表示せず、ブラウザのコンソールに 1 行だけ残します（お客さまに誤りの文を見せないため）。組み合わせにバリエーションが無いといった「お知らせ」は、止めずにテーマエディタにだけ出します。

## 9. テーマを更新したとき

テーマを新しい版に上げると、足したファイルが引き継がれないことがあります。更新のあとは「3. 設置の手順」の 4 と 5 をもう一度行ってください。ファイル名はすべて `suminawa-configurator` か `product-configurator` で始まるので、テーマの元のファイルとはぶつかりません。

## 10. よくある質問

- **section が何も出ない** ── その商品のメタフィールド `custom.configurator` が空か、設定に誤りがあります。テーマエディタで開くと、誤りの一覧が出ます。
- **3D が出ず「モデルを読み込めませんでした」と出る** ── `model.src` の URL をブラウザで開き、GLB がダウンロードされるかをご確認ください。
- **「この組み合わせはお選びいただけません」と出る** ── その組み合わせのバリエーションが商品にありません。オプションの値（表記の揺れ・空白）と `shopify.values` をご確認ください。
- **カートに選んだ内容が出ない** ── テーマのカートの表示が line-item properties に対応しているかをご確認ください（Dawn は対応しています）。
- **3D モデルの作り方** ── 設定で触るパーツに Blender のオブジェクト名で名前を付け、glTF バイナリ（`.glb`）で書き出してください。`target` `show` `hide` はこの名前で結びつきます。

## 付録 A. テーマの購入ボタンに載せる方式

Dawn の購入ボタンをそのまま使いたいときの方式です。コードを 1 行足します。

1. 「コードを編集」で `snippets/suminawa-configurator-properties.liquid` を足します（「3. 設置の手順」の 4）。
2. `snippets/buy-buttons.liquid` を開き、商品フォームのタグ（`form 'product'` で始まる行）のすぐ下に、次の 1 行を足します。

   ```liquid
   {%- render 'suminawa-configurator-properties' -%}
   ```

3. section の設定「カートの方式」を「テーマの購入ボタン」にします。「商品情報」の「購入ボタン」ブロックは表示したままにし、「価格」ブロックは非表示にします。「バリエーションの選択」ブロックは非表示にせず残してください。この方式では、購入ボタンを押した時点でそこに選ばれているバリエーションがカートに入ります。

コンフィギュレーターが、選んだ内容を hidden の `properties[...]` としてフォームに書き込み、フォームの `id` を選んだ組み合わせのバリエーションに変えます。組み合わせが無いときは購入ボタンを押せなくします。テーマによってフォームの作りが違うため、この方式は Dawn でだけ確かめています。

## 付録 B. つなぎを直して作り直す

`src/` はつなぎ（`suminawa-configurator.js`）の元のコードです。直したあとは、次の 1 行で作り直せます（Node.js 20 以降）。

```bash
npx esbuild src/entry.ts --bundle --format=iife --minify --charset=utf8 --target=es2020 --outfile=theme/assets/suminawa-configurator.js
```

## ライセンスとお問い合わせ

`LICENSE.md` をご覧ください。改変は自由で、クライアントのストアへの組み込み納品もできます。再配布・転売はできません。

お困りのことがあれば hello@suminawa.dev までご連絡ください。3 営業日以内にお返事します。

Shopify は Shopify Inc. の商標です。本品は Shopify の公式の製品ではなく、Shopify と提携もしていません。3D の表示には three.js、コンフィギュレーターの UI には React を使っています（いずれも MIT ライセンス。全文は `THIRD-PARTY-NOTICES.md`）。
