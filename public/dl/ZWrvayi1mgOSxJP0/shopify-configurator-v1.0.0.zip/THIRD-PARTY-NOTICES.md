# サードパーティのお知らせ / Third-Party Notices

本 zip の `theme/assets/product-configurator.global.js` と `theme/assets/product-configurator-3d.global.js` には、次のオープンソースソフトウェアのコードが含まれています（3D コンフィギュレーター本体の一部として）。いずれも MIT ライセンスです。著作権の表示は、それぞれのパッケージの LICENSE のファイルから写しています（LICENSE のファイルが無いパッケージは、表の中にそう書いています）。ライセンスの全文は、表の下のとおりです。

The files `theme/assets/product-configurator.global.js` and `theme/assets/product-configurator-3d.global.js` in this zip include code from the following open-source software (as part of the 3D configurator itself). All are under the MIT License. The copyright lines are taken from each package's own LICENSE file (a package that ships no LICENSE file is marked as such in the table). The full text of the license follows the table.

| Package | Version | License | Copyright |
| --- | --- | --- | --- |
| @babel/runtime | 7.29.7 | MIT | Copyright (c) 2014-present Sebastian McKenzie and other contributors |
| @react-three/drei | 10.7.8 | MIT | Copyright (c) 2020 react-spring |
| @react-three/fiber | 9.7.0 | MIT | Paul Henschel (https://github.com/drcmda)（パッケージに LICENSE のファイルが無いため、package.json の author から / from the author field of package.json, as the package ships no LICENSE file） |
| camera-controls | 3.1.2 | MIT | Copyright (c) 2017 @yomotsu |
| its-fine | 2.0.0 | MIT | Copyright (c) 2022-2025 Poimandres |
| react | 19.2.4 | MIT | Copyright (c) Meta Platforms, Inc. and affiliates. |
| react-dom | 19.2.4 | MIT | Copyright (c) Meta Platforms, Inc. and affiliates. |
| react-use-measure | 2.1.7 | MIT | Copyright (c) 2019-2025 Poimandres |
| scheduler | 0.27.0 | MIT | Copyright (c) Meta Platforms, Inc. and affiliates. |
| suspend-react | 0.1.3 | MIT | Copyright (c) 2021 Paul Henschel |
| three | 0.185.1 | MIT | Copyright © 2010-2026 three.js authors |
| three-stdlib | 2.36.1 | MIT | Copyright (c) 2021-2023 Poimandres |
| use-sync-external-store | 1.7.0 | MIT | Copyright (c) Meta Platforms, Inc. and affiliates. |
| zustand | 5.0.15 | MIT | Copyright (c) 2019 Paul Henschel |

## MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
