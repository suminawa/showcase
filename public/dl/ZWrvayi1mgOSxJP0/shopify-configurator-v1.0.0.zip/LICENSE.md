# 利用許諾（3D コンフィギュレーター for Shopify）

発行者: suminawa（hello@suminawa.dev）　対象: 本 zip に含まれるすべてのファイル

1. 個人ライセンス: 購入者本人が、自分のストア・自分の案件で、数に制限なく使えます。
2. 組織ライセンス: 購入した組織（法人・チーム）が、その組織の案件で使えます。個人ライセンスで購入した場合、所属組織の他のメンバーへの配布はできません。
3. 改変: 自由です。改変したものを自分のストアで使うことも、クライアントのストアに組み込んで納品することもできます。
4. 禁止: 本ファイル一式（改変の有無を問わず）の再配布・転売・共有、テンプレートやパック商品としての再販、同種の商品として販売すること。Shopify のアプリやテーマとして公開・販売すること。
5. 保証と責任: 現状有姿で提供します。発行者の故意または重大な過失による場合を除き、本ソフトウェアに関する損害賠償の責任は購入代金を上限とします。
6. サポート: 購入後 14 日間、不具合のご連絡にメールで対応します（3 営業日以内に返信）。使い方のご質問にも同じ窓口で応じます。
7. 返金: デジタル商品の性質上、ダウンロード後の返金はできません。不具合は 6. のサポートで対応します。
8. 準拠法: 日本法。

購入日をもって本許諾に同意したものとします。

本 zip には three.js と React（いずれも MIT ライセンス）が含まれます。ライセンス全文は `THIRD-PARTY-NOTICES.md` をご覧ください。

---

# License (3D Configurator for Shopify)

Publisher: suminawa (hello@suminawa.dev). Applies to every file in this zip. If the Japanese text above and this English text differ, the Japanese text prevails.

1. Personal license: the buyer may use the files in their own stores and projects, without limit.
2. Organization license: the buying organization (company or team) may use the files in its projects. A personal license may not be shared with other members of the buyer's organization.
3. Modification: allowed. Modified files may be used in your own store or delivered as part of a client's store.
4. Prohibited: redistributing, reselling or sharing the files (modified or not), reselling them as a template or bundle, selling them as a similar product, or publishing or selling them as a Shopify app or theme.
5. Warranty and liability: provided as is. Except in cases of intent or gross negligence by the publisher, liability is limited to the purchase price.
6. Support: for 14 days after purchase, bug reports are handled by email (reply within three business days). Questions about usage are answered at the same address.
7. Refunds: because this is a digital product, refunds are not available after download. Bugs are handled under 6.
8. Governing law: the laws of Japan.

You agree to this license as of the date of purchase.

This zip includes three.js and React (both under the MIT License). See `THIRD-PARTY-NOTICES.md` for the full license texts.
