/** 画面の文言。核の文言（DEFAULT_LABELS）の英訳と、つなぎが足す文言（ja / en） */
import type { ConfiguratorLabels } from "@core/config";
import type { Lang } from "./types";

/** 核の DEFAULT_LABELS の全キーの英訳。日本語は核の既定のまま使う */
export const CORE_LABELS_EN: ConfiguratorLabels = {
  price: "Price",
  copy: "Copy selection",
  copied: "Copied",
  export: "Save as PNG",
  share: "Copy share URL",
  shared: "URL copied",
  reset: "Start over",
  loading: "Loading…",
  loadError: "We couldn't load the 3D model. Please check model.src in the settings.",
  noWebgl: "3D can't be displayed on this device.",
  sceneMissing: "The 3D module (product-configurator-3d.global.js) wasn't found. Please check the installation steps.",
  missing: "Not in the model",
  none: "None",
  textTooLong: "Please enter up to {max} characters.",
  textInvalid: "Please use letters, numbers, spaces and the symbols . & -",
  imageTooLarge: "Please choose an image of {max} or smaller.",
  imageType: "Please choose a PNG, JPEG or SVG image.",
  imageClear: "Remove image",
  hint: "Drag to rotate, scroll to zoom, double-click to reset.",
};

/** 核の mount に渡す labels。日本語は核の既定なので空 */
export function coreLabelsFor(lang: Lang): Partial<ConfiguratorLabels> {
  return lang === "en" ? { ...CORE_LABELS_EN } : {};
}

export interface AdapterLabels {
  price: string;
  referencePrice: string;
  referenceNote: string;
  referenceCurrency: string;
  quantity: string;
  addToCart: string;
  adding: string;
  unavailable: string;
  soldOut: string;
  cartFailed: string;
  cartSoldOut: string;
  logoSuffix: string;
  errorsTitle: string;
  warningsTitle: string;
  themeFormMissing: string;
  empty: string;
}

export const ADAPTER_LABELS: Record<Lang, AdapterLabels> = {
  ja: {
    price: "価格",
    referencePrice: "参考価格",
    referenceNote: "お支払い金額は、ご注文確認のご連絡で確定します。",
    referenceCurrency: "参考価格は {currency} でご案内します。",
    quantity: "数量",
    addToCart: "カートに入れる",
    adding: "カートに入れています…",
    unavailable: "この組み合わせはお選びいただけません",
    soldOut: "在庫切れです",
    cartFailed: "カートに入れられませんでした。時間をおいてお試しください。",
    cartSoldOut: "在庫が足りないため、カートに入れられませんでした。数量か組み合わせを変えてお試しください。",
    logoSuffix: "（ご注文後にメールでお送りください）",
    errorsTitle: "3D コンフィギュレーターの設定に直すところがあります（この表示はテーマエディタの中だけに出ます）",
    warningsTitle: "3D コンフィギュレーターの設定のお知らせ（この表示はテーマエディタの中だけに出ます）",
    themeFormMissing:
      "カートの方式が「テーマの購入ボタン」ですが、購入ボタンのフォームの中に suminawa-configurator-properties が見つかりません。いまはコンフィギュレーターのボタンを出しています。",
    empty: "メタフィールド custom.configurator に設定が入っていません。",
  },
  en: {
    price: "Price",
    referencePrice: "Reference price",
    referenceNote: "The final amount will be confirmed in our order confirmation.",
    referenceCurrency: "The reference price is shown in {currency}.",
    quantity: "Quantity",
    addToCart: "Add to cart",
    adding: "Adding to cart…",
    unavailable: "This combination isn't available",
    soldOut: "Sold out",
    cartFailed: "We couldn't add this to your cart. Please try again later.",
    cartSoldOut: "There isn't enough stock to add this to your cart. Please change the quantity or the combination.",
    logoSuffix: " (please email the file to us after ordering)",
    errorsTitle: "The 3D configurator settings need attention (shown only in the theme editor)",
    warningsTitle: "Notes on the 3D configurator settings (shown only in the theme editor)",
    themeFormMissing:
      "The cart mode is \"theme buy button\", but suminawa-configurator-properties wasn't found inside the buy button form. The configurator's own button is shown instead.",
    empty: "The metafield custom.configurator has no settings.",
  },
};

/** 店の人向けの文を言語で選ぶ */
export function t(lang: Lang, ja: string, en: string): string {
  return lang === "ja" ? ja : en;
}
