/** 商品メタフィールド custom.configurator（JSON）を読む。核の設定と shopify の塊に分け、見出しを言語で選び、検査する */
import type { ConfiguratorConfig, GroupType, ResolvedConfig } from "@core/config";
import { ADAPTER_LABELS, coreLabelsFor, t } from "./labels";
import type { Lang, PriceMode, SectionContext, ShopifyProduct, ShopifyVariant } from "./types";
import { countMissingCombos } from "./variants";

/** 核が整えた群を、つなぎが使う形にしたもの（見出しは表示中の言語） */
export interface GroupInfo {
  id: string;
  type: GroupType;
  label: string;
  required: boolean;
  options: { id: string; label: string }[];
  /** 差額を持つ（選択肢のどれか、または刻印・ロゴの price が 0 でない） */
  priced: boolean;
}

/** 群と商品のオプションの結びつき */
export interface Binding {
  groupId: string;
  optionName: string;
  /** 商品のオプションの位置（variant.options の添字） */
  optionIndex: number;
  /** 選択の値（選択肢の id、または filled / empty）→ 商品のオプションの値 */
  values: Record<string, string>;
}

export interface ShopifyConfig {
  priceMode: PriceMode;
  bindings: Binding[];
  /** shopify.properties で false にした群（見える行に出さない） */
  hiddenProperties: string[];
  /** 参考価格方式の注記（空にできない） */
  referenceNote: string;
}

export interface ParsedConfig {
  /** 核の mount に渡す設定（shopify を除き、見出しを選び、scene.src・通貨・文言を入れたもの） */
  core: ConfiguratorConfig;
  groups: GroupInfo[];
  shopify: ShopifyConfig;
  /** price.note（表示中の言語）。つなぎの価格の横に出す */
  priceNote: string;
  warnings: string[];
}

export type ParseResult = { ok: true; value: ParsedConfig } | { ok: false; errors: string[] };

export interface ParseOptions {
  /** 3D の束の URL（section の data-scene-src） */
  sceneSrc: string;
  /** 核の resolveConfig（本番は window.ProductConfigurator.resolveConfig） */
  resolveConfig: (input: unknown) => ResolvedConfig;
}

type Json = Record<string, unknown>;

function isRecord(value: unknown): value is Json {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringOr(value: unknown, fallback: string): string {
  return typeof value === "string" ? value : fallback;
}

/** "本体の色" か { "ja": …, "en": … } から、表示する言語の文字を選ぶ。片方だけならそれを使う。形が違えば null */
export function pickLabel(value: unknown, lang: Lang): string | null {
  if (typeof value === "string") return value;
  if (!isRecord(value)) return null;
  const ja = typeof value.ja === "string" && value.ja !== "" ? value.ja : null;
  const en = typeof value.en === "string" && value.en !== "" ? value.en : null;
  return lang === "en" ? (en ?? ja) : (ja ?? en);
}

/** カートに入れるときの既定のバリエーション（商品ページで選ばれているもの → 在庫のある最初のもの → 最初のもの） */
export function selectedVariant(product: ShopifyProduct): ShopifyVariant | undefined {
  return product.variants.find((v) => v.id === product.selectedVariantId) ?? product.variants.find((v) => v.available) ?? product.variants[0];
}

/** section の data-sc-context を読む。誤りは console にだけ出すので日本語の 1 文 */
export function parseContext(text: string | null | undefined): { ok: true; value: SectionContext } | { ok: false; error: string } {
  let raw: unknown;
  try {
    raw = JSON.parse(text ?? "");
  } catch {
    return { ok: false, error: "data-sc-context が JSON として読めません（section のファイルが壊れていないかご確認ください）" };
  }
  if (!isRecord(raw) || !isRecord(raw.product)) return { ok: false, error: "data-sc-context に product がありません" };
  const p = raw.product;
  if (!Array.isArray(p.variants) || p.variants.length === 0) return { ok: false, error: "data-sc-context の product.variants が空です" };
  const variants: ShopifyVariant[] = [];
  for (const item of p.variants) {
    if (!isRecord(item) || typeof item.id !== "number" || typeof item.price !== "number" || !Array.isArray(item.options)) {
      return { ok: false, error: "data-sc-context の product.variants の形が違います" };
    }
    variants.push({
      id: item.id,
      title: stringOr(item.title, ""),
      options: item.options.map((o) => String(o)),
      price: item.price,
      available: item.available === true,
      sku: stringOr(item.sku, ""),
    });
  }
  const s = isRecord(raw.settings) ? raw.settings : {};
  const currency = typeof raw.currency === "string" && raw.currency !== "" ? raw.currency : "JPY";
  return {
    ok: true,
    value: {
      lang: raw.lang === "ja" ? "ja" : "en",
      product: {
        id: typeof p.id === "number" ? p.id : 0,
        title: stringOr(p.title, ""),
        handle: stringOr(p.handle, ""),
        url: typeof p.url === "string" && p.url !== "" ? p.url : "/",
        options: Array.isArray(p.options) ? p.options.map((o) => String(o)) : [],
        selectedVariantId: typeof p.selectedVariantId === "number" ? p.selectedVariantId : null,
        variants,
      },
      currency,
      shopCurrency: typeof raw.shopCurrency === "string" && raw.shopCurrency !== "" ? raw.shopCurrency : currency,
      routesRoot: typeof raw.routesRoot === "string" && raw.routesRoot !== "" ? raw.routesRoot : "/",
      designMode: raw.designMode === true,
      mock: raw.mock === true,
      settings: {
        priceMode: s.priceMode === "reference" ? "reference" : "variant",
        cartMode: s.cartMode === "theme" ? "theme" : "own",
        showQuantity: s.showQuantity !== false,
        buttonLabel: typeof s.buttonLabel === "string" ? s.buttonLabel.trim() : "",
        showErrors: s.showErrors !== false,
      },
    },
  };
}

/** 見出し（{ ja, en } か文字）を表示する言語の文字に置き換えた写しを作る */
function localize(raw: Json, lang: Lang, errors: string[]): Json {
  const out = JSON.parse(JSON.stringify(raw)) as Json;
  const fix = (holder: Json, key: string, where: string) => {
    if (holder[key] === undefined || holder[key] === null) return;
    const picked = pickLabel(holder[key], lang);
    if (picked === null) {
      errors.push(t(lang, `${where} は文字か { "ja": "…", "en": "…" } にしてください。`, `${where} must be a string or { "ja": "…", "en": "…" }.`));
    } else {
      holder[key] = picked;
    }
  };
  if (isRecord(out.product)) fix(out.product, "name", "product.name");
  if (isRecord(out.price)) fix(out.price, "note", "price.note");
  if (Array.isArray(out.groups)) {
    out.groups.forEach((group, i) => {
      if (!isRecord(group)) return;
      fix(group, "label", `groups[${i}].label`);
      fix(group, "placeholder", `groups[${i}].placeholder`);
      if (Array.isArray(group.options)) {
        group.options.forEach((option, j) => {
          if (isRecord(option)) fix(option, "label", `groups[${i}].options[${j}].label`);
        });
      }
    });
  }
  if (isRecord(out.labels)) {
    const labels = out.labels;
    for (const key of Object.keys(labels)) fix(labels, key, `labels.${key}`);
  }
  return out;
}

/** 選択肢の日本語の見出し（shopify.values を省いたとき、商品のオプションの値と照らす） */
function japaneseLabels(raw: Json): Record<string, Record<string, string>> {
  const out: Record<string, Record<string, string>> = {};
  if (!Array.isArray(raw.groups)) return out;
  for (const group of raw.groups) {
    if (!isRecord(group) || typeof group.id !== "string" || !Array.isArray(group.options)) continue;
    const table: Record<string, string> = {};
    for (const option of group.options) {
      if (!isRecord(option) || typeof option.id !== "string") continue;
      const label = pickLabel(option.label, "ja");
      if (label !== null) table[option.id] = label;
    }
    out[group.id] = table;
  }
  return out;
}

function modelSrcError(model: unknown, lang: Lang, mock: boolean): string | null {
  const src = isRecord(model) ? model.src : undefined;
  if (typeof src !== "string" || src.trim() === "") {
    return t(lang, "model.src に GLB の URL（https://cdn.shopify.com/… ）を入れてください。", "Please set model.src to the GLB URL (https://cdn.shopify.com/…).");
  }
  if (/^https:\/\//i.test(src) || src.startsWith("//")) return null;
  if (mock && !/^[a-z][a-z0-9+.-]*:/i.test(src)) return null;
  return t(lang, `model.src は https:// か // で始まる URL にしてください（いまの値: ${src}）。`, `model.src must start with https:// or // (current value: ${src}).`);
}

function groupsOf(resolved: ResolvedConfig): GroupInfo[] {
  return resolved.groups.map((group) => {
    if (group.type === "text" || group.type === "image") {
      return { id: group.id, type: group.type, label: group.label, required: false, options: [], priced: group.price !== 0 };
    }
    return {
      id: group.id,
      type: group.type,
      label: group.label,
      required: group.required,
      options: group.options.map((o) => ({ id: o.id, label: o.label })),
      priced: group.options.some((o) => o.price !== 0),
    };
  });
}

/** バリエーション方式では核に差額を渡さない（請求されるのはバリエーションの価格だけなので） */
function stripPrices(core: Json): void {
  if (!Array.isArray(core.groups)) return;
  for (const group of core.groups) {
    if (!isRecord(group)) continue;
    if (group.price !== undefined) group.price = 0;
    if (Array.isArray(group.options)) {
      for (const option of group.options) if (isRecord(option) && option.price !== undefined) option.price = 0;
    }
  }
}

/** shopify.priceMode（無ければ section の設定）から方式を決める。検査はせず、核へ渡す通貨を選ぶためだけに使う（parseShopify と同じ式） */
function guessPriceMode(shopifyRaw: unknown, settings: SectionContext["settings"]): PriceMode {
  const modeRaw = isRecord(shopifyRaw) ? shopifyRaw.priceMode : undefined;
  return (modeRaw ?? settings.priceMode) === "reference" ? "reference" : "variant";
}

interface ShopifyContext {
  lang: Lang;
  context: SectionContext;
  groups: GroupInfo[];
  ja: Record<string, Record<string, string>>;
  errors: string[];
  warnings: string[];
}

function parseShopify(raw: unknown, ctx: ShopifyContext): ShopifyConfig {
  const { lang, context, groups, ja, errors, warnings } = ctx;
  const product = context.product;
  const s = raw === undefined || raw === null ? {} : raw;
  const fallback: ShopifyConfig = { priceMode: context.settings.priceMode, bindings: [], hiddenProperties: [], referenceNote: ADAPTER_LABELS[lang].referenceNote };
  if (!isRecord(s)) {
    errors.push(t(lang, "shopify は { } の形にしてください。", "shopify must be an object { }."));
    return fallback;
  }
  const byId = new Map(groups.map((g) => [g.id, g]));
  const unknownGroup = (where: string, id: string) =>
    errors.push(t(lang, `${where} の「${id}」という群はありません（ある群: ${groups.map((g) => g.id).join(", ")}）。`, `${where} refers to a group "${id}" that doesn't exist (groups: ${groups.map((g) => g.id).join(", ")}).`));

  const modeRaw = s.priceMode ?? context.settings.priceMode;
  if (modeRaw !== "variant" && modeRaw !== "reference") {
    errors.push(t(lang, `shopify.priceMode は variant か reference にしてください（いまの値: ${String(modeRaw)}）。`, `shopify.priceMode must be variant or reference (current value: ${String(modeRaw)}).`));
  }
  const priceMode: PriceMode = modeRaw === "reference" ? "reference" : "variant";
  if (priceMode === "reference" && product.variants.length > 1) {
    warnings.push(
      t(
        lang,
        "参考価格方式は、バリエーションが 1 つだけの商品向けです。この商品にはバリエーションが複数あるため、カートには商品ページで選ばれているバリエーションが入ります（テーマの購入ボタンの方式では、購入ボタンを押した時点で選ばれているバリエーションが入ります）。",
        "Reference price mode is meant for products with a single variant. This product has more than one variant, so the variant selected on the product page goes into the cart (with the theme buy button mode, the variant selected at the moment the button is pressed goes into the cart).",
      ),
    );
  }

  const hiddenProperties: string[] = [];
  if (s.properties !== undefined) {
    if (!isRecord(s.properties)) {
      errors.push(t(lang, 'shopify.properties は { "群の id": false } の形にしてください。', 'shopify.properties must look like { "group id": false }.'));
    } else {
      for (const [id, value] of Object.entries(s.properties)) {
        if (!byId.has(id)) unknownGroup("shopify.properties", id);
        else if (typeof value !== "boolean") errors.push(t(lang, `shopify.properties.${id} は true か false にしてください。`, `shopify.properties.${id} must be true or false.`));
        else if (!value) hiddenProperties.push(id);
      }
    }
  }

  let referenceNote = ADAPTER_LABELS[lang].referenceNote;
  if (s.referenceNote !== undefined) {
    const picked = pickLabel(s.referenceNote, lang);
    if (picked === null || picked.trim() === "") {
      errors.push(
        t(lang, "shopify.referenceNote は空にできません。お支払い金額がいつ確定するかをお書きください。", "shopify.referenceNote can't be empty. Please say when the final amount is confirmed."),
      );
    } else {
      referenceNote = picked;
    }
  }

  const values: Record<string, Record<string, string>> = {};
  if (s.values !== undefined && !isRecord(s.values)) {
    errors.push(t(lang, 'shopify.values は { "群の id": { "選択肢の id": "オプションの値" } } の形にしてください。', 'shopify.values must look like { "group id": { "option id": "option value" } }.'));
  } else if (isRecord(s.values)) {
    for (const [id, table] of Object.entries(s.values)) {
      const group = byId.get(id);
      if (!group) {
        unknownGroup("shopify.values", id);
        continue;
      }
      if (!isRecord(table) || Object.values(table).some((v) => typeof v !== "string" || v === "")) {
        errors.push(t(lang, `shopify.values.${id} は { "選択肢の id": "オプションの値" } の形にしてください。`, `shopify.values.${id} must look like { "option id": "option value" }.`));
        continue;
      }
      const allowed = group.type === "text" || group.type === "image" ? ["filled", "empty"] : [...group.options.map((o) => o.id), "empty"];
      for (const key of Object.keys(table)) {
        if (!allowed.includes(key)) {
          errors.push(
            t(lang, `shopify.values.${id} の「${key}」は、群「${group.label}」の選択肢にありません（使える名前: ${allowed.join(", ")}）。`, `shopify.values.${id} has "${key}", which is not an option of "${group.label}" (allowed: ${allowed.join(", ")}).`),
          );
        }
      }
      values[id] = table as Record<string, string>;
    }
  }

  const bindings: Binding[] = [];
  if (s.options !== undefined && !isRecord(s.options)) {
    errors.push(t(lang, 'shopify.options は { "群の id": "商品のオプション名" } の形にしてください。', 'shopify.options must look like { "group id": "product option name" }.'));
  } else if (isRecord(s.options) && priceMode === "reference") {
    if (Object.keys(s.options).length > 0) {
      warnings.push(
        t(lang, "参考価格方式では shopify.options を使いません（カートには商品ページで選ばれているバリエーションが入ります）。", "shopify.options is not used in reference price mode (the variant selected on the product page goes into the cart)."),
      );
    }
  } else if (priceMode === "variant") {
    const used = new Set<string>();
    for (const [id, name] of Object.entries(isRecord(s.options) ? s.options : {})) {
      const group = byId.get(id);
      if (!group) {
        unknownGroup("shopify.options", id);
        continue;
      }
      if (typeof name !== "string" || name === "") {
        errors.push(t(lang, `shopify.options.${id} は商品のオプション名（文字）にしてください。`, `shopify.options.${id} must be a product option name (string).`));
        continue;
      }
      const optionIndex = product.options.indexOf(name);
      if (optionIndex < 0) {
        errors.push(
          t(lang, `shopify.options.${id} の「${name}」は、この商品のオプションにありません（ある名前: ${product.options.join(", ")}）。`, `shopify.options.${id} is "${name}", which is not an option of this product (options: ${product.options.join(", ")}).`),
        );
        continue;
      }
      if (used.has(name)) {
        errors.push(t(lang, `商品のオプション「${name}」に、2 つの群が結びついています。1 つにしてください。`, `Two groups are linked to the product option "${name}". Please link only one.`));
        continue;
      }
      used.add(name);
      const table = values[id] ?? {};
      const map: Record<string, string> = {};
      if (group.type === "text" || group.type === "image") {
        if (table.filled === undefined || table.empty === undefined) {
          errors.push(
            t(lang, `「${group.label}」を商品のオプションに結びつけるには、shopify.values.${id} に filled と empty の値を入れてください。`, `To link "${group.label}" to a product option, set filled and empty in shopify.values.${id}.`),
          );
          continue;
        }
        map.filled = table.filled;
        map.empty = table.empty;
      } else {
        for (const option of group.options) map[option.id] = table[option.id] ?? ja[id]?.[option.id] ?? option.label;
        if (!group.required && table.empty !== undefined) map.empty = table.empty;
      }
      bindings.push({ groupId: id, optionName: name, optionIndex, values: map });
      const present = new Set(product.variants.map((v) => v.options[optionIndex]));
      const absent = [...new Set(Object.values(map))].filter((v) => !present.has(v));
      if (absent.length > 0) {
        warnings.push(
          t(lang, `商品のオプション「${name}」に「${absent.join("」「")}」がありません。その選択肢では「お選びいただけません」と出ます。`, `The product option "${name}" has no value "${absent.join('", "')}". Customers will see "not available" for that choice.`),
        );
      }
    }
    if (product.variants.length > 1) {
      for (const name of product.options) {
        if (!used.has(name)) {
          errors.push(t(lang, `商品のオプション「${name}」が、どの群にも結びついていません。shopify.options に入れてください。`, `The product option "${name}" is not linked to any group. Please add it to shopify.options.`));
        }
      }
    }
    const bound = new Set(bindings.map((b) => b.groupId));
    for (const group of groups) {
      if (group.priced && !bound.has(group.id)) {
        errors.push(
          t(
            lang,
            `「${group.label}」には差額がありますが、商品のオプションに結びついていません。バリエーション方式では請求できません。差額を 0 にするか、shopify.options で結びつけてください。`,
            `"${group.label}" has a price difference but is not linked to a product option, so it can't be charged in variant mode. Set the difference to 0 or link it in shopify.options.`,
          ),
        );
      }
    }
  }
  return { priceMode, bindings, hiddenProperties, referenceNote };
}

/** メタフィールドの JSON（文字か、読んだもの）を読む。誤りは店の人向けの文（表示中の言語）で返す */
export function parseMetafield(input: unknown, context: SectionContext, options: ParseOptions): ParseResult {
  const { lang } = context;
  const L = ADAPTER_LABELS[lang];
  let raw: unknown = input;
  if (typeof raw === "string") {
    const text = raw.trim();
    if (text === "" || text === "null") return { ok: false, errors: [L.empty] };
    try {
      raw = JSON.parse(text);
    } catch {
      return {
        ok: false,
        errors: [t(lang, "メタフィールド custom.configurator が JSON として読めません。カンマや括弧の抜けをご確認ください。", "The metafield custom.configurator is not valid JSON. Please check for missing commas or brackets.")],
      };
    }
  }
  if (raw === null || raw === undefined) return { ok: false, errors: [L.empty] };
  if (!isRecord(raw)) return { ok: false, errors: [t(lang, "メタフィールド custom.configurator は { } の形にしてください。", "The metafield custom.configurator must be a JSON object { }.")] };

  const { shopify: shopifyRaw, ...rest } = raw;
  const errors: string[] = [];
  const warnings: string[] = [];
  const localized = localize(rest, lang, errors);
  const srcError = modelSrcError(localized.model, lang, context.mock);
  if (srcError !== null) errors.push(srcError);
  if (errors.length > 0) return { ok: false, errors };

  const productRaw = isRecord(localized.product) ? localized.product : {};
  const priceRaw = isRecord(localized.price) ? localized.price : {};
  // 参考価格方式かどうかは shopify.priceMode（無ければ section の設定）で決まる。検査は parseShopify で行うので、ここでは核へ渡す通貨を選ぶためだけに使う
  const priceMode = guessPriceMode(shopifyRaw, context.settings);
  const core: Json = {
    ...localized,
    product: { name: productRaw.name ?? context.product.title, sku: productRaw.sku ?? selectedVariant(context.product)?.sku ?? "" },
    scene: { ...(isRecord(localized.scene) ? localized.scene : {}), src: options.sceneSrc === "" ? null : options.sceneSrc },
    // 金額は Shopify のものを使う。基本は 0。参考価格方式は差額を店の通貨のまま核に渡すので、通貨も店の通貨にする（バリエーション方式は核に差額を渡さないので表示中の通貨のままでよい）。注記はつなぎの価格の横に出す
    price: { base: 0, currency: priceMode === "reference" ? context.shopCurrency : context.currency, note: "" },
    labels: { ...coreLabelsFor(lang), ...(isRecord(localized.labels) ? localized.labels : {}) },
  };
  let resolved: ResolvedConfig;
  try {
    resolved = options.resolveConfig(core);
  } catch (error) {
    const message = (error instanceof Error ? error.message : String(error)).replace(/^product-configurator: /, "");
    return { ok: false, errors: [t(lang, `設定の誤り: ${message}`, `Settings error: ${message}`)] };
  }
  const groups = groupsOf(resolved);
  const shopify = parseShopify(shopifyRaw, { lang, context, groups, ja: japaneseLabels(rest), errors, warnings });
  if (errors.length > 0) return { ok: false, errors };
  if (shopify.priceMode === "variant") {
    const { total, missing } = countMissingCombos(context.product, shopify.bindings, groups);
    if (missing > 0) {
      warnings.push(
        t(lang, `組み合わせ ${total} 通りのうち ${missing} 通りは、商品にバリエーションがありません。その組み合わせでは「お選びいただけません」と出ます。`, `${missing} of ${total} combinations have no product variant. Customers will see "not available" for them.`),
      );
    }
    stripPrices(core);
  }
  return {
    ok: true,
    value: { core: core as ConfiguratorConfig, groups, shopify, priceNote: typeof priceRaw.note === "string" ? priceRaw.note : "", warnings },
  };
}
