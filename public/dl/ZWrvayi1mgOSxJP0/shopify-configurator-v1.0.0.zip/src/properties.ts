/** カートの line-item properties。見える行（群の見出し → 選んだもの）と、隠れる行（_ で始まる。注文詳細にだけ残る） */
import type { GroupInfo, ShopifyConfig } from "./config";
import { ADAPTER_LABELS } from "./labels";
import type { Lang } from "./types";
import type { Selection } from "./variants";

/** 値 1 つの上限 */
export const PROPERTY_VALUE_LIMIT = 250;

/** 改行を空白にして 250 字で切る */
export function clipValue(value: string): string {
  return value.replace(/[\r\n]+/g, " ").trim().slice(0, PROPERTY_VALUE_LIMIT);
}

/** キーは群の見出しのまま。properties[...] の括弧と、隠れる行と紛れる先頭の _ だけ全角にする */
export function propertyKey(label: string): string {
  return clipValue(label).replace(/\[/g, "［").replace(/\]/g, "］").replace(/^_/, "＿");
}

/** _configurator の値の中で、区切りの ; と = を逃がす */
function shortValue(value: string): string {
  return value.replace(/%/g, "%25").replace(/;/g, "%3B").replace(/=/g, "%3D").replace(/[\r\n]+/g, " ");
}

/** body=navy;lid=steel;size=500;engrave=MINATO の短い形（群の順。未選択と空は書かない） */
export function configuratorLine(groups: GroupInfo[], selection: Selection): string {
  const parts: string[] = [];
  for (const group of groups) {
    const value = selection[group.id];
    if (value === null || value === undefined) continue;
    const text = typeof value === "string" ? value : value.name;
    if (text.trim() === "") continue;
    parts.push(`${group.id}=${shortValue(text)}`);
  }
  return clipValue(parts.join(";"));
}

export interface PropertiesInput {
  lang: Lang;
  groups: GroupInfo[];
  shopify: ShopifyConfig;
  selection: Selection;
  /** 商品 URL + #pc=…（店の人が開けば同じ 3D になる）。空なら _preview を書かない */
  previewUrl: string;
  /** 参考価格（書式済み）。参考価格方式でだけ _reference_price に書く */
  referencePrice: string | null;
}

export function toProperties(input: PropertiesInput): Record<string, string> {
  const L = ADAPTER_LABELS[input.lang];
  // バリエーションに結びついた色・素材・パーツは、バリエーション名と二重になるので出さない（刻印とロゴは中身を出す）
  const bound = new Set(input.shopify.priceMode === "variant" ? input.shopify.bindings.map((b) => b.groupId) : []);
  const out: Record<string, string> = {};
  const put = (label: string, value: string) => {
    const base = propertyKey(label);
    if (base === "") return;
    let key = base;
    for (let n = 2; key in out; n += 1) key = `${base} (${n})`;
    out[key] = clipValue(value);
  };
  for (const group of input.groups) {
    if (input.shopify.hiddenProperties.includes(group.id)) continue;
    const value = input.selection[group.id];
    if (value === null || value === undefined) continue;
    if (group.type === "text") {
      if (typeof value === "string" && value.trim() !== "") put(group.label, value);
      continue;
    }
    if (group.type === "image") {
      if (typeof value === "object") put(group.label, `${value.name}${L.logoSuffix}`);
      continue;
    }
    if (bound.has(group.id) || typeof value !== "string") continue;
    const option = group.options.find((o) => o.id === value);
    if (option) put(group.label, option.label);
  }
  const line = configuratorLine(input.groups, input.selection);
  if (line !== "") out._configurator = line;
  // 切れた URL は開けないので、長すぎるときは書かない
  if (input.previewUrl !== "" && input.previewUrl.length <= PROPERTY_VALUE_LIMIT) out._preview = input.previewUrl;
  if (input.shopify.priceMode === "reference" && input.referencePrice !== null) out._reference_price = clipValue(input.referencePrice);
  return out;
}
