/** 選択 → バリエーション、Liquid の金額、画面に出す価格（バリエーション方式・参考価格方式） */
import type { SelectionJson } from "@core/selection";
import { selectedVariant, type Binding, type GroupInfo, type ShopifyConfig } from "./config";
import { ADAPTER_LABELS } from "./labels";
import type { Lang, PriceMode, ShopifyProduct, ShopifyVariant } from "./types";

export type Selection = SelectionJson["selection"];

export type VariantMatch =
  | { status: "ok"; variant: ShopifyVariant }
  | { status: "soldout"; variant: ShopifyVariant }
  | { status: "none"; variant: null };

/** Liquid の金額は最小単位の 100 倍の整数（円でも 100 倍）。100 で割って通貨の単位にする */
export function fromShopifyMoney(amount: number): number {
  return Math.round(amount) / 100;
}

/** 群の選択を、shopify.values の鍵（選択肢の id、filled / empty）にする */
export function valueKeyOf(group: GroupInfo, value: Selection[string] | undefined): string {
  if (group.type === "text") return typeof value === "string" && value.trim() !== "" ? "filled" : "empty";
  if (group.type === "image") return value === null || value === undefined ? "empty" : "filled";
  return typeof value === "string" ? value : "empty";
}

function matchOf(variant: ShopifyVariant | undefined): VariantMatch {
  if (!variant) return { status: "none", variant: null };
  return variant.available ? { status: "ok", variant } : { status: "soldout", variant };
}

/** 結びついた群の選択から、バリエーションを 1 つ探す */
export function findVariant(product: ShopifyProduct, bindings: Binding[], groups: GroupInfo[], selection: Selection): VariantMatch {
  if (bindings.length === 0) return matchOf(product.variants.length === 1 ? product.variants[0] : undefined);
  const byId = new Map(groups.map((g) => [g.id, g]));
  const wanted: { index: number; value: string }[] = [];
  for (const binding of bindings) {
    const group = byId.get(binding.groupId);
    if (!group) return { status: "none", variant: null };
    const value = binding.values[valueKeyOf(group, selection[binding.groupId])];
    if (value === undefined) return { status: "none", variant: null };
    wanted.push({ index: binding.optionIndex, value });
  }
  return matchOf(product.variants.find((v) => wanted.every((w) => v.options[w.index] === w.value)));
}

/** カートに入れるバリエーション。参考価格方式は商品ページで選ばれているもの */
export function cartVariant(product: ShopifyProduct, shopify: ShopifyConfig, groups: GroupInfo[], selection: Selection): VariantMatch {
  if (shopify.priceMode === "reference") return matchOf(selectedVariant(product));
  return findVariant(product, shopify.bindings, groups, selection);
}

/** 群が取りうる鍵（任意の群は「なし」= empty も） */
function keysOf(group: GroupInfo): string[] {
  if (group.type === "text" || group.type === "image") return ["filled", "empty"];
  const ids = group.options.map((o) => o.id);
  return group.required ? ids : [...ids, "empty"];
}

/** 結びついた群の全部の組み合わせのうち、バリエーションが無いものを数える */
export function countMissingCombos(product: ShopifyProduct, bindings: Binding[], groups: GroupInfo[]): { total: number; missing: number } {
  if (bindings.length === 0) return { total: 0, missing: 0 };
  const byId = new Map(groups.map((g) => [g.id, g]));
  let combos: Record<string, string>[] = [{}];
  for (const binding of bindings) {
    const group = byId.get(binding.groupId);
    if (!group) continue;
    combos = combos.flatMap((combo) => keysOf(group).map((key) => ({ ...combo, [binding.groupId]: key })));
  }
  let missing = 0;
  for (const combo of combos) {
    const values = bindings.map((b) => b.values[combo[b.groupId]]);
    const found = !values.includes(undefined as never) && product.variants.some((v) => bindings.every((b, i) => v.options[b.optionIndex] === values[i]));
    if (!found) missing += 1;
  }
  return { total: combos.length, missing };
}

export interface PriceView {
  label: string;
  /** 出す金額（書式済み）。出せないときは null */
  amount: string | null;
  note: string;
}

export interface PriceInput {
  lang: Lang;
  mode: PriceMode;
  match: VariantMatch;
  /** 核が計算した差額の合計（参考価格方式だけ使う） */
  delta: number;
  currency: string;
  shopCurrency: string;
  priceNote: string;
  referenceNote: string;
  format: (amount: number) => string;
}

/** 画面の価格。バリエーション方式はバリエーションの価格、参考価格方式はバリエーションの価格 + 差額（通貨が店と違えば出さない） */
export function priceView(input: PriceInput): PriceView {
  const L = ADAPTER_LABELS[input.lang];
  if (input.mode === "variant") {
    return { label: L.price, amount: input.match.variant ? input.format(fromShopifyMoney(input.match.variant.price)) : null, note: input.priceNote };
  }
  if (input.currency !== input.shopCurrency) {
    return { label: L.referencePrice, amount: null, note: L.referenceCurrency.replace("{currency}", input.shopCurrency) };
  }
  const base = input.match.variant ? fromShopifyMoney(input.match.variant.price) : null;
  return {
    label: L.referencePrice,
    amount: base === null ? null : input.format(base + input.delta),
    note: [input.priceNote, input.referenceNote].filter((s) => s !== "").join(" "),
  };
}
