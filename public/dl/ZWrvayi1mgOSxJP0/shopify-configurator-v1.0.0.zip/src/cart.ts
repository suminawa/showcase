/** カートへ: /cart/add.js の本文と送信、テーマのフォームの hidden input、失敗の文 */
import { ADAPTER_LABELS } from "./labels";
import type { Lang, PriceMode, ShopifyVariant } from "./types";

export interface CartLine {
  id: number;
  quantity: number;
  properties: Record<string, string>;
}

export interface AddBody {
  items: CartLine[];
}

export type AddResult = { ok: true } | { ok: false; status: number };

/** 数量は 1〜999 の整数に丸める */
export function clampQuantity(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return 1;
  return Math.min(999, Math.max(1, Math.trunc(n)));
}

export function addToCartBody(variantId: number, quantity: unknown, properties: Record<string, string>): AddBody {
  return { items: [{ id: variantId, quantity: clampQuantity(quantity), properties }] };
}

/** routes.root_url（"/" や "/en"）に道を足す */
export function cartUrl(routesRoot: string, path: string): string {
  return `${routesRoot.replace(/\/+$/, "")}${path}`;
}

/** 同じストアの /cart/add.js へ送る。Shopify の誤りの本文は読まない（画面に出さない） */
export async function addToCart(fetchFn: typeof fetch, routesRoot: string, body: AddBody): Promise<AddResult> {
  try {
    const response = await fetchFn(cartUrl(routesRoot, "/cart/add.js"), {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(body),
      credentials: "same-origin",
    });
    return response.ok ? { ok: true } : { ok: false, status: response.status };
  } catch {
    return { ok: false, status: 0 };
  }
}

/** 422（在庫）のときだけ在庫の文、それ以外は同じ文 */
export function cartErrorMessage(status: number, lang: Lang): string {
  const L = ADAPTER_LABELS[lang];
  return status === 422 ? L.cartSoldOut : L.cartFailed;
}

/**
 * 参考価格方式は、3D の選択がバリエーションを決めない（商品ページで選ばれているバリエーション固定）。
 * フォームの [name="id"] にすでに入っている値が、この商品のバリエーションの id なら、そちらを使う
 * （Dawn 自身のバリエーションの選択が動き続けるように）。それ以外（バリエーション方式・値が無い・商品の外の値）は、
 * これまでどおり計算したバリエーションを使う
 */
export function resolveThemeVariantId(mode: PriceMode, formIdValue: string | undefined, computed: number | null, variants: ShopifyVariant[]): number | null {
  if (mode === "reference" && formIdValue !== undefined) {
    const raw = Number(formIdValue);
    if (Number.isFinite(raw) && variants.some((v) => v.id === raw)) return raw;
  }
  return computed;
}

/**
 * テーマの購入ボタンのフォームに載せる（cart_mode = theme）。
 * container（snippet の <div data-sc-properties>）の中を properties[...] の hidden input で書き直し、
 * フォームの name="id" を決めたバリエーションに変えて change を送る。決まらなければ購入ボタンを押せなくする。
 */
export function writeFormInputs(container: HTMLElement, variantId: number | null, properties: Record<string, string>): void {
  const doc = container.ownerDocument;
  for (const old of Array.from(container.querySelectorAll("input[data-sc-input]"))) old.remove();
  for (const [key, value] of Object.entries(properties)) {
    const input = doc.createElement("input");
    input.type = "hidden";
    input.name = `properties[${key}]`;
    input.value = value;
    input.setAttribute("data-sc-input", "");
    container.append(input);
  }
  const form = container.closest("form");
  if (!form) return;
  const idField = form.querySelector<HTMLInputElement | HTMLSelectElement>('[name="id"]');
  if (idField && variantId !== null && idField.value !== String(variantId)) {
    idField.value = String(variantId);
    idField.dispatchEvent(new Event("change", { bubbles: true }));
  }
  const submit = form.querySelector<HTMLButtonElement>('[type="submit"]');
  if (submit) submit.disabled = variantId === null;
}
