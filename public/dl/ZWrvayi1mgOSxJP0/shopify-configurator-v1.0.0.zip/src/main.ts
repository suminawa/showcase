/** つなぎの本体: section の JSON 2 つを読み、核を mount し、価格とカートのボタンを出す */
import { addToCart, addToCartBody, cartErrorMessage, cartUrl, resolveThemeVariantId, writeFormInputs } from "./cart";
import { parseContext, parseMetafield } from "./config";
import { ADAPTER_LABELS, t } from "./labels";
import { storeMoneyFormatter } from "./money";
import { toProperties } from "./properties";
import { cartVariant, priceView, type VariantMatch } from "./variants";
import type { CartMode, CoreGlobal, CoreHandle, SectionContext, SelectionJson, ShopifyVariant } from "./types";

export interface BootEnv {
  core: CoreGlobal;
  /**
   * つなぎの script（suminawa-configurator.js）のある場所（URL の、最後の / まで。? から後ろは含まない）。
   * 3D の束（data-scene-src）は、同じ場所にあるものだけを読む。分からなければ null
   */
  scriptDir: string | null;
  fetch: typeof fetch;
  location: { origin: string; assign(url: string): void };
  console: Pick<Console, "warn">;
}

export interface SectionHandle {
  destroy(): void;
}

/** カートに入ったあとに root で送る合図。preventDefault すると /cart へ移らない（カートの引き出しを開くテーマ向け） */
export const ADDED_EVENT = "suminawa-configurator:added";

const PREFIX = "[suminawa-configurator]";

function el<K extends keyof HTMLElementTagNameMap>(doc: Document, tag: K, className: string, text = ""): HTMLElementTagNameMap[K] {
  const node = doc.createElement(tag);
  if (className !== "") node.className = className;
  if (text !== "") node.textContent = text;
  return node;
}

/** section の中の <script type="application/json"> だけから読む（同じ属性を持つほかの要素からは読まない） */
function jsonOf(root: HTMLElement, attribute: string): string | null {
  return root.querySelector(`script[type="application/json"][${attribute}]`)?.textContent ?? null;
}

/**
 * URL のファイルがある場所（origin + 道の、最後の / まで）。? と # から後ろは見ない。読めなければ null。
 * cdn.shopify.com のように、出どころ（origin）を多くのストアが共有する場所があるので、出どころではなく場所で比べる
 */
export function dirOf(url: string | undefined | null, base: string): string | null {
  if (typeof url !== "string" || url === "") return null;
  try {
    const parsed = new URL(url, base);
    if (parsed.origin === "null" || parsed.username !== "" || parsed.password !== "") return null;
    return `${parsed.origin}${parsed.pathname.slice(0, parsed.pathname.lastIndexOf("/") + 1)}`;
  } catch {
    return null;
  }
}

function hostOf(origin: string): string | undefined {
  try {
    return new URL(origin).host;
  } catch {
    return undefined;
  }
}

/**
 * 誤りで動かせないときのお客さまの画面。カートの方式が「コンフィギュレーターのボタン」のときは、テーマの価格と購入ボタンが
 * 隠されていて商品ページが空になるので、誤りの中身は出さずに一言だけ出す。
 * 「テーマの購入ボタン」のときはテーマのボタンで買えるので、section ごと隠す。section の設定が読めなかったときも隠す
 */
function showUnavailable(root: HTMLElement, context: SectionContext | null): void {
  if (context === null || context.settings.cartMode !== "own") {
    root.hidden = true;
    return;
  }
  // 描きかけの核が残っていても見えないように、差し込み口ごと隠す（中身は消さない。核が描画を続けていても触らないため）
  const mountPoint = root.querySelector<HTMLElement>("[data-sc-mount]");
  if (mountPoint) mountPoint.hidden = true;
  if (root.querySelector("[data-sc-unavailable]")) return;
  const note = el(root.ownerDocument, "p", "sc-unavailable", ADAPTER_LABELS[context.lang].storefrontUnavailable);
  note.setAttribute("data-sc-unavailable", "");
  note.setAttribute("role", "status");
  root.append(note);
}

/**
 * 設定の誤り・お知らせ。テーマエディタの中（design_mode）で「誤りを出す」が on のときだけ section に出す。
 * それ以外は console に 1 行。誤り（fatal）なら、お客さまには誤りの文を見せず、showUnavailable の一言か、section ごと隠す
 */
function showProblems(root: HTMLElement, context: SectionContext | null, messages: string[], fatal: boolean, env: Pick<BootEnv, "console">): void {
  if (context === null || !context.designMode || !context.settings.showErrors) {
    env.console.warn(`${PREFIX} ${messages.join(" / ")}`);
    if (fatal) showUnavailable(root, context);
    return;
  }
  const doc = root.ownerDocument;
  const L = ADAPTER_LABELS[context.lang];
  const box = root.querySelector<HTMLElement>("[data-sc-errors]") ?? root;
  const panel = el(doc, "div", fatal ? "sc-problems sc-problems--error" : "sc-problems");
  panel.setAttribute("role", fatal ? "alert" : "status");
  panel.append(el(doc, "p", "sc-problems-title", fatal ? L.errorsTitle : L.warningsTitle));
  const list = el(doc, "ul", "sc-problems-list");
  for (const message of messages) list.append(el(doc, "li", "", message));
  panel.append(list);
  box.append(panel);
  box.hidden = false;
}

/**
 * カートの方式が「テーマの購入ボタン」のときの [data-sc-properties] を選ぶ。
 * ページに同じ snippet を置いたフォームが複数あるとき（関連商品などで同じ商品テンプレートが繰り返される場合）、
 * 単純な最初の 1 つではなく、この商品のバリエーションの id を持つフォームを探す。無ければ最初の 1 つ
 */
function pickPropertiesSlot(doc: Document, variants: ShopifyVariant[]): HTMLElement | null {
  const slots = Array.from(doc.querySelectorAll<HTMLElement>("[data-sc-properties]"));
  if (slots.length === 0) return null;
  const ids = new Set(variants.map((v) => v.id));
  for (const slot of slots) {
    const idField = slot.closest("form")?.querySelector<HTMLInputElement | HTMLSelectElement>('[name="id"]');
    const raw = idField ? Number(idField.value) : NaN;
    if (Number.isFinite(raw) && ids.has(raw)) return slot;
  }
  return slots[0];
}

interface CartUi {
  root: HTMLElement;
  priceLabel: HTMLElement;
  priceAmount: HTMLElement;
  priceNote: HTMLElement;
  reason: HTMLElement;
  status: HTMLElement;
  quantity: HTMLInputElement | null;
  button: HTMLButtonElement | null;
}

function buildCartUi(doc: Document, context: SectionContext, cartMode: CartMode): CartUi {
  const L = ADAPTER_LABELS[context.lang];
  const root = el(doc, "div", "sc-cart");
  const price = el(doc, "div", "sc-price");
  price.setAttribute("aria-live", "polite");
  const priceLabel = el(doc, "span", "sc-price-label");
  const priceAmount = el(doc, "strong", "sc-price-amount");
  const priceNote = el(doc, "span", "sc-price-note");
  price.append(priceLabel, priceAmount, priceNote);
  const reason = el(doc, "p", "sc-reason");
  reason.setAttribute("role", "status");
  const status = el(doc, "p", "sc-status");
  status.setAttribute("role", "alert");
  root.append(price, reason);
  let quantity: HTMLInputElement | null = null;
  let button: HTMLButtonElement | null = null;
  if (cartMode === "own") {
    const buy = el(doc, "div", "sc-buy");
    if (context.settings.showQuantity) {
      const label = el(doc, "label", "sc-qty");
      label.append(el(doc, "span", "sc-qty-label", L.quantity));
      quantity = el(doc, "input", "sc-qty-input");
      quantity.type = "number";
      quantity.min = "1";
      quantity.max = "999";
      quantity.value = "1";
      quantity.inputMode = "numeric";
      label.append(quantity);
      buy.append(label);
    }
    button = el(doc, "button", "sc-add");
    button.type = "button";
    buy.append(button);
    root.append(buy, status);
  }
  return { root, priceLabel, priceAmount, priceNote, reason, status, quantity, button };
}

/**
 * 核（product-configurator.global.js）が読み込まれていないときの section の見え方。設定の誤りと同じ道を通る:
 * テーマエディタの中（誤りを出すが on）では誤りの一覧、それ以外は console に 1 行と、お客さま向けの一言（または section ごと隠す）
 */
export function showCoreMissing(root: HTMLElement, env: Pick<BootEnv, "console">): void {
  const result = parseContext(jsonOf(root, "data-sc-context"));
  const context = result.ok ? result.value : null;
  const ja = "product-configurator.global.js が読み込まれていません。テーマの assets にあるかをご確認ください。";
  const en = "product-configurator.global.js is not loaded. Please check that it is in the theme's assets.";
  // 言語が分からないとき（section の設定が読めない）は、日本語と英語を 1 行に並べる
  const message = context === null ? `${ja} / ${en}` : t(context.lang, ja, en);
  showProblems(root, context, [message], true, env);
}

/** section 1 つを動かす。設定の誤りで動かせなければ null */
export function bootSection(root: HTMLElement, env: BootEnv): SectionHandle | null {
  const doc = root.ownerDocument;
  const contextResult = parseContext(jsonOf(root, "data-sc-context"));
  if (!contextResult.ok) {
    showProblems(root, null, [contextResult.error], true, env);
    return null;
  }
  const context = contextResult.value;
  const lang = context.lang;
  const L = ADAPTER_LABELS[lang];
  // 3D の束は script として読み込まれる。つなぎの script と同じ場所（同じフォルダ）にあるものだけを読む
  {
    const sceneDir = dirOf(root.dataset.sceneSrc, doc.baseURI);
    if (env.scriptDir === null || sceneDir === null || sceneDir !== env.scriptDir) {
      showProblems(
        root,
        context,
        [
          t(
            lang,
            "3D の部品（data-scene-src）の場所が、キットの script（suminawa-configurator.js）と同じ場所ではありません。section のファイルが書き換えられていないか、script を書き換えるアプリが入っていないかをご確認ください。",
            "The 3D module (data-scene-src) is not in the same place as the kit's own script (suminawa-configurator.js). Please check that the section file has not been altered and that no app rewrites the scripts.",
          ),
        ],
        true,
        env,
      );
      return null;
    }
  }
  const parsed = parseMetafield(jsonOf(root, "data-sc-config") ?? "", context, {
    sceneSrc: root.dataset.sceneSrc ?? "",
    resolveConfig: (input) => env.core.resolveConfig(input),
    pageHost: hostOf(env.location.origin),
  });
  if (!parsed.ok) {
    showProblems(root, context, parsed.errors, true, env);
    return null;
  }
  const config = parsed.value;
  const mountPoint = root.querySelector<HTMLElement>("[data-sc-mount]");
  if (!mountPoint) {
    showProblems(root, context, [t(lang, "[data-sc-mount] が section にありません（section のファイルが壊れていないかご確認ください）。", "[data-sc-mount] is missing from the section (please check that the section file is intact).")], true, env);
    return null;
  }
  let handle: CoreHandle;
  try {
    handle = env.core.mount(mountPoint, config.core);
  } catch (error) {
    // 核は描き始めてから失敗することがある。描きかけが誤りの一覧や一言の横に出ないよう、差し込み口を隠す
    mountPoint.hidden = true;
    showProblems(root, context, [error instanceof Error ? error.message : String(error)], true, env);
    return null;
  }
  const mode = config.shopify.priceMode;
  root.dataset.scMode = mode;
  // 参考価格方式で、表示中の通貨が店の通貨と違うときは、選択肢ごとの差額（pc-option-price）を CSS で隠す。合計の案内は「参考価格は○○でご案内します」の注記だけで示す
  if (mode === "reference" && context.currency !== context.shopCurrency) root.dataset.scCurrencyMismatch = "";

  let cartMode = context.settings.cartMode;
  const warnings = [...config.warnings];
  const themeSlot = cartMode === "theme" ? pickPropertiesSlot(doc, context.product.variants) : null;
  if (cartMode === "theme" && themeSlot === null) {
    warnings.push(L.themeFormMissing);
    cartMode = "own";
  }
  if (warnings.length > 0) showProblems(root, context, warnings, false, env);

  // テーマの購入ボタンの、触る前の disabled（destroy で元に戻すため）
  const themeForm = themeSlot?.closest("form") ?? null;
  const themeSubmit = themeForm?.querySelector<HTMLButtonElement>('[type="submit"]') ?? null;
  const themeSubmitWasDisabled = themeSubmit?.disabled ?? false;

  // 核の操作列の下（.pc-panel の最後）に置く。見つからなければ mount の後ろ
  const ui = buildCartUi(doc, context, cartMode);
  const panel = mountPoint.querySelector<HTMLElement>(".pc-panel");
  if (panel) panel.append(ui.root);
  else mountPoint.after(ui.root);

  // 金額は店の書式（テーマが出す価格と同じ見た目）で出す。店の書式は店の通貨のものなので、表示中の通貨が店の通貨と違うとき
  // （Shopify マーケット）と、書式が使えないときは、ブラウザの書式に戻す
  // 店の書式は 1 度だけ読む（選択が変わるたびに読み直さない）
  const storeFormat = context.currency === context.shopCurrency ? storeMoneyFormatter(context.moneyFormat) : null;
  // 金額の文字を作る途中で何が起きても、価格とボタンを描きかけにしない: 店の書式 → ブラウザの書式 → 数字と通貨の名前、の順に戻す
  const format = (amount: number): string => {
    try {
      const store = storeFormat === null ? null : storeFormat(amount);
      if (store !== null) return store;
    } catch {
      // 下のブラウザの書式に戻す
    }
    try {
      return env.core.formatPrice(amount, context.currency, lang === "ja" ? "ja-JP" : "en-US");
    } catch {
      return `${amount} ${context.currency}`;
    }
  };
  const previewUrl = (share: string): string => {
    const at = share.indexOf("#");
    return at < 0 ? "" : `${env.location.origin}${context.product.url}${share.slice(at)}`;
  };

  interface Current {
    json: SelectionJson;
    match: VariantMatch;
    referencePrice: string | null;
  }
  let current: Current | null = null;
  let busy = false;

  const propertiesOf = (state: Current) =>
    toProperties({ lang, groups: config.groups, shopify: config.shopify, selection: state.json.selection, previewUrl: previewUrl(handle.shareUrl()), referencePrice: state.referencePrice });

  const render = () => {
    if (current === null) return;
    const { match } = current;
    ui.reason.textContent = match.status === "none" ? L.unavailable : match.status === "soldout" ? L.soldOut : "";
    if (ui.button) {
      ui.button.disabled = busy || match.status !== "ok";
      ui.button.textContent = busy ? L.adding : context.settings.buttonLabel || L.addToCart;
    }
  };

  // 核が持つ価格の欄（.pc-price）は使わない（価格はつなぎが出す）。CSS で隠しているが、CSS が読み込まれないときも
  // 読み上げの道具に出ないよう、属性でも隠す。核が描き直しても外れないよう、選択が変わるたびに付け直す（核の中身の文字は変えない）
  const hideCorePrice = () => {
    for (const node of Array.from(mountPoint.querySelectorAll<HTMLElement>(".pc-price"))) {
      node.hidden = true;
      node.setAttribute("aria-hidden", "true");
      node.removeAttribute("aria-live");
    }
  };

  const update = (json: SelectionJson) => {
    hideCorePrice();
    const match = cartVariant(context.product, config.shopify, config.groups, json.selection);
    const view = priceView({
      lang,
      mode,
      match,
      delta: json.price.delta,
      currency: context.currency,
      shopCurrency: context.shopCurrency,
      priceNote: config.priceNote,
      referenceNote: config.shopify.referenceNote,
      format,
    });
    ui.priceLabel.textContent = view.label;
    ui.priceAmount.textContent = view.amount ?? "";
    ui.priceNote.textContent = view.note;
    ui.status.textContent = "";
    current = { json, match, referencePrice: mode === "reference" ? view.amount : null };
    render();
    if (themeSlot) {
      // 参考価格方式は選んだ 3D の内容がバリエーションを決めない（商品ページで選ばれているもの固定）ので、
      // フォームにすでに入っている id（Dawn のバリエーションの選択が書いたもの）が商品のバリエーションなら、それを優先する
      const idField = themeForm?.querySelector<HTMLInputElement | HTMLSelectElement>('[name="id"]');
      const variantId = resolveThemeVariantId(mode, idField?.value, match.status === "ok" ? match.variant.id : null, context.product.variants);
      writeFormInputs(themeSlot, variantId, propertiesOf(current));
    }
  };

  const add = async () => {
    const state = current;
    if (state === null || busy) return;
    const match = state.match;
    if (match.status !== "ok") return;
    const body = addToCartBody(match.variant.id, ui.quantity ? ui.quantity.value : 1, propertiesOf(state));
    busy = true;
    render();
    const result = await addToCart(env.fetch, context.routesRoot, body);
    busy = false;
    render();
    if (!result.ok) {
      ui.status.textContent = cartErrorMessage(result.status, lang);
      return;
    }
    const proceed = root.dispatchEvent(new CustomEvent(ADDED_EVENT, { bubbles: true, cancelable: true, detail: body.items[0] }));
    if (proceed) env.location.assign(cartUrl(context.routesRoot, "/cart"));
  };
  const onClick = () => void add();
  ui.button?.addEventListener("click", onClick);

  update(handle.getSelection());
  const unsubscribe = handle.subscribe(update);

  return {
    destroy() {
      unsubscribe();
      ui.button?.removeEventListener("click", onClick);
      handle.destroy();
      ui.root.remove();
      if (themeSlot) themeSlot.replaceChildren();
      if (themeSubmit) themeSubmit.disabled = themeSubmitWasDisabled;
    },
  };
}
