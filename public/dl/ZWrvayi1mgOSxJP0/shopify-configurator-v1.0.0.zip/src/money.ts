/** 店の金額の書式（Liquid の shop.money_format。例 "¥{{amount_no_decimals}}"、"${{amount}}"、"{{amount_with_comma_separator}} €"）で金額を出す */

interface Style {
  decimals: 0 | 2;
  thousands: string;
  decimal: string;
}

/** Shopify の money フィルターと同じ決まり */
const STYLES: Record<string, Style> = {
  amount: { decimals: 2, thousands: ",", decimal: "." },
  amount_no_decimals: { decimals: 0, thousands: ",", decimal: "." },
  amount_with_comma_separator: { decimals: 2, thousands: ".", decimal: "," },
  amount_no_decimals_with_comma_separator: { decimals: 0, thousands: ".", decimal: "," },
  amount_with_apostrophe_separator: { decimals: 2, thousands: "'", decimal: "." },
  amount_no_decimals_with_space_separator: { decimals: 0, thousands: " ", decimal: "," },
  amount_with_space_separator: { decimals: 2, thousands: " ", decimal: "," },
  amount_with_period_and_space_separator: { decimals: 2, thousands: " ", decimal: "." },
};

const PLACEHOLDER = /\{\{\s*([a-z_]+)\s*\}\}/;

/** 文字に戻す名前つきの文字参照。< と > には戻さない（タグに見える文字を出さないため） */
const NAMED: Record<string, string> = { amp: "&", yen: "¥", euro: "€", pound: "£", nbsp: " ", quot: '"' };

/** 文字参照の番号を文字にする。範囲の外（0、0x10FFFF より上、サロゲート）は元の文字のまま */
function fromCode(code: number, whole: string): string {
  if (!Number.isInteger(code) || code < 1 || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return whole;
  return String.fromCodePoint(code);
}

/**
 * 書式に混ざる HTML のタグ（<span class="money"> など）を外し、文字参照を文字に戻す。
 * 画面には textContent で出すのでタグは要らない。最後に < と > を取り除き、タグに見える文字を残さない
 */
function plain(text: string): string {
  return text
    .replace(/<[^>]*>/g, "")
    .replace(/&#(\d+);/g, (whole: string, code: string) => fromCode(Number(code), whole))
    .replace(/&#x([0-9a-f]+);/gi, (whole: string, code: string) => fromCode(parseInt(code, 16), whole))
    .replace(/&([a-z]+);/gi, (whole: string, name: string) => NAMED[name.toLowerCase()] ?? whole)
    .replace(/[<>]/g, "");
}

/** 書式の置き場の名前（amount、amount_no_decimals など）。書式が使えなければ null */
export function moneyStyleOf(format: string): string | null {
  try {
    const found = PLACEHOLDER.exec(plain(format));
    return found && STYLES[found[1]] ? found[1] : null;
  } catch {
    return null;
  }
}

function digits(amount: number, style: Style): string {
  const [whole, fraction] = amount.toFixed(style.decimals).split(".");
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, style.thousands);
  return fraction === undefined ? grouped : `${grouped}${style.decimal}${fraction}`;
}

interface Parts {
  before: string;
  name: string;
  style: Style;
  after: string;
}

/** 書式の長さの上限。これより長い書式は使わない */
export const MONEY_FORMAT_LIMIT = 200;

/**
 * 書式を、置き場の前の文字・置き場・後ろの文字に分ける。文字だけでは元の書式どおりに出せないときは null:
 * 置き場が無い・知らない・2 つ以上ある、前後に数字がある（金額と続けて読めてしまう）、文字参照の形が残っている
 */
function partsOf(format: string): Parts | null {
  if (typeof format !== "string" || format.length > MONEY_FORMAT_LIMIT) return null;
  const text = plain(format).trim();
  const found = PLACEHOLDER.exec(text);
  if (!found) return null;
  const style = STYLES[found[1]];
  if (!style) return null;
  const before = text.slice(0, found.index);
  const after = text.slice(found.index + found[0].length);
  const around = before + after;
  if (/\{\{|\}\}/.test(around)) return null;
  if (/\p{Nd}/u.test(around)) return null;
  if (/&#?[a-z0-9]+;/i.test(around)) return null;
  return { before, name: found[1], style, after };
}

/** 店の書式を使えるか（formatStoreMoney が金額を出せる書式か） */
export function isUsableMoneyFormat(format: string): boolean {
  try {
    return partsOf(format) !== null;
  } catch {
    return false;
  }
}

/**
 * 書式が「通貨の記号 1 文字 + {{amount}} か {{amount_no_decimals}}」の形か（"${{amount}}"、"¥{{amount_no_decimals}}" など）。
 * 記号は、文字でも数字でも空白でもない 1 文字。後ろには何も付かない。
 * 核がブラウザの書式で描く差額（記号が前、区切りは , と .）と、見た目がそろう形
 */
export function isLeadingSymbolFormat(format: string): boolean {
  try {
    const parts = partsOf(format);
    if (parts === null) return false;
    if (parts.name !== "amount" && parts.name !== "amount_no_decimals") return false;
    return parts.after === "" && /^[^\p{L}\p{N}\s]$/u.test(parts.before);
  } catch {
    return false;
  }
}

/**
 * amount は通貨の単位（4700 円なら 4700、12.5 ドルなら 12.5）。
 * 次のときは null（呼ぶ側がブラウザの書式に戻す）: 書式が空か、文字だけでは元のとおりに出せない（partsOf）、
 * 金額が負・数でない・大きすぎる（1e15 以上）、途中で失敗した
 */
export function formatStoreMoney(amount: number, format: string): string | null {
  return storeMoneyFormatter(format)?.(amount) ?? null;
}

/** 書式を 1 度だけ読み、金額を文字にする関数を返す。書式が使えなければ null */
export function storeMoneyFormatter(format: string): ((amount: number) => string | null) | null {
  let parts: Parts | null;
  try {
    parts = partsOf(format);
  } catch {
    return null;
  }
  if (parts === null) return null;
  const { before, style, after } = parts;
  return (amount) => {
    try {
      if (!Number.isFinite(amount) || amount < 0 || amount >= 1e15) return null;
      return `${before}${digits(amount, style)}${after}`;
    } catch {
      return null;
    }
  };
}
