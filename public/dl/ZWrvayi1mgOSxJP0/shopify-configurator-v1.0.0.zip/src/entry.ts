/** IIFE の入口（theme/assets/suminawa-configurator.js）。product-configurator.global.js のあとに読む */
import { bootSection, dirOf, showCoreMissing, type BootEnv, type SectionHandle } from "./main";
import type { CoreGlobal } from "./types";

const SELECTOR = "[data-suminawa-configurator]";
/** この script のある場所。読み込まれたその場でしか分からないので、はじめに控える */
const SCRIPT_DIR = dirOf(document.currentScript instanceof HTMLScriptElement ? document.currentScript.getAttribute("src") : null, document.baseURI);
const handles = new WeakMap<HTMLElement, SectionHandle>();
/** 核が無いことを知らせ済みの section（同じ一言や誤りを 2 度出さない） */
const reported = new WeakSet<HTMLElement>();

function envOf(): BootEnv | null {
  const core = (window as Window & { ProductConfigurator?: CoreGlobal }).ProductConfigurator;
  if (!core) return null;
  return { core, scriptDir: SCRIPT_DIR, fetch: window.fetch.bind(window), location: window.location, console };
}

function bootWithin(scope: ParentNode): void {
  const roots = Array.from(scope.querySelectorAll<HTMLElement>(SELECTOR));
  if (roots.length === 0) return;
  const env = envOf();
  if (!env) {
    for (const root of roots) {
      if (reported.has(root)) continue;
      reported.add(root);
      showCoreMissing(root, { console });
    }
    return;
  }
  for (const root of roots) {
    if (handles.has(root)) continue;
    const handle = bootSection(root, env);
    if (handle) handles.set(root, handle);
  }
}

function start(): void {
  bootWithin(document);
  // テーマエディタで section を足したり設定を変えたりすると、section が差し替わる
  document.addEventListener("shopify:section:load", (event) => bootWithin(event.target as ParentNode));
  document.addEventListener("shopify:section:unload", (event) => {
    for (const root of Array.from((event.target as ParentNode).querySelectorAll<HTMLElement>(SELECTOR))) {
      handles.get(root)?.destroy();
      handles.delete(root);
    }
  });
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
else start();
