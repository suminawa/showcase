/** つなぎの型。核（product-configurator）の型は import type でだけ読む（束に核を積まないため） */
import type { ConfiguratorConfig, ResolvedConfig } from "@core/config";
import type { PriceBreakdown } from "@core/price";
import type { SelectionJson } from "@core/selection";

export type { ConfiguratorConfig, PriceBreakdown, ResolvedConfig, SelectionJson };

export type Lang = "ja" | "en";
export type PriceMode = "variant" | "reference";
export type CartMode = "own" | "theme";

/** Liquid が書き出すバリエーション。price は Liquid の金額（最小単位の 100 倍の整数。円でも 100 倍） */
export interface ShopifyVariant {
  id: number;
  title: string;
  options: string[];
  price: number;
  available: boolean;
  sku: string;
}

export interface ShopifyProduct {
  id: number;
  title: string;
  handle: string;
  url: string;
  /** 商品のオプション名（多くて 3 つ） */
  options: string[];
  selectedVariantId: number | null;
  variants: ShopifyVariant[];
}

/** section の設定（テーマエディタ） */
export interface SectionSettings {
  priceMode: PriceMode;
  cartMode: CartMode;
  showQuantity: boolean;
  buttonLabel: string;
  showErrors: boolean;
}

/** section の <script type="application/json" data-sc-context> を読んだもの */
export interface SectionContext {
  lang: Lang;
  product: ShopifyProduct;
  /** 表示中の通貨（cart.currency.iso_code） */
  currency: string;
  /** 店の通貨（shop.currency） */
  shopCurrency: string;
  /** routes.root_url（"/" や "/en"） */
  routesRoot: string;
  /** request.design_mode（テーマエディタの中） */
  designMode: boolean;
  /** page/mock-product.html だけが true にする。model.src に相対パスを許す */
  mock: boolean;
  settings: SectionSettings;
}

/** 核の mount が返す取っ手のうち、つなぎが使うもの */
export interface CoreHandle {
  getSelection(): SelectionJson;
  setSelection(partial: Record<string, unknown>): void;
  getPrice(): PriceBreakdown;
  reset(): void;
  shareUrl(): string;
  subscribe(listener: (selection: SelectionJson) => void): () => void;
  destroy(): void;
}

/** window.ProductConfigurator（product-configurator.global.js）のうち、つなぎが使うもの */
export interface CoreGlobal {
  mount(root: HTMLElement, config: ConfiguratorConfig): CoreHandle;
  resolveConfig(input: unknown): ResolvedConfig;
  formatPrice(amount: number, currency: string, locale?: string): string;
}
