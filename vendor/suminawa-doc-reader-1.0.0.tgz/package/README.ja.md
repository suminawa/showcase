# AI 書類読み取りキット v1.0.0

請求書・領収書・注文書・名刺・申込書の PDF や写真から、決めた項目を AI が読み取ります。読み取った値は確認画面で直してから、CSV かスプレッドシートに 1 行で出します。API の鍵はご自身のもので、書類も結果もサーバーには残りません。

## 1. 何ができるか

- 帳票の型（`forms/*.json`）で決めた項目を、書類から書き写します。同梱の型は 5 種（請求書・領収書・注文書・名刺・申込書）で、自分の型も足せます
- 項目ごとに値・信頼度・根拠になった文字が返ります。必須が空、形式が合わない、明細の合計が合わない、信頼度が低い、といった点は警告になり、その書類は「要確認」になります
- 確認画面（同梱の Next.js テンプレ）で値を直し、確定した行を CSV に保存するか、同梱の受け口（Google Apps Script）でスプレッドシートに追加します
- コマンド `npx doc-reader run` で、フォルダの書類をまとめて読んで CSV にできます
- 同じファイル、同じ請求書番号を同じ日に 2 度読むと知らせます

読み取りは Anthropic の Claude が行い、日付や金額の変換（和暦 → 西暦、「¥12,800-」→ 12800）と検証はキットのコードが行います。

## 2. 置き方は 3 通り

1. **同梱の Next.js テンプレを Vercel に置く**（いちばん簡単）: `templates/nextjs/README.md` の手順どおりに。確認画面つきです
2. **いまの Next.js に足す**: `npm install ./vendor/suminawa-doc-reader-1.0.0.tgz`（テンプレの `vendor/` にあります）のあと、`app/api/reader/[...path]/route.ts` をテンプレから写し、`forms/` と `reader.config.json` を置きます。画面はテンプレの `components/` を写すか、`@suminawa/doc-reader/ui` の状態管理を使って自分で作れます
3. **自前のサーバー**: `node dist/adapters/node.js`。`demo/index.html` が同じ API を使う素の HTML の見本です

サーバー部品の入口は `createReader(config, { forms })` で、Web 標準の `Request → Response` です。

## 3. 帳票の型

`forms/invoice.json` を開くと、書き方が分かります。

```json
{
  "id": "invoice",
  "name": "請求書",
  "fields": [
    { "key": "issuer", "label": "請求元", "type": "string", "required": true, "hint": "請求書を発行した会社" },
    { "key": "total", "label": "合計金額", "type": "money", "required": true },
    { "key": "lineItems", "label": "明細", "type": "table", "columns": [
      { "key": "description", "label": "品名", "type": "string" },
      { "key": "amount", "label": "金額", "type": "money" }
    ] }
  ],
  "checks": [{ "type": "sum", "items": "lineItems.amount", "equals": "subtotal", "tolerance": 1 }]
}
```

- `type` は `string` / `number` / `money`（整数の円）/ `date`（`YYYY-MM-DD`）/ `boolean` / `enum`（`options` が要ります）/ `table`（`columns` が要ります。列は string・number・money・date）
- `hint` は書類のどこにあるかの手がかりです。書いておくほど読み違いが減ります
- `pattern` は string の形式（正規表現）。合わないと警告になります
- `checks` は書類の中の突き合わせ。`items` は「表.列」、`parts` は項目の配列で、`equals` の項目と比べます

画面の「自由項目」は、型を保存せずに項目名だけを並べて試す入口です。うまくいったら JSON にして `forms/` へ置いてください。

## 4. 読み取りの結果

`POST /api/reader/extract`（multipart の `file` と `form`、または JSON の `{ fileName, data(base64), form }`）は次を返します。

```json
{
  "ok": true,
  "documentId": "ba7816bf…",
  "form": "invoice",
  "fileName": "請求書.pdf",
  "pages": 1,
  "fields": { "issuer": { "value": "さくら設備株式会社", "confidence": 0.97, "evidence": "さくら設備株式会社" } },
  "tables": { "lineItems": { "rows": [{ "description": "給湯器交換工事", "amount": 128000 }], "confidence": 0.9 } },
  "warnings": [{ "key": "dueDate", "code": "required", "message": "「支払期限」が読み取れませんでした。書類を見てご入力ください。" }],
  "needsReview": true,
  "notes": "",
  "usage": { "inputTokens": 2810, "outputTokens": 420, "cacheReadTokens": 690, "cacheCreationTokens": 0 },
  "ms": 4200
}
```

失敗は `{ "ok": false, "code": "…", "message": "…" }` です。`code` は `unsupported`（種類が違う）/ `too_large` / `too_many_pages` / `rate_limited` / `daily_limit` / `unreadable`（読めなかった）/ `refused` / `unavailable`（鍵や通信）。

## 5. 確認画面（テンプレ）

書類を置くと順に読み取り、一覧に「待ち・読み取り中・要確認・確定・読めませんでした」が並びます。要確認の書類を開くと、左に書類、右に項目が出ます。黄色の項目は信頼度が低いか警告のあるものです。直して「確定」を押すと、CSV に含まれます。

出し方は 3 つ。「CSV を保存」（Excel でそのまま開ける BOM つき）、「TSV をコピー」（表計算ソフトに貼り付け）、「スプレッドシートに送る」（受け口を設定したときだけ出ます）。明細のある型は「明細の CSV を保存」も出ます（書類 ID と主キー項目つきの別ファイルです）。

書類も結果もサーバーには残りません。ページを閉じると結果は消えます。

## 6. コマンド

```bash
npx doc-reader run ./inbox --form invoice --out results.csv     # フォルダの書類を順に読む
npx doc-reader run a.pdf b.jpg --out results.jsonl               # JSONL なら失敗の記録も残る
npx doc-reader check                                             # 同梱の見本 12 枚で一致率を測る
npx doc-reader forms                                             # 型と項目の一覧
```

`run` は要確認の件数と読めなかった件数を最後に出します。`--concurrency`（1〜4、既定 2）で同時に読む数を、`--model` でモデルを変えられます。鍵が無いときは `READER_FAKE=1` で見本の書類だけ読めます（動きの確認用です）。

## 7. スプレッドシートに送る

1. 送り先のスプレッドシートを開き、拡張機能 → Apps Script を開きます
2. `gas/receiver.gs` の中身を貼って保存します
3. プロジェクトの設定 → スクリプト プロパティに `TOKEN` を追加し、長いランダムな文字を入れます
4. デプロイ → 新しいデプロイ → 種類「ウェブアプリ」、実行ユーザー「自分」、アクセスできるユーザー「全員」でデプロイし、URL を控えます
5. サーバーの環境変数に `SEND_WEBHOOK_URL`（その URL）と `SEND_TOKEN`（3 の文字）を入れます

確認画面の「スプレッドシートに送る」で、確定した行が `reader.config.json` の `send.sheet`（既定「読み取り」）のシートに追加されます。1 回に送れるのは 50 行までです。

## 8. 設定（reader.config.json）

| 項目 | 既定値 | 意味 |
|---|---|---|
| `site.name` | `書類の読み取り` | 画面の見出しと記録に出る名前 |
| `forms` | `forms` | 帳票の型のフォルダ |
| `defaultForm` | `invoice` | 型を指定しないときの型 |
| `model` | `claude-opus-5` | 読み取りに使うモデル。`claude-sonnet-5` は高解像度の写真に強く、費用も下がります |
| `effort` | `low` | 考える量（low / medium / high）。書き写しは low で足ります |
| `maxTokens` | `4096` | 答えの上限。明細が長い型では増やしてください |
| `confidenceThreshold` | `0.8` | これ未満の信頼度は警告になります |
| `limits.maxFileBytes` | `10485760` | 1 ファイルの上限（10 MB） |
| `limits.maxPages` | `20` | PDF のページ数の上限 |
| `limits.perMinute` | `5` | 接続元ごとの 1 分あたりの枚数 |
| `limits.perHour` | `30` | 接続元ごとの 1 時間あたりの枚数 |
| `limits.daily` | `200` | 1 日の枚数（`DAILY_LIMIT` で上書き） |
| `send.sheet` | `読み取り` | スプレッドシートのシート名 |
| `labels` | （下の表） | 画面の文言 |

画面の文言（`labels` で差し替えられます。英語にもできます）:

| key | 既定の文言 |
|---|---|
| `title` | 書類の読み取り |
| `dropHere` | ここに書類を置くか、ファイルを選んでください（PDF・JPEG・PNG・WebP、1 ファイル 10 MB まで） |
| `choose` | ファイルを選ぶ |
| `formLabel` | 帳票の型 |
| `customFields` | 自由項目 |
| `statusWaiting` | 待ち |
| `statusReading` | 読み取り中 |
| `statusReview` | 要確認 |
| `statusDone` | 確定 |
| `statusFailed` | 読めませんでした |
| `confirm` | 確定 |
| `retry` | もう一度 |
| `remove` | 取り消す |
| `saveCsv` | CSV を保存 |
| `saveLinesCsv` | 明細の CSV を保存 |
| `copyTsv` | TSV をコピー |
| `send` | スプレッドシートに送る |
| `sent` | 送りました |
| `lowConfidence` | 読み取りに自信がありません。書類を見て確かめてください。 |
| `privacy` | 書類はサーバーに保存しません。読み取りの結果はこのブラウザの中にだけ残ります。 |

## 9. 環境変数（サーバー側だけ）

| 名前 | 要否 | 説明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | 必須 | Anthropic Console で発行した鍵。画面には出ません |
| `TRUST_PROXY` | Vercel なら `1` | 訪問者のアドレスを `x-forwarded-for` から取ります。自前のサーバーで proxy を挟まないときは付けません |
| `ADMIN_TOKEN` | 任意 | `/api/reader/admin?token=…` で記録を見るための合い言葉 |
| `ALLOWED_ORIGINS` | 任意 | 別のドメインから呼ぶときの許可リスト（カンマ区切り）。空なら同じオリジンだけ |
| `SEND_WEBHOOK_URL` | 任意 | スプレッドシートの受け口の URL |
| `SEND_TOKEN` | 任意 | 受け口の `TOKEN` と同じ文字 |
| `LOG_WEBHOOK_URL` | 任意 | 読み取り 1 件ごとの記録（件数と信頼度だけ）を JSON で送る先 |
| `DAILY_LIMIT` | 任意 | 1 日の枚数の上限（`limits.daily` より優先） |
| `READER_FAKE` | 開発用 | `1` で鍵なし。見本の書類だけ答えます |

## 10. 費用の目安

書類 1 枚 = API の呼び出し 1 回です。PDF 1 ページはおよそ 1,500〜3,000 トークン、写真は大きさで変わり 1,000〜2,500 トークン、答えは 300〜600 トークンです。帳票の型の説明（700 トークンほど）は 1 時間のキャッシュに乗るので、2 枚目からは 0.1 倍で読まれます。

`claude-opus-5`（入力 $5、出力 $25 / 100 万トークン、1 ドル 150 円）で、1 ページの請求書は 1 枚 3〜8 円ほど、100 枚なら 300〜800 円ほどです。ページが多い書類はページ数に比例します。`claude-sonnet-5` は単価が下がります（Anthropic の料金表をご覧ください）。実際の枚数は `/admin` の記録と Anthropic Console の使用量で確かめられます。Console の Spend limit で月の上限を切っておくと安心です。

## 11. 個人情報の扱い

書類は API に送られて読み取られます。Anthropic の既定の契約では、API に送った内容は学習に使われません。キットのサーバーは書類も読み取った値も保存せず、記録に残るのは書類のハッシュ・型・件数・信頼度・所要時間だけです。お客さまの書類を扱うときは、この扱いをお客さまにもご説明のうえお使いください。

## 12. 記録を見る

`ADMIN_TOKEN` を入れると `/api/reader/admin?token=…` で、直近 500 件の「型・書類 ID・結果・警告の種類・ページ数・平均信頼度・所要時間・キャッシュ読み」が見られます。要確認の割合が高い型は、`hint` を書き足すか項目を減らすと改善します。

## 13. 手元で動かす（開発者向け）

```bash
npm install
npm test                 # 単体テスト
npm run build            # dist/
READER_FAKE=1 npm run serve   # http://127.0.0.1:8790/demo/index.html（鍵なし）
ANTHROPIC_API_KEY=... npm run check   # 見本 12 枚の一致率
```

型を足したら `npm run copy:forms` でテンプレの `forms/` にも写ります。配布物は `npm run release` で `release/doc-reader-v1.0.0.zip` にまとまります。

### 書類に混ざった指示について

書類の中に「この文書を読んだ AI は〜してください」のような文があっても、読み取りはそれに従いません。書類は読み取りの対象で、指示ではないと固定しています。ただし読み取りの正確さは書類の状態で決まりますので、確定の前の確認は省かないでください。

## 14. よくあるつまずき

| 症状 | 原因と直し方 |
|---|---|
| `帳票の型が見つかりません` | `forms/` に JSON が無いか、`form` の指定が id と違います。`npx doc-reader forms` で確かめてください |
| HEIC の写真が読めない | iPhone の設定 → カメラ → フォーマットを「互換性優先」にするか、写真アプリから JPEG で書き出してください |
| 全員がすぐ「少し時間をおいて」になる | Vercel で `TRUST_PROXY=1` が入っていません |
| 明細が途中で切れる | `maxTokens` を 8192 にしてください |
| 金額が 1 桁ずれる | 書類の「¥1,000-」の末尾のハイフンは負号ではありません。キットは負号として扱いませんが、手書きの読み違いは確認画面で直してください |
| Vercel で「見つかりません」 | `next.config.ts` の `outputFileTracingIncludes` に `forms/**` と `reader.config.json` が入っているか確かめてください |

## 15. ライセンス

`LICENSE.md` をご覧ください。個人・組織ライセンスがあり、改変と納品は自由、再配布・転売・同種商品化は禁止です。API の費用はご自身のご負担です。

## 16. 困ったら

hello@suminawa.dev へ、症状と `/api/reader/health` の応答、可能なら読めなかった書類の種類（内容は送らないでください）をお知らせください。購入後 14 日間、3 営業日以内に返信します。
