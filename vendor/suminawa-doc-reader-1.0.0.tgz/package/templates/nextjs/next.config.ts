import type { NextConfig } from "next";

const config: NextConfig = {
  serverExternalPackages: ["@anthropic-ai/sdk"],
  // Route Handler は reader.config.json と forms/ を「実行時」に読む。自動追跡が見つけられないので明示する
  outputFileTracingIncludes: {
    "/*": ["./reader.config.json", "./forms/**/*"],
  },
};

export default config;
