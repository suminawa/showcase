"use client";

import { statusLabel, type DocItem, type ReaderLabels } from "@suminawa/doc-reader/ui";

interface Props {
  items: DocItem[];
  selected: string | null;
  labels: ReaderLabels;
  onSelect: (id: string) => void;
  onRetry: (id: string) => void;
  onRemove: (id: string) => void;
}

export function DocumentList({ items, selected, labels, onSelect, onRetry, onRemove }: Props) {
  if (items.length === 0) return <div className="dr-list"><p className="dr-muted" style={{ padding: 12 }}>まだ書類がありません。</p></div>;
  return (
    <div className="dr-list">
      {items.map((item) => (
        // 行そのものは div。中の「選ぶ」「再試行」「取り消す」はそれぞれ独立した button にする
        // （button の中に button や a を入れられないため。キーボードでも順に辿れる）
        <div key={item.id} className={`dr-item${item.id === selected ? " selected" : ""}`}>
          <button type="button" className="dr-item-main" onClick={() => onSelect(item.id)}>
            <span className="name" title={item.fileName}>{item.fileName}{item.sent ? " ✓" : ""}</span>
            <span className={`dr-badge ${item.status}`}>{statusLabel(item.status, labels)}</span>
          </button>
          {item.status === "failed" && (
            <p className="dr-warning">
              {item.error}{" "}
              <button type="button" className="dr-link" onClick={() => onRetry(item.id)}>{labels.retry}</button>
              {" / "}
              <button type="button" className="dr-link" onClick={() => onRemove(item.id)}>{labels.remove}</button>
            </p>
          )}
        </div>
      ))}
    </div>
  );
}
