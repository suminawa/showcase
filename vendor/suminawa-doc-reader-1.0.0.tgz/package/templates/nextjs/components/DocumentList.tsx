"use client";

import { statusLabel, type DocItem, type ReaderLabels } from "@suminawa/doc-reader/ui";

interface Props {
  items: DocItem[];
  selected: string | null;
  labels: ReaderLabels;
  onSelect: (id: string) => void;
  onRetry: (id: string) => void;
  onRemove: (id: string) => void;
}

export function DocumentList({ items, selected, labels, onSelect, onRetry, onRemove }: Props) {
  if (items.length === 0) return <div className="dr-list"><p className="dr-muted" style={{ padding: 12 }}>まだ書類がありません。</p></div>;
  return (
    <div className="dr-list">
      {items.map((item) => (
        <button key={item.id} type="button" className={`dr-item${item.id === selected ? " selected" : ""}`} onClick={() => onSelect(item.id)}>
          <span className="name" title={item.fileName}>{item.fileName}{item.sent ? " ✓" : ""}</span>
          <span className={`dr-badge ${item.status}`}>{statusLabel(item.status, labels)}</span>
          {item.status === "failed" && (
            <span className="dr-warning" style={{ gridColumn: "1 / -1" }}>
              {item.error}{" "}
              <a onClick={(e) => { e.stopPropagation(); onRetry(item.id); }} role="button">{labels.retry}</a>{" / "}
              <a onClick={(e) => { e.stopPropagation(); onRemove(item.id); }} role="button">{labels.remove}</a>
            </span>
          )}
        </button>
      ))}
    </div>
  );
}
