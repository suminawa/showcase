"use client";

import type { Dispatch } from "react";
import type { DocItem, FormSummary, ReaderLabels, ScalarValue, UiAction } from "@suminawa/doc-reader/ui";

interface Props {
  item: DocItem;
  form: FormSummary;
  labels: ReaderLabels;
  previewUrl: string | null;
  dispatch: Dispatch<UiAction>;
}

const THRESHOLD = 0.8;

function parse(type: string, text: string): ScalarValue {
  if (text.trim() === "") return null;
  if (type === "number" || type === "money") {
    const n = Number(text.replace(/[,，¥￥円\s]/g, ""));
    return Number.isFinite(n) ? n : text;
  }
  if (type === "boolean") return text === "はい";
  return text;
}

const show = (value: ScalarValue): string => (value === null ? "" : typeof value === "boolean" ? (value ? "はい" : "いいえ") : String(value));

export function FieldEditor({ item, form, labels, previewUrl, dispatch }: Props) {
  const result = item.result!;
  const isPdf = item.fileName.toLowerCase().endsWith(".pdf");
  const warned = new Set(result.warnings.map((w) => w.key));
  return (
    <section className="dr-editor">
      <h2>{item.fileName}</h2>
      {previewUrl !== null && (
        <div className="dr-preview">{isPdf ? <iframe src={previewUrl} title={item.fileName} style={{ width: "100%", height: "100%", border: 0 }} /> : <img src={previewUrl} alt="" />}</div>
      )}
      {result.warnings.map((w, i) => (
        <p key={i} className="dr-warning">{w.message}</p>
      ))}
      {form.fields.filter((f) => f.type !== "table").map((field) => {
        const r = result.fields[field.key];
        const low = r !== undefined && (r.confidence < THRESHOLD || warned.has(field.key));
        return (
          <div key={field.key} className={`dr-field${low ? " warn" : ""}`}>
            <label htmlFor={`f-${field.key}`}>{field.label}{field.required ? " *" : ""}</label>
            {field.type === "boolean" ? (
              <select id={`f-${field.key}`} value={show(r?.value ?? null)} onChange={(e) => dispatch({ type: "edit", id: item.id, key: field.key, value: e.target.value === "" ? null : e.target.value === "はい" })}>
                <option value=""></option><option value="はい">はい</option><option value="いいえ">いいえ</option>
              </select>
            ) : field.type === "enum" ? (
              <select id={`f-${field.key}`} value={show(r?.value ?? null)} onChange={(e) => dispatch({ type: "edit", id: item.id, key: field.key, value: e.target.value === "" ? null : e.target.value })}>
                <option value=""></option>{(field.options ?? []).map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            ) : (
              <input id={`f-${field.key}`} value={show(r?.value ?? null)} onChange={(e) => dispatch({ type: "edit", id: item.id, key: field.key, value: parse(field.type, e.target.value) })} />
            )}
            <span className="dr-muted" title={r?.evidence ?? ""}>{r === undefined ? "" : `${Math.round(r.confidence * 100)}%`}</span>
          </div>
        );
      })}
      {form.fields.filter((f) => f.type === "table").map((field) => {
        const columns = field.columns ?? [];
        const rows = result.tables[field.key]?.rows ?? [];
        return (
          <div key={field.key}>
            <h3 style={{ fontSize: "0.95rem", margin: "16px 0 4px" }}>{field.label}</h3>
            <table className="dr-table">
              <thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}<th></th></tr></thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i}>
                    {columns.map((c) => (
                      <td key={c.key}><input value={show(row[c.key] ?? null)} onChange={(e) => dispatch({ type: "editCell", id: item.id, table: field.key, row: i, column: c.key, value: parse(c.type, e.target.value) })} /></td>
                    ))}
                    <td><button className="dr-btn" type="button" onClick={() => dispatch({ type: "removeRow", id: item.id, table: field.key, row: i })}>×</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button className="dr-btn" type="button" onClick={() => dispatch({ type: "addRow", id: item.id, table: field.key, columns: columns.map((c) => c.key) })}>行を足す</button>
          </div>
        );
      })}
      <div className="dr-actions">
        <button className="dr-btn primary" type="button" onClick={() => dispatch({ type: "confirm", id: item.id })}>{labels.confirm}</button>
        <button className="dr-btn" type="button" onClick={() => dispatch({ type: "remove", id: item.id })}>{labels.remove}</button>
      </div>
    </section>
  );
}
