"use client";

import { useEffect, useReducer, useRef, useState } from "react";
import { confirmedResults, initialState, nextWaiting, readingCount, reducer, toTsv, unsentConfirmed, type FormSummary } from "@suminawa/doc-reader/ui";
import { downloadCsv, extract, fetchConfig, fetchForms, send, type UiConfig } from "@/lib/api";
import { DocumentList } from "./DocumentList";
import { FieldEditor } from "./FieldEditor";

const CONCURRENCY = 2;

export function ReaderApp() {
  const [config, setConfig] = useState<UiConfig | null>(null);
  const [forms, setForms] = useState<FormSummary[]>([]);
  const [state, dispatch] = useReducer(reducer, initialState("invoice"));
  const files = useRef(new Map<string, File>());
  const urls = useRef(new Map<string, string>());
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        const [c, f] = await Promise.all([fetchConfig(), fetchForms()]);
        setConfig(c);
        setForms(f);
        dispatch({ type: "setForm", form: c.defaultForm });
      } catch {
        dispatch({ type: "message", text: "設定を読み込めませんでした。ページを読み直してください。" });
      }
    })();
  }, []);

  // 待ちの書類を、同時 2 件まで順に読む
  useEffect(() => {
    if (readingCount(state) >= CONCURRENCY) return;
    const item = nextWaiting(state);
    if (item === undefined) return;
    const file = files.current.get(item.id);
    if (file === undefined) return;
    dispatch({ type: "start", id: item.id });
    void extract(file, state.form).then((result) => {
      if (result.ok) dispatch({ type: "succeed", id: item.id, result });
      else dispatch({ type: "fail", id: item.id, message: result.message });
    });
  }, [state]);

  const addFiles = (list: FileList | File[]) => {
    const items: Array<{ id: string; fileName: string }> = [];
    for (const file of Array.from(list)) {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      files.current.set(id, file);
      urls.current.set(id, URL.createObjectURL(file));
      items.push({ id, fileName: file.name });
    }
    dispatch({ type: "add", items });
  };

  const labels = config?.labels;
  const form = forms.find((f) => f.id === state.form) ?? null;
  const selected = state.items.find((i) => i.id === state.selected) ?? null;
  const confirmed = confirmedResults(state);
  const tables = form?.fields.filter((f) => f.type === "table") ?? [];

  const onSend = async () => {
    const targets = unsentConfirmed(state);
    if (targets.length === 0) return;
    setBusy(true);
    const reply = await send(state.form, targets.map((t) => t.result!));
    setBusy(false);
    if (reply.ok) {
      dispatch({ type: "sent", ids: targets.map((t) => t.id) });
      dispatch({ type: "message", text: `${labels?.sent ?? "送りました"}（${reply.appended ?? targets.length} 件）` });
    } else {
      dispatch({ type: "message", text: reply.message ?? "送れませんでした。" });
    }
  };

  const onCopy = async () => {
    if (form === null) return;
    await navigator.clipboard.writeText(toTsv({ ...form, checks: [], fields: form.fields.map((f) => ({ ...f, hint: null, pattern: null })) }, confirmed));
    dispatch({ type: "message", text: "コピーしました。表計算ソフトに貼り付けてください。" });
  };

  if (config === null || labels === undefined) return <main className="dr-app"><p className="dr-muted">読み込んでいます…</p></main>;

  return (
    <main className="dr-app">
      <header className="dr-head">
        <h1>{config.site.name} ── {labels.title}</h1>
        <p className="dr-muted">{labels.privacy}</p>
      </header>
      <div className="dr-row">
        <label>
          {labels.formLabel}{" "}
          <select value={state.form} onChange={(e) => dispatch({ type: "setForm", form: e.target.value })}>
            {forms.map((f) => (
              <option key={f.id} value={f.id}>{f.name}</option>
            ))}
          </select>
        </label>
      </div>
      <div
        className={`dr-drop${over ? " over" : ""}`}
        onDragEnter={(e) => { e.preventDefault(); setOver(true); }}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); addFiles(e.dataTransfer.files); }}
      >
        {labels.dropHere}{" "}
        <label>
          {labels.choose}
          <input type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.webp" onChange={(e) => { if (e.target.files) addFiles(e.target.files); e.target.value = ""; }} />
        </label>
      </div>
      {state.message !== null && (
        <div className="dr-message" role="status">
          {state.message} <button className="dr-btn" onClick={() => dispatch({ type: "message", text: null })}>閉じる</button>
        </div>
      )}
      <div className="dr-grid">
        <DocumentList items={state.items} selected={state.selected} labels={labels} onSelect={(id) => dispatch({ type: "select", id })} onRetry={(id) => dispatch({ type: "retry", id })} onRemove={(id) => dispatch({ type: "remove", id })} />
        <div>
          {selected !== null && selected.result !== null && form !== null ? (
            <FieldEditor item={selected} form={form} labels={labels} previewUrl={urls.current.get(selected.id) ?? null} dispatch={dispatch} />
          ) : (
            <p className="dr-muted">左の一覧から書類を選ぶと、ここに項目が出ます。</p>
          )}
          <div className="dr-actions">
            <button className="dr-btn primary" disabled={confirmed.length === 0} onClick={() => void downloadCsv(state.form, confirmed, null)}>{labels.saveCsv}（{confirmed.length}）</button>
            {tables.map((t) => (
              <button key={t.key} className="dr-btn" disabled={confirmed.length === 0} onClick={() => void downloadCsv(state.form, confirmed, t.key)}>{labels.saveLinesCsv}: {t.label}</button>
            ))}
            <button className="dr-btn" disabled={confirmed.length === 0} onClick={() => void onCopy()}>{labels.copyTsv}</button>
            {config.canSend && (
              <button className="dr-btn" disabled={busy || unsentConfirmed(state).length === 0} onClick={() => void onSend()}>{labels.send}（{unsentConfirmed(state).length}）</button>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
