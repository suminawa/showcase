import type { ExtractResult, Extraction, FormSummary, ReaderLabels } from "@suminawa/doc-reader/ui";

export const ENDPOINT = "/api/reader";

export interface UiConfig {
  site: { name: string };
  labels: ReaderLabels;
  defaultForm: string;
  limits: { maxFileBytes: number; maxPages: number };
  canSend: boolean;
}

export async function fetchConfig(): Promise<UiConfig> {
  const res = await fetch(`${ENDPOINT}/config`);
  if (!res.ok) throw new Error("config");
  const body = (await res.json()) as UiConfig & { ok: boolean };
  return body;
}

export async function fetchForms(): Promise<FormSummary[]> {
  const res = await fetch(`${ENDPOINT}/forms`);
  if (!res.ok) throw new Error("forms");
  return ((await res.json()) as { forms: FormSummary[] }).forms;
}

export const API_MESSAGES = {
  unavailable: "いまは読み取れません。しばらくしてからもう一度お試しください。",
  tooLarge: "ファイルが大きすぎて送れませんでした。写真アプリで小さく書き出してからお試しください。",
  failed: "読み取れませんでした。「再試行」でもう一度お試しください。",
} as const;

/**
 * 読み取りを頼む。通信が切れても、JSON でない応答（プラットフォームのエラー画面など）が返っても、
 * かならず Extraction の形で返す。投げないので、画面の書類が「読み取り中」のまま止まらない
 */
export async function extract(file: File, form: string): Promise<Extraction> {
  const body = new FormData();
  body.set("file", file);
  body.set("form", form);
  try {
    const res = await fetch(`${ENDPOINT}/extract`, { method: "POST", body });
    const parsed: unknown = await res.json().catch(() => null);
    if (parsed !== null && typeof parsed === "object" && "ok" in parsed) return parsed as Extraction;
    if (res.status === 413) return { ok: false, code: "too_large", message: API_MESSAGES.tooLarge };
    return { ok: false, code: "unavailable", message: API_MESSAGES.unavailable };
  } catch {
    return { ok: false, code: "unavailable", message: API_MESSAGES.unavailable };
  }
}

export async function downloadCsv(form: string, results: ExtractResult[], table: string | null): Promise<void> {
  const res = await fetch(`${ENDPOINT}/csv`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ form, results, table }) });
  if (!res.ok) throw new Error("csv");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = table === null ? `${form}.csv` : `${form}-${table}.csv`;
  // ブラウザによっては、文書に入っていない a の click では保存が始まらない。
  // URL を返すのも 1 秒だけ待つ（同じ拍で返すと、始まったばかりの保存が止まることがある）
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function send(form: string, results: ExtractResult[]): Promise<{ ok: boolean; appended?: number; message?: string }> {
  const res = await fetch(`${ENDPOINT}/send`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ form, results }) });
  return (await res.json()) as { ok: boolean; appended?: number; message?: string };
}
