import type { ExtractResult, Extraction, FormSummary, ReaderLabels } from "@suminawa/doc-reader/ui";

export const ENDPOINT = "/api/reader";

export interface UiConfig {
  site: { name: string };
  labels: ReaderLabels;
  defaultForm: string;
  limits: { maxFileBytes: number; maxPages: number };
  canSend: boolean;
}

export async function fetchConfig(): Promise<UiConfig> {
  const res = await fetch(`${ENDPOINT}/config`);
  if (!res.ok) throw new Error("config");
  const body = (await res.json()) as UiConfig & { ok: boolean };
  return body;
}

export async function fetchForms(): Promise<FormSummary[]> {
  const res = await fetch(`${ENDPOINT}/forms`);
  if (!res.ok) throw new Error("forms");
  return ((await res.json()) as { forms: FormSummary[] }).forms;
}

export async function extract(file: File, form: string): Promise<Extraction> {
  const body = new FormData();
  body.set("file", file);
  body.set("form", form);
  const res = await fetch(`${ENDPOINT}/extract`, { method: "POST", body });
  return (await res.json()) as Extraction;
}

export async function downloadCsv(form: string, results: ExtractResult[], table: string | null): Promise<void> {
  const res = await fetch(`${ENDPOINT}/csv`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ form, results, table }) });
  if (!res.ok) throw new Error("csv");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = table === null ? `${form}.csv` : `${form}-${table}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export async function send(form: string, results: ExtractResult[]): Promise<{ ok: boolean; appended?: number; message?: string }> {
  const res = await fetch(`${ENDPOINT}/send`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ form, results }) });
  return (await res.json()) as { ok: boolean; appended?: number; message?: string };
}
