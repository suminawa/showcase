# Next.js テンプレ（AI 書類読み取り）

このフォルダをそのまま Vercel に置けば、確認画面つきの書類の読み取りが動きます。

## 1. 用意するもの

- Node.js 22 以上
- Anthropic の API キー（Anthropic Console で発行）

## 2. 動かす

```bash
npm install
ANTHROPIC_API_KEY=sk-ant-... npm run dev
```

`http://localhost:3000` を開き、書類を置いてください。帳票の型は `forms/` の JSON で、5 種を同梱しています（`npm install` の時点で入っています）。`reader.config.json` で社名・既定の型・上限・文言を変えられます。

鍵を入れずに画面の動きだけ見るときは `READER_FAKE=1 npm run dev` です（すべての項目が空で返り、注記に案内が出ます）。見本の書類で中身のある答えを見るときは、配布 zip の `samples/` フォルダを `reader.config.json` の隣に写してから起動してください。

## 3. 環境変数

| 名前 | 要否 | 説明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | 必須 | Anthropic Console で発行した鍵 |
| `TRUST_PROXY` | **`1` にしてください** | Vercel は訪問者のアドレスを `x-forwarded-for` で渡します。`1` にしないと全員が 1 つの枠を分け合います |
| `ADMIN_TOKEN` | 任意 | `/api/reader/admin?token=…` で読み取りの記録（件数と信頼度だけ）を見るための合い言葉 |
| `SEND_WEBHOOK_URL` | 任意 | スプレッドシートの受け口（`gas/receiver.gs`）のウェブアプリ URL。入れると「スプレッドシートに送る」が出ます |
| `SEND_TOKEN` | 任意 | 受け口のスクリプトのプロパティ `TOKEN` と同じ文字 |
| `ALLOWED_ORIGINS` | 任意 | 別のドメインから呼ぶときだけ。カンマ区切り |
| `LOG_WEBHOOK_URL` | 任意 | 読み取り 1 件ごとの記録（件数と信頼度だけ）を送る先 |
| `DAILY_LIMIT` | 任意 | 1 日の受付上限（既定 200） |

## 4. Vercel に置く

1. このフォルダを Git リポジトリにして push します（`vendor/` の tgz と `forms/` も含めてください）。
2. Vercel で Import し、環境変数に `ANTHROPIC_API_KEY` と `TRUST_PROXY=1` を入れて Deploy します。
3. 公開 URL を開いて、見本の書類を 1 枚読ませてみてください。

Vercel の関数が受け取れる本文は 4.5 MB までです。それより大きい書類はこのキットに届く前に断られるため、`reader.config.json` の `limits.maxFileBytes` は 4 MB（`4194304`）にしてあります。10 MB の書類まで扱うときは、Node で自分のサーバーに置いてください。

## 5. 書類はどこに残りますか

サーバーには残りません。読み取りが終わると、結果はブラウザの中にだけあります。ページを閉じる前に「CSV を保存」か「スプレッドシートに送る」でお出しください。読み取りの記録として残るのは、書類のハッシュ・型・件数・信頼度・所要時間だけです。

## 6. 帳票の型を足す

`forms/` に JSON を 1 本足します。書き方はキットの `README.ja.md` の「帳票の型」をご覧ください。足したら再デプロイで反映されます。
