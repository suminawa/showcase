import type { ReactNode } from "react";
import "./globals.css";

export const metadata = {
  title: "書類の読み取り",
  description: "請求書・領収書・申込書を読み取り、確認してから CSV かスプレッドシートに出します。",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
