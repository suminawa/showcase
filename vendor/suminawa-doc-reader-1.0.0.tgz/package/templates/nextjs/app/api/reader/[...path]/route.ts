import { createReader, loadConfigFile, loadFakeAnswers, createFakeClient, loadForms, resolveConfig, type Reader } from "@suminawa/doc-reader";

// 書類を API に渡すのでサーバー側で動かす。1 枚の読み取りは数秒〜十数秒
export const runtime = "nodejs";
export const maxDuration = 60;
export const dynamic = "force-dynamic";

let ready: Promise<Reader> | null = null;

function reader(): Promise<Reader> {
  if (ready === null) {
    ready = (async () => {
      const config = resolveConfig({ file: await loadConfigFile("reader.config.json"), env: process.env });
      const forms = await loadForms(config.formsDir);
      // READER_FAKE=1 のときは鍵なし。samples/ を置いていればその見本だけ答える
      const client = config.fake ? createFakeClient(await loadFakeAnswers("samples")) : undefined;
      return createReader(config, { forms, client });
    })();
  }
  return ready;
}

export async function POST(request: Request): Promise<Response> {
  return (await reader()).fetch(request);
}

export async function GET(request: Request): Promise<Response> {
  return (await reader()).fetch(request);
}

export async function OPTIONS(request: Request): Promise<Response> {
  return (await reader()).fetch(request);
}
