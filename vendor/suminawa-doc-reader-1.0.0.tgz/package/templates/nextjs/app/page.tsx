import { ReaderApp } from "@/components/ReaderApp";

export default function Page() {
  return <ReaderApp />;
}
