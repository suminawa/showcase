/**
 * AI 書類読み取りキット ── スプレッドシートの受け口
 *
 * 置き方（README.ja.md の「7. スプレッドシートに送る」）:
 * 1. 送り先のスプレッドシートを開き、拡張機能 → Apps Script を開く
 * 2. このファイルの中身を Code.gs に貼り、保存する
 * 3. プロジェクトの設定 → スクリプト プロパティ に TOKEN を追加し、長いランダムな文字を入れる
 * 4. デプロイ → 新しいデプロイ → 種類「ウェブアプリ」、実行ユーザー「自分」、アクセス「全員」→ デプロイ
 * 5. 出てきたウェブアプリの URL を SEND_WEBHOOK_URL に、TOKEN の文字を SEND_TOKEN に入れる
 *
 * 受け取る JSON: { token, sheet, headers: [...], rows: [[...], ...] }（1 回 50 行まで）
 * 返す JSON:    { ok: true, appended: n } か { ok: false, message }
 */
function doPost(e) {
  var out = function (payload) {
    return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(ContentService.MimeType.JSON);
  };
  try {
    var body = JSON.parse(e.postData.contents);
    var token = PropertiesService.getScriptProperties().getProperty("TOKEN") || "";
    if (token === "" || body.token !== token) return out({ ok: false, message: "合い言葉が合いません。" });
    var rows = Array.isArray(body.rows) ? body.rows : [];
    var headers = Array.isArray(body.headers) ? body.headers : [];
    if (rows.length === 0 || rows.length > 50) return out({ ok: false, message: "行は 1〜50 件にしてください。" });
    var name = String(body.sheet || "読み取り").slice(0, 100);
    var book = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = book.getSheetByName(name) || book.insertSheet(name);
    var lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      if (sheet.getLastRow() === 0 && headers.length > 0) sheet.appendRow(headers);
      for (var i = 0; i < rows.length; i++) {
        sheet.appendRow(
          rows[i].map(function (value) {
            // 表計算ソフトが式として実行しないよう、= + - @ で始まる文字は文字列にする
            return typeof value === "string" && /^[=+\-@]/.test(value) ? "'" + value : value;
          })
        );
      }
    } finally {
      lock.releaseLock();
    }
    return out({ ok: true, appended: rows.length });
  } catch (error) {
    return out({ ok: false, message: "受け取れませんでした。" });
  }
}

function doGet() {
  return ContentService.createTextOutput("doc-reader receiver: ok");
}
