# 3D 商品コンフィギュレーター

商品ページに置ける、3D の商品コンフィギュレーターです。GLB の商品モデルを回して見せ、色・素材・パーツ・刻印・ロゴをお客さまに選んでいただき、価格をその場で表示します。選んだ内容は JSON・PNG・共有 URL で取り出せるので、注文フォームやお問い合わせにそのまま添えられます。

- 設定は JSON 1 つ。プログラムを書かずに、選択肢と価格を組めます
- 3D のモデルは glTF（.glb）。Blender などで書き出した自社商品をそのまま読み込みます
- ロゴの画像はお客さまのブラウザの中だけで扱い、サーバーには送りません
- 素の HTML（script 2 本）、npm、React / Next.js の 3 通りの置き方に対応

## 1. 動く見本

`page/index.html` が単体で動く見本です。フォルダで簡易サーバーを起動してからお開きください（ファイルを直接開くと、ブラウザの決まりで 3D のデータを読めません）。

```bash
npx serve page
```

見本の商品はステンレスタンブラー（`page/tumbler.glb`）で、設定は `page/tumbler.config.json` です。

## 2. 置き方

### 2-1. 素の HTML（いちばん簡単）

`embed/` の 6 つのファイル（`product-configurator.global.js` `product-configurator-3d.global.js` `product-configurator.css` と見本 3 つ）をサイトの同じフォルダに置き、次の断片を商品ページに貼ります。

```html
<link rel="stylesheet" href="./product-configurator.css">
<div id="configurator"></div>
<script src="./product-configurator.global.js"></script>
<script>
  ProductConfigurator.mount(document.getElementById("configurator"), {
    product: { name: "ステンレスタンブラー", sku: "TB-01" },
    model: { src: "./tumbler.glb" },
    scene: { src: "./product-configurator-3d.global.js" },
    price: { base: 3800, currency: "JPY", note: "税込" },
    groups: [ /* 3 章の設定 */ ]
  });
</script>
```

3D の部品（`product-configurator-3d.global.js`、およそ 1 MB）は `scene.src` に置き場所を書いておくと、ページを開いたあとに読み込みます。`<script defer src="./product-configurator-3d.global.js">` を先に書いておく置き方でも構いません。

設定を要素に書く置き方もできます。`<div id="configurator" data-config='{ … }'></div>` として `ProductConfigurator.mount(要素)` と呼ぶだけです。

### 2-2. npm（Vite など）

```bash
npm install ./suminawa-product-configurator-1.0.0.tgz
```

```ts
import { mount } from "@suminawa/product-configurator";
import "@suminawa/product-configurator/styles.css";

const handle = mount(document.getElementById("configurator")!, config);
```

3D の部品は最初に必要になったときに動的に読み込まれます（three.js は依存として一緒に入ります）。

### 2-3. React / Next.js

```tsx
"use client";
import { ProductConfigurator } from "@suminawa/product-configurator/react";
import "@suminawa/product-configurator/styles.css";

const CONFIG = { /* 3 章の設定 */ };

export function Tool() {
  return <ProductConfigurator config={CONFIG} onChange={(selection) => console.log(selection)} />;
}
```

`config` は定数か `useMemo` で渡してください。参照が変わると作り直され、選択が最初に戻ります。Next.js の App Router では `dynamic(() => import(...), { ssr: false })` で読み込むと、サーバー側で three.js を読まずに済みます。

## 3. 設定

すべての項目と既定値です。`product` `price` `groups` 以外は省けます。

| 項目 | 内容 | 既定値 |
| --- | --- | --- |
| `product.name` | 商品名。操作列の見出しと PNG のファイル名に使う | `"商品"` |
| `product.sku` | 品番。選択 JSON の `product` に入る | `""` |
| `model.src` | GLB の場所（相対パスか https）。省くと同梱の見本 `./tumbler.glb` | `null` |
| `model.scale` | 表示の大きさの倍率（0.01〜100） | `1` |
| `model.rotation` | 最初の向き（度。x, y, z） | `[0, 0, 0]` |
| `model.camera` | 視点。`distance`（距離）`elevation`（仰角）`azimuth`（方位。0 が正面） | `{ distance: 2.6, elevation: 18, azimuth: -35 }` |
| `scene.background` | 3D の背景色（#rrggbb） | `"#f4efe6"` |
| `scene.floor` | 床の色 | `"#e8e2d6"` |
| `scene.autoRotate` | 触るまで自動で回す | `false` |
| `scene.src` | 3D の部品の置き場所（素の HTML で、あとから読ませるとき） | `null` |
| `price.base` | 基本価格（整数） | `0` |
| `price.currency` | 通貨（ISO 4217。表示は `Intl` に従う） | `"JPY"` |
| `price.note` | 価格の注記（「税込」など） | `""` |
| `groups` | 選択肢の群（1〜20 個）。下の 3-1 | ── |
| `features.export` / `share` / `copy` | PNG・共有 URL・JSON コピーのボタンを出す | すべて `true` |
| `labels.*` | 画面の文言の上書き。項目は `DEFAULT_LABELS` | 日本語の既定 |
| `onChange(selection)` | 選択が変わるたびに呼ばれる（4 章の JSON） | ── |
| `onExport({ blob, name })` | 渡すと PNG はダウンロードされず、ここへ来る | ── |

### 3-1. 群（groups）

群は 5 種類です。`id`（半角の一意な名前）と `label`（画面の見出し）と `type` は必ず入れます。

| type | 何を変えるか | 固有の項目 |
| --- | --- | --- |
| `color` | 対象メッシュの色。粗さ・金属感も変えられる | `target`（メッシュ名の一覧）`required` `default` `options[]`: `{ id, label, color, roughness?, metalness?, price? }` |
| `material` | 対象メッシュの材質（色・粗さ・金属感の組） | `target` `required` `default` `options[]`: `{ id, label, color, roughness, metalness, price? }` |
| `variant` | パーツの表示。選んだ選択肢の `show` を出し `hide` を隠す | `required` `default` `options[]`: `{ id, label, show?, hide?, price? }` |
| `text` | 刻印。対象メッシュに文字を描いたラベルを貼る | `target` `maxChars`（1〜40、既定 12）`pattern`（許す文字の正規表現）`placeholder` `font` `color` `background` `hideWhenEmpty` `price` |
| `image` | ロゴ。対象メッシュに画像を貼る | `target` `maxBytes`（既定 2,000,000）`background` `hideWhenEmpty` `price` |

- `required` が `true` の群は必ずどれかが選ばれます（`default` を省くと先頭）。`false` なら「なし」を選べます。
- `price` は基本価格への差額（整数。負の値も可）。刻印は文字があるとき、ロゴは画像を入れたときだけ足します。
- `variant` の `show` に出てくるメッシュは、選ばれた選択肢が見せるときだけ表示されます。
- 刻印とロゴが同じ `target` を持つときは 1 枚のラベルにまとめて描きます（ロゴが上、文字が下）。

### 3-2. 見本の設定

`samples/tumbler.config.json`（全部入り）と `samples/tumbler-simple.config.json`（色と容量だけ）をご覧ください。

## 4. 選んだ内容の取り出し

### 4-1. 選択 JSON

`onChange`・「選択内容をコピー」・取っ手の `getSelection()` は、同じ形の JSON を返します。

```json
{
  "product": "TB-01",
  "selection": { "body": "navy", "lid": "steel", "size": "500", "strap": null, "engrave": "MINATO", "logo": { "name": "logo.png", "type": "image/png", "size": 12345 } },
  "price": { "base": 3800, "delta": 900, "total": 4700, "currency": "JPY" },
  "at": "2026-10-02T09:00:00.000Z"
}
```

ロゴは名前・種類・大きさだけで、画像そのものは含みません（ブラウザの外に出さないため）。注文で画像が必要なときは、フォームのファイル欄で別途お受け取りください。

### 4-2. PNG

「PNG で保存」でいま見えている 3D を横 1600 px の PNG にします。`onExport` を渡すとダウンロードせずに `{ blob, name }` を受け取れます。

### 4-3. 共有 URL

「共有 URL をコピー」で、いまのページの URL に `#pc=…` を付けたものをコピーします。開くと同じ選択で始まります（ロゴは含みません）。

## 5. 取っ手（JavaScript から動かす）

`mount()` の戻り値と、React の `handleRef` に届くものは同じです。

| 呼び方 | 内容 |
| --- | --- |
| `getSelection()` | 4-1 の JSON |
| `setSelection({ body: "black", size: "500" })` | 選択を変える（知らない id は無視） |
| `getPrice()` | `{ base, delta, total, currency }` |
| `reset()` | 最初の選択に戻す |
| `exportPng()` | PNG を作る（`Promise<{ blob, name } | null>`） |
| `shareUrl()` | 共有 URL の文字列 |
| `subscribe(listener)` | 変更のたびに呼ぶ。戻り値で解除 |
| `destroy()` | 消す（`mount()` の戻り値だけ） |

## 6. 3D モデルの用意

- 形式は glTF バイナリ（`.glb`）。DRACO などの圧縮は使わず、そのまま書き出してください。テクスチャは中に埋め込めます。
- 設定で触るパーツには、Blender のオブジェクト名で名前を付けてください（例: `body` `lid`）。設定の `target` `show` `hide` はこの名前で結びつきます。設定にあってモデルに無い名前は、画面の左上に小さく表示して知らせます（止まりません）。
- 刻印・ロゴを貼るパーツは、UV を持つ面にしてください（ラベル 1 枚は 2:1 の画像です）。
- 大きさは自動で合わせます（いちばん長い辺を 1 として床に置く）。`model.scale` と `model.rotation` で調整できます。
- 色を変えるパーツの材質は、Principled BSDF（金属感・粗さ）で書き出してください。
- 1 つのパーツには 1 つの材質を割り当ててください。1 つのオブジェクトに複数の材質スロットがあると、書き出しでパーツが `名前_0` `名前_1` のように分かれます（設定の `target` には元の名前を書けば、その両方に当たります）。

## 7. 見た目の調整

CSS 変数 `--pc-bg` `--pc-fg` `--pc-muted` `--pc-brand` `--pc-on-brand` `--pc-line` `--pc-surface` `--pc-radius` `--pc-font` を `.pc` かその祖先に書くと色と間隔が変わります。3D の背景と床の色は設定の `scene` で渡します。

## 8. よくある質問

- **3D が出ず「3D の部品が見つかりません」と出る** ── `product-configurator-3d.global.js` の置き場所が `scene.src` と合っていません。1 本目より先に読ませていないかもご確認ください。
- **色が変わらないパーツがある** ── メッシュ名が設定と違います。画面左上の「モデルに無い名前」をご覧ください。
- **刻印が裏返って見える** ── ラベルを貼る面の UV が左右逆です。Blender で UV を水平に反転してください。
- **スマホで重い** ── モデルの頂点数を減らすか、テクスチャを 1024 px 以下にしてください。3D の部品はおよそ 1 MB です。
- **WebGL の無い環境** ── 3D の枠に断りを出し、操作列と価格はそのまま使えます。

## 9. 手元で動かす

```bash
npm install
npm test
npm run build
npm run samples
npm run release
```

`release/product-configurator-v1.0.0.zip` ができます。

## 10. ライセンス

`LICENSE.md` をご覧ください。改変は自由で、クライアントのサイトへの組み込み納品もできます。再配布・転売はできません。

## 11. 困ったら

hello@suminawa.dev までご連絡ください。3 営業日以内にお返事します。
