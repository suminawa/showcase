# AI 案内窓口キット v1.0.0

自社の文書だけを根拠に、サイトを訪れた方のご質問へお答えする「案内窓口」です。会社案内・料金・よくあるご質問などを読み込ませると、窓口が敬体でお答えし、根拠になったページへのリンクを添えます。資料に無いことは「載っていません」とお伝えして、問い合わせフォームへご案内します。

## 1. 何ができるか

- **自社の文書の範囲で答えます**: 会社案内・料金・FAQ・施工事例などを読み込ませます。推測では答えません
- **根拠を示します**: 答えの下に、参照した文書の題名とリンクが最大 3 つ並びます
- **流れながら表示します**: 答えは書かれるそばから出ます（SSE）
- **窓は 2 通り**: 右下のボタンから開く形と、ページの中に埋め込む形
- **未回答が残ります**: お答えできなかったご質問は `/admin` にたまります。資料を足す目安になります
- **費用を抑えます**: 同じ文書を毎回送る形でも、2 回目以降はキャッシュから読まれます
- **依存はひとつ**: サーバー部品が使うのは `@anthropic-ai/sdk` だけです

**作っていないもの**: 会話の長期記憶、ユーザー登録、決済連携、音声、多言語の UI（文言は差し替えられます）、埋め込みベクトル検索。

## 2. 置き方は 3 通り

| | 向いている方 | 手順 |
|---|---|---|
| (1) Vercel に Deploy | サーバーをお持ちでない方 | `templates/nextjs/` をそのまま置きます |
| (2) いまの Next.js に足す | すでにサイトが Next.js の方 | `createConcierge` を Route Handler から呼びます |
| (3) Node のサーバー | 自前のサーバーがある方 | `node dist/adapters/node.js` |

(1) のテンプレは、キット本体を `templates/nextjs/vendor/` に tgz として同梱しています。`npm install` はこの tgz から `@suminawa/ai-concierge` を取り込みます（配布 zip にはあらかじめ tgz が入っているので、そのままお使いいただけます）。(3) の Node サーバーは `demo/` と `dist/` だけを配ります。`data/` や `concierge.config.json` などはブラウザから見えません。

どの置き方でも、サイト側に貼るのは次の 2 行だけです。

```html
<link rel="stylesheet" href="/ai-concierge.css">
<script src="/ai-concierge.js" data-endpoint="/api/concierge"></script>
```

## 3. 文書を用意する

`content/` に Markdown を置きます。1 ファイル 1 テーマにすると、根拠が示しやすくなります。

```
content/
  about.md     会社概要
  price.md     料金
  faq.md       よくあるご質問
```

- 先頭の `# 見出し` が文書の題名になります。
- `##` 以下の見出しで区切って、600〜1,200 字くらいの「片」に分けます。
- 元になる公開ページがあるときは、先頭に次を書くと「根拠」がそのページへ向きます。

```markdown
---
url: https://example.com/price
updatedAt: 2026-09-01
---
```

すでに公開しているページを取り込むこともできます。`concierge.config.json` の `urls` に並べると、索引づくりのときに本文を抜き出します（`<main>` → `<article>` → `<body>` の順に探し、メニューやフッターは除きます）。

見本は `samples/content/` に 8 本あります。書き方の見本としてお使いください。

## 4. 索引を作る

```bash
npx ai-concierge index
```

`data/index.json` ができます。**このファイルはリポジトリにコミットしてください**（Vercel 上では作れません）。

```bash
npx ai-concierge index --check          # 書かずに、何本・何片になるかだけ見ます
npx ai-concierge index --count-tokens   # 正確なトークン数を数えます（API キーが必要です）
npx ai-concierge index --out public/index.json
```

文書を書き換えたら、もう一度このコマンドを実行してください。

## 5. 窓を貼る

`<script>` の属性だけで設定できます。

```html
<script
  src="/ai-concierge.js"
  data-endpoint="/api/concierge"
  data-greeting="こんにちは。ご質問にお答えします。"
  data-suggestions="対応エリアはどこまでですか|見積もりは無料ですか"
  data-contact-url="/contact"
></script>
```

ページの中に置きたいときは、置きたい場所に `<div id="ai-window"></div>` を作り、`data-inline="#ai-window"` を足します。

JavaScript から開きたいときは次のようにします。

```html
<script src="/ai-concierge.js"></script>
<script>
  const concierge = AIConcierge.mount({
    endpoint: "/api/concierge",
    greeting: "こんにちは。ご質問にお答えします。",
    suggestions: ["対応エリアはどこまでですか"],
    contactUrl: "/contact",
  });
  document.querySelector("#ask").addEventListener("click", () => concierge.open());
</script>
```

## 6. 設定（concierge.config.json）

```json
{
  "site": { "name": "◯◯工務店", "url": "https://example.com" },
  "urls": ["https://example.com/price"],
  "content": "content",
  "alwaysInclude": ["会社概要", "料金"],
  "greeting": "こんにちは。◯◯工務店の案内窓口です。",
  "suggestions": ["対応エリアはどこまでですか", "見積もりは無料ですか"],
  "contactUrl": "https://example.com/contact",
  "labels": {},
  "answer": { "model": "claude-opus-5", "effort": "low", "maxTokens": 1024, "style": "敬体。300 字以内。" },
  "retrieval": { "wholeCorpusMaxTokens": 60000, "topK": 8 },
  "limits": { "maxInputChars": 400, "perMinute": 10, "perHour": 60, "dailyQuestions": 500 }
}
```

| 項目 | 既定 | 説明 |
|---|---|---|
| `site.name` | （必須） | 窓口の名乗りに使います |
| `alwaysInclude` | `[]` | 題名がここに挙げた語を含む文書は、検索に関わらず毎回送ります |
| `answer.model` | `claude-opus-5` | `claude-sonnet-5` / `claude-haiku-4-5` に変えられます |
| `answer.effort` | `low` | `low` / `medium` / `high`。`claude-haiku-4-5` では送りません |
| `answer.maxTokens` | `1024` | 1 回の答えの上限 |
| `retrieval.wholeCorpusMaxTokens` | `60000` | この数までは全文を送ります。超えると BM25 に切り替わります |
| `retrieval.topK` | `8` | BM25 のときに送る片の数 |
| `limits.maxInputChars` | `400` | ご質問の字数の上限 |
| `limits.perMinute` / `perHour` | `10` / `60` | IP ごとの回数の上限 |
| `limits.dailyQuestions` | `500` | 1 日の受付の上限 |

窓の文言は `labels` で差し替えられます（英語にもできます）。

| 鍵 | 既定の文言 |
|---|---|
| `windowTitle` | 案内窓口 |
| `open` | 質問する |
| `close` | 閉じる |
| `placeholder` | 質問を入力してください |
| `send` | 送信 |
| `thinking` | 調べています… |
| `sources` | 根拠 |
| `contact` | 担当者に問い合わせる |
| `reset` | 最初から |
| `unavailable` | いまはお答えできません。お手数ですが問い合わせフォームからご連絡ください。 |
| `tooLong` | 質問は 400 字以内でお願いします。 |
| `rateLimited` | 少し時間をおいてからお試しください。 |
| `offline` | 通信できませんでした。少し時間をおいてからお試しください。 |
| `emptyQuestion` | ご質問を入力してください。 |

色や角の丸みは CSS の変数で変えられます。

```css
:root {
  --ac-brand: #14532d;      /* ボタンと吹き出しの色 */
  --ac-brand-fg: #ffffff;   /* その上の文字 */
  --ac-bg: #ffffff;
  --ac-fg: #1b1b1b;
  --ac-muted: #666666;
  --ac-border: #e2e2e2;
  --ac-radius: 12px;
  --ac-font: system-ui, sans-serif;
  --ac-shadow: 0 12px 40px rgb(0 0 0 / 18%);
  --ac-z: 2147483000;
}
```

## 7. 環境変数（サーバー側だけ）

| 名前 | 要否 | 説明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | 必須 | Anthropic Console で発行した鍵。**窓には出ません** |
| `ALLOWED_ORIGINS` | 任意 | 窓を置くサイトの URL をカンマ区切りで。未設定のときは、同じオリジンからのアクセスだけを受け付けます |
| `ADMIN_TOKEN` | 任意 | `/admin` を見るための合い言葉。未設定なら `/admin` は出ません |
| `LOG_WEBHOOK_URL` | 任意 | ご質問を 1 件ずつ送る先 |
| `LOG_WEBHOOK_FORMAT` | 任意 | `json`（既定）または `slack` |
| `CONCIERGE_INDEX` | 任意 | `index.json` の場所（既定 `data/index.json`） |
| `DAILY_QUESTION_LIMIT` | 任意 | 1 日の受付の上限 |
| `MAX_INPUT_CHARS` | 任意 | ご質問の字数の上限 |

`ALLOWED_ORIGINS` は「許可するオリジンの一覧」であって、「制限を外す」設定ではありません。自分のサイト（同じオリジン）からの利用だけであれば設定は不要ですが、**別のドメインに窓を埋め込むときは、そのサイトの URL を必ず `ALLOWED_ORIGINS` に入れてください**。入れていないと、別オリジンからの `/chat` 呼び出しは断られます。TLS を終端する自前の proxy（nginx など）の後ろで `node dist/adapters/node.js` を動かす場合は、`x-forwarded-proto` ヘッダーを見て自分の URL を組み立てます。

環境変数のほかにも、次の制限は設定に関わらず常に効いています。

- ご質問 1 回の送信は 64 KB まで。超えると 413 でお断りします
- Webhook の送信は 5 秒でタイムアウトします。送信先が応答しなくても、ご質問への回答自体は止まりません

## 8. 費用の目安

API の費用はお客さまのご負担です（鍵はお客さまのものです）。文書が 30,000 トークン、ご質問 100 トークン、答え 300 トークンのときの目安です。

| モデル | 初回 | 2 回目以降（キャッシュあり） |
|---|---|---|
| `claude-opus-5` | 約 $0.16 | 約 $0.02 |
| `claude-sonnet-5` | 約 $0.06 | 約 $0.008 |

同じ文書を続けて送るあいだはキャッシュが効きます。1 日 100 件のご質問で、`claude-opus-5` なら月 9,000 円ほどが目安です。厳密な上限は Anthropic Console の月額上限でお決めください。

## 9. お答えできなかったご質問を見る

`ADMIN_TOKEN` を入れると、次の画面が使えます。

- `/api/concierge/admin?token=＜合い言葉＞` — 記録の一覧（`&unanswered=1` で未回答だけ）
- `/api/concierge/admin/export?token=＜合い言葉＞` — CSV で書き出し

記録に残るのは、ご質問・答えの先頭 200 字・出典の番号・答えられたか・所要時間・モデル・トークン数です。IP と User-Agent は残しません。メールアドレスと電話番号らしい並びは伏せてから保存します。CSV に書き出すときは、`=` `+` `-` `@` で始まる値をそのまま書き出さず、表計算ソフトが数式として実行しないようにしてあります。

記録はサーバーのメモリに直近 500 件だけ残ります。Vercel のようにインスタンスが入れ替わる置き方では消えますので、残しておきたい場合は `LOG_WEBHOOK_URL` を設定してください。

## 10. 手元で動かす（開発者向け）

```bash
npm install
npm test          # 単体テスト
npm run typecheck
npm run build     # dist/ を作ります
npm run eval      # 見本の 30 問で recall を測ります
```

見本は文書が 8 本・片が 8 個しかないため、`recall@4` も参考の `recall@8`（上位 8 片＝索引の全部を見る数字）も 1.000 になります。片の数が少ない見本では取りこぼしが起きにくく、この 1.000 は検索の質を証明する数字ではありません。実際の文書数が増えてきたら、そのときの `recall@4` の下がり具合を目安にしてください。`--judge` を付けると答えが資料の範囲に収まっているか（根拠性）も採点できますが、`ANTHROPIC_API_KEY` が必要です（無いと実行を止めます）。

窓の動きを鍵なしで見るには、決まった答えを返す形で立ち上げます。

```bash
node dist/cli.js index --config samples/concierge.config.json --out data/index.json
CONCIERGE_FAKE=1 node dist/adapters/node.js
```

`http://127.0.0.1:8787/demo/index.html` を開いてください。

## 11. よくあるつまずき

| 症状 | 原因と直し方 |
|---|---|
| 窓は出るが答えが返らない | `ANTHROPIC_API_KEY` が入っていません。サーバー側の環境変数をご確認ください |
| 「このページからのご利用は受け付けておりません」 | `ALLOWED_ORIGINS` に、窓を置いたサイトの URL を足してください |
| `data/index.json が見つかりません` | `npx ai-concierge index` を実行し、できたファイルをコミットしてください |
| 根拠のリンクが出ない | 文書の front matter に `url:` を書いてください |
| 答えが「資料に載っていません」ばかり | 文書にその言葉が無いか、聞かれ方と書き方がずれています。`/admin` の未回答を見て、お客さまの言い方で書き足してください |
| 答えが長い | `answer.style` と `answer.maxTokens` を短くしてください |
| 文書が増えて答えが遅い・高い | `retrieval.wholeCorpusMaxTokens` を超えると BM25 に切り替わります。`alwaysInclude` に会社概要と料金を入れておくと取りこぼしが減ります |

## 12. ライセンス

`LICENSE.md` をご覧ください。改変と納品は自由、再配布と転売はできません。API の費用はお客さまのご負担です。

## 13. 困ったら

hello@suminawa.dev までご連絡ください。3 営業日以内にお返事します。
