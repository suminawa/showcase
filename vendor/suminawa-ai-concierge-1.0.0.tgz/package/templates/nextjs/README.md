# Next.js テンプレ（AI 案内窓口）

このフォルダをそのまま Vercel に置けば、案内窓口が動きます。

## 1. 文書を置く

`content/` を作り、自社の文書を Markdown で置きます（1 ファイル 1 テーマ）。

```
content/
  about.md     会社概要
  price.md     料金
  faq.md       よくあるご質問
```

先頭の `# 見出し` が文書の題名になります。元のページがあるときは、先頭に次を書くと窓の「根拠」がそのページへ向きます。

```markdown
---
url: https://example.com/price
---
```

## 2. 索引を作る

```bash
npm install
npm run index
```

`data/index.json` ができます。このファイルは**リポジトリにコミットしてください**（Vercel 上では作れません）。

キット本体は `vendor/suminawa-ai-concierge-1.0.0.tgz` として同梱してあり、`npm install` でそこから入ります（`package.json` の `@suminawa/ai-concierge` がこのファイルを指しています）。`vendor/` もリポジトリに含めてください。キットを新しい版に入れ替えるときは、この tgz を差し替えてから `npm install` をもう一度実行します。

## 3. 環境変数を入れる

| 名前 | 要否 | 説明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | 必須 | Anthropic Console で発行した鍵 |
| `ALLOWED_ORIGINS` | 任意 | 窓を置くサイトの URL をカンマ区切りで |
| `ADMIN_TOKEN` | 任意 | `/api/concierge/admin` を見るための合い言葉 |
| `LOG_WEBHOOK_URL` | 任意 | 質問を 1 件ずつ送る先 |
| `LOG_WEBHOOK_FORMAT` | 任意 | `json`（既定）または `slack` |
| `DAILY_QUESTION_LIMIT` | 任意 | 1 日の受付上限（既定 500） |
| `CONCIERGE_INDEX` | 任意 | 索引ファイルの場所（既定 `data/index.json`） |
| `MAX_INPUT_CHARS` | 任意 | 質問文の最大文字数（既定 400、10〜4000） |

## 4. 動かす

```bash
npm run dev
```

`http://localhost:3000` を開くと、右下に「質問する」が出ます。

`app/contact/page.tsx` は「お問い合わせ」ページの見本です。実際にお使いになる際は、貴社の連絡先に書き換えるか、`app/layout.tsx` の `data-contact-url` を既存のお問い合わせページに向けてください。

## 5. Vercel に置く手順

1. Vercel でこのリポジトリ（またはこのフォルダ）を Import します。`vercel` CLI から置く場合も同じ手順です。
2. **初回のデプロイより前に**、上の環境変数を Vercel のプロジェクト設定に入れてください。デプロイ後に追加・変更した場合は、再デプロイしないと反映されません。
3. デプロイの前に `npx ai-concierge index`（`npm run index` でも同じです）を実行し、`data/index.json` をフォルダに用意してください。Vercel 上では索引を作れません。
4. `route.ts` の `export const maxDuration = 60` は、プランで許可された秒数までしか効きません。Hobby プランの上限は 10 秒のため、Hobby でお使いの場合は `route.ts` の `maxDuration` を短く書き換えてください。

## 6. ほかのサイトに窓だけ置く

`public/ai-concierge.js` と `public/ai-concierge.css` を置いたページに、次の 2 行を貼ります。

```html
<link rel="stylesheet" href="https://＜このアプリの URL＞/ai-concierge.css">
<script src="https://＜このアプリの URL＞/ai-concierge.js" data-endpoint="https://＜このアプリの URL＞/api/concierge"></script>
```

`ALLOWED_ORIGINS` に、貼り付け先のサイトの URL を入れてください。
