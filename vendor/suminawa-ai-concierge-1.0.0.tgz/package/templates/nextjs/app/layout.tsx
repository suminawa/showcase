import type { ReactNode } from "react";

export const metadata = {
  title: "みなと工務店",
  description: "AI 案内窓口を置いた見本のサイトです。",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ja">
      <head>
        <link rel="stylesheet" href="/ai-concierge.css" />
      </head>
      <body style={{ fontFamily: "system-ui, sans-serif", margin: "0 auto", maxWidth: "44rem", padding: "3rem 1rem 8rem", lineHeight: 1.8 }}>
        {children}
        <script
          src="/ai-concierge.js"
          data-endpoint="/api/concierge"
          data-greeting="こんにちは。みなと工務店の案内窓口です。料金や対応エリア、工事の流れなどをお答えします。"
          data-suggestions="対応エリアはどこまでですか|見積もりは無料ですか|工事中も住み続けられますか"
          data-contact-url="/contact"
        />
      </body>
    </html>
  );
}
